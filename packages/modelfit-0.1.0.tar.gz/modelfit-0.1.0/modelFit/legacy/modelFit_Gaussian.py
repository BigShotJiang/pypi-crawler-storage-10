"""Gaussian-focused maximum-likelihood and MAP estimation utilities.

The refactor streamlines the original workflow to concentrate on Gaussian
observation models, enforce explicit input contracts, and provide verbose
diagnostics during optimisation. The module exposes compact helpers that return
homogeneous outputs which are easy to inspect programmatically or interactively.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

from mpl_toolkits.axes_grid1.inset_locator import inset_axes

import math
import os
import platform
import sys

import numpy as np
from scipy import stats
from scipy.optimize import OptimizeResult, minimize
from scipy.special import betaln, gammaln

ArrayLike = Union[np.ndarray, Sequence[float]]
ModelFunction = Callable[[np.ndarray, np.ndarray], np.ndarray]
SigmaFunction = Callable[[np.ndarray], float]
Bounds = Optional[Sequence[Tuple[Optional[float], Optional[float]]]]


class VerboseLogger:
    """Collects optimisation messages and optionally echoes them to stdout."""

    def __init__(self, enabled: bool) -> None:
        self.enabled = bool(enabled)
        self.messages: List[str] = []
        self._iteration = 0

    def log(self, message: str) -> None:
        text = f"[GaussianFit] {message}"
        self.messages.append(text)
        if self.enabled:
            print(text)

    def callback(self) -> Callable[[np.ndarray], None]:
        def _callback(theta: np.ndarray) -> None:
            self._iteration += 1
            theta_str = np.array2string(
                np.asarray(theta, dtype=float),
                precision=4,
                separator=", ",
            )
            self.log(f"iter {self._iteration}: theta={theta_str}")

        return _callback


@dataclass(frozen=True)
class FitUncertainty:
    """Aggregates parameter uncertainty diagnostics."""

    covariance: Optional[np.ndarray]
    standard_errors: Optional[np.ndarray]
    method: str
    bootstrap_estimates: Optional[np.ndarray] = None
    confidence_intervals: Optional[np.ndarray] = None
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FitMetrics:
    """Summarises goodness-of-fit diagnostics across observation families."""

    r_squared: float
    sse: float
    mse: float
    rmse: float
    aic: float
    bic: float
    n_obs: int
    n_params: int
    sigma_hat: float
    extra: Dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class LikelihoodSurface:
    """Dense log-likelihood evaluations across a two-parameter grid."""

    param_indices: Tuple[int, int]
    axis0: np.ndarray
    axis1: np.ndarray
    log_likelihood: np.ndarray


@dataclass
class FitResult:
    """Container for the optimisation outcome and derived diagnostics."""

    success: bool
    mode: str
    params: np.ndarray
    fun: float
    log_likelihood: float
    log_prior: Optional[float]
    log_posterior: float
    fitted: np.ndarray
    residuals: np.ndarray
    uncertainty: FitUncertainty
    metrics: FitMetrics
    optimizer_result: OptimizeResult
    history: Sequence[str]
    likelihood_surface: Optional[LikelihoodSurface] = None

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serialisable representation of the fit outcome."""

        return {
            "success": bool(self.success),
            "mode": str(self.mode),
            "params": self.params.tolist(),
            "objective": float(self.fun),
            "log_likelihood": float(self.log_likelihood),
            "log_prior": None if self.log_prior is None else float(self.log_prior),
            "log_posterior": float(self.log_posterior),
            "fitted": self.fitted.tolist(),
            "residuals": self.residuals.tolist(),
            "uncertainty": {
                "method": str(self.uncertainty.method),
                "covariance": None
                if self.uncertainty.covariance is None
                else self.uncertainty.covariance.tolist(),
                "standard_errors": None
                if self.uncertainty.standard_errors is None
                else self.uncertainty.standard_errors.tolist(),
                "bootstrap_estimates": None
                if self.uncertainty.bootstrap_estimates is None
                else self.uncertainty.bootstrap_estimates.tolist(),
                "confidence_intervals": None
                if self.uncertainty.confidence_intervals is None
                else self.uncertainty.confidence_intervals.tolist(),
                "extras": {
                    name: (value.tolist() if hasattr(value, "tolist") else value)
                    for name, value in self.uncertainty.extras.items()
                },
            },
            "metrics": {
                "r_squared": float(self.metrics.r_squared),
                "sse": float(self.metrics.sse),
                "mse": float(self.metrics.mse),
                "rmse": float(self.metrics.rmse),
                "aic": float(self.metrics.aic),
                "bic": float(self.metrics.bic),
                "n_obs": int(self.metrics.n_obs),
                "n_params": int(self.metrics.n_params),
                "sigma_hat": float(self.metrics.sigma_hat),
                "extra": {name: float(value) for name, value in self.metrics.extra.items()},
            },
            "history": list(self.history),
            "likelihood_surface": None
            if self.likelihood_surface is None
            else {
                "param_indices": list(self.likelihood_surface.param_indices),
                "axis0": self.likelihood_surface.axis0.tolist(),
                "axis1": self.likelihood_surface.axis1.tolist(),
                "log_likelihood": self.likelihood_surface.log_likelihood.tolist(),
            },
        }

    def summary(self) -> Dict[str, Any]:
        """Alias for backwards compatibility with previous API."""

        return self.to_dict()

# ---------------------------------------------------------------------------
# Data coercion utilities
# ---------------------------------------------------------------------------

def _coerce_float_array(name: str, value: ArrayLike) -> np.ndarray:
    """Return ``value`` as a finite float array or raise a descriptive error."""
    try:
        array = np.asarray(value, dtype=float)
    except TypeError as exc:  # pragma: no cover - defensive
        raise TypeError(
            f"`{name}` must be convertible to a float array. Received type {type(value).__name__}."
        ) from exc
    if array.size == 0:
        raise ValueError(f"`{name}` must contain at least one element.")
    if not np.isfinite(array).all():
        raise ValueError(f"`{name}` must not contain NaN or infinite values.")
    return array


def _ensure_2d_features(x_arr: np.ndarray) -> np.ndarray:
    """Ensure feature matrix has shape ``(n_samples, n_features)``."""
    if x_arr.ndim == 1:
        return x_arr.reshape(-1, 1)
    if x_arr.ndim != 2:
        raise ValueError(
            "`x` must be convertible to a 2D float array with shape (n_samples, n_features). "
            f"Received array with ndim={x_arr.ndim} and shape {x_arr.shape}."
        )
    return x_arr


def _ensure_1d_response(y_arr: np.ndarray, name: str = "y") -> np.ndarray:
    """Ensure response vector is one-dimensional with ``n_samples`` entries."""
    if y_arr.ndim != 1:
        raise ValueError(
            f"`{name}` must be convertible to a 1D float array with shape (n_samples,). "
            f"Received array with ndim={y_arr.ndim} and shape {y_arr.shape}."
        )
    return y_arr


def _ensure_theta(initial_params: ArrayLike) -> np.ndarray:
    """Validate and return the parameter initialisation vector."""
    theta = _coerce_float_array("initial_params", initial_params)
    if theta.ndim != 1:
        raise ValueError(
            "`initial_params` must be a 1D float array with shape (n_params,). "
            f"Received array with ndim={theta.ndim} and shape {theta.shape}."
        )
    return theta


def _validate_bounds(bounds: Bounds, n_params: int) -> Optional[List[Tuple[Optional[float], Optional[float]]]]:
    """Normalise optimiser bounds into a list of ``(lower, upper)`` tuples."""
    if bounds is None:
        return None
    if len(bounds) != n_params:
        raise ValueError(
            "`bounds` must contain one (lower, upper) tuple per parameter. "
            f"Received {len(bounds)} tuples for {n_params} parameters."
        )
    formatted: List[Tuple[Optional[float], Optional[float]]] = []
    for idx, pair in enumerate(bounds):
        if not isinstance(pair, Sequence) or len(pair) != 2:
            raise TypeError(
                f"`bounds[{idx}]` must be a tuple-like pair `(lower, upper)`."
            )
        lower, upper = pair
        lower_f: Optional[float] = None if lower is None else float(lower)
        upper_f: Optional[float] = None if upper is None else float(upper)

        if lower_f is not None and math.isnan(lower_f):
            raise ValueError("Lower bounds must be finite numbers, ±inf, or None.")
        if upper_f is not None and math.isnan(upper_f):
            raise ValueError("Upper bounds must be finite numbers, ±inf, or None.")

        if lower_f is not None and upper_f is not None:
            if math.isfinite(lower_f) and math.isfinite(upper_f) and upper_f <= lower_f:
                raise ValueError("Each bounds tuple must satisfy lower < upper when both are finite.")

        formatted.append((lower_f, upper_f))
    return formatted


# ---------------------------------------------------------------------------
# Prior factory utilities
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PriorInfo:
    """Encapsulates log-prior evaluation for MAP estimation across families."""

    enabled: bool
    distribution: str = "gaussian"
    log_prior_fn: Optional[Callable[[np.ndarray], float]] = None
    component_log_prior_fn: Optional[Callable[[np.ndarray], np.ndarray]] = None
    parameters: Dict[str, np.ndarray] = field(default_factory=dict)

    def evaluate(self, theta: np.ndarray) -> float:
        """Evaluate the configured log prior at ``theta``."""
        if not self.enabled:
            return 0.0
        if self.log_prior_fn is None:
            raise RuntimeError("PriorInfo requires a log_prior_fn when enabled.")
        return float(self.log_prior_fn(theta))

    def component_log_density(self, theta: np.ndarray) -> np.ndarray:
        """Return per-parameter log prior contributions for ``theta``."""
        if not self.enabled or self.component_log_prior_fn is None:
            return np.zeros_like(np.asarray(theta, dtype=float))
        return np.asarray(self.component_log_prior_fn(theta), dtype=float)


def _build_prior(
    mode: str,
    theta0: np.ndarray,
    prior_distribution: str,
    *,
    prior_mean: Optional[ArrayLike],
    prior_variance: Optional[ArrayLike],
    prior_prob: Optional[ArrayLike],
    prior_rate: Optional[ArrayLike],
    prior_alpha: Optional[ArrayLike],
    prior_beta: Optional[ArrayLike],
) -> PriorInfo:
    """Construct prior metadata for MAP estimation from user inputs."""

    if mode == "mle":
        return PriorInfo(enabled=False)

    distribution = str(prior_distribution).lower()
    if distribution not in {"gaussian", "bernoulli", "poisson", "beta"}:
        raise ValueError(
            "`prior_distribution` must be one of {'gaussian', 'bernoulli', 'poisson', 'beta'}."
        )

    def _validate_shape(name: str, arr: np.ndarray) -> None:
        if arr.ndim != 1 or arr.shape != theta0.shape:
            raise ValueError(
                f"`{name}` must be a 1D float array with shape {theta0.shape}. Received shape {arr.shape}."
            )

    eps = 1e-12  # Small constant to keep log terms finite.

    if distribution == "gaussian":
        # Relevant when parameters are expected to follow a normal distribution.
        if prior_mean is None or prior_variance is None:
            raise ValueError(
                "Gaussian priors require `prior_mean` and `prior_variance` arrays matching `initial_params`."
            )
        mean_arr = _coerce_float_array("prior_mean", prior_mean)
        var_arr = _coerce_float_array("prior_variance", prior_variance)
        _validate_shape("prior_mean", mean_arr)
        _validate_shape("prior_variance", var_arr)
        if np.any(var_arr <= 0):
            raise ValueError("All entries in `prior_variance` must be strictly positive.")
        log_det = np.log(2.0 * np.pi * var_arr)

        def _log_prior(theta: np.ndarray) -> float:
            diff = theta - mean_arr
            # Diagonal Gaussian log density evaluated at theta.
            return -0.5 * float(np.sum(diff**2 / var_arr + log_det))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            diff = theta_arr - mean_arr
            return -0.5 * (diff**2 / var_arr + log_det)

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"mean": mean_arr, "variance": var_arr},
        )

    if distribution == "bernoulli":
        # Relevant when parameters represent probabilities constrained to [0, 1].
        if prior_prob is None:
            raise ValueError("Bernoulli priors require `prior_prob` with success probabilities per parameter.")
        prob_arr = _coerce_float_array("prior_prob", prior_prob)
        _validate_shape("prior_prob", prob_arr)
        if np.any((prob_arr <= 0) | (prob_arr >= 1)):
            raise ValueError("`prior_prob` entries must lie strictly between 0 and 1 for Bernoulli priors.")
        log_prob = np.log(np.clip(prob_arr, eps, 1 - eps))
        log_one_minus = np.log(np.clip(1.0 - prob_arr, eps, 1 - eps))

        def _log_prior(theta: np.ndarray) -> float:
            theta_arr = np.asarray(theta, dtype=float)
            if theta_arr.shape != prob_arr.shape:
                raise ValueError("Theta and Bernoulli prior arrays must share the same shape.")
            if np.any((theta_arr < -eps) | (theta_arr > 1 + eps)):
                raise ValueError("Bernoulli priors expect parameters constrained to [0, 1].")
            theta_clipped = np.clip(theta_arr, 0.0, 1.0)
            # Bernoulli log mass for independent parameters.
            return float(np.sum(theta_clipped * log_prob + (1.0 - theta_clipped) * log_one_minus))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            theta_clipped = np.clip(theta_arr, 0.0, 1.0)
            return theta_clipped * log_prob + (1.0 - theta_clipped) * log_one_minus

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"prob": prob_arr},
        )

    if distribution == "poisson":
        # Relevant when parameters are expected to be sparse and non-negative.
        if prior_rate is None:
            raise ValueError("Poisson priors require `prior_rate` with positive rate parameters per coefficient.")
        rate_arr = _coerce_float_array("prior_rate", prior_rate)
        _validate_shape("prior_rate", rate_arr)
        if np.any(rate_arr <= 0):
            raise ValueError("`prior_rate` entries must be strictly positive for Poisson priors.")

        def _log_prior(theta: np.ndarray) -> float:
            theta_arr = np.asarray(theta, dtype=float)
            if theta_arr.shape != rate_arr.shape:
                raise ValueError("Theta and Poisson prior arrays must share the same shape.")
            if np.any(theta_arr < 0):
                raise ValueError("Poisson priors expect non-negative parameters.")
            theta_clipped = np.clip(theta_arr, 0.0, None)
            # Use gammaln to retain numerical stability for factorial terms.
            return float(np.sum(theta_clipped * np.log(rate_arr) - rate_arr - gammaln(theta_clipped + 1.0)))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            theta_clipped = np.clip(theta_arr, 0.0, None)
            return theta_clipped * np.log(rate_arr) - rate_arr - gammaln(theta_clipped + 1.0)

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"rate": rate_arr},
        )

    # Beta prior as final branch.
    # Relevant when parameters are probabilities with prior beliefs about their distribution.
    if prior_alpha is None or prior_beta is None:
        raise ValueError("Beta priors require `prior_alpha` and `prior_beta` arrays.")
    alpha_arr = _coerce_float_array("prior_alpha", prior_alpha)
    beta_arr = _coerce_float_array("prior_beta", prior_beta)
    _validate_shape("prior_alpha", alpha_arr)
    _validate_shape("prior_beta", beta_arr)
    if np.any(alpha_arr <= 0) or np.any(beta_arr <= 0):
        raise ValueError("`prior_alpha` and `prior_beta` entries must be strictly positive for Beta priors.")
    log_norm = betaln(alpha_arr, beta_arr)

    def _log_prior(theta: np.ndarray) -> float:
        theta_arr = np.asarray(theta, dtype=float)
        if theta_arr.shape != alpha_arr.shape:
            raise ValueError("Theta and Beta prior arrays must share the same shape.")
        if np.any((theta_arr <= 0) | (theta_arr >= 1)):
            raise ValueError("Beta priors expect parameters strictly within (0, 1).")
        theta_clipped = np.clip(theta_arr, eps, 1 - eps)
        log_density = (alpha_arr - 1.0) * np.log(theta_clipped) + (beta_arr - 1.0) * np.log(1.0 - theta_clipped) - log_norm
        return float(np.sum(log_density))

    def _component(theta: np.ndarray) -> np.ndarray:
        theta_arr = np.asarray(theta, dtype=float)
        theta_clipped = np.clip(theta_arr, eps, 1 - eps)
        return (alpha_arr - 1.0) * np.log(theta_clipped) + (beta_arr - 1.0) * np.log(1.0 - theta_clipped) - log_norm

    return PriorInfo(
        enabled=True,
        distribution=distribution,
        log_prior_fn=_log_prior,
        component_log_prior_fn=_component,
        parameters={"alpha": alpha_arr, "beta": beta_arr},
    )


# ---------------------------------------------------------------------------
# Observation model evaluation
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EvaluationResult:
    """Wraps model evaluation outputs for downstream bookkeeping."""

    fitted: np.ndarray
    residuals: np.ndarray
    sigma: Optional[float]
    log_likelihood: float
    extras: Dict[str, Any] = field(default_factory=dict)

class ObservationModelEvaluator:
    """Evaluates model predictions and log-likelihood across observation families."""

    def __init__(
        self,
        model_fn: ModelFunction,
        x: np.ndarray,
        y: np.ndarray,
        sigma_fn: Optional[SigmaFunction],
        profile_sigma: bool,
        distribution: str,
        n_trials: Optional[np.ndarray],
    ) -> None:
        self.model_fn = model_fn
        self.x = x
        self.y = y
        self.sigma_fn = sigma_fn
        self.profile_sigma = bool(profile_sigma)
        self.distribution = distribution
        self.n_trials = n_trials

    def evaluate(self, theta: np.ndarray) -> EvaluationResult:
        """Return fitted expectation, residuals, and log-likelihood for ``theta``."""
        raw_prediction = np.asarray(self.model_fn(theta, self.x), dtype=float).reshape(-1)
        if raw_prediction.shape != self.y.shape:
            raise ValueError(
                "`model_fn` must return a 1D float array matching the shape of `y`. "
                f"Received shape {raw_prediction.shape}, expected {self.y.shape}."
            )

        if self.distribution == "gaussian":
            residuals = self.y - raw_prediction
            sigma = self._compute_sigma(theta, residuals)
            log_likelihood = gaussian_log_likelihood(residuals, sigma)
            return EvaluationResult(
                fitted=raw_prediction,
                residuals=residuals,
                sigma=sigma,
                log_likelihood=log_likelihood,
                extras={"sigma": sigma},
            )

        if self.distribution == "binomial":
            probs = _sigmoid(raw_prediction)
            trials = self.n_trials if self.n_trials is not None else np.ones_like(self.y)
            expectation = trials * probs
            residuals = self.y - expectation
            log_likelihood = binomial_log_likelihood(self.y, probs, trials)
            return EvaluationResult(
                fitted=expectation,
                residuals=residuals,
                sigma=None,
                log_likelihood=log_likelihood,
                extras={"probabilities": probs, "n_trials": trials},
            )

        if self.distribution == "poisson":
            rate = np.exp(raw_prediction)
            residuals = self.y - rate
            log_likelihood = poisson_log_likelihood(self.y, rate)
            return EvaluationResult(
                fitted=rate,
                residuals=residuals,
                sigma=None,
                log_likelihood=log_likelihood,
                extras={"rate": rate},
            )

        raise ValueError(f"Unsupported output distribution: {self.distribution}")

    def _compute_sigma(self, theta: np.ndarray, residuals: np.ndarray) -> float:
        """Determine the observation scale either from ``sigma_fn`` or profiling."""
        if self.sigma_fn is not None:
            sigma = float(self.sigma_fn(theta))
            if not np.isfinite(sigma) or sigma <= 0:
                raise ValueError(
                    "`sigma_fn` must return a positive finite scalar for every theta."
                )
            return sigma

        if self.profile_sigma:
            sigma = float(np.sqrt(np.mean(residuals**2)))
            if not np.isfinite(sigma) or sigma <= 0:
                raise ValueError(
                    "Residual-based sigma estimation failed. Ensure the model produces non-degenerate residuals."
                )
            return sigma

        raise ValueError(
            "Provide `sigma_fn` or set `profile_sigma=True` to specify the observation noise scale."
        )


@dataclass
class EvaluationState:
    """Snapshot of the objective landscape at a given parameter vector."""

    theta: np.ndarray
    evaluation: EvaluationResult
    log_prior: float
    log_posterior: float
    objective: float
    assigned: bool = False


@dataclass
class ParameterProfile:
    """One-dimensional profile of log densities for a single parameter."""

    grid: np.ndarray
    log_likelihood: np.ndarray
    log_prior: np.ndarray
    log_posterior: np.ndarray


class ObjectiveTracker:
    """Wraps the scalar objective to keep optimisation state in sync with the monitor."""

    def __init__(
        self,
        evaluator: ObservationModelEvaluator,
        prior_info: PriorInfo,
        monitor: "OptimisationMonitor",
    ) -> None:
        self._evaluator = evaluator
        self._prior_info = prior_info
        self._monitor = monitor

    def __call__(self, theta: np.ndarray) -> float:
        return self.evaluate(theta, record=True)

    def evaluate(self, theta: np.ndarray, *, record: bool = True) -> float:
        theta_arr = np.asarray(theta, dtype=float).reshape(-1)
        evaluation = self._evaluator.evaluate(theta_arr)
        log_prior = self._prior_info.evaluate(theta_arr)
        log_posterior = evaluation.log_likelihood + log_prior
        objective = -log_posterior
        state = EvaluationState(
            theta=theta_arr.copy(),
            evaluation=evaluation,
            log_prior=log_prior,
            log_posterior=log_posterior,
            objective=objective,
        )
        if record:
            self._monitor.record(state)
        else:
            self._monitor.set_last_state(state)
        return objective

    @property
    def last_state(self) -> Optional[EvaluationState]:
        return self._monitor.last_state


# ---------------------------------------------------------------------------
# Visualisation utilities
# ---------------------------------------------------------------------------

class _QtTabContext:
    """Handle for a Qt tab embedding a Matplotlib canvas."""

    def __init__(
        self,
        app: Any,
        tabs: Any,
        tab_widget: Any,
        canvas: Any,
        original_window: Any,
    ) -> None:
        self._app = app
        self._tabs = tabs
        self._tab_widget = tab_widget
        self._canvas = canvas
        self._original_window = original_window

    def process_events(self) -> None:
        if self._app is not None:
            self._app.processEvents()

    def close(self) -> None:
        if self._tabs is not None and self._tab_widget is not None:
            index = self._tabs.indexOf(self._tab_widget)
            if index != -1:
                self._tabs.removeTab(index)
        if self._canvas is not None:
            try:
                self._canvas.setParent(None)
                self._canvas.close()
                delete_later = getattr(self._canvas, "deleteLater", None)
                if callable(delete_later):
                    delete_later()
            except Exception:
                pass
        if self._original_window is not None:
            self._original_window.close()
        self._tab_widget = None
        self._canvas = None
        self._original_window = None


class _QtTabManager:
    """Shared Qt tab host that stacks multiple optimisation dashboards."""

    def __init__(self, matplotlib_module: Any) -> None:
        self.available = False
        self._app: Optional[Any] = None
        self._window: Any = None
        self._tabs: Any = None
        self._figure_context: Dict[Any, _QtTabContext] = {}
        self._run_counter = 0

        backend = matplotlib_module.get_backend().lower()
        if "qt" not in backend:
            return

        try:
            from matplotlib.backends import qt_compat  # type: ignore
            from matplotlib.backends.backend_qtagg import NavigationToolbar2QT  # type: ignore
        except Exception:
            return

        QtWidgets = getattr(qt_compat, "QtWidgets", None)
        if QtWidgets is None:
            return

        self.available = True
        self._QtWidgets = QtWidgets
        self._NavigationToolbar = NavigationToolbar2QT
        try:
            self._app = qt_compat._create_qApp()  # type: ignore[attr-defined]
        except AttributeError:
            # Fallback for older Matplotlib that does not expose _create_qApp
            self._app = QtWidgets.QApplication.instance()
            if self._app is None:
                self._app = QtWidgets.QApplication(sys.argv or [""])

    def attach(self, figure_or_canvas: Any, label: Optional[str]) -> Optional[_QtTabContext]:
        if not self.available:
            return None

        canvas: Any
        figure: Any
        if hasattr(figure_or_canvas, "figure") and hasattr(figure_or_canvas, "mpl_connect"):
            canvas = figure_or_canvas
            figure = getattr(canvas, "figure", None)
        else:
            figure = figure_or_canvas
            canvas = getattr(figure, "canvas", None)
        if canvas is None:
            return None
        manager = getattr(canvas, "manager", None)
        window = getattr(manager, "window", None)
        if window is None:
            window = None

        QtWidgets = self._QtWidgets
        if self._window is None:
            self._window = QtWidgets.QMainWindow()
            self._window.setWindowTitle("Gaussian Fit Dashboard")
            self._tabs = QtWidgets.QTabWidget()
            self._tabs.setTabsClosable(False)
            self._window.setCentralWidget(self._tabs)
            self._window.resize(1280, 720)

        tab_container = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab_container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        toolbar = self._NavigationToolbar(canvas, tab_container)
        layout.addWidget(toolbar)
        layout.addWidget(canvas)
        if hasattr(canvas, "setParent"):
            canvas.setParent(tab_container)

        display_label = label or f"Run {self._run_counter + 1}"
        index = self._tabs.addTab(tab_container, display_label)
        self._tabs.setCurrentIndex(index)
        self._window.show()
        if window is not None:
            window.hide()

        key = figure if figure is not None else canvas
        context = _QtTabContext(self._app, self._tabs, tab_container, canvas, window)
        self._figure_context[key] = context
        self._run_counter += 1

        def _close_handler(_: Any) -> None:
            self.detach(key)

        target = canvas
        if hasattr(target, "mpl_connect"):
            target.mpl_connect("close_event", _close_handler)
        self.process_events()
        return context

    def detach(self, key: Any) -> None:
        context = self._figure_context.pop(key, None)
        if context is not None:
            context.close()
        if self._tabs is not None and self._tabs.count() == 0 and self._window is not None:
            self._window.hide()

    def process_events(self) -> None:
        if self._app is not None:
            self._app.processEvents()

    def close_all(self) -> None:
        for fig in list(self._figure_context.keys()):
            self.detach(fig)
        if self._window is not None:
            self._window.close()
            self._window = None
            self._tabs = None


_TAB_MANAGER: Optional[_QtTabManager] = None


def _get_tab_manager(matplotlib_module: Any) -> Optional[_QtTabManager]:
    global _TAB_MANAGER
    if _TAB_MANAGER is None:
        _TAB_MANAGER = _QtTabManager(matplotlib_module)
    if _TAB_MANAGER.available:
        return _TAB_MANAGER
    return None


class DynamicDisplay:
    """Matplotlib-powered dashboard to follow optimisation progress in real time."""

    def __init__(
        self,
        n_params: int,
        *,
        surface_enabled: bool,
        surface_indices: Optional[Tuple[int, int]],
        map_enabled: bool,
        display_label: Optional[str] = None,
        prior_payload: Optional[Dict[str, Any]] = None,
        allow_backend_switch: bool = False,
    ) -> None:
        try:
            import matplotlib
            import matplotlib.pyplot as plt
            from matplotlib import gridspec
        except ImportError as exc:  # pragma: no cover - runtime safeguard
            raise RuntimeError(
                "Dynamic display requires matplotlib to be installed. Install it or set display=False."
            ) from exc

        backend_name = matplotlib.get_backend().lower()
        self._allow_backend_switch = bool(allow_backend_switch)

        def _backend_supports_gui(name: str) -> bool:
            from matplotlib import rcsetup

            lowered = name.lower()

            if lowered.startswith("module://"):
                if "matplotlib_inline" in lowered or "ipympl" in lowered:
                    return False

            non_gui_exact = {
                "agg",
                "pdf",
                "ps",
                "svg",
                "cairo",
                "pgf",
                "template",
                "nbagg",
                "webagg",
                "inline",
            }
            if lowered in non_gui_exact:
                return False

            interactive_backends = {bk.lower() for bk in rcsetup.interactive_bk}
            interactive_backends.update({"qtagg", "qt6agg"})

            return lowered in interactive_backends or lowered.startswith("qt") or lowered == "macosx"

        attempted = backend_name

        def _try_switch(candidates: Sequence[str]) -> Optional[str]:
            nonlocal plt
            for candidate in candidates:
                try:
                    plt.switch_backend(candidate)
                except Exception:
                    continue
                candidate_backend = matplotlib.get_backend().lower()
                if _backend_supports_gui(candidate_backend):
                    return candidate_backend
            return None

        gui_backend = _backend_supports_gui(backend_name)

        if not gui_backend and self._allow_backend_switch:
            if "qt" not in backend_name:
                qt_candidates = ["QtAgg", "Qt6Agg", "Qt5Agg", "Qt4Agg"]
                new_backend = _try_switch(qt_candidates)
                if new_backend is not None and "qt" in new_backend:
                    backend_name = new_backend
                    gui_backend = _backend_supports_gui(backend_name)

            if not gui_backend:
                system_name = platform.system()
                fallback_candidates: List[str]
                if system_name == "Darwin":
                    fallback_candidates = ["macosx", "QtAgg", "Qt5Agg", "TkAgg"]
                elif system_name == "Windows":
                    fallback_candidates = ["QtAgg", "Qt5Agg", "TkAgg"]
                else:
                    fallback_candidates = ["QtAgg", "Qt5Agg", "TkAgg"]

                new_backend = _try_switch(fallback_candidates)
                if new_backend is not None:
                    backend_name = new_backend
                    gui_backend = _backend_supports_gui(backend_name)

        if not gui_backend:
            raise RuntimeError(
                "Dynamic display requires a GUI matplotlib backend. "
                f"Current backend '{attempted}' cannot open pop-up windows. "
                "Either activate one manually (e.g. `%matplotlib qt`) or pass "
                "`display_backend_fallback=True` to `fit_gaussian` to enable automatic switching."
            )

        self._plt = plt
        self._surface_enabled = surface_enabled
        self._surface_indices = surface_indices
        self.map_enabled = map_enabled
        plt.ion()
        self._tab_context: Optional[_QtTabContext] = None
        self._canvas: Any
        self._prior_payload = prior_payload if map_enabled else None
        self._prior_text_artist: Optional[Any] = None
        self._prior_mean_lines: List[Any] = []
        self._prior_band_patches: List[Any] = []
        tab_manager = _get_tab_manager(matplotlib)

        figure_created = False
        if tab_manager is not None:
            try:
                from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
                from matplotlib.figure import Figure
            except Exception:
                FigureCanvasQTAgg = None
                Figure = None  # type: ignore[assignment]
            if FigureCanvasQTAgg is not None and Figure is not None:
                self.fig = Figure(figsize=(13.0, 8.0), constrained_layout=True)
                self._canvas = FigureCanvasQTAgg(self.fig)
                self._tab_context = tab_manager.attach(self._canvas, display_label)
                figure_created = True

        if not figure_created:
            self.fig = plt.figure(figsize=(13.0, 8.0), constrained_layout=True)
            self._canvas = self.fig.canvas

        if self._tab_context is None and tab_manager is not None:
            self._tab_context = tab_manager.attach(self._canvas, display_label)
        if hasattr(self.fig, "set_constrained_layout_pads"):
            self.fig.set_constrained_layout_pads(w_pad=0.18, h_pad=0.18, wspace=0.18, hspace=0.18)

        if map_enabled:
            primary_spec = gridspec.GridSpec(
                1,
                2,
                figure=self.fig,
                width_ratios=[1.0, 0.42],
                wspace=0.82,
            )
            grid = gridspec.GridSpecFromSubplotSpec(
                2,
                2,
                subplot_spec=primary_spec[0, 0],
                height_ratios=[1.05, 1.3],
                width_ratios=[1.0, 1.85],
                hspace=0.1,
                wspace=0.12,
            )
            profiles_parent = primary_spec[0, 1]
        else:
            grid = gridspec.GridSpec(
                2,
                2,
                figure=self.fig,
                height_ratios=[1.05, 1.3],
                width_ratios=[1.0, 1.85],
                hspace=0.1,
                wspace=0.12,
            )
            profiles_parent = None

        self.fig.subplots_adjust(left=0.055, right=0.975, top=0.97, bottom=0.075)

        self.ax_objective = self.fig.add_subplot(grid[0, 0])
        self.ax_objective.set_title("Objective Value")
        self.ax_objective.set_xlabel("Iteration")
        self.ax_objective.set_ylabel("-log posterior" if self.map_enabled else "-log likelihood")
        self.ax_objective.grid(True, alpha=0.25)
        (self._objective_line,) = self.ax_objective.plot([], [], color="#1f77b4")
        self._objective_text = self.ax_objective.text(
            0.02,
            -0.18,
            "",
            transform=self.ax_objective.transAxes,
            va="top",
            ha="left",
            clip_on=False,
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
        )

        self.ax_scatter = self.fig.add_subplot(grid[0, 1])
        self.ax_scatter.set_title("Observed vs predicted")
        self.ax_scatter.set_xlabel("Observed")
        self.ax_scatter.set_ylabel("Predicted")
        self.ax_scatter.grid(True, alpha=0.25)
        self.ax_scatter.set_aspect("equal", adjustable="box")
        (self._scatter_points,) = self.ax_scatter.plot(
            [],
            [],
            linestyle="",
            marker="o",
            markersize=4.5,
            color="#ff7f0e",
            alpha=0.6,
        )
        (self._identity_line,) = self.ax_scatter.plot([], [], linestyle="--", color="#666666", linewidth=1.0)
        self._scatter_text = self.ax_scatter.text(
            0.02,
            -0.18,
            "",
            transform=self.ax_scatter.transAxes,
            va="top",
            ha="left",
            clip_on=False,
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
        )

        if surface_enabled:
            self.ax_parameters = self.fig.add_subplot(grid[1, 0])
            self.ax_surface = self.fig.add_subplot(grid[1, 1])
            self.ax_surface.set_title("Log-likelihood surface")
            if surface_indices is not None:
                self.ax_surface.set_xlabel(f"θ{surface_indices[0]}")
                self.ax_surface.set_ylabel(f"θ{surface_indices[1]}")
            self.ax_surface.grid(False)
            if hasattr(self.ax_surface, "set_box_aspect"):
                self.ax_surface.set_box_aspect(1)
            else:
                self.ax_surface.set_aspect("equal", adjustable="box")
            self._surface_cbar_ax = inset_axes(
                self.ax_surface,
                width="3%",
                height="100%",
                loc="lower left",
                bbox_to_anchor=(1.02, 0.0, 1.0, 1.0),
                bbox_transform=self.ax_surface.transAxes,
                borderpad=0.0,
            )
            self._surface_cbar_ax.yaxis.set_ticks_position("right")
            self._surface_cbar_ax.yaxis.set_label_position("right")
            self._surface_cbar_ax.tick_params(
                left=False,
                right=True,
                labelleft=False,
                labelright=True,
                pad=2,
            )
            self._surface_image = None
            self._surface_point = None
            self._surface_path = None
            self._surface_colorbar = None
        else:
            self.ax_parameters = self.fig.add_subplot(grid[1, 0:2])
            self.ax_surface = None
            self._surface_image = None
            self._surface_point = None
            self._surface_path = None
            self._surface_cbar_ax = None
            self._surface_colorbar = None

        self.ax_parameters.set_title("Parameter trajectories")
        self.ax_parameters.set_xlabel("Iteration")
        self.ax_parameters.set_ylabel("Value")
        self.ax_parameters.grid(True, alpha=0.25)

        cmap = plt.cm.get_cmap("tab10", max(n_params, 10))
        self._param_lines: List[Any] = []
        for idx in range(n_params):
            color = cmap(idx % cmap.N)
            (line,) = self.ax_parameters.plot([], [], label=f"θ{idx}", color=color)
            self._param_lines.append(line)
        self._legend_shown = False

        if hasattr(self._canvas, "draw_idle"):
            self._canvas.draw_idle()
        if hasattr(self._canvas, "flush_events"):
            self._canvas.flush_events()

        if self.map_enabled and self._prior_payload is not None:
            self._initialise_prior_annotations()

        self._profile_axes: List[Any] = []
        self._profile_lines: List[Dict[str, Any]] = []
        if map_enabled and profiles_parent is not None:
            rows = n_params
            # Nested spec keeps the profile column peeled away from the 2x2 dashboard.
            profiles_spec = gridspec.GridSpecFromSubplotSpec(
                rows,
                1,
                subplot_spec=profiles_parent,
                hspace=0.16,
            )
            for idx in range(rows):
                ax = self.fig.add_subplot(profiles_spec[idx, 0])
                ax.set_title(f"θ{idx} profile")
                ax.set_xlabel("Value")
                ax.set_ylabel("Log density (normalised)")
                ax.grid(True, alpha=0.25)
                (line_prior,) = ax.plot([], [], linestyle="--", color="#2ca02c", label="log prior")
                (line_like,) = ax.plot([], [], linestyle="-.", color="#9467bd", label="log likelihood")
                (line_post,) = ax.plot([], [], linestyle="-", color="#d62728", label="log posterior")
                if idx == rows - 1:
                    legend = ax.legend(
                        loc="lower center",
                        bbox_to_anchor=(0.5, -0.32),
                        borderaxespad=0.0,
                        frameon=False,
                        ncol=3,
                    )
                    legend.set_draggable(False)
                self._profile_axes.append(ax)
                self._profile_lines.append(
                    {
                        "prior": line_prior,
                        "likelihood": line_like,
                        "posterior": line_post,
                    }
                )

    def _initialise_prior_annotations(self) -> None:
        prior = self._prior_payload
        if prior is None:
            return
        if self._prior_text_artist is None:
            self._prior_text_artist = self.ax_parameters.text(
                0.02,
                -0.18,
                "",
                transform=self.ax_parameters.transAxes,
                va="top",
                ha="left",
                fontsize=9,
                clip_on=False,
                bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "alpha": 0.75},
            )
        else:
            self._prior_text_artist.set_position((0.02, 0.02))
            self._prior_text_artist.set_verticalalignment("bottom")
            self._prior_text_artist.set_text("")

        for artist in self._prior_mean_lines:
            artist.remove()
        for patch in self._prior_band_patches:
            patch.remove()
        self._prior_mean_lines = []
        self._prior_band_patches = []

        if prior.get("distribution") != "gaussian":
            return

        mean = np.asarray(prior.get("mean", []), dtype=float).ravel()
        variance = np.asarray(prior.get("variance", []), dtype=float).ravel()
        if mean.size != len(self._param_lines) or variance.size != len(self._param_lines):
            return

        self._prior_mean_lines = []
        self._prior_band_patches = []
        for idx, line in enumerate(self._param_lines):
            mu = float(mean[idx])
            color = line.get_color()
            h_line = self.ax_parameters.axhline(
                mu,
                color=color,
                linestyle=":",
                linewidth=1.1,
                alpha=0.8,
            )
            self._prior_mean_lines.append(h_line)
            var_val = float(variance[idx]) if np.isfinite(variance[idx]) else 0.0
            if var_val <= 0.0:
                continue
            sigma = float(np.sqrt(var_val))
            band = self.ax_parameters.axhspan(
                mu - sigma,
                mu + sigma,
                color=color,
                alpha=0.12,
            )
            self._prior_band_patches.append(band)

    @staticmethod
    def _format_float(value: float) -> str:
        if not np.isfinite(value):
            return "nan"
        magnitude = abs(value)
        if magnitude != 0.0 and (magnitude < 1e-3 or magnitude >= 1e3):
            return f"{value:.3e}"
        return f"{value:.3f}"

    def _build_prior_text(self, latest_theta: Optional[np.ndarray]) -> str:
        if self._prior_payload is None:
            return ""

        distribution = str(self._prior_payload.get("distribution", "")).capitalize()
        lines = [f"Prior: {distribution}"]
        latest = np.asarray(latest_theta, dtype=float) if latest_theta is not None else None

        if self._prior_payload.get("distribution") == "gaussian":
            mean = np.asarray(self._prior_payload.get("mean", []), dtype=float).ravel()
            variance = np.asarray(self._prior_payload.get("variance", []), dtype=float).ravel()
            for idx, mu in enumerate(mean):
                variance_val = variance[idx] if idx < variance.size else 0.0
                sigma = float(np.sqrt(max(variance_val, 0.0))) if np.isfinite(variance_val) else float("nan")
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    f"θ{idx}: mu={self._format_float(mu)}, sigma={self._format_float(sigma)}, theta={self._format_float(theta_val)}"
                )
        elif self._prior_payload.get("distribution") == "bernoulli":
            probs = np.asarray(self._prior_payload.get("prob", []), dtype=float).ravel()
            for idx, prob in enumerate(probs):
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(f"θ{idx}: p={self._format_float(prob)}, theta={self._format_float(theta_val)}")
        elif self._prior_payload.get("distribution") == "poisson":
            rates = np.asarray(self._prior_payload.get("rate", []), dtype=float).ravel()
            for idx, rate in enumerate(rates):
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(f"θ{idx}: lambda={self._format_float(rate)}, theta={self._format_float(theta_val)}")
        elif self._prior_payload.get("distribution") == "beta":
            alpha_params = np.asarray(self._prior_payload.get("alpha", []), dtype=float).ravel()
            beta_params = np.asarray(self._prior_payload.get("beta", []), dtype=float).ravel()
            for idx, alpha_val in enumerate(alpha_params):
                beta_val = beta_params[idx] if idx < beta_params.size else float("nan")
                theta_val = float(latest[idx]) if latest is not None and idx < latest.size else float("nan")
                lines.append(
                    f"θ{idx}: alpha={self._format_float(alpha_val)}, beta={self._format_float(beta_val)}, theta={self._format_float(theta_val)}"
                )

        return "\n".join(lines)

    def _update_prior_annotations(self, thetas: np.ndarray) -> None:
        if self._prior_payload is None:
            return

        latest = thetas[-1] if thetas.size != 0 else None
        if self._prior_text_artist is not None:
            self._prior_text_artist.set_text(self._build_prior_text(latest))

    def update(
        self,
        *,
        objectives: np.ndarray,
        thetas: np.ndarray,
        correlations: np.ndarray,
        log_likelihoods: np.ndarray,
        log_priors: np.ndarray,
        log_posteriors: np.ndarray,
        current_theta: np.ndarray,
        surface: Optional[Dict[str, np.ndarray]],
        map_profiles: Optional[List[ParameterProfile]],
        observed: np.ndarray,
        fitted: np.ndarray,
        r_squared: np.ndarray,
        prior_summary: Optional[Dict[str, Any]] = None,
    ) -> None:
        if objectives.size == 0:
            return

        prior_changed = prior_summary is not None and prior_summary is not self._prior_payload
        if prior_summary is not None:
            self._prior_payload = prior_summary
        if self.map_enabled and (self._prior_text_artist is None or prior_changed):
            self._initialise_prior_annotations()

        iterations = np.arange(objectives.size)
        self._objective_line.set_data(iterations, objectives)
        self.ax_objective.relim()
        self.ax_objective.autoscale_view()
        last_ll = log_likelihoods[-1] if log_likelihoods.size else float("nan")
        if self.map_enabled:
            last_lp = log_priors[-1] if log_priors.size else float("nan")
            self._objective_text.set_text(f"LL={last_ll:.3f}\nlog prior={last_lp:.3f}")
        else:
            self._objective_text.set_text(f"LL={last_ll:.3f}")

        observed_arr = np.asarray(observed, dtype=float).reshape(-1)
        fitted_arr = np.asarray(fitted, dtype=float).reshape(-1)
        valid_mask = np.isfinite(observed_arr) & np.isfinite(fitted_arr)
        if np.any(valid_mask):
            x_vals = observed_arr[valid_mask]
            y_vals = fitted_arr[valid_mask]
            self._scatter_points.set_data(x_vals, y_vals)
            data_min = float(np.nanmin(np.concatenate((x_vals, y_vals))))
            data_max = float(np.nanmax(np.concatenate((x_vals, y_vals))))
            if not np.isfinite(data_min) or not np.isfinite(data_max):
                data_min, data_max = -1.0, 1.0
            if data_min == data_max:
                span = 1.0 if data_min == 0.0 else abs(data_min) * 0.1
                data_min -= span
                data_max += span
            pad = 0.05 * (data_max - data_min)
            lower = data_min - pad
            upper = data_max + pad
            self.ax_scatter.set_xlim(lower, upper)
            self.ax_scatter.set_ylim(lower, upper)
            self._identity_line.set_data([lower, upper], [lower, upper])
        else:
            self._scatter_points.set_data([], [])
            self._identity_line.set_data([], [])

        r_display = correlations[-1] if correlations.size else float("nan")
        r2_display = r_squared[-1] if r_squared.size else float("nan")
        text_lines: List[str] = []
        if np.isfinite(r2_display):
            text_lines.append(f"R²={r2_display:.3f}")
        else:
            text_lines.append("R²=nan")
        if np.isfinite(r_display):
            text_lines.append(f"r={r_display:.3f}")
        else:
            text_lines.append("r=nan")
        self._scatter_text.set_text("\n".join(text_lines))

        if thetas.size != 0:
            for idx, line in enumerate(self._param_lines):
                line.set_data(iterations, thetas[:, idx])
            self.ax_parameters.relim()
            self.ax_parameters.autoscale_view()
            if not self._legend_shown:
                legend = self.ax_parameters.legend(
                    loc="upper left",
                    bbox_to_anchor=(1.02, 1.0),
                    borderaxespad=0.0,
                    frameon=False,
                    ncol=1,  # Display the legend in one column
                )
                if legend is not None:
                    legend.set_draggable(False)
                self._legend_shown = True

        if self.map_enabled:
            self._update_prior_annotations(thetas)

        if self._surface_enabled and surface is not None and self.ax_surface is not None:
            axis0 = surface["axis0"]
            axis1 = surface["axis1"]
            grid = surface["grid"]
            extent = [axis0.min(), axis0.max(), axis1.min(), axis1.max()]
            if self._surface_image is None:
                self._surface_image = self.ax_surface.imshow(
                    grid,
                    origin="lower",
                    aspect="auto",
                    extent=extent,
                    cmap="viridis",
                )
                if self._surface_cbar_ax is not None:
                    self._surface_colorbar = self.fig.colorbar(
                        self._surface_image,
                        cax=self._surface_cbar_ax,
                    )
                    self._surface_cbar_ax.yaxis.set_ticks_position("right")
                    self._surface_cbar_ax.yaxis.set_label_position("right")
            else:
                self._surface_image.set_data(grid)
                self._surface_image.set_extent(extent)
                if self._surface_colorbar is not None:
                    self._surface_colorbar.update_normal(self._surface_image)
            if thetas.size != 0 and thetas.ndim == 2 and self._surface_indices is not None:
                idx0, idx1 = self._surface_indices
                path_x = thetas[:, idx0]
                path_y = thetas[:, idx1]
                mask = np.isfinite(path_x) & np.isfinite(path_y)
                if np.any(mask):
                    path_x = path_x[mask]
                    path_y = path_y[mask]
                    if self._surface_path is None:
                        self._surface_path = self.ax_surface.plot(
                            path_x,
                            path_y,
                            color="#ff9896",
                            linewidth=1.2,
                            alpha=0.6,
                            marker="o",
                            markersize=3.0,
                        )[0]
                    else:
                        self._surface_path.set_data(path_x, path_y)
                elif self._surface_path is not None:
                    self._surface_path.set_data([], [])
            if self._surface_point is None:
                x_val = float(current_theta[self._surface_indices[0]])
                y_val = float(current_theta[self._surface_indices[1]])
                self._surface_point = self.ax_surface.plot(
                    [x_val],
                    [y_val],
                    marker="o",
                    color="#d62728",
                )[0]
            else:
                x_val = float(current_theta[self._surface_indices[0]])
                y_val = float(current_theta[self._surface_indices[1]])
                self._surface_point.set_data([x_val], [y_val])

        if self.map_enabled and map_profiles is not None and self._profile_lines:
            for idx, profile in enumerate(map_profiles):
                if idx >= len(self._profile_lines):
                    break
                lines = self._profile_lines[idx]
                x_vals = profile.grid
                prior_vals = self._normalise(profile.log_prior)
                like_vals = self._normalise(profile.log_likelihood)
                post_vals = self._normalise(profile.log_posterior)
                lines["prior"].set_data(x_vals, prior_vals)
                lines["likelihood"].set_data(x_vals, like_vals)
                lines["posterior"].set_data(x_vals, post_vals)
                axis = self._profile_axes[idx]
                axis.relim()
                axis.autoscale_view()

        if hasattr(self._canvas, "draw_idle"):
            self._canvas.draw_idle()
        if hasattr(self._canvas, "flush_events"):
            self._canvas.flush_events()

        if self._tab_context is not None:
            self._tab_context.process_events()
        else:
            self._plt.pause(0.01)

    @staticmethod
    def _normalise(values: np.ndarray) -> np.ndarray:
        result = np.asarray(values, dtype=float)
        if result.size == 0 or not np.isfinite(result).any():
            return result
        max_val = np.nanmax(result)
        if not np.isfinite(max_val):
            return result
        return result - max_val


# ---------------------------------------------------------------------------
# Optimisation orchestration
# ---------------------------------------------------------------------------

class OptimisationMonitor:
    """Keeps optimisation traces, drives the live dashboard, and exposes summary state."""

    def __init__(
        self,
        *,
        y: np.ndarray,
        evaluator: ObservationModelEvaluator,
        prior_info: PriorInfo,
    bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
        mode: str,
        n_params: int,
        display: bool,
        surface_enabled: bool,
        surface_indices: Optional[Tuple[int, int]],
        surface_points: int,
        display_label: Optional[str] = None,
        allow_backend_switch: bool = False,
    ) -> None:
        self.y = y
        self._y_std = float(np.std(y))
        self._y_mean = float(np.mean(y))
        self._ss_tot = float(np.sum((y - self._y_mean) ** 2))
        self._evaluator = evaluator
        self._prior_info = prior_info
        self._bounds = bounds
        self.mode = mode
        self._surface_indices = surface_indices if surface_enabled else None
        self._surface_points = surface_points
        self._profile_points = 80
        self._profile_every = 3
        self._surface_refresh = 2

        self._evaluation_states: List[EvaluationState] = []
        self._iteration_states: List[EvaluationState] = []
        self._last_state: Optional[EvaluationState] = None

        self.theta_history: List[np.ndarray] = []
        self.objective_history: List[float] = []
        self.log_likelihood_history: List[float] = []
        self.log_prior_history: List[float] = []
        self.log_posterior_history: List[float] = []
        self.correlation_history: List[float] = []
        self.r2_history: List[float] = []

        self.surface_snapshot: Optional[LikelihoodSurface] = None

        self.map_enabled = display and mode == "map" and prior_info.enabled
        self.surface_enabled = display and surface_enabled and self._bounds is not None
        self._prior_payload = self._build_prior_payload(prior_info) if self.map_enabled else None
        self.display = (
            DynamicDisplay(
                n_params=int(n_params),
                surface_enabled=self.surface_enabled,
                surface_indices=self._surface_indices,
                map_enabled=self.map_enabled,
                display_label=display_label,
                prior_payload=self._prior_payload,
                allow_backend_switch=allow_backend_switch,
            )
            if display
            else None
        )

    @property
    def last_state(self) -> Optional[EvaluationState]:
        return self._last_state

    @property
    def latest_iteration_state(self) -> Optional[EvaluationState]:
        if self._iteration_states:
            return self._iteration_states[-1]
        return self._last_state

    def record(self, state: EvaluationState) -> None:
        self._evaluation_states.append(state)
        self._last_state = state

    def set_last_state(self, state: EvaluationState) -> None:
        self._last_state = state

    def seed_initial_state(self, state: EvaluationState) -> None:
        if state not in self._evaluation_states:
            self._evaluation_states.append(state)
        self.register_iteration(state, is_initial=True, force=True)

    def on_iteration(self, theta: np.ndarray) -> None:
        state = self._match_state(theta)
        if state is None:
            return
        self.register_iteration(state)

    def finalize(self, theta: np.ndarray) -> None:
        state = self._match_state(theta)
        if state is None:
            state = self._last_state
        if state is not None:
            self.register_iteration(state, force=True)

    def register_iteration(self, state: EvaluationState, *, is_initial: bool = False, force: bool = False) -> None:
        if state.assigned and not force:
            return
        state.assigned = True
        if self._iteration_states and np.allclose(self._iteration_states[-1].theta, state.theta) and not force:
            return

        self._iteration_states.append(state)
        self.theta_history.append(state.theta.copy())
        self.objective_history.append(state.objective)
        self.log_likelihood_history.append(state.evaluation.log_likelihood)
        self.log_prior_history.append(state.log_prior)
        self.log_posterior_history.append(state.log_posterior)
        fitted_values = state.evaluation.fitted
        self.correlation_history.append(self._compute_correlation(fitted_values))
        self.r2_history.append(self._compute_r_squared(fitted_values))

        if self.display is not None:
            profiles: Optional[List[ParameterProfile]] = None
            iteration_count = len(self._iteration_states)
            refresh_profiles = (
                self.map_enabled
                and (is_initial or force or iteration_count == 1 or iteration_count % self._profile_every == 0)
            )
            if refresh_profiles:
                profiles = self._compute_profiles(state.theta)

            surface_payload: Optional[Dict[str, np.ndarray]] = None
            if self.surface_enabled:
                need_surface = (
                    self.surface_snapshot is None
                    or force
                    or iteration_count % self._surface_refresh == 0
                )
                if need_surface:
                    self.surface_snapshot = self._compute_surface_snapshot(state.theta)
                if self.surface_snapshot is not None:
                    surface_payload = {
                        "axis0": self.surface_snapshot.axis0,
                        "axis1": self.surface_snapshot.axis1,
                        "grid": self.surface_snapshot.log_likelihood,
                    }

            objectives = np.asarray(self.objective_history, dtype=float)
            thetas = np.vstack(self.theta_history) if self.theta_history else np.empty((0,))
            correlations = np.asarray(self.correlation_history, dtype=float)
            log_likelihoods = np.asarray(self.log_likelihood_history, dtype=float)
            log_priors = np.asarray(self.log_prior_history, dtype=float)
            log_posteriors = np.asarray(self.log_posterior_history, dtype=float)
            r_squareds = np.asarray(self.r2_history, dtype=float)

            self.display.update(
                objectives=objectives,
                thetas=thetas,
                correlations=correlations,
                log_likelihoods=log_likelihoods,
                log_priors=log_priors,
                log_posteriors=log_posteriors,
                current_theta=state.theta,
                surface=surface_payload,
                map_profiles=profiles,
                observed=self.y,
                fitted=fitted_values,
                r_squared=r_squareds,
                prior_summary=self._prior_payload,
            )

    def _match_state(self, theta: np.ndarray) -> Optional[EvaluationState]:
        theta_arr = np.asarray(theta, dtype=float)
        for state in reversed(self._evaluation_states):
            if state.assigned:
                continue
            if np.allclose(state.theta, theta_arr, rtol=1e-7, atol=1e-9):
                return state
        return None

    def _compute_correlation(self, fitted: np.ndarray) -> float:
        fitted_arr = np.asarray(fitted, dtype=float)
        if fitted_arr.size != self.y.size:
            return float("nan")
        fitted_std = float(np.std(fitted_arr))
        if self._y_std == 0.0 or fitted_std == 0.0:
            return float("nan")
        corr = float(np.corrcoef(self.y, fitted_arr)[0, 1])
        return float(np.clip(corr, -1.0, 1.0))

    def _compute_r_squared(self, fitted: np.ndarray) -> float:
        fitted_arr = np.asarray(fitted, dtype=float)
        if fitted_arr.size != self.y.size or self._ss_tot == 0.0:
            return float("nan")
        residuals = self.y - fitted_arr
        ss_res = float(np.sum(residuals**2))
        r2 = 1.0 - ss_res / self._ss_tot
        return float(np.clip(r2, -10.0, 1.0))

    def _build_prior_payload(self, prior_info: PriorInfo) -> Optional[Dict[str, Any]]:
        if not prior_info.enabled or not prior_info.distribution:
            return None

        payload: Dict[str, Any] = {"distribution": str(prior_info.distribution).lower()}
        parameters = prior_info.parameters or {}
        for key, value in parameters.items():
            if value is None:
                continue
            arr = np.asarray(value, dtype=float)
            payload[key] = np.atleast_1d(arr).astype(float, copy=True)
        return payload

    def _compute_profiles(self, theta: np.ndarray) -> Optional[List[ParameterProfile]]:
        if not self.map_enabled:
            return None

        theta_arr = np.asarray(theta, dtype=float)
        n_params = theta_arr.size
        profiles: List[ParameterProfile] = []

        for idx in range(n_params):
            grid = self._parameter_grid(idx, theta_arr)
            log_likelihood_curve = np.full(grid.size, np.nan, dtype=float)
            log_prior_curve = np.full(grid.size, np.nan, dtype=float)
            log_posterior_curve = np.full(grid.size, np.nan, dtype=float)

            for pos, value in enumerate(grid):
                theta_candidate = theta_arr.copy()
                theta_candidate[idx] = value
                try:
                    evaluation = self._evaluator.evaluate(theta_candidate)
                    log_prior_val = self._prior_info.evaluate(theta_candidate)
                    log_likelihood_curve[pos] = evaluation.log_likelihood
                    log_prior_curve[pos] = log_prior_val
                    log_posterior_curve[pos] = evaluation.log_likelihood + log_prior_val
                except Exception:  # pragma: no cover - keep interactive plotting resilient
                    continue

            profiles.append(
                ParameterProfile(
                    grid=grid,
                    log_likelihood=log_likelihood_curve,
                    log_prior=log_prior_curve,
                    log_posterior=log_posterior_curve,
                )
            )

        return profiles

    def _parameter_grid(self, index: int, theta: np.ndarray) -> np.ndarray:
        lower_bound: Optional[float] = None
        upper_bound: Optional[float] = None
        if self._bounds is not None:
            lower, upper = self._bounds[index]
            if (
                lower is not None
                and upper is not None
                and math.isfinite(lower)
                and math.isfinite(upper)
            ):
                return np.linspace(lower, upper, self._profile_points)
            if lower is not None and math.isfinite(lower):
                lower_bound = lower
            if upper is not None and math.isfinite(upper):
                upper_bound = upper

        if self._prior_info.enabled:
            distribution = self._prior_info.distribution
            params = self._prior_info.parameters
            if distribution == "gaussian" and "mean" in params and "variance" in params:
                mean = params["mean"][index]
                std = math.sqrt(params["variance"][index])
                return np.linspace(mean - 4.0 * std, mean + 4.0 * std, self._profile_points)
            if distribution in {"bernoulli", "beta"}:
                return np.linspace(1e-6, 1.0 - 1e-6, self._profile_points)
            if distribution == "poisson" and "rate" in params:
                upper = max(theta[index] * 3.0, params["rate"][index] * 5.0, 1.0)
                return np.linspace(0.0, upper, self._profile_points)

        span = max(abs(theta[index]) * 2.0, 1.0)
        lower_default = theta[index] - span if lower_bound is None else lower_bound
        upper_default = theta[index] + span if upper_bound is None else upper_bound
        return np.linspace(lower_default, upper_default, self._profile_points)

    def _compute_surface_snapshot(self, theta: np.ndarray) -> Optional[LikelihoodSurface]:
        if not self.surface_enabled or self._bounds is None or self._surface_indices is None:
            return None
        try:
            return _evaluate_likelihood_surface_grid(
                evaluator=self._evaluator,
                theta_reference=theta,
                bounds=self._bounds,
                indices=self._surface_indices,
                surface_points=self._surface_points,
            )
        except Exception:  # pragma: no cover - keep plotting resilient
            return None


# ---------------------------------------------------------------------------
# Likelihood and uncertainty helpers
# ---------------------------------------------------------------------------

def gaussian_log_likelihood(residuals: np.ndarray, sigma: float) -> float:
    """Return the Gaussian log-likelihood given residuals and a scale."""

    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError("`sigma` must be a positive finite scalar.")
    residuals = np.asarray(residuals, dtype=float).reshape(-1)
    if residuals.size == 0:
        raise ValueError("`residuals` must contain at least one element.")

    n = residuals.size
    squared_error = float(np.dot(residuals, residuals))
    return float(
        -0.5 * (n * np.log(2.0 * np.pi * sigma**2) + squared_error / (sigma**2))
    )


def _sigmoid(z: np.ndarray) -> np.ndarray:
    """Stable logistic transform used for Bernoulli/Binomial outputs."""
    return 1.0 / (1.0 + np.exp(-np.clip(z, -700.0, 700.0)))


def binomial_log_likelihood(y: np.ndarray, prob: np.ndarray, trials: np.ndarray) -> float:
    """Return the Binomial log-likelihood for independent observations."""

    eps = 1e-12
    prob_clipped = np.clip(prob, eps, 1.0 - eps)
    term = (
        gammaln(trials + 1.0)
        - gammaln(y + 1.0)
        - gammaln(trials - y + 1.0)
        + y * np.log(prob_clipped)
        + (trials - y) * np.log(1.0 - prob_clipped)
    )
    return float(np.sum(term))


def poisson_log_likelihood(y: np.ndarray, rate: np.ndarray) -> float:
    """Return the Poisson log-likelihood for independent observations."""

    rate_clipped = np.clip(rate, 1e-12, None)
    term = y * np.log(rate_clipped) - rate_clipped - gammaln(y + 1.0)
    return float(np.sum(term))


def approximate_hessian(
    func: Callable[[np.ndarray], float],
    theta: np.ndarray,
    eps: float = 1e-5,
) -> Optional[np.ndarray]:
    """Numerically approximate the Hessian matrix via central differences."""

    theta = np.asarray(theta, dtype=float)
    n = theta.size
    eye = np.eye(n)
    hessian = np.zeros((n, n), dtype=float)

    f0 = func(theta)
    if not np.isfinite(f0):
        return None

    for i in range(n):
        step = eps * eye[i]
        f_plus = func(theta + step)
        f_minus = func(theta - step)
        if not (np.isfinite(f_plus) and np.isfinite(f_minus)):
            return None
        hessian[i, i] = (f_plus - 2.0 * f0 + f_minus) / (eps**2)

    for i in range(n):
        for j in range(i + 1, n):
            step_i = eps * eye[i]
            step_j = eps * eye[j]
            f_pp = func(theta + step_i + step_j)
            f_pm = func(theta + step_i - step_j)
            f_mp = func(theta - step_i + step_j)
            f_mm = func(theta - step_i - step_j)
            if not all(np.isfinite(val) for val in (f_pp, f_pm, f_mp, f_mm)):
                return None
            value = (f_pp - f_pm - f_mp + f_mm) / (4.0 * eps**2)
            hessian[i, j] = value
            hessian[j, i] = value

    return hessian


def _evaluate_likelihood_surface_grid(
    *,
    evaluator: ObservationModelEvaluator,
    theta_reference: np.ndarray,
    bounds: Sequence[Tuple[Optional[float], Optional[float]]],
    indices: Tuple[int, int],
    surface_points: int,
) -> LikelihoodSurface:
    """Utility to evaluate log-likelihood on a 2D grid for visual diagnostics."""

    if surface_points <= 1:
        raise ValueError("`surface_points` must be greater than 1 to form a grid.")

    idx0, idx1 = indices
    lower0, upper0 = bounds[idx0]
    lower1, upper1 = bounds[idx1]

    def _check_limits(lower: Optional[float], upper: Optional[float]) -> Tuple[float, float]:
        if lower is None or upper is None:
            raise ValueError("Likelihood surfaces require finite lower and upper bounds.")
        if not (math.isfinite(lower) and math.isfinite(upper)):
            raise ValueError("Likelihood surfaces require finite lower and upper bounds.")
        if upper <= lower:
            raise ValueError("Likelihood surface bounds must satisfy lower < upper.")
        return lower, upper

    lower0, upper0 = _check_limits(lower0, upper0)
    lower1, upper1 = _check_limits(lower1, upper1)
    axis0 = np.linspace(lower0, upper0, surface_points)
    axis1 = np.linspace(lower1, upper1, surface_points)
    grid = np.empty((surface_points, surface_points), dtype=float)

    for i, value0 in enumerate(axis0):
        for j, value1 in enumerate(axis1):
            theta_candidate = np.asarray(theta_reference, dtype=float).copy()
            theta_candidate[idx0] = value0
            theta_candidate[idx1] = value1
            try:
                evaluation = evaluator.evaluate(theta_candidate)
                grid[j, i] = evaluation.log_likelihood
            except Exception:  # pragma: no cover - keep visual diagnostics robust
                grid[j, i] = float("nan")

    return LikelihoodSurface(
        param_indices=indices,
        axis0=axis0,
        axis1=axis1,
        log_likelihood=grid,
    )


def _compute_hessian_uncertainty(
    estimate_uncertainty: bool,
    objective: Callable[[np.ndarray], float],
    theta: np.ndarray,
    hessian_eps: float,
    likelihood_distribution: str,
    prior_distribution: str,
    logger: VerboseLogger,
) -> FitUncertainty:
    """Approximate covariance and standard errors from the observed Hessian."""
    if not estimate_uncertainty:
        logger.log("Skipped covariance estimation at user request.")
        return FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="none",
        )

    logger.log("Estimating uncertainty via observed Hessian (workers=1).")

    if likelihood_distribution != "gaussian":
        logger.log(
            "Warning: Hessian-based uncertainty under a non-Gaussian likelihood is an approximation; validate with simulation."
        )
    if prior_distribution != "gaussian":
        logger.log(
            "Warning: Non-Gaussian priors alter posterior curvature; treat covariance estimates with caution."
        )

    hessian = approximate_hessian(objective, theta, eps=hessian_eps)
    if hessian is None:
        logger.log("Failed to approximate Hessian; uncertainty estimates unavailable.")
        return FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="hessian",
        )

    try:
        covariance = np.linalg.inv(hessian)
    except np.linalg.LinAlgError:
        logger.log("Observed Hessian is singular; uncertainty estimates unavailable.")
        return FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="hessian",
        )

    standard_errors = np.sqrt(np.diag(covariance))
    logger.log("Computed covariance matrix and standard errors from the Hessian.")
    return FitUncertainty(
        covariance=covariance,
        standard_errors=standard_errors,
        method="hessian",
    )


def _compute_bootstrap_uncertainty(
    *,
    estimate_uncertainty: bool,
    model_fn: ModelFunction,
    x: np.ndarray,
    y: np.ndarray,
    theta_start: np.ndarray,
    method: str,
    bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
    options: Optional[Dict[str, Union[int, float]]],
    prior_info: PriorInfo,
    sigma_fn: Optional[SigmaFunction],
    profile_sigma: bool,
    distribution: str,
    trials: Optional[np.ndarray],
    n_bootstrap: int,
    bootstrap_seed: Optional[int],
    bootstrap_parallel: bool,
    bootstrap_max_workers: Optional[int],
    logger: VerboseLogger,
) -> FitUncertainty:
    """Estimate parameter uncertainty via nonparametric bootstrapping."""

    if not estimate_uncertainty:
        logger.log("Skipped uncertainty estimation at user request.")
        return FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="none",
        )

    if n_bootstrap <= 0:
        raise ValueError("`n_bootstrap` must be a positive integer when using bootstrap uncertainty.")

    rng = np.random.default_rng(bootstrap_seed)
    n_obs = y.shape[0]
    # Pre-generate bootstrap index matrix once to reduce RNG overhead inside the loop.
    index_matrix = rng.integers(0, n_obs, size=(n_bootstrap, n_obs), dtype=int)
    theta_start = np.asarray(theta_start, dtype=float)
    theta_dimension = theta_start.size
    bootstrap_params: List[np.ndarray] = []
    failure_count = 0
    failure_messages: List[str] = []
    worker_count = 1

    def _project_to_feasible(theta_candidate: np.ndarray) -> np.ndarray:
        candidate = np.asarray(theta_candidate, dtype=float).copy()
        if bounds is not None:
            for param_index, (lower, upper) in enumerate(bounds):
                if lower is not None and not math.isinf(lower):
                    candidate[param_index] = max(candidate[param_index], lower)
                if upper is not None and not math.isinf(upper):
                    candidate[param_index] = min(candidate[param_index], upper)
        if prior_info.enabled:
            distribution = prior_info.distribution
            if distribution in {"bernoulli", "beta"}:
                candidate = np.clip(candidate, 1e-6, 1.0 - 1e-6)
            elif distribution == "poisson":
                candidate = np.clip(candidate, 0.0, None)
        return candidate

    jitter_scale = np.maximum(np.abs(theta_start), 1.0) * 0.05
    initial_guess_matrix = np.empty((n_bootstrap, theta_dimension), dtype=float)
    for iteration in range(n_bootstrap):
        noise = rng.normal(scale=jitter_scale)
        candidate = theta_start + noise
        initial_guess_matrix[iteration] = _project_to_feasible(candidate)

    def _run_single_bootstrap(
        index: int,
        sample_indices: np.ndarray,
        theta_initial: np.ndarray,
    ) -> Tuple[bool, Optional[np.ndarray], Optional[str]]:
        """Optimise a single bootstrap draw; returns (success, params, message)."""

        x_sample = x[sample_indices]
        y_sample = y[sample_indices]
        trials_sample = trials[sample_indices] if trials is not None else None

        evaluator = ObservationModelEvaluator(
            model_fn,
            x_sample,
            y_sample,
            sigma_fn,
            profile_sigma,
            distribution,
            trials_sample,
        )

        def objective(theta: np.ndarray) -> float:
            evaluation = evaluator.evaluate(theta)
            return -(evaluation.log_likelihood + prior_info.evaluate(theta))

        try:
            result = minimize(
                objective,
                np.asarray(theta_initial, dtype=float).copy(),
                method=method,
                bounds=bounds,
                options=options,
            )
        except Exception as exc:  # pragma: no cover - defensive
            return False, None, f"Bootstrap iteration {index + 1} failed with error: {exc}"

        if not result.success or not np.all(np.isfinite(result.x)):
            return False, None, f"Bootstrap iteration {index + 1} did not converge: {result.message}"

        return True, np.asarray(result.x, dtype=float), None

    # Execute bootstrap evaluations in parallel when feasible; fall back to sequential execution otherwise.
    if bootstrap_parallel and n_bootstrap > 1:
        max_workers = bootstrap_max_workers or None
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            worker_count = max_workers if max_workers is not None else min(32, (os.cpu_count() or 1) + 4)
            logger.log(
                "Estimating uncertainty via bootstrap with {workers} worker(s) over {n} resamples.".format(
                    workers=worker_count,
                    n=n_bootstrap,
                )
            )
            futures = {
                executor.submit(
                    _run_single_bootstrap,
                    iteration,
                    index_matrix[iteration],
                    initial_guess_matrix[iteration],
                ): iteration
                for iteration in range(n_bootstrap)
            }
            for future in as_completed(futures):
                iteration = futures[future]
                try:
                    success, params, message = future.result()
                except Exception as exc:  # pragma: no cover - defensive
                    failure_count += 1
                    if len(failure_messages) < 3:
                        failure_messages.append(
                            f"Bootstrap iteration {iteration + 1} raised an unexpected error: {exc}"
                        )
                    continue
                if success and params is not None:
                    bootstrap_params.append(params)
                    continue
                failure_count += 1
                if message and len(failure_messages) < 3:
                    failure_messages.append(message)
    else:
        logger.log(
            "Estimating uncertainty via bootstrap with 1 worker over {n} resamples.".format(
                n=n_bootstrap,
            )
        )
        for iteration in range(n_bootstrap):
            # Reuse successful estimates as warm starts when available.
            if bootstrap_params:
                seed_index = rng.integers(len(bootstrap_params))
                base_seed = bootstrap_params[seed_index]
                perturbed = _project_to_feasible(
                    base_seed + rng.normal(scale=jitter_scale)
                )
                initial_guess_matrix[iteration] = perturbed

            success, params, message = _run_single_bootstrap(
                iteration,
                index_matrix[iteration],
                initial_guess_matrix[iteration],
            )
            if success and params is not None:
                bootstrap_params.append(params)
                continue
            failure_count += 1
            if message and len(failure_messages) < 3:
                failure_messages.append(message)

    if failure_messages:
        for msg in failure_messages:
            logger.log(msg)
        if failure_count > len(failure_messages):
            logger.log(
                f"Additional {failure_count - len(failure_messages)} bootstrap iterations failed to converge."
            )

    if not bootstrap_params:
        logger.log("Bootstrap uncertainty estimation failed: no successful resamples.")
        return FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="bootstrap",
            extras={
                "n_bootstrap": n_bootstrap,
                "n_success": 0,
                "n_failures": n_bootstrap,
                "parallel": bootstrap_parallel,
                "worker_count": worker_count,
                "requested_max_workers": bootstrap_max_workers,
            },
        )

    samples = np.vstack(bootstrap_params)
    n_success = samples.shape[0]
    covariance = np.cov(samples, rowvar=False) if n_success > 1 else None
    standard_errors: Optional[np.ndarray]
    if n_success > 1:
        standard_errors = samples.std(axis=0, ddof=1)
    else:
        standard_errors = None

    confidence_intervals = np.percentile(samples, [2.5, 97.5], axis=0).T

    logger.log(
        "Computed bootstrap uncertainty with {success} successful resamples out of {total}.".format(
            success=n_success,
            total=n_bootstrap,
        )
    )

    return FitUncertainty(
        covariance=covariance,
        standard_errors=standard_errors,
        method="bootstrap",
        bootstrap_estimates=samples,
        confidence_intervals=confidence_intervals,
        extras={
            "n_bootstrap": n_bootstrap,
            "n_success": n_success,
            "n_failures": n_bootstrap - n_success,
            "parallel": bootstrap_parallel,
            "worker_count": worker_count,
            "requested_max_workers": bootstrap_max_workers,
        },
    )


def _compute_metrics(
    y: np.ndarray,
    evaluation: EvaluationResult,
    log_likelihood: float,
    n_params: int,
    distribution: str,
) -> FitMetrics:
    """Package goodness-of-fit statistics tailored to the observation distribution."""

    n_obs = y.size
    aic = float(2.0 * n_params - 2.0 * log_likelihood)
    bic = float(n_params * np.log(n_obs) - 2.0 * log_likelihood)

    if distribution == "gaussian":
        residuals = evaluation.residuals
        sse = float(np.sum(residuals**2))
        mse = sse / n_obs
        rmse = float(np.sqrt(mse))
        sst = float(np.sum((y - y.mean()) ** 2))
        r_squared = float(1.0 - sse / sst) if sst > 0 else float("nan")
        if np.isfinite(r_squared):
            r_squared = float(np.clip(r_squared, 0.0, 1.0))
        sigma_hat = float(evaluation.sigma) if evaluation.sigma is not None else float("nan")
        return FitMetrics(
            r_squared=r_squared,
            sse=sse,
            mse=mse,
            rmse=rmse,
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=sigma_hat,
        )

    if distribution == "binomial":
        trials = evaluation.extras.get("n_trials")
        probs = evaluation.extras.get("probabilities")
        log_loss = -log_likelihood / n_obs
        mae = float(np.mean(np.abs(y - evaluation.fitted)))
        extra = {
            "log_loss": float(log_loss),
            "mean_abs_error": mae,
            "mean_probability": float(np.mean(probs)) if probs is not None else float("nan"),
            "mean_trials": float(np.mean(trials)) if trials is not None else float("nan"),
        }
        return FitMetrics(
            r_squared=float("nan"),
            sse=float("nan"),
            mse=float("nan"),
            rmse=float("nan"),
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=float("nan"),
            extra=extra,
        )

    if distribution == "poisson":
        rate = evaluation.extras.get("rate")
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = np.clip(y, 1e-12, None) / np.clip(rate, 1e-12, None)
            deviance = 2.0 * np.sum(y * np.log(ratio) - (y - rate))
        extra = {
            "deviance": float(deviance),
            "mean_rate": float(np.mean(rate)) if rate is not None else float("nan"),
        }
        return FitMetrics(
            r_squared=float("nan"),
            sse=float("nan"),
            mse=float("nan"),
            rmse=float("nan"),
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=float("nan"),
            extra=extra,
        )

    raise ValueError(f"Unsupported distribution for metrics: {distribution}")


# ---------------------------------------------------------------------------
# Core fitting routine
# ---------------------------------------------------------------------------

def fit_gaussian(
    model_fn: ModelFunction,
    x: ArrayLike,
    y: ArrayLike,
    initial_params: ArrayLike,
    *,
    method: str = "L-BFGS-B",
    bounds: Bounds = None,
    options: Optional[Dict[str, Union[int, float]]] = None,
    estimate_uncertainty: bool = True,
    uncertainty_method: str = "bootstrap",
    n_bootstrap: int = 1000,
    bootstrap_seed: Optional[int] = None,
    hessian_eps: float = 1e-5,
    sigma_fn: Optional[SigmaFunction] = None,
    profile_sigma: bool = False,
    mode: str = "mle",
    prior_mean: Optional[ArrayLike] = None,
    prior_variance: Optional[ArrayLike] = None,
    prior_distribution: str = "gaussian",
    prior_prob: Optional[ArrayLike] = None,
    prior_rate: Optional[ArrayLike] = None,
    prior_alpha: Optional[ArrayLike] = None,
    prior_beta_shape: Optional[ArrayLike] = None,
    output_distribution: str = "gaussian",
    binomial_trials: Optional[ArrayLike] = None,
    verbose: bool = False,
    display: bool = False,
    display_identifier: Optional[str] = None,
    display_backend_fallback: bool = False,
    compute_likelihood_surface: bool = False,
    surface_param_indices: Tuple[int, int] = (0, 1),
    surface_points: int = 50,
    bootstrap_parallel: bool = True,
    bootstrap_max_workers: Optional[int] = None,
) -> FitResult:
    """Fit a Gaussian observation model via (M)LE and return a ``FitResult``.

    Parameters
    ----------
    model_fn : callable
        Maps ``(theta, x)`` to the model expectation for each observation.
    x : array_like
        Feature matrix with shape ``(n_samples, n_features)``; will be coerced to
        ``float`` and reshaped when necessary.
    y : array_like
        Response vector with shape ``(n_samples,)``; coerced to ``float``.
    initial_params : array_like
        Starting point for the optimiser with shape ``(n_params,)``.
    method : str, optional
        Optimisation algorithm passed to ``scipy.optimize.minimize`` (default ``"L-BFGS-B"``).
    bounds : sequence of tuple, optional
        Per-parameter ``(lower, upper)`` bounds. ``None`` for any parameter removes the bound.
    options : dict, optional
        Extra keyword arguments forwarded to ``scipy.optimize.minimize``.
    estimate_uncertainty : bool, optional
        When ``True`` (default), approximate Hessian-based covariance estimates are computed.
    uncertainty_method : str, optional
        Strategy for uncertainty quantification. One of {``"bootstrap"``, ``"hessian"``, ``"none"``}
        (default ``"bootstrap"``).
    n_bootstrap : int, optional
        Number of bootstrap resamples evaluated when ``uncertainty_method="bootstrap"``
        (default ``1000``).
    bootstrap_seed : int, optional
        Random seed passed to the bootstrap generator for reproducibility.
    bootstrap_parallel : bool, optional
        When ``True`` (default) bootstrap iterations are evaluated concurrently using a
        thread pool; set to ``False`` to force sequential execution.
    bootstrap_max_workers : int, optional
        Upper bound on the number of worker threads used for bootstrap evaluation. ``None``
        lets ``ThreadPoolExecutor`` decide based on the runtime.
    hessian_eps : float, optional
        Step size for the finite-difference Hessian (default ``1e-5``).
    sigma_fn : callable, optional
        Function returning the observation scale ``sigma`` from ``theta``. Required unless
        ``profile_sigma`` is ``True`` for Gaussian likelihoods.
    profile_sigma : bool, optional
        If ``True`` and using a Gaussian likelihood, recomputes ``sigma`` from residuals
        instead of using ``sigma_fn``.
    mode : str, optional
        Either ``"mle"`` or ``"map"``.
    prior_mean : array_like, optional
        Mean of the diagonal Gaussian prior used when ``mode="map"`` and
        ``prior_distribution="gaussian"``.
    prior_variance : array_like, optional
        Variance of the diagonal Gaussian prior used when ``prior_distribution="gaussian"``.
    prior_distribution : str, optional
        Prior family for MAP estimation. One of ``"gaussian"``, ``"bernoulli"``,
        ``"poisson"``, or ``"beta"``.
    prior_prob : array_like, optional
        Success probabilities for Bernoulli priors when ``prior_distribution="bernoulli"``.
    prior_rate : array_like, optional
        Rate parameters for Poisson priors when ``prior_distribution="poisson"``.
    prior_alpha : array_like, optional
        Alpha (shape) parameters for Beta priors when ``prior_distribution="beta"``.
    prior_beta_shape : array_like, optional
        Beta (shape) parameters for Beta priors when ``prior_distribution="beta"``.
    output_distribution : str, optional
        Observation family. One of ``"gaussian"``, ``"binomial"``, or ``"poisson"``.
    binomial_trials : array_like, optional
        Number of trials per observation when ``output_distribution="binomial"``.
    verbose : bool, optional
        When ``True`` (default), log messages are printed during optimisation.
    display : bool, optional
        When ``True``, open a live matplotlib dashboard showing optimisation diagnostics.
    display_identifier : str, optional
        Optional label used to distinguish concurrent dashboards. When the Qt backend is active,
        dashboards share a single window with per-run tabs using this identifier.
    display_backend_fallback : bool, optional
        When ``True``, allow the helper to switch Matplotlib to a GUI backend automatically when
        ``display`` is enabled and the current backend cannot create windows. Default ``False``
        requires the caller to configure a GUI backend manually.
    compute_likelihood_surface : bool, optional
        When ``True``, evaluate the log-likelihood on a square grid for the selected
        parameter pair using the provided bounds (default ``False``).
    surface_param_indices : tuple of int, optional
        Indices of the two parameters to explore when computing the likelihood surface
        (default ``(0, 1)``).
    surface_points : int, optional
        Number of grid points per axis for the likelihood surface (default ``50``).

    Returns
    -------
    FitResult
        Structured container holding optimisation status, fitted values,
        log-likelihood components, uncertainty estimates, metrics, optional
        likelihood surface evaluations, and the verbose history of the run.
        All arrays are returned as ``np.ndarray``.
    """

    # --- Validate callable inputs and chosen optimisation mode ---
    if not callable(model_fn):
        raise TypeError(
            "`model_fn` must be callable with signature model_fn(theta: np.ndarray, x: np.ndarray) -> np.ndarray."
        )
    if sigma_fn is not None and not callable(sigma_fn):
        raise TypeError(
            "`sigma_fn` must be callable with signature sigma_fn(theta: np.ndarray) -> float when provided."
        )

    mode_normalised = str(mode).lower()
    if mode_normalised not in {"mle", "map"}:
        raise ValueError("`mode` must be either 'mle' or 'map'.")

    distribution_normalised = str(output_distribution).lower()
    if distribution_normalised not in {"gaussian", "binomial", "poisson"}:
        raise ValueError(
            "`output_distribution` must be one of {'gaussian', 'binomial', 'poisson'}."
        )

    uncertainty_method_normalised = str(uncertainty_method).lower()
    if uncertainty_method_normalised not in {"bootstrap", "hessian", "none"}:
        raise ValueError(
            "`uncertainty_method` must be one of {'bootstrap', 'hessian', 'none'}."
        )
    if (
        estimate_uncertainty
        and uncertainty_method_normalised == "bootstrap"
        and not isinstance(n_bootstrap, int)
    ):
        raise TypeError("`n_bootstrap` must be provided as an integer when using bootstrap uncertainty.")
    if (
        estimate_uncertainty
        and uncertainty_method_normalised == "bootstrap"
        and n_bootstrap <= 0
    ):
        raise ValueError("`n_bootstrap` must be a positive integer when using bootstrap uncertainty.")
    if bootstrap_max_workers is not None:
        if not isinstance(bootstrap_max_workers, int):
            raise TypeError("`bootstrap_max_workers` must be an integer or None.")
        if bootstrap_max_workers <= 0:
            raise ValueError("`bootstrap_max_workers` must be a positive integer when provided.")
    if not isinstance(bootstrap_parallel, bool):
        raise TypeError("`bootstrap_parallel` must be provided as a boolean.")

    # --- Coerce and validate observed data ---
    x_arr = _ensure_2d_features(_coerce_float_array("x", x))
    y_arr = _ensure_1d_response(_coerce_float_array("y", y))
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError(
            "`x` and `y` must contain the same number of observations. "
            f"Received {x_arr.shape[0]} rows in `x` and {y_arr.shape[0]} values in `y`."
        )

    trials_arr: Optional[np.ndarray] = None
    if distribution_normalised == "binomial":
        trials_data = np.ones_like(y_arr) if binomial_trials is None else _coerce_float_array(
            "binomial_trials", binomial_trials
        )
        trials_arr = trials_data.astype(float)
        if trials_arr.shape != y_arr.shape:
            raise ValueError(
                "`binomial_trials` must match the shape of `y` when using a binomial likelihood."
            )
        if np.any(trials_arr <= 0):
            raise ValueError("`binomial_trials` entries must be positive.")
        if np.any((y_arr < 0) | (y_arr > trials_arr)):
            raise ValueError("Binomial responses must satisfy 0 <= y <= number of trials.")

    if distribution_normalised == "poisson" and np.any(y_arr < 0):
        raise ValueError("Poisson responses must be non-negative.")

    if distribution_normalised != "gaussian" and (sigma_fn is not None or profile_sigma):
        raise ValueError(
            "`sigma_fn` and `profile_sigma` are only valid for Gaussian likelihoods."
        )

    # --- Prepare initial parameter vector and optional bounds ---
    theta0 = _ensure_theta(initial_params)
    bounds_list = _validate_bounds(bounds, theta0.size)

    if options is not None and not isinstance(options, dict):
        raise TypeError("`options` must be a dictionary compatible with scipy.optimize.minimize or None.")

    # --- Construct prior information (no-op in MLE mode) ---
    prior_info = _build_prior(
        mode_normalised,
        theta0,
        prior_distribution,
        prior_mean=prior_mean,
        prior_variance=prior_variance,
        prior_prob=prior_prob,
        prior_rate=prior_rate,
        prior_alpha=prior_alpha,
        prior_beta=prior_beta_shape,
    )

    # --- Set up logging, monitoring, and reusable evaluator ---
    logger = VerboseLogger(verbose)
    evaluator = ObservationModelEvaluator(
        model_fn,
        x_arr,
        y_arr,
        sigma_fn,
        profile_sigma,
        distribution_normalised,
        trials_arr,
    )

    surface_enabled_for_display = (
        compute_likelihood_surface and bounds_list is not None and theta0.size == 2
    )

    monitor = OptimisationMonitor(
        y=y_arr,
        evaluator=evaluator,
        prior_info=prior_info,
        bounds=bounds_list,
        mode=mode_normalised,
        n_params=theta0.size,
        display=display,
        surface_enabled=surface_enabled_for_display,
        surface_indices=surface_param_indices if surface_enabled_for_display else None,
        surface_points=surface_points,
        display_label=display_identifier,
        allow_backend_switch=display_backend_fallback,
    )

    initial_eval = evaluator.evaluate(theta0)
    initial_log_prior = prior_info.evaluate(theta0)
    initial_state = EvaluationState(
        theta=theta0.copy(),
        evaluation=initial_eval,
        log_prior=initial_log_prior,
        log_posterior=initial_eval.log_likelihood + initial_log_prior,
        objective=-(initial_eval.log_likelihood + initial_log_prior),
    )
    monitor.record(initial_state)
    monitor.seed_initial_state(initial_state)

    sigma_msg = (
        f", sigma_start={initial_eval.sigma:.6f}" if initial_eval.sigma is not None else ""
    )
    logger.log(
        f"Validated inputs: n_obs={y_arr.size}, n_params={theta0.size}{sigma_msg}"
    )
    logger.log(f"Initial objective value: {initial_state.objective:.6f}")

    tracker = ObjectiveTracker(evaluator, prior_info, monitor)
    callback_logger = logger.callback()

    def _combined_callback(theta: np.ndarray) -> None:
        callback_logger(theta)
        monitor.on_iteration(theta)

    # --- Optimisation using scipy's minimise driver ---
    result = minimize(
        tracker,
        theta0,
        method=method,
        bounds=bounds_list,
        options=options,
        callback=_combined_callback,
    )

    monitor.finalize(result.x)
    final_state = monitor.latest_iteration_state
    if final_state is None or not np.allclose(final_state.theta, result.x, rtol=1e-7, atol=1e-9):
        tracker.evaluate(result.x, record=True)
        monitor.finalize(result.x)
        final_state = monitor.latest_iteration_state
    if final_state is None:
        raise RuntimeError("Optimisation finished without producing a valid evaluation state.")

    # --- Recover final fitted values and log densities ---
    final_theta = final_state.theta.copy()
    final_eval = final_state.evaluation
    log_likelihood = final_eval.log_likelihood
    log_prior_raw = final_state.log_prior
    log_prior_val = log_prior_raw if prior_info.enabled else None
    log_posterior = final_state.log_posterior

    # --- Estimate covariance / standard errors when requested ---
    if not estimate_uncertainty or uncertainty_method_normalised == "none":
        if not estimate_uncertainty:
            logger.log("Skipped uncertainty estimation at user request.")
        else:
            logger.log("Skipped uncertainty estimation because uncertainty_method='none'.")
        uncertainty = FitUncertainty(
            covariance=None,
            standard_errors=None,
            method="none",
        )
    elif uncertainty_method_normalised == "hessian":
        def objective_for_hessian(theta: np.ndarray) -> float:
            return tracker.evaluate(theta, record=False)
        uncertainty = _compute_hessian_uncertainty(
            estimate_uncertainty,
            objective_for_hessian,
            final_theta,
            hessian_eps,
            distribution_normalised,
            prior_info.distribution,
            logger,
        )
    else:
        uncertainty = _compute_bootstrap_uncertainty(
            estimate_uncertainty=estimate_uncertainty,
            model_fn=model_fn,
            x=x_arr,
            y=y_arr,
            theta_start=final_theta,
            method=method,
            bounds=bounds_list,
            options=options,
            prior_info=prior_info,
            sigma_fn=sigma_fn,
            profile_sigma=profile_sigma,
            distribution=distribution_normalised,
            trials=trials_arr,
            n_bootstrap=n_bootstrap,
            bootstrap_seed=bootstrap_seed,
            bootstrap_parallel=bootstrap_parallel,
            bootstrap_max_workers=bootstrap_max_workers,
            logger=logger,
        )

    # --- Collate goodness-of-fit diagnostics ---
    metrics = _compute_metrics(
        y_arr,
        final_eval,
        log_likelihood,
        final_theta.size,
        distribution_normalised,
    )

    likelihood_surface: Optional[LikelihoodSurface] = None
    if compute_likelihood_surface:
        if bounds_list is None:
            raise ValueError("`compute_likelihood_surface=True` requires finite bounds for all parameters.")
        idx0, idx1 = surface_param_indices
        if not isinstance(idx0, int) or not isinstance(idx1, int):
            raise TypeError("`surface_param_indices` must be a tuple of two integers.")
        if idx0 == idx1:
            raise ValueError("`surface_param_indices` must reference two distinct parameters.")
        n_params = final_theta.size
        if idx0 < 0 or idx1 < 0 or idx0 >= n_params or idx1 >= n_params:
            raise ValueError(
                "`surface_param_indices` entries must be valid parameter indices for the fitted model."
            )
        def _finite_pair(bound: Tuple[Optional[float], Optional[float]]) -> bool:
            lower, upper = bound
            return (
                lower is not None
                and upper is not None
                and math.isfinite(lower)
                and math.isfinite(upper)
            )

        if not _finite_pair(bounds_list[idx0]) or not _finite_pair(bounds_list[idx1]):
            raise ValueError(
                "Likelihood surface evaluation requires finite bounds for the selected parameters."
            )
        if surface_points <= 1:
            raise ValueError("`surface_points` must be greater than 1 to form a grid.")
        snapshot = monitor.surface_snapshot
        if snapshot is not None and snapshot.param_indices == (idx0, idx1):
            likelihood_surface = snapshot
        else:
            likelihood_surface = _evaluate_likelihood_surface_grid(
                evaluator=evaluator,
                theta_reference=final_theta,
                bounds=bounds_list,
                indices=(idx0, idx1),
                surface_points=surface_points,
            )
        logger.log(
            "Computed likelihood surface on a {size}x{size} grid for parameters {indices}.".format(
                size=likelihood_surface.axis0.size,
                indices=(idx0, idx1),
            )
        )

    logger.log(
        "Finished optimisation: success={success}, objective={objective:.6f}{sigma}".format(
            success=result.success,
            objective=result.fun,
            sigma="" if final_eval.sigma is None else f", sigma={final_eval.sigma:.6f}",
        )
    )

    # --- Assemble homogeneous FitResult payload ---
    return FitResult(
        success=bool(result.success),
        mode=mode_normalised,
        params=final_theta,
        fun=float(result.fun),
        log_likelihood=float(log_likelihood),
        log_prior=None if log_prior_val is None else float(log_prior_val),
        log_posterior=float(log_posterior),
        fitted=final_eval.fitted,
        residuals=final_eval.residuals,
        uncertainty=uncertainty,
        metrics=metrics,
        optimizer_result=result,
        history=logger.messages,
        likelihood_surface=likelihood_surface,
    )


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

def normality_tests(
    residuals: ArrayLike,
    alpha: float = 0.05,
) -> Dict[str, Dict[str, float]]:
    """Run Kolmogorov–Smirnov and Shapiro–Wilk tests on normalised residuals."""

    residuals_arr = _ensure_1d_response(_coerce_float_array("residuals", residuals), "residuals")
    if residuals_arr.size < 3:
        raise ValueError("`normality_tests` requires at least three residuals.")

    std = residuals_arr.std(ddof=1)
    if std <= 0 or not np.isfinite(std):
        raise ValueError("Residuals must have non-zero finite variance for normality testing.")

    z = (residuals_arr - residuals_arr.mean()) / std

    ks_stat, ks_p = stats.kstest(z, "norm")

    shapiro_result = {"statistic": float("nan"), "p_value": float("nan")}
    if z.size <= 5000:
        sw_stat, sw_p = stats.shapiro(z)
        shapiro_result = {"statistic": float(sw_stat), "p_value": float(sw_p)}

    return {
        "kolmogorov_smirnov": {
            "statistic": float(ks_stat),
            "p_value": float(ks_p),
            "reject_null": bool(ks_p < alpha),
        },
        "shapiro_wilk": {
            **shapiro_result,
            "reject_null": bool(shapiro_result["p_value"] < alpha)
            if np.isfinite(shapiro_result["p_value"])
            else False,
        },
    }


# ---------------------------------------------------------------------------
# Demo / quick-start helper
# ---------------------------------------------------------------------------

def _demo_linear_gaussian() -> None:
    """Run a minimal example showcasing ``fit_gaussian`` on synthetic data."""
    rng = np.random.default_rng(123)
    x = np.linspace(0, 5, 50)
    beta = np.array([1.8, -0.2, np.log(0.3)])
    noise = np.exp(beta[-1]) * rng.standard_normal(x.size)
    y = beta[0] * x + beta[1] + noise

    def model_fn(theta: np.ndarray, x_data: np.ndarray) -> np.ndarray:
        return theta[0] * x_data[:, 0] + theta[1]

    def sigma_fn(theta: np.ndarray) -> float:
        return float(np.exp(theta[2]))

    initial_guess = np.array([1.0, 0.0, np.log(1.0)])

    fit = fit_gaussian(
        model_fn,
        x,
        y,
        initial_guess,
        sigma_fn=sigma_fn,
        verbose=True,
    )
    
    print("Success:", fit.success)
    print("Estimated parameters:", fit.params)
    print("Standard errors:", fit.uncertainty.standard_errors)
    print("Normality tests:", normality_tests(fit.residuals))
    
    return fit


if __name__ == "__main__":  # pragma: no cover - manual quick-start only
    _demo_linear_gaussian()


__all__ = [
    "FitResult",
    "FitMetrics",
    "FitUncertainty",
    "LikelihoodSurface",
    "fit_gaussian",
    "approximate_hessian",
    "normality_tests",
    "gaussian_log_likelihood",
]
