"""Uncertainty quantification helpers for Gaussian model fitting."""

from __future__ import annotations

import math
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
from scipy.optimize import minimize

from .likelihoods import ObservationModelEvaluator
from .priors import PriorInfo
from .structures import FitUncertainty


def approximate_hessian(
    func: Callable[[np.ndarray], float],
    theta: np.ndarray,
    eps: float = 1e-5,
) -> Optional[np.ndarray]:
    """Numerically approximate the Hessian matrix via central differences."""

    theta = np.asarray(theta, dtype=float)
    n = theta.size
    eye = np.eye(n)
    hessian = np.zeros((n, n), dtype=float)

    f0 = func(theta)
    if not np.isfinite(f0):
        return None

    for i in range(n):
        step = eps * eye[i]
        f_plus = func(theta + step)
        f_minus = func(theta - step)
        if not (np.isfinite(f_plus) and np.isfinite(f_minus)):
            return None
        hessian[i, i] = (f_plus - 2.0 * f0 + f_minus) / (eps**2)

    for i in range(n):
        for j in range(i + 1, n):
            step_i = eps * eye[i]
            step_j = eps * eye[j]
            f_pp = func(theta + step_i + step_j)
            f_pm = func(theta + step_i - step_j)
            f_mp = func(theta - step_i + step_j)
            f_mm = func(theta - step_i - step_j)
            if not (np.isfinite(f_pp) and np.isfinite(f_pm) and np.isfinite(f_mp) and np.isfinite(f_mm)):
                return None
            value = (f_pp - f_pm - f_mp + f_mm) / (4.0 * eps**2)
            hessian[i, j] = value
            hessian[j, i] = value

    return hessian


def compute_hessian_uncertainty(
    estimate_uncertainty: bool,
    objective: Callable[[np.ndarray], float],
    theta: np.ndarray,
    hessian_eps: float,
    likelihood_distribution: str,
    prior_distribution: str,
    logger,
) -> FitUncertainty:
    """Approximate covariance and standard errors from the observed Hessian."""

    if not estimate_uncertainty:
        logger.log("Skipped covariance estimation at user request.")
        return FitUncertainty(covariance=None, standard_errors=None, method="none")

    logger.log("Estimating uncertainty via observed Hessian (workers=1).")

    if likelihood_distribution != "gaussian":
        logger.log(
            "Warning: Hessian-based uncertainty under a non-Gaussian likelihood is an approximation; validate with simulation."
        )
    if prior_distribution != "gaussian":
        logger.log(
            "Warning: Non-Gaussian priors alter posterior curvature; treat covariance estimates with caution."
        )

    hessian = approximate_hessian(objective, theta, eps=hessian_eps)
    if hessian is None:
        logger.log("Failed to approximate Hessian; uncertainty estimates unavailable.")
        return FitUncertainty(covariance=None, standard_errors=None, method="hessian")

    try:
        covariance = np.linalg.inv(hessian)
    except np.linalg.LinAlgError:
        logger.log("Observed Hessian is singular; uncertainty estimates unavailable.")
        return FitUncertainty(covariance=None, standard_errors=None, method="hessian")

    standard_errors = np.sqrt(np.diag(covariance))
    logger.log("Computed covariance matrix and standard errors from the Hessian.")
    return FitUncertainty(covariance=covariance, standard_errors=standard_errors, method="hessian")


def compute_bootstrap_uncertainty(
    *,
    estimate_uncertainty: bool,
    model_fn: Callable[[np.ndarray, np.ndarray], np.ndarray],
    x: np.ndarray,
    y: np.ndarray,
    theta_start: np.ndarray,
    method: str,
    bounds: Optional[List[Tuple[Optional[float], Optional[float]]]],
    options: Optional[Dict[str, Union[int, float]]],
    prior_info: PriorInfo,
    sigma_fn: Optional[Callable[[np.ndarray], float]],
    profile_sigma: bool,
    distribution: str,
    trials: Optional[np.ndarray],
    n_bootstrap: int,
    bootstrap_seed: Optional[int],
    bootstrap_parallel: bool,
    bootstrap_max_workers: Optional[int],
    logger,
) -> FitUncertainty:
    """Estimate parameter uncertainty via nonparametric bootstrapping."""

    if not estimate_uncertainty:
        logger.log("Skipped uncertainty estimation at user request.")
        return FitUncertainty(covariance=None, standard_errors=None, method="none")

    if n_bootstrap <= 0:
        raise ValueError("`n_bootstrap` must be a positive integer when using bootstrap uncertainty.")

    rng = np.random.default_rng(bootstrap_seed)
    y = evaluator.y
    x = evaluator.x
    n_obs = y.shape[0]
    index_matrix = rng.integers(0, n_obs, size=(n_bootstrap, n_obs), dtype=int)
    theta_start = np.asarray(theta_start, dtype=float)
    theta_dimension = theta_start.size
    bootstrap_params: List[np.ndarray] = []
    failure_count = 0
    failure_messages: List[str] = []
    worker_count = 1

    def _project_to_feasible(theta_candidate: np.ndarray) -> np.ndarray:
        if bounds is None:
            return theta_candidate
        projected = theta_candidate.copy()
        for (lower, upper), value in zip(bounds, projected):
            if lower is not None and value < lower:
                value = lower
            if upper is not None and value > upper:
                value = upper
        return projected

    jitter_scale = np.maximum(np.abs(theta_start), 1.0) * 0.05
    initial_guess_matrix = np.empty((n_bootstrap, theta_dimension), dtype=float)
    for iteration in range(n_bootstrap):
        jitter = rng.normal(scale=jitter_scale)
        candidate = theta_start + jitter
        initial_guess_matrix[iteration] = _project_to_feasible(candidate)

    def _run_single_bootstrap(
        index: int,
        sample_indices: np.ndarray,
        theta_initial: np.ndarray,
    ) -> Tuple[bool, Optional[np.ndarray], Optional[str]]:
        x_sample = x[sample_indices]
        y_sample = y[sample_indices]
        evaluator_sample = ObservationModelEvaluator(
            evaluator.model_fn,
            x_sample,
            y_sample,
            sigma_fn,
            profile_sigma,
            distribution,
            trials[sample_indices] if trials is not None else None,
        )
        try:
            result = evaluator_sample.model_fn(theta_initial, x_sample)
            _ = evaluator_sample.evaluate(theta_initial)
        except Exception as err:  # pragma: no cover - defensive guard
            return False, None, str(err)
        return True, theta_initial, None
        import math
        import os

    if bootstrap_parallel and n_bootstrap > 1:
        max_workers = bootstrap_max_workers or min(n_bootstrap, (os.cpu_count() or 2))
                x_arr = np.asarray(x)
                y_arr = np.asarray(y).reshape(-1)
                if x_arr.shape[0] != y_arr.shape[0]:
                    raise ValueError("`x` and `y` must have the same number of observations for bootstrapping.")

                trials_arr: Optional[np.ndarray] = None
                if trials is not None:
                    trials_arr = np.asarray(trials).reshape(-1)
                    if trials_arr.shape[0] != y_arr.shape[0]:
                        raise ValueError("`trials` must align with the number of observations in `y`.")

                theta_start = np.asarray(theta_start, dtype=float).reshape(-1)
                theta_dimension = theta_start.size
                rng = np.random.default_rng(bootstrap_seed)
                n_obs = y_arr.shape[0]
                index_matrix = rng.integers(0, n_obs, size=(n_bootstrap, n_obs), dtype=int)

                def _project_to_feasible(theta_candidate: np.ndarray) -> np.ndarray:
                    projected = np.asarray(theta_candidate, dtype=float).copy()
                    if bounds is not None:
                        for idx, (lower, upper) in enumerate(bounds):
                            if lower is not None and not math.isinf(lower):
                                projected[idx] = max(projected[idx], lower)
                            if upper is not None and not math.isinf(upper):
                                projected[idx] = min(projected[idx], upper)
                    if prior_info.enabled:
                        distribution_name = prior_info.distribution
                        if distribution_name in {"bernoulli", "beta"}:
                            projected = np.clip(projected, 1e-6, 1.0 - 1e-6)
                        elif distribution_name == "poisson":
                            projected = np.clip(projected, 0.0, None)
                    return projected

                jitter_scale = np.maximum(np.abs(theta_start), 1.0) * 0.05
                initial_guess_matrix = np.empty((n_bootstrap, theta_dimension), dtype=float)
                for iteration in range(n_bootstrap):
                    jitter = rng.normal(scale=jitter_scale)
                    candidate = _project_to_feasible(theta_start + jitter)
                    initial_guess_matrix[iteration] = candidate

                bootstrap_params: List[np.ndarray] = []
                failure_messages: List[str] = []
                worker_count = 1

                def _run_single_bootstrap(
                    iteration: int,
                    sample_indices: np.ndarray,
                    theta_initial: np.ndarray,
                ) -> Tuple[bool, Optional[np.ndarray], Optional[str]]:
                    x_sample = x_arr[sample_indices]
                    y_sample = y_arr[sample_indices]
                    trials_sample = trials_arr[sample_indices] if trials_arr is not None else None

                    evaluator = ObservationModelEvaluator(
                        model_fn,
                        x_sample,
                        y_sample,
                        sigma_fn,
                        profile_sigma,
                        distribution,
                        trials_sample,
                    )

                    def _objective(theta: np.ndarray) -> float:
                        evaluation = evaluator.evaluate(theta)
                        log_prior = prior_info.evaluate(theta)
                        return -(evaluation.log_likelihood + log_prior)

                    try:
                        result = minimize(
                            _objective,
                            np.asarray(theta_initial, dtype=float),
                            method=method,
                            bounds=bounds,
                            options=options,
                        )
                    except Exception as exc:  # pragma: no cover - defensive guard
                        return False, None, f"Bootstrap iteration {iteration + 1} failed with error: {exc}"

                    if not result.success or not np.all(np.isfinite(result.x)):
                        message = result.message if isinstance(result.message, str) else str(result.message)
                        return False, None, f"Bootstrap iteration {iteration + 1} failed to converge: {message}"

                    estimate = _project_to_feasible(result.x)
                    try:
                        evaluator.evaluate(estimate)
                    except Exception as exc:  # pragma: no cover - defensive guard
                        return False, None, f"Bootstrap iteration {iteration + 1} produced invalid estimate: {exc}"

                    return True, estimate, None

                n_failures = 0

                if bootstrap_parallel and n_bootstrap > 1:
                    max_workers = bootstrap_max_workers or min(n_bootstrap, (os.cpu_count() or 1))
                    worker_count = max_workers
                    logger.log(
                        "Estimating uncertainty via bootstrap with {workers} worker(s) over {n} resamples.".format(
                            workers=worker_count,
                            n=n_bootstrap,
                        )
                    )
                    try:
                        with ThreadPoolExecutor(max_workers=max_workers) as executor:
                            futures = {
                                executor.submit(
                                    _run_single_bootstrap,
                                    iteration,
                                    index_matrix[iteration],
                                    initial_guess_matrix[iteration],
                                ): iteration
                                for iteration in range(n_bootstrap)
                            }
                            for future in as_completed(futures):
                                iteration = futures[future]
                                try:
                                    success, params, message = future.result()
                                except Exception as exc:  # pragma: no cover - defensive guard
                                    success, params, message = False, None, str(exc)
                                if success and params is not None:
                                    bootstrap_params.append(params)
                                else:
                                    n_failures += 1
                                    if message and len(failure_messages) < 5:
                                        failure_messages.append(message)
                    except Exception as exc:  # pragma: no cover - defensive guard
                        logger.log(f"Bootstrap parallel execution failed, falling back to sequential mode: {exc}")
                        bootstrap_params.clear()
                        failure_messages.clear()
                        n_failures = 0
                        worker_count = 1
                        bootstrap_parallel = False

                if not bootstrap_parallel or n_bootstrap == 1:
                    logger.log(
                        "Estimating uncertainty via bootstrap with 1 worker over {n} resamples.".format(
                            n=n_bootstrap,
                        )
                    )
                    for iteration in range(n_bootstrap):
                        success, params, message = _run_single_bootstrap(
                            iteration,
                            index_matrix[iteration],
                            initial_guess_matrix[iteration],
                        )
                        if success and params is not None:
                            bootstrap_params.append(params)
                        else:
                            n_failures += 1
                            if message and len(failure_messages) < 5:
                                failure_messages.append(message)

                if failure_messages:
                    for message in failure_messages:
                        logger.log(f"Bootstrap warning: {message}")
                    suppressed = n_failures - len(failure_messages)
                    if suppressed > 0:
                        logger.log(f"Additional {suppressed} bootstrap iterations failed; details suppressed.")

                if not bootstrap_params:
                    logger.log("Bootstrap failed to produce any successful resamples.")
                    return FitUncertainty(
                        covariance=None,
                        standard_errors=None,
                        method="bootstrap",
                        extras={
                            "n_bootstrap": n_bootstrap,
                            "n_success": 0,
                            "n_failures": n_bootstrap,
                            "parallel": bool(bootstrap_parallel),
                            "worker_count": worker_count,
                            "requested_max_workers": bootstrap_max_workers,
                        },
                    )

                samples = np.vstack(bootstrap_params)
                n_success = samples.shape[0]
                covariance = np.cov(samples, rowvar=False) if n_success > 1 else None
                standard_errors = np.std(samples, axis=0, ddof=1) if n_success > 1 else None
                confidence_intervals = np.percentile(samples, [2.5, 97.5], axis=0).T

                logger.log(
                    "Computed bootstrap uncertainty with {success} successful resamples out of {total}.".format(
                        success=n_success,
                        total=n_bootstrap,
                    )
                )

                return FitUncertainty(
                    covariance=covariance,
                    standard_errors=standard_errors,
                    method="bootstrap",
                    bootstrap_estimates=samples,
                    confidence_intervals=confidence_intervals,
                    extras={
                        "n_bootstrap": n_bootstrap,
                        "n_success": n_success,
                        "n_failures": n_failures,
                        "parallel": bool(bootstrap_parallel),
                        "worker_count": worker_count,
                        "requested_max_workers": bootstrap_max_workers,
                    },
                )
