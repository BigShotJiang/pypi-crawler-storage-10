"""Prior distribution helpers for MAP estimation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Optional

import numpy as np
from scipy.special import betaln, gammaln

from .data import ArrayLike, coerce_float_array


@dataclass(frozen=True)
class PriorInfo:
    """Encapsulates log-prior evaluation for MAP estimation across families."""

    enabled: bool
    distribution: str = "gaussian"
    log_prior_fn: Optional[Callable[[np.ndarray], float]] = None
    component_log_prior_fn: Optional[Callable[[np.ndarray], np.ndarray]] = None
    parameters: Dict[str, np.ndarray] = field(default_factory=dict)

    def evaluate(self, theta: np.ndarray) -> float:
        """Return the full log prior for ``theta``."""

        if not self.enabled or self.log_prior_fn is None:
            return 0.0
        return float(self.log_prior_fn(theta))

    def component_log_density(self, theta: np.ndarray) -> np.ndarray:
        """Return component-wise log prior contributions."""

        if not self.enabled or self.component_log_prior_fn is None:
            return np.zeros_like(theta, dtype=float)
        return np.asarray(self.component_log_prior_fn(theta), dtype=float)


def build_prior(
    mode: str,
    theta0: np.ndarray,
    prior_distribution: str,
    *,
    prior_mean: Optional[ArrayLike],
    prior_variance: Optional[ArrayLike],
    prior_prob: Optional[ArrayLike],
    prior_rate: Optional[ArrayLike],
    prior_alpha: Optional[ArrayLike],
    prior_beta: Optional[ArrayLike],
) -> PriorInfo:
    """Construct prior metadata for MAP estimation."""

    if mode == "mle":
        return PriorInfo(enabled=False)

    distribution = str(prior_distribution).lower()
    if distribution not in {"gaussian", "bernoulli", "poisson", "beta"}:
        raise ValueError(
            "`prior_distribution` must be one of {'gaussian', 'bernoulli', 'poisson', 'beta'}."
        )

    def _validate_shape(name: str, arr: np.ndarray) -> None:
        if arr.ndim != 1 or arr.shape != theta0.shape:
            raise ValueError(
                f"`{name}` must be a 1D array matching the parameter vector shape {theta0.shape}."
            )

    eps = 1e-12

    if distribution == "gaussian":
        if prior_mean is None or prior_variance is None:
            raise ValueError("Gaussian priors require `prior_mean` and `prior_variance` arrays.")
        mean_arr = coerce_float_array("prior_mean", prior_mean)
        var_arr = coerce_float_array("prior_variance", prior_variance)
        _validate_shape("prior_mean", mean_arr)
        _validate_shape("prior_variance", var_arr)
        if np.any(var_arr <= 0):
            raise ValueError("`prior_variance` entries must all be strictly positive.")
        log_det = np.log(2.0 * np.pi * var_arr)

        def _log_prior(theta: np.ndarray) -> float:
            theta_arr = np.asarray(theta, dtype=float)
            if theta_arr.shape != mean_arr.shape:
                raise ValueError("Theta and Gaussian prior arrays must share the same shape.")
            diff = theta_arr - mean_arr
            return float(-0.5 * np.sum(log_det + diff**2 / var_arr))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            diff = theta_arr - mean_arr
            return -0.5 * (log_det + diff**2 / var_arr)

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"mean": mean_arr, "variance": var_arr},
        )

    if distribution == "bernoulli":
        if prior_prob is None:
            raise ValueError("Bernoulli priors require `prior_prob` array.")
        prob_arr = coerce_float_array("prior_prob", prior_prob)
        _validate_shape("prior_prob", prob_arr)
        if np.any((prob_arr <= 0) | (prob_arr >= 1)):
            raise ValueError("`prior_prob` entries must lie strictly inside (0, 1).")
        log_prob = np.log(np.clip(prob_arr, eps, 1 - eps))
        log_one_minus = np.log(np.clip(1.0 - prob_arr, eps, 1 - eps))

        def _log_prior(theta: np.ndarray) -> float:
            theta_arr = np.asarray(theta, dtype=float)
            if theta_arr.shape != prob_arr.shape:
                raise ValueError("Theta and Bernoulli prior arrays must share the same shape.")
            if np.any((theta_arr < -eps) | (theta_arr > 1 + eps)):
                raise ValueError("Bernoulli priors expect parameters constrained to [0, 1].")
            theta_clipped = np.clip(theta_arr, 0.0, 1.0)
            return float(np.sum(theta_clipped * log_prob + (1 - theta_clipped) * log_one_minus))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            theta_clipped = np.clip(theta_arr, 0.0, 1.0)
            return theta_clipped * log_prob + (1.0 - theta_clipped) * log_one_minus

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"prob": prob_arr},
        )

    if distribution == "poisson":
        if prior_rate is None:
            raise ValueError("Poisson priors require `prior_rate` array.")
        rate_arr = coerce_float_array("prior_rate", prior_rate)
        _validate_shape("prior_rate", rate_arr)
        if np.any(rate_arr <= 0):
            raise ValueError("`prior_rate` entries must be strictly positive.")

        def _log_prior(theta: np.ndarray) -> float:
            theta_arr = np.asarray(theta, dtype=float)
            if theta_arr.shape != rate_arr.shape:
                raise ValueError("Theta and Poisson prior arrays must share the same shape.")
            if np.any(theta_arr < 0):
                raise ValueError("Poisson priors expect non-negative parameters.")
            theta_clipped = np.clip(theta_arr, 0.0, None)
            return float(np.sum(theta_clipped * np.log(rate_arr) - rate_arr - gammaln(theta_clipped + 1.0)))

        def _component(theta: np.ndarray) -> np.ndarray:
            theta_arr = np.asarray(theta, dtype=float)
            theta_clipped = np.clip(theta_arr, 0.0, None)
            return theta_clipped * np.log(rate_arr) - rate_arr - gammaln(theta_clipped + 1.0)

        return PriorInfo(
            enabled=True,
            distribution=distribution,
            log_prior_fn=_log_prior,
            component_log_prior_fn=_component,
            parameters={"rate": rate_arr},
        )

    if prior_alpha is None or prior_beta is None:
        raise ValueError("Beta priors require `prior_alpha` and `prior_beta` arrays.")
    alpha_arr = coerce_float_array("prior_alpha", prior_alpha)
    beta_arr = coerce_float_array("prior_beta", prior_beta)
    _validate_shape("prior_alpha", alpha_arr)
    _validate_shape("prior_beta", beta_arr)
    if np.any(alpha_arr <= 0) or np.any(beta_arr <= 0):
        raise ValueError("`prior_alpha` and `prior_beta` entries must be strictly positive for Beta priors.")
    log_norm = betaln(alpha_arr, beta_arr)

    def _log_prior(theta: np.ndarray) -> float:
        theta_arr = np.asarray(theta, dtype=float)
        if theta_arr.shape != alpha_arr.shape:
            raise ValueError("Theta and Beta prior arrays must share the same shape.")
        if np.any((theta_arr <= 0) | (theta_arr >= 1)):
            raise ValueError("Beta priors expect parameters strictly within (0, 1).")
        theta_clipped = np.clip(theta_arr, eps, 1 - eps)
        log_density = (alpha_arr - 1.0) * np.log(theta_clipped) + (beta_arr - 1.0) * np.log(1.0 - theta_clipped) - log_norm
        return float(np.sum(log_density))

    def _component(theta: np.ndarray) -> np.ndarray:
        theta_arr = np.asarray(theta, dtype=float)
        theta_clipped = np.clip(theta_arr, eps, 1 - eps)
        return (alpha_arr - 1.0) * np.log(theta_clipped) + (beta_arr - 1.0) * np.log(1.0 - theta_clipped) - log_norm

    return PriorInfo(
        enabled=True,
        distribution=distribution,
        log_prior_fn=_log_prior,
        component_log_prior_fn=_component,
        parameters={"alpha": alpha_arr, "beta": beta_arr},
    )


__all__ = ["PriorInfo", "build_prior"]
