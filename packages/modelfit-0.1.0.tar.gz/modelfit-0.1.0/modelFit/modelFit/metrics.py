"""Goodness-of-fit and diagnostic statistics."""

from __future__ import annotations

from typing import Dict

import numpy as np
from scipy import stats

from .structures import EvaluationResult, FitMetrics


def compute_metrics(
    y: np.ndarray,
    evaluation: EvaluationResult,
    log_likelihood: float,
    n_params: int,
    distribution: str,
) -> FitMetrics:
    """Package goodness-of-fit statistics tailored to the observation distribution."""

    n_obs = y.size
    aic = float(2.0 * n_params - 2.0 * log_likelihood)
    bic = float(n_params * np.log(n_obs) - 2.0 * log_likelihood)

    if distribution == "gaussian":
        residuals = evaluation.residuals
        sse = float(np.sum(residuals**2))
        mse = sse / n_obs
        rmse = float(np.sqrt(mse))
        sst = float(np.sum((y - y.mean()) ** 2))
        r_squared = float(1.0 - sse / sst) if sst > 0 else float("nan")
        if np.isfinite(r_squared):
            r_squared = float(np.clip(r_squared, 0.0, 1.0))
        sigma_hat = float(evaluation.sigma) if evaluation.sigma is not None else float("nan")
        return FitMetrics(
            r_squared=r_squared,
            sse=sse,
            mse=float(mse),
            rmse=rmse,
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=sigma_hat,
        )

    if distribution == "binomial":
        trials = evaluation.extras.get("n_trials")
        probs = evaluation.extras.get("probabilities")
        log_loss = -log_likelihood / n_obs
        mae = float(np.mean(np.abs(y - evaluation.fitted)))
        extra = {
            "log_loss": float(log_loss),
            "mean_abs_error": mae,
            "mean_probability": float(np.mean(probs)) if probs is not None else float("nan"),
            "mean_trials": float(np.mean(trials)) if trials is not None else float("nan"),
        }
        return FitMetrics(
            r_squared=float("nan"),
            sse=float("nan"),
            mse=float("nan"),
            rmse=float("nan"),
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=float("nan"),
            extra=extra,
        )

    if distribution == "poisson":
        rate = evaluation.extras.get("rate")
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = np.clip(y, 1e-12, None) / np.clip(rate, 1e-12, None)
            deviance = 2.0 * np.sum(y * np.log(ratio) - (y - rate))
        extra = {
            "deviance": float(deviance),
            "mean_rate": float(np.mean(rate)) if rate is not None else float("nan"),
        }
        return FitMetrics(
            r_squared=float("nan"),
            sse=float("nan"),
            mse=float("nan"),
            rmse=float("nan"),
            aic=aic,
            bic=bic,
            n_obs=int(n_obs),
            n_params=int(n_params),
            sigma_hat=float("nan"),
            extra=extra,
        )

    raise ValueError(f"Unsupported distribution for metrics: {distribution}")


def normality_tests(
    residuals: np.ndarray,
    alpha: float = 0.05,
) -> Dict[str, Dict[str, float]]:
    """Run Kolmogorov–Smirnov and Shapiro–Wilk tests on normalised residuals."""

    residuals_arr = np.asarray(residuals, dtype=float).reshape(-1)
    if residuals_arr.size < 3:
        raise ValueError("Normality tests require at least three residuals.")

    std = residuals_arr.std(ddof=1)
    if std <= 0 or not np.isfinite(std):
        raise ValueError("Residual standard deviation must be positive and finite.")

    z = (residuals_arr - residuals_arr.mean()) / std

    ks_stat, ks_p = stats.kstest(z, "norm")

    shapiro_result = {"statistic": float("nan"), "p_value": float("nan")}
    if z.size <= 5000:
        shapiro_stat, shapiro_p = stats.shapiro(z)
        shapiro_result = {"statistic": float(shapiro_stat), "p_value": float(shapiro_p)}

    return {
        "kolmogorov_smirnov": {
            "statistic": float(ks_stat),
            "p_value": float(ks_p),
            "reject_null": bool(ks_p < alpha),
        },
        "shapiro_wilk": {
            **shapiro_result,
            "reject_null": bool(shapiro_result["p_value"] < alpha)
            if np.isfinite(shapiro_result["p_value"])
            else False,
        },
    }


__all__ = ["compute_metrics", "normality_tests"]
