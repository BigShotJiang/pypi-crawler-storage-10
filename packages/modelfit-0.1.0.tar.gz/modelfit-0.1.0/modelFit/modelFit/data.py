"""Core data validation helpers used across the Gaussian fitting toolbox.

Each function normalises user provided inputs into NumPy arrays with clear
contracts, raising descriptive errors whenever inputs break expectations.
"""

from __future__ import annotations

from typing import Optional, Sequence, Tuple

import numpy as np

ArrayLike = np.ndarray | Sequence[float]
Bounds = Optional[Sequence[Tuple[Optional[float], Optional[float]]]]


def coerce_float_array(name: str, value: ArrayLike) -> np.ndarray:
    """Return ``value`` as a finite float array.

    Parameters
    ----------
    name:
        Symbolic name used inside error messages.
    value:
        Iterable convertible to a NumPy array of floats.

    Returns
    -------
    numpy.ndarray
        A 1D or 2D array of dtype ``float``.
    """
    try:
        array = np.asarray(value, dtype=float)
    except TypeError as exc:  # pragma: no cover - defensive programming
        raise TypeError(
            f"`{name}` must be convertible to a float array. Received type {type(value).__name__}."
        ) from exc

    if array.size == 0:
        raise ValueError(f"`{name}` must contain at least one element.")
    if not np.isfinite(array).all():
        raise ValueError(f"`{name}` must not contain NaN or infinite values.")
    return array


def ensure_2d_features(x_arr: np.ndarray) -> np.ndarray:
    """Ensure a feature matrix shaped ``(n_samples, n_features)``.

    A 1D array is reshaped into a column vector; higher dimensions raise a
    validation error.
    """

    if x_arr.ndim == 1:
        return x_arr.reshape(-1, 1)
    if x_arr.ndim != 2:
        raise ValueError(
            "`x` must be convertible to a 2D float array with shape (n_samples, n_features). "
            f"Received array with ndim={x_arr.ndim} and shape {x_arr.shape}."
        )
    return x_arr


def ensure_1d_response(y_arr: np.ndarray, name: str = "y") -> np.ndarray:
    """Validate that the response vector is one-dimensional."""

    if y_arr.ndim != 1:
        raise ValueError(
            f"`{name}` must be convertible to a 1D float array with shape (n_samples,). "
            f"Received array with ndim={y_arr.ndim} and shape {y_arr.shape}."
        )
    return y_arr


def ensure_theta(initial_params: ArrayLike) -> np.ndarray:
    """Validate and return the optimiser initialisation vector."""

    theta = coerce_float_array("initial_params", initial_params)
    if theta.ndim != 1:
        raise ValueError(
            "`initial_params` must be a 1D float array with shape (n_params,). "
            f"Received array with ndim={theta.ndim} and shape {theta.shape}."
        )
    return theta


def validate_bounds(bounds: Bounds, n_params: int) -> list[tuple[Optional[float], Optional[float]]] | None:
    """Normalise optimiser bounds into a list of ``(lower, upper)`` tuples."""

    if bounds is None:
        return None

    if len(bounds) != n_params:
        raise ValueError(
            "`bounds` must contain one (lower, upper) tuple per parameter. "
            f"Received {len(bounds)} tuples for {n_params} parameters."
        )

    formatted: list[tuple[Optional[float], Optional[float]]] = []
    for idx, pair in enumerate(bounds):
        if not isinstance(pair, Sequence) or len(pair) != 2:
            raise TypeError(
                "Each entry in `bounds` must be a sequence of two elements `(lower, upper)`; "
                f"received {pair!r} at position {idx}."
            )

        lower, upper = pair
        lower_f: Optional[float] = None if lower is None else float(lower)
        upper_f: Optional[float] = None if upper is None else float(upper)

        if lower_f is not None and np.isnan(lower_f):
            raise ValueError(f"Lower bound for parameter {idx} is NaN.")
        if upper_f is not None and np.isnan(upper_f):
            raise ValueError(f"Upper bound for parameter {idx} is NaN.")
        if lower_f is not None and upper_f is not None and upper_f < lower_f:
            raise ValueError(
                f"Parameter {idx} has inconsistent bounds: lower={lower_f} > upper={upper_f}."
            )

        formatted.append((lower_f, upper_f))

    return formatted


__all__ = [
    "ArrayLike",
    "Bounds",
    "coerce_float_array",
    "ensure_1d_response",
    "ensure_2d_features",
    "ensure_theta",
    "validate_bounds",
]
