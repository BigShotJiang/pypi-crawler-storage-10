"""Shared dataclasses used across the model fitting toolbox."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import OptimizeResult


@dataclass(frozen=True)
class FitUncertainty:
    """Aggregates parameter uncertainty diagnostics."""

    covariance: Optional[np.ndarray]
    standard_errors: Optional[np.ndarray]
    method: str
    bootstrap_estimates: Optional[np.ndarray] = None
    confidence_intervals: Optional[np.ndarray] = None
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FitMetrics:
    """Summarises goodness-of-fit diagnostics across observation families."""

    r_squared: float
    sse: float
    mse: float
    rmse: float
    aic: float
    bic: float
    n_obs: int
    n_params: int
    sigma_hat: float
    extra: Dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class LikelihoodSurface:
    """Dense log-likelihood evaluations across a two-parameter grid."""

    param_indices: Tuple[int, int]
    axis0: np.ndarray
    axis1: np.ndarray
    log_likelihood: np.ndarray


@dataclass(frozen=True)
class EvaluationResult:
    """Wraps model evaluation outputs for downstream bookkeeping."""

    fitted: np.ndarray
    residuals: np.ndarray
    sigma: Optional[float]
    log_likelihood: float
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvaluationState:
    """Snapshot of the objective landscape at a given parameter vector."""

    theta: np.ndarray
    evaluation: EvaluationResult
    log_prior: float
    log_posterior: float
    objective: float
    assigned: bool = False


@dataclass(frozen=True)
class ParameterProfile:
    """One-dimensional profile of log densities for a single parameter."""

    grid: np.ndarray
    log_likelihood: np.ndarray
    log_prior: np.ndarray
    log_posterior: np.ndarray


@dataclass
class FitResult:
    """Container for the optimisation outcome and derived diagnostics."""

    success: bool
    mode: str
    params: np.ndarray
    fun: float
    log_likelihood: float
    log_prior: Optional[float]
    log_posterior: float
    fitted: np.ndarray
    residuals: np.ndarray
    uncertainty: FitUncertainty
    metrics: FitMetrics
    optimizer_result: OptimizeResult
    history: Sequence[str]
    likelihood_surface: Optional[LikelihoodSurface] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialise the result into a JSON-friendly dictionary."""

        return {
            "success": bool(self.success),
            "mode": str(self.mode),
            "params": self.params.tolist(),
            "fun": float(self.fun),
            "log_likelihood": float(self.log_likelihood),
            "log_prior": None if self.log_prior is None else float(self.log_prior),
            "log_posterior": float(self.log_posterior),
            "fitted": self.fitted.tolist(),
            "residuals": self.residuals.tolist(),
            "uncertainty": {
                "method": str(self.uncertainty.method),
                "covariance": None
                if self.uncertainty.covariance is None
                else self.uncertainty.covariance.tolist(),
                "standard_errors": None
                if self.uncertainty.standard_errors is None
                else self.uncertainty.standard_errors.tolist(),
                "bootstrap_estimates": None
                if self.uncertainty.bootstrap_estimates is None
                else self.uncertainty.bootstrap_estimates.tolist(),
                "confidence_intervals": None
                if self.uncertainty.confidence_intervals is None
                else self.uncertainty.confidence_intervals.tolist(),
                "extras": {
                    name: (value.tolist() if hasattr(value, "tolist") else value)
                    for name, value in self.uncertainty.extras.items()
                },
            },
            "metrics": {
                "r_squared": float(self.metrics.r_squared),
                "sse": float(self.metrics.sse),
                "mse": float(self.metrics.mse),
                "rmse": float(self.metrics.rmse),
                "aic": float(self.metrics.aic),
                "bic": float(self.metrics.bic),
                "n_obs": int(self.metrics.n_obs),
                "n_params": int(self.metrics.n_params),
                "sigma_hat": float(self.metrics.sigma_hat),
                "extra": {name: float(value) for name, value in self.metrics.extra.items()},
            },
            "history": list(self.history),
            "likelihood_surface": None
            if self.likelihood_surface is None
            else {
                "param_indices": list(self.likelihood_surface.param_indices),
                "axis0": self.likelihood_surface.axis0.tolist(),
                "axis1": self.likelihood_surface.axis1.tolist(),
                "log_likelihood": self.likelihood_surface.log_likelihood.tolist(),
            },
        }

    def summary(self) -> Dict[str, Any]:
        """Retained for backwards compatibility with previous API."""

        return self.to_dict()


__all__ = [
    "FitResult",
    "FitMetrics",
    "FitUncertainty",
    "LikelihoodSurface",
    "EvaluationResult",
    "EvaluationState",
    "ParameterProfile",
]
