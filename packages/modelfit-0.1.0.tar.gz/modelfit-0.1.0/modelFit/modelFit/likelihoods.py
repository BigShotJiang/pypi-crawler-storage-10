"""Observation model evaluation utilities and likelihood kernels."""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.special import gammaln

from .structures import EvaluationResult

ModelFunction = Callable[[np.ndarray, np.ndarray], np.ndarray]


def gaussian_log_likelihood(residuals: np.ndarray, sigma: float) -> float:
    """Return the Gaussian log-likelihood given residuals and a scale."""

    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError("`sigma` must be a positive finite scalar.")
    residuals = np.asarray(residuals, dtype=float).reshape(-1)
    if residuals.size == 0:
        raise ValueError("`residuals` must contain at least one element.")

    n = residuals.size
    squared_error = float(np.dot(residuals, residuals))
    return float(-0.5 * (n * np.log(2.0 * np.pi * sigma**2) + squared_error / (sigma**2)))


def _sigmoid(z: np.ndarray) -> np.ndarray:
    """Stable logistic transform used for Bernoulli/Binomial outputs."""

    return 1.0 / (1.0 + np.exp(-np.clip(z, -700.0, 700.0)))


def binomial_log_likelihood(y: np.ndarray, prob: np.ndarray, trials: np.ndarray) -> float:
    """Return the Binomial log-likelihood for independent observations."""

    eps = 1e-12
    prob_clipped = np.clip(prob, eps, 1.0 - eps)
    term = (
        gammaln(trials + 1.0)
        - gammaln(y + 1.0)
        - gammaln(trials - y + 1.0)
        + y * np.log(prob_clipped)
        + (trials - y) * np.log(1.0 - prob_clipped)
    )
    return float(np.sum(term))


def poisson_log_likelihood(y: np.ndarray, rate: np.ndarray) -> float:
    """Return the Poisson log-likelihood for independent observations."""

    rate_clipped = np.clip(rate, 1e-12, None)
    term = y * np.log(rate_clipped) - rate_clipped - gammaln(y + 1.0)
    return float(np.sum(term))


class ObservationModelEvaluator:
    """Evaluate model predictions and log-likelihood across observation families."""

    def __init__(
        self,
        model_fn: ModelFunction,
        x: np.ndarray,
        y: np.ndarray,
        sigma_fn: Optional[Callable[[np.ndarray], float]],
        profile_sigma: bool,
        distribution: str,
        n_trials: Optional[np.ndarray],
    ) -> None:
        self.model_fn = model_fn
        self.x = x
        self.y = y
        self.sigma_fn = sigma_fn
        self.profile_sigma = bool(profile_sigma)
        self.distribution = distribution
        self.n_trials = n_trials

    def evaluate(self, theta: np.ndarray) -> EvaluationResult:
        """Return fitted expectation, residuals, and log-likelihood for ``theta``."""

        raw_prediction = np.asarray(self.model_fn(theta, self.x), dtype=float).reshape(-1)
        if raw_prediction.shape != self.y.shape:
            raise ValueError(
                "Model function returned predictions with shape "
                f"{raw_prediction.shape}, expected {self.y.shape}."
            )

        if self.distribution == "gaussian":
            residuals = self.y - raw_prediction
            sigma_value = self._compute_sigma(theta, residuals)
            log_likelihood = gaussian_log_likelihood(residuals, sigma_value)
            return EvaluationResult(
                fitted=raw_prediction,
                residuals=residuals,
                sigma=sigma_value,
                log_likelihood=log_likelihood,
                extras={"sigma": sigma_value},
            )

        if self.distribution == "binomial":
            if self.n_trials is None:
                raise ValueError("`n_trials` must be provided for binomial outputs.")
            probs = _sigmoid(raw_prediction)
            trials = self.n_trials
            expectation = trials * probs
            residuals = self.y - expectation
            log_likelihood = binomial_log_likelihood(self.y, probs, trials)
            return EvaluationResult(
                fitted=expectation,
                residuals=residuals,
                sigma=None,
                log_likelihood=log_likelihood,
                extras={"probabilities": probs, "n_trials": trials},
            )

        if self.distribution == "poisson":
            rate = np.exp(raw_prediction)
            residuals = self.y - rate
            log_likelihood = poisson_log_likelihood(self.y, rate)
            return EvaluationResult(
                fitted=rate,
                residuals=residuals,
                sigma=None,
                log_likelihood=log_likelihood,
                extras={"rate": rate},
            )

        raise ValueError(f"Unsupported output distribution: {self.distribution}")

    def _compute_sigma(self, theta: np.ndarray, residuals: np.ndarray) -> float:
        """Determine the observation scale either from ``sigma_fn`` or profiling."""

        if self.sigma_fn is not None:
            sigma = float(self.sigma_fn(theta))
            if not np.isfinite(sigma) or sigma <= 0:
                raise ValueError("`sigma_fn` must return a positive finite scalar for every theta.")
            return sigma

        if self.profile_sigma:
            sigma = float(np.sqrt(np.mean(residuals**2)))
            if not np.isfinite(sigma) or sigma <= 0:
                raise ValueError(
                    "Residual-based sigma estimation failed. Ensure the model produces non-degenerate residuals."
                )
            return sigma

        raise ValueError(
            "Provide `sigma_fn` or set `profile_sigma=True` to specify the observation noise scale."
        )


__all__ = [
    "ObservationModelEvaluator",
    "EvaluationResult",
    "gaussian_log_likelihood",
    "binomial_log_likelihood",
    "poisson_log_likelihood",
]
