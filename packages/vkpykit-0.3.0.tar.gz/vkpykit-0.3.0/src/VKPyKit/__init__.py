from . import EDA
from . import DT

__all__ = [ "EDA", "DT"]
# AIFunctions.addDT(2, 3)