import unicodedata
from .detection import detect_language_distribution
from .processing import clean_text


def analyze(text: str) -> dict:
    if not text:
        return {}

    normalized = unicodedata.normalize("NFC", text)
    cleaned = clean_text(normalized)
    
    return detect_language_distribution(cleaned)