from ..analyzer import analyze

def determine(text: str) -> dict:
    for lang in analyze(text):
        print(lang)
    return analyze(text)