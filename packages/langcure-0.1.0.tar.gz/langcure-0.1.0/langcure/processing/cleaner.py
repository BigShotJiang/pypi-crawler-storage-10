import unicodedata
import re


def clean_text(text: str) -> str:
    cleaned = ''.join(
        char for char in text
        if unicodedata.category(char)[0] in ('L', 'M') or char.isspace()
    )
    return re.sub(r"\s+", " ", cleaned).strip()