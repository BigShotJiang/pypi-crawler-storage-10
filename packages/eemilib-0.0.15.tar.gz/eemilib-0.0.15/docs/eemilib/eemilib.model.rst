model package
=====================

.. automodule:: eemilib.model
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 5

   eemilib.model.chung_and_everhart
   eemilib.model.model
   eemilib.model.parameter
   eemilib.model.sombrin
   eemilib.model.vaughan
