main module
===================

.. automodule:: eemilib.main
   :members:
   :show-inheritance:
   :undoc-members:
