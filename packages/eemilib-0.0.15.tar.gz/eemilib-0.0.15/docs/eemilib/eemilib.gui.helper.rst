helper module
=========================

.. automodule:: eemilib.gui.helper
   :members:
   :show-inheritance:
   :undoc-members:
