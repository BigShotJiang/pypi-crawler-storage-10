parameter module
==============================

.. automodule:: eemilib.model.parameter
   :members:
   :show-inheritance:
   :undoc-members:
