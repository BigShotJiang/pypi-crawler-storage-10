constants module
=============================

.. automodule:: eemilib.util.constants
   :members:
   :show-inheritance:
   :undoc-members:
