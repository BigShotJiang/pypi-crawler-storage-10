emission\_angle\_distribution module
===========================================================

.. automodule:: eemilib.emission_data.emission_angle_distribution
   :members:
   :show-inheritance:
   :undoc-members:
