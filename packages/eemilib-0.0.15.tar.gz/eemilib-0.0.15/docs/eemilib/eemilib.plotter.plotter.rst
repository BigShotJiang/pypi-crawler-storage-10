plotter module
==============================

.. automodule:: eemilib.plotter.plotter
   :members:
   :show-inheritance:
   :undoc-members:
