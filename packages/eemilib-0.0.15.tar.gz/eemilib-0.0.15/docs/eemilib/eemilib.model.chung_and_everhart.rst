chung\_and\_everhart module
=========================================

.. automodule:: eemilib.model.chung_and_everhart
   :members:
   :show-inheritance:
   :undoc-members:
