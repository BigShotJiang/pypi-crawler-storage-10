ag package
=======================

.. automodule:: eemilib.data.ag
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 5

   eemilib.data.ag.emission_energy
