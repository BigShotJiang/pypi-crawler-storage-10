emission\_energy\_distribution module
============================================================

.. automodule:: eemilib.emission_data.emission_energy_distribution
   :members:
   :show-inheritance:
   :undoc-members:
