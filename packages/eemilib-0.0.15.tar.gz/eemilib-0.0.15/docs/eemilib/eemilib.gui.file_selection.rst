file\_selection module
==================================

.. automodule:: eemilib.gui.file_selection
   :members:
   :show-inheritance:
   :undoc-members:
