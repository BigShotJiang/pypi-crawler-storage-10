model\_config module
=================================

.. automodule:: eemilib.core.model_config
   :members:
   :show-inheritance:
   :undoc-members:
