emission\_energy package
========================================

.. automodule:: eemilib.data.ag.emission_energy
   :members:
   :show-inheritance:
   :undoc-members:
