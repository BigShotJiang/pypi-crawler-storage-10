emission\_data package
==============================

.. automodule:: eemilib.emission_data
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 5

   eemilib.emission_data.data_matrix
   eemilib.emission_data.emission_angle_distribution
   eemilib.emission_data.emission_data
   eemilib.emission_data.emission_energy_distribution
   eemilib.emission_data.emission_yield
   eemilib.emission_data.helper
