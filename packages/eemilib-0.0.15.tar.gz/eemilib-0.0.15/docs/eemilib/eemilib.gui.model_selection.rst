model\_selection module
===================================

.. automodule:: eemilib.gui.model_selection
   :members:
   :show-inheritance:
   :undoc-members:
