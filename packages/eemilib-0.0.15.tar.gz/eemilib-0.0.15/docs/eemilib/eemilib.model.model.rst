model module
==========================

.. automodule:: eemilib.model.model
   :members:
   :show-inheritance:
   :undoc-members:
