gui package
===================

.. automodule:: eemilib.gui
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 5

   eemilib.gui.file_selection
   eemilib.gui.gui
   eemilib.gui.helper
   eemilib.gui.model_selection
