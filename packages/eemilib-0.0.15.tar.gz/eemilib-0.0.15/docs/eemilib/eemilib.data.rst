data package
====================

.. automodule:: eemilib.data
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 5

   eemilib.data.ag
   eemilib.data.cu
