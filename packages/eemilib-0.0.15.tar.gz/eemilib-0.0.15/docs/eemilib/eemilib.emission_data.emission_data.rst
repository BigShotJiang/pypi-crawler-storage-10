emission\_data module
============================================

.. automodule:: eemilib.emission_data.emission_data
   :members:
   :show-inheritance:
   :undoc-members:
