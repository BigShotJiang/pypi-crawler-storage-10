vaughan module
============================

.. automodule:: eemilib.model.vaughan
   :members:
   :show-inheritance:
   :undoc-members:
