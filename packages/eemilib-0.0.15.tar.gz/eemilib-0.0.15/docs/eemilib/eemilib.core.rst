core package
====================

.. automodule:: eemilib.core
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

.. toctree::
   :maxdepth: 5

   eemilib.core.model_config
