helper module
====================================

.. automodule:: eemilib.emission_data.helper
   :members:
   :show-inheritance:
   :undoc-members:
