data\_matrix module
==========================================

.. automodule:: eemilib.emission_data.data_matrix
   :members:
   :show-inheritance:
   :undoc-members:
