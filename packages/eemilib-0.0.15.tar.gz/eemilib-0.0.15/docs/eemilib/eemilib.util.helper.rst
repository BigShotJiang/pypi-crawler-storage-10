helper module
==========================

.. automodule:: eemilib.util.helper
   :members:
   :show-inheritance:
   :undoc-members:
