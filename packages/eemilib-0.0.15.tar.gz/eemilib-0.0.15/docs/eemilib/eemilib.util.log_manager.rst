log\_manager module
================================

.. automodule:: eemilib.util.log_manager
   :members:
   :show-inheritance:
   :undoc-members:
