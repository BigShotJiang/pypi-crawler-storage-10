emission\_yield module
=============================================

.. automodule:: eemilib.emission_data.emission_yield
   :members:
   :show-inheritance:
   :undoc-members:
