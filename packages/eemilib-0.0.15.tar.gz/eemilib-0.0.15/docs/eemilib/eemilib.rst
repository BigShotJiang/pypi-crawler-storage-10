eemilib package
===============

.. automodule:: eemilib
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 5

   eemilib.core
   eemilib.data
   eemilib.emission_data
   eemilib.gui
   eemilib.loader
   eemilib.model
   eemilib.plotter
   eemilib.util

Submodules
----------

.. toctree::
   :maxdepth: 5

   eemilib.main
