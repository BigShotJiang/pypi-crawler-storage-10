helper module
=============================

.. automodule:: eemilib.plotter.helper
   :members:
   :show-inheritance:
   :undoc-members:
