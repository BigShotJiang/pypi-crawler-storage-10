gui module
======================

.. automodule:: eemilib.gui.gui
   :members:
   :show-inheritance:
   :undoc-members:
