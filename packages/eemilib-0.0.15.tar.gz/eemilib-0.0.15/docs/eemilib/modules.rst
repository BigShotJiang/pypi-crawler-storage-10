src
===

.. toctree::
   :maxdepth: 5

   eemilib
