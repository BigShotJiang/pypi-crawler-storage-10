sombrin module
============================

.. automodule:: eemilib.model.sombrin
   :members:
   :show-inheritance:
   :undoc-members:
