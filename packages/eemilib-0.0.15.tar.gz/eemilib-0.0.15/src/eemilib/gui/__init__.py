"""Define the GUI."""
