"""This module provides data for example and testing purposes."""
