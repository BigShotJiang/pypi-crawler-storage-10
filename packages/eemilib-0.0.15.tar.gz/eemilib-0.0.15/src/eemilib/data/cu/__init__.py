"""This set of data is available online :cite:`Placais2020b`. Please use this
reference if you use it in your work.

It corresponds to the two Cu samples I used in my PhD :cite:`Placais2021`.

This data can be loaded with :class:`.pandas_loader.PandasLoader`.

"""
