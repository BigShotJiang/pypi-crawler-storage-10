"""Define objects to store electron emission data."""

from .data_matrix import DataMatrix

__all__ = ["DataMatrix"]
