"""Define the object that will take care of plotting the data."""

from .pandas import PandasPlotter

__all__ = ["PandasPlotter"]
