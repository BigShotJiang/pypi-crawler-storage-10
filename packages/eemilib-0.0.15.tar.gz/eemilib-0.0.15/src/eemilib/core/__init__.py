"""Define fundamental objects used by several other modules."""
