# Batre CLI — Client-Side Ingestion Tool

## Setup
```bash
make install
