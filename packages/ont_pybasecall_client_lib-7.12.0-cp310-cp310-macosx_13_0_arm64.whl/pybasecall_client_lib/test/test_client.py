#! /usr/bin/env python3

import importlib.resources
import os
import unittest

from pybasecall_client_lib import TEST_SERVER_PORT
from pybasecall_client_lib.client_lib import BasecallClient
from pybasecall_client_lib.helper_functions import basecall_with_pybasecall_client


class TestBasecallClientLib(unittest.TestCase):
    # TEST_SERVER_PORT can be set automatically in the main __init__.py when a
    # server is started, but if it's not we'll check for an environment
    # variable.
    SERVER_ADDRESS = TEST_SERVER_PORT
    if SERVER_ADDRESS is None:
        SERVER_ADDRESS = os.environ.get("TEST_SERVER_PORT")
    MODEL_SET = "dna_r10.4.1_e8.2_400bps_fast@v5.2.0||"
    DNA_FOLDER = "dna"
    print("Server address is {}".format(SERVER_ADDRESS))

    def setUp(self):
        data_dir = os.path.join("test", "data")
        ref = importlib.resources.files("pybasecall_client_lib") / data_dir
        with importlib.resources.as_file(ref) as path:
            self.data_path = path

    def tearDown(self):
        pass

    def test_00_basecalling_test(self):
        if TestBasecallClientLib.SERVER_ADDRESS is None:
            raise unittest.SkipTest("No server port has been set.")
        input_folder = os.path.join(self.data_path, TestBasecallClientLib.DNA_FOLDER)
        client = BasecallClient(
            TestBasecallClientLib.SERVER_ADDRESS, TestBasecallClientLib.MODEL_SET
        )
        client.set_params({"client_name": "basecall_client_test_00_basecalling_test"})
        self.assertEqual(
            BasecallClient.disconnected,
            client.get_status(),
            "validate connection status disconnected prior to connect.",
        )
        result = client.connect()
        self.assertEqual(BasecallClient.success, result)
        self.assertEqual(
            BasecallClient.connected,
            client.get_status(),
            "validate connection status after connecting.",
        )
        try:
            basecall_with_pybasecall_client(client, input_folder)
        finally:
            client.disconnect()
