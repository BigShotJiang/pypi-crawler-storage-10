galassify module
=================

.. automodule:: galassify.galassify
    :members:
    :show-inheritance:
