gui module
==========

.. automodule:: galassify.gui
    :members:
    :show-inheritance: