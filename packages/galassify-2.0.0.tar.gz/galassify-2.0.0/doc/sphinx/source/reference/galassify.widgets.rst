widgets module
==============

.. automodule:: galassify.widgets
    :members:
    :show-inheritance: