API Reference
=============

.. toctree::
    :maxdepth: 3

    galassify
    get_images

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`