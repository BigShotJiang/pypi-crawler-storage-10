utils module
================

.. automodule:: galassify.utils
    :members:
    :show-inheritance:
