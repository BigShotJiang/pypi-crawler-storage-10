.. GALAssify documentation master file, created by
   sphinx-quickstart on Tue Nov 12 08:13:23 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

GALAssify
=========

.. include:: ../../../README.md
   :parser: myst_parser.sphinx_
   :start-after: # GALAssify
   :end-before: <!-- doc -->

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   getting_started/index
   developer_guide/index
   reference/index
   

