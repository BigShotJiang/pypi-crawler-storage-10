from pathlib import Path
import sys

sys.path.append(str(Path(__file__).resolve().parents[1]))

import pytest

from telegram_markdown import render_markdown_to_telegram


@pytest.mark.parametrize(
    "source, expected",
    [
        ("**bold** text", "*bold* text"),
        ("__italic__", "*italic*"),
        ("`code_snippet`", "`code_snippet`"),
        ("普通文本 (test)", "普通文本 \\(test\\)"),
        ("raw *literal* star", "raw _literal_ star"),
        ("带感叹号! 以及加号+", "带感叹号\\! 以及加号\\+"),
        ("multiline\nline2", "multiline\nline2"),
    ],
)
def test_render_inline_markdown(source: str, expected: str) -> None:
    assert render_markdown_to_telegram(source) == expected


def test_render_code_block_with_language() -> None:
    markdown = "```python\nprint('hello')\n```"
    rendered = render_markdown_to_telegram(markdown)
    assert rendered == "```python\nprint('hello')\n```"


def test_render_bullet_list() -> None:
    markdown = "- item 1\n- item 2"
    rendered = render_markdown_to_telegram(markdown)
    assert rendered.splitlines() == ["- item 1", "- item 2"]


def test_render_ordered_list() -> None:
    markdown = "1. first\n2. second"
    rendered = render_markdown_to_telegram(markdown)
    assert rendered.splitlines() == ["1. first", "2. second"]


def test_render_heading_and_paragraph_spacing() -> None:
    markdown = "# Title\n\nParagraph line."
    rendered = render_markdown_to_telegram(markdown)
    assert rendered == "*Title*\n\nParagraph line\\."


def test_render_blockquote() -> None:
    markdown = "> quote"
    assert render_markdown_to_telegram(markdown) == "> quote"


def test_render_link() -> None:
    markdown = "[link](https://example.com/path?a=1&b=2)"
    assert render_markdown_to_telegram(markdown) == "[link](https://example.com/path?a=1&b=2)"
