from setuptools import setup, find_packages

setup(
    name="entropy-rag",
    version="1.0.0",
    description="Entropy-regulated retrieval-augmented reasoning system inspired by diffusion physics.",
    author="Steven Reid",
    author_email="sreid1118@gmail.com",
    license="Apache-2.0",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "numpy",
        "scipy",
        "scikit-learn",
        "nltk",
        "transformers",
        "torch",
        "sentence-transformers"
    ],
)
