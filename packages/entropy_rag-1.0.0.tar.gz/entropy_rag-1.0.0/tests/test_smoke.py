import pytest
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import entropy_rag.entropy_index as ei
import entropy_rag.retriever as er

def test_index_and_retrieval():
    # Minimal sanity check: can build index and retrieve a doc
    docs = [
        "Entropy stabilizes diffusion by regulating potential energy.",
        "Topological Adam introduces alpha-beta coupling in optimization.",
        "Nonlinear PDEs improve stability in differentiable physics."
    ]
    index = ei.build_index(docs, n_topics=3)
    selector = er.EntropyBalancedSelector(index, er.EntropySelectorConfig(Omega_mode='median'))
    results = selector.retrieve('how does entropy regulate diffusion?', k=3)

    assert isinstance(results, list)
    assert len(results) > 0
    assert any('entropy' in r.lower() for r in results)

if __name__ == '__main__':
    pytest.main([__file__])
