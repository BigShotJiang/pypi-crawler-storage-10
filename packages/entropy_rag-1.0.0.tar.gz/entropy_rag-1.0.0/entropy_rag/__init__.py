"""Entropy-Balanced Retrieval (Ω–λ–C)
Author: Steven Reid (RRG314)
License: Apache-2.0
"""

from .embedder import Embedder
from .entropy_index import Index, build_index
from .retriever import EntropyBalancedSelector, EntropySelectorConfig, vanilla_topk
from .evaluator import evaluate_retrieval
