import numpy as np, time, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def compute_div(chunks):
    vect=TfidfVectorizer(stop_words="english")
    X=vect.fit_transform(chunks)
    S=cosine_similarity(X)
    mask=~np.eye(len(chunks),dtype=bool)
    return 1 - S[mask].mean()

def evaluate_retrieval(index, selector, queries, k=6):
    results=[]
    for q in queries:
        t0=time.time(); v_docs=vanilla_topk(index,q,k); v_time=time.time()-t0
        t0=time.time(); e_docs=selector.select(q,k); e_time=time.time()-t0
        v_div=compute_div(v_docs); e_div=compute_div(e_docs)
        results.append({"query":q,"div_vanilla":v_div,"div_entropy":e_div,
                        "time_vanilla":v_time,"time_entropy":e_time})
    return pd.DataFrame(results)
