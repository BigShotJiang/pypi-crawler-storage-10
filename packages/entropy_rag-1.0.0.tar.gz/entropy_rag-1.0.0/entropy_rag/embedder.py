import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class Embedder:
    """TF-IDF embedder (replaceable with transformer later)."""
    def __init__(self):
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), min_df=1)
    def fit(self, docs):
        self.docs = docs
        self.doc_mat = self.vectorizer.fit_transform(docs)
        return self
    def encode(self, texts):
        return self.vectorizer.transform(texts)
    def similarity(self, query_vec, subset=None):
        mat = self.doc_mat if subset is None else self.doc_mat[subset]
        return cosine_similarity(query_vec, mat)[0]
