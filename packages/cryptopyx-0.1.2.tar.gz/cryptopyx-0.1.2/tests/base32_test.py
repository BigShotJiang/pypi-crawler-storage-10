import pytest
from cryptopyx.encodings import base32
from utils import random_base32


def test_base32_encode():
    # Basic functionality
    assert base32.encode('hello') == 'NBSWY3DP'
    assert base32.encode('hello there') == 'NBSWY3DPEB2GQZLSMU======'
    assert (
        base32.encode('The quick brown fox jumps over the lazy dog.')
        == 'KRUGKIDROVUWG2ZAMJZG653OEBTG66BANJ2W24DTEBXXMZLSEB2GQZJANRQXU6JAMRXWOLQ='
    )
    # Encode bytes
    assert base32.encode_bytes(b'hello') == b'NBSWY3DP'


def test_base32_decode():
    # Basic functionality
    assert base32.decode('NBSWY3DP') == 'hello'
    assert base32.decode('NBSWY3DPEB2GQZLSMU======') == 'hello there'
    assert (
        base32.decode(
            'KRUGKIDROVUWG2ZAMJZG653OEBTG66BANJ2W24DTEBXXMZLSEB2GQZJANRQXU6JAMRXWOLQ='
        )
        == 'The quick brown fox jumps over the lazy dog.'
    )
    # Decode bytes
    assert base32.decode_bytes(b'NBSWY3DP') == b'hello'
    assert base32.decode_bytes(b'74======') == b'\xff'
    # Decode errors
    with pytest.raises(ValueError):
        base32.decode('Sphinx of black quartz, judge my vow')
        base32.decode('74======')
        base32.decode('NBSWY3DP=')


# Benchmarks (cause why not?)
def test_base32_encode_benchmark(benchmark):
    strings: list[str] = random_base32(
        1000000, string_num=100
    )  # 1 million chars, 100 strings
    bytes = [string.encode() for string in strings]

    def multi_encode():
        for byte in bytes:
            base32.encode_bytes(byte)

    benchmark(multi_encode)


def test_base32_decode_benchmark(benchmark):
    strings: list[str] = random_base32(
        1000000, string_num=100
    )  # 1 million chars, 100 strings
    bytes = [string.encode() for string in strings]

    def multi_decode():
        for byte in bytes:
            base32.decode_bytes(byte)

    benchmark(multi_decode)
