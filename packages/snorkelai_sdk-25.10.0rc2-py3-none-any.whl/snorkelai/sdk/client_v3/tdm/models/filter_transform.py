from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Type,
    TypeVar,
)

import attrs

from ..models.dataset_transform_type import DatasetTransformType

if TYPE_CHECKING:
    # fmt: off
    from ..models.dataset_transform_config import DatasetTransformConfig  # noqa: F401
    # fmt: on


T = TypeVar("T", bound="FilterTransform")


@attrs.define
class FilterTransform:
    """
    Attributes:
        config (DatasetTransformConfig):
        transform_type (DatasetTransformType):
    """

    config: "DatasetTransformConfig"
    transform_type: DatasetTransformType
    additional_properties: Dict[str, Any] = attrs.field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        # fmt: off
        from ..models.dataset_transform_config import (
            DatasetTransformConfig,  # noqa: F401
        )
        # fmt: on
        config = self.config.to_dict()
        transform_type = self.transform_type.value

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "config": config,
                "transform_type": transform_type,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        # fmt: off
        from ..models.dataset_transform_config import (
            DatasetTransformConfig,  # noqa: F401
        )
        # fmt: on
        d = src_dict.copy()
        config = DatasetTransformConfig.from_dict(d.pop("config"))

        transform_type = DatasetTransformType(d.pop("transform_type"))

        obj = cls(
            config=config,
            transform_type=transform_type,
        )
        obj.additional_properties = d
        return obj

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
