⚠️ THIS PROJECT 'nvidia-nvvm-cu13' IS DEPRECATED.
Please use 'nvidia-nvvm' instead.

To install the correct package, use:

    pip install nvidia-nvvm

For more information, visit: https://pypi.org/project/nvidia-nvvm/
