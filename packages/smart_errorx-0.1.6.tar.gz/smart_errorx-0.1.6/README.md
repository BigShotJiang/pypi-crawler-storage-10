🧠 SmartErrorX — AI-Powered Error Detection & Fix Suggestions.



SmartErrorX is an intelligent **Python error-handling library** That automatically detects in user code, analyzes them using **OpenAI**, and displays **the cause and fix suggestions** in a clean, formatted terminal output using the **Rich** Library.


⚙️ How It Works:-

When you decorate any Python function with `@catch`, SmartErrorX automatically:

1. Executes your function.
2. If an error occurs:
   - Captures the **error message**, **function source code**, and **arguments**.
   - Sends that data to the **OpenAI model** using your API key from `.env`.
   - Receives a structured response containing:
     - 🧩 **Cause** – why the error occurred.
     - 🔧 **Fix** – how to correct it.
   - Displays both with colorful Rich panels.