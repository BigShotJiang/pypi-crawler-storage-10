"""
FreeP2W - Free PDF to Word Converter
"""

__version__ = "1.0.0"

__all__ = []
