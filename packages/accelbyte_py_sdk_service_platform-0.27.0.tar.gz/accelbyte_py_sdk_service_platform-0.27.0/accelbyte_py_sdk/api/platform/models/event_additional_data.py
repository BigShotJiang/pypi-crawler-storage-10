# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: model.j2

# AccelByte Gaming Services Platform Service

# pylint: disable=duplicate-code
# pylint: disable=line-too-long
# pylint: disable=missing-function-docstring
# pylint: disable=missing-module-docstring
# pylint: disable=too-many-arguments
# pylint: disable=too-many-branches
# pylint: disable=too-many-instance-attributes
# pylint: disable=too-many-lines
# pylint: disable=too-many-locals
# pylint: disable=too-many-public-methods
# pylint: disable=too-many-return-statements
# pylint: disable=too-many-statements
# pylint: disable=unused-import

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union

from accelbyte_py_sdk.core import Model

from ..models.additional_data_entitlement import AdditionalDataEntitlement


class EventAdditionalData(Model):
    """Event additional data (EventAdditionalData)

    Properties:
        entitlement: (entitlement) OPTIONAL List[AdditionalDataEntitlement]

        purpose: (purpose) OPTIONAL str
    """

    # region fields

    entitlement: List[AdditionalDataEntitlement]  # OPTIONAL
    purpose: str  # OPTIONAL

    # endregion fields

    # region with_x methods

    def with_entitlement(
        self, value: List[AdditionalDataEntitlement]
    ) -> EventAdditionalData:
        self.entitlement = value
        return self

    def with_purpose(self, value: str) -> EventAdditionalData:
        self.purpose = value
        return self

    # endregion with_x methods

    # region to methods

    def to_dict(self, include_empty: bool = False) -> dict:
        result: dict = {}
        if hasattr(self, "entitlement"):
            result["entitlement"] = [
                i0.to_dict(include_empty=include_empty) for i0 in self.entitlement
            ]
        elif include_empty:
            result["entitlement"] = []
        if hasattr(self, "purpose"):
            result["purpose"] = str(self.purpose)
        elif include_empty:
            result["purpose"] = ""
        return result

    # endregion to methods

    # region static methods

    @classmethod
    def create(
        cls,
        entitlement: Optional[List[AdditionalDataEntitlement]] = None,
        purpose: Optional[str] = None,
        **kwargs,
    ) -> EventAdditionalData:
        instance = cls()
        if entitlement is not None:
            instance.entitlement = entitlement
        if purpose is not None:
            instance.purpose = purpose
        return instance

    @classmethod
    def create_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> EventAdditionalData:
        instance = cls()
        if not dict_:
            return instance
        if "entitlement" in dict_ and dict_["entitlement"] is not None:
            instance.entitlement = [
                AdditionalDataEntitlement.create_from_dict(
                    i0, include_empty=include_empty
                )
                for i0 in dict_["entitlement"]
            ]
        elif include_empty:
            instance.entitlement = []
        if "purpose" in dict_ and dict_["purpose"] is not None:
            instance.purpose = str(dict_["purpose"])
        elif include_empty:
            instance.purpose = ""
        return instance

    @classmethod
    def create_many_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> Dict[str, EventAdditionalData]:
        return (
            {k: cls.create_from_dict(v, include_empty=include_empty) for k, v in dict_}
            if dict_
            else {}
        )

    @classmethod
    def create_many_from_list(
        cls, list_: list, include_empty: bool = False
    ) -> List[EventAdditionalData]:
        return (
            [cls.create_from_dict(i, include_empty=include_empty) for i in list_]
            if list_
            else []
        )

    @classmethod
    def create_from_any(
        cls, any_: any, include_empty: bool = False, many: bool = False
    ) -> Union[
        EventAdditionalData, List[EventAdditionalData], Dict[Any, EventAdditionalData]
    ]:
        if many:
            if isinstance(any_, dict):
                return cls.create_many_from_dict(any_, include_empty=include_empty)
            elif isinstance(any_, list):
                return cls.create_many_from_list(any_, include_empty=include_empty)
            else:
                raise ValueError()
        else:
            return cls.create_from_dict(any_, include_empty=include_empty)

    @staticmethod
    def get_field_info() -> Dict[str, str]:
        return {
            "entitlement": "entitlement",
            "purpose": "purpose",
        }

    @staticmethod
    def get_required_map() -> Dict[str, bool]:
        return {
            "entitlement": False,
            "purpose": False,
        }

    # endregion static methods
