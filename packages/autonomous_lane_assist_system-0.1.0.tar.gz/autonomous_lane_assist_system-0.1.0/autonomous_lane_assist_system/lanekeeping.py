"""Lane keeping algorithms refactored from script.

This module provides pure functions for edge detection, line finding and steering
angle calculation. It also includes a lightweight `run_camera_loop` helper that
can be used on Raspberry Pi if RPi.GPIO is available. GPIO interactions are
optional and guarded so the module can be imported on non-RPi machines for
development and testing.
"""

from typing import List, Optional
import cv2
import numpy as np
import math
import time

try:
    import RPi.GPIO as GPIO
    _HAS_GPIO = True
except Exception:
    GPIO = None
    _HAS_GPIO = False


# -- GPIO defaults (only used if _HAS_GPIO) --
DEFAULT_GPIO_CONFIG = {
    "throttlePin": 25,
    "in3": 23,
    "in4": 24,
    "steeringPin": 22,
    "in1": 17,
    "in2": 27,
}


def detect_edges(frame: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_blue = np.array([90, 120, 0], dtype="uint8")
    upper_blue = np.array([150, 255, 255], dtype="uint8")
    mask = cv2.inRange(hsv, lower_blue, upper_blue)
    edges = cv2.Canny(mask, 50, 100)
    return edges


def region_of_interest(edges: np.ndarray) -> np.ndarray:
    height, width = edges.shape
    mask = np.zeros_like(edges)
    polygon = np.array([[
        (0, height),
        (0, int(height / 2)),
        (width, int(height / 2)),
        (width, height),
    ]], np.int32)
    cv2.fillPoly(mask, polygon, 255)
    cropped_edges = cv2.bitwise_and(edges, mask)
    return cropped_edges


def detect_line_segments(cropped_edges: np.ndarray) -> Optional[np.ndarray]:
    rho = 1
    theta = np.pi / 180
    min_threshold = 10
    line_segments = cv2.HoughLinesP(cropped_edges, rho, theta, min_threshold,
                                    np.array([]), minLineLength=5, maxLineGap=150)
    return line_segments


def make_points(frame: np.ndarray, line: np.ndarray) -> List[List[int]]:
    height, width, _ = frame.shape
    slope, intercept = line
    y1 = height
    y2 = int(y1 / 2)
    if slope == 0:
        slope = 0.1
    x1 = int((y1 - intercept) / slope)
    x2 = int((y2 - intercept) / slope)
    return [[x1, y1, x2, y2]]


def average_slope_intercept(frame: np.ndarray, line_segments: Optional[np.ndarray]) -> List[List[int]]:
    lane_lines = []
    if line_segments is None:
        return lane_lines
    height, width, _ = frame.shape
    left_fit = []
    right_fit = []
    boundary = 1 / 3
    left_region_boundary = width * (1 - boundary)
    right_region_boundary = width * boundary
    for segment in line_segments:
        for x1, y1, x2, y2 in segment:
            if x1 == x2:
                continue
            slope = (y2 - y1) / (x2 - x1)
            intercept = y1 - (slope * x1)
            if slope < 0:
                if x1 < left_region_boundary and x2 < left_region_boundary:
                    left_fit.append((slope, intercept))
            else:
                if x1 > right_region_boundary and x2 > right_region_boundary:
                    right_fit.append((slope, intercept))
    if len(left_fit) > 0:
        left_fit_average = np.average(left_fit, axis=0)
        lane_lines.append(make_points(frame, left_fit_average))
    if len(right_fit) > 0:
        right_fit_average = np.average(right_fit, axis=0)
        lane_lines.append(make_points(frame, right_fit_average))
    return lane_lines


def display_lines(frame: np.ndarray, lines: List[List[int]], line_color=(0, 255, 0), line_width=6) -> np.ndarray:
    line_image = np.zeros_like(frame)
    if lines is not None:
        for line in lines:
            for x1, y1, x2, y2 in line:
                cv2.line(line_image, (x1, y1), (x2, y2), line_color, line_width)
    line_image = cv2.addWeighted(frame, 0.8, line_image, 1, 1)
    return line_image


def display_heading_line(frame: np.ndarray, steering_angle: float, line_color=(0, 0, 255), line_width=5) -> np.ndarray:
    heading_image = np.zeros_like(frame)
    height, width, _ = frame.shape
    steering_angle_radian = steering_angle / 180.0 * math.pi
    x1 = int(width / 2)
    y1 = height
    x2 = int(x1 - height / 2 / math.tan(steering_angle_radian))
    y2 = int(height / 2)
    cv2.line(heading_image, (x1, y1), (x2, y2), line_color, line_width)
    heading_image = cv2.addWeighted(frame, 0.8, heading_image, 1, 1)
    return heading_image


def get_steering_angle(frame: np.ndarray, lane_lines: List[List[int]]) -> int:
    height, width, _ = frame.shape
    if len(lane_lines) == 2:
        _, _, left_x2, _ = lane_lines[0][0]
        _, _, right_x2, _ = lane_lines[1][0]
        mid = int(width / 2)
        x_offset = (left_x2 + right_x2) / 2 - mid
        y_offset = int(height / 2)
    elif len(lane_lines) == 1:
        x1, _, x2, _ = lane_lines[0][0]
        x_offset = x2 - x1
        y_offset = int(height / 2)
    else:
        x_offset = 0
        y_offset = int(height / 2)
    angle_to_mid_radian = math.atan(x_offset / y_offset)
    angle_to_mid_deg = int(angle_to_mid_radian * 180.0 / math.pi)
    steering_angle = angle_to_mid_deg + 90
    return steering_angle


def _setup_gpio(cfg: dict = DEFAULT_GPIO_CONFIG):
    if not _HAS_GPIO:
        raise RuntimeError("RPi.GPIO not available on this platform")
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    for pin in (cfg["in1"], cfg["in2"], cfg["in3"], cfg["in4"]):
        GPIO.setup(pin, GPIO.OUT)
    GPIO.setup(cfg["throttlePin"], GPIO.OUT)
    GPIO.setup(cfg["steeringPin"], GPIO.OUT)
    return cfg


def run_camera_loop(use_gpio: bool = False, cfg: dict = DEFAULT_GPIO_CONFIG):
    """Run a simplified camera loop. If use_gpio is True, RPi GPIO must be
    available and will be used to control PWM. This function is a convenience
    wrapper and keeps the original behavior but is safe to import on non-RPi
    systems when use_gpio=False.
    """
    if use_gpio and not _HAS_GPIO:
        raise RuntimeError("use_gpio=True requires RPi.GPIO installed")

    if use_gpio:
        _setup_gpio(cfg)
        GPIO.output(cfg["in3"], GPIO.HIGH)
        GPIO.output(cfg["in4"], GPIO.LOW)
        steering = GPIO.PWM(cfg["steeringPin"], 1000)
        throttle = GPIO.PWM(cfg["throttlePin"], 1000)
    else:
        steering = throttle = None

    video = cv2.VideoCapture(0)
    video.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    video.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
    time.sleep(1)

    speed = 8
    lastTime = time.time()
    lastError = 0
    kp = 0.4
    kd = kp * 0.65

    try:
        while True:
            ret, frame = video.read()
            if not ret:
                break
            frame = cv2.flip(frame, -1)
            edges = detect_edges(frame)
            roi = region_of_interest(edges)
            line_segments = detect_line_segments(roi)
            lane_lines = average_slope_intercept(frame, line_segments)
            lane_lines_image = display_lines(frame, lane_lines)
            steering_angle = get_steering_angle(frame, lane_lines)
            heading_image = display_heading_line(lane_lines_image, steering_angle)
            cv2.imshow("heading line", heading_image)

            now = time.time()
            dt = now - lastTime
            deviation = steering_angle - 90
            error = abs(deviation)

            if use_gpio:
                if -5 < deviation < 5:
                    GPIO.output(cfg["in1"], GPIO.LOW)
                    GPIO.output(cfg["in2"], GPIO.LOW)
                    steering.stop()
                elif deviation > 5:
                    GPIO.output(cfg["in1"], GPIO.LOW)
                    GPIO.output(cfg["in2"], GPIO.HIGH)
                    steering.start(100)
                else:
                    GPIO.output(cfg["in1"], GPIO.HIGH)
                    GPIO.output(cfg["in2"], GPIO.LOW)
                    steering.start(100)

                derivative = kd * (error - lastError) / max(dt, 1e-6)
                proportional = kp * error
                PD = int(speed + derivative + proportional)
                spd = abs(PD)
                spd = min(spd, 25)
                throttle.start(spd)

            lastError = error
            lastTime = time.time()

            key = cv2.waitKey(1)
            if key == 27:
                break
    finally:
        video.release()
        cv2.destroyAllWindows()
        if use_gpio:
            for pin in (cfg["in1"], cfg["in2"], cfg["in3"], cfg["in4"]):
                GPIO.output(pin, GPIO.LOW)
            throttle.stop()
            steering.stop()
