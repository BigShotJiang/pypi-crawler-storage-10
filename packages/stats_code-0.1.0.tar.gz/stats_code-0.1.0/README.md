# Code Statistics
A full python tool to gather statistics from your codebase.
It can be customized flexibly to fit your needs.

## Quick Start
Install the package via pip:
```bash
pip install code-stat
```

Run the tool on your codebase:
```bash
code-stat
```