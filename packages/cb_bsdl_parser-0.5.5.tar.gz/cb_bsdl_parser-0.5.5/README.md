<h1 align="center">

[![pypi](https://img.shields.io/pypi/v/cb_bsdl_parser.svg)](https://pypi.org/project/cb_bsdl_parser/)
[![python](https://img.shields.io/pypi/pyversions/cb_bsdl_parser.svg)](https://pypi.org/project/cb_bsdl_parser/)
<br>
[![Tests Status](./doc/tests-badge.svg)]()
[![Coverage Status](./doc/coverage-badge.svg)]()

</h1>



# Chriesibaum's BSDL File Parser



## dev tool installation

install antlr4 from the deb package sources/store:

```
sudo apt install antlr4
```