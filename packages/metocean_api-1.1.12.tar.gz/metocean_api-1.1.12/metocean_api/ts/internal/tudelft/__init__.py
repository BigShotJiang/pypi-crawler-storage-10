"""
Internal package for ECHOWAVE.

"""
