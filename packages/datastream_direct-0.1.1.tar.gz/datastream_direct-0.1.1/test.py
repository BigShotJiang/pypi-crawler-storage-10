from datastream_direct.connection import connect
from datastream_direct.pandas_extras import fetch_frame

connection = connect(
    username="skrughoff+17@energydomain.com",
    password="p!Assword1",
    host="data-dev-api.energydomain.com",
    port=443,
    database="energy_domain",
)

cursor = connection.cursor()
df = fetch_frame(cursor, "SELECT * from well_combined limit 100")
print(df)

connection.close()
