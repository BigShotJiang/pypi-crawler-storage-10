__version__ = '2.8.1.88'
__version_info__ = tuple(int(i) for i in __version__.split('.') if i.isdigit())
