from pydantic import Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from maleo.schemas.mixins.identity import Identifier
from ..enums.user_medical_role import IdentifierType
from ..types.user_medical_role import CompositeIdentifier, IdentifierValueType


class UserMedicalRoleIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    pass


class IdUserMedicalRoleIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDUserMedicalRoleIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


class CompositeUserMedicalRoleIdentifier(
    Identifier[Literal[IdentifierType.COMPOSITE], CompositeIdentifier]
):
    type: Annotated[
        Literal[IdentifierType.COMPOSITE],
        Field(IdentifierType.COMPOSITE, description="Identifier's type"),
    ] = IdentifierType.COMPOSITE
    value: Annotated[CompositeIdentifier, Field(..., description="Identifier's value")]


AnyUserMedicalRoleIdentifier = (
    UserMedicalRoleIdentifier
    | IdUserMedicalRoleIdentifier
    | UUIDUserMedicalRoleIdentifier
    | CompositeUserMedicalRoleIdentifier
)


def is_id_identifier(
    identifier: AnyUserMedicalRoleIdentifier,
) -> TypeGuard[IdUserMedicalRoleIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyUserMedicalRoleIdentifier,
) -> TypeGuard[UUIDUserMedicalRoleIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)


def is_composite_identifier(
    identifier: AnyUserMedicalRoleIdentifier,
) -> TypeGuard[CompositeUserMedicalRoleIdentifier]:
    return identifier.type is IdentifierType.COMPOSITE and isinstance(
        identifier.value, tuple
    )
