from setuptools import setup, find_packages

setup(
    name="chzhq0518-pythonproject",
    version="0.1.0",
    description="Python Project",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        # 在这里添加依赖
    ],
)

