import json

from kaq_quant_common.common.redis_table_monitor import RedisTableMonitor
from kaq_quant_common.utils import yml_utils


# 订单簿交易对监听器
class LimitOrderSymbolMonitor(RedisTableMonitor):
    def __init__(self, exchange: str, handler: callable = None, default_symbols=["BTCUSDT", "ETHUSDT"]):
        #
        self._exchange = exchange
        # 回调
        self._handler = handler
        #
        self._default_symbols = default_symbols
        # 间隔1秒
        super().__init__(table_name="kaq_all_futures_limit_order_symbols_config", interval=1)

        # 输出一下初始的交易对
        self._logger.info(f"init {self._exchange} limit order symbols: {self._default_symbols}")

    def _on_get_redis_config(self):
        # 获取redis配置
        host, port, passwd = yml_utils.get(f"kaq_{self._exchange}_quant", "redis", ["host", "port", "passwd"])
        return {"host": host, "port": int(port), "passwd": passwd}

    def _do_query(self) -> str:
        # 获取字符串
        str = super()._do_query()
        try:
            # 解析为json
            json_obj = json.loads(str)
            # 只要平台的值
            symbols = json_obj.get(self._exchange, self._default_symbols)
        except Exception as e:
            symbols = self._default_symbols
        return symbols

    def _do_compare(self, value1: list[str], value2: list[str]) -> bool:
        # 判断数组是否一样，数组也是这样判断也可以
        return value1 == value2

    def _on_value_change(self, value: list[str]):
        # 输出一下变化的交易对
        self._logger.info(f"{self._exchange} limit order symbols changed: {value}")
        if self._handler is not None:
            self._handler(value)

    # get, set
    def set_handler(self, handler: callable):
        self._handler = handler

    def get_symbols(self) -> list[str]:
        return self._value
