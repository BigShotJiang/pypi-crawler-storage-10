from .NitroDec import patch_starlette_app

__version__ = "0.1.4"

patch_starlette_app()