from flask import Request

def del_garbage(text):
    out = ""

    for i, char in enumerate(text):
        if not char in "\t\n ":
            out += text[i:]
            break

    i = len(out)
    while i > 1:
        i -= 1
        char = out[i]
        if not char in "\n\t ":
            return out[:i + 1]
    return out

def rinfo(name, data, tabs, tab):
    print(f"{tab*tabs}{name}:" + " {")
    for key, value in data.items():
        if not isinstance(value, dict):
            print(f"{tab*(tabs+1)}{key}: {value}")
        else:
            rinfo(key, value, tabs+1, tab)
    print(f"{tab*tabs}" + "}")

def info(request : Request):
    tab = "    "

    if not isinstance(request, Request):
        print("Not request")
        return
    
    print(f"Request <{request.content_type}> :" + " {")
    for key, value in request.json.items():
        if not isinstance(value, dict):
            print(f"{tab}{key}: {value}")
        else:
            rinfo(key, value, 1, tab)
    print("}")

def sum_paths(*paths):
    out = ""
    for path in paths:
        if len(path) > 0:
            if del_garbage(path).replace("/", "\\")[-1] == "\\":
                out += del_garbage(path).replace("/", "\\")
            else:
                out += del_garbage(path).replace("/", "\\") + "\\"
    return out[:-1]

def split_first(text: str, char: str) -> tuple[str, str]:
    return text.split(char)[0], char.join(text.split(char)[1:])

def split_last(text: str, char: str) -> tuple[str, str]:
    return char.join(text.split(char)[:-1]), text.split(char)[-1]