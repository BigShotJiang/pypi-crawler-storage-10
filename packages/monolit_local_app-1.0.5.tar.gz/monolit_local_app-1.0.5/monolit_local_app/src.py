class App:
    from typing import Callable, Optional
    from monolit_local_app.other import sum_paths
    from os.path import dirname

    www: str = None
    process_request: Optional[Callable] = None
    process_path: Optional[Callable] = None
    not_found: str = sum_paths(dirname(__file__), "not-found.html")
    port: int = 5000
    debug: bool = False

    del Callable, Optional, sum_paths, dirname

def host(src):
    import monolit_local_app as ml
    from typing import Callable, Optional

    try:
        app : App = src()
    except TypeError as e:
        raise TypeError(f"an invalid argument was passed to the function: run({src})\nTypeError: {e}")

    try:
        ml.server.www = app.www
    except AttributeError:
        raise AttributeError(f"the class '{src.__name__}' must has attribute 'www'")
    if not isinstance(app.www, str):
        raise TypeError(f"the 'www' attribute, in class '{src.__name__}', must be a 'str', not a '{type(app.www).__name__}'")

    try:
        ml.server.process_request: Optional[Callable] = app.process_request
    except AttributeError:
        raise AttributeError(f"there is no 'process_request' method in the class '{src.__name__}'")
    if not isinstance(app.process_request, Optional[Callable]):
        raise TypeError(f"the 'process_request' attribute, in class '{src.__name__}', must be a '{type(Optional[Callable]).__name__}', not a '{type(app.process_request).__name__}'")
    
    try:
        ml.server.process_path: Optional[Callable] = app.process_path
    except AttributeError:
        def process_path(path : str) -> str: return None
        ml.server.process_path: Optional[Callable] = process_path
    if not isinstance(app.process_path, Optional[Callable]):
        raise TypeError(f"the 'process_path' method, in class '{src.__name__}', must be a '{type(Optional[Callable]).__name__}', not a '{type(app.process_request).__name__}'")

    try:
        ml.server.not_found = app.not_found
    except AttributeError:
        ml.server.not_found = ml.sum_paths(ml.dirname(__file__), "not-found.html")
    if not isinstance(app.not_found, str):
        raise TypeError(f"the 'not_found' attribute, in class '{src.__name__}', must be a 'str', not a '{type(app.port).__name__}'")

    try:
        port = app.port
    except AttributeError:
        port = "5000"
    if not isinstance(app.port, int):
        raise TypeError(f"the 'port' attribute, in class '{src.__name__}', must be a 'int', not a '{type(app.port).__name__}'")
    
    try:
        debug = app.debug
    except AttributeError:
        debug = False
    if not isinstance(app.debug, bool):
        raise TypeError(f"the 'debug' attribute, in class '{src.__name__}', must be a 'bool', not a '{type(app.port).__name__}'")
    
    del Callable, Optional

    ml.server.run(host="127.0.0.1", port=port, debug=debug)