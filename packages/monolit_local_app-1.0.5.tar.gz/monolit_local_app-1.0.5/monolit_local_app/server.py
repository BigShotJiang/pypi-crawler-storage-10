from flask import Flask, request, jsonify, send_file
from os.path import dirname, abspath
from monolit_local_app.other import sum_paths, split_first

class Monolit(Flask):
    from typing import Callable, Optional

    www: str = None
    process_request: Optional[Callable] = None
    process_path: Optional[Callable] = None
    not_found: str = None

    del Callable, Optional

server = Monolit(__name__, template_folder="www")

@server.route("/www/index.html")
def index(): return send_file(sum_paths(server.www, "index.html"), mimetype="text/html"), 200

@server.route("/logo.png")
def logo(): return send_file(sum_paths(dirname(__file__), "logo.png"))

@server.route("/<path:path>")
def send_anything(path: str):
    path = path.replace("\\", "/")

    export_path = server.process_path(path)
    if export_path == None:
        export_path = sum_paths(server.www, split_first(path, "/")[1])

    try:
        return send_file(export_path), 200
    except FileNotFoundError:
        return send_file(server.not_found, mimetype="text/html"), 404
    except PermissionError:
        return send_file(server.not_found, mimetype="text/html"), 404
    
@server.route("/process", methods=["POST"])
def process_json_from_client():
    if request.method == "POST":
        if request.is_json:
            try:
                return server.process_request(request)
            except Exception as e:
                print(f"[SERVER] Can not process JSON: {e}")
                return jsonify({"error": "Can not process JSON"}), 400
        else:
            print(f"[SERVER] Request must be in JSON format")
            return jsonify({"error": "Request must be in JSON format"}), 415
    else:
        print(f"[SERVER] Method not support")
        return jsonify({"error": "Method not support"}), 405