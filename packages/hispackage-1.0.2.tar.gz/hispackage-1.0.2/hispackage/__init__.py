print('i am saimon islam tarek')


import first_module
import second_variable
import third_module






