Tutorials
=========
This section contains various tutorials showcasing use cases for automatic cell type labeling with :mod:`cell_annotator`.

.. toctree::
    :maxdepth: 1
    :glob:

    *
