```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 2

api.md
changelog.md
contributing.md
references.md

notebooks/tutorials/index
```
