from pathlib import Path

TEMPLATES = Path(__file__).parent.parent / "templates"
