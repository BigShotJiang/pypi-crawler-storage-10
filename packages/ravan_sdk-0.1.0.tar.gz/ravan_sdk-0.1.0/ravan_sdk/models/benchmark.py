import json
import subprocess
from pathlib import Path
from typing import Any, Dict


class BenchmarkSuite:
    def __init__(self, client: "RavanClient"):
        self.client = client

    def run(self) -> Dict[str, Any]:
        results_path = Path("benchmark_results.json")
        try:
            subprocess.run(["python", "run_benchmarks.py"], check=True)
            if results_path.exists():
                return json.loads(results_path.read_text(encoding="utf-8"))
        except Exception:
            pass
        return {}


