from typing import Any, Dict, List
import numpy as np
import requests


class SurrogateModel:
    def __init__(self, client: "RavanClient"):
        self.client = client

    def predict(self, params: Dict[str, float] | List[float] | np.ndarray) -> Dict[str, Any]:
        return self.client.predict(params)


