import matplotlib.pyplot as plt


def plot_performance(results: dict):
    success_rate = results.get("success_rate") or results.get("inverse_design", {}).get("success_rate")
    mean_error = results.get("mean_error") or results.get("inverse_design", {}).get("mean_error")

    labels = []
    values = []
    if success_rate is not None:
        labels.append("Success Rate")
        values.append(success_rate)
    if mean_error is not None:
        labels.append("Mean Error")
        values.append(mean_error)

    if not labels:
        raise ValueError("No plottable keys in results")

    plt.figure(figsize=(6, 4))
    plt.bar(labels, values, color=["#1f77b4", "#ff7f0e"]) 
    plt.title("Ravan Benchmark Results")
    plt.tight_layout()
    plt.show()


