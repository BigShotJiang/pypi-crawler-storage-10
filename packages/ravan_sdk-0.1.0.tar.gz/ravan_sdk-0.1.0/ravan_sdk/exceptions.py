class RavanSDKError(Exception):
    pass


class APIUnavailableError(RavanSDKError):
    pass


class APIRequestError(RavanSDKError):
    pass


class LocalModelNotAvailable(RavanSDKError):
    pass


class InverseDesignError(RavanSDKError):
    pass


