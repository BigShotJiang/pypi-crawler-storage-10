from nonebot.plugin.on import CommandGroup

command = CommandGroup(("lp"), priority=10, block=True, prefix_aliases=True)
