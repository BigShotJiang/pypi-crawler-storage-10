__version__: str = "0.5.0"
package_name: str = "kataloger"
