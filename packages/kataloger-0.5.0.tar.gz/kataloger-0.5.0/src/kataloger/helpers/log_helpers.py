def log_warning(message: str) -> None:
    print(f"W: {message}")
