import subprocess
import time
import os

def get_ros_version():
    ros_releases = {
        "jammy": "humble",
        "noble": "jazzy"
    }
    _, codename = get_version_and_codename()

    return ros_releases.get(codename)

def get_version_and_codename():
    version = None
    codename = None
    try:
        with open("/etc/os-release") as f:
            for line in f:
                if line.startswith("VERSION_ID="):
                    version = line.strip().split('=')[1].strip('"')
                elif line.startswith("UBUNTU_CODENAME="):
                    codename = line.strip().split('=')[1]
                elif line.startswith("VERSION_CODENAME="):
                    codename = line.strip().split('=')[1]
        return version, codename
    except Exception as e:
        print(f"Error reading OS version and codename: {e}")
        return None, None

def update():
    subprocess.run("sudo apt update", shell=True)

def upgrade():
    subprocess.run("sudo apt upgrade", shell=True)

def get_shell():
    return os.environ.get("SHELL")


def get_active_shell():
    ppid = os.getppid()  # Get parent process ID
    shell_path = None
    try:
        # Read the executable path of the parent process
        shell_path = os.readlink(f'/proc/{ppid}/exe')
    except Exception as e:
        print(f"Could not determine shell executable: {e}")
    return shell_path









def print_big_heart():

    t = """
        I might not be expressive or talkative, might be too stressful and negative\n 
        I might be too dark\n
        and a lot of other things...\n\n
        But among all those "maybes", the thing that is certain is that I love you\n
    """

    print(t)

    for _ in range(40):
            print("<3 ", end="", flush=True)
            time.sleep(0.7)

    print("\nclick anything to say I love you too...")
    input()

    os.system('cls' if os.name == 'nt' else 'clear')

    heart_s_heart = """
   ***       ***           ***********        ***       ***
 *******   *******        *************     *******   *******
********* *********      ****     ****    ********* *********
*********************    ****            *********************
*********************     ***********    *********************
 *******************       ***********    *******************
   ***************                *****     ***************
     ***********          ****     *****      ***********
       *******             *************        *******
         ***                ***********           ***
          *                                        *
    """
    print(heart_s_heart)

