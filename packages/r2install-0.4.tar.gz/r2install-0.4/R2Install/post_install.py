import os

from .utils import get_ros_version

def post_install():

    ros_version = get_ros_version()
        
    home = os.path.expanduser("~")
    files_and_lines = {
        f".bashrc": f"source /opt/ros/{ros_version}/setup.bash",
        f".bash_profile": f"source /opt/ros/{ros_version}/setup.bash",
        f".zshrc": f"source /opt/ros/{ros_version}/setup.zsh",
        f".profile": f"source /opt/ros/{ros_version}/setup.sh",
    }

    for filename, line in files_and_lines.items():
        full_path = os.path.join(home, filename)
        append_if_missing(full_path, line)
    print("#################### ALL SET ####################")
    print()
        
            

def append_if_missing(file_path, line):
    if os.path.exists(file_path):
        with open(file_path) as f:
            if line not in f.read():
                with open(file_path, "a") as fa:
                    print("#################### "+line+" ####################")
                    fa.write(f"\n{line}\n")

            print("#################### "+file_path+" Updated ####################")
        
        
            

