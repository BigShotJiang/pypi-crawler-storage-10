import subprocess
from .utils import get_ros_version, update, upgrade

def install():
    

    ros_version = get_ros_version()

    commands = {
                    f"installing ros {ros_version} desktop": f"sudo apt install ros-{ros_version}-desktop",
                    f"installing ros {ros_version} base": f"sudo apt install ros-{ros_version}-ros-base",
                }
    


    print()
    print("#################### Updating ####################")
    print()
    update()

    print()
    print("#################### Upgrading ####################")
    print()
    upgrade()

    for description, cmd in commands.items():
        try:
            print()
            print("#################### "+description+" ####################")
            print("#################### "+cmd+" ####################")
            print()
            subprocess.run(cmd, shell=True, check=True)

        except FileNotFoundError as invalid_command:
            raise Exception(str(invalid_command))
            
        except subprocess.CalledProcessError as failed:
            raise Exception( str(failed))


        except Exception as e:
            raise Exception(str(e))

            
        print()
        print("#################### DONE ####################")
        print()

          
        