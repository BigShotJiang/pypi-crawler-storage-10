"""
Unified task bus with in-memory fallback.

Redis backend can be added later; default is in-process asyncio queues.
"""

from __future__ import annotations

import asyncio
import uuid
from collections import defaultdict
from typing import Dict, Any


class InMemoryBus:
    def __init__(self):
        self.queues: Dict[str, asyncio.Queue] = defaultdict(asyncio.Queue)

    async def publish(self, agent_name: str, payload: dict) -> str:
        task_id = str(uuid.uuid4())
        await self.queues[agent_name].put({"task_id": task_id, "payload": payload})
        return task_id

    async def consume(self, agent_name: str) -> Dict[str, Any]:
        return await self.queues[agent_name].get()

    async def list_agents(self):
        return list(self.queues.keys())


# Placeholder for future Redis implementation
class RedisBus:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("RedisBus is not implemented yet")
