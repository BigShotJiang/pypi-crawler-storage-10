StarRail_version = "3.6.0"
