from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README.md if available
this_directory = Path(__file__).parent
long_description = ""
readme_path = this_directory / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text()

setup(
    name="coeaidpml",
    version="4.0.0",
    description="LLM-powered schema analyzer and ML use case discovery engine for OCI AIDP",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Nikesh Gogia",
    author_email="you@example.com",  # optional but helpful
    url="https://pypi.org/project/coe-aidp-ml-discovery/",  # or your GitHub
    packages=find_packages(),
    license="MIT",  # or "Proprietary"
    install_requires=[],
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Intended Audience :: Developers",
    ],
    keywords="oci aidp pyspark llm schema discovery data ai ml",
)
