"""
Unit tests for Coastal Wave Transport Model

This package contains comprehensive tests for all modules to ensure
correctness and verify that all original functionality is preserved.
"""

