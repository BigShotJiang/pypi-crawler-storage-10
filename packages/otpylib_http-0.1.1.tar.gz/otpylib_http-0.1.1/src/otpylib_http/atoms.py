"""
otpylib_http.atoms

Domain-specific atoms for the HTTP server system.
Covers acceptor, connection lifecycle, routing, and protocol states.
"""

from otpylib import atom

# =============================================================================
# Acceptor Atoms
# =============================================================================

# Acceptor commands
ACCEPT = atom.ensure('accept')
LISTEN = atom.ensure('listen')
STOP_ACCEPTING = atom.ensure('stop_accepting')

# Acceptor events
CONNECTION_ACCEPTED = atom.ensure('connection_accepted')
ACCEPT_ERROR = atom.ensure('accept_error')


# =============================================================================
# Connection Lifecycle Atoms
# =============================================================================

# Connection states (for gen_statem)
AWAITING_REQUEST = atom.ensure('awaiting_request')
READING_HEADERS = atom.ensure('reading_headers')
READING_BODY = atom.ensure('reading_body')
DISPATCHING = atom.ensure('dispatching')
SENDING_RESPONSE = atom.ensure('sending_response')
KEEP_ALIVE = atom.ensure('keep_alive')
CLOSING = atom.ensure('closing')
UPGRADING = atom.ensure('upgrading')  # For WebSocket upgrade

# Connection events
READ_DATA = atom.ensure('read_data')
PARSE_REQUEST = atom.ensure('parse_request')
DISPATCH_REQUEST = atom.ensure('dispatch_request')
SEND_RESPONSE = atom.ensure('send_response')
CLOSE_CONNECTION = atom.ensure('close_connection')
CONNECTION_TIMEOUT = atom.ensure('connection_timeout')
SOCKET_CLOSED = atom.ensure('socket_closed')
SOCKET_ERROR = atom.ensure('socket_error')


# =============================================================================
# HTTP Protocol Atoms
# =============================================================================

# HTTP Methods
GET = atom.ensure('GET')
POST = atom.ensure('POST')
PUT = atom.ensure('PUT')
DELETE = atom.ensure('DELETE')
PATCH = atom.ensure('PATCH')
HEAD = atom.ensure('HEAD')
OPTIONS = atom.ensure('OPTIONS')
TRACE = atom.ensure('TRACE')
CONNECT = atom.ensure('CONNECT')

# HTTP Versions
HTTP_1_0 = atom.ensure('HTTP/1.0')
HTTP_1_1 = atom.ensure('HTTP/1.1')
HTTP_2_0 = atom.ensure('HTTP/2.0')

# Common Status Codes (as atoms for pattern matching)
STATUS_200 = atom.ensure('200')
STATUS_201 = atom.ensure('201')
STATUS_204 = atom.ensure('204')
STATUS_301 = atom.ensure('301')
STATUS_302 = atom.ensure('302')
STATUS_304 = atom.ensure('304')
STATUS_400 = atom.ensure('400')
STATUS_401 = atom.ensure('401')
STATUS_403 = atom.ensure('403')
STATUS_404 = atom.ensure('404')
STATUS_405 = atom.ensure('405')
STATUS_408 = atom.ensure('408')
STATUS_500 = atom.ensure('500')
STATUS_502 = atom.ensure('502')
STATUS_503 = atom.ensure('503')
STATUS_504 = atom.ensure('504')


# =============================================================================
# Router Atoms
# =============================================================================

# Router operations
LOOKUP = atom.ensure('lookup')
ADD_ROUTE = atom.ensure('add_route')
REMOVE_ROUTE = atom.ensure('remove_route')
LIST_ROUTES = atom.ensure('list_routes')
MATCH = atom.ensure('match')

# Route matching results
ROUTE_FOUND = atom.ensure('route_found')
ROUTE_NOT_FOUND = atom.ensure('route_not_found')
ROUTE_EXISTS = atom.ensure('route_exists')

# Route types
STATIC_ROUTE = atom.ensure('static')
DYNAMIC_ROUTE = atom.ensure('dynamic')
WILDCARD_ROUTE = atom.ensure('wildcard')


# =============================================================================
# Handler Atoms
# =============================================================================

# Handler lifecycle
HANDLER_INIT = atom.ensure('handler_init')
HANDLER_HANDLE = atom.ensure('handler_handle')
HANDLER_TERMINATE = atom.ensure('handler_terminate')
HANDLER_ERROR = atom.ensure('handler_error')

# Handler results
HANDLER_OK = atom.ensure('handler_ok')
HANDLER_CRASH = atom.ensure('handler_crash')
HANDLER_TIMEOUT = atom.ensure('handler_timeout')


# =============================================================================
# Request/Response Atoms
# =============================================================================

# Request parts
REQUEST_LINE = atom.ensure('request_line')
HEADERS = atom.ensure('headers')
BODY = atom.ensure('body')
PARAMS = atom.ensure('params')
QUERY = atom.ensure('query')
PATH = atom.ensure('path')
METHOD = atom.ensure('method')
VERSION = atom.ensure('version')

# Response parts
STATUS = atom.ensure('status')
STATUS_TEXT = atom.ensure('status_text')
RESPONSE_HEADERS = atom.ensure('response_headers')
RESPONSE_BODY = atom.ensure('response_body')

# Content types (for pattern matching)
TEXT_PLAIN = atom.ensure('text/plain')
TEXT_HTML = atom.ensure('text/html')
APPLICATION_JSON = atom.ensure('application/json')
APPLICATION_XML = atom.ensure('application/xml')
APPLICATION_OCTET_STREAM = atom.ensure('application/octet-stream')
MULTIPART_FORM_DATA = atom.ensure('multipart/form-data')
APPLICATION_FORM_URLENCODED = atom.ensure('application/x-www-form-urlencoded')


# =============================================================================
# Error Atoms
# =============================================================================

# Parse errors
PARSE_ERROR = atom.ensure('parse_error')
INVALID_REQUEST = atom.ensure('invalid_request')
INVALID_METHOD = atom.ensure('invalid_method')
INVALID_PATH = atom.ensure('invalid_path')
INVALID_VERSION = atom.ensure('invalid_version')
INVALID_HEADERS = atom.ensure('invalid_headers')
BODY_TOO_LARGE = atom.ensure('body_too_large')

# Connection errors
CONNECTION_ERROR = atom.ensure('connection_error')
TIMEOUT = atom.ensure('timeout')
CLOSED = atom.ensure('closed')
RESET = atom.ensure('reset')

# Handler errors
HANDLER_NOT_FOUND = atom.ensure('handler_not_found')
HANDLER_EXCEPTION = atom.ensure('handler_exception')
INTERNAL_ERROR = atom.ensure('internal_error')


# =============================================================================
# Configuration Atoms
# =============================================================================

# Server config
HOST = atom.ensure('host')
PORT = atom.ensure('port')
BACKLOG = atom.ensure('backlog')
MAX_HEADERS_SIZE = atom.ensure('max_headers_size')
MAX_BODY_SIZE = atom.ensure('max_body_size')
REQUEST_TIMEOUT = atom.ensure('request_timeout')
KEEP_ALIVE_TIMEOUT = atom.ensure('keep_alive_timeout')

# TLS/SSL config
TLS = atom.ensure('tls')
CERTFILE = atom.ensure('certfile')
KEYFILE = atom.ensure('keyfile')


# =============================================================================
# Streaming/WebSocket Atoms (Future)
# =============================================================================

# Streaming
CHUNK = atom.ensure('chunk')
STREAM_START = atom.ensure('stream_start')
STREAM_DATA = atom.ensure('stream_data')
STREAM_END = atom.ensure('stream_end')

# WebSocket
WS_HANDSHAKE = atom.ensure('ws_handshake')
WS_FRAME = atom.ensure('ws_frame')
WS_TEXT = atom.ensure('ws_text')
WS_BINARY = atom.ensure('ws_binary')
WS_PING = atom.ensure('ws_ping')
WS_PONG = atom.ensure('ws_pong')
WS_CLOSE = atom.ensure('ws_close')


# =============================================================================
# Common Response Atoms
# =============================================================================

OK = atom.ensure('ok')
ERROR = atom.ensure('error')
CONTINUE = atom.ensure('continue')
NOREPLY = atom.ensure('noreply')
STOP = atom.ensure('stop')
