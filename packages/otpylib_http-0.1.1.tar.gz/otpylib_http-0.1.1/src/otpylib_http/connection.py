"""
otpylib_http.connection

HTTP Connection State Machine (gen_statem) - handles the lifecycle of a single
HTTP connection from request parsing through response sending.

Uses active mode TCP to receive data as messages in the mailbox.
"""

from typing import Any, Dict, Optional

from otpylib import process
from otpylib.module import OTPModule, GEN_STATEM
from otpylib.gen_statem import (
    CallbackMode,
    EventType,
    NextState,
    KeepState,
    StopState,
    ReplyAction,
    StateTimeoutAction,
)
from otpylib.inet import close, send, setopts, controlling_process, Socket, SocketOptions
from otpylib.inet.atoms import TCP_MSG, TCP_CLOSED, TCP_ERROR
from otpylib import gen_server

from otpylib_http.atoms import (
    AWAITING_REQUEST, READING_HEADERS, READING_BODY, DISPATCHING, SENDING_RESPONSE,
    OK, ERROR,
)


# =============================================================================
# HTTP Connection State Machine
# =============================================================================

class HttpConnection(metaclass=OTPModule, behavior=GEN_STATEM, version="1.0.0"):
    """
    HTTP Connection State Machine.
    
    Manages a single HTTP/1.1 connection through its lifecycle:
    - awaiting_request: Waiting for initial request line
    - reading_headers: Reading HTTP headers
    - reading_body: Reading request body (if present)
    - dispatching: Routing to handler and executing
    - sending_response: Sending HTTP response
    
    Uses active mode TCP - data arrives as TCP_MSG in mailbox.
    
    State data:
        {
            'socket': Socket,
            'router_pid': PID,
            'buffer': bytes (accumulated data),
            'request': dict (parsed request),
            'response': dict (handler response),
            'request_timeout': float
        }
    """
    
    async def callback_mode(self):
        """Use state-specific callback functions."""
        print(f"[HttpConnection] callback_mode() called")
        return CallbackMode.STATE_FUNCTIONS
    
    async def init(self, config: Dict[str, Any]):
        """Initialize connection state machine."""
        try:
            socket = config['socket']
            router_pid = config['router_pid']
            request_timeout = config.get('request_timeout', 30.0)

            peer = socket.peer
            print(f"[HttpConnection] New connection from {peer.host}:{peer.port}")

            # Set socket to active mode - data will arrive as TCP_MSG
            print(f"[HttpConnection] Setting socket to active mode...")
            socket_opts = SocketOptions(
                active=True,
                binary=True,
                buffer_size=8192
            )
            await setopts(socket, socket_opts)
            print(f"[HttpConnection] Active mode set")

            # Transfer socket control to this process
            print(f"[HttpConnection] Transferring socket control to {process.self()}")
            await controlling_process(socket, process.self())
            print(f"[HttpConnection] Socket control transferred")

            # Initial state data
            state_data = {
                'socket': socket,
                'router_pid': router_pid,
                'buffer': b'',
                'request': None,
                'response': None,
                'request_timeout': request_timeout,
            }

            print(f"[HttpConnection] Init complete, returning AWAITING_REQUEST")

            # Return state name and data
            return AWAITING_REQUEST, state_data

        except Exception as e:
            print(f"[HttpConnection] INIT FAILED: {e}")
            import traceback
            traceback.print_exc()
            raise
    
    # ========================================================================
    # State: awaiting_request
    # ========================================================================
    
    async def state_reading_headers(self, event_type: EventType, event_content, data: dict):
        """
        Reading HTTP headers.

        Looking for headers ending with \r\n\r\n
        """
        print(f"[HttpConnection/reading_headers] event_type={event_type}, buffer_len={len(data['buffer'])}")

        match event_type:
            case EventType.INFO:
                match event_content:
                    case (tcp_msg, socket, received_data) if tcp_msg == TCP_MSG:
                        print(f"[HttpConnection/reading_headers] Received {len(received_data)} bytes")
                        data['buffer'] += received_data

                        # Check for end of headers
                        if b'\r\n\r\n' in data['buffer']:
                            headers_block, body_start = data['buffer'].split(b'\r\n\r\n', 1)

                            # Parse headers
                            header_lines = headers_block.split(b'\r\n')
                            for line in header_lines:
                                if b':' in line:
                                    key, value = line.split(b':', 1)
                                    data['request']['headers'][key.decode('utf-8').strip()] = \
                                        value.decode('utf-8').strip()

                            data['buffer'] = body_start

                            print(f"[HttpConnection/reading_headers] Parsed {len(data['request']['headers'])} headers")

                            # Check if there's a body
                            content_length = data['request']['headers'].get('Content-Length')

                            if content_length:
                                # Has body, move to reading_body
                                data['request']['body'] = b''
                                data['request']['content_length'] = int(content_length)

                                return NextState(
                                    state_name=READING_BODY,
                                    state_data=data,
                                    actions=[StateTimeoutAction(
                                        timeout=data['request_timeout'],
                                        event_content='request_timeout'
                                    )]
                                )
                            else:
                                # No body, dispatch immediately
                                print(f"[HttpConnection/reading_headers] No body, moving to dispatch")
                                return NextState(
                                    state_name=DISPATCHING,
                                    state_data=data
                                )

                        # Need more data
                        return KeepState(state_data=data)

                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        return StopState(reason='normal', state_data=data)

                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        return StopState(reason='socket_error', state_data=data)

            case EventType.ENTER:
                # CRITICAL: Check buffer immediately when entering this state!
                # The headers might already be in the buffer from the previous read
                print(f"[HttpConnection/reading_headers] ENTER event, checking buffer...")

                if b'\r\n\r\n' in data['buffer']:
                    print(f"[HttpConnection/reading_headers] Headers already in buffer!")
                    headers_block, body_start = data['buffer'].split(b'\r\n\r\n', 1)

                    # Parse headers
                    header_lines = headers_block.split(b'\r\n')
                    for line in header_lines:
                        if b':' in line:
                            key, value = line.split(b':', 1)
                            data['request']['headers'][key.decode('utf-8').strip()] = \
                                value.decode('utf-8').strip()

                    data['buffer'] = body_start

                    print(f"[HttpConnection/reading_headers] Parsed {len(data['request']['headers'])} headers")

                    # Check if there's a body
                    content_length = data['request']['headers'].get('Content-Length')

                    if content_length:
                        data['request']['body'] = b''
                        data['request']['content_length'] = int(content_length)

                        return NextState(
                            state_name=READING_BODY,
                            state_data=data,
                            actions=[StateTimeoutAction(
                                timeout=data['request_timeout'],
                                event_content='request_timeout'
                            )]
                        )
                    else:
                        print(f"[HttpConnection/reading_headers] No body, moving to dispatch")
                        return NextState(
                            state_name=DISPATCHING,
                            state_data=data
                        )

                # Buffer doesn't have complete headers yet, wait for TCP_MSG
                return KeepState(state_data=data)

            case EventType.STATE_TIMEOUT:
                if event_content == 'request_timeout':
                    return await self._send_error(408, b'Request Timeout', data)

        return KeepState(state_data=data)

    # ========================================================================
    # State: awaiting_request
    # ========================================================================

    async def state_awaiting_request(self, event_type: EventType, event_content, data: dict):
        """Waiting for HTTP request line."""
        print(f"[HttpConnection/awaiting_request] event_type={event_type}")

        match event_type:
            case EventType.INFO:
                match event_content:
                    case (tcp_msg, socket, received_data) if tcp_msg == TCP_MSG:
                        # Received data from socket
                        data['buffer'] += received_data
                        print(f"[HttpConnection/awaiting_request] Buffer now has {len(data['buffer'])} bytes")

                        # Try to parse request line
                        if b'\r\n' in data['buffer']:
                            # Found end of request line
                            line, rest = data['buffer'].split(b'\r\n', 1)

                            try:
                                # Parse: "GET /path HTTP/1.1"
                                parts = line.decode('utf-8').split(' ')
                                if len(parts) != 3:
                                    return await self._send_error(400, b'Bad Request', data)

                                method, path, version = parts

                                # Initialize request
                                data['request'] = {
                                    'method': method,
                                    'path': path,
                                    'version': version,
                                    'headers': {},
                                    'body': b''
                                }
                                data['buffer'] = rest

                                print(f"[HttpConnection] {method} {path} {version}")
                                print(f"[HttpConnection] Remaining buffer: {len(rest)} bytes")

                                # Move to reading headers and trigger immediate buffer check
                                from otpylib.gen_statem import NextEventAction
                                return NextState(
                                    state_name=READING_HEADERS,
                                    state_data=data,
                                    actions=[NextEventAction(EventType.INTERNAL, 'check_buffer')]
                                )

                            except Exception as e:
                                print(f"[HttpConnection] Parse error: {e}")
                                return await self._send_error(400, b'Bad Request', data)

                        # Need more data
                        return KeepState(state_data=data)

                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        print(f"[HttpConnection] Connection closed by peer")
                        return StopState(reason='normal', state_data=data)

                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        print(f"[HttpConnection] Socket error: {error}")
                        return StopState(reason='socket_error', state_data=data)

            case EventType.STATE_TIMEOUT:
                if event_content == 'request_timeout':
                    print(f"[HttpConnection] Request timeout")
                    return await self._send_error(408, b'Request Timeout', data)

        return KeepState(state_data=data)


    # ========================================================================
    # State: reading_headers  
    # ========================================================================


    async def state_reading_headers(self, event_type: EventType, event_content, data: dict):
        """Reading HTTP headers."""
        print(f"[HttpConnection/reading_headers] event_type={event_type}, buffer_len={len(data['buffer'])}")

        # Helper to parse headers
        def try_parse_headers():
            if b'\r\n\r\n' not in data['buffer']:
                return None

            print(f"[HttpConnection/reading_headers] Found complete headers!")
            headers_block, body_start = data['buffer'].split(b'\r\n\r\n', 1)

            # Parse headers
            header_lines = headers_block.split(b'\r\n')
            for line in header_lines:
                if b':' in line:
                    key, value = line.split(b':', 1)
                    data['request']['headers'][key.decode('utf-8').strip()] = \
                        value.decode('utf-8').strip()

            data['buffer'] = body_start
            print(f"[HttpConnection/reading_headers] Parsed {len(data['request']['headers'])} headers")

            # Check for body
            content_length = data['request']['headers'].get('Content-Length')

            if content_length:
                data['request']['body'] = b''
                data['request']['content_length'] = int(content_length)
                return NextState(state_name=READING_BODY, state_data=data)
            else:
                print(f"[HttpConnection/reading_headers] No body, dispatching")
                # Trigger dispatch with INTERNAL event
                from otpylib.gen_statem import NextEventAction
                return NextState(
                    state_name=DISPATCHING,
                    state_data=data,
                    actions=[NextEventAction(EventType.INTERNAL, 'dispatch')]
                )

        match event_type:
            case EventType.INTERNAL:
                # Triggered immediately after entering this state
                if event_content == 'check_buffer':
                    print(f"[HttpConnection/reading_headers] INTERNAL check_buffer")
                    result = try_parse_headers()
                    if result:
                        return result
                    # Headers not complete, wait for TCP_MSG
                    return KeepState(state_data=data)

            case EventType.INFO:
                match event_content:
                    case (tcp_msg, socket, received_data) if tcp_msg == TCP_MSG:
                        print(f"[HttpConnection/reading_headers] Received {len(received_data)} bytes")
                        data['buffer'] += received_data

                        result = try_parse_headers()
                        if result:
                            return result

                        # Need more data
                        return KeepState(state_data=data)

                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        return StopState(reason='normal', state_data=data)

                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        return StopState(reason='socket_error', state_data=data)

            case EventType.STATE_TIMEOUT:
                if event_content == 'request_timeout':
                    return await self._send_error(408, b'Request Timeout', data)

        return KeepState(state_data=data)


    
    # ========================================================================
    # State: reading_body
    # ========================================================================
    
    async def state_reading_body(self, event_type: EventType, event_content, data: dict):
        """
        Reading HTTP request body.
        """
        match event_type:
            case EventType.INFO:
                match event_content:
                    case (tcp_msg, socket, received_data) if tcp_msg == TCP_MSG:
                        data['buffer'] += received_data
                        
                        content_length = data['request']['content_length']
                        
                        # Check if we have enough data
                        if len(data['buffer']) >= content_length:
                            # Body complete
                            data['request']['body'] = data['buffer'][:content_length]
                            data['buffer'] = data['buffer'][content_length:]
                            
                            # Move to dispatching
                            return NextState(
                                state_name=DISPATCHING,
                                state_data=data
                            )
                        
                        # Need more data
                        return KeepState(state_data=data)
                    
                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        return StopState(reason='normal', state_data=data)
                    
                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        return StopState(reason='socket_error', state_data=data)
            
            case EventType.STATE_TIMEOUT:
                if event_content == 'request_timeout':
                    return await self._send_error(408, b'Request Timeout', data)
        
        return KeepState(state_data=data)
    
    # ========================================================================
    # State: dispatching
    # ========================================================================

    async def state_dispatching(self, event_type: EventType, event_content, data: dict):
        """
        Route request to handler and execute.
        
        This state executes immediately when entered via INTERNAL event.
        """
        print(f"[HttpConnection/dispatching] event_type={event_type}, event_content={event_content}")
        
        # Only dispatch on INTERNAL event (triggered when entering state)
        # Ignore other events while dispatching is in progress
        match event_type:
            case EventType.INTERNAL:
                if event_content == 'dispatch':
                    try:
                        # Strip query string for routing (but keep full path in request)
                        full_path = data['request']['path']
                        route_path = full_path.split('?')[0] if '?' in full_path else full_path
                        
                        print(f"[HttpConnection] Dispatching: route_path={route_path}, full_path={full_path}")
    
                        # Look up handler from router using path without query string
                        result = await gen_server.call(
                            data['router_pid'],
                            ('lookup', route_path)
                        )
    
                        print(f"[HttpConnection] Router returned: {result}")
    
                        if result[0] == OK:
                            handler_class = result[1]
    
                            print(f"[HttpConnection] Instantiating handler: {handler_class.__name__}")
    
                            # Instantiate handler (plain module!)
                            handler = handler_class()
    
                            print(f"[HttpConnection] Calling handler.handle()")
    
                            # Call handler with full request (including query string in path)
                            response = await handler.handle(data['request'])
    
                            print(f"[HttpConnection] Handler returned: status={response.get('status')}")
    
                            data['response'] = response
    
                            # Move to sending response (also needs INTERNAL trigger)
                            from otpylib.gen_statem import NextEventAction
                            return NextState(
                                state_name=SENDING_RESPONSE,
                                state_data=data,
                                actions=[NextEventAction(EventType.INTERNAL, 'send')]
                            )
                        else:
                            print(f"[HttpConnection] Route not found: {route_path}")
                            # 404 Not Found
                            return await self._send_error(404, b'Not Found', data)
    
                    except Exception as e:
                        print(f"[HttpConnection] Handler error: {e}")
                        import traceback
                        traceback.print_exc()
                        return await self._send_error(500, b'Internal Server Error', data)
            
            case EventType.INFO:
                # Ignore TCP messages while dispatching
                match event_content:
                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        return StopState(reason='normal', state_data=data)
                    
                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        return StopState(reason='socket_error', state_data=data)
                    
                    case _:
                        # Ignore other messages
                        return KeepState(state_data=data)
            
            case _:
                # Ignore other event types
                return KeepState(state_data=data)
        
        return KeepState(state_data=data)

    # ========================================================================
    # State: sending_response
    # ========================================================================
    
    async def state_sending_response(self, event_type: EventType, event_content, data: dict):
        """
        Send HTTP response to client.

        This state runs immediately when triggered by INTERNAL event.
        """
        print(f"[HttpConnection/sending_response] event_type={event_type}")

        match event_type:
            case EventType.INTERNAL:
                if event_content == 'send':
                    try:
                        response = data['response']

                        # Build HTTP response
                        status = response.get('status', 200)
                        headers = response.get('headers', {})
                        body = response.get('body', b'')

                        # Status line
                        status_text = self._status_text(status)
                        response_lines = [
                            f"HTTP/1.1 {status} {status_text}".encode('utf-8')
                        ]

                        # Default headers
                        if 'Content-Length' not in headers:
                            headers['Content-Length'] = str(len(body))
                        if 'Content-Type' not in headers:
                            headers['Content-Type'] = 'text/plain'

                        # Add headers
                        for key, value in headers.items():
                            response_lines.append(f"{key}: {value}".encode('utf-8'))

                        # Empty line before body
                        response_lines.append(b'')

                        # Join with \r\n
                        response_bytes = b'\r\n'.join(response_lines) + b'\r\n' + body

                        # Send response
                        await send(data['socket'], response_bytes)

                        print(f"[HttpConnection] Sent {status} response ({len(body)} bytes)")

                        # Check for keep-alive
                        connection_header = data['request']['headers'].get('Connection', '').lower()

                        if connection_header == 'keep-alive':
                            # Reset for next request
                            data['buffer'] = b''
                            data['request'] = None
                            data['response'] = None

                            return NextState(
                                state_name=AWAITING_REQUEST,
                                state_data=data,
                                actions=[StateTimeoutAction(
                                    timeout=data['request_timeout'],
                                    event_content='request_timeout'
                                )]
                            )
                        else:
                            # Close connection
                            return StopState(reason='normal', state_data=data)

                    except Exception as e:
                        print(f"[HttpConnection] Send error: {e}")
                        return StopState(reason='send_error', state_data=data)

            case EventType.INFO:
                # Ignore TCP messages while sending
                match event_content:
                    case (tcp_closed, socket) if tcp_closed == TCP_CLOSED:
                        return StopState(reason='normal', state_data=data)

                    case (tcp_error, socket, error) if tcp_error == TCP_ERROR:
                        return StopState(reason='socket_error', state_data=data)

                    case _:
                        return KeepState(state_data=data)

            case _:
                return KeepState(state_data=data)

        return KeepState(state_data=data)
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    async def _send_error(self, status: int, message: bytes, data: dict):
        """Send error response and close connection."""
        try:
            status_text = self._status_text(status)
            response = (
                f"HTTP/1.1 {status} {status_text}\r\n"
                f"Content-Type: text/plain\r\n"
                f"Content-Length: {len(message)}\r\n"
                f"Connection: close\r\n"
                f"\r\n"
            ).encode('utf-8') + message
            
            await send(data['socket'], response)
        except:
            pass
        
        return StopState(reason='error_sent', state_data=data)
    
    def _status_text(self, status: int) -> str:
        """Get status text for status code."""
        status_texts = {
            200: 'OK',
            201: 'Created',
            204: 'No Content',
            400: 'Bad Request',
            404: 'Not Found',
            408: 'Request Timeout',
            500: 'Internal Server Error',
        }
        return status_texts.get(status, 'Unknown')
    
    # ========================================================================
    # Cleanup
    # ========================================================================
    
    async def terminate(self, reason, state_name, state_data):
        """Cleanup on termination."""
        print(f"[HttpConnection] Terminating: {reason}")
        
        try:
            await close(state_data['socket'])
        except:
            pass
