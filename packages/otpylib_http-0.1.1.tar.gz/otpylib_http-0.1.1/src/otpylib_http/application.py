"""
otpylib_http.application

HTTP Application - top-level supervision tree for the HTTP server.

Starts and supervises:
- Router (gen_server)
- Connection Supervisor (DynamicSupervisor)
- Acceptor (gen_server)
"""

from typing import List, Tuple, Dict, Any

from otpylib import process, supervisor, dynamic_supervisor
from otpylib.module import OTPModule, APPLICATION, SUPERVISOR, DYNAMIC_SUPERVISOR
from otpylib.supervisor import child_spec, options, ONE_FOR_ALL
from otpylib.dynamic_supervisor import child_spec as dyn_child_spec, options as dyn_options, ONE_FOR_ONE, PERMANENT

from otpylib_http.router import HttpRouter
from otpylib_http.acceptor import HttpAcceptor


# =============================================================================
# Connection Supervisor Module
# =============================================================================

class ConnectionSupervisor(metaclass=OTPModule, behavior=DYNAMIC_SUPERVISOR, version="1.0.0"):
    """
    Dynamic supervisor for HTTP connection handlers.
    
    Spawns ConnectionHandler processes as connections are accepted.
    """
    
    async def init(self, args):
        """Initialize with no static children - connections added dynamically."""
        print("[ConnectionSupervisor] Initializing connection supervisor")
        
        children = []  # No initial children
        
        opts = dyn_options(
            strategy=ONE_FOR_ONE,
            max_restarts=10,
            max_seconds=5
        )
        
        return (children, opts)
    
    async def terminate(self, reason, state):
        """Called when supervisor terminates."""
        print(f"[ConnectionSupervisor] Terminating: {reason}")


# =============================================================================
# HTTP Supervisor Module
# =============================================================================

class HttpSupervisor(metaclass=OTPModule, behavior=SUPERVISOR, version="1.0.0"):
    """
    Main HTTP supervisor.
    
    Supervises:
    - Router (gen_server)
    - ConnectionSupervisor (dynamic_supervisor)
    - Acceptor (gen_server)
    """
    
    async def init(self, args: Dict[str, Any]):
        """Initialize HTTP supervisor with children."""
        port = args.get('port', 8080)
        routes = args.get('routes', [])
        accept_timeout = args.get('accept_timeout', 5.0)
        request_timeout = args.get('request_timeout', 30.0)
        
        print(f"[HttpSupervisor] Starting HTTP server on port {port}")
        print(f"[HttpSupervisor] Routes: {len(routes)}")
        
        # Build child specs
        children = [
            # 1. Router - started first
            child_spec(
                id='http_router',
                module=HttpRouter,
                args=routes,
                restart='permanent',
                name='http_router'
            ),
            
            # 2. Connection Supervisor - manages connection handlers
            child_spec(
                id='http_conn_sup',
                module=ConnectionSupervisor,
                args=None,
                restart='permanent',
                name='http_conn_sup'
            ),
            
            # 3. Acceptor - started last (needs router and conn_sup PIDs)
            child_spec(
                id='http_acceptor',
                module=HttpAcceptor,
                args={
                    'port': port,
                    'accept_timeout': accept_timeout,
                    'request_timeout': request_timeout,
                    'router_pid': None,  # Will use whereis() in acceptor init
                    'conn_sup_pid': None,  # Will use whereis() in acceptor init
                },
                restart='permanent',
                name='http_acceptor'
            ),
        ]
        
        opts = options(
            strategy=ONE_FOR_ALL,  # If any critical component fails, restart all
            max_restarts=3,
            max_seconds=10
        )
        
        return (children, opts)
    
    async def terminate(self, reason, state):
        """Called when supervisor terminates."""
        print(f"[HttpSupervisor] Terminating: {reason}")


# =============================================================================
# HTTP Application
# =============================================================================

class HttpApp(metaclass=OTPModule, behavior=APPLICATION, version="1.0.0"):
    """
    HTTP Application.
    
    Supervision tree:
        HttpApp (application)
        └── HttpSupervisor (supervisor)
            ├── HttpRouter (gen_server)
            ├── ConnectionSupervisor (dynamic_supervisor)
            └── HttpAcceptor (gen_server)
    
    Usage:
        # In your main process:
        app_pid = await HttpApp.start_link(init_arg={
            'port': 8080,
            'routes': [
                ('/hello', HelloHandler),
                ('/api', ApiHandler),
            ]
        })
        
        # Block forever
        while True:
            await process.receive()
    """
    
    async def start(self, start_type, args: Dict[str, Any]):
        """
        Start the HTTP application.
        
        Args:
            start_type: Application start type (normal, etc.)
            args: {
                'port': 8080,
                'routes': List[Tuple[str, handler_class]],
                'accept_timeout': 5.0,
                'request_timeout': 30.0,
            }
        
        Returns:
            Top supervisor PID
        """
        print(f"[HttpApp] Starting HTTP application")
        
        # Start the supervisor tree
        sup_pid = await supervisor.start_link(
            HttpSupervisor,
            init_arg=args,
            name='http_supervisor'
        )
        
        print(f"[HttpApp] HTTP server started successfully")
        print(f"[HttpApp]   Supervisor PID: {sup_pid}")
        
        return sup_pid
    
    async def stop(self, state):
        """
        Stop the HTTP application.
        
        Args:
            state: Application state (supervisor PID)
        """
        print(f"[HttpApp] Stopping HTTP server")
        
        # Supervisor will handle shutting down children
        
    async def config_change(self, changed, new, removed):
        """
        Handle configuration changes.
        
        Args:
            changed: Changed config keys
            new: New config keys
            removed: Removed config keys
        """
        # TODO: Support hot-reloading routes
        print(f"[HttpApp] Config change: changed={changed}, new={new}, removed={removed}")
