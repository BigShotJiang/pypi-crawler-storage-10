"""
otpylib_http.router

HTTP Router GenServer - maintains routing table and matches paths to handlers.

Supports:
- Static routes: exact path matching
- Dynamic routes: path parameters (future)
- Route registration and lookup
"""

from typing import Any, Dict, List, Tuple, Optional

from otpylib import process
from otpylib.module import OTPModule, GEN_SERVER
from otpylib.gen_server.data import Reply, NoReply, Stop

from otpylib_http.atoms import (
    LOOKUP, ADD_ROUTE, REMOVE_ROUTE, LIST_ROUTES,
    ROUTE_FOUND, ROUTE_NOT_FOUND,
    OK, ERROR,
)


# =============================================================================
# HTTP Router GenServer
# =============================================================================

class HttpRouter(metaclass=OTPModule, behavior=GEN_SERVER, version="1.0.0"):
    """
    HTTP Router GenServer.
    
    Maintains a routing table that maps paths to handler classes (plain modules).
    Performs path matching and returns the appropriate handler.
    
    State:
        {
            'routes': List[Tuple[str, handler_class]],
            'route_count': int
        }
    
    Routes are tried in order, first match wins.
    """
    
    async def init(self, routes: List[Tuple[str, type]]):
        """
        Initialize router with routes.
        
        Args:
            routes: List of (path_pattern, handler_class) tuples
                Example: [
                    ('/hello', HelloHandler),
                    ('/api/users', UserHandler),
                ]
        
        Returns:
            Initial state dict
        """
        print(f"[HttpRouter] Initializing with {len(routes)} routes")
        
        for path, handler in routes:
            print(f"[HttpRouter]   {path} -> {handler.__name__}")
        
        state = {
            'routes': routes,
            'route_count': len(routes),
        }
        
        return state
    
    async def handle_call(self, request, from_pid, state: Dict[str, Any]):
        """
        Handle synchronous calls.
        
        Supported calls:
            - ('lookup', path): Find handler for path
            - ('add_route', path, handler): Add new route
            - ('remove_route', path): Remove route
            - LIST_ROUTES: Get all routes
        """
        match request:
            case ('lookup', path):
                # Find handler for path
                handler = self._match_route(path, state['routes'])
                
                if handler:
                    return (Reply(payload=(OK, handler)), state)
                else:
                    return (Reply(payload=(ERROR, ROUTE_NOT_FOUND)), state)
            
            case ('add_route', path, handler):
                # Add new route
                state['routes'].append((path, handler))
                state['route_count'] += 1
                
                print(f"[HttpRouter] Added route: {path} -> {handler.__name__}")
                
                return (Reply(payload=OK), state)
            
            case ('remove_route', path):
                # Remove route by path
                original_count = len(state['routes'])
                state['routes'] = [(p, h) for p, h in state['routes'] if p != path]
                removed = original_count - len(state['routes'])
                
                if removed > 0:
                    state['route_count'] = len(state['routes'])
                    print(f"[HttpRouter] Removed route: {path}")
                    return (Reply(payload=(OK, removed)), state)
                else:
                    return (Reply(payload=(ERROR, ROUTE_NOT_FOUND)), state)
            
            case req if req == LIST_ROUTES:
                # Return all routes (as list of path strings)
                route_list = [path for path, _ in state['routes']]
                return (Reply(payload=(OK, route_list)), state)
            
            case 'stats':
                # Return router statistics
                stats = {
                    'route_count': state['route_count'],
                    'routes': [path for path, _ in state['routes']]
                }
                return (Reply(payload=(OK, stats)), state)
            
            case _:
                return (Reply(payload=(ERROR, f'unknown_call: {request}')), state)
    
    async def handle_cast(self, message, state: Dict[str, Any]):
        """
        Handle asynchronous casts.
        
        Currently no casts supported.
        """
        match message:
            case _:
                return (NoReply(), state)
    
    async def handle_info(self, message, state: Dict[str, Any]):
        """
        Handle info messages.
        
        Currently no info messages expected.
        """
        match message:
            case _:
                return (NoReply(), state)
    
    async def terminate(self, reason, state: Dict[str, Any]):
        """
        Cleanup on termination.
        """
        print(f"[HttpRouter] Terminating: {reason}")
    
    # ========================================================================
    # Route Matching Logic
    # ========================================================================
    
    def _match_route(self, path: str, routes: List[Tuple[str, type]]) -> Optional[type]:
        """
        Match path against routes.
        
        Currently uses simple prefix matching.
        First match wins.
        
        Args:
            path: Request path (e.g., '/hello' or '/api/users/123')
            routes: List of (pattern, handler) tuples
        
        Returns:
            Handler class if match found, None otherwise
        """
        for pattern, handler in routes:
            if self._path_matches(path, pattern):
                return handler
        
        return None
    
    def _path_matches(self, path: str, pattern: str) -> bool:
        """
        Check if path matches pattern.
        
        Currently supports:
        - Exact match: '/hello' matches '/hello'
        - Prefix match: '/api' matches '/api/users'
        
        Future:
        - Path parameters: '/users/:id' matches '/users/123'
        - Wildcards: '/static/*' matches '/static/css/style.css'
        
        Args:
            path: Request path
            pattern: Route pattern
        
        Returns:
            True if match, False otherwise
        """
        # Exact match
        if path == pattern:
            return True
        
        # Prefix match
        if path.startswith(pattern + '/'):
            return True
        
        # TODO: Add support for path parameters and wildcards
        # Example:
        # if ':' in pattern:
        #     return self._match_with_params(path, pattern)
        
        return False
    
    def _extract_params(self, path: str, pattern: str) -> Dict[str, str]:
        """
        Extract path parameters from path based on pattern.
        
        Future feature for dynamic routes.
        
        Example:
            pattern: '/users/:id/posts/:post_id'
            path: '/users/123/posts/456'
            returns: {'id': '123', 'post_id': '456'}
        
        Args:
            path: Request path
            pattern: Route pattern with :param syntax
        
        Returns:
            Dictionary of parameter names to values
        """
        # TODO: Implement path parameter extraction
        params = {}
        
        pattern_parts = pattern.split('/')
        path_parts = path.split('/')
        
        if len(pattern_parts) != len(path_parts):
            return {}
        
        for pattern_part, path_part in zip(pattern_parts, path_parts):
            if pattern_part.startswith(':'):
                param_name = pattern_part[1:]
                params[param_name] = path_part
        
        return params
