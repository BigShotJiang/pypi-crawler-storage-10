"""
otpylib_http.handler

Handler utilities and base functionality for HTTP handlers.

Handlers are plain OTPModules (no behavior) that implement request processing.
This module provides helper functions and utilities for handler authors.
"""

from typing import Dict, Any, Optional


# =============================================================================
# Response Builders
# =============================================================================

def response(
    status: int = 200,
    body: bytes = b'',
    headers: Optional[Dict[str, str]] = None,
    content_type: str = 'text/plain'
) -> Dict[str, Any]:
    """
    Build a standard HTTP response dict.
    
    Args:
        status: HTTP status code (default: 200)
        body: Response body as bytes
        headers: Additional headers (optional)
        content_type: Content-Type header (default: 'text/plain')
    
    Returns:
        Response dict for ConnectionHandler
    
    Example:
        return response(200, b'Hello, World!')
        return response(404, b'Not Found', content_type='text/html')
    """
    resp_headers = headers or {}
    
    # Set Content-Type if not already present
    if 'Content-Type' not in resp_headers:
        resp_headers['Content-Type'] = content_type
    
    return {
        'status': status,
        'headers': resp_headers,
        'body': body
    }


def json_response(
    data: Any,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Build a JSON response.
    
    Args:
        data: Data to serialize as JSON (dict, list, etc.)
        status: HTTP status code (default: 200)
        headers: Additional headers (optional)
    
    Returns:
        Response dict with JSON content-type
    
    Example:
        return json_response({'message': 'Hello', 'count': 42})
    """
    import json
    
    body = json.dumps(data).encode('utf-8')
    
    resp_headers = headers or {}
    resp_headers['Content-Type'] = 'application/json'
    
    return {
        'status': status,
        'headers': resp_headers,
        'body': body
    }


def html_response(
    html: str,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Build an HTML response.
    
    Args:
        html: HTML content as string
        status: HTTP status code (default: 200)
        headers: Additional headers (optional)
    
    Returns:
        Response dict with HTML content-type
    
    Example:
        return html_response('<h1>Hello World</h1>')
    """
    body = html.encode('utf-8')
    
    resp_headers = headers or {}
    resp_headers['Content-Type'] = 'text/html; charset=utf-8'
    
    return {
        'status': status,
        'headers': resp_headers,
        'body': body
    }


def redirect(
    location: str,
    status: int = 302,
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Build a redirect response.
    
    Args:
        location: URL to redirect to
        status: HTTP status code (default: 302 Found)
        headers: Additional headers (optional)
    
    Returns:
        Response dict with Location header
    
    Example:
        return redirect('/login')
        return redirect('https://example.com', status=301)
    """
    resp_headers = headers or {}
    resp_headers['Location'] = location
    
    return {
        'status': status,
        'headers': resp_headers,
        'body': b''
    }


def error_response(
    status: int,
    message: Optional[str] = None,
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Build an error response.
    
    Args:
        status: HTTP error status code (400, 404, 500, etc.)
        message: Error message (optional, uses default for status)
        headers: Additional headers (optional)
    
    Returns:
        Response dict with error status
    
    Example:
        return error_response(404, 'Resource not found')
        return error_response(500)
    """
    if message is None:
        message = _default_error_message(status)
    
    body = message.encode('utf-8')
    
    return response(status, body, headers, content_type='text/plain')


def _default_error_message(status: int) -> str:
    """Get default error message for status code."""
    messages = {
        400: 'Bad Request',
        401: 'Unauthorized',
        403: 'Forbidden',
        404: 'Not Found',
        405: 'Method Not Allowed',
        408: 'Request Timeout',
        500: 'Internal Server Error',
        502: 'Bad Gateway',
        503: 'Service Unavailable',
        504: 'Gateway Timeout',
    }
    return messages.get(status, 'Error')


# =============================================================================
# Request Parsing Helpers
# =============================================================================

def get_header(request: Dict[str, Any], name: str, default: Optional[str] = None) -> Optional[str]:
    """
    Get header from request (case-insensitive).
    
    Args:
        request: Request dict from ConnectionHandler
        name: Header name (case-insensitive)
        default: Default value if header not found
    
    Returns:
        Header value or default
    
    Example:
        content_type = get_header(request, 'Content-Type', 'text/plain')
        auth = get_header(request, 'Authorization')
    """
    headers = request.get('headers', {})
    
    # Case-insensitive lookup
    name_lower = name.lower()
    for key, value in headers.items():
        if key.lower() == name_lower:
            return value
    
    return default


def parse_query_string(request: Dict[str, Any]) -> Dict[str, str]:
    """
    Parse query string from request path.
    
    Args:
        request: Request dict from ConnectionHandler
    
    Returns:
        Dictionary of query parameters
    
    Example:
        # Request: GET /search?q=hello&limit=10
        params = parse_query_string(request)
        # params = {'q': 'hello', 'limit': '10'}
    """
    from urllib.parse import urlparse, parse_qs
    
    path = request.get('path', '')
    parsed = urlparse(path)
    
    if not parsed.query:
        return {}
    
    # parse_qs returns lists, get first value
    params = parse_qs(parsed.query)
    return {key: values[0] for key, values in params.items()}


def parse_json_body(request: Dict[str, Any]) -> Any:
    """
    Parse JSON body from request.
    
    Args:
        request: Request dict from ConnectionHandler
    
    Returns:
        Parsed JSON data (dict, list, etc.)
    
    Raises:
        ValueError: If body is not valid JSON
    
    Example:
        data = parse_json_body(request)
        username = data.get('username')
    """
    import json
    
    body = request.get('body', b'')
    
    if not body:
        raise ValueError('No body in request')
    
    return json.loads(body.decode('utf-8'))


def parse_form_data(request: Dict[str, Any]) -> Dict[str, str]:
    """
    Parse URL-encoded form data from request body.
    
    Args:
        request: Request dict from ConnectionHandler
    
    Returns:
        Dictionary of form fields
    
    Example:
        # POST with body: username=alice&password=secret
        form = parse_form_data(request)
        # form = {'username': 'alice', 'password': 'secret'}
    """
    from urllib.parse import parse_qs
    
    body = request.get('body', b'')
    
    if not body:
        return {}
    
    # parse_qs expects string
    query_string = body.decode('utf-8')
    params = parse_qs(query_string)
    
    # parse_qs returns lists, get first value
    return {key: values[0] for key, values in params.items()}


# =============================================================================
# Method Checking
# =============================================================================

def is_method(request: Dict[str, Any], method: str) -> bool:
    """
    Check if request method matches.
    
    Args:
        request: Request dict from ConnectionHandler
        method: HTTP method to check ('GET', 'POST', etc.)
    
    Returns:
        True if method matches
    
    Example:
        if is_method(request, 'POST'):
            data = parse_json_body(request)
    """
    return request.get('method', '').upper() == method.upper()


def require_method(request: Dict[str, Any], method: str) -> Optional[Dict[str, Any]]:
    """
    Require specific HTTP method, return error response if mismatch.
    
    Args:
        request: Request dict from ConnectionHandler
        method: Required HTTP method
    
    Returns:
        None if method matches, error response dict if mismatch
    
    Example:
        # In handler:
        error = require_method(request, 'POST')
        if error:
            return error
        
        # Process POST request...
    """
    if not is_method(request, method):
        return error_response(405, f'Method Not Allowed. Expected {method}')
    
    return None


# =============================================================================
# Content Negotiation
# =============================================================================

def accepts_json(request: Dict[str, Any]) -> bool:
    """
    Check if client accepts JSON response.
    
    Args:
        request: Request dict from ConnectionHandler
    
    Returns:
        True if Accept header includes application/json
    
    Example:
        if accepts_json(request):
            return json_response(data)
        else:
            return html_response(render_html(data))
    """
    accept = get_header(request, 'Accept', '')
    return 'application/json' in accept or '*/*' in accept


def accepts_html(request: Dict[str, Any]) -> bool:
    """
    Check if client accepts HTML response.
    
    Args:
        request: Request dict from ConnectionHandler
    
    Returns:
        True if Accept header includes text/html
    """
    accept = get_header(request, 'Accept', '')
    return 'text/html' in accept or '*/*' in accept
