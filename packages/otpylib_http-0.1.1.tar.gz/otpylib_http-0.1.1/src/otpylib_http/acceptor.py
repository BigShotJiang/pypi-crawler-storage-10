"""
otpylib_http.acceptor

HTTP Acceptor GenServer - accepts incoming TCP connections and spawns
ConnectionHandler processes under a DynamicSupervisor.

Uses otpylib.inet for OTP-style TCP with active mode support.
"""

from typing import Any, Dict

from otpylib import process
from otpylib.module import OTPModule, GEN_SERVER
from otpylib.gen_server.data import Reply, NoReply, Stop
from otpylib.inet import listen, accept, close, SocketOptions, ListenSocket, Socket
from otpylib.inet.atoms import TCP_MSG, TCP_CLOSED, TCP_ERROR

from otpylib_http.atoms import (
    ACCEPT, STOP_ACCEPTING,
    OK, ERROR,
)


# =============================================================================
# HttpAcceptor GenServer
# =============================================================================

class HttpAcceptor(metaclass=OTPModule, behavior=GEN_SERVER, version="1.0.0"):
    """
    HTTP Acceptor GenServer.
    
    Manages a listening socket and continuously accepts incoming connections.
    Each accepted connection spawns a new ConnectionHandler under the
    connection supervisor.
    
    State:
        {
            'listen_socket': ListenSocket,
            'host': bind host,
            'port': bind port,
            'conn_sup_pid': connection supervisor PID,
            'router_pid': router PID,
            'accepting': bool,
            'connections_accepted': int,
            'accept_timeout': accept timeout in seconds
        }
    """
    
    async def init(self, config: Dict[str, Any]):
        """
        Initialize the acceptor.
        
        Args:
            config: {
                'port': 8080,
                'conn_sup_pid': PID of DynamicSupervisor,
                'router_pid': PID of router,
                'accept_timeout': timeout in seconds (default: 5.0)
            }
        
        Returns:
            Initial state dict
        """
        port = config.get('port', 8080)
        accept_timeout = config.get('accept_timeout', 5.0)
        conn_sup_pid = config['conn_sup_pid']
        router_pid = config['router_pid']
        
        # Create socket options
        socket_opts = SocketOptions(
            reuseaddr=True,
            nodelay=True,  # Disable Nagle for HTTP
            keepalive=True,
            buffer_size=8192
        )
        
        # Create listening socket using inet
        try:
            listen_socket = await listen(port, socket_opts)
            
            local_addr = listen_socket.local
            print(f"[HttpAcceptor] Listening on {local_addr.host}:{local_addr.port}")
            
        except Exception as e:
            raise Exception(f"Failed to create listening socket: {e}")
        
        # Build initial state
        state = {
            'listen_socket': listen_socket,
            'host': local_addr.host,
            'port': local_addr.port,
            'conn_sup_pid': conn_sup_pid,
            'router_pid': router_pid,
            'accepting': True,
            'connections_accepted': 0,
            'accept_timeout': accept_timeout,
        }
        
        # Trigger first accept
        await process.send(process.self(), ACCEPT)
        
        return state
    
    async def handle_call(self, request, from_pid, state: Dict[str, Any]):
        """
        Handle synchronous calls.
        
        Supported calls:
            - STOP_ACCEPTING: Stop accepting new connections
            - 'start_accepting': Resume accepting connections
            - 'stats': Get acceptor statistics
        """
        match request:
            case req if req == STOP_ACCEPTING:
                state['accepting'] = False
                return (Reply(payload=OK), state)
            
            case 'start_accepting':
                if not state['accepting']:
                    state['accepting'] = True
                    # Trigger accept loop
                    await process.send(process.self(), ACCEPT)
                return (Reply(payload=OK), state)
            
            case 'stats':
                stats = {
                    'host': state['host'],
                    'port': state['port'],
                    'accepting': state['accepting'],
                    'connections_accepted': state['connections_accepted'],
                }
                return (Reply(payload=(OK, stats)), state)
            
            case _:
                return (Reply(payload=(ERROR, f'unknown_call: {request}')), state)
    
    async def handle_cast(self, message, state: Dict[str, Any]):
        """
        Handle asynchronous casts.
        
        Supported casts:
            - 'shutdown': Graceful shutdown
        """
        match message:
            case 'shutdown':
                state['accepting'] = False
                return (Stop(reason='shutdown'), state)
            
            case _:
                return (NoReply(), state)
    
    async def handle_info(self, message, state: Dict[str, Any]):
        """
        Handle info messages.

        Main accept loop runs here.
        """
        match message:
            case msg if msg == ACCEPT:
                if not state['accepting']:
                    # Not accepting, don't loop
                    return (NoReply(), state)

                try:
                    # Accept connection (blocks until client connects or timeout)
                    conn_socket: Socket = await accept(
                        state['listen_socket'],
                        timeout=state['accept_timeout']
                    )

                    # Connection accepted!
                    state['connections_accepted'] += 1

                    peer = conn_socket.peer
                    print(f"[HttpAcceptor] Connection from {peer.host}:{peer.port}")

                    # Look up router and supervisor PIDs by registered names
                    router_pid = process.whereis('http_router')
                    conn_sup_pid = process.whereis('http_conn_sup')

                    if not router_pid or not conn_sup_pid:
                        print(f"[HttpAcceptor] ERROR: Router or ConnSup not found!")
                        await close(conn_socket)
                    else:
                        # Spawn HttpConnection under dynamic supervisor
                        from otpylib import dynamic_supervisor
                        from otpylib.dynamic_supervisor import child_spec as dyn_child_spec, TEMPORARY
                        from otpylib_http.connection import HttpConnection

                        spec = dyn_child_spec(
                            id=f"conn_{peer.host}_{peer.port}",
                            module=HttpConnection,
                            args={
                                'socket': conn_socket,
                                'router_pid': router_pid
                            },
                            restart=TEMPORARY,
                            name=None
                        )
                        
                        success, result = await dynamic_supervisor.start_child(conn_sup_pid, spec)
                        
                        if success:
                            print(f"[HttpAcceptor] Spawned connection handler: {result}")
                        else:
                            print(f"[HttpAcceptor] Failed to spawn handler: {result}")
                            await close(conn_socket)

                except Exception as e:
                    # Accept timeout or error - that's fine, just loop back
                    if "timeout" not in str(e).lower():
                        print(f"[HttpAcceptor] Accept error: {e}")

                # Loop back to accept next connection
                if state['accepting']:
                    await process.send(process.self(), ACCEPT)

                return (NoReply(), state)

            case _:
                # Unknown info message
                return (NoReply(), state)
    
    async def terminate(self, reason, state: Dict[str, Any]):
        """
        Cleanup on termination.
        
        Close the listening socket.
        """
        print(f"[HttpAcceptor] Terminating: {reason}")
        
        try:
            if state.get('listen_socket'):
                # Close listening socket (this will stop accepting)
                server = state['listen_socket'].handle['server']
                server.close()
                await server.wait_closed()
                print(f"[HttpAcceptor] Listening socket closed")
        except Exception as e:
            print(f"[HttpAcceptor] Error closing socket: {e}")
