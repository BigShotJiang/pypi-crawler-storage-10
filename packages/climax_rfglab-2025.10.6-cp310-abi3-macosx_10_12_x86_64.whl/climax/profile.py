import time
from climax.climax import climax
  
a = climax('./dev_tests/a16bmovie.tif')
#a.action_zoom("in")
#a.action_zoom("in")

NUM_ITER = 100

thetimes = []
for _ in range(NUM_ITER):
    t0 = time.perf_counter()
    a.action_next_slice()
    t1 = time.perf_counter()
    thetimes.append((t1 - t0))

mean_time = sum(thetimes) / NUM_ITER
std_time = (sum((x - mean_time) ** 2 for x in thetimes) / NUM_ITER) ** 0.5
print(f"Mean time: {mean_time * 1000:.2f}ms, std: {std_time * 1000:.2f}ms over {NUM_ITER} iterations")
#took = (t1 - t0) / NUM_ITER
#print(f"Took an avg of {took * 1000:.2f}ms per iteration")
print(a.image_data.shape)