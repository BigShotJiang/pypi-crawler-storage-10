# numpi/__init__.py

from .core import get1, get2, get3, get4

__all__ = ["get1", "get2", "get3", "get4"]
