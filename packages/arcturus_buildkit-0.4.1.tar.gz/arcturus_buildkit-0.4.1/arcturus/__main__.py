import argparse
import random
from .arcturus_buildkit import arcturusNLP, arcturusSUPERVISED_INTENT

def build_bot():
    nlp = arcturusNLP()
    
    training_data = [
        ("hi", "greeting"),
        ("hello", "greeting"),
        ("hey", "greeting"),
        ("how are you", "greeting"),
        ("bye", "goodbye"),
        ("see you later", "goodbye"),
        ("tell me a joke", "joke"),
        ("make me laugh", "joke"),
        ("thanks", "thanks"),
        ("thank you", "thanks"),
        ("what's your name", "identity")
    ]
    
    intent_responses = {
        "greeting": ["Hello!", "Hey there!", "Hi! How can I help you?"],
        "goodbye": ["Goodbye!", "See you later!", "Bye!"],
        "joke": ["Why do programmers prefer dark mode? Because light attracts bugs!"],
        "thanks": ["You're welcome!", "No problem!", "Anytime!"],
        "identity": ["I'm Arcturus, your AI assistant."]
    }
    
    bot = arcturusSUPERVISED_INTENT(nlp, intent_responses)
    bot.train(training_data)
    return bot

def main():
    parser = argparse.ArgumentParser(
        description="Arcturus NLP Bot CLI — chat or predict intent from a sentence"
    )
    
    parser.add_argument(
        "-s", "--sentence", type=str, help="Send a single sentence and get a response"
    )
    parser.add_argument(
        "-i", "--interactive", action="store_true",
        help="Run the interactive chat mode"
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Show debug similarity scores"
    )
    
    args = parser.parse_args()
    
    bot = build_bot()
    
    if args.sentence:
        response = bot.get_response(args.sentence)
        if args.verbose:
            print(f"[DEBUG] Input: {args.sentence}")
            print(f"[DEBUG] Predicted intent: {bot.predict_intent(args.sentence, show_scores=True)}")
        print(response)
    elif args.interactive:
        print("🤖 Arcturus NLP Bot v0.2.0 | Type 'exit' to quit.")
        while True:
            user_input = input("You: ")
            if user_input.lower() == "exit":
                print("Bot: Goodbye!")
                break
            response = bot.get_response(user_input)
            if args.verbose:
                bot.predict_intent(user_input, show_scores=True)
            print("Bot:", response)
    else:
        print("No input provided. Use --sentence <text> or --interactive")
        parser.print_help()

if __name__ == "__main__":
    main()
