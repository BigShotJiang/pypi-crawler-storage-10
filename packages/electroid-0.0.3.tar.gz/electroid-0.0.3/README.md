# Electroid
`electroid` is a Python library utilizing the anthropomorphized electric power consumption for tasks at hand.
<pre>
  pip install electroid
</pre>
Then:
```Python
  # Python
  import electroid
```
