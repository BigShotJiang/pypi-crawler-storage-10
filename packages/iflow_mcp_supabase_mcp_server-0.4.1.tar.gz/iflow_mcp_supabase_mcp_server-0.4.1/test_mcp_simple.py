#!/usr/bin/env python3
"""
Simple test script to verify MCP server can start and respond to basic requests
without requiring actual database connections.
"""

import asyncio
import json
import sys
from contextlib import asynccontextmanager
from collections.abc import AsyncGenerator

from mcp.server.fastmcp import FastMCP

# Create a minimal MCP server for testing
@asynccontextmanager
async def minimal_lifespan(app: FastMCP) -> AsyncGenerator[FastMCP, None]:
    """Minimal lifespan that doesn't require database connections"""
    try:
        print("Initializing minimal MCP server...")
        
        # Add a simple test tool
        @app.tool(description="A simple test tool that returns basic information")
        async def test_tool() -> dict:
            """Test tool that returns basic server information"""
            return {
                "status": "ok",
                "message": "Supabase MCP Server is running",
                "tools_available": ["test_tool"]
            }
        
        yield app
    finally:
        print("Shutting down minimal MCP server...")

# Create minimal MCP instance
mcp = FastMCP("supabase-test", lifespan=minimal_lifespan)

def run_test_server() -> None:
    """Run the test server"""
    print("Starting minimal Supabase MCP server for testing...")
    mcp.run()

if __name__ == "__main__":
    run_test_server()