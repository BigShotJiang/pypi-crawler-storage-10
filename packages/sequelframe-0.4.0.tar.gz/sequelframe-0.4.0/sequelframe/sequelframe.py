"""SQL interface for pandas DataFrames using SQLite."""

from __future__ import annotations

import os
import sqlite3
import time
import warnings
from pathlib import Path
from typing import Any, Optional, Union

import pandas as pd


class SequelFrame:
    """
    A lightweight wrapper to run SQL queries on pandas DataFrames using SQLite.

    This class creates a temporary SQLite database from a pandas DataFrame or file,
    allowing you to execute SQL queries against it.

    Args:
        data: Either a pandas DataFrame, file path (CSV/Excel), or Path object
        table_name: Name of the table in the SQLite database (default: "data")
        verbose: If True, print query results for SELECT statements (default: False)
        temp_dir: Directory for temporary database files (default: current directory)

    Examples:
        >>> # From a DataFrame
        >>> import pandas as pd
        >>> df = pd.DataFrame({'name': ['Alice', 'Bob'], 'age': [25, 30]})
        >>> db = SequelFrame(df)
        >>> result = db.runsql('SELECT * FROM data WHERE age > 25')
        >>> db.kill()

        >>> # Using context manager (recommended)
        >>> with SequelFrame('data.csv') as db:
        ...     result = db.runsql('SELECT * FROM data WHERE age > 25')

        >>> # From a file
        >>> db = SequelFrame('mydata.csv', table_name='customers')
    """

    def __init__(
        self,
        data: Union[pd.DataFrame, str, Path],
        table_name: str = "data",
        verbose: bool = False,
        temp_dir: Optional[Union[str, Path]] = None,
    ) -> None:
        self.table_name = table_name
        self.verbose = verbose
        self._conn: Optional[sqlite3.Connection] = None
        self._db_path: Optional[Path] = None

        # Load the DataFrame
        self.df = self._load_data(data)

        # Create temporary SQLite database
        self._db_path = self._create_temp_db(data, temp_dir)
        self._conn = sqlite3.connect(str(self._db_path))

        # Write DataFrame to SQLite
        self.df.to_sql(self.table_name, self._conn, if_exists='replace', index=False)

    def _load_data(self, data: Union[pd.DataFrame, str, Path]) -> pd.DataFrame:
        """Load data from various sources into a pandas DataFrame."""
        if isinstance(data, pd.DataFrame):
            return data.copy()

        # Convert to Path object
        file_path = Path(data) if isinstance(data, str) else data

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Determine file type and read accordingly
        suffix = file_path.suffix.lower()

        try:
            if suffix == '.csv':
                return pd.read_csv(file_path)
            elif suffix in ['.xls', '.xlsx', '.xlsm', '.xlsb']:
                return pd.read_excel(file_path)
            elif suffix in ['.json']:
                return pd.read_json(file_path)
            elif suffix in ['.parquet']:
                return pd.read_parquet(file_path)
            elif suffix in ['.feather']:
                return pd.read_feather(file_path)
            else:
                raise ValueError(
                    f"Unsupported file type: {suffix}. "
                    f"Supported formats: CSV, Excel, JSON, Parquet, Feather"
                )
        except Exception as e:
            raise ValueError(f"Failed to read file {file_path}: {e}") from e

    def _create_temp_db(
        self,
        data: Union[pd.DataFrame, str, Path],
        temp_dir: Optional[Union[str, Path]] = None,
    ) -> Path:
        """Create a unique temporary database file path."""
        # Determine base name
        if isinstance(data, pd.DataFrame):
            base_name = 'temp'
        else:
            file_path = Path(data) if isinstance(data, str) else data
            base_name = file_path.stem

        # Determine directory
        if temp_dir:
            directory = Path(temp_dir)
            directory.mkdir(parents=True, exist_ok=True)
        else:
            directory = Path.cwd()

        # Create unique filename with timestamp
        timestamp = int(time.time() * 1000000)  # Microsecond precision
        db_path = directory / f"{base_name}_{timestamp}.sqlite"

        return db_path

    def runsql(
        self,
        query: str,
        params: Optional[tuple[Any, ...]] = None,
        return_df: bool = True,
    ) -> Optional[pd.DataFrame]:
        """
        Execute a SQL query on the database.

        Args:
            query: SQL query string
            params: Optional tuple of parameters for parameterized queries
            return_df: If True, return results as DataFrame for SELECT queries

        Returns:
            DataFrame for SELECT queries if return_df=True, None otherwise

        Examples:
            >>> db.runsql('SELECT * FROM data WHERE age > 25')
            >>> db.runsql('SELECT * FROM data WHERE name = ?', ('Alice',))
            >>> db.runsql('UPDATE data SET age = 31 WHERE name = "John"')
        """
        if self._conn is None:
            raise RuntimeError("Database connection is closed. Cannot execute query.")

        try:
            cursor = self._conn.cursor()

            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            self._conn.commit()

            # Check if it's a SELECT query
            query_upper = query.strip().upper()
            if query_upper.startswith('SELECT') or query_upper.startswith('WITH'):
                if return_df:
                    result = pd.read_sql(query, self._conn, params=params)
                    if self.verbose:
                        print(result)
                    return result
                else:
                    return None

            # For non-SELECT queries, refresh the DataFrame
            self.df = pd.read_sql(f'SELECT * FROM {self.table_name}', self._conn)
            return None

        except sqlite3.Error as e:
            raise sqlite3.Error(f"SQL execution failed: {e}") from e

    def query(
        self,
        sql: str,
        params: Optional[tuple[Any, ...]] = None,
    ) -> pd.DataFrame:
        """
        Alias for runsql that always returns a DataFrame.

        This is a convenience method for SELECT queries.
        """
        result = self.runsql(sql, params=params, return_df=True)
        if result is None:
            raise ValueError("Query did not return any results. Use runsql() for non-SELECT queries.")
        return result

    def show(self, limit: Optional[int] = None) -> pd.DataFrame:
        """
        Display all data (or limited rows) from the table.

        Args:
            limit: Maximum number of rows to return (None for all rows)

        Returns:
            DataFrame containing the data
        """
        query = f'SELECT * FROM {self.table_name}'
        if limit is not None:
            query += f' LIMIT {limit}'

        result = self.runsql(query)
        return result if result is not None else pd.DataFrame()

    def get_dataframe(self) -> pd.DataFrame:
        """
        Get the current state of the DataFrame.

        Returns:
            A copy of the current DataFrame
        """
        return self.df.copy()

    def update_dataframe(self, df: pd.DataFrame) -> None:
        """
        Replace the current DataFrame and update the database.

        Args:
            df: New DataFrame to use
        """
        if not isinstance(df, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame")

        if self._conn is None:
            raise RuntimeError("Database connection is closed.")

        self.df = df.copy()
        self.df.to_sql(self.table_name, self._conn, if_exists='replace', index=False)

    @property
    def columns(self) -> list[str]:
        """Get the list of column names."""
        return self.df.columns.tolist()

    @property
    def shape(self) -> tuple[int, int]:
        """Get the shape of the DataFrame (rows, columns)."""
        return self.df.shape

    def kill(self) -> None:
        """
        Close the database connection and remove the temporary database file.

        This should be called when you're done with the SequelFrame object.
        """
        if self._conn:
            try:
                self._conn.close()
            except Exception as e:
                warnings.warn(f"Error closing connection: {e}")
            finally:
                self._conn = None

        if self._db_path and self._db_path.exists():
            try:
                self._db_path.unlink()
            except Exception as e:
                warnings.warn(f"Error removing database file {self._db_path}: {e}")

    def __enter__(self) -> SequelFrame:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit - automatically cleanup."""
        self.kill()

    def __del__(self) -> None:
        """Destructor - ensure cleanup on object deletion."""
        # Only close connection, don't remove file in destructor
        # as it might be called at unexpected times
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

    def __repr__(self) -> str:
        """String representation of the SequelFrame object."""
        status = "open" if self._conn else "closed"
        return (
            f"SequelFrame(table='{self.table_name}', "
            f"shape={self.shape}, status='{status}')"
        )

    def __str__(self) -> str:
        """Human-readable string representation."""
        return self.__repr__()


# Alias for backward compatibility
sequelframe = SequelFrame
