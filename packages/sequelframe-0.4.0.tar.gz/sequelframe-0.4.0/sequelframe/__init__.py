"""sequelframe - SQL interface for pandas DataFrames using SQLite."""

from __future__ import annotations

from .sequelframe import SequelFrame, sequelframe

__version__ = "0.4.0"
__all__ = ["SequelFrame", "sequelframe"]
