"""
plot_learning_curve:
Create a simple learning curve from lists of values.
"""
import matplotlib.pyplot as plt
from typing import Sequence, Optional

def plot_learning_curve(train_values: Sequence[float],
                        val_values: Optional[Sequence[float]] = None,
                        metric_name: str = "loss",
                        title: Optional[str] = None,
                        show: bool = True,
                        save_path: Optional[str] = None):
    epochs = range(1, len(train_values) + 1)
    plt.figure(figsize=(8, 5))
    plt.plot(epochs, train_values, label=f"train {metric_name}", marker="o")
    if val_values is not None:
        plt.plot(epochs, val_values, label=f"val {metric_name}", marker="o")
    plt.xlabel("Epoch")
    plt.ylabel(metric_name)
    plt.xticks(epochs)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    if title:
        plt.title(title)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    if show:
        plt.show()
    plt.close()
