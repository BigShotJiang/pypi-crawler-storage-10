from setuptools import setup, find_packages
from pathlib import Path

long_desc = ""
readme = Path(__file__).parent / "README.md"
if readme.exists():
    long_desc = readme.read_text(encoding="utf-8")

setup(
    name="visai",
    version="0.1.0",
    author="Your Name",
    description="Simple ML visualization helpers",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "matplotlib>=3.0",
        "scikit-learn>=1.0",
        "numpy",
        "seaborn"
    ],
    python_requires=">=3.8",
)