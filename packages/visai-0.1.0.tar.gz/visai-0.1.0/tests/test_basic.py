import numpy as np
from sklearn.linear_model import LogisticRegression
from visai.feature_importance import _extract_importances

def test_extract_importances_linear():
    X = np.random.randn(20, 5)
    y = (np.random.rand(20) > 0.5).astype(int)
    clf = LogisticRegression(max_iter=200).fit(X, y)
    imps, names = _extract_importances(clf)
    assert len(imps) == 5
