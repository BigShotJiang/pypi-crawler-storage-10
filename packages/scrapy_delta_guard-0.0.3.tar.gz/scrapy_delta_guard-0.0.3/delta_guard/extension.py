from scrapy import signals
from scrapy.exceptions import CloseSpider
from .core import DeltaBatchProcessor
from .utils import load_object

class DeltaGuardExtension:
    def __init__(self, crawler):
        self.crawler = crawler
        self.settings = crawler.settings
        self.enabled = self.settings.getbool("DELTA_GUARD_ENABLED", False)
        if not self.enabled:
            return
        self.batch_processor = DeltaBatchProcessor(self.settings)
        self.item_count = 0
        crawler.signals.connect(self.process_item, signal=signals.item_scraped)

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler)

    def process_item(self, item, spider):
        if not self.enabled:
            return
        try:
            self.batch_processor.add_item(item)
        except CloseSpider as e:
            jira_func_path = self.settings.get("DELTA_GUARD_JIRA_FUNC")
            if jira_func_path:
                jira_func = load_object(jira_func_path)
                jira_func(str(e))
            spider.logger.error(str(e))
            raise
