import math
from scrapy.exceptions import CloseSpider

class DeltaBatchProcessor:
    def __init__(self, settings):
        self.settings = settings
        self.batch_size = settings.getint("DELTA_GUARD_BATCH_SIZE", 100)
        self.fields_config = settings.getlist("DELTA_GUARD_FIELDS_CONFIG", [])
        self.db_obj = settings.get("DELTA_GUARD_DB_OBJECT")
        self.default_threshold = settings.getfloat("DELTA_GUARD_DEFAULT_THRESHOLD", 0.05)
        self.db_none_ignore = settings.getbool("DELTA_GUARD_DB_NONE_IGNORE", False)
        self.spider_none_ignore = settings.getbool("DELTA_GUARD_SPIDER_NONE_IGNORE", False)
        self.batch_items = []

    def add_item(self, item):
        self.batch_items.append(item)
        if len(self.batch_items) >= self.batch_size:
            exceeded, info = self.check_thresholds()
            self.batch_items = []
            if exceeded:
                raise CloseSpider(f"DeltaGuard stopped spider: {info}")

    def check_thresholds(self):
        deltas = {f["name"]: [] for f in self.fields_config}
        for item in self.batch_items:
            for f in self.fields_config:
                field_name = f["name"]
                threshold = f.get("threshold", self.default_threshold)
                db_attr = f.get("db_attr", field_name)
                spider_attr = f.get("spider_attr", field_name)

                db_val = getattr(self.db_obj, db_attr, None) if hasattr(self.db_obj, db_attr) else self.db_obj.get(db_attr) if isinstance(self.db_obj, dict) else None
                sp_val = item.get(spider_attr)

                if db_val is None and self.db_none_ignore:
                    continue
                if sp_val is None and self.spider_none_ignore:
                    continue

                if db_val != sp_val:
                    deltas[field_name].append((db_val, sp_val))

        exceeded_fields = []
        for field, changes in deltas.items():
            if not changes:
                continue
            ratio = len(changes) / len(self.batch_items)
            if ratio > (self._get_field_threshold(field) or self.default_threshold):
                exceeded_fields.append({"field": field, "delta_ratio": ratio})

        if exceeded_fields:
            return True, exceeded_fields
        return False, None

    def _get_field_threshold(self, field_name):
        for f in self.fields_config:
            if f["name"] == field_name:
                return f.get("threshold", self.default_threshold)
        return self.default_threshold
