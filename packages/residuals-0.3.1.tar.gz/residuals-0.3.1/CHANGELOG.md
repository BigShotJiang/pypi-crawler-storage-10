# Changelog
## [0.3.1] - 2025-10-30

### Added
- `Residuals.apply_to_pretrained(model, residuals, ...)`: shorthand to load a base model and residuals by name/path and apply in one call. Parameters use simple names `model` and `residuals`.
- `Residuals.apply(...)` now optionally accepts `base_model_name` and `model_dtype` to load the base model directly if an instance isn't provided.

## [0.3.0] - 2025-10-26

### Added
- `normalize_embeddings` parameter (default: true) in `Residuals.from_models()` and `Residuals.apply()` to normalize models to a shared tokenizer space.
  - Compute-time: resize base and instruct to the instruct tokenizer so residuals capture newly added tokens (zero-initialized new rows).
  - Apply-time: resize base to the saved tokenizer before applying residuals.

### Improved
- Clear error messages on shape mismatches suggesting enabling `normalize_embeddings=True` or providing `instruct_tokenizer`/`instruct_tokenizer_name`.


## [0.2.3] - 2025-10-26

### Fixed
- Hotfix `torch_dtype` parameter in `Residuals.from_models`.

## [0.2.2] - 2025-10-25

### Fixed
- Model card generation now includes the correct repository name.
- Warning about deprecated `torch_dtype` parameter.

## [0.2.1] - 2025-10-24

### Added
- `Residuals.push_to_hub(repo_id, private=False, token=None)`: publish residuals to Hugging Face Hub with auto-generated model card and tokenizer included.
- `Residuals.from_pretrained(path_or_repo, token=None)`: now supports loading directly from Hub repo IDs.

---

## [0.2.0] - 2025-10-24

### Added
- Package release on PyPi
- Support for Python 3.13 and 3.14

### Added
- Initial release of residuals package
- Core API is class-only: `Residuals` with `from_models`, `from_pretrained`, `apply`, `save_pretrained`
- Residual artifacts always include the instruct tokenizer saved alongside weights
- Implementation based on Samsung Research 2024 paper (Jindal et al.)
- Task arithmetic methodology following Ilharco et al. 2022
- Automatic tokenizer alignment with PAD token handling
- Comprehensive test suite with >90% coverage
- Full documentation with usage examples
- GitHub Actions CI/CD with PyPI Trusted Publisher
- Support for Python 3.8+

### Features
- Element-wise residual calculation (no scaling needed for same-family)
- Safe tokenizer alignment before residual application (requires both base and instruct tokenizers)
- Zero-initialization of new embedding rows
- Full type hints and docstrings with paper references
- Compatible with Unsloth, HuggingFace Transformers

[0.1.0]: https://github.com/omarkamali/residuals/releases/tag/v0.1.0
