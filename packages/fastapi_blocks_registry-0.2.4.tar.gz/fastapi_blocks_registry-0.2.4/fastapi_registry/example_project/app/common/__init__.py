"""Common utilities and helpers."""
