from .normal import NormalLikelihood
from .student import StudentTLikelihood
from .laplace import LaplaceLikelihood
