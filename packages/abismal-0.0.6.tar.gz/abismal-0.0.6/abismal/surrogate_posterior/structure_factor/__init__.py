from .folded_normal import FoldedNormalPosterior
from .rice import RicePosterior
from .normal import NormalPosterior
from .truncated_normal import TruncatedNormalPosterior
