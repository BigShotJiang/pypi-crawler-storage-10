from .gamma import GammaPosterior
from .folded_normal import FoldedNormalPosterior
