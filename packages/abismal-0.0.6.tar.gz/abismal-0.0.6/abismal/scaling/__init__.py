from .scaling import ImageScaler
from .graph import GraphImageScaler
