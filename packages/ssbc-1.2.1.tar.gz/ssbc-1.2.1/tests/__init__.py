"""Unit test package for ssbc."""
