"""Setup file for ssbc package.

This project uses pyproject.toml for configuration.
This file exists for backward compatibility with older tools.
"""

from setuptools import setup  # type: ignore[import]

setup()
