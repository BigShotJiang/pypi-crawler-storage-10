from setuptools import setup, find_packages

setup(
    name="generalmaths1",
    version="0.1.0",
    author="sathishdhuda",
    author_email="sathishdhuda25@gmail.com",
    description="gwdhqwgqd",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
