#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Secure CLI for MareArts Road Objects Detection
"""

import os
import sys
import argparse
import getpass
from pathlib import Path
from typing import Optional, Dict, Tuple
import cv2
# Import our modules
from .marearts_robj_p import validate_user_key_with_signature
# Detector import
try:
    from .marearts_robj_d import ma_road_object_detector
    DETECTOR_AVAILABLE = True
except ImportError:
    DETECTOR_AVAILABLE = False
    ma_road_object_detector = None
# GPU functions (query onnxruntime at runtime)
def has_gpu_support():
    """Check if GPU support is available"""
    try:
        import onnxruntime
        providers = onnxruntime.get_available_providers()
        gpu_providers = ['CUDAExecutionProvider', 'TensorrtExecutionProvider', 'DmlExecutionProvider']
        return any(p in providers for p in gpu_providers)
    except:
        return False


def get_gpu_providers():
    """Get list of available GPU providers"""
    try:
        import onnxruntime
        providers = onnxruntime.get_available_providers()
        gpu_providers = ['CUDAExecutionProvider', 'TensorrtExecutionProvider', 'DmlExecutionProvider']
        return [p for p in providers if p in gpu_providers]
    except:
        return []


def get_all_providers():
    """Get all available ONNX Runtime providers"""
    try:
        import onnxruntime
        return onnxruntime.get_available_providers()
    except:
        return ['CPUExecutionProvider']


GPU_SUPPORT_AVAILABLE = True  # Always available - check at runtime


def get_execution_mode():
    """Get current execution mode (GPU or CPU)"""
    try:
        import onnxruntime
        available_providers = onnxruntime.get_available_providers()
        if 'CUDAExecutionProvider' in available_providers or 'TensorrtExecutionProvider' in available_providers:
            return "GPU mode (CUDA)"
        elif 'DmlExecutionProvider' in available_providers:
            return "GPU mode (DirectML)"
        else:
            return "CPU mode"
    except:
        return "CPU mode"


# ANPR family environment variable names (shared with ANPR)
ENV_USERNAME = 'MAREARTS_ANPR_USERNAME'
ENV_SERIAL_KEY = 'MAREARTS_ANPR_SERIAL_KEY'
ENV_SIGNATURE = 'MAREARTS_ANPR_SIGNATURE'
# Colors for terminal output
class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    END = '\033[0m'


def secure_save_env_file(username: str, serial_key: str, signature: str):
    """Save credentials to ~/.marearts/.marearts_env file (recommended for security)"""
    marearts_dir = Path.home() / '.marearts'
    marearts_dir.mkdir(parents=True, exist_ok=True)
    # Set hidden attribute on Windows
    if os.name == 'nt':  # Windows
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(marearts_dir), 0x02)
        except Exception:
            pass  # Not critical if it fails
    env_file = marearts_dir / '.marearts_env'
    # Write credentials in shell export format
    with open(env_file, 'w') as f:
        f.write("# MareArts ANPR/Road Objects License Configuration\n")
        f.write("# Source this file: source ~/.marearts/.marearts_env\n")
        f.write("# Or add to your shell rc file: ~/.bashrc or ~/.zshrc\n\n")
        f.write(f'export {ENV_USERNAME}="{username}"\n')
        f.write(f'export {ENV_SERIAL_KEY}="{serial_key}"\n')
        f.write(f'export {ENV_SIGNATURE}="{signature}"\n')
    # Set secure permissions (Unix-like systems)
    if hasattr(os, 'chmod'):
        os.chmod(env_file, 0o600)  # Read/write for owner only
    return env_file


def load_credentials() -> Dict[str, str]:
    """Load credentials from environment variables or ~/.marearts/.marearts_env file"""
    env_username = os.getenv(ENV_USERNAME)
    env_serial_key = os.getenv(ENV_SERIAL_KEY)
    env_signature = os.getenv(ENV_SIGNATURE)
    if env_username and env_serial_key:
        credentials = {
            'user_name': env_username,
            'serial_key': env_serial_key,
            'source': 'environment'
        }
        if env_signature:
            credentials['signature'] = env_signature
        return credentials
    env_file = Path.home() / '.marearts' / '.marearts_env'
    if env_file.exists():
        try:
            with open(env_file, 'r') as f:
                lines = f.readlines()
                username = None
                serial_key = None
                signature = None
                for line in lines:
                    if line.startswith(f'export {ENV_USERNAME}='):
                        username = line.split('=', 1)[1].strip().strip('"')
                    elif line.startswith(f'export {ENV_SERIAL_KEY}='):
                        serial_key = line.split('=', 1)[1].strip().strip('"')
                    elif line.startswith(f'export {ENV_SIGNATURE}='):
                        signature = line.split('=', 1)[1].strip().strip('"')
                if username and serial_key:
                    os.environ[ENV_USERNAME] = username
                    os.environ[ENV_SERIAL_KEY] = serial_key
                    if signature:
                        os.environ[ENV_SIGNATURE] = signature
                    credentials = {
                        'user_name': username,
                        'serial_key': serial_key,
                        'source': '~/.marearts/.marearts_env file'
                    }
                    if signature:
                        credentials['signature'] = signature
                    return credentials
        except Exception:
            pass
    return {}


def get_credentials(args) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Get credentials securely from various sources (returns username, serial_key, signature)"""
    username = None
    serial_key = None
    signature = None
    # 1. Try ~/.marearts_env and environment variables
    credentials = load_credentials()
    if credentials:
        username = credentials.get('user_name')
        serial_key = credentials.get('serial_key')
        signature = credentials.get('signature')
    # 2. Check command line args (least secure, but needed for flexibility)
    if hasattr(args, 'username') and args.username:
        username = args.username
    if hasattr(args, 'serial_key') and args.serial_key:
        serial_key = args.serial_key
    # 3. Interactive prompt if still missing
    if not username:
        try:
            username = input("Enter username: ")
        except (EOFError, KeyboardInterrupt):
            raise RuntimeError("Interactive input failed or was cancelled")
    if not serial_key:
        try:
            serial_key = getpass.getpass("Enter serial key: ")
        except (EOFError, KeyboardInterrupt):
            raise RuntimeError("Interactive input failed or was cancelled")
    # V2 requires signature - prompt if not available
    if not signature:
        try:
            signature = input("Signature: ").strip()
        except (EOFError, KeyboardInterrupt):
            raise RuntimeError("Interactive input failed or was cancelled")
    return username, serial_key, signature


def cmd_detect(args):
    """Detect objects in image"""
    if not DETECTOR_AVAILABLE:
        print(f"{Colors.RED}Detector not available in this build{Colors.END}")
        return 1
    # Get credentials with error handling
    try:
        username, serial_key, signature = get_credentials(args)
    except Exception as e:
        print(f"{Colors.RED}Error getting credentials: {str(e)}{Colors.END}")
        return 1
    if not username or not serial_key:
        print(f"{Colors.RED}Error: License credentials required{Colors.END}")
        return 1
    # Check if image exists
    if not os.path.exists(args.image):
        print(f"{Colors.RED}Error: Image not found: {args.image}{Colors.END}")
        return 1
    try:
        # Show execution mode
        execution_mode = get_execution_mode()
        print(f"{Colors.BLUE}Execution: {execution_mode}{Colors.END}")

        # Create detector (automatically validates, downloads, decrypts, loads model)
        print(f"{Colors.BLUE}Loading {args.model} model with {args.backend} backend...{Colors.END}")
        try:
            detector = ma_road_object_detector(
                model_name=args.model,
                user_name=username,
                serial_key=serial_key,
                signature=signature,
                backend=args.backend,
                conf_thres=args.confidence,
                iou_thres=0.5
            )
            print(f"{Colors.GREEN}Model loaded successfully!{Colors.END}")
        except ValueError as e:
            print(f"{Colors.RED}Error: {str(e)}{Colors.END}")
            return 1
        except Exception as e:
            print(f"{Colors.RED}Error initializing detector: {str(e)}{Colors.END}")
            return 1
        # Load image
        image = cv2.imread(args.image)
        if image is None:
            print(f"{Colors.RED}Error: Failed to load image{Colors.END}")
            return 1
        # Detect
        print(f"{Colors.BLUE}Detecting objects...{Colors.END}")
        result = detector.detector(image)

        # Extract results from ANPR-style format
        detections = result.get('results', [])
        detection_time = result.get('ltrb_proc_sec', 0.0)

        # Display results
        if detections and len(detections) > 0:
            print(f"\n{Colors.GREEN}Found {len(detections)} objects (in {detection_time:.3f}s):{Colors.END}")
            for det in detections:
                print(f"  - {det.get('class', 'unknown')} - confidence: {det.get('ltrb_conf', 0)}")
                print(f"    ltrb: {det.get('ltrb', [])}")
        else:
            print(f"{Colors.YELLOW}No objects detected (in {detection_time:.3f}s){Colors.END}")
            return 0

        # Save output if requested
        if args.output and detections:
            # Draw detections
            for det in detections:
                ltrb = det.get('ltrb', [])
                if len(ltrb) == 4:
                    x1, y1, x2, y2 = map(int, ltrb)
                    color = (0, 255, 0)  # Green
                    cv2.rectangle(image, (x1, y1), (x2, y2), color, 2)
                    label = f"{det.get('class', 'unknown')}: {det.get('ltrb_conf', 0)}"
                    cv2.putText(image, label, (x1, y1-10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
            cv2.imwrite(args.output, image)
            print(f"\n{Colors.GREEN}Output saved to: {args.output}{Colors.END}")
        return 0
    except Exception as e:
        print(f"{Colors.RED}Error: {str(e)}{Colors.END}")
        return 1


def cmd_config(args):
    """Configure license securely"""
    if args.show:
        # Load credentials from environment/env file
        credentials = load_credentials()
        if not credentials:
            print(f"{Colors.YELLOW}No credentials configured{Colors.END}")
            print(f"\nRun 'ma-robj config' to configure your license")
            return 1
        username = credentials.get('user_name', '')
        serial_key = credentials.get('serial_key', '')
        signature = credentials.get('signature', '')
        source = credentials.get('source', 'unknown')
        print(f"Current configuration (source: {source}):")
        print(f"  Username: {username}")
        if serial_key:
            masked_key = serial_key[:4] + '*' * (len(serial_key) - 8) + serial_key[-4:]
            print(f"  Serial Key: {masked_key}")
        else:
            print("  Serial Key: (not set)")
        if signature:
            print(f"  Signature: {signature}")
        else:
            print("  Signature: (not set)")
        return 0
    # Set new config
    print("Configure MareArts Road Objects license (V2)")
    print("(Press Ctrl+C to cancel)\n")
    try:
        username = input("Username: ")
        serial_key = getpass.getpass("Serial Key: ")
        signature = input("Signature: ").strip()
        # Signature is required for V2
        if not signature:
            print(f"{Colors.RED}Error: Signature is required for V2 licenses{Colors.END}")
            return 1
        # Validate before saving
        print(f"{Colors.BLUE}Validating license...{Colors.END}")
        is_valid, _, _ = validate_user_key_with_signature(username, serial_key, signature)
        if not is_valid:
            print(f"{Colors.RED}Error: Invalid license{Colors.END}")
            return 1
        # Save to ~/.marearts_env
        env_file = secure_save_env_file(username, serial_key, signature)
        print(f"{Colors.GREEN}License configured successfully!{Colors.END}")
        print(f"Credentials saved to: {env_file}")
        print(f"\n{Colors.BLUE}To use in current shell:{Colors.END}")
        print(f"  source {env_file}")
        print(f"\n{Colors.BLUE}To use automatically (add to ~/.bashrc or ~/.zshrc):{Colors.END}")
        print(f"  echo 'source {env_file}' >> ~/.bashrc")
        return 0
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Configuration cancelled{Colors.END}")
        return 1


def cmd_validate(args):
    """Validate license from saved configuration (read-only)"""
    # Load credentials from file/env only - do NOT prompt
    credentials = load_credentials()
    if not credentials:
        print(f"{Colors.RED}No credentials configured{Colors.END}")
        print(f"\nPlease run 'ma-robj config' to configure your license first")
        return 1

    username = credentials.get('user_name')
    serial_key = credentials.get('serial_key')
    signature = credentials.get('signature')

    if not username or not serial_key:
        print(f"{Colors.RED}Incomplete credentials in configuration{Colors.END}")
        print(f"\nPlease run 'ma-robj config' to reconfigure your license")
        return 1

    # Validate license and get dates
    try:
        is_valid, start_date, end_date = validate_user_key_with_signature(username, serial_key, signature)
        if is_valid:
            print(f"{Colors.GREEN}✓ License is valid!{Colors.END}")
            if start_date and end_date:
                print(f"\n{Colors.BLUE}License Period:{Colors.END}")
                print(f"  Start Date: {start_date}")
                print(f"  End Date:   {end_date}")
            return 0
        else:
            print(f"{Colors.RED}✗ License is invalid{Colors.END}")
            return 1
    except Exception as e:
        print(f"{Colors.RED}Error validating license: {str(e)}{Colors.END}")
        return 1


def cmd_gpu_info(args):
    """Show GPU acceleration information"""
    try:
        if not GPU_SUPPORT_AVAILABLE:
            print(f"{Colors.YELLOW}GPU support functions not available (build mode){Colors.END}")
            return 1
        all_providers = get_all_providers()
        gpu_providers = get_gpu_providers()
        print(f"{Colors.BLUE}ONNX Runtime GPU Information{Colors.END}")
        print("=" * 40)
        print(f"\n{Colors.GREEN}All Available Providers:{Colors.END}")
        for provider in all_providers:
            if provider in gpu_providers:
                print(f"  🚀 {provider} (GPU)")
            else:
                print(f"  ⚡ {provider}")
        if gpu_providers:
            print(f"\n{Colors.GREEN}GPU Acceleration: ENABLED{Colors.END}")
            print(f"Available GPU providers: {len(gpu_providers)}")
            for provider in gpu_providers:
                gpu_type = "NVIDIA" if "CUDA" in provider or "Tensorrt" in provider else \
                          "DirectML" if "Dml" in provider else \
                          "Intel" if "OpenVINO" in provider else "Unknown"
                print(f"  • {provider} ({gpu_type})")
        else:
            print(f"\n{Colors.YELLOW}GPU Acceleration: NOT AVAILABLE{Colors.END}")
            print("Only CPU execution will be used.")
            print("\nTo enable GPU acceleration, reinstall with GPU support:")
            print(f"  {Colors.GREEN}# For NVIDIA GPUs (Linux/Windows):{Colors.END}")
            print("    pip install marearts-road-objects[gpu]")
            print(f"  {Colors.GREEN}# For DirectML (Windows):{Colors.END}")
            print("    pip install marearts-road-objects[directml]")
            print(f"  {Colors.GREEN}# For all GPU support:{Colors.END}")
            print("    pip install marearts-road-objects[all-gpu]")
            print(f"\n  {Colors.BLUE}Or manually install:{Colors.END}")
            print("    pip install onnxruntime-gpu  # NVIDIA")
            print("    pip install onnxruntime-directml  # Windows DirectML")
        return 0
    except Exception as e:
        print(f"{Colors.RED}Error checking GPU info: {str(e)}{Colors.END}")
        return 1


def cmd_version(args):
    """Show version information"""
    try:
        from ._version import __version__
        print(f"{Colors.GREEN}MareArts Road Objects Detection{Colors.END}")
        print(f"Version: {__version__}")
        return 0
    except Exception as e:
        print(f"{Colors.RED}Error getting version: {str(e)}{Colors.END}")
        return 1


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='MareArts Road Objects Detection CLI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Getting Started:
  1. Configure your license:
     marearts-robj config  (or: ma-robj config)

  2. Run detection (models download automatically on first use):
     marearts-robj detect image.jpg

Available Commands:
  config      Configure and save license credentials
  validate    Validate your license
  detect      Detect road objects in images (models auto-download)
  gpu-info    Show available GPU acceleration
  version     Show package version

Command Aliases:
  marearts-robj, marearts-road-objects, ma-robj  (all work the same)

License Configuration:
  - V2 License requires: username, serial_key, and signature
  - Credentials saved to: ~/.marearts/.marearts_env
  - Auto-loads from environment or config file

  Setup steps:
    1. Run: ma-robj config
    2. Enter credentials when prompted
    3. Source in current shell: source ~/.marearts/.marearts_env
    4. (Optional) Auto-load: echo 'source ~/.marearts/.marearts_env' >> ~/.bashrc

Model Download:
  - Models download automatically when detector is initialized
  - Cached in ~/.marearts/marearts_robj_data/ directory
  - No manual download command needed
  - Supports: small_fp32, medium_fp32, large_fp32

Examples:
  \033[90m# First-time setup\033[0m
  \033[96mma-robj config\033[0m
  \033[96mma-robj validate\033[0m

  \033[90m# Basic detection (uses small_fp32, auto backend, downloads if needed)\033[0m
  \033[96mma-robj detect traffic.jpg\033[0m

  \033[90m# Detection with output image\033[0m
  \033[96mma-robj detect traffic.jpg -o result.jpg\033[0m

  \033[90m# Use specific model size (downloads automatically if not cached)\033[0m
  \033[96mma-robj detect image.jpg --model large_fp32\033[0m

  \033[90m# Use GPU acceleration\033[0m
  \033[96mma-robj detect image.jpg --backend cuda\033[0m

  \033[90m# Custom confidence threshold\033[0m
  \033[96mma-robj detect image.jpg -c 0.7\033[0m

  \033[90m# Check GPU support\033[0m
  \033[96mma-robj gpu-info\033[0m

  \033[90m# Show current config\033[0m
  \033[96mma-robj config --show\033[0m
""")
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    # Detect command
    detect_parser = subparsers.add_parser('detect', help='Detect objects in image')
    detect_parser.add_argument('image', help='Path to input image')
    detect_parser.add_argument('-m', '--model', default='small_fp32',
                              choices=['small_fp32', 'medium_fp32', 'large_fp32'],
                              help='Model size (default: small_fp32)')
    detect_parser.add_argument('-b', '--backend', default='auto',
                              choices=['auto', 'cpu', 'cuda', 'directml'],
                              help='Backend (default: auto - tries cuda→directml→cpu)')
    detect_parser.add_argument('-c', '--confidence', type=float, default=0.5,
                              help='Confidence threshold (default: 0.5)')
    detect_parser.add_argument('-o', '--output', help='Path to save output image')
    detect_parser.add_argument('--username', help='License username (insecure)')
    detect_parser.add_argument('--serial-key', help='License serial key (insecure)')
    # Config command
    config_parser = subparsers.add_parser('config', help='Configure license')
    config_parser.add_argument('--show', action='store_true',
                              help='Show current configuration')
    # Validate command
    validate_parser = subparsers.add_parser('validate', help='Validate saved license configuration')
    # GPU info command
    gpu_parser = subparsers.add_parser('gpu-info', help='Show GPU acceleration information')
    # Version command
    version_parser = subparsers.add_parser('version', help='Show version information')
    # Parse arguments
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return 0
    # Execute command
    commands = {
        'detect': cmd_detect,
        'config': cmd_config,
        'validate': cmd_validate,
        'gpu-info': cmd_gpu_info,
        'version': cmd_version,
    }
    return commands[args.command](args)
if __name__ == '__main__':
    sys.exit(main())

