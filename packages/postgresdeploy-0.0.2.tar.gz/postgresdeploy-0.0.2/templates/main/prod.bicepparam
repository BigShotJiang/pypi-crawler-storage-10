using 'main.bicep'

param functionAppName = ''
param rgManagedIdentityName = ''
param generalKeyVaultName = ''
param generalKeyVaultRG = ''
param functionAppOperationalDays = '1111111'
param functionAppOperationalHours = 'all'
param envKeyVaultName = ''
param envKeyVaultSecretOfficerUserIds = ['525a5f23-f060-48f0-8908-6f3d51e4e384','644e53ec-c867-49ef-98c1-741c7c3a3985']
