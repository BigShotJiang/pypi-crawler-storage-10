from dramatiq.brokers.stub import StubBroker
from dramatiq.brokers.stub import _StubMessageProxy


class EagerBroker(StubBroker):
    def __init__(self, middleware, *args, fail_fast=True, **kwargs):
        super().__init__(middleware, *args, **kwargs)

        self.fail_fast = fail_fast

    def process_message(self, message):
        try:
            # Ensure middlewares are executed
            self.emit_before("process_message", message)

            actor = self.get_actor(message.actor_name)
            result = actor(*message.args, **message.kwargs)

            self.emit_after("process_message", message, result=result)
        except BaseException as e:
            if self.fail_fast:
                raise

            message.stuff_exception(e)
            self.emit_after("process_message", message, exception=e)
        finally:
            self.post_process_message(message)

        return message

    def enqueue(self, message, *, delay=None):
        return self.process_message(_StubMessageProxy(message))

    def post_process_message(self, message):
        # message.failed is set by the Retries middlware.
        # nack'ing a message in case of a failure is necessary so that the results
        # middleware stores the exception.
        if message.failed:
            self.emit_after("nack", message)
        else:
            self.emit_after("ack", message)
