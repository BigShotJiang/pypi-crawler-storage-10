__version__ = "0.3.0"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
