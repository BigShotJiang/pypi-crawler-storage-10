
from .component import QueryDecomposition
