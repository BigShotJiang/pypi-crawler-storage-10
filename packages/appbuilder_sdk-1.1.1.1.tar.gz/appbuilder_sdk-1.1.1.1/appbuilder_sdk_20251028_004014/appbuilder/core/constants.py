# Copyright (c) 2023 Baidu, Inc. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

SECRET_KEY_PREFIX = "Bearer"

GATEWAY_URL = "https://appbuilder.baidu.com"
GATEWAY_INNER_URL = "http://appbuilder.sdns.baidu.com"

GATEWAY_URL_V2 = "https://qianfan.baidubce.com"
CONSOLE_OPENAPI_VERSION = "/v2"
CONSOLE_OPENAPI_PREFIX = ""

MAX_DOCUMENTS_NUM = 800
SUPPORTED_FILE_TYPE = ["txt", "pdf", "doc", "docx"]

COMPONENT_SUPPORT_FILE_NUMBER = 10