# timber/common/services/security/oauth_service.py
"""
Core OAuth 2.0 Authorization Server and Resource Protector Service.

This service works with FastAPI by creating OAuth2Request objects directly.
"""
from authlib.oauth2.rfc6749 import AuthorizationServer 
from authlib.oauth2.rfc6749 import ResourceProtector
from authlib.oauth2.rfc6749 import grants
from authlib.oauth2.rfc6749.resource_protector import TokenValidator
from authlib.oauth2.rfc7636 import CodeChallenge
from authlib.common.security import generate_token
from datetime import datetime, timedelta, timezone 
from typing import Optional, Dict, Any, List
import uuid
import logging

from common.models.registry import model_registry
from common.services.db_service import db_service

logger = logging.getLogger(__name__)

# --- Helper to get models from registry ---
def _get_model(name: str):
    """Retrieves a model class from the application's registry."""
    model = model_registry.get_model(name)
    if not model:
        logger.error(f"OAuth Model '{name}' not found in registry.")
    return model


# --- Create OAuth2Request wrapper for FastAPI/Starlette ---

class PayloadObject:
    """
    Object wrapper for form data to provide attribute access.
    
    Authlib expects request.payload.grant_type (attribute access),
    not request.payload['grant_type'] (dict access).
    
    Authlib also expects request.payload.data.get("key") for optional params.
    """
    
    def __init__(self, form_data):
        self._data = dict(form_data) if form_data else {}
        # Store form data as object attributes for Authlib
        for key, value in self._data.items():
            setattr(self, key, value)
    
    @property
    def data(self):
        """Return the underlying dict - Authlib uses payload.data.get("key")"""
        return self._data
    
    def get(self, key, default=None):
        """Dict-like get method for compatibility."""
        return self._data.get(key, default)
    
    def __getitem__(self, key):
        """Dict-like item access for compatibility."""
        return self._data[key]
    
    def __contains__(self, key):
        """Dict-like 'in' operator for compatibility."""
        return key in self._data
    
    @property
    def datalist(self):
        """Return data as dict for validation."""
        # For validation that checks multiple values
        return {k: [v] for k, v in self._data.items()}


class StarletteOAuth2Request:
    """
    OAuth2Request wrapper for Starlette/FastAPI Request objects.
    
    This class wraps a Starlette Request and provides the interface
    that Authlib expects for OAuth2 request handling.
    
    CRITICAL: Authlib expects:
    - request.payload (form data as object with attribute access)
    - request.args (query params as dict)
    - request.form (form data as dict)
    - request.data (form data as dict)
    """
    
    def __init__(self, request):
        self._request = request
        self._form_data = None
        self._payload = None
        
    async def _load_form(self):
        """Load form data asynchronously if not already loaded."""
        if self._form_data is None:
            self._form_data = dict(await self._request.form())
            self._payload = PayloadObject(self._form_data)
        return self._form_data
    
    @property
    def payload(self):
        """
        Form data as object with attribute access.
        
        CRITICAL: Authlib's base.py expects request.payload.grant_type
        This MUST be an object with attributes, not a dict.
        """
        if self._payload is None:
            # If form hasn't been loaded yet, we need to do it synchronously
            # This happens when Authlib accesses payload before we've parsed the form
            import asyncio
            if self._form_data is None:
                # Try to get the event loop
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # We're in an async context but payload is accessed synchronously
                        # This shouldn't happen, but if it does, raise a clear error
                        raise RuntimeError(
                            "Form data not loaded. Call await request._load_form() before accessing payload."
                        )
                    else:
                        # Load it synchronously
                        self._form_data = dict(loop.run_until_complete(self._request.form()))
                        self._payload = PayloadObject(self._form_data)
                except RuntimeError:
                    # No event loop, create one
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    self._form_data = dict(loop.run_until_complete(self._request.form()))
                    self._payload = PayloadObject(self._form_data)
                    loop.close()
        return self._payload
    
    @property
    def args(self):
        """Query parameters as dict - Authlib expects this."""
        return dict(self._request.query_params)
    
    @property
    def form(self):
        """Form data as dict - needed for client authentication."""
        if self._form_data is None:
            return {}
        return self._form_data
    
    @property
    def data(self):
        """Form data as dict - alternative to form."""
        if self._form_data is None:
            return {}
        return self._form_data
    
    @property
    def method(self):
        """HTTP method."""
        return self._request.method
    
    @property
    def url(self):
        """Request URL as string."""
        return str(self._request.url)
    
    @property
    def headers(self):
        """Request headers."""
        return self._request.headers
    
    @property
    def client_id(self):
        """Get client_id from form data."""
        if self._form_data:
            return self._form_data.get('client_id')
        return None
    
    @property
    def grant_type(self):
        """Get grant_type from form data."""
        if self._form_data:
            return self._form_data.get('grant_type')
        return None
    
    def __getattr__(self, name):
        """Delegate other attribute access to the wrapped request."""
        return getattr(self._request, name)


# --- Custom Subclass for Core Authlib Integration ---
class ModularAuthorizationServer(AuthorizationServer):
    """
    Subclassing the generic Authlib AuthorizationServer to implement the 
    mandatory query_client and save_token methods using the persistence layer.
    
    Also implements create_oauth2_request for FastAPI/Starlette compatibility.
    """
    
    def query_client(self, client_id: str):
        """Implements the mandatory client query for Authlib."""
        OAuth2Client = _get_model('OAuth2Client')
        if not OAuth2Client:
            return None
        
        with db_service.session_scope() as session:
            client = session.query(OAuth2Client).filter_by(client_id=client_id).first()
            if client:
                session.expunge(client)
            return client

    def save_token(self, token_data: Dict[str, Any], request: Any):
        """Implements the mandatory token saving for Authlib."""
        OAuth2Token = _get_model('OAuth2Token')
        if not OAuth2Token:
            return

        user_id = getattr(request, 'user', None) and request.user.id or "client_only"

        try:
            # FIX: Manually calculate and supply issued_at/expires_at
            issued_at = datetime.now(timezone.utc)
            expires_in = token_data['expires_in']
            expires_at = issued_at + timedelta(seconds=expires_in)
            
            with db_service.session_scope() as session:
                token = OAuth2Token(
                    user_id=user_id,
                    client_id=request.client.client_id,
                    token_type=token_data['token_type'],
                    access_token=token_data['access_token'],
                    refresh_token=token_data.get('refresh_token'),
                    scope=token_data['scope'],
                    expires_in=expires_in,
                    issued_at=issued_at,
                    expires_at=expires_at 
                )
                session.add(token)
        except Exception as e:
            logger.error(f"Failed to save OAuth token: {e}")

    def create_oauth2_request(self, request):
        """
        Convert FastAPI/Starlette Request to an object Authlib can use.
        
        This should only be called with an already-wrapped StarletteOAuth2Request
        that has form data pre-loaded. For initial wrapping, use create_oauth2_request_async.
        """
        # If it's already wrapped, just return it
        if isinstance(request, StarletteOAuth2Request):
            return request
        # Otherwise create a new wrapper (but form data won't be loaded yet)
        return StarletteOAuth2Request(request)
    
    async def create_oauth2_request_async(self, request):
        """
        Async method to create and pre-load the OAuth2 request wrapper.
        
        Call this from your FastAPI endpoints before passing to create_token_response.
        """
        wrapped = StarletteOAuth2Request(request)
        await wrapped._load_form()
        return wrapped


# --- Token Validator for Resource Protection ---
class MyTokenValidator(TokenValidator):
    
    def _to_aware_utc(self, dt: datetime) -> datetime:
        """Helper to force offset-naive datetimes to be timezone-aware UTC."""
        if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    def _is_token_expired(self, token: Any) -> bool:
        """Utility to check expiry based on DB columns, since method is missing."""
        if not hasattr(token, 'expires_at') or token.expires_at is None:
            return False 
            
        # FIX 2: Ensure comparison is between two timezone-aware datetimes
        token_expiry_aware = self._to_aware_utc(token.expires_at)
        return datetime.now(timezone.utc) > token_expiry_aware

    def authenticate_token(self, token_string: str):
        """Authenticates an access token from the database."""
        OAuth2Token = _get_model('OAuth2Token')
        if not OAuth2Token: return None
            
        with db_service.session_scope() as session:
            token = session.query(OAuth2Token).filter_by(access_token=token_string).first()
            
            if token and not self._is_token_expired(token):
                session.expunge(token) 
                return token
            return None

    def request_invalid(self, request: Any):
        return False 

    def token_expired(self, token: Any):
        """Checks if the token has expired. Relies on model's logic."""
        # FIX 2: Use internal method to check expiry
        return self._is_token_expired(token)

    def scope_insufficient(self, token: Any, scope: str):
        if not scope: return False
        token_scopes = set(token.scope.split())
        required_scopes = set(scope.split())
        return not token_scopes.issuperset(required_scopes)

# --- OAuth Grant Type Implementations ---

class MyAuthorizationCodeGrant(grants.AuthorizationCodeGrant):
    
    def _to_aware_utc(self, dt: datetime) -> datetime:
        """Helper to force offset-naive datetimes to be timezone-aware UTC."""
        if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)

    def _is_code_expired(self, auth_code: Any) -> bool:
        """Utility to check Auth Code expiry based on DB columns."""
        if not hasattr(auth_code, 'expires_at') or auth_code.expires_at is None:
            return True 
            
        # FIX 2: Ensure comparison is between two timezone-aware datetimes
        code_expiry_aware = self._to_aware_utc(auth_code.expires_at)
        return datetime.now(timezone.utc) > code_expiry_aware

    def save_authorization_code(self, code: str, request: Any):
        """Saves the authorization code and associated request data."""
        OAuth2AuthorizationCode = _get_model('OAuth2AuthorizationCode')
        if not OAuth2AuthorizationCode:
            raise Exception("Authorization Code Model not available.")
            
        issued_at = datetime.now(timezone.utc)
        expires_at = issued_at + timedelta(minutes=5) # Auth Code standard expiry
        
        with db_service.session_scope() as session:
            auth_code = OAuth2AuthorizationCode(
                user_id=request.user.id,
                client_id=request.client.client_id, 
                code=code,
                redirect_uri=request.redirect_uri,
                scope=request.scope,
                issued_at=issued_at,
                expires_at=expires_at 
            )
            session.add(auth_code)
            
            # FIX: Expunge object before returning it to the test/Authlib for later use
            session.flush()
            session.expunge(auth_code)
            
            return auth_code

    def query_authorization_code(self, code: str, client: Any):
        """Retrieves an authorization code from the database."""
        OAuth2AuthorizationCode = _get_model('OAuth2AuthorizationCode')
        if not OAuth2AuthorizationCode: return None
            
        with db_service.session_scope() as session:
            auth_code = session.query(OAuth2AuthorizationCode).filter_by(
                code=code, client_id=client.client_id).first() 
                
            if auth_code and not self._is_code_expired(auth_code):
                session.expunge(auth_code) 
                return auth_code
            return None

    def delete_authorization_code(self, authorization_code: Any):
        OAuth2AuthorizationCode = _get_model('OAuth2AuthorizationCode')
        if not OAuth2AuthorizationCode: return
        with db_service.session_scope() as session:
            session.delete(session.merge(authorization_code))

    def authenticate_user(self, authorization_code: Any):
        User = _get_model('User')
        if not User: return None
        with db_service.session_scope() as session:
            user = session.query(User).get(authorization_code.user_id)
            if user: session.expunge(user) 
            return user


class MyPasswordGrant(grants.ResourceOwnerPasswordCredentialsGrant):
    """
    Password Grant (Resource Owner Password Credentials Grant).
    
    This grant type allows the client to exchange a username and password
    directly for an access token. It should only be used by trusted clients.
    
    Supports multiple client authentication methods:
    - client_secret_basic: Client credentials in Authorization header
    - client_secret_post: Client credentials in request body
    - none: Public clients (no authentication)
    """
    
    # CRITICAL: Support multiple authentication methods for web and mobile clients
    # client_secret_basic: For server-to-server (credentials in Authorization header)
    # client_secret_post: For web apps (credentials in POST body with username/password)
    # none: For public clients like mobile apps or SPAs
    TOKEN_ENDPOINT_AUTH_METHODS = ['client_secret_basic', 'client_secret_post', 'none']
    
    def authenticate_user(self, username: str, password: str):
        """
        Authenticate a user by username (email) and password.
        
        Args:
            username: User's email address
            password: User's plain-text password
            
        Returns:
            User object if authentication succeeds, None otherwise
        """
        User = _get_model('User')
        if not User:
            logger.error("User model not found in registry")
            return None
        
        try:
            with db_service.session_scope() as session:
                # Find user by email
                user = session.query(User).filter_by(email=username).first()
                
                if not user:
                    logger.warning(f"Password grant: User not found: {username}")
                    return None
                
                # Check if user is active
                if not user.is_active:
                    logger.warning(f"Password grant: User not active: {username}")
                    return None
                
                # Verify password
                if not user.check_password(password):
                    logger.warning(f"Password grant: Invalid password for user: {username}")
                    return None
                
                # Update last login
                user.update_last_login()
                session.flush()
                
                # Expunge to avoid detached instance issues
                session.expunge(user)
                
                logger.info(f"Password grant: User authenticated successfully: {username}")
                return user
                
        except Exception as e:
            logger.error(f"Password grant authentication error: {e}", exc_info=True)
            return None
        
        
class MyRefreshTokenGrant(grants.RefreshTokenGrant):
    
    def _is_refresh_token_active(self, token: Any) -> bool:
        """Utility to check refresh token validity (simple, based on access token expiry)."""
        # FIX: Access the token validator via the server object
        validator = self.server.resource_protector.get_token_validator(token.token_type)
        return not validator._is_token_expired(token)

    def authenticate_refresh_token(self, refresh_token: str):
        """Authenticates the refresh token from the database."""
        OAuth2Token = _get_model('OAuth2Token')
        if not OAuth2Token: return None
            
        with db_service.session_scope() as session:
            token = session.query(OAuth2Token).filter_by(refresh_token=refresh_token).first()
            
            # FIX: Use internal method
            if token and self._is_refresh_token_active(token): 
                session.expunge(token) 
                return token
            return None

    def create_access_token(self, token: Any, client: Any, request: Any):
        OAuth2Token = _get_model('OAuth2Token')
        if not OAuth2Token: return None
            
        with db_service.session_scope() as session:
            old_token = session.merge(token)
            session.delete(old_token)
            
            issued_at = datetime.now(timezone.utc)
            expires_at = issued_at + timedelta(seconds=3600)
            
            new_token = OAuth2Token(
                user_id=token.user_id,
                client_id=client.client_id,
                token_type=token.token_type,
                scope=request.scope,
                access_token=str(uuid.uuid4()), 
                refresh_token=str(uuid.uuid4()), 
                expires_in=3600,
                issued_at=issued_at,
                expires_at=expires_at
            )
            session.add(new_token)
            session.expunge(new_token) 
            return new_token


class MyClientCredentialsGrant(grants.ClientCredentialsGrant):
    def authenticate_client(self, client: Any):
        return client 

    def create_access_token(self, client: Any, request: Any):
        OAuth2Token = _get_model('OAuth2Token')
        if not OAuth2Token: return None
            
        with db_service.session_scope() as session:
            issued_at = datetime.now(timezone.utc)
            expires_at = issued_at + timedelta(seconds=3600)
            
            new_token = OAuth2Token(
                user_id="client_only", 
                client_id=client.client_id,
                token_type='bearer',
                scope=request.scope,
                access_token=str(uuid.uuid4()),
                expires_in=3600,
                issued_at=issued_at,
                expires_at=expires_at
            )
            session.add(new_token)
            session.expunge(new_token) 
            return new_token

# --- Core Service Objects ---

authorization = ModularAuthorizationServer()
resource_protector = ResourceProtector() 

# --- Initialization Function (Simplified for library use) ---

def init_oauth_service():
    """
    Initializes the core OAuth server logic.
    """
    logger.info("Initializing core OAuth service objects (Framework-Agnostic).")
    
    # Register Grant Types
    authorization.register_grant(MyAuthorizationCodeGrant, [CodeChallenge(required=False)]) 
    authorization.register_grant(MyPasswordGrant)
    authorization.register_grant(MyRefreshTokenGrant)
    authorization.register_grant(MyClientCredentialsGrant)
    
    # Register the validator explicitly
    resource_protector.register_token_validator(MyTokenValidator())
    
    # Attach resource protector instance to the authorization server instance
    authorization.resource_protector = resource_protector 
    
    logger.info("OAuth service initialized with Authorization Code, Password, Refresh, and Client Credentials grants.")

# Call the initialization function immediately to set up the grants
init_oauth_service()


__all__ = [
    'authorization',
    'resource_protector',
    'init_oauth_service',
    'MyAuthorizationCodeGrant',
    'MyPasswordGrant',
    'MyRefreshTokenGrant',
    '_get_model', 
]