## ::: base.AxeBase

## ::: base.AxeResults

## ::: sync_playwright.Axe

## ::: async_playwright.Axe
