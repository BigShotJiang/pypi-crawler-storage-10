# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs as SteadyCalculationOutputsModel
from dnv_bladed_models.velocity_range import VelocityRange
from dnv_bladed_models.velocity_range import VelocityRange as VelocityRangeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SteadyPowerCurveCalculation(SteadyCalculation):
    r"""
    Defines a calculation which produces power, torque and thrust as a function of wind speed, assuming a uniform steady wind field.  The entire turbine is modelled for this analysis and prebend and sweep included, but without any flexibility.  Most realities such as tower shadow and wind shear are ignored.
    
    Not supported yet.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['SteadyPowerCurve'], default='SteadyPowerCurve', Not supported yet
        Defines the specific type of SteadyCalculation model in use.  For a `SteadyPowerCurve` object, this must always be set to a value of `SteadyPowerCurve`.
    
    WindSpeedRange : VelocityRange
    
    CalculateSpeedAndPitchChange : bool, Not supported yet
        If true, the pitch and speed change schedule will be calculated by Bladed.
    
    PitchAngle : float, Not supported yet
        The pitch angle of all of the turbine blades to be considered for the calculation.
    
    RotorSpeed : float, Not supported yet
        The rotor speed to be considered for the calculation.
    
    Outputs : SteadyCalculationOutputs
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    SteadyCalculationType: Literal['SteadyPowerCurve'] = Field(alias="SteadyCalculationType", default='SteadyPowerCurve', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `SteadyPowerCurve` object, this must always be set to a value of `SteadyPowerCurve`.

    *Not supported yet*

    - default = 'SteadyPowerCurve'
    """

    WindSpeedRange: VelocityRangeModel = Field(alias="WindSpeedRange", default=None)
    r"""
    """

    CalculateSpeedAndPitchChange: bool = Field(alias="CalculateSpeedAndPitchChange", default=None) # Not supported yet
    r"""
    If true, the pitch and speed change schedule will be calculated by Bladed.

    *Not supported yet*

    """

    PitchAngle: float = Field(alias="PitchAngle", default=None) # Not supported yet
    r"""
    The pitch angle of all of the turbine blades to be considered for the calculation.

    *Not supported yet*

    """

    RotorSpeed: float = Field(alias="RotorSpeed", default=None) # Not supported yet
    r"""
    The rotor speed to be considered for the calculation.

    *Not supported yet*

    """

    Outputs: SteadyCalculationOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/SteadyPowerCurveCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(SteadyCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SteadyPowerCurveCalculation.model_rebuild()
