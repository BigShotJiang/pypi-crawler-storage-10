# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation
from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation as CampbellDiagramModeOfOperationModel
from dnv_bladed_models.velocity_range import VelocityRange
from dnv_bladed_models.velocity_range import VelocityRange as VelocityRangeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CampbellPowerProduction(CampbellDiagramModeOfOperation):
    r"""
    The properties for generating a Campbell diagram for a turbine in power production mode.  This will use the steady-state operating parameters defined in the TurbineOperationalParameters section to determine the operating point for the specified wind speeds.
    
    Attributes
    ----------
    CampbellDiagramModeOfOperationType : Literal['PowerProduction'], default='PowerProduction'
        Defines the specific type of CampbellDiagramModeOfOperation model in use.  For a `PowerProduction` object, this must always be set to a value of `PowerProduction`.
    
    WindSpeedRange : VelocityRange
    
    Notes
    -----
    
    """

    CampbellDiagramModeOfOperationType: Literal['PowerProduction'] = Field(alias="CampbellDiagramModeOfOperationType", default='PowerProduction', frozen=True) # type: ignore
    r"""
    Defines the specific type of CampbellDiagramModeOfOperation model in use.  For a `PowerProduction` object, this must always be set to a value of `PowerProduction`.
    - default = 'PowerProduction'
    """

    WindSpeedRange: VelocityRangeModel = Field(alias="WindSpeedRange", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/CampbellDiagramModeOfOperation/CampbellPowerProduction.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'CampbellDiagramModeOfOperationType').merge(CampbellDiagramModeOfOperation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CampbellPowerProduction.model_rebuild()
