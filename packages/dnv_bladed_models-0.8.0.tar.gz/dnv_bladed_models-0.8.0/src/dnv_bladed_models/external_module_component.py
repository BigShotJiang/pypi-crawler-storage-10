# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from dnv_bladed_models.external_module_component_connectable_nodes import ExternalModuleComponentConnectableNodes
from dnv_bladed_models.external_module_component_connectable_nodes import ExternalModuleComponentConnectableNodes as ExternalModuleComponentConnectableNodesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExternalModuleComponent(Component):
    r"""
    A specialised External Module component.  This is in the form of an external library (a dynamic link library on Windows, or a shared object on Linux).  This acts as a component in the Bladed assembly, and creates multibody objects to attach to the previous component.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentType : Literal['ExternalModuleComponent'], default='ExternalModuleComponent', Not supported yet
        Defines the specific type of Component model in use.  For a `ExternalModuleComponent` object, this must always be set to a value of `ExternalModuleComponent`.
    
    Filepath : str, Not supported yet
        The absolute filepath to the dynamic linked library (Windows) or the shared object (Linux).
    
    ParametersAsString : str, Not supported yet
        A string that will be passed to the external module.
    
    ParametersAsJson : Dict[str, Any], Not supported yet
        A JSON object that will be serialised as a string and passed to the external module.
    
    ConnectableNodes : ExternalModuleComponentConnectableNodes, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentType: Literal['ExternalModuleComponent'] = Field(alias="ComponentType", default='ExternalModuleComponent', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `ExternalModuleComponent` object, this must always be set to a value of `ExternalModuleComponent`.

    *Not supported yet*

    - default = 'ExternalModuleComponent'
    """

    Filepath: str = Field(alias="Filepath", default=None) # Not supported yet
    r"""
    The absolute filepath to the dynamic linked library (Windows) or the shared object (Linux).

    *Not supported yet*

    """

    ParametersAsString: str = Field(alias="ParametersAsString", default=None) # Not supported yet
    r"""
    A string that will be passed to the external module.

    *Not supported yet*

    """

    ParametersAsJson: Dict[str, Any] = Field(alias="ParametersAsJson", default=None) # Not supported yet
    r"""
    A JSON object that will be serialised as a string and passed to the external module.

    *Not supported yet*

    """

    ConnectableNodes: ExternalModuleComponentConnectableNodesModel = Field(alias="ConnectableNodes", default_factory=ExternalModuleComponentConnectableNodes) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/ExternalModuleComponent/ExternalModuleComponent.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['ConnectableNodes', ]), 'ComponentType').merge(Component._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExternalModuleComponent.model_rebuild()
