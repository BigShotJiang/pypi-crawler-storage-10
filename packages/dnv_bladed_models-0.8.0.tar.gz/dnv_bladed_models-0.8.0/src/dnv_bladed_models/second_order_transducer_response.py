# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.transducer_behaviour import TransducerBehaviour
from dnv_bladed_models.transducer_behaviour import TransducerBehaviour as TransducerBehaviourModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SecondOrderTransducerResponse(TransducerBehaviour):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    TransducerBehaviourType : Literal['SecondOrderTransducerResponse'], default='SecondOrderTransducerResponse', Not supported yet
        Defines the specific type of TransducerBehaviour model in use.  For a `SecondOrderTransducerResponse` object, this must always be set to a value of `SecondOrderTransducerResponse`.
    
    Frequency : float, default=6.28318530717959, Not supported yet
        The angular frequency of oscillation of response.
    
    Damping : float, default=0.8, Not supported yet
        The fraction of critical damping.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TransducerBehaviourType: Literal['SecondOrderTransducerResponse'] = Field(alias="TransducerBehaviourType", default='SecondOrderTransducerResponse', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of TransducerBehaviour model in use.  For a `SecondOrderTransducerResponse` object, this must always be set to a value of `SecondOrderTransducerResponse`.

    *Not supported yet*

    - default = 'SecondOrderTransducerResponse'
    """

    Frequency: float = Field(alias="Frequency", default=None) # Not supported yet
    r"""
    The angular frequency of oscillation of response.

    *Not supported yet*

    - default = 6.28318530717959
    """

    Damping: float = Field(alias="Damping", default=None) # Not supported yet
    r"""
    The fraction of critical damping.

    *Not supported yet*

    - default = 0.8
    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/common/SecondOrderTransducerResponse.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'TransducerBehaviourType').merge(TransducerBehaviour._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SecondOrderTransducerResponse.model_rebuild()
