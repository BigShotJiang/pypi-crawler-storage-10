# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Earthquake(BladedModel):
    r"""
    The definition of a seismic event, or earthquake.
    
    Not supported yet.
    
    Attributes
    ----------
    QuakeFilepath : str, Not supported yet
        The filepath or URI providing a time history of the earthquake accelerations.
    
    StartTime : float, Not supported yet
        The time into the simulation at which the earthquake begins (excluding the lead-in time).
    
    DirectionClockwiseFromNorth : float, Not supported yet
        The angle to the global x-axis that the accelerations in the file will be applied in.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    QuakeFilepath: str = Field(alias="QuakeFilepath", default=None) # Not supported yet
    r"""
    The filepath or URI providing a time history of the earthquake accelerations.

    *Not supported yet*

    """

    StartTime: float = Field(alias="StartTime", default=None) # Not supported yet
    r"""
    The time into the simulation at which the earthquake begins (excluding the lead-in time).

    *Not supported yet*

    """

    DirectionClockwiseFromNorth: float = Field(alias="DirectionClockwiseFromNorth", default=None) # Not supported yet
    r"""
    The angle to the global x-axis that the accelerations in the file will be applied in.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Earthquake/Earthquake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Earthquake.model_rebuild()
