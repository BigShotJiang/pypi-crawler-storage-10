# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs as SteadyCalculationOutputsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class AerodynamicInformationCalculation(SteadyCalculation):
    r"""
    Defines a calculation which produces the aerodynamic parameters of the rotor in a steady flow, including local aerodynamic loading at each blade station.  The rotor is modelled as being completely rigid in this calculation, without prebend and sweep.  The rotor is analysed in isolation without any influence from the rest of the turbine structure.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['AerodynamicInformation'], default='AerodynamicInformation'
        Defines the specific type of SteadyCalculation model in use.  For a `AerodynamicInformation` object, this must always be set to a value of `AerodynamicInformation`.
    
    HubWindSpeed : float
        The wind speed at hub height.
    
    PitchAngle : float
        The pitch angle of all of the blades on the rotor or rotors.
    
    RotorSpeed : float
        The rotor speed to model during the calculation.
    
    Outputs : SteadyCalculationOutputs
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['AerodynamicInformation'] = Field(alias="SteadyCalculationType", default='AerodynamicInformation', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `AerodynamicInformation` object, this must always be set to a value of `AerodynamicInformation`.
    - default = 'AerodynamicInformation'
    """

    HubWindSpeed: float = Field(alias="HubWindSpeed", default=None)
    r"""
    The wind speed at hub height.
    """

    PitchAngle: float = Field(alias="PitchAngle", default=None)
    r"""
    The pitch angle of all of the blades on the rotor or rotors.
    """

    RotorSpeed: float = Field(alias="RotorSpeed", default=None)
    r"""
    The rotor speed to model during the calculation.
    """

    Outputs: SteadyCalculationOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/AerodynamicInformationCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(SteadyCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


AerodynamicInformationCalculation.model_rebuild()
