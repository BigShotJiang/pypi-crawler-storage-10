# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.transducer_faults import TransducerFaults
from dnv_bladed_models.transducer_faults import TransducerFaults as TransducerFaultsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TransducerFaultsMoment(TransducerFaults):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/SignalPropertiesMoment/TransducerFaultsMoment/TransducerFaultsMoment.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(TransducerFaults._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TransducerFaultsMoment.model_rebuild()
