# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.tower_can_cross_section_properties import TowerCanCrossSectionProperties
from dnv_bladed_models.tower_can_cross_section_properties import TowerCanCrossSectionProperties as TowerCanCrossSectionPropertiesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerCanPropertiesByMaterial(TowerCanCrossSectionProperties):
    r"""
    The definition of a can cross-section where the material properties, the diameter, and the wall thickness will be used to calculate the structural properties.  Any properties which are omitted will be taken from the BaseCrossSection definition.
    
    Attributes
    ----------
    WallThickness : float
        The wall thickness of the can.
    
    Notes
    -----
    
    """

    WallThickness: float = Field(alias="WallThickness", default=None)
    r"""
    The wall thickness of the can.
    """

    _relative_schema_path: str = 'Components/Tower/TowerCan/TowerCanPropertiesByMaterial/TowerCanPropertiesByMaterial.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(TowerCanCrossSectionProperties._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerCanPropertiesByMaterial.model_rebuild()
