# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.shaft_input_torque_vs_resisting_torque import ShaftInputTorqueVsResistingTorque
from dnv_bladed_models.shaft_input_torque_vs_resisting_torque import ShaftInputTorqueVsResistingTorque as ShaftInputTorqueVsResistingTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ShaftSpeedVsShaftInputTorqueVsResistingTorque(BladedModel):
    r"""
    A line or row in a look-up table, specifying a value of ResistingTorque for a specified ShaftSpeed.
    
    Attributes
    ----------
    ShaftSpeed : float
        The rotational velocity of the low speed shaft.
    
    ShaftInputTorqueVsResistingTorque : List[ShaftInputTorqueVsResistingTorque]
        The torque acting in opposition to the shaft's rotation.
    
    Notes
    -----
    
    """

    ShaftSpeed: float = Field(alias="ShaftSpeed", default=None)
    r"""
    The rotational velocity of the low speed shaft.
    """

    ShaftInputTorqueVsResistingTorque: List[ShaftInputTorqueVsResistingTorqueModel] = Field(alias="ShaftInputTorqueVsResistingTorque", default_factory=list)
    r"""
    The torque acting in opposition to the shaft's rotation.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/MechanicalLosses/ShaftSpeedVsShaftInputTorqueVsResistingTorque/ShaftSpeedVsShaftInputTorqueVsResistingTorque.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['ShaftInputTorqueVsResistingTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ShaftSpeedVsShaftInputTorqueVsResistingTorque.model_rebuild()
