# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.wind_shear import WindShear
from dnv_bladed_models.wind_shear import WindShear as WindShearModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExponentialShearModel(WindShear):
    r"""
    The wind shear to apply to the wind field.  This will vary according to the wind shear model selected.
    
    Attributes
    ----------
    WindShearType : Literal['ExponentialShearModel'], default='ExponentialShearModel'
        Defines the specific type of WindShear model in use.  For a `ExponentialShearModel` object, this must always be set to a value of `ExponentialShearModel`.
    
    ShearExponent : float
        The exponential factor governing the shape of the wind shear variation.
    
    Notes
    -----
    
    """

    WindShearType: Literal['ExponentialShearModel'] = Field(alias="WindShearType", default='ExponentialShearModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of WindShear model in use.  For a `ExponentialShearModel` object, this must always be set to a value of `ExponentialShearModel`.
    - default = 'ExponentialShearModel'
    """

    ShearExponent: float = Field(alias="ShearExponent", default=None)
    r"""
    The exponential factor governing the shape of the wind shear variation.
    """

    _relative_schema_path: str = 'common/ExponentialShearModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'WindShearType').merge(WindShear._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExponentialShearModel.model_rebuild()
