# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.first_order_position_response import FirstOrderPositionResponse
from dnv_bladed_models.first_order_position_response import FirstOrderPositionResponse as FirstOrderPositionResponseModel
from dnv_bladed_models.first_order_rate_response import FirstOrderRateResponse
from dnv_bladed_models.first_order_rate_response import FirstOrderRateResponse as FirstOrderRateResponseModel
from dnv_bladed_models.immediate_position_response import ImmediatePositionResponse
from dnv_bladed_models.immediate_position_response import ImmediatePositionResponse as ImmediatePositionResponseModel
from dnv_bladed_models.immediate_rate_response import ImmediateRateResponse
from dnv_bladed_models.immediate_rate_response import ImmediateRateResponse as ImmediateRateResponseModel
from dnv_bladed_models.proportional_integral_deriviative_for_position import ProportionalIntegralDeriviativeForPosition
from dnv_bladed_models.proportional_integral_deriviative_for_position import ProportionalIntegralDeriviativeForPosition as ProportionalIntegralDeriviativeForPositionModel
from dnv_bladed_models.proportional_integral_deriviative_for_rate import ProportionalIntegralDeriviativeForRate
from dnv_bladed_models.proportional_integral_deriviative_for_rate import ProportionalIntegralDeriviativeForRate as ProportionalIntegralDeriviativeForRateModel
from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand
from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand as ResponseToPositionDemandModel
from dnv_bladed_models.response_to_position_demand_insert import ResponseToPositionDemandInsert
from dnv_bladed_models.response_to_position_demand_insert import ResponseToPositionDemandInsert as ResponseToPositionDemandInsertModel
from dnv_bladed_models.response_to_rate_demand import ResponseToRateDemand
from dnv_bladed_models.response_to_rate_demand import ResponseToRateDemand as ResponseToRateDemandModel
from dnv_bladed_models.response_to_rate_demand_insert import ResponseToRateDemandInsert
from dnv_bladed_models.response_to_rate_demand_insert import ResponseToRateDemandInsert as ResponseToRateDemandInsertModel
from dnv_bladed_models.second_order_position_response import SecondOrderPositionResponse
from dnv_bladed_models.second_order_position_response import SecondOrderPositionResponse as SecondOrderPositionResponseModel
from dnv_bladed_models.second_order_rate_response import SecondOrderRateResponse
from dnv_bladed_models.second_order_rate_response import SecondOrderRateResponse as SecondOrderRateResponseModel
from .schema_helper import SchemaHelper
from .base_entity import *

TResponseToPositionDemandOptions = TypeVar('TResponseToPositionDemandOptions', FirstOrderPositionResponse, ImmediatePositionResponse, ResponseToPositionDemandInsert, ProportionalIntegralDeriviativeForPosition, SecondOrderPositionResponse, ResponseToPositionDemand, )
TResponseToRateDemandOptions = TypeVar('TResponseToRateDemandOptions', FirstOrderRateResponse, ImmediateRateResponse, ResponseToRateDemandInsert, ProportionalIntegralDeriviativeForRate, SecondOrderRateResponse, ResponseToRateDemand, )



class PitchSystemDemand(BladedModel):
    r"""
    The common properties of the pitch and rate demand responses.
    
    Attributes
    ----------
    ResponseToPositionDemand : Union[FirstOrderPositionResponse, ImmediatePositionResponse, ResponseToPositionDemandInsert, ProportionalIntegralDeriviativeForPosition, SecondOrderPositionResponse]
    
    ResponseToRateDemand : Union[FirstOrderRateResponse, ImmediateRateResponse, ResponseToRateDemandInsert, ProportionalIntegralDeriviativeForRate, SecondOrderRateResponse]
    
    Notes
    -----
    
    """

    ResponseToPositionDemand: Union[FirstOrderPositionResponseModel, ImmediatePositionResponseModel, ResponseToPositionDemandInsertModel, ProportionalIntegralDeriviativeForPositionModel, SecondOrderPositionResponseModel] = Field(alias="ResponseToPositionDemand", default=None, discriminator='ResponseToPositionDemandType')
    r"""
    """

    ResponseToRateDemand: Union[FirstOrderRateResponseModel, ImmediateRateResponseModel, ResponseToRateDemandInsertModel, ProportionalIntegralDeriviativeForRateModel, SecondOrderRateResponseModel] = Field(alias="ResponseToRateDemand", default=None, discriminator='ResponseToRateDemandType')
    r"""
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSystemDemand/PitchSystemDemand.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([('ResponseToPositionDemand', 'ResponseToPositionDemandType'),('ResponseToRateDemand', 'ResponseToRateDemandType'),]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    @property
    def ResponseToPositionDemand_as_FirstOrderPositionResponse(self) -> FirstOrderPositionResponse:
        """
        Retrieves the value of ResponseToPositionDemand guaranteeing it is a FirstOrderPositionResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        FirstOrderPositionResponse
            A model object, guaranteed to be a FirstOrderPositionResponse.

        Raises
        ------
        TypeError
            If the value is not a FirstOrderPositionResponse.
        """
        return self.ResponseToPositionDemand_as(FirstOrderPositionResponse)


    @property
    def ResponseToPositionDemand_as_ImmediatePositionResponse(self) -> ImmediatePositionResponse:
        """
        Retrieves the value of ResponseToPositionDemand guaranteeing it is a ImmediatePositionResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ImmediatePositionResponse
            A model object, guaranteed to be a ImmediatePositionResponse.

        Raises
        ------
        TypeError
            If the value is not a ImmediatePositionResponse.
        """
        return self.ResponseToPositionDemand_as(ImmediatePositionResponse)


    @property
    def ResponseToPositionDemand_as_ProportionalIntegralDeriviativeForPosition(self) -> ProportionalIntegralDeriviativeForPosition:
        """
        Retrieves the value of ResponseToPositionDemand guaranteeing it is a ProportionalIntegralDeriviativeForPosition; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ProportionalIntegralDeriviativeForPosition
            A model object, guaranteed to be a ProportionalIntegralDeriviativeForPosition.

        Raises
        ------
        TypeError
            If the value is not a ProportionalIntegralDeriviativeForPosition.
        """
        return self.ResponseToPositionDemand_as(ProportionalIntegralDeriviativeForPosition)


    @property
    def ResponseToPositionDemand_as_SecondOrderPositionResponse(self) -> SecondOrderPositionResponse:
        """
        Retrieves the value of ResponseToPositionDemand guaranteeing it is a SecondOrderPositionResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SecondOrderPositionResponse
            A model object, guaranteed to be a SecondOrderPositionResponse.

        Raises
        ------
        TypeError
            If the value is not a SecondOrderPositionResponse.
        """
        return self.ResponseToPositionDemand_as(SecondOrderPositionResponse)


    @property
    def ResponseToPositionDemand_as_inline(self) -> Union[FirstOrderPositionResponse, ImmediatePositionResponse, ProportionalIntegralDeriviativeForPosition, SecondOrderPositionResponse]:
        """
        Retrieves the value of ResponseToPositionDemand as a model object; if the value is specified with a '$insert', an error is raised.

        Returns
        -------
        Union[FirstOrderPositionResponse, ImmediatePositionResponse, ProportionalIntegralDeriviativeForPosition, SecondOrderPositionResponse]
            A model object at the specified index, guaranteed to not be a '$insert'.

        Raises
        ------
        TypeError
            If the value is not one of the concrete types of ResponseToPositionDemand; i.e. it is specified with a '$insert'.
        """
        if isinstance(self.ResponseToPositionDemand, ResponseToPositionDemandInsert) or self.ResponseToPositionDemand.is_insert:
            raise TypeError(f"Expected ResponseToPositionDemand value to be an in-line object, but it is currently in the '$insert' state.")
        return self.ResponseToPositionDemand


    def ResponseToPositionDemand_as(self, cls: Type[TResponseToPositionDemandOptions])-> TResponseToPositionDemandOptions:
        """
        Retrieves the value of ResponseToPositionDemand, ensuring it is of the specified type.
        The specified type must be one of the valid concrete types of ResponseToPositionDemand, or the '$insert' type
        (in the case the model is defined to be inserted from an external resource).

        Useful when using type-checking development tools, as it provides a concise way to access a value with the correct type.

        Parameters
        ----------
        cls: Type[Union[FirstOrderPositionResponse, ImmediatePositionResponse, ResponseToPositionDemandInsert, ProportionalIntegralDeriviativeForPosition, SecondOrderPositionResponse]]
            One of the valid concrete types of ResponseToPositionDemand, or the '$insert' type
            (in the case the model is defined to be inserted from an external resource).

        Returns
        -------
        TResponseToPositionDemandOptions
            A model object of the specified type.

        Raises
        ------
        TypeError
            If the value is not of the specified type.

        Examples
        --------
        Get a reference to the value when it is one of the types of ResponseToPositionDemand:
        >>> val_obj = model_obj.ResponseToPositionDemand_as(models.FirstOrderPositionResponse)
        >>> val_obj = model_obj.ResponseToPositionDemand_as(models.ImmediatePositionResponse)
        >>> val_obj = model_obj.ResponseToPositionDemand_as(models.ProportionalIntegralDeriviativeForPosition)
        >>> val_obj = model_obj.ResponseToPositionDemand_as(models.SecondOrderPositionResponse)

        Get a reference to the value, when it was specified with a '$insert' and read in from a file:
        >>> insert_obj = model_obj.ResponseToPositionDemand_as(models.ResponseToPositionDemandInsert)
        """
        if not isinstance(self.ResponseToPositionDemand, cls):
            raise TypeError(f"Expected ResponseToPositionDemand of type '{cls.__name__}' but was type '{type(self.ResponseToPositionDemand).__name__}'")
        return self.ResponseToPositionDemand


    @property
    def ResponseToRateDemand_as_FirstOrderRateResponse(self) -> FirstOrderRateResponse:
        """
        Retrieves the value of ResponseToRateDemand guaranteeing it is a FirstOrderRateResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        FirstOrderRateResponse
            A model object, guaranteed to be a FirstOrderRateResponse.

        Raises
        ------
        TypeError
            If the value is not a FirstOrderRateResponse.
        """
        return self.ResponseToRateDemand_as(FirstOrderRateResponse)


    @property
    def ResponseToRateDemand_as_ImmediateRateResponse(self) -> ImmediateRateResponse:
        """
        Retrieves the value of ResponseToRateDemand guaranteeing it is a ImmediateRateResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ImmediateRateResponse
            A model object, guaranteed to be a ImmediateRateResponse.

        Raises
        ------
        TypeError
            If the value is not a ImmediateRateResponse.
        """
        return self.ResponseToRateDemand_as(ImmediateRateResponse)


    @property
    def ResponseToRateDemand_as_ProportionalIntegralDeriviativeForRate(self) -> ProportionalIntegralDeriviativeForRate:
        """
        Retrieves the value of ResponseToRateDemand guaranteeing it is a ProportionalIntegralDeriviativeForRate; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ProportionalIntegralDeriviativeForRate
            A model object, guaranteed to be a ProportionalIntegralDeriviativeForRate.

        Raises
        ------
        TypeError
            If the value is not a ProportionalIntegralDeriviativeForRate.
        """
        return self.ResponseToRateDemand_as(ProportionalIntegralDeriviativeForRate)


    @property
    def ResponseToRateDemand_as_SecondOrderRateResponse(self) -> SecondOrderRateResponse:
        """
        Retrieves the value of ResponseToRateDemand guaranteeing it is a SecondOrderRateResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SecondOrderRateResponse
            A model object, guaranteed to be a SecondOrderRateResponse.

        Raises
        ------
        TypeError
            If the value is not a SecondOrderRateResponse.
        """
        return self.ResponseToRateDemand_as(SecondOrderRateResponse)


    @property
    def ResponseToRateDemand_as_inline(self) -> Union[FirstOrderRateResponse, ImmediateRateResponse, ProportionalIntegralDeriviativeForRate, SecondOrderRateResponse]:
        """
        Retrieves the value of ResponseToRateDemand as a model object; if the value is specified with a '$insert', an error is raised.

        Returns
        -------
        Union[FirstOrderRateResponse, ImmediateRateResponse, ProportionalIntegralDeriviativeForRate, SecondOrderRateResponse]
            A model object at the specified index, guaranteed to not be a '$insert'.

        Raises
        ------
        TypeError
            If the value is not one of the concrete types of ResponseToRateDemand; i.e. it is specified with a '$insert'.
        """
        if isinstance(self.ResponseToRateDemand, ResponseToRateDemandInsert) or self.ResponseToRateDemand.is_insert:
            raise TypeError(f"Expected ResponseToRateDemand value to be an in-line object, but it is currently in the '$insert' state.")
        return self.ResponseToRateDemand


    def ResponseToRateDemand_as(self, cls: Type[TResponseToRateDemandOptions])-> TResponseToRateDemandOptions:
        """
        Retrieves the value of ResponseToRateDemand, ensuring it is of the specified type.
        The specified type must be one of the valid concrete types of ResponseToRateDemand, or the '$insert' type
        (in the case the model is defined to be inserted from an external resource).

        Useful when using type-checking development tools, as it provides a concise way to access a value with the correct type.

        Parameters
        ----------
        cls: Type[Union[FirstOrderRateResponse, ImmediateRateResponse, ResponseToRateDemandInsert, ProportionalIntegralDeriviativeForRate, SecondOrderRateResponse]]
            One of the valid concrete types of ResponseToRateDemand, or the '$insert' type
            (in the case the model is defined to be inserted from an external resource).

        Returns
        -------
        TResponseToRateDemandOptions
            A model object of the specified type.

        Raises
        ------
        TypeError
            If the value is not of the specified type.

        Examples
        --------
        Get a reference to the value when it is one of the types of ResponseToRateDemand:
        >>> val_obj = model_obj.ResponseToRateDemand_as(models.FirstOrderRateResponse)
        >>> val_obj = model_obj.ResponseToRateDemand_as(models.ImmediateRateResponse)
        >>> val_obj = model_obj.ResponseToRateDemand_as(models.ProportionalIntegralDeriviativeForRate)
        >>> val_obj = model_obj.ResponseToRateDemand_as(models.SecondOrderRateResponse)

        Get a reference to the value, when it was specified with a '$insert' and read in from a file:
        >>> insert_obj = model_obj.ResponseToRateDemand_as(models.ResponseToRateDemandInsert)
        """
        if not isinstance(self.ResponseToRateDemand, cls):
            raise TypeError(f"Expected ResponseToRateDemand of type '{cls.__name__}' but was type '{type(self.ResponseToRateDemand).__name__}'")
        return self.ResponseToRateDemand


    def _entity(self) -> bool:
        return True


PitchSystemDemand.model_rebuild()
