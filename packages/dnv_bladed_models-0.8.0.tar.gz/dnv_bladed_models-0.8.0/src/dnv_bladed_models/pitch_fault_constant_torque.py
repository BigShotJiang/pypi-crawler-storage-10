# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_fault import PitchFault
from dnv_bladed_models.pitch_fault import PitchFault as PitchFaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchFaultConstantTorque(PitchFault):
    r"""
    A fault in a single pitch system where the actuator applies a constant torque over the bearing.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['PitchFaultConstantTorque'], default='PitchFaultConstantTorque', Not supported yet
        Defines the specific type of Event model in use.  For a `PitchFaultConstantTorque` object, this must always be set to a value of `PitchFaultConstantTorque`.
    
    FaultPitchTorque : float, Not supported yet
        The torque which will be applied after the fault occurs.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['PitchFaultConstantTorque'] = Field(alias="EventType", default='PitchFaultConstantTorque', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `PitchFaultConstantTorque` object, this must always be set to a value of `PitchFaultConstantTorque`.

    *Not supported yet*

    - default = 'PitchFaultConstantTorque'
    """

    FaultPitchTorque: float = Field(alias="FaultPitchTorque", default=None) # Not supported yet
    r"""
    The torque which will be applied after the fault occurs.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/PitchFaultConstantTorque.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(PitchFault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchFaultConstantTorque.model_rebuild()
