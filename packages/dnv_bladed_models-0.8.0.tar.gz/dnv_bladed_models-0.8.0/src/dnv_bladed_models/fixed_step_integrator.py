# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.integrator import Integrator
from dnv_bladed_models.integrator import Integrator as IntegratorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FixedStepIntegrator(Integrator, ABC):
    r"""
    Common settings for the fixed step integrators.
    
    Attributes
    ----------
    TimeStep : float, default=0.005
        The fixed time step used by the integrator.  It must be set as a divisor of the output time-step and external controller communication interval.
    
    Tolerance : float, default=0.005
        When the \"Maximum number of iterations\" > 1, the integrator relative tolerance is used to control how many iterations are carried out when integrating the first order and prescribed second order states.  Iterations are carried out until the maximum number of iterations is reached, or until the change in all first order and prescribed state derivatives between successive iterations is less than the relative tolerance multiplied by the state derivative absolute value.
    
    Notes
    -----
    
    """

    TimeStep: float = Field(alias="TimeStep", default=None)
    r"""
    The fixed time step used by the integrator.  It must be set as a divisor of the output time-step and external controller communication interval.
    - default = 0.005
    """

    Tolerance: float = Field(alias="Tolerance", default=None)
    r"""
    When the \"Maximum number of iterations\" > 1, the integrator relative tolerance is used to control how many iterations are carried out when integrating the first order and prescribed second order states.  Iterations are carried out until the maximum number of iterations is reached, or until the change in all first order and prescribed state derivatives between successive iterations is less than the relative tolerance multiplied by the state derivative absolute value.
    - default = 0.005
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Integrator._type_info)

FixedStepIntegrator.model_rebuild()
