# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_fault import PitchFault
from dnv_bladed_models.pitch_fault import PitchFault as PitchFaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchFaultConstantRate(PitchFault):
    r"""
    A fault in a single pitch system where the pitch system moves at a constant rate until it reaches an end stop or the safety system intervenes.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['PitchFaultConstantRate'], default='PitchFaultConstantRate', Not supported yet
        Defines the specific type of Event model in use.  For a `PitchFaultConstantRate` object, this must always be set to a value of `PitchFaultConstantRate`.
    
    FaultPitchRate : float, Not supported yet
        The rate at which the pitch system will move until it reaches an end stop.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['PitchFaultConstantRate'] = Field(alias="EventType", default='PitchFaultConstantRate', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `PitchFaultConstantRate` object, this must always be set to a value of `PitchFaultConstantRate`.

    *Not supported yet*

    - default = 'PitchFaultConstantRate'
    """

    FaultPitchRate: float = Field(alias="FaultPitchRate", default=None) # Not supported yet
    r"""
    The rate at which the pitch system will move until it reaches an end stop.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/PitchFaultConstantRate.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(PitchFault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchFaultConstantRate.model_rebuild()
