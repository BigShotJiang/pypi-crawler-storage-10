# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.height_vs_shear_factor import HeightVsShearFactor
from dnv_bladed_models.height_vs_shear_factor import HeightVsShearFactor as HeightVsShearFactorModel
from dnv_bladed_models.wind_shear import WindShear
from dnv_bladed_models.wind_shear import WindShear as WindShearModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LookUpShearModel(WindShear):
    r"""
    The wind shear to apply to the wind field.
    
    Attributes
    ----------
    WindShearType : Literal['LookUpShearModel'], default='LookUpShearModel'
        Defines the specific type of WindShear model in use.  For a `LookUpShearModel` object, this must always be set to a value of `LookUpShearModel`.
    
    HeightVsShearFactor : List[HeightVsShearFactor]
        A series of height vs shear factors, including a point at the reference height (above which normal flow begins) and 0.0 (ground level).
    
    Notes
    -----
    
    """

    WindShearType: Literal['LookUpShearModel'] = Field(alias="WindShearType", default='LookUpShearModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of WindShear model in use.  For a `LookUpShearModel` object, this must always be set to a value of `LookUpShearModel`.
    - default = 'LookUpShearModel'
    """

    HeightVsShearFactor: List[HeightVsShearFactorModel] = Field(alias="HeightVsShearFactor", default_factory=list)
    r"""
    A series of height vs shear factors, including a point at the reference height (above which normal flow begins) and 0.0 (ground level).
    """

    _relative_schema_path: str = 'common/LookUpShearModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['HeightVsShearFactor',]), 'WindShearType').merge(WindShear._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LookUpShearModel.model_rebuild()
