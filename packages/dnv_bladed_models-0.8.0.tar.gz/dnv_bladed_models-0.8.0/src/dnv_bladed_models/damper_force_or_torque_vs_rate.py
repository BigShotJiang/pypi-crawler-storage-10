# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class DamperForceOrTorqueVsRate(BladedModel):
    r"""
    A line or row in a look-up table, specifying a value of Rate for a specified DamperForceOrTorque.
    
    Not supported yet.
    
    Attributes
    ----------
    DamperForceOrTorque : float, Not supported yet
        The torque or linear force applied by the damper for the corresponding rate.
    
    Rate : float, Not supported yet
        The rate of the pitch bearing for which the torque or linear force will apply.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    DamperForceOrTorque: float = Field(alias="DamperForceOrTorque", default=None) # Not supported yet
    r"""
    The torque or linear force applied by the damper for the corresponding rate.

    *Not supported yet*

    """

    Rate: float = Field(alias="Rate", default=None) # Not supported yet
    r"""
    The rate of the pitch bearing for which the torque or linear force will apply.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSafetySystem/DamperForceOrTorqueVsRate/DamperForceOrTorqueVsRate.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


DamperForceOrTorqueVsRate.model_rebuild()
