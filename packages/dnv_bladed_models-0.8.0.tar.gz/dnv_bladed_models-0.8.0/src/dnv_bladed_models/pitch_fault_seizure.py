# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_fault import PitchFault
from dnv_bladed_models.pitch_fault import PitchFault as PitchFaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchFaultSeizure(PitchFault):
    r"""
    The seizure of a blade's pitch system that occurs at a specified time in the simulation.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['PitchFaultSeizure'], default='PitchFaultSeizure', Not supported yet
        Defines the specific type of Event model in use.  For a `PitchFaultSeizure` object, this must always be set to a value of `PitchFaultSeizure`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['PitchFaultSeizure'] = Field(alias="EventType", default='PitchFaultSeizure', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `PitchFaultSeizure` object, this must always be set to a value of `PitchFaultSeizure`.

    *Not supported yet*

    - default = 'PitchFaultSeizure'
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/PitchFaultSeizure.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(PitchFault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchFaultSeizure.model_rebuild()
