# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.point_on_span import PointOnSpan
from dnv_bladed_models.point_on_span import PointOnSpan as PointOnSpanModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ReferenceCoordinateSystem(BladedModel):
    r"""
    The main coordinate system of the cross-section, from which all other coordinate systems are derived.  If a coordinate system is not specified, it defaults to the ReferenceCoordinateSystem.  Consequently, any coordinate system may serve as the reference coordinate system.
    
    Attributes
    ----------
    Origin : PointOnSpan
    
    ZAxis : Vector3D
    
    RotationAboutReferenceZ : float
        This specifies the ReferenceCoordinateSystem's local Y-axis direction.  A vector specifying the YAxis explicitly can be provided instead, or without either the Y-axis will lie on the component's YZ-plane.
    
    YAxis : Vector3D
    
    Notes
    -----
    
    """

    Origin: PointOnSpanModel = Field(alias="Origin", default=None)
    r"""
    """

    ZAxis: Vector3DModel = Field(alias="ZAxis", default=None)
    r"""
    """

    RotationAboutReferenceZ: float = Field(alias="RotationAboutReferenceZ", default=None)
    r"""
    This specifies the ReferenceCoordinateSystem's local Y-axis direction.  A vector specifying the YAxis explicitly can be provided instead, or without either the Y-axis will lie on the component's YZ-plane.
    """

    YAxis: Vector3DModel = Field(alias="YAxis", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/CoordinateSystems/ReferenceCoordinateSystem/ReferenceCoordinateSystem.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ReferenceCoordinateSystem.model_rebuild()
