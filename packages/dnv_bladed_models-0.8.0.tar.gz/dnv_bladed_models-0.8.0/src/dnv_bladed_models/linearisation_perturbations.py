# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearisationPerturbations(BladedModel, ABC):
    r"""
    The settings to control the number of perturbations and settings to scale the perturbations common to both Campbell Diagrams and Model Linearisation calculations.
    
    Attributes
    ----------
    NumberOfPerturbationPoints : int, default=3
        The number of values that each state gets perturbed to either side of the equilibrium point.  Larger numbers provide more robustness; smaller numbers provide faster analysis and lower memory usage.
    
    AbsoluteTolerancePerturbationMultiplier : float, default=1
        A state with an equilibrium value close to zero will be perturbed by the absolute state tolerance scaled by this multiplier.
    
    StateRelativePerturbation : float, default=0.005
        The magnitude of the state perturbations relative to the absolute steady-state state values
    
    Notes
    -----
    
    """

    NumberOfPerturbationPoints: int = Field(alias="NumberOfPerturbationPoints", default=None)
    r"""
    The number of values that each state gets perturbed to either side of the equilibrium point.  Larger numbers provide more robustness; smaller numbers provide faster analysis and lower memory usage.
    - default = 3
    """

    AbsoluteTolerancePerturbationMultiplier: float = Field(alias="AbsoluteTolerancePerturbationMultiplier", default=None)
    r"""
    A state with an equilibrium value close to zero will be perturbed by the absolute state tolerance scaled by this multiplier.
    - default = 1
    """

    StateRelativePerturbation: float = Field(alias="StateRelativePerturbation", default=None)
    r"""
    The magnitude of the state perturbations relative to the absolute steady-state state values
    - default = 0.005
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

LinearisationPerturbations.model_rebuild()
