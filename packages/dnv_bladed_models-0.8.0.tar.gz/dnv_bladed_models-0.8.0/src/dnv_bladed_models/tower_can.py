# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.tower_can_modelling import TowerCanModelling
from dnv_bladed_models.tower_can_modelling import TowerCanModelling as TowerCanModellingModel
from .schema_helper import SchemaHelper
from .base_entity import *


class TowerCan_TowerCanTypeEnum(str, Enum):
    EXPLICIT_TOWER_CAN = "ExplicitTowerCan"
    SIMPLE_TOWER_CAN = "SimpleTowerCan"
    INSERT = "Insert"



class TowerCan(BladedModel, ABC):
    r"""
    The common properties for a single can in the tower
    
    Attributes
    ----------
    TowerCanType : TowerCan_TowerCanTypeEnum
        Defines the specific type of model in use.
    
    Modelling : TowerCanModelling
    
    CanHeight : float
        The height of the tower can, assuming that it is mounted vertically.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - ExplicitTowerCan
        - TowerCanInsert
        - SimpleTowerCan
    
    """

    TowerCanType: TowerCan_TowerCanTypeEnum = Field(alias="TowerCanType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    Modelling: TowerCanModellingModel = Field(alias="Modelling", default=None)
    r"""
    """

    CanHeight: float = Field(alias="CanHeight", default=None)
    r"""
    The height of the tower can, assuming that it is mounted vertically.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

TowerCan.model_rebuild()
