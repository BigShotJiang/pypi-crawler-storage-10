# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *


class NacelleSensor_NacelleSensorTypeEnum(str, Enum):
    ACCELEROMETER = "Accelerometer"
    INCLINOMETER = "Inclinometer"
    INSERT = "Insert"



class NacelleSensor(BladedModel, ABC):
    r"""
    The common properties of a sensor mounted on the nacelle.  This can be mounted anywhere on the structure.
    
    Attributes
    ----------
    NacelleSensorType : NacelleSensor_NacelleSensorTypeEnum
        Defines the specific type of model in use.
    
    OffsetFromOrigin : Vector3D
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - NacelleAccelerometer
        - NacelleInclinometer
        - NacelleSensorInsert
    
    """

    NacelleSensorType: NacelleSensor_NacelleSensorTypeEnum = Field(alias="NacelleSensorType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    OffsetFromOrigin: Vector3DModel = Field(alias="OffsetFromOrigin", default=None)
    r"""
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

NacelleSensor.model_rebuild()
