# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.structural_mode import StructuralMode
from dnv_bladed_models.structural_mode import StructuralMode as StructuralModeModel
from dnv_bladed_models.structural_modelling import StructuralModelling
from dnv_bladed_models.structural_modelling import StructuralModelling as StructuralModellingModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ModalStructuralModelling(StructuralModelling):
    r"""
    The properties for the structural modelling using modal reduction.
    
    Attributes
    ----------
    StructuralModellingType : Literal['ModalStructuralModelling'], default='ModalStructuralModelling'
        Defines the specific type of StructuralModelling model in use.  For a `ModalStructuralModelling` object, this must always be set to a value of `ModalStructuralModelling`.
    
    StructuralModes : List[StructuralMode]
        List of included modes and their associated damping ratios. The presence of any of these objects in the StructuralModes list indicates that the mode should be calculated, even if it does not include a DampingRatio. If no modes are provided, the structure will be considered rigid. Users can add any metadata alongside the DampingRatio, such as _Name or _Mode. Bladed will disregard any metadata as long as it is prefixed with an underscore.
    
    Notes
    -----
    
    """

    StructuralModellingType: Literal['ModalStructuralModelling'] = Field(alias="StructuralModellingType", default='ModalStructuralModelling', frozen=True) # type: ignore
    r"""
    Defines the specific type of StructuralModelling model in use.  For a `ModalStructuralModelling` object, this must always be set to a value of `ModalStructuralModelling`.
    - default = 'ModalStructuralModelling'
    """

    StructuralModes: List[StructuralModeModel] = Field(alias="StructuralModes", default_factory=list)
    r"""
    List of included modes and their associated damping ratios. The presence of any of these objects in the StructuralModes list indicates that the mode should be calculated, even if it does not include a DampingRatio. If no modes are provided, the structure will be considered rigid. Users can add any metadata alongside the DampingRatio, such as _Name or _Mode. Bladed will disregard any metadata as long as it is prefixed with an underscore.
    """

    _relative_schema_path: str = 'Components/StructuralModelling/ModalStructuralModelling.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['StructuralModes',]), 'StructuralModellingType').merge(StructuralModelling._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ModalStructuralModelling.model_rebuild()
