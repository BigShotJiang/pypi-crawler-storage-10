# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.frequency_vs_spectral_density import FrequencyVsSpectralDensity
from dnv_bladed_models.frequency_vs_spectral_density import FrequencyVsSpectralDensity as FrequencyVsSpectralDensityModel
from dnv_bladed_models.irregular_waves import IrregularWaves
from dnv_bladed_models.irregular_waves import IrregularWaves as IrregularWavesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class UserDefinedWaves(IrregularWaves):
    r"""
    A look-up table for a user-defined wave spectrum.
    
    Not supported yet.
    
    Attributes
    ----------
    WavesType : Literal['UserDefined'], default='UserDefined', Not supported yet
        Defines the specific type of Waves model in use.  For a `UserDefined` object, this must always be set to a value of `UserDefined`.
    
    FrequencyVsSpectralDensity : List[FrequencyVsSpectralDensity], Not supported yet
        List of FrequencyVsSpectralDensity
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    WavesType: Literal['UserDefined'] = Field(alias="WavesType", default='UserDefined', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Waves model in use.  For a `UserDefined` object, this must always be set to a value of `UserDefined`.

    *Not supported yet*

    - default = 'UserDefined'
    """

    FrequencyVsSpectralDensity: List[FrequencyVsSpectralDensityModel] = Field(alias="FrequencyVsSpectralDensity", default_factory=list) # Not supported yet
    r"""
    List of FrequencyVsSpectralDensity

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Waves/UserDefinedWaves.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['FrequencyVsSpectralDensity',]), 'WavesType').merge(IrregularWaves._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


UserDefinedWaves.model_rebuild()
