# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


from dataclasses import dataclass
import json
from typing import Any, Callable, ClassVar, Dict, Generic, Optional, Set, Tuple, Type, TypeVar, Union
from abc import ABC, abstractmethod
from typing_extensions import Self
from pydantic import BaseModel, ModelWrapValidatorHandler, model_validator, PrivateAttr
import pydantic_core
TPydanticModel = TypeVar('TPydanticModel', bound='BaseModel')
TEntity = TypeVar('TEntity', bound='BaseEntity')

@dataclass(frozen=True)
class TypeInfo:
    discriminated_props: set[Tuple[str, str]]
    discriminated_arrays: set[Tuple[str, str]]
    containers: set[str]
    discriminator: Optional[str] = None

    def merge(self, other: 'TypeInfo') -> 'TypeInfo':
        return TypeInfo(
            self.discriminated_props.union(other.discriminated_props),
            self.discriminated_arrays.union(other.discriminated_arrays),
            self.containers.union(other.containers),
            other.discriminator if self.discriminator is None else self.discriminator)


K = TypeVar('K')
V = TypeVar('V')
class ReadOnlyDict(dict, Generic[K, V]):
    def __setitem__(self, key, value):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def __delitem__(self, key):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def clear(self):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def pop(self, *args):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def popitem(self):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def setdefault(self, key, default=None):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")
    
    def update(self, *args, **kwargs):
        raise TypeError("This dictionary is read-only. Use the item accessors on the owning object to update the entries.")


class BaseEntity(BaseModel, ABC):

    _incoming_fields: set[str] = PrivateAttr(default_factory=lambda: set())
    _type_info: ClassVar[TypeInfo] = TypeInfo(set(), set(), set())
   
    @abstractmethod
    def _entity(self) -> bool:
        pass


    @model_validator(mode='before')
    def _remove_underscore_fields(cls, data: Any):
        if isinstance(data, dict):
            remove_underscore_fields(data)
        return data
    
    
    @classmethod
    def _entity_factory(cls, data: Any, handler: ModelWrapValidatorHandler[Self]) -> Self:
        if not isinstance(data, dict):
            return handler(data)
        incoming_keys = set(data.keys())
        prepare_model_dict(cls, data, cls._type_info.discriminated_props, cls._type_info.discriminated_arrays)
        entity = handler(data)
        entity._incoming_fields.update(incoming_keys)
        return entity


    @model_validator(mode='wrap')
    @classmethod
    def _entity_validator(cls, data: Any, handler: ModelWrapValidatorHandler[Self]) -> Self:
        return cls._entity_factory(data, handler)


    @property
    def is_insert(self) -> bool:
        """
        Returns true if the model is to be loaded from an external resource by the Bladed application; i.e. the 'insert' field is set with a resource location.
        """
        if 'insert' in self.__pydantic_fields_set__:
            insert_val = self.__dict__['insert']
            return insert_val is not None and insert_val != ''
        return False

    
    def _find_unused_containers(self) -> Set[str]:
        unused_containers: Set[str] = set()
        for container in self._type_info.containers:
            if container in self.__class__.model_fields:
                container_obj = self.__dict__[container]
                if container_obj is not None and len(container_obj) == 0 and container not in self._incoming_fields:
                    if isinstance(container_obj, BaseEntity):
                        if container_obj._is_unused():
                            unused_containers.add(container)
                    else:
                        unused_containers.add(container)
        return unused_containers


    def _is_unused(self) -> bool:
        """
        Returns true if the model has no user-supplied values. This indicates the object should not be rendered in the final JSON output.
        """
        candidate_fields = [x[1] for x in self.__dict__.items() if x[0] != self.__class__._type_info.discriminator]
        if len(candidate_fields) == 0:
            return True
        for f in candidate_fields:
            if f is None:
                continue
            if isinstance(f, dict) or isinstance(f, list):
                if len(f) > 0:
                    return False
                else:
                    continue
            elif f is not None:
                return False
        return True

    
    def _excluded(self) -> Optional[set[str]]:
        return None if self.is_insert else self._find_unused_containers()
    

    def _included(self) -> Optional[set[str]]:
        return set(['insert']) if self.is_insert else None
    

    @classmethod
    def _is_field_exported(cls, field_name: str, include: Optional[set[str]], exclude: Optional[set[str]]) -> bool:
        return (include is None and exclude is None)\
                or (include is None and exclude is not None and field_name not in exclude)\
                or (include is not None and field_name in include and exclude is None)\
                or (include is not None and field_name in include and exclude is not None and field_name not in exclude)
    

    def _export(self) -> dict[str, Any]:
        output: dict[str, Any] = dict()

        def export_list(l: list[Any]) -> list[Any]:
            output_list: list[Any] = []
            for val in l:
                if isinstance(val, BaseEntity):
                    output_list.append(val._export())
                elif isinstance(val, list):
                    output_list.append(export_list(val))
                elif isinstance(val, dict):
                    output_list.append(export_dict(val))
                else:
                    output_list.append(val)
            return output_list
        
        def export_dict(d: dict) -> dict[str, Any]:
            output_dict: dict[str, Any] = dict()
            for key, val in d.items():
                if isinstance(val, BaseEntity):
                    output_dict[key] = val._export()
                elif isinstance(val, list):
                    output_dict[key] = export_list(val)
                elif isinstance(val, dict):
                    output_dict[key] = export_dict(val)
                else:
                    output_dict[key] = val
            return output_dict

        exclude=self._excluded()
        include=self._included()
        props: list[Tuple[str, Any]] = []
        for name, field in self.__class__.model_fields.items():
            if not field.exclude and name in self.__dict__:
                if self._is_field_exported(name, include, exclude):
                    props.append((field.alias or name, self.__dict__[name]))

        if self.__pydantic_extra__:
            for key, val in self.__pydantic_extra__.items():
                if self._is_field_exported(key, include, exclude):
                    props.append((key, val))

        for (name, val) in props:
            if isinstance(val, BaseEntity):
                output[name] = val._export()
            elif isinstance(val, list):
                output[name] = export_list(val)
            elif isinstance(val, dict):
                output[name] = export_dict(val)
            elif val is not None:
                output[name] = val
        return output


    def to_json(self, indent: Optional[int] = 2) -> str:
        data = self._export()
        return json.dumps(data, indent=indent)

BaseEntity.model_rebuild()

def remove_underscore_fields(values: Dict[str, Any]):
    to_remove: Set[str] = set()
    for child_name, child in values.items():
        if child_name.startswith('_'):
            to_remove.add(child_name)
    for x in to_remove:
        del values[x]


def prepare_dict_for_discriminated_insert(cls, field_name: str, field_obj: dict, discriminator_prop: str):
    if isinstance(field_obj, dict) and '$insert' in field_obj:
        if discriminator_prop in field_obj and field_obj[discriminator_prop] is not None and field_obj['$insert'] is not None:
            error: pydantic_core.InitErrorDetails = {
                # The type: ignore on the next line is to ignore the requirement of LiteralString
                'type': pydantic_core.PydanticCustomError('value_error', f"Cannot set both {discriminator_prop} and $insert fields."),  # type: ignore
                'loc': (field_name,),
                'input': field_obj,
            }
            raise pydantic_core.ValidationError.from_exception_data(cls.__name__, [error])
        field_obj[discriminator_prop] = 'Insert'


def prepare_list_for_discriminated_insert(cls, field_name: str, field_obj: dict, discriminator_prop: str):
    if isinstance(field_obj, list):
        i = 0
        for item in field_obj:
            if isinstance(item, dict) and '$insert' in item:
                if discriminator_prop in item and item[discriminator_prop] is not None and item['$insert'] is not None:
                    error: pydantic_core.InitErrorDetails = {
                        # The type: ignore on the next line is to ignore the requirement of LiteralString
                        'type': pydantic_core.PydanticCustomError('value_error', f"Cannot set both {discriminator_prop} and $insert fields."),  # type: ignore
                        'loc': (f"{field_name}[{i}]",),
                        'input': item,
                    }
                    raise pydantic_core.ValidationError.from_exception_data(cls.__name__, [error])
                item[discriminator_prop] = 'Insert'
            i += 1
    

def prepare_model_dict(cls, data: dict, discriminated_props: set[Tuple[str, str]], discriminated_arrays: set[Tuple[str, str]]) -> dict:
    if any(discriminated_props) or any(discriminated_arrays):
        for field_name, discriminator in discriminated_props:
            if field_name in data:
                prepare_dict_for_discriminated_insert(cls, field_name, data[field_name], discriminator)
        for field_name, discriminator in discriminated_arrays:
            if field_name in data:
                prepare_list_for_discriminated_insert(cls, field_name, data[field_name], discriminator)
    return data


