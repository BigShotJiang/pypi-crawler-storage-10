# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Event_EventTypeEnum(str, Enum):
    CONTROLLER_FAULT = "ControllerFault"
    EMERGENCY_STOP_OPERATION = "EmergencyStopOperation"
    GRID_LOSS = "GridLoss"
    NETWORK_FREQUENCY_DISTURBANCE = "NetworkFrequencyDisturbance"
    NETWORK_VOLTAGE_DISTURBANCE = "NetworkVoltageDisturbance"
    NORMAL_STOP_OPERATION = "NormalStopOperation"
    PERMANENTLY_STUCK_PITCH_SYSTEM = "PermanentlyStuckPitchSystem"
    PITCH_FAULT_CONSTANT_RATE = "PitchFaultConstantRate"
    PITCH_FAULT_CONSTANT_TORQUE = "PitchFaultConstantTorque"
    PITCH_FAULT_LIMP = "PitchFaultLimp"
    PITCH_FAULT_SEIZURE = "PitchFaultSeizure"
    PITCH_FAULT_SEIZURE_AT_ANGLE = "PitchFaultSeizureAtAngle"
    SHORT_CIRCUIT = "ShortCircuit"
    START_UP_OPERATION = "StartUpOperation"
    YAW_FAULT_CONSTANT_RATE = "YawFaultConstantRate"
    YAW_FAULT_CONSTANT_TORQUE = "YawFaultConstantTorque"
    YAW_FAULT_LIMP = "YawFaultLimp"
    YAW_MANOEUVRE = "YawManoeuvre"
    INSERT = "Insert"



class Event(BladedModel, ABC):
    r"""
    An event which may occur during the simulation.  These can either be timed events, or based on a set of conditions which may or may not occur.
    
    Attributes
    ----------
    EventType : Event_EventTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - ControllerFault
        - EmergencyStopOperation
        - GridLoss
        - EventInsert
        - NetworkFrequencyDisturbance
        - NetworkVoltageDisturbance
        - NormalStopOperation
        - PermanentlyStuckPitchSystem
        - PitchFaultConstantRate
        - PitchFaultConstantTorque
        - PitchFaultLimp
        - PitchFaultSeizure
        - PitchFaultSeizureAtAngle
        - ShortCircuit
        - StartUpOperation
        - YawFaultConstantRate
        - YawFaultConstantTorque
        - YawFaultLimp
        - YawManoeuvre
    
    """

    EventType: Event_EventTypeEnum = Field(alias="EventType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

Event.model_rebuild()
