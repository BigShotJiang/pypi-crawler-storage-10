# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.electrical_losses import ElectricalLosses
from dnv_bladed_models.electrical_losses import ElectricalLosses as ElectricalLossesModel
from dnv_bladed_models.input_power_vs_loss import InputPowerVsLoss
from dnv_bladed_models.input_power_vs_loss import InputPowerVsLoss as InputPowerVsLossModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NonLinearElectricalLosses(ElectricalLosses):
    r"""
    An electrical loss model where the losses are related to the power being generated, but is not linearly proportional to it.
    
    Attributes
    ----------
    ElectricalLossesType : Literal['NonLinearElectricalLosses'], default='NonLinearElectricalLosses'
        Defines the specific type of ElectricalLosses model in use.  For a `NonLinearElectricalLosses` object, this must always be set to a value of `NonLinearElectricalLosses`.
    
    InputPowerVsLoss : List[InputPowerVsLoss]
        A list of points in a look-up table specifying the relationship between the power and the corresponding losses.
    
    Notes
    -----
    
    """

    ElectricalLossesType: Literal['NonLinearElectricalLosses'] = Field(alias="ElectricalLossesType", default='NonLinearElectricalLosses', frozen=True) # type: ignore
    r"""
    Defines the specific type of ElectricalLosses model in use.  For a `NonLinearElectricalLosses` object, this must always be set to a value of `NonLinearElectricalLosses`.
    - default = 'NonLinearElectricalLosses'
    """

    InputPowerVsLoss: List[InputPowerVsLossModel] = Field(alias="InputPowerVsLoss", default_factory=list)
    r"""
    A list of points in a look-up table specifying the relationship between the power and the corresponding losses.
    """

    _relative_schema_path: str = 'Components/Generator/ElectricalLosses/NonLinearElectricalLosses.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['InputPowerVsLoss',]), 'ElectricalLossesType').merge(ElectricalLosses._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NonLinearElectricalLosses.model_rebuild()
