# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class ExternalController_CallingConventionEnum(str, Enum):
    CDECL = "__cdecl"
    STDCALL = "__stdcall"

class ExternalController_TimeStepMultiplierEnum(str, Enum):
    EVERY = "Every"
    SECOND = "Second"
    THIRD = "Third"
    FOURTH = "Fourth"
    FIFTH = "Fifth"
    SIXTH = "Sixth"
    SEVENTH = "Seventh"
    EIGTH = "Eigth"
    NINTH = "Ninth"
    TENTH = "Tenth"



class ExternalController(BladedModel):
    r"""
    A definition of a single controller for the turbine.
    
    Attributes
    ----------
    Filepath : str
        The location of the external controller dll.
    
    CallingConvention : ExternalController_CallingConventionEnum, default='__cdecl'
        The calling convention to be used when calling the external controller.  The default for all C-family languages is '__cdecl'.  The default for FORTRAN is '__stdcall' unless the [C] qualifier is specfied immediately after the function name.  Specifying the wrong calling convention can lead to unexplained system exceptions when attempting to call the external controller.
    
    PassParametersByFile : bool, default=False
        If true, a file will be written containing the parameters in the above box.  The location of this file can be obtained in the external controller using the function GetInfileFilepath.  The name of this file will be \"DISCON.IN\" if there is only one controller, or of the pattern \"DISCONn.IN\", where 'n' is the number of the controller.  If not checked (the default), this string will be directly available using the function GetUserParameters.
    
    ForceLegacy : bool, default=False
        If true, only the old-style 'DISCON' function will be looked for in the controller, and raise an error if it cannot be found.  This is only used for testing legacy controllers where both CONTROLLER and DISCON functions are both defined, but the DISCON function is required.
    
    TimeStepMultiplier : ExternalController_TimeStepMultiplierEnum, default='Every'
        Whether the controller should be called on every discrete timestep, set above.
    
    ParametersAsString : str
        A string that will be passed to the external controller.
    
    ParametersAsJson : Dict[str, Any]
        A JSON object that will be serialised as a string and passed to the external controller.
    
    UseFloatingPointProtection : bool, default=True
        If true, this will apply floating point protection when calling the external controllers.  When the protection is on, any floating point errors are trapped and reported.  When this is switched off, the behaviour will default to that of the computer's floating point machine, but this can often be to not report the error, and to use a semi-random (but often very large) number instead of the correct result.  This can lead to unrepeatable results and numeric errors.
    
    Notes
    -----
    
    """

    Filepath: str = Field(alias="Filepath", default=None)
    r"""
    The location of the external controller dll.
    """

    CallingConvention: ExternalController_CallingConventionEnum = Field(alias="CallingConvention", default=None)
    r"""
    The calling convention to be used when calling the external controller.  The default for all C-family languages is '__cdecl'.  The default for FORTRAN is '__stdcall' unless the [C] qualifier is specfied immediately after the function name.  Specifying the wrong calling convention can lead to unexplained system exceptions when attempting to call the external controller.
    - default = '__cdecl'
    """

    PassParametersByFile: bool = Field(alias="PassParametersByFile", default=None)
    r"""
    If true, a file will be written containing the parameters in the above box.  The location of this file can be obtained in the external controller using the function GetInfileFilepath.  The name of this file will be \"DISCON.IN\" if there is only one controller, or of the pattern \"DISCONn.IN\", where 'n' is the number of the controller.  If not checked (the default), this string will be directly available using the function GetUserParameters.
    - default = False
    """

    ForceLegacy: bool = Field(alias="ForceLegacy", default=None)
    r"""
    If true, only the old-style 'DISCON' function will be looked for in the controller, and raise an error if it cannot be found.  This is only used for testing legacy controllers where both CONTROLLER and DISCON functions are both defined, but the DISCON function is required.
    - default = False
    """

    TimeStepMultiplier: ExternalController_TimeStepMultiplierEnum = Field(alias="TimeStepMultiplier", default=None)
    r"""
    Whether the controller should be called on every discrete timestep, set above.
    - default = 'Every'
    """

    ParametersAsString: str = Field(alias="ParametersAsString", default=None)
    r"""
    A string that will be passed to the external controller.
    """

    ParametersAsJson: Dict[str, Any] = Field(alias="ParametersAsJson", default=None)
    r"""
    A JSON object that will be serialised as a string and passed to the external controller.
    """

    UseFloatingPointProtection: bool = Field(alias="UseFloatingPointProtection", default=None)
    r"""
    If true, this will apply floating point protection when calling the external controllers.  When the protection is on, any floating point errors are trapped and reported.  When this is switched off, the behaviour will default to that of the computer's floating point machine, but this can often be to not report the error, and to use a semi-random (but often very large) number instead of the correct result.  This can lead to unrepeatable results and numeric errors.
    - default = True
    """

    _relative_schema_path: str = 'Turbine/BladedControl/ExternalController/ExternalController.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExternalController.model_rebuild()
