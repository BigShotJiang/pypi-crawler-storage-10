# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SlippingClutch(BladedModel):
    r"""
    Slipping clutch model
    
    Attributes
    ----------
    Friction : float
        The friction of the clutch once in motion.
    
    Stiction : float
        The stiction or static friction of the clutch which opposes the initial movement.
    
    HighSpeedShaftInertia : float
        The rotational inertia of the high-speed shaft up to the clutch.  This is only relevant if there is a slipping clutch present, as otherwise it can be considered part of the generator.
    
    Notes
    -----
    
    """

    Friction: float = Field(alias="Friction", default=None)
    r"""
    The friction of the clutch once in motion.
    """

    Stiction: float = Field(alias="Stiction", default=None)
    r"""
    The stiction or static friction of the clutch which opposes the initial movement.
    """

    HighSpeedShaftInertia: float = Field(alias="HighSpeedShaftInertia", default=None)
    r"""
    The rotational inertia of the high-speed shaft up to the clutch.  This is only relevant if there is a slipping clutch present, as otherwise it can be considered part of the generator.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/SlippingClutch/SlippingClutch.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SlippingClutch.model_rebuild()
