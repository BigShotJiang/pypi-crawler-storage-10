# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class PitchSafetySystem_PitchSafetySystemTypeEnum(str, Enum):
    ACTUATION_LIMITED = "ActuationLimited"
    CONSTANT_RATE = "ConstantRate"
    RATE_DEMAND_SET_BY_EXTERNAL_CONTROLLER = "RateDemandSetByExternalController"
    RATE_VARIES_WITH_POSITION = "RateVariesWithPosition"
    RATE_VARIES_WITH_TIME = "RateVariesWithTime"
    TORQUE_SET_BY_EXTERNAL_CONTROLLER = "TorqueSetByExternalController"
    INSERT = "Insert"



class PitchSafetySystem(BladedModel, ABC):
    r"""
    The common properties of a pitch controller's safety system.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchSafetySystemType : PitchSafetySystem_PitchSafetySystemTypeEnum, Not supported yet
        Defines the specific type of model in use.
    
    AlwaysUseBackupPower : bool, default=False, Not supported yet
        Backup power is normally only used in a grid loss.  If true, this will trigger a switch to backup power torque limits in all safety system pitch action events.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    This class is an abstraction, with the following concrete implementations:
        - PitchActuationLimited
        - PitchConstantRateSafetySystem
        - PitchSafetySystemInsert
        - PitchRateDemandSetByExternalController
        - PitchRateVariesWithPosition
        - PitchRateVariesWithTime
        - PitchTorqueSetByExternalController
    
    """

    PitchSafetySystemType: PitchSafetySystem_PitchSafetySystemTypeEnum = Field(alias="PitchSafetySystemType", default=None) # Not supported yet
    r"""
    Defines the specific type of model in use.

    *Not supported yet*

    """

    AlwaysUseBackupPower: bool = Field(alias="AlwaysUseBackupPower", default=None) # Not supported yet
    r"""
    Backup power is normally only used in a grid loss.  If true, this will trigger a switch to backup power torque limits in all safety system pitch action events.

    *Not supported yet*

    - default = False
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

PitchSafetySystem.model_rebuild()
