# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.damper_force_or_torque_vs_rate import DamperForceOrTorqueVsRate
from dnv_bladed_models.damper_force_or_torque_vs_rate import DamperForceOrTorqueVsRate as DamperForceOrTorqueVsRateModel
from dnv_bladed_models.pitch_controller_torque_safety_system import PitchControllerTorqueSafetySystem
from dnv_bladed_models.pitch_controller_torque_safety_system import PitchControllerTorqueSafetySystem as PitchControllerTorqueSafetySystemModel
from dnv_bladed_models.spring_force_or_torque_vs_position import SpringForceOrTorqueVsPosition
from dnv_bladed_models.spring_force_or_torque_vs_position import SpringForceOrTorqueVsPosition as SpringForceOrTorqueVsPositionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchActuationLimited(PitchControllerTorqueSafetySystem):
    r"""
    A safety system where the movement is limited by the available torque.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchSafetySystemType : Literal['ActuationLimited'], default='ActuationLimited', Not supported yet
        Defines the specific type of PitchSafetySystem model in use.  For a `ActuationLimited` object, this must always be set to a value of `ActuationLimited`.
    
    AppliedForceOrTorque : float, default=0, Not supported yet
        The constant actuator torque (for a rotary system) or linear force (for a linear syste) applied during safety system pitch action.
    
    SpringForceOrTorqueVsPosition : List[SpringForceOrTorqueVsPosition], Not supported yet
        A look-up of the torque or force applied by a spring in the safety system at a given position.
    
    DamperForceOrTorqueVsRate : List[DamperForceOrTorqueVsRate], Not supported yet
        A look-up of the torque or force applied by a damper in the safety system for a given rate.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    PitchSafetySystemType: Literal['ActuationLimited'] = Field(alias="PitchSafetySystemType", default='ActuationLimited', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of PitchSafetySystem model in use.  For a `ActuationLimited` object, this must always be set to a value of `ActuationLimited`.

    *Not supported yet*

    - default = 'ActuationLimited'
    """

    AppliedForceOrTorque: float = Field(alias="AppliedForceOrTorque", default=None) # Not supported yet
    r"""
    The constant actuator torque (for a rotary system) or linear force (for a linear syste) applied during safety system pitch action.

    *Not supported yet*

    - default = 0
    """

    SpringForceOrTorqueVsPosition: List[SpringForceOrTorqueVsPositionModel] = Field(alias="SpringForceOrTorqueVsPosition", default_factory=list) # Not supported yet
    r"""
    A look-up of the torque or force applied by a spring in the safety system at a given position.

    *Not supported yet*

    """

    DamperForceOrTorqueVsRate: List[DamperForceOrTorqueVsRateModel] = Field(alias="DamperForceOrTorqueVsRate", default_factory=list) # Not supported yet
    r"""
    A look-up of the torque or force applied by a damper in the safety system for a given rate.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSafetySystem/PitchActuationLimited.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['SpringForceOrTorqueVsPosition','DamperForceOrTorqueVsRate',]), 'PitchSafetySystemType').merge(PitchControllerTorqueSafetySystem._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchActuationLimited.model_rebuild()
