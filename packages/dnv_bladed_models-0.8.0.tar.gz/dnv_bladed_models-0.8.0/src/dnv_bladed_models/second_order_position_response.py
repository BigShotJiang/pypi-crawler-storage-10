# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand
from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand as ResponseToPositionDemandModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SecondOrderPositionResponse(ResponseToPositionDemand):
    r"""
    Defines a second-order response to the controller's demands.
    
    Attributes
    ----------
    ResponseToPositionDemandType : Literal['SecondOrderPositionResponse'], default='SecondOrderPositionResponse'
        Defines the specific type of ResponseToPositionDemand model in use.  For a `SecondOrderPositionResponse` object, this must always be set to a value of `SecondOrderPositionResponse`.
    
    Frequency : float, default=6.28318530717959
        The angular frequency of oscillation of response.
    
    Damping : float, default=0.8
        The fraction of critical damping.
    
    Notes
    -----
    
    """

    ResponseToPositionDemandType: Literal['SecondOrderPositionResponse'] = Field(alias="ResponseToPositionDemandType", default='SecondOrderPositionResponse', frozen=True) # type: ignore
    r"""
    Defines the specific type of ResponseToPositionDemand model in use.  For a `SecondOrderPositionResponse` object, this must always be set to a value of `SecondOrderPositionResponse`.
    - default = 'SecondOrderPositionResponse'
    """

    Frequency: float = Field(alias="Frequency", default=None)
    r"""
    The angular frequency of oscillation of response.
    - default = 6.28318530717959
    """

    Damping: float = Field(alias="Damping", default=None)
    r"""
    The fraction of critical damping.
    - default = 0.8
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSystemDemand/ResponseToPositionDemand/SecondOrderPositionResponse.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ResponseToPositionDemandType').merge(ResponseToPositionDemand._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SecondOrderPositionResponse.model_rebuild()
