# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.tower_can import TowerCan
from dnv_bladed_models.tower_can import TowerCan as TowerCanModel
from dnv_bladed_models.tower_can_properties_explicit import TowerCanPropertiesExplicit
from dnv_bladed_models.tower_can_properties_explicit import TowerCanPropertiesExplicit as TowerCanPropertiesExplicitModel
from dnv_bladed_models.tower_can_properties_explicit_where_different import TowerCanPropertiesExplicitWhereDifferent
from dnv_bladed_models.tower_can_properties_explicit_where_different import TowerCanPropertiesExplicitWhereDifferent as TowerCanPropertiesExplicitWhereDifferentModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExplicitTowerCan(TowerCan):
    r"""
    A tower can where all of the structural properties are explicitly provided.
    
    Attributes
    ----------
    TowerCanType : Literal['ExplicitTowerCan'], default='ExplicitTowerCan'
        Defines the specific type of TowerCan model in use.  For a `ExplicitTowerCan` object, this must always be set to a value of `ExplicitTowerCan`.
    
    BaseCrossSection : TowerCanPropertiesExplicit
    
    TopCrossSection : TowerCanPropertiesExplicitWhereDifferent
    
    Notes
    -----
    
    """

    TowerCanType: Literal['ExplicitTowerCan'] = Field(alias="TowerCanType", default='ExplicitTowerCan', frozen=True) # type: ignore
    r"""
    Defines the specific type of TowerCan model in use.  For a `ExplicitTowerCan` object, this must always be set to a value of `ExplicitTowerCan`.
    - default = 'ExplicitTowerCan'
    """

    BaseCrossSection: TowerCanPropertiesExplicitModel = Field(alias="BaseCrossSection", default=None)
    r"""
    """

    TopCrossSection: TowerCanPropertiesExplicitWhereDifferentModel = Field(alias="TopCrossSection", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Tower/TowerCan/ExplicitTowerCan.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'TowerCanType').merge(TowerCan._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExplicitTowerCan.model_rebuild()
