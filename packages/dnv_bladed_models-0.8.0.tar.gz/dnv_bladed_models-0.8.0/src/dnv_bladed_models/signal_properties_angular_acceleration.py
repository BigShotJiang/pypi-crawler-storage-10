# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.signal_properties import SignalProperties
from dnv_bladed_models.signal_properties import SignalProperties as SignalPropertiesModel
from dnv_bladed_models.transducer_faults_angular_acceleration import TransducerFaultsAngularAcceleration
from dnv_bladed_models.transducer_faults_angular_acceleration import TransducerFaultsAngularAcceleration as TransducerFaultsAngularAccelerationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SignalPropertiesAngularAcceleration(SignalProperties):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    TransducerFaults : TransducerFaultsAngularAcceleration, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TransducerFaults: TransducerFaultsAngularAccelerationModel = Field(alias="TransducerFaults", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/SignalPropertiesAngularAcceleration/SignalPropertiesAngularAcceleration.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(SignalProperties._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SignalPropertiesAngularAcceleration.model_rebuild()
