# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.foundation import Foundation
from dnv_bladed_models.foundation import Foundation as FoundationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SimplifiedLinearFoundation(Foundation):
    r"""
    A simplified foundation model, comprising of basic masses and inertias, with linear stiffnesses.
    
    Attributes
    ----------
    FoundationType : Literal['SimplifiedLinearFoundation'], default='SimplifiedLinearFoundation'
        Defines the specific type of Foundation model in use.  For a `SimplifiedLinearFoundation` object, this must always be set to a value of `SimplifiedLinearFoundation`.
    
    TranslationalStiffness : float
        Transitional stiffness of foundation  Omit if no translation permited.
    
    Mass : float, default=0
        Mass of foundation
    
    RotationalStiffness : float
        Rotational stiffness of foundation  Omit if no rotation permited.
    
    RotationalInertia : float, default=0
        Moment of inertia of foundation mass about a horizontal axis at tower base.
    
    Notes
    -----
    
    """

    FoundationType: Literal['SimplifiedLinearFoundation'] = Field(alias="FoundationType", default='SimplifiedLinearFoundation', frozen=True) # type: ignore
    r"""
    Defines the specific type of Foundation model in use.  For a `SimplifiedLinearFoundation` object, this must always be set to a value of `SimplifiedLinearFoundation`.
    - default = 'SimplifiedLinearFoundation'
    """

    TranslationalStiffness: float = Field(alias="TranslationalStiffness", default=None)
    r"""
    Transitional stiffness of foundation  Omit if no translation permited.
    """

    Mass: float = Field(alias="Mass", default=None)
    r"""
    Mass of foundation
    - default = 0
    """

    RotationalStiffness: float = Field(alias="RotationalStiffness", default=None)
    r"""
    Rotational stiffness of foundation  Omit if no rotation permited.
    """

    RotationalInertia: float = Field(alias="RotationalInertia", default=None)
    r"""
    Moment of inertia of foundation mass about a horizontal axis at tower base.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Tower/Foundation/SimplifiedLinearFoundation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'FoundationType').merge(Foundation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SimplifiedLinearFoundation.model_rebuild()
