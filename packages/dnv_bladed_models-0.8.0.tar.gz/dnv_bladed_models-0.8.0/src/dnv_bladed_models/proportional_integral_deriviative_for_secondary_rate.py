# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.response_to_secondary_rate_demand import ResponseToSecondaryRateDemand
from dnv_bladed_models.response_to_secondary_rate_demand import ResponseToSecondaryRateDemand as ResponseToSecondaryRateDemandModel
from .schema_helper import SchemaHelper
from .base_entity import *


class ProportionalIntegralDeriviativeForSecondaryRate_DifferentialGainActionEnum(str, Enum):
    ERROR = "Error"
    FEEDBACK = "Feedback"
    SETPOINT = "Setpoint"



class ProportionalIntegralDeriviativeForSecondaryRate(ResponseToSecondaryRateDemand):
    r"""
    Defines an proportional, integral, deriviative (PID) response to the controller's demands.
    
    Attributes
    ----------
    ResponseToSecondaryRateDemandType : Literal['ProportionalIntegralDeriviativeForSecondaryRate'], default='ProportionalIntegralDeriviativeForSecondaryRate'
        Defines the specific type of ResponseToSecondaryRateDemand model in use.  For a `ProportionalIntegralDeriviativeForSecondaryRate` object, this must always be set to a value of `ProportionalIntegralDeriviativeForSecondaryRate`.
    
    ProportionalGain : float, default=0
        The gain on the contemporaneous error.
    
    IntegralGain : float, default=0
        The gain on the integral from time zero till the present of the error signal.
    
    DifferentialGain : float, default=0
        The gain the filtered derivative of the error.  The derivative of the error is passed through a low-pass filter.
    
    DifferentialGainAction : ProportionalIntegralDeriviativeForSecondaryRate_DifferentialGainActionEnum, default='Feedback'
        The proportional and integral terms are apllied on error.  Derivative term may also be applied on the feedback or setpoint signals.
    
    DifferentialGainTimeConstant : float, default=0
        The derivative term uses a low-pass filter on input.
    
    DesaturationTimeConstant : float, default=0
        The time constant for when the output exceeds the limits.
    
    Notes
    -----
    
    """

    ResponseToSecondaryRateDemandType: Literal['ProportionalIntegralDeriviativeForSecondaryRate'] = Field(alias="ResponseToSecondaryRateDemandType", default='ProportionalIntegralDeriviativeForSecondaryRate', frozen=True) # type: ignore
    r"""
    Defines the specific type of ResponseToSecondaryRateDemand model in use.  For a `ProportionalIntegralDeriviativeForSecondaryRate` object, this must always be set to a value of `ProportionalIntegralDeriviativeForSecondaryRate`.
    - default = 'ProportionalIntegralDeriviativeForSecondaryRate'
    """

    ProportionalGain: float = Field(alias="ProportionalGain", default=None)
    r"""
    The gain on the contemporaneous error.
    - default = 0
    """

    IntegralGain: float = Field(alias="IntegralGain", default=None)
    r"""
    The gain on the integral from time zero till the present of the error signal.
    - default = 0
    """

    DifferentialGain: float = Field(alias="DifferentialGain", default=None)
    r"""
    The gain the filtered derivative of the error.  The derivative of the error is passed through a low-pass filter.
    - default = 0
    """

    DifferentialGainAction: ProportionalIntegralDeriviativeForSecondaryRate_DifferentialGainActionEnum = Field(alias="DifferentialGainAction", default=None)
    r"""
    The proportional and integral terms are apllied on error.  Derivative term may also be applied on the feedback or setpoint signals.
    - default = 'Feedback'
    """

    DifferentialGainTimeConstant: float = Field(alias="DifferentialGainTimeConstant", default=None)
    r"""
    The derivative term uses a low-pass filter on input.
    - default = 0
    """

    DesaturationTimeConstant: float = Field(alias="DesaturationTimeConstant", default=None)
    r"""
    The time constant for when the output exceeds the limits.
    - default = 0
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSystemDemand/ResponseToPositionDemand/ResponseToSecondaryRateDemand/ProportionalIntegralDeriviativeForSecondaryRate.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ResponseToSecondaryRateDemandType').merge(ResponseToSecondaryRateDemand._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ProportionalIntegralDeriviativeForSecondaryRate.model_rebuild()
