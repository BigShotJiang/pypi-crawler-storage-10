# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.angle_vs_stiffness_torque import AngleVsStiffnessTorque
from dnv_bladed_models.angle_vs_stiffness_torque import AngleVsStiffnessTorque as AngleVsStiffnessTorqueModel
from dnv_bladed_models.damper import Damper
from dnv_bladed_models.damper import Damper as DamperModel
from dnv_bladed_models.pendulum_damper_mounting_position import PendulumDamperMountingPosition
from dnv_bladed_models.pendulum_damper_mounting_position import PendulumDamperMountingPosition as PendulumDamperMountingPositionModel
from dnv_bladed_models.velocity_vs_damping_torque import VelocityVsDampingTorque
from dnv_bladed_models.velocity_vs_damping_torque import VelocityVsDampingTorque as VelocityVsDampingTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PendulumDamper(Damper):
    r"""
    A \"pendulum\" or \"tuned mass\" damper, which uses a suspended mass to damp oscillations in a tower.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentType : Literal['PendulumDamper'], default='PendulumDamper', Not supported yet
        Defines the specific type of Component model in use.  For a `PendulumDamper` object, this must always be set to a value of `PendulumDamper`.
    
    Length : float, Not supported yet
        The length of the (rigid) pendulum arm.
    
    Mass : float, Not supported yet
        The mass suspended at the end of the pendulum arm.
    
    Inertia : float, Not supported yet
        Any added inertia for the pendulum.
    
    Stiffness : float, Not supported yet
        The constant stiffness term for the hinge of the pendulum.  This is in addition to the non-linear terms defined in the AngleVsStiffnessTorque parameter.
    
    Damping : float, Not supported yet
        The constant damping term for the hinge of the pendulum.  This is in addition to the non-linear terms defined in the VelocityVsDampingTorque parameter.
    
    InitialAngle : float, Not supported yet
        The initial angle of the pendulum at the beginning of the simulation.
    
    ConstantFriction : float, Not supported yet
        The constant friction torque applied to rotational hinge.  Any other friction contributions will be in addition to this.
    
    AngleVsStiffnessTorque : List[AngleVsStiffnessTorque], Not supported yet
        A look-up table of additional stiffnesses that vary with the pendulum's position.
    
    VelocityVsDampingTorque : List[VelocityVsDampingTorque], Not supported yet
        A look-up table of additional damping that vary with the pendulum's velocity.
    
    MountingPosition : PendulumDamperMountingPosition, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentType: Literal['PendulumDamper'] = Field(alias="ComponentType", default='PendulumDamper', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `PendulumDamper` object, this must always be set to a value of `PendulumDamper`.

    *Not supported yet*

    - default = 'PendulumDamper'
    """

    Length: float = Field(alias="Length", default=None) # Not supported yet
    r"""
    The length of the (rigid) pendulum arm.

    *Not supported yet*

    """

    Mass: float = Field(alias="Mass", default=None) # Not supported yet
    r"""
    The mass suspended at the end of the pendulum arm.

    *Not supported yet*

    """

    Inertia: float = Field(alias="Inertia", default=None) # Not supported yet
    r"""
    Any added inertia for the pendulum.

    *Not supported yet*

    """

    Stiffness: float = Field(alias="Stiffness", default=None) # Not supported yet
    r"""
    The constant stiffness term for the hinge of the pendulum.  This is in addition to the non-linear terms defined in the AngleVsStiffnessTorque parameter.

    *Not supported yet*

    """

    Damping: float = Field(alias="Damping", default=None) # Not supported yet
    r"""
    The constant damping term for the hinge of the pendulum.  This is in addition to the non-linear terms defined in the VelocityVsDampingTorque parameter.

    *Not supported yet*

    """

    InitialAngle: float = Field(alias="InitialAngle", default=None) # Not supported yet
    r"""
    The initial angle of the pendulum at the beginning of the simulation.

    *Not supported yet*

    """

    ConstantFriction: float = Field(alias="ConstantFriction", default=None) # Not supported yet
    r"""
    The constant friction torque applied to rotational hinge.  Any other friction contributions will be in addition to this.

    *Not supported yet*

    """

    AngleVsStiffnessTorque: List[AngleVsStiffnessTorqueModel] = Field(alias="AngleVsStiffnessTorque", default_factory=list) # Not supported yet
    r"""
    A look-up table of additional stiffnesses that vary with the pendulum's position.

    *Not supported yet*

    """

    VelocityVsDampingTorque: List[VelocityVsDampingTorqueModel] = Field(alias="VelocityVsDampingTorque", default_factory=list) # Not supported yet
    r"""
    A look-up table of additional damping that vary with the pendulum's velocity.

    *Not supported yet*

    """

    MountingPosition: PendulumDamperMountingPositionModel = Field(alias="MountingPosition", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Damper/PendulumDamper.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['AngleVsStiffnessTorque','VelocityVsDampingTorque',]), 'ComponentType').merge(Damper._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PendulumDamper.model_rebuild()
