# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.pitch_force_minimum_maximum import PitchForceMinimumMaximum
from dnv_bladed_models.pitch_force_minimum_maximum import PitchForceMinimumMaximum as PitchForceMinimumMaximumModel
from dnv_bladed_models.pitch_position_vs_minimum_and_maximum_moment import PitchPositionVsMinimumAndMaximumMoment
from dnv_bladed_models.pitch_position_vs_minimum_and_maximum_moment import PitchPositionVsMinimumAndMaximumMoment as PitchPositionVsMinimumAndMaximumMomentModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchForceLimits(BladedModel):
    r"""
    The limits on the forces that the actuator can apply under normal operation.
    
    Attributes
    ----------
    Limits : PitchForceMinimumMaximum
    
    PositionVsLimits : List[PitchPositionVsMinimumAndMaximumMoment]
        A list of pitch positions and associated minimum and maximum force limits at those postions.
    
    Notes
    -----
    
    """

    Limits: PitchForceMinimumMaximumModel = Field(alias="Limits", default=None)
    r"""
    """

    PositionVsLimits: List[PitchPositionVsMinimumAndMaximumMomentModel] = Field(alias="PositionVsLimits", default_factory=list)
    r"""
    A list of pitch positions and associated minimum and maximum force limits at those postions.
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/PitchForceLimits/PitchForceLimits.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['PositionVsLimits',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchForceLimits.model_rebuild()
