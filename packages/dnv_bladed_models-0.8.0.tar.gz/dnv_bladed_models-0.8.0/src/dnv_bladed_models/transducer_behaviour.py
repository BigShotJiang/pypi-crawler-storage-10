# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class TransducerBehaviour_TransducerBehaviourTypeEnum(str, Enum):
    FIRST_ORDER_TRANSDUCER_RESPONSE = "FirstOrderTransducerResponse"
    INSTANTANEOUS_TRANSDUCER_RESPONSE = "InstantaneousTransducerResponse"
    PASSIVE_TRANSDUCER_RESPONSE = "PassiveTransducerResponse"
    POSITION_PROPORTIONAL_INTEGRAL_DERIVIATIVE = "PositionProportionalIntegralDeriviative"
    RATE_PROPORTIONAL_INTEGRAL_DERIVIATIVE = "RateProportionalIntegralDeriviative"
    SECOND_ORDER_TRANSDUCER_RESPONSE = "SecondOrderTransducerResponse"
    USE_SETPOINT_TRAJECTORY_PLANNING = "UseSetpointTrajectoryPlanning"
    INSERT = "Insert"



class TransducerBehaviour(BladedModel, ABC):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    TransducerBehaviourType : TransducerBehaviour_TransducerBehaviourTypeEnum, Not supported yet
        Defines the specific type of model in use.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    This class is an abstraction, with the following concrete implementations:
        - FirstOrderTransducerResponse
        - TransducerBehaviourInsert
        - InstantaneousTransducerResponse
        - PassiveTransducerResponse
        - PositionProportionalIntegralDeriviative
        - RateProportionalIntegralDeriviative
        - SecondOrderTransducerResponse
        - UseSetpointTrajectoryPlanning
    
    """

    TransducerBehaviourType: TransducerBehaviour_TransducerBehaviourTypeEnum = Field(alias="TransducerBehaviourType", default=None) # Not supported yet
    r"""
    Defines the specific type of model in use.

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

TransducerBehaviour.model_rebuild()
