# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.tower_can_cross_section_properties import TowerCanCrossSectionProperties
from dnv_bladed_models.tower_can_cross_section_properties import TowerCanCrossSectionProperties as TowerCanCrossSectionPropertiesModel
from dnv_bladed_models.tower_can_torsional_properties import TowerCanTorsionalProperties
from dnv_bladed_models.tower_can_torsional_properties import TowerCanTorsionalProperties as TowerCanTorsionalPropertiesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerCanPropertiesExplicit(TowerCanCrossSectionProperties):
    r"""
    The definition of a single tower can cross-section where any structural properties can be explicitly specified if they are different to those specified in the BaseCrossSection.
    
    Attributes
    ----------
    MassPerUnitLength : float
        The mass per unit length.
    
    BendingStiffness : float
        The bending stiffness of the cross-section.
    
    ShearStiffness : float
        The shear stiffness of the cross-section.
    
    TorsionalProperties : TowerCanTorsionalProperties
    
    Notes
    -----
    
    """

    MassPerUnitLength: float = Field(alias="MassPerUnitLength", default=None)
    r"""
    The mass per unit length.
    """

    BendingStiffness: float = Field(alias="BendingStiffness", default=None)
    r"""
    The bending stiffness of the cross-section.
    """

    ShearStiffness: float = Field(alias="ShearStiffness", default=None)
    r"""
    The shear stiffness of the cross-section.
    """

    TorsionalProperties: TowerCanTorsionalPropertiesModel = Field(alias="TorsionalProperties", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Tower/TowerCan/TowerCanPropertiesExplicit/TowerCanPropertiesExplicit.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(TowerCanCrossSectionProperties._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerCanPropertiesExplicit.model_rebuild()
