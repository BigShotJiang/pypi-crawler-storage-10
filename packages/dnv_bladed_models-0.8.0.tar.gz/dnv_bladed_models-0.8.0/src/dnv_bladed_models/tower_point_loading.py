# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.support_structure_point_loading import SupportStructurePointLoading
from dnv_bladed_models.support_structure_point_loading import SupportStructurePointLoading as SupportStructurePointLoadingModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerPointLoading(SupportStructurePointLoading):
    r"""
    A time history of point loading applied to an axisymmetric tower.
    
    Not supported yet.
    
    Attributes
    ----------
    AppliedLoadType : Literal['TowerPointLoading'], default='TowerPointLoading', Not supported yet
        Defines the specific type of AppliedLoad model in use.  For a `TowerPointLoading` object, this must always be set to a value of `TowerPointLoading`.
    
    HeightOfImpact : float, default=0, Not supported yet
        The height up the tower that the force is to be applied, measured from the bottom of the tower component.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    AppliedLoadType: Literal['TowerPointLoading'] = Field(alias="AppliedLoadType", default='TowerPointLoading', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of AppliedLoad model in use.  For a `TowerPointLoading` object, this must always be set to a value of `TowerPointLoading`.

    *Not supported yet*

    - default = 'TowerPointLoading'
    """

    HeightOfImpact: float = Field(alias="HeightOfImpact", default=None) # Not supported yet
    r"""
    The height up the tower that the force is to be applied, measured from the bottom of the tower component.

    *Not supported yet*

    - default = 0
    """

    _relative_schema_path: str = 'TimeDomainSimulation/AppliedLoad/TowerPointLoading.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'AppliedLoadType').merge(SupportStructurePointLoading._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerPointLoading.model_rebuild()
