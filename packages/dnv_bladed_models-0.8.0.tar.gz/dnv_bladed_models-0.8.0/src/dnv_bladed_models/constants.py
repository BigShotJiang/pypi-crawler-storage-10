# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.air_characteristics import AirCharacteristics
from dnv_bladed_models.air_characteristics import AirCharacteristics as AirCharacteristicsModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.water_characteristics import WaterCharacteristics
from dnv_bladed_models.water_characteristics import WaterCharacteristics as WaterCharacteristicsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Constants(BladedModel):
    r"""
    The physical constants used in the analysis.  The default values are assumed if not provided explicitly.
    
    Attributes
    ----------
    AccelerationDueToGravity : float, default=9.81, >= 0
        The acceleration due to gravity known as g
    
    AirCharacteristics : AirCharacteristics
    
    WaterCharacteristics : WaterCharacteristics, Not supported yet
    
    Notes
    -----
    
    """

    AccelerationDueToGravity: float = Field(alias="AccelerationDueToGravity", default=None, ge=0)
    r"""
    The acceleration due to gravity known as g
    - default = 9.81
    - &gt;= 0
    """

    AirCharacteristics: AirCharacteristicsModel = Field(alias="AirCharacteristics", default=None)
    r"""
    """

    WaterCharacteristics: WaterCharacteristicsModel = Field(alias="WaterCharacteristics", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Constants/Constants.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Constants.model_rebuild()
