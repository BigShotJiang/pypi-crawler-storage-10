# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladePointMass(BladedModel):
    r"""
    A point mass with rotational inertia on the blade.  This is defined in the blade root axes.
    
    Attributes
    ----------
    LocationInRootAxes : Vector3D
    
    Mass : float
        The mass value
    
    Notes
    -----
    
    """

    LocationInRootAxes: Vector3DModel = Field(alias="LocationInRootAxes", default=None)
    r"""
    """

    Mass: float = Field(alias="Mass", default=None)
    r"""
    The mass value
    """

    _relative_schema_path: str = 'Components/Blade/BladeAdditionalInertia/BladePointMass/BladePointMass.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladePointMass.model_rebuild()
