# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.damper import Damper
from dnv_bladed_models.damper import Damper as DamperModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ActiveDamper(Damper, ABC):
    r"""
    An active damper, applying a force which is specified by the controller.
    
    Not supported yet.
    
    Attributes
    ----------
    ForceLag : float, Not supported yet
        The force lag for the force signal's transfer function.
    
    AccelerationLag : float, Not supported yet
        The time lag for the acceleration signal's transfer function.
    
    ForceTransferFunction : float, Not supported yet
        Transfer function for active damper
    
    PerturbationForLinearisationCalculation : float, Not supported yet
        The perturbation step to use during linearisation calculation.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ForceLag: float = Field(alias="ForceLag", default=None) # Not supported yet
    r"""
    The force lag for the force signal's transfer function.

    *Not supported yet*

    """

    AccelerationLag: float = Field(alias="AccelerationLag", default=None) # Not supported yet
    r"""
    The time lag for the acceleration signal's transfer function.

    *Not supported yet*

    """

    ForceTransferFunction: float = Field(alias="ForceTransferFunction", default=None) # Not supported yet
    r"""
    Transfer function for active damper

    *Not supported yet*

    """

    PerturbationForLinearisationCalculation: float = Field(alias="PerturbationForLinearisationCalculation", default=None) # Not supported yet
    r"""
    The perturbation step to use during linearisation calculation.

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Damper._type_info)

ActiveDamper.model_rebuild()
