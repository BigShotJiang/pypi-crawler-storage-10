# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.response_to_rate_demand import ResponseToRateDemand
from dnv_bladed_models.response_to_rate_demand import ResponseToRateDemand as ResponseToRateDemandModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FirstOrderRateResponse(ResponseToRateDemand):
    r"""
    Defines a first-order delay response to the controller's demands.
    
    Attributes
    ----------
    ResponseToRateDemandType : Literal['FirstOrderRateResponse'], default='FirstOrderRateResponse'
        Defines the specific type of ResponseToRateDemand model in use.  For a `FirstOrderRateResponse` object, this must always be set to a value of `FirstOrderRateResponse`.
    
    LagTime : float, default=0.3
        The time constant for 1st order response delay.
    
    Notes
    -----
    
    """

    ResponseToRateDemandType: Literal['FirstOrderRateResponse'] = Field(alias="ResponseToRateDemandType", default='FirstOrderRateResponse', frozen=True) # type: ignore
    r"""
    Defines the specific type of ResponseToRateDemand model in use.  For a `FirstOrderRateResponse` object, this must always be set to a value of `FirstOrderRateResponse`.
    - default = 'FirstOrderRateResponse'
    """

    LagTime: float = Field(alias="LagTime", default=None)
    r"""
    The time constant for 1st order response delay.
    - default = 0.3
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSystemDemand/ResponseToRateDemand/FirstOrderRateResponse.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ResponseToRateDemandType').merge(ResponseToRateDemand._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FirstOrderRateResponse.model_rebuild()
