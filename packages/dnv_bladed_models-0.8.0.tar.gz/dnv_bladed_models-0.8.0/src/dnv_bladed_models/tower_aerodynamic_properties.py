# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.flow_obstruction import FlowObstruction
from dnv_bladed_models.flow_obstruction import FlowObstruction as FlowObstructionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerAerodynamicProperties(BladedModel):
    r"""
    The aerodynamic properties of the tower, including tower shadow.
    
    Attributes
    ----------
    CoefficientOfDrag : float, default=1.12
        The coefficient of drag for the entire tower.
    
    TowerShadow : FlowObstruction
    
    Notes
    -----
    
    """

    CoefficientOfDrag: float = Field(alias="CoefficientOfDrag", default=None)
    r"""
    The coefficient of drag for the entire tower.
    - default = 1.12
    """

    TowerShadow: FlowObstructionModel = Field(alias="TowerShadow", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Tower/TowerAerodynamicProperties/TowerAerodynamicProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerAerodynamicProperties.model_rebuild()
