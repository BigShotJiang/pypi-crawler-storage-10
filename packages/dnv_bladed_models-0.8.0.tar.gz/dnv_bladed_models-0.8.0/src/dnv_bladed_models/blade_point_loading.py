# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.applied_load import AppliedLoad
from dnv_bladed_models.applied_load import AppliedLoad as AppliedLoadModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladePointLoading(AppliedLoad):
    r"""
    A time history of point loading applied to a blade.
    
    Not supported yet.
    
    Attributes
    ----------
    AppliedLoadType : Literal['BladePointLoading'], default='BladePointLoading', Not supported yet
        Defines the specific type of AppliedLoad model in use.  For a `BladePointLoading` object, this must always be set to a value of `BladePointLoading`.
    
    DistanceAlongBlade : float, Not supported yet
        The distance along the reference axis of the blade to apply the loading.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    AppliedLoadType: Literal['BladePointLoading'] = Field(alias="AppliedLoadType", default='BladePointLoading', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of AppliedLoad model in use.  For a `BladePointLoading` object, this must always be set to a value of `BladePointLoading`.

    *Not supported yet*

    - default = 'BladePointLoading'
    """

    DistanceAlongBlade: float = Field(alias="DistanceAlongBlade", default=None) # Not supported yet
    r"""
    The distance along the reference axis of the blade to apply the loading.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/AppliedLoad/BladePointLoading.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'AppliedLoadType').merge(AppliedLoad._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladePointLoading.model_rebuild()
