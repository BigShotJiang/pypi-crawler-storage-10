# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.current_direction_shear_variation import CurrentDirectionShearVariation
from dnv_bladed_models.current_direction_shear_variation import CurrentDirectionShearVariation as CurrentDirectionShearVariationModel
from dnv_bladed_models.time_vs_current_direction_shear import TimeVsCurrentDirectionShear
from dnv_bladed_models.time_vs_current_direction_shear import TimeVsCurrentDirectionShear as TimeVsCurrentDirectionShearModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CurrentDirectionShearTimeHistory(CurrentDirectionShearVariation):
    r"""
    A time history of the vertical direction shear (veer).  This is a linear relationship between the height and the local direction, with the direction being its nominal value at the reference height.
    
    Not supported yet.
    
    Attributes
    ----------
    DirectionShearVariationType : Literal['TimeHistory'], default='TimeHistory', Not supported yet
        Defines the specific type of DirectionShearVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.
    
    TimeVsDirectionShear : List[TimeVsCurrentDirectionShear], Not supported yet
        A list of points specifying the wind veer at the corresponding time.  The wind veer will be interpolated between these points; the wind veer before the first point will be constant at the first point's value; and the wind veer after the last point will remain constant at the last point's value
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    DirectionShearVariationType: Literal['TimeHistory'] = Field(alias="DirectionShearVariationType", default='TimeHistory', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of DirectionShearVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.

    *Not supported yet*

    - default = 'TimeHistory'
    """

    TimeVsDirectionShear: List[TimeVsCurrentDirectionShearModel] = Field(alias="TimeVsDirectionShear", default_factory=list) # Not supported yet
    r"""
    A list of points specifying the wind veer at the corresponding time.  The wind veer will be interpolated between these points; the wind veer before the first point will be constant at the first point's value; and the wind veer after the last point will remain constant at the last point's value

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/CurrentDirectionShearVariation/CurrentDirectionShearTimeHistory.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['TimeVsDirectionShear',]), 'DirectionShearVariationType').merge(CurrentDirectionShearVariation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CurrentDirectionShearTimeHistory.model_rebuild()
