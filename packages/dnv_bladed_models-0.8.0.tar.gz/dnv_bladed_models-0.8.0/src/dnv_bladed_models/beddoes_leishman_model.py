# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_stall import DynamicStall
from dnv_bladed_models.dynamic_stall import DynamicStall as DynamicStallModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BeddoesLeishmanModel(DynamicStall, ABC):
    r"""
    The common properties for the Beddoes Leishman dynamic stall models.
    
    Attributes
    ----------
    UseKirchoffFlow : bool, default=False
        If true,the normal force coefficient is computed using the dynamic separation position in Kirchoff's equation directly.  If false, the dynamic separation position is used to linearly interpolate between fully separated and fully attached flow. In normal operating conditions this setting will not lead to significant differences, but it has been found that in parked/idling cases (where the blade experiences high angles of attack) this option will improve the aerodynamic damping of the blade. The explanation for the damping differences is given in the aerodynamic validation document on the User Portal.
    
    UseImpulsiveContributions : bool, default=False
        Enabling the impulsive contributions in lift and moment coefficient.
    
    PressureLagTimeConstant : float, default=1.7
        The lag between the pressure and the lift.
    
    VortexLiftTimeConstant : float, default=6
        The rate of decay of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    
    VortexTravelTimeConstant : float, default=7.5
        The time constant that controls the duration of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    
    AttachedFlowConstantA1 : float, default=0.165
        The constant A1 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantA2 : float, default=0.335
        The constant A2 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantB1 : float, default=0.0455
        The constant B1 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantB2 : float, default=0.3
        The constant B2 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    
    Notes
    -----
    
    """

    UseKirchoffFlow: bool = Field(alias="UseKirchoffFlow", default=None)
    r"""
    If true,the normal force coefficient is computed using the dynamic separation position in Kirchoff's equation directly.  If false, the dynamic separation position is used to linearly interpolate between fully separated and fully attached flow. In normal operating conditions this setting will not lead to significant differences, but it has been found that in parked/idling cases (where the blade experiences high angles of attack) this option will improve the aerodynamic damping of the blade. The explanation for the damping differences is given in the aerodynamic validation document on the User Portal.
    - default = False
    """

    UseImpulsiveContributions: bool = Field(alias="UseImpulsiveContributions", default=None)
    r"""
    Enabling the impulsive contributions in lift and moment coefficient.
    - default = False
    """

    PressureLagTimeConstant: float = Field(alias="PressureLagTimeConstant", default=None)
    r"""
    The lag between the pressure and the lift.
    - default = 1.7
    """

    VortexLiftTimeConstant: float = Field(alias="VortexLiftTimeConstant", default=None)
    r"""
    The rate of decay of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    - default = 6
    """

    VortexTravelTimeConstant: float = Field(alias="VortexTravelTimeConstant", default=None)
    r"""
    The time constant that controls the duration of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    - default = 7.5
    """

    AttachedFlowConstantA1: float = Field(alias="AttachedFlowConstantA1", default=None)
    r"""
    The constant A1 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    - default = 0.165
    """

    AttachedFlowConstantA2: float = Field(alias="AttachedFlowConstantA2", default=None)
    r"""
    The constant A2 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    - default = 0.335
    """

    AttachedFlowConstantB1: float = Field(alias="AttachedFlowConstantB1", default=None)
    r"""
    The constant B1 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    - default = 0.0455
    """

    AttachedFlowConstantB2: float = Field(alias="AttachedFlowConstantB2", default=None)
    r"""
    The constant B2 for the Beddoes-Leishman type dynamic stall model to control the attached flow states.
    - default = 0.3
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(DynamicStall._type_info)

BeddoesLeishmanModel.model_rebuild()
