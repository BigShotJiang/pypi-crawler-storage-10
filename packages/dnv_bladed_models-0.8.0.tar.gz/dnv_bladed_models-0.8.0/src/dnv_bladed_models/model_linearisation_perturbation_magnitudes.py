# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ModelLinearisationPerturbationMagnitudes(BladedModel):
    r"""
    
    
    Attributes
    ----------
    WindSpeedPerturbation : float, default=0.1
        The magnitude of perturbation of the wind speed around the equilibrium value.  It should be small so that the analysis stays in the linear region  Omit keyword in order to let Bladed calculate a default perturbation.
    
    PitchDemandPerturbation : float, default=0.00010
        The magnitude of perturbation of the pitch angle or rate demand around the equilibrium value.  It should be small so that the analysis stays in the linear region.  The default value will be interpreted as an angle in the case of a position demand, and an angular velocity in the case of a rate demand.
    
    PitchActuationPerturbation : float
        The magnitude of perturbation of the pitch actuation force or torque around the equilibrium value.  It should be small so that the analysis stays in the linear region.  If omitted, the pitch demand will be perturbed instead.
    
    GeneratorTorqueDemandPerturbation : float, default=1000
        The magnitude of perturbation of the generator torque demand around the equilibrium value.  It should be small so that the analysis stays in the linear region.
    
    WindShearPerturbation : float
        The magnitude of both horizontal and vertical shear perturbations. The wind shear is perturbued by linearly varying the wind speed in proportion to to vertical or horizontal distance from the rotor centre.  If omitted, the wind shears will not be perturbed as part of this analysis.
    
    YawActuatorTorquePerturbation : float, Not supported yet
        Yaw actuator torque perturbation. The torque perturbation is evenly distributed across the actuator banks.  If omitted, the yaw torque will not be perturbed as part of this analysis.
    
    Notes
    -----
    
    """

    WindSpeedPerturbation: float = Field(alias="WindSpeedPerturbation", default=None)
    r"""
    The magnitude of perturbation of the wind speed around the equilibrium value.  It should be small so that the analysis stays in the linear region  Omit keyword in order to let Bladed calculate a default perturbation.
    - default = 0.1
    """

    PitchDemandPerturbation: float = Field(alias="PitchDemandPerturbation", default=None)
    r"""
    The magnitude of perturbation of the pitch angle or rate demand around the equilibrium value.  It should be small so that the analysis stays in the linear region.  The default value will be interpreted as an angle in the case of a position demand, and an angular velocity in the case of a rate demand.
    - default = 0.00010
    """

    PitchActuationPerturbation: float = Field(alias="PitchActuationPerturbation", default=None)
    r"""
    The magnitude of perturbation of the pitch actuation force or torque around the equilibrium value.  It should be small so that the analysis stays in the linear region.  If omitted, the pitch demand will be perturbed instead.
    """

    GeneratorTorqueDemandPerturbation: float = Field(alias="GeneratorTorqueDemandPerturbation", default=None)
    r"""
    The magnitude of perturbation of the generator torque demand around the equilibrium value.  It should be small so that the analysis stays in the linear region.
    - default = 1000
    """

    WindShearPerturbation: float = Field(alias="WindShearPerturbation", default=None)
    r"""
    The magnitude of both horizontal and vertical shear perturbations. The wind shear is perturbued by linearly varying the wind speed in proportion to to vertical or horizontal distance from the rotor centre.  If omitted, the wind shears will not be perturbed as part of this analysis.
    """

    YawActuatorTorquePerturbation: float = Field(alias="YawActuatorTorquePerturbation", default=None) # Not supported yet
    r"""
    Yaw actuator torque perturbation. The torque perturbation is evenly distributed across the actuator banks.  If omitted, the yaw torque will not be perturbed as part of this analysis.

    *Not supported yet*

    """

    _relative_schema_path: str = 'SteadyCalculation/ModelLinearisationPerturbations/ModelLinearisationPerturbationMagnitudes/ModelLinearisationPerturbationMagnitudes.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ModelLinearisationPerturbationMagnitudes.model_rebuild()
