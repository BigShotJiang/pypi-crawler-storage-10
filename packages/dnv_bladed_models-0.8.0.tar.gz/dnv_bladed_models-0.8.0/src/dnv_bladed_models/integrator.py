# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Integrator_IntegratorTypeEnum(str, Enum):
    EXPLICIT_NEWMARK_BETA_FIXED_STEP = "ExplicitNewmarkBetaFixedStep"
    GENERALISED_ALPHA_FIXED_STEP = "GeneralisedAlphaFixedStep"
    IMPLICIT_NEWMARK_BETA_FIXED_STEP = "ImplicitNewmarkBetaFixedStep"
    RUNGE_KUTTA_VARIABLE_STEP = "RungeKuttaVariableStep"
    INSERT = "Insert"



class Integrator(BladedModel, ABC):
    r"""
    The settings for the integrator, used for all time domain simulations.
    
    Attributes
    ----------
    IntegratorType : Integrator_IntegratorTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - ExplicitNewmarkBetaFixedStep
        - GeneralisedAlphaFixedStep
        - ImplicitNewmarkBetaFixedStep
        - IntegratorInsert
        - RungeKuttaVariableStep
    
    """

    IntegratorType: Integrator_IntegratorTypeEnum = Field(alias="IntegratorType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

Integrator.model_rebuild()
