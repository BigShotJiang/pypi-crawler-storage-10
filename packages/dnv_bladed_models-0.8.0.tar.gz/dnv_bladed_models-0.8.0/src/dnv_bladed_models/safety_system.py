# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.emergency_stop_button import EmergencyStopButton
from dnv_bladed_models.emergency_stop_button import EmergencyStopButton as EmergencyStopButtonModel
from dnv_bladed_models.generator_overpower import GeneratorOverpower
from dnv_bladed_models.generator_overpower import GeneratorOverpower as GeneratorOverpowerModel
from dnv_bladed_models.generator_overspeed import GeneratorOverspeed
from dnv_bladed_models.generator_overspeed import GeneratorOverspeed as GeneratorOverspeedModel
from dnv_bladed_models.generator_short_circuit import GeneratorShortCircuit
from dnv_bladed_models.generator_short_circuit import GeneratorShortCircuit as GeneratorShortCircuitModel
from dnv_bladed_models.nacelle_vibration import NacelleVibration
from dnv_bladed_models.nacelle_vibration import NacelleVibration as NacelleVibrationModel
from dnv_bladed_models.rotor_overspeed import RotorOverspeed
from dnv_bladed_models.rotor_overspeed import RotorOverspeed as RotorOverspeedModel
from dnv_bladed_models.safety_circuit_library import SafetyCircuitLibrary
from dnv_bladed_models.safety_circuit_library import SafetyCircuitLibrary as SafetyCircuitLibraryModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SafetySystem(BladedModel):
    r"""
    The definition of the turbine's safety system.  This supersedes the turbine's controller requests.
    
    Not supported yet.
    
    Attributes
    ----------
    SafetyCircuitLibrary : SafetyCircuitLibrary, Not supported yet
    
    GeneratorOverspeed : GeneratorOverspeed, Not supported yet
    
    RotorOverspeed : RotorOverspeed, Not supported yet
    
    GeneratorOverpower : GeneratorOverpower, Not supported yet
    
    NacelleVibration : NacelleVibration, Not supported yet
    
    GeneratorShortCircuit : GeneratorShortCircuit, Not supported yet
    
    EmergencyStopButton : EmergencyStopButton, Not supported yet
    
    OnlyActivateOnceLoggingHasCommenced : bool, Not supported yet
        If true, the safety system will be inactivated during the lead in time when there is no logging.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    SafetyCircuitLibrary: SafetyCircuitLibraryModel = Field(alias="SafetyCircuitLibrary", default_factory=SafetyCircuitLibrary) # Not supported yet
    r"""

    *Not supported yet*

    """

    GeneratorOverspeed: GeneratorOverspeedModel = Field(alias="GeneratorOverspeed", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    RotorOverspeed: RotorOverspeedModel = Field(alias="RotorOverspeed", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    GeneratorOverpower: GeneratorOverpowerModel = Field(alias="GeneratorOverpower", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleVibration: NacelleVibrationModel = Field(alias="NacelleVibration", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    GeneratorShortCircuit: GeneratorShortCircuitModel = Field(alias="GeneratorShortCircuit", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    EmergencyStopButton: EmergencyStopButtonModel = Field(alias="EmergencyStopButton", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    OnlyActivateOnceLoggingHasCommenced: bool = Field(alias="OnlyActivateOnceLoggingHasCommenced", default=None) # Not supported yet
    r"""
    If true, the safety system will be inactivated during the lead in time when there is no logging.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/SafetySystem/SafetySystem.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['SafetyCircuitLibrary', ]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SafetySystem.model_rebuild()
