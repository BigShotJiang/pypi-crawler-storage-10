# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.regular_waves import RegularWaves
from dnv_bladed_models.regular_waves import RegularWaves as RegularWavesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class StreamFunction(RegularWaves):
    r"""
    The definition of Stream Function waves.
    
    Not supported yet.
    
    Attributes
    ----------
    WavesType : Literal['StreamFunction'], default='StreamFunction', Not supported yet
        Defines the specific type of Waves model in use.  For a `StreamFunction` object, this must always be set to a value of `StreamFunction`.
    
    UseTotalAcceleration : bool, Not supported yet
        If true, total acceleration (convective and time derivative) will be used for Morison loading when using the stream function.  The water particle accelerations in Bladed only include the time derivative terms. The convective terms of the water particles can be added when using the stream function for the water particle acceleration calculations.  If irregular waves and additional constrained waves are applied, where the constrained wave is defined by a stream function and total acceleration is turned on, the water particle acceleration will be calculated using local derivatives for the irregular waves and substantive derivatives for the constrained waves and will therefore be inconsistent.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    WavesType: Literal['StreamFunction'] = Field(alias="WavesType", default='StreamFunction', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Waves model in use.  For a `StreamFunction` object, this must always be set to a value of `StreamFunction`.

    *Not supported yet*

    - default = 'StreamFunction'
    """

    UseTotalAcceleration: bool = Field(alias="UseTotalAcceleration", default=None) # Not supported yet
    r"""
    If true, total acceleration (convective and time derivative) will be used for Morison loading when using the stream function.  The water particle accelerations in Bladed only include the time derivative terms. The convective terms of the water particles can be added when using the stream function for the water particle acceleration calculations.  If irregular waves and additional constrained waves are applied, where the constrained wave is defined by a stream function and total acceleration is turned on, the water particle acceleration will be calculated using local derivatives for the irregular waves and substantive derivatives for the constrained waves and will therefore be inconsistent.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Waves/StreamFunction.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'WavesType').merge(RegularWaves._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


StreamFunction.model_rebuild()
