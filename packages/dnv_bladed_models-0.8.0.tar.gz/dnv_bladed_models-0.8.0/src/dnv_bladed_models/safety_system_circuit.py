# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SafetySystemCircuit(BladedModel):
    r"""
    A safety system circuit, which defines the actions that will be taken if it is triggered.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchAction : bool, Not supported yet
        If true, the pitch system will be asked to activate its own safety system.
    
    ApplyShaftBrake1 : bool, Not supported yet
        If true, the third shaft brake will be activated.
    
    ApplyShaftBrake2 : bool, Not supported yet
        If true, the third shaft brake will be activated.
    
    ApplyShaftBrake3 : bool, Not supported yet
        If true, the third shaft brake will be activated.
    
    DisconnectGenerator : bool, Not supported yet
        If true, the generator will be disconnected from the grid.
    
    ApplyGeneratorBrake : bool, Not supported yet
        If true, the generator brake will be activated.
    
    DisconnectYawDrive : bool, Not supported yet
        If true, the yaw drive will be disconnected.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    PitchAction: bool = Field(alias="PitchAction", default=None) # Not supported yet
    r"""
    If true, the pitch system will be asked to activate its own safety system.

    *Not supported yet*

    """

    ApplyShaftBrake1: bool = Field(alias="ApplyShaftBrake1", default=None) # Not supported yet
    r"""
    If true, the third shaft brake will be activated.

    *Not supported yet*

    """

    ApplyShaftBrake2: bool = Field(alias="ApplyShaftBrake2", default=None) # Not supported yet
    r"""
    If true, the third shaft brake will be activated.

    *Not supported yet*

    """

    ApplyShaftBrake3: bool = Field(alias="ApplyShaftBrake3", default=None) # Not supported yet
    r"""
    If true, the third shaft brake will be activated.

    *Not supported yet*

    """

    DisconnectGenerator: bool = Field(alias="DisconnectGenerator", default=None) # Not supported yet
    r"""
    If true, the generator will be disconnected from the grid.

    *Not supported yet*

    """

    ApplyGeneratorBrake: bool = Field(alias="ApplyGeneratorBrake", default=None) # Not supported yet
    r"""
    If true, the generator brake will be activated.

    *Not supported yet*

    """

    DisconnectYawDrive: bool = Field(alias="DisconnectYawDrive", default=None) # Not supported yet
    r"""
    If true, the yaw drive will be disconnected.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/SafetySystem/SafetyCircuitLibrary/SafetySystemCircuit/SafetySystemCircuit.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SafetySystemCircuit.model_rebuild()
