# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.gearbox_mounting_rolling import GearboxMountingRolling
from dnv_bladed_models.gearbox_mounting_rolling import GearboxMountingRolling as GearboxMountingRollingModel
from dnv_bladed_models.pallet_nodding import PalletNodding
from dnv_bladed_models.pallet_nodding import PalletNodding as PalletNoddingModel
from dnv_bladed_models.pallet_rolling import PalletRolling
from dnv_bladed_models.pallet_rolling import PalletRolling as PalletRollingModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PalletMountingFlexibility(BladedModel):
    r"""
    The parameters defining the flexibility of the drivetrain mounting.
    
    Attributes
    ----------
    PalletRolling : PalletRolling
    
    PalletNodding : PalletNodding
    
    GearboxMountingRolling : GearboxMountingRolling
    
    Notes
    -----
    
    """

    PalletRolling: PalletRollingModel = Field(alias="PalletRolling", default=None)
    r"""
    """

    PalletNodding: PalletNoddingModel = Field(alias="PalletNodding", default=None)
    r"""
    """

    GearboxMountingRolling: GearboxMountingRollingModel = Field(alias="GearboxMountingRolling", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/PalletMountingFlexibility/PalletMountingFlexibility.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PalletMountingFlexibility.model_rebuild()
