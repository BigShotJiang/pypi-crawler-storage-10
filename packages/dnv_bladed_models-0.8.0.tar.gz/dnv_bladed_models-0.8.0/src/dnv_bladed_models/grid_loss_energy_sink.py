# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class GridLossEnergySink(BladedModel):
    r"""
    An energy sink used to absorb the power from the generator in the case of a grid loss where generator braking is used.
    
    Not supported yet.
    
    Attributes
    ----------
    MaximumGeneratorTorque : float, default=0, Not supported yet
        The maximum generator torque while the energy sink is active after grid loss has occurred.  This limit is applied to generator torque demand in addition to the maximum torque demand specified in the generator model parameters.
    
    EnergyCapacityOfSink : float, default=0, Not supported yet
        The total generator mechanical input energy which can be absorbed before generator torque falls to zero following grid loss.  In a multi-rotor turbine, this is the energy capacity per rotor.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    MaximumGeneratorTorque: float = Field(alias="MaximumGeneratorTorque", default=None) # Not supported yet
    r"""
    The maximum generator torque while the energy sink is active after grid loss has occurred.  This limit is applied to generator torque demand in addition to the maximum torque demand specified in the generator model parameters.

    *Not supported yet*

    - default = 0
    """

    EnergyCapacityOfSink: float = Field(alias="EnergyCapacityOfSink", default=None) # Not supported yet
    r"""
    The total generator mechanical input energy which can be absorbed before generator torque falls to zero following grid loss.  In a multi-rotor turbine, this is the energy capacity per rotor.

    *Not supported yet*

    - default = 0
    """

    _relative_schema_path: str = 'Turbine/ElectricalGrid/GridLossEnergySink/GridLossEnergySink.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


GridLossEnergySink.model_rebuild()
