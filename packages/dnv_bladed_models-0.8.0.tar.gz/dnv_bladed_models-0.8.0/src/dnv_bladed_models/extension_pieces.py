# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExtensionPieces(BladedModel):
    r"""
    The (typically cylindrical) extension connecting the pitch drive to the blade root.  These can be provided if the drag on this part of the hub needs to be modelled.
    
    Attributes
    ----------
    ExtensionPieceDiameter : float
        The diameter of the (typically cylindrical) extension piece.
    
    CoefficientOfDrag : float
        The coefficient of drag for the extension piece.
    
    Notes
    -----
    
    """

    ExtensionPieceDiameter: float = Field(alias="ExtensionPieceDiameter", default=None)
    r"""
    The diameter of the (typically cylindrical) extension piece.
    """

    CoefficientOfDrag: float = Field(alias="CoefficientOfDrag", default=None)
    r"""
    The coefficient of drag for the extension piece.
    """

    _relative_schema_path: str = 'Components/Hub/ExtensionPieces/ExtensionPieces.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExtensionPieces.model_rebuild()
