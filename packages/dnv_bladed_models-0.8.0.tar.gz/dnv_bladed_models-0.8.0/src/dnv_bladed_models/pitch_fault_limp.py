# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_fault import PitchFault
from dnv_bladed_models.pitch_fault import PitchFault as PitchFaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchFaultLimp(PitchFault):
    r"""
    The failure of a blade's pitch system at a specified time that leaves it without actuation and free to move.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['PitchFaultLimp'], default='PitchFaultLimp', Not supported yet
        Defines the specific type of Event model in use.  For a `PitchFaultLimp` object, this must always be set to a value of `PitchFaultLimp`.
    
    IncludePitchFriction : bool, Not supported yet
        If true, the friction defined in the pitch system will be applied to the joint.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['PitchFaultLimp'] = Field(alias="EventType", default='PitchFaultLimp', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `PitchFaultLimp` object, this must always be set to a value of `PitchFaultLimp`.

    *Not supported yet*

    - default = 'PitchFaultLimp'
    """

    IncludePitchFriction: bool = Field(alias="IncludePitchFriction", default=None) # Not supported yet
    r"""
    If true, the friction defined in the pitch system will be applied to the joint.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/PitchFaultLimp.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(PitchFault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchFaultLimp.model_rebuild()
