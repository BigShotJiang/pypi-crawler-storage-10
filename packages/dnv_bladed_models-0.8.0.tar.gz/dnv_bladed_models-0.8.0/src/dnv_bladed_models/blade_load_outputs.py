# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladeLoadOutputs(BladedModel):
    r"""
    Loads selected
    
    Not supported yet.
    
    Attributes
    ----------
    FlapwiseBendingLoads : bool, default=False, Not supported yet
        Output blade bending moments for the flapwise direction (0=no, 1=yes).
    
    EdgewiseBendingLoads : bool, default=False, Not supported yet
        Output blade bending moments for the edgewise direction (0=no, 1=yes).
    
    FlapwiseShearLoads : bool, default=False, Not supported yet
        Output blade shear forces for the flapwise direction (0=no, 1=yes).
    
    EdgewiseShearLoads : bool, default=False, Not supported yet
        Output blade shear forces for the edgewise direction (0=no, 1=yes).
    
    OutOfPlaneBendingLoads : bool, default=False, Not supported yet
        Output blade bending moments for out of plane direction (0=no, 1=yes).
    
    InPlaneBendingLoads : bool, default=False, Not supported yet
        Output blade bending moments for in plane direction (0=no, 1=yes).
    
    OutOfPlaneShearLoads : bool, default=False, Not supported yet
        Output blade shear forces for out of plane direction (0=no, 1=yes).
    
    InPlaneShearLoads : bool, default=False, Not supported yet
        Output blade shear forces for in plane direction (0=no, 1=yes).
    
    RadialForces : bool, default=False, Not supported yet
        Output blade radial forces (0=no, 1=yes).
    
    LoadsInRootAxisSystem : bool, default=False, Not supported yet
        Output blade loads about the root axes system (0=no, 1=yes).
    
    LoadsInAeroAxisSystem : bool, default=False, Not supported yet
        Output blade loads about the aero axes system (0=no, 1=yes).
    
    LoadsInUserAxisSystem : bool, default=False, Not supported yet
        Output blade loads about the user defined axes system (0=no, 1=yes).
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    FlapwiseBendingLoads: bool = Field(alias="FlapwiseBendingLoads", default=None) # Not supported yet
    r"""
    Output blade bending moments for the flapwise direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    EdgewiseBendingLoads: bool = Field(alias="EdgewiseBendingLoads", default=None) # Not supported yet
    r"""
    Output blade bending moments for the edgewise direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    FlapwiseShearLoads: bool = Field(alias="FlapwiseShearLoads", default=None) # Not supported yet
    r"""
    Output blade shear forces for the flapwise direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    EdgewiseShearLoads: bool = Field(alias="EdgewiseShearLoads", default=None) # Not supported yet
    r"""
    Output blade shear forces for the edgewise direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    OutOfPlaneBendingLoads: bool = Field(alias="OutOfPlaneBendingLoads", default=None) # Not supported yet
    r"""
    Output blade bending moments for out of plane direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    InPlaneBendingLoads: bool = Field(alias="InPlaneBendingLoads", default=None) # Not supported yet
    r"""
    Output blade bending moments for in plane direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    OutOfPlaneShearLoads: bool = Field(alias="OutOfPlaneShearLoads", default=None) # Not supported yet
    r"""
    Output blade shear forces for out of plane direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    InPlaneShearLoads: bool = Field(alias="InPlaneShearLoads", default=None) # Not supported yet
    r"""
    Output blade shear forces for in plane direction (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    RadialForces: bool = Field(alias="RadialForces", default=None) # Not supported yet
    r"""
    Output blade radial forces (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    LoadsInRootAxisSystem: bool = Field(alias="LoadsInRootAxisSystem", default=None) # Not supported yet
    r"""
    Output blade loads about the root axes system (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    LoadsInAeroAxisSystem: bool = Field(alias="LoadsInAeroAxisSystem", default=None) # Not supported yet
    r"""
    Output blade loads about the aero axes system (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    LoadsInUserAxisSystem: bool = Field(alias="LoadsInUserAxisSystem", default=None) # Not supported yet
    r"""
    Output blade loads about the user defined axes system (0=no, 1=yes).

    *Not supported yet*

    - default = False
    """

    _relative_schema_path: str = 'Components/Blade/BladeOutputGroupLibrary/BladeOutputGroup/BladeLoadOutputs/BladeLoadOutputs.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladeLoadOutputs.model_rebuild()
