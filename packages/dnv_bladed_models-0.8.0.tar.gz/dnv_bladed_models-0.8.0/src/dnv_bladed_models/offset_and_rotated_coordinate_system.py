# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class OffsetAndRotatedCoordinateSystem(BladedModel):
    r"""
    The X- and Y-offsets and a rotation, relative to the ReferenceCoordinateSystem, are used to position and orient a coordinate system.
    
    Attributes
    ----------
    OffsetInReferenceX : float, default=0
        The X-offset of the coordinate system origin along the reference X-axis, relative to the ReferenceCoordinateSystem.
    
    OffsetInReferenceY : float, default=0
        The Y-offset of the coordinate system origin along the reference Y-axis, relative to the ReferenceCoordinateSystem.
    
    RotationAboutReferenceZ : float, default=0
        The rotation of the coordinate system's X- and Y-axes around the reference Z-axis (the section plane normal).
    
    Notes
    -----
    
    """

    OffsetInReferenceX: float = Field(alias="OffsetInReferenceX", default=None)
    r"""
    The X-offset of the coordinate system origin along the reference X-axis, relative to the ReferenceCoordinateSystem.
    - default = 0
    """

    OffsetInReferenceY: float = Field(alias="OffsetInReferenceY", default=None)
    r"""
    The Y-offset of the coordinate system origin along the reference Y-axis, relative to the ReferenceCoordinateSystem.
    - default = 0
    """

    RotationAboutReferenceZ: float = Field(alias="RotationAboutReferenceZ", default=None)
    r"""
    The rotation of the coordinate system's X- and Y-axes around the reference Z-axis (the section plane normal).
    - default = 0
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/CoordinateSystems/OffsetAndRotatedCoordinateSystem/OffsetAndRotatedCoordinateSystem.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


OffsetAndRotatedCoordinateSystem.model_rebuild()
