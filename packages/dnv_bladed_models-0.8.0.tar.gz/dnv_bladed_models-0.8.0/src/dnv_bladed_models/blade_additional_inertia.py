# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.blade_point_mass import BladePointMass
from dnv_bladed_models.blade_point_mass import BladePointMass as BladePointMassModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladeAdditionalInertia(BladedModel):
    r"""
    The definition of additional inertias applied in the whole blade context.
    
    Attributes
    ----------
    PointInertias : List[BladePointMass]
        A list of point inertias to be applied to the blade structure.
    
    AdditionalWholeBladePitchingInertia : float, default=0
        Any additional pitching inertia on the whole blade.
    
    Notes
    -----
    
    """

    PointInertias: List[BladePointMassModel] = Field(alias="PointInertias", default_factory=list)
    r"""
    A list of point inertias to be applied to the blade structure.
    """

    AdditionalWholeBladePitchingInertia: float = Field(alias="AdditionalWholeBladePitchingInertia", default=None)
    r"""
    Any additional pitching inertia on the whole blade.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Blade/BladeAdditionalInertia/BladeAdditionalInertia.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['PointInertias',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladeAdditionalInertia.model_rebuild()
