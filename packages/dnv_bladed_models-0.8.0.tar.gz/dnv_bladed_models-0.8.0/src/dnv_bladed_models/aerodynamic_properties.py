# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class AerodynamicProperties(BladedModel):
    r"""
    The aerodynamic properties of the blade cross-section.  These are defined in the QuarterChordCoordinateSystem, which specifies the position and orientation of the aerofoil.
    
    Attributes
    ----------
    Chord : float
        The chord of the blade at this cross-section, measured from leading to trailing edge.  The cross-section will be positioned so that the aerofoil's quarter-chord position coincides with the origin of the QuarterChordCoordinateSystem.
    
    ThicknessToChordRatio : float
        The ratio between the thickness and the chord length at the cross-section.  This would be 1.0 for a cylinder, and in the order of 0.1 (or 10%) for a typical slender aerofoil section.
    
    AerodynamicData : str, regex=^(AerofoilLibrary|InterpolatedAerofoilLibrary|AileronAerofoilLibrary).(.+)$
        A reference to an aerofoil, interpolated aerofoil, or aileron aerofoil to use for this cross-section.  The value must be the key of an aerofoil definition in either the AerofoilLibrary, InterpolatedAerofoilLibrary or AileronAerofoilLibrary.  i.e.  `AerofoilLibrary.<key>` or `InterpolatedAerofoilLibrary.<key>` or `AileronAerofoilLibrary.<key>`
    
    Notes
    -----
    
    """

    Chord: float = Field(alias="Chord", default=None)
    r"""
    The chord of the blade at this cross-section, measured from leading to trailing edge.  The cross-section will be positioned so that the aerofoil's quarter-chord position coincides with the origin of the QuarterChordCoordinateSystem.
    """

    ThicknessToChordRatio: float = Field(alias="ThicknessToChordRatio", default=None)
    r"""
    The ratio between the thickness and the chord length at the cross-section.  This would be 1.0 for a cylinder, and in the order of 0.1 (or 10%) for a typical slender aerofoil section.
    """

    AerodynamicData: str = Field(alias="@AerodynamicData", default=None, pattern='^(AerofoilLibrary|InterpolatedAerofoilLibrary|AileronAerofoilLibrary).(.+)$')
    r"""
    A reference to an aerofoil, interpolated aerofoil, or aileron aerofoil to use for this cross-section.  The value must be the key of an aerofoil definition in either the AerofoilLibrary, InterpolatedAerofoilLibrary or AileronAerofoilLibrary.  i.e.  `AerofoilLibrary.<key>` or `InterpolatedAerofoilLibrary.<key>` or `AileronAerofoilLibrary.<key>`
    - regex = ^(AerofoilLibrary|InterpolatedAerofoilLibrary|AileronAerofoilLibrary).(.+)$
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/AerodynamicProperties/AerodynamicProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


AerodynamicProperties.model_rebuild()
