# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class BladeOutputsForLocation_BladeOutputsForLocationTypeEnum(str, Enum):
    OUTPUTS_FOR_CROSS_SECTION = "OutputsForCrossSection"
    OUTPUTS_FOR_POSITION = "OutputsForPosition"
    INSERT = "Insert"



class BladeOutputsForLocation(BladedModel, ABC):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    BladeOutputsForLocationType : BladeOutputsForLocation_BladeOutputsForLocationTypeEnum, Not supported yet
        Defines the specific type of model in use.
    
    Loads : bool, default=False, Not supported yet
        An array of blade station indices to output loads for (exclusive with BLOADS_POS).
    
    Motion : bool, default=False, Not supported yet
        An array of blade station indices to output deflections for (exclusive with BDEFLS_POS).
    
    Aerodynamics : bool, Not supported yet
        Whether to output loads on this node
    
    Hydrodynamics : bool, default=False, Not supported yet
        An array of blade radii to output water kinematics for (tidal only).
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    This class is an abstraction, with the following concrete implementations:
        - BladeOutputsForLocationInsert
        - BladeOutputsForCrossSection
        - BladeOutputsForPosition
    
    """

    BladeOutputsForLocationType: BladeOutputsForLocation_BladeOutputsForLocationTypeEnum = Field(alias="BladeOutputsForLocationType", default=None) # Not supported yet
    r"""
    Defines the specific type of model in use.

    *Not supported yet*

    """

    Loads: bool = Field(alias="Loads", default=None) # Not supported yet
    r"""
    An array of blade station indices to output loads for (exclusive with BLOADS_POS).

    *Not supported yet*

    - default = False
    """

    Motion: bool = Field(alias="Motion", default=None) # Not supported yet
    r"""
    An array of blade station indices to output deflections for (exclusive with BDEFLS_POS).

    *Not supported yet*

    - default = False
    """

    Aerodynamics: bool = Field(alias="Aerodynamics", default=None) # Not supported yet
    r"""
    Whether to output loads on this node

    *Not supported yet*

    """

    Hydrodynamics: bool = Field(alias="Hydrodynamics", default=None) # Not supported yet
    r"""
    An array of blade radii to output water kinematics for (tidal only).

    *Not supported yet*

    - default = False
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

BladeOutputsForLocation.model_rebuild()
