# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.brake import Brake
from dnv_bladed_models.brake import Brake as BrakeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SimpleShaftBrake(Brake):
    r"""
    The definition of a simple shaft brake whose retarding torque will increase linearly over a set time.
    
    Attributes
    ----------
    BrakeType : Literal['SimpleShaftBrake'], default='SimpleShaftBrake'
        Defines the specific type of Brake model in use.  For a `SimpleShaftBrake` object, this must always be set to a value of `SimpleShaftBrake`.
    
    MaximumTorque : float
        The maximum retarding torque to apply to the shaft.
    
    RampTime : float
        The amount of time following the brake's activation to reach maximum torque.
    
    Notes
    -----
    
    """

    BrakeType: Literal['SimpleShaftBrake'] = Field(alias="BrakeType", default='SimpleShaftBrake', frozen=True) # type: ignore
    r"""
    Defines the specific type of Brake model in use.  For a `SimpleShaftBrake` object, this must always be set to a value of `SimpleShaftBrake`.
    - default = 'SimpleShaftBrake'
    """

    MaximumTorque: float = Field(alias="MaximumTorque", default=None)
    r"""
    The maximum retarding torque to apply to the shaft.
    """

    RampTime: float = Field(alias="RampTime", default=None)
    r"""
    The amount of time following the brake's activation to reach maximum torque.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/Brake/SimpleShaftBrake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'BrakeType').merge(Brake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SimpleShaftBrake.model_rebuild()
