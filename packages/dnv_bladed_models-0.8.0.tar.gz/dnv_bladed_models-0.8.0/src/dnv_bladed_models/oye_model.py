# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_stall import DynamicStall
from dnv_bladed_models.dynamic_stall import DynamicStall as DynamicStallModel
from .schema_helper import SchemaHelper
from .base_entity import *




class OyeModel(DynamicStall):
    r"""
    The Oye dynamic stall model.
    
    Attributes
    ----------
    DynamicStallType : Literal['OyeModel'], default='OyeModel'
        Defines the specific type of DynamicStall model in use.  For a `OyeModel` object, this must always be set to a value of `OyeModel`.
    
    Notes
    -----
    
    """

    DynamicStallType: Literal['OyeModel'] = Field(alias="DynamicStallType", default='OyeModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicStall model in use.  For a `OyeModel` object, this must always be set to a value of `OyeModel`.
    - default = 'OyeModel'
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/DynamicStall/OyeModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicStallType').merge(DynamicStall._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


OyeModel.model_rebuild()
