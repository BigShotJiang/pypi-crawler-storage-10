# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.alpha_line import AlphaLine
from dnv_bladed_models.alpha_line import AlphaLine as AlphaLineModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Aerofoil(BladedModel):
    r"""
    The definition of a single 2D aerodynamic aerofoil section.
    
    Attributes
    ----------
    ChordwiseOriginForForcesAndMoments : float, default=0.25
        The fraction of the chord from the leading edge to the position about which Cl, Cd, and Cm have been calculated.  This is traditionally 0.25 (25%), but can be any location so long as it is consistent with the provided aerodynamic data.
    
    AerodynamicPerformance : List[AlphaLine]
        The relationship between angle of attack, and the lift and drag coefficients.
    
    ReynoldsNumber : float
        The Reynolds number at which the aerodynamic properties were obtained.
    
    ThicknessToChordRatio : float
        The ratio between the thickness and the chord length of the measured aerofoil.
    
    Notes
    -----
    
    """

    ChordwiseOriginForForcesAndMoments: float = Field(alias="ChordwiseOriginForForcesAndMoments", default=None)
    r"""
    The fraction of the chord from the leading edge to the position about which Cl, Cd, and Cm have been calculated.  This is traditionally 0.25 (25%), but can be any location so long as it is consistent with the provided aerodynamic data.
    - default = 0.25
    """

    AerodynamicPerformance: List[AlphaLineModel] = Field(alias="AerodynamicPerformance", default_factory=list)
    r"""
    The relationship between angle of attack, and the lift and drag coefficients.
    """

    ReynoldsNumber: float = Field(alias="ReynoldsNumber", default=None)
    r"""
    The Reynolds number at which the aerodynamic properties were obtained.
    """

    ThicknessToChordRatio: float = Field(alias="ThicknessToChordRatio", default=None)
    r"""
    The ratio between the thickness and the chord length of the measured aerofoil.
    """

    _relative_schema_path: str = 'Components/Blade/AerofoilLibrary/Aerofoil/Aerofoil.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['AerodynamicPerformance',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Aerofoil.model_rebuild()
