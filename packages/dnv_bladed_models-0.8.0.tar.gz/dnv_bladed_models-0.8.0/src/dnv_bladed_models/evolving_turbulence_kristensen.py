# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.evolving_turbulence import EvolvingTurbulence
from dnv_bladed_models.evolving_turbulence import EvolvingTurbulence as EvolvingTurbulenceModel
from .schema_helper import SchemaHelper
from .base_entity import *




class EvolvingTurbulenceKristensen(EvolvingTurbulence):
    r"""
    The settings for Kristensen evolving turbulence.  In the case of a normal turbulent wind field, the turbulence is \"frozen\" and approaches the turbine at a constant block.  Although this doesn't match physical reality, it is a particular problem for Lidar - as it gives them a \"perfect\" insight into the oncoming wind field.  In order to represent the nature of real turbulence, a second turbulence file is superimposed on the windfield so that it \"evolves\" as it moves forward.  This is computationally expensive, and is usually applied only to the Lidar readings - although it can be applied to all the wind values in a simulation.
    
    Attributes
    ----------
    EvolvingTurbulenceType : Literal['EvolvingTurbulenceKristensen'], default='EvolvingTurbulenceKristensen'
        Defines the specific type of EvolvingTurbulence model in use.  For a `EvolvingTurbulenceKristensen` object, this must always be set to a value of `EvolvingTurbulenceKristensen`.
    
    Notes
    -----
    
    """

    EvolvingTurbulenceType: Literal['EvolvingTurbulenceKristensen'] = Field(alias="EvolvingTurbulenceType", default='EvolvingTurbulenceKristensen', frozen=True) # type: ignore
    r"""
    Defines the specific type of EvolvingTurbulence model in use.  For a `EvolvingTurbulenceKristensen` object, this must always be set to a value of `EvolvingTurbulenceKristensen`.
    - default = 'EvolvingTurbulenceKristensen'
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/EvolvingTurbulence/EvolvingTurbulenceKristensen.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EvolvingTurbulenceType').merge(EvolvingTurbulence._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


EvolvingTurbulenceKristensen.model_rebuild()
