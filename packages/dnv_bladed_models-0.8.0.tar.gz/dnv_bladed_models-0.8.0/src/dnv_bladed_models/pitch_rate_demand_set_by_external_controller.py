# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_controller_rate_safety_system import PitchControllerRateSafetySystem
from dnv_bladed_models.pitch_controller_rate_safety_system import PitchControllerRateSafetySystem as PitchControllerRateSafetySystemModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchRateDemandSetByExternalController(PitchControllerRateSafetySystem):
    r"""
    A pitch safety system where the rate is specified by the main controller.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchSafetySystemType : Literal['RateDemandSetByExternalController'], default='RateDemandSetByExternalController', Not supported yet
        Defines the specific type of PitchSafetySystem model in use.  For a `RateDemandSetByExternalController` object, this must always be set to a value of `RateDemandSetByExternalController`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    PitchSafetySystemType: Literal['RateDemandSetByExternalController'] = Field(alias="PitchSafetySystemType", default='RateDemandSetByExternalController', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of PitchSafetySystem model in use.  For a `RateDemandSetByExternalController` object, this must always be set to a value of `RateDemandSetByExternalController`.

    *Not supported yet*

    - default = 'RateDemandSetByExternalController'
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSafetySystem/PitchRateDemandSetByExternalController.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'PitchSafetySystemType').merge(PitchControllerRateSafetySystem._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchRateDemandSetByExternalController.model_rebuild()
