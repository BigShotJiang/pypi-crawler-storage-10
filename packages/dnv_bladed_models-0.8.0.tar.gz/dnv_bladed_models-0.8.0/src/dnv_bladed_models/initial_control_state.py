# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.initial_condition import InitialCondition
from dnv_bladed_models.initial_condition import InitialCondition as InitialConditionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class InitialControlState(InitialCondition, ABC):
    r"""
    The initial operational state of the turbine.
    
    Attributes
    ----------
    OnComponentInAssembly : str, regex=^Assembly.(.+)$
        The rotor which is in this state.  If omitted, all rotors on the turbine will be in this state.  A qualified, dot-separated path to a component in the assembly tree to which this applies.  i.e. `Assembly.<name1>.<name2>`
    
    Notes
    -----
    
    """

    OnComponentInAssembly: str = Field(alias="@OnComponentInAssembly", default=None, pattern='^Assembly.(.+)$')
    r"""
    The rotor which is in this state.  If omitted, all rotors on the turbine will be in this state.  A qualified, dot-separated path to a component in the assembly tree to which this applies.  i.e. `Assembly.<name1>.<name2>`
    - regex = ^Assembly.(.+)$
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(InitialCondition._type_info)

InitialControlState.model_rebuild()
