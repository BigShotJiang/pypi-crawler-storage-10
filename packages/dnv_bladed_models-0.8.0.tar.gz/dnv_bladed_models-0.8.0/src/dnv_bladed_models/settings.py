# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.aerodynamic_settings import AerodynamicSettings
from dnv_bladed_models.aerodynamic_settings import AerodynamicSettings as AerodynamicSettingsModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.hydrodynamic_calculation import HydrodynamicCalculation
from dnv_bladed_models.hydrodynamic_calculation import HydrodynamicCalculation as HydrodynamicCalculationModel
from dnv_bladed_models.logging import Logging
from dnv_bladed_models.logging import Logging as LoggingModel
from dnv_bladed_models.solver_settings import SolverSettings
from dnv_bladed_models.solver_settings import SolverSettings as SolverSettingsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Settings(BladedModel):
    r"""
    The settings for both time domain simulations and steady calculations.  These are typically calculation options which have reliable defaults, but offer the users other options to control the analysis.
    
    Attributes
    ----------
    Solver : SolverSettings
    
    Aerodynamics : AerodynamicSettings
    
    Hydrodynamics : HydrodynamicCalculation, Not supported yet
    
    Logging : Logging
    
    Notes
    -----
    
    """

    Solver: SolverSettingsModel = Field(alias="Solver", default=None)
    r"""
    """

    Aerodynamics: AerodynamicSettingsModel = Field(alias="Aerodynamics", default=None)
    r"""
    """

    Hydrodynamics: HydrodynamicCalculationModel = Field(alias="Hydrodynamics", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    Logging: LoggingModel = Field(alias="Logging", default=None)
    r"""
    """

    _relative_schema_path: str = 'Settings/Settings.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Settings.model_rebuild()
