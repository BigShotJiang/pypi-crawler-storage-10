# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_controller_torque_safety_system import PitchControllerTorqueSafetySystem
from dnv_bladed_models.pitch_controller_torque_safety_system import PitchControllerTorqueSafetySystem as PitchControllerTorqueSafetySystemModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchTorqueSetByExternalController(PitchControllerTorqueSafetySystem):
    r"""
    A pitch safety system where the torque is specified by the main controller.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchSafetySystemType : Literal['TorqueSetByExternalController'], default='TorqueSetByExternalController', Not supported yet
        Defines the specific type of PitchSafetySystem model in use.  For a `TorqueSetByExternalController` object, this must always be set to a value of `TorqueSetByExternalController`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    PitchSafetySystemType: Literal['TorqueSetByExternalController'] = Field(alias="PitchSafetySystemType", default='TorqueSetByExternalController', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of PitchSafetySystem model in use.  For a `TorqueSetByExternalController` object, this must always be set to a value of `TorqueSetByExternalController`.

    *Not supported yet*

    - default = 'TorqueSetByExternalController'
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSafetySystem/PitchTorqueSetByExternalController.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'PitchSafetySystemType').merge(PitchControllerTorqueSafetySystem._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchTorqueSetByExternalController.model_rebuild()
