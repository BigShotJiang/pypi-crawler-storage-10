# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.nodes_at_heights import NodesAtHeights
from dnv_bladed_models.nodes_at_heights import NodesAtHeights as NodesAtHeightsModel
from dnv_bladed_models.tower_node_loads import TowerNodeLoads
from dnv_bladed_models.tower_node_loads import TowerNodeLoads as TowerNodeLoadsModel
from dnv_bladed_models.tower_node_outputs import TowerNodeOutputs
from dnv_bladed_models.tower_node_outputs import TowerNodeOutputs as TowerNodeOutputsModel
from .schema_helper import SchemaHelper
from .base_entity import *


class TowerOutputGroup_AxisSystemEnum(str, Enum):
    GLOBAL = "GLOBAL"



class TowerOutputGroup(BladedModel):
    r"""
    A named tower output group.
    
    Not supported yet.
    
    Attributes
    ----------
    SelectedNodeLoads : TowerNodeLoads, Not supported yet
    
    AxisSystem : TowerOutputGroup_AxisSystemEnum, default='GLOBAL', Not supported yet
        The axis sytstem to be used for the outputs.
    
    AllConnectableNodes : TowerNodeOutputs, Not supported yet
    
    AllNodes : TowerNodeOutputs, Not supported yet
    
    NodesAtHeights : NodesAtHeights, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    SelectedNodeLoads: TowerNodeLoadsModel = Field(alias="SelectedNodeLoads", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    AxisSystem: TowerOutputGroup_AxisSystemEnum = Field(alias="AxisSystem", default=None) # Not supported yet
    r"""
    The axis sytstem to be used for the outputs.

    *Not supported yet*

    - default = 'GLOBAL'
    """

    AllConnectableNodes: TowerNodeOutputsModel = Field(alias="AllConnectableNodes", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    AllNodes: TowerNodeOutputsModel = Field(alias="AllNodes", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NodesAtHeights: NodesAtHeightsModel = Field(alias="NodesAtHeights", default_factory=NodesAtHeights) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Tower/TowerOutputGroupLibrary/TowerOutputGroup/TowerOutputGroup.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['NodesAtHeights', ]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerOutputGroup.model_rebuild()
