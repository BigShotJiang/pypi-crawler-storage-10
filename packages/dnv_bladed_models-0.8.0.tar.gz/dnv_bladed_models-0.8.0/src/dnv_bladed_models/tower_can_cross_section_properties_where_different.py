# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.tower_can_cross_section_with_sensors import TowerCanCrossSectionWithSensors
from dnv_bladed_models.tower_can_cross_section_with_sensors import TowerCanCrossSectionWithSensors as TowerCanCrossSectionWithSensorsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerCanCrossSectionPropertiesWhereDifferent(TowerCanCrossSectionWithSensors, ABC):
    r"""
    The definition of a can cross-section where the material properties, the diameter, and the wall thickness will be used to calculate the structural properties.  Any properties which are omitted will be taken from the BaseCrossSection definition.
    
    Attributes
    ----------
    OutsideDiameter : float
        The external diameter of the can cross-section.  If omitted, the value from the BaseCrossSection will be used.
    
    Notes
    -----
    
    """

    OutsideDiameter: float = Field(alias="OutsideDiameter", default=None)
    r"""
    The external diameter of the can cross-section.  If omitted, the value from the BaseCrossSection will be used.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(TowerCanCrossSectionWithSensors._type_info)

TowerCanCrossSectionPropertiesWhereDifferent.model_rebuild()
