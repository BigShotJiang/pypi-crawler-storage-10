# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.pitch_safety_limit_switches import PitchSafetyLimitSwitches
from dnv_bladed_models.pitch_safety_limit_switches import PitchSafetyLimitSwitches as PitchSafetyLimitSwitchesModel
from dnv_bladed_models.standard_pitch_limit_switches import StandardPitchLimitSwitches
from dnv_bladed_models.standard_pitch_limit_switches import StandardPitchLimitSwitches as StandardPitchLimitSwitchesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchLimitSwitches(BladedModel):
    r"""
    The definition of the limit switches for the standard control system and the safety system.
    
    Attributes
    ----------
    Safety : PitchSafetyLimitSwitches
    
    Standard : StandardPitchLimitSwitches
    
    Notes
    -----
    
    """

    Safety: PitchSafetyLimitSwitchesModel = Field(alias="Safety", default=None)
    r"""
    """

    Standard: StandardPitchLimitSwitchesModel = Field(alias="Standard", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchLimitSwitches/PitchLimitSwitches.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchLimitSwitches.model_rebuild()
