# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TimeVsCurrentDirection(BladedModel):
    r"""
    A line or row in a look-up table, specifying a value of Direction for a specified Time.
    
    Not supported yet.
    
    Attributes
    ----------
    Time : float, Not supported yet
        The time into the simulation (excluding the lead-in time).
    
    Direction : float, Not supported yet
        The current's direction at the specified time.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Time: float = Field(alias="Time", default=None) # Not supported yet
    r"""
    The time into the simulation (excluding the lead-in time).

    *Not supported yet*

    """

    Direction: float = Field(alias="Direction", default=None) # Not supported yet
    r"""
    The current's direction at the specified time.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/CurrentDirectionVariation/TimeVsCurrentDirection/TimeVsCurrentDirection.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TimeVsCurrentDirection.model_rebuild()
