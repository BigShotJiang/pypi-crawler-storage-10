# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.sensor import Sensor
from dnv_bladed_models.sensor import Sensor as SensorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Inclinometer(Sensor):
    r"""
    An inclinometer affixed to a component.
    
    Attributes
    ----------
    SensorType : Literal['Inclinometer'], default='Inclinometer'
        Defines the specific type of Sensor model in use.  For a `Inclinometer` object, this must always be set to a value of `Inclinometer`.
    
    Notes
    -----
    
    """

    SensorType: Literal['Inclinometer'] = Field(alias="SensorType", default='Inclinometer', frozen=True) # type: ignore
    r"""
    Defines the specific type of Sensor model in use.  For a `Inclinometer` object, this must always be set to a value of `Inclinometer`.
    - default = 'Inclinometer'
    """

    _relative_schema_path: str = 'Components/common/Inclinometer.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SensorType').merge(Sensor._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Inclinometer.model_rebuild()
