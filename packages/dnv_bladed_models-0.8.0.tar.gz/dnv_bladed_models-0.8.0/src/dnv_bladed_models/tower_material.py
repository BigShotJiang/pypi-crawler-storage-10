# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerMaterial(BladedModel):
    r"""
    A material definition for use by the tower cans.
    
    Attributes
    ----------
    Density : float
        The density of the material, used to calculate the mass.
    
    YoungsModulus : float
        The Young's modulus, used to calculate the stiffness properties.
    
    ShearModulus : float
        The shear modulus, used to calculate the stiffness properties.
    
    Notes
    -----
    
    """

    Density: float = Field(alias="Density", default=None)
    r"""
    The density of the material, used to calculate the mass.
    """

    YoungsModulus: float = Field(alias="YoungsModulus", default=None)
    r"""
    The Young's modulus, used to calculate the stiffness properties.
    """

    ShearModulus: float = Field(alias="ShearModulus", default=None)
    r"""
    The shear modulus, used to calculate the stiffness properties.
    """

    _relative_schema_path: str = 'Components/Tower/TowerMaterialsLibrary/TowerMaterial/TowerMaterial.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerMaterial.model_rebuild()
