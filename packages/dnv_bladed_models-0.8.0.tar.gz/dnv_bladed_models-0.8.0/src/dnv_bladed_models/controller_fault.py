# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.fault import Fault
from dnv_bladed_models.fault import Fault as FaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ControllerFault(Fault):
    r"""
    A controller fault occuring at a specified time.  A signal will be sent to the controller, and the controller will be expected to implement the fault behaviour.
    
    Attributes
    ----------
    EventType : Literal['ControllerFault'], default='ControllerFault'
        Defines the specific type of Event model in use.  For a `ControllerFault` object, this must always be set to a value of `ControllerFault`.
    
    FaultCode : int
        A fault number that will be provided to the controller.  It is for the controller to decide how to react to this number.
    
    FaultParametersAsString : str
        A string and passed to the external controller at the time the fault occurs.
    
    FaultParametersAsJson : Dict[str, Any]
        A JSON object that will be serialised as a string and passed to the external controller at the time the fault occurs.
    
    Notes
    -----
    
    """

    EventType: Literal['ControllerFault'] = Field(alias="EventType", default='ControllerFault', frozen=True) # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `ControllerFault` object, this must always be set to a value of `ControllerFault`.
    - default = 'ControllerFault'
    """

    FaultCode: int = Field(alias="FaultCode", default=None)
    r"""
    A fault number that will be provided to the controller.  It is for the controller to decide how to react to this number.
    """

    FaultParametersAsString: str = Field(alias="FaultParametersAsString", default=None)
    r"""
    A string and passed to the external controller at the time the fault occurs.
    """

    FaultParametersAsJson: Dict[str, Any] = Field(alias="FaultParametersAsJson", default=None)
    r"""
    A JSON object that will be serialised as a string and passed to the external controller at the time the fault occurs.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/ControllerFault.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(Fault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ControllerFault.model_rebuild()
