# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.brake import Brake
from dnv_bladed_models.brake import Brake as BrakeModel
from dnv_bladed_models.time_vs_torque import TimeVsTorque
from dnv_bladed_models.time_vs_torque import TimeVsTorque as TimeVsTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NonLinearShaftBrake(Brake):
    r"""
    The definition of a shaft brake whose applied torque varies with time.
    
    Attributes
    ----------
    BrakeType : Literal['NonLinearShaftBrake'], default='NonLinearShaftBrake'
        Defines the specific type of Brake model in use.  For a `NonLinearShaftBrake` object, this must always be set to a value of `NonLinearShaftBrake`.
    
    TimeVsTorque : List[TimeVsTorque]
        The relationship between the time following the brake's activation, and the retarding torque it applies to the shaft.
    
    Notes
    -----
    
    """

    BrakeType: Literal['NonLinearShaftBrake'] = Field(alias="BrakeType", default='NonLinearShaftBrake', frozen=True) # type: ignore
    r"""
    Defines the specific type of Brake model in use.  For a `NonLinearShaftBrake` object, this must always be set to a value of `NonLinearShaftBrake`.
    - default = 'NonLinearShaftBrake'
    """

    TimeVsTorque: List[TimeVsTorqueModel] = Field(alias="TimeVsTorque", default_factory=list)
    r"""
    The relationship between the time following the brake's activation, and the retarding torque it applies to the shaft.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/Brake/NonLinearShaftBrake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['TimeVsTorque',]), 'BrakeType').merge(Brake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NonLinearShaftBrake.model_rebuild()
