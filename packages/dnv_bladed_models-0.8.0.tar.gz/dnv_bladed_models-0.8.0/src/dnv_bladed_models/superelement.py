# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from dnv_bladed_models.interface_load_file import InterfaceLoadFile
from dnv_bladed_models.interface_load_file import InterfaceLoadFile as InterfaceLoadFileModel
from dnv_bladed_models.superelement_connectable_nodes import SuperelementConnectableNodes
from dnv_bladed_models.superelement_connectable_nodes import SuperelementConnectableNodes as SuperelementConnectableNodesModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Superelement_WaveLoadingUnitsInFileEnum(str, Enum):
    N = "N"
    K_N = "kN"



class Superelement(Component):
    r"""
    A structural superelement, mathematically representing a structural component.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentType : Literal['Superelement'], default='Superelement', Not supported yet
        Defines the specific type of Component model in use.  For a `Superelement` object, this must always be set to a value of `Superelement`.
    
    DefinitionFilepath : str, Not supported yet
        The filepath of URI to the superelement data.
    
    WaveLoadingFilepath : str, Not supported yet
        The filepath of URI to the accompanying wave data.
    
    WaveLoadingUnitsInFile : Superelement_WaveLoadingUnitsInFileEnum, default='kN', Not supported yet
        The units that were used when generating the wave load files.  The industry standard is to provide wave loads in kN and kNm.
    
    CoordinateTransformationMatrix : List[List[float]]
        A 6x6 matrix to transform one set of coordinates into another.
    
    InterfaceLoadFile : InterfaceLoadFile, Not supported yet
    
    ConnectableNodes : SuperelementConnectableNodes, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentType: Literal['Superelement'] = Field(alias="ComponentType", default='Superelement', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `Superelement` object, this must always be set to a value of `Superelement`.

    *Not supported yet*

    - default = 'Superelement'
    """

    DefinitionFilepath: str = Field(alias="DefinitionFilepath", default=None) # Not supported yet
    r"""
    The filepath of URI to the superelement data.

    *Not supported yet*

    """

    WaveLoadingFilepath: str = Field(alias="WaveLoadingFilepath", default=None) # Not supported yet
    r"""
    The filepath of URI to the accompanying wave data.

    *Not supported yet*

    """

    WaveLoadingUnitsInFile: Superelement_WaveLoadingUnitsInFileEnum = Field(alias="WaveLoadingUnitsInFile", default=None) # Not supported yet
    r"""
    The units that were used when generating the wave load files.  The industry standard is to provide wave loads in kN and kNm.

    *Not supported yet*

    - default = 'kN'
    """

    CoordinateTransformationMatrix: List[List[float]] = Field(alias="CoordinateTransformationMatrix", default_factory=list)
    r"""
    A 6x6 matrix to transform one set of coordinates into another.
    """

    InterfaceLoadFile: InterfaceLoadFileModel = Field(alias="InterfaceLoadFile", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    ConnectableNodes: SuperelementConnectableNodesModel = Field(alias="ConnectableNodes", default_factory=SuperelementConnectableNodes) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Superelement/Superelement.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['CoordinateTransformationMatrix','ConnectableNodes', ]), 'ComponentType').merge(Component._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Superelement.model_rebuild()
