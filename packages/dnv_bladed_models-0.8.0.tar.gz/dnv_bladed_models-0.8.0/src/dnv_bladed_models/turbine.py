# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.assembly import Assembly
from dnv_bladed_models.assembly import Assembly as AssemblyModel
from dnv_bladed_models.bladed_control import BladedControl
from dnv_bladed_models.bladed_control import BladedControl as BladedControlModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.component_library import ComponentLibrary
from dnv_bladed_models.component_library import ComponentLibrary as ComponentLibraryModel
from dnv_bladed_models.electrical_grid import ElectricalGrid
from dnv_bladed_models.electrical_grid import ElectricalGrid as ElectricalGridModel
from dnv_bladed_models.external_module import ExternalModule
from dnv_bladed_models.external_module import ExternalModule as ExternalModuleModel
from dnv_bladed_models.turbine_operational_parameters import TurbineOperationalParameters
from dnv_bladed_models.turbine_operational_parameters import TurbineOperationalParameters as TurbineOperationalParametersModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Turbine(BladedModel):
    r"""
    The definition of the turbine and its installation that is to be modelled.
    
    Attributes
    ----------
    ElectricalGrid : ElectricalGrid, Not supported yet
    
    TurbineOperationalParameters : TurbineOperationalParameters
    
    Control : BladedControl
    
    GlobalExternalModules : List[ExternalModule], Not supported yet
        A list of any external modules that will be run with the time domain simulations.  It is expected that external modules defined here will interact with more than one area of the turbine, such as to apply additional aerodynamics loads to the entire structure.  Any external modules that represent a single component should be added to the Assembly tree.
    
    MeanSeaLevel : float, Not supported yet
        The mean sea depth at the turbine location.  If omitted, the Turbine will be considered an on-shore turbine and any sea states will be ignored.
    
    Assembly : Assembly
    
    ComponentLibrary : ComponentLibrary
    
    Notes
    -----
    
    """

    ElectricalGrid: ElectricalGridModel = Field(alias="ElectricalGrid", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    TurbineOperationalParameters: TurbineOperationalParametersModel = Field(alias="TurbineOperationalParameters", default=None)
    r"""
    """

    Control: BladedControlModel = Field(alias="Control", default=None)
    r"""
    """

    GlobalExternalModules: List[ExternalModuleModel] = Field(alias="GlobalExternalModules", default_factory=list) # Not supported yet
    r"""
    A list of any external modules that will be run with the time domain simulations.  It is expected that external modules defined here will interact with more than one area of the turbine, such as to apply additional aerodynamics loads to the entire structure.  Any external modules that represent a single component should be added to the Assembly tree.

    *Not supported yet*

    """

    MeanSeaLevel: float = Field(alias="MeanSeaLevel", default=None) # Not supported yet
    r"""
    The mean sea depth at the turbine location.  If omitted, the Turbine will be considered an on-shore turbine and any sea states will be ignored.

    *Not supported yet*

    """

    Assembly: AssemblyModel = Field(alias="Assembly", default_factory=Assembly)
    r"""
    """

    ComponentLibrary: ComponentLibraryModel = Field(alias="ComponentLibrary", default_factory=ComponentLibrary)
    r"""
    """

    _relative_schema_path: str = 'Turbine/Turbine.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['GlobalExternalModules','Assembly', 'ComponentLibrary', ]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Turbine.model_rebuild()
