# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.lidar_mounting_position import LidarMountingPosition
from dnv_bladed_models.lidar_mounting_position import LidarMountingPosition as LidarMountingPositionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LidarBeam(BladedModel):
    r"""
    The definition of a single Lidar beam.  A Lidar device may have multiple beams.
    
    Not supported yet.
    
    Attributes
    ----------
    Azimuth : float, Not supported yet
        The angle between the beam's centreline and the Lidar component's x-axis.
    
    AngleToCentreLine : float, Not supported yet
        The angle between the beam's centreline and the Lidar component's y-axis.
    
    CorrectForMountingNodeVelocity : bool, default=False, Not supported yet
        If true, the mounting node velocity will not be factored into the line-of-sight wind speed measurement.
    
    MountingPosition : LidarMountingPosition, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Azimuth: float = Field(alias="Azimuth", default=None) # Not supported yet
    r"""
    The angle between the beam's centreline and the Lidar component's x-axis.

    *Not supported yet*

    """

    AngleToCentreLine: float = Field(alias="AngleToCentreLine", default=None) # Not supported yet
    r"""
    The angle between the beam's centreline and the Lidar component's y-axis.

    *Not supported yet*

    """

    CorrectForMountingNodeVelocity: bool = Field(alias="CorrectForMountingNodeVelocity", default=None) # Not supported yet
    r"""
    If true, the mounting node velocity will not be factored into the line-of-sight wind speed measurement.

    *Not supported yet*

    - default = False
    """

    MountingPosition: LidarMountingPositionModel = Field(alias="MountingPosition", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Lidar/LidarBeam/LidarBeam.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LidarBeam.model_rebuild()
