# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#



import os

class SchemaHelper:
    """
    Helper methods for constructing schema URLs and retrieving the schema version.
    """
    __schema_version__ = "0.8.0"
    __build_version__ = "0.8.0-rc.24+b.20.sha.1581bb5a"
    __host__ = "https://mysoftware.dnv.com/download/public/bladed/schema"

    __is_internal__ = os.environ.get('BLADEDX_ENVIRONMENT', '') == 'internal'
    __internal_schema_version__ = "0.8.0-rc.24"
    __internal_host__ = "https://bladednextgentest.z33.web.core.windows.net/download/public/bladed/schema"

    @staticmethod
    def construct_schema_url(relative_schema_path: str) -> str:
        """
        Constructs a schema URL based on the provided path.

        Parameters
        ----------
        relative_schema_path: str
            The relative path to a schema file within the Bladed schema repository.

        Returns
        -------
        str
            The constructed schema URL.

        """
        if SchemaHelper.__is_internal__:
            return f"{SchemaHelper.__internal_host__}/{SchemaHelper.__internal_schema_version__}/{relative_schema_path}"
        else:
            return f"{SchemaHelper.__host__}/{SchemaHelper.__schema_version__}/{relative_schema_path}"


    @staticmethod
    def get_schema_version() -> str:
        """
        Retrieves the schema version this Model API was generated for.
        """
        if SchemaHelper.__is_internal__:
            return SchemaHelper.__internal_schema_version__
        else:
            return SchemaHelper.__schema_version__