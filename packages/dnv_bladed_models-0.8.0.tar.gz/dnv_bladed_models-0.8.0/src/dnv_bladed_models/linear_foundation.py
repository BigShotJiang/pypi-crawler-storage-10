# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.foundation import Foundation
from dnv_bladed_models.foundation import Foundation as FoundationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearFoundation(Foundation):
    r"""
    A foundation represented by a linear stiffness and mass matrix at a single point.
    
    Attributes
    ----------
    FoundationType : Literal['LinearFoundation'], default='LinearFoundation'
        Defines the specific type of Foundation model in use.  For a `LinearFoundation` object, this must always be set to a value of `LinearFoundation`.
    
    StiffnessMatrix : List[List[float]]
        A 6x6 matrix representing the linear and rotational stiffnesses of an object or joint.
    
    MassMatrix : List[List[float]]
        A 6x6 matrix representing the mass and rotational inertias of an object.  These are symmetric matrices for all real-world objects.
    
    Notes
    -----
    
    """

    FoundationType: Literal['LinearFoundation'] = Field(alias="FoundationType", default='LinearFoundation', frozen=True) # type: ignore
    r"""
    Defines the specific type of Foundation model in use.  For a `LinearFoundation` object, this must always be set to a value of `LinearFoundation`.
    - default = 'LinearFoundation'
    """

    StiffnessMatrix: List[List[float]] = Field(alias="StiffnessMatrix", default_factory=list)
    r"""
    A 6x6 matrix representing the linear and rotational stiffnesses of an object or joint.
    """

    MassMatrix: List[List[float]] = Field(alias="MassMatrix", default_factory=list)
    r"""
    A 6x6 matrix representing the mass and rotational inertias of an object.  These are symmetric matrices for all real-world objects.
    """

    _relative_schema_path: str = 'Components/Tower/Foundation/LinearFoundation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['StiffnessMatrix','MassMatrix',]), 'FoundationType').merge(Foundation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LinearFoundation.model_rebuild()
