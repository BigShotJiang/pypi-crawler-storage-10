# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.angle_range import AngleRange
from dnv_bladed_models.angle_range import AngleRange as AngleRangeModel
from dnv_bladed_models.dimensionless_range import DimensionlessRange
from dnv_bladed_models.dimensionless_range import DimensionlessRange as DimensionlessRangeModel
from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs as SteadyCalculationOutputsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PerformanceCoefficientsCalculation(SteadyCalculation):
    r"""
    Defines a calculation which produces power, torque and thrust coefficients are calculated in a uniform steady wind field.  The rotor is modelled with flexibility as well as prebend and sweep.  However, the rotor is analysed in isolation without any influence from the rest of the turbine structure.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['PerformanceCoefficients'], default='PerformanceCoefficients'
        Defines the specific type of SteadyCalculation model in use.  For a `PerformanceCoefficients` object, this must always be set to a value of `PerformanceCoefficients`.
    
    TipSpeedRatioRange : DimensionlessRange
    
    PitchRange : AngleRange
    
    RotorSpeed : float
        The rotor speed to be considered for the calculation.
    
    Outputs : SteadyCalculationOutputs
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['PerformanceCoefficients'] = Field(alias="SteadyCalculationType", default='PerformanceCoefficients', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `PerformanceCoefficients` object, this must always be set to a value of `PerformanceCoefficients`.
    - default = 'PerformanceCoefficients'
    """

    TipSpeedRatioRange: DimensionlessRangeModel = Field(alias="TipSpeedRatioRange", default=None)
    r"""
    """

    PitchRange: AngleRangeModel = Field(alias="PitchRange", default=None)
    r"""
    """

    RotorSpeed: float = Field(alias="RotorSpeed", default=None)
    r"""
    The rotor speed to be considered for the calculation.
    """

    Outputs: SteadyCalculationOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/PerformanceCoefficientsCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(SteadyCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PerformanceCoefficientsCalculation.model_rebuild()
