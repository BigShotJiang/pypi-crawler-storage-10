# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *


class ConnectableNode_ComponentTypesAllowedEnum(str, Enum):
    COMPONENTS = "COMPONENTS"



class ConnectableNode(BladedModel, ABC):
    r"""
    An object declaring a distal node for a component.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentTypesAllowed : ConnectableNode_ComponentTypesAllowedEnum, Not supported yet
        Optional: A list of the components that could be attached to the node.  If not specified, this will be governed by the component's connectivity.
    
    RelativeOrientation : List[float], Not supported yet
        The relative orientation of the attached component to the current component (e.g. the axle to the nacelle, or the blade assembly to the hub).  Required if encrypted and not the same as the parent (e.g. for a nacelle's axle node)
    
    OffsetIfEncrypted : Vector3D
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentTypesAllowed: ConnectableNode_ComponentTypesAllowedEnum = Field(alias="ComponentTypesAllowed", default=None) # Not supported yet
    r"""
    Optional: A list of the components that could be attached to the node.  If not specified, this will be governed by the component's connectivity.

    *Not supported yet*

    """

    RelativeOrientation: List[float] = Field(alias="RelativeOrientation", default_factory=list) # Not supported yet
    r"""
    The relative orientation of the attached component to the current component (e.g. the axle to the nacelle, or the blade assembly to the hub).  Required if encrypted and not the same as the parent (e.g. for a nacelle's axle node)

    *Not supported yet*

    """

    OffsetIfEncrypted: Vector3DModel = Field(alias="OffsetIfEncrypted", default=None)
    r"""
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['RelativeOrientation',]), None).merge(BladedModel._type_info)

ConnectableNode.model_rebuild()
