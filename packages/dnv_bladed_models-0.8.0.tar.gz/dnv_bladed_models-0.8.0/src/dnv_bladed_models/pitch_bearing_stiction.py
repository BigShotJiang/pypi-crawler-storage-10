# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.friction_torque_vs_stiction_torque import FrictionTorqueVsStictionTorque
from dnv_bladed_models.friction_torque_vs_stiction_torque import FrictionTorqueVsStictionTorque as FrictionTorqueVsStictionTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchBearingStiction(BladedModel):
    r"""
    The additional torque resisting the initial movement of the bearing.
    
    Attributes
    ----------
    ConstantStiction : float, default=0
        The stiction is the additional friction when the bearing is stationary (static friction = kinetic friction + stiction).
    
    StictionTorquePerUnitFrictionTorque : float
        A fixed ratio between the kinetic friction of the bearing and the stiction opposing the initial motion.
    
    FrictionTorqueVsStictionTorque : List[FrictionTorqueVsStictionTorque]
        A look-up table describing a non-linear relationship between the friction of the bearing and the corresponding stiction.
    
    Notes
    -----
    
    """

    ConstantStiction: float = Field(alias="ConstantStiction", default=None)
    r"""
    The stiction is the additional friction when the bearing is stationary (static friction = kinetic friction + stiction).
    - default = 0
    """

    StictionTorquePerUnitFrictionTorque: float = Field(alias="StictionTorquePerUnitFrictionTorque", default=None)
    r"""
    A fixed ratio between the kinetic friction of the bearing and the stiction opposing the initial motion.
    """

    FrictionTorqueVsStictionTorque: List[FrictionTorqueVsStictionTorqueModel] = Field(alias="FrictionTorqueVsStictionTorque", default_factory=list)
    r"""
    A look-up table describing a non-linear relationship between the friction of the bearing and the corresponding stiction.
    """

    _relative_schema_path: str = 'Components/PitchSystem/Friction/PitchBearingStiction/PitchBearingStiction.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['FrictionTorqueVsStictionTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchBearingStiction.model_rebuild()
