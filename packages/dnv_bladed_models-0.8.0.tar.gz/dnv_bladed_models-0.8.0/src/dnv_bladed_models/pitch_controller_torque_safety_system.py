# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_safety_system import PitchSafetySystem
from dnv_bladed_models.pitch_safety_system import PitchSafetySystem as PitchSafetySystemModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchControllerTorqueSafetySystem(PitchSafetySystem, ABC):
    r"""
    The common properties of a pitch safety system where the motion is dictated by the torque applied.
    
    Not supported yet.
    
    Attributes
    ----------
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(PitchSafetySystem._type_info)

PitchControllerTorqueSafetySystem.model_rebuild()
