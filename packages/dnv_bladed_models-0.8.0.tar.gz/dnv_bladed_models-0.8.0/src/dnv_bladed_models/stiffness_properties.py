# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bending_torsion_coupling_terms_about_elastic_xy import BendingTorsionCouplingTermsAboutElasticXY
from dnv_bladed_models.bending_torsion_coupling_terms_about_elastic_xy import BendingTorsionCouplingTermsAboutElasticXY as BendingTorsionCouplingTermsAboutElasticXYModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.shear_stiffnesses_along_elastic_xy import ShearStiffnessesAlongElasticXY
from dnv_bladed_models.shear_stiffnesses_along_elastic_xy import ShearStiffnessesAlongElasticXY as ShearStiffnessesAlongElasticXYModel
from .schema_helper import SchemaHelper
from .base_entity import *




class StiffnessProperties(BladedModel):
    r"""
    The stiffness properties of the blade cross-section. All properties, except for torsional stiffness, are defined in the PrincipalElasticCoordinateSystem. Torsional stiffness is defined in the PrincipalShearCoordinateSystem.
    
    Attributes
    ----------
    BendingStiffnessAboutElasticX : float
        The bending stiffness about the principal elastic X-axis, as defined by the PrincipalElasticCoordinateSystem.
    
    BendingStiffnessAboutElasticY : float
        The bending stiffness about the principal elastic Y-axis, as defined by the PrincipalElasticCoordinateSystem.
    
    TorsionalStiffnessAboutShearZ : float
        The torsional stiffness about the principal shear Z-axis (shear centre), as defined by the PrincipalShearCoordinateSystem.
    
    AxialStiffness : float
        The axial stiffness, perpendicular to the principal elastic Z-axis (elastic centre), as defined by the PrincipalElasticCoordinateSystem.
    
    ShearStiffnessesAlongElasticXY : ShearStiffnessesAlongElasticXY
    
    BendingTorsionCouplingTermsAboutElasticXY : BendingTorsionCouplingTermsAboutElasticXY
    
    Notes
    -----
    
    """

    BendingStiffnessAboutElasticX: float = Field(alias="BendingStiffnessAboutElasticX", default=None)
    r"""
    The bending stiffness about the principal elastic X-axis, as defined by the PrincipalElasticCoordinateSystem.
    """

    BendingStiffnessAboutElasticY: float = Field(alias="BendingStiffnessAboutElasticY", default=None)
    r"""
    The bending stiffness about the principal elastic Y-axis, as defined by the PrincipalElasticCoordinateSystem.
    """

    TorsionalStiffnessAboutShearZ: float = Field(alias="TorsionalStiffnessAboutShearZ", default=None)
    r"""
    The torsional stiffness about the principal shear Z-axis (shear centre), as defined by the PrincipalShearCoordinateSystem.
    """

    AxialStiffness: float = Field(alias="AxialStiffness", default=None)
    r"""
    The axial stiffness, perpendicular to the principal elastic Z-axis (elastic centre), as defined by the PrincipalElasticCoordinateSystem.
    """

    ShearStiffnessesAlongElasticXY: ShearStiffnessesAlongElasticXYModel = Field(alias="ShearStiffnessesAlongElasticXY", default=None)
    r"""
    """

    BendingTorsionCouplingTermsAboutElasticXY: BendingTorsionCouplingTermsAboutElasticXYModel = Field(alias="BendingTorsionCouplingTermsAboutElasticXY", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/StiffnessProperties/StiffnessProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


StiffnessProperties.model_rebuild()
