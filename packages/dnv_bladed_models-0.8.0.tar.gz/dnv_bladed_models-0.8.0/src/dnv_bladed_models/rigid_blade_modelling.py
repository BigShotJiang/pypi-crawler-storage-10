# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.blade_modelling import BladeModelling
from dnv_bladed_models.blade_modelling import BladeModelling as BladeModellingModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RigidBladeModelling(BladeModelling):
    r"""
    The properties for modelling the blade as being completely rigid.
    
    Attributes
    ----------
    BladeModellingType : Literal['RigidBladeModelling'], default='RigidBladeModelling'
        Defines the specific type of BladeModelling model in use.  For a `RigidBladeModelling` object, this must always be set to a value of `RigidBladeModelling`.
    
    Notes
    -----
    
    """

    BladeModellingType: Literal['RigidBladeModelling'] = Field(alias="BladeModellingType", default='RigidBladeModelling', frozen=True) # type: ignore
    r"""
    Defines the specific type of BladeModelling model in use.  For a `RigidBladeModelling` object, this must always be set to a value of `RigidBladeModelling`.
    - default = 'RigidBladeModelling'
    """

    _relative_schema_path: str = 'Components/Blade/BladeModelling/RigidBladeModelling.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'BladeModellingType').merge(BladeModelling._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RigidBladeModelling.model_rebuild()
