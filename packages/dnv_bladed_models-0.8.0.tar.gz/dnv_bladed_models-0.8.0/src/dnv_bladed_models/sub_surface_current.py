# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SubSurfaceCurrent(BladedModel):
    r"""
    The definition of a current whose strength depends on height above the sea bed according to a power law or a user defined relationship.
    
    Not supported yet.
    
    Attributes
    ----------
    VelocityAtSurface : float, Not supported yet
        The current speed at the surface.
    
    Heading : float, Not supported yet
        The direction towards which the current is flowing (measured clockwise from North).
    
    ShearExponent : float, Not supported yet
        The shear exponent of the sub-surface current.  This is typically in the order of 1/7.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    VelocityAtSurface: float = Field(alias="VelocityAtSurface", default=None) # Not supported yet
    r"""
    The current speed at the surface.

    *Not supported yet*

    """

    Heading: float = Field(alias="Heading", default=None) # Not supported yet
    r"""
    The direction towards which the current is flowing (measured clockwise from North).

    *Not supported yet*

    """

    ShearExponent: float = Field(alias="ShearExponent", default=None) # Not supported yet
    r"""
    The shear exponent of the sub-surface current.  This is typically in the order of 1/7.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/SubSurfaceCurrent/SubSurfaceCurrent.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SubSurfaceCurrent.model_rebuild()
