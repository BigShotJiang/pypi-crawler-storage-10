# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.radius_vs_deficit import RadiusVsDeficit
from dnv_bladed_models.radius_vs_deficit import RadiusVsDeficit as RadiusVsDeficitModel
from dnv_bladed_models.steady_wake_deficit import SteadyWakeDeficit
from dnv_bladed_models.steady_wake_deficit import SteadyWakeDeficit as SteadyWakeDeficitModel
from .schema_helper import SchemaHelper
from .base_entity import *




class UserDefinedWakeDeficit(SteadyWakeDeficit):
    r"""
    A simple model for the reduced velocity of the wind behind another turbine.  This deficit will be applied across a certain region, and this region will not move around during the simulation.  The velocity deficit profile is a look-up table of the radius against the deficit at that radius.
    
    Attributes
    ----------
    SteadyWakeDeficitType : Literal['UserDefined'], default='UserDefined'
        Defines the specific type of SteadyWakeDeficit model in use.  For a `UserDefined` object, this must always be set to a value of `UserDefined`.
    
    RadiusVsDeficit : List[RadiusVsDeficit]
        A list of radii vs the deficit at that radius.  The first value should be at a radius of 0.0, and the largest radius will be the extent of the affected region.  At this point, the deficit is usually 0.0.
    
    Notes
    -----
    
    """

    SteadyWakeDeficitType: Literal['UserDefined'] = Field(alias="SteadyWakeDeficitType", default='UserDefined', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyWakeDeficit model in use.  For a `UserDefined` object, this must always be set to a value of `UserDefined`.
    - default = 'UserDefined'
    """

    RadiusVsDeficit: List[RadiusVsDeficitModel] = Field(alias="RadiusVsDeficit", default_factory=list)
    r"""
    A list of radii vs the deficit at that radius.  The first value should be at a radius of 0.0, and the largest radius will be the extent of the affected region.  At this point, the deficit is usually 0.0.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/SteadyWakeDeficit/UserDefinedWakeDeficit.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['RadiusVsDeficit',]), 'SteadyWakeDeficitType').merge(SteadyWakeDeficit._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


UserDefinedWakeDeficit.model_rebuild()
