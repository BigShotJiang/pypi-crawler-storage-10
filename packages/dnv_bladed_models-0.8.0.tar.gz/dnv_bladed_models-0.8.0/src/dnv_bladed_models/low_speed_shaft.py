# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LowSpeedShaft(BladedModel):
    r"""
    The low speed shaft bending definition.
    
    Attributes
    ----------
    EffectiveShaftLength : float
        The length of the low speed shaft to be considered for the bending model, beginning at the outside face of the main bearing.
    
    HingePosition : float
        The fraction of the low speed shaft length (from the hub centre) where the hinge between the two massless rigid shafts are connected.
    
    TorsionalStiffness : float
        The shaft stiffness about the axis of rotation.
    
    TorsionalDamping : float
        The shaft damping about the axis of rotation.
    
    BendingStiffness : float
        The shaft's bending stiffness about any axis perpendicular to the axis of rotation.
    
    BendingDamping : float
        The shaft's bending damping about any axis perpendicular to the axis of rotation.
    
    Notes
    -----
    
    """

    EffectiveShaftLength: float = Field(alias="EffectiveShaftLength", default=None)
    r"""
    The length of the low speed shaft to be considered for the bending model, beginning at the outside face of the main bearing.
    """

    HingePosition: float = Field(alias="HingePosition", default=None)
    r"""
    The fraction of the low speed shaft length (from the hub centre) where the hinge between the two massless rigid shafts are connected.
    """

    TorsionalStiffness: float = Field(alias="TorsionalStiffness", default=None)
    r"""
    The shaft stiffness about the axis of rotation.
    """

    TorsionalDamping: float = Field(alias="TorsionalDamping", default=None)
    r"""
    The shaft damping about the axis of rotation.
    """

    BendingStiffness: float = Field(alias="BendingStiffness", default=None)
    r"""
    The shaft's bending stiffness about any axis perpendicular to the axis of rotation.
    """

    BendingDamping: float = Field(alias="BendingDamping", default=None)
    r"""
    The shaft's bending damping about any axis perpendicular to the axis of rotation.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/LowSpeedShaft/LowSpeedShaft.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LowSpeedShaft.model_rebuild()
