# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from dnv_bladed_models.rotational_stiffness import RotationalStiffness
from dnv_bladed_models.rotational_stiffness import RotationalStiffness as RotationalStiffnessModel
from dnv_bladed_models.translational_stiffness import TranslationalStiffness
from dnv_bladed_models.translational_stiffness import TranslationalStiffness as TranslationalStiffnessModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Flexibility(Component):
    r"""
    A generic component representing a flexibility between two other nodes.  The proximal and distal nodes can have flexibility in up to six degrees of freedom.  The hinge is assumed to be rigid in any direction where the properties are not specified.
    
    Attributes
    ----------
    ComponentType : Literal['Flexibility'], default='Flexibility'
        Defines the specific type of Component model in use.  For a `Flexibility` object, this must always be set to a value of `Flexibility`.
    
    AlongX : TranslationalStiffness
    
    AlongY : TranslationalStiffness
    
    AlongZ : TranslationalStiffness
    
    AboutX : RotationalStiffness
    
    AboutY : RotationalStiffness
    
    AboutZ : RotationalStiffness
    
    Notes
    -----
    
    """

    ComponentType: Literal['Flexibility'] = Field(alias="ComponentType", default='Flexibility', frozen=True) # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `Flexibility` object, this must always be set to a value of `Flexibility`.
    - default = 'Flexibility'
    """

    AlongX: TranslationalStiffnessModel = Field(alias="AlongX", default=None)
    r"""
    """

    AlongY: TranslationalStiffnessModel = Field(alias="AlongY", default=None)
    r"""
    """

    AlongZ: TranslationalStiffnessModel = Field(alias="AlongZ", default=None)
    r"""
    """

    AboutX: RotationalStiffnessModel = Field(alias="AboutX", default=None)
    r"""
    """

    AboutY: RotationalStiffnessModel = Field(alias="AboutY", default=None)
    r"""
    """

    AboutZ: RotationalStiffnessModel = Field(alias="AboutZ", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Flexibility.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(Component._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Flexibility.model_rebuild()
