# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BendingTorsionCouplingTermsAboutElasticXY(BladedModel):
    r"""
    The bending-torsion and bending-bending stiffness coupling terms about the principal elastic X- and Y-axes, as defined by the PrincipalElasticCoordinateSystem.
    
    Attributes
    ----------
    BendingBendingCouplingAboutElasticXY : float, default=0
        The stiffness coupling term between the bending stiffness about the principal elastic X- and Y-axes, as defined by the PrincipalElasticCoordinateSystem.
    
    TorsionBendingCouplingAboutElasticXZ : float, default=0
        The stiffness coupling term between the bending stiffness about the principal elastic X-axis and torsional stiffness about the principal elastic Z-axis, as defined by the PrincipalElasticCoordinateSystem.
    
    TorsionBendingCouplingAboutElasticYZ : float, default=0
        The stiffness coupling term between the bending stiffness about the principal elastic Y-axis and the torsional stiffness about the principal elastic Z-axis, as defined by the PrincipalElasticCoordinateSystem.
    
    Notes
    -----
    
    """

    BendingBendingCouplingAboutElasticXY: float = Field(alias="BendingBendingCouplingAboutElasticXY", default=None)
    r"""
    The stiffness coupling term between the bending stiffness about the principal elastic X- and Y-axes, as defined by the PrincipalElasticCoordinateSystem.
    - default = 0
    """

    TorsionBendingCouplingAboutElasticXZ: float = Field(alias="TorsionBendingCouplingAboutElasticXZ", default=None)
    r"""
    The stiffness coupling term between the bending stiffness about the principal elastic X-axis and torsional stiffness about the principal elastic Z-axis, as defined by the PrincipalElasticCoordinateSystem.
    - default = 0
    """

    TorsionBendingCouplingAboutElasticYZ: float = Field(alias="TorsionBendingCouplingAboutElasticYZ", default=None)
    r"""
    The stiffness coupling term between the bending stiffness about the principal elastic Y-axis and the torsional stiffness about the principal elastic Z-axis, as defined by the PrincipalElasticCoordinateSystem.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/StiffnessProperties/BendingTorsionCouplingTermsAboutElasticXY/BendingTorsionCouplingTermsAboutElasticXY.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BendingTorsionCouplingTermsAboutElasticXY.model_rebuild()
