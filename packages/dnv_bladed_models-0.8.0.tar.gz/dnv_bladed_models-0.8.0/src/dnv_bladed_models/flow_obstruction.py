# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.tower_shadow_potential_flow import TowerShadowPotentialFlow
from dnv_bladed_models.tower_shadow_potential_flow import TowerShadowPotentialFlow as TowerShadowPotentialFlowModel
from dnv_bladed_models.tower_shadow_powles import TowerShadowPowles
from dnv_bladed_models.tower_shadow_powles import TowerShadowPowles as TowerShadowPowlesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FlowObstruction(BladedModel):
    r"""
    The properties of the tower shadow, which modifies the flow in the region around the tower.  This has a direct affect on the flow as the blade sees it.
    
    Attributes
    ----------
    PotentialFlow : TowerShadowPotentialFlow
    
    Powles : TowerShadowPowles
    
    Notes
    -----
    
    """

    PotentialFlow: TowerShadowPotentialFlowModel = Field(alias="PotentialFlow", default=None)
    r"""
    """

    Powles: TowerShadowPowlesModel = Field(alias="Powles", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Tower/TowerAerodynamicProperties/FlowObstruction/FlowObstruction.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FlowObstruction.model_rebuild()
