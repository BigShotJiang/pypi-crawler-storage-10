# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LookUpTableElement(BladedModel):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    DistanceFromFocalPoint : float, Not supported yet
        The distance either side of the nominal focal distance that the sample was collected from.  If there isn't a value provided for a distance of 0.0, the weighting will be assumed to be 1.0 (100%).
    
    ProportionOfSignal : float, Not supported yet
        The proportion of the signal to take at the corresponding distance from the nominal focal distance, also known as the weighting.  This should range from 1.0 (100%) down to 0.0 (0%).
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    DistanceFromFocalPoint: float = Field(alias="DistanceFromFocalPoint", default=None) # Not supported yet
    r"""
    The distance either side of the nominal focal distance that the sample was collected from.  If there isn't a value provided for a distance of 0.0, the weighting will be assumed to be 1.0 (100%).

    *Not supported yet*

    """

    ProportionOfSignal: float = Field(alias="ProportionOfSignal", default=None) # Not supported yet
    r"""
    The proportion of the signal to take at the corresponding distance from the nominal focal distance, also known as the weighting.  This should range from 1.0 (100%) down to 0.0 (0%).

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Lidar/LookUpTableElement/LookUpTableElement.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LookUpTableElement.model_rebuild()
