# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchPositionVsMinimumAndMaximumMoment(BladedModel):
    r"""
    The limits on the torque of the rotary drive as they vary with position.
    
    Attributes
    ----------
    Position : float, default=0
        The position at which the maximum and minimum are applicable for.
    
    Minimum : float, default=0
        The minimum torque of the rotary drive.
    
    Maximum : float, default=0
        The maximum torque of the rotary drive.
    
    Notes
    -----
    
    """

    Position: float = Field(alias="Position", default=None)
    r"""
    The position at which the maximum and minimum are applicable for.
    - default = 0
    """

    Minimum: float = Field(alias="Minimum", default=None)
    r"""
    The minimum torque of the rotary drive.
    - default = 0
    """

    Maximum: float = Field(alias="Maximum", default=None)
    r"""
    The maximum torque of the rotary drive.
    - default = 0
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/common/PitchPositionVsMinimumAndMaximumMoment.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchPositionVsMinimumAndMaximumMoment.model_rebuild()
