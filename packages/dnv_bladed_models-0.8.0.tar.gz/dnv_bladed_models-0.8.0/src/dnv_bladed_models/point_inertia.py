# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.added_inertia import AddedInertia
from dnv_bladed_models.added_inertia import AddedInertia as AddedInertiaModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PointInertia(AddedInertia):
    r"""
    An inertia added to a structural component.
    
    Attributes
    ----------
    AddedInertiaType : Literal['PointInertia'], default='PointInertia'
        Defines the specific type of AddedInertia model in use.  For a `PointInertia` object, this must always be set to a value of `PointInertia`.
    
    Mass : float, default=0
        The mass to be added.
    
    Offset : Vector3D
    
    MomentOfInertiaTensor : List[float], default=[0,0,0]
        Moment of inertia tensor acting about the centre of mass. This tensor is defined using the local coordinate system of the attachment node.
    
    CompleteInertiaTensor : float, default=0
        The symmetric inertia tensor acting about the attachment node. This tensor is defined using the local coordinate system of the attachment node.
    
    Notes
    -----
    
    """

    AddedInertiaType: Literal['PointInertia'] = Field(alias="AddedInertiaType", default='PointInertia', frozen=True) # type: ignore
    r"""
    Defines the specific type of AddedInertia model in use.  For a `PointInertia` object, this must always be set to a value of `PointInertia`.
    - default = 'PointInertia'
    """

    Mass: float = Field(alias="Mass", default=None)
    r"""
    The mass to be added.
    - default = 0
    """

    Offset: Vector3DModel = Field(alias="Offset", default=None)
    r"""
    """

    MomentOfInertiaTensor: List[float] = Field(alias="MomentOfInertiaTensor", default_factory=list)
    r"""
    Moment of inertia tensor acting about the centre of mass. This tensor is defined using the local coordinate system of the attachment node.
    - default = [0,0,0]
    """

    CompleteInertiaTensor: float = Field(alias="CompleteInertiaTensor", default=None)
    r"""
    The symmetric inertia tensor acting about the attachment node. This tensor is defined using the local coordinate system of the attachment node.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Tower/AddedInertia/PointInertia.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['MomentOfInertiaTensor',]), 'AddedInertiaType').merge(AddedInertia._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PointInertia.model_rebuild()
