# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class AngleVsStiffnessTorque(BladedModel):
    r"""
    A line or row in a look-up table, specifying a value of StiffnessTorque for a specified Angle.
    
    Not supported yet.
    
    Attributes
    ----------
    Angle : float, Not supported yet
        The angle of deflection of the pendulum from its resting position.
    
    StiffnessTorque : float, Not supported yet
        The opposing stiffness torque applicable at the corresponding angle of deflection.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Angle: float = Field(alias="Angle", default=None) # Not supported yet
    r"""
    The angle of deflection of the pendulum from its resting position.

    *Not supported yet*

    """

    StiffnessTorque: float = Field(alias="StiffnessTorque", default=None) # Not supported yet
    r"""
    The opposing stiffness torque applicable at the corresponding angle of deflection.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Damper/AngleVsStiffnessTorque/AngleVsStiffnessTorque.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


AngleVsStiffnessTorque.model_rebuild()
