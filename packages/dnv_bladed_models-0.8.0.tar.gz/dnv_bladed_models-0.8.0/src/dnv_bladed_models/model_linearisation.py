# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.linearisation_calculation import LinearisationCalculation
from dnv_bladed_models.linearisation_calculation import LinearisationCalculation as LinearisationCalculationModel
from dnv_bladed_models.model_linearisation_perturbations import ModelLinearisationPerturbations
from dnv_bladed_models.model_linearisation_perturbations import ModelLinearisationPerturbations as ModelLinearisationPerturbationsModel
from dnv_bladed_models.velocity_range import VelocityRange
from dnv_bladed_models.velocity_range import VelocityRange as VelocityRangeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ModelLinearisation(LinearisationCalculation):
    r"""
    Defines a calculation which produces a linear model.  This can be post-processed into a linearised model of the turbine in state-space form.  This is of particular value in the design of controllers.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['ModelLinearisation'], default='ModelLinearisation'
        Defines the specific type of SteadyCalculation model in use.  For a `ModelLinearisation` object, this must always be set to a value of `ModelLinearisation`.
    
    WindSpeedRange : VelocityRange
    
    Perturbations : ModelLinearisationPerturbations
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['ModelLinearisation'] = Field(alias="SteadyCalculationType", default='ModelLinearisation', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `ModelLinearisation` object, this must always be set to a value of `ModelLinearisation`.
    - default = 'ModelLinearisation'
    """

    WindSpeedRange: VelocityRangeModel = Field(alias="WindSpeedRange", default=None)
    r"""
    """

    Perturbations: ModelLinearisationPerturbationsModel = Field(alias="Perturbations", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/ModelLinearisation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(LinearisationCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ModelLinearisation.model_rebuild()
