# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class StructuralModelling_StructuralModellingTypeEnum(str, Enum):
    MODAL_STRUCTURAL_MODELLING = "ModalStructuralModelling"
    RIGID_STRUCTURAL_MODELLING = "RigidStructuralModelling"
    INSERT = "Insert"

class StructuralModelling_GeometricStiffnessModelEnum(str, Enum):
    AXIAL_LOADS_ONLY = "AxialLoadsOnly"
    INTERNAL_LOADS_ONLY = "InternalLoadsOnly"
    DISABLED = "Disabled"



class StructuralModelling(BladedModel, ABC):
    r"""
    The modelling options for a component with flexibility.  This is primarily the blade and the support structure.
    
    Attributes
    ----------
    StructuralModellingType : StructuralModelling_StructuralModellingTypeEnum
        Defines the specific type of model in use.
    
    MaximumNodeSpacing : float
        The maximum node spacing allowed on the component.  If any two nodes are further spaced apart than this, an additional node or nodes will be added inbetween them.  If omite, no additional nodes will be added.
    
    GeometricStiffnessModel : StructuralModelling_GeometricStiffnessModelEnum, default='AxialLoadsOnly'
        The geometric stiffness model to use for the support structure
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - StructuralModellingInsert
        - ModalStructuralModelling
        - RigidStructuralModelling
    
    """

    StructuralModellingType: StructuralModelling_StructuralModellingTypeEnum = Field(alias="StructuralModellingType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    MaximumNodeSpacing: float = Field(alias="MaximumNodeSpacing", default=None)
    r"""
    The maximum node spacing allowed on the component.  If any two nodes are further spaced apart than this, an additional node or nodes will be added inbetween them.  If omite, no additional nodes will be added.
    """

    GeometricStiffnessModel: StructuralModelling_GeometricStiffnessModelEnum = Field(alias="GeometricStiffnessModel", default=None)
    r"""
    The geometric stiffness model to use for the support structure
    - default = 'AxialLoadsOnly'
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

StructuralModelling.model_rebuild()
