# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.nacelle_sensor import NacelleSensor
from dnv_bladed_models.nacelle_sensor import NacelleSensor as NacelleSensorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NacelleAccelerometer(NacelleSensor):
    r"""
    An accelerometer mounted on the nacelle.  This can be mounted anywhere on the structure.
    
    Attributes
    ----------
    NacelleSensorType : Literal['Accelerometer'], default='Accelerometer'
        Defines the specific type of NacelleSensor model in use.  For a `Accelerometer` object, this must always be set to a value of `Accelerometer`.
    
    IncludeAccelerationDueToGravity : bool, default=False
        When this feature is enabled, the accelerometer will always record a downwards acceleration due to gravity in addition to the local acceleration of the structure.
    
    Notes
    -----
    
    """

    NacelleSensorType: Literal['Accelerometer'] = Field(alias="NacelleSensorType", default='Accelerometer', frozen=True) # type: ignore
    r"""
    Defines the specific type of NacelleSensor model in use.  For a `Accelerometer` object, this must always be set to a value of `Accelerometer`.
    - default = 'Accelerometer'
    """

    IncludeAccelerationDueToGravity: bool = Field(alias="IncludeAccelerationDueToGravity", default=None)
    r"""
    When this feature is enabled, the accelerometer will always record a downwards acceleration due to gravity in addition to the local acceleration of the structure.
    - default = False
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/NacelleSensor/NacelleAccelerometer.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'NacelleSensorType').merge(NacelleSensor._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NacelleAccelerometer.model_rebuild()
