# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.hardware_tracking import HardwareTracking
from dnv_bladed_models.hardware_tracking import HardwareTracking as HardwareTrackingModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExternallySteppedSimulation(BladedModel):
    r"""
    The definition of a Bladed real time simulation.  This will be run with Bladed as an external library (i.e. a dynamic link library (dll) on Windows, or a shared object (so) on Linux).  An external process must call functions within the Bladed external library to \"step\" the simulation, and thereby keep it synchronised with the external controlling process.
    
    Not supported yet.
    
    Attributes
    ----------
    TimeStep : float, Not supported yet
        The real time simulation time step, as set by the external process that is calling Bladed in real time mode.
    
    TimeStepMultiplier : float, Not supported yet
        The real time simulation time step multiplier.
    
    HardwareTracking : HardwareTracking, Not supported yet
    
    OutputRealTimeDataFromStart : bool, Not supported yet
        If true, realtime data will be output as soon as Bladed is running.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TimeStep: float = Field(alias="TimeStep", default=None) # Not supported yet
    r"""
    The real time simulation time step, as set by the external process that is calling Bladed in real time mode.

    *Not supported yet*

    """

    TimeStepMultiplier: float = Field(alias="TimeStepMultiplier", default=None) # Not supported yet
    r"""
    The real time simulation time step multiplier.

    *Not supported yet*

    """

    HardwareTracking: HardwareTrackingModel = Field(alias="HardwareTracking", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    OutputRealTimeDataFromStart: bool = Field(alias="OutputRealTimeDataFromStart", default=None) # Not supported yet
    r"""
    If true, realtime data will be output as soon as Bladed is running.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/ExternallySteppedSimulation/ExternallySteppedSimulation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExternallySteppedSimulation.model_rebuild()
