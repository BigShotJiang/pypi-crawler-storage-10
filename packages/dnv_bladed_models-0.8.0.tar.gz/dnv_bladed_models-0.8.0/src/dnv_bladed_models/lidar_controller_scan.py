# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.lidar_scanning_pattern import LidarScanningPattern
from dnv_bladed_models.lidar_scanning_pattern import LidarScanningPattern as LidarScanningPatternModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LidarControllerScan(LidarScanningPattern):
    r"""
    Where the scan pattern is controlled by the turbine's controller.  The controller API will provide functions with which to move the beam.
    
    Not supported yet.
    
    Attributes
    ----------
    ScanningPatternType : Literal['ControllerScan'], default='ControllerScan', Not supported yet
        Defines the specific type of ScanningPattern model in use.  For a `ControllerScan` object, this must always be set to a value of `ControllerScan`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ScanningPatternType: Literal['ControllerScan'] = Field(alias="ScanningPatternType", default='ControllerScan', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of ScanningPattern model in use.  For a `ControllerScan` object, this must always be set to a value of `ControllerScan`.

    *Not supported yet*

    - default = 'ControllerScan'
    """

    _relative_schema_path: str = 'Components/Lidar/LidarScanningPattern/LidarControllerScan.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ScanningPatternType').merge(LidarScanningPattern._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LidarControllerScan.model_rebuild()
