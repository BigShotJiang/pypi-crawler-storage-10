# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_wake import DynamicWake
from dnv_bladed_models.dynamic_wake import DynamicWake as DynamicWakeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class EquilibriumWakeModel(DynamicWake):
    r"""
    The equilibrium wake model instantaneously updates the induction in response to changes operating condition.  This represents the steady state solution.  It should not be used in linearisation as it would represent an instantaneous response of the wake, where in reality the response is significantly lagged.  It is also not a good approach for time domain as the lagged wake response is not captured.
    
    Attributes
    ----------
    DynamicWakeType : Literal['EquilibriumWakeModel'], default='EquilibriumWakeModel'
        Defines the specific type of DynamicWake model in use.  For a `EquilibriumWakeModel` object, this must always be set to a value of `EquilibriumWakeModel`.
    
    Notes
    -----
    
    """

    DynamicWakeType: Literal['EquilibriumWakeModel'] = Field(alias="DynamicWakeType", default='EquilibriumWakeModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicWake model in use.  For a `EquilibriumWakeModel` object, this must always be set to a value of `EquilibriumWakeModel`.
    - default = 'EquilibriumWakeModel'
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/MomentumTheoryCorrections/DynamicWake/EquilibriumWakeModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicWakeType').merge(DynamicWake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


EquilibriumWakeModel.model_rebuild()
