# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.electrical_losses import ElectricalLosses
from dnv_bladed_models.electrical_losses import ElectricalLosses as ElectricalLossesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearElectricalLosses(ElectricalLosses):
    r"""
    An electrical loss model that assumes a proportional relationship between the power and the losses.
    
    Attributes
    ----------
    ElectricalLossesType : Literal['LinearElectricalLosses'], default='LinearElectricalLosses'
        Defines the specific type of ElectricalLosses model in use.  For a `LinearElectricalLosses` object, this must always be set to a value of `LinearElectricalLosses`.
    
    PowerLossAtNoLoad : float
        The power loss when there is no load on the generator.
    
    Efficiency : float
        The efficiency of the generator, with 100% being a perfect, lossless generator.
    
    Notes
    -----
    
    """

    ElectricalLossesType: Literal['LinearElectricalLosses'] = Field(alias="ElectricalLossesType", default='LinearElectricalLosses', frozen=True) # type: ignore
    r"""
    Defines the specific type of ElectricalLosses model in use.  For a `LinearElectricalLosses` object, this must always be set to a value of `LinearElectricalLosses`.
    - default = 'LinearElectricalLosses'
    """

    PowerLossAtNoLoad: float = Field(alias="PowerLossAtNoLoad", default=None)
    r"""
    The power loss when there is no load on the generator.
    """

    Efficiency: float = Field(alias="Efficiency", default=None)
    r"""
    The efficiency of the generator, with 100% being a perfect, lossless generator.
    """

    _relative_schema_path: str = 'Components/Generator/ElectricalLosses/LinearElectricalLosses.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ElectricalLossesType').merge(ElectricalLosses._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LinearElectricalLosses.model_rebuild()
