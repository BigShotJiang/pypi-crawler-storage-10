# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.fault import Fault
from dnv_bladed_models.fault import Fault as FaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ShortCircuit(Fault):
    r"""
    A short circuit that occurs at a specified time in the simulation.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['ShortCircuit'], default='ShortCircuit', Not supported yet
        Defines the specific type of Event model in use.  For a `ShortCircuit` object, this must always be set to a value of `ShortCircuit`.
    
    Filepath : str, Not supported yet
        The filepath or URI of the short circuit data.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['ShortCircuit'] = Field(alias="EventType", default='ShortCircuit', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `ShortCircuit` object, this must always be set to a value of `ShortCircuit`.

    *Not supported yet*

    - default = 'ShortCircuit'
    """

    Filepath: str = Field(alias="Filepath", default=None) # Not supported yet
    r"""
    The filepath or URI of the short circuit data.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/ShortCircuit.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(Fault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ShortCircuit.model_rebuild()
