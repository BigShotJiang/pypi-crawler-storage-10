# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.lidar_focal_distance_control import LidarFocalDistanceControl
from dnv_bladed_models.lidar_focal_distance_control import LidarFocalDistanceControl as LidarFocalDistanceControlModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ControllerLidarSettings(LidarFocalDistanceControl):
    r"""
    The focal distance is controlled by the external controller.
    
    Not supported yet.
    
    Attributes
    ----------
    FocalDistanceControlType : Literal['Controller'], default='Controller', Not supported yet
        Defines the specific type of FocalDistanceControl model in use.  For a `Controller` object, this must always be set to a value of `Controller`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    FocalDistanceControlType: Literal['Controller'] = Field(alias="FocalDistanceControlType", default='Controller', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of FocalDistanceControl model in use.  For a `Controller` object, this must always be set to a value of `Controller`.

    *Not supported yet*

    - default = 'Controller'
    """

    _relative_schema_path: str = 'Components/Lidar/LidarFocalDistanceControl/ControllerLidarSettings.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'FocalDistanceControlType').merge(LidarFocalDistanceControl._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ControllerLidarSettings.model_rebuild()
