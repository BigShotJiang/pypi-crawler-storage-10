# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.first_order_secondary_rate_response import FirstOrderSecondaryRateResponse
from dnv_bladed_models.first_order_secondary_rate_response import FirstOrderSecondaryRateResponse as FirstOrderSecondaryRateResponseModel
from dnv_bladed_models.proportional_integral_deriviative_for_secondary_rate import ProportionalIntegralDeriviativeForSecondaryRate
from dnv_bladed_models.proportional_integral_deriviative_for_secondary_rate import ProportionalIntegralDeriviativeForSecondaryRate as ProportionalIntegralDeriviativeForSecondaryRateModel
from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand
from dnv_bladed_models.response_to_position_demand import ResponseToPositionDemand as ResponseToPositionDemandModel
from dnv_bladed_models.response_to_secondary_rate_demand import ResponseToSecondaryRateDemand
from dnv_bladed_models.response_to_secondary_rate_demand import ResponseToSecondaryRateDemand as ResponseToSecondaryRateDemandModel
from dnv_bladed_models.response_to_secondary_rate_demand_insert import ResponseToSecondaryRateDemandInsert
from dnv_bladed_models.response_to_secondary_rate_demand_insert import ResponseToSecondaryRateDemandInsert as ResponseToSecondaryRateDemandInsertModel
from dnv_bladed_models.second_order_secondary_rate_response import SecondOrderSecondaryRateResponse
from dnv_bladed_models.second_order_secondary_rate_response import SecondOrderSecondaryRateResponse as SecondOrderSecondaryRateResponseModel
from .schema_helper import SchemaHelper
from .base_entity import *

TResponseToSecondaryRateDemandOptions = TypeVar('TResponseToSecondaryRateDemandOptions', FirstOrderSecondaryRateResponse, ResponseToSecondaryRateDemandInsert, ProportionalIntegralDeriviativeForSecondaryRate, SecondOrderSecondaryRateResponse, ResponseToSecondaryRateDemand, )

class ProportionalIntegralDeriviativeForPosition_DifferentialGainActionEnum(str, Enum):
    ERROR = "Error"
    FEEDBACK = "Feedback"
    SETPOINT = "Setpoint"



class ProportionalIntegralDeriviativeForPosition(ResponseToPositionDemand):
    r"""
    Defines an proportional, integral, deriviative (PID) response to the controller's demands.
    
    Attributes
    ----------
    ResponseToPositionDemandType : Literal['ProportionalIntegralDeriviativeForPosition'], default='ProportionalIntegralDeriviativeForPosition'
        Defines the specific type of ResponseToPositionDemand model in use.  For a `ProportionalIntegralDeriviativeForPosition` object, this must always be set to a value of `ProportionalIntegralDeriviativeForPosition`.
    
    ProportionalGain : float, default=0
        The gain on the contemporaneous error.
    
    IntegralGain : float, default=0
        The gain on the integral from time zero till the present of the error signal.
    
    DifferentialGain : float, default=0
        The gain the filtered derivative of the error.  The derivative of the error is passed through a low-pass filter.
    
    SecondaryRateResponse : Union[FirstOrderSecondaryRateResponse, ResponseToSecondaryRateDemandInsert, ProportionalIntegralDeriviativeForSecondaryRate, SecondOrderSecondaryRateResponse]
    
    DifferentialGainAction : ProportionalIntegralDeriviativeForPosition_DifferentialGainActionEnum, default='Feedback'
        The proportional and integral terms are applied on error.  Derivative term may also be applied on the feedback or setpoint signals.
    
    DifferentialGainTimeConstant : float, default=0
        The derivative term uses a low-pass filter on input.
    
    DesaturationTimeConstant : float, default=0
        The time constant for when the output exceeds the limits.
    
    Notes
    -----
    
    """

    ResponseToPositionDemandType: Literal['ProportionalIntegralDeriviativeForPosition'] = Field(alias="ResponseToPositionDemandType", default='ProportionalIntegralDeriviativeForPosition', frozen=True) # type: ignore
    r"""
    Defines the specific type of ResponseToPositionDemand model in use.  For a `ProportionalIntegralDeriviativeForPosition` object, this must always be set to a value of `ProportionalIntegralDeriviativeForPosition`.
    - default = 'ProportionalIntegralDeriviativeForPosition'
    """

    ProportionalGain: float = Field(alias="ProportionalGain", default=None)
    r"""
    The gain on the contemporaneous error.
    - default = 0
    """

    IntegralGain: float = Field(alias="IntegralGain", default=None)
    r"""
    The gain on the integral from time zero till the present of the error signal.
    - default = 0
    """

    DifferentialGain: float = Field(alias="DifferentialGain", default=None)
    r"""
    The gain the filtered derivative of the error.  The derivative of the error is passed through a low-pass filter.
    - default = 0
    """

    SecondaryRateResponse: Union[FirstOrderSecondaryRateResponseModel, ResponseToSecondaryRateDemandInsertModel, ProportionalIntegralDeriviativeForSecondaryRateModel, SecondOrderSecondaryRateResponseModel] = Field(alias="SecondaryRateResponse", default=None, discriminator='ResponseToSecondaryRateDemandType')
    r"""
    """

    DifferentialGainAction: ProportionalIntegralDeriviativeForPosition_DifferentialGainActionEnum = Field(alias="DifferentialGainAction", default=None)
    r"""
    The proportional and integral terms are applied on error.  Derivative term may also be applied on the feedback or setpoint signals.
    - default = 'Feedback'
    """

    DifferentialGainTimeConstant: float = Field(alias="DifferentialGainTimeConstant", default=None)
    r"""
    The derivative term uses a low-pass filter on input.
    - default = 0
    """

    DesaturationTimeConstant: float = Field(alias="DesaturationTimeConstant", default=None)
    r"""
    The time constant for when the output exceeds the limits.
    - default = 0
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSystemDemand/ResponseToPositionDemand/ProportionalIntegralDeriviativeForPosition.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([('SecondaryRateResponse', 'ResponseToSecondaryRateDemandType'),]), set([]), set([]), 'ResponseToPositionDemandType').merge(ResponseToPositionDemand._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    @property
    def SecondaryRateResponse_as_FirstOrderSecondaryRateResponse(self) -> FirstOrderSecondaryRateResponse:
        """
        Retrieves the value of SecondaryRateResponse guaranteeing it is a FirstOrderSecondaryRateResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        FirstOrderSecondaryRateResponse
            A model object, guaranteed to be a FirstOrderSecondaryRateResponse.

        Raises
        ------
        TypeError
            If the value is not a FirstOrderSecondaryRateResponse.
        """
        return self.SecondaryRateResponse_as(FirstOrderSecondaryRateResponse)


    @property
    def SecondaryRateResponse_as_ProportionalIntegralDeriviativeForSecondaryRate(self) -> ProportionalIntegralDeriviativeForSecondaryRate:
        """
        Retrieves the value of SecondaryRateResponse guaranteeing it is a ProportionalIntegralDeriviativeForSecondaryRate; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ProportionalIntegralDeriviativeForSecondaryRate
            A model object, guaranteed to be a ProportionalIntegralDeriviativeForSecondaryRate.

        Raises
        ------
        TypeError
            If the value is not a ProportionalIntegralDeriviativeForSecondaryRate.
        """
        return self.SecondaryRateResponse_as(ProportionalIntegralDeriviativeForSecondaryRate)


    @property
    def SecondaryRateResponse_as_SecondOrderSecondaryRateResponse(self) -> SecondOrderSecondaryRateResponse:
        """
        Retrieves the value of SecondaryRateResponse guaranteeing it is a SecondOrderSecondaryRateResponse; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SecondOrderSecondaryRateResponse
            A model object, guaranteed to be a SecondOrderSecondaryRateResponse.

        Raises
        ------
        TypeError
            If the value is not a SecondOrderSecondaryRateResponse.
        """
        return self.SecondaryRateResponse_as(SecondOrderSecondaryRateResponse)


    @property
    def SecondaryRateResponse_as_inline(self) -> Union[FirstOrderSecondaryRateResponse, ProportionalIntegralDeriviativeForSecondaryRate, SecondOrderSecondaryRateResponse]:
        """
        Retrieves the value of SecondaryRateResponse as a model object; if the value is specified with a '$insert', an error is raised.

        Returns
        -------
        Union[FirstOrderSecondaryRateResponse, ProportionalIntegralDeriviativeForSecondaryRate, SecondOrderSecondaryRateResponse]
            A model object at the specified index, guaranteed to not be a '$insert'.

        Raises
        ------
        TypeError
            If the value is not one of the concrete types of ResponseToSecondaryRateDemand; i.e. it is specified with a '$insert'.
        """
        if isinstance(self.SecondaryRateResponse, ResponseToSecondaryRateDemandInsert) or self.SecondaryRateResponse.is_insert:
            raise TypeError(f"Expected SecondaryRateResponse value to be an in-line object, but it is currently in the '$insert' state.")
        return self.SecondaryRateResponse


    def SecondaryRateResponse_as(self, cls: Type[TResponseToSecondaryRateDemandOptions])-> TResponseToSecondaryRateDemandOptions:
        """
        Retrieves the value of SecondaryRateResponse, ensuring it is of the specified type.
        The specified type must be one of the valid concrete types of ResponseToSecondaryRateDemand, or the '$insert' type
        (in the case the model is defined to be inserted from an external resource).

        Useful when using type-checking development tools, as it provides a concise way to access a value with the correct type.

        Parameters
        ----------
        cls: Type[Union[FirstOrderSecondaryRateResponse, ResponseToSecondaryRateDemandInsert, ProportionalIntegralDeriviativeForSecondaryRate, SecondOrderSecondaryRateResponse]]
            One of the valid concrete types of ResponseToSecondaryRateDemand, or the '$insert' type
            (in the case the model is defined to be inserted from an external resource).

        Returns
        -------
        TResponseToSecondaryRateDemandOptions
            A model object of the specified type.

        Raises
        ------
        TypeError
            If the value is not of the specified type.

        Examples
        --------
        Get a reference to the value when it is one of the types of ResponseToSecondaryRateDemand:
        >>> val_obj = model_obj.SecondaryRateResponse_as(models.FirstOrderSecondaryRateResponse)
        >>> val_obj = model_obj.SecondaryRateResponse_as(models.ProportionalIntegralDeriviativeForSecondaryRate)
        >>> val_obj = model_obj.SecondaryRateResponse_as(models.SecondOrderSecondaryRateResponse)

        Get a reference to the value, when it was specified with a '$insert' and read in from a file:
        >>> insert_obj = model_obj.SecondaryRateResponse_as(models.ResponseToSecondaryRateDemandInsert)
        """
        if not isinstance(self.SecondaryRateResponse, cls):
            raise TypeError(f"Expected SecondaryRateResponse of type '{cls.__name__}' but was type '{type(self.SecondaryRateResponse).__name__}'")
        return self.SecondaryRateResponse


    def _entity(self) -> bool:
        return True


ProportionalIntegralDeriviativeForPosition.model_rebuild()
