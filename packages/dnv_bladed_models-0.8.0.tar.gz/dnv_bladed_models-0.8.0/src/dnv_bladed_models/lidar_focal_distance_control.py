# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class LidarFocalDistanceControl_FocalDistanceControlTypeEnum(str, Enum):
    CONTROLLER = "Controller"
    MULTIPLE_FOCAL_DISTANCES = "MultipleFocalDistances"
    SINGLE_FOCAL_DISTANCE = "SingleFocalDistance"
    INSERT = "Insert"

class LidarFocalDistanceControl_FocussingModeEnum(str, Enum):
    PULSED = "Pulsed"
    CONTINUOUS = "Continuous"



class LidarFocalDistanceControl(BladedModel, ABC):
    r"""
    The common properties of the different focal distance control methods.
    
    Not supported yet.
    
    Attributes
    ----------
    FocalDistanceControlType : LidarFocalDistanceControl_FocalDistanceControlTypeEnum, Not supported yet
        Defines the specific type of model in use.
    
    FocussingMode : LidarFocalDistanceControl_FocussingModeEnum, Not supported yet
        The focussing mode of the Lidar beam.  Continuous beam that focuses at single point or pulsed beam measures velocities at multiple distances
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    This class is an abstraction, with the following concrete implementations:
        - ControllerLidarSettings
        - LidarFocalDistanceControlInsert
        - MultipleLidarFocalDistances
        - SingleLidarFocalDistance
    
    """

    FocalDistanceControlType: LidarFocalDistanceControl_FocalDistanceControlTypeEnum = Field(alias="FocalDistanceControlType", default=None) # Not supported yet
    r"""
    Defines the specific type of model in use.

    *Not supported yet*

    """

    FocussingMode: LidarFocalDistanceControl_FocussingModeEnum = Field(alias="FocussingMode", default=None) # Not supported yet
    r"""
    The focussing mode of the Lidar beam.  Continuous beam that focuses at single point or pulsed beam measures velocities at multiple distances

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

LidarFocalDistanceControl.model_rebuild()
