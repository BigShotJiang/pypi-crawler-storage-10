# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.applied_moment_vs_friction_torque import AppliedMomentVsFrictionTorque
from dnv_bladed_models.applied_moment_vs_friction_torque import AppliedMomentVsFrictionTorque as AppliedMomentVsFrictionTorqueModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchBearingFrictionXYMomentRelationship(BladedModel):
    r"""
    The relationship between the Coulomb friction and the bending moment over the bearing.
    
    Attributes
    ----------
    FrictionTorquePerUnitAppliedMoment : float
        A fixed ratio between the bending moment over the bearing and the friction opposing the motion.
    
    AppliedMomentVsFrictionTorque : List[AppliedMomentVsFrictionTorque]
        A look-up table describing a non-linear relationship between the bending moment over the bearing and the corresponding friction.
    
    Notes
    -----
    
    """

    FrictionTorquePerUnitAppliedMoment: float = Field(alias="FrictionTorquePerUnitAppliedMoment", default=None)
    r"""
    A fixed ratio between the bending moment over the bearing and the friction opposing the motion.
    """

    AppliedMomentVsFrictionTorque: List[AppliedMomentVsFrictionTorqueModel] = Field(alias="AppliedMomentVsFrictionTorque", default_factory=list)
    r"""
    A look-up table describing a non-linear relationship between the bending moment over the bearing and the corresponding friction.
    """

    _relative_schema_path: str = 'Components/PitchSystem/Friction/PitchBearingKineticFriction/PitchBearingFrictionXYMomentRelationship/PitchBearingFrictionXYMomentRelationship.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['AppliedMomentVsFrictionTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchBearingFrictionXYMomentRelationship.model_rebuild()
