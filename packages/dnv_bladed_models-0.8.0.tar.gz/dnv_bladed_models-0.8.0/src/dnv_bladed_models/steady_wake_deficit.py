# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class SteadyWakeDeficit_SteadyWakeDeficitTypeEnum(str, Enum):
    GAUSSIAN = "Gaussian"
    USER_DEFINED = "UserDefined"
    INSERT = "Insert"



class SteadyWakeDeficit(BladedModel, ABC):
    r"""
    A simple model for the reduced velocity of the wind behind another turbine.  This deficit will be applied across a certain region, and this region will not move around during the simulation.
    
    Attributes
    ----------
    SteadyWakeDeficitType : SteadyWakeDeficit_SteadyWakeDeficitTypeEnum
        Defines the specific type of model in use.
    
    HorizontalOffsetFromHub : float
        The horizontal (global Y) offset of the upwind turbine from the turbine being simulated.
    
    VerticalOffsetFromHub : float
        The vertical (global Z) offset of the upwind turbine from the turbine being simulated.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - Gaussian
        - SteadyWakeDeficitInsert
        - UserDefinedWakeDeficit
    
    """

    SteadyWakeDeficitType: SteadyWakeDeficit_SteadyWakeDeficitTypeEnum = Field(alias="SteadyWakeDeficitType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    HorizontalOffsetFromHub: float = Field(alias="HorizontalOffsetFromHub", default=None)
    r"""
    The horizontal (global Y) offset of the upwind turbine from the turbine being simulated.
    """

    VerticalOffsetFromHub: float = Field(alias="VerticalOffsetFromHub", default=None)
    r"""
    The vertical (global Z) offset of the upwind turbine from the turbine being simulated.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

SteadyWakeDeficit.model_rebuild()
