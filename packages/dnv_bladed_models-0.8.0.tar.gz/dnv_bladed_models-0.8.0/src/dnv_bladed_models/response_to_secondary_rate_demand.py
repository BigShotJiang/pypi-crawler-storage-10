# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class ResponseToSecondaryRateDemand_ResponseToSecondaryRateDemandTypeEnum(str, Enum):
    FIRST_ORDER_SECONDARY_RATE_RESPONSE = "FirstOrderSecondaryRateResponse"
    PROPORTIONAL_INTEGRAL_DERIVIATIVE_FOR_SECONDARY_RATE = "ProportionalIntegralDeriviativeForSecondaryRate"
    SECOND_ORDER_SECONDARY_RATE_RESPONSE = "SecondOrderSecondaryRateResponse"
    INSERT = "Insert"



class ResponseToSecondaryRateDemand(BladedModel, ABC):
    r"""
    The common properties of all control responses.
    
    Attributes
    ----------
    ResponseToSecondaryRateDemandType : ResponseToSecondaryRateDemand_ResponseToSecondaryRateDemandTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - FirstOrderSecondaryRateResponse
        - ResponseToSecondaryRateDemandInsert
        - ProportionalIntegralDeriviativeForSecondaryRate
        - SecondOrderSecondaryRateResponse
    
    """

    ResponseToSecondaryRateDemandType: ResponseToSecondaryRateDemand_ResponseToSecondaryRateDemandTypeEnum = Field(alias="ResponseToSecondaryRateDemandType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

ResponseToSecondaryRateDemand.model_rebuild()
