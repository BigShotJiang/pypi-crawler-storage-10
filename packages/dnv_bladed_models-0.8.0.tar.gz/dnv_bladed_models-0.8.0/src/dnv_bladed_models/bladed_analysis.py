# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.aerodynamic_information_calculation import AerodynamicInformationCalculation
from dnv_bladed_models.aerodynamic_information_calculation import AerodynamicInformationCalculation as AerodynamicInformationCalculationModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.campbell_diagram import CampbellDiagram
from dnv_bladed_models.campbell_diagram import CampbellDiagram as CampbellDiagramModel
from dnv_bladed_models.constants import Constants
from dnv_bladed_models.constants import Constants as ConstantsModel
from dnv_bladed_models.modal_analysis_calculation import ModalAnalysisCalculation
from dnv_bladed_models.modal_analysis_calculation import ModalAnalysisCalculation as ModalAnalysisCalculationModel
from dnv_bladed_models.model_linearisation import ModelLinearisation
from dnv_bladed_models.model_linearisation import ModelLinearisation as ModelLinearisationModel
from dnv_bladed_models.performance_coefficients_calculation import PerformanceCoefficientsCalculation
from dnv_bladed_models.performance_coefficients_calculation import PerformanceCoefficientsCalculation as PerformanceCoefficientsCalculationModel
from dnv_bladed_models.settings import Settings
from dnv_bladed_models.settings import Settings as SettingsModel
from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_insert import SteadyCalculationInsert
from dnv_bladed_models.steady_calculation_insert import SteadyCalculationInsert as SteadyCalculationInsertModel
from dnv_bladed_models.steady_operational_loads_calculation import SteadyOperationalLoadsCalculation
from dnv_bladed_models.steady_operational_loads_calculation import SteadyOperationalLoadsCalculation as SteadyOperationalLoadsCalculationModel
from dnv_bladed_models.steady_parked_loads_calculation import SteadyParkedLoadsCalculation
from dnv_bladed_models.steady_parked_loads_calculation import SteadyParkedLoadsCalculation as SteadyParkedLoadsCalculationModel
from dnv_bladed_models.steady_power_curve_calculation import SteadyPowerCurveCalculation
from dnv_bladed_models.steady_power_curve_calculation import SteadyPowerCurveCalculation as SteadyPowerCurveCalculationModel
from dnv_bladed_models.time_domain_simulation import TimeDomainSimulation
from dnv_bladed_models.time_domain_simulation import TimeDomainSimulation as TimeDomainSimulationModel
from dnv_bladed_models.turbine import Turbine
from dnv_bladed_models.turbine import Turbine as TurbineModel
from .schema_helper import SchemaHelper
from .base_entity import *

TSteadyCalculationOptions = TypeVar('TSteadyCalculationOptions', AerodynamicInformationCalculation, CampbellDiagram, SteadyCalculationInsert, ModalAnalysisCalculation, ModelLinearisation, PerformanceCoefficientsCalculation, SteadyOperationalLoadsCalculation, SteadyParkedLoadsCalculation, SteadyPowerCurveCalculation, SteadyCalculation, )



class BladedAnalysis(BladedModel):
    r"""
    The definition of a single Bladed analysis.
    
    Attributes
    ----------
    TimeDomainSimulation : TimeDomainSimulation
    
    SteadyCalculation : Union[AerodynamicInformationCalculation, CampbellDiagram, SteadyCalculationInsert, ModalAnalysisCalculation, ModelLinearisation, PerformanceCoefficientsCalculation, SteadyOperationalLoadsCalculation, SteadyParkedLoadsCalculation, SteadyPowerCurveCalculation]
    
    Settings : Settings
    
    Constants : Constants
    
    Turbine : Turbine
    
    Notes
    -----
    
    """

    TimeDomainSimulation: TimeDomainSimulationModel = Field(alias="TimeDomainSimulation", default=None)
    r"""
    """

    SteadyCalculation: Union[AerodynamicInformationCalculationModel, CampbellDiagramModel, SteadyCalculationInsertModel, ModalAnalysisCalculationModel, ModelLinearisationModel, PerformanceCoefficientsCalculationModel, SteadyOperationalLoadsCalculationModel, SteadyParkedLoadsCalculationModel, SteadyPowerCurveCalculationModel] = Field(alias="SteadyCalculation", default=None, discriminator='SteadyCalculationType')
    r"""
    """

    Settings: SettingsModel = Field(alias="Settings", default=None)
    r"""
    """

    Constants: ConstantsModel = Field(alias="Constants", default=None)
    r"""
    """

    Turbine: TurbineModel = Field(alias="Turbine", default=None)
    r"""
    """

    _relative_schema_path: str = 'BladedAnalysis.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([('SteadyCalculation', 'SteadyCalculationType'),]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    @property
    def SteadyCalculation_as_AerodynamicInformationCalculation(self) -> AerodynamicInformationCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a AerodynamicInformationCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        AerodynamicInformationCalculation
            A model object, guaranteed to be a AerodynamicInformationCalculation.

        Raises
        ------
        TypeError
            If the value is not a AerodynamicInformationCalculation.
        """
        return self.SteadyCalculation_as(AerodynamicInformationCalculation)


    @property
    def SteadyCalculation_as_CampbellDiagram(self) -> CampbellDiagram:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a CampbellDiagram; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        CampbellDiagram
            A model object, guaranteed to be a CampbellDiagram.

        Raises
        ------
        TypeError
            If the value is not a CampbellDiagram.
        """
        return self.SteadyCalculation_as(CampbellDiagram)


    @property
    def SteadyCalculation_as_ModalAnalysisCalculation(self) -> ModalAnalysisCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a ModalAnalysisCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ModalAnalysisCalculation
            A model object, guaranteed to be a ModalAnalysisCalculation.

        Raises
        ------
        TypeError
            If the value is not a ModalAnalysisCalculation.
        """
        return self.SteadyCalculation_as(ModalAnalysisCalculation)


    @property
    def SteadyCalculation_as_ModelLinearisation(self) -> ModelLinearisation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a ModelLinearisation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        ModelLinearisation
            A model object, guaranteed to be a ModelLinearisation.

        Raises
        ------
        TypeError
            If the value is not a ModelLinearisation.
        """
        return self.SteadyCalculation_as(ModelLinearisation)


    @property
    def SteadyCalculation_as_PerformanceCoefficientsCalculation(self) -> PerformanceCoefficientsCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a PerformanceCoefficientsCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        PerformanceCoefficientsCalculation
            A model object, guaranteed to be a PerformanceCoefficientsCalculation.

        Raises
        ------
        TypeError
            If the value is not a PerformanceCoefficientsCalculation.
        """
        return self.SteadyCalculation_as(PerformanceCoefficientsCalculation)


    @property
    def SteadyCalculation_as_SteadyOperationalLoadsCalculation(self) -> SteadyOperationalLoadsCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a SteadyOperationalLoadsCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SteadyOperationalLoadsCalculation
            A model object, guaranteed to be a SteadyOperationalLoadsCalculation.

        Raises
        ------
        TypeError
            If the value is not a SteadyOperationalLoadsCalculation.
        """
        return self.SteadyCalculation_as(SteadyOperationalLoadsCalculation)


    @property
    def SteadyCalculation_as_SteadyParkedLoadsCalculation(self) -> SteadyParkedLoadsCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a SteadyParkedLoadsCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SteadyParkedLoadsCalculation
            A model object, guaranteed to be a SteadyParkedLoadsCalculation.

        Raises
        ------
        TypeError
            If the value is not a SteadyParkedLoadsCalculation.
        """
        return self.SteadyCalculation_as(SteadyParkedLoadsCalculation)


    @property
    def SteadyCalculation_as_SteadyPowerCurveCalculation(self) -> SteadyPowerCurveCalculation:
        """
        Retrieves the value of SteadyCalculation guaranteeing it is a SteadyPowerCurveCalculation; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        SteadyPowerCurveCalculation
            A model object, guaranteed to be a SteadyPowerCurveCalculation.

        Raises
        ------
        TypeError
            If the value is not a SteadyPowerCurveCalculation.
        """
        return self.SteadyCalculation_as(SteadyPowerCurveCalculation)


    @property
    def SteadyCalculation_as_inline(self) -> Union[AerodynamicInformationCalculation, CampbellDiagram, ModalAnalysisCalculation, ModelLinearisation, PerformanceCoefficientsCalculation, SteadyOperationalLoadsCalculation, SteadyParkedLoadsCalculation, SteadyPowerCurveCalculation]:
        """
        Retrieves the value of SteadyCalculation as a model object; if the value is specified with a '$insert', an error is raised.

        Returns
        -------
        Union[AerodynamicInformationCalculation, CampbellDiagram, ModalAnalysisCalculation, ModelLinearisation, PerformanceCoefficientsCalculation, SteadyOperationalLoadsCalculation, SteadyParkedLoadsCalculation, SteadyPowerCurveCalculation]
            A model object at the specified index, guaranteed to not be a '$insert'.

        Raises
        ------
        TypeError
            If the value is not one of the concrete types of SteadyCalculation; i.e. it is specified with a '$insert'.
        """
        if isinstance(self.SteadyCalculation, SteadyCalculationInsert) or self.SteadyCalculation.is_insert:
            raise TypeError(f"Expected SteadyCalculation value to be an in-line object, but it is currently in the '$insert' state.")
        return self.SteadyCalculation


    def SteadyCalculation_as(self, cls: Type[TSteadyCalculationOptions])-> TSteadyCalculationOptions:
        """
        Retrieves the value of SteadyCalculation, ensuring it is of the specified type.
        The specified type must be one of the valid concrete types of SteadyCalculation, or the '$insert' type
        (in the case the model is defined to be inserted from an external resource).

        Useful when using type-checking development tools, as it provides a concise way to access a value with the correct type.

        Parameters
        ----------
        cls: Type[Union[AerodynamicInformationCalculation, CampbellDiagram, SteadyCalculationInsert, ModalAnalysisCalculation, ModelLinearisation, PerformanceCoefficientsCalculation, SteadyOperationalLoadsCalculation, SteadyParkedLoadsCalculation, SteadyPowerCurveCalculation]]
            One of the valid concrete types of SteadyCalculation, or the '$insert' type
            (in the case the model is defined to be inserted from an external resource).

        Returns
        -------
        TSteadyCalculationOptions
            A model object of the specified type.

        Raises
        ------
        TypeError
            If the value is not of the specified type.

        Examples
        --------
        Get a reference to the value when it is one of the types of SteadyCalculation:
        >>> val_obj = model_obj.SteadyCalculation_as(models.AerodynamicInformationCalculation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.CampbellDiagram)
        >>> val_obj = model_obj.SteadyCalculation_as(models.ModalAnalysisCalculation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.ModelLinearisation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.PerformanceCoefficientsCalculation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.SteadyOperationalLoadsCalculation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.SteadyParkedLoadsCalculation)
        >>> val_obj = model_obj.SteadyCalculation_as(models.SteadyPowerCurveCalculation)

        Get a reference to the value, when it was specified with a '$insert' and read in from a file:
        >>> insert_obj = model_obj.SteadyCalculation_as(models.SteadyCalculationInsert)
        """
        if not isinstance(self.SteadyCalculation, cls):
            raise TypeError(f"Expected SteadyCalculation of type '{cls.__name__}' but was type '{type(self.SteadyCalculation).__name__}'")
        return self.SteadyCalculation


    def _entity(self) -> bool:
        return True


BladedAnalysis.model_rebuild()
