# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.current_horizontal_shear_variation import CurrentHorizontalShearVariation
from dnv_bladed_models.current_horizontal_shear_variation import CurrentHorizontalShearVariation as CurrentHorizontalShearVariationModel
from dnv_bladed_models.time_vs_current_horizontal_shear import TimeVsCurrentHorizontalShear
from dnv_bladed_models.time_vs_current_horizontal_shear import TimeVsCurrentHorizontalShear as TimeVsCurrentHorizontalShearModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CurrentHorizontalShearTimeHistory(CurrentHorizontalShearVariation):
    r"""
    A time history of the current 's horizontal shear.
    
    Not supported yet.
    
    Attributes
    ----------
    HorizontalShearVariationType : Literal['TimeHistory'], default='TimeHistory', Not supported yet
        Defines the specific type of HorizontalShearVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.
    
    TimeVsHorizontalShear : List[TimeVsCurrentHorizontalShear], Not supported yet
        A list of points specifying the current's shear at the corresponding time.  The shear will be interpolated between these points; the shear before the first point will be constant at the first point's value; and the shear after the last point will remain constant at the last point's value
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    HorizontalShearVariationType: Literal['TimeHistory'] = Field(alias="HorizontalShearVariationType", default='TimeHistory', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of HorizontalShearVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.

    *Not supported yet*

    - default = 'TimeHistory'
    """

    TimeVsHorizontalShear: List[TimeVsCurrentHorizontalShearModel] = Field(alias="TimeVsHorizontalShear", default_factory=list) # Not supported yet
    r"""
    A list of points specifying the current's shear at the corresponding time.  The shear will be interpolated between these points; the shear before the first point will be constant at the first point's value; and the shear after the last point will remain constant at the last point's value

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/CurrentHorizontalShearVariation/CurrentHorizontalShearTimeHistory.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['TimeVsHorizontalShear',]), 'HorizontalShearVariationType').merge(CurrentHorizontalShearVariation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CurrentHorizontalShearTimeHistory.model_rebuild()
