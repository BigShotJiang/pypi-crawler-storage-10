# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.irregular_waves import IrregularWaves
from dnv_bladed_models.irregular_waves import IrregularWaves as IrregularWavesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class JonswapPiersonMoskowitz(IrregularWaves):
    r"""
    The definition of Jonswap/Pierson-Moskowitz spectrum waves.
    
    Not supported yet.
    
    Attributes
    ----------
    WavesType : Literal['JonswapPiersonMoskowitz'], default='JonswapPiersonMoskowitz', Not supported yet
        Defines the specific type of Waves model in use.  For a `JonswapPiersonMoskowitz` object, this must always be set to a value of `JonswapPiersonMoskowitz`.
    
    SignificantWaveHeight : float, Not supported yet
        The average height of the highest one third of the waves in the seastate.
    
    SpectralPeakPeriod : float, Not supported yet
        The period of the most energetic component in the wave spectrum.
    
    Peakedness : float, Not supported yet
        The width of the frequency band containing most of the energy in the spectrum.  It should take a value between 1 (Pierson-Moskowitz) and 7.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    WavesType: Literal['JonswapPiersonMoskowitz'] = Field(alias="WavesType", default='JonswapPiersonMoskowitz', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Waves model in use.  For a `JonswapPiersonMoskowitz` object, this must always be set to a value of `JonswapPiersonMoskowitz`.

    *Not supported yet*

    - default = 'JonswapPiersonMoskowitz'
    """

    SignificantWaveHeight: float = Field(alias="SignificantWaveHeight", default=None) # Not supported yet
    r"""
    The average height of the highest one third of the waves in the seastate.

    *Not supported yet*

    """

    SpectralPeakPeriod: float = Field(alias="SpectralPeakPeriod", default=None) # Not supported yet
    r"""
    The period of the most energetic component in the wave spectrum.

    *Not supported yet*

    """

    Peakedness: float = Field(alias="Peakedness", default=None) # Not supported yet
    r"""
    The width of the frequency band containing most of the energy in the spectrum.  It should take a value between 1 (Pierson-Moskowitz) and 7.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Waves/JonswapPiersonMoskowitz.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'WavesType').merge(IrregularWaves._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


JonswapPiersonMoskowitz.model_rebuild()
