# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.linearisation_perturbations import LinearisationPerturbations
from dnv_bladed_models.linearisation_perturbations import LinearisationPerturbations as LinearisationPerturbationsModel
from dnv_bladed_models.model_linearisation_perturbation_magnitudes import ModelLinearisationPerturbationMagnitudes
from dnv_bladed_models.model_linearisation_perturbation_magnitudes import ModelLinearisationPerturbationMagnitudes as ModelLinearisationPerturbationMagnitudesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ModelLinearisationPerturbations(LinearisationPerturbations):
    r"""
    Settings to control the number of perturbations and the perturbation magnitudes.
    
    Attributes
    ----------
    ApplyPitchPerturbationToEachBlade : bool, default=False
        If true, the pitch angle will be perturbed in turn for each blade as well as collectively for all blades
    
    PerturbationMagnitudes : ModelLinearisationPerturbationMagnitudes
    
    Notes
    -----
    
    """

    ApplyPitchPerturbationToEachBlade: bool = Field(alias="ApplyPitchPerturbationToEachBlade", default=None)
    r"""
    If true, the pitch angle will be perturbed in turn for each blade as well as collectively for all blades
    - default = False
    """

    PerturbationMagnitudes: ModelLinearisationPerturbationMagnitudesModel = Field(alias="PerturbationMagnitudes", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/ModelLinearisationPerturbations/ModelLinearisationPerturbations.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(LinearisationPerturbations._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ModelLinearisationPerturbations.model_rebuild()
