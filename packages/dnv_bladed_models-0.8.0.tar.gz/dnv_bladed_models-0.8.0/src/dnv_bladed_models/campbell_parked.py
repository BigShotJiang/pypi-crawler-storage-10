# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation
from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation as CampbellDiagramModeOfOperationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CampbellParked(CampbellDiagramModeOfOperation):
    r"""
    The properties for generating a Campbell diagram for a turbine whilst parked.  This will use the pitch angle for parked defined in the TurbineOperationalParameters section.
    
    Attributes
    ----------
    CampbellDiagramModeOfOperationType : Literal['Parked'], default='Parked'
        Defines the specific type of CampbellDiagramModeOfOperation model in use.  For a `Parked` object, this must always be set to a value of `Parked`.
    
    WindSpeed : float, default=0
        The uniform wind speed (m/s) during the analysis.
    
    WindDirection : float, default=0
        The wind direction in radians.
    
    WindInclination : float, default=0
        The inclination of the flow relative to the horizontal plane.  Typically this is in the order of 8 degrees for an onshore turbine, and 0 degrees for an offshore turbine.
    
    Notes
    -----
    
    """

    CampbellDiagramModeOfOperationType: Literal['Parked'] = Field(alias="CampbellDiagramModeOfOperationType", default='Parked', frozen=True) # type: ignore
    r"""
    Defines the specific type of CampbellDiagramModeOfOperation model in use.  For a `Parked` object, this must always be set to a value of `Parked`.
    - default = 'Parked'
    """

    WindSpeed: float = Field(alias="WindSpeed", default=None)
    r"""
    The uniform wind speed (m/s) during the analysis.
    - default = 0
    """

    WindDirection: float = Field(alias="WindDirection", default=None)
    r"""
    The wind direction in radians.
    - default = 0
    """

    WindInclination: float = Field(alias="WindInclination", default=None)
    r"""
    The inclination of the flow relative to the horizontal plane.  Typically this is in the order of 8 degrees for an onshore turbine, and 0 degrees for an offshore turbine.
    - default = 0
    """

    _relative_schema_path: str = 'SteadyCalculation/CampbellDiagramModeOfOperation/CampbellParked.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'CampbellDiagramModeOfOperationType').merge(CampbellDiagramModeOfOperation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CampbellParked.model_rebuild()
