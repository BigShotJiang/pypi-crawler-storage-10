# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.current_mean_speed_variation import CurrentMeanSpeedVariation
from dnv_bladed_models.current_mean_speed_variation import CurrentMeanSpeedVariation as CurrentMeanSpeedVariationModel
from dnv_bladed_models.time_vs_current_mean_speed import TimeVsCurrentMeanSpeed
from dnv_bladed_models.time_vs_current_mean_speed import TimeVsCurrentMeanSpeed as TimeVsCurrentMeanSpeedModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CurrentMeanSpeedTimeHistory(CurrentMeanSpeedVariation):
    r"""
    A time history of the current's speed.
    
    Not supported yet.
    
    Attributes
    ----------
    MeanSpeedVariationType : Literal['TimeHistory'], default='TimeHistory', Not supported yet
        Defines the specific type of MeanSpeedVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.
    
    TimeVsMeanSpeed : List[TimeVsCurrentMeanSpeed], Not supported yet
        A list of points specifying the current's speed at the corresponding time.  The speed will be interpolated between these points; the speed before the first point will be constant at the first point's value; and the speed after the last point will remain constant at the last point's value
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    MeanSpeedVariationType: Literal['TimeHistory'] = Field(alias="MeanSpeedVariationType", default='TimeHistory', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of MeanSpeedVariation model in use.  For a `TimeHistory` object, this must always be set to a value of `TimeHistory`.

    *Not supported yet*

    - default = 'TimeHistory'
    """

    TimeVsMeanSpeed: List[TimeVsCurrentMeanSpeedModel] = Field(alias="TimeVsMeanSpeed", default_factory=list) # Not supported yet
    r"""
    A list of points specifying the current's speed at the corresponding time.  The speed will be interpolated between these points; the speed before the first point will be constant at the first point's value; and the speed after the last point will remain constant at the last point's value

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/CurrentMeanSpeedVariation/CurrentMeanSpeedTimeHistory.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['TimeVsMeanSpeed',]), 'MeanSpeedVariationType').merge(CurrentMeanSpeedVariation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CurrentMeanSpeedTimeHistory.model_rebuild()
