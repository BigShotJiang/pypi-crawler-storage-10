# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class AirCharacteristics(BladedModel):
    r"""
    The properties of air for use in both onshore and offshore calculations.
    
    Attributes
    ----------
    Density : float, default=1.225
        The air density.
    
    Viscosity : float, default=0.0000182
        The viscosity of the air.
    
    Notes
    -----
    
    """

    Density: float = Field(alias="Density", default=None)
    r"""
    The air density.
    - default = 1.225
    """

    Viscosity: float = Field(alias="Viscosity", default=None)
    r"""
    The viscosity of the air.
    - default = 0.0000182
    """

    _relative_schema_path: str = 'Constants/AirCharacteristics/AirCharacteristics.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


AirCharacteristics.model_rebuild()
