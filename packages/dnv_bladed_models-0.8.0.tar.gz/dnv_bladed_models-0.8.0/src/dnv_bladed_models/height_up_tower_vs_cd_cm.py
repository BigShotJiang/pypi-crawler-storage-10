# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class HeightUpTowerVsCdCm(BladedModel):
    r"""
    A look-up table for the hydrodynamic properties of the tower at different heights.
    
    Not supported yet.
    
    Attributes
    ----------
    HeightUpTower : float, Not supported yet
        The height measured from the bottom of the tower, assuming that the tower is mounted vertically.
    
    Cd : float, Not supported yet
        The coefficient of drag at the specified height.
    
    Cm : float, Not supported yet
        The coefficient of added mass for the tower.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    HeightUpTower: float = Field(alias="HeightUpTower", default=None) # Not supported yet
    r"""
    The height measured from the bottom of the tower, assuming that the tower is mounted vertically.

    *Not supported yet*

    """

    Cd: float = Field(alias="Cd", default=None) # Not supported yet
    r"""
    The coefficient of drag at the specified height.

    *Not supported yet*

    """

    Cm: float = Field(alias="Cm", default=None) # Not supported yet
    r"""
    The coefficient of added mass for the tower.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Tower/TowerHydrodynamicProperties/HeightUpTowerVsCdCm/HeightUpTowerVsCdCm.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


HeightUpTowerVsCdCm.model_rebuild()
