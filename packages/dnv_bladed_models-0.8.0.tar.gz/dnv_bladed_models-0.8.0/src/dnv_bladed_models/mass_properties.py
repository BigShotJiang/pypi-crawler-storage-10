# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class MassProperties(BladedModel):
    r"""
    The mass properties of the cross-section, expressed per unit length where appropriate.  These are defined in the PrincipalInertiaCoordinateSystem.
    
    Attributes
    ----------
    MassPerUnitLength : float
        The mass per unit length.
    
    PolarMassMomentOfInertia : float
        The polar mass moment of inertia per unit length at the mass centre, as defined by the PrincipalInertiaCoordinateSystem.
    
    RadiusOfGyrationRatio : float
        The ratio of the radius of gyration along the principal inertia Y-axis divided by the radius of gyration in the principal inertia X-axis, as defined by the PrincipalInertiaCoordinateSystem.
    
    Notes
    -----
    
    """

    MassPerUnitLength: float = Field(alias="MassPerUnitLength", default=None)
    r"""
    The mass per unit length.
    """

    PolarMassMomentOfInertia: float = Field(alias="PolarMassMomentOfInertia", default=None)
    r"""
    The polar mass moment of inertia per unit length at the mass centre, as defined by the PrincipalInertiaCoordinateSystem.
    """

    RadiusOfGyrationRatio: float = Field(alias="RadiusOfGyrationRatio", default=None)
    r"""
    The ratio of the radius of gyration along the principal inertia Y-axis divided by the radius of gyration in the principal inertia X-axis, as defined by the PrincipalInertiaCoordinateSystem.
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/MassProperties/MassProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


MassProperties.model_rebuild()
