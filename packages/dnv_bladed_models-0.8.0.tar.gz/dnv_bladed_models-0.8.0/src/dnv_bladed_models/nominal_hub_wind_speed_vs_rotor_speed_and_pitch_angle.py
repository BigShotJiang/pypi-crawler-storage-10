# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NominalHubWindSpeedVsRotorSpeedAndPitchAngle(BladedModel):
    r"""
    The look-up table for specifying the nominal free-field wind speed at the hub against the turbine's operating condition appropriate for that wind speed.  Wind speeds need to be in monotonic ascending order. Linear interpolation is used between points. The lowest value for the hub wind speed will be taken as the cut-in wind speed for the turbine, and the highest the cut-out wind speed.
    
    Attributes
    ----------
    NominalHubWindSpeed : float
        The nominal free-field wind speed at the hub.
    
    RotorSpeed : float
        The rotor speed to apply for the specified hub wind speed in steady state/initial condition calculations. The generator torque will be calculated to achieve this rotor speed.  If the torque required is negative, a warning will be generated.
    
    PitchAngle : float
        The pitch angle to apply to all blades for the specified hub wind speed in steady state/initial condition calculations.
    
    Notes
    -----
    
    """

    NominalHubWindSpeed: float = Field(alias="NominalHubWindSpeed", default=None)
    r"""
    The nominal free-field wind speed at the hub.
    """

    RotorSpeed: float = Field(alias="RotorSpeed", default=None)
    r"""
    The rotor speed to apply for the specified hub wind speed in steady state/initial condition calculations. The generator torque will be calculated to achieve this rotor speed.  If the torque required is negative, a warning will be generated.
    """

    PitchAngle: float = Field(alias="PitchAngle", default=None)
    r"""
    The pitch angle to apply to all blades for the specified hub wind speed in steady state/initial condition calculations.
    """

    _relative_schema_path: str = 'Turbine/TurbineOperationalParameters/NominalHubWindSpeedVsRotorSpeedAndPitchAngle/NominalHubWindSpeedVsRotorSpeedAndPitchAngle.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NominalHubWindSpeedVsRotorSpeedAndPitchAngle.model_rebuild()
