# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class TransducerFaults_FaultTypeEnum(str, Enum):
    NONE = "None"
    NOISE = "Noise"
    TO_CONSTANT = "ToConstant"
    CONSTANT_OFFSET = "ConstantOffset"
    GROWING_OFFSET = "GrowingOffset"
    HARMONIC_OFFSET = "HarmonicOffset"



class TransducerFaults(BladedModel, ABC):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    ApplyOnlyToFirst : bool, default=True, Not supported yet
        If true, the fault will be aplied only to the first instance of this transducer.  If false, all sensors of this type will fail identically.
    
    MiscalibrationOffset : float, default=0, Not supported yet
        A constant value added to the sensor's output - for example, if the sensor had been incorrectly installed or poorly calibrated.
    
    InverseInstallation : bool, default=False, Not supported yet
        Whether the sensor was installed in reverse, resulting in its outputs being multiplied by -1.0.
    
    FailTime : float, default=0, Not supported yet
        The time at which any time-dependent failure occurs.  This will be from the beginning of the simulation, and not from the start of logging.  Please ensure that this time will equate to a period which is being clearly logged.
    
    FaultType : TransducerFaults_FaultTypeEnum, default='None', Not supported yet
        What fault occurs at a specified time in the simulation.
    
    NoiseMultiplier : float, default=1, Not supported yet
        The factor by which the noise on the signal increases (or decreases) by.
    
    FailureValue : float, default=0, Not supported yet
        The value which the sensor reverts to in the case of failure.
    
    FailureValueRampRate : float, default=0, Not supported yet
        The rate at which the signal reverts to its fail value.  A rate of 0.0 represents an instantaneous step change to the fail value.
    
    ConstantOffset : float, default=0, Not supported yet
        The value by which the signal is offset by.
    
    GrowingOffset : float, default=0, Not supported yet
        The rate at which the signal is deviating from its calibrated value.
    
    Magnitude : float, default=0, Not supported yet
        The greatest magnitude of the harmonic interference from the 'true' value.
    
    Period : float, default=1, Not supported yet
        The time period of the full sinusoidal interference pattern.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ApplyOnlyToFirst: bool = Field(alias="ApplyOnlyToFirst", default=None) # Not supported yet
    r"""
    If true, the fault will be aplied only to the first instance of this transducer.  If false, all sensors of this type will fail identically.

    *Not supported yet*

    - default = True
    """

    MiscalibrationOffset: float = Field(alias="MiscalibrationOffset", default=None) # Not supported yet
    r"""
    A constant value added to the sensor's output - for example, if the sensor had been incorrectly installed or poorly calibrated.

    *Not supported yet*

    - default = 0
    """

    InverseInstallation: bool = Field(alias="InverseInstallation", default=None) # Not supported yet
    r"""
    Whether the sensor was installed in reverse, resulting in its outputs being multiplied by -1.0.

    *Not supported yet*

    - default = False
    """

    FailTime: float = Field(alias="FailTime", default=None) # Not supported yet
    r"""
    The time at which any time-dependent failure occurs.  This will be from the beginning of the simulation, and not from the start of logging.  Please ensure that this time will equate to a period which is being clearly logged.

    *Not supported yet*

    - default = 0
    """

    FaultType: TransducerFaults_FaultTypeEnum = Field(alias="FaultType", default=None) # Not supported yet
    r"""
    What fault occurs at a specified time in the simulation.

    *Not supported yet*

    - default = 'None'
    """

    NoiseMultiplier: float = Field(alias="NoiseMultiplier", default=None) # Not supported yet
    r"""
    The factor by which the noise on the signal increases (or decreases) by.

    *Not supported yet*

    - default = 1
    """

    FailureValue: float = Field(alias="FailureValue", default=None) # Not supported yet
    r"""
    The value which the sensor reverts to in the case of failure.

    *Not supported yet*

    - default = 0
    """

    FailureValueRampRate: float = Field(alias="FailureValueRampRate", default=None) # Not supported yet
    r"""
    The rate at which the signal reverts to its fail value.  A rate of 0.0 represents an instantaneous step change to the fail value.

    *Not supported yet*

    - default = 0
    """

    ConstantOffset: float = Field(alias="ConstantOffset", default=None) # Not supported yet
    r"""
    The value by which the signal is offset by.

    *Not supported yet*

    - default = 0
    """

    GrowingOffset: float = Field(alias="GrowingOffset", default=None) # Not supported yet
    r"""
    The rate at which the signal is deviating from its calibrated value.

    *Not supported yet*

    - default = 0
    """

    Magnitude: float = Field(alias="Magnitude", default=None) # Not supported yet
    r"""
    The greatest magnitude of the harmonic interference from the 'true' value.

    *Not supported yet*

    - default = 0
    """

    Period: float = Field(alias="Period", default=None) # Not supported yet
    r"""
    The time period of the full sinusoidal interference pattern.

    *Not supported yet*

    - default = 1
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

TransducerFaults.model_rebuild()
