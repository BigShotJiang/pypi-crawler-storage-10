# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.generator_speed_vs_generator_torque import GeneratorSpeedVsGeneratorTorque
from dnv_bladed_models.generator_speed_vs_generator_torque import GeneratorSpeedVsGeneratorTorque as GeneratorSpeedVsGeneratorTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PartialLoadOperation(BladedModel):
    r"""
    The general parameters of the torque control strategy while the turbine is operating at less than its rated power.  These are used to determine steady-state conditions, such as the initial conditions for a time-domain simulation.
    
    Attributes
    ----------
    OptimalModeGain : float
        The ratio between the generator torque demand and the square of the measured generator speed.
    
    MinimumGeneratorSpeed : float
        The minimum speed at which the generator will be producing power and thus apply a generator torque.
    
    GeneratorSpeedVsGeneratorTorque : List[GeneratorSpeedVsGeneratorTorque]
        A look-up table of the generator torque demand vs the measured generator speed. The table must extend up to FullLoadOperation.GeneratorSpeed which is the range Bladed will use.
    
    Notes
    -----
    
    """

    OptimalModeGain: float = Field(alias="OptimalModeGain", default=None)
    r"""
    The ratio between the generator torque demand and the square of the measured generator speed.
    """

    MinimumGeneratorSpeed: float = Field(alias="MinimumGeneratorSpeed", default=None)
    r"""
    The minimum speed at which the generator will be producing power and thus apply a generator torque.
    """

    GeneratorSpeedVsGeneratorTorque: List[GeneratorSpeedVsGeneratorTorqueModel] = Field(alias="GeneratorSpeedVsGeneratorTorque", default_factory=list)
    r"""
    A look-up table of the generator torque demand vs the measured generator speed. The table must extend up to FullLoadOperation.GeneratorSpeed which is the range Bladed will use.
    """

    _relative_schema_path: str = 'Turbine/TurbineOperationalParameters/VariableSpeedPitchRegulatedControlModel/PartialLoadOperation/PartialLoadOperation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['GeneratorSpeedVsGeneratorTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PartialLoadOperation.model_rebuild()
