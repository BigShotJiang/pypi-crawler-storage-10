# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class EquilibriumStateSolverSettings(BladedModel):
    r"""
    The settings pertaining to the determination of equilibrium conditions, used for steady calculations or initial conditions.
    
    Attributes
    ----------
    ModalStatesRelaxationFactor : float, default=0.4
        The relaxation factor applied to modal states during iterations to find the equilibrium conditions, to improve numerical stability.  This is used to calculate the initial conditions for time domain calculations, and the steady state in steady calculations.
    
    FloatingPlatformStatesRelaxationFactor : float, default=0.4, Not supported yet
        The relaxation factor applied to floating platform positional states during iterations to find the equilibrium conditions, to improve numerical stability.  This is used to calculate the initial conditions for time domain calculations, and the steady state in steady calculations.
    
    Notes
    -----
    
    """

    ModalStatesRelaxationFactor: float = Field(alias="ModalStatesRelaxationFactor", default=None)
    r"""
    The relaxation factor applied to modal states during iterations to find the equilibrium conditions, to improve numerical stability.  This is used to calculate the initial conditions for time domain calculations, and the steady state in steady calculations.
    - default = 0.4
    """

    FloatingPlatformStatesRelaxationFactor: float = Field(alias="FloatingPlatformStatesRelaxationFactor", default=None) # Not supported yet
    r"""
    The relaxation factor applied to floating platform positional states during iterations to find the equilibrium conditions, to improve numerical stability.  This is used to calculate the initial conditions for time domain calculations, and the steady state in steady calculations.

    *Not supported yet*

    - default = 0.4
    """

    _relative_schema_path: str = 'Settings/SolverSettings/EquilibriumStateSolverSettings/EquilibriumStateSolverSettings.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


EquilibriumStateSolverSettings.model_rebuild()
