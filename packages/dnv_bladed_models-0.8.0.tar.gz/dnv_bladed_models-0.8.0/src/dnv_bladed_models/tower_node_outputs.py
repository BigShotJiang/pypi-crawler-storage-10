# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerNodeOutputs(BladedModel):
    r"""
    The outputs to produce for a specified node or node type.
    
    Not supported yet.
    
    Attributes
    ----------
    Displacements : bool, default=False, Not supported yet
        If true, the displacements of the nodes from their undeformed position will be output.
    
    Loads : bool, default=False, Not supported yet
        If true, the loads on the tower at the node's location will be output.
    
    WaterKinematics : bool, default=False, Not supported yet
        If true, the water velocities and accelerations at the node's location will be output.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Displacements: bool = Field(alias="Displacements", default=None) # Not supported yet
    r"""
    If true, the displacements of the nodes from their undeformed position will be output.

    *Not supported yet*

    - default = False
    """

    Loads: bool = Field(alias="Loads", default=None) # Not supported yet
    r"""
    If true, the loads on the tower at the node's location will be output.

    *Not supported yet*

    - default = False
    """

    WaterKinematics: bool = Field(alias="WaterKinematics", default=None) # Not supported yet
    r"""
    If true, the water velocities and accelerations at the node's location will be output.

    *Not supported yet*

    - default = False
    """

    _relative_schema_path: str = 'Components/Tower/TowerOutputGroupLibrary/TowerOutputGroup/TowerNodeOutputs/TowerNodeOutputs.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerNodeOutputs.model_rebuild()
