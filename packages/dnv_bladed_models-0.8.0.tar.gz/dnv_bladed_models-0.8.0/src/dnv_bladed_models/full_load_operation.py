# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FullLoadOperation(BladedModel):
    r"""
    The general parameters of the pitch control strategy while the turbine is operating at its full rated power.  These are used to determine steady-state conditions, such as the initial conditions for a time-domain simulation.
    
    Attributes
    ----------
    GeneratorTorque : float
        The generator torque while the turbine is operating at its rated power.
    
    GeneratorSpeed : float
        The speed when the turbine is operating at its rated power.
    
    Notes
    -----
    
    """

    GeneratorTorque: float = Field(alias="GeneratorTorque", default=None)
    r"""
    The generator torque while the turbine is operating at its rated power.
    """

    GeneratorSpeed: float = Field(alias="GeneratorSpeed", default=None)
    r"""
    The speed when the turbine is operating at its rated power.
    """

    _relative_schema_path: str = 'Turbine/TurbineOperationalParameters/VariableSpeedPitchRegulatedControlModel/FullLoadOperation/FullLoadOperation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FullLoadOperation.model_rebuild()
