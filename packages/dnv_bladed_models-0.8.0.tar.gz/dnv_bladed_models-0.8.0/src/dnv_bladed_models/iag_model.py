# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_stall import DynamicStall
from dnv_bladed_models.dynamic_stall import DynamicStall as DynamicStallModel
from .schema_helper import SchemaHelper
from .base_entity import *




class IAGModel(DynamicStall):
    r"""
    The IAG dynamic stall model.
    
    Attributes
    ----------
    DynamicStallType : Literal['IAGModel'], default='IAGModel'
        Defines the specific type of DynamicStall model in use.  For a `IAGModel` object, this must always be set to a value of `IAGModel`.
    
    UseImpulsiveContributions : bool, default=True
        Enabling the impulsive contributions in lift and moment coefficient.
    
    PressureLagTimeConstant : float, default=1.7
        The lag between the pressure and the lift.
    
    VortexLiftTimeConstant : float, default=6
        The rate of decay of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    
    VortexTravelTimeConstant : float, default=6
        The time constant that controls the duration of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    
    AttachedFlowConstantA1 : float, default=0.3
        The constant A1 for the IAG dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantA2 : float, default=0.7
        The constant A2 for the IAG dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantB1 : float, default=0.7
        The constant B1 for the IAG dynamic stall model to control the attached flow states.
    
    AttachedFlowConstantB2 : float, default=0.53
        The constant B2 for the IAG dynamic stall model to control the attached flow states.
    
    Notes
    -----
    
    """

    DynamicStallType: Literal['IAGModel'] = Field(alias="DynamicStallType", default='IAGModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicStall model in use.  For a `IAGModel` object, this must always be set to a value of `IAGModel`.
    - default = 'IAGModel'
    """

    UseImpulsiveContributions: bool = Field(alias="UseImpulsiveContributions", default=None)
    r"""
    Enabling the impulsive contributions in lift and moment coefficient.
    - default = True
    """

    PressureLagTimeConstant: float = Field(alias="PressureLagTimeConstant", default=None)
    r"""
    The lag between the pressure and the lift.
    - default = 1.7
    """

    VortexLiftTimeConstant: float = Field(alias="VortexLiftTimeConstant", default=None)
    r"""
    The rate of decay of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    - default = 6
    """

    VortexTravelTimeConstant: float = Field(alias="VortexTravelTimeConstant", default=None)
    r"""
    The time constant that controls the duration of the vortex induced lift that is generated when aerofoils undergo a rapid change in angle of attack towards positive or negative stall.
    - default = 6
    """

    AttachedFlowConstantA1: float = Field(alias="AttachedFlowConstantA1", default=None)
    r"""
    The constant A1 for the IAG dynamic stall model to control the attached flow states.
    - default = 0.3
    """

    AttachedFlowConstantA2: float = Field(alias="AttachedFlowConstantA2", default=None)
    r"""
    The constant A2 for the IAG dynamic stall model to control the attached flow states.
    - default = 0.7
    """

    AttachedFlowConstantB1: float = Field(alias="AttachedFlowConstantB1", default=None)
    r"""
    The constant B1 for the IAG dynamic stall model to control the attached flow states.
    - default = 0.7
    """

    AttachedFlowConstantB2: float = Field(alias="AttachedFlowConstantB2", default=None)
    r"""
    The constant B2 for the IAG dynamic stall model to control the attached flow states.
    - default = 0.53
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/DynamicStall/IAGModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicStallType').merge(DynamicStall._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


IAGModel.model_rebuild()
