# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.iced_condition import IcedCondition
from dnv_bladed_models.iced_condition import IcedCondition as IcedConditionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class GL2010Icing(IcedCondition):
    r"""
    The initial condition of a blade being iced according to the GL2010 standards.  This will remain unchanged throughout the simulation.
    
    Not supported yet.
    
    Attributes
    ----------
    InitialConditionType : Literal['GL2010Icing'], default='GL2010Icing', Not supported yet
        Defines the specific type of InitialCondition model in use.  For a `GL2010Icing` object, this must always be set to a value of `GL2010Icing`.
    
    ReferenceTipChord : float, Not supported yet
        The blade tip chord  for the GL2010 ice model standards.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    InitialConditionType: Literal['GL2010Icing'] = Field(alias="InitialConditionType", default='GL2010Icing', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of InitialCondition model in use.  For a `GL2010Icing` object, this must always be set to a value of `GL2010Icing`.

    *Not supported yet*

    - default = 'GL2010Icing'
    """

    ReferenceTipChord: float = Field(alias="ReferenceTipChord", default=None) # Not supported yet
    r"""
    The blade tip chord  for the GL2010 ice model standards.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/InitialCondition/GL2010Icing.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(IcedCondition._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


GL2010Icing.model_rebuild()
