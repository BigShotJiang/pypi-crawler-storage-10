# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.transducer_behaviour import TransducerBehaviour
from dnv_bladed_models.transducer_behaviour import TransducerBehaviour as TransducerBehaviourModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PassiveTransducerResponse(TransducerBehaviour):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    TransducerBehaviourType : Literal['PassiveTransducerResponse'], default='PassiveTransducerResponse', Not supported yet
        Defines the specific type of TransducerBehaviour model in use.  For a `PassiveTransducerResponse` object, this must always be set to a value of `PassiveTransducerResponse`.
    
    Numerators : List[float], Not supported yet
        The numerators of the transfer function. Transfer function must be at least second order.
    
    Denominators : List[float], Not supported yet
        The denominators of the transfer function. Transfer function must be at least second order.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TransducerBehaviourType: Literal['PassiveTransducerResponse'] = Field(alias="TransducerBehaviourType", default='PassiveTransducerResponse', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of TransducerBehaviour model in use.  For a `PassiveTransducerResponse` object, this must always be set to a value of `PassiveTransducerResponse`.

    *Not supported yet*

    - default = 'PassiveTransducerResponse'
    """

    Numerators: List[float] = Field(alias="Numerators", default_factory=list) # Not supported yet
    r"""
    The numerators of the transfer function. Transfer function must be at least second order.

    *Not supported yet*

    """

    Denominators: List[float] = Field(alias="Denominators", default_factory=list) # Not supported yet
    r"""
    The denominators of the transfer function. Transfer function must be at least second order.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/common/PassiveTransducerResponse.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['Numerators','Denominators',]), 'TransducerBehaviourType').merge(TransducerBehaviour._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PassiveTransducerResponse.model_rebuild()
