# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_controller_rate_safety_system import PitchControllerRateSafetySystem
from dnv_bladed_models.pitch_controller_rate_safety_system import PitchControllerRateSafetySystem as PitchControllerRateSafetySystemModel
from dnv_bladed_models.rate_vs_position import RateVsPosition
from dnv_bladed_models.rate_vs_position import RateVsPosition as RateVsPositionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchRateVariesWithPosition(PitchControllerRateSafetySystem):
    r"""
    A safety system where the pitch system will adjust its rate dependent on the position of the bearing once the safety system has been triggered.
    
    Not supported yet.
    
    Attributes
    ----------
    PitchSafetySystemType : Literal['RateVariesWithPosition'], default='RateVariesWithPosition', Not supported yet
        Defines the specific type of PitchSafetySystem model in use.  For a `RateVariesWithPosition` object, this must always be set to a value of `RateVariesWithPosition`.
    
    PositionVsRate : List[RateVsPosition], Not supported yet
        A look-up table of the rate versus the position of the bearing.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    PitchSafetySystemType: Literal['RateVariesWithPosition'] = Field(alias="PitchSafetySystemType", default='RateVariesWithPosition', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of PitchSafetySystem model in use.  For a `RateVariesWithPosition` object, this must always be set to a value of `RateVariesWithPosition`.

    *Not supported yet*

    - default = 'RateVariesWithPosition'
    """

    PositionVsRate: List[RateVsPositionModel] = Field(alias="PositionVsRate", default_factory=list) # Not supported yet
    r"""
    A look-up table of the rate versus the position of the bearing.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchController/PitchSafetySystem/PitchRateVariesWithPosition.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['PositionVsRate',]), 'PitchSafetySystemType').merge(PitchControllerRateSafetySystem._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchRateVariesWithPosition.model_rebuild()
