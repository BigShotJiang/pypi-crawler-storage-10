# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Rotation(Component):
    r"""
    A change in orientation between two components, or the origin - [0,0,0] - and the first component in the Assembly tree.  This will be modelled as completely rigid.
    
    Attributes
    ----------
    ComponentType : Literal['Rotation'], default='Rotation'
        Defines the specific type of Component model in use.  For a `Rotation` object, this must always be set to a value of `Rotation`.
    
    AxisOfRotation : Vector3D
    
    AngleOfRotation : float
        The angle to rotate around the AxisOfRotation, following the right-hand-rule.
    
    Notes
    -----
    
    """

    ComponentType: Literal['Rotation'] = Field(alias="ComponentType", default='Rotation', frozen=True) # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `Rotation` object, this must always be set to a value of `Rotation`.
    - default = 'Rotation'
    """

    AxisOfRotation: Vector3DModel = Field(alias="AxisOfRotation", default=None)
    r"""
    """

    AngleOfRotation: float = Field(alias="AngleOfRotation", default=None)
    r"""
    The angle to rotate around the AxisOfRotation, following the right-hand-rule.
    """

    _relative_schema_path: str = 'Components/Rotation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(Component._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Rotation.model_rebuild()
