# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RadiusVsDeficit(BladedModel):
    r"""
    A line or row in a look-up table, specifying a value of deficit for a specified radius.
    
    Attributes
    ----------
    Radius : float
        The radius at which the deficit applies.
    
    Deficit : float
        The deficit corresponding to the specified radius.  1.0 or 100% would be a reduction of the wind to zero, whereas 0.0 or 0% would represent no change in the free-field wind speed.
    
    Notes
    -----
    
    """

    Radius: float = Field(alias="Radius", default=None)
    r"""
    The radius at which the deficit applies.
    """

    Deficit: float = Field(alias="Deficit", default=None)
    r"""
    The deficit corresponding to the specified radius.  1.0 or 100% would be a reduction of the wind to zero, whereas 0.0 or 0% would represent no change in the free-field wind speed.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/SteadyWakeDeficit/RadiusVsDeficit/RadiusVsDeficit.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RadiusVsDeficit.model_rebuild()
