# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.meandering_wake import MeanderingWake
from dnv_bladed_models.meandering_wake import MeanderingWake as MeanderingWakeModel
from dnv_bladed_models.position_of_upwind_turbine import PositionOfUpwindTurbine
from dnv_bladed_models.position_of_upwind_turbine import PositionOfUpwindTurbine as PositionOfUpwindTurbineModel
from dnv_bladed_models.wake_properties_of_upstream_turbine import WakePropertiesOfUpstreamTurbine
from dnv_bladed_models.wake_properties_of_upstream_turbine import WakePropertiesOfUpstreamTurbine as WakePropertiesOfUpstreamTurbineModel
from .schema_helper import SchemaHelper
from .base_entity import *




class DynamicUpstreamWake(BladedModel):
    r"""
    
    
    Attributes
    ----------
    RadialStepSize : float, default=0.05
        The resolution of the wake deficit profile in the radial direction.
    
    NumberOfRadialPoints : int, default=50
        The total number of points in the radial wake deficit profile.
    
    StreamwiseStep : float, default=0.1
        The integration step in streamwise direction for the propagation of the wake.
    
    MixingLength : float, default=1.323
        The length scale of the part of ambient turbulence which affects the wake deficit evolution.
    
    ShearCalibrationConstant : float, default=0.008
        The calibration factor for self-generated turbulence.  IEC edition 4 recommends a value of 0.008.
    
    AmbientCalibrationConstant : float, default=0.023
        The calibration factor for influence of ambient turbulence.  IEC edition 4 recommends a value of 0.023.
    
    PositionOfUpwindTurbine : PositionOfUpwindTurbine
    
    WakePropertiesOfUpstreamTurbine : WakePropertiesOfUpstreamTurbine
    
    MeanderingWake : MeanderingWake
    
    Notes
    -----
    
    """

    RadialStepSize: float = Field(alias="RadialStepSize", default=None)
    r"""
    The resolution of the wake deficit profile in the radial direction.
    - default = 0.05
    """

    NumberOfRadialPoints: int = Field(alias="NumberOfRadialPoints", default=None)
    r"""
    The total number of points in the radial wake deficit profile.
    - default = 50
    """

    StreamwiseStep: float = Field(alias="StreamwiseStep", default=None)
    r"""
    The integration step in streamwise direction for the propagation of the wake.
    - default = 0.1
    """

    MixingLength: float = Field(alias="MixingLength", default=None)
    r"""
    The length scale of the part of ambient turbulence which affects the wake deficit evolution.
    - default = 1.323
    """

    ShearCalibrationConstant: float = Field(alias="ShearCalibrationConstant", default=None)
    r"""
    The calibration factor for self-generated turbulence.  IEC edition 4 recommends a value of 0.008.
    - default = 0.008
    """

    AmbientCalibrationConstant: float = Field(alias="AmbientCalibrationConstant", default=None)
    r"""
    The calibration factor for influence of ambient turbulence.  IEC edition 4 recommends a value of 0.023.
    - default = 0.023
    """

    PositionOfUpwindTurbine: PositionOfUpwindTurbineModel = Field(alias="PositionOfUpwindTurbine", default=None)
    r"""
    """

    WakePropertiesOfUpstreamTurbine: WakePropertiesOfUpstreamTurbineModel = Field(alias="WakePropertiesOfUpstreamTurbine", default=None)
    r"""
    """

    MeanderingWake: MeanderingWakeModel = Field(alias="MeanderingWake", default=None)
    r"""
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/DynamicUpstreamWake/DynamicUpstreamWake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


DynamicUpstreamWake.model_rebuild()
