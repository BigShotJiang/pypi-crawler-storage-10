# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SelectedComponentOutputGroup(BladedModel):
    r"""
    A reference to the OutputGroup on a specific component within the assembly.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentWithinAssembly : str, regex=^Assembly.(.+)$, Not supported yet
        A qualified, dot-separated path to a component in the assembly tree.  e.g. `Assembly.Hub.PitchSystem1.Blade`
    
    SelectedOutputGroup : str, Not supported yet
        This is the name of the OutputGroup that should be used for the selected component, as defined in the OutputGroups library of the component's definition.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentWithinAssembly: str = Field(alias="@ComponentWithinAssembly", default=None, pattern='^Assembly.(.+)$') # Not supported yet
    r"""
    A qualified, dot-separated path to a component in the assembly tree.  e.g. `Assembly.Hub.PitchSystem1.Blade`

    *Not supported yet*

    - regex = ^Assembly.(.+)$
    """

    SelectedOutputGroup: str = Field(alias="@SelectedOutputGroup", default=None) # Not supported yet
    r"""
    This is the name of the OutputGroup that should be used for the selected component, as defined in the OutputGroups library of the component's definition.

    *Not supported yet*

    """

    _relative_schema_path: str = 'common/SelectedComponentOutputGroup.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SelectedComponentOutputGroup.model_rebuild()
