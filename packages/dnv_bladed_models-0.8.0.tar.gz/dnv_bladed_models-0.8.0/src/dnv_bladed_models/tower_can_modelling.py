# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerCanModelling(BladedModel):
    r"""
    Parameters controlling the way the can will be modelled by Bladed.
    
    Attributes
    ----------
    MaximumNodeSpacing : float
        If any two nodes are further spaced apart than this, an additional node or nodes will be added equally spaced between them.  The default is infinity, meaning that no extra nodes will ever be added unless NumberOfIntermediateNodes has been specified.
    
    NumberOfIntermediateNodes : int, default=0
        The number of structural nodes to be added, equally spaced between the top and bottom of the can.  The default is 0, meaning that (unless the MaximumNodeSpacing requires additional nodes to be added) the can will be represented by a single beam.
    
    Notes
    -----
    
    """

    MaximumNodeSpacing: float = Field(alias="MaximumNodeSpacing", default=None)
    r"""
    If any two nodes are further spaced apart than this, an additional node or nodes will be added equally spaced between them.  The default is infinity, meaning that no extra nodes will ever be added unless NumberOfIntermediateNodes has been specified.
    """

    NumberOfIntermediateNodes: int = Field(alias="NumberOfIntermediateNodes", default=None)
    r"""
    The number of structural nodes to be added, equally spaced between the top and bottom of the can.  The default is 0, meaning that (unless the MaximumNodeSpacing requires additional nodes to be added) the can will be represented by a single beam.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Tower/TowerCan/TowerCanModelling/TowerCanModelling.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerCanModelling.model_rebuild()
