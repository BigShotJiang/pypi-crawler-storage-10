# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NacelleVibration(BladedModel):
    r"""
    The definition of the safety system behaviour when the vibration in the nacelle is too high
    
    Not supported yet.
    
    Attributes
    ----------
    TripValue : float, Not supported yet
        The vibration level above which the circuit should be activated.
    
    Delay : float, Not supported yet
        The delay after the TripValue is reached before the circuit is activated.
    
    CircuitToActivate : str, regex=^SafetyCircuitLibrary.(.+)$, Not supported yet
        The safety system circuit to activate, which defines the actions to take, specified with the key of the SafetySystemCircuit in the SafetyCircuitLibrary.  i.e. `SafetyCircuitLibrary.<circuit-key>`
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TripValue: float = Field(alias="TripValue", default=None) # Not supported yet
    r"""
    The vibration level above which the circuit should be activated.

    *Not supported yet*

    """

    Delay: float = Field(alias="Delay", default=None) # Not supported yet
    r"""
    The delay after the TripValue is reached before the circuit is activated.

    *Not supported yet*

    """

    CircuitToActivate: str = Field(alias="@CircuitToActivate", default=None, pattern='^SafetyCircuitLibrary.(.+)$') # Not supported yet
    r"""
    The safety system circuit to activate, which defines the actions to take, specified with the key of the SafetySystemCircuit in the SafetyCircuitLibrary.  i.e. `SafetyCircuitLibrary.<circuit-key>`

    *Not supported yet*

    - regex = ^SafetyCircuitLibrary.(.+)$
    """

    _relative_schema_path: str = 'Turbine/BladedControl/SafetySystem/NacelleVibration/NacelleVibration.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NacelleVibration.model_rebuild()
