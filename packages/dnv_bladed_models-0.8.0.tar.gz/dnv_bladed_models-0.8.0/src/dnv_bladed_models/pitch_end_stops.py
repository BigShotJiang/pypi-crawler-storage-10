# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchEndStops(BladedModel):
    r"""
    The pitch angles of end-stops at fine pitch (minimum) and feather pitch (maximum).
    
    Attributes
    ----------
    MinimumAngle : float
        The position of the end-stop in the fine pitch direction.
    
    MaximumAngle : float
        The position of the end-stop in the feather pitch direction.
    
    StiffnessOnceExceeded : float
        The stiffness of both end-stops.  Force is only applied when position has exceeded the end-stop position.
    
    Notes
    -----
    
    """

    MinimumAngle: float = Field(alias="MinimumAngle", default=None)
    r"""
    The position of the end-stop in the fine pitch direction.
    """

    MaximumAngle: float = Field(alias="MaximumAngle", default=None)
    r"""
    The position of the end-stop in the feather pitch direction.
    """

    StiffnessOnceExceeded: float = Field(alias="StiffnessOnceExceeded", default=None)
    r"""
    The stiffness of both end-stops.  Force is only applied when position has exceeded the end-stop position.
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchEndStops/PitchEndStops.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchEndStops.model_rebuild()
