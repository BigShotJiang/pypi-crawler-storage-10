# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.blade_modelling import BladeModelling
from dnv_bladed_models.blade_modelling import BladeModelling as BladeModellingModel
from dnv_bladed_models.structural_mode import StructuralMode
from dnv_bladed_models.structural_mode import StructuralMode as StructuralModeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FiniteElementBladeModelling(BladeModelling):
    r"""
    The properties for the structural modelling of the blade using finite element analysis without modal reduction.
    
    Attributes
    ----------
    BladeModellingType : Literal['FiniteElementBladeModelling'], default='FiniteElementBladeModelling'
        Defines the specific type of BladeModelling model in use.  For a `FiniteElementBladeModelling` object, this must always be set to a value of `FiniteElementBladeModelling`.
    
    WholeBladeModeDampingRatios : List[StructuralMode]
        List of known whole-blade mode damping ratios. The whole-blade damping ratios will be converted into finite element degrees of freedom by Bladed. If the list is incomplete, meaning it lacks damping ratios for all modes, Bladed will assign frequency-proportional damping based on the damping ratio of the highest defined mode. The list must contain at least one entry.
    
    Notes
    -----
    
    """

    BladeModellingType: Literal['FiniteElementBladeModelling'] = Field(alias="BladeModellingType", default='FiniteElementBladeModelling', frozen=True) # type: ignore
    r"""
    Defines the specific type of BladeModelling model in use.  For a `FiniteElementBladeModelling` object, this must always be set to a value of `FiniteElementBladeModelling`.
    - default = 'FiniteElementBladeModelling'
    """

    WholeBladeModeDampingRatios: List[StructuralModeModel] = Field(alias="WholeBladeModeDampingRatios", default_factory=list)
    r"""
    List of known whole-blade mode damping ratios. The whole-blade damping ratios will be converted into finite element degrees of freedom by Bladed. If the list is incomplete, meaning it lacks damping ratios for all modes, Bladed will assign frequency-proportional damping based on the damping ratio of the highest defined mode. The list must contain at least one entry.
    """

    _relative_schema_path: str = 'Components/Blade/BladeModelling/FiniteElementBladeModelling.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['WholeBladeModeDampingRatios',]), 'BladeModellingType').merge(BladeModelling._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FiniteElementBladeModelling.model_rebuild()
