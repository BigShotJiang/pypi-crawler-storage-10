# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.timed_event import TimedEvent
from dnv_bladed_models.timed_event import TimedEvent as TimedEventModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Fault(TimedEvent, ABC):
    r"""
    A fault which may occur during the simulation.  These can either be timed events, or based on a set of conditions which may or may not occur.
    
    Attributes
    ----------
    OnComponentInAssembly : str, regex=^Assembly.(.+)$
        A qualified, dot-separated path to a component in the assembly tree to which this applies.  i.e. `Assembly.<name1>.<name2>`
    
    Notes
    -----
    
    """

    OnComponentInAssembly: str = Field(alias="@OnComponentInAssembly", default=None, pattern='^Assembly.(.+)$')
    r"""
    A qualified, dot-separated path to a component in the assembly tree to which this applies.  i.e. `Assembly.<name1>.<name2>`
    - regex = ^Assembly.(.+)$
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(TimedEvent._type_info)

Fault.model_rebuild()
