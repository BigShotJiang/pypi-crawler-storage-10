# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.initial_position import InitialPosition
from dnv_bladed_models.initial_position import InitialPosition as InitialPositionModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class InitialFloatingPosition(InitialPosition):
    r"""
    Initial mooring position.  This can be provided where the equilibrium position of a floating position is time-consuming to calculate.
    
    Not supported yet.
    
    Attributes
    ----------
    InitialConditionType : Literal['InitialFloatingPosition'], default='InitialFloatingPosition', Not supported yet
        Defines the specific type of InitialCondition model in use.  For a `InitialFloatingPosition` object, this must always be set to a value of `InitialFloatingPosition`.
    
    PositionOfOrigin : Vector3D
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    InitialConditionType: Literal['InitialFloatingPosition'] = Field(alias="InitialConditionType", default='InitialFloatingPosition', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of InitialCondition model in use.  For a `InitialFloatingPosition` object, this must always be set to a value of `InitialFloatingPosition`.

    *Not supported yet*

    - default = 'InitialFloatingPosition'
    """

    PositionOfOrigin: Vector3DModel = Field(alias="PositionOfOrigin", default=None)
    r"""
    """

    _relative_schema_path: str = 'TimeDomainSimulation/InitialCondition/InitialFloatingPosition.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(InitialPosition._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


InitialFloatingPosition.model_rebuild()
