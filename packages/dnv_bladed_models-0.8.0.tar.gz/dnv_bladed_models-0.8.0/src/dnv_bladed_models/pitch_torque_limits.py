# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.pitch_position_vs_minimum_and_maximum_moment import PitchPositionVsMinimumAndMaximumMoment
from dnv_bladed_models.pitch_position_vs_minimum_and_maximum_moment import PitchPositionVsMinimumAndMaximumMoment as PitchPositionVsMinimumAndMaximumMomentModel
from dnv_bladed_models.pitch_rate_vs_minimum_and_maximum_moment import PitchRateVsMinimumAndMaximumMoment
from dnv_bladed_models.pitch_rate_vs_minimum_and_maximum_moment import PitchRateVsMinimumAndMaximumMoment as PitchRateVsMinimumAndMaximumMomentModel
from dnv_bladed_models.pitch_torque_minimum_maximum import PitchTorqueMinimumMaximum
from dnv_bladed_models.pitch_torque_minimum_maximum import PitchTorqueMinimumMaximum as PitchTorqueMinimumMaximumModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchTorqueLimits(BladedModel):
    r"""
    The limits on the torque produced by the rotary drive.
    
    Attributes
    ----------
    Limits : PitchTorqueMinimumMaximum
    
    PositionVsLimits : List[PitchPositionVsMinimumAndMaximumMoment]
        The limits on the torque of the rotary drive as they vary with position.
    
    RateVsLimits : List[PitchRateVsMinimumAndMaximumMoment]
        The limits on the torque of the rotary drive as they vary with the angular velocity.
    
    Notes
    -----
    
    """

    Limits: PitchTorqueMinimumMaximumModel = Field(alias="Limits", default=None)
    r"""
    """

    PositionVsLimits: List[PitchPositionVsMinimumAndMaximumMomentModel] = Field(alias="PositionVsLimits", default_factory=list)
    r"""
    The limits on the torque of the rotary drive as they vary with position.
    """

    RateVsLimits: List[PitchRateVsMinimumAndMaximumMomentModel] = Field(alias="RateVsLimits", default_factory=list)
    r"""
    The limits on the torque of the rotary drive as they vary with the angular velocity.
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/PitchTorqueLimits/PitchTorqueLimits.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['PositionVsLimits','RateVsLimits',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchTorqueLimits.model_rebuild()
