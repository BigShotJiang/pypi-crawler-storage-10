# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladeElementTheoryCorrections(BladedModel):
    r"""
    Properties related to the blade element aspects of the Blade Element Momentum model.
    
    Attributes
    ----------
    UsePrandtlCorrectionForTipLoss : bool, default=True
        If true, a Prandtl correction for tip loss effects will be applied.
    
    UsePrandtlCorrectionForRootLoss : bool, default=False
        If true, a Prandtl correction for hub loss effects will be applied.
    
    UseDragInInduction : bool, default=True
        If true, the drag coefficient will be included in the induction calculations. This mainly influences the BEM solution near the root of the blade, where the drag force is significant.
    
    Notes
    -----
    
    """

    UsePrandtlCorrectionForTipLoss: bool = Field(alias="UsePrandtlCorrectionForTipLoss", default=None)
    r"""
    If true, a Prandtl correction for tip loss effects will be applied.
    - default = True
    """

    UsePrandtlCorrectionForRootLoss: bool = Field(alias="UsePrandtlCorrectionForRootLoss", default=None)
    r"""
    If true, a Prandtl correction for hub loss effects will be applied.
    - default = False
    """

    UseDragInInduction: bool = Field(alias="UseDragInInduction", default=None)
    r"""
    If true, the drag coefficient will be included in the induction calculations. This mainly influences the BEM solution near the root of the blade, where the drag force is significant.
    - default = True
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/BladeElementTheoryCorrections/BladeElementTheoryCorrections.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladeElementTheoryCorrections.model_rebuild()
