# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.fault import Fault
from dnv_bladed_models.fault import Fault as FaultModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchFault(Fault, ABC):
    r"""
    A fault in a single pitch system occuring at a specified time.
    
    Attributes
    ----------
    IsAmenableToSafetySystem : bool
        If true, the safety system is able to intervene and take any specified action.  If false, the safety system will not respond to this event.
    
    Notes
    -----
    
    """

    IsAmenableToSafetySystem: bool = Field(alias="IsAmenableToSafetySystem", default=None)
    r"""
    If true, the safety system is able to intervene and take any specified action.  If false, the safety system will not respond to this event.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Fault._type_info)

PitchFault.model_rebuild()
