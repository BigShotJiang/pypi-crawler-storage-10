# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.initial_position import InitialPosition
from dnv_bladed_models.initial_position import InitialPosition as InitialPositionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class InitialAzimuthPosition(InitialPosition):
    r"""
    The initial position of a rotor.  If there is only one rotor, then AssemblyReference can be omitted.
    
    Attributes
    ----------
    InitialConditionType : Literal['InitialAzimuthPosition'], default='InitialAzimuthPosition'
        Defines the specific type of InitialCondition model in use.  For a `InitialAzimuthPosition` object, this must always be set to a value of `InitialAzimuthPosition`.
    
    AngleOfFirstBladeToVertical : float
        The starting azimuth angle of the specified rotor or turbine.
    
    Notes
    -----
    
    """

    InitialConditionType: Literal['InitialAzimuthPosition'] = Field(alias="InitialConditionType", default='InitialAzimuthPosition', frozen=True) # type: ignore
    r"""
    Defines the specific type of InitialCondition model in use.  For a `InitialAzimuthPosition` object, this must always be set to a value of `InitialAzimuthPosition`.
    - default = 'InitialAzimuthPosition'
    """

    AngleOfFirstBladeToVertical: float = Field(alias="AngleOfFirstBladeToVertical", default=None)
    r"""
    The starting azimuth angle of the specified rotor or turbine.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/InitialCondition/InitialAzimuthPosition.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(InitialPosition._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


InitialAzimuthPosition.model_rebuild()
