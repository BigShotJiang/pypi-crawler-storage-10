# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class MountingPoints(BladedModel):
    r"""
    The properties defining where the blades or pitch systems attach to the hub.  All of the angles described are for INSIDE of the pitch bearing - the blade has its own values for sweep and cone outside of the pitch bearing.
    
    Attributes
    ----------
    RadiusOfBladeConnection : float
        The radius (measured from the hub's axis of rotation) that the extension piece terminates and the blade will commence.
    
    ConingAngle : float, default=0
        The coning angle of the hub itself.  A positive value for ConingAngle will result in the blade tips moving away from the nacelle, whether an upwind or downwind turbine.
    
    SetAngle : float, default=0
        The angle at which the pitch bearings or blades are mounted onto the pitch bearing or hub.  When the set angle is 0, the blade root Y-axis (which is broadly aligned with the chord-line) will lie in the plane of the rotor (when cone angle is ignored).  More positive values of set angle push the leading edge further upstream.
    
    Notes
    -----
    
    """

    RadiusOfBladeConnection: float = Field(alias="RadiusOfBladeConnection", default=None)
    r"""
    The radius (measured from the hub's axis of rotation) that the extension piece terminates and the blade will commence.
    """

    ConingAngle: float = Field(alias="ConingAngle", default=None)
    r"""
    The coning angle of the hub itself.  A positive value for ConingAngle will result in the blade tips moving away from the nacelle, whether an upwind or downwind turbine.
    - default = 0
    """

    SetAngle: float = Field(alias="SetAngle", default=None)
    r"""
    The angle at which the pitch bearings or blades are mounted onto the pitch bearing or hub.  When the set angle is 0, the blade root Y-axis (which is broadly aligned with the chord-line) will lie in the plane of the rotor (when cone angle is ignored).  More positive values of set angle push the leading edge further upstream.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Hub/MountingPoints/MountingPoints.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


MountingPoints.model_rebuild()
