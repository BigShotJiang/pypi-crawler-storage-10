# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.outputs import Outputs
from dnv_bladed_models.outputs import Outputs as OutputsModel
from dnv_bladed_models.selected_component_output_group import SelectedComponentOutputGroup
from dnv_bladed_models.selected_component_output_group import SelectedComponentOutputGroup as SelectedComponentOutputGroupModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SteadyCalculationWithComponentOutputs(Outputs):
    r"""
    
    
    Attributes
    ----------
    SelectedComponentOutputGroups : List[SelectedComponentOutputGroup], Not supported yet
        List of SelectedComponentOutputGroup
    
    Notes
    -----
    
    """

    SelectedComponentOutputGroups: List[SelectedComponentOutputGroupModel] = Field(alias="SelectedComponentOutputGroups", default_factory=list) # Not supported yet
    r"""
    List of SelectedComponentOutputGroup

    *Not supported yet*

    """

    _relative_schema_path: str = 'SteadyCalculation/SteadyCalculationWithComponentOutputs/SteadyCalculationWithComponentOutputs.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['SelectedComponentOutputGroups',]), None).merge(Outputs._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SteadyCalculationWithComponentOutputs.model_rebuild()
