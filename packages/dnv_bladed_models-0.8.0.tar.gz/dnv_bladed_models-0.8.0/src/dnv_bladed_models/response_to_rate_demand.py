# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.pitch_acceleration_limits import PitchAccelerationLimits
from dnv_bladed_models.pitch_acceleration_limits import PitchAccelerationLimits as PitchAccelerationLimitsModel
from dnv_bladed_models.pitch_rate_limits import PitchRateLimits
from dnv_bladed_models.pitch_rate_limits import PitchRateLimits as PitchRateLimitsModel
from .schema_helper import SchemaHelper
from .base_entity import *


class ResponseToRateDemand_ResponseToRateDemandTypeEnum(str, Enum):
    FIRST_ORDER_RATE_RESPONSE = "FirstOrderRateResponse"
    IMMEDIATE_RATE_RESPONSE = "ImmediateRateResponse"
    PROPORTIONAL_INTEGRAL_DERIVIATIVE_FOR_RATE = "ProportionalIntegralDeriviativeForRate"
    SECOND_ORDER_RATE_RESPONSE = "SecondOrderRateResponse"
    INSERT = "Insert"



class ResponseToRateDemand(BladedModel, ABC):
    r"""
    The common properties of all control responses.
    
    Attributes
    ----------
    ResponseToRateDemandType : ResponseToRateDemand_ResponseToRateDemandTypeEnum
        Defines the specific type of model in use.
    
    RateLimits : PitchRateLimits
    
    AccelerationLimits : PitchAccelerationLimits
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - FirstOrderRateResponse
        - ImmediateRateResponse
        - ResponseToRateDemandInsert
        - ProportionalIntegralDeriviativeForRate
        - SecondOrderRateResponse
    
    """

    ResponseToRateDemandType: ResponseToRateDemand_ResponseToRateDemandTypeEnum = Field(alias="ResponseToRateDemandType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    RateLimits: PitchRateLimitsModel = Field(alias="RateLimits", default=None)
    r"""
    """

    AccelerationLimits: PitchAccelerationLimitsModel = Field(alias="AccelerationLimits", default=None)
    r"""
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

ResponseToRateDemand.model_rebuild()
