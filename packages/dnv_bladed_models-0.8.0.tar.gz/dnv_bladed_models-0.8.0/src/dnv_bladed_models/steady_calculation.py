# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class SteadyCalculation_SteadyCalculationTypeEnum(str, Enum):
    AERODYNAMIC_INFORMATION = "AerodynamicInformation"
    CAMPBELL_DIAGRAM = "CampbellDiagram"
    MODAL_ANALYSIS = "ModalAnalysis"
    MODEL_LINEARISATION = "ModelLinearisation"
    PERFORMANCE_COEFFICIENTS = "PerformanceCoefficients"
    STEADY_OPERATIONAL_LOADS = "SteadyOperationalLoads"
    STEADY_PARKED_LOADS = "SteadyParkedLoads"
    STEADY_POWER_CURVE = "SteadyPowerCurve"
    INSERT = "Insert"



class SteadyCalculation(BladedModel, ABC):
    r"""
    The common properties of the steady calculations in Bladed.
    
    Attributes
    ----------
    SteadyCalculationType : SteadyCalculation_SteadyCalculationTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - AerodynamicInformationCalculation
        - CampbellDiagram
        - SteadyCalculationInsert
        - ModalAnalysisCalculation
        - ModelLinearisation
        - PerformanceCoefficientsCalculation
        - SteadyOperationalLoadsCalculation
        - SteadyParkedLoadsCalculation
        - SteadyPowerCurveCalculation
    
    """

    SteadyCalculationType: SteadyCalculation_SteadyCalculationTypeEnum = Field(alias="SteadyCalculationType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

SteadyCalculation.model_rebuild()
