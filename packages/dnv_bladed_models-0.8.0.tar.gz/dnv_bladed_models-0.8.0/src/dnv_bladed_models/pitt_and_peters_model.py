# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_wake import DynamicWake
from dnv_bladed_models.dynamic_wake import DynamicWake as DynamicWakeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PittAndPetersModel(DynamicWake):
    r"""
    The Pitt and Peters dynamic wake model.
    
    Attributes
    ----------
    DynamicWakeType : Literal['PittAndPetersModel'], default='PittAndPetersModel'
        Defines the specific type of DynamicWake model in use.  For a `PittAndPetersModel` object, this must always be set to a value of `PittAndPetersModel`.
    
    Notes
    -----
    
    """

    DynamicWakeType: Literal['PittAndPetersModel'] = Field(alias="DynamicWakeType", default='PittAndPetersModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicWake model in use.  For a `PittAndPetersModel` object, this must always be set to a value of `PittAndPetersModel`.
    - default = 'PittAndPetersModel'
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/MomentumTheoryCorrections/DynamicWake/PittAndPetersModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicWakeType').merge(DynamicWake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PittAndPetersModel.model_rebuild()
