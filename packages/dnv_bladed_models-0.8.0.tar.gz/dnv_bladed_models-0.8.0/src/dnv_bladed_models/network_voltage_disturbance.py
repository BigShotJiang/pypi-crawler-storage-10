# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.fault import Fault
from dnv_bladed_models.fault import Fault as FaultModel
from dnv_bladed_models.time_vs_voltage_change import TimeVsVoltageChange
from dnv_bladed_models.time_vs_voltage_change import TimeVsVoltageChange as TimeVsVoltageChangeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NetworkVoltageDisturbance(Fault):
    r"""
    A disturbance in the network connection where the grid's voltage fluctuates at a specified time.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['NetworkVoltageDisturbance'], default='NetworkVoltageDisturbance', Not supported yet
        Defines the specific type of Event model in use.  For a `NetworkVoltageDisturbance` object, this must always be set to a value of `NetworkVoltageDisturbance`.
    
    Filepath : str, Not supported yet
        The filepath or URI of the voltage disturbance data.
    
    TimeVsVoltageChange : List[TimeVsVoltageChange], Not supported yet
        A series of time vs voltage to apply once the specified time is reached.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['NetworkVoltageDisturbance'] = Field(alias="EventType", default='NetworkVoltageDisturbance', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `NetworkVoltageDisturbance` object, this must always be set to a value of `NetworkVoltageDisturbance`.

    *Not supported yet*

    - default = 'NetworkVoltageDisturbance'
    """

    Filepath: str = Field(alias="Filepath", default=None) # Not supported yet
    r"""
    The filepath or URI of the voltage disturbance data.

    *Not supported yet*

    """

    TimeVsVoltageChange: List[TimeVsVoltageChangeModel] = Field(alias="TimeVsVoltageChange", default_factory=list) # Not supported yet
    r"""
    A series of time vs voltage to apply once the specified time is reached.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/NetworkVoltageDisturbance.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['TimeVsVoltageChange',]), 'EventType').merge(Fault._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NetworkVoltageDisturbance.model_rebuild()
