# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.current_horizontal_shear_variation import CurrentHorizontalShearVariation
from dnv_bladed_models.current_horizontal_shear_variation import CurrentHorizontalShearVariation as CurrentHorizontalShearVariationModel
from .schema_helper import SchemaHelper
from .base_entity import *


class PresetCurrentHorizontalShearTransient_VariationShapeEnum(str, Enum):
    FULL = "FULL"
    HALF = "HALF"
    IEC_2 = "IEC-2"



class PresetCurrentHorizontalShearTransient(CurrentHorizontalShearVariation):
    r"""
    A preset transient in the current's horizontal shear.
    
    Not supported yet.
    
    Attributes
    ----------
    HorizontalShearVariationType : Literal['PresetTransient'], default='PresetTransient', Not supported yet
        Defines the specific type of HorizontalShearVariation model in use.  For a `PresetTransient` object, this must always be set to a value of `PresetTransient`.
    
    HorizontalShearAtStart : float, Not supported yet
        The current's horizontal shear at the start of the simulation up to the beginning of the transient.  For a full cycle this will also be the value after the transient has completed.
    
    AmplitudeOfVariation : float, Not supported yet
        The maximum amplitude of the variation.
    
    StartTime : float, Not supported yet
        The time into the simulation at which to start the transient (excluding the lead-in time).
    
    DurationOfVariation : float, Not supported yet
        The time taken to complete the transient, whether half-cycle or full-cycle.
    
    VariationShape : PresetCurrentHorizontalShearTransient_VariationShapeEnum, Not supported yet
        The shape of the transient.  This can either be a half-cycle (where the current's shear remains at the initial current's shear plus the amplitude after the transient has been completed) or a full-cycle (where the current's shear returns to its original value).
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    HorizontalShearVariationType: Literal['PresetTransient'] = Field(alias="HorizontalShearVariationType", default='PresetTransient', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of HorizontalShearVariation model in use.  For a `PresetTransient` object, this must always be set to a value of `PresetTransient`.

    *Not supported yet*

    - default = 'PresetTransient'
    """

    HorizontalShearAtStart: float = Field(alias="HorizontalShearAtStart", default=None) # Not supported yet
    r"""
    The current's horizontal shear at the start of the simulation up to the beginning of the transient.  For a full cycle this will also be the value after the transient has completed.

    *Not supported yet*

    """

    AmplitudeOfVariation: float = Field(alias="AmplitudeOfVariation", default=None) # Not supported yet
    r"""
    The maximum amplitude of the variation.

    *Not supported yet*

    """

    StartTime: float = Field(alias="StartTime", default=None) # Not supported yet
    r"""
    The time into the simulation at which to start the transient (excluding the lead-in time).

    *Not supported yet*

    """

    DurationOfVariation: float = Field(alias="DurationOfVariation", default=None) # Not supported yet
    r"""
    The time taken to complete the transient, whether half-cycle or full-cycle.

    *Not supported yet*

    """

    VariationShape: PresetCurrentHorizontalShearTransient_VariationShapeEnum = Field(alias="VariationShape", default=None) # Not supported yet
    r"""
    The shape of the transient.  This can either be a half-cycle (where the current's shear remains at the initial current's shear plus the amplitude after the transient has been completed) or a full-cycle (where the current's shear returns to its original value).

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/CurrentHorizontalShearVariation/PresetCurrentHorizontalShearTransient.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'HorizontalShearVariationType').merge(CurrentHorizontalShearVariation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PresetCurrentHorizontalShearTransient.model_rebuild()
