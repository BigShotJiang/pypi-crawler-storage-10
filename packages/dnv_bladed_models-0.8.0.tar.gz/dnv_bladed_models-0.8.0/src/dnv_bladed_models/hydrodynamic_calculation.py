# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class HydrodynamicCalculation_HydrostaticsMorisonMethodEnum(str, Enum):
    VARIABLE_INTERFACE = "VARIABLE_INTERFACE"
    EQUALLY_SPACED_INTERFACE = "EQUALLY_SPACED_INTERFACE"
    NOT_USED = "NOT_USED"



class HydrodynamicCalculation(BladedModel):
    r"""
    Settings for the hydrodynamic modelling within Bladed.  Note that many hydrodynamic modelling options are specific to the components.  These options can be found within the componentss definitions themselves.
    
    Not supported yet.
    
    Attributes
    ----------
    MinimumExcitationForceTimeStep : float, default=0.1, Not supported yet
        The timestep for calculating excitation forces for BEM bodies.  If omitted, the excitation force will be calculated on every integrator timestep.
    
    HydrostaticsMorisonMethod : HydrodynamicCalculation_HydrostaticsMorisonMethodEnum, default='NOT_USED', Not supported yet
        The method to use for the hydrostatics Morison calculations.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    MinimumExcitationForceTimeStep: float = Field(alias="MinimumExcitationForceTimeStep", default=None) # Not supported yet
    r"""
    The timestep for calculating excitation forces for BEM bodies.  If omitted, the excitation force will be calculated on every integrator timestep.

    *Not supported yet*

    - default = 0.1
    """

    HydrostaticsMorisonMethod: HydrodynamicCalculation_HydrostaticsMorisonMethodEnum = Field(alias="HydrostaticsMorisonMethod", default=None) # Not supported yet
    r"""
    The method to use for the hydrostatics Morison calculations.

    *Not supported yet*

    - default = 'NOT_USED'
    """

    _relative_schema_path: str = 'Settings/HydrodynamicCalculation/HydrodynamicCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


HydrodynamicCalculation.model_rebuild()
