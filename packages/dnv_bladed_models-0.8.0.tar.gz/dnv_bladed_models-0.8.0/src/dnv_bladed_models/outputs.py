# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Outputs_FileFormatEnum(str, Enum):
    BINARY = "BINARY"
    ASCII = "ASCII"



class Outputs(BladedModel, ABC):
    r"""
    Definition outputs to write for this analysis.
    
    Attributes
    ----------
    OutputDirectory : str
        The output directory for results files.
    
    FileStem : str
        A name for the analysis that will be used as the name of all the output files.
    
    FileFormat : Outputs_FileFormatEnum, default='BINARY'
        The output format, whether it is ASCII or binary.
    
    OutputDongleActivity : bool, default=False
        If true, the dongle activity will be logged.
    
    Notes
    -----
    
    """

    OutputDirectory: str = Field(alias="OutputDirectory", default=None)
    r"""
    The output directory for results files.
    """

    FileStem: str = Field(alias="FileStem", default=None)
    r"""
    A name for the analysis that will be used as the name of all the output files.
    """

    FileFormat: Outputs_FileFormatEnum = Field(alias="FileFormat", default=None)
    r"""
    The output format, whether it is ASCII or binary.
    - default = 'BINARY'
    """

    OutputDongleActivity: bool = Field(alias="OutputDongleActivity", default=None)
    r"""
    If true, the dongle activity will be logged.
    - default = False
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

Outputs.model_rebuild()
