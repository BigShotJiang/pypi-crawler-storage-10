# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.controlled_operation import ControlledOperation
from dnv_bladed_models.controlled_operation import ControlledOperation as ControlledOperationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ControlledStop(ControlledOperation, ABC):
    r"""
    A stop operation  occuring at a specified time.
    
    Attributes
    ----------
    ExtraSimulationTimeAfterFullStop : float
        The time after all rotors come to a complete stop at which to terminate the simulation.  If this occurs after the simulation duration has completed, it will have no effect.  This parameter is to allow a simulation to stop earlier if all the required data has been collected.
    
    Notes
    -----
    
    """

    ExtraSimulationTimeAfterFullStop: float = Field(alias="ExtraSimulationTimeAfterFullStop", default=None)
    r"""
    The time after all rotors come to a complete stop at which to terminate the simulation.  If this occurs after the simulation duration has completed, it will have no effect.  This parameter is to allow a simulation to stop earlier if all the required data has been collected.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(ControlledOperation._type_info)

ControlledStop.model_rebuild()
