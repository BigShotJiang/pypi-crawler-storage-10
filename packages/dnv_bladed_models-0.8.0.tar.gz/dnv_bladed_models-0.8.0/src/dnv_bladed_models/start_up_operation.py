# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.controlled_operation import ControlledOperation
from dnv_bladed_models.controlled_operation import ControlledOperation as ControlledOperationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class StartUpOperation(ControlledOperation):
    r"""
    A request for the controller to start the turbine at a specified time in the simulation.  The start up will be performed by the controller.
    
    Attributes
    ----------
    EventType : Literal['StartUpOperation'], default='StartUpOperation'
        Defines the specific type of Event model in use.  For a `StartUpOperation` object, this must always be set to a value of `StartUpOperation`.
    
    Notes
    -----
    
    """

    EventType: Literal['StartUpOperation'] = Field(alias="EventType", default='StartUpOperation', frozen=True) # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `StartUpOperation` object, this must always be set to a value of `StartUpOperation`.
    - default = 'StartUpOperation'
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/StartUpOperation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(ControlledOperation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


StartUpOperation.model_rebuild()
