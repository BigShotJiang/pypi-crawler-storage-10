# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class InitialCondition_InitialConditionTypeEnum(str, Enum):
    GL2010_ICING = "GL2010Icing"
    IEC4_ICING = "IEC4Icing"
    INITIAL_AZIMUTH_POSITION = "InitialAzimuthPosition"
    INITIAL_FLOATING_POSITION = "InitialFloatingPosition"
    INITIAL_PITCH_POSITION = "InitialPitchPosition"
    INITIAL_ROTOR_SPEED = "InitialRotorSpeed"
    INITIAL_YAW_ANGLE = "InitialYawAngle"
    ROTOR_IDLING = "RotorIdling"
    ROTOR_IN_POWER_PRODUCTION = "RotorInPowerProduction"
    ROTOR_PARKED = "RotorParked"
    INSERT = "Insert"



class InitialCondition(BladedModel, ABC):
    r"""
    A condition of the turbine or a component at the beginning of the simulation.  This may change during the simulation.
    
    Attributes
    ----------
    InitialConditionType : InitialCondition_InitialConditionTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - GL2010Icing
        - IEC4Icing
        - InitialAzimuthPosition
        - InitialFloatingPosition
        - InitialPitchPosition
        - InitialRotorSpeed
        - InitialYawAngle
        - InitialConditionInsert
        - RotorIdlingControlState
        - RotorInPowerProduction
        - RotorParkedControlState
    
    """

    InitialConditionType: InitialCondition_InitialConditionTypeEnum = Field(alias="InitialConditionType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

InitialCondition.model_rebuild()
