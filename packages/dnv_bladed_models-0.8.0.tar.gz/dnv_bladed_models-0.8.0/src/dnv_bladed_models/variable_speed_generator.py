# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.generator import Generator
from dnv_bladed_models.generator import Generator as GeneratorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class VariableSpeedGenerator(Generator):
    r"""
    A variable speed generator where the torque is actively controlled by the controller.
    
    Attributes
    ----------
    ComponentType : Literal['VariableSpeedGenerator'], default='VariableSpeedGenerator'
        Defines the specific type of Component model in use.  For a `VariableSpeedGenerator` object, this must always be set to a value of `VariableSpeedGenerator`.
    
    GeneratorTimeConstant : float, default=0
        Time constant of generator torque response to demanded torque
    
    PowerFactor : float, default=1
        Turbine power factor
    
    MaximumTorqueDemand : float
        The upper limit for the torque demand.
    
    MinimumTorqueDemand : float, default=0
        The lower limit for the torque demand.
    
    Notes
    -----
    
    """

    ComponentType: Literal['VariableSpeedGenerator'] = Field(alias="ComponentType", default='VariableSpeedGenerator', frozen=True) # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `VariableSpeedGenerator` object, this must always be set to a value of `VariableSpeedGenerator`.
    - default = 'VariableSpeedGenerator'
    """

    GeneratorTimeConstant: float = Field(alias="GeneratorTimeConstant", default=None)
    r"""
    Time constant of generator torque response to demanded torque
    - default = 0
    """

    PowerFactor: float = Field(alias="PowerFactor", default=None)
    r"""
    Turbine power factor
    - default = 1
    """

    MaximumTorqueDemand: float = Field(alias="MaximumTorqueDemand", default=None)
    r"""
    The upper limit for the torque demand.
    """

    MinimumTorqueDemand: float = Field(alias="MinimumTorqueDemand", default=None)
    r"""
    The lower limit for the torque demand.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Generator/VariableSpeedGenerator.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(Generator._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


VariableSpeedGenerator.model_rebuild()
