# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.wind import Wind
from dnv_bladed_models.wind import Wind as WindModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ExternalFlowSourceForWind(Wind):
    r"""
    The definition of a wind field that is provided by an external library - a dynamic link library (dll) on Windows, or a shared object (so) on Linux.
    
    Attributes
    ----------
    WindType : Literal['ExternalFlowSourceForWind'], default='ExternalFlowSourceForWind'
        Defines the specific type of Wind model in use.  For a `ExternalFlowSourceForWind` object, this must always be set to a value of `ExternalFlowSourceForWind`.
    
    LibraryFilepath : str
        The filepath of the external library object.
    
    ParametersAsString : str
        A string that will be passed to the external wind module.
    
    ParametersAsJson : Dict[str, Any]
        A JSON object that will be serialised as a string and passed to the external wind module.
    
    Notes
    -----
    
    """

    WindType: Literal['ExternalFlowSourceForWind'] = Field(alias="WindType", default='ExternalFlowSourceForWind', frozen=True) # type: ignore
    r"""
    Defines the specific type of Wind model in use.  For a `ExternalFlowSourceForWind` object, this must always be set to a value of `ExternalFlowSourceForWind`.
    - default = 'ExternalFlowSourceForWind'
    """

    LibraryFilepath: str = Field(alias="LibraryFilepath", default=None)
    r"""
    The filepath of the external library object.
    """

    ParametersAsString: str = Field(alias="ParametersAsString", default=None)
    r"""
    A string that will be passed to the external wind module.
    """

    ParametersAsJson: Dict[str, Any] = Field(alias="ParametersAsJson", default=None)
    r"""
    A JSON object that will be serialised as a string and passed to the external wind module.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/ExternalFlowSourceForWind.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'WindType').merge(Wind._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ExternalFlowSourceForWind.model_rebuild()
