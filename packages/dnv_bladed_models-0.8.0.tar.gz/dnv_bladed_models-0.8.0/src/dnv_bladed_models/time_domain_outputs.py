# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.outputs import Outputs
from dnv_bladed_models.outputs import Outputs as OutputsModel
from dnv_bladed_models.selected_component_output_group import SelectedComponentOutputGroup
from dnv_bladed_models.selected_component_output_group import SelectedComponentOutputGroup as SelectedComponentOutputGroupModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TimeDomainOutputs(Outputs):
    r"""
    The definition outputs to write for this simulation.
    
    Attributes
    ----------
    TimeStepForOutputs : float
        The output time step for the simulation.
    
    LengthOfOutputBuffer : float
        The length of time to buffer the output logs.
    
    OutputSummaryInformation : bool, default=True, Not supported yet
        If true, the summary information output group will be created.
    
    OutputExternalControllers : bool, default=True, Not supported yet
        If true, the controller output group will be created.
    
    OutputBuoyancyInformation : bool, default=False, Not supported yet
        If true, the buoyancy output group will be created.
    
    OutputFiniteElementMatrices : bool, default=False, Not supported yet
        If true, the finite element output group will be created, providing far more detail about the finite element matrices.
    
    OutputSignalProperties : bool, default=False, Not supported yet
        If true, the signal properties output group will be created.  This records the properties provided to the controller, with and without noise and other distortions.
    
    OutputWakePropagation : bool, default=False, Not supported yet
        If true, the eddy viscosity propagation of the wake is output as a 2D table of relative velocity against radial position and distance traveled to a \".wake\" file in the output folder.
    
    OutputSoftwarePerformance : bool, default=False, Not supported yet
        If true, the software performance output group will be created.
    
    OutputStateInformation : bool, default=False, Not supported yet
        If true, the integrator state output group will be created.  This can be used to help understand how efficiently the integrator is coping with the simulation.
    
    OutputExternalControllerExchangeObject : bool, default=False, Not supported yet
        If true, this will output all of the values contained in the external controller interface before and after each external controller call.  This is intended to assist debugging external controllers.
    
    OutputExternalControllerLegacySwapArray : bool, default=False, Not supported yet
        If true, the contents of the swap array passed to a legacy controller will be logged.  This is used only when trying to debug legacy controllers, and will not produce useful results if there is more than one legacy controller being run.
    
    SelectedComponentOutputGroups : List[SelectedComponentOutputGroup], Not supported yet
        A list of references to the OutputGroup of specific components to output.  This allows the outputs of individual components to be switched off, or chosen from an available list of output regimes.  If a component is not mentioned, it will produce outputs according to its default output group, if there is one available.
    
    Notes
    -----
    
    """

    TimeStepForOutputs: float = Field(alias="TimeStepForOutputs", default=None)
    r"""
    The output time step for the simulation.
    """

    LengthOfOutputBuffer: float = Field(alias="LengthOfOutputBuffer", default=None)
    r"""
    The length of time to buffer the output logs.
    """

    OutputSummaryInformation: bool = Field(alias="OutputSummaryInformation", default=None) # Not supported yet
    r"""
    If true, the summary information output group will be created.

    *Not supported yet*

    - default = True
    """

    OutputExternalControllers: bool = Field(alias="OutputExternalControllers", default=None) # Not supported yet
    r"""
    If true, the controller output group will be created.

    *Not supported yet*

    - default = True
    """

    OutputBuoyancyInformation: bool = Field(alias="OutputBuoyancyInformation", default=None) # Not supported yet
    r"""
    If true, the buoyancy output group will be created.

    *Not supported yet*

    - default = False
    """

    OutputFiniteElementMatrices: bool = Field(alias="OutputFiniteElementMatrices", default=None) # Not supported yet
    r"""
    If true, the finite element output group will be created, providing far more detail about the finite element matrices.

    *Not supported yet*

    - default = False
    """

    OutputSignalProperties: bool = Field(alias="OutputSignalProperties", default=None) # Not supported yet
    r"""
    If true, the signal properties output group will be created.  This records the properties provided to the controller, with and without noise and other distortions.

    *Not supported yet*

    - default = False
    """

    OutputWakePropagation: bool = Field(alias="OutputWakePropagation", default=None) # Not supported yet
    r"""
    If true, the eddy viscosity propagation of the wake is output as a 2D table of relative velocity against radial position and distance traveled to a \".wake\" file in the output folder.

    *Not supported yet*

    - default = False
    """

    OutputSoftwarePerformance: bool = Field(alias="OutputSoftwarePerformance", default=None) # Not supported yet
    r"""
    If true, the software performance output group will be created.

    *Not supported yet*

    - default = False
    """

    OutputStateInformation: bool = Field(alias="OutputStateInformation", default=None) # Not supported yet
    r"""
    If true, the integrator state output group will be created.  This can be used to help understand how efficiently the integrator is coping with the simulation.

    *Not supported yet*

    - default = False
    """

    OutputExternalControllerExchangeObject: bool = Field(alias="OutputExternalControllerExchangeObject", default=None) # Not supported yet
    r"""
    If true, this will output all of the values contained in the external controller interface before and after each external controller call.  This is intended to assist debugging external controllers.

    *Not supported yet*

    - default = False
    """

    OutputExternalControllerLegacySwapArray: bool = Field(alias="OutputExternalControllerLegacySwapArray", default=None) # Not supported yet
    r"""
    If true, the contents of the swap array passed to a legacy controller will be logged.  This is used only when trying to debug legacy controllers, and will not produce useful results if there is more than one legacy controller being run.

    *Not supported yet*

    - default = False
    """

    SelectedComponentOutputGroups: List[SelectedComponentOutputGroupModel] = Field(alias="SelectedComponentOutputGroups", default_factory=list) # Not supported yet
    r"""
    A list of references to the OutputGroup of specific components to output.  This allows the outputs of individual components to be switched off, or chosen from an available list of output regimes.  If a component is not mentioned, it will produce outputs according to its default output group, if there is one available.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/TimeDomainOutputs/TimeDomainOutputs.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['SelectedComponentOutputGroups',]), None).merge(Outputs._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TimeDomainOutputs.model_rebuild()
