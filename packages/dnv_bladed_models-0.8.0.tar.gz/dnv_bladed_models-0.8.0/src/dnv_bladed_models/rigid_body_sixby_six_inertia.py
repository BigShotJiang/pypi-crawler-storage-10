# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.rigid_body_inertia import RigidBodyInertia
from dnv_bladed_models.rigid_body_inertia import RigidBodyInertia as RigidBodyInertiaModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RigidBodySixbySixInertia(RigidBodyInertia):
    r"""
    An inertia component to the assembly tree, defined via a six-by-six matrix.
    
    Attributes
    ----------
    ComponentType : Literal['RigidBodySixbySixInertia'], default='RigidBodySixbySixInertia'
        Defines the specific type of Component model in use.  For a `RigidBodySixbySixInertia` object, this must always be set to a value of `RigidBodySixbySixInertia`.
    
    Inertia : List[List[float]]
        A 6x6 matrix of the linear and rotational inertias of an object.
    
    Notes
    -----
    
    """

    ComponentType: Literal['RigidBodySixbySixInertia'] = Field(alias="ComponentType", default='RigidBodySixbySixInertia', frozen=True) # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `RigidBodySixbySixInertia` object, this must always be set to a value of `RigidBodySixbySixInertia`.
    - default = 'RigidBodySixbySixInertia'
    """

    Inertia: List[List[float]] = Field(alias="Inertia", default_factory=list)
    r"""
    A 6x6 matrix of the linear and rotational inertias of an object.
    """

    _relative_schema_path: str = 'Components/RigidBodySixbySixInertia.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['Inertia',]), 'ComponentType').merge(RigidBodyInertia._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RigidBodySixbySixInertia.model_rebuild()
