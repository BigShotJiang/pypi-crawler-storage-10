# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.blade_outputs_for_location import BladeOutputsForLocation
from dnv_bladed_models.blade_outputs_for_location import BladeOutputsForLocation as BladeOutputsForLocationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladeOutputsForCrossSection(BladeOutputsForLocation):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    BladeOutputsForLocationType : Literal['OutputsForCrossSection'], default='OutputsForCrossSection', Not supported yet
        Defines the specific type of BladeOutputsForLocation model in use.  For a `OutputsForCrossSection` object, this must always be set to a value of `OutputsForCrossSection`.
    
    SectionReference : str, Not supported yet
        The cross-section at which to produce the outputs for.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    BladeOutputsForLocationType: Literal['OutputsForCrossSection'] = Field(alias="BladeOutputsForLocationType", default='OutputsForCrossSection', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of BladeOutputsForLocation model in use.  For a `OutputsForCrossSection` object, this must always be set to a value of `OutputsForCrossSection`.

    *Not supported yet*

    - default = 'OutputsForCrossSection'
    """

    SectionReference: str = Field(alias="@SectionReference", default=None) # Not supported yet
    r"""
    The cross-section at which to produce the outputs for.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Blade/BladeOutputGroupLibrary/BladeOutputGroup/BladeOutputsForLocation/BladeOutputsForCrossSection.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'BladeOutputsForLocationType').merge(BladeOutputsForLocation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladeOutputsForCrossSection.model_rebuild()
