# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LoadBank(BladedModel):
    r"""
    The properties of a load bank.
    
    Attributes
    ----------
    HighSpeedShaftStiffness : float
        The stiffness of the high speed shaft. Obmiting this will be it rigid. If omitted, the shaft will be rigid.
    
    HighSpeedShaftDamping : float
        The coefficient of damping for the high speed shaft. If omitted, the shaft will be rigid.
    
    MomentOfInertiaOfMotor : float
        The inertia of the motor/actuator connected to this HSS.
    
    Notes
    -----
    
    """

    HighSpeedShaftStiffness: float = Field(alias="HighSpeedShaftStiffness", default=None)
    r"""
    The stiffness of the high speed shaft. Obmiting this will be it rigid. If omitted, the shaft will be rigid.
    """

    HighSpeedShaftDamping: float = Field(alias="HighSpeedShaftDamping", default=None)
    r"""
    The coefficient of damping for the high speed shaft. If omitted, the shaft will be rigid.
    """

    MomentOfInertiaOfMotor: float = Field(alias="MomentOfInertiaOfMotor", default=None)
    r"""
    The inertia of the motor/actuator connected to this HSS.
    """

    _relative_schema_path: str = 'Components/YawSystem/YawActuation/LoadBank/LoadBank.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LoadBank.model_rebuild()
