# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.controlled_stop import ControlledStop
from dnv_bladed_models.controlled_stop import ControlledStop as ControlledStopModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NormalStopOperation(ControlledStop):
    r"""
    A request for the controller to stop the turbine or rotor at a specified time in the simulation.  The stop will be performed by the controller.
    
    Attributes
    ----------
    EventType : Literal['NormalStopOperation'], default='NormalStopOperation'
        Defines the specific type of Event model in use.  For a `NormalStopOperation` object, this must always be set to a value of `NormalStopOperation`.
    
    Notes
    -----
    
    """

    EventType: Literal['NormalStopOperation'] = Field(alias="EventType", default='NormalStopOperation', frozen=True) # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `NormalStopOperation` object, this must always be set to a value of `NormalStopOperation`.
    - default = 'NormalStopOperation'
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/NormalStopOperation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(ControlledStop._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NormalStopOperation.model_rebuild()
