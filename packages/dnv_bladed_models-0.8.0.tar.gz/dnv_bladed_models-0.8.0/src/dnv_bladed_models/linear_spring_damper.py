# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.flexible_joint import FlexibleJoint
from dnv_bladed_models.flexible_joint import FlexibleJoint as FlexibleJointModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearSpringDamper(FlexibleJoint):
    r"""
    The definition of a linear spring damper.
    
    Attributes
    ----------
    Stiffness : float, default=0
        The stiffness of the damper.
    
    Damping : float, default=0
        The damping of the damper.
    
    Notes
    -----
    
    """

    Stiffness: float = Field(alias="Stiffness", default=None)
    r"""
    The stiffness of the damper.
    - default = 0
    """

    Damping: float = Field(alias="Damping", default=None)
    r"""
    The damping of the damper.
    - default = 0
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/LinearSpringDamper/LinearSpringDamper.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(FlexibleJoint._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LinearSpringDamper.model_rebuild()
