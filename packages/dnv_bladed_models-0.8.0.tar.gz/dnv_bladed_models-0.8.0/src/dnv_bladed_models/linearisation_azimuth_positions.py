# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearisationAzimuthPositions(BladedModel):
    r"""
    Settings to control the azimuthal positions used in the analysis. If omitted, a single azimuthal position of zero is used. When more than one azimuthal position is used, the positions for the analysis are calculated such that they are evenly distributed around the circle.
    
    Attributes
    ----------
    FirstAzimuthPosition : float, default=0
        The first azimuthal position (in radians) used in the analysis. If the NumberOfAzimuthPositions = 1, then this is the only azimuthal position.
    
    NumberOfAzimuthPositions : int, default=1
        The number of azimuthal positions. Azimuthal positions for the analysis will be calculated such that they are evenly distributed around the whole circle.
    
    Notes
    -----
    
    """

    FirstAzimuthPosition: float = Field(alias="FirstAzimuthPosition", default=None)
    r"""
    The first azimuthal position (in radians) used in the analysis. If the NumberOfAzimuthPositions = 1, then this is the only azimuthal position.
    - default = 0
    """

    NumberOfAzimuthPositions: int = Field(alias="NumberOfAzimuthPositions", default=None)
    r"""
    The number of azimuthal positions. Azimuthal positions for the analysis will be calculated such that they are evenly distributed around the whole circle.
    - default = 1
    """

    _relative_schema_path: str = 'SteadyCalculation/LinearisationAzimuthPositions/LinearisationAzimuthPositions.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LinearisationAzimuthPositions.model_rebuild()
