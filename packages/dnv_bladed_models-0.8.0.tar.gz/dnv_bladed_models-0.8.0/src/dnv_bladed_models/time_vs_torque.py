# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TimeVsTorque(BladedModel):
    r"""
    The relationship between the time following the brake's activation, and the retarding torque it applies to the shaft.
    
    Attributes
    ----------
    Time : float
        The time since the brake has been activated.
    
    Torque : float
        The retarding torque to be applied to the shaft.
    
    Notes
    -----
    
    """

    Time: float = Field(alias="Time", default=None)
    r"""
    The time since the brake has been activated.
    """

    Torque: float = Field(alias="Torque", default=None)
    r"""
    The retarding torque to be applied to the shaft.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/Brake/TimeVsTorque/TimeVsTorque.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TimeVsTorque.model_rebuild()
