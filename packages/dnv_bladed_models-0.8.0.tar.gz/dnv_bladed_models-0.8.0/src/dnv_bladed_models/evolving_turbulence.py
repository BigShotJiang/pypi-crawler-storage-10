# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class EvolvingTurbulence_EvolvingTurbulenceTypeEnum(str, Enum):
    EVOLVING_TURBULENCE_EXPONENTIAL = "EvolvingTurbulenceExponential"
    EVOLVING_TURBULENCE_KRISTENSEN = "EvolvingTurbulenceKristensen"
    INSERT = "Insert"



class EvolvingTurbulence(BladedModel, ABC):
    r"""
    The settings for evolving turbulence.  In the case of a normal turbulent wind field, the turbulence is \"frozen\" and approaches the turbine at a constant block.  Although this doesn't match physical reality, it is a particular problem for Lidar - as it gives them a \"perfect\" insight into the oncoming wind field.  In order to represent the nature of real turbulence, a second turbulence file is superimposed on the windfield so that it \"evolves\" as it moves forward.  This is computationally expensive, and is usually applied only to the Lidar readings - although it can be applied to all the wind values in a simulation.
    
    Attributes
    ----------
    EvolvingTurbulenceType : EvolvingTurbulence_EvolvingTurbulenceTypeEnum
        Defines the specific type of model in use.
    
    SecondTurbulenceFilepath : str
        The filepath or URI of the second turbulence file.  The turbulence in this file will be used to simulate an evolving turbulence field.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - EvolvingTurbulenceExponential
        - EvolvingTurbulenceKristensen
        - EvolvingTurbulenceInsert
    
    """

    EvolvingTurbulenceType: EvolvingTurbulence_EvolvingTurbulenceTypeEnum = Field(alias="EvolvingTurbulenceType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    SecondTurbulenceFilepath: str = Field(alias="SecondTurbulenceFilepath", default=None)
    r"""
    The filepath or URI of the second turbulence file.  The turbulence in this file will be used to simulate an evolving turbulence field.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

EvolvingTurbulence.model_rebuild()
