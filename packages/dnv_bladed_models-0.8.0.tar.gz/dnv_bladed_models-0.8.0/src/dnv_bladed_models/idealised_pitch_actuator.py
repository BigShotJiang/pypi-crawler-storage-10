# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.pitch_actuator import PitchActuator
from dnv_bladed_models.pitch_actuator import PitchActuator as PitchActuatorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class IdealisedPitchActuator(PitchActuator):
    r"""
    An idealised pitch actuation system which achieves the specified positions without considering any of the physical realities of the system.
    
    Attributes
    ----------
    ActuatorDriveType : Literal['IdealisedActuator'], default='IdealisedActuator'
        Defines the specific type of ActuatorDrive model in use.  For a `IdealisedActuator` object, this must always be set to a value of `IdealisedActuator`.
    
    Notes
    -----
    
    """

    ActuatorDriveType: Literal['IdealisedActuator'] = Field(alias="ActuatorDriveType", default='IdealisedActuator', frozen=True) # type: ignore
    r"""
    Defines the specific type of ActuatorDrive model in use.  For a `IdealisedActuator` object, this must always be set to a value of `IdealisedActuator`.
    - default = 'IdealisedActuator'
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/IdealisedPitchActuator.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ActuatorDriveType').merge(PitchActuator._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


IdealisedPitchActuator.model_rebuild()
