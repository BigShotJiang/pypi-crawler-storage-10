# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.preset_lidar_scan import PresetLidarScan
from dnv_bladed_models.preset_lidar_scan import PresetLidarScan as PresetLidarScanModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CircularLidarScan(PresetLidarScan):
    r"""
    A simple circular scan pattern.
    
    Not supported yet.
    
    Attributes
    ----------
    ScanningPatternType : Literal['CircularScan'], default='CircularScan', Not supported yet
        Defines the specific type of ScanningPattern model in use.  For a `CircularScan` object, this must always be set to a value of `CircularScan`.
    
    HalfAngle : float, Not supported yet
        The half-angle between centre of scan and scanning position.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ScanningPatternType: Literal['CircularScan'] = Field(alias="ScanningPatternType", default='CircularScan', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of ScanningPattern model in use.  For a `CircularScan` object, this must always be set to a value of `CircularScan`.

    *Not supported yet*

    - default = 'CircularScan'
    """

    HalfAngle: float = Field(alias="HalfAngle", default=None) # Not supported yet
    r"""
    The half-angle between centre of scan and scanning position.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Lidar/LidarScanningPattern/CircularLidarScan.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ScanningPatternType').merge(PresetLidarScan._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CircularLidarScan.model_rebuild()
