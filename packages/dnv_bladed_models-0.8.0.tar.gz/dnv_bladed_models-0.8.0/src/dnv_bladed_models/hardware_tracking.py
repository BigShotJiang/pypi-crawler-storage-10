# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class HardwareTracking(BladedModel):
    r"""
    Options for tracking external hardware using BHTM (Bladed Hardware Test Module) or similar external package.
    
    Not supported yet.
    
    Attributes
    ----------
    TrackPitchActuator : bool, default=False, Not supported yet
        If true, Bladed will accept data about the pitch system from an external source, and simulate the rest of the turbine in Bladed.
    
    TrackGenerator : bool, Not supported yet
        If true, Bladed will accept data about the generator from an external source, and simulate the rest of the turbine in Bladed.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TrackPitchActuator: bool = Field(alias="TrackPitchActuator", default=None) # Not supported yet
    r"""
    If true, Bladed will accept data about the pitch system from an external source, and simulate the rest of the turbine in Bladed.

    *Not supported yet*

    - default = False
    """

    TrackGenerator: bool = Field(alias="TrackGenerator", default=None) # Not supported yet
    r"""
    If true, Bladed will accept data about the generator from an external source, and simulate the rest of the turbine in Bladed.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/ExternallySteppedSimulation/HardwareTracking/HardwareTracking.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


HardwareTracking.model_rebuild()
