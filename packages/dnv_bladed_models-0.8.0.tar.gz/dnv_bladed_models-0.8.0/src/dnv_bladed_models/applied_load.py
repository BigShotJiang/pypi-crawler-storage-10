# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *


class AppliedLoad_AppliedLoadTypeEnum(str, Enum):
    BLADE_POINT_LOADING = "BladePointLoading"
    TOWER_POINT_LOADING = "TowerPointLoading"
    INSERT = "Insert"



class AppliedLoad(BladedModel, ABC):
    r"""
    The common properties of a point loading time history.
    
    Not supported yet.
    
    Attributes
    ----------
    AppliedLoadType : AppliedLoad_AppliedLoadTypeEnum, Not supported yet
        Defines the specific type of model in use.
    
    StartTime : float, Not supported yet
        The time into the simulation at which to start applying the loading (excluding the lead-in time).
    
    LoadingFilepath : str, Not supported yet
        A filepath or URI containing one or six degree of loading data.  In the case of the six degrees of freedom, these will be applied in the component's coordinate system.  Where a single degree of freedom is provided, SingleDirectionLoading must also be specified.
    
    DirectionOfLoading : Vector3D
    
    OnComponentInAssembly : str, regex=^Assembly.(.+)$, Not supported yet
        A qualified, dot-separated path to a component in the assembly tree to which to apply the force.  i.e. `Assembly.<name1>.<name2>`
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    This class is an abstraction, with the following concrete implementations:
        - BladePointLoading
        - AppliedLoadInsert
        - TowerPointLoading
    
    """

    AppliedLoadType: AppliedLoad_AppliedLoadTypeEnum = Field(alias="AppliedLoadType", default=None) # Not supported yet
    r"""
    Defines the specific type of model in use.

    *Not supported yet*

    """

    StartTime: float = Field(alias="StartTime", default=None) # Not supported yet
    r"""
    The time into the simulation at which to start applying the loading (excluding the lead-in time).

    *Not supported yet*

    """

    LoadingFilepath: str = Field(alias="LoadingFilepath", default=None) # Not supported yet
    r"""
    A filepath or URI containing one or six degree of loading data.  In the case of the six degrees of freedom, these will be applied in the component's coordinate system.  Where a single degree of freedom is provided, SingleDirectionLoading must also be specified.

    *Not supported yet*

    """

    DirectionOfLoading: Vector3DModel = Field(alias="DirectionOfLoading", default=None)
    r"""
    """

    OnComponentInAssembly: str = Field(alias="@OnComponentInAssembly", default=None, pattern='^Assembly.(.+)$') # Not supported yet
    r"""
    A qualified, dot-separated path to a component in the assembly tree to which to apply the force.  i.e. `Assembly.<name1>.<name2>`

    *Not supported yet*

    - regex = ^Assembly.(.+)$
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

AppliedLoad.model_rebuild()
