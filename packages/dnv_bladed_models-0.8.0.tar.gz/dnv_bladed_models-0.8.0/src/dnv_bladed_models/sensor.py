# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Sensor_SensorTypeEnum(str, Enum):
    ACCELEROMETER = "Accelerometer"
    INCLINOMETER = "Inclinometer"
    LOAD_SENSOR = "LoadSensor"
    INSERT = "Insert"



class Sensor(BladedModel, ABC):
    r"""
    The base class for all sensors.
    
    Attributes
    ----------
    SensorType : Sensor_SensorTypeEnum
        Defines the specific type of model in use.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - Accelerometer
        - Inclinometer
        - SensorInsert
        - LoadSensor
    
    """

    SensorType: Sensor_SensorTypeEnum = Field(alias="SensorType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

Sensor.model_rebuild()
