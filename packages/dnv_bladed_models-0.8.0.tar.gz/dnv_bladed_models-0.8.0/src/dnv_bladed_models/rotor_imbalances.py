# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RotorImbalances(BladedModel):
    r"""
    The definition of any imbalances on the hub.
    
    Attributes
    ----------
    OutOfBalanceMass : float
        A mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    
    RadiusOfMass : float
        The radial location of the mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    
    AzimuthalPositionOfMass : float
        The angular location of the mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    
    ErrorsInSetAngle : List[float]
        The manufacturing or assembly errors in the angle the pitch bearings or blades are attached to the hub.
    
    ErrorsInAzimuthAngle : List[float]
        The manufacturing or assembly errors in the azimuth angle for each blade mounting point.
    
    Notes
    -----
    
    """

    OutOfBalanceMass: float = Field(alias="OutOfBalanceMass", default=None)
    r"""
    A mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    """

    RadiusOfMass: float = Field(alias="RadiusOfMass", default=None)
    r"""
    The radial location of the mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    """

    AzimuthalPositionOfMass: float = Field(alias="AzimuthalPositionOfMass", default=None)
    r"""
    The angular location of the mass to add off the centreline of the hub to represent the various mass imbalances and assymetries in the rotor.
    """

    ErrorsInSetAngle: List[float] = Field(alias="ErrorsInSetAngle", default_factory=list)
    r"""
    The manufacturing or assembly errors in the angle the pitch bearings or blades are attached to the hub.
    """

    ErrorsInAzimuthAngle: List[float] = Field(alias="ErrorsInAzimuthAngle", default_factory=list)
    r"""
    The manufacturing or assembly errors in the azimuth angle for each blade mounting point.
    """

    _relative_schema_path: str = 'Components/Hub/RotorImbalances/RotorImbalances.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['ErrorsInSetAngle','ErrorsInAzimuthAngle',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RotorImbalances.model_rebuild()
