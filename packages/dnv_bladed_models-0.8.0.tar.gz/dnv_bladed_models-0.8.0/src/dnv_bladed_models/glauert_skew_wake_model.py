# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.skew_wake_model import SkewWakeModel
from dnv_bladed_models.skew_wake_model import SkewWakeModel as SkewWakeModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class GlauertSkewWakeModel(SkewWakeModel):
    r"""
    Settings for the Glauert skew wake model.
    
    Attributes
    ----------
    VelocityCorrectionFactor : float, default=0.75
        The correction factor for quasi-steady velocity in Glauert skew wake model.
    
    TimeCorrectionFactor : float, default=0.5
        The correction factor for time constant in Glauert skew wake model.
    
    Notes
    -----
    
    """

    VelocityCorrectionFactor: float = Field(alias="VelocityCorrectionFactor", default=None)
    r"""
    The correction factor for quasi-steady velocity in Glauert skew wake model.
    - default = 0.75
    """

    TimeCorrectionFactor: float = Field(alias="TimeCorrectionFactor", default=None)
    r"""
    The correction factor for time constant in Glauert skew wake model.
    - default = 0.5
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/MomentumTheoryCorrections/GlauertSkewWakeModel/GlauertSkewWakeModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(SkewWakeModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


GlauertSkewWakeModel.model_rebuild()
