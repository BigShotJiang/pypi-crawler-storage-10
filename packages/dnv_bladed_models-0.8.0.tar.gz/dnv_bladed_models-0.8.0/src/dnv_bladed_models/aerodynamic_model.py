# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.sequential_timestep_adaptation import SequentialTimestepAdaptation
from dnv_bladed_models.sequential_timestep_adaptation import SequentialTimestepAdaptation as SequentialTimestepAdaptationModel
from .schema_helper import SchemaHelper
from .base_entity import *


class AerodynamicModel_AerodynamicModelTypeEnum(str, Enum):
    BLADE_ELEMENT_MOMENTUM = "BladeElementMomentum"
    VORTEX_LINE = "VortexLine"
    INSERT = "Insert"



class AerodynamicModel(BladedModel, ABC):
    r"""
    Common properties for all aerodynamics models.
    
    Attributes
    ----------
    AerodynamicModelType : AerodynamicModel_AerodynamicModelTypeEnum
        Defines the specific type of model in use.
    
    SequentialTimestepAdaptation : SequentialTimestepAdaptation, Not supported yet
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - BladeElementMomentum
        - AerodynamicModelInsert
        - VortexLine
    
    """

    AerodynamicModelType: AerodynamicModel_AerodynamicModelTypeEnum = Field(alias="AerodynamicModelType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    SequentialTimestepAdaptation: SequentialTimestepAdaptationModel = Field(alias="SequentialTimestepAdaptation", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

AerodynamicModel.model_rebuild()
