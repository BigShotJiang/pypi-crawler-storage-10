# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.active_damper import ActiveDamper
from dnv_bladed_models.active_damper import ActiveDamper as ActiveDamperModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FixedSpeedActiveDamper(ActiveDamper):
    r"""
    A fixed speed active damper for the support structure.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentType : Literal['FixedSpeedActiveDamper'], default='FixedSpeedActiveDamper', Not supported yet
        Defines the specific type of Component model in use.  For a `FixedSpeedActiveDamper` object, this must always be set to a value of `FixedSpeedActiveDamper`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentType: Literal['FixedSpeedActiveDamper'] = Field(alias="ComponentType", default='FixedSpeedActiveDamper', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `FixedSpeedActiveDamper` object, this must always be set to a value of `FixedSpeedActiveDamper`.

    *Not supported yet*

    - default = 'FixedSpeedActiveDamper'
    """

    _relative_schema_path: str = 'Components/Damper/FixedSpeedActiveDamper.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(ActiveDamper._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FixedSpeedActiveDamper.model_rebuild()
