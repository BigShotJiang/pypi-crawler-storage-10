# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RigidBodyInertia(Component, ABC):
    r"""
    An inertia to be added to the assembly.
    
    Attributes
    ----------
    Notes
    -----
    
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Component._type_info)

RigidBodyInertia.model_rebuild()
