# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerNodeLoads(BladedModel):
    r"""
    The moments and forces to output for any node location where the loads are requested.
    
    Not supported yet.
    
    Attributes
    ----------
    Mx : bool, default=False, Not supported yet
        If true, the moment about the x-axis will be output.
    
    My : bool, default=False, Not supported yet
        If true, the moment about the y-axis will be output.
    
    Mz : bool, default=False, Not supported yet
        If true, the moment about the z-axis will be output.
    
    Mxy : bool, Not supported yet
        If true, the maximum moment about any axis that lies in the XY plane will be output.
    
    Fx : bool, default=False, Not supported yet
        If true, the force in the X direction will be output.
    
    Fy : bool, default=False, Not supported yet
        If true, the force in the Y direction will be output.
    
    Fz : bool, default=False, Not supported yet
        If true, the force in the Z direction will be output.
    
    Fxy : bool, Not supported yet
        If true, the maximum force along any axis that lies in the XY plane will be output.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Mx: bool = Field(alias="Mx", default=None) # Not supported yet
    r"""
    If true, the moment about the x-axis will be output.

    *Not supported yet*

    - default = False
    """

    My: bool = Field(alias="My", default=None) # Not supported yet
    r"""
    If true, the moment about the y-axis will be output.

    *Not supported yet*

    - default = False
    """

    Mz: bool = Field(alias="Mz", default=None) # Not supported yet
    r"""
    If true, the moment about the z-axis will be output.

    *Not supported yet*

    - default = False
    """

    Mxy: bool = Field(alias="Mxy", default=None) # Not supported yet
    r"""
    If true, the maximum moment about any axis that lies in the XY plane will be output.

    *Not supported yet*

    """

    Fx: bool = Field(alias="Fx", default=None) # Not supported yet
    r"""
    If true, the force in the X direction will be output.

    *Not supported yet*

    - default = False
    """

    Fy: bool = Field(alias="Fy", default=None) # Not supported yet
    r"""
    If true, the force in the Y direction will be output.

    *Not supported yet*

    - default = False
    """

    Fz: bool = Field(alias="Fz", default=None) # Not supported yet
    r"""
    If true, the force in the Z direction will be output.

    *Not supported yet*

    - default = False
    """

    Fxy: bool = Field(alias="Fxy", default=None) # Not supported yet
    r"""
    If true, the maximum force along any axis that lies in the XY plane will be output.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Tower/TowerOutputGroupLibrary/TowerOutputGroup/TowerNodeLoads/TowerNodeLoads.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerNodeLoads.model_rebuild()
