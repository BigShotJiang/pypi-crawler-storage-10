# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Mounting(BladedModel):
    r"""
    The blade mounting angles, outboard of pitch bearing.
    
    Attributes
    ----------
    ConingAngle : float, default=0
        An additional blade coning angle applied at the root of the blade itself.  This has the effect of adding a contribution to the pre-bend deflection which increases linearly with distance along the blade. The direction of the coning follows that of the hub ConingAngle when the pitch of the blade is fine.
    
    SweepAngle : float, default=0
        The blade sweep angle, a positive sweep angle means that the blade tip is swept back from the pitch axis, away from the direction of rotation.
    
    Notes
    -----
    
    """

    ConingAngle: float = Field(alias="ConingAngle", default=None)
    r"""
    An additional blade coning angle applied at the root of the blade itself.  This has the effect of adding a contribution to the pre-bend deflection which increases linearly with distance along the blade. The direction of the coning follows that of the hub ConingAngle when the pitch of the blade is fine.
    - default = 0
    """

    SweepAngle: float = Field(alias="SweepAngle", default=None)
    r"""
    The blade sweep angle, a positive sweep angle means that the blade tip is swept back from the pitch axis, away from the direction of rotation.
    - default = 0
    """

    _relative_schema_path: str = 'Components/Blade/Mounting/Mounting.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Mounting.model_rebuild()
