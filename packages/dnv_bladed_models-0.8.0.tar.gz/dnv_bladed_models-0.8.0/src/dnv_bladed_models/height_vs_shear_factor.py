# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class HeightVsShearFactor(BladedModel):
    r"""
    A single height vs shear factor point.
    
    Attributes
    ----------
    Height : float
        The height above the ground.  This should vary from 0.0 up to the reference height, above which normal flow resumes.
    
    ShearFactor : float
        The shear factor, varying from 0.0 (no wind) up to 1.0 (full flow).
    
    Notes
    -----
    
    """

    Height: float = Field(alias="Height", default=None)
    r"""
    The height above the ground.  This should vary from 0.0 up to the reference height, above which normal flow resumes.
    """

    ShearFactor: float = Field(alias="ShearFactor", default=None)
    r"""
    The shear factor, varying from 0.0 (no wind) up to 1.0 (full flow).
    """

    _relative_schema_path: str = 'common/HeightVsShearFactor.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


HeightVsShearFactor.model_rebuild()
