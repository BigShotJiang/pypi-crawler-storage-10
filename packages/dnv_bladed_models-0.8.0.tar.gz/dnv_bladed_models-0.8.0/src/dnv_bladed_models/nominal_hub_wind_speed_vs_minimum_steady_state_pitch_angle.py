# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NominalHubWindSpeedVsMinimumSteadyStatePitchAngle(BladedModel):
    r"""
    The look-up table for specifying the nominal free-field wind speed at the hub against the respective minimum pitch angle for pitch scheduling. Wind speeds need to be in monotonic ascending order. Linear interpolation is used between points. If the hub wind speed exceeds the specified value the nearest will be used and a warning message will be written.
    
    Attributes
    ----------
    HubWindSpeed : float
        The nominal free-field wind speed at the hub for which the minimum pitch angle will apply.
    
    MinimumSteadyStatePitchAngle : float
        The minimum pitch angle demand of the blades that the turbine control will apply for the specified wind speed.  The initial conditions may choose a higher pitch angle in order to achieve an equilibrium, but not a lower one.
    
    Notes
    -----
    
    """

    HubWindSpeed: float = Field(alias="HubWindSpeed", default=None)
    r"""
    The nominal free-field wind speed at the hub for which the minimum pitch angle will apply.
    """

    MinimumSteadyStatePitchAngle: float = Field(alias="MinimumSteadyStatePitchAngle", default=None)
    r"""
    The minimum pitch angle demand of the blades that the turbine control will apply for the specified wind speed.  The initial conditions may choose a higher pitch angle in order to achieve an equilibrium, but not a lower one.
    """

    _relative_schema_path: str = 'Turbine/TurbineOperationalParameters/VariableSpeedPitchRegulatedControlModel/NominalHubWindSpeedVsMinimumSteadyStatePitchAngle/NominalHubWindSpeedVsMinimumSteadyStatePitchAngle.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NominalHubWindSpeedVsMinimumSteadyStatePitchAngle.model_rebuild()
