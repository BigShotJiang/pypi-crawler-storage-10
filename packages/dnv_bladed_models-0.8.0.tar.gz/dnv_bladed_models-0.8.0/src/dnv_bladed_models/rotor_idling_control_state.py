# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.initial_control_state import InitialControlState
from dnv_bladed_models.initial_control_state import InitialControlState as InitialControlStateModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RotorIdlingControlState(InitialControlState):
    r"""
    The initial condition of the rotor or turbine idling.  The external controller is still able to change the state of the turbine during the simulation.
    
    Attributes
    ----------
    InitialConditionType : Literal['RotorIdling'], default='RotorIdling'
        Defines the specific type of InitialCondition model in use.  For a `RotorIdling` object, this must always be set to a value of `RotorIdling`.
    
    IsControllerActive : bool
        If true, the controller is active and can change the state of the turbine.
    
    Notes
    -----
    
    """

    InitialConditionType: Literal['RotorIdling'] = Field(alias="InitialConditionType", default='RotorIdling', frozen=True) # type: ignore
    r"""
    Defines the specific type of InitialCondition model in use.  For a `RotorIdling` object, this must always be set to a value of `RotorIdling`.
    - default = 'RotorIdling'
    """

    IsControllerActive: bool = Field(alias="IsControllerActive", default=None)
    r"""
    If true, the controller is active and can change the state of the turbine.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/InitialCondition/RotorIdlingControlState.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(InitialControlState._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RotorIdlingControlState.model_rebuild()
