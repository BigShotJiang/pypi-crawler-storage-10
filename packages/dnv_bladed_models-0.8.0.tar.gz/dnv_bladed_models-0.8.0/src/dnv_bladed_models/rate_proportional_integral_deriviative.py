# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.transducer_behaviour import TransducerBehaviour
from dnv_bladed_models.transducer_behaviour import TransducerBehaviour as TransducerBehaviourModel
from .schema_helper import SchemaHelper
from .base_entity import *


class RateProportionalIntegralDeriviative_DifferentialGainActionEnum(str, Enum):
    ERROR = "Error"
    FEEDBACK = "Feedback"
    SETPOINT = "Setpoint"



class RateProportionalIntegralDeriviative(TransducerBehaviour):
    r"""
    
    
    Not supported yet.
    
    Attributes
    ----------
    TransducerBehaviourType : Literal['RateProportionalIntegralDeriviative'], default='RateProportionalIntegralDeriviative', Not supported yet
        Defines the specific type of TransducerBehaviour model in use.  For a `RateProportionalIntegralDeriviative` object, this must always be set to a value of `RateProportionalIntegralDeriviative`.
    
    ProportionalGain : float, default=0, Not supported yet
        The gain on the contemporaneous error.
    
    IntegralGain : float, default=0, Not supported yet
        The gain on the integral from time zero till the present of the error signal.
    
    DifferentialGain : float, default=0, Not supported yet
        The gain the filtered derivative of the error. The derivative of the error is passed through a low-pass filter.
    
    DifferentialGainAction : RateProportionalIntegralDeriviative_DifferentialGainActionEnum, default='Feedback', Not supported yet
        Proportional and integral terms are applied on error.  The derivative term may also be applied on the feedback or setpoint signals.
    
    DifferentialGainTimeConstant : float, default=0, Not supported yet
        The derivative term uses a low-pass filter on input.
    
    DesaturationTimeConstant : float, default=0, Not supported yet
        The time constant for when the output exceeds the limits.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    TransducerBehaviourType: Literal['RateProportionalIntegralDeriviative'] = Field(alias="TransducerBehaviourType", default='RateProportionalIntegralDeriviative', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of TransducerBehaviour model in use.  For a `RateProportionalIntegralDeriviative` object, this must always be set to a value of `RateProportionalIntegralDeriviative`.

    *Not supported yet*

    - default = 'RateProportionalIntegralDeriviative'
    """

    ProportionalGain: float = Field(alias="ProportionalGain", default=None) # Not supported yet
    r"""
    The gain on the contemporaneous error.

    *Not supported yet*

    - default = 0
    """

    IntegralGain: float = Field(alias="IntegralGain", default=None) # Not supported yet
    r"""
    The gain on the integral from time zero till the present of the error signal.

    *Not supported yet*

    - default = 0
    """

    DifferentialGain: float = Field(alias="DifferentialGain", default=None) # Not supported yet
    r"""
    The gain the filtered derivative of the error. The derivative of the error is passed through a low-pass filter.

    *Not supported yet*

    - default = 0
    """

    DifferentialGainAction: RateProportionalIntegralDeriviative_DifferentialGainActionEnum = Field(alias="DifferentialGainAction", default=None) # Not supported yet
    r"""
    Proportional and integral terms are applied on error.  The derivative term may also be applied on the feedback or setpoint signals.

    *Not supported yet*

    - default = 'Feedback'
    """

    DifferentialGainTimeConstant: float = Field(alias="DifferentialGainTimeConstant", default=None) # Not supported yet
    r"""
    The derivative term uses a low-pass filter on input.

    *Not supported yet*

    - default = 0
    """

    DesaturationTimeConstant: float = Field(alias="DesaturationTimeConstant", default=None) # Not supported yet
    r"""
    The time constant for when the output exceeds the limits.

    *Not supported yet*

    - default = 0
    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/common/RateProportionalIntegralDeriviative.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'TransducerBehaviourType').merge(TransducerBehaviour._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


RateProportionalIntegralDeriviative.model_rebuild()
