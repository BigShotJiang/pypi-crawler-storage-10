# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.fixed_step_integrator import FixedStepIntegrator
from dnv_bladed_models.fixed_step_integrator import FixedStepIntegrator as FixedStepIntegratorModel
from .schema_helper import SchemaHelper
from .base_entity import *




class GeneralisedAlphaFixedStep(FixedStepIntegrator):
    r"""
    Settings for the Generalised Alpha Fixed Step integrator.
    
    Attributes
    ----------
    IntegratorType : Literal['GeneralisedAlphaFixedStep'], default='GeneralisedAlphaFixedStep'
        Defines the specific type of Integrator model in use.  For a `GeneralisedAlphaFixedStep` object, this must always be set to a value of `GeneralisedAlphaFixedStep`.
    
    MaximumNumberOfIterations : int, default=1
        The maximum number of iterations for prescribed freedoms and first order states (e.g. dynamic stall & wake).  A value of 1 may sometimes inprecisely integrate first order states
    
    SpectralRadiusAtInfiniteFrequency : float, default=0.8
        This determines the numerical damping of high-frequency modes.  A value of 1 provides no numerical damping and a low value provides heavy numerical damping on high-frequency modes which can improve stability but decrease precision.
    
    Notes
    -----
    
    """

    IntegratorType: Literal['GeneralisedAlphaFixedStep'] = Field(alias="IntegratorType", default='GeneralisedAlphaFixedStep', frozen=True) # type: ignore
    r"""
    Defines the specific type of Integrator model in use.  For a `GeneralisedAlphaFixedStep` object, this must always be set to a value of `GeneralisedAlphaFixedStep`.
    - default = 'GeneralisedAlphaFixedStep'
    """

    MaximumNumberOfIterations: int = Field(alias="MaximumNumberOfIterations", default=None)
    r"""
    The maximum number of iterations for prescribed freedoms and first order states (e.g. dynamic stall & wake).  A value of 1 may sometimes inprecisely integrate first order states
    - default = 1
    """

    SpectralRadiusAtInfiniteFrequency: float = Field(alias="SpectralRadiusAtInfiniteFrequency", default=None)
    r"""
    This determines the numerical damping of high-frequency modes.  A value of 1 provides no numerical damping and a low value provides heavy numerical damping on high-frequency modes which can improve stability but decrease precision.
    - default = 0.8
    """

    _relative_schema_path: str = 'Settings/SolverSettings/Integrator/GeneralisedAlphaFixedStep.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'IntegratorType').merge(FixedStepIntegrator._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


GeneralisedAlphaFixedStep.model_rebuild()
