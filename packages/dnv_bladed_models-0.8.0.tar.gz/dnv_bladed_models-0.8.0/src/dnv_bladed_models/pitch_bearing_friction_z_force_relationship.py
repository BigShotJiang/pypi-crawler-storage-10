# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.applied_z_force_vs_friction_torque import AppliedZForceVsFrictionTorque
from dnv_bladed_models.applied_z_force_vs_friction_torque import AppliedZForceVsFrictionTorque as AppliedZForceVsFrictionTorqueModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchBearingFrictionZForceRelationship(BladedModel):
    r"""
    The relationship between the Coulomb friction and the axial force on the bearing.
    
    Attributes
    ----------
    FrictionTorquePerUnitAppliedForce : float
        A fixed ratio between the axial force on the bearing and the friction opposing the motion.
    
    AppliedForceVsFrictionTorque : List[AppliedZForceVsFrictionTorque]
        A look-up table describing a non-linear relationship between the axial force on the bearing and the corresponding friction.
    
    Notes
    -----
    
    """

    FrictionTorquePerUnitAppliedForce: float = Field(alias="FrictionTorquePerUnitAppliedForce", default=None)
    r"""
    A fixed ratio between the axial force on the bearing and the friction opposing the motion.
    """

    AppliedForceVsFrictionTorque: List[AppliedZForceVsFrictionTorqueModel] = Field(alias="AppliedForceVsFrictionTorque", default_factory=list)
    r"""
    A look-up table describing a non-linear relationship between the axial force on the bearing and the corresponding friction.
    """

    _relative_schema_path: str = 'Components/PitchSystem/Friction/PitchBearingKineticFriction/PitchBearingFrictionZForceRelationship/PitchBearingFrictionZForceRelationship.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['AppliedForceVsFrictionTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchBearingFrictionZForceRelationship.model_rebuild()
