# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.assembly_node import AssemblyNode
from dnv_bladed_models.assembly_node import AssemblyNode as AssemblyNodeModel
from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Assembly(BladedModel):
    r"""
    The Assembly is a tree structure defining the connectivity of the turbine components. Each node in the tree is defined as an object with a custom name, and a reference to the relevant component in the ComponentDefinitions. Each node can have 0 or more connected 'child' nodes, defined as object properties inside it. The Assembly tree must start with a single node at the root.
    
    Attributes
    ----------
    Notes
    -----
    
    """
    # The entries for a library object can be accessed using item accessors on the
    # object itself. They are stored using Pydantic's 'extra' feature.
    __pydantic_extra__: dict[str, AssemblyNode] = Field(init=False)

    _relative_schema_path: str = 'Turbine/Assembly/Assembly.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='allow')

    @property
    def entries(self) -> ReadOnlyDict[str, AssemblyNode]:
        """
        A read-only dictionary representation of the library entries.
        Use the item accessors on the object itself to add/update/delete entries.
        """
        return ReadOnlyDict(self.__pydantic_extra__)
    
    @property
    def model_extra(self) -> ReadOnlyDict[str, AssemblyNode]:
        """
        A read-only dictionary representation of the library entries.
        Use the item accessors on the object itself to add/update/delete entries.
        """
        return ReadOnlyDict(self.__pydantic_extra__)


    def items(self) -> ItemsView[str, AssemblyNode]:
        """
        Returns a list of key-value pairs for all of the user-supplied entries currently in the model.
        """
        return self.__pydantic_extra__.items()


    def keys(self) -> KeysView[str]:
        """
        Returns a list of keys for all of the user-supplied entries currently in the model.
        """
        return self.__pydantic_extra__.keys()


    def values(self) -> ValuesView[AssemblyNode]:
        """
        Returns a list of model objects for all of the user-supplied entries currently in the model.
        """
        return self.__pydantic_extra__.values()


    def __len__(self):
        return len(self.__pydantic_extra__)


    def __contains__(self, item):
        return item in self.__pydantic_extra__


    def __getitem__(self, key: Union[str, int]) -> AssemblyNode:
        if isinstance(key, int):
            keys = self.__pydantic_extra__.keys()
            if len(keys) == 0:
                raise KeyError(f"There are currently no entries in the model object.")
            if key < 0 or key >= len(keys):
                raise KeyError(f"Invalid index specified: {key} (0 >= i < {len(keys)})")
            str_key = list(keys)[key]
        elif isinstance(key, str):
            if key in Assembly.model_fields:
                raise KeyError(f"Item accessors can only be used for custom entries. '{key}' is a pre-defined model property.")
            if not key in self.__pydantic_extra__:
                raise KeyError(f"There is no entry with key '{key}'.")
            str_key = key
        return self.__pydantic_extra__[str_key]


    def __setitem__(self, key: str, value: AssemblyNode):
        if not isinstance(key, str):
            raise KeyError(f"Custom entries can only be added with string keys")
        if not isinstance(value, AssemblyNode):
            error: pydantic_core.InitErrorDetails = {
                'type': pydantic_core.PydanticCustomError('value_error', f"Entries must be of type 'AssemblyNode'; received '{type(value).__name__}'"),  # type: ignore
                'loc': (self.__class__.__name__, '<entries>', key),
                'input': value,
            }
            raise pydantic_core.ValidationError.from_exception_data(self.__class__.__name__, [error])
        self.__pydantic_extra__[key] = value


    def __delitem__(self, key: Union[str, int]):
        if isinstance(key, int):
            keys = self.__pydantic_extra__.keys()
            if len(keys) == 0:
                raise KeyError(f"There are currently no entries in the model object.")
            if key < 0 or key >= len(keys):
                raise KeyError(f"Invalid index specified: {key} (0 >= i < {len(keys)})")
            str_key = list(keys)[key]
        elif isinstance(key, str):
            if not key in self.__pydantic_extra__:
                raise KeyError(f"There is no entry with key '{key}'.")
            str_key = key
        del self.__pydantic_extra__[str_key]



    def _entity(self) -> bool:
        return True


Assembly.model_rebuild()
