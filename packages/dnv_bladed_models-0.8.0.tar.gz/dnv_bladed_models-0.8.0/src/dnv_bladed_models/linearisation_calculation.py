# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.linearisation_azimuth_positions import LinearisationAzimuthPositions
from dnv_bladed_models.linearisation_azimuth_positions import LinearisationAzimuthPositions as LinearisationAzimuthPositionsModel
from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs as SteadyCalculationOutputsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearisationCalculation(SteadyCalculation, ABC):
    r"""
    The common properties of calculations which use small perturbations to generate system responses, from which the dynamics of the fully coupled system can be analysed.
    
    Attributes
    ----------
    Outputs : SteadyCalculationOutputs
    
    TransformRotorModesToNonRotating : bool, default=True
        If true, a multi-blade coordinate (MBC) transform will be performed to transform the rotating modes into the stationary frame of reference.  This will generate forward and backward whirling modes in a Campbell diagram.
    
    AlignWindFieldWithDeflectedHubAxis : bool, default=True
        If true, the deflected steady-state operating conditions of the turbine are calculated, and then the wind field is rotated to align with the rotating axis of the (first) hub for linearisation.
    
    EvenlySpacedAzimuthPositions : LinearisationAzimuthPositions
    
    Notes
    -----
    
    """

    Outputs: SteadyCalculationOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    TransformRotorModesToNonRotating: bool = Field(alias="TransformRotorModesToNonRotating", default=None)
    r"""
    If true, a multi-blade coordinate (MBC) transform will be performed to transform the rotating modes into the stationary frame of reference.  This will generate forward and backward whirling modes in a Campbell diagram.
    - default = True
    """

    AlignWindFieldWithDeflectedHubAxis: bool = Field(alias="AlignWindFieldWithDeflectedHubAxis", default=None)
    r"""
    If true, the deflected steady-state operating conditions of the turbine are calculated, and then the wind field is rotated to align with the rotating axis of the (first) hub for linearisation.
    - default = True
    """

    EvenlySpacedAzimuthPositions: LinearisationAzimuthPositionsModel = Field(alias="EvenlySpacedAzimuthPositions", default=None)
    r"""
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(SteadyCalculation._type_info)

LinearisationCalculation.model_rebuild()
