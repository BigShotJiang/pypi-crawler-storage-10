# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_with_component_outputs import SteadyCalculationWithComponentOutputs
from dnv_bladed_models.steady_calculation_with_component_outputs import SteadyCalculationWithComponentOutputs as SteadyCalculationWithComponentOutputsModel
from dnv_bladed_models.velocity_range import VelocityRange
from dnv_bladed_models.velocity_range import VelocityRange as VelocityRangeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SteadyOperationalLoadsCalculation(SteadyCalculation):
    r"""
    Defines a calculation which produces all the loads in a steady, uniform wind field.  The entire turbine is modelled for this analysis and prebend and sweep included, as well as flexibility.  Most realities such as tower shadow and wind shear are ignored.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['SteadyOperationalLoads'], default='SteadyOperationalLoads'
        Defines the specific type of SteadyCalculation model in use.  For a `SteadyOperationalLoads` object, this must always be set to a value of `SteadyOperationalLoads`.
    
    WindSpeedRange : VelocityRange
    
    Outputs : SteadyCalculationWithComponentOutputs
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['SteadyOperationalLoads'] = Field(alias="SteadyCalculationType", default='SteadyOperationalLoads', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `SteadyOperationalLoads` object, this must always be set to a value of `SteadyOperationalLoads`.
    - default = 'SteadyOperationalLoads'
    """

    WindSpeedRange: VelocityRangeModel = Field(alias="WindSpeedRange", default=None)
    r"""
    """

    Outputs: SteadyCalculationWithComponentOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/SteadyOperationalLoadsCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(SteadyCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SteadyOperationalLoadsCalculation.model_rebuild()
