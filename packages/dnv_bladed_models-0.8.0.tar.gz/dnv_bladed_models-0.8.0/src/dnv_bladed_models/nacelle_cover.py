# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class NacelleCover(BladedModel):
    r"""
    A nacelle cover best represented by a cuboid.
    
    Attributes
    ----------
    Width : float
        The width (Y dimension) of the nacelle cover.
    
    Length : float
        The length (X dimension) of the nacelle cover.
    
    Height : float
        The height (Z dimension) of the nacelle cover.
    
    CentreOfPressure : Vector3D
    
    CoefficientOfDrag : float
        The coefficient of drag for the nacelle.
    
    Notes
    -----
    
    """

    Width: float = Field(alias="Width", default=None)
    r"""
    The width (Y dimension) of the nacelle cover.
    """

    Length: float = Field(alias="Length", default=None)
    r"""
    The length (X dimension) of the nacelle cover.
    """

    Height: float = Field(alias="Height", default=None)
    r"""
    The height (Z dimension) of the nacelle cover.
    """

    CentreOfPressure: Vector3DModel = Field(alias="CentreOfPressure", default=None)
    r"""
    """

    CoefficientOfDrag: float = Field(alias="CoefficientOfDrag", default=None)
    r"""
    The coefficient of drag for the nacelle.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/NacelleCover/NacelleCover.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


NacelleCover.model_rebuild()
