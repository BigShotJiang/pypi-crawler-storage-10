# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TimeVsVoltageChange(BladedModel):
    r"""
    A single point in the time vs voltage time history.
    
    Not supported yet.
    
    Attributes
    ----------
    Time : float, Not supported yet
        The time after the disturbance starts.  The first point in the series should be at Time=0.0.
    
    VoltageChange : float, Not supported yet
        The change in voltage at the corresponding time.  0.0 would represent no disturbance in the voltage.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    Time: float = Field(alias="Time", default=None) # Not supported yet
    r"""
    The time after the disturbance starts.  The first point in the series should be at Time=0.0.

    *Not supported yet*

    """

    VoltageChange: float = Field(alias="VoltageChange", default=None) # Not supported yet
    r"""
    The change in voltage at the corresponding time.  0.0 would represent no disturbance in the voltage.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/TimeVsVoltageChange/TimeVsVoltageChange.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TimeVsVoltageChange.model_rebuild()
