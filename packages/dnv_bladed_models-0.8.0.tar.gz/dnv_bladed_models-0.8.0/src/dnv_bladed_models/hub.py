# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.component import Component
from dnv_bladed_models.component import Component as ComponentModel
from dnv_bladed_models.extension_pieces import ExtensionPieces
from dnv_bladed_models.extension_pieces import ExtensionPieces as ExtensionPiecesModel
from dnv_bladed_models.hub_connectable_nodes import HubConnectableNodes
from dnv_bladed_models.hub_connectable_nodes import HubConnectableNodes as HubConnectableNodesModel
from dnv_bladed_models.hub_mass_properties import HubMassProperties
from dnv_bladed_models.hub_mass_properties import HubMassProperties as HubMassPropertiesModel
from dnv_bladed_models.hub_output_group_library import HubOutputGroupLibrary
from dnv_bladed_models.hub_output_group_library import HubOutputGroupLibrary as HubOutputGroupLibraryModel
from dnv_bladed_models.mounting_points import MountingPoints
from dnv_bladed_models.mounting_points import MountingPoints as MountingPointsModel
from dnv_bladed_models.spinner import Spinner
from dnv_bladed_models.spinner import Spinner as SpinnerModel
from .schema_helper import SchemaHelper
from .base_entity import *


class Hub_RotationDirectionEnum(str, Enum):
    CLOCKWISE_VIEWED_FROM_FRONT = "CLOCKWISE_VIEWED_FROM_FRONT"
    ANTICLOCKWISE_VIEWED_FROM_FRONT = "ANTICLOCKWISE_VIEWED_FROM_FRONT"

class Hub_UpwindOrDownwindEnum(str, Enum):
    UPWIND = "UPWIND"
    DOWNWIND = "DOWNWIND"



class Hub(Component, ABC):
    r"""
    The common properties shared by all hubs.
    
    Attributes
    ----------
    RotationDirection : Hub_RotationDirectionEnum
        The rotational sense of rotor when viewed from upwind.
    
    UpwindOrDownwind : Hub_UpwindOrDownwindEnum
        Whether the turbine is an upwind turbine (where the rotor is upwind of the nacelle) or a downwind turbine (where the rotor is downwind of the nacelle).
    
    MountingPoints : MountingPoints
    
    ExtensionPieces : ExtensionPieces
    
    MassProperties : HubMassProperties
    
    Spinner : Spinner
    
    ConnectableNodes : HubConnectableNodes, Not supported yet
    
    OutputGroups : HubOutputGroupLibrary, Not supported yet
    
    Notes
    -----
    
    """

    RotationDirection: Hub_RotationDirectionEnum = Field(alias="RotationDirection", default=None)
    r"""
    The rotational sense of rotor when viewed from upwind.
    """

    UpwindOrDownwind: Hub_UpwindOrDownwindEnum = Field(alias="UpwindOrDownwind", default=None)
    r"""
    Whether the turbine is an upwind turbine (where the rotor is upwind of the nacelle) or a downwind turbine (where the rotor is downwind of the nacelle).
    """

    MountingPoints: MountingPointsModel = Field(alias="MountingPoints", default=None)
    r"""
    """

    ExtensionPieces: ExtensionPiecesModel = Field(alias="ExtensionPieces", default=None)
    r"""
    """

    MassProperties: HubMassPropertiesModel = Field(alias="MassProperties", default=None)
    r"""
    """

    Spinner: SpinnerModel = Field(alias="Spinner", default=None)
    r"""
    """

    ConnectableNodes: HubConnectableNodesModel = Field(alias="ConnectableNodes", default_factory=HubConnectableNodes) # Not supported yet
    r"""

    *Not supported yet*

    """

    OutputGroups: HubOutputGroupLibraryModel = Field(alias="OutputGroups", default_factory=HubOutputGroupLibrary) # Not supported yet
    r"""

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['ConnectableNodes', 'OutputGroups', ]), None).merge(Component._type_info)

Hub.model_rebuild()
