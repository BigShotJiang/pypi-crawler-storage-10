# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.initial_condition import InitialCondition
from dnv_bladed_models.initial_condition import InitialCondition as InitialConditionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class InitialConditionInsert(BaseEntity):
    r"""
    A InitialCondition is to be inserted from an external resource. The exact type of InitialCondition is not currently known.
    
    Attributes
    ----------
    InitialConditionType : Literal['Insert'], default='Insert'
        For internal use when reading & writing JSON.
    
    insert : str
        A path to a resource from which a valid JSON model object can be resolved. All properties will be taken from the resolved object; no properties can be specified in-line.

    Notes
    -----
    
    """

    InitialConditionType: Literal['Insert'] = Field(alias="InitialConditionType", default='Insert', frozen=True) # type: ignore
    r"""
    For internal use when reading & writing JSON.
    - default = 'Insert'
    """

    insert: str = Field(alias="$insert", default=None)
    r"""
    A path to a resource from which a valid JSON model object can be resolved. All properties will be taken from the resolved object; no properties can be specified in-line.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(BaseEntity._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    @property
    def is_insert(self) -> bool:
        """
        Returns true if the model is to be loaded from an external resource by the Bladed application; i.e. the 'insert' field is set with a resource location.
        """
        return True


    def _entity(self) -> bool:
        return True


InitialConditionInsert.model_rebuild()
