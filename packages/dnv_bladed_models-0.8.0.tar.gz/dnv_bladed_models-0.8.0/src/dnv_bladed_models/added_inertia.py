# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *


class AddedInertia_AddedInertiaTypeEnum(str, Enum):
    POINT_INERTIA = "PointInertia"
    SIX_BY_SIX_INERTIA = "SixBySixInertia"
    INSERT = "Insert"



class AddedInertia(BladedModel, ABC):
    r"""
    The common properties of inertias added to the tower component.
    
    Attributes
    ----------
    AddedInertiaType : AddedInertia_AddedInertiaTypeEnum
        Defines the specific type of model in use.
    
    IgnoreGravityLoads : bool, default=False
        If true, the loads due to gravity on this inertia will be ignored.
    
    HeightUpTower : float, default=0
        The height measured from the bottom of the tower, assuming that the tower is mounted vertically.
    
    SnapToNearestNode : bool
        If true, the inertias will be added to the nearest structural node, which may be at a significantly different height to that specified.
    
    Notes
    -----
    
    This class is an abstraction, with the following concrete implementations:
        - AddedInertiaInsert
        - PointInertia
        - SixBySixInertia
    
    """

    AddedInertiaType: AddedInertia_AddedInertiaTypeEnum = Field(alias="AddedInertiaType", default=None)
    r"""
    Defines the specific type of model in use.
    """

    IgnoreGravityLoads: bool = Field(alias="IgnoreGravityLoads", default=None)
    r"""
    If true, the loads due to gravity on this inertia will be ignored.
    - default = False
    """

    HeightUpTower: float = Field(alias="HeightUpTower", default=None)
    r"""
    The height measured from the bottom of the tower, assuming that the tower is mounted vertically.
    - default = 0
    """

    SnapToNearestNode: bool = Field(alias="SnapToNearestNode", default=None)
    r"""
    If true, the inertias will be added to the nearest structural node, which may be at a significantly different height to that specified.
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)

AddedInertia.model_rebuild()
