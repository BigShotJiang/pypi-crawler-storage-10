# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.hub import Hub
from dnv_bladed_models.hub import Hub as HubModel
from dnv_bladed_models.rotor_imbalances import RotorImbalances
from dnv_bladed_models.rotor_imbalances import RotorImbalances as RotorImbalancesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class StandardHub(Hub, ABC):
    r"""
    The common properties of hubs with rotational symmetry and more than two blades.
    
    Attributes
    ----------
    NumberOfBlades : int
        The number of blades on the hub.
    
    Imbalances : RotorImbalances
    
    Notes
    -----
    
    """

    NumberOfBlades: int = Field(alias="NumberOfBlades", default=None)
    r"""
    The number of blades on the hub.
    """

    Imbalances: RotorImbalancesModel = Field(alias="Imbalances", default=None)
    r"""
    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Hub._type_info)

StandardHub.model_rebuild()
