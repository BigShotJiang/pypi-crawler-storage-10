# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.height_up_tower_vs_cd_cm import HeightUpTowerVsCdCm
from dnv_bladed_models.height_up_tower_vs_cd_cm import HeightUpTowerVsCdCm as HeightUpTowerVsCdCmModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TowerHydrodynamicProperties(BladedModel):
    r"""
    The hydrodynamic properties of the tower, if fully or partly submerged in water.
    
    Not supported yet.
    
    Attributes
    ----------
    CoefficientOfDrag : float, default=1.12, Not supported yet
        The coefficient of drag for the entire tower.
    
    CoefficientOfMass : float, Not supported yet
        The coefficient of added mass for the tower.
    
    HeightUpTowerVsCdCm : List[HeightUpTowerVsCdCm], Not supported yet
        A look-up table for the hydrodynamic properties of the tower at different heights.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    CoefficientOfDrag: float = Field(alias="CoefficientOfDrag", default=None) # Not supported yet
    r"""
    The coefficient of drag for the entire tower.

    *Not supported yet*

    - default = 1.12
    """

    CoefficientOfMass: float = Field(alias="CoefficientOfMass", default=None) # Not supported yet
    r"""
    The coefficient of added mass for the tower.

    *Not supported yet*

    """

    HeightUpTowerVsCdCm: List[HeightUpTowerVsCdCmModel] = Field(alias="HeightUpTowerVsCdCm", default_factory=list) # Not supported yet
    r"""
    A look-up table for the hydrodynamic properties of the tower at different heights.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Tower/TowerHydrodynamicProperties/TowerHydrodynamicProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['HeightUpTowerVsCdCm',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TowerHydrodynamicProperties.model_rebuild()
