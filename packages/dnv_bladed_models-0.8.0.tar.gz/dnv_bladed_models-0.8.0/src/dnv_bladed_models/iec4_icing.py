# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.iced_condition import IcedCondition
from dnv_bladed_models.iced_condition import IcedCondition as IcedConditionModel
from .schema_helper import SchemaHelper
from .base_entity import *




class IEC4Icing(IcedCondition):
    r"""
    The initial condition of a blade being iced according to the IEC4 standards.  This will remain unchanged throughout the simulation.
    
    Not supported yet.
    
    Attributes
    ----------
    InitialConditionType : Literal['IEC4Icing'], default='IEC4Icing', Not supported yet
        Defines the specific type of InitialCondition model in use.  For a `IEC4Icing` object, this must always be set to a value of `IEC4Icing`.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    InitialConditionType: Literal['IEC4Icing'] = Field(alias="InitialConditionType", default='IEC4Icing', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of InitialCondition model in use.  For a `IEC4Icing` object, this must always be set to a value of `IEC4Icing`.

    *Not supported yet*

    - default = 'IEC4Icing'
    """

    _relative_schema_path: str = 'TimeDomainSimulation/InitialCondition/IEC4Icing.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'InitialConditionType').merge(IcedCondition._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


IEC4Icing.model_rebuild()
