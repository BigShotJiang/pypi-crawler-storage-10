# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.wave_diffraction_approximation import WaveDiffractionApproximation
from dnv_bladed_models.wave_diffraction_approximation import WaveDiffractionApproximation as WaveDiffractionApproximationModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SimpleCutoffFrequency(WaveDiffractionApproximation):
    r"""
    The MacCamy-Fuchs methodology will be used, with the member diameter automatically determined from the model.
    
    Not supported yet.
    
    Attributes
    ----------
    WaveDiffractionApproximationType : Literal['SimpleCutoffFrequency'], default='SimpleCutoffFrequency', Not supported yet
        Defines the specific type of WaveDiffractionApproximation model in use.  For a `SimpleCutoffFrequency` object, this must always be set to a value of `SimpleCutoffFrequency`.
    
    CutoffFrequency : float, Not supported yet
        A threshold to cut off high frequency wave particle kinematics for calculating applied forces.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    WaveDiffractionApproximationType: Literal['SimpleCutoffFrequency'] = Field(alias="WaveDiffractionApproximationType", default='SimpleCutoffFrequency', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of WaveDiffractionApproximation model in use.  For a `SimpleCutoffFrequency` object, this must always be set to a value of `SimpleCutoffFrequency`.

    *Not supported yet*

    - default = 'SimpleCutoffFrequency'
    """

    CutoffFrequency: float = Field(alias="CutoffFrequency", default=None) # Not supported yet
    r"""
    A threshold to cut off high frequency wave particle kinematics for calculating applied forces.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Waves/WaveDiffractionApproximation/SimpleCutoffFrequency.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'WaveDiffractionApproximationType').merge(WaveDiffractionApproximation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SimpleCutoffFrequency.model_rebuild()
