# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class MeanderingWake(BladedModel):
    r"""
    The parameters governing the meandering of the upwind turbine wake.
    
    Attributes
    ----------
    MeanderingWindFile : str
        A filepath or URI containing low pass filtered wind data that is used to determine the meandering of the wake centreline.
    
    FractionalAmbientVelocity : float, default=0.8
        The longitudinal velocity at which the wake travels relative to the ambient longitudinal wind speed.
    
    Notes
    -----
    
    """

    MeanderingWindFile: str = Field(alias="MeanderingWindFile", default=None)
    r"""
    A filepath or URI containing low pass filtered wind data that is used to determine the meandering of the wake centreline.
    """

    FractionalAmbientVelocity: float = Field(alias="FractionalAmbientVelocity", default=None)
    r"""
    The longitudinal velocity at which the wake travels relative to the ambient longitudinal wind speed.
    - default = 0.8
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/DynamicUpstreamWake/MeanderingWake/MeanderingWake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


MeanderingWake.model_rebuild()
