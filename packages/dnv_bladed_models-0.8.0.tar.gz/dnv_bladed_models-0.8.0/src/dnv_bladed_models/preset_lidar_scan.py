# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.lidar_scanning_pattern import LidarScanningPattern
from dnv_bladed_models.lidar_scanning_pattern import LidarScanningPattern as LidarScanningPatternModel
from .schema_helper import SchemaHelper
from .base_entity import *


class PresetLidarScan_BeamSamplingEnum(str, Enum):
    SIMULTANEOUS = "Simultaneous"
    SEQUENTIAL = "Sequential"



class PresetLidarScan(LidarScanningPattern, ABC):
    r"""
    the common properties of scan patterns which are set by the Lidar, rather than controlled in realtime by the turbine's controller.
    
    Not supported yet.
    
    Attributes
    ----------
    SamplesPerScan : int, default=1, Not supported yet
        The number of samples taken during a complete scan.
    
    LidarInterval : float, Not supported yet
        The time interval between scans.  Note that all fossing distances will be sampled at the same time.
    
    BeamSampling : PresetLidarScan_BeamSamplingEnum, Not supported yet
        The method of how each beam is sampled - whether is is simultaneously, or in sequence.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    SamplesPerScan: int = Field(alias="SamplesPerScan", default=None) # Not supported yet
    r"""
    The number of samples taken during a complete scan.

    *Not supported yet*

    - default = 1
    """

    LidarInterval: float = Field(alias="LidarInterval", default=None) # Not supported yet
    r"""
    The time interval between scans.  Note that all fossing distances will be sampled at the same time.

    *Not supported yet*

    """

    BeamSampling: PresetLidarScan_BeamSamplingEnum = Field(alias="BeamSampling", default=None) # Not supported yet
    r"""
    The method of how each beam is sampled - whether is is simultaneously, or in sequence.

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(LidarScanningPattern._type_info)

PresetLidarScan.model_rebuild()
