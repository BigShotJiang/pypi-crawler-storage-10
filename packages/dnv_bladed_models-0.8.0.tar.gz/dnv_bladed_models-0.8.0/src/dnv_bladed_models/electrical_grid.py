# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.grid_loss_energy_sink import GridLossEnergySink
from dnv_bladed_models.grid_loss_energy_sink import GridLossEnergySink as GridLossEnergySinkModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ElectricalGrid(BladedModel):
    r"""
    The definition of the electrical grid that the turbine is connected to.
    
    Not supported yet.
    
    Attributes
    ----------
    NetworkVoltage : float, Not supported yet
        The voltage of the local network.
    
    ConnectingLineResistance : float, Not supported yet
        The resistance of the line that connects the turbine to the local network.
    
    ConnectingLineInductance : float, Not supported yet
        The inductance of the line that connects the turbine to the local network.
    
    NetworkResistance : float, Not supported yet
        The resistance of the network that the turbine is connected to.
    
    NetworkInductance : float, Not supported yet
        The inductance of the network that the turbine is connected to.
    
    NumberOfTurbinesOnFarm : int, Not supported yet
        The number of turbines on the farm that share the same grid connection.
    
    GridLossEnergySinks : List[GridLossEnergySink], Not supported yet
        A list of energy sinks available to the turbine.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    NetworkVoltage: float = Field(alias="NetworkVoltage", default=None) # Not supported yet
    r"""
    The voltage of the local network.

    *Not supported yet*

    """

    ConnectingLineResistance: float = Field(alias="ConnectingLineResistance", default=None) # Not supported yet
    r"""
    The resistance of the line that connects the turbine to the local network.

    *Not supported yet*

    """

    ConnectingLineInductance: float = Field(alias="ConnectingLineInductance", default=None) # Not supported yet
    r"""
    The inductance of the line that connects the turbine to the local network.

    *Not supported yet*

    """

    NetworkResistance: float = Field(alias="NetworkResistance", default=None) # Not supported yet
    r"""
    The resistance of the network that the turbine is connected to.

    *Not supported yet*

    """

    NetworkInductance: float = Field(alias="NetworkInductance", default=None) # Not supported yet
    r"""
    The inductance of the network that the turbine is connected to.

    *Not supported yet*

    """

    NumberOfTurbinesOnFarm: int = Field(alias="NumberOfTurbinesOnFarm", default=None) # Not supported yet
    r"""
    The number of turbines on the farm that share the same grid connection.

    *Not supported yet*

    """

    GridLossEnergySinks: List[GridLossEnergySinkModel] = Field(alias="GridLossEnergySinks", default_factory=list) # Not supported yet
    r"""
    A list of energy sinks available to the turbine.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/ElectricalGrid/ElectricalGrid.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['GridLossEnergySinks',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ElectricalGrid.model_rebuild()
