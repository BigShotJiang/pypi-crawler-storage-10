# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.added_inertia import AddedInertia
from dnv_bladed_models.added_inertia import AddedInertia as AddedInertiaModel
from .schema_helper import SchemaHelper
from .base_entity import *




class SixBySixInertia(AddedInertia):
    r"""
    An inertia added to a structural component specified with a 6x6 inertia matrix.
    
    Attributes
    ----------
    AddedInertiaType : Literal['SixBySixInertia'], default='SixBySixInertia'
        Defines the specific type of AddedInertia model in use.  For a `SixBySixInertia` object, this must always be set to a value of `SixBySixInertia`.
    
    Inertia : List[List[float]]
        A 6x6 matrix of the linear and rotational inertias of an object.
    
    Notes
    -----
    
    """

    AddedInertiaType: Literal['SixBySixInertia'] = Field(alias="AddedInertiaType", default='SixBySixInertia', frozen=True) # type: ignore
    r"""
    Defines the specific type of AddedInertia model in use.  For a `SixBySixInertia` object, this must always be set to a value of `SixBySixInertia`.
    - default = 'SixBySixInertia'
    """

    Inertia: List[List[float]] = Field(alias="Inertia", default_factory=list)
    r"""
    A 6x6 matrix of the linear and rotational inertias of an object.
    """

    _relative_schema_path: str = 'Components/Tower/AddedInertia/SixBySixInertia.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['Inertia',]), 'AddedInertiaType').merge(AddedInertia._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


SixBySixInertia.model_rebuild()
