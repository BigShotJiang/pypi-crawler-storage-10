# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.signal_properties_acceleration import SignalPropertiesAcceleration
from dnv_bladed_models.signal_properties_acceleration import SignalPropertiesAcceleration as SignalPropertiesAccelerationModel
from dnv_bladed_models.signal_properties_angle import SignalPropertiesAngle
from dnv_bladed_models.signal_properties_angle import SignalPropertiesAngle as SignalPropertiesAngleModel
from dnv_bladed_models.signal_properties_angular_acceleration import SignalPropertiesAngularAcceleration
from dnv_bladed_models.signal_properties_angular_acceleration import SignalPropertiesAngularAcceleration as SignalPropertiesAngularAccelerationModel
from dnv_bladed_models.signal_properties_angular_velocity import SignalPropertiesAngularVelocity
from dnv_bladed_models.signal_properties_angular_velocity import SignalPropertiesAngularVelocity as SignalPropertiesAngularVelocityModel
from dnv_bladed_models.signal_properties_force import SignalPropertiesForce
from dnv_bladed_models.signal_properties_force import SignalPropertiesForce as SignalPropertiesForceModel
from dnv_bladed_models.signal_properties_length import SignalPropertiesLength
from dnv_bladed_models.signal_properties_length import SignalPropertiesLength as SignalPropertiesLengthModel
from dnv_bladed_models.signal_properties_moment import SignalPropertiesMoment
from dnv_bladed_models.signal_properties_moment import SignalPropertiesMoment as SignalPropertiesMomentModel
from dnv_bladed_models.signal_properties_power import SignalPropertiesPower
from dnv_bladed_models.signal_properties_power import SignalPropertiesPower as SignalPropertiesPowerModel
from dnv_bladed_models.signal_properties_velocity import SignalPropertiesVelocity
from dnv_bladed_models.signal_properties_velocity import SignalPropertiesVelocity as SignalPropertiesVelocityModel
from .schema_helper import SchemaHelper
from .base_entity import *




class MeasuredSignalProperties(BladedModel):
    r"""
    The noise and transducer properties for those signals representing values coming from a physical sensor.
    
    Not supported yet.
    
    Attributes
    ----------
    RandomNumberSeed : int, default=0, Not supported yet
        A seed for the random number generator to ensure that subsequent runs have identical noise signatures.
    
    TurnOffNoise : bool, default=False, Not supported yet
        This allows the noise to be turned off globally.  Note: this turns off noise, but keeps discretisation, sampling time, faults and transducer behaviour.
    
    ShaftPowerSignals : SignalPropertiesPower, Not supported yet
    
    RotorSpeedSignals : SignalPropertiesAngularVelocity, Not supported yet
    
    ElectricalPowerOutputSignals : SignalPropertiesPower, Not supported yet
    
    GeneratorSpeedSignals : SignalPropertiesAngularVelocity, Not supported yet
    
    GeneratorTorqueSignals : SignalPropertiesMoment, Not supported yet
    
    YawBearingAngularPositionSignals : SignalPropertiesAngle, Not supported yet
    
    YawBearingAngularVelocitySignals : SignalPropertiesAngularVelocity, Not supported yet
    
    YawBearingAngularAccelerationSignals : SignalPropertiesAngularAcceleration, Not supported yet
    
    YawMotorRateSignals : SignalPropertiesAngularVelocity, Not supported yet
    
    YawErrorSignals : SignalPropertiesAngle, Not supported yet
    
    NacelleAngleFromNorthSignals : SignalPropertiesAngle, Not supported yet
    
    TowerTopForeAftAccelerationSignals : SignalPropertiesAcceleration, Not supported yet
    
    TowerTopSideSideAccelerationSignals : SignalPropertiesAcceleration, Not supported yet
    
    ShaftTorqueSignals : SignalPropertiesMoment, Not supported yet
    
    YawBearingMySignals : SignalPropertiesMoment, Not supported yet
    
    YawBearingMzSignals : SignalPropertiesMoment, Not supported yet
    
    NacelleRollAngleSignals : SignalPropertiesAngle, Not supported yet
    
    NacelleNoddingAngleSignals : SignalPropertiesAngle, Not supported yet
    
    NacelleRollAccelerationSignals : SignalPropertiesAngularAcceleration, Not supported yet
    
    NacelleNoddingAccelerationSignals : SignalPropertiesAngularAcceleration, Not supported yet
    
    NacelleYawAccelerationSignals : SignalPropertiesAngularAcceleration, Not supported yet
    
    RotorAzimuthAngleSignals : SignalPropertiesAngle, Not supported yet
    
    NominalHubFlowSpeedSignals : SignalPropertiesVelocity, Not supported yet
    
    RotatingHubMySignals : SignalPropertiesMoment, Not supported yet
    
    RotatingHubMzSignals : SignalPropertiesMoment, Not supported yet
    
    FixedHubMySignals : SignalPropertiesMoment, Not supported yet
    
    FixedHubMzSignals : SignalPropertiesMoment, Not supported yet
    
    FixedHubFxSignals : SignalPropertiesForce, Not supported yet
    
    FixedHubFySignals : SignalPropertiesForce, Not supported yet
    
    FixedHubFzSignals : SignalPropertiesForce, Not supported yet
    
    PitchAngleSignals : SignalPropertiesAngle, Not supported yet
    
    PitchRateSignals : SignalPropertiesAngularVelocity, Not supported yet
    
    PitchActuatorTorqueSignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingFrictionSignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingStictionSignals : SignalPropertiesMoment, Not supported yet
    
    BladeOutOfPlaneBendingMomentSignals : SignalPropertiesMoment, Not supported yet
    
    BladeInPlaneBendingMomentSignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingMxSignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingMySignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingMzSignals : SignalPropertiesMoment, Not supported yet
    
    PitchBearingRadialForceSignals : SignalPropertiesForce, Not supported yet
    
    PitchBearingAxialForceSignals : SignalPropertiesForce, Not supported yet
    
    PitchBearingFxSignals : SignalPropertiesForce, Not supported yet
    
    PitchBearingFySignals : SignalPropertiesForce, Not supported yet
    
    BladeStationWindSpeedSignals : SignalPropertiesVelocity, Not supported yet
    
    BladeStationAngleOfAttackSignals : SignalPropertiesAngle, Not supported yet
    
    AileronAngleSignals : SignalPropertiesAngle, Not supported yet
    
    AileronRateSignals : SignalPropertiesAngularVelocity, Not supported yet
    
    BladeStationPositionXSignals : SignalPropertiesLength, Not supported yet
    
    BladeStationPositionYSignals : SignalPropertiesLength, Not supported yet
    
    BladeStationPositionZSignals : SignalPropertiesLength, Not supported yet
    
    BladeStationPositionXRotationSignals : SignalPropertiesAngle, Not supported yet
    
    BladeStationPositionYRotationSignals : SignalPropertiesAngle, Not supported yet
    
    BladeStationPositionZRotationSignals : SignalPropertiesAngle, Not supported yet
    
    LidarBeamFocalPointVelocitySignals : SignalPropertiesVelocity, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    RandomNumberSeed: int = Field(alias="RandomNumberSeed", default=None) # Not supported yet
    r"""
    A seed for the random number generator to ensure that subsequent runs have identical noise signatures.

    *Not supported yet*

    - default = 0
    """

    TurnOffNoise: bool = Field(alias="TurnOffNoise", default=None) # Not supported yet
    r"""
    This allows the noise to be turned off globally.  Note: this turns off noise, but keeps discretisation, sampling time, faults and transducer behaviour.

    *Not supported yet*

    - default = False
    """

    ShaftPowerSignals: SignalPropertiesPowerModel = Field(alias="ShaftPowerSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    RotorSpeedSignals: SignalPropertiesAngularVelocityModel = Field(alias="RotorSpeedSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    ElectricalPowerOutputSignals: SignalPropertiesPowerModel = Field(alias="ElectricalPowerOutputSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    GeneratorSpeedSignals: SignalPropertiesAngularVelocityModel = Field(alias="GeneratorSpeedSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    GeneratorTorqueSignals: SignalPropertiesMomentModel = Field(alias="GeneratorTorqueSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawBearingAngularPositionSignals: SignalPropertiesAngleModel = Field(alias="YawBearingAngularPositionSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawBearingAngularVelocitySignals: SignalPropertiesAngularVelocityModel = Field(alias="YawBearingAngularVelocitySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawBearingAngularAccelerationSignals: SignalPropertiesAngularAccelerationModel = Field(alias="YawBearingAngularAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawMotorRateSignals: SignalPropertiesAngularVelocityModel = Field(alias="YawMotorRateSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawErrorSignals: SignalPropertiesAngleModel = Field(alias="YawErrorSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleAngleFromNorthSignals: SignalPropertiesAngleModel = Field(alias="NacelleAngleFromNorthSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    TowerTopForeAftAccelerationSignals: SignalPropertiesAccelerationModel = Field(alias="TowerTopForeAftAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    TowerTopSideSideAccelerationSignals: SignalPropertiesAccelerationModel = Field(alias="TowerTopSideSideAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    ShaftTorqueSignals: SignalPropertiesMomentModel = Field(alias="ShaftTorqueSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawBearingMySignals: SignalPropertiesMomentModel = Field(alias="YawBearingMySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    YawBearingMzSignals: SignalPropertiesMomentModel = Field(alias="YawBearingMzSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleRollAngleSignals: SignalPropertiesAngleModel = Field(alias="NacelleRollAngleSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleNoddingAngleSignals: SignalPropertiesAngleModel = Field(alias="NacelleNoddingAngleSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleRollAccelerationSignals: SignalPropertiesAngularAccelerationModel = Field(alias="NacelleRollAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleNoddingAccelerationSignals: SignalPropertiesAngularAccelerationModel = Field(alias="NacelleNoddingAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NacelleYawAccelerationSignals: SignalPropertiesAngularAccelerationModel = Field(alias="NacelleYawAccelerationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    RotorAzimuthAngleSignals: SignalPropertiesAngleModel = Field(alias="RotorAzimuthAngleSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NominalHubFlowSpeedSignals: SignalPropertiesVelocityModel = Field(alias="NominalHubFlowSpeedSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    RotatingHubMySignals: SignalPropertiesMomentModel = Field(alias="RotatingHubMySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    RotatingHubMzSignals: SignalPropertiesMomentModel = Field(alias="RotatingHubMzSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    FixedHubMySignals: SignalPropertiesMomentModel = Field(alias="FixedHubMySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    FixedHubMzSignals: SignalPropertiesMomentModel = Field(alias="FixedHubMzSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    FixedHubFxSignals: SignalPropertiesForceModel = Field(alias="FixedHubFxSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    FixedHubFySignals: SignalPropertiesForceModel = Field(alias="FixedHubFySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    FixedHubFzSignals: SignalPropertiesForceModel = Field(alias="FixedHubFzSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchAngleSignals: SignalPropertiesAngleModel = Field(alias="PitchAngleSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchRateSignals: SignalPropertiesAngularVelocityModel = Field(alias="PitchRateSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchActuatorTorqueSignals: SignalPropertiesMomentModel = Field(alias="PitchActuatorTorqueSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingFrictionSignals: SignalPropertiesMomentModel = Field(alias="PitchBearingFrictionSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingStictionSignals: SignalPropertiesMomentModel = Field(alias="PitchBearingStictionSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeOutOfPlaneBendingMomentSignals: SignalPropertiesMomentModel = Field(alias="BladeOutOfPlaneBendingMomentSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeInPlaneBendingMomentSignals: SignalPropertiesMomentModel = Field(alias="BladeInPlaneBendingMomentSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingMxSignals: SignalPropertiesMomentModel = Field(alias="PitchBearingMxSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingMySignals: SignalPropertiesMomentModel = Field(alias="PitchBearingMySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingMzSignals: SignalPropertiesMomentModel = Field(alias="PitchBearingMzSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingRadialForceSignals: SignalPropertiesForceModel = Field(alias="PitchBearingRadialForceSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingAxialForceSignals: SignalPropertiesForceModel = Field(alias="PitchBearingAxialForceSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingFxSignals: SignalPropertiesForceModel = Field(alias="PitchBearingFxSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    PitchBearingFySignals: SignalPropertiesForceModel = Field(alias="PitchBearingFySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationWindSpeedSignals: SignalPropertiesVelocityModel = Field(alias="BladeStationWindSpeedSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationAngleOfAttackSignals: SignalPropertiesAngleModel = Field(alias="BladeStationAngleOfAttackSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    AileronAngleSignals: SignalPropertiesAngleModel = Field(alias="AileronAngleSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    AileronRateSignals: SignalPropertiesAngularVelocityModel = Field(alias="AileronRateSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionXSignals: SignalPropertiesLengthModel = Field(alias="BladeStationPositionXSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionYSignals: SignalPropertiesLengthModel = Field(alias="BladeStationPositionYSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionZSignals: SignalPropertiesLengthModel = Field(alias="BladeStationPositionZSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionXRotationSignals: SignalPropertiesAngleModel = Field(alias="BladeStationPositionXRotationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionYRotationSignals: SignalPropertiesAngleModel = Field(alias="BladeStationPositionYRotationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    BladeStationPositionZRotationSignals: SignalPropertiesAngleModel = Field(alias="BladeStationPositionZRotationSignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    LidarBeamFocalPointVelocitySignals: SignalPropertiesVelocityModel = Field(alias="LidarBeamFocalPointVelocitySignals", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/MeasuredSignalProperties/MeasuredSignalProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


MeasuredSignalProperties.model_rebuild()
