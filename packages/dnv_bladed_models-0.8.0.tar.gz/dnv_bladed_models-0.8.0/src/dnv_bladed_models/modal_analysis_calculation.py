# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.steady_calculation import SteadyCalculation
from dnv_bladed_models.steady_calculation import SteadyCalculation as SteadyCalculationModel
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs
from dnv_bladed_models.steady_calculation_outputs import SteadyCalculationOutputs as SteadyCalculationOutputsModel
from .schema_helper import SchemaHelper
from .base_entity import *




class ModalAnalysisCalculation(SteadyCalculation):
    r"""
    Defines a modal calculation.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['ModalAnalysis'], default='ModalAnalysis'
        Defines the specific type of SteadyCalculation model in use.  For a `ModalAnalysis` object, this must always be set to a value of `ModalAnalysis`.
    
    Outputs : SteadyCalculationOutputs
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['ModalAnalysis'] = Field(alias="SteadyCalculationType", default='ModalAnalysis', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `ModalAnalysis` object, this must always be set to a value of `ModalAnalysis`.
    - default = 'ModalAnalysis'
    """

    Outputs: SteadyCalculationOutputsModel = Field(alias="Outputs", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/ModalAnalysisCalculation.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyCalculationType').merge(SteadyCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


ModalAnalysisCalculation.model_rebuild()
