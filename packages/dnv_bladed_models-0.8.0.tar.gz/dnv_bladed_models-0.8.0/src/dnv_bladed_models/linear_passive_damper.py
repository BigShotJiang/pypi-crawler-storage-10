# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.damper import Damper
from dnv_bladed_models.damper import Damper as DamperModel
from dnv_bladed_models.vector3_d import Vector3D
from dnv_bladed_models.vector3_d import Vector3D as Vector3DModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LinearPassiveDamper(Damper):
    r"""
    A linear vibration damper to add to the support structure.
    
    Not supported yet.
    
    Attributes
    ----------
    ComponentType : Literal['LinearPassiveDamper'], default='LinearPassiveDamper', Not supported yet
        Defines the specific type of Component model in use.  For a `LinearPassiveDamper` object, this must always be set to a value of `LinearPassiveDamper`.
    
    Mass : float, Not supported yet
        The active mass of the vibration damper.
    
    Frequency : float, Not supported yet
        The peak frequency which the vibration damper responds to.
    
    Damping : float, Not supported yet
        The fraction of critical damping that the vibration damper will achive.
    
    IgnoreInModalAnalysis : bool, Not supported yet
        If true, the damper will be ignored in modal analyses.
    
    Direction : Vector3D
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    ComponentType: Literal['LinearPassiveDamper'] = Field(alias="ComponentType", default='LinearPassiveDamper', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `LinearPassiveDamper` object, this must always be set to a value of `LinearPassiveDamper`.

    *Not supported yet*

    - default = 'LinearPassiveDamper'
    """

    Mass: float = Field(alias="Mass", default=None) # Not supported yet
    r"""
    The active mass of the vibration damper.

    *Not supported yet*

    """

    Frequency: float = Field(alias="Frequency", default=None) # Not supported yet
    r"""
    The peak frequency which the vibration damper responds to.

    *Not supported yet*

    """

    Damping: float = Field(alias="Damping", default=None) # Not supported yet
    r"""
    The fraction of critical damping that the vibration damper will achive.

    *Not supported yet*

    """

    IgnoreInModalAnalysis: bool = Field(alias="IgnoreInModalAnalysis", default=None) # Not supported yet
    r"""
    If true, the damper will be ignored in modal analyses.

    *Not supported yet*

    """

    Direction: Vector3DModel = Field(alias="Direction", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Damper/LinearPassiveDamper.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(Damper._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LinearPassiveDamper.model_rebuild()
