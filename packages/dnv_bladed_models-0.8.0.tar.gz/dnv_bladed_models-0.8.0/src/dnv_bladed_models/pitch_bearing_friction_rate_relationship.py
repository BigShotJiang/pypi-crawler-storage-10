# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.rate_vs_friction_torque import RateVsFrictionTorque
from dnv_bladed_models.rate_vs_friction_torque import RateVsFrictionTorque as RateVsFrictionTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchBearingFrictionRateRelationship(BladedModel):
    r"""
    The relationship between the Coulomb friction and the rate at which the bearing is turning.
    
    Attributes
    ----------
    FrictionTorquePerUnitRate : float
        A fixed ratio between the rate at which the bearing is turning and the friction opposing the motion.
    
    RateVsFrictionTorque : List[RateVsFrictionTorque]
        A look-up table describing a non-linear relationship between the angular velocity and the corresponding friction.
    
    Notes
    -----
    
    """

    FrictionTorquePerUnitRate: float = Field(alias="FrictionTorquePerUnitRate", default=None)
    r"""
    A fixed ratio between the rate at which the bearing is turning and the friction opposing the motion.
    """

    RateVsFrictionTorque: List[RateVsFrictionTorqueModel] = Field(alias="RateVsFrictionTorque", default_factory=list)
    r"""
    A look-up table describing a non-linear relationship between the angular velocity and the corresponding friction.
    """

    _relative_schema_path: str = 'Components/PitchSystem/Friction/PitchBearingKineticFriction/PitchBearingFrictionRateRelationship/PitchBearingFrictionRateRelationship.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['RateVsFrictionTorque',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchBearingFrictionRateRelationship.model_rebuild()
