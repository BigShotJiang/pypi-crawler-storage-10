# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.event import Event
from dnv_bladed_models.event import Event as EventModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PermanentlyStuckPitchSystem(Event):
    r"""
    A pitch fault where the pitch system is stuck for the entire duration of the simulation.
    
    Not supported yet.
    
    Attributes
    ----------
    EventType : Literal['PermanentlyStuckPitchSystem'], default='PermanentlyStuckPitchSystem', Not supported yet
        Defines the specific type of Event model in use.  For a `PermanentlyStuckPitchSystem` object, this must always be set to a value of `PermanentlyStuckPitchSystem`.
    
    StuckAtAngle : float, Not supported yet
        The angle of the stuck blade.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    EventType: Literal['PermanentlyStuckPitchSystem'] = Field(alias="EventType", default='PermanentlyStuckPitchSystem', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Event model in use.  For a `PermanentlyStuckPitchSystem` object, this must always be set to a value of `PermanentlyStuckPitchSystem`.

    *Not supported yet*

    - default = 'PermanentlyStuckPitchSystem'
    """

    StuckAtAngle: float = Field(alias="StuckAtAngle", default=None) # Not supported yet
    r"""
    The angle of the stuck blade.

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Event/PermanentlyStuckPitchSystem.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'EventType').merge(Event._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PermanentlyStuckPitchSystem.model_rebuild()
