# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class HubMassProperties(BladedModel):
    r"""
    The mass properties of the hub.
    
    Attributes
    ----------
    Mass : float
        The total mass of hub including the pitch system, but excluding contribution from the blades connected to it.
    
    AxialPositionOfCentreOfGravity : float
        The hub centre of gravity, relative to intercept of blade pitch axis and drivetrain axis (the hub centre), positive direction being along drivetrain axis towards the hub.
    
    MomentOfInertiaAboutShaft : float
        The total moment of inertia of hub about the low speed shaft, including the pitch system but excluding contribution from the blades connected to it.
    
    MomentOfInertiaPerpendicularToShaft : float
        The total moment of inertia of hub perpendicular to the low speed shaft, including the pitch system but excluding contribution from the blades connected to it.
    
    Notes
    -----
    
    """

    Mass: float = Field(alias="Mass", default=None)
    r"""
    The total mass of hub including the pitch system, but excluding contribution from the blades connected to it.
    """

    AxialPositionOfCentreOfGravity: float = Field(alias="AxialPositionOfCentreOfGravity", default=None)
    r"""
    The hub centre of gravity, relative to intercept of blade pitch axis and drivetrain axis (the hub centre), positive direction being along drivetrain axis towards the hub.
    """

    MomentOfInertiaAboutShaft: float = Field(alias="MomentOfInertiaAboutShaft", default=None)
    r"""
    The total moment of inertia of hub about the low speed shaft, including the pitch system but excluding contribution from the blades connected to it.
    """

    MomentOfInertiaPerpendicularToShaft: float = Field(alias="MomentOfInertiaPerpendicularToShaft", default=None)
    r"""
    The total moment of inertia of hub perpendicular to the low speed shaft, including the pitch system but excluding contribution from the blades connected to it.
    """

    _relative_schema_path: str = 'Components/Hub/HubMassProperties/HubMassProperties.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


HubMassProperties.model_rebuild()
