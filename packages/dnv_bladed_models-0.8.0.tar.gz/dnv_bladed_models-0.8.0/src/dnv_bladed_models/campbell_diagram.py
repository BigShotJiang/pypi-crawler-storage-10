# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation
from dnv_bladed_models.campbell_diagram_mode_of_operation import CampbellDiagramModeOfOperation as CampbellDiagramModeOfOperationModel
from dnv_bladed_models.campbell_diagram_mode_of_operation_insert import CampbellDiagramModeOfOperationInsert
from dnv_bladed_models.campbell_diagram_mode_of_operation_insert import CampbellDiagramModeOfOperationInsert as CampbellDiagramModeOfOperationInsertModel
from dnv_bladed_models.campbell_diagram_perturbations import CampbellDiagramPerturbations
from dnv_bladed_models.campbell_diagram_perturbations import CampbellDiagramPerturbations as CampbellDiagramPerturbationsModel
from dnv_bladed_models.campbell_idling import CampbellIdling
from dnv_bladed_models.campbell_idling import CampbellIdling as CampbellIdlingModel
from dnv_bladed_models.campbell_parked import CampbellParked
from dnv_bladed_models.campbell_parked import CampbellParked as CampbellParkedModel
from dnv_bladed_models.campbell_power_production import CampbellPowerProduction
from dnv_bladed_models.campbell_power_production import CampbellPowerProduction as CampbellPowerProductionModel
from dnv_bladed_models.linearisation_calculation import LinearisationCalculation
from dnv_bladed_models.linearisation_calculation import LinearisationCalculation as LinearisationCalculationModel
from .schema_helper import SchemaHelper
from .base_entity import *

TCampbellDiagramModeOfOperationOptions = TypeVar('TCampbellDiagramModeOfOperationOptions', CampbellIdling, CampbellDiagramModeOfOperationInsert, CampbellParked, CampbellPowerProduction, CampbellDiagramModeOfOperation, )



class CampbellDiagram(LinearisationCalculation):
    r"""
    Defines a calculation which produces a Campbell diagram, showing the system coupled mode frequencies and dampings at each rotor speed.
    
    Attributes
    ----------
    SteadyCalculationType : Literal['CampbellDiagram'], default='CampbellDiagram'
        Defines the specific type of SteadyCalculation model in use.  For a `CampbellDiagram` object, this must always be set to a value of `CampbellDiagram`.
    
    ModeOfOperation : Union[CampbellIdling, CampbellDiagramModeOfOperationInsert, CampbellParked, CampbellPowerProduction]
    
    MinimumCorrelationCoefficient : float, default=0.8
        The minimum acceptable correlation coefficient for the relationship between a state value and a state derivative.  If it is below the minimum, the relationship is disregarded and a zero value is taken.
    
    MaximumPlotFrequency : float, default=10
        The maximum frequency for modes to be shown in the Campbell diagram plot. The default value is 10 Hz
    
    OutputCoupledModeAnimationData : bool, default=True
        Whether to generate the additional outputs needed for the Coupled Mode Animator.
    
    Perturbations : CampbellDiagramPerturbations
    
    Notes
    -----
    
    """

    SteadyCalculationType: Literal['CampbellDiagram'] = Field(alias="SteadyCalculationType", default='CampbellDiagram', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyCalculation model in use.  For a `CampbellDiagram` object, this must always be set to a value of `CampbellDiagram`.
    - default = 'CampbellDiagram'
    """

    ModeOfOperation: Union[CampbellIdlingModel, CampbellDiagramModeOfOperationInsertModel, CampbellParkedModel, CampbellPowerProductionModel] = Field(alias="ModeOfOperation", default=None, discriminator='CampbellDiagramModeOfOperationType')
    r"""
    """

    MinimumCorrelationCoefficient: float = Field(alias="MinimumCorrelationCoefficient", default=None)
    r"""
    The minimum acceptable correlation coefficient for the relationship between a state value and a state derivative.  If it is below the minimum, the relationship is disregarded and a zero value is taken.
    - default = 0.8
    """

    MaximumPlotFrequency: float = Field(alias="MaximumPlotFrequency", default=None)
    r"""
    The maximum frequency for modes to be shown in the Campbell diagram plot. The default value is 10 Hz
    - default = 10
    """

    OutputCoupledModeAnimationData: bool = Field(alias="OutputCoupledModeAnimationData", default=None)
    r"""
    Whether to generate the additional outputs needed for the Coupled Mode Animator.
    - default = True
    """

    Perturbations: CampbellDiagramPerturbationsModel = Field(alias="Perturbations", default=None)
    r"""
    """

    _relative_schema_path: str = 'SteadyCalculation/CampbellDiagram.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([('ModeOfOperation', 'CampbellDiagramModeOfOperationType'),]), set([]), set([]), 'SteadyCalculationType').merge(LinearisationCalculation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    @property
    def ModeOfOperation_as_CampbellIdling(self) -> CampbellIdling:
        """
        Retrieves the value of ModeOfOperation guaranteeing it is a CampbellIdling; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        CampbellIdling
            A model object, guaranteed to be a CampbellIdling.

        Raises
        ------
        TypeError
            If the value is not a CampbellIdling.
        """
        return self.ModeOfOperation_as(CampbellIdling)


    @property
    def ModeOfOperation_as_CampbellParked(self) -> CampbellParked:
        """
        Retrieves the value of ModeOfOperation guaranteeing it is a CampbellParked; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        CampbellParked
            A model object, guaranteed to be a CampbellParked.

        Raises
        ------
        TypeError
            If the value is not a CampbellParked.
        """
        return self.ModeOfOperation_as(CampbellParked)


    @property
    def ModeOfOperation_as_CampbellPowerProduction(self) -> CampbellPowerProduction:
        """
        Retrieves the value of ModeOfOperation guaranteeing it is a CampbellPowerProduction; if it is not, an error is raised.

        Useful when using type-checking development tools, as it provides a concise way to retrieve a value and assign a variable with the correct type.

        Returns
        -------
        CampbellPowerProduction
            A model object, guaranteed to be a CampbellPowerProduction.

        Raises
        ------
        TypeError
            If the value is not a CampbellPowerProduction.
        """
        return self.ModeOfOperation_as(CampbellPowerProduction)


    @property
    def ModeOfOperation_as_inline(self) -> Union[CampbellIdling, CampbellParked, CampbellPowerProduction]:
        """
        Retrieves the value of ModeOfOperation as a model object; if the value is specified with a '$insert', an error is raised.

        Returns
        -------
        Union[CampbellIdling, CampbellParked, CampbellPowerProduction]
            A model object at the specified index, guaranteed to not be a '$insert'.

        Raises
        ------
        TypeError
            If the value is not one of the concrete types of CampbellDiagramModeOfOperation; i.e. it is specified with a '$insert'.
        """
        if isinstance(self.ModeOfOperation, CampbellDiagramModeOfOperationInsert) or self.ModeOfOperation.is_insert:
            raise TypeError(f"Expected ModeOfOperation value to be an in-line object, but it is currently in the '$insert' state.")
        return self.ModeOfOperation


    def ModeOfOperation_as(self, cls: Type[TCampbellDiagramModeOfOperationOptions])-> TCampbellDiagramModeOfOperationOptions:
        """
        Retrieves the value of ModeOfOperation, ensuring it is of the specified type.
        The specified type must be one of the valid concrete types of CampbellDiagramModeOfOperation, or the '$insert' type
        (in the case the model is defined to be inserted from an external resource).

        Useful when using type-checking development tools, as it provides a concise way to access a value with the correct type.

        Parameters
        ----------
        cls: Type[Union[CampbellIdling, CampbellDiagramModeOfOperationInsert, CampbellParked, CampbellPowerProduction]]
            One of the valid concrete types of CampbellDiagramModeOfOperation, or the '$insert' type
            (in the case the model is defined to be inserted from an external resource).

        Returns
        -------
        TCampbellDiagramModeOfOperationOptions
            A model object of the specified type.

        Raises
        ------
        TypeError
            If the value is not of the specified type.

        Examples
        --------
        Get a reference to the value when it is one of the types of CampbellDiagramModeOfOperation:
        >>> val_obj = model_obj.ModeOfOperation_as(models.CampbellIdling)
        >>> val_obj = model_obj.ModeOfOperation_as(models.CampbellParked)
        >>> val_obj = model_obj.ModeOfOperation_as(models.CampbellPowerProduction)

        Get a reference to the value, when it was specified with a '$insert' and read in from a file:
        >>> insert_obj = model_obj.ModeOfOperation_as(models.CampbellDiagramModeOfOperationInsert)
        """
        if not isinstance(self.ModeOfOperation, cls):
            raise TypeError(f"Expected ModeOfOperation of type '{cls.__name__}' but was type '{type(self.ModeOfOperation).__name__}'")
        return self.ModeOfOperation


    def _entity(self) -> bool:
        return True


CampbellDiagram.model_rebuild()
