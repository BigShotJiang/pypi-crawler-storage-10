# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.steady_wake_deficit import SteadyWakeDeficit
from dnv_bladed_models.steady_wake_deficit import SteadyWakeDeficit as SteadyWakeDeficitModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Gaussian(SteadyWakeDeficit):
    r"""
    A simple model for the reduced velocity of the wind behind another turbine.  This deficit will be applied across a certain region, and this region will not move around during the simulation.  The velocity deficit profile will be based on a Gaussian distribution, scaled by a maximum deficit and the radius of the region affected.
    
    Attributes
    ----------
    SteadyWakeDeficitType : Literal['Gaussian'], default='Gaussian'
        Defines the specific type of SteadyWakeDeficit model in use.  For a `Gaussian` object, this must always be set to a value of `Gaussian`.
    
    CentrelineVelocityDeficit : float
        The maximum deficit within the affected region, occurring in the centre.  1.0 or 100% would be a reduction of the wind to zero, whereas 0.0 or 0% would represent no change in the free-field wind speed.
    
    WidthOfDeficit : float
        The width of the region within which there is a velocity deficit.
    
    Notes
    -----
    
    """

    SteadyWakeDeficitType: Literal['Gaussian'] = Field(alias="SteadyWakeDeficitType", default='Gaussian', frozen=True) # type: ignore
    r"""
    Defines the specific type of SteadyWakeDeficit model in use.  For a `Gaussian` object, this must always be set to a value of `Gaussian`.
    - default = 'Gaussian'
    """

    CentrelineVelocityDeficit: float = Field(alias="CentrelineVelocityDeficit", default=None)
    r"""
    The maximum deficit within the affected region, occurring in the centre.  1.0 or 100% would be a reduction of the wind to zero, whereas 0.0 or 0% would represent no change in the free-field wind speed.
    """

    WidthOfDeficit: float = Field(alias="WidthOfDeficit", default=None)
    r"""
    The width of the region within which there is a velocity deficit.
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/SteadyWakeDeficit/Gaussian.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'SteadyWakeDeficitType').merge(SteadyWakeDeficit._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Gaussian.model_rebuild()
