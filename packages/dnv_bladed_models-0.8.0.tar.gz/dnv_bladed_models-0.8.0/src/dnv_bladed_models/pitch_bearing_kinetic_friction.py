# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.pitch_bearing_friction_rate_relationship import PitchBearingFrictionRateRelationship
from dnv_bladed_models.pitch_bearing_friction_rate_relationship import PitchBearingFrictionRateRelationship as PitchBearingFrictionRateRelationshipModel
from dnv_bladed_models.pitch_bearing_friction_xy_force_relationship import PitchBearingFrictionXYForceRelationship
from dnv_bladed_models.pitch_bearing_friction_xy_force_relationship import PitchBearingFrictionXYForceRelationship as PitchBearingFrictionXYForceRelationshipModel
from dnv_bladed_models.pitch_bearing_friction_xy_moment_relationship import PitchBearingFrictionXYMomentRelationship
from dnv_bladed_models.pitch_bearing_friction_xy_moment_relationship import PitchBearingFrictionXYMomentRelationship as PitchBearingFrictionXYMomentRelationshipModel
from dnv_bladed_models.pitch_bearing_friction_z_force_relationship import PitchBearingFrictionZForceRelationship
from dnv_bladed_models.pitch_bearing_friction_z_force_relationship import PitchBearingFrictionZForceRelationship as PitchBearingFrictionZForceRelationshipModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PitchBearingKineticFriction(BladedModel):
    r"""
    The torque resisting movement, once the bearing is in motion.
    
    Attributes
    ----------
    ConstantFriction : float, default=0
        The constant friction opposing the movement of the bearing.
    
    RelationshipWithXYMoment : PitchBearingFrictionXYMomentRelationship
    
    RelationshipWithXYForce : PitchBearingFrictionXYForceRelationship
    
    RelationshipWithZForce : PitchBearingFrictionZForceRelationship
    
    RelationshipWithRate : PitchBearingFrictionRateRelationship
    
    Notes
    -----
    
    """

    ConstantFriction: float = Field(alias="ConstantFriction", default=None)
    r"""
    The constant friction opposing the movement of the bearing.
    - default = 0
    """

    RelationshipWithXYMoment: PitchBearingFrictionXYMomentRelationshipModel = Field(alias="RelationshipWithXYMoment", default=None)
    r"""
    """

    RelationshipWithXYForce: PitchBearingFrictionXYForceRelationshipModel = Field(alias="RelationshipWithXYForce", default=None)
    r"""
    """

    RelationshipWithZForce: PitchBearingFrictionZForceRelationshipModel = Field(alias="RelationshipWithZForce", default=None)
    r"""
    """

    RelationshipWithRate: PitchBearingFrictionRateRelationshipModel = Field(alias="RelationshipWithRate", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/PitchSystem/Friction/PitchBearingKineticFriction/PitchBearingKineticFriction.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PitchBearingKineticFriction.model_rebuild()
