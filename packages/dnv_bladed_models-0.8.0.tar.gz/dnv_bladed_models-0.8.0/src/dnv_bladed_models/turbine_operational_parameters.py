# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.nominal_hub_wind_speed_vs_rotor_speed_and_pitch_angle import NominalHubWindSpeedVsRotorSpeedAndPitchAngle
from dnv_bladed_models.nominal_hub_wind_speed_vs_rotor_speed_and_pitch_angle import NominalHubWindSpeedVsRotorSpeedAndPitchAngle as NominalHubWindSpeedVsRotorSpeedAndPitchAngleModel
from dnv_bladed_models.variable_speed_pitch_regulated_control_model import VariableSpeedPitchRegulatedControlModel
from dnv_bladed_models.variable_speed_pitch_regulated_control_model import VariableSpeedPitchRegulatedControlModel as VariableSpeedPitchRegulatedControlModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class TurbineOperationalParameters(BladedModel):
    r"""
    The general operational parameters for the turbine. These are used to calculate steady state conditions for steady calculation types or initial conditions for time-domain calculation types.
    
    Attributes
    ----------
    NominalHubWindSpeedVsRotorSpeedAndPitchAngle : List[NominalHubWindSpeedVsRotorSpeedAndPitchAngle]
        User defined look-up table to define the steady state conditions of rotor speed and pitch angle over wind speed. If defined Bladed will use these values instead of trying to determine them.
    
    VariableSpeedPitchRegulatedControlModel : VariableSpeedPitchRegulatedControlModel
    
    PitchAngleWhilstIdling : float, default=1.570796326794
        The pitch angle of the blades when the turbine is idling.  The default is 90 degrees.
    
    PitchAngleWhilstParked : float, default=1.570796326794
        The pitch angle of the blades when the turbine is parked.  The default is 90 degrees.
    
    Notes
    -----
    
    """

    NominalHubWindSpeedVsRotorSpeedAndPitchAngle: List[NominalHubWindSpeedVsRotorSpeedAndPitchAngleModel] = Field(alias="NominalHubWindSpeedVsRotorSpeedAndPitchAngle", default_factory=list)
    r"""
    User defined look-up table to define the steady state conditions of rotor speed and pitch angle over wind speed. If defined Bladed will use these values instead of trying to determine them.
    """

    VariableSpeedPitchRegulatedControlModel: VariableSpeedPitchRegulatedControlModelModel = Field(alias="VariableSpeedPitchRegulatedControlModel", default=None)
    r"""
    """

    PitchAngleWhilstIdling: float = Field(alias="PitchAngleWhilstIdling", default=None)
    r"""
    The pitch angle of the blades when the turbine is idling.  The default is 90 degrees.
    - default = 1.570796326794
    """

    PitchAngleWhilstParked: float = Field(alias="PitchAngleWhilstParked", default=None)
    r"""
    The pitch angle of the blades when the turbine is parked.  The default is 90 degrees.
    - default = 1.570796326794
    """

    _relative_schema_path: str = 'Turbine/TurbineOperationalParameters/TurbineOperationalParameters.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['NominalHubWindSpeedVsRotorSpeedAndPitchAngle',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


TurbineOperationalParameters.model_rebuild()
