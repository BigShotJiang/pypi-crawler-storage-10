# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.actuator_response import ActuatorResponse
from dnv_bladed_models.actuator_response import ActuatorResponse as ActuatorResponseModel
from .schema_helper import SchemaHelper
from .base_entity import *




class InstantaneousActuatorResponse(ActuatorResponse):
    r"""
    Defines an instantaneous response to the controller's demands - effectively ignoring any pitch controller dynamics.
    
    Attributes
    ----------
    ActuatorResponseType : Literal['InstantaneousActuatorResponse'], default='InstantaneousActuatorResponse'
        Defines the specific type of ActuatorResponse model in use.  For a `InstantaneousActuatorResponse` object, this must always be set to a value of `InstantaneousActuatorResponse`.
    
    Notes
    -----
    
    """

    ActuatorResponseType: Literal['InstantaneousActuatorResponse'] = Field(alias="ActuatorResponseType", default='InstantaneousActuatorResponse', frozen=True) # type: ignore
    r"""
    Defines the specific type of ActuatorResponse model in use.  For a `InstantaneousActuatorResponse` object, this must always be set to a value of `InstantaneousActuatorResponse`.
    - default = 'InstantaneousActuatorResponse'
    """

    _relative_schema_path: str = 'Components/PitchSystem/PitchActuator/ActuatorResponse/InstantaneousActuatorResponse.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ActuatorResponseType').merge(ActuatorResponse._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


InstantaneousActuatorResponse.model_rebuild()
