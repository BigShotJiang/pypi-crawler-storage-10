# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.near_shore_current import NearShoreCurrent
from dnv_bladed_models.near_shore_current import NearShoreCurrent as NearShoreCurrentModel
from dnv_bladed_models.near_surface_current import NearSurfaceCurrent
from dnv_bladed_models.near_surface_current import NearSurfaceCurrent as NearSurfaceCurrentModel
from dnv_bladed_models.sub_surface_current import SubSurfaceCurrent
from dnv_bladed_models.sub_surface_current import SubSurfaceCurrent as SubSurfaceCurrentModel
from dnv_bladed_models.time_domain_current import TimeDomainCurrent
from dnv_bladed_models.time_domain_current import TimeDomainCurrent as TimeDomainCurrentModel
from .schema_helper import SchemaHelper
from .base_entity import *




class Currents(TimeDomainCurrent):
    r"""
    The definition of the current using simple numerical models.
    
    Not supported yet.
    
    Attributes
    ----------
    CurrentType : Literal['Currents'], default='Currents', Not supported yet
        Defines the specific type of Current model in use.  For a `Currents` object, this must always be set to a value of `Currents`.
    
    NearSurfaceCurrent : NearSurfaceCurrent, Not supported yet
    
    SubSurfaceCurrent : SubSurfaceCurrent, Not supported yet
    
    NearShoreCurrent : NearShoreCurrent, Not supported yet
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    CurrentType: Literal['Currents'] = Field(alias="CurrentType", default='Currents', frozen=True) # Not supported yet # type: ignore
    r"""
    Defines the specific type of Current model in use.  For a `Currents` object, this must always be set to a value of `Currents`.

    *Not supported yet*

    - default = 'Currents'
    """

    NearSurfaceCurrent: NearSurfaceCurrentModel = Field(alias="NearSurfaceCurrent", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    SubSurfaceCurrent: SubSurfaceCurrentModel = Field(alias="SubSurfaceCurrent", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    NearShoreCurrent: NearShoreCurrentModel = Field(alias="NearShoreCurrent", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/SeaState/Current/Currents.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'CurrentType').merge(TimeDomainCurrent._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


Currents.model_rebuild()
