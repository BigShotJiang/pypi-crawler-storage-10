# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.external_controller import ExternalController
from dnv_bladed_models.external_controller import ExternalController as ExternalControllerModel
from dnv_bladed_models.measured_signal_properties import MeasuredSignalProperties
from dnv_bladed_models.measured_signal_properties import MeasuredSignalProperties as MeasuredSignalPropertiesModel
from dnv_bladed_models.safety_system import SafetySystem
from dnv_bladed_models.safety_system import SafetySystem as SafetySystemModel
from .schema_helper import SchemaHelper
from .base_entity import *




class BladedControl(BladedModel):
    r"""
    A definition of how the turbine is controlled.
    
    Attributes
    ----------
    SignalProperties : MeasuredSignalProperties, Not supported yet
    
    ControlDiscreteTimeStep : float, default=0.1
        The minimum timestep to be used across all of the controllers.  Controllers do not need to be called on every timestep (see the 'TimeStepMultiplier' parameter, below).
    
    Controllers : List[ExternalController]
        A list of externally-defined controllers.  These will be run in the order they are specified, but can be run at different multiples of the timestep set above.  If no controllers are specified, there will be no control action taken throughout the simulation.  No control demands will be calculated or acted upon, although the rotor speed may well accelerate.  The friction of the pitch systems may also be overcome, resulting in a change in the pitch angles.
    
    SafetySystem : SafetySystem, Not supported yet
    
    Notes
    -----
    
    """

    SignalProperties: MeasuredSignalPropertiesModel = Field(alias="SignalProperties", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    ControlDiscreteTimeStep: float = Field(alias="ControlDiscreteTimeStep", default=None)
    r"""
    The minimum timestep to be used across all of the controllers.  Controllers do not need to be called on every timestep (see the 'TimeStepMultiplier' parameter, below).
    - default = 0.1
    """

    Controllers: List[ExternalControllerModel] = Field(alias="Controllers", default_factory=list)
    r"""
    A list of externally-defined controllers.  These will be run in the order they are specified, but can be run at different multiples of the timestep set above.  If no controllers are specified, there will be no control action taken throughout the simulation.  No control demands will be calculated or acted upon, although the rotor speed may well accelerate.  The friction of the pitch systems may also be overcome, resulting in a change in the pitch angles.
    """

    SafetySystem: SafetySystemModel = Field(alias="SafetySystem", default=None) # Not supported yet
    r"""

    *Not supported yet*

    """

    _relative_schema_path: str = 'Turbine/BladedControl/BladedControl.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['Controllers',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


BladedControl.model_rebuild()
