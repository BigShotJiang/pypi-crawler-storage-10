# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.standard_hub import StandardHub
from dnv_bladed_models.standard_hub import StandardHub as StandardHubModel
from .schema_helper import SchemaHelper
from .base_entity import *




class IndependentPitchHub(StandardHub):
    r"""
    A standard hub with two or more blades, and one pitch system for each blade.
    
    Attributes
    ----------
    ComponentType : Literal['IndependentPitchHub'], default='IndependentPitchHub'
        Defines the specific type of Component model in use.  For a `IndependentPitchHub` object, this must always be set to a value of `IndependentPitchHub`.
    
    Notes
    -----
    
    """

    ComponentType: Literal['IndependentPitchHub'] = Field(alias="ComponentType", default='IndependentPitchHub', frozen=True) # type: ignore
    r"""
    Defines the specific type of Component model in use.  For a `IndependentPitchHub` object, this must always be set to a value of `IndependentPitchHub`.
    - default = 'IndependentPitchHub'
    """

    _relative_schema_path: str = 'Components/Hub/IndependentPitchHub.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'ComponentType').merge(StandardHub._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


IndependentPitchHub.model_rebuild()
