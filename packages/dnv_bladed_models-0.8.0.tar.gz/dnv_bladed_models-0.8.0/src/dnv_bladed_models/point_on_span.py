# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PointOnSpan(BladedModel):
    r"""
    A position along the span of the blade, defined either in full 3D, or as if the blade had been flattened into 2D (i.e. disregarding pre-bend and pre-sweep).
    
    Attributes
    ----------
    X : float, default=0
        The offset of the point from the blade's pitch axis (the z-axis) in the blade root's X direction.
    
    Y : float, default=0
        The offset of the point from the blade's pitch axis (the z- axis) in the blade root's Y direction.
    
    Z : float
        The spanwise location of the point along the blade's pitch axis (the blade root axes' z-axis).  This is the absolute 3D position, including any pre-bend or pre-sweep.
    
    DistanceAlongSpan : float
        The spanwise location of the point along the blade's pitch axis (the blade root z-axis), as measured along the blade's reference curve, which connects the origins of each blade cross-section.  This would be the distance along the undeformed blade, should it lie flat in a plane.  This is used when the pre-bend and pre-sweep has yet to be finalised, as the PlanformDistance will remain constant for any value of X and Y.
    
    Notes
    -----
    
    """

    X: float = Field(alias="X", default=None)
    r"""
    The offset of the point from the blade's pitch axis (the z-axis) in the blade root's X direction.
    - default = 0
    """

    Y: float = Field(alias="Y", default=None)
    r"""
    The offset of the point from the blade's pitch axis (the z- axis) in the blade root's Y direction.
    - default = 0
    """

    Z: float = Field(alias="Z", default=None)
    r"""
    The spanwise location of the point along the blade's pitch axis (the blade root axes' z-axis).  This is the absolute 3D position, including any pre-bend or pre-sweep.
    """

    DistanceAlongSpan: float = Field(alias="DistanceAlongSpan", default=None)
    r"""
    The spanwise location of the point along the blade's pitch axis (the blade root z-axis), as measured along the blade's reference curve, which connects the origins of each blade cross-section.  This would be the distance along the undeformed blade, should it lie flat in a plane.  This is used when the pre-bend and pre-sweep has yet to be finalised, as the PlanformDistance will remain constant for any value of X and Y.
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/CoordinateSystems/ReferenceCoordinateSystem/PointOnSpan/PointOnSpan.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PointOnSpan.model_rebuild()
