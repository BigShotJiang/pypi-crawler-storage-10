# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.wind_direction_variation import WindDirectionVariation
from dnv_bladed_models.wind_direction_variation import WindDirectionVariation as WindDirectionVariationModel
from .schema_helper import SchemaHelper
from .base_entity import *


class PresetWindDirectionTransient_VariationShapeEnum(str, Enum):
    FULL = "FULL"
    HALF = "HALF"
    IEC_2 = "IEC-2"



class PresetWindDirectionTransient(WindDirectionVariation):
    r"""
    A preset transient in the wind direction.
    
    Attributes
    ----------
    DirectionVariationType : Literal['PresetTransient'], default='PresetTransient'
        Defines the specific type of DirectionVariation model in use.  For a `PresetTransient` object, this must always be set to a value of `PresetTransient`.
    
    DirectionAtStart : float
        The direction at the start of the simulation up to the beginning of the transient.  For a full cycle this will also be the value after the transient has completed.
    
    AmplitudeOfVariation : float
        The maximum amplitude of the variation.
    
    StartTime : float
        The time into the simulation at which to start the transient (excluding the lead-in time).
    
    DurationOfVariation : float
        The time taken to complete the transient, whether half-cycle or full-cycle.
    
    VariationShape : PresetWindDirectionTransient_VariationShapeEnum
        The shape of the transient.  This can either be a half-cycle (where the direction remains at the initial direction plus the amplitude after the transient has been completed) or a full-cycle (where the direction returns to its original value).
    
    Notes
    -----
    
    """

    DirectionVariationType: Literal['PresetTransient'] = Field(alias="DirectionVariationType", default='PresetTransient', frozen=True) # type: ignore
    r"""
    Defines the specific type of DirectionVariation model in use.  For a `PresetTransient` object, this must always be set to a value of `PresetTransient`.
    - default = 'PresetTransient'
    """

    DirectionAtStart: float = Field(alias="DirectionAtStart", default=None)
    r"""
    The direction at the start of the simulation up to the beginning of the transient.  For a full cycle this will also be the value after the transient has completed.
    """

    AmplitudeOfVariation: float = Field(alias="AmplitudeOfVariation", default=None)
    r"""
    The maximum amplitude of the variation.
    """

    StartTime: float = Field(alias="StartTime", default=None)
    r"""
    The time into the simulation at which to start the transient (excluding the lead-in time).
    """

    DurationOfVariation: float = Field(alias="DurationOfVariation", default=None)
    r"""
    The time taken to complete the transient, whether half-cycle or full-cycle.
    """

    VariationShape: PresetWindDirectionTransient_VariationShapeEnum = Field(alias="VariationShape", default=None)
    r"""
    The shape of the transient.  This can either be a half-cycle (where the direction remains at the initial direction plus the amplitude after the transient has been completed) or a full-cycle (where the direction returns to its original value).
    """

    _relative_schema_path: str = 'TimeDomainSimulation/Environment/Wind/WindDirectionVariation/PresetWindDirectionTransient.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DirectionVariationType').merge(WindDirectionVariation._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PresetWindDirectionTransient.model_rebuild()
