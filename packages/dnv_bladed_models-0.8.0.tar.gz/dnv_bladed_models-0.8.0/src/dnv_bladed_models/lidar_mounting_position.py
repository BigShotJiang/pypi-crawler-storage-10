# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class LidarMountingPosition(BladedModel):
    r"""
    The offset of the Lidar device from it's attachment point, in the component's axis system.
    
    Not supported yet.
    
    Attributes
    ----------
    X : float, Not supported yet
        The offset in the Lidar component's X direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.
    
    Y : float, Not supported yet
        The offset in the Lidar component's Y direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.
    
    Z : float, Not supported yet
        The offset in the Lidar component's Z direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    X: float = Field(alias="X", default=None) # Not supported yet
    r"""
    The offset in the Lidar component's X direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.

    *Not supported yet*

    """

    Y: float = Field(alias="Y", default=None) # Not supported yet
    r"""
    The offset in the Lidar component's Y direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.

    *Not supported yet*

    """

    Z: float = Field(alias="Z", default=None) # Not supported yet
    r"""
    The offset in the Lidar component's Z direction between the Lidar component's origin (where it attaches to the turbine structure) and the origin of the beam.

    *Not supported yet*

    """

    _relative_schema_path: str = 'Components/Lidar/LidarBeam/LidarMountingPosition/LidarMountingPosition.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


LidarMountingPosition.model_rebuild()
