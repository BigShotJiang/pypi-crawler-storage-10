# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_wake import DynamicWake
from dnv_bladed_models.dynamic_wake import DynamicWake as DynamicWakeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class FrozenWakeModel(DynamicWake):
    r"""
    The frozen wake model keeps the induction velocity from the initial conditions, and doesnâ€™t change the induction either during linearisation perturbations or in the time domain.  In linearisation this lack of response can be a good approximation to the lagged dynamic wake response.  The frozen wake approach is not appropriate in the time domain.
    
    Attributes
    ----------
    DynamicWakeType : Literal['FrozenWakeModel'], default='FrozenWakeModel'
        Defines the specific type of DynamicWake model in use.  For a `FrozenWakeModel` object, this must always be set to a value of `FrozenWakeModel`.
    
    Notes
    -----
    
    """

    DynamicWakeType: Literal['FrozenWakeModel'] = Field(alias="DynamicWakeType", default='FrozenWakeModel', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicWake model in use.  For a `FrozenWakeModel` object, this must always be set to a value of `FrozenWakeModel`.
    - default = 'FrozenWakeModel'
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/MomentumTheoryCorrections/DynamicWake/FrozenWakeModel.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicWakeType').merge(DynamicWake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


FrozenWakeModel.model_rebuild()
