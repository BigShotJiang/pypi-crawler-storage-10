# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from abc import ABC

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.waves import Waves
from dnv_bladed_models.waves import Waves as WavesModel
from .schema_helper import SchemaHelper
from .base_entity import *




class RegularWaves(Waves, ABC):
    r"""
    The definition of regular waves.
    
    Not supported yet.
    
    Attributes
    ----------
    DirectionOfApproachClockwiseFromNorth : float, Not supported yet
        The bearing from which waves arrive at the turbine.
    
    WaveHeight : float, Not supported yet
        The wave height, defined from trough to crest.
    
    Period : float, Not supported yet
        The wave period.
    
    Notes
    -----
    This model is not supported yet by the Bladed calculation engine.
    """

    DirectionOfApproachClockwiseFromNorth: float = Field(alias="DirectionOfApproachClockwiseFromNorth", default=None) # Not supported yet
    r"""
    The bearing from which waves arrive at the turbine.

    *Not supported yet*

    """

    WaveHeight: float = Field(alias="WaveHeight", default=None) # Not supported yet
    r"""
    The wave height, defined from trough to crest.

    *Not supported yet*

    """

    Period: float = Field(alias="Period", default=None) # Not supported yet
    r"""
    The wave period.

    *Not supported yet*

    """

    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(Waves._type_info)

RegularWaves.model_rebuild()
