# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class AlphaLine(BladedModel):
    r"""
    The relationship between angle of attack, and the lift and drag coefficients.
    
    Attributes
    ----------
    Angle : float
        The angle of attack for which the Cl, Cd, and Cm apply.
    
    Cl : float
        The non-dimensionalised coefficient of lift.
    
    Cd : float
        The non-dimensionalised coefficient of drag.
    
    Cm : float
        The non-dimensionalised coefficient of pitching.
    
    Notes
    -----
    
    """

    Angle: float = Field(alias="Angle", default=None)
    r"""
    The angle of attack for which the Cl, Cd, and Cm apply.
    """

    Cl: float = Field(alias="Cl", default=None)
    r"""
    The non-dimensionalised coefficient of lift.
    """

    Cd: float = Field(alias="Cd", default=None)
    r"""
    The non-dimensionalised coefficient of drag.
    """

    Cm: float = Field(alias="Cm", default=None)
    r"""
    The non-dimensionalised coefficient of pitching.
    """

    _relative_schema_path: str = 'Components/Blade/AerofoilLibrary/Aerofoil/AlphaLine/AlphaLine.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


AlphaLine.model_rebuild()
