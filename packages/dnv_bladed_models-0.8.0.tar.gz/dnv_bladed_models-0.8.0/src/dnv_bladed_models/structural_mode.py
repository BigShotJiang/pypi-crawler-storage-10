# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class StructuralMode(BladedModel):
    r"""
    An object containing the DampingRatio for a particular structural mode. Used by the support structure to include structural modes and their associated DampingRatios, as well as by the blades to define WholeBladeModeDampingRatios. Users can add any metadata alongside the DampingRatio, such as _Name or _Mode. Bladed will disregard any metadata as long as it is prefixed with an underscore.
    
    Attributes
    ----------
    DampingRatio : float
        The damping ratio on the mode.  This is typically in the order of 0.005.  An underdamped mode can lead to numerical instability in the simulation, whereas overdamped mode can affect the veracity of the results.
    
    Notes
    -----
    
    """

    DampingRatio: float = Field(alias="DampingRatio", default=None)
    r"""
    The damping ratio on the mode.  This is typically in the order of 0.005.  An underdamped mode can lead to numerical instability in the simulation, whereas overdamped mode can affect the veracity of the results.
    """

    _relative_schema_path: str = 'Components/common/StructuralMode.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


StructuralMode.model_rebuild()
