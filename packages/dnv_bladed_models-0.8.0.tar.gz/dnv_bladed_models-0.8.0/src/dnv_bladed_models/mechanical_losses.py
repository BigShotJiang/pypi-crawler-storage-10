# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.shaft_input_power_vs_power_loss import ShaftInputPowerVsPowerLoss
from dnv_bladed_models.shaft_input_power_vs_power_loss import ShaftInputPowerVsPowerLoss as ShaftInputPowerVsPowerLossModel
from dnv_bladed_models.shaft_input_torque_vs_resisting_torque import ShaftInputTorqueVsResistingTorque
from dnv_bladed_models.shaft_input_torque_vs_resisting_torque import ShaftInputTorqueVsResistingTorque as ShaftInputTorqueVsResistingTorqueModel
from dnv_bladed_models.shaft_speed_vs_shaft_input_power_vs_power_loss import ShaftSpeedVsShaftInputPowerVsPowerLoss
from dnv_bladed_models.shaft_speed_vs_shaft_input_power_vs_power_loss import ShaftSpeedVsShaftInputPowerVsPowerLoss as ShaftSpeedVsShaftInputPowerVsPowerLossModel
from dnv_bladed_models.shaft_speed_vs_shaft_input_torque_vs_resisting_torque import ShaftSpeedVsShaftInputTorqueVsResistingTorque
from dnv_bladed_models.shaft_speed_vs_shaft_input_torque_vs_resisting_torque import ShaftSpeedVsShaftInputTorqueVsResistingTorque as ShaftSpeedVsShaftInputTorqueVsResistingTorqueModel
from .schema_helper import SchemaHelper
from .base_entity import *




class MechanicalLosses(BladedModel):
    r"""
    The common properties for the mechanical losses in the drivetrain.
    
    Attributes
    ----------
    ShaftSpeedVsShaftInputTorqueVsResistingTorque : List[ShaftSpeedVsShaftInputTorqueVsResistingTorque]
        A series of look-up tables for the losses, each valid for the specified shaft speed.
    
    ShaftInputTorqueVsResistingTorque : List[ShaftInputTorqueVsResistingTorque]
        A look-up table for the losses, each valid for the specified input torque.
    
    ShaftSpeedVsShaftInputPowerVsPowerLoss : List[ShaftSpeedVsShaftInputPowerVsPowerLoss]
        A series of look-up tables for the losses, each valid for the specified shaft rotational speed.
    
    ShaftInputPowerVsPowerLoss : List[ShaftInputPowerVsPowerLoss]
        A series of look-up tables for the losses, each valid for the specified shaft rotational speed.
    
    Notes
    -----
    
    """

    ShaftSpeedVsShaftInputTorqueVsResistingTorque: List[ShaftSpeedVsShaftInputTorqueVsResistingTorqueModel] = Field(alias="ShaftSpeedVsShaftInputTorqueVsResistingTorque", default_factory=list)
    r"""
    A series of look-up tables for the losses, each valid for the specified shaft speed.
    """

    ShaftInputTorqueVsResistingTorque: List[ShaftInputTorqueVsResistingTorqueModel] = Field(alias="ShaftInputTorqueVsResistingTorque", default_factory=list)
    r"""
    A look-up table for the losses, each valid for the specified input torque.
    """

    ShaftSpeedVsShaftInputPowerVsPowerLoss: List[ShaftSpeedVsShaftInputPowerVsPowerLossModel] = Field(alias="ShaftSpeedVsShaftInputPowerVsPowerLoss", default_factory=list)
    r"""
    A series of look-up tables for the losses, each valid for the specified shaft rotational speed.
    """

    ShaftInputPowerVsPowerLoss: List[ShaftInputPowerVsPowerLossModel] = Field(alias="ShaftInputPowerVsPowerLoss", default_factory=list)
    r"""
    A series of look-up tables for the losses, each valid for the specified shaft rotational speed.
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/MechanicalLosses/MechanicalLosses.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set(['ShaftSpeedVsShaftInputTorqueVsResistingTorque','ShaftInputTorqueVsResistingTorque','ShaftSpeedVsShaftInputPowerVsPowerLoss','ShaftInputPowerVsPowerLoss',]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


MechanicalLosses.model_rebuild()
