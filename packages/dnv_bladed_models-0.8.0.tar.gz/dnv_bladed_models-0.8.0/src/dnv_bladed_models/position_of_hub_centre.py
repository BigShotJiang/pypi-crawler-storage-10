# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from .schema_helper import SchemaHelper
from .base_entity import *




class PositionOfHubCentre(BladedModel):
    r"""
    The positioning of the hub centre.  The hub centre is the nominal point where all of the pitch axes intercept the axis of rotation, if any sweep is ignored.
    
    Attributes
    ----------
    RotorTilt : float
        The angle of the main bearing and low speed shaft to the horizontal.  A positive value will tilt the rotor upwards to face the sky.
    
    Overhang : float
        The distance of the hub centre upwind from the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw bearing or support structure). This will be considered as the vector component parallel to the `DrivetrainAndNacelle`'s x-axis if the `DrivetrainAndNacelle`'s axis system is not aligned with global X.
    
    HeightOffset : float
        The distance in the `DrivetrainAndNacelle`'s Z direction between the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw system or support structure) and the hub centre.
    
    SideOffset : float, default=0
        The distance in the `DrivetrainAndNacelle`'s Y direction between the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw system or support structure) and the hub centre.  This is often zero or very small.
    
    Notes
    -----
    
    """

    RotorTilt: float = Field(alias="RotorTilt", default=None)
    r"""
    The angle of the main bearing and low speed shaft to the horizontal.  A positive value will tilt the rotor upwards to face the sky.
    """

    Overhang: float = Field(alias="Overhang", default=None)
    r"""
    The distance of the hub centre upwind from the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw bearing or support structure). This will be considered as the vector component parallel to the `DrivetrainAndNacelle`'s x-axis if the `DrivetrainAndNacelle`'s axis system is not aligned with global X.
    """

    HeightOffset: float = Field(alias="HeightOffset", default=None)
    r"""
    The distance in the `DrivetrainAndNacelle`'s Z direction between the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw system or support structure) and the hub centre.
    """

    SideOffset: float = Field(alias="SideOffset", default=None)
    r"""
    The distance in the `DrivetrainAndNacelle`'s Y direction between the `DrivetrainAndNacelle`'s origin (where the nacelle is attached to the yaw system or support structure) and the hub centre.  This is often zero or very small.
    - default = 0
    """

    _relative_schema_path: str = 'Components/DrivetrainAndNacelle/PositionOfHubCentre/PositionOfHubCentre.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


PositionOfHubCentre.model_rebuild()
