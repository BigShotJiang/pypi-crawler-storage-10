# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.dynamic_wake import DynamicWake
from dnv_bladed_models.dynamic_wake import DynamicWake as DynamicWakeModel
from .schema_helper import SchemaHelper
from .base_entity import *




class OyeDynamicWake(DynamicWake):
    r"""
    The Oye dynamic wake model captures the lag in induction in response to a change of inflow conditions.  It is the most accurate model for linearisation and time domain, but it does increase linearisation time significantly as it introduces extra states.
    
    Attributes
    ----------
    DynamicWakeType : Literal['OyeDynamicWake'], default='OyeDynamicWake'
        Defines the specific type of DynamicWake model in use.  For a `OyeDynamicWake` object, this must always be set to a value of `OyeDynamicWake`.
    
    DynamicTangentialInduction : bool, default=True
        If false, the tangential induction will be solved by iteration on each time step, as per the Pitt and Peters model.
    
    OyeTimeLagMultiplier : float, default=1
        The time constant for the Oye dynamic wake model.
    
    Notes
    -----
    
    """

    DynamicWakeType: Literal['OyeDynamicWake'] = Field(alias="DynamicWakeType", default='OyeDynamicWake', frozen=True) # type: ignore
    r"""
    Defines the specific type of DynamicWake model in use.  For a `OyeDynamicWake` object, this must always be set to a value of `OyeDynamicWake`.
    - default = 'OyeDynamicWake'
    """

    DynamicTangentialInduction: bool = Field(alias="DynamicTangentialInduction", default=None)
    r"""
    If false, the tangential induction will be solved by iteration on each time step, as per the Pitt and Peters model.
    - default = True
    """

    OyeTimeLagMultiplier: float = Field(alias="OyeTimeLagMultiplier", default=None)
    r"""
    The time constant for the Oye dynamic wake model.
    - default = 1
    """

    _relative_schema_path: str = 'Settings/AerodynamicSettings/AerodynamicModel/MomentumTheoryCorrections/DynamicWake/OyeDynamicWake.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), 'DynamicWakeType').merge(DynamicWake._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


OyeDynamicWake.model_rebuild()
