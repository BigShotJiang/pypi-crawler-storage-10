# *********************************************************************#
# Bladed Python Models API                                             #
# Copyright (c) DNV Services UK Limited (c) 2025. All rights reserved. #
# MIT License (see license file)                                       #
# *********************************************************************#


# coding: utf-8

from __future__ import annotations

from datetime import date, datetime  # noqa: F401
from enum import Enum, IntEnum
from pathlib import Path

import os
import re  # noqa: F401
from typing import Annotated, Any, ClassVar, Dict, List, Literal, Optional, Set, Type, TypeVar, Union, Callable, Iterable, ItemsView, KeysView, ValuesView  # noqa: F401
Model = TypeVar('Model', bound='BaseModel')
StrBytes = Union[str, bytes]

from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, ValidationError  # noqa: F401

from dnv_bladed_models.bladed_model import BladedModel
from dnv_bladed_models.bladed_model import BladedModel as BladedModelModel
from dnv_bladed_models.offset_and_rotated_coordinate_system import OffsetAndRotatedCoordinateSystem
from dnv_bladed_models.offset_and_rotated_coordinate_system import OffsetAndRotatedCoordinateSystem as OffsetAndRotatedCoordinateSystemModel
from dnv_bladed_models.reference_coordinate_system import ReferenceCoordinateSystem
from dnv_bladed_models.reference_coordinate_system import ReferenceCoordinateSystem as ReferenceCoordinateSystemModel
from .schema_helper import SchemaHelper
from .base_entity import *




class CoordinateSystems(BladedModel):
    r"""
    The coordinate systems of the blade cross-section.  If a coordinate system is not specified, it defaults to the ReferenceCoordinateSystem.  Consequently, any coordinate system may serve as the reference coordinate system.
    
    Attributes
    ----------
    ReferenceCoordinateSystem : ReferenceCoordinateSystem
    
    QuarterChordCoordinateSystem : OffsetAndRotatedCoordinateSystem
    
    PrincipalInertiaCoordinateSystem : OffsetAndRotatedCoordinateSystem
    
    PrincipalElasticCoordinateSystem : OffsetAndRotatedCoordinateSystem
    
    PrincipalShearCoordinateSystem : OffsetAndRotatedCoordinateSystem
    
    Notes
    -----
    
    """

    ReferenceCoordinateSystem: ReferenceCoordinateSystemModel = Field(alias="ReferenceCoordinateSystem", default=None)
    r"""
    """

    QuarterChordCoordinateSystem: OffsetAndRotatedCoordinateSystemModel = Field(alias="QuarterChordCoordinateSystem", default=None)
    r"""
    """

    PrincipalInertiaCoordinateSystem: OffsetAndRotatedCoordinateSystemModel = Field(alias="PrincipalInertiaCoordinateSystem", default=None)
    r"""
    """

    PrincipalElasticCoordinateSystem: OffsetAndRotatedCoordinateSystemModel = Field(alias="PrincipalElasticCoordinateSystem", default=None)
    r"""
    """

    PrincipalShearCoordinateSystem: OffsetAndRotatedCoordinateSystemModel = Field(alias="PrincipalShearCoordinateSystem", default=None)
    r"""
    """

    _relative_schema_path: str = 'Components/Blade/CrossSection/CoordinateSystems/CoordinateSystems.json'
    _type_info: ClassVar[TypeInfo] = TypeInfo(set([]), set([]), set([]), None).merge(BladedModel._type_info)
    model_config = ConfigDict(validate_assignment=True, strict=True, validate_by_name=True, validate_by_alias=True, extra='forbid')

    def _entity(self) -> bool:
        return True


CoordinateSystems.model_rebuild()
