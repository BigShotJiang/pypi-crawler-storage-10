from .mixins import QueryExecutorMixin, execute_django_query

__version__ = "1.2.0"
__all__ = ["QueryExecutorMixin", "execute_django_query"]
