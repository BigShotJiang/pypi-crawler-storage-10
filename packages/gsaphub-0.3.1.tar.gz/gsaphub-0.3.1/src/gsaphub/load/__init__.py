import json

from . import annotations, docs, gql, text_units


def to_json(content, fn):
    with open(fn, "w") as f:
        json.dump(content, f)


def to_jsonl(list_of_content, fn):
    jsons_raw = [json.dumps(c) for c in list_of_content]
    json_raw = "\n".join(jsons_raw)
    with open(fn, "w") as f:
        f.write(json_raw)


__all__ = ["gql", "to_json", "to_jsonl", "annotations", "docs", "text_units"]
