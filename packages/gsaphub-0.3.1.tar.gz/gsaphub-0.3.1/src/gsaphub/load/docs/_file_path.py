import json
from pathlib import Path


def _load_docs_to_file_path(docs, path_target_docs: str, include_annotator=False):
    for doc in docs:
        doc_id = doc["document_name"]
        annotator = doc["inception_meta"]["user_name"]
        # add annotator to filename if needed and use .json
        #    (e.g., 01.txt => "01_Rudi.json")
        annotator_str = f"_{annotator}" if include_annotator else ""
        doc_id_stem = Path(doc_id).stem
        doc_filename = Path(f"{doc_id_stem}{annotator_str}.json")
        path_to_doc = Path(path_target_docs) / doc_filename
        with path_to_doc.open("w") as f:
            json.dump(doc, f)
