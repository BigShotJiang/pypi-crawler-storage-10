from ._file_path import _load_docs_to_file_path as file_path

__all__ = ["file_path"]
