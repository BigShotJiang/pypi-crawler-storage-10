from .file_path import file_path

__all__ = ["file_path"]
