import json
from pathlib import Path


def file_path(ents, rels, path):
    path = Path(path)
    path.mkdir(exist_ok=True, parents=True)
    fn_ents = path / "entities.json"
    fn_rels = path / "relations.json"
    with fn_ents.open("w") as f:
        json.dump(ents, f, indent=4)
    with fn_rels.open("w") as f:
        json.dump(rels, f, indent=4)
