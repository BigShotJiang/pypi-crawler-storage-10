"""
Json format of PLMarker
```json
{
    "doc_id": "00002_1810_04805.txt",
    "sentences": [["Each", "token", "separate"], ["Second", "sentence", "."]],
    "clusters": [[[1,1], [69,70]]], # entity clusters
    "ner": [[[0,3,"Task"]], [[34, 34, "Generic"], [35, 36, "Method"]]],
    "relations": [
        [
            [0,3,34,34,"PART-OF"], # all relations of one sentence
        ],
        []
    ]
    "doc_token": [
    "url_inception":
}```
"""

import json
import random
import re
from collections import Counter, defaultdict
from copy import deepcopy
from glob import glob
from itertools import chain
from pathlib import Path

import pandas as pd
import spacy
from spacy.tokenizer import Tokenizer
from spacy.util import compile_infix_regex


def text_units_to_plmarker(text_units, nlp, key_doc_id="doc_id"):
    nlp.tokenizer = _create_custom_tokenizer(nlp)
    docs, errors = _to_plmarker_docs(text_units, nlp, key_doc_id)
    return docs, errors


def _to_plmarker_docs(sentences, nlp, key_doc_id):
    default_doc = dict(
        sentences=[],
        clusters=[],
        doc_tokens=[],
        doc_token_spans=[],
        url_inception=[],
        ner=[],
        relations=[],
    )
    docs = []
    current_doc_id = None
    doc = None
    all_errors = []
    for sent_idx, sent in enumerate(sentences, start=1):
        doc_id = sent[key_doc_id]
        if current_doc_id != doc_id:
            doc = deepcopy(default_doc)
            doc["doc_id"] = doc_id
            docs.append(doc)
            start_idx = 0
            current_doc_id = doc_id

        tokens, token_spans, ner, relations, errors = _sent_to_sent(
            nlp, sent, start_idx
        )

        doc["doc_tokens"].extend(tokens)
        doc["doc_token_spans"].extend(token_spans)
        doc["url_inception"].append(sent["url_inception"])
        for error in errors:
            all_errors.append(
                dict(
                    doc_id=doc_id,
                    sent_idx=sent_idx - 1,
                    sent_text=sent["text"],
                    url_inception=sent["url_inception"],
                    error=error,
                )
            )
        start_idx += len(tokens)
        doc["sentences"].append(tokens)
        doc["ner"].append(ner)
        doc["relations"].append(relations)
        print(f"\r{sent_idx}/{len(sentences)}", end="")
    print()
    return docs, all_errors


def _sent_to_sent(nlp, sentence_info, start_idx, layer="Scholarly"):
    sent_begin_in_doc = sentence_info["begin"]
    sent_sp = nlp(sentence_info["text"])
    sentence = [t.text for t in sent_sp]
    sentence_spans = [
        [sent_begin_in_doc + t.idx, sent_begin_in_doc + t.idx + len(t)] for t in sent_sp
    ]
    ner = []
    relations = []
    id_to_ner = {}
    errors = []
    for ent in sentence_info["annotations"]:
        label = ent["label"]
        span_start, span_end, error = _get_span(sent_sp, ent)
        if error is not None:
            errors.append(error)
        begin = span_start + start_idx
        end = span_end + start_idx
        ner.append([begin, end, label])
        id_to_ner[ent["id"]] = [begin, end]
        # check entity text

    for rel in sentence_info["relations"]:
        label = rel["relation_label"]
        subj_idxs = id_to_ner.get(rel["subject_id"])
        obj_idxs = id_to_ner.get(rel["object_id"])
        if subj_idxs is None or obj_idxs is None:
            # relation is not inner sentence relation
            continue
        relation = subj_idxs + obj_idxs + [label]
        relations.append(relation)
    return sentence, sentence_spans, ner, relations, errors


def _get_span(doc_spacy, ent):
    char_begin, char_end = ent["begin_in_text_unit"], ent["end_in_text_unit"]
    span = doc_spacy.char_span(char_begin, char_end, alignment_mode="strict")
    changed = span is None
    error = None
    if changed:
        span = doc_spacy.char_span(char_begin, char_end, alignment_mode="expand")
        # alignment_mode "contract" will only
        #  match tokens which are fully inside the char span
        error = f"'{ent['text']}' is expanded to '{span}'"
    return span.start, span.end - 1, error


# Create a custom tokenizer with the modified infix patterns
# Adapted from here: https://www.longest.io/2018/01/27/spacy-custom-tokenization.html
def _create_custom_tokenizer(nlp):
    my_prefixes = [r"[0-9]\.", r"[-]"]

    all_prefixes_re = spacy.util.compile_prefix_regex(
        tuple(list(nlp.Defaults.prefixes) + my_prefixes)
    )

    # Handle ( that doesn't have proper spacing around it
    custom_infixes = [
        "\.\.\.+",
        "(?<=[0-9])-(?=[0-9])",
        "[!&:,()\+\/]",
        "(?<=[\\]])\.",
        "\\](?=[\\.\)])",
        "\\=+",
    ]
    infix_defaults = nlp.Defaults.infixes
    infix_defaults = [i for i in infix_defaults if i not in {"'s", "'S", "’s", "’S"}]

    infix_regexs = tuple(list(nlp.Defaults.infixes) + custom_infixes)
    infix_re = spacy.util.compile_infix_regex(infix_regexs)

    custom_suffixes = [
        "\\.",
        "\\-",
        "\\:",
    ]  # [r'\.']# not working yet ("45."): , r'(?<=[0-9])\\.',]
    # Keep out "g." "G." to split them.
    suffix_re = spacy.util.compile_suffix_regex(
        tuple(list(nlp.Defaults.suffixes) + custom_suffixes)
    )

    return Tokenizer(
        nlp.vocab,
        nlp.Defaults.tokenizer_exceptions,
        prefix_search=all_prefixes_re.search,
        infix_finditer=infix_re.finditer,
        suffix_search=suffix_re.search,
        token_match=None,
    )
