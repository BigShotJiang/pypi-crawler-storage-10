from flattentei import get_units
from gql import gql


async def insert_docs_meta(client, docs_meta):
    """This function inserts documents into a GraphQL database and returns a
    dictionary mapping document names to their corresponding GraphQL IDs.
    """
    insert_doc = """
      mutation create_doc (
          $document_name: String!, $title: String!, $inception_document_id: Int!,
          $inception_project_id: Int!        
      )
      {
      createDocument(
        input: {document: {
                documentName: $document_name,
                inceptionDocumentId: $inception_document_id,
                inceptionProjectId: $inception_project_id,
                title: $title}}
      ) {
        clientMutationId
        document {
          documentName
          id
        }
      }
    }
    """
    document_name_to_gql_id = {}
    for doc_info in docs_meta:
        doc_name = doc_info["annotation_filename"]
        print(f"\r{doc_name}", end="")
        doc_info = dict(
            document_name=doc_name,
            title=doc_info["title"],
            inception_document_id=doc_info["inception_document_id"],
            inception_project_id=doc_info["inception_project_id"],
        )
        doc_in_tool = await client.execute_async(
            gql(insert_doc), variable_values=doc_info
        )
        doc_gql_id = doc_in_tool["createDocument"]["document"]["id"]
        document_name_to_gql_id[doc_name] = doc_gql_id
    return document_name_to_gql_id


async def insert_docs_lines(client, docs):
    for doc in docs:
        await insert_doc_lines(client, doc)


async def insert_doc_lines(client, doc):
    insert_chunk = """
        mutation create_chunk ($doc_id: Int!, $inception_line: Int,
                               $begin: Int!, $text: String!){
            createChunk(
                input: {
                    chunk: {
                        docId: $doc_id,
                        beginIdx: $begin,
                        inceptionLine: $inception_line,
                        text: $text
                    }
                }
            ) 
            {
                clientMutationId
                chunk {
                id
                }
            }
        }
    """
    doc_id = doc["doc_id_gql"]
    lines = get_units("Line", doc, doc_id=doc_id)
    for line in lines:
        line_idx = line["idx"] + 1
        print(f"\rAdd line {line_idx} for {doc_id}\033[K", end="", flush=True)
        chunk_info = {key: line[key] for key in ["doc_id", "begin", "text"]}
        chunk_info["inception_line"] = line_idx
        await client.execute_async(gql(insert_chunk), variable_values=chunk_info)
    print("\r\033[K", end="", flush=True)


async def add_span_id_if_exist(client, ent):
    query_ent_exist = """
         query ($userId: Int!, $docId: Int!, $beginIdx: Int!, $endIdx:Int!,
                 $label: String!, $layer: String!)
         { inTool: spansList (
              condition: {
              userId: $userId,
              docId: $docId,
              beginIdx: $beginIdx,
              endIdx: $endIdx,
              label: $label,
              layer: $layer}
              ){ id }
          }"""
    spans_in_tool = await client.execute_async(
        gql(query_ent_exist), variable_values=ent
    )
    spans_in_tool = spans_in_tool["inTool"]
    if len(spans_in_tool) == 1:
        span_id = spans_in_tool[0]["id"]
        ent["id"] = span_id
    if len(spans_in_tool) > 1:
        raise Exception(
            "unique constraint is not working properly for spans in graphql"
        )


async def insert_entity(client, ent, check_before=True):
    insert_ent = """
        mutation ($userId: Int!, $docId: Int!, $beginIdx: Int!,
                  $endIdx:Int!, $label: String!,
                  $text: String!, $layer: String!,
                  $chunkBegin: Int!, $chunkEnd: Int!)
        {
            createSpan(
                input: {span: {
                docId: $docId,
                userId: $userId,
                beginIdx: $beginIdx,
                endIdx: $endIdx,
                label: $label,
                layer: $layer,
                text: $text,
                chunkBegin: $chunkBegin,
                chunkEnd: $chunkEnd
                }}
              ) {
                clientMutationId
                span {
                  id
                }
              }
        }"""
    if check_before:
        await add_span_id_if_exist(client, ent)
    info = ""
    if "id" in ent:
        info = "existed"
    else:
        # insert
        span_in_tool = await client.execute_async(gql(insert_ent), variable_values=ent)
        new_span_id = span_in_tool["createSpan"]["span"]["id"]
        ent["id"] = new_span_id
        info = "added"
    return info


async def insert_entities(client, ents, layer="GSAP", check_before=True):
    not_inserted = 0
    existed_ents = 0
    for idx, ent in enumerate(ents, start=1):
        print(f"\rInsert Entities: {idx}/{len(ents)}", end="")
        if ent["chunkBegin"] is None:
            not_inserted += 1
            print(f"\rInsert Entities: {not_inserted} entities not inserted.", end="")
            continue
        info = await insert_entity(client, ent, check_before)
        if info == "existed":
            existed_ents += 1
    n_inserted = len(ents) - not_inserted - existed_ents
    print(
        f"\rInsert Entities: {n_inserted}/{len(ents)}"
        f"({not_inserted} not inserted, {existed_ents} existed before)",
        end="",
    )
    return ents


async def prepare_and_insert_entities(client, ents, layer="GSAP", check_before=False):
    not_inserted = 0
    existed_ents = 0
    for idx, ent_full in enumerate(ents, start=1):
        ent = _to_gql_span(ent_full, layer)
        print(f"\rInsert Entity: {idx}/{len(ents)}", end="")
        if ent["chunkBegin"] is None:
            not_inserted += 1

            print(f"\rInsert Entities: {not_inserted} entities not inserted.", end="")
            continue
        info = await insert_entity(client, ent, check_before)
        ent_full["gql_id"] = ent["id"]
        if info == "existed":
            existed_ents += 1
    n_inserted = len(ents) - not_inserted - existed_ents
    print(
        f"\rInsert Entities: {n_inserted}/{len(ents)} "
        f"({not_inserted} not inserted, {existed_ents} existed before)",
        end="",
    )
    return ents


async def prepare_and_insert_relations(client, relations):
    total = len(relations)
    relations_added_in_gql = 0
    relations_allready_in_gql = 0
    relations_in_gql = []
    for idx, rel_full in enumerate(relations):
        rel, inserted = await prepare_and_insert_relation(client, rel_full, idx, total)
        if inserted:
            relations_allready_in_gql += 1
        relations_in_gql.append(rel)

    print(f"relations added in graphql: {relations_added_in_gql}")
    print(f"relations allready in graphql: {relations_allready_in_gql}")
    return relations_in_gql


async def prepare_and_insert_relation(client, rel_full, idx=0, limit=0):
    rel = _to_gql_relation(rel_full)
    inserted = await insert_relation(client, rel, True, idx, limit)
    if rel["id"] is not None:
        rel_full["gql_id"] = rel["id"]
    return rel_full, inserted


GQL_insert_relation = """
    mutation ($userId: Int!, $subject: Int!, $relation: String!, $object: Int!)
      {
        createRelation(
          input: { relation: {
                userId: $userId,
                subject: $subject,
                relation: $relation,
                object: $object
        }}
      ) {
        clientMutationId
        relation {
          id
        }
      }
}"""


async def insert_relation(client, relation, check_before=False, idx=0, limit=0):
    if relation["subject"] == -1 or relation["object"] == -1:
        print(f"\nnot inserted! Because no subject id or no object id: {relation}\n")
        return relation
    print(f"\rInsert Relations: {idx + 1} / {limit}", end="")
    if check_before:
        await add_relation_id_if_exists(client, relation)
    if relation["id"] is None:
        # Add relation
        relation_in_tool = await client.execute_async(
            gql(GQL_insert_relation), variable_values=relation
        )
        rel_id = relation_in_tool["createRelation"]["relation"]["id"]
        relation["id"] = rel_id
        return True
    return False


async def add_relation_id_if_exists(client, relation):
    """ """
    query_rel_exist = """
         query ($userId: Int!,
                 $subject: Int!,
                 $relation: String!,
                 $object: Int!)
         { inTool: relationsList (
              condition: {
              userId: $userId,
              subject: $subject,
              relation: $relation,
              object: $object
              }
              ){ id }
          }"""
    # print()
    # print(ent)
    rels_in_tool = await client.execute_async(
        gql(query_rel_exist), variable_values=relation
    )
    # print("here")
    # print(spans_in_tool)
    rels_in_tool = rels_in_tool["inTool"]
    if len(rels_in_tool) == 1:
        rel_id = rels_in_tool[0]["id"]
        current_id = relation.get("id")
        assert current_id is None
        relation["id"] = rel_id
        if current_id is not None:
            if current_id != rel_id:
                raise Exception(
                    "Relation Existence Check:"
                    "existing relation id is not equal to db id"
                )
    elif len(rels_in_tool) > 1:
        raise Exception(
            "unique constraint is not working properly for relations in graphql"
        )


def _to_gql_span(ent, layer):
    gql_span = dict(
        docId=ent["gql_doc_id"],
        userId=ent["gql_user_id"],
        beginIdx=ent["begin"],
        endIdx=ent["end"],
        label=ent["label"],
        layer=layer,
        text=ent["text"],
        chunkBegin=ent.get("gql_chunk_id_start"),
        chunkEnd=ent.get("gql_chunk_id_end"),
    )
    return gql_span


def _to_gql_relation(relation):
    rel = dict(
        id=relation["gql_id"],
        subject=relation["gql_subject_ent_id"],
        relation=relation["relation_label"],
        object=relation["gql_object_ent_id"],
        userId=relation["gql_user_id"],
    )
    return rel
