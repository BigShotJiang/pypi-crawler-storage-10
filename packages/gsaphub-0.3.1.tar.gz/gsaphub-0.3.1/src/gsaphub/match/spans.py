from bisect import bisect_left, bisect_right
from collections import defaultdict


def exact(
    ents,
    ents_compare,
    matching_keys=["doc_id", "begin", "end"],
    target_key="matched_ents",
):
    ents_compare_id_by_key = defaultdict(list)
    for ent in ents_compare:
        ent_key = tuple(ent[k] for k in matching_keys)
        ents_compare_id_by_key[ent_key].append(ent["id"])
    for ent in ents:
        ent_key = tuple(ent[k] for k in matching_keys)
        ent[target_key] = ents_compare_id_by_key.get(ent_key, [])


def partial(
    ents,
    ents_target,
    target_key="matched_ent_ids",
    only_same_annotator=False,
):
    doc_keys = ["doc_id"]
    if only_same_annotator:
        doc_keys.append("annotator")
    docs_ents = defaultdict(list)
    docs_ents_target = defaultdict(list)
    for ent in ents:
        key = tuple([ent[k] for k in doc_keys])
        docs_ents[key].append(ent)
    for ent in ents_target:
        key = tuple([ent[k] for k in doc_keys])
        docs_ents_target[key].append(ent)

    all_doc_keys = set(docs_ents) | set(docs_ents_target)
    for doc_key in all_doc_keys:
        doc_ents = docs_ents.get(doc_key, [])
        doc_ents_target = docs_ents_target.get(doc_key, [])
        match_doc_entities(doc_ents, doc_ents_target, target_key)


def match_doc_entities(ents, ents_target, target_key):
    ents_target_begin = sorted(ents_target, key=lambda x: x["begin"])
    ents_target_end = sorted(ents_target, key=lambda x: x["end"])
    for ent in ents:
        matches = get_overlapping(ent, ents_target_begin, ents_target_end)
        ent[target_key] = matches


def get_overlapping(ent, ents_target_begin, ents_target_end):
    # all target ents with smaller end as begining of query ent
    ent_idx_end_max = bisect_right(
        ents_target_end, ent["begin"], key=lambda x: x["end"]
    )
    # all target ents with smaller beginning as ending of quer ent
    ent_idx_begin_min = bisect_left(
        ents_target_begin, ent["end"], key=lambda x: x["begin"]
    )
    # anno_idx_begin_min, anno_idx_end_max

    matches = {a["id"] for a in ents_target_end[ent_idx_end_max:]} & {
        a["id"] for a in ents_target_begin[:ent_idx_begin_min]
    }
    return list(matches)
