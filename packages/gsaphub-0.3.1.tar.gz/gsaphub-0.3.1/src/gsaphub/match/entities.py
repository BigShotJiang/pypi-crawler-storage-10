from .spans import exact, partial

__all__ = ["exact", "partial"]


def partial_ranked(
    ents,
    ents_compare,
    target_key="matched_ent_ids",
    doc_key="document_name",
    id_key="id",
    only_same_annotator=False,
    only_same_label=False,
):
    partial(ents, ents_compare, target_key, only_same_annotator)
    ents_compare = {e[id_key]: e for e in ents_compare}
    for ent in ents:
        ranked = _get_ranked_matches(ent, ents_compare, only_same_label, target_key)
        ent[target_key] = ranked


def _get_ranked_matches(
    ent, ents_compare_dict, only_same_label, match_info_key="matched_ent_id"
):
    """
    add best matching entity infor to ent

    """
    ordered = []
    for ident in ent[match_info_key]:
        is_exact = False
        is_correct_label = False
        ent_compare = ents_compare_dict[ident]
        if ent["label"] == ent_compare["label"]:
            is_correct_label = True
        if ent["begin"] == ent_compare["begin"] and ent["end"] == ent_compare["end"]:
            is_exact = True
        ordered.append((is_correct_label, is_exact, ent_compare))
    if only_same_label:
        ordered = [e for e in ordered if e[0]]
    ordered.sort(key=lambda x: (x[0], x[1]), reverse=True)
    ordered = [
        (
            ent_compare["id"],
            "strict"
            if is_correct_label and is_exact
            else "label"
            if is_correct_label
            else "exact"
            if is_exact
            else "overlap",
        )
        for is_correct_label, is_exact, ent_compare in ordered
    ]
    return ordered
