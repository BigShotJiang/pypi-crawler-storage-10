from collections import defaultdict


def exact_match(rels, ents, rels_compare, ents_compare, strict=False):
    """matches all relations with relations from rel_compare
    A match is only considered if doc_id, begin, end, and relation label is the same.
    if strict is True:
        the entity labels need to be the same as well.
    """
    ents = {e["id"]: e for e in ents}
    ents_compare = {e["id"]: e for e in ents_compare}
    match_field = "match_compare"
    if strict:
        match_field += "_strict"
    matching_keys = [
        "doc_id",
        "relation_label",
    ]
    ent_keys = ["begin", "end"]
    if strict:
        ent_keys.append("label")

    key_to_rels = _generate_key_to_rels(rels, ents, matching_keys, ent_keys)
    key_to_rels_compare = _generate_key_to_rels(
        rels_compare, ents_compare, matching_keys, ent_keys
    )

    rel_diff = len(rels) - len(key_to_rels)
    if rel_diff > 0:
        print(
            f"warning: {rel_diff} relations with matching relations in same set.\n "
            f"\te.g., MLModel trainedOn Dataset, MLModelGeneric trainedOn Dataset "
            f"on same spans"
        )
    rel_diff = len(rels_compare) - len(key_to_rels_compare)
    if rel_diff > 0:
        print(
            f"warning: {rel_diff} compare relations with matching relations "
            f"in same set."
        )
        print("\te.g., MLModel trainedOn Dataset, MLModelGeneric trainedOn Dataset")

    common_keys = set(key_to_rels) & set(key_to_rels_compare)
    for key in common_keys:
        key_rels = key_to_rels[key]
        if key not in key_to_rels_compare:
            rel[match_field] = None
            continue
        key_rels_compare = key_to_rels_compare[key]
        ent_labels_compare = {
            (
                ents_compare[r["subject_id"]]["label"],
                ents_compare[r["object_id"]]["label"],
            ): r["id"]
            for r in key_rels_compare
        }
        for rel in key_rels:
            ent_labels = (
                ents[rel["subject_id"]]["label"],
                ents[rel["object_id"]]["label"],
            )
            if ent_labels in ent_labels_compare:
                rel[match_field] = ent_labels_compare[ent_labels]
            else:
                # take first
                rel[match_field] = key_rels_compare[0]["id"]
        # Add info also to rels_compare
        if key not in key_to_rels:
            rel_compare[match_field] = None
            continue
        key_rels = key_to_rels[key]
        ent_labels = {
            (ents[r["subject_id"]]["label"], ents[r["subject_id"]]["label"]): r["id"]
            for r in key_rels
        }
        for rel in key_rels_compare:
            ent_labels_compare = (
                ents_compare[rel["subject_id"]]["label"],
                ents_compare[rel["object_id"]]["label"],
            )
            if ent_labels_compare in ent_labels:
                rel[match_field] = ent_labels[ent_labels_compare]
            else:
                # take first
                rel[match_field] = key_rels[0]["id"]


def _generate_key_to_rels(rels, ents, matching_keys, ent_keys):
    key_to_rels = defaultdict(list)
    for rel in rels:
        rel_key = _generate_key(rel, ents, matching_keys, ent_keys)
        key_to_rels[rel_key].append(rel)
    key_to_rels = dict(key_to_rels)
    return key_to_rels


def _generate_key(rel, ents, keys, ent_keys):
    rel_key = ()
    for key in keys:
        rel_key += (rel[key],)
    for ent_role in ["subject", "object"]:
        ent = ents[rel[f"{ent_role}_id"]]
        for key in ent_keys:
            rel_key += (ent[key],)
    return rel_key
