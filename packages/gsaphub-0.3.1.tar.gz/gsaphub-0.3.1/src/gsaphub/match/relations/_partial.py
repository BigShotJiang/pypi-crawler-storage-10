import json
from collections import Counter
from copy import deepcopy
from itertools import product
from pathlib import Path
from pprint import pprint

from ..entities import _get_ranked_matches
from ..spans import partial as match_spans_partial

ENT_ORDER = ["strict", "label", "exact", "overlap", "NIL"]
REL_ORDER = ["same", "same_reverse", "differ", "differ_reverse", "NIL"]


def partial_match(rels, ents, rels_pred, ents_pred, doc_annotator_to_corrector={}):
    matches, not_matched = get_matches_bidirectional(rels, ents, rels_pred, ents_pred)
    change_info = to_change_info(
        matches,
        not_matched,
        rels,
        ents,
        rels_pred,
        ents_pred,
        doc_annotator_to_corrector,
    )
    return change_info


def get_matches_bidirectional(rels, ents, rels_pred, ents_pred):
    # Match entities with all overlapping entity spans
    match_spans_partial(ents, ents_pred, target_key="matched_ent_id")
    match_spans_partial(ents_pred, ents, target_key="matched_ent_id")

    # Adding info about the best matching relations
    #  for both sides: the relations and the relations to compare
    _add_all_matches_ordered(rels, ents, rels_pred, ents_pred)
    _add_all_matches_ordered(rels_pred, ents_pred, rels, ents)

    # combine all possible matches in both direction (incl. best "NIL" matches)
    all_matches = get_all_matches(rels, rels_pred)

    # filter by match preference
    # @todo: add prefered match type here
    filtered_matches = filter_matches(all_matches)

    # Double check, that every rel_id (from both relation sets) only occurs once.
    check_relation_matching(rels, rels_pred, filtered_matches)

    match_to_compare, not_matched_compare = split_matches(filtered_matches)
    return match_to_compare, not_matched_compare


def _add_all_matches_ordered(
    rels, ents, rels_compare, ents_compare, match_info_key="matched_ent_id"
):
    # add all potential relation matches. Incl.
    ent_dict = {e["id"]: e for e in ents}
    ents_comp_dict = {e["id"]: e for e in ents_compare}
    partial_strict_label = {"strict", "label", "exact", "overlap"}
    rels_compare_dict = {(r["subject_id"], r["object_id"]): r for r in rels_compare}
    for rel in rels:
        # rel["matched"] = False
        relation_match_type = "NIL"
        subj_id = rel["subject_id"]
        obj_id = rel["object_id"]
        subj = ent_dict[subj_id]
        obj = ent_dict[obj_id]

        all_matches = []
        subj_matches = _get_ranked_matches(subj, ents_comp_dict, only_same_label=False)
        obj_matches = _get_ranked_matches(obj, ents_comp_dict, only_same_label=False)

        # get annotator info from first subj or obj match.
        annotator_other = "NIL"
        if subj_matches:
            ent_matched = ents_comp_dict[subj_matches[0][0]]
            annotator_other = ent_matched.get("annotator", "NIL")
        elif obj_matches:
            ent_matched = ents_comp_dict[obj_matches[0][0]]
            annotator_other = ent_matched.get("annotator", "NIL")


        # only subj have matches
        # * no relation match possible
        # * add all possible "subj only" matches
        if subj_matches and not obj_matches:
            for subj_id_matched, subj_match_type in subj_matches:
                all_matches.append(
                    dict(
                        subject_id=subj_id_matched,
                        object_id=None,
                        relation_id=rel["id"],
                        subject_match_type=subj_match_type,
                        object_match_type="NIL",
                        relation_match_id=None,
                        relation_match_type="NIL",
                        relation_label=rel["relation_label"],
                        relation_match_label="NIL",
                        annotator_match=annotator_other,
                    )
                )
        # only objects have matches
        # * no relation match possible
        # * add all possible "obj only" matches
        if obj_matches and not subj_matches:
            for obj_id_matched, obj_match_type in obj_matches:
                all_matches.append(
                    dict(
                        relation_id=rel["id"],
                        subject_id=None,
                        object_id=obj_id_matched,
                        subject_match_type="NIL",
                        object_match_type=obj_match_type,
                        relation_match_id=None,
                        relation_match_type="NIL",
                        relation_label=rel["relation_label"],
                        relation_match_label="NIL",
                        annotator_match=annotator_other,
                    )
                )
        # no subject and no object span match
        #  * no relation match possible
        #  * add match to "nothing": "NIL", "NIL", "NIL"
        if not obj_matches and not subj_matches:
            all_matches.append(
                dict(
                    relation_id=rel["id"],
                    subject_id=None,
                    object_id=None,
                    subject_match_type="NIL",
                    object_match_type="NIL",
                    relation_match_id=None,
                    relation_match_type="NIL",
                    relation_label=rel["relation_label"],
                    relation_match_label="NIL",
                    annotator_match=annotator_other,
                )
            )
        # there are subject and object matches
        # * add for all combinations a match
        # * search for relation labels and incl. reverse label matches
        for (subj_id_matched, subj_match_type), (
            obj_id_matched,
            obj_match_type,
        ) in product(subj_matches, obj_matches):
            rel_match_type = "NIL"
            # search for matching relation for subj and obj.
            rel_key = subj_id_matched, obj_id_matched
            rel_matched = rels_compare_dict.get(rel_key)
            if rel_matched is not None:
                if rel_matched["relation_label"] == rel["relation_label"]:
                    rel_match_type = "same"
                else:
                    rel_match_type = "differ"
            else:
                # search for reverse relation:
                rel_key = obj_id_matched, subj_id_matched
                rel_matched = rels_compare_dict.get(rel_key)
                if rel_matched is not None:
                    if rel_matched["relation_label"] == rel["relation_label"]:
                        rel_match_type = "same_reverse"
                    else:
                        rel_match_type = "differ_reverse"

            if rel_matched is not None:
                rel_matched_id = rel_matched["id"]
                rel_matched_label = rel_matched["relation_label"]
                all_matches.append(
                    dict(
                        relation_id=rel["id"],
                        subject_id=subj_id_matched,
                        object_id=obj_id_matched,
                        subject_match_type=subj_match_type,
                        object_match_type=obj_match_type,
                        relation_match_id=rel_matched_id,
                        relation_match_type=rel_match_type,
                        relation_label=rel["relation_label"],
                        relation_match_label=rel_matched_label,
                        annotator_match=annotator_other,
                    )
                )
            # no matching alternative
            # Add a "NIL" relation for all possible subj, obj matches
            # This is needed to have an alternative for
            #   the subj, obj match if the relation is used somewhere else
            rel_matched_id = None
            rel_matched_label = "NIL"
            all_matches.append(
                dict(
                    relation_id=rel["id"],
                    subject_id=subj_id_matched,
                    object_id=obj_id_matched,
                    subject_match_type=subj_match_type,
                    object_match_type=obj_match_type,
                    relation_match_id=None,
                    relation_match_type="NIL",
                    relation_label=rel["relation_label"],
                    relation_match_label="NIL",
                    annotator_match=annotator_other,
                )
            )
        # Sort all possible matches
        # For "NIL" relation matches the best subj obj match is first
        all_matches.sort(key=_compare_match_types)
        rel["all_matches"] = all_matches


def _get_best_match(all_matches):
    all_matches.sort(key=_compare_match_types)
    return all_matches[0]


def _compare_match_types(comp_info):
    rel = REL_ORDER.index(comp_info["relation_match_type"])
    subj = ENT_ORDER.index(comp_info["subject_match_type"])
    obj = ENT_ORDER.index(comp_info["object_match_type"])
    return rel, subj + obj


def get_all_matches(rels, rels_pred):
    # for all combination of rels (by id and incl. NIL matches) take the best match
    # Goal is to use the global best matching relations and
    # only one match by both relation_id and relation_compare_id later
    known_combinations = set()
    all_matches = []
    for rel in rels:
        for match_ in rel["all_matches"]:
            ident = match_["relation_id"], match_["relation_match_id"]
            if ident in known_combinations:
                continue
            known_combinations.add(ident)
            match_["reverse"] = False
            all_matches.append(match_)
    for rel in rels_pred:
        for match_ in rel["all_matches"]:
            ident = match_["relation_match_id"], match_["relation_id"]
            if ident in known_combinations:
                continue
            known_combinations.add(ident)
            match_["reverse"] = True
            all_matches.append(match_)

    return all_matches


# @todo: add strict, partial, full, incl. reverse
def filter_matches(all_matches):
    """Select for each relation_id and relation_id_compare exactly one match
    * n_min = max(len(rels), len(rels_compare): All rels are matching
    * n_max = len(rels) + len(rels_compare): No relation is matching
    """
    all_matches.sort(key=_compare_match_types)
    filtered_matches = []
    seen_rels = set()
    seen_rels_pred = set()
    for match_ in all_matches:
        rel_id = match_["relation_id"]
        rel_id_match = match_["relation_match_id"]
        if match_["reverse"]:
            rel_id, rel_id_match = rel_id_match, rel_id
        if rel_id not in seen_rels and rel_id_match not in seen_rels_pred:
            filtered_matches.append(match_)
            if rel_id is not None:
                seen_rels.add(rel_id)
            if rel_id_match is not None:
                seen_rels_pred.add(rel_id_match)
    return filtered_matches


# check validity
def check_relation_matching(rels, rels_pred, filtered_matches):
    """
    Every relation (from both directions) should only be once in the matching relations
    """
    rel_ids = {rel["id"] for rel in rels}
    rel_ids_pred = {rel["id"] for rel in rels_pred}
    for match_ in filtered_matches:
        rel_id, rel_id_pred = match_["relation_id"], match_["relation_match_id"]
        if match_["reverse"]:
            rel_id, rel_id_pred = rel_id_pred, rel_id
        if rel_id is not None:
            rel_ids.remove(rel_id)
        if rel_id_pred is not None:
            rel_ids_pred.remove(rel_id_pred)
        assert rel_id is not None or rel_id_pred is not None
    assert len(rel_ids) == 0
    assert len(rel_ids_pred) == 0


def split_matches(matches):
    return [m for m in matches if not m["reverse"]], [
        m for m in matches if m["reverse"]
    ]


def _simplify_ent(ent, prefix):
    keys = ["id", "begin", "end", "label", "text"]
    ent_simple = dict()
    for key in keys:
        ent_simple[f"{prefix}_{key}"] = ent.get(key)
    return ent_simple


def to_change_info(
    matches,
    matches_reverse,
    rels,
    ents,
    rels_compare,
    ents_compare,
    doc_annotator_to_corrector,
):
    ents = {e["id"]: e for e in ents}
    ents_compare = {e["id"]: e for e in ents_compare}
    rels = {r["id"]: r for r in rels}
    rels_compare = {r["id"]: r for r in rels_compare}
    change_infos = []
    n_strict = 0
    for best_match in matches + matches_reverse:
        if (
            best_match["subject_match_type"] == "strict"
            and best_match["object_match_type"] == "strict"
            and best_match["relation_match_type"] == "same"
        ):
            # no change needed
            n_strict += 1
            continue
        if best_match["reverse"]:
            rel = rels.get(best_match["relation_match_id"])
            subject_id = best_match["subject_id"]
            subj = ents.get(subject_id, {})
            object_id = best_match["object_id"]
            obj = ents.get(object_id, {})
            match_rel_id = best_match["relation_id"]
            match_rel = rels_compare[match_rel_id]
            match_subj = ents_compare[match_rel["subject_id"]]
            match_obj = ents_compare[match_rel["object_id"]]
            if rel is None:
                rel = dict(
                    doc_id=match_rel["doc_id"],
                    annotator=best_match["annotator_match"],
                    url_inception=match_rel["url_inception"],
                    text_unit_text=match_rel.get("text_unit_text"),
                )
        else:
            rel = rels[best_match["relation_id"]]
            subj = ents[rel["subject_id"]]
            obj = ents[rel["object_id"]]
            match_rel_id = best_match["relation_match_id"]
            match_rel = rels_compare.get(match_rel_id, {})
            match_subject_id = best_match["subject_id"]
            match_subj = ents_compare.get(match_subject_id, {})
            match_object_id = best_match["object_id"]
            match_obj = ents_compare.get(match_object_id, {})

        # now collect info
        keys = ["doc_id", "annotator", "url_inception", "text_unit_text"]
        info = {k: rel[k] for k in keys}
        info["relation_score"] = rel.get("score")
        info["relation_label"] = rel.get("relation_label", "NIL")
        info |= _simplify_ent(subj, "subject")
        info |= _simplify_ent(obj, "object")
        info["relation_alt_label"] = match_rel.get("relation_label", "NIL")
        info["relation_alt_id"] = match_rel.get("id")
        info["annotator_alt"] = match_rel.get(
            "annotator"
        )  # best_match["annotator_match"]
        info["relation_score_alt"] = match_rel.get("score")

        info |= _simplify_ent(match_subj, "subject_alt")
        info |= _simplify_ent(match_obj, "object_alt")

        keys = ["subject_match_type", "object_match_type", "relation_match_type"]
        for key in keys:
            info[key] = best_match[key]
        corrector = doc_annotator_to_corrector.get((info["doc_id"], info["annotator"]))
        if corrector is None:
            corrector = doc_annotator_to_corrector.get((
                info["doc_id"],
                info["annotator_alt"],
            ))
        info["corrector"] = corrector
        change_infos.append(info)
    print(f"Exact matching relations: {n_strict}")
    return change_infos


def to_simple_change_info(change_info):
    change_info = deepcopy(change_info)
    sep = " -> "
    sep = "\n"
    for info in change_info:
        info["subject_text_compare"] = (
            f"{info['subject_text']}{sep}{info.get('subject_alt_text', 'NIL')}"
        )
        if "subject_alt_text" in info:
            del info["subject_alt_text"]
        info["subject_label_compare"] = (
            f"{info['subject_label']}{sep}{info.get('subject_alt_label', 'NIL')}"
        )
        if "subject_alt_label" in info:
            del info["subject_alt_label"]
        info["object_text_compare"] = (
            f"{info['object_text']}{sep}{info.get('object_alt_text', 'NIL')}"
        )
        if "object_alt_text" in info:
            del info["object_alt_text"]
        info["object_label_compare"] = (
            f"{info['object_label']}{sep}{info.get('object_alt_label', 'NIL')}"
        )
        if "object_alt_label" in info:
            del info["object_alt_label"]
        info["relation_label_compare"] = (
            f"{info['relation_label']}{sep}{info['relation_alt_label']}"
        )
        info["annotator"] = f"{info['annotator']}{sep}{info['annotator_alt']}"
        del info["annotator_alt"]
        # if "object_alt_label" in info: del info["object_alt_label"]
        del info["relation_alt_label"]
        info["url_inception"] = f'=HYPERLINK("{info["url_inception"]}", "inception")'
    return change_info
