from .._to_string import _text_unit_as_string as as_string

__all__ = ["as_string"]
