from ... import match
from ...labels import GSAP_SUBTYPE_MAPPING


def merge_sub_types(ents):
    sub_label = {}
    match.spans.partial(ents, ents, only_same_annotator=True)
    ents_filtered = []
    ent_dict = {e["id"]: e for e in ents}
    subtypes_not_matched = []
    for ent in ents:
        # get super labels and new subtype labels for all defined subtypes
        super_label, sub_label = GSAP_SUBTYPE_MAPPING.get(ent["label"], (None, None))
        # ent is a subtype label! map the label to the original label
        if super_label is not None:
            # This annotation is a subtype
            found = False
            for ent_id in ent["matched_ent_ids"]:
                # Add subtype infos to all matching entity mentions
                if ent_id == ent["id"]:
                    # no self match
                    continue
                ent_mapped = ent_dict[ent_id]
                if ent_mapped["label"] == super_label:
                    if (
                        ent_mapped["begin"] != ent["begin"]
                        or ent_mapped["end"] != ent_mapped["end"]
                    ):
                        print("Subtype matching: Subtype with non identical spans")
                        print(f"\tsub type text: '{ent['text']}'")
                        print(ent["url_inception"])
                        print(f"\tsuper type text: '{ent_mapped['text']}'")
                    if "label_sub" in ent_mapped:
                        # two subtypes for one entity mention
                        old = ent_mapped.get("label_sub_alternative", [])
                        new = old + [sub_label]
                        ent_mapped["label_sub_alternative"] = new
                    else:
                        ent_mapped["label_sub"] = sub_label
                    found = True

            if not found:
                subtypes_not_matched.append(ent)
        else:
            ents_filtered.append(ent)
    return ents_filtered, subtypes_not_matched
