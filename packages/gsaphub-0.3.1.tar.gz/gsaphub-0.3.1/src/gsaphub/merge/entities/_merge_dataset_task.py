from collections import defaultdict


def merge_dataset_task(ents, rels):
    ents = {e["id"]: e for e in ents}
    subj_to_rel = defaultdict(list)
    obj_to_rel = defaultdict(list)
    for rel in rels:
        subj_to_rel[rel["subject_id"]].append(rel)
        obj_to_rel[rel["object_id"]].append(rel)
    keys = ("begin", "end", "doc_id", "annotator")
    datasets = {
        tuple(e[k] for k in keys): e for e in ents.values() if e["label"] == "Dataset"
    }
    tasks_to_delete = set()
    rels_to_delete = set()
    rels_to_be_replaced = []
    for ent in ents.values():
        if ent["label"] != "Task":
            continue
        ent_key = tuple(ent[k] for k in keys)
        # print(ent_key)
        # print(len(datasets))
        # print(list(datasets.items())[0])
        # raise Exception()
        connected_dataset = datasets.get(ent_key)
        if connected_dataset is None:
            continue
        # found double annotion (Dataset Task)
        ent_rels_to_delete, ent_not_matched_relations = get_rel_pattern(
            ent, connected_dataset, subj_to_rel, obj_to_rel, ents
        )
        rels_to_be_replaced.extend(ent_not_matched_relations)
        for rel in ent_rels_to_delete:
            # this seems to not work correctly
            rels_to_delete.add(rel["id"])
        tasks_to_delete.add(ent["id"])
    ents_filtered = [e for e_id, e in ents.items() if e_id not in tasks_to_delete]
    rels_filtered = [
        r
        for r in rels
        if r["subject_id"] not in tasks_to_delete
        and r["object_id"] not in tasks_to_delete
    ]

    print(f"tasks to delete: {len(tasks_to_delete)}")
    print(f"task rels to delete: {len(rels_to_delete)}")
    print(
        f"relations to check because of Task Dataset merge: {len(rels_to_be_replaced)}"
    )
    print(f"{len(rels) - len(rels_filtered)} relations deleted by Task Dataset merge")
    print(f"{len(ents) - len(ents_filtered)} entities are really deleted.")
    return ents_filtered, rels_filtered, rels_to_be_replaced


def get_rel_pattern(task, dataset, subj_to_rel, obj_to_rel, ents):
    rels_to_delete = []
    dataset_rels = {}
    match_info = []
    not_matched = []
    for rel in subj_to_rel[dataset["id"]] + obj_to_rel[dataset["id"]]:
        subj = ents[rel["subject_id"]]
        obj = ents[rel["object_id"]]
        key = tuple(sorted([(subj["begin"], subj["end"]), (obj["begin"], obj["end"])]))
        dataset_rels[key] = dict(rel=rel, obj=obj, subj=subj)
    for rel in subj_to_rel[task["id"]] + obj_to_rel[task["id"]]:
        subj = ents[rel["subject_id"]]
        obj = ents[rel["object_id"]]
        key = tuple(sorted([(subj["begin"], subj["end"]), (obj["begin"], obj["end"])]))
        # relation can be deleted
        rels_to_delete.append(rel)
        if key in dataset_rels:
            # same relation subj span and obj span connected to dataset
            #  this should be in general ok, because connection between
            #  entity span is kept in the dataset
            dataset_equivalent = dataset_rels[key]
            match_info.append((
                (subj["label"], rel["relation_label"], obj["label"]),
                (
                    dataset_equivalent["subj"]["label"],
                    dataset_equivalent["rel"]["relation_label"],
                    dataset_equivalent["obj"]["label"],
                ),
            ))
        else:
            not_matched.append(rel)
            # not matched relation is lost!

    return rels_to_delete, not_matched


# from ..show.relations import as_string as relation_to_string

# logging
# not_matched_info.append(
#       (subj["label"], rel["relation_label"], obj["label"], rel["annotator"]))
# for p, c in pattern_counts[::-1]:
#        print()
#        print(f"found {c} times:")
#        print(p)
# print(relation_to_string(rel, subj, obj))
# print(ent_to_url(subj))
