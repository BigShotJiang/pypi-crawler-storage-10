from ... import match
from ...labels import ALLOWED_ENTITY_TYPES, GSAP_INTENTION_MAPPING


def merge_intentions(ents):
    match.spans.partial(ents, ents, only_same_annotator=True)
    ents_filtered = []
    ent_dict = {e["id"]: e for e in ents}
    intentions_not_joined = []
    intentions_stacked = []
    multi_ent_intention = 0
    for ent in ents:
        intention = GSAP_INTENTION_MAPPING.get(ent["label"])
        if intention is not None:
            found = set()
            for ent_id in ent["matched_ent_ids"]:
                # do not handle self match
                if ent_id == ent["id"]:
                    continue
                ent_mapped = ent_dict[ent_id]
                if ent_mapped["begin"] != ent["begin"]:
                    continue
                if ent_mapped["end"] != ent["end"]:
                    continue
                if "Generic" in ent_mapped["label"]:
                    # no intention for generics
                    continue
                mapped_label = ent_mapped["label"]
                if mapped_label in GSAP_INTENTION_MAPPING:
                    intentions_stacked.append(ent)
                    print(
                        f"annotation error: "
                        "stacked intention: {mapped_label} {ent['label']}"
                    )
                    print(ent["url_inception"])
                elif mapped_label in ALLOWED_ENTITY_TYPES:
                    ent_mapped["intention"] = intention
                    found.add(ent_id)
                elif mapped_label == "Corrupt":
                    # do not add to the corrupt label
                    pass
                else:
                    raise Exception(
                        f"Join Intentions: Unexpected entity type ({mapped_label})."
                        f"Map and filter entity types first"
                    )
            if len(found) > 1:
                multi_ent_intention += 1
                print("Info: One Intention for multiple Enities:")
                for ent_id in found:
                    label = ent_dict[ent_id]["label"]
                    text = ent_dict[ent_id]["text"]
                    print(f'\t[{label}: "{text}"]')
            elif len(found) == 0:
                intentions_not_joined.append(ent)
        else:
            ents_filtered.append(ent)
    return ents_filtered, intentions_not_joined, intentions_stacked
