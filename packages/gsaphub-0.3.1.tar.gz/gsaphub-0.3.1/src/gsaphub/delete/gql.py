from gql import gql


async def delete_lines_by_id(client, line_ids):
    q = """
        mutation ($id: Int!) {
            deleteChunk(input: {id: $id}) {
            clientMutationId
            }
        }
    """
    for idx, line_info in enumerate(line_ids, start=1):
        print(f"\rDelete Relations: {idx}/{len(line_ids)}   ", end="")
        await client.execute_async(gql(q), variable_values=line_info)
    print("\r", end="")
