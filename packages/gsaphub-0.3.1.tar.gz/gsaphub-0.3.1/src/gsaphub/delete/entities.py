from gql import gql


async def graphql_by_id(client, entities):
    q = """
        mutation ($id: Int!) {
            deleteSpan(input: {id: $id}) {
                clientMutationId
            }
        }
    """
    for idx, ent in enumerate(entities):
        print(f"\rDelete Entities:  {idx + 1}/{len(entities)}   ", end="")
        await client.execute_async(gql(q), variable_values=ent)
    print()
