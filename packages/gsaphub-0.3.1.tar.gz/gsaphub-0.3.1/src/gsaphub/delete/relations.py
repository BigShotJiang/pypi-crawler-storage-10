from gql import gql


async def graphql_by_id(client, relations):
    q = """
        mutation ($id: Int!) {
            deleteRelation(input: {id: $id}) {
            clientMutationId
            }
        }
    """
    for idx, rel in enumerate(relations):
        print(f"\rDelete Relations: {idx + 1}/{len(relations)}   ", end="")
        await client.execute_async(gql(q), variable_values=rel)
    print()
