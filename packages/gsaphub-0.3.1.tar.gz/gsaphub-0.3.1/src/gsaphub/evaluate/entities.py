from collections import defaultdict

import pandas as pd

from ..compare.entities import best_match as entity_compare_best_match
from ..match.entities import exact as match_entities_exact
from .relations import calc_metrics


def precision_recall_f1(ents_gold, ents_pred, partial=False):
    if partial:
        return _precision_recall_f1_partial(ents_gold, ents_pred)
    else:
        return _precision_recall_f1_exact(ents_gold, ents_pred)


def _precision_recall_f1_exact(
    ents_gold, ents_pred, keys=["doc_id", "begin", "end", "label"]
):
    match_entities_exact(ents_gold, ents_pred, matching_keys=keys)
    match_entities_exact(ents_pred, ents_gold, matching_keys=keys)
    counts = _count_matches(ents_gold, ents_pred)
    metrics = calc_metrics(counts)
    show = ["label", "precision", "recall", "f1_score", "support", "predicted"]
    return metrics[show]


def _precision_recall_f1_partial(ents_gold, ents_pred):
    pairs = entity_compare_best_match(
        ents_gold, ents_pred, ["strict", "label"], flat_format=False
    )
    counts = _count_pair_matches(pairs)
    counts = pd.DataFrame(counts).fillna(0).astype(int)
    metrics = calc_metrics(counts).rename(columns=dict(index="label"))
    show = ["label", "precision", "recall", "f1_score", "support", "predicted"]
    return metrics[show]


def _count_pair_matches(pairs):
    tp = defaultdict(int)
    fp = defaultdict(int)
    fn = defaultdict(int)
    predicted = defaultdict(int)
    support = defaultdict(int)
    for pair in pairs:
        if pair.entity is not None and pair.entity_compare is not None:
            tp[pair.entity["label"]] += 1
            predicted[pair.entity["label"]] += 1
            support[pair.entity_compare["label"]] += 1
        if pair.entity is None and pair.entity_compare is not None:
            fp[pair.entity_compare["label"]] += 1
            predicted[pair.entity_compare["label"]] += 1
        if pair.entity is not None and pair.entity_compare is None:
            fn[pair.entity["label"]] += 1
            support[pair.entity["label"]] += 1
    return dict(tp=tp, fp=fp, fn=fn, predicted=predicted, support=support)


def _count_matches(rels, rels_compare, match_field="matched_ents", label_field="label"):
    rels_df = pd.DataFrame(rels)
    rels_compare_df = pd.DataFrame(rels_compare)
    n_pred = rels_compare_df[label_field].value_counts().rename("predicted")
    f_tp = rels_compare_df[match_field].apply(len) > 0
    tp = rels_compare_df[f_tp][label_field].value_counts().rename("tp")
    fp = rels_compare_df[~f_tp][label_field].value_counts().rename("fp")
    f_fn = rels_df[match_field].apply(len) == 0
    fn = rels_df[f_fn][label_field].value_counts().rename("fn")
    support = rels_df[label_field].value_counts().rename("support")
    counts = (
        tp.to_frame()
        .join(fp, how="outer")
        .join(fn, how="outer")
        .join(support, how="outer")
        .join(n_pred)
        .fillna(0)
        .astype(int)
    )
    return counts


def confusion_matrix(ents_gold, ents_pred, partial=True):
    if partial:
        allowed_match_types = ["strict", "label", "exact", "overlap"]
    else:
        allowed_match_types = ["strict", "exact"]
    compare = entity_compare_best_match(
        ents_gold, ents_pred, allowed_ordered_match_types=allowed_match_types
    )
    compare_df = pd.DataFrame(compare)
    confusion_matrix = (
        compare_df[["label", "label_compare"]]
        .value_counts()
        .unstack()
        .fillna(0)
        .astype(int)
    )
    return confusion_matrix
