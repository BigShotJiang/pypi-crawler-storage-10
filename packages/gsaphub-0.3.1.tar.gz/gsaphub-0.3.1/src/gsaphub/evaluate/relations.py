from collections import defaultdict
from enum import Enum

import pandas as pd

from ..labels import RELATION_LABEL_TO_GROUP
from ..match.relations import exact as exact_match
from ..match.relations import get_matches_bidirectional
from ..match.relations import partial as partial_match


class RelationExtractionMetric(Enum):
    STRICT_MATCH = "RE+"
    STRICT_PARTIAL_MATCH = "RE+ partial"
    RELAXED_MATCH = "RE"
    RELAXED_PARTIAL_MATCH = "RE partial"


class ScoreType(Enum):
    F1 = "f1_score"
    PRECISION = "precision"
    RECALL = "recall"


def precision_recall_f1_partial(
    rels_gold, ents_gold, rels_pred, ents_pred, strict=True, show_counts=False
):
    re_metric = (
        [RelationExtractionMetric.STRICT_PARTIAL_MATCH]
        if strict
        else [RelationExtractionMetric.RELAXED_PARTIAL_MATCH]
    )
    return precision_recall_f1(
        rels_gold,
        ents_gold,
        rels_pred,
        ents_pred,
        re_metrics=re_metric,
        score_types=[ScoreType.F1, ScoreType.PRECISION, ScoreType.RECALL],
        show_counts=show_counts,
    )


def precision_recall_f1_exact(
    rels_gold, ents_gold, rels_pred, ents_pred, strict=True, show_counts=False
):
    re_metric = (
        [RelationExtractionMetric.STRICT_MATCH]
        if strict
        else [RelationExtractionMetric.RELAXED_MATCH]
    )
    return precision_recall_f1(
        rels_gold,
        ents_gold,
        rels_pred,
        ents_pred,
        re_metrics=re_metric,
        score_types=[ScoreType.F1, ScoreType.PRECISION, ScoreType.RECALL],
        show_counts=show_counts,
    )


def precision_recall_f1(
    rels_gold,
    ents_gold,
    rels_pred,
    ents_pred,
    re_metrics: list[RelationExtractionMetric] = [
        RelationExtractionMetric.STRICT_MATCH
    ],
    score_types: list[ScoreType] = [
        ScoreType.F1,
        ScoreType.PRECISION,
        ScoreType.RECALL,
    ],
    show_counts=True,
):
    score_type_top = len(score_types) < len(re_metrics)
    matches_gold, not_matched_pred = get_matches_bidirectional(
        rels_gold, ents_gold, rels_pred, ents_pred
    )
    counts = _count_matches(matches_gold, not_matched_pred)
    all_metrics = None
    base_info = None
    count_stats = None
    cols = []
    for re_metric in re_metrics:
        metrics = calc_metrics(counts[re_metric])
        metrics_ = metrics[[st.value for st in score_types]]
        if score_type_top:
            cols = pd.MultiIndex.from_tuples([
                (st.value, re_metric.value) for st in score_types
            ])
        else:
            cols = pd.MultiIndex.from_tuples([
                (re_metric.value, st.value) for st in score_types
            ])
        metrics_.columns = cols
        if all_metrics is None:
            metrics["relation_group"] = metrics["relation_label"].apply(
                RELATION_LABEL_TO_GROUP.get
            )
            cols = ["relation_group", "relation_label"]
            cols_h = [("relation", "group"), ("relation", "label")]
            all_metrics = metrics[cols]
            all_metrics.columns = pd.MultiIndex.from_tuples(cols_h)
            cols = ["predicted", "support"]
            cols_h = [("counts", c) for c in cols]
            count_stats = metrics[cols]
            count_stats.columns = pd.MultiIndex.from_tuples(cols_h)
        all_metrics = all_metrics.join(metrics_)
    if show_counts and all_metrics is not None:
        all_metrics = all_metrics.join(count_stats)
    all_metrics = all_metrics.sort_values(
        [("relation", "group"), ("relation", "label")], ascending=False
    )
    return all_metrics


def precision_recall_f1_group_mean(
    rels_gold, ents_gold, rels_pred, ents_pred, re_metrics, score_types
):
    metrics = precision_recall_f1(
        rels_gold, ents_gold, rels_pred, ents_pred, re_metrics, score_types, False
    )
    return (
        metrics.set_index(("relation", "label"))
        .groupby(("relation", "group"))
        .mean()
        .sort_index(ascending=False)
    )


def _count_matches(matches_a, not_matching_predictions):
    strict = {}
    exact = {}
    strict_partial = {}
    partial = {}
    for group in ["tp", "fn", "fp"]:
        for type_ in [strict, exact, strict_partial, partial]:
            type_[group] = defaultdict(int)
    for match_ in matches_a:
        rel_label = match_["relation_label"]
        rel_match_label = match_["relation_match_label"]
        if match_["relation_match_type"] == "same":
            if (
                match_["subject_match_type"] == "strict"
                and match_["object_match_type"] == "strict"
            ):
                strict["tp"][rel_label] += 1
            else:
                strict["fp"][rel_match_label] += 1
                strict["fn"][rel_label] += 1
            if match_["subject_match_type"] in {"strict", "label"} and match_[
                "object_match_type"
            ] in {"strict", "label"}:
                strict_partial["tp"][rel_label] += 1
            else:
                strict_partial["fp"][rel_match_label] += 1
                strict_partial["fn"][rel_label] += 1
            if match_["subject_match_type"] in {"strict", "exact"} and match_[
                "object_match_type"
            ] in {"strict", "exact"}:
                exact["tp"][rel_label] += 1
            else:
                exact["fp"][rel_match_label] += 1
                exact["fn"][rel_label] += 1
            if match_["subject_match_type"] in {
                "strict",
                "label",
                "exact",
                "overlap",
            } and match_["object_match_type"] in {
                "strict",
                "label",
                "exact",
                "overlap",
            }:
                partial["tp"][rel_label] += 1
            else:
                partial["fp"][rel_match_label] += 1
                partial["fn"][rel_label] += 1
        elif match_["relation_match_type"] in {
            "same_reverse",
            "differ",
            "differ_reverse",
        }:
            for type_ in strict, exact, strict_partial, partial:
                type_["fp"][rel_match_label] += 1
                type_["fn"][rel_label] += 1
        elif match_["relation_match_type"] == "NIL":
            for type_ in strict, exact, strict_partial, partial:
                type_["fn"][rel_label] += 1
        else:
            raise Exception(f"not known match_type: {match_['relation_match_type']}")
    for match_ in not_matching_predictions:
        rel_match_label = match_["relation_label"]
        for type_ in strict, exact, strict_partial, partial:
            type_["fp"][rel_match_label] += 1
    return {
        RelationExtractionMetric.STRICT_MATCH: _to_frame(strict),
        RelationExtractionMetric.RELAXED_MATCH: _to_frame(exact),
        RelationExtractionMetric.STRICT_PARTIAL_MATCH: _to_frame(strict_partial),
        RelationExtractionMetric.RELAXED_PARTIAL_MATCH: _to_frame(partial),
    }


def _to_frame(type_):
    type_ = pd.DataFrame(type_).fillna(0).astype(int)
    type_["predicted"] = type_.tp + type_.fp
    type_ = (
        type_.reset_index()
        .rename(columns=dict(index="relation_label"))
        .set_index("relation_label")
    )
    return type_


def calc_metrics(counts):
    metrics = counts.copy()
    labels = list(counts.index)
    metrics["support"] = metrics.tp + metrics.fn
    support = metrics.support.sum()
    predicted = metrics.predicted.sum()
    # Micro
    metrics.loc["micro"] = metrics.sum()

    # precision, recall f1
    metrics["precision"] = metrics.tp / (metrics.tp + metrics.fp)
    metrics["recall"] = metrics.tp / (metrics.tp + metrics.fn)
    metrics["f1_score"] = (2 * metrics.precision * metrics.recall) / (
        metrics.precision + metrics.recall
    )

    # dafault precision and recall to 0.
    metrics = metrics.fillna(0.0)

    # Macro
    metrics.loc["macro"] = metrics.loc[labels][
        ["precision", "recall", "f1_score"]
    ].mean()
    metrics.loc["macro", "support"] = support
    metrics.loc["macro", "predicted"] = predicted

    # Weighted
    weights = metrics.loc[labels].support / metrics.loc[labels].support.sum()
    label_scores = metrics.loc[labels][["precision", "recall", "f1_score"]]
    metrics.loc["weighted"] = label_scores.mul(weights, axis=0).sum()
    metrics.loc["weighted", "support"] = support
    metrics.loc["weighted", "predicted"] = predicted

    metrics["support"] = metrics.support.astype(int)
    metrics["predicted"] = metrics.predicted.astype(int)
    metrics = metrics.reset_index()
    return metrics
