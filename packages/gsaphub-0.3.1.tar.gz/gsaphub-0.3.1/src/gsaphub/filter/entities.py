from ..labels import ALLOWED_ENTITY_TYPES


def invalid_labels(ents):
    ents_filtered = []
    to_check = []
    for ent in ents:
        if ent["label"] not in ALLOWED_ENTITY_TYPES:
            to_check.append(ent)
            continue
        ents_filtered.append(ent)
    return ents_filtered, to_check


def annotator(ents, annotator):
    return _by_field(ents, annotator, "annotator")


def split(ents, split):
    return _by_field(ents, split, "split")


def _by_field(units, key, field):
    units = [u for u in units if u[field] == key]
    return units
