from ..match.spans import partial as spans_match_partial
from .relations import not_connected as filter_relations_not_connected


def by_text_units(ents, rels, text_units):
    # match ents with text_units
    spans_match_partial(ents, text_units, target_key="matched_text_units")
    text_units_dict = {t["id"]: t["text"] for t in text_units}
    text_unit_id_to_url = {t["id"]: t["url_inception"] for t in text_units}
    ents = [e for e in ents if len(e["matched_text_units"]) > 0]
    # add url_inception if not there:
    for e in ents:
        text_unit_id = e["matched_text_units"][0]
        if "url_inception" not in e:
            e["url_inception"] = text_unit_id_to_url[text_unit_id]
        e["text_unit_text"] = text_units_dict[text_unit_id]
    rels, _ = filter_relations_not_connected(rels, ents)
    ent_to_unit_text = {e["id"]: e["text_unit_text"] for e in ents}
    ent_to_url = {e["id"]: e["url_inception"] for e in ents}
    for rel in rels:
        rel["text_unit_text"] = ent_to_unit_text[rel["subject_id"]]
        rel["url_inception"] = ent_to_url[rel["subject_id"]]
    return ents, rels
