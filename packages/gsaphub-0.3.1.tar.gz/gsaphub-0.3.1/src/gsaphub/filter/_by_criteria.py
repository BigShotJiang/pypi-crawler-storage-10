from typing import Dict, List, Set


def by_exact_match(*groups, **kwargs):
    groups_filtered = []
    for things in groups:
        things_filtered = []
        for thing in things:
            keep = True
            for field, key in kwargs.items():
                if thing[field] != key:
                    keep = False
                    break
            if keep:
                things_filtered.append(thing)
        groups_filtered.append(things_filtered)
    groups_filtered = groups_filtered[0] if len(groups) == 1 else groups_filtered
    return groups_filtered


def by_doc_id_annotator(
    ent_or_rel: List[Dict[str, str]], allowed_doc_annotator: Set[str]
) -> List[Dict[str, str]]:
    """
    Filters a list of entities or relations based on allowed document annotators.

    Args:
        ent_or_rel (List[Dict[str, str]]): The list of entities or relations to filter.
        allowed_doc_annotator (Set[str]): The set of allowed document annotators.

    Returns:
        List[Dict[str, str]]: The filtered list of entities or relations.
    """
    allowed_doc_annotator = set(allowed_doc_annotator)
    ents_filtered = []
    for ent in ent_or_rel:
        key = ent["document_name"], ent["annotator"]
        if key in allowed_doc_annotator:
            ents_filtered.append(ent)
    return ents_filtered
