from .. import match


def corrupt(text_units, corrupt_annos):
    # match spans
    corrupt_annos = [c | dict(doc_id=c["doc_id"]) for c in corrupt_annos]
    match.spans.partial(text_units, corrupt_annos, target_key="corrupt_annotations")
    filtered_text_units = []
    skipped = 0
    for text_unit in text_units:
        if text_unit["corrupt_annotations"]:
            skipped += 1
        else:
            del text_unit["corrupt_annotations"]
            filtered_text_units.append(text_unit)
    return filtered_text_units, dict(text_units_with_corrupt_annotations=skipped)
