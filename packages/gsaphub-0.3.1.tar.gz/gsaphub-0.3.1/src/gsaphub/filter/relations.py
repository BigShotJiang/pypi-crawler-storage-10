from ..labels import ALLOWED_SIGNATURES


def invalid_signatures(rels, ents):
    allowed_sign = {tuple(s) for s in ALLOWED_SIGNATURES}
    rels_filtered = []
    ents = {e["id"]: e for e in ents}
    to_check = []
    for rel in rels:
        subj_label = ents.get(rel["subject_id"], {}).get("label", "not_found")
        rel_label = rel["relation_label"]
        obj_label = ents.get(rel["object_id"], {}).get("label", "not_found")
        signature = subj_label, rel_label, obj_label
        if signature in allowed_sign:
            rels_filtered.append(rel)
        else:
            to_check.append(rel)
    return rels_filtered, to_check


def not_connected(rels, ents):
    ent_ids = {e["id"] for e in ents}
    rels_filtered = []
    rels_deleted = []
    for rel in rels:
        if rel["subject_id"] not in ent_ids or rel["object_id"] not in ent_ids:
            rels_deleted.append(rel)
        else:
            rels_filtered.append(rel)
    return rels_filtered, rels_deleted


def drop_duplicates(rels, ents):
    ents = {e["id"]: e for e in ents}
    n_rels_deleted = 0
    rels_filtered = {}
    for rel in rels:
        subj = ents[rel["subject_id"]]
        obj = ents[rel["object_id"]]
        rel_key = (
            rel["doc_id"],
            rel["annotator"],
            subj["begin"],
            subj["end"],
            subj["label"],
            obj["begin"],
            obj["end"],
            obj["label"],
            rel["relation_label"],
        )
        if rel_key in rels_filtered:
            n_rels_deleted += 1
        else:
            rels_filtered[rel_key] = rel
    rels_filtered = list(rels_filtered.values())
    return rels_filtered, dict(n_rels_deleted=n_rels_deleted)
