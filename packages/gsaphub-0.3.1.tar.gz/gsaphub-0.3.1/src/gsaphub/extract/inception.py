import json
import zipfile
from copy import deepcopy
from io import BytesIO

from pycaprio import Pycaprio
from pycaprio.core.exceptions import InceptionBadResponse
from pycaprio.mappings import InceptionFormat

# Pycaprio function
DOCUMENT_NAME_BEGIN = {"000", "100", "300"}
SKIP_ANNOTATOR = {"Saurav", "Matt", "SHK"}


def _extract_docs_from_inception(project_id, layer_info, skip_new=True, limit=None):
    doc_anno_infos = _extract_docs_annotations_records(project_id, skip_new, limit)
    print()
    docs = []
    n_docs = 0
    for doc_anno_info in doc_anno_infos:
        print(
            f"\r{n_docs} document annotations for {len(doc_anno_infos)}",
            "document annotations loaded",
            end="",
        )
        doc = _extract_annotated_doc(doc_anno_info, layer_info)
        if doc is not None:
            n_docs += 1
            docs.append(doc)
    print()
    return docs


def _extract_docs_annotations_records(project_id, skip_new=True, limit=None):
    doc_rec_iter = Pycaprio().api.documents(project_id)
    all_doc_annotations = []
    n_found = 0
    for doc_rec in doc_rec_iter:
        if limit is not None and n_found >= limit:
            break
        if skip_new and str(doc_rec.document_state) == "NEW":
            continue
        doc_annotation_records = _extract_doc_annotation_records(project_id, doc_rec)
        print(
            f"\r{n_found + 1} document annotations records for",
            f"{len(doc_rec_iter)} document loaded {doc_rec.document_state}",
            f"({len(doc_annotation_records)} annotations doc {doc_rec})",
            end="",
        )
        for doc_anno_rec in doc_annotation_records:
            if doc_anno_rec["document_name"][:3] not in DOCUMENT_NAME_BEGIN:
                continue
            if doc_anno_rec["user_name"] in SKIP_ANNOTATOR:
                continue
            n_found += 1
            all_doc_annotations.append(doc_anno_rec)
    if limit is not None:
        all_doc_annotations = all_doc_annotations[:limit]
    return all_doc_annotations


def _extract_doc_annotation_records(project_id, doc):
    doc_annotations = []
    doc_anno_iter = Pycaprio().api.annotations(project_id, doc)
    for doc_anno in doc_anno_iter:
        doc_anno = _doc_annotation_record_as_dict(doc_anno)
        doc_anno["document_name"] = doc.document_name
        doc_annotations.append(doc_anno)
    # Load curation if possible
    curration_record = _extract_doc_curration_record(project_id, doc)
    if curration_record is not None:
        doc_annotations.append(curration_record)
    return doc_annotations


def _extract_doc_curration_record(project_id, doc):
    curration_record = None
    try:
        _curation = Pycaprio().api.curation(project_id, doc)
        curration_record = dict(
            project_id=project_id,
            document_id=doc.document_id,
            document_name=doc.document_name,
            user_name="curation",
        )
    except InceptionBadResponse:
        pass
    return curration_record


def _doc_annotation_record_as_dict(doc_annotation_record):
    date = doc_annotation_record.timestamp
    if date is not None:
        date = date.strftime("%Y-%m-%d")
    info = dict(
        project_id=doc_annotation_record.project_id,
        document_id=doc_annotation_record.document_id,
        user_name=doc_annotation_record.user_name,
        annotation_state=doc_annotation_record.annotation_state,
        date=date,
    )
    return info


# Extract doc annotations


def _extract_annotated_doc(
    annotation_info,
    layer_infos,
):
    layer_span = layer_infos["layer_entity"]
    layer_feature_span = layer_infos["layer_feature_entity"]
    layer_relation = layer_infos["layer_relation"]
    layer_feature_relation = layer_infos["layer_feature_relation"]
    target_layer = layer_infos["target_layer"]

    anno_data = load_uima_cas(annotation_info)
    if anno_data is None:
        return None
    # document_name = annotation_info["document_name"] if add_document_name else None
    # document_id_inception = annotation_info["document_id"]
    doc_text = anno_data["_referenced_fss"]["1"]["sofaString"]
    initial_view = anno_data["_views"]["_InitialView"]
    fss_dict = _load_fss_dict(anno_data)
    doc_layers = initial_view.keys()
    document_name = annotation_info["document_name"]
    # Do not try to load ents and relations if doc_layers do not exist
    if layer_span not in doc_layers and layer_relation not in doc_layers:
        return None
    ents = prepare_ents(
        initial_view, fss_dict, layer_span, layer_feature_span, doc_text
    )
    relations = prepare_relations(
        initial_view, fss_dict, layer_relation, layer_feature_relation, ents
    )
    if len(ents) == 0 and len(relations) == 0:
        return None
    doc = dict(
        text=doc_text,
        document_name=annotation_info["document_name"],
        inception_meta=annotation_info,
        annotations={target_layer: ents},
        relations={target_layer: relations},
    )
    return doc


def prepare_relations(
    initial_view, fss_dict, layer_relation, layer_feature_relation, entities
):
    relations = []
    rel_raw = initial_view.get(layer_relation, [])
    if rel_raw:
        entity_dict = {e["ref_id"]: e for e in entities}

        for rel in rel_raw:
            source_id = rel["Governor"]
            source = entity_dict[source_id]
            target_id = rel["Dependent"]
            target = entity_dict.get(target_id)
            if target is None:
                print("key is missing. Source exists:")
                print(source)
            else:
                rel = dict(
                    source_id=source_id,
                    source_text=source["text"],
                    source_label=source["label"],
                    relation_label=rel.get(layer_feature_relation, "Unknown"),
                    target_id=target_id,
                    target_text=target["text"],
                    target_label=target["label"],
                )
                relations.append(rel)
    return relations


def prepare_ents(initial_view, fss_dict, layer_span, layer_feature_span, doc_text):
    char_mapping = get_char_mapping(doc_text)
    ents_raw = initial_view.get(layer_span, [])
    ents_raw = deepcopy(ents_raw)
    ents = []
    for idx, ent in enumerate(ents_raw):
        if type(ent) is int:  # case (2) from comments
            ent = deepcopy(fss_dict[ent])
            ent["in_relation"] = True
            del ent[
                "_type"
            ]  # this is the type like `NER` in our case `ScholarlyEntity`
            del ent["sofa"]  # this is the reference text (in our case the whole doc)

        else:  # no id yet, add one
            ent["ref_id"] = f"_{idx}"
            ent["in_relation"] = False
            del ent["sofa"]
        if layer_feature_span in ent:  # have a label instead of a layer: label dict
            ent["label"] = ent[layer_feature_span]
            del ent[layer_feature_span]
        else:  # no label is given in the annotation!
            ent["label"] = "Unknown"
        ent["begin"] = ent.get("begin", 0)  # 0 is not mentioned in begin so add it.
        # correct char position (in inception a char with 4 bytes is counted as 2 chars)
        ent["begin"] = char_mapping[ent["begin"]]
        ent["end"] = char_mapping[ent["end"]]
        ent["text"] = doc_text[ent["begin"] : ent["end"]]
        ents.append(ent)
    return ents


def get_char_mapping(doc_text):
    """Necessary because of encoding problem of inception
    (multi byte utf-8 chars are counted as multiple chars)
    """
    mapping = []
    for idx, char in enumerate(doc_text):
        n_bytes = len(char.encode())
        mapping.append(idx)
        if n_bytes >= 4:
            mapping.append(idx)
    return mapping


def _load_fss_dict(anno_data):
    fss_dict = anno_data["_referenced_fss"]
    fss_dict = {int(k): v for k, v in fss_dict.items()}
    for key, fss in fss_dict.items():
        fss["ref_id"] = key
    return fss_dict


def load_uima_cas(annotation_info):
    project_id = annotation_info["project_id"]
    doc_id = annotation_info["document_id"]
    user_name = annotation_info["user_name"]
    # doc_json = annotation_info["document_name"][:-4] + ".json"
    # download the annotation infos in binary zip file
    if user_name == "curation":
        try:
            annotation_content = Pycaprio().api.curation(
                project_id,
                doc_id,
                curation_format=InceptionFormat.UIMA_CAS_JSON,
            )
        except Exception as e:
            print(f"\rNo UIMA CAS loadable: {doc_id} {user_name}", end="")
            return None
    else:
        try:
            annotation_content = Pycaprio().api.annotation(
                project_id,
                doc_id,
                user_name,
                annotation_format=InceptionFormat.UIMA_CAS_JSON,
            )
        except Exception as e:
            print(f"\rNo UIMA CAS loadable: {doc_id} {user_name}", end="")
            return None
    anno_zip = zipfile.ZipFile(BytesIO(annotation_content))
    fn_doc_jsons = [f for f in anno_zip.filelist if f.filename.endswith(".json")]
    assert len(fn_doc_jsons) == 1  # expect one json uima_cas_json for one document
    fn_doc_json = fn_doc_jsons[0]
    with anno_zip.open(fn_doc_json) as f:
        annos = json.load(f)
    return annos
