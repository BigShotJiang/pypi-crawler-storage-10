from flattentei import get_units


def _extract_annotations_from_docs(docs, target_layer, annotator_default=None):
    all_ents = []
    all_rels = []
    for doc in docs:
        ents, rels = _extract_annotations_from_doc(doc, target_layer, annotator_default)
        all_ents.extend(ents)
        all_rels.extend(rels)
    return all_ents, all_rels


def _extract_annotations_from_doc(doc, target_layer, annotator_default=None):
    ents, span_lines = _extract_ents(doc, target_layer, annotator_default)
    rels = list(_extract_relations(doc, target_layer, span_lines, annotator_default))
    return ents, rels


def _extract_ents(doc, target_layer, annotator_default):
    if annotator_default is not None:
        annotator = annotator_default
    else:
        annotator = doc["inception_meta"]["user_name"]
    document_name = doc["document_name"]
    spans_with_context = get_units(
        target_layer, doc, doc_id=document_name, enrich_container=["Sentence"]
    )
    for span_idx, span in enumerate(spans_with_context):
        # some entities (e.g., predictions from a model) might not have an id:
        if "id" not in span and "ref_id" not in span:
            span["ref_id"] = span_idx
        span["annotator"] = annotator
    entity_lines = {}
    # enrich ents with inception info (@todo: sometimes lines are not working)
    for span in spans_with_context:
        if "inception_meta" in doc:
            span["inception_meta"] = {k: v for k, v in doc["inception_meta"].items()}
        if "Line" in span["container"]:
            line_idx = span["container"]["Line"]["idx"]
            if "inception_meta" in span:
                span["inception_meta"]["line_idx"] = line_idx
            entity_lines[span["ref_id"]] = line_idx
        else:
            # this is a multiline annotation and not allowed
            # but in the data we found examples for that. @todo better handling
            print("unhandeled multiline entity")
    return spans_with_context, entity_lines


def _extract_relations(doc, target_layer, entity_lines, annotator_default=None):
    if annotator_default is not None:
        annotator = annotator_default
    else:
        annotator = doc["inception_meta"]["user_name"]
    document_name = doc["document_name"]
    relations = doc.get("relations", {}).get(target_layer, [])
    for rel in relations:
        rel["source_line_idx"] = entity_lines.get(rel["source_id"])
        rel["target_line_idx"] = entity_lines.get(rel["source_id"])
        if "inception_meta" in doc:
            rel["inception_meta"] = doc["inception_meta"]
        rel["document_name"] = document_name
        rel["annotator"] = annotator
        yield rel
