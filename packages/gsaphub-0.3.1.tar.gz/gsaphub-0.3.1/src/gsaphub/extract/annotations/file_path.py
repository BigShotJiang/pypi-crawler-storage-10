from pathlib import Path

from .._extract import json_file


def file_path(path):
    path = Path(path)
    fn_ents = path / "entities.json"
    fn_rels = path / "relations.json"
    ents = json_file(fn_ents)
    rels = json_file(fn_rels)
    return ents, rels
