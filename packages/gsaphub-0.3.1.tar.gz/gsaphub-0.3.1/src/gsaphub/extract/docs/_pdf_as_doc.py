# load pdf file, extract text via grobid api, and transform into json
from glob import glob
from pathlib import Path

from io import BytesIO
import requests
from flattentei.tei_to_text_and_standoff import transform_xml

def _extract_docs_from_pdf_folder(folder, grobid_server):
    files = glob(f"{folder}/*.pdf")
    # Save config as temp file (needed for grobid_client)
    # iterate over pdf files
    for pdf_idx, fn_pdf in enumerate(files, start=1):
        with open(fn_pdf, "rb") as f:
            pdf_binary = f.read()
            doc = _extract_doc_from_pdf_binary(pdf_binary, grobid_server)
            doc["pdf_filename"] = Path(fn_pdf).name
            yield doc

GROBID_PARAMS = {
        "consolidateCitations": 1,
        "segmentSentences": 1,
        "includeRawCitations": 1,
        "teiCoordinates": ["persName", "figure", "ref" "biblStruct", "formula", "s"] ,
        #"start": 1,
        #"end": 2,
}

def _extract_doc_from_pdf_binary(pdf_binary, grobid_server, grobid_params=GROBID_PARAMS):
    url = f"{grobid_server}/api/processFulltextDocument"
    headers = {
        "Accept": "application/xml"
    }
    files = {
        "input": BytesIO(pdf_binary)
    }
    response = requests.post(url, headers=headers, files=files, data=grobid_params)
    if response.status_code != 200:
        raise Exeception("PDF Processing not working")
    xml = BytesIO(response.text.encode('utf-8'))
    text, annotations = transform_xml(xml)
    doc = dict(text=text, annotations=annotations)
    return doc

