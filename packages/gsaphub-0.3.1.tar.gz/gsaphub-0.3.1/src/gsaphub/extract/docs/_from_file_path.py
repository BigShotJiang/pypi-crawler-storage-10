import json
from glob import glob
from pathlib import Path


def _extract_doc_from_file_path_by_ids(path_docs: str, doc_ids: set[str]):
    # add annotator to filename if needed and use .json (e.g., 01.txt => "01_Rudi.json")
    docs = []
    for fn in glob(f"{Path(path_docs)}/*.json"):
        doc_id = Path(fn).stem + ".txt"
        if doc_id in doc_ids:
            doc = _extract_doc_from_file_path_by_id(path_docs, doc_id)
            docs.append(doc)
    return docs


def _extract_doc_from_file_path_by_id(path_docs: str, doc_id: str, annotator=None):
    # add annotator to filename if needed and use .json (e.g., 01.txt => "01_Rudi.json")
    annotator = "" if annotator is None else f"_{annotator}"
    if doc_id.endswith(".txt"):
        doc_id = doc_id[:-4]
    doc_filename = Path(f"{doc_id}{annotator}.json")
    path_to_doc = Path(path_docs) / doc_filename
    if path_to_doc.exists():
        with path_to_doc.open("r") as f:
            doc = json.load(f)
            if "document_name" not in doc:
                doc["document_name"] = doc_id + ".txt"
        return doc
    return None
