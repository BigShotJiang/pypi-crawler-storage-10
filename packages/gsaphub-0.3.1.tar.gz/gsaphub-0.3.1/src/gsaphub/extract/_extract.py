import json


def json_file(fn):
    with open(fn, "r") as f:
        content = json.load(f)
    return content
