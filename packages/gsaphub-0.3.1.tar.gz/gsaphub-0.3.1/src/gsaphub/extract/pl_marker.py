import json
from itertools import chain


def plmarker_file(fn_docs, fn_docs_token_spans, annotator):
    # Correct token spans (reproduced)
    docs = load_docs(fn_docs, fn_docs_token_spans)
    spans_pred = extract_spans_pred(docs, annotator)
    rels_pred = extract_relations(docs, spans_pred, annotator)
    return spans_pred, rels_pred


def load_docs(fn_docs, fn_docs_info):
    if fn_docs_info:
        docs = load_docs(fn_docs_info, None)
        doc_token_spans = {d["doc_id"]: d["doc_token_spans"] for d in docs}
        doc_urls_inception = {d["doc_id"]: d["url_inception"] for d in docs}
    else:
        doc_token_spans = None
    docs = []
    with open(fn_docs) as f:
        for line in f.readlines():
            doc = json.loads(line)
            if fn_docs_info:
                doc["doc_token_spans"] = doc_token_spans[doc["doc_id"]]
                doc["url_inception"] = doc_urls_inception[doc["doc_id"]]
            docs.append(doc)
    return docs


def extract_spans_pred(docs, annotator):
    spans = []
    for doc in docs:
        doc_ents_preds = extract_doc_spans_pred(doc, annotator)
        spans.extend(doc_ents_preds)
    # set id
    spans = [e | dict(ref_id=idx) for idx, e in enumerate(spans)]
    return spans


def extract_doc_spans_pred(doc, annotator):
    doc_id = doc["doc_id"]
    token_idx_to_span = doc["doc_token_spans"]
    spans = {}
    for sent_idx, ent_sent in enumerate(doc["predicted_ner_proba"]):
        ents_gold = doc["ner"][sent_idx]
        span_to_label_gold = {(begin, end): label for begin, end, label in ents_gold}
        add_link = "url_inception" in doc
        if add_link:
            url_inception = doc["url_inception"][sent_idx]
        for begin, end, prob, label in ent_sent:
            label_gold = span_to_label_gold.get((begin, end), "NIL")
            text = doc["doc_tokens"][begin : end + 1]
            text = " ".join(text)
            begin_char = token_idx_to_span[begin][0]
            end_char = token_idx_to_span[end][1]
            spans[(doc_id, begin, end)] = dict(
                key=(doc_id, begin, end),
                doc_id=doc_id,
                label="NIL",
                text=text,
                begin=begin_char,
                end=end_char,
                begin_token=begin,
                end_token=end,
                label_gold=label_gold,
                is_ent=False,
                in_rel=False,
                annotator=annotator,
                prob_prune=prob,
                url_inception=url_inception if add_link else None,
            )
    # add predicted label info
    for ent_sent in doc["predicted_ner_proba"]:
        for begin, end, label, score in ent_sent:
            key = doc_id, begin, end
            span = spans[key]
            span["label"] = label
            span["is_ent"] = True
            span["score"] = score

    return list(spans.values())


def extract_relations(docs, ents_pred, annotator):
    spans_pred_dict = {e["key"]: e for e in ents_pred}
    rels = []
    skipped = 0
    for doc in docs:
        rels_doc, skipped_doc = extract_doc_relations(doc, spans_pred_dict, annotator)
        rels.extend(rels_doc)
        skipped += skipped_doc
    rels = [r | dict(id=idx) for idx, r in enumerate(rels)]
    print(f"{skipped} rels skipped, subj. or obj. not in ents")
    return rels


def extract_doc_relations(doc, ents_pred_dict, annotator):
    doc_id = doc["doc_id"]
    doc_rels = []
    skipped = 0
    for sent_idx, sent_rel in enumerate(doc.get("predicted_rel_proba", [])):
        add_link = "url_inception" in doc
        if add_link:
            url_inception = doc["url_inception"][sent_idx]
        for s_b, s_e, o_b, o_e, relation_label, score in sent_rel:
            subj_key = doc_id, s_b, s_e
            obj_key = doc_id, o_b, o_e
            if subj_key not in ents_pred_dict or obj_key not in ents_pred_dict:
                skipped += 1
                continue
            subject = ents_pred_dict[subj_key]
            subject["in_rel"] = True
            subject_id = subject["ref_id"]
            obj = ents_pred_dict[obj_key]
            obj["in_rel"] = True
            object_id = obj["ref_id"]
            rel = dict(
                doc_id=doc_id,
                annotator=annotator,
                source_id=subject_id,
                relation_label=relation_label,
                target_id=object_id,
                score=score,
            )
            if add_link:
                rel["url_inception"] = url_inception
            doc_rels.append(rel)
    return doc_rels, skipped
