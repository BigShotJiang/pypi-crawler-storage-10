# load identifier from:
# * metadata files
# * gql
# * for matching of documuments, chunks, (Sentences?)

# Documents

from gql import gql


async def user_ids(client):
    QUERY_USER_IDS = """
    mutation ($input: UserListInput = {}) {
      userList(input: $input) {
          results {
                userId
                      username
                          }
                            }
                            }
                            """
    user_result = await client.execute_async(gql(QUERY_USER_IDS))
    user = user_result.get("userList", {}).get("results")
    name_to_user_id = {u["username"]: u["userId"] for u in user}
    return name_to_user_id


async def document_ids(client):
    QUERY_DOC_IDS = """
    query {
        documentsList {
            id
            documentName
            inceptionDocumentId
            url
        }
    }"""
    docs_result = await client.execute_async(gql(QUERY_DOC_IDS))
    docs = docs_result.get("documentsList")
    return docs


async def line_ids(client):
    QUERY = """
        query { chunksList {
          id
          docId
          inceptionLine
          beginIdx
          }
        }"""
    chunk_results = await client.execute_async(gql(QUERY))
    chunk_ids = chunk_results["chunksList"]
    return chunk_ids


async def entity_ids(client, layer="GSAP"):
    QUERY = """query  ($layer: String!) {
      spansList(condition: {layer: $layer}) {
        id
        label
        begin: beginIdx
        end: endIdx
        docId
        userId
        layer
      }
    }
    """
    chunk_results = await client.execute_async(
        gql(QUERY), variable_values=dict(layer=layer)
    )
    chunk_ids = chunk_results["spansList"]
    return chunk_ids


async def relation_ids(client):
    QUERY = """{
          relationsList {
            id
            relation
            userId
            object
            subject
          }
        }
    """
    chunk_results = await client.execute_async(gql(QUERY))
    chunk_ids = chunk_results["relationsList"]
    return chunk_ids
