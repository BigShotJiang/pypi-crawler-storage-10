from collections import defaultdict

from ..labels import GSAP_TYPES_WITH_SUBTYPES


def sub_types(ents):
    """
    Count the sublabels of entities found in 'sublabel' field.

    Parameters:
    ents (list[dict]): The entities.

    Returns:
    dict: The sublabel counts by label keys.
    """
    stats = {
        label: dict(valid=defaultdict(int), invalid=defaultdict(int))
        for label in GSAP_TYPES_WITH_SUBTYPES
    }
    for ent in ents:
        label = ent["label"]
        label_sub = ent.get("label_sub")
        allowed_subtypes = GSAP_TYPES_WITH_SUBTYPES.get(label)
        if allowed_subtypes is not None:
            correct = label_sub in allowed_subtypes
            stats[label]["valid" if correct else "invalid"][label_sub] += 1
    return stats
