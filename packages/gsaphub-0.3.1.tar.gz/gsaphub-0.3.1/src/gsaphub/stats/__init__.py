from . import annotations, corpus, entities, relations

__all__ = ["relations", "entities", "annotations", "corpus"]
