from itertools import chain


def overview(text_units, ents, rels):
    stats = {}
    entity_types = {e["label"] for e in ents}
    stats["n_entity_types"] = len(entity_types)
    relation_types = {r["relation_label"] for r in rels}
    stats["n_relation_types"] = len(relation_types)
    n_ents = len(ents)
    stats["n_entities"] = n_ents
    n_rels = len(rels)
    stats["n_relations"] = n_rels
    ents_in_rels = len(set(chain(*[[r["subject_id"], r["object_id"]] for r in rels])))
    stats["ents_in_rels"] = ents_in_rels
    stats["ents_in_rels_relative"] = ents_in_rels / n_ents
    doc_ids = {tu["doc_id"] for tu in text_units}
    n_docs = len(doc_ids)
    stats["n_docs"] = n_docs
    n_sents = len(text_units)
    stats["n_sentences"] = n_sents
    stats["relations_by_doc"] = n_rels / n_docs
    stats["sentences_by_doc"] = n_sents / n_docs
    n_null_sentences = len([tu for tu in text_units if len(tu["annotations"]) == 0])
    stats["n_null_sentences"] = n_null_sentences
    stats["n_not_null_sentences"] = len(text_units) - n_null_sentences
    stats["null_sentences_relative"] = n_null_sentences / len(text_units)
    return stats
