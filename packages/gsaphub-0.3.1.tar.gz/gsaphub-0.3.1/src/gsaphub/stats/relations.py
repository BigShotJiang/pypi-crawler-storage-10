from collections import Counter, defaultdict


def signature_counts(rels, ents):
    ents = {e["id"]: e for e in ents}
    sign_stats = defaultdict(list)
    for rel in rels:
        subj = ents[rel["subject_id"]]
        obj = ents[rel["object_id"]]
        annotator = rel["annotator"]
        sign = subj["label"], rel["relation_label"], obj["label"]
        sign_stats[annotator].append(sign)
        sign_stats["all"].append(sign)
    sign_stats_final = {}
    for key, signatures in sign_stats.items():
        sign_stats_final[key] = dict(Counter(signatures).most_common())
    return sign_stats_final
