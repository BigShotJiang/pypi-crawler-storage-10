def documents_annotated(rels, ents):
    stats = {}
    docs_with_ents = {e["doc_id"] for e in ents}
    docs_with_rels = {r["doc_id"] for r in rels}
    docs_without_rels = docs_with_ents - docs_with_rels
    stats_annotator = dict(
        n_docs_with_ents=len(docs_with_ents),
        n_docs_with_rels=len(docs_with_rels),
        n_docs_without_rels=len(docs_without_rels),
    )
    stats["all_annotator"] = stats_annotator
    # by annotator
    annotators = {e["annotator"] for e in ents}
    for annotator in annotators:
        docs_with_ents = {e["doc_id"] for e in ents if e["annotator"] == annotator}
        docs_with_rels = {r["doc_id"] for r in rels if r["annotator"] == annotator}
        docs_without_rels = docs_with_ents - docs_with_rels
        stats_annotator = dict(
            n_docs_with_ents=len(docs_with_ents),
            n_docs_with_rels=len(docs_with_rels),
            n_docs_without_rels=len(docs_without_rels),
            docs_without_rels=list(docs_without_rels),
        )
        stats[annotator] = stats_annotator
    return stats
