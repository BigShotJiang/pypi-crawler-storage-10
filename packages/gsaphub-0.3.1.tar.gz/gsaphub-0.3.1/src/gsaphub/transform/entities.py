from collections import defaultdict

from ..labels import ENTITY_MAPPING


def relabel(ents):
    label_changed = defaultdict(int)
    for ent in ents:
        mapped_label = ENTITY_MAPPING.get(ent["label"])
        if mapped_label is not None:
            label_changed[(ent["label"], mapped_label)] += 1
            ent["label"] = mapped_label
    return label_changed
