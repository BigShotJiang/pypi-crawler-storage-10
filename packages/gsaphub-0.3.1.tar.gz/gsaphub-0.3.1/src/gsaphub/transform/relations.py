from collections import Counter, defaultdict

from ..labels import RELATION_INVERSE, RELATION_MAPPING, SYMMETRIC_RELATIONS


def deduplicate(relations):
    known = set()
    deduplicated = []
    for rel in relations:
        key = rel["subject_id"], rel["relation_label"], rel["object_id"]
        if key not in known:
            deduplicated.append(rel)
            known.add(key)
    stats = dict(n_duplicates_deleted=len(relations) - len(deduplicated))
    return deduplicated, stats


def unify_undirected_default(relations, ents):
    unify_undirected(relations, ents, SYMMETRIC_RELATIONS)


def unify_undirected(relations, ents, symmetric_relations):
    ents = {e["id"]: e for e in ents}
    reverse = defaultdict(int)
    kept = defaultdict(int)
    for relation in relations:
        if relation["relation_label"] in symmetric_relations:
            subj = ents[relation["subject_id"]]
            obj = ents[relation["object_id"]]
            if subj["begin"] > obj["begin"]:
                reverse[relation["annotator"]] += 1
                relation["subject_id"], relation["object_id"] = (
                    relation["object_id"],
                    relation["subject_id"],
                )
            else:
                kept[relation["annotator"]] += 1
    return dict(reverse=dict(reverse), kept=dict(kept))


def relabel(rels, ents):
    ents = {e["id"]: e for e in ents}
    changes = []
    for rel in rels:
        change = _relabel_relation(rel, ents)
        if change is not None:
            changes.append(change)
    _invert_relations(rels)
    return dict(Counter(changes).most_common())


def _relabel_relation(rel, ents):
    old_label = rel["relation_label"]
    subject_label = ents[rel["subject_id"]]["label"]
    object_label = ents[rel["object_id"]]["label"]
    new_label = RELATION_MAPPING.get((subject_label, old_label, object_label))
    if new_label is not None:
        rel["relation_label"] = new_label
        return old_label, new_label


def _invert_relations(rels):
    for rel in rels:
        if rel["relation_label"] in RELATION_INVERSE:
            rel["subject_id"], rel["object_id"] = rel["object_id"], rel["subject_id"]
