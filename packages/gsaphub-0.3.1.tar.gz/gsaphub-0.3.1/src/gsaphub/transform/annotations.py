from ..check.annotations import id_consistency
from .entities import relabel as _relabel_entities
from .relations import relabel as _relabel_relations


def relabel(ents, rels):
    stats_rel_mapping = _relabel_relations(rels, ents)
    stats_ent_mapping = _relabel_entities(ents)
    stats = dict(
        stats_rel_mapping=stats_rel_mapping, stats_ent_mapping=stats_ent_mapping
    )
    return stats


def reset_ids(ents, rels):
    to_new_format(ents, rels)
    ent_key_fields = ["doc_id", "annotator", "id"]
    subj_key_fields = ["doc_id", "annotator", "subject_id"]
    obj_key_fields = ["doc_id", "annotator", "object_id"]
    ent_id_mapping = _map_ent_ids(ents, ent_key_fields)
    _map_rel_subj_obj(rels, ent_id_mapping, subj_key_fields, obj_key_fields)
    _clean_rel_fields(rels)
    # add rel ids:
    for rel_idx, rel in enumerate(rels):
        rel["id"] = rel_idx
    id_consistency(ents, rels)


def to_new_format(ents, rels):
    if ents:
        ent = ents[0]
        if "ref_id" in ent:
            for ent in ents:
                ent["id"] = ent["ref_id"]
                del ent["ref_id"]
    if rels:
        rel = rels[0]
        if "source_id" in rel:
            for rel in rels:
                rel["subject_id"] = rel["source_id"]
                del rel["source_id"]
                rel["object_id"] = rel["target_id"]
                del rel["target_id"]
    _use_doc_id(ents)
    _use_doc_id(rels)


def _map_ent_ids(ents, ent_key_fields):
    """set new ent ids and create a map from the ent_key_fields to the new id"""
    ent_id_mapping = {}
    for idx, ent in enumerate(ents):
        key = tuple(ent[k] for k in ent_key_fields)
        ent_id_mapping[key] = idx
        ent["id"] = idx
    return ent_id_mapping


def _map_rel_subj_obj(rels, ent_id_mapping, subj_key_fields, obj_key_fields):
    for rel in rels:
        subj_key = tuple(rel[k] for k in subj_key_fields)
        obj_key = tuple(rel[k] for k in obj_key_fields)
        rel["subject_id"] = ent_id_mapping[subj_key]
        rel["object_id"] = ent_id_mapping[obj_key]


def _clean_rel_fields(rels):
    for rel in rels:
        # Delete source and target keys to be more flexible
        current_keys = list(rel.keys())
        for key in current_keys:
            if key.startswith("source") or key.startswith("target"):
                del rel[key]


def _use_doc_id(annos):
    for anno in annos:
        if "document_name" in anno and "doc_id" not in anno:
            anno["doc_id"] = anno["document_name"]
            del anno["document_name"]
        else:
            assert "doc_id" in anno
