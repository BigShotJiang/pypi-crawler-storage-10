from .annotations import to_new_format as annotations_to_new_format


def to_new_format(text_units):
    for sent in text_units:
        ents = sent["annotations"]
        rels = sent["relations"]
        annotations_to_new_format(ents, rels)
