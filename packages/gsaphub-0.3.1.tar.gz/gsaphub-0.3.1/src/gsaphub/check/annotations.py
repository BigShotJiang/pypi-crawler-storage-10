def id_consistency(ents, rels):
    # import pdb; pdb.set_trace()
    ent_ids = {e["id"] for e in ents}
    for rel in rels:
        if rel["subject_id"] not in ent_ids or rel["object_id"] not in ent_ids:
            raise Exception("Relation with not valid subject or object id found")
