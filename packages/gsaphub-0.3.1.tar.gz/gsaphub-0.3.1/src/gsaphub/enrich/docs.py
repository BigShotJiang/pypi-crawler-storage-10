from ..extract.docs._from_file_path import _extract_doc_from_file_path_by_id


def spans_from_source_docs(docs, path_source_docs):
    """
    Add span annotations based on source docs
    (e.g., grobid extractions like Paragraph and
    Sentence spans as well as reference strings and other)
    """
    for doc in docs:
        doc_id = doc["document_name"]
        doc_source = _extract_doc_from_file_path_by_id(path_source_docs, doc_id)
        if doc_source is not None:
            for layer, spans in doc_source["annotations"].items():
                if layer in doc:
                    print("layer overwritten!!!!")
                doc["annotations"][layer] = spans
