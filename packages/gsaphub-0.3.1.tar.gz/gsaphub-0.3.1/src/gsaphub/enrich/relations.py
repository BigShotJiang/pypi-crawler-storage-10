from ._graphql_ids import gql_doc_id as gql_doc_id
from ._graphql_ids import gql_user_id as gql_user_id
from ._graphql_ids import relation_entity_joiner as gql_entity_ids
from ._graphql_ids import relation_gql_rel_id as gql_relation_id


def entity_info(
    relations,
    entities,
    ent_fields_to_enrich=["label", "text", "ref_cluster_id", "score", "begin", "end"],
):
    ents = {e["id"]: e for e in entities}
    for relation in relations:
        for related in ["subject", "object"]:
            related_ent_id = relation[f"{related}_id"]
            related_ent = ents[related_ent_id]
            if related == "subject":
                url = related_ent.get("url_inception")
                if url is not None:
                    relation["url_inception"] = url
            for field in ent_fields_to_enrich:
                if field not in related_ent:
                    continue
                relation[f"{related}_{field}"] = related_ent[field]


def character_distance(relations, entities):
    """returns the distance in number of characters between subject and object.
    If subject and object are overlapping return None
    """
    ent_to_begin = {e["id"]: e["begin"] for e in entities}
    ent_to_end = {e["id"]: e["end"] for e in entities}

    def get_distance(ent_id, ent_id_other):
        if ent_to_end[ent_id] < ent_to_begin[ent_id_other]:
            return ent_to_begin[ent_id_other] - ent_to_end[ent_id]
        elif ent_to_end[ent_id_other] < ent_to_begin[ent_id]:
            return ent_to_begin[ent_id] - ent_to_end[ent_id_other]

    for rel in relations:
        distance = get_distance(rel["subject_id"], rel["object_id"])
        if distance is not None:
            rel["distance"] = distance

def is_inner_line(relations, entities):
    return is_inner_container(relations, entities, "Line")

def is_inner_sentence(relations, entities):
    return is_inner_container(relations, entities, "Sentence")

def is_inner_paragraph(relations, entities):
    return is_inner_container(relations, entities, "Paragraph")

def is_inner_container(relations, entities, container_type):
    target_key = f"is_inner_{container_type.lower()}"
    ent_to_container_id = {(e["doc_id"], e["annotator"], e["id"]): _get_container_id(e, container_type) for e in entities}
    # make sure, that the ids are really unique:
    assert len(ent_to_container_id) == len(entities) 
    for rel in relations:
        is_inner = False
        subj_container_id = ent_to_container_id.get((rel["doc_id"], rel["annotator"], rel["subject_id"]))
        obj_container_id = ent_to_container_id.get((rel["doc_id"], rel["annotator"], rel["object_id"]))
        # if one of the two entities are not in a "sentence" (e.g. heading)
        if subj_container_id is not None and obj_container_id is not None:
            is_inner = subj_container_id == obj_container_id
        rel[target_key] = is_inner
    
def _get_container_id(entity, container_type):
    container = entity["container"].get(container_type)
    if container is not None:
        container_idx = container["idx"]
        return entity["doc_id"], container_idx

__all__ = [
    "gql_user_id",
    "gql_doc_id",
    "gql_relation_id",
    "gql_entity_ids",
    "entity_info",
    "character_distance",
    "is_inner_container",
]
