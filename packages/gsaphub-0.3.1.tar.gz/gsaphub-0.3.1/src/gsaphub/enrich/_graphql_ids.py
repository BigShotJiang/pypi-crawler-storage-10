def gql_user_id(ents, user_dict):
    for ent in ents:
        annotator = ent["annotator"]
        ent["gql_user_id"] = user_dict[annotator]
    return ents


def gql_doc_id(ents, doc_ids):
    doc_mapping = {d["documentName"]: d["id"] for d in doc_ids}
    for ent in ents:
        doc_id = ent["doc_id"]
        ent["gql_doc_id"] = doc_mapping[doc_id]
    return ents


def entity_gql_chunk_id(ents, chunk_ids):
    line_mapping = {
        (chunk["docId"], chunk["inceptionLine"]): chunk for chunk in chunk_ids
    }
    n_no_line = 0
    for ent in ents:
        # container line
        container_line = ent["container"].get("Line")
        if container_line:
            line_begin_in_doc = container_line["begin_in_doc"]
        else:
            line_begin_in_doc = -1
        doc_id = ent["gql_doc_id"]
        line_idx = ent["inception_meta"].get("line_idx")
        if line_idx is not None:
            line_idx += 1
            line_info = line_mapping[(doc_id, line_idx)]
            assert ent["begin"] >= line_info["beginIdx"]
            assert line_begin_in_doc != -1
            assert line_begin_in_doc == line_info["beginIdx"]
            ent["gql_chunk_id_start"] = line_info["id"]
            ent["gql_chunk_id_end"] = line_info["id"]
        else:
            lines = _get_all_lines(ent)
            # pprint(len(lines))
            if len(lines) == 0:
                # pprint(ent)
                n_no_line += 1
            else:
                line_idx = lines[0]["idx"] + 1
                line_info = line_mapping[(doc_id, line_idx)]
                if ent["begin"] < line_info["beginIdx"]:
                    print(ent["label"], "no line")
                    n_no_line += 1
                    continue
                    print(ent["begin"], line_info["beginIdx"])
                    print("ent")
                    print(ent)
                    print("line")
                    print(line_info)
                    print("ent_lines")
                    print(lines)
                assert ent["begin"] >= line_info["beginIdx"]
                assert lines[0]["begin_in_doc"] == line_info["beginIdx"]
                ent["gql_chunk_id_start"] = line_info["id"]
                ent["gql_chunk_id_end"] = line_info["id"]
                # print(lines[0])
            # print("no_line", ent)
    print(f"While enriching chunk ids: {n_no_line} ents have no line. Need FIX!")
    return ents


def entity_gql_ent_id(ents, entity_ids):
    """
    {'id': 1, 'label': 'MLModel', 'begin': 0, 'end': 4, 'docId': 2, 'userId': 22}
    """
    ent_mapping = {
        (e["docId"], e["userId"], e["begin"], e["end"], e["label"]): e["id"]
        for e in entity_ids
    }
    for ent in ents:
        key = (
            ent["gql_doc_id"],
            ent["gql_user_id"],
            ent["begin"],
            ent["end"],
            ent["label"],
        )
        ent["gql_id"] = ent_mapping.get(key)
    return ents


def relation_gql_rel_id(relations, relation_ids):
    rel_mapping = {
        (r["subject"], r["relation"], r["object"]): r["id"] for r in relation_ids
    }
    for rel in relations:
        key_relation = (
            rel["gql_subject_ent_id"],
            rel["relation_label"],
            rel["gql_object_ent_id"],
        )
        gql_rel_id = rel_mapping.get(key_relation)
        rel["gql_id"] = gql_rel_id
    return relations


def relation_entity_joiner(relations, ents, key_ent_id="id"):
    ent_mapping = {
        (e["gql_doc_id"], e["gql_user_id"], e[key_ent_id]): e["gql_id"] for e in ents
    }
    for rel in relations:
        subject_key = (rel["gql_doc_id"], rel["gql_user_id"], rel["subject_id"])
        subject = ent_mapping.get(subject_key)
        rel["gql_subject_ent_id"] = subject
        object_key = (rel["gql_doc_id"], rel["gql_user_id"], rel["object_id"])
        obj = ent_mapping.get(object_key)
        rel["gql_object_ent_id"] = obj
    return relations


def _get_all_lines(ent):
    # lines_inside:
    lines_inside = [e for e in ent.get("annotations", []) if e.get("type") == "Line"]
    lines_overlap = [
        e for e in ent.get("annotations_overlap", []) if e.get("type") == "Line"
    ]
    lines = lines_inside + lines_overlap
    lines.sort(key=lambda x: x["begin_in_doc"])
    return lines
