def enrich_doc_coref(
    doc,
    key_subject=["doc_id", "annotator", "subject_id"],
    key_object=["doc_id", "annotator", "object_id"],
    key_entity=["doc_id", "annotator", "id"],
    target_key_coref="coreference_cluster_paragraph",
    coref_start_id=0,
    layer="Scholarly",
):
    """
    Enrich entity information based on coreference clusters derived from relationships.

    This function takes two dataframes: one containing entity information (`ent_df`) and
    another containing relationship information (`rel_df`).
    It uses the `get_cluster_index` function to identify clusters of coreferent entities
    within the relationship data.
    If clusters are identified, it enriches the entity dataframe with these clusters
    using the `enrich_entities` function.

    Args:
        doc (dict): The document in the flattei format
        @todo add all args

    Returns:
        int: The maximum id used for coreferences
    """
    entities = doc["annotations"][layer]
    relations = doc["relations"][layer]
    coref_start_id = reference_cluster_ids(
        entities,
        relations,
        key_subject,
        key_object,
        key_entity,
        target_key_coref,
        coref_start_id=coref_start_id,
    )
    return coref_start_id

def reference_cluster_ids(
    entities,
    relations,
    key_subject,
    key_object,
    key_entity,
    target_key_coref,
    coref_start_id=0,
):
    # Clean old reference cluster ids
    for ent in entities:
        if target_key_coref in ent:
            del ent[target_key_coref]
    coref_relations = extract_coref_id_tuples(relations, key_subject, key_object)
    coref_cluster_mapping = vertices_to_connected_component_mapping(coref_relations)
    coref_cluster_mapping = {
        ent: cluster_id + coref_start_id
        for ent, cluster_id in coref_cluster_mapping.items()
    }
    coref_start_id += max(set(coref_cluster_mapping.values()))
    enrich_entities_with_mapping(
        entities, coref_cluster_mapping, key_entity, target_key_coref
    )
    # add coref id also to single entities (no coref relation)
    for ent in entities:
        if target_key_coref not in ent:
            coref_start_id += 1
            ent[target_key_coref] = coref_start_id
    return coref_start_id


def enrich_entities_with_mapping(
    entities, entity_cluster_mapping, key_entity, target_key_coref
):
    """
    Enrich entities DataFrame with coreference cluster information.

    Args:
        entities (list[dict]): List containing the entities.
        entity_cluster_mapping (dict): Mapping of each vertex to its
            corresponding component.
        key_entity (list):
        target_key_coref (str): Target key to add the coref cluster info

    Returns:
        entities (list[dict]): including coreference cluster information.
    """
    for ent in entities:
        key = tuple(ent[k] for k in key_entity)
        if key in entity_cluster_mapping:
            ent[target_key_coref] = entity_cluster_mapping[key]

    return entities


def extract_coref_id_tuples(
    relations, key_subject, key_object, coreference_relation_label="coreference"
):
    """
    Extract coreference relations and transform them into clusters.

    Args:
        relations (list[dict]): relations

    Returns:
        list: A list of id tuples.
    """
    coref_relation_tuples = []
    if relations is not None:
        for rel in relations:
            if rel["relation_label"] != coreference_relation_label:
                continue
            subject_id = tuple(rel[key] for key in key_subject)
            object_id = tuple(rel[key] for key in key_object)
            coref_relation_tuples.append((subject_id, object_id))
    return coref_relation_tuples


def vertices_to_connected_component_mapping(edges):
    """
    Transform coreference relations into clusters of connected components.

    Args:
        edges (list of tuples): A list of edges where each edge is a tuple
            of two vertices.

    Returns:
        dict: A mapping of each vertex to its corresponding component.
    """
    clusters = {}
    vertex_to_component = {}
    cluster_id = 0

    for vertex1, vertex2 in edges:
        # Case 1: Both vertices have been seen before and belong to different clusters
        if vertex1 in vertex_to_component and vertex2 in vertex_to_component:
            cluster1 = vertex_to_component[vertex1]
            cluster2 = vertex_to_component[vertex2]
            if cluster1 != cluster2:
                clusters[cluster1].update(clusters[cluster2])
                for entity in clusters[cluster2]:
                    vertex_to_component[entity] = cluster1
                del clusters[cluster2]

        # Case 2: Only the first vertex has been seen before
        elif vertex1 in vertex_to_component:
            cluster = vertex_to_component[vertex1]
            clusters[cluster].add(vertex2)
            vertex_to_component[vertex2] = cluster

        # Case 3: Only the second vertex has been seen before
        elif vertex2 in vertex_to_component:
            cluster = vertex_to_component[vertex2]
            clusters[cluster].add(vertex1)
            vertex_to_component[vertex1] = cluster

        # Case 4: Neither vertex has been seen before
        else:
            clusters[cluster_id] = {vertex1, vertex2}
            vertex_to_component[vertex1] = cluster_id
            vertex_to_component[vertex2] = cluster_id
            cluster_id += 1

    return vertex_to_component

# 
from itertools import groupby


def reference_cluster_ids_doc_by_heuristic(ents, target_key="ent_id_doc"):
    key = lambda x: x["doc_id"]
    ents.sort(key=key)
    for doc_id, doc_ents in groupby(ents, key=key):
        doc_ents = list(doc_ents)
        _reference_cluster_ids_doc_by_heuristic(doc_ents, target_key)



def _reference_cluster_ids_doc_by_heuristic(ents, target_key):
    """
    Coref resulution using simle heuristic (normalized string identity for non generics and 
    Abbreviations (based on resolvable abb`Greviation of near entity mentions
    """
    ent_candidates = ents
    ent_label = {"Method", "MLModel", "ModelArchitecture", "Dataset", "DataSource", "URL", "ReferenceLink"}
    # initialize with entity id
    abbreviations = _abbreviation_detection(ent_candidates)
    for ent in ent_candidates:
        # Look if entity span is an abbreviation and if so replace with the long form
        long_form = abbreviations.get(ent["text"], ent["text"])
        ent["text_norm"] = _norm_text(long_form)
        ent[target_key] = ent["id"]
    # filter Generics
    ent_candidates = [e for e in ent_candidates if e["label"] in ent_label]
    key = lambda x: (x["text_norm"], x["label"])
    ent_candidates.sort(key=key)
    for key, ent_mentions in groupby(ent_candidates, key=key):
        ent_mentions = list(ent_mentions)
        ident = ent_mentions[0]["id"]
        for ent in ent_mentions:
            ent[target_key] = ident

def _abbreviation_detection(ents):
    ents.sort(key = lambda x: (x["doc_id"], x["label"], x["begin"]))
    last = None
    abbreviations = {}
    for ent in ents:
        if last is None:
            last = ent
            continue
        same_doc = last["doc_id"] != ent["doc_id"]
        same_label = ent["label"] == last["label"] 
        char_distance =  ent["begin"] - last["end"]
        small_char_distance = char_distance < 0 or char_distance >= 5
        if same_doc or not same_label or not small_char_distance:
            last = ent 
            continue
        # Now handle candidates:
        if _is_abbreviation(ent["text"], last["text"]):
            abbreviations[last["text"]] = ent["text"]
            if last["text"].endswith("s"):
                abbreviations[last["text"][:-1]] = ent["text"]
        elif _is_abbreviation(last["text"], ent["text"]):
            abbreviations[ent["text"]] = last["text"]
            if ent["text"].endswith("s"):
                abbreviations[ent["text"][:-1]] = last["text"]
        last = ent
    return abbreviations

def _is_abbreviation(text_span, abbreviation_candidate):
    # Detect things like EBMs"
    if abbreviation_candidate.endswith("s"):
        abbreviation_candidate = abbreviation_candidate[:-1]
    if not abbreviation_candidate.isupper():
        # not capitalized, do not handle
        return False
    # first letters of words of text span
    words = text_span.replace("-", " ").split()
    first_letters_with_hyphen_separate = (w[0] for w in words)
    abbr_calculated = "".join(first_letters_with_hyphen_separate).upper()
    if abbr_calculated == abbreviation_candidate:
        return True
    words = text_span.replace("-", "").split()
    first_letters_with_hyphen_connected = (w[0] for w in words)
    abbr_calculated = "".join(first_letters_with_hyphen_connected).upper()
    if abbr_calculated == abbreviation_candidate:
        return True
    # all upper case letters as candidate:
    abbr_calculated = "".join([char for char in text_span if char.isupper()])
    if abbr_calculated == abbreviation_candidate:
        return True
    return False

def _norm_text(text):
    text_norm = text.lower()
    if text_norm.endswith("s"):
        text_norm = text_norm[:-1]
    replace = "().,:;/"
    for rep in replace:
        text_norm = text_norm.replace(rep, "")
        
    for beginning in ["the ", "a ", "an ", "this ", "https", "http"]:
        if text_norm.startswith(beginning):
            strip_length = len(beginning)
            text_norm = text_norm[strip_length:]
    text_norm = text_norm.replace("-", "")
    text_norm = text_norm.replace(" ", "")
    return text_norm
