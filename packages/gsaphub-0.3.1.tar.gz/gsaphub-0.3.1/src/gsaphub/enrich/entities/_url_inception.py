from ..._inception_url_helper import ent_to_url


def url_inception(ents):
    for ent in ents:
        url = ent_to_url(ent)
        if url is not None:
            ent["url_inception"] = url
