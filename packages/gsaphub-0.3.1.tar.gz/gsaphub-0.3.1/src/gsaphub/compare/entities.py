from dataclasses import dataclass

from ..match.entities import _get_ranked_matches
from ..match.spans import partial as match_spans_partial


@dataclass
class EntityComparison:
    entity: dict
    entity_compare: dict
    match_type: str


def best_match(
    ents, ents_pred, allowed_ordered_match_types=["strict", "label"], flat_format=True
) -> list[EntityComparison]:
    """
    for strict match: allowed_ordered_match_types=["strict"]
    for partial match: allowed_ordered_match_types=["strict", "label"]
    for more matches you can append: ["exact", "overlap"]
        (e.g. for showing better suggestions)
    """
    allowed_ordered_match_types_ = allowed_ordered_match_types + ["NIL"]
    match_spans_partial(ents, ents_pred, target_key="matched_ent_id")
    match_spans_partial(ents_pred, ents, target_key="matched_ent_id")
    ents_pred_dict = {e["id"]: e for e in ents_pred}
    ents_dict = {e["id"]: e for e in ents}
    pairs = {}
    for ent in ents:
        ranked_matches = _get_ranked_matches(ent, ents_pred_dict, only_same_label=False)
        for ent_id_match, match_type in ranked_matches:
            if match_type in allowed_ordered_match_types_:
                pairs[(ent["id"], ent_id_match)] = ent["id"], ent_id_match, match_type
        pairs[(ent["id"], None)] = ent["id"], None, "NIL"
    for ent in ents_pred:
        pairs[(None, ent["id"])] = None, ent["id"], "NIL"
    pairs = list(pairs.values())
    pairs.sort(key=lambda x: allowed_ordered_match_types_.index(x[-1]))
    seen_ent_ids = set()
    seen_ent_ids_compare = set()
    final_pairs = []
    for ent_id, ent_id_compare, match_label in pairs:
        if (ent_id is None or ent_id not in seen_ent_ids) and (
            ent_id_compare is None or ent_id_compare not in seen_ent_ids_compare
        ):
            final_pairs.append(
                EntityComparison(
                    entity=ents_dict.get(ent_id),
                    entity_compare=ents_pred_dict.get(ent_id_compare),
                    match_type=match_label,
                )
            )
            if ent_id is not None:
                seen_ent_ids.add(ent_id)
            if ent_id_compare is not None:
                seen_ent_ids_compare.add(ent_id_compare)
    assert len(seen_ent_ids) == len(ents_dict) == len(ents)
    assert len(seen_ent_ids_compare) == len(ents_pred_dict) == len(ents_pred)
    if flat_format:
        final_pairs = _flatten_pairs(final_pairs)
    return final_pairs


def _flatten_pairs(pairs):
    flat_pairs = []
    for p in pairs:
        ent = p.entity if p.entity is not None else {}
        ent_other = p.entity_compare if p.entity_compare is not None else {}
        info = dict(
            match_type=p.match_type,
        )
        for key in ["label"]:
            label = ent.get(key)
            info[key] = label if label is not None else "NIL"
            label = ent_other.get(key)
            info[f"{key}_compare"] = label if label is not None else "NIL"
        for key in ["text", "score", "url_inception", "annotator"]:
            info[key] = ent.get(key)
            info[f"{key}_compare"] = ent_other.get(key)
        for key in ["text_unit_text", "doc_id"]:
            value = ent.get(key)
            if value is None:
                value = ent_other.get(key)
            info[key] = value
        flat_pairs.append(info)
    return flat_pairs
