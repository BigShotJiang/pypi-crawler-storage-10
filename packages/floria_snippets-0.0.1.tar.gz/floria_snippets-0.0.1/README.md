# floria-snippets

Minimal dialogue snippets for Floria.
