# Length of the longest supported key (number of strokes).
LONGEST_KEY = 1
