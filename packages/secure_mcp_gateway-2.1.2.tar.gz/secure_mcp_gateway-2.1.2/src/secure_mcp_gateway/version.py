"""Package version."""

__version__ = "2.1.2"
