# nquencolor

A Python module to display colored and highlighted text in the terminal using ANSI escape codes.

## Installation

```bash
pip install nquencolor