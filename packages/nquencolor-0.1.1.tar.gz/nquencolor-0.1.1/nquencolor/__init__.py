FG_COLORS = {
    "black": "30", "red": "91", "green": "92", "yellow": "93",
    "blue": "94", "magenta": "95", "cyan": "96", "white": "97",
    "bright_black": "90", "bright_red": "31", "bright_green": "32",
    "bright_yellow": "33", "bright_blue": "34", "bright_magenta": "35",
    "bright_cyan": "36", "bright_white": "37"
}

BG_COLORS = {
    "black": "40", "red": "41", "green": "42", "yellow": "43",
    "blue": "44", "magenta": "45", "cyan": "46", "white": "47",
    "light_yellow": "103", "light_cyan": "106", "light_white": "107"
}

STYLES = {
    "bold": "1", "dim": "2", "italic": "3", "underline": "4",
    "blink": "5", "reverse": "7", "strikethrough": "9"
}

def colorize(text, fg_color="white", bg_color=None, style=None):
    codes = []
    if fg_color in FG_COLORS:
        codes.append(FG_COLORS[fg_color])
    if bg_color in BG_COLORS:
        codes.append(BG_COLORS[bg_color])
    if style in STYLES:
        codes.append(STYLES[style])
    ansi_code = ";".join(codes) if codes else "0"
    return f"\033[{ansi_code}m{text}\033[0m"