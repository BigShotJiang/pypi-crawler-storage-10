from setuptools import setup, find_packages

setup(
    name="nquencolor",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[],
    author="Nqùen Tũng",
    description="A module to display colored and highlighted text in the terminal",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)