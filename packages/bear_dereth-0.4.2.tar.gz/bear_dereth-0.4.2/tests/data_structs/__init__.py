"""Data structure tests."""
