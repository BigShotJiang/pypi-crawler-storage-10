"""Tests for MsgPackHandler class."""

from io import BytesIO

from bear_dereth.message_pack.packing import MsgPackHandler, pack


class TestMsgPackHandler:
    """Test suite for MsgPackHandler."""

    def test_pack_unpack_dict(self):
        """Test packing and unpacking a dictionary."""
        handler = MsgPackHandler(data=None)
        data = {"name": "Bear", "age": 42, "active": True}
        packed = handler.pack(data)
        unpacked = handler.unpack(packed)
        assert unpacked == data

    def test_pack_unpack_list(self):
        """Test packing and unpacking a list."""
        handler = MsgPackHandler(data=None)
        data = [1, 2, 3, 4, 5]
        packed = handler.pack(data)
        unpacked = handler.unpack(packed)
        assert unpacked == data

    def test_pack_unpack_nested(self):
        """Test packing and unpacking nested structures."""
        handler = MsgPackHandler(data=None)
        data = {
            "users": [
                {"id": 1, "name": "Bear"},
                {"id": 2, "name": "Claire"},
            ],
            "count": 2,
        }
        packed = handler.pack(data)
        unpacked = handler.unpack(packed)
        assert unpacked == data

    def test_multiple_cycles(self):
        """Test multiple pack/unpack cycles with same handler."""
        handler = MsgPackHandler(data=None)

        # Cycle 1
        data1 = {"name": "Bear", "count": 42}
        packed1 = handler.pack(data1)
        unpacked1 = handler.unpack(packed1)
        assert unpacked1 == data1

        # Cycle 2
        data2 = [1, 2, 3, 4, 5]
        packed2 = handler.pack(data2)
        unpacked2 = handler.unpack(packed2)
        assert unpacked2 == data2

        # Cycle 3
        data3 = {"nested": {"deep": {"value": 123}}}
        packed3 = handler.pack(data3)
        unpacked3 = handler.unpack(packed3)
        assert unpacked3 == data3

    def test_pack_into(self):
        """Test pack_into method."""
        handler = MsgPackHandler(data=None)
        handler.pack_into({"test": 1})
        handler.pack_into([2, 3])
        buffer = handler.get_buffer()
        assert len(buffer) > 0

    def test_clear(self):
        """Test clear method."""
        handler = MsgPackHandler(data=None)
        handler.pack({"data": "test"})
        handler.clear()
        buffer = handler.get_buffer()
        assert len(buffer) == 0

    def test_get_buffer_clear(self):
        """Test get_buffer with clear=True."""
        handler = MsgPackHandler(data=None)
        handler.pack({"data": "test"})
        buffer1 = handler.get_buffer(clear=False)
        assert len(buffer1) > 0
        buffer2 = handler.get_buffer(clear=True)
        assert buffer1 == buffer2
        buffer3 = handler.get_buffer()
        assert len(buffer3) == 0

    def test_pack_primitives(self):
        """Test packing various primitive types."""
        handler = MsgPackHandler(data=None)

        test_cases = [
            None,
            True,
            False,
            0,
            42,
            -1,
            3.14,
            "hello",
            b"bytes",
        ]

        for value in test_cases:
            packed = handler.pack(value)
            unpacked = handler.unpack(packed)
            assert unpacked == value, f"Failed for {value!r}"

    def test_unpack_stream(self):
        """Test unpacking multiple objects from a stream."""
        handler = MsgPackHandler(data=None)

        # Pack multiple objects
        obj1 = {"id": 1, "name": "Bear"}
        obj2 = [1, 2, 3]
        obj3 = "hello"

        packed = pack(obj1) + pack(obj2) + pack(obj3)

        # Unpack stream
        results = handler.unpack_stream(packed)

        assert len(results) == 3
        assert results[0] == obj1
        assert results[1] == obj2
        assert results[2] == obj3

    def test_size_property(self):
        """Test size property returns buffer length."""
        handler = MsgPackHandler(data=None)

        # Empty buffer
        assert handler.size == 0

        # After packing
        data = {"test": 123}
        handler.pack(data)
        assert handler.size > 0

        # After clear
        handler.clear()
        assert handler.size == 0

    def test_context_manager(self):
        """Test context manager clears buffer on exit."""
        with MsgPackHandler(data=None) as handler:
            handler.pack({"data": "test"})
            assert handler.size > 0

        # Buffer should be cleared after context exit
        assert handler.size == 0

    def test_init_with_bytes_data(self):
        """Test initializing handler with bytes data."""
        data = {"name": "Bear", "age": 42}
        packed = pack(data)

        # Initialize with packed bytes
        handler = MsgPackHandler(data=packed)

        # Should be able to unpack without providing data again
        # (though our current API requires passing data to unpack)
        # This tests that init with data doesn't break anything
        handler.clear()
        unpacked = handler.unpack(packed)
        assert unpacked == data

    def test_init_with_buffer_class(self):
        """Test initializing with buffer class and data."""
        data = {"test": 123}
        packed = pack(data)

        # Pass buffer class and data
        handler = MsgPackHandler(data=packed, buffer=BytesIO)
        handler.clear()
        unpacked = handler.unpack(packed)
        assert unpacked == data

    def test_unpack_stream_single_object(self):
        """Test unpack_stream with single object."""
        handler = MsgPackHandler(data=None)
        data = {"single": "object"}
        packed = pack(data)

        results = handler.unpack_stream(packed)
        assert len(results) == 1
        assert results[0] == data

    def test_unpack_stream_empty(self):
        """Test unpack_stream with empty data."""
        handler = MsgPackHandler(data=None)
        results = handler.unpack_stream(b"")
        assert results == []
