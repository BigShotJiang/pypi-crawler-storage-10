# bear_dereth.typing_tools

Utilities for wrangling Python types: converting between strings and types,
inferring type hints, validating generics, and introspecting function
signatures. These helpers keep Bear Dereth’s APIs strongly typed without a ton
of boilerplate.

## Modules & Highlights
- `from_type.py`: `type_to_str` (and `CollectionCheck`) for turning Python types
  or container contents into string type names.
- `to_type.py`: `str_to_type`, `value_to_type`, and `coerce_to_type` for mapping
  strings or arbitrary values back into concrete Python types.
- `infer.py`: Smart inference of type strings from runtime values, including
  nested collections (`Inference` class).
- `from_str.py`: Lightweight boolean parsing (`str_to_bool`).
- `builtin_tools.py`: Helpers to avoid name collisions and inspect built-in
  types (`type_name`, `check_for_conflicts`).
- `type_helper.py`: `TypeHelper` and convenience functions for generics
  (`type_param`, `num_type_params`, `validate_type`, `all_same_type`).
- `utils.py`: Protocol-style guards (`is_mapping`, `is_object`, `ArrayLike`,
  `JSONLike`, `TypeHint`).
- `introspection/`: Cached wrappers around `inspect` primitives for resolving
  annotations (`get_function_signature`, `introspect_types`, `resolve_string_to_type`).

---

## Converting Types ⇄ Strings

```python
from bear_dereth.typing_tools import type_to_str, str_to_type, coerce_to_type

assert type_to_str(list) == "list"
tp = str_to_type("path")
assert tp is not None

value = coerce_to_type("42", int)
assert value == 42
```

`value_to_type(container, key, type)` fetches attributes or dict keys, coercing
them to the desired type or using a default if provided.

---

## Inferring Runtime Types

```python
from bear_dereth.typing_tools import infer_type, str_to_bool

assert infer_type("[1, 2, 3]") == "list[int]"
assert infer_type({"key": 10}) == "dict[str, int]"
assert str_to_bool("yes") is True
assert str_to_bool("0", as_str=True) == "bool"
```

`Inference` handles nested sequences, unions, and tuple ellipses, returning
strings like `list[dict[str, float]]`. It also recognizes filesystem paths (when
`path_as_str=False`).

---

## Introspection Helpers

```python
from bear_dereth.typing_tools import get_function_signature, find_type_hints, introspect_types

def example(name: str, count: int = 0) -> None: ...

sig = get_function_signature(example)
annotation = find_type_hints("name", example)
param = sig.parameters["count"]

resolved = introspect_types(param, example)  # -> <class 'int'>
```

- `ParamWrapper` (in `_helpers.py`) normalizes `inspect.Parameter` objects so
  you can unwrap generics, detect unions, or resolve string annotations.
- `resolve_string_to_type` checks type hints, module globals, then function
  globals to replace forward references.
- `not_in_bound` and `isinstance_in_annotation` speed up injection logic by
  caching parameter checks.

---

## Type Validation & Helpers

```python
from typing import Generic, TypeVar
from bear_dereth.typing_tools import TypeHelper, validate_type, all_same_type

T = TypeVar("T")

class Box(Generic[T]): ...

helper = TypeHelper(Box[int])
assert helper.tp_count == 1
assert helper.get_type_param() is int

validate_type(5, int)         # passes
assert all_same_type("a", "b")
```

`TypeHint(SomeClass)` can be used as a mixin to graft type hints onto dynamic
classes at runtime while keeping static checkers happy.

---

## Utilities & Guards

- `is_mapping`, `is_object`, `is_array_like`, `is_json_like` are `TypeGuard`s
  used across the codebase for runtime dispatch.
- `a_or_b` returns a function that dispatches to mapping/object handlers based
  on the value passed in.
- `check_for_conflicts("list")` appends an underscore to avoid keyword/built-in
  collisions, optionally letting you provide a custom modifier.

---

## Tips
- Most functions are cached (`lru_cache`)—leverage them freely in tight loops.
- When coercing user input, prefer `value_to_type` or `str_to_type` with a
  `custom_map` to support project-specific types.
- Combine `introspect_types` with `infer_type` to build robust dependency
  injection or serialization logic.

Type bravely, Bear! 🐻🧠✨
