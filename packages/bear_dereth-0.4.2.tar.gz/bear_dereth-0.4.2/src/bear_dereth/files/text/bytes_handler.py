"""A simple bytes file handler with locking and lazy open."""

from __future__ import annotations

from typing import IO, TYPE_CHECKING, Any, Self, TypeGuard, override

from lazy_bear import LazyLoader

from bear_dereth.constants.binary_types import MAX_VALUE, MIN_VALUE
from bear_dereth.files.base_file_handler import BaseFileHandler
from bear_dereth.files.file_lock import ex_lock, sh_lock, unlock
from bear_dereth.operations.funcstuffs import n_in_range

if TYPE_CHECKING:
    from inspect import isclass
    from pathlib import Path
else:
    isclass = LazyLoader("inspect").to("isclass")


def is_buffer(buffer: Any) -> TypeGuard[type[IO]]:
    """Check if using an in-memory buffer."""
    return buffer is not None and (callable(buffer) or hasattr(buffer, "read"))


class BytesFileHandler(BaseFileHandler[bytes]):
    """A simple bytes file handler with locking and lazy open.

    - Lazily opens the file on first use
    - Uses fcntl file locks for read/write sections
    - Provides read_bytes(), write_bytes(), clear(), and basic handle helpers
    """

    def __init__(
        self,
        file: str | Path | None = None,
        mode: str = "a+b",
        touch: bool = False,
        buffer: type[IO] | IO | None = None,
        append: bool = False,
    ) -> None:
        """Initialize the bytes file handler.

        Args:
            file: Path to the bytes file
            mode: File open mode (default: "a+b")
            touch: Whether to create the file if it doesn't exist (default: False)
            buffer: Type of in-memory buffer to use (default: BytesIO)
            append: Whether to append to the file (default: False)
        """
        self.buffer: type[IO] | IO | None = buffer
        self.append: int = 0 if not append else 2
        self._offset: int = 0
        super().__init__(file=file, mode=mode, touch=touch)

    def set_offset(self, o: int) -> Self:
        """Set the file read/write offset."""
        self._offset = o
        return self

    def get_offset(self) -> int:
        """Get the current file read/write offset."""
        return self._offset

    @override
    def handle(self, open_file: bool = True) -> IO[Any] | None:
        """Get the file handle, opening it if needed."""
        if is_buffer(self.buffer) and (self._handle is None or self._handle.closed):
            if isclass(self.buffer):
                self._handle = self.buffer()
            else:
                self._handle = self.buffer
            return self._handle
        if not open_file:
            return self._handle
        if self._handle is None or self._handle.closed:
            self._handle = self._open()
        return self._handle

    @override
    def clear(self) -> None:
        """Clear the file contents using an exclusive lock."""
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        not_buffer: bool = not is_buffer(self.buffer)
        try:
            if not_buffer:
                ex_lock(handle)
            handle.seek(0)
            handle.truncate(0)
        finally:
            if not_buffer:
                unlock(handle)

    def read(self, size: int = -1, *, offset: int | None = None, tick: int | None = None, **kwargs) -> bytes:
        """Read the entire file (or up to n bytes) as bytes with a shared lock.

        Args:
            size: Number of bytes to read (default: -1 for all)
            offset: Offset to start reading from (default: current offset)
            tick: Number of bytes to advance the offset after reading (default: None)
        """
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        not_buffer: bool = not is_buffer(self.buffer)
        if (n := kwargs.pop("n", None)) is not None:
            size = n
        if offset is None:
            offset = self._offset

        try:
            if not_buffer:
                sh_lock(handle)
            handle.seek(offset)
            data: bytes = handle.read(size)
        finally:
            if not_buffer:
                unlock(handle)
        if tick is not None:
            offset += tick
            self._offset = offset
        return data

    def read_byte(self, offset: int | None = None) -> bytes:
        """Read a single byte from the file with a shared lock.

        Args:
            offset: Offset to read from (default: current offset)

        Returns:
            The byte read as an integer.
        """
        data: bytes = self.read(size=1, offset=offset)
        n: int = len(data)
        if n == 0:
            raise EOFError("End of file reached while attempting to read a byte.")
        return data

    def write(self, data: bytes, **kwargs) -> None:
        """Replace file contents with bytes using an exclusive lock."""
        handle: IO[Any] | None = self.handle()
        if handle is None:
            raise ValueError("File handle is not available.")
        append: int = kwargs.pop("append", self.append)
        not_buffer: bool = not is_buffer(self.buffer)
        try:
            if not_buffer:
                ex_lock(handle)
            handle.seek(0, append)
            handle.truncate(0) if append == 0 else None
            handle.write(data)
            handle.flush()
        finally:
            if not_buffer:
                unlock(handle)

    def write_byte(self, b: int) -> None:
        """Write a single byte to the file using an exclusive lock."""
        if n_in_range(b, MIN_VALUE, MAX_VALUE):
            return self.write(bytes([b]))
        raise ValueError(f"Byte value {b} must be in range 0-255.")


# if __name__ == "__main__":
#     from io import BytesIO

#     # Example usage with an in-memory buffer
#     mem_handler = BytesFileHandler(buffer=BytesIO)
#     mem_handler.write(b"In-memory data")
#     print(mem_handler.read())

#     # Example usage with a file
#     file_handler = BytesFileHandler(file="example.bin", touch=True)
#     file_handler.write(b"File data")
#     print(file_handler.read())
