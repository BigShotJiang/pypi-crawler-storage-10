"""Handlers for MessagePack Tag unpacking."""

from collections.abc import Callable
from struct import unpack as struct_unpack
from typing import Any

from bear_dereth.files.text.bytes_handler import BytesFileHandler
from bear_dereth.message_pack.common._msgpack_tag import Tag
from bear_dereth.operations.binarystuffs import from_be_bytes


def unpack_literal(br: BytesFileHandler, tag: Tag) -> Any:  # noqa: ARG001
    """Unpack a literal tag (NIL, TRUE, FALSE)."""
    return tag.meta.literal


def unpack_float64(br: BytesFileHandler, tag: Tag) -> float:
    """Unpack a 64-bit float."""
    return struct_unpack(">d", br.read(n=tag.meta.size, tick=tag.meta.size))[0]


def _read_length(br: BytesFileHandler, tag: Tag, signed: bool = False) -> int:
    """Read a length value based on the tag's size."""
    data: bytes = br.read(n=tag.meta.size, tick=tag.meta.size)
    return from_be_bytes(data, signed=signed)


def _read_int(br: BytesFileHandler, tag: Tag) -> int:
    """Read an integer based on the tag's size and signedness."""
    return from_be_bytes(br.read(n=tag.meta.size, tick=tag.meta.size), signed=tag.meta.signed)


def unpack_str(br: BytesFileHandler, tag: Tag) -> str:
    """Unpack a string (STR8/16/32)."""
    length: int = _read_length(br, tag)
    data: bytes = br.read(n=length, tick=length)
    return data.decode("utf-8")


def unpack_bin(br: BytesFileHandler, tag: Tag) -> bytes:
    """Unpack binary data (BIN8/16/32)."""
    length: int = _read_length(br, tag)
    return br.read(n=length, tick=length)


def unpack_int(br: BytesFileHandler, tag: Tag) -> int:
    """Unpack an integer (INT8/16/32/64 or UINT8/16/32/64)."""
    return _read_int(br, tag)


def unpack_array(br: BytesFileHandler, tag: Tag) -> list:
    """Unpack an array (ARRAY16/32)."""
    from bear_dereth.message_pack.unpacking import unpack_one  # noqa: PLC0415

    return [unpack_one(br) for _ in range(_read_length(br, tag))]


def unpack_map(br: BytesFileHandler, tag: Tag) -> dict:
    """Unpack a map (MAP16/32)."""
    from bear_dereth.message_pack.unpacking import unpack_one  # noqa: PLC0415

    return {unpack_one(br): unpack_one(br) for _ in range(_read_length(br, tag))}


TAG_HANDLERS: dict[Tag, Callable[..., Any]] = {
    Tag.NIL: unpack_literal,
    Tag.TRUE: unpack_literal,
    Tag.FALSE: unpack_literal,
    Tag.FLOAT64: unpack_float64,
    Tag.STR8: unpack_str,
    Tag.STR16: unpack_str,
    Tag.STR32: unpack_str,
    Tag.BIN8: unpack_bin,
    Tag.BIN16: unpack_bin,
    Tag.BIN32: unpack_bin,
    Tag.UINT8: unpack_int,
    Tag.UINT16: unpack_int,
    Tag.UINT32: unpack_int,
    Tag.UINT64: unpack_int,
    Tag.INT8: unpack_int,
    Tag.INT16: unpack_int,
    Tag.INT32: unpack_int,
    Tag.INT64: unpack_int,
    Tag.ARRAY16: unpack_array,
    Tag.ARRAY32: unpack_array,
    Tag.MAP16: unpack_map,
    Tag.MAP32: unpack_map,
}
