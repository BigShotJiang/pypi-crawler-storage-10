"""Handlers for MessagePack fix family unpacking."""

from typing import Any

from bear_dereth.files.text.bytes_handler import BytesFileHandler
from bear_dereth.message_pack.common._fix_families import FixFamily
from bear_dereth.operations.binarystuffs import from_be_bytes


def unpack_fixstr(br: BytesFileHandler, byte_val: int) -> str:
    """Unpack a fixstr from the byte reader.

    Args:
        br: The byte reader to read from.
        byte_val: The first byte that matched the fixstr pattern.

    Returns:
        The decoded string.
    """
    length: int = FixFamily.FIXSTR.meta.extract_length(byte_val)
    data: bytes = br.read(n=length, tick=length)
    return data.decode("utf-8")


def unpack_fixarray(br: BytesFileHandler, byte_val: int) -> list:
    """Unpack a fixarray from the byte reader.

    Args:
        br: The byte reader to read from.
        byte_val: The first byte that matched the fixarray pattern.

    Returns:
        The unpacked list.
    """
    from bear_dereth.message_pack.unpacking import unpack_one  # noqa: PLC0415

    length: int = FixFamily.FIXARRAY.meta.extract_length(byte_val)
    return [unpack_one(br) for _ in range(length)]


def unpack_fixmap(br: BytesFileHandler, byte_val: int) -> dict:
    """Unpack a fixmap from the byte reader.

    Args:
        br: The byte reader to read from.
        byte_val: The first byte that matched the fixmap pattern.

    Returns:
        The unpacked dict.
    """
    from bear_dereth.message_pack.unpacking import unpack_one  # noqa: PLC0415

    length: int = FixFamily.FIXMAP.meta.extract_length(byte_val)
    return {unpack_one(br): unpack_one(br) for _ in range(length)}


def unpack_pos_fixint(br: BytesFileHandler, byte_val: int) -> int:  # noqa: ARG001
    """Unpack a positive fixint.

    Args:
        br: The byte reader (unused for fixints).
        byte_val: The byte value itself is the integer.

    Returns:
        The integer value.
    """
    return byte_val


def unpack_neg_fixint(br: BytesFileHandler, byte_val: int) -> int:  # noqa: ARG001
    """Unpack a negative fixint.

    Args:
        br: The byte reader (unused for fixints).
        byte_val: The byte value to decode as signed.

    Returns:
        The negative integer value.
    """
    return from_be_bytes(bytes([byte_val]), signed=True)


FIX_HANDLERS: dict[FixFamily, Any] = {
    FixFamily.FIXSTR: unpack_fixstr,
    FixFamily.FIXARRAY: unpack_fixarray,
    FixFamily.FIXMAP: unpack_fixmap,
    FixFamily.POS_FIXINT: unpack_pos_fixint,
    FixFamily.NEG_FIXINT: unpack_neg_fixint,
}
