"""A set of common utilities for MessagePack handling."""
