"""MessagePack depacking functionality."""

from typing import TYPE_CHECKING, Any

from bear_dereth.files.text.bytes_handler import BytesFileHandler
from bear_dereth.message_pack._unpacking._fix_handlers import FIX_HANDLERS
from bear_dereth.message_pack._unpacking._tag_handlers import TAG_HANDLERS
from bear_dereth.message_pack.common._fix_families import FixFamily
from bear_dereth.message_pack.common._msgpack_tag import Tag
from bear_dereth.message_pack.common.exceptions import InvalidMsgPackTagError

if TYPE_CHECKING:
    from collections.abc import Callable


def unpack_one(br: BytesFileHandler) -> Any:
    """Unpack a single MessagePack object from the byte reader."""
    b: bytes = br.read(n=1, tick=1)
    byte_val: int = int.from_bytes(b, "big")

    for fix_family in FixFamily.values():
        if fix_family.meta.matches(byte_val):
            fix_handler: Callable[..., Any] = FIX_HANDLERS[fix_family]
            return fix_handler(br, byte_val)

    tag: Tag | None = Tag.get(byte_val, None)
    tag_handler: Callable[..., Any] | None = TAG_HANDLERS.get(tag, None)
    if tag_handler is not None:
        return tag_handler(br, tag)
    raise InvalidMsgPackTagError(f"No handler for tag: {tag}")
