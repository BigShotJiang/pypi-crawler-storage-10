"""Conversations from MessagePack stringing system."""

from __future__ import annotations

from contextlib import suppress
from io import BytesIO
from typing import IO, TYPE_CHECKING, Any, Self

from lazy_bear import LazyLoader

from bear_dereth.files.text.bytes_handler import BytesFileHandler
from bear_dereth.message_pack._packing._type_handlers import pack_bin, pack_float, pack_int, pack_into, pack_str
from bear_dereth.message_pack.unpacking import unpack_one

if TYPE_CHECKING:
    from inspect import isclass
else:
    isclass = LazyLoader("inspect").to("isclass")


def pack(obj: Any) -> bytes:
    """Pack an object into MessagePack bytes."""
    buf = BytesFileHandler(buffer=BytesIO, append=True)
    pack_into(buf, obj)
    return buf.read()


def unpack(data: bytes) -> Any:
    """Unpack MessagePack bytes into a Python object."""
    buf = BytesFileHandler(buffer=BytesIO(data))
    return unpack_one(buf)


class MsgPackHandler:
    """In-memory cache for packing and unpacking MessagePack data.

    Maintains a reusable buffer for efficient serialization/deserialization.
    """

    def __init__(self, data: Any | None = None, buffer: type[IO] | IO | None = None) -> None:
        """Initialize with an empty buffer."""
        if buffer is None:
            buffer = BytesIO(data) if data is not None else BytesIO
        elif data is not None and isclass(buffer):
            buffer = buffer(data)  # type: ignore[arg-type]

        buffer = BytesIO(data) if data is not None and isclass(buffer) else buffer

        self.buffer = BytesFileHandler(buffer=buffer, append=True)

    def pack_into(self, x: object) -> None:
        """Pack an object into the buffer (accumulates data)."""
        pack_into(self.buffer, x)

    def pack(self, obj: Any) -> bytes:
        """Pack an object and return MessagePack bytes (clears buffer first)."""
        self.clear()
        self.buffer.set_offset(0)
        pack_into(self.buffer, obj)
        self.buffer.set_offset(0)
        return self.buffer.read()

    def unpack(self, data: bytes) -> Any:
        """Unpack MessagePack bytes into a Python object (uses buffer)."""
        self.clear()
        self.buffer.write(data)
        self.buffer.set_offset(0)
        result: Any = unpack_one(self.buffer)
        self.buffer.set_offset(0)
        return result

    def unpack_stream(self, data: bytes) -> Any:
        """Unpack the next MessagePack object from the current buffer position."""
        self.clear()
        self.buffer.write(data)
        self.buffer.set_offset(0)
        results: list[Any] = []
        with suppress(Exception):
            while self.buffer.get_offset() < len(data):
                result: Any = unpack_one(self.buffer)
                results.append(result)
        return results

    @property
    def size(self) -> int:
        """Get the current size of the internal buffer."""
        return len(self.get_buffer())

    def clear(self) -> None:
        """Clear the internal buffer."""
        self.buffer.clear()
        self.buffer.set_offset(0)

    def get_buffer(self, clear: bool = False) -> bytes:
        """Get the current buffer contents as bytes."""
        current_offset: int = self.buffer.get_offset()
        self.buffer.set_offset(0)
        data: bytes = self.buffer.read()
        self.buffer.set_offset(current_offset)
        if clear:
            self.clear()
        return data

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        self.clear()


__all__ = ["MsgPackHandler", "pack", "pack_bin", "pack_float", "pack_int", "pack_str", "unpack"]
