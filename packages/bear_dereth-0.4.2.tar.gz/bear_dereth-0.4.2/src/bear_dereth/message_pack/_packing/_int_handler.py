from __future__ import annotations

from functools import partial
from typing import TYPE_CHECKING

from bear_dereth.message_pack.common._fix_families import FIXINTS, NEG_FIXINT, POS_FIXINT, FixFamily
from bear_dereth.message_pack.common._msgpack_tag import INT_TYPES, Tag

if TYPE_CHECKING:
    from collections.abc import Callable

    from bear_dereth.files.text.bytes_handler import BytesFileHandler

DataType = FixFamily | Tag


def pack_int(buf: BytesFileHandler, x: int, data: DataType) -> None:
    """Pack an integer into the buffer based on its range."""
    if isinstance(data, FixFamily):
        fix: FixFamily = data
        if data == POS_FIXINT:
            return buf.write_byte(x)
        if data == NEG_FIXINT:
            return buf.write_byte(fix.meta.base | (x & fix.meta.extract_mask))
    if isinstance(data, Tag):
        tag: Tag = data
        buf.write_byte(int(tag))
        return buf.write(tag.meta.be_bytes(x))
    raise ValueError(f"Unsupported data type for packing: {data}")


class IntDispatcher:
    """Dispatch packing functions based on integer ranges."""

    def __init__(self) -> None:
        self.handlers: dict[DataType, Callable[[BytesFileHandler, int, DataType], None]] = {}

    def register(self, data: tuple[DataType, ...]) -> None:
        """Register a packing function for a specific integer range."""
        for i in data:
            self.handlers[i] = partial(pack_int, data=i)

    def get_handler(self, x: int) -> Callable:
        """Get the appropriate packing function for the given integer."""
        for data, handler in self.handlers.items():
            if data.in_range(x):
                return handler
        raise ValueError(f"No handler registered for value: {x}")


int_handle = IntDispatcher()

int_handle.register(FIXINTS)
int_handle.register(INT_TYPES)
