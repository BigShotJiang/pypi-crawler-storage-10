"""Type-based handlers for packing Python objects into MessagePack."""

from __future__ import annotations

from collections.abc import Mapping
from functools import partial
from struct import pack as struct_pack
from types import NoneType
from typing import TYPE_CHECKING, Any

from bear_dereth.message_pack._packing._int_handler import int_handle
from bear_dereth.message_pack.common._fix_families import FixFamily
from bear_dereth.message_pack.common._msgpack_tag import Tag
from bear_dereth.message_pack.common.exceptions import PackError
from bear_dereth.operations.funcstuffs import if_is_instance

if TYPE_CHECKING:
    from collections.abc import Callable

    from bear_dereth.files.text.bytes_handler import BytesFileHandler


def pack_nil(buf: BytesFileHandler, obj: object) -> None:  # noqa: ARG001
    """Pack None as NIL tag."""
    buf.write_byte(Tag.NIL)


def pack_bool(buf: BytesFileHandler, obj: bool) -> None:
    """Pack boolean as TRUE/FALSE tag."""
    buf.write_byte(Tag.TRUE if obj else Tag.FALSE)


def pack_int(buf: BytesFileHandler, x: int) -> None:
    """Pack integer using range-based dispatch."""
    int_handle.get_handler(x)(buf, x)


def pack_float(buf: BytesFileHandler, x: float) -> None:
    """Pack float as FLOAT64."""
    buf.write_byte(Tag.FLOAT64)
    buf.write(struct_pack(">d", x))


def pack_str(buf: BytesFileHandler, data: bytes | str) -> None:
    """Pack string with appropriate length encoding."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    n: int = len(data)
    if n <= FixFamily.FIXSTR.meta.high:
        buf.write_byte(FixFamily.FIXSTR.meta.base | n)
    elif n <= Tag.UINT8.meta.high:
        buf.write_byte(Tag.STR8)
        buf.write(Tag.UINT8.meta.be_bytes(n))
    elif n <= Tag.UINT16.meta.high:
        buf.write_byte(Tag.STR16)
        buf.write(Tag.UINT16.meta.be_bytes(n))
    else:
        buf.write_byte(Tag.STR32)
        buf.write(Tag.UINT32.meta.be_bytes(n))
    buf.write(data)


def pack_bin(buf: BytesFileHandler, data: bytes) -> None:
    """Pack binary data with appropriate length encoding."""
    n: int = len(data)
    if n <= Tag.UINT8.meta.high:
        buf.write_byte(Tag.BIN8)
        buf.write(Tag.UINT8.meta.be_bytes(n))
    elif n <= Tag.UINT16.meta.high:
        buf.write_byte(Tag.BIN16)
        buf.write(Tag.UINT16.meta.be_bytes(n))
    else:
        buf.write_byte(Tag.BIN32)
        buf.write(Tag.UINT32.meta.be_bytes(n))
    buf.write(data)


def pack_list(buf: BytesFileHandler, obj: list | tuple) -> None:
    """Pack list/tuple with appropriate length encoding."""
    n: int = len(obj)
    if n <= FixFamily.FIXARRAY.meta.high:
        buf.write_byte(FixFamily.FIXARRAY.meta.base | n)
    elif n <= Tag.UINT16.meta.high:
        buf.write_byte(Tag.ARRAY16)
        buf.write(Tag.UINT16.meta.be_bytes(n))
    else:
        buf.write_byte(Tag.ARRAY32)
        buf.write(Tag.UINT32.meta.be_bytes(n))
    for it in obj:
        pack_into(buf, it)


def pack_mapping(buf: BytesFileHandler, obj: Mapping) -> None:
    """Pack mapping with appropriate length encoding."""
    n: int = len(obj)
    if n <= FixFamily.FIXMAP.meta.high:
        buf.write_byte(FixFamily.FIXMAP.meta.base | n)
    elif n <= Tag.UINT16.meta.high:
        buf.write_byte(Tag.MAP16)
        buf.write(Tag.UINT16.meta.be_bytes(n))
    else:
        buf.write_byte(Tag.MAP32)
        buf.write(Tag.UINT32.meta.be_bytes(n))
    for k, v in sorted(obj.items(), key=lambda kv: kv[0]):
        pack_into(buf, k)
        pack_into(buf, v)


def pack_into(buf: BytesFileHandler, obj: Any) -> None:
    """Pack any Python object into MessagePack bytes."""
    for condition, handler in TYPE_HANDLERS:
        if condition(obj):
            return handler(buf, obj)
    raise PackError(f"Unsupported type for packing: {type(obj).__name__}")


TYPE_HANDLERS: list[tuple[Callable[..., bool], Callable[..., None]]] = [
    (partial(if_is_instance, types=NoneType), pack_nil),
    (partial(if_is_instance, types=bool), pack_bool),
    (partial(if_is_instance, types=int), pack_int),
    (partial(if_is_instance, types=float), pack_float),
    (partial(if_is_instance, types=str), pack_str),
    (partial(if_is_instance, types=(bytes, bytearray, memoryview)), pack_bin),
    (partial(if_is_instance, types=(list, tuple)), pack_list),
    (partial(if_is_instance, types=Mapping), pack_mapping),
]
