# bear_dereth.operations

Composable utilities for manipulating collections, documents, and functional
pipelines. These helpers power Bear Dereth’s query results, tooling factories,
and scripted data transforms.

## Modules At A Glance
- `classes.py`: `Massaman` for curry-style invocation and `ListMerge` for
  staged list aggregation.
- `common.py`: Shared data structures (`KeyCounts`, `Location`) plus factory
  helpers for building dict/list/set instances on demand.
- `dictstuffs.py`: Dictionary merges with conflict resolution and key updating.
- `iterstuffs.py`: Itertools-style generators (`window`, `pairwise`, `diff`,
  etc.).
- `funcstuffs.py`: Function combinators (`compose`, `pipe`, predicates) and
  instance helpers.
- `operationstuffs.py`: Field-level operations (increment, append, toggle…)
  that rely on injection contexts.
- `factories/`: Runtime wiring for operations—`plugins.py`,
  `tool_context.py`, and `tool_injection.py` provide DI-friendly factories
  (skip `old_factories.py`).
- `randoms/`: Randomization helpers (e.g., weighted choices).

---

## Currying & Merging

```python
from bear_dereth.operations import Massaman, ListMerge

def add_three(a, b, c):
    return a + b + c

curried = Massaman(add_three, 1)
assert curried(2, 3) == 6

with ListMerge([1, 2]) as merger:
    merger.add([2, 3])
    combined = merger.merge([4, 4], unique=True)
assert combined == [1, 2, 3, 4]
```

- `Massaman` stores partial args/kwargs until the function signature is
  satisfied, then executes once.
- `ListMerge` lets you queue merges, optionally deduplicate, and render the
  final result as a list or newline-separated string.

---

## Dictionary Operations

```python
from bear_dereth.operations import merge_dicts, key_counts, update_keys

merged = merge_dicts({"a": 1}, {"a": 2, "b": 3})  # later dict wins
counts = key_counts({"foo": 1}, {"foo": 2, "bar": 3})
renamed = update_keys({"old": 1}, {"old": "new"})
```

`merge_dicts` (aka `merge`) supports conflict strategies:
- `overwrite_keys=True` (default) → last value wins.
- `conflict_choice="skip_last"` or `"skip_first"` when you want to keep the
  first/last occurrence instead.
- `conflict_choice="add_number"` appends `_1`, `_2`, … until the key is unique.

`KeyCounts` captures where duplicates occur across multiple dicts, returning
structured metadata or JSON for debugging.

---

## Functional Helpers

```python
from bear_dereth.operations import compose, pipe, always_true, if_in_list

double_then_increment = compose(lambda x: x + 1, lambda x: x * 2)
assert double_then_increment(3) == 7

result = pipe(10, lambda x: x - 2, lambda x: x * 3)
assert result == 24

assert always_true()
assert if_in_list("bear", ["bear", "wolf"])
```

`funcstuffs` also exposes:
- `const(value)` producing callable constants.
- `get_instance(obj)` which instantiates classes (returning existing objects if
  already created).

---

## Iterable Utilities

```python
from bear_dereth.operations import window, diff, pairwise, merge_lists

list(window([1, 2, 3, 4], 3))        # [(1,2,3), (2,3,4)]
list(diff([1, 2, 3], [1, 3, 3]))     # [(2, 3, 3)]
list(pairwise("bear"))               # [('b','e'), ('e','a'), ('a','r')]
merge_lists([1, 2], (3, 4), unique=True)  # [1,2,3,4]
```

These helpers support lazy iteration (generators) and optional key functions or
default fill values (`diff` can emulates `zip_longest`). `uniqueify` preserves
the first occurrence order.

---

## Field Operations With Context

The functions in `operationstuffs.py` expect an injected context (`FuncContext`)
that supplies `getter`, `setter`, and `deleter` callables—wired up by
`factories/tool_injection.py`. They return callables ready to mutate records.

```python
from bear_dereth.operations import increment, append
from bear_dereth.operations.factories.tool_context import SimpleContext

doc = {"visits": 1, "tags": ["bear"]}
ctx = SimpleContext(doc)

increment("visits", ctx=ctx)
append("tags", "forest", ctx=ctx)
assert doc == {"visits": 2, "tags": ["bear", "forest"]}
```

Highlights:
- Numeric operations (`add`, `subtract`, `multiply`, `div`, `mod`, `clamp`…).
- String operations (`upper`, `lower`, `replace`, `format`, `toggle` for bools).
- List operations (`push`, `append`, `extend`, `pop`).
- `if_else` branches between two operations based on a predicate.

---

## Factory & Plugin Layer

`operations.factories` ties everything together:
- `tool_context.py`: Context objects that expose uniform getter/setter APIs.
- `tool_injection.py`: Decorators (`inject_ops`, `inject_tools`) that inject
  contexts or factories into operation functions.
- `plugins.py`: Patterns for registering additional operations dynamically.

These components let you swap implementations (e.g., operate on dicts, Pydantic
models, or custom storages) while reusing the same operation functions.

---

## Tips
- Many functions are decorators expecting dependency-injected contexts; wire
  them with the provided factories or your own `FuncContext`.
- `KeyCounts` is handy for audits—log `counts.to_dict(dupes_only=True)` to spot
  naming collisions in merged configs.
- Combine `compose`/`pipe` with iterable helpers to build tidy data pipelines
  without importing heavy frameworks.

Operate confidently, Bear! 🐻⚙️✨
