"""A set of rich enums for various purposes."""

from bear_dereth.rich_enums.int_enum import IntValue, RichIntEnum
from bear_dereth.rich_enums.str_enum import RichStrEnum, StrValue
from bear_dereth.rich_enums.variable_enum import VariableEnum, VariableType, VarValue

__all__ = [
    "IntValue",
    "RichIntEnum",
    "RichStrEnum",
    "StrValue",
    "VarValue",
    "VariableEnum",
    "VariableType",
]
