"""Helper class for Write-Ahead Log (WAL) operations in the datastore."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Self

from bear_dereth.data_structs.counter_class import Counter
from bear_dereth.data_structs.wal import Operation, WALRecord, WriteAheadLog

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from bear_dereth.data_structs.autosort_list import AutoSort
    from bear_dereth.datastore.record import Record
    from bear_dereth.datastore.tables.table import Table


class WALHelper:
    """Helper class for Write-Ahead Log (WAL) operations in the datastore."""

    def __init__(self, file: str | Path, table_name: str) -> None:
        """Initialize the WALHelper with a WAL file and a TableHandler."""
        self._table_name: str = table_name
        self._tx_counter: Counter = Counter(start=0)
        self._wal: WriteAheadLog[WALRecord] = WriteAheadLog(file=file)

    def insert(self, record: Record, operation: Callable) -> int:
        """Log an insert operation to the WAL and execute it.

        Args:
            record: The record being inserted.
            operation: Callable that performs the actual insert (e.g., table.insert)

        Returns:
            The transaction ID assigned to the logged operation.
        """
        txid: int = self._tx_counter.tick()
        self._wal.add_op(
            txid=txid,
            op=Operation.INSERT,
            data={"record": record.model_dump(exclude_none=True)},
        )
        operation(record)
        self._wal.commit(txid)
        return txid

    def update(self, primary_key_value: dict[str, Any], updated_fields: dict[str, Any], operation: Callable) -> int:
        """Log an update operation to the WAL and execute it.

        Args:
            primary_key_value: Dictionary of primary key field(s) and their value(s).
            updated_fields: Dictionary of fields to update.
            operation: Callable that performs the actual update (e.g., table.update)

        Returns:
            The transaction ID assigned to the logged operation.
        """
        txid: int = self._tx_counter.tick()
        self._wal.add_op(
            txid=txid,
            op=Operation.UPDATE,
            data={
                "primary_key_value": primary_key_value,
                "updated_fields": updated_fields,
            },
        )
        operation(primary_key_value, updated_fields)
        self._wal.commit(txid)
        return txid

    def delete(self, primary_key_value: dict[str, Any], operation: Callable) -> int:
        """Log a delete operation to the WAL and execute it.

        Args:
            primary_key_value: Dictionary of primary key field(s) and their value(s).
            operation: Callable that performs the actual delete (e.g., table.delete)

        Returns:
            The transaction ID assigned to the logged operation.
        """
        txid: int = self._tx_counter.tick()
        self._wal.add_op(
            txid=txid,
            op=Operation.DELETE,
            data={"primary_key_value": primary_key_value},
        )
        operation(primary_key_value)
        self._wal.commit(txid)
        return txid

    def recover_from_wal(self, table: Table) -> Self:
        """Recover the table's state from the Write-Ahead Log (WAL).

        Replays all committed transactions from the WAL, then checkpoints
        to flush changes to disk and clear the WAL.

        Args:
            table: The Table instance to recover

        Returns:
            Self for method chaining
        """
        # TODO: Still working on this method

        records: AutoSort[dict[str, Any]] = self._wal.read_all()

        txns: set[int] = {r["txid"] for r in records if r["op"] == Operation.COMMIT}  # only replay committed txns
        recs: list[dict[str, Any]] = [r for r in records if r["txid"] in txns and r["op"] != Operation.COMMIT]

        inserts: list[dict[str, Any]] = [r["data"]["record"] for r in recs if r["op"] == Operation.INSERT]
        updates: list[tuple[dict[str, Any], dict[str, Any]]] = [
            (r["data"]["primary_key_value"], r["data"]["updated_fields"]) for r in recs if r["op"] == Operation.UPDATE
        ]

        # pretty sure primary key value is not a dict[str, Any]? why are we typing it that way?
        deletes: list[dict[str, Any]] = [r["data"]["primary_key_value"] for r in recs if r["op"] == Operation.DELETE]

        # Apply operations in order: inserts, updates, then deletes
        # (Note: This assumes WAL records are in chronological order)
        if inserts:
            table.insert_all(inserts, checkpoint=False)
        if updates:
            table.update_all(updates, checkpoint=False)  # pyright: ignore[reportArgumentType]
        if deletes:
            table.delete_all(pk_kwargs_list=deletes, checkpoint=False)
        table.save()  # Checkpoint once at the end to flush everything to disk
        self._wal.clear()
        return self

    def checkpoint(self, table: Table) -> None:
        """Checkpoint the table: save to disk and clear WAL.

        Args:
            table: The Table instance to checkpoint
        """
        table.save()
        self._wal.clear()
