__all__ = ["StyleEncoder", "DurationPredictor", "DiffusionTimeEmbedding", "TextEncoder"]

from lt_utils.common import *
from lt_tensor.common import *
import torch.nn.functional as F
from lt_tensor.model_zoo.convs import ConvBase, is_conv

from lt_tensor.model_zoo.text_encoder import TextEncoder


class DiffusionTimeEmbedding(Model):
    def __init__(
        self,
        max_steps: int = 1000,
        emb_dim: int = 256,  # number of sin/cos frequency pairs
        hidden_dim: int = 768,
        freq_scale: float = 10.0,  # frequency scaling base
        activation: nn.Module = nn.SiLU(),
    ):
        super().__init__()
        assert emb_dim % 2 == 0, "emb_dim must be divisible by 2"
        self.max_steps = max_steps
        self.sin_cos_dim = emb_dim // 2
        self.freq_scale = freq_scale

        # Precompute embedding table (acts as a lookup)
        self.register_buffer(
            "embedding", self._build_embedding(max_steps), persistent=False
        )

        # Flexible projection network
        self.net = nn.Sequential(
            nn.Linear(emb_dim, hidden_dim),
            activation,
            nn.Linear(hidden_dim, emb_dim),
            activation,
        )

    def forward(self, diffusion_step: Tensor):
        """
        diffusion_step: [B] integer timesteps (0..max_steps-1)
        returns: [B, output_dim]
        """
        # ensure indexing tensor
        diffusion_step = torch.as_tensor(diffusion_step, dtype=torch.long)
        step_emb = self.embedding[diffusion_step]  # [B, input_dim * 2]
        return self.net(step_emb)

    def _build_embedding(self, max_steps: int) -> torch.Tensor:
        """
        Create Fourier features across timesteps.
        The scaling function is fully open: f(d, i) = step * scale^(i / (input_dim-1))
        """
        steps = torch.arange(max_steps).unsqueeze(1)  # [T, 1]
        dims = torch.arange(self.sin_cos_dim).unsqueeze(0)  # [1, D]

        # Exponential frequency scaling
        freq = self.freq_scale ** (dims / (self.sin_cos_dim - 1))
        table = steps * freq  # [T, D]
        table = torch.cat([torch.sin(table), torch.cos(table)], dim=1)  # [T, 2D]
        return table


class DurationPredictor(ConvBase):
    def __init__(
        self,
        d_model: int = 128,
        exponential: bool = True,
        flatten_outputs: bool = True,
        bias_at_final_layer: bool = True,
        dilation: int = 1,
        n_layers: int = 2,
        dropout: float = 0.0,
        kernel_size: int = 3,
        mask_value: Number = 0.0,
        proj_activation: nn.Module = nn.SELU(),
        layers_activations: nn.Module = nn.Mish(),
        norm: Optional[Literal["weight_norm", "spectral_norm"]] = None,
    ):
        super().__init__()
        self.flatten_outputs = flatten_outputs
        pad = self.get_padding(kernel_size, dilation)
        n_layers = max(int(n_layers), 1)
        self.layers = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(d_model, d_model),
                    layers_activations,
                )
                for _ in range(n_layers)
            ]
        )
        self.conv_post = nn.Sequential(
            self.get_1d_conv(d_model, d_model, 3, padding=1, norm=norm),
            proj_activation,
            nn.BatchNorm1d(d_model),
            self.get_1d_conv(d_model, 1, 1, bias=bias_at_final_layer, norm=norm),
        )
        self.exponential = exponential
        self.n_layers = n_layers
        self.dropout = (
            nn.Identity() if dropout <= 0 or self.n_layers < 2 else nn.Dropout(dropout)
        )
        self.res_sp = 1.0 / ((self.n_layers + 1) * 2)
        self.mask_value = mask_value
        for m in self.conv_post:
            if is_conv(m):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.weight)
        for m in self.layers:
            nn.init.xavier_normal_(m[0].weight)

    def forward(self, x: Tensor, mask: Optional[Tensor] = None):
        # x=[B, C, d_model]
        if mask is not None:
            x = x.transpose(-1, -2)
            x.masked_fill_(mask, self.mask_value)
            x = x.transpose(-1, -2)

        for layer in self.layers:
            x = self.dropout(x)
            x = layer(x)

        x = x.transpose(-1, -2).contiguous()
        if mask is not None:
            x.masked_fill_(mask, self.mask_value)

        x = self.conv_post(x)

        if self.exponential:
            x = x.exp()
        if self.flatten_outputs:
            x = x.flatten(1, -1)
        return x

    @staticmethod
    def expand_embeddings(x: Tensor, durations: Tensor) -> Tensor:
        """
        Expand per-token embeddings according to predicted or target durations.

        Args:
            x: Tensor of shape [B, seq_len, D] — token embeddings.
            durations: Tensor of shape [B, seq_len] — durations (in frames).

        Returns:
            expanded: Tensor of shape [B, total_frames, D]
                where total_frames = sum(durations[b]) for each batch.
        """
        expanded = []
        durations = torch.clamp(durations, min=1).long()

        for b in range(x.size(0)):
            expanded_seq = torch.repeat_interleave(x[b], durations[b], dim=0)
            expanded.append(expanded_seq)

        # pad to the max total length across the batch for tensor stacking
        max_len = max(seq.size(0) for seq in expanded)
        expanded = [F.pad(seq, (0, 0, 0, max_len - seq.size(0))) for seq in expanded]
        return torch.stack(expanded, dim=0)

    @staticmethod
    def _dur_loss_label(
        durations: Union[List[int], Tensor], lengths: Union[List[int], Tensor]
    ):
        # helper to setup duration loss' label
        mel_lengths = torch.as_tensor(durations, dtype=torch.float32)  # (B,)
        token_lengths = torch.as_tensor(
            lengths, dtype=torch.float32, device=mel_lengths.device
        )  # (B,)
        max_tokens = int(token_lengths.max().item())
        dur_target = torch.zeros(
            mel_lengths.size(-1), max_tokens, device=mel_lengths.device
        )

        for b, (mel_len, tok_len) in enumerate(zip(mel_lengths, token_lengths)):
            # Evenly assign mel frames per token
            avg = mel_len / tok_len
            dur_target[b, : int(tok_len)] = avg

        return dur_target


class AttentionPooling(nn.Module):
    """Learned attention-based pooling over time dimension."""

    def __init__(self, d_model: int):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.Tanh(), nn.Linear(d_model // 2, 1)
        )

    def forward(self, x, mask=None):
        # x: [B, T, D]
        attn_scores = self.attn(x).squeeze(-1)  # [B, T]
        if mask is not None:
            attn_scores = attn_scores.masked_fill(~mask, float("-inf"))
        attn_weights = torch.softmax(attn_scores, dim=-1)  # [B, T]
        pooled = torch.sum(x * attn_weights.unsqueeze(-1), dim=1)
        return pooled


class StyleEncoder(Model):
    """
    Audio-only style encoder for TTS.
    Architecture: Conv1D stack → BiGRU → Dense (MLP) → style vector

    Input:
        mel: [B, n_mels, T]  (mel-spectrogram)
    Output:
        style: [B, d_style]  (global style embedding)
    """

    def __init__(
        self,
        n_mels: int = 80,
        d_model: int = 512,
        d_style: int = 256,
        gru_hidden: int = 512,
        gru_layers: int = 2,
        kernel_size: int = 5,
        groups: int = 4,
        dropout: float = 0.1,
        pooling: Literal["mean", "adaptive", "attention"] = "adaptive",
        adaptive_out: int = 1,
    ):
        super().__init__()

        # ===========================
        # Convolutional Frontend
        # ===========================
        # Expands from n_mels → d_model
        padding = (kernel_size - 1) // 2
        self.conv = nn.Sequential(
            nn.Conv1d(n_mels, d_model // 4, kernel_size, padding=padding),
            nn.LeakyReLU(0.1, inplace=True),
            nn.Conv1d(d_model // 4, d_model // 2, kernel_size, padding=padding),
            nn.LeakyReLU(0.1, inplace=True),
            nn.GroupNorm(groups, d_model // 2),
            nn.Conv1d(d_model // 2, d_model, kernel_size, padding=padding),
            nn.LeakyReLU(0.1, inplace=True),
        )
        # ===========================
        # Bidirectional GRU Core
        # ===========================
        self.gru = nn.GRU(
            input_size=d_model,
            hidden_size=gru_hidden,
            num_layers=gru_layers,
            dropout=0 if gru_layers < 2 else dropout,
            batch_first=True,
            bidirectional=True,
        )

        # ===========================
        # Dense (MLP) Projection
        # ===========================
        self.mlp = nn.Sequential(
            nn.Linear(gru_hidden * 2, d_model),
            nn.SiLU(),
            nn.Linear(d_model, d_style),
        )
        # --- 3️Pooling ---
        self.pooling_type = pooling
        if pooling == "attention":
            self.pool = AttentionPooling(gru_hidden * 2)
        elif pooling == "adaptive":
            self.pool = nn.AdaptiveAvgPool1d(adaptive_out)
        else:
            self.pool = lambda x: torch.mean(x, dim=1)
        self.dropout = nn.Dropout(dropout)

    def forward(self, mel, lengths=None):
        """
        Args:
            mel: [B, n_mels, T]
            lengths: List[int] for GRU packing
        Returns:
            style: [B, d_style]
        """
        # --- CNN frontend ---
        x = self.conv(mel)  # [B, d_model, T]
        x = x.transpose(1, 2)  # [B, T, d_model]

        # --- RNN core ---
        if lengths is not None:
            x_packed = nn.utils.rnn.pack_padded_sequence(
                x, lengths, batch_first=True, enforce_sorted=False
            )
            outputs = self.gru(x_packed)[0]
            x = nn.utils.rnn.pad_packed_sequence(outputs, batch_first=True)[0]
        else:
            x = self.gru(x)[0]

        # --- Temporal pooling ---
        if self.pooling_type == "adaptive":
            x = x.transpose(1, 2)  # [B, D, T]
            x = self.pool(x).squeeze(-1)  # [B, D]
        else:
            x = self.pool(x)  # [B, D]

        # --- Dense projection ---
        x = self.dropout(x)
        style = self.mlp(x)  # [B, d_style]
        return style
