# coding:utf-8

import http
import typing as t

from makit.web import status


class ConfigException(Exception):
    """"""


class InvaidConfigException(ConfigException):
    """"""


class DisconnectError(Exception):
    """"""


class HttpException(Exception):
    def __init__(
            self,
            status_code: t.Optional[int] = None,
            detail: t.Optional[str] = None,
            headers: t.Optional[dict] = None,
    ) -> None:
        status_code = status_code or status.HTTP_500_INTERNAL_SERVER_ERROR
        if detail is None:
            detail = http.HTTPStatus(status_code).phrase
        self.status_code = status_code
        self.detail = detail
        self.headers = headers

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        return f"{class_name}(status_code={self.status_code!r}, detail={self.detail!r})"


class HttpNotFoundException(HttpException):
    def __init__(self, detail=None, headers=None):
        super().__init__(status_code=status.HTTP_404_NOT_FOUND, detail=detail, headers=headers)


class HttpForbiddenException(HttpException):
    def __init__(self, detail=None, headers=None):
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, detail=detail, headers=headers)


class HttpUnauthorizedException(HttpException):
    def __init__(self, detail=None, headers=None):
        super().__init__(status_code=status.HTTP_401_UNAUTHORIZED, detail=detail, headers=headers)


class InvalidMiddlewareError(Exception):
    """"""
