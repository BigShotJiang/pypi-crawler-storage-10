# coding:utf-8

APP = dict(
    name='makit-web',
    host='127.0.0.1',
    port=8000,
    debug=True,
)

JWT = dict()

CORS = dict()
