# coding:utf-8


class PathConverter:
    regex = None

    def convert(self, value: str):
        return value


class StrConverter(PathConverter):
    regex = '[^/]+'


class IntConverter(PathConverter):
    regex = r'\d+'

    def convert(self, value) -> int:
        return int(value)


class BoolConverter(PathConverter):
    regex = '(1|true|0|false)'

    def convert(self, value: str) -> bool:
        value = value.lower()
        if value in ['1', 'true']:
            return True
        return False


class FloatConvertor(PathConverter):
    regex = r"[0-9]+(\.[0-9]+)?"

    def convert(self, value: str) -> float:
        return float(value)


class PathConvertor(PathConverter):
    regex = ".*"


CONVERTERS = {
    'str': StrConverter,
    'int': IntConverter,
    'float': FloatConvertor,
    'path': PathConvertor,
    'bool': BoolConverter
}
