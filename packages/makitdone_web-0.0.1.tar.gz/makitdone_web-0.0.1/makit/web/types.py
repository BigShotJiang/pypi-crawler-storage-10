# coding:utf-8

import typing as t

Message = t.Dict[str, t.Any]
Scope = t.MutableMapping[str, t.Any]
Receive = t.Callable[[], t.Awaitable[Message]]
Send = t.Callable[[Message], t.Awaitable[None]]
