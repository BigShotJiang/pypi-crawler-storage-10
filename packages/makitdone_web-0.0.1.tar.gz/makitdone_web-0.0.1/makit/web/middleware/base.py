# coding:utf-8
import typing as t

from makit.web.context import Context

MiddlewareHandler = t.Callable[[Context], t.Awaitable[None]]


class MiddlewareClass(type):
    """"""


class Middleware(metaclass=MiddlewareClass):
    """"""

    async def __call__(self, c: Context):
        await c.next()


class HandlerMiddleware(Middleware):
    def __init__(self, handler):
        self.handler = handler

    async def __call__(self, c: Context):
        await self.handler(c)
