# coding:utf-8

from makit.web.context import Context
from makit.web.middleware import Middleware


class GZipMiddleware(Middleware):

    async def __call__(self, c: Context):
        # TODO
        pass
