Setup:

- Install `account_usability`

Credit invoice:

- Create a credit for "Gemini Furniture"
- Add line "Gutschrift" with price 20'000 without taxes
- Create invoice for "Gemini Furniture" for 30'000
- Go to "Customer > Invoices" and apply filter "Has Outstanding Credits"
- Check if the invoice is shown

Reconicle:

- Open the invoice of "Gemini Furniture"
- Pay the invoice with the credit and return to the list
- Ensure that the invoice is not shown

Customer payments:

- Create a customer payment for "Gemini Furniture"
- Enter 5'000 and post
- Go to "Customer > Invoices" and apply filter "Has Outstanding Credits"
- Check if the invoice is shown
