# flake8: noqa

# import apis into api package
from wds_client.api.capabilities_api import CapabilitiesApi
from wds_client.api.collection_api import CollectionApi
from wds_client.api.general_wds_information_api import GeneralWDSInformationApi
from wds_client.api.import_api import ImportApi
from wds_client.api.job_api import JobApi
from wds_client.api.record_api import RecordApi
from wds_client.api.records_api import RecordsApi
from wds_client.api.schema_api import SchemaApi
from wds_client.api.workspace_api import WorkspaceApi

