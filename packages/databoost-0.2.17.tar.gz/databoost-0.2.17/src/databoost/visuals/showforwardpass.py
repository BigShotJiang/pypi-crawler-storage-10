import torch
import matplotlib.pyplot as plt
import numpy as np

def show_forward_pass(model, x_input, percentile=None):
    """
    Visualizza la rete con attivazioni fornite dal forward integrato del modello.
    - Input: primo layer
    - Hidden: attivazioni intermedie
    - Output: ultima attivazione
    Colori: rosso <0, bianco=0, verde>0, saturazione proporzionale al modulo.
    """
    
    model.eval()
    
    # Forward pass, raccogli tutte le attivazioni restituite
    with torch.inference_mode():
        acts = model(x_input.unsqueeze(0)) if x_input.ndim==1 else model(x_input)
    
    # Se il modello restituisce un singolo tensore, trasformalo in tuple
    if not isinstance(acts, (tuple, list)):
        acts = (acts,)
    
    # Inserisci input come primo layer
    input_vals = x_input.detach().numpy() if isinstance(x_input, torch.Tensor) else np.array(x_input)
    activations = [input_vals] + [a.detach().numpy()[0] if a.ndim==2 else a.detach().numpy() for a in acts]
    
    layer_neurons = [len(a) for a in activations]
    neuroni_lista = []
    
    for i, layer_vals in enumerate(activations):
        n_neurons = len(layer_vals)
        coords_y = np.linspace(-n_neurons/2, n_neurons/2, n_neurons)
        max_abs = np.max(np.abs(layer_vals)) + 1e-8
        
        for idx, y in enumerate(coords_y):
            val = layer_vals[idx]
            
            # Colore rosso/bianco/verde
            if percentile is None or i==0:
                if val > 0:
                    norm = val / max_abs
                    color = (1 - norm, 1, 1 - norm)  # verde
                elif val < 0:
                    norm = -val / max_abs
                    color = (1, 1 - norm, 1 - norm)  # rosso
                else:
                    color = (1,1,1)  # bianco
            else:
                thresh = np.percentile(layer_vals, percentile)
                color = "green" if val >= thresh else "gray"
            
            plt.scatter(i, y, color=color, s=500, zorder=2)
            neuroni_lista.append((i, y))
    
    # Connessioni
    for i in range(len(layer_neurons)-1):
        actual_neurons = [t for t in neuroni_lista if t[0]==i]
        next_neurons = [t for t in neuroni_lista if t[0]==i+1]
        for n1 in actual_neurons:
            x1, y1 = n1
            for n2 in next_neurons:
                x2, y2 = n2
                plt.plot([x1,x2],[y1,y2],color="gray",zorder=1)
    
    plt.axis("off")
    plt.show()
