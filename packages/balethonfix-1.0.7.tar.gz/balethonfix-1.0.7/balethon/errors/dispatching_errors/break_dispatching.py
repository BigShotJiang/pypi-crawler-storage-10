class BreakDispatching(Exception):
    pass
