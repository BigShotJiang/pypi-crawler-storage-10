
from setuptools import setup

setup(
    name="mts-gendoc-cobol",
    version="1.0.0",
    description="Generate COBOL documentation using Copilot",
    author="Your Name",
    author_email="your.email@example.com",
    packages=["gendoc"],
    entry_points={
        'console_scripts': [
            'gen-doc=gendoc.__main__:main'
        ]
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
