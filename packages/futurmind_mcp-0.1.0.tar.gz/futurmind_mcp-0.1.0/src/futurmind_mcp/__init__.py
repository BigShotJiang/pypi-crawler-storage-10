# Futurmind MCP Server Package
"""
Futurmind Expert Digital Twin MCP Server

A Model Context Protocol (MCP) server that provides access to 
expert digital twins through standardized interface.
"""

__version__ = "0.1.0"
