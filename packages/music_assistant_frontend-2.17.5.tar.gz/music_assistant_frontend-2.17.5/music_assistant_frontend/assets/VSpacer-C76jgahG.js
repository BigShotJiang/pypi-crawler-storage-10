/* empty css              */import{cO as r}from"./index-CoB_2BUd.js";const e=r("v-spacer","div","VSpacer");export{e as V};
