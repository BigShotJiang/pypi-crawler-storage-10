# flake8: noqa

# import apis into api package
from wink_sdk_booking.api.checkout_api import CheckoutApi
from wink_sdk_booking.api.consumer_booking_api import ConsumerBookingApi
from wink_sdk_booking.api.review_api import ReviewApi
from wink_sdk_booking.api.shopping_cart_api import ShoppingCartApi

