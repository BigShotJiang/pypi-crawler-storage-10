select implementation details of fakecbed
=========================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:
