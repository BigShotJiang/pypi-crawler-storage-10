Literature
==========

There are currently no references cited in the ``fakecbed`` documentation.
