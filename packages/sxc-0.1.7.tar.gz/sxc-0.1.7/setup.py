from setuptools import setup, find_packages

setup(
    name="constraint_optimisation",
    version="0.1.7",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "scipy",
    ],
    author="Suchibrata Patra",
    author_email="your_email@example.com",
    description="A Python package for unconstrained and constrained optimisation algorithms",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/constraint_optimisation/",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
