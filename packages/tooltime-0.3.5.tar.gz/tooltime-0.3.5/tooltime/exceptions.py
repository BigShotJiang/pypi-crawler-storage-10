from __future__ import annotations


class RepresentationDetectionException(Exception):
    """raised when time datatype representation could not be detected"""

    pass
