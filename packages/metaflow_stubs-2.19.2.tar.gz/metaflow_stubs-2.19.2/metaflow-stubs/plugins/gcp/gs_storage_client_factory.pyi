######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.2                                                                                 #
# Generated on 2025-10-28T11:13:58.732482                                                            #
######################################################################################################

from __future__ import annotations



class GcpDefaultClientProvider(object, metaclass=type):
    @staticmethod
    def get_gs_storage_client(*args, **kwargs):
        ...
    @staticmethod
    def get_credentials(scopes, *args, **kwargs):
        ...
    ...

cached_provider_class: None

def get_gs_storage_client():
    ...

def get_credentials(scopes, *args, **kwargs):
    ...

