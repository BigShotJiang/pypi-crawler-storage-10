######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.2                                                                                 #
# Generated on 2025-10-28T11:13:58.699387                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

