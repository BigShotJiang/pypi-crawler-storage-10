######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.2                                                                                 #
# Generated on 2025-10-28T11:13:58.670000                                                            #
######################################################################################################

from __future__ import annotations


from .._vendor import yaml as yaml

def yaml_parser(content: str) -> dict:
    """
    Parse YAML content to a dictionary.
    
    Parameters
    ----------
    content : str
    
    Returns
    -------
    dict
    """
    ...

