######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.2                                                                                 #
# Generated on 2025-10-28T11:13:58.662690                                                            #
######################################################################################################

from __future__ import annotations



def namedtuple_with_defaults(typename, field_descr, defaults = ()):
    ...

foreach_frame_field_list: list

