######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.2                                                                                 #
# Generated on 2025-10-28T11:13:58.690022                                                            #
######################################################################################################

from __future__ import annotations



def copy_tree(src, dst, update = False):
    ...

def sync_local_metadata_to_datastore(metadata_local_dir, task_ds):
    ...

def sync_local_metadata_from_datastore(metadata_local_dir, task_ds):
    ...

