"""
This is the nodes module, in which we have
all the classes that make the concept work.

This module is specific to process with GPU.
"""