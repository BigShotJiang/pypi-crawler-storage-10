"""Test :mod:`d_scale_fit`."""

import control
import numpy as np
import pytest

import dkpy


class TestTfFitSlicot:
    """Test :class:`DScaleFitSlicot`."""

    @pytest.mark.parametrize(
        "omega, tf_l, tf_r, order, block_structure, atol",
        [
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                1,
                [dkpy.ComplexFullBlock(1, 1), dkpy.ComplexFullBlock(1, 1)],
                1e-2,
            ),
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                [1, 0],
                [dkpy.ComplexFullBlock(1, 1), dkpy.ComplexFullBlock(1, 1)],
                1e-2,
            ),
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                1,
                [dkpy.ComplexFullBlock(2, 2)],
                1e-2,
            ),
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                1,
                np.array([[1, 1], [1, 1]]),
                1e-2,
            ),
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [0],
                        ],
                        [
                            [0],
                            [1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1],
                        ],
                        [
                            [1],
                            [1],
                        ],
                    ],
                ),
                [1, 0],
                np.array([[1, 1], [1, 1]]),
                1e-2,
            ),
        ],
    )
    def test_tf_fit_slicot(self, omega, tf_l, tf_r, order, block_structure, atol):
        """Test :class:`DScaleFitSlicot`."""
        D_l_omega = tf_l(1j * omega)
        D_r_omega = tf_r(1j * omega)
        if D_l_omega.ndim == 1:
            D_l_omega = D_l_omega.reshape((1, 1, -1))
        if D_r_omega.ndim == 1:
            D_r_omega = D_r_omega.reshape((1, 1, -1))
        tf_l_fit, _ = dkpy.DScaleFitSlicot().fit(
            omega, D_l_omega, D_r_omega, order, block_structure
        )
        D_l_omega_fit = tf_l_fit(1j * omega)
        if D_l_omega_fit.ndim == 1:
            D_l_omega_fit = D_l_omega_fit.reshape((1, 1, -1))
        np.testing.assert_allclose(D_l_omega, D_l_omega_fit, atol=atol)

    @pytest.mark.parametrize(
        "omega, tf_l, tf_r, order, block_structure",
        [
            (
                np.logspace(-2, 2, 100),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [1, 1],
                            [1, 1],
                        ],
                        [
                            [1, 1],
                            [1, 1],
                            [1, 1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1, 9],
                            [1, 7],
                        ],
                        [
                            [1, 8],
                            [1, 6],
                            [1, 10],
                        ],
                    ],
                ),
                control.TransferFunction(
                    [
                        [
                            [1, 1],
                            [1, 1],
                            [1, 1],
                        ],
                        [
                            [1, 1],
                            [1, 1],
                            [1, 1],
                        ],
                    ],
                    [
                        [
                            [1, 10],
                            [1, 9],
                            [1, 7],
                        ],
                        [
                            [1, 8],
                            [1, 6],
                            [1, 10],
                        ],
                    ],
                ),
                1,
                None,
            ),
        ],
    )
    def test_tf_fit_slicot_error(self, omega, tf_l, tf_r, order, block_structure):
        with pytest.raises(ValueError):
            D_l_omega = tf_l(1j * omega)
            D_r_omega = tf_r(1j * omega)
            if D_l_omega.ndim == 1:
                D_l_omega = D_l_omega.reshape((1, 1, -1))
            if D_r_omega.ndim == 1:
                D_r_omega = D_r_omega.reshape((1, 1, -1))
            tf_fit, _ = dkpy.DScaleFitSlicot().fit(
                omega, D_l_omega, D_r_omega, order, block_structure
            )


class TestGenerateDScaleMask:
    @pytest.mark.parametrize(
        "block_structure, mask_l_exp, mask_r_exp",
        [
            (
                [dkpy.ComplexFullBlock(1, 1), dkpy.ComplexFullBlock(1, 1)],
                np.array(
                    [
                        [-1, 0],
                        [0, 1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [-1, 0],
                        [0, 1],
                    ],
                    dtype=int,
                ),
            ),
            (
                [dkpy.ComplexFullBlock(2, 2), dkpy.ComplexFullBlock(1, 1)],
                np.array(
                    [
                        [-1, 0, 0],
                        [0, -1, 0],
                        [0, 0, 1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [-1, 0, 0],
                        [0, -1, 0],
                        [0, 0, 1],
                    ],
                    dtype=int,
                ),
            ),
            (
                [dkpy.ComplexFullBlock(1, 1), dkpy.ComplexFullBlock(2, 2)],
                np.array(
                    [
                        [-1, 0, 0],
                        [0, 1, 0],
                        [0, 0, 1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [-1, 0, 0],
                        [0, 1, 0],
                        [0, 0, 1],
                    ],
                    dtype=int,
                ),
            ),
            (
                [dkpy.ComplexDiagonalBlock(2), dkpy.ComplexFullBlock(2, 3)],
                np.array(
                    [
                        [-1, -1, 0, 0, 0],
                        [0, -1, 0, 0, 0],
                        [0, 0, 1, 0, 0],
                        [0, 0, 0, 1, 0],
                        [0, 0, 0, 0, 1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [-1, -1, 0, 0],
                        [0, -1, 0, 0],
                        [0, 0, 1, 0],
                        [0, 0, 0, 1],
                    ],
                    dtype=int,
                ),
            ),
            (
                [dkpy.ComplexFullBlock(2, 3), dkpy.ComplexDiagonalBlock(2)],
                np.array(
                    [
                        [1, 0, 0, 0, 0],
                        [0, 1, 0, 0, 0],
                        [0, 0, 1, 0, 0],
                        [0, 0, 0, -1, -1],
                        [0, 0, 0, 0, -1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [1, 0, 0, 0],
                        [0, 1, 0, 0],
                        [0, 0, -1, -1],
                        [0, 0, 0, -1],
                    ],
                    dtype=int,
                ),
            ),
            (
                [
                    dkpy.ComplexDiagonalBlock(3),
                    dkpy.ComplexFullBlock(2, 3),
                    dkpy.ComplexDiagonalBlock(2),
                ],
                np.array(
                    [
                        [-1, -1, -1, 0, 0, 0, 0, 0],
                        [0, -1, -1, 0, 0, 0, 0, 0],
                        [0, 0, -1, 0, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, -1, -1],
                        [0, 0, 0, 0, 0, 0, 0, -1],
                    ],
                    dtype=int,
                ),
                np.array(
                    [
                        [-1, -1, -1, 0, 0, 0, 0],
                        [0, -1, -1, 0, 0, 0, 0],
                        [0, 0, -1, 0, 0, 0, 0],
                        [0, 0, 0, 1, 0, 0, 0],
                        [0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, -1, -1],
                        [0, 0, 0, 0, 0, 0, -1],
                    ],
                    dtype=int,
                ),
            ),
        ],
    )
    def test_generate_d_scale_mask(self, block_structure, mask_l_exp, mask_r_exp):
        """Test :func:`_mask_from_block_strucure`."""
        mask_l, mask_r = dkpy.d_scale_fit._generate_d_scale_mask(block_structure)
        np.testing.assert_allclose(mask_l_exp, mask_l)
        np.testing.assert_allclose(mask_r_exp, mask_r)


class TestInvertBiproperSs:
    """Test :func:`_invert_biproper_ss`."""

    @pytest.mark.parametrize(
        "tf",
        [
            control.TransferFunction([1, 2], [3, 4]),
            control.TransferFunction([1, 2, 1], [3, 6, 1]),
            control.TransferFunction([6, 2, 5], [5, 6, 7]),
        ],
    )
    def test_invert_biproper_ss(self, tf):
        """Test :func:`_invert_biproper_ss`."""
        ss = control.tf2ss(tf)
        ss_inv = dkpy.d_scale_fit._invert_biproper_ss(ss)
        eye_l = control.minreal(ss * ss_inv, verbose=False)
        eye_r = control.minreal(ss_inv * ss, verbose=False)
        omega = np.logspace(-3, 3, 100)
        for eye in [eye_l, eye_r]:
            mag, _, _ = eye.frequency_response(omega)
            np.testing.assert_allclose(1, eye.dcgain())
            np.testing.assert_allclose(np.ones_like(mag), mag)
