Code shared by the `narada` and `narada-pyodide` packages.
