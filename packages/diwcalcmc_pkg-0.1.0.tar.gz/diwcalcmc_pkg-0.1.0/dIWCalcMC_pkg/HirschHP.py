# %%
# === Standard library ===
import math
import time
import warnings
import subprocess

# === Core scientific stack ===
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# === SciPy modules ===
from scipy import integrate, optimize, stats, special
from scipy.integrate import quad, trapezoid
from scipy.optimize import fsolve, brentq, root_scalar

# === Matplotlib setup (optional aesthetic) ===
plt.style.use('seaborn-v0_8-whitegrid')

# === Warning filters ===
warnings.filterwarnings('ignore', category=RuntimeWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# %%
# Universal gas constant in J/mol·K
R_gas = 8.314  

# Reference temperature in K
T_ref = 300  

# Numerical tolerance for root finding
tol = 1e-5  

# %%
# -------------------------------
# EOS for FeO and Fe2O3
# -------------------------------

# -------------------------------
# Vinet EOS (Komabayashi 2014)
# -------------------------------
def VinetVolumeFunc2(P, T, V0, K0, Kprime, alpha0, delta0):
    """
    Calculate the molar volume (cm³/mol) of a phase at a given pressure P (GPa) 
    and temperature T (K) using the Vinet equation of state with thermal expansion.

    Parameters
    ----------
    P : float
        Pressure in GPa
    T : float
        Temperature in K
    V0 : float
        Reference molar volume at ambient conditions (cm³/mol)
    K0 : float
        Bulk modulus at ambient conditions (GPa)
    Kprime : float
        Pressure derivative of bulk modulus
    alpha0 : float
        Thermal expansion coefficient at reference conditions
    delta0 : float
        Parameter controlling temperature dependence of alpha

    Returns
    -------
    float
        Molar volume at given P and T
    """
    T0 = 298.15  # reference temperature in K
    kappa = 1.4  # empirical exponent for thermal expansion

    # -------------------------------
    # Define implicit Vinet EOS equation for compression factor x
    # x = (VT0 / V0)^(1/3)
    # -------------------------------
    def vinet_eq(x):
        return 3*K0*(x**-2)*(1-x)*np.exp(1.5*(Kprime-1)*(1-x)) - P

    # Solve for x using a numerical solver
    xsol = fsolve(vinet_eq, 0.95, xtol=1e-12)[0]
    VT0_P = V0 * xsol**3  # volume at P at reference temperature

    # -------------------------------
    # Compute thermal expansion adjustment
    # -------------------------------
    alpha = alpha0 * np.exp((-delta0/kappa) * (1 - (VT0_P/V0)**kappa))

    # Return final volume at (T, P)
    return VT0_P * np.exp(alpha * (T - T0))


# -------------------------------
# Gibbs free energy polynomial
# -------------------------------
def GibbsPoly(a, b, c, d, e, f, g, T):
    """
    Evaluate the Gibbs energy polynomial for a given phase and temperature.

    Polynomial form:
    G(T) = a + b*T + c*T*ln(T) + d*T^2 + e/T + f*ln(T) + g*T^3

    Parameters
    ----------
    a, b, c, d, e, f, g : float
        Polynomial coefficients for a given phase
    T : float
        Temperature in K

    Returns
    -------
    float
        Gibbs energy at temperature T
    """
    return a + b*T + c*T*np.log(T) + d*T**2 + e/T + f*np.log(T) + g*T**3



# %%
# -------------------------------
# EOS and stability of Fe
# -------------------------------
# 
# # -------------------------------
# Stable iron phase (self-contained)
# -------------------------------
def StableIronPhase(T, P):
    """
    Compute Gibbs energies of Fe phases and return the most stable phase
    using hardcoded LowT and HiT dictionaries instead of Excel.

    Parameters
    ----------
    T : float
        Temperature in K
    P : float
        Pressure in GPa

    Returns
    -------
    G : np.ndarray
        Gibbs energies of all Fe phases (J/mol)
    stable : int
        Index of the most stable phase (0-based)
    """

    # -------------------------------
    # Hardcoded LowT and HiT SGTE data for Fe phases
    # -------------------------------
    LowT = {
        "a": [-236.7000, 1225.7, -2480.08, 5970.7, 13265.87],
        "b": [132.4160, 124.134, 136.725, 124.134, 117.57557],
        "c": [-24.6643, -23.5143, -24.6643, -23.5143, -23.5143],
        "d": [-0.0038, -0.004398, -0.00375752, -0.00439752, -0.00439752],
        "e": [-5.8927e-08]*5,
        "f": [77359, 77359, 77358.5, 77358.5, 77358.5],
        "g": [0, 0, 0, 0, -3.68e-21],
        "h": [0]*5
    }

    HiT = {
        "a": [-27097.396, -25383.581, -29340.780, -20638.581, -10838.830],
        "b": [300.253, 299.313, 304.562, 299.313, 291.302],
        "c": [-46.0]*5,
        "d": [0]*5,
        "e": [0]*5,
        "f": [0]*5,
        "g": [0]*5,
        "h": [-2.7885e31, 2.2960e31, 2.79e31, 2.30e31, 0]
    }

    # -------------------------------
    # Select LowT or HiT data based on temperature
    # -------------------------------
    Gdict = LowT if T < 1811 else HiT

    # Convert dictionary values to numpy arrays for vectorized computation
    a = np.array(Gdict["a"], dtype=float)
    b = np.array(Gdict["b"], dtype=float)
    c = np.array(Gdict["c"], dtype=float)
    d = np.array(Gdict["d"], dtype=float)
    e = np.array(Gdict["e"], dtype=float)
    f = np.array(Gdict["f"], dtype=float)
    g = np.array(Gdict["g"], dtype=float)
    h = np.array(Gdict["h"], dtype=float)

    N = len(a)
    G = np.zeros(N)

    # -------------------------------
    # Compute Gibbs energy for each phase
    # -------------------------------
    for gg in range(N):
        G[gg] = (a[gg] + b[gg]*T + c[gg]*T*np.log(T) +
                 d[gg]*T**2 + e[gg]*T**3 + f[gg]/T +
                 g[gg]*T**7 + h[gg]*T**-9)

    # -------------------------------
    # Magnetic correction for bcc-alpha (phase index 1)
    # -------------------------------
    Tc = 1043          # Curie temperature in K
    Pfactor = 0.4      # Pressure scaling factor
    Beta = 2.22        # Magnetic constant
    A = 1.55828482     # Scaling factor

    if T < Tc:
        Gmag = 1 - (1/A)*((79*(T/Tc)**-1 / (140*Pfactor)) +
                          (474/497)*((1/Pfactor)-1) *
                          ((T/Tc)**3/6 + (T/Tc)**9/135 + (T/Tc)**15/600))
    else:
        Gmag = (-1/A)*((T/Tc)**-5/10 + (T/Tc)**-15/315 + (T/Tc)**-25/1500)

    Gmag = Gmag * (R_gas*T*np.log(Beta+1))
    G[1] += Gmag

    # -------------------------------
    # EOS parameters (Komabayashi 2014)
    # -------------------------------
    EOSFe = np.array([
        [6.82, 163.4, 5.38, 7e-05, 5.5],    # fcc
        [7.092, 163.4, 5.38, 7e-05, 5.5],   # bcc-alpha
        [6.753, 163.4, 5.38, 5.8e-05, 5.1], # hcp
        [7.092, 163.4, 5.38, 7e-05, 5.5],   # bcc-delta
        [6.88, 148.0, 5.8, 9.0e-05, 5.1]    # liquid
    ])

    # -------------------------------
    # Pressure correction using Vinet EOS
    # -------------------------------
    GPressureAdjust = np.zeros(5)
    for j in range(5):
        PArray = np.linspace(0.0001, P, 100)
        VArray = np.array([VinetVolumeFunc2(Pi, T, *EOSFe[j]) for Pi in PArray])
        VdP = trapezoid(VArray, PArray)
        G[j] += VdP * 1000  # Convert from cm³·GPa/mol → J/mol

    # -------------------------------
    # Identify most stable phase (lowest Gibbs energy)
    # -------------------------------
    stable = np.argmin(G[:4])  # exclude liquid

    return G, stable


# -------------------------------
# Newton-Raphson solver for root-finding
# -------------------------------
def NewtRaphZero(func, x0, epsilon1=1e-9, maxiter=300):
    """
    Solve func(x) = 0 using a Newton-Raphson method with small-step numerical derivative.

    Parameters
    ----------
    func : callable
        Function whose root is sought
    x0 : float
        Initial guess
    epsilon1 : float
        Convergence tolerance for function value
    maxiter : int
        Maximum number of iterations

    Returns
    -------
    float
        Estimated root of the function
    """
    epsilon2 = 1e-12  # small step for numerical derivative
    x = x0
    counter = 1

    while counter < maxiter:
        fx = func(x)
        if abs(fx) < epsilon1:
            return x

        # Numerical derivative
        dfdx = (func(x + epsilon2) - func(x - epsilon2)) / (2*epsilon2)
        x -= fx / dfdx

        # Prevent negative values
        if x < 0:
            x = 1e-6 if counter <= 50 else 1e-8

        counter += 1

    # Return fallback value if convergence fails
    return 1e-4

# %%
# -------------------------------
# Main IW calculation: log10(fO2)
# -------------------------------
def IW_Hirsch_HP(p_bar, t_k):
    """
    Calculate log10(fO2) for the Fe-FeO equilibrium using 
    Hidayat (2015) and Dinsdale (1991) parameters.

    Parameters
    ----------
    p_bar : float
        Pressure in bar
    t_k : float
        Temperature in K

    Returns
    -------
    float
        log10(fO2)
    """

    # -------------------------------
    # Convert input pressure from bar -> GPa
    # -------------------------------
    P = p_bar / 1e4
    T = t_k  # Temperature in K

    # -------------------------------
    # Polynomial Gibbs coefficients for Fe, FeO, and O2
    # -------------------------------
    a = [-285203.5, -523138.5, -13137.52]
    b = [274.2455, 73.37019, 25.32003]
    c = [-49.19444, -26.96809, -33.627]
    d = [-0.004678477, -0.008836071, -0.00119159]
    e = [297568.8, 1498519, 525809.556]
    f = [574.4469, 25471.09, 0]
    g = [0, 0, 1.356111e-8]

    # -------------------------------
    # Adjust low-temperature O2 parameters
    # -------------------------------
    if T < 1000:
        a[2], b[2], c[2], d[2], e[2], f[2], g[2] = \
            -6961.7445, -51.0057, -22.271, -0.0101977, -7629.7484, 0, 1.32369e-8

    # -------------------------------
    # Integrate molar volumes for FeO solids using Vinet EOS
    # -------------------------------
    dvdpFeOsolid = quad(
        lambda Pp: VinetVolumeFunc2(Pp, T,
                                    V0=12.256, K0=149, Kprime=3.83,
                                    alpha0=4.5e-5, delta0=4.25),
        0, P
    )[0]

    dvdpFeO1_5solid = quad(
        lambda Pp: VinetVolumeFunc2(Pp, T,
                                    V0=16.372, K0=1499, Kprime=3.83,
                                    alpha0=4.5e-5, delta0=4.25),
        0, P
    )[0]

    # -------------------------------
    # Compute Gibbs energies of FeO, FeO1.5, and O2
    # -------------------------------
    GFeO   = GibbsPoly(a[0], b[0], c[0], d[0], e[0], f[0], g[0], T) + dvdpFeOsolid*1000
    GFeO15 = GibbsPoly(a[1], b[1], c[1], d[1], e[1], f[1], g[1], T) + dvdpFeO1_5solid*1000
    GO2    = GibbsPoly(a[2], b[2], c[2], d[2], e[2], f[2], g[2], T)

    # -------------------------------
    # Compute Gibbs energy of stable Fe phase
    # -------------------------------
    GFe_all, stable = StableIronPhase(T, P)
    GFe = GFe_all[stable]

    # -------------------------------
    # Mixing parameters for FeO–FeO1.5 system
    # -------------------------------
    q00 = -5.94e4
    q10 =  4.27e4

    # -------------------------------
    # Gibbs energy for Fe saturation
    # -------------------------------
    DeltaGFeSat = 3*GFeO - 2*GFeO15 - GFe

    # -------------------------------
    # Function for XFeO1.5 equilibrium using Newton-Raphson
    # -------------------------------
    func = lambda x2: (
        0.5*DeltaGFeSat
        + R_gas*T*np.log((1-x2)**1.5/x2)
        + 0.5*3*((q00 + 2*q10*(1-x2))*x2**2)
        - 0.5*2*((1-x2)**2*(q00 + q10 - 2*q10*x2))
    )

    XFeO15 = NewtRaphZero(func, 0.05)  # solve for equilibrium mole fraction
    XFeO   = 1 - XFeO15                 # complementary fraction

    # -------------------------------
    # Activity coefficients for non-ideal mixing
    # -------------------------------
    gammaFeO   = (q00 + 2*q10*(1-XFeO15)) * XFeO15**2
    gammaFeO15 = (1-XFeO15)**2 * (q00 + q10 - 2*q10*XFeO15)

    # -------------------------------
    # Gibbs energy change for IW reaction
    # -------------------------------
    DeltaGfO2 = GFeO15 - GFeO - 0.25*GO2

    # -------------------------------
    # Calculate log10(fO2)
    # -------------------------------
    logfO2 = (4 / (2.303 * T * R_gas)) * (
        DeltaGfO2 + R_gas*T*np.log(XFeO15 / XFeO) + gammaFeO15 - gammaFeO
    )

    return logfO2


# %%



