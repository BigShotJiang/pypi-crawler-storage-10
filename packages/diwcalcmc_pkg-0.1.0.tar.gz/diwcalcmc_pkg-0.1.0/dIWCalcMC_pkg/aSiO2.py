# %%
# ----------------------------------------------------------------------
# Standard Library Imports
# ----------------------------------------------------------------------
import math
import time
from datetime import timedelta
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# ----------------------------------------------------------------------
# Third-Party Imports
# ----------------------------------------------------------------------
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# %%
# ============================================================
# 🔹 Import MAGEMin_C 
# ============================================================
from julia import Julia
jl = Julia(compiled_modules=False)  # initialize Julia
from julia import Main

Main.eval("""
using MAGEMin_C
data = Initialize_MAGEMin("ig", verbose=false)
""")

# %%
# ============================================================
# 🔹 CONSTANTS AND PHYSICAL PARAMETERS
# ============================================================
R = 8.3145  # Universal gas constant [J·mol⁻¹·K⁻¹]

# ============================================================
# 🔹 MOLAR MASSES OF OXIDES [g·mol⁻¹]
# ============================================================
MOLAR_MASSES = {
    "SiO2" :  60.0843,
    "Al2O3": 101.9613,
    "CaO"  :  56.0774,
    "MgO"  :  40.3044,
    "FeO"  :  71.844,
    "K2O"  :  94.196,
    "Na2O" :  61.9789,
    "TiO2" :  79.8658,
    "Cr2O3": 151.990,
    "H2O"  :  18.01528,
    "S"    :  32.065,
}

# ============================================================
# 🔹 INTERACTION PARAMETERS W (Massuyeau et al., 2015)
# ============================================================
W = {
    "Al2O3-SiO2": -86189,
    "CaO-SiO2":   83743,
    "Na2O-SiO2": -85227,
    "K2O-SiO2":  -85967,
    "Al2O3-FeO": -990442,
    "Al2O3-MgO":  174780,
    "FeO-CaO":    722813,
    "CaO-Na2O":  -168280
}

# Key oxides for MAGEMin calculations
oxide_columns = ["SiO2","Al2O3","CaO","MgO","FeO","K2O","Na2O","TiO2","Cr2O3","H2O", "S"]

# %%
# ============================================================
# 🔹 FUNCTIONS
# ============================================================

# ============================================================
# 🔹 FUNCTION: Convert oxide wt% to mole fractions
# ============================================================
def oxide_molfractions(c_wt: dict):
    """Convert oxide wt% to mole fractions."""
    moles = {ox: c_wt[ox] / MOLAR_MASSES[ox] for ox in c_wt if ox in MOLAR_MASSES}
    total_moles = sum(moles.values())
    X = {ox: n / total_moles for ox, n in moles.items()}
    df = pd.DataFrame({
        "Wt%": pd.Series(c_wt),
        "Moles": pd.Series(moles),
        "Mole Fraction": pd.Series(X)
    })
    return df, X

# ============================================================
# 🔹 FUNCTION: ln(gamma_SiO2)
# ============================================================

def ln_gamma_SiO2(X: dict, W: dict, R, T):
    """Calculate ln(gamma_SiO2) based on Massuyeau et al., 2015."""
    ln_gamma = (
        W.get("Al2O3-SiO2", 0) * X.get("Al2O3", 0) * (1 - X.get("SiO2", 0)) +
        W.get("CaO-SiO2",   0) * X.get("CaO",   0) * (1 - X.get("SiO2", 0)) +
        W.get("Na2O-SiO2",  0) * X.get("Na2O",  0) * (1 - X.get("SiO2", 0)) +
        W.get("K2O-SiO2",   0) * X.get("K2O",   0) * (1 - X.get("SiO2", 0)) -
        (W.get("Al2O3-FeO", 0) * X.get("Al2O3", 0) * X.get("FeO", 0) +
         W.get("Al2O3-MgO", 0) * X.get("Al2O3", 0) * X.get("MgO", 0) +
         W.get("FeO-CaO",   0) * X.get("FeO",   0) * X.get("CaO", 0) +
         W.get("CaO-Na2O",  0) * X.get("CaO",   0) * X.get("Na2O", 0))
    ) / (R * T)
    return ln_gamma

# ============================================================
# 🔹 FUNCTION: aSiO2 (SiO2 activity)
# ============================================================

def aSiO2(X: dict, W: dict, R, T):
    """Compute SiO2 activity in a silicate melt."""
    ln_gamma = ln_gamma_SiO2(X, W, R, T)
    gamma = np.exp(ln_gamma)
    return gamma * X.get("SiO2", 0)

# %%
# ============================================================
# 🔹 RUN THE aSiO2 CALCULATION with Massuyeau et al., 2015; Chem Geol 418
# ============================================================

def run_SiO2_activity_models(data, output_dir=None):
    """
    Compute SiO2 activity using both Massuyeau et al. (2015) and MAGEMin_C,
    either from an Excel file or directly from a pandas DataFrame.

    Parameters
    ----------
    data : str or pd.DataFrame
        Either a path to an Excel file containing oxide compositions,
        or a pandas DataFrame with oxide compositions.
    output_dir : str, optional
        Directory where results will be saved as Excel (optional).

    Returns
    -------
    pd.DataFrame
        DataFrame containing SiO2 activities from both models.
    """

    # --- Handle file path or DataFrame input ---
    if isinstance(data, str):
        df = pd.read_excel(data)
    elif isinstance(data, pd.DataFrame):
        df = data.copy()
    else:
        raise TypeError("Input must be either a file path or a pandas DataFrame.")

    # --- Check for essential columns ---
    if "t_k" not in df.columns:
        raise ValueError("Input must contain a column 't_k' (temperature in K).")
    if "P" not in df.columns:
        df["P"] = 1e5  # default pressure if missing

    results = []

    # --- Loop over each row (sample or MC draw) ---
    for idx, row in df.iterrows():
        try:
            sample = row.get("Sample", f"Sample_{idx}")
            T = row.get("t_k", 1673.15)
            P = row.get("P", 1e5)
            PMag = P / 1e4  # convert to kbar
            TMag = T - 273.15

            # === 1. Extract and normalize oxide composition ===
            c_wt_julia = {ox: row[ox] for ox in oxide_columns if ox in row and pd.notna(row[ox])}
            if not c_wt_julia:
                raise ValueError("No valid oxide composition found.")

            total_ox = sum(c_wt_julia.values())
            c_wt_julia = {ox: wt / total_ox * 100 for ox, wt in c_wt_julia.items()}

            # === 2. Massuyeau et al. (2015) model ===
            _, X = oxide_molfractions(c_wt_julia)
            a_mass = aSiO2(X, W, R, T)
            ln_gamma_mass = ln_gamma_SiO2(X, W, R, T)

            # === 3. MAGEMin_C model ===
            Main.Xoxides = list(c_wt_julia.keys())
            Main.X = [float(v) for v in c_wt_julia.values()]
            Main.sys_in = "wt"
            Main.P = float(PMag)
            Main.T = float(TMag)

            Main.eval("""
            out = single_point_minimization(P, T, data, X=X, Xoxides=Xoxides, sys_in=sys_in)
            """)
            a_MAGEMin = Main.out.aSiO2

            # === Store results ===
            results.append({
                "Sample": sample,
                "T(K)": T,
                "P(bar)": P,
                "a(SiO2)_Massuyeau": a_mass,
                "ln(gamma_SiO2)": ln_gamma_mass,
                "a(SiO2)_MAGEMin": a_MAGEMin
            })

        except Exception as e:
            print(f"⚠️ {sample}: SiO2 activity calculation failed — {e}")
            continue

    # --- Convert results to DataFrame ---
    df_results = pd.DataFrame(results)

    # --- Optional saving ---
    if output_dir:
        output_file = os.path.join(output_dir, "Compo_SiO2_results.xlsx")
        df_results.to_excel(output_file, index=False)

    return df_results


# %%
