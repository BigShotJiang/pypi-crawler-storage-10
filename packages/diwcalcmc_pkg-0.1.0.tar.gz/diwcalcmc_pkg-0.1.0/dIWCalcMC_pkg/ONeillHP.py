# %%
# === Standard library ===
import math
import time
import warnings
import subprocess

# === Core scientific stack ===
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# === SciPy modules ===
from scipy import integrate, optimize, stats, special
from scipy.integrate import quad, trapezoid
from scipy.optimize import fsolve, brentq, root_scalar

# === Matplotlib setup (optional aesthetic) ===
plt.style.use('seaborn-v0_8-whitegrid')

# === Warning filters ===
warnings.filterwarnings('ignore', category=RuntimeWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# %%
# Universal gas constant in J/mol·K
R_gas = 8.314  

# Reference temperature in K
T_ref = 300  

# Numerical tolerance for root finding
tol = 1e-5  

# %%
# ============================================================
# FeO Equation of State (Mie–Grüneisen + Birch–Murnaghan)
# Based on Campbell (2009)
# ============================================================

# ============================================================
# === 1. Thermal energy model (Debye/Einstein-like) ===
# ============================================================

def thermal_energy(theta_D, T, n, R=8.314):
    """
    Thermal energy per mole using the Dulong–Petit high-T limit:
        E = 3nRT

    Parameters
    ----------
    theta_D : float
        Debye temperature (K)
    T : float
        Temperature (K)
    n : int
        Number of atoms per formula unit
    R : float, optional
        Gas constant [J/mol/K]

    Returns
    -------
    float
        Thermal energy (J/mol)
    """
    # Placeholder; replace with full Debye model if needed
    return 3 * n * R * T


# ============================================================
# === 2. Birch–Murnaghan cold compression term ===
# ============================================================

def birch_murnaghan_pressure(V, V0, K0, Kp):
    """
    Third-order Birch–Murnaghan isothermal equation of state.

    Parameters
    ----------
    V, V0 : float
        Volume and reference volume [m³/mol]
    K0 : float
        Bulk modulus [Pa]
    Kp : float
        First pressure derivative of K0

    Returns
    -------
    float
        Cold (elastic) pressure [Pa]
    """
    eta = (V0 / V) ** (1/3)
    return (3/2) * K0 * (eta**7 - eta**5) * (1 - 0.75 * (4 - Kp) * (eta**2 - 1))


# ============================================================
# === 3. Mie–Grüneisen thermal pressure correction ===
# ============================================================

def total_pressure(V, V0, K0, Kp, gamma0, Hie, q):
    """
    Total pressure = elastic (Birch–Murnaghan) + thermal (Mie–Grüneisen).

    Parameters
    ----------
    V, V0, K0, Kp : floats
        EOS parameters (see above)
    gamma0 : float
        Grüneisen parameter at reference volume
    Hie : float
        Thermal energy difference, E(T) - E(T_ref)
    q : float
        Grüneisen volume exponent (γ ∝ V^q)

    Returns
    -------
    float
        Total pressure (Pa)
    """
    P_cold = birch_murnaghan_pressure(V, V0, K0, Kp)
    P_thermal = gamma0 * Hie * V**(q - 1) / (V0**q)
    return P_cold + P_thermal


# ============================================================
# === 4. Analytical ∫V dP(V) term for ΔG computation ===
# ============================================================

def integral_VdP(V, V0, K0, Kp, gamma0, Hie, q):
    """
    Analytical form of ∫V dP(V) for the combined EOS.

    Used to compute ΔG via:
        ΔG = P*V - ∫V dP

    Parameters
    ----------
    V, V0, K0, Kp, gamma0, Hie, q : floats

    Returns
    -------
    float
        Integral value [Pa·m³/mol]
    """
    term_thermal = (gamma0 * Hie / q) * (V / V0) ** q
    term_elastic = (9 * K0 * (
        (Kp - 4) * V0**3 +
        (14 - 3*Kp) * V**(2/3) * V0**(7/3) +
        (3*Kp - 16) * V**(4/3) * V0**(5/3)
    )) / (16 * V**2)
    return term_thermal - term_elastic


# ============================================================
# === 5. Numerical root-finder with safety checks ===
# ============================================================

def safe_root(func, v_min, v_max, tol=1e-8):
    """
    Robust Brent root finder with bracket checking.

    Returns NaN if no sign change is found.

    Parameters
    ----------
    func : callable
        Function f(V) = 0 to solve
    v_min, v_max : float
        Search interval [m³/mol]
    tol : float
        Tolerance for convergence

    Returns
    -------
    float
        Root V or NaN if no bracketed root is found
    """
    f_min, f_max = func(v_min), func(v_max)
    if f_min * f_max > 0:
        return np.nan
    return brentq(func, v_min, v_max, xtol=tol)


# ============================================================
# === 6. Main driver: Gibbs free energy grid ΔG(P,T) ===
# ============================================================

def compute_dG_MieBM(v0, k, kp, t_d, gamma0, q, n, t_ref, p_list, t_list, tol=1e-8):
    """
    Compute Gibbs free energy differences ΔG(P,T) using the
    Mie–Grüneisen + Birch–Murnaghan equation of state.

    Parameters
    ----------
    v0 : float
        Reference molar volume (m³/mol)
    k : float
        Bulk modulus (Pa)
    kp : float
        Pressure derivative of bulk modulus
    t_d : float
        Debye temperature (K)
    gamma0 : float
        Grüneisen parameter at reference state
    q : float
        Volume exponent for γ(V)
    n : int
        Number of atoms per formula unit
    t_ref : float
        Reference temperature (K)
    p_list : array-like
        List of target pressures (Pa)
    t_list : array-like
        List of target temperatures (K)
    tol : float
        Solver tolerance

    Returns
    -------
    ndarray
        2D array of ΔG values (J/mol), shape = [len(t_list), len(p_list)]

    Notes
    -----
    For each temperature:
        1. Compute thermal excitation Hie = E(T) - E(T_ref)
        2. Determine v_ref at 1 bar (reference)
        3. For each P, solve for v(P, T)
        4. Compute ΔG = P·V - ∫V dP, relative to the reference volume

    This neglects electronic and anharmonic terms and assumes
    quasi-harmonic behavior.
    """
    results = []

    for T in np.atleast_1d(t_list):
        # Thermal energy difference at current T
        hie = thermal_energy(t_d, T, n) - thermal_energy(t_d, t_ref, n)

        # Find reference volume corresponding to P = 1 bar
        vlow = safe_root(lambda v: total_pressure(v, v0, k, kp, gamma0, hie, q) - 1,
                         0.01, 2*v0, tol)
        row = []

        for P in np.atleast_1d(p_list):
            # Find equilibrium volume at target pressure
            vhigh = safe_root(lambda v: total_pressure(v, v0, k, kp, gamma0, hie, q) - P,
                              0.01, 2*v0, tol)

            if np.isnan(vlow) or np.isnan(vhigh):
                row.append(np.nan)
                continue

            # Compute Gibbs energy difference analytically
            int_def = integral_VdP(vhigh, v0, k, kp, gamma0, hie, q) \
                    - integral_VdP(vlow,  v0, k, kp, gamma0, hie, q)

            dg = total_pressure(vhigh, v0, k, kp, gamma0, hie, q) * vhigh \
               - total_pressure(vlow,  v0, k, kp, gamma0, hie, q) * vlow \
               - int_def

            row.append(dg)

        results.append(row)

    return np.array(results)

# %%
# ============================================================
# Fe Equation of State (Dorogokupets & Dewaele, 2017)
# ============================================================

# ============================================================
# 1. Phase Parameters for Fe
# ============================================================
# Notes:
# - bcc = α-Fe (low-P)
# - fcc = γ-Fe (intermediate-T)
# - hcp = ε-Fe (high-P)
# - Parameters include thermoelastic, vibrational, electronic, magnetic, and empirical offsets


PHASE_PARAMS = {
    'bcc': {  # α-Fe (body-centered cubic, stable at low P–T)
        'n': 1,          # number of formula units per mole (usually 1)
        'vo': 0.7092,    # reference molar volume (e.g. cm³/mol or 10⁻⁶ m³/mol)
        'ko': 1640,      # bulk modulus (kbar, if consistent with rest of code)
        'kk': 5.5,       # pressure derivative of bulk modulus (K0')
        'mmm': 2,        # ? magnetic multiplicity or structural index
        'qbo': 2.22,     # Grüneisen parameter (γ0)
        'd': 1,          # dimensional factor or degeneracy
        'qeo1': 303,     # characteristic Einstein (or Debye) temperature (K)
        'me1': 3,        # number of atoms per formula unit
        'gamvo': 1.736,  # volume Grüneisen parameter for vibrations
        'beta': 1.125,   # volume dependence exponent of γ(V)
        'gb': 0,         # additional elastic term (unused or placeholder)
        'mm': 1,         # magnetic moment coefficient
        'ae': 198,       # magnetic energy scale parameter
        'tc': 1043,      # Curie temperature (K)
        'pp': 0.4        # magnetic pressure or spin-coupling parameter
    },

    'hcp': {  # ε-Fe (hexagonal close-packed, high-P phase)
        'n': 1,
        'vo': 0.68175,
        'ko': 1480,
        'kk': 5.86,
        'mmm': 2,
        'qbo': 1e-7,     # nearly non-magnetic (tiny γ0 for mag. term)
        'd': 1,
        'qeo1': 227,
        'me1': 3,
        'gamvo': 2.2,
        'beta': 0.01,
        'gb': 0,
        'mm': -0.83,     # magnetic correction coefficient (negative)
        'ae': 126,
        'tc': 67,        # low Curie temperature (essentially non-magnetic)
        'pp': 0.28,
        'extra_g': 4500  # additional Gibbs offset (J/mol)
    },

    'fcc': {  # γ-Fe (face-centered cubic, intermediate-T phase)
        'n': 1,
        'vo': 0.69285,
        'ko': 1462,
        'kk': 4.67,
        'mmm': 2,
        'qbo': 1e-7,
        'd': 1,
        'qeo1': 222.5,
        'me1': 3,
        'gamvo': 2.203,
        'beta': 0.01,
        'gb': 0,
        'mm': 0.5,
        'ae': 198,
        'tc': 67,
        'pp': 0.28,
        'extra_g': 4470  # empirical offset (J/mol)
    }
}

# ============================================================
# 2. Vinet Equation of State and Pressure Integration
# ============================================================
def pressure_vinet(x, params):
    """Calculates the pressure from the Vinet EOS (bar) for reduced volume x = V/Vo."""
    ff = x ** (1 / 3)
    aa = 1.5 * params['kk'] + 0.5 - params['mmm']
    return 3 * params['ko'] * 1000 * np.exp(aa * (1 - ff)) * (1 - ff) / ff ** params['mmm']


def integrate_pressure(b, params):
    """Integrates pressure over reduced volume to compute mechanical work ∫V dP (J/mol)."""
    a = 1.0
    if b < 1:
        a, b = b, a
        sign = -1
    else:
        sign = 1

    s2 = 1
    h = b - a
    S = (pressure_vinet(a, params) + pressure_vinet(b, params)) * params['vo']

    while True:
        s3 = s2
        h /= 2
        s1 = 0
        x_val = a + h
        while x_val < b:
            s1 += 2 * pressure_vinet(x_val, params) * params['vo']
            x_val += 2 * h
        S += s1
        s2 = (S + s1) * h / 3
        if abs(s3 - s2) / 15 < 0.0001:
            break

    return sign * s2


def find_reduced_volume(pbar, T, params):
    """Solves for reduced volume x = V/Vo at target pressure pbar and temperature T."""
    def residual(x):
        ff = x ** (1 / 3)
        aa = 1.5 * params['kk'] + 0.5 - params['mmm']
        px = 3 * params['ko'] * 1000 * np.exp(aa * (1 - ff)) * (1 - ff) / ff ** params['mmm']

        expp = 1 / x ** params['gb'] * np.exp((params['gamvo'] - params['gb']) / params['beta'] * (1 - x ** params['beta']))
        gamv = params['gb'] + (params['gamvo'] - params['gb']) * x ** params['beta']
        qe1 = params['qeo1'] * expp

        e1 = np.exp(qe1 / T)
        pth1 = params['me1'] * R_gas * ((qe1 / (e1 - 1)) * gamv / (x * params['vo']))
        e1r = np.exp(qe1 / T_ref)
        pth1r = params['me1'] * R_gas * ((qe1 / (e1r - 1)) * gamv / (x * params['vo']))

        pe = 1.5 * params['n'] * R_gas * params['ae'] / 1e6 * x**params['mm'] * params['mm'] / x / params['vo'] * (T**2 - T_ref**2)

        tau, tau_r = T / params['tc'], T_ref / params['tc']
        def calc_ggg(tau_val, pp_val):
            if params['tc'] == 1043:
                if tau_val <= 1:
                    return 1 - (79/tau_val/140/pp_val + 474/497*(1/pp_val-1)*(tau_val**3/6 + tau_val**9/135 + tau_val**15/600)) \
                           / (518/1125 + 11692/15975*(1/pp_val-1))
                else:
                    return -(tau_val**-5/10 + tau_val**-15/315 + tau_val**-25/1500) / (518/1125 + 11692/15975*(1/pp_val - 1))
            return -(tau_val**-5/10 + tau_val**-15/315 + tau_val**-25/1500) / (518/1125 + 11692/15975*(1/pp_val - 1))

        ggg, gggr = calc_ggg(tau, params['pp']), calc_ggg(tau_r, params['pp'])
        mmb = -params['n'] * R_gas * T * params['qbo'] / (params['qbo'] * x + 1) * (ggg - 1) / params['vo']
        mmbr = -params['n'] * R_gas * T_ref * params['qbo'] / (params['qbo'] * x + 1) * (gggr - 1) / params['vo']

        return pth1 - pth1r + px + pe + mmb - mmbr - pbar

    return root_scalar(residual, bracket=[0.3, 1.3], xtol=tol).root


# ============================================================
# 3. Thermal Free Energy
# ============================================================
def thermal_free_energy(x, T, params):
    """Computes thermal contribution to Helmholtz free energy F(V,T) relative to T_ref."""
    tc, pp, bo = params['tc'], params['pp'], params['qbo']
    expp = 1 / x ** params['gb'] * np.exp((params['gamvo'] - params['gb']) / params['beta'] * (1 - x ** params['beta']))
    gamv = params['gb'] + (params['gamvo'] - params['gb']) * x ** params['beta']

    qe1 = params['qeo1'] * expp
    fe1 = params['me1'] * R_gas * (T * np.log(1 - 1 / np.exp(qe1 / T)))
    fe1r = params['me1'] * R_gas * (T_ref * np.log(1 - 1 / np.exp(qe1 / T_ref)))

    fel = -1.5 * params['n'] * R_gas * params['ae'] / 1e6 * x ** params['mm'] * (T**2 - T_ref**2)

    tau, tau_r = T / tc, T_ref / tc
    def calc_ggg(tau_val, pp_val):
        if tau_val <= 1:
            return 1 - (79/tau_val/140/pp_val + 474/497*(1/pp_val - 1)*(tau_val**3/6 + tau_val**9/135 + tau_val**15/600)) \
                   / (518/1125 + 11692/15975*(1/pp_val - 1))
        return -(tau_val**-5/10 + tau_val**-15/315 + tau_val**-25/1500) / (518/1125 + 11692/15975*(1/pp_val-1))

    ggg, gggr = calc_ggg(tau, pp), calc_ggg(tau_r, pp)
    mmb = params['n'] * R_gas * T * np.log(bo * 1 + 1) * (ggg - 1)
    mmbr = params['n'] * R_gas * T_ref * np.log(bo * 1 + 1) * (gggr - 1)

    return fe1 - fe1r + fel + mmb - mmbr


# ============================================================
# 4. Gibbs Free Energy and Phase Equilibria
# ============================================================
def gibbs_energy_phase(T, p, phase):
    """Computes G(T,P) for a specific Fe phase using EOS and thermal contributions."""
    params = PHASE_PARAMS[phase]
    x = find_reduced_volume(p, T, params)
    F_th = thermal_free_energy(x, T, params)
    VdP = integrate_pressure(x, params)
    extra_G = params.get('extra_g', 0)
    return F_th + VdP + extra_G + p * x * params['vo']


def fe_phase_transitions(T, max_p):
    """Determines Fe phase boundaries (bcc–fcc–hcp) by Gibbs free energy equality."""
    def phase_diff(phase1, phase2):
        return lambda pval: gibbs_energy_phase(T, pval, phase2) - gibbs_energy_phase(T, pval, phase1)

    phases = pd.DataFrame(columns=['phase', 'p'])
    if gibbs_energy_phase(T, 1, 'bcc') < gibbs_energy_phase(T, 1, 'fcc'):
        phases.loc[0] = ['bcc', 1]
        try:
            t_bcc_hcp = root_scalar(phase_diff('bcc', 'hcp'), bracket=[1, max_p], xtol=tol).root
        except:
            t_bcc_hcp = max_p + 1
        try:
            t_bcc_fcc = root_scalar(phase_diff('bcc', 'fcc'), bracket=[1, max_p], xtol=tol).root
        except:
            t_bcc_fcc = max_p + 1
        if t_bcc_fcc < t_bcc_hcp:
            phases.loc[len(phases)] = ['fcc', t_bcc_fcc]
        elif t_bcc_hcp <= max_p:
            phases.loc[len(phases)] = ['hcp', t_bcc_hcp]
    else:
        phases.loc[0] = ['fcc', 1]
        try:
            t_fcc_hcp = root_scalar(phase_diff('fcc', 'hcp'), bracket=[1, 1.1], xtol=tol).root
        except:
            t_fcc_hcp = np.nan
        if not np.isnan(t_fcc_hcp):
            phases.loc[len(phases)] = ['hcp', t_fcc_hcp]

    return phases.reset_index(drop=True)


# ============================================================
# 5. VdP Integration Across Phase Transitions
# ============================================================
def vdp_integral(p_array, T_array):
    """Computes ∫VdP along P–T paths, accounting for phase transitions."""
    p_array = np.atleast_1d(p_array)
    T_array = np.atleast_1d(T_array)
    result = np.array([])

    for T in T_array:
        transitions = fe_phase_transitions(T, max_p=np.max(p_array))
        for p in p_array:
            trunc_trans = transitions[transitions['p'] <= p].copy()
            VdP_total = 0
            for k in range(len(trunc_trans)):
                p_start = trunc_trans.iloc[k]['p']
                p_end = p if k == len(trunc_trans)-1 else trunc_trans.iloc[k+1]['p']
                if p_end > p_start:
                    phase = trunc_trans.iloc[k]['phase']
                    integrand = lambda x: find_reduced_volume(x, T, PHASE_PARAMS[phase])
                    int_val, _ = quad(integrand, p_start, p_end)
                    VdP_total += PHASE_PARAMS[phase]['vo'] * int_val
            result = np.append(result, VdP_total)

    return result


# %%
# ============================================================
# IW buffer function using O'Neill model with FeO (Campbell et al., 2009)
# and Fe (Dorogokupets et al., 2017)
# ============================================================
mgres = []

def IW_ONeill_HP(p_bar, t_k):
    """
    Vectorized calculation of log10(fO2) following the IW buffer.

    Parameters
    ----------
    p_bar : float
        Pressure in bar (scalar)
    t_k : np.ndarray or float
        Temperatures in K (1D array or scalar)

    Returns
    -------
    np.ndarray
        log10(fO2) values
    """
    T_array = np.atleast_1d(t_k)

    # ============================================================
    # 1. Chemical potential of O2 at 1 bar (mu1bar)
    # ============================================================
    mu1bar = np.zeros_like(T_array, dtype=float)

    # Low-temperature regime: T < 1042 K
    mask = T_array < 1042
    mu1bar[mask] = -605568 / T_array[mask] + 1366.42 - 182.7955 * np.log(T_array[mask]) + 0.10359 * T_array[mask]

    # Intermediate-temperature regime: 1042 <= T <= 1184 K
    mask = (T_array >= 1042) & (T_array <= 1184)
    mu1bar[mask] = -519113 / T_array[mask] + 59.129 + 8.9276 * np.log(T_array[mask])

    # High-temperature regime: T > 1184 K
    mask = T_array > 1184
    mu1bar[mask] = -550915 / T_array[mask] + 269.106 - 16.9484 * np.log(T_array[mask])

    # ============================================================
    # 2. Gibbs free energy of Fe (vectorized)
    # ============================================================
    dg_fe = vdp_integral(p_bar, T_array)  # Returns 1D array aligned with T_array

    # ============================================================
    # 3. Gibbs free energy of FeO (vectorized via Mie–Grüneisen–Birch–Murnaghan EOS)
    # ============================================================
    m_g_vec = np.vectorize(
        lambda t_val: compute_dG_MieBM(
            v0=12.256 / 10,
            k=146.9e4,
            kp=4,
            t_d=380,
            gamma0=1.42,
            q=1.3,
            n=2,
            t_ref=T_ref,
            p_list=np.atleast_1d(p_bar),
            t_list=np.atleast_1d(t_val),
            tol=1e-8,
        )
    )
    dg_feo = m_g_vec(T_array)  # 1D array aligned with T_array

    # ============================================================
    # 4. Calculate log10(fO2) using the IW buffer
    # ============================================================
    log10fo2 = (mu1bar + 2 * (dg_feo - dg_fe) / T_array) / (R_gas * np.log(10))

    # Return scalar if input was scalar
    return log10fo2 if isinstance(t_k, (np.ndarray, list)) else log10fo2[0]





