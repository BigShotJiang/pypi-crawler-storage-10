# %%
# ===============================
# Standard library imports
# ===============================
import os

# ===============================
# Third-party imports
# ===============================
import numpy as np
import pandas as pd
from tqdm import tqdm
import time

# ===============================
# Local / project-specific modules
# ===============================
# NOTE: The imports below are changed to be relative (using 'from . import ...')
# This ensures they correctly reference the other scripts in the same package folder.
from . import aSi as activitySi
from . import aSiO2 as activitySiO2
from . import ONeillHP as IWONeill
from . import HirschHP as IWHirsch
from . import SiSiO2HP as SiSiO2liquid
from . import SiSiO2solidHP as SiSiO2solid


# %%
# ===============================
# Run the fo2 and activity Monte Carlo simulations
# ===============================

# 
def DeltaSiSiO2_MC(
    file_path,
    metal_module=None,
    silicate_module=None,
    IW_model="ONeill",
    SiSiO2_model="liquid",
    amodelSiO2="MAGEMin",
    saturated="no",
    N_MC=25,
    MC_temperature="yes",
    MC_composition="yes",
    MC_Si_parameters="yes",
    MC_pressure="no",
    pressure_error=0.1
):
    """
    Monte Carlo simulation of Δ(Si–SiO2) and ΔIW including uncertainties
    in temperature, oxide/metal compositions, Si activity parameters, and pressure.

    Parameters
    ----------
    file_path : str
        Path to Excel file with sample data
    metal_module : module
        Module with 'run_metal_activity_models' function
    silicate_module : module
        Module with 'run_SiO2_activity_models' function
    IW_model : str
        "ONeill" or "Hirsch" model for IW calculation
    SiSiO2_model : str
        "liquid" or "solid" Si-SiO2 model for fO2 calculation
    amodelSiO2 : str
        SiO2 activity model ("MAGEMin" or "Massuyeau")
    saturated : str
        "yes" to compute saturated Δ(Si–SiO2), else compute ratio
    N_MC : int
        Number of Monte Carlo draws
    MC_temperature : str
        "yes" to sample temperature uncertainty
    MC_composition : str
        "yes" to sample composition uncertainty
    MC_Si_parameters : str
        "yes" to randomize Si interaction parameters per MC draw
    MC_pressure : str
        "yes" to sample pressure uncertainty
    pressure_error : float
        Relative 1-sigma pressure error (e.g., 0.1 for 10%)

    Returns
    -------
    pd.DataFrame
        DataFrame with MC statistics for each sample, saved to Excel
    """
    start_time = time.time()

    # --- Input validation ---
    if metal_module is None or silicate_module is None:
        raise ValueError("Provide both 'metal_module' and 'silicate_module'.")
    if IW_model not in ["ONeill", "Hirsch"]:
        raise ValueError("IW_model must be 'ONeill' or 'Hirsch'.")
    if SiSiO2_model not in ["liquid", "solid"]:
        raise ValueError("SiSiO2_model must be 'liquid' or 'solid'.")
    if saturated not in ["yes", "no"]:
        raise ValueError("saturated must be 'yes' or 'no'.")
    if amodelSiO2 not in ["MAGEMin", "Massuyeau"]:
        raise ValueError("amodelSiO2 must be 'MAGEMin' or 'Massuyeau'.")

    # --- Override number of MC draws if all MC options are "no" ---
    if MC_temperature=="no" and MC_composition=="no" and MC_Si_parameters=="no" and MC_pressure=="no":
        N_MC = 1

    # --- Load Excel and check required columns ---
    df_original = pd.read_excel(file_path)
    required_cols = {"Sample", "t_k", "t_1s", "P"}
    if not required_cols.issubset(df_original.columns):
        raise ValueError(f"Excel file must contain columns: {required_cols}")

    metal_elements = ["c", "o", "si", "s", "ti", "cr", "mn", "ni", "fe"]
    oxide_columns = ["SiO2","Al2O3","CaO","MgO","FeO","K2O","Na2O","TiO2","Cr2O3","H2O","S"]

    results = []  # list to store results per sample

    # --- Loop over each sample ---
    for idx, row in tqdm(df_original.iterrows(), total=len(df_original), desc="Samples"):
        sample = row["Sample"]
        t_mean = row["t_k"]
        t_sigma = row["t_1s"]
        p_bar = row.get("P", 1e5)

        # --- Lists to store MC draws ---
        ΔIW_list = []
        aSi_list, aSiO2_list = [], []
        eSi2_list, lnY0_2_list = [], []

        for iMC in range(N_MC):
            try:
                # --- Temperature draw ---
                t_k_MC = np.random.normal(t_mean, t_sigma) if MC_temperature=="yes" else t_mean
                if t_k_MC <= 0: continue  # skip nonphysical temperatures
                # --- Pressure draw ---
                if MC_pressure=="yes":
                    p_bar_MC = np.random.normal(loc=p_bar, scale=pressure_error*p_bar)
                    if p_bar_MC <= 0: p_bar_MC = p_bar
                else:
                    p_bar_MC = p_bar

                # --- Composition draw ---
                if MC_composition=="yes":
                    # Oxides
                    oxide_MC = {ox: max(0, np.random.normal(row.get(ox,0), row.get(f"{ox}_1s",0))) for ox in oxide_columns}
                    total_ox = sum(oxide_MC.values())
                    if total_ox <= 0: continue
                    oxide_MC = {ox: 100*val/total_ox for ox,val in oxide_MC.items()}
                    
                    # Metals
                    metal_MC = {el: max(0, np.random.normal(row.get(el,0), row.get(f"{el}_1s",0))) for el in metal_elements}
                    total_metal = sum(metal_MC.values())
                    if total_metal <= 0: continue
                    metal_MC = {el: 100*val/total_metal for el,val in metal_MC.items()}
                else:
                    oxide_MC = {ox: row.get(ox,0) for ox in oxide_columns}
                    metal_MC = {el: row.get(el,0) for el in metal_elements}
      
                # --- Prepare DataFrames ---
                df_metal_in = pd.DataFrame([{"Sample": sample, "t_k": t_k_MC, "P": p_bar_MC, **metal_MC}])
                df_oxide_in = pd.DataFrame([{"Sample": sample, "t_k": t_k_MC, "P": p_bar_MC, **oxide_MC}])

                # --- Run metal activity model ---
                aMetal = metal_module.run_metal_activity_models(df_metal_in, MC_Si_parameters=MC_Si_parameters)
                aSi_list.append(aMetal["aSi"].iloc[0])
                eSi2_list.append(aMetal["eSi2"].iloc[0])
                lnY0_2_list.append(aMetal["lnY0_2"].iloc[0])

                # --- Run silicate activity model ---
                aSiO2 = silicate_module.run_SiO2_activity_models(df_oxide_in)
                aSiO2_val = aSiO2["a(SiO2)_MAGEMin"].iloc[0] if amodelSiO2=="MAGEMin" else aSiO2["a(SiO2)_Massuyeau"].iloc[0]
                aSiO2_list.append(aSiO2_val)

                # --- Compute Δ(Si–SiO2) ---
                delta_SiSiO2 = np.log10(1/aMetal["aSi"].iloc[0]) if saturated=="yes" else np.log10(aSiO2_val / aMetal["aSi"].iloc[0])

                # --- Compute ΔIW ---
                fo2IW = IWONeill.IW_ONeill_HP(p_bar=p_bar_MC, t_k=t_k_MC) if IW_model=="ONeill" else IWHirsch.IW_Hirsch_HP(p_bar=p_bar_MC, t_k=t_k_MC)
                fo2SiSiO2 = SiSiO2liquid.fO2_SiSiO2(p_bar=p_bar_MC, t_k=t_k_MC) if SiSiO2_model=="liquid" else SiSiO2solid.fO2_SiSiO2solidHP(p_bar=p_bar_MC, t_k=t_k_MC)
                ΔIW_list.append(fo2SiSiO2 + delta_SiSiO2 - fo2IW)

            except Exception as e:
                print(f"⚠️ {sample}: MC draw failed — {e}")
                continue

        # --- Store MC statistics ---
        results.append({
            "Sample": sample,
            "t_k_mean": t_mean,
            "T_1s": t_sigma,
            "P": p_bar,
            "ΔIW_mean": np.mean(ΔIW_list),
            "ΔIW_std": np.std(ΔIW_list),
            "aSi_mean": np.mean(aSi_list),
            "aSi_std": np.std(aSi_list),
            "aSiO2_mean": np.mean(aSiO2_list),
            "aSiO2_std": np.std(aSiO2_list),
            "eSi_Si_mean": np.mean(eSi2_list),
            "eSi_Si_std": np.std(eSi2_list),
            "lnY0Si_mean": np.mean(lnY0_2_list),
            "lnY0Si_std": np.std(lnY0_2_list),
            "N_success": len(ΔIW_list),
            "N_MC": N_MC,
            "IW_model": IW_model,
            "SiSiO2_model": SiSiO2_model,
            "SiO2_activity_model": amodelSiO2,
            "MC_temperature": MC_temperature,
            "MC_composition": MC_composition,
            "MC_Si_parameters": MC_Si_parameters,
            "MC_pressure": MC_pressure,
            "pressure_error": pressure_error
        })

    # --- Save results ---
    df_results = pd.DataFrame(results)
    output_path = file_path.replace(".xlsx", "_MC.xlsx")
    df_results.to_excel(output_path, index=False)

    print(f"\n✅ Monte Carlo finished in {time.time() - start_time:.1f} s. Results saved to {output_path}")
    return df_results
