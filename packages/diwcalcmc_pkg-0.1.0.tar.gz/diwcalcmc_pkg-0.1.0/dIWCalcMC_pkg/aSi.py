# %%
# === Core scientific computing ===
import math
import os
import numpy as np
import pandas as pd
import scipy.integrate as integrate
import scipy.optimize as opt
import scipy.special as special
from scipy import stats


# === Plotting ===
import matplotlib.pyplot as plt

# %%
# =============================================================================
# UNIVERSAL CONSTANTS
# =============================================================================

R = 8.314  # J/(mol·K), universal gas constant
# =============================================================================
# METAL ELEMENTS AND THEIR PROPERTIES
# =============================================================================

# List of metal elements in the melt (lowercase for consistency with DataFrame)
metal_elements = ["c", "o", "si", "s", "ti", "cr", "mn", "ni", "fe"]

# Molecular weights of elements [g/mol], same order as metal_elements
molweightmetal = np.array([
    12.01,   # C
    16.00,   # O
    28.09,   # Si
    32.07,   # S
    47.87,   # Ti
    52.00,   # Cr
    54.94,   # Mn
    58.69,   # Ni
    55.85    # Fe
])

# Reference temperature for scaling interaction parameters [K]
tref_metal = 1873


# %%
# =============================================================================
# HELPER FUNCTION FOR 2ND/4TH AND 3RD TERMS
# =============================================================================
def term_activity(e_array, index, Metal_Mol, formula=2):
    """
    Calculate contributions to activity coefficients for 2nd/4th or 3rd terms
    in the excess Gibbs free energy model for a metallic melt.

    Parameters
    ----------
    e_array : np.array
        Array of interaction parameters for one element with others.
    index : int
        Index of the current element in Metal_Mol.
    Metal_Mol : np.array
        Mole fractions of all metal elements in the melt.
    formula : int, optional
        Selects which formula to use:
        2 -> 2nd/4th term
        3 -> 3rd term
        Default is 2.

    Returns
    -------
    float
        Sum of ln(activity) contributions for this element.
    """

    lnY_save = []  # List to store contributions for each interaction partner

    # Loop over interaction partners in e_array
    for i in range(len(e_array)):
        x_i = Metal_Mol[index]       # Mole fraction of current element
        x_j = Metal_Mol[index + i + 1]  # Mole fraction of interacting element

        if x_i == 0 or x_j == 0:
            # If either mole fraction is zero, contribution is zero
            lnY_save.append(0)
        else:
            if formula == 2:  # 2nd/4th term contribution
                val = 0.5*e_array[i]*x_i**2*x_j**2 * ((1/(1-x_j)) + (1/(1-x_i)) - 1) - \
                      e_array[i]*x_i*x_j*(1 + np.log(1-x_i)/x_i + np.log(1-x_j)/x_j)
            elif formula == 3:  # 3rd term contribution
                val = e_array[i]*x_i*x_j*(1 + np.log(1-x_j)/x_j - 1/(1-x_i)) + \
                      e_array[i]*x_i**2*x_j**2*((1/(1-x_i)) + (1/(1-x_j)) + (x_i/(2*(1-x_i)**2)) - 1)
            lnY_save.append(val)

    return sum(lnY_save)  # Return total contribution from this element

    # %%
# =============================================================================
# CALCULATION OF YFE AND YSI
# =============================================================================

def calc_metal_activities(Metal_Mol, e_dict, lnY0):
    """
    Calculate activity coefficients for Fe and Si in a metallic melt using
    an interaction parameter model (excess Gibbs energy approach).

    Parameters
    ----------
    Metal_Mol : np.array
        Mole fractions of all metal elements in the melt.
    e_dict : dict
        Dictionary of interaction parameters for each element (arrays).
    lnY0 : np.array
        Reference activity coefficients at the reference temperature.

    Returns
    -------
    Y_Fe : float
        Activity of Fe in the melt.
    Y_Si : float
        Activity of Si in the melt.
    """

    elements = list(e_dict.keys())  # List of element symbols

    # --- 1st term: self-interaction contribution ---
    # Sum over elements, contribution = e_i * (x_i + ln(1-x_i))
    e_1stTerm = np.array([e_dict[el][i] for i, el in enumerate(elements[:-1])])
    lnY_1stTerm = sum([e_1stTerm[i]*(Metal_Mol[i] + np.log(1-Metal_Mol[i])) 
                       for i in range(len(e_1stTerm))])

    # --- Define slices for MATLAB-style interactions in 2nd/3rd/4th terms ---
    # Each slice selects the appropriate interactions for a given element
    slice_dict = {
        "C":  slice(1, 8),
        "O":  slice(2, 8),
        "Si": slice(3, 8),
        "S":  slice(4, 8),
        "Ti": slice(5, 8),
        "Cr": slice(6, 8),
        "Mn": slice(7, 8),
        "Ni": slice(7, 8)  # Last element
    }

    # --- 2nd/4th term contributions ---
    # Sum contributions from term_activity helper function for each element
    lnY_2_4 = sum([term_activity(e_dict[el][slice_dict[el]], i, Metal_Mol, formula=2)
                    for i, el in enumerate(elements[:-1])])

    # --- 3rd term contributions ---
    lnY_3_5 = sum([term_activity(e_dict[el][slice_dict[el]], i, Metal_Mol, formula=3)
                    for i, el in enumerate(elements[:-1])])

    # --- total Fe activity ---
    Y_Fe = np.exp(lnY_1stTerm + lnY_2_4 + lnY_3_5)

    # --- Si activity (example calculation) ---
    # lnYSi uses 3rd term contributions as placeholder; full detailed formula may vary
    lnYSi = lnY_3_5
    Y_Si = np.exp(np.log(Y_Fe) + lnY0[2] - e_dict["Si"][2]*np.log(1-Metal_Mol[2]) + lnYSi)

    return Y_Fe, Y_Si


# %%
# =============================================================================
# RUN METAL ACTIVITY MODELS
# =============================================================================
# This function reads metal composition data from an Excel file, calculates 
# mole fractions and activities of Fe and Si in the metallic melt using 
# interaction parameters and excess Gibbs energy models, and saves the 
# updated results to a new Excel file.
# =============================================================================

def run_metal_activity_models(data, MC_Si_parameters="no", output_dir=None):
    """
    Compute metal activities with optional Monte Carlo Si parameter variation.

    Parameters
    ----------
    data : pd.DataFrame
        Must include metal wt% columns and 't_k' for temperature
    MC_Si_parameters : str
        "yes" to randomize e_dict["Si"][2] and lnY0[2] for each draw
    output_dir : str, optional
        Folder to save results

    Returns
    -------
    pd.DataFrame
        Original data plus columns: YFe, YSi, aFe, aSi, eSi2, lnY0_2
    """

    # --- Define metal elements and their molar weights ---
    metal_elements = ["c","o","si","s","ti","cr","mn","ni","fe"]
    molweightmetal = np.array([12.01,16.00,28.09,32.07,47.87,52.00,54.94,58.69,55.85])
    tref_metal = 1873  # reference temperature (K)

    # --- Default interaction parameters for each element ---
    default_e_dict = {
        "C":  np.array([12.8056, -20.3721, 9.7509, 6.0967, 0, -4.8565, -1.8382, 2.3298]),
        "O":  np.array([-20.04, -10.49, -7.14, -17.14, -220.66, -11.71, -4.74, 1.40]),
        "Si": np.array([9.6891, -7.1277, 12.4114, 8.9245, 242.6279, -0.0113, -3.2186, 1.1576]),
        "S":  np.array([6.14, -17.08, 8.95, -5.65, -35.34, -2.09, -5.68, -0.02]),
        "Ti": np.array([0, -223.32, 243.41, -35.23, 8.42, 0, -9.71, 0]),
        "Cr": np.array([-4.85, -9.83, 0.02, -2.10, 0, 0, 0.90, 0]),
        "Mn": np.array([-1.88, -4.76, -3.29, -5.73, -9.71, 0.91, 0.02, -1.75]),
        "Ni": np.array([2.33, 1.37, 1.19, -0.02, 0, 0, -1.75, 0.12])
    }

    # --- Default reference activity coefficients ---
    default_lnY0 = np.array([-0.62,0,-6.65,0,-5.52,0,0.36,-0.42])

    # --- Lists to store results for each row/sample ---
    Y_Fe_list, Y_Si_list = [], []
    aFe_list, aSi_list = [], []
    eSi2_list, lnY0_2_list = [], []

    # --- Loop over each row/sample in the input DataFrame ---
    for idx, row in data.iterrows():
        T = row["t_k"]  # temperature for the sample

        # --- Convert weight % to mole fractions ---
        wt = row[metal_elements].to_numpy(dtype=float)  # extract metal wt%
        wt[np.isnan(wt)] = 0  # replace NaNs with 0
        total_wt = np.sum(wt)
        if total_wt <= 0:
            # If all weights are zero or missing, append NaNs and skip
            Y_Fe_list.append(np.nan)
            Y_Si_list.append(np.nan)
            aFe_list.append(np.nan)
            aSi_list.append(np.nan)
            eSi2_list.append(np.nan)
            lnY0_2_list.append(np.nan)
            continue

        wt = wt / total_wt * 100  # normalize to 100 wt%
        moles = wt / molweightmetal  # convert wt% to moles
        Metal_Mol = moles / np.sum(moles)  # convert to mole fractions
        Femolfrac = Metal_Mol[metal_elements.index("fe")]  # Fe mole fraction
        Simolfrac = Metal_Mol[metal_elements.index("si")]  # Si mole fraction

        # --- Copy default interaction parameters ---
        e_dict = {k:v.copy() for k,v in default_e_dict.items()}
        lnY0 = default_lnY0.copy()
        e_scaled = {k: tref_metal * v / T for k, v in e_dict.items()}
        lnY0_scaled = tref_metal * lnY0 / T

        # --- Randomize Si parameters if requested (MC simulation) ---
        if MC_Si_parameters.lower() == "yes":
            e_dict["Si"][2] = np.random.normal(loc=12.41, scale=1.5)
            lnY0[2] = np.random.normal(loc=-6.65, scale=0.5)
            e_scaled = {k: tref_metal * v / T for k, v in e_dict.items()}
            lnY0_scaled = tref_metal * lnY0 / T

        # --- Compute Fe and Si activities using the interaction model ---
        Y_Fe, Y_Si = calc_metal_activities(Metal_Mol, e_scaled, lnY0_scaled)

        # --- Store results ---
        Y_Fe_list.append(Y_Fe)
        Y_Si_list.append(Y_Si)
        aFe_list.append(Femolfrac*Y_Fe)  # effective activity for Fe
        aSi_list.append(Simolfrac*Y_Si)  # effective activity for Si
        eSi2_list.append(e_dict["Si"][2])  # store actual Si interaction parameter used
        lnY0_2_list.append(lnY0[2])        # store actual lnY0 used

    # --- Add all results as new columns in the original DataFrame ---
    df = data.copy()
    df["YFe"] = Y_Fe_list
    df["YSi"] = Y_Si_list
    df["aFe"] = aFe_list
    df["aSi"] = aSi_list
    df["eSi2"] = eSi2_list
    df["lnY0_2"] = lnY0_2_list

    # --- Save to Excel if output directory is provided ---
    if output_dir:
        output_file = os.path.join(output_dir,"Compo_metal_results.xlsx")
        df.to_excel(output_file,index=False)

    return df

# %%



