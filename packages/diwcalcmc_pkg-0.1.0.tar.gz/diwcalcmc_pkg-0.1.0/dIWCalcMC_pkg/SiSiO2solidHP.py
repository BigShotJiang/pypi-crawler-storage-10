# %%
# ----------------------------------------------------------------------
# Standard Library Imports
# ----------------------------------------------------------------------
import math
import time
from datetime import timedelta

# ----------------------------------------------------------------------
# Third-Party Imports
# ----------------------------------------------------------------------
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# ----------------------------------------------------------------------
# Specific Imports from Third-Party Packages 
# ----------------------------------------------------------------------
from numpy import inf
from scipy import stats
import scipy.integrate as integrate
from scipy.integrate import quad
import scipy.optimize as opt
import scipy.special as special
from scipy.optimize import fsolve, brentq
from functools import lru_cache
from scipy.integrate import trapezoid

# %%
# =============================================================================
# Define some constants
# =============================================================================

# The ideal gas constant, or molar gas constant (J/(mol·K))
R_gas = 8.3144 

# Avogadro's constant (number of particles per mole) (mol⁻¹)
na = 6.02214*10**23 

# Reference pressure, set to 1 bar
pref = 1.0 

# Reference temperature, set to 298.15 K (25 °C)
tref = 298.15  

# %%
# =============================================================================
# Thermodynamic properties of silicon polymorphs thermochemistry data
# =============================================================================

silicon_thermo_data = {
    "Si_V": {
        "H": 32177.23239,      # ΔH_298K in J/mol
        "S": 31.0,             # S_298K in J/mol/K
        "a": 22.8317533,
        "b": 0.003825808,
        "c": -353334,
        "d": 2.1312e-08,
        "e": 0,
        "f": 0,
        "g": 0,
        "tref": 298.15
    },
    "Si_VII": {
        "H": 49199.99915,
        "S": 39.6100312,
        "a": 22.8317533,
        "b": 0.003825808,
        "c": -353334,
        "d": 2.1312e-08,
        "e": 0,
        "f": 0,
        "g": 0,
        "tref": 298.15
    }
}

# =============================================================================
# Thermodynamic properties of silicon polymorphs thermophysical data
# =============================================================================
# Each silicon phase has its own Vinet EOS and thermal parameters.
# Units: V0 [Å³/mol-atom], K0 [GPa], alpha0 [1/K], gamma0 [dimensionless].
Si_phases = {
    "SiI": {
        "V0": 12.0566, "K0": 101.5, "Kp": 3.11,
        "alpha0": 0.876e-5, "gamma0": 3.11, "kappa": 1.4,
        "T_ref": 298.15
    },
    "SiV": {
        "V0": 9.7, "K0": 95, "Kp": 4.6,
        "alpha0": 7e-5, "gamma0": 5.92, "kappa": 1.4,
        "T_ref": 298.15
    },
    "SiVII": {
        "V0": 9.3, "K0": 96.9, "Kp": 4.01,
        "alpha0": 7e-5, "gamma0": 5.92, "kappa": 1.4,
        "tref": 298.15
    }
}

# Thermodynamic properties of Si-I (Bajenovaa et al., 2023)

# Einstein Temperatures (K)
THETA_E_PRIME = 615.45
THETA_E_DOUBLE_PRIME = 206.96

# Einstein Coefficients (dimensionless)
ALPHA_PRIME = 0.67401
ALPHA_DOUBLE_PRIME = 0.32599

# Polynomial Coefficients
C2 = 6.7793e-4
C5 = 7.5778e-13

# The parameters EET1 and EET2 are typically boundary conditions
# (0 < T < EET K) and are noted for context, but not used in the G equation itself.
EET1 = 3535  # K
EET2 = 3538  # K

# -----------------------------
# Species JANAF
# -----------------------------
# Each dictionary below defines the NASA polynomial coefficients for a gas species.
# Coefficients A–H are determined by fitting experimental or calculated thermochemical data.

# ---- Molecular oxygen gas (O2) < 2000 K ----
O2lt = {
    "A": 30.03235,
    "B": 8.772972,
    "C": -3.988133,
    "D": 0.788313,
    "E": -0.741599,
    "F": -11.32468,
    "G": 236.1663,
    "H": 0.0
}

# ---- Molecular oxygen gas (O2) > 2000 K ----
O2ht = {
    "A": 29.91111,
    "B": 10.72071,
    "C":-2.020498,
    "D": 0.146449,
    "E": 9.245722,
    "F": 5.337651,
    "G": 237.6185,
    "H": 0.0
}

# ---- Si solid ----
Sisolid = {
    "A": 22.81719,
    "B": 3.899510,
    "C": -0.082885,
    "D": 0.042111,
    "E": -0.354063,
    "F": -8.163946,
    "G": 43.27846,
    "H": 0.0
}

# ---------------------------------------------------------------
# Thermodynamic properties of SiO2 polymorphs from Holland (2011)
# ---------------------------------------------------------------

SiO2Holland = {
    "Tridymite": {
        "H":-907080,
        "S": 44.10,
        "a": 0.0749e3,
        "b": 0.3100e-5*1e3,
        "c": -1174.0e3,
        "d": -0.2367e3
    },
    "Cristobalite": {
        "H": -904240,
        "S": 50.86,
        "a": 0.0727e3,
        "b": 0.1304e-5*1e3,
        "c": -4129e3,
        "d": 0e3
    },
}


# =============================================================================
# Thermophysical data Holland for SiO2 polymorphs
# =============================================================================
# Original values: [DeltaH_298K (J/mol), S_298K (J/mol·K)]
# Dividing by 1000 scales H to kJ/mol and S to kJ/mol·K.
ThermocristoHol_P = np.array([-904240.0, 50.86]) / 1000
ThermoquartzHol_P = np.array([-910700.0, 41.46]) / 1000
ThermocoesiteHol_P = np.array([-906400.0, 40.60]) / 1000
ThermostishoviteHol_P = np.array([-874000.0, 24.60]) / 1000

SIO2_PHASES = {
    "Cristobalite": {
        "H_298": ThermocristoHol_P[0], # kJ/mol
        "S_298": ThermocristoHol_P[1], # kJ/mol·K
        "Cp_coeffs": {'a': 0.0727, 'b': 1.304e-6, 'c': -4129, 'd': 0},
        "EoS_params": {'s': 50.86, 'v0': 2.745, 'n': 3, 'a0': 0.0, 'K': 160, 'dKdP': 4.35, 'dKdP2': -0.0272},
        "Landau_params":  None,
    },
    "Quartz": {
        "H_298": ThermoquartzHol_P[0], # kJ/mol
        "S_298": ThermoquartzHol_P[1], # kJ/mol·K
        "Cp_coeffs": {'a': 0.0929, 'b': -6.42e-7, 'c': -714.9, 'd': -0.7161},
        "EoS_params": {'s': 41.43, 'v0': 2.269, 'n': 3, 'a0': 0.0, 'K': 730, 'dKdP': 6.0, 'dKdP2': -0.0082},
        "Landau_params": {'smax': 0.00495, 'vmax': 0.1188, 'tc0': 847},
    },
    "Coesite": {
        "H_298": ThermocoesiteHol_P[0],
        "S_298": ThermocoesiteHol_P[1],
        "Cp_coeffs": {'a': 0.1078, 'b': -3.279e-6, 'c': -190.3, 'd': -1.0416},
        "EoS_params": {'s': 39.6, 'v0': 2.064, 'n': 3, 'a0': 1.23e-5, 'K': 979, 'dKdP': 4.19, 'dKdP2': -0.0043},
        "Landau_params": None,
    },
    "Stishovite": {
        "H_298": ThermostishoviteHol_P[0],
        "S_298": ThermostishoviteHol_P[1],
        "Cp_coeffs": {'a': 0.0681, 'b': 6.010e-6, 'c': -1978.2, 'd': -0.0821},
        "EoS_params": {'s': 24.0, 'v0': 1.401, 'n': 3, 'a0': 1.58e-5, 'K': 3090, 'dKdP': 4.6, 'dKdP2': -0.00150},
        "Landau_params": None,
    }
}


# ---------------------------------------------------------------
# Thermodynamic properties of SiO2 polymorphs from Mao
# ---------------------------------------------------------------
SiO2Mao = {
    "Quartz_alpha": {
        "H": -910700,
        "S": 41.46,
        "a": 81.1447,
        "b": 18.28e-3,
        "c": -18.09E4,
        "d": 540.58e-8,
        "e": 0,
        "f": -6.9846E2,
        "g": 0
    },
    "Quartz_beta": {
        "H": -910497,
        "S": 41.70,
        "a": 78.8120,
        "b": 1.205e-3,
        "c": 173.1E4,
        "d": 0,
        "e": 1.202E8,
        "f": 0,
        "g": -1.213E4
    },
    "Tridymite": {
        "H": -906913,
        "S": 45.116,
        "a": 66.6993,
        "b": 5.2779e-3,
        "c": -213.23389E4,
        "d": -35.4783e-8,
        "e": 0,
        "f": 0,
        "g": 0
    },
    "Cristobalite": {
        "H": -906034,
        "S": 46.060,
        "a": 74.9325,
        "b": -1.6202e-3,
        "c": -440.5322E4,
        "d": 99.4385e-8,
        "e": 0,
        "f": 0,
        "g": 0
    },
    "Coesite": {
        "H": -906400,
        "S": 40.600,
        "a": 78.9,
        "b": 0,
        "c": -506.5000E4,
        "d": 0,
        "e": 8.250e8,
        "f": -1.6350E2,
        "g": 0
    },
    "Stishovite": {
        "H": -874000,
        "S": 24.600,
        "a": 85.780,
        "b": 0,
        "c": -360.5000E4,
        "d": 0,
        "e": 4.511e8,
        "f": -3.4550E2,
        "g": 0
    }
}

# %%
# =============================================================================
# Function for Gibbs free energy calculations
# =============================================================================

# =============================================================================
# Function: Integral of Cp (Used for Enthalpy Change, ΔH) with Calphad Model
# =============================================================================

def integral_Cp_Calphad(a, b, c, d, e, f, g, tref, t):
    """
    Calculates the definite integral of Cp from tref to t, used for ΔH.
    Integral is: ∫ (a + bT + cT⁻² + dT² + eT⁻³ + fT⁻⁰·⁵ + gT⁶) dT
    
    Returns:
        float: ΔH = H(t) - H(tref)
    """
    
    # Indefinite integral evaluated at T (upper bound)
    H_t = (a*t + 0.5*b*(t**2) - c*(t**-1) + (1/3)*d*(t**3) - 0.5*e*(t**-2) + 2*f*(t**0.5) + (1/7)*g*(t**7))
    
    # Indefinite integral evaluated at tref (lower bound)
    H_tref = (a*tref + 0.5*b*(tref**2) - c*(tref**-1) + (1/3)*d*(tref**3) - 0.5*e*(tref**-2) + 2*f*(tref**0.5) + (1/7)*g*(tref**7))
    
    return H_t - H_tref

# =============================================================================
# Function: Integral of Cp/T (Used for Entropy Change, ΔS) with Calphad Model
# =============================================================================

def integral_CpT_Calphad(a, b, c, d, e, f, g, tref, t):
    """
    Calculates the definite integral of Cp/T from tref to t, used for ΔS.
    Integral is: ∫ (a/T + b + cT⁻³ + dT + eT⁻⁴ + fT⁻¹·⁵ + gT⁵) dT
    
    Returns:
        float: ΔS = S(t) - S(tref)
    """
    
    # Indefinite integral evaluated at T (upper bound)
    S_t = (a*np.log(t) + b*t - 0.5*c*(t**-2) + 0.5*d*(t**2) - (1/3)*e*(t**-3) - 2*f*(t**-0.5) + (1/6)*g*(t**6))
    
    # Indefinite integral evaluated at tref (lower bound)
    S_tref = (a*np.log(tref) + b*tref - 0.5*c*(tref**-2) + 0.5*d*(tref**2) - (1/3)*e*(tref**-3) - 2*f*(tref**-0.5) + (1/6)*g*(tref**6))
    
    return S_t - S_tref

# =============================================================================
# Functions: Heat Capacity (Cp) Integrals using Holland et al. model
# =============================================================================
# Cp(T) is expressed as:
#     Cp(T) = a + b*T + c*T**-2 + d*T**0.5
# Integral forms:
#   ∫Cp dT      -> for enthalpy change (ΔH)
#   ∫Cp/T dT    -> for entropy change (ΔS)
# Reference temperature tref is used for definite integration.

import numpy as np

def integral_Cp_Holland(a, b, c, d, tref, T):
    """
    Compute the definite integral of Cp from tref to T (enthalpy change ΔH)
    using Holland et al. heat capacity model.

    Cp(T) = a + b*T + c*T**-2 + d*T**0.5

    Parameters
    ----------
    a, b, c, d : float
        Heat capacity coefficients.
    tref : float
        Reference temperature (K).
    T : float
        Target temperature (K).

    Returns
    -------
    float
        ΔH = H(T) - H(tref) in same units as coefficients.
    """
    # Indefinite integral of Cp(T) evaluated at T
    H_T = a*T + 0.5*b*T**2 - c*(T**-1) + 2*d*T**0.5
    # Indefinite integral of Cp(T) evaluated at tref
    H_tref = a*tref + 0.5*b*tref**2 - c*(tref**-1) + 2*d*tref**0.5
    return H_T - H_tref


def integral_CpT_Holland(a, b, c, d, tref, T):
    """
    Compute the definite integral of Cp/T from tref to T (entropy change ΔS)
    using Holland et al. heat capacity model.

    Cp(T)/T = a/T + b + c*T**-3 + d*T**-1.5

    Parameters
    ----------
    a, b, c, d : float
        Heat capacity coefficients.
    tref : float
        Reference temperature (K).
    T : float
        Target temperature (K).

    Returns
    -------
    float
        ΔS = S(T) - S(tref) in same units as coefficients.
    """
    # Indefinite integral of Cp/T evaluated at T
    S_T = a*np.log(T) + b*T - 0.5*c*T**-2 - 2*d*T**-0.5
    # Indefinite integral of Cp/T evaluated at tref
    S_tref = a*np.log(tref) + b*tref - 0.5*c*tref**-2 - 2*d*tref**-0.5
    return S_T - S_tref

# =============================================================================
# Cp and Cp/T integrals using Mao et al. heat capacity model
# Cp(T) = a + b*T + c*T**-2 + d*T**3 + e*T**-3 + f*T**0.5 + g*T**-1
# =============================================================================

def integral_Cp_Mao(a, b, c, d, e, f, g, tref, T):
    """
    Compute the definite integral of Cp(T) from tref to T (enthalpy change ΔH)
    using Mao et al. heat capacity model.

    Cp(T) = a + b*T + c*T**-2 + d*T**3 + e*T**-3 + f*T**0.5 + g*T**-1

    Parameters
    ----------
    a, b, c, d, e, f, g : float
        Heat capacity coefficients
    tref : float
        Reference temperature (K)
    T : float
        Target temperature (K)

    Returns
    -------
    float
        ΔH = H(T) - H(tref)
    """
    # Evaluate indefinite integral at T
    H_T = (a*T + 0.5*b*T**2 - c*T**-1 + (1/3)*d*T**3 - 0.5*e*T**-2
           + 2*f*T**0.5 + g*np.log(T))
    
    # Evaluate indefinite integral at tref
    H_tref = (a*tref + 0.5*b*tref**2 - c*tref**-1 + (1/3)*d*tref**3 - 0.5*e*tref**-2
              + 2*f*tref**0.5 + g*np.log(tref))
    
    return H_T - H_tref


def integral_CpT_Mao(a, b, c, d, e, f, g, tref, T):
    """
    Compute the definite integral of Cp(T)/T from tref to T (entropy change ΔS)
    using Mao et al. heat capacity model.

    Cp(T)/T = a/T + b + c*T**-3 + d*T**2 + e*T**-3 + f*T**-0.5 + g*T**-1

    Parameters
    ----------
    a, b, c, d, e, f, g : float
        Heat capacity coefficients
    tref : float
        Reference temperature (K)
    T : float
        Target temperature (K)

    Returns
    -------
    float
        ΔS = S(T) - S(tref)
    """
    # Evaluate indefinite integral at T
    S_T = (a*np.log(T) + b*T - 0.5*c*T**-2 + 0.5*d*T**2 - (1/3)*e*T**-3
           - 2*f*T**-0.5 - g*T**-1)
    
    # Evaluate indefinite integral at tref
    S_tref = (a*np.log(tref) + b*tref - 0.5*c*tref**-2 + 0.5*d*tref**2 - (1/3)*e*tref**-3
              - 2*f*tref**-0.5 - g*tref**-1)
    
    return S_T - S_tref


# -----------------------------
# NASA polynomial functions - Enthalpy
# -----------------------------
def H_minus_H298(T, A, B, C, D, E, F, H):
    """
    Compute enthalpy difference [H(T) - H(298 K)] for a given species
    using the NASA 7-coefficient polynomial.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    A–H : float
        NASA polynomial coefficients specific to each species.

    Returns
    -------
    float
        Enthalpy difference in J/mol.

    Notes
    -----
    The NASA polynomial defines Cp/R as:
        Cp/R = A + B*t + C*t² + D*t³ + E*t⁻²
    where t = T / 1000.

    Integrating Cp(T) from 298 to T gives:
        (H(T) - H(298)) = 1000 × [A*t + ½B*t² + (1/3)C*t³ + (1/4)D*t⁴ - E/t + F]

    The result is multiplied by 1000 to ensure the final units are J/mol.
    """
    t = T / 1e3  # Dimensionless temperature variable (T scaled by 1000)
    return 1e3 * (A*t + 0.5*B*t**2 + (1/3)*C*t**3 + (1/4)*D*t**4 - E/t + F)

# ------------------------------------
# NASA polynomial functions - Entropy
# ------------------------------------

def S_absolute(T, A, B, C, D, E, G):
    """
    Compute absolute entropy S°(T) using NASA 7-coefficient polynomial.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    A–G : float
        NASA polynomial coefficients specific to each species.

    Returns
    -------
    float
        Absolute entropy (J/mol/K).

    Notes
    -----
    The integrated form of Cp/T yields the absolute entropy:
        S°/R = A*ln(t) + B*t + ½C*t² + (1/3)D*t³ - ½E/t² + G
    where t = T / 1000.

    Here, the function returns S°(T) in J/mol/K (R = 1 conventionally omitted).
    """
    t = T / 1e3  # Dimensionless temperature
    return A*np.log(t) + B*t + 0.5*C*t**2 + (1/3)*D*t**3 - 0.5*E/t**2 + G

# ----------------------------------------
# Gibbs free energy calculation for oxygen
# ----------------------------------------

def GibbsNIST(T, species):
    """
    Compute Gibbs free energy G(T) = H(T) - T*S(T)
    for a given chemical species.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    species : str
        Name of the chemical species (key string).
        Must match one of the defined species dictionaries.

    Returns
    -------
    float
        Gibbs free energy in J/mol.
    """

        # Compute enthalpy relative to 298 K
    H = H_minus_H298(
        T, species["A"], species["B"], species["C"], species["D"],
        species["E"], species["F"], species["H"]
    )

    # Compute absolute entropy
    S = S_absolute(
        T, species["A"], species["B"], species["C"], species["D"],
        species["E"], species["G"]
    )

    # Gibbs free energy relation
    return H - T * S

# ----------------------------------------
# Gibbs free energy calculation for silicon
# ----------------------------------------

def GibbsSicalphad(T, species):
    """
    Compute Gibbs free energy G(T) = H(T) - T*S(T)
    for a given silicon polymorph using CALPHAD Cp integration.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    species : str
        Name of the silicon polymorph ("Si_V_solid" or "Si_VII_solid").

    Returns
    -------
    float
        Gibbs free energy in J/mol.
    """

    if species not in silicon_thermo_data:
        raise ValueError(f"Unknown silicon species: {species}")

    # Extract all thermodynamic properties and CALPHAD coefficients
    props = silicon_thermo_data[species]

    # Compute enthalpy and entropy using integrals
    H = props["H"] + integral_Cp_Calphad(
        props["a"], props["b"], props["c"], props["d"],
        props["e"], props["f"], props["g"], props["tref"], T
    )
    S = props["S"] + integral_CpT_Calphad(
        props["a"], props["b"], props["c"], props["d"],
        props["e"], props["f"], props["g"], props["tref"], T
    )

    # Gibbs free energy
    return H - T * S

# =============================================================================
# Gibbs Free Energy Function G(T)
# =============================================================================

def GibbsSi_I(T):
    """
    Calculates the Gibbs Free Energy G (J/mol) for the liquid phase 
    using the given thermodynamic model (Einstein model + polynomial).

    Parameters
    ----------
    T : float or np.ndarray
        Temperature in Kelvin (K). Must be 0 < T < EET.
    R_gas : float
        The ideal gas constant (J/(mol·K)).

    Returns
    -------
    float or np.ndarray
        Gibbs Free Energy G in J/mol.
    """
    
    # Ensure T is not zero, as it would cause division by zero or log(0)
    if np.any(T <= 0):
        raise ValueError("Temperature T must be greater than 0.")

    # --- Term 1: Constant (Enthalpy reference at T=0) ---
    G1_constant = -9229.0
    
    # --- Term 2: Einstein Model (H_E contribution at T=0) ---
    G2_einstein_enthalpy = (3/2) * R_gas * (ALPHA_PRIME * THETA_E_PRIME + ALPHA_DOUBLE_PRIME * THETA_E_DOUBLE_PRIME)
    
    # --- Term 3: Einstein Model (Entropy contribution) ---
    
    # Calculate the argument for the natural logarithm: 
    #   A = [alpha' * (e^(th'/T) / (e^(th'/T) - 1))] + [alpha'' * (e^(th''/T) / (e^(th''/T) - 1))]
    
    # Argument for first Einstein term
    exp_term_prime = np.exp(THETA_E_PRIME / T)
    arg_prime = ALPHA_PRIME * (exp_term_prime / (exp_term_prime - 1))
    
    # Argument for second Einstein term
    exp_term_double_prime = np.exp(THETA_E_DOUBLE_PRIME / T)
    arg_double_prime = ALPHA_DOUBLE_PRIME * (exp_term_double_prime / (exp_term_double_prime - 1))
    
    # Sum the arguments and calculate the final term
    log_argument = arg_prime + arg_double_prime
    
    G3_einstein_entropy = -3.0 * R_gas * T * np.log(log_argument)
    
    # --- Term 4: Polynomial Term 1 (T^2) ---
    G4_poly2 = -(C2 / 2.0) * (T**2)
    
    # --- Term 5: Polynomial Term 2 (T^5) ---
    G5_poly5 = -(C5 / 20.0) * (T**5)

    # --- Total Gibbs Energy ---
    G_total = G1_constant + G2_einstein_enthalpy + G3_einstein_entropy + G4_poly2 + G5_poly5
    
    return G_total


# ---------------------------------------
# Gibbs free energy function SiO2 Holland
# ---------------------------------------
def Gibbs_SiO2_Holland(T):
    """
    Compute Gibbs free energy for all SiO2 polymorphs using Holland et al. Cp model,
    and determine the stable phase (lowest G) at a given temperature.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.

    Returns
    -------
    G_min : float
        Gibbs free energy of the stable polymorph (J/mol).
    stable_phase : str
        Name of the polymorph with the lowest Gibbs energy.
    G_dict : dict
        Gibbs energies of all polymorphs at temperature T.
    """

    G_dict = {}

    # Loop over all polymorphs in the global SiO2Holland dictionary
    for phase, props in SiO2Holland.items():
        # Compute enthalpy change from reference H
        H = props["H"] + integral_Cp_Holland(
            props["a"], props["b"], props["c"], props["d"], tref=298.15, T=T
        )
        # Compute entropy change from reference S
        S = props["S"] + integral_CpT_Holland(
            props["a"], props["b"], props["c"], props["d"], tref=298.15, T=T
        )
        # Gibbs free energy
        G_dict[phase] = H - T*S

    # Determine stable phase (lowest G)
    stable_phase = min(G_dict, key=G_dict.get)
    G_min = G_dict[stable_phase]

    return G_min

# ---------------------------------------
# Gibbs free energy function SiO2 Mao
# ---------------------------------------
def Gibbs_SiO2_Mao(T):
    """
    Compute Gibbs free energy for Tridymite and Cristobalite using Mao et al. Cp model,
    and determine the stable phase (lowest G) at a given temperature.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.

    Returns
    -------
    G_min : float
        Gibbs free energy of the stable polymorph (J/mol).
    stable_phase : str
        Name of the polymorph with the lowest Gibbs energy.
    G_dict : dict
        Gibbs energies of both polymorphs at temperature T.
    """

    # Define the Mao SiO2 data for Tridymite and Cristobalite
    SiO2Mao_subset = {
        "Tridymite": SiO2Mao["Tridymite"],
        "Cristobalite": SiO2Mao["Cristobalite"]
    }

    G_dict = {}

    # Loop over the two polymorphs
    for phase, props in SiO2Mao_subset.items():
        # Compute enthalpy change from reference H
        H = props["H"] + integral_Cp_Mao(
            props["a"], props["b"], props["c"], props["d"],
            props.get("e", 0), props.get("f", 0), props.get("g", 0),
            tref=298.15, T=T
        )
        # Compute entropy change from reference S
        S = props["S"] + integral_CpT_Mao(
            props["a"], props["b"], props["c"], props["d"],
            props.get("e", 0), props.get("f", 0), props.get("g", 0),
            tref=298.15, T=T
        )
        # Gibbs free energy
        G_dict[phase] = H - T*S

    # Determine stable phase (lowest G)
    stable_phase = min(G_dict, key=G_dict.get)
    G_min = G_dict[stable_phase]

    return G_min

# %%
    # ------------------------------------------------------------
    # 1 bar log fO2 calculation
    # ------------------------------------------------------------

def log10fo2(t_k):    
    G_Si   = GibbsSi_I(t_k)
    # GibbsSi_I(t_k)  
    G_SiO2 = Gibbs_SiO2_Holland(t_k)
    # G_SiO2 = Gibbs_SiO2_Mao(t_k)
    if t_k < 2000:
        G_O2   = GibbsNIST(t_k, O2lt)
    else:
        G_O2   = GibbsNIST(t_k, O2ht)

    # ------------------------------------------------------------
    # 6. Reaction ΔG and oxygen fugacity
    # ------------------------------------------------------------
    # Reaction: Si + O2 ⇌ SiO2
    # ΔG_rxn = G(SiO2) - G(Si) - G(O2)
    #
    # At equilibrium:
    #   ΔG_rxn = -R*T*ln(K)
    #   and  K = 1/fO2   →  fO2 = exp(ΔG_rxn / (R*T))
    #
    # The logarithm base 10 is then applied for convenience.
    dG_rxn = G_SiO2 - G_Si - G_O2
    fO2_log10 = np.log10(np.exp(dG_rxn / (R_gas * t_k)))

    # ------------------------------------------------------------
    # 7. Return the log10(fO2)
    # ------------------------------------------------------------
    return fO2_log10

# %%
# T_range = np.linspace(1000, 2000, 100)
#     # -------------------------------
# GHolland = np.array([Gibbs_SiO2_Holland(T=T) for T in T_range])
# GMao = np.array([Gibbs_SiO2_Mao(T=T) for T in T_range])

# # Plot results
# plt.figure(figsize=(8,5))
# plt.plot(T_range, GHolland, 'r')
# plt.plot(T_range, GMao, 'b')
# plt.xlabel("Temperature (K)")
# plt.ylabel("Gibbs free energy (J/mol)")
# plt.title("Gibbs Free Energy of SiO2 Polymorphs (Holland Model)")
# plt.legend()
# plt.grid(True)
# plt.show()

# %%
# -------------------------------------------------------------------
# User prerequisites (must be defined in your session)
# - Si_phases: dict with phase keys (SiI, SiV, SiVII) and fields:
#     V0 (cm^3/mol), K0 (GPa), Kp (unitless), alpha0 (1/K),
#     gamma0, kappa, optional T_ref (K)
# - GibbsNIST(T, Sisolid) -> J/mol
# - GibbsSicalphad(T, phase_name) -> J/mol
# - Sisolid variable used by GibbsNIST
# -------------------------------------------------------------------

# -----------------------------
# Vinet residual and thermal model (unchanged)
# -----------------------------
def f_Vinet(Vtemp, P_target, V0, K0, Kp):
    x = (Vtemp / V0)**(1/3)
    if x <= 0:
        return 1e30
    P_from_Vinet = 3.0 * K0 * (1.0 - x) * x**-2 * np.exp(1.5 * (Kp - 1.0) * (1.0 - x))
    return P_from_Vinet - P_target

def VinetThermalVolume(V_ref, V0, alpha0, gamma0, kappa, tref, T):
    alpha = alpha0 * np.exp(-(gamma0 / kappa) * (1.0 - (V_ref / V0)**kappa))
    return V_ref * np.exp(alpha * (T - tref))

# -----------------------------
# Precompute P -> V_iso tables for each phase
# -----------------------------
def precompute_PV_table(phase_name, P_min=0.0, P_max=50.0, n_points=500, overwrite=False):
    """
    Build and store a table (Ps, V_iso) in Si_phases[phase_name]['_PV_table'].
    P in GPa, V_iso in same units as V0 (expected cm^3/mol).
    """
    if phase_name not in Si_phases:
        raise KeyError(f"Phase '{phase_name}' not found in Si_phases.")

    phase = Si_phases[phase_name]
    if ('_PV_table' in phase) and (not overwrite):
        return phase['_PV_table']

    V0 = phase['V0']
    K0 = phase['K0']
    Kp = phase['Kp']

    Ps = np.linspace(P_min, P_max, n_points)
    Vs = np.empty_like(Ps)
    # Solve Vinet for each P. Good initial guess: V0 scaled by (1 + P/K0)^-1 approximation
    for i, P in enumerate(Ps):
        approx_scale = 1.0 / (1.0 + P / (K0 + 1e-12))
        guess = V0 * approx_scale
        try:
            Vs[i] = fsolve(f_Vinet, guess, args=(P, V0, K0, Kp), maxfev=200)[0]
        except Exception:
            # fallback to previous value or V0
            Vs[i] = Vs[i-1] if i>0 else V0

    phase['_PV_table'] = (Ps, Vs)
    return phase['_PV_table']

def precompute_all_PV_tables(P_min=0.0, P_max=50.0, n_points=500, overwrite=False):
    for name in Si_phases:
        precompute_PV_table(name, P_min=P_min, P_max=P_max, n_points=n_points, overwrite=overwrite)

# -----------------------------
# Fast interpolated V(P,T) using precomputed V_iso table
# -----------------------------
def V_P_thermal_fast(P_gpa, phase_name, T):
    """
    Fast volume: interpolate precomputed V_iso(P) then apply thermal expansion.
    Returns V_th in same units as V0 (cm^3/mol).
    """
    phase = Si_phases[phase_name]
    if '_PV_table' not in phase:
        # default precompute if missing
        precompute_PV_table(phase_name)

    Ps, Vs_iso = phase['_PV_table']
    # clamp P within table bounds for stability
    P_clamped = np.clip(P_gpa, Ps[0], Ps[-1])
    V_iso = np.interp(P_clamped, Ps, Vs_iso)

    tref = phase.get('T_ref', 298.15)
    V_th = VinetThermalVolume(V_iso, phase['V0'], phase['alpha0'], phase['gamma0'], phase['kappa'], tref, T)
    return V_th

# -----------------------------
# Fast trapezoidal integral ∫ V dP
# -----------------------------
def Gibbs_integral_phase_fast(phase_name, P_target, T, P0=0.0, n_integration_pts=200):
    """
    Fast ∫_{P0}^{P_target} V(P,T) dP using vectorized trapezoid rule.
    Assumes precomputed PV table covers the requested P range.
    Returns J/mol (V in cm^3/mol, P in GPa; multiply by 1e3)
    """
    if abs(P_target - P0) < 1e-12:
        return 0.0

    # construct integration grid (use same grid as PV table if possible)
    phase = Si_phases[phase_name]
    Ps_table = phase.get('_PV_table', (None, None))[0]
    if Ps_table is not None:
        # choose subset of the table overlapping [min(P0,Pt), max(P0,Pt)]
        Pmin, Pmax = min(P0, P_target), max(P0, P_target)
        # pick ~n_integration_pts points uniformly within bracket, but aligned with table
        Ps = np.linspace(Pmin, Pmax, n_integration_pts)
    else:
        Ps = np.linspace(P0, P_target, n_integration_pts)

    Vs = np.array([V_P_thermal_fast(P, phase_name, T) for P in Ps])
    integral = trapezoid(Vs, Ps)  # GPa * cm^3/mol
    return integral * 1e3  # -> J/mol

# -----------------------------
# Cached transition pressures (per T)
# -----------------------------
@lru_cache(maxsize=64)
def get_transition_pressures(T, P_min=0.0, P_max=50.0):
    """
    Return (P_eq_SiI_SiV, P_eq_SiV_SiVII) in GPa for given T.
    Uses fast integrator and precomputed PV tables.
    """
    # ensure PV tables present for phases used in transitions
    for ph in ['SiI', 'SiV', 'SiVII']:
        precompute_PV_table(ph, P_min=P_min, P_max=P_max, n_points=1000, overwrite=False)

    # define deltaG functions using fast integrator and the user's Gibbs reference functions
    def deltaG_SiI_SiV_fast(P):
        G1 = GibbsNIST(T, Sisolid) + Gibbs_integral_phase_fast('SiI', P, T, P0=0.0)
        G2 = GibbsSicalphad(T, "Si_V") + Gibbs_integral_phase_fast('SiV', P, T, P0=0.0)
        return G2 - G1

    def deltaG_SiV_SiVII_fast(P):
        G2 = GibbsSicalphad(T, "Si_V") + Gibbs_integral_phase_fast('SiV', P, T, P0=0.0)
        G3 = GibbsSicalphad(T, "Si_VII") + Gibbs_integral_phase_fast('SiVII', P, T, P0=0.0)
        return G3 - G2

    # helper: find bracket where sign changes by sampling grid
    def find_bracket(func, a, b, n=200):
        xs = np.linspace(a, b, n)
        fs = [func(x) for x in xs]
        for i in range(len(xs)-1):
            if np.isfinite(fs[i]) and np.isfinite(fs[i+1]) and fs[i]*fs[i+1] <= 0:
                return xs[i], xs[i+1]
        raise ValueError(f"No sign change in [{a},{b}] for function; check T or extend bracket.")

    # find and solve roots
    a1, b1 = find_bracket(deltaG_SiI_SiV_fast, P_min, P_max)
    P_eq1 = brentq(deltaG_SiI_SiV_fast, a1, b1)

    a2, b2 = find_bracket(deltaG_SiV_SiVII_fast, P_min, P_max)
    P_eq2 = brentq(deltaG_SiV_SiVII_fast, a2, b2)

    return float(P_eq1), float(P_eq2)

# -----------------------------
# Fast top-level Gibbs function
# -----------------------------
def GSiHP_fast(T, P_gpa, use_fast_integrator=True):
    """
    Fast Gibbs energy of Si at (T, P_gpa) in J/mol.

    Parameters
    ----------
    T : float
        temperature in K
    P_gpa : float
        pressure in GPa
    use_fast_integrator : bool
        if True use trapezoidal integrator over precomputed PV tables

    Returns
    -------
    G_total : float (J/mol)
    """

    # Reference at 1 bar (user-supplied function)
    GSi1bar = GibbsNIST(T,Sisolid)
    # Use only Si-I because we cannot find phase transition above 1500 K due to phase metastability
    GHP = Gibbs_integral_phase_fast('SiVII', P_gpa, T, P0=0.0)

    # else:# Choose the piecewise VdP contributions using fast integrator
    #         # Get transition pressures (cached per T)
    #     P_eq1, P_eq2 = get_transition_pressures(T)
        
    #     if P_gpa < P_eq1:
    #         GHP = Gibbs_integral_phase_fast('SiI', P_gpa, T, P0=0.0)
    #     elif P_gpa < P_eq2:
    #         GHP = (Gibbs_integral_phase_fast('SiI', P_eq1, T, P0=0.0)
    #             + Gibbs_integral_phase_fast('SiV', P_gpa, T, P0=P_eq1))
    #     else:
    #         GHP = (Gibbs_integral_phase_fast('SiI', P_eq1, T, P0=0.0)
    #             + Gibbs_integral_phase_fast('SiV', P_eq2, T, P0=P_eq1)
    #             + Gibbs_integral_phase_fast('SiVII', P_gpa, T, P0=P_eq2))
    #     if T > 1500:
    #         GHP = Gibbs_integral_phase_fast('SiI', P_gpa, T, P0=0.0)

    return GSi1bar + GHP

# -----------------------------
# Utility: clear caches / rebuild tables
# -----------------------------
def clear_precomputed_tables():
    for name in Si_phases:
        if '_PV_table' in Si_phases[name]:
            del Si_phases[name]['_PV_table']
    get_transition_pressures.cache_clear()

def rebuild_all_tables(P_min=0.0, P_max=50.0, n_points=500, overwrite=True):
    precompute_all_PV_tables(P_min, P_max, n_points, overwrite=overwrite)
    get_transition_pressures.cache_clear()

# -----------------------------
# Usage example (do not run here; run in your session)
# -----------------------------
# 1) Precompute tables once (optional; function will auto-precompute if needed)
# # rebuild_all_tables(P_min=0.0, P_max=50.0, n_points=1000)
#
# 2) Compute fast Gibbs:
# G = GSiHP_fast(T=1500.0, P_gpa=1.0)
# print("G (J/mol) =", G)


# %%
# ---------------------------
# Functions needed to calculate the SiO2 phase transitions
# ---------------------------

def teosth(s, v0, n, a0, K, dKdP, dKdP2, pkbar, tref, T):
    """Calculates the integral of VdP term using thermal pressure (pth) and EoS."""
    theta = 10636 / (s/n + 6.44)
    u0 = theta / tref
    ksi0 = np.power(u0, 2) * math.exp(u0) / np.power((math.exp(u0) - 1), 2)
    a_eos = (1 + dKdP) / (1 + dKdP + K * dKdP2)
    b_eos = dKdP/K - dKdP2 / (1 + dKdP)
    c_eos = (1 + dKdP + K * dKdP2) / (np.power(dKdP, 2) + dKdP - K * dKdP2)
    u = theta / T
    pth = a0 * K * theta / ksi0 * (1 / (math.exp(u) - 1) - 1 / (math.exp(u0) - 1))
    
    intVdP = pkbar * v0 * (1 - a_eos + a_eos * (
        np.sign((1 - b_eos * pth)) * np.power(abs(1 - b_eos * pth), (1 - c_eos)) - 
        np.sign((1 + b_eos * (pkbar - pth))) * np.power(abs((1 + b_eos * (pkbar - pth))), (1 - c_eos))
    ) / (b_eos * (c_eos - 1) * pkbar))
    
    # Returning pth, a, b, c, and intVdP as in the original function
    return [pth, a_eos, b_eos, c_eos, intVdP]

def landauhp1bar(smax, vmax, tc0, pkbar, T):
    """Calculates the Landau contribution to Delta G for the alpha/beta transition."""
    q02 = np.sqrt(1 - tref / tc0)
    tc = tc0 + pkbar * vmax / smax
    
    if (tc - T) > 0:
        q2 = np.sqrt((tc - T) / tc0)
    else:
        q2 = 0
        
    gdistot = smax * (tc0 * (q02 - 1/3 * q02**3 + 1/3 * q2**3) - tc * q2 - T * (q02 - q2)) + pkbar * vmax * q02
    return gdistot

def calculate_G_phase(phase_key, pkbar, T, H_298, S_298, landau_enable=False):
    """Calculates the Gibbs energy G for a single phase at P, T."""
    data = SIO2_PHASES[phase_key]
    
    # H(T) - T*S(T) part at P_ref (H and S must be scaled consistently, here kJ/mol and kJ/molK)
    G_Pref = H_298 + integral_Cp_Holland(tref=tref, T=T, **data["Cp_coeffs"]) \
             - T * (S_298 + integral_CpT_Holland(tref=tref, T=T, **data["Cp_coeffs"]))
    
    # Integral VdP (EoS term)
    vdp_results = teosth(pkbar=pkbar, tref=tref, T=T, **data["EoS_params"])
    vdp = vdp_results[4]
    
    # Landau Term 
    landau_term = 0.0
    if landau_enable and data["Landau_params"]:
        landau_term = landauhp1bar(pkbar=pkbar, T=T, **data["Landau_params"])
        
    G_phase = G_Pref + vdp + landau_term
    return G_phase

# =============================================================================
# 4. Streamlined Transition Functions
# =============================================================================

# -----------------------------
# Gibbs free energy difference Quartz → Coesite (Simplified)
# -----------------------------

def cristoquartztrans_simplified(pkbar, t):
    # Retrieve H and S directly from the data structure
    hcristo = SIO2_PHASES['Cristobalite']['H_298']
    scristo = SIO2_PHASES['Cristobalite']['S_298']
    hqz = SIO2_PHASES['Quartz']['H_298']
    sqz = SIO2_PHASES['Quartz']['S_298']

    gcristo = calculate_G_phase("Cristobalite", pkbar, t, hcristo, scristo, landau_enable=False)
    gqz = calculate_G_phase("Quartz", pkbar, t, hqz, sqz, landau_enable=True)
    return gcristo - gqz

def qzcoetrans_simplified(pkbar, t):
    # Retrieve H and S directly from the data structure
    hqz = SIO2_PHASES['Quartz']['H_298']
    sqz = SIO2_PHASES['Quartz']['S_298']
    hcoe = SIO2_PHASES['Coesite']['H_298']
    scoe = SIO2_PHASES['Coesite']['S_298']
    
    gqz = calculate_G_phase("Quartz", pkbar, t, hqz, sqz, landau_enable=True)
    gcoe = calculate_G_phase("Coesite", pkbar, t, hcoe, scoe, landau_enable=False)
    return gqz - gcoe

# -----------------------------
# Gibbs free energy difference Coesite → Stishovite (Simplified)
# -----------------------------
def coestishtrans_simplified(pkbar, t):
    # Retrieve H and S directly from the data structure
    hcoe = SIO2_PHASES['Coesite']['H_298']
    scoe = SIO2_PHASES['Coesite']['S_298']
    hstish = SIO2_PHASES['Stishovite']['H_298']
    sstish = SIO2_PHASES['Stishovite']['S_298']
    
    gcoe = calculate_G_phase("Coesite", pkbar, t, hcoe, scoe, landau_enable=False)
    gstish = calculate_G_phase("Stishovite", pkbar, t, hstish, sstish, landau_enable=False)
    return gcoe - gstish


# %%
# def G_phase(T, phase, include_landau=False, pkbar=0):
#     """
#     Compute Gibbs free energy of a SiO2 phase at temperature T and optionally at pressure pkbar.

#     Parameters
#     ----------
#     T : float
#         Temperature in K
#     phase : dict
#         Phase dictionary containing 'H_298', 'S_298', 'Cp_coeffs', 'Landau_params', 'EoS_params'
#     include_landau : bool, optional
#         If True, include Landau contribution (default False)
#     pkbar : float, optional
#         Pressure in kbar for Landau contribution (default 0)

#     Returns
#     -------
#     float
#         Gibbs free energy in J/mol (0-P reference)
#     """
#     Cp = phase["Cp_coeffs"]
#     H_ref = phase["H_298"]
#     S_ref = phase["S_298"]

#     # Heat capacity contributions
#     dH = integral_Cp_Holland(Cp['a'], Cp['b'], Cp['c'], Cp['d'], 298.15, T)
#     dS = integral_CpT_Holland(Cp['a'], Cp['b'], Cp['c'], Cp['d'], 298.15, T)

#     # Base Gibbs energy
#     G = H_ref*1e3 + dH - T * (S_ref*1e3 + dS)

#     # Optional Landau contribution (e.g., Quartz)
#     if include_landau and phase["Landau_params"]:
#         lp = phase["Landau_params"]
#         G += landauhp1bar(**lp, pkbar=pkbar, T=T)

#     return G


def GSiO2_HP(T, P_GPa):
    """
    Compute total Gibbs free energy of SiO2 at pressure P_GPa and temperature T.
    Accounts for phase transitions: Cristobalite -> Quartz -> Coesite -> Stishovite.

    Parameters
    ----------
    T : float
        Temperature (K)
    P_GPa : float
        Pressure (GPa)

    Returns
    -------
    float
        Gibbs free energy in J/mol
    """
    # Convert P to kbar
    pkbar = P_GPa * 10

    # --- Find equilibrium pressures for phase transitions ---
    P_eq_Cr_Qz = fsolve(lambda p: cristoquartztrans_simplified(p, T), x0=3.0)[0]
    P_eq_Qz_Co = fsolve(lambda p: qzcoetrans_simplified(p, T), x0=3.0)[0]
    P_eq_Co_St = fsolve(lambda p: coestishtrans_simplified(p, T), x0=8.0)[0]

    # Start with 0-pressure Cristobalite contribution
    hcristo = SIO2_PHASES['Cristobalite']['H_298']
    scristo = SIO2_PHASES['Cristobalite']['S_298']
    G_total = 1e3 * calculate_G_phase("Cristobalite", 1, T, hcristo, scristo, landau_enable=False)


    #### Up to this point everything is fine ####

    # --- Piecewise contributions depending on P ---
    if pkbar < P_eq_Cr_Qz:
        # Only Cristobalite
        phase = SIO2_PHASES["Cristobalite"]
        G_total += teosth(**phase["EoS_params"], pkbar=pkbar, tref=298.15, T=T)[4] * 1e3

    elif pkbar < P_eq_Qz_Co:
        # Cristobalite up to transition
        phase = SIO2_PHASES["Cristobalite"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

        # Quartz from transition to current P
        phase = SIO2_PHASES["Quartz"]
        G_total += teosth(**phase["EoS_params"], pkbar=pkbar - P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

    elif pkbar < P_eq_Co_St:
        # Cristobalite
        phase = SIO2_PHASES["Cristobalite"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

        # Quartz
        phase = SIO2_PHASES["Quartz"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Qz_Co - P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

        # Coesite
        phase = SIO2_PHASES["Coesite"]
        G_total += teosth(**phase["EoS_params"], pkbar=pkbar - P_eq_Qz_Co, tref=298.15, T=T)[4] * 1e3

    else:
        # Cristobalite
        phase = SIO2_PHASES["Cristobalite"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

        # Quartz
        phase = SIO2_PHASES["Quartz"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Qz_Co - P_eq_Cr_Qz, tref=298.15, T=T)[4] * 1e3

        # Coesite
        phase = SIO2_PHASES["Coesite"]
        G_total += teosth(**phase["EoS_params"], pkbar=P_eq_Co_St - P_eq_Qz_Co, tref=298.15, T=T)[4] * 1e3

        # Stishovite
        phase = SIO2_PHASES["Stishovite"]
        G_total += teosth(**phase["EoS_params"], pkbar=pkbar - P_eq_Co_St, tref=298.15, T=T)[4] * 1e3

    return G_total

# %%
def fO2_SiSiO2solidHP(p_bar, t_k):
    """
    Compute log10(fO2) for the equilibrium:
        SiO2 = Si + O2

    Parameters
    ----------
    T : float
        Temperature in K
    P : float
        Pressure in bar (or in the units expected by GSiO2_func and GSi_func)
    GSiO2_func : callable
        Function returning Gibbs free energy of SiO2 (J/mol)
    GSi_func : callable
        Function returning Gibbs free energy of Si (J/mol)
    GO2_func : callable
        Function returning Gibbs free energy of O2 (J/mol)
    O2_data : dict, optional
        Data structure passed to GO2_func (e.g., for NIST functions)

    Returns
    -------
    float
        log10(fO2)
    """
    T = t_k 

    # Compute Gibbs energies (J/mol)
    G_SiO2 = GSiO2_HP(T, p_bar * 1e-4)  
    G_Si = GSiHP_fast(T, p_bar * 1e-4)
    if t_k <= 2000:
        G_O2 = GibbsNIST(T, O2lt)
    else:
        G_O2 = GibbsNIST(T, O2ht)

    # Reaction: SiO2 = Si + O2
    dG_rxn = G_SiO2 - G_Si - G_O2

    # log10(fO2)
    fO2_log10 = np.log10(np.exp(dG_rxn / (R_gas * T)))

    return fO2_log10


