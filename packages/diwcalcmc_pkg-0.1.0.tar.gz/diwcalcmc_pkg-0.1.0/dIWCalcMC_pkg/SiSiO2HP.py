# %%
# === Core scientific computing ===
import math
import numpy as np
import pandas as pd
import scipy.integrate as integrate
import scipy.optimize as opt
import scipy.special as special
from scipy import stats

# === Specific functions (optional shortcuts) ===
from scipy.integrate import quad
from scipy.optimize import fsolve
from scipy.special import factorial

# === Plotting ===
import matplotlib.pyplot as plt

# %%
# -----------------------------
# Universal constant
# -----------------------------
R_gas = 8.314  # J/mol/K — universal gas constant

# %%
# =============================================================================
# Define some parameters for SiO2 liquid (Stixrude's models)
# =============================================================================

# Coefficients of the excess free energy expansion for SiO2 liquid
# (Appendix of de Koker 2009, used for computing non-ideal contributions)
a_SiO2 = np.array([[-1.94593156e+06,  4.55028631e+05, -2.16602819e+05],
                   [-2.26683598e+05, -2.00585046e+05,  7.30776533e+04],
                   [ 2.01565287e+06,  4.41534041e+05,  8.92122090e+05],
                   [ 4.83697299e+07,  2.07016995e+07, -1.22847875e+06],
                   [-6.51587652e+08, -1.28258724e+08,  0.00000000e+00],
                   [ 4.10018129e+09,  0.00000000e+00,  0.00000000e+00]])

# =============================================================================
# Set of functions to calculate the volume of SiO2 and Fe2SiO4 liquids
# =============================================================================

# -------------------------------------------------------------------------
# Function to bracket a zero of a function (used for root-finding of volumes)
# -------------------------------------------------------------------------
def bracket(fn, x0, dx, args=(), ratio=1.618, maxiter=100):
    """
    Find initial bracketing interval [x_left, x_right] where a function changes sign.
    
    Parameters
    ----------
    fn : callable
        Function for which a zero is sought.
    x0 : float
        Initial guess for zero.
    dx : float
        Initial step size to move left and right from x0.
    args : tuple
        Additional arguments to pass to fn.
    ratio : float
        Multiplicative factor for expanding step size.
    maxiter : int
        Maximum number of iterations to attempt bracketing.
        
    Returns
    -------
    x_left, x_right, f_left, f_right : float
        Bracketing interval and corresponding function values.
    """
    niter = 0
    dx = np.abs(dx)
    assert(ratio > 1.0)  # Ensure ratio > 1 for expansion

    # Evaluate function at starting points
    f0 = fn(x0, *args)
    x_left = x0 - dx
    x_right = x0 + dx
    f_left = fn(x_left, *args)
    f_right = fn(x_right, *args)

    # Adjust dx if slope changes sign unexpectedly
    if (f0 - f_left) * (f_right - f0) < 0.:
        while (f0 - f_left) * (f_right - f0) < 0. and dx > np.finfo('float').eps and niter < maxiter:
            dx /= ratio
            x_left = x0 - dx
            x_right = x0 + dx
            f_left = fn(x_left, *args)
            f_right = fn(x_right, *args)
            niter += 1
        if niter == maxiter:
            raise ValueError('Cannot find zero.')

    # Determine initial walking direction based on slope
    niter = 0
    slope = f_right - f0
    if slope > 0. and f0 > 0.:
        dx = -dx
        x1 = x_left
        f1 = f_left
    elif slope > 0. and f0 < 0.:
        x1 = x_right
        f1 = f_right
    elif slope < 0. and f0 > 0:
        x1 = x_right
        f1 = f_right
    else:
        dx = -dx
        x1 = x_left
        f1 = f_left

    # Walk iteratively until zero is bracketed
    while f0 * f1 > 0. and niter < maxiter:
        dx *= ratio
        xnew = x1 + dx
        fnew = fn(xnew, *args)
        x0 = x1
        f0 = f1
        x1 = xnew
        f1 = fnew
        niter += 1

    if f0 * f1 > 0.:
        raise ValueError('Cannot find zero.')
    else:
        return x0, x1, f0, f1

# -------------------------------------------------------------------------
# Atomic/molecular contributions to free energy
# -------------------------------------------------------------------------

# Natural log of the partition function (atomic momentum contribution, Eq. 14 de Koker 2009)
def _ln_partition_function(mass, t):
    return 3./2.*np.log(t) + 3./2.*np.log(mass*Boltzmann/(2*np.pi*Dirac*Dirac))

# Ideal gas Helmholtz free energy (Eq. 14 de Koker 2009)
def _F_ig(t, v, formula):
    V = v/na  # Convert molar volume to atomic volume
    if formula == 'SiO2':
        figoverRT = (-1*(np.log(V) + _ln_partition_function(0.0280855/na, t) + 1.) + 1*np.log(1)) + \
                    (-2*(np.log(V) + _ln_partition_function(0.0159994/na, t) + 1.) + 2*np.log(2))
    elif formula == 'Fe2SiO4':
        figoverRT = (-2*(np.log(V) + _ln_partition_function(0.055845/na, t) + 1.) + 2*np.log(2)) + \
                    (-1*(np.log(V) + _ln_partition_function(0.0280855/na, t) + 1.) + 1*np.log(1)) + \
                    (-4*(np.log(V) + _ln_partition_function(0.0159994/na, t) + 1.) + 4*np.log(4))
    return R*t*figoverRT

# Ideal gas contribution to pressure (section 3.1.1 de Koker 2009)
def _P_ig(t, v, n):
    return n*R_gas*t/v

# -------------------------------------------------------------------------
# Thermal electronic contributions
# -------------------------------------------------------------------------

# Volume associated with thermal electronic excitation (Eq. 34 de Koker 2009)
def _Tel(t, v, te0, el0, et):
    return te0*(np.power((v/el0), et))

# Volume associated with zeta parameter (Eq. 35 de Koker 2009)
def _zeta(t, v, ze, el0, x):
    return ze*(math.pow(v/el0, x))

# Electronic contribution to Helmholtz free energy (Eq. 30 de Koker 2009)
def _gimel(t_el, t, v):
    return 0.5*(t*t - t_el*t_el) - t*t_el*np.log(t/t_el)

# Total electronic Helmholtz free energy
def _F_el(t, v, ze, te0, el0, et, x):
    t_el = _Tel(t, v,te0, el0, et)
    if t < t_el:
        F_el = 0
    else:
        F_el = -_zeta(t, v, ze, el0, x) * _gimel(t_el, t, v)
    return F_el

# Volume derivative of zeta (Eq. 32 de Koker 2009)
def _dzetadV(t, v, ze, x, el0):
    return ze*x*(math.pow(v/el0, x))/v

# Volume derivative of Tel (Eq. 32 de Koker 2009)
def _dTeldV(t, v, te0, et, el0):
    return te0 * et * (math.pow(v/el0, et))/v

# Right-hand part of electronic pressure contribution (Eq. 32 de Koker 2009)
def _dgimeldTel(t_el, t, v, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0):
    return (t-t_el) - t*np.log(t/t_el)

# Electronic contribution to pressure (Eq. 32 de Koker 2009)
def _P_el(t, v, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0):
    t_el = _Tel(t, v, te0, el0, et)
    if t < t_el:
        P_el = 0
    else:
        P_el =  _dzetadV(t, v, ze, x, el0) * _gimel(t_el, t, v) + \
                _zeta(t, v, ze, el0, x) * _dTeldV(t, v, te0, et, el0) * \
                _dgimeldTel(t_el, t, v, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0)
    return P_el

# -------------------------------------------------------------------------
# Excess free energy contributions
# -------------------------------------------------------------------------

# Finite strain (Eq. 23 de Koker 2009)
def _finite_strain(t, v, v_0):
    return (1./2.)*(math.pow(v_0/v, 2./3.) - 1.0)

# Thermal variable theta (Eq. 24 de Koker 2009)
def _theta(t, v, t_0, m_0):
    return math.pow(t/t_0, m_0) - 1.  

# Volume derivative of finite strain (Eq. 16 de Koker 2009)
def _dfdV(t, v, v_0):
    return (-1./3.)*math.pow(v_0/v, 2./3.)/v

# Excess Helmholtz free energy (Eq. 16 de Koker 2009)
def _F_xs(t, v, v_0, t_0, m_0, a):
    f = _finite_strain(t, v, v_0)
    theta = _theta(t, v, t_0, m_0)
    energy = 0.
    for i in range(len(a)):
        ifact = factorial(i, exact=False)
        for j in range(len(a[0])):
            jfact = factorial(j, exact=False)
            energy += a[i][j]*math.pow(f, i)*math.pow(theta, j)/ifact/jfact         
    return energy

# Excess contribution to pressure (Eq. 17 de Koker 2009)
def _P_xs(t, v, v_0, t_0, m_0, a):
    f = _finite_strain(t, v, v_0)
    theta = _theta(t, v, t_0, m_0)
    pressure = 0.
    for i in range(len(a)):
        ifact = factorial(i, exact=False)
        if i > 0:
            for j in range(len(a[0])):
                jfact = factorial(j, exact=False)
                pressure += float(i)*a[i][j]*math.pow(f, float(i)-1.)*math.pow(theta, float(j))/ifact/jfact
    return -_dfdV(t, v, v_0)*pressure

# -------------------------------------------------------------------------
# Magnetic contributions
# -------------------------------------------------------------------------

# Calculate spin contribution for magnetic effects
def _spin(t, v, v_0, n, spin_a_0, spin_b_0):
    S_a = 0.
    S_b = 0.
    numerator = 0.
    numerator_2 = 0.
    if spin_a_0 != 0:
        n = 2  
        VoverVx = v/v_0
        S_a = spin_a_0[0] + spin_a_0[1]*VoverVx
        S_b = (spin_b_0[0] + spin_b_0[1]/VoverVx + spin_b_0[2]/(VoverVx**2) + spin_b_0[3]/(VoverVx**3))
        numerator = -2.*(-spin_a_0[1]*t + spin_b_0[1]/(VoverVx**2) + 2.*spin_b_0[2]/(VoverVx**3) + 3.*spin_b_0[3]/(VoverVx**4))/v_0
        numerator_2 = 2.*((2.*spin_b_0[1]/(VoverVx**3) + 6.*spin_b_0[2]/(VoverVx**4) + 12.*spin_b_0[3]/(VoverVx**5))/v_0**2)
    return S_a, S_b, numerator, numerator_2, n

# Magnetic contribution to Helmholtz energy
def _F_mag(t, v, v_0, n, spin_a_0, spin_b_0):
    S_a, S_b, numerator, numerator_2, n_atoms = _spin(t, v, v_0, n, spin_a_0, spin_b_0)
    S = S_a*t + S_b
    return -n_atoms*R*t*np.log(2.*S + 1.)

# Magnetic contribution to pressure
def _P_mag(t, v, v_0, n, spin_a_0, spin_b_0):
    S_a, S_b, numerator, numerator_2, n_atoms = _spin(t, v, v_0, n, spin_a_0, spin_b_0)
    S = S_a*t + S_b
    dFdV = -n_atoms*R_gas*t*numerator/(2.*S + 1.)
    return -dFdV

# -------------------------------------------------------------------------
# Total thermodynamic properties
# -------------------------------------------------------------------------

# Helmholtz free energy including all contributions
def helmholtz_free_energy(p, t, v, ze, te0, el0, et, v_0, t_0, m_0, a, n, x, spin_a_0, spin_b_0, formula):
    F = (_F_ig(t, v, formula) 
         + _F_el(t, v, ze, te0, el0, et, x)
         + _F_xs(t, v, v_0, t_0, m_0, a)
         + _F_mag(t, v, v_0, n, spin_a_0, spin_b_0))
    return F

# Gibbs free energy: Helmholtz + PV term
def gibbs_free_energy(p, t, v, ze, te0, el0, et, v_0, t_0, m_0, a, n, x, spin_a_0, spin_b_0, formula):
    G = helmholtz_free_energy(p, t, v, ze, te0, el0, et, v_0, t_0, m_0, a, n, x, spin_a_0, spin_b_0, formula) + p*v
    return G

# Total pressure (sum of all contributions)
def pressure(t, v, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0):
    P = (_P_ig(t, v, n) 
         + _P_el(t, v, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0)
         + _P_xs(t, v, v_0, t_0, m_0, a)
         + _P_mag(t, v, v_0, n, spin_a_0, spin_b_0))
    return P

# Compute volume of liquid at given P, T by root-finding
def volume(p, t, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0):
    _delta_pressure = lambda vol: p - pressure(t=t, v=vol, n=n, ze=ze, x=x, te0=te0, el0=el0, et=et,
                                               v_0=v_0, t_0=t_0, m_0=m_0, a=a,
                                               spin_a_0=spin_a_0, spin_b_0=spin_b_0)
    try:
        sol = bracket(_delta_pressure, v_0, 1.e-2 * v_0)
    except ValueError:
        raise Exception('Cannot find a volume, perhaps outside EOS validity range?')
    
    return opt.brentq(_delta_pressure, sol[0], sol[1])

# -------------------------------------------------------------------------
# Integration of V(P, T) over P
# -------------------------------------------------------------------------

# Integral of V(P, T) from 0 to P_max
def integral_V_vs_P(P_max, T, n, ze, x, te0, el0, et, v_0, t_0, m_0, a, spin_a_0, spin_b_0):
    """
    Compute ∫_0^P_max V(P, T) dP numerically.
    
    Parameters
    ----------
    P_max : float
        Maximum pressure (Pa)
    T : float
        Temperature (K)
    Other args : parameters needed for `volume` function
    
    Returns
    -------
    float
        Numerical integral of V(P, T) from 0 to P_max (m³)
    """
    integrand = lambda P: volume(p=P, t=T, n=n, ze=ze, x=x, te0=te0, el0=el0, et=et,
                                 v_0=v_0, t_0=t_0, m_0=m_0, a=a,
                                 spin_a_0=spin_a_0, spin_b_0=spin_b_0)
    result, error = quad(integrand, 0, P_max, limit=200)
    return result


# %%
# =============================================================================
# Vinet Equation of State with Thermal Expansion for Si EOS
# =============================================================================
# This module computes the pressure–volume–temperature (P–V–T) relations
# for a solid phase using the Vinet EOS (Vinet et al., 1987, J. Geophys. Res.),
# combined with a thermal expansion correction following an exponential law
# dependent on the Grüneisen parameter (γ0) and an anharmonic exponent (κ).
# =============================================================================

# -----------------------------
# 1. Thermal expansion correction
# -----------------------------
def VinetThermalVolume(V_ref: float, V0: float, alpha0: float, gamma0: float, kappa: float,
                       T_ref: float, T: float) -> float:
    """
    Compute the temperature-corrected volume using the Vinet thermal expansion model.

    Parameters
    ----------
    V_ref : float
        Reference (cold or isothermal) volume at the given pressure, typically obtained
        from the static (0 K) Vinet EOS at pressure P (in cm³/mol or m³/mol).
    V0 : float
        Reference volume at 0 K and 0 GPa (the "zero-pressure molar volume").
    alpha0 : float
        Thermal expansion coefficient at reference conditions (1/K).
    gamma0 : float
        Grüneisen parameter at reference conditions (dimensionless),
        describing how vibrational frequencies vary with volume.
    kappa : float
        Exponent defining how γ changes with volume (γ ∝ (V/V0)^κ).
    T_ref : float
        Reference temperature (K) for the thermal correction, e.g., 298 K.
    T : float
        Target temperature (K) at which the thermally expanded volume is required.

    Returns
    -------
    float
        Temperature-corrected volume (same units as V_ref).

    Notes
    -----
    The model assumes exponential thermal expansion according to:
        α(V) = α₀ * exp[-(γ₀/κ) * (1 - (V_ref/V₀)^κ)]

    The thermal volume expansion is then computed as:
        V(T) = V_ref * exp[α(V) * (T - T_ref)]

    This approach approximates the integrated thermal expansion assuming
    α varies slowly with temperature and pressure.
    """
    # Compute the effective thermal expansion coefficient α(V)
    alpha = alpha0 * np.exp(-(gamma0 / kappa) * (1 - (V_ref / V0)**kappa))

    # Apply thermal expansion to obtain V(T)
    V_th = V_ref * np.exp(alpha * (T - T_ref))

    return V_th


# -----------------------------
# 2. Static (cold) Vinet EOS function
# -----------------------------
def Vinet(V, P, V0, K0, Kp):
    """
    Cold (0 K) Vinet equation of state relating pressure and volume.

    Parameters
    ----------
    V : float
        Volume at pressure P (m³/mol or cm³/mol).
    P : float
        External pressure (GPa).
    V0 : float
        Reference zero-pressure volume at 0 K.
    K0 : float
        Bulk modulus at zero pressure (GPa).
    Kp : float
        First pressure derivative of the bulk modulus (dimensionless).

    Returns
    -------
    float
        Residual (P_model - P), which should be zero when V satisfies the EOS.

    Notes
    -----
    The Vinet EOS is given by:
        P(V) = 3K₀(1 - η^(1/3)) * η^(-2/3) * exp[1.5(K'₀ - 1)(1 - η^(1/3))]

    where η = V / V₀.

    The form used here rearranges this equation as:
        f(V) = P_model(V) - P_target = 0

    This allows numerical solution for V(P) using a root-finding algorithm
    such as Brent’s method (opt.brentq).
    """
    eta = V / V0
    P_model = 3 * K0 * eta**(-2/3) * (1 - eta**(1/3)) * np.exp(1.5 * (Kp - 1) * (1 - eta**(1/3)))
    return P_model - P


# -----------------------------
# 3. Compute the equilibrium volume V(P, T)
# -----------------------------
def V_of_P_T(P, T, V0, K0, Kp, alpha0, gamma0, kappa, T_ref):
    """
    Solve for equilibrium volume at given pressure and temperature.

    Parameters
    ----------
    P : float
        Pressure (GPa)
    T : float
        Temperature (K)
    V0 : float
        Reference zero-pressure volume (m³/mol)
    K0 : float
        Bulk modulus at zero pressure (GPa)
    Kp : float
        Pressure derivative of bulk modulus
    alpha0 : float
        Thermal expansion coefficient at reference conditions (1/K)
    gamma0 : float
        Grüneisen parameter at reference conditions
    kappa : float
        Grüneisen exponent
    T_ref : float
        Reference temperature (K)

    Returns
    -------
    float
        Temperature- and pressure-dependent volume, V(P, T).

    Procedure
    ---------
    1. Compute the *cold compression volume* (V_cold) by solving the Vinet EOS
       at the desired pressure P and reference temperature.
    2. Apply the exponential thermal expansion correction to account for T ≠ T_ref.
    """
    # Step 1 — find the isothermal “cold” volume at pressure P
    # Brent’s method is used to find the root of f(V) = Vinet(V) = 0
    V_cold = opt.brentq(Vinet, 0.1 * V0, 1.5 * V0, args=(P, V0, K0, Kp))

    # Step 2 — apply thermal expansion to correct for temperature
    V_th = VinetThermalVolume(V_cold, V0, alpha0, gamma0, kappa, T_ref, T)

    return V_th


# -----------------------------
# 4. Integrate V(P, T) from 0 → P_max
# -----------------------------
def integrate_V_dP(P_max, T, V0, K0, Kp, alpha0, gamma0, kappa, T_ref):
    """
    Compute the integral of volume over pressure, ∫₀^{P_max} V(P, T) dP.

    Parameters
    ----------
    P_max : float
        Maximum pressure (GPa).
    T : float
        Temperature (K).
    V0 : float
        Reference zero-pressure volume (m³/mol).
    K0 : float
        Bulk modulus at zero pressure (GPa).
    Kp : float
        Pressure derivative of bulk modulus.
    alpha0 : float
        Thermal expansion coefficient (1/K).
    gamma0 : float
        Grüneisen parameter.
    kappa : float
        Exponent controlling the volume dependence of γ.
    T_ref : float
        Reference temperature (K).

    Returns
    -------
    float
        Integral value of ∫₀^{P_max} V(P, T) dP (in cm³·GPa/mol if input units are consistent).

    Notes
    -----
    This integral term appears in the Gibbs energy difference:
        ΔG = ∫₀^{P} V(P', T) dP'
    which represents the work done upon compression from 0 to P at temperature T.

    Numerical integration is performed using adaptive Gaussian quadrature (`scipy.integrate.quad`)
    with a conservative limit of 200 subintervals to ensure convergence even for steep
    P–V relationships at high compression.
    """
    # Define integrand for numerical quadrature
    integrand = lambda P: V_of_P_T(P, T, V0, K0, Kp, alpha0, gamma0, kappa, T_ref)

    # Perform numerical integration using SciPy’s adaptive quadrature
    integral, err = integrate.quad(integrand, 0, P_max, limit=200)

    return integral


# %%
# =============================================================================
# NASA Polynomial Thermodynamic Functions for Si-SiO2 JANAF
# =============================================================================
# This script computes temperature-dependent thermodynamic properties of
# selected gaseous species (Si, SiO2, O2) using NASA 7-coefficient polynomials.
#
# The NASA polynomial formalism expresses Cp(T), H(T), and S(T) as polynomial
# functions of temperature, and allows the computation of the Gibbs free energy:
#       G(T) = H(T) - T * S(T)
#
# References:
#   McBride et al. (1993), NASA Technical Memorandum 4513
#   “Thermodynamic Data for Fifty Reference Elements and Their Compounds”
#
# Units:
#   T  : temperature in K
#   H  : J/mol (enthalpy)
#   S  : J/mol/K (entropy)
#   G  : J/mol (Gibbs free energy)
# =============================================================================


# -----------------------------
# NASA polynomial functions
# -----------------------------
def H_minus_H298(T, A, B, C, D, E, F, H):
    """
    Compute enthalpy difference [H(T) - H(298 K)] for a given species
    using the NASA 7-coefficient polynomial.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    A–H : float
        NASA polynomial coefficients specific to each species.

    Returns
    -------
    float
        Enthalpy difference in J/mol.

    Notes
    -----
    The NASA polynomial defines Cp/R as:
        Cp/R = A + B*t + C*t² + D*t³ + E*t⁻²
    where t = T / 1000.

    Integrating Cp(T) from 298 to T gives:
        (H(T) - H(298)) = 1000 × [A*t + ½B*t² + (1/3)C*t³ + (1/4)D*t⁴ - E/t + F]

    The result is multiplied by 1000 to ensure the final units are J/mol.
    """
    t = T / 1e3  # Dimensionless temperature variable (T scaled by 1000)
    return 1e3 * (A*t + 0.5*B*t**2 + (1/3)*C*t**3 + (1/4)*D*t**4 - E/t + F)


def S_absolute(T, A, B, C, D, E, G):
    """
    Compute absolute entropy S°(T) using NASA 7-coefficient polynomial.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    A–G : float
        NASA polynomial coefficients specific to each species.

    Returns
    -------
    float
        Absolute entropy (J/mol/K).

    Notes
    -----
    The integrated form of Cp/T yields the absolute entropy:
        S°/R = A*ln(t) + B*t + ½C*t² + (1/3)D*t³ - ½E/t² + G
    where t = T / 1000.

    Here, the function returns S°(T) in J/mol/K (R = 1 conventionally omitted).
    """
    t = T / 1e3  # Dimensionless temperature
    return A*np.log(t) + B*t + 0.5*C*t**2 + (1/3)*D*t**3 - 0.5*E/t**2 + G


# -----------------------------
# Species coefficients
# -----------------------------
# Each dictionary below defines the NASA polynomial coefficients for a gas species.
# Coefficients A–H are determined by fitting experimental or calculated thermochemical data.

# ---- Elemental silicon gas (Si) ----
Si = {
    "A": 27.19604,        # Coefficient A: constant term in Cp/R
    "B": -1.198306e-10,   # Coefficient B: linear term in Cp/R
    "C": 5.353262e-11,    # Coefficient C: quadratic term in Cp/R
    "D": -6.956612e-12,   # Coefficient D: cubic term in Cp/R
    "E": -4.294375e-12,   # Coefficient E: inverse-square term in Cp/R
    "F": 40.36163,        # Coefficient F: enthalpy integration constant
    "G": 77.37178,        # Coefficient G: entropy integration constant
    "H": 48.46997         # Coefficient H: standard enthalpy (298 K)
}

# ---- Silicon dioxide gas (SiO2) ----
SiO2 = {
    "A": 85.77200,
    "B": -1.6e-5,
    "C": 4.0e-6,
    "D": -3.809081e-7,
    "E": -1.7e-5,
    "F": -952.8700,
    "G": 113.3440,
    "H": -902.6610
}

# ---- Molecular oxygen gas (O2) < 2000 K ----
O2lt = {
    "A": 30.03235,
    "B": 8.772972,
    "C": -3.988133,
    "D": 0.788313,
    "E": -0.741599,
    "F": -11.32468,
    "G": 236.1663,
    "H": 0.0
}

# ---- Molecular oxygen gas (O2) > 2000 K ----
O2ht = {
    "A": 29.91111,
    "B": 10.72071,
    "C":-2.020498,
    "D": 0.146449,
    "E": 9.245722,
    "F": 5.337651,
    "G": 237.6185,
    "H": 0.0
}

# -----------------------------
# Gibbs free energy function
# -----------------------------
def Gibbs(T, species):
    """
    Compute Gibbs free energy G(T) = H(T) - T*S(T)
    for a given chemical species using NASA polynomial parameters.

    Parameters
    ----------
    T : float
        Temperature in Kelvin.
    species : dict
        Dictionary of NASA polynomial coefficients (A–H).

    Returns
    -------
    float
        Gibbs free energy in J/mol.

    Method
    -------
    1. Compute enthalpy change relative to 298 K:
           H = H_minus_H298(T, ...)
    2. Compute absolute entropy:
           S = S_absolute(T, ...)
    3. Combine to obtain Gibbs energy:
           G = H - T*S
    """
    # Compute enthalpy relative to 298 K
    H = H_minus_H298(
        T, species["A"], species["B"], species["C"], species["D"],
        species["E"], species["F"], species["H"]
    )

    # Compute absolute entropy
    S = S_absolute(
        T, species["A"], species["B"], species["C"], species["D"],
        species["E"], species["G"]
    )

    # Gibbs free energy relation
    return H - T * S


# %%
def gibbs_free_energy_model_2_liquid(T):
    """
    Calculates the Gibbs free energy (G) in J/mol using the parameters for Liquid 
    from the second image.
    
    Parameters:
    T (float or np.ndarray): Temperature in Kelvin (K). The model is valid 
                            for 0 < T < 6000 K.
    
    Returns:
    float or np.ndarray: Gibbs free energy G in J/mol.
    """
    
    # Parameters from the second image (Liquid)
    theta_prime_E = 418.05 # K
    alpha_prime = 0.748
    theta_double_prime_E = 155.54 # K
    alpha_double_prime = 0.252 # Note: alpha_prime + alpha_double_prime = 1.000
    
    # Ensure T is not zero
    if np.any(T <= 0):
        T = np.where(T <= 0, 1e-10, T)
        
    # Variables for calculation
    t_prime = theta_prime_E / T
    t_double_prime = theta_double_prime_E / T
    
    # 1. First two terms (Constant and 3/2*R*...)
    G_const_term = 25835.4 + (3/2) * R_gas * (alpha_prime * theta_prime_E + alpha_double_prime * theta_double_prime_E)
    
    # 2. Third term (Entropy-like part) - Same mathematical simplification as model 1
    ln_term_prime = t_prime - np.log(np.exp(t_prime) - 1)
    ln_term_double_prime = t_double_prime - np.log(np.exp(t_double_prime) - 1)
    
    G_entropy_term = -3 * R_gas * T * (alpha_prime * ln_term_prime + alpha_double_prime * ln_term_double_prime)
    
    # No polynomial terms (T^2, T^5) in this equation
    
    G = G_const_term + G_entropy_term
    
    return G

# %%
def fO2_SiSiO2(p_bar, t_k):
    """
    Compute log10(fO2) for the equilibrium:
        Si + O2 = SiO2

    This function calculates the oxygen fugacity (fO2) in log10 units as a 
    function of temperature (t_k) and pressure (p_bar) for the equilibrium:
        Si + O2 ⇌ SiO2

    It combines thermodynamic data (NASA polynomials) with 
    pressure–volume–temperature (P–V–T) corrections from equations of state (EOS).

    Parameters
    ----------
    p_bar : float
        Pressure [bar].
    t_k : float
        Temperature [K].

    Returns
    -------
    fO2_log10 : float
        log10(fO2) corresponding to equilibrium between Si, SiO2, and O2.
    """

    # ------------------------------------------------------------
    # Access global functions, constants, and species data
    # ------------------------------------------------------------
    global Gibbs, Si, SiO2, O2, integrate_V_dP, integral_V_vs_P, R_gas, a_SiO2

    # ------------------------------------------------------------
    # 1. EOS parameters for metallic Si
    # ------------------------------------------------------------
    # These constants describe the elastic and thermal behavior of silicon
    # and are used in the Vinet equation of state for ∫V dP calculation.
    V0_cm3 = 9.73        # Reference molar volume [cm³/mol]
    K0 = 44.0            # Bulk modulus [GPa]
    dK0dP = 6.0          # First pressure derivative of bulk modulus
    alpha0 = 8e-5        # Thermal expansion coefficient [1/K]
    gamma0 = 5.1         # Grüneisen parameter (dimensionless)
    kappa = 0.56         # Anderson–Grüneisen parameter (dimensionless)
    Tref = 298.0         # Reference temperature [K]
    R = R_gas            # Gas constant [J/mol/K], defined globally

    # ------------------------------------------------------------
    # 2. Fixed empirical parameters for SiO2 EOS
    # ------------------------------------------------------------
    # Parameters defining an empirical high-pressure–temperature model for SiO2.
    n    = 3
    ze   = 0.0004266056389
    x    = 0.863943304
    te0  = 5651.204964
    el0  = 1e-6
    et   = -0.2783503528
    v_0  = 2.78e-5
    t_0  = 3000.0
    m_0  = 0.91

    # ------------------------------------------------------------
    # 3. ∫VdP for Si using the Vinet EOS
    # ------------------------------------------------------------
    # Compute the integral of volume over pressure (∫V dP) between 0 and P for Si,
    # accounting for thermal effects via the Vinet EOS.
    #
    # The returned integral is converted from cm³·GPa/mol to J/mol by multiplying by 1e3.
    dvdp_Si = 1e3 * integrate_V_dP(p_bar / 1e4, t_k, V0_cm3, K0, dK0dP,
                                   alpha0, gamma0, kappa, Tref)

    # ------------------------------------------------------------
    # 4. ∫VdP for SiO2 using empirical EOS model
    # ------------------------------------------------------------
    # Compute the equivalent ∫V dP correction for SiO2 using a more complex,
    # empirical P–V–T model, where pressure must be expressed in Pa.
    integral_value_SiO2 = integral_V_vs_P(
        p_bar * 1e5, t_k,   # bar → Pa
        n=n, ze=ze, x=x, te0=te0, el0=el0, et=et,
        v_0=v_0, t_0=t_0, m_0=m_0,
        a=a_SiO2, spin_a_0=0, spin_b_0=0
    )

    # ------------------------------------------------------------
    # 5. Gibbs free energies including pressure corrections
    # ------------------------------------------------------------
    # Add the P–V work correction (∫V dP) to the Gibbs free energy at 1 bar
    # to get the total Gibbs energy under the specified P–T conditions.
    G_Si   = Gibbs(t_k, Si)   + dvdp_Si
    # G_Si = gibbs_free_energy_model_2_liquid(t_k) + dvdp_Si
    G_SiO2 = Gibbs(t_k, SiO2) + integral_value_SiO2
    if t_k < 2000:
        G_O2   = Gibbs(t_k, O2lt)
    else:
        G_O2   = Gibbs(t_k, O2ht)

    # ------------------------------------------------------------
    # 6. Reaction ΔG and oxygen fugacity
    # ------------------------------------------------------------
    # Reaction: Si + O2 ⇌ SiO2
    # ΔG_rxn = G(SiO2) - G(Si) - G(O2)
    #
    # At equilibrium:
    #   ΔG_rxn = -R*T*ln(K)
    #   and  K = 1/fO2   →  fO2 = exp(ΔG_rxn / (R*T))
    #
    # The logarithm base 10 is then applied for convenience.
    dG_rxn = G_SiO2 - G_Si - G_O2
    fO2_log10 = np.log10(np.exp(dG_rxn / (R * t_k)))

    # ------------------------------------------------------------
    # 7. Return the log10(fO2)
    # ------------------------------------------------------------
    return fO2_log10


# %%


# %%



