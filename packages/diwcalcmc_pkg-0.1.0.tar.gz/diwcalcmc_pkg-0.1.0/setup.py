from setuptools import setup, find_packages

setup(
    # --- Package Metadata ---
    name='diwcalcmc_pkg',  # The name users will use for 'pip install'
    version='0.1.0',       # Initial version
    author='Olivier Namur',
    author_email='olivier.namur@kuleuven.be',
    description='Monte Carlo simulations for fO2 (Delta IW and Delta Si-SiO2) calculations.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/YourUsername/dIWCalcMC_pkg', # Update this URL!
    license='MIT',

    # --- Package Content ---
    # Scans for the inner 'dIWCalcMC_pkg' directory
    packages=find_packages(),

    # --- Dependencies ---
    install_requires=[
        'numpy',
        'pandas',
        'tqdm',
        'openpyxl',  # pandas needs this to read/write .xlsx files
        # If your activity models (e.g., MAGEMin) rely on other external libraries, list them here.
    ],

    # --- Python Compatibility ---
    python_requires='>=3.9',
    
    # --- Classifiers (Helps users find your package) ---
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Physics',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
)