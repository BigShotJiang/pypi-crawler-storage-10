# 🚀 Rocket Linear Regression

A simple implementation of **Simple Linear Regression** from scratch using only NumPy.  
This package is meant for learning and experimenting with regression models — no scikit-learn required!

---

## 📦 Installation

### 🔹 Install from PyPI

```bash
pip install rocket-linear-regression-moussa
