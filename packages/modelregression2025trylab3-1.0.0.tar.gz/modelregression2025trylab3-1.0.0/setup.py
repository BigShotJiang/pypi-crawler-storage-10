from setuptools import setup, find_packages

setup(
   name='modelregression2025trylab3',
   version="1.0.0",
    author="Moussa Ballou",
    author_email="m.ballou@esi-sba.dz",
    description="A simple linear regression model from scratch",
    packages=find_packages(),
    install_requires=["numpy"],
    python_requires=">=3.8",
)
