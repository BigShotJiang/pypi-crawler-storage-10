# -*- coding: utf-8 -*-
from setuptools import setup

# README.md 파일을 불러오는 기능
with open('README.md', encoding='utf-8') as f:
  long_description = f.read()

setup(
  name='nmsl_dummy_package', # 등록할 패키지 이름 (PyPI에 등록되는 이름)
  version='0.1.0', # 패키지 버전
  description='This is nmsl dummy package.', # 패키지의 짧은 설명
  long_description=long_description, # 패키지의 상세 설명
  long_description_content_type = 'text/markdown', # long_description의 형식
  author='sohyun yang', # 패키지 작성자 이름
  author_email='1234@dgist.ac.kr', # 패키지 작성자 이메일
  url='https://example.com', # 프로젝트의 공식 URL
  license='MIT', # 패키지의 라이선스 정보
  python_requires='>=3.7', # 패키지가 지원하는 Python 버전
  install_requires=[], # 패키지가 의존하는 외부 라이브러리 목록
  packages=['package'], # 포함할 Python 패키지 목록
  package_data={}, # 패키지에 포함할 추가 데이터 목록
  keywords=[], # 패키지 검색 키워드
  classifiers=[
    'Development Status :: 4 - Beta',
    'Intended Audience :: Developers',
    'Programming Language :: Python :: 3',
    'Operating System :: OS Independent',
    'License :: OSI Approved :: MIT License',
  ] # 패키지 분류
)