
# Yuro Labs SDK

This SDK allows developers to deploy models one-click on Modal and test inference through a clean CLI.

## Install

```bash
pip install yurolabs
```

## Login

```bash
yuro login sk_test_123
```

## Deploy

```bash
yuro deploy model.onnx
```

## Test inference

```bash
yuro test "input"
```
