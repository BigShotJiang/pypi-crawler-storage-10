import base64
import requests
from pathlib import Path

from .config import load_base_url, load_key
from .types import Detection, InferenceResult
from .exceptions import (
    AuthenticationError,
    DeploymentError,
    InferenceError,
)


class YuroClient:
    """
    High-level programmatic interface for the Yuro inference platform.
    CLI users should continue using `yuro ...` commands.
    """

    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or load_key()
        self.base_url = base_url or load_base_url()
        if not self.api_key:
            raise AuthenticationError("API key required; run `yuro login`")

    # -----------------------
    # Internal helpers
    # -----------------------
    def _headers(self):
        ret
