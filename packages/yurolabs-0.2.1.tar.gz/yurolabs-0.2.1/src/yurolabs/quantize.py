import torch

def quantize_fp16(src: str, dst: str):
    model = torch.load(src)
    model.half()
    torch.save(model, dst)

def quantize_int8(src: str, dst: str):
    model = torch.load(src)
    model.qconfig = torch.quantization.get_default_qconfig("fbgemm")
    torch.quantization.prepare(model, inplace=True)
    torch.quantization.convert(model, inplace=True)
    torch.save(model, dst)
