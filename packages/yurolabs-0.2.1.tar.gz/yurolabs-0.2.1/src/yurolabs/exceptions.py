class YuroError(Exception):
    pass

class AuthenticationError(YuroError):
    pass

class DeploymentError(YuroError):
    pass

class InferenceError(YuroError):
    pass
