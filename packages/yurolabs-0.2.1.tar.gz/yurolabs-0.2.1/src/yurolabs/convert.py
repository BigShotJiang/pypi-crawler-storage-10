from ultralytics import YOLO

def to_onnx(pt_path: str, onnx_path: str):
    model = YOLO(pt_path)
    model.export(format="onnx", imgsz=640)
    print(f"ONNX saved → {onnx_path}")
