from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Detection:
    class_name: str
    confidence: float
    box: List[float]

@dataclass
class InferenceResult:
    detections: List[Detection]
    image_base64: Optional[str] = None
