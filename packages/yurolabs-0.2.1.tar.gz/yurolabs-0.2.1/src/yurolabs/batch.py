from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from .client import YuroClient

def batch_infer(folder: str, client: YuroClient, workers=4):
    paths = list(Path(folder).glob("*.jpg")) + list(Path(folder).glob("*.png"))

    results = {}
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(client.infer, str(p)): p for p in paths}
        for fut in futures:
            results[str(futures[fut])] = fut.result()
    return results
