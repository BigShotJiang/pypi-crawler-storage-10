"""Functions that operate on functions, this is considered experimental."""

from __future__ import annotations

from functools import cache
from typing import TYPE_CHECKING, Any

from lazy_bear import LazyLoader

from bear_dereth.data_structs.constant import Const
from bear_dereth.sentinels import NOT_FOUND
from bear_dereth.typing_tools.utils import (
    is_bool,
    is_float,
    is_infinite,
    is_instance_of,
    is_int,
    is_list,
    is_mapping,
    is_none,
    is_not_instance,
    is_object,
    is_sequence,
    is_set,
    is_str,
    is_tuple,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    import inspect
    from inspect import isclass, ismodule

    from bear_dereth.typing_tools import LitFalse, LitTrue
else:
    inspect = LazyLoader("inspect")
    isclass, ismodule = LazyLoader("inspect").to("isclass", "ismodule")


def const[T](value: T, *_, **__) -> Const[T]:
    """Create a constant function that always returns the given value.

    Use this when you just need the value to be returned by a function, but
    don't care about the arguments. If you want to have more control over
    the arguments, use the `Const` class directly.

    Args:
        value (Any): The value to be returned by the constant function.

    Returns:
        Callable[..., Any]: A function that takes any arguments and returns the specified value.
    """
    return Const[T](value)


def identity[T](x: T) -> T:
    """Return the input value unchanged.

    Args:
        x (T): The input value.

    Returns:
        T: The same input value.
    """
    return x


def compose(*funcs: Callable) -> Callable:
    """Compose multiple functions into a single function.

    Args:
        *funcs (Callable): Functions to compose. The functions are applied
            from right to left.

    Returns:
        Callable: A new function that is the composition of the input functions.
    """
    if not funcs:
        return identity

    def composed(x: Any) -> Any:
        """Apply the composed functions to the input value."""
        for f in reversed(funcs):
            x = f(x)
        return x

    return composed


def pipe(value: Any, *funcs: Callable) -> Any:
    """Pipe a value through a series of functions.

    Args:
        value (Any): The initial value to be processed.
        *funcs (Callable): Functions to apply to the value in sequence.

    Returns:
        Any: The final result after applying all functions.
    """
    for func in funcs:
        value = func(value)
    return value


def complement(f: Callable[[Any], bool]) -> Callable[[Any], bool]:
    """Return the complement of a predicate function.

    Args:
        f (Callable[[Any], bool]): A predicate function that returns a boolean value.

    Returns:
        Callable[[Any], bool]: A new function that returns the opposite boolean value of the input function.
    """

    def complemented(*args: Any, **kwargs: Any) -> bool:
        return not f(*args, **kwargs)

    return complemented


def has_attrs(seq: object, attrs: Sequence[str], true_only: bool = False) -> dict[str, bool]:
    """Check if an object has all specified attributes.

    Args:
        obj (Any): The object to check.
        attrs (list[str]): A list of attribute names to check for.

    Returns:
        dict[str, bool]: A dictionary mapping each attribute name to a boolean indicating its presence.
    """
    out: dict[str, bool] = {attr: hasattr(seq, attr) for attr in attrs}
    if true_only:
        out = {k: v for k, v in out.items() if v}
    return out


def if_in_list(item: Any, lst: list | tuple) -> bool:
    """Check if an item is in a collection (list, tuple, or set).

    Args:
        item: The item to check for.
        lst: The collection to check within.

    Returns:
        bool: True if the item is in the collection, False otherwise.
    """
    return item in lst


def any_of(*conditions: Callable[..., bool]) -> Callable[..., bool]:
    """Return a function that checks if any of the given conditions are True.

    Args:
        *conditions (Callable[..., bool]): A variable number of predicate functions.

    Returns:
        Callable[..., bool]: A function that returns True if any condition is True.
    """

    def checker(*args: Any, **kwargs: Any) -> bool:
        return any(condition(*args, **kwargs) for condition in conditions)

    return checker


def all_of(*conditions: Callable[..., bool]) -> Callable[..., bool]:
    """Return a function that checks if all of the given conditions are True.

    Args:
        *conditions (Callable[..., bool]): A variable number of predicate functions.

    Returns:
        Callable[..., bool]: A function that returns True if all conditions are True.
    """

    def checker(*args: Any, **kwargs: Any) -> bool:
        return all(condition(*args, **kwargs) for condition in conditions)

    return checker


def none_of(*conditions: Callable[..., bool]) -> Callable[..., bool]:
    """Return a function that checks if none of the given conditions are True.

    Args:
        *conditions (Callable[..., bool]): A variable number of predicate functions.

    Returns:
        Callable[..., bool]: A function that returns True if none of the conditions are True.
    """

    def checker(*args: Any, **kwargs: Any) -> bool:
        return not any(condition(*args, **kwargs) for condition in conditions)

    return checker


def one_of(*conditions: Callable[..., bool]) -> Callable[..., bool]:
    """Return a function that checks if exactly one of the given conditions is True.

    Args:
        *conditions (Callable[..., bool]): A variable number of predicate functions.

    Returns:
        Callable[..., bool]: A function that returns True if exactly one condition is True.
    """

    def checker(*args: Any, **kwargs: Any) -> bool:
        return sum(1 for condition in conditions if condition(*args, **kwargs)) == 1

    return checker


def not_equal_value(obj: Any, value: Any | tuple[Any, ...]) -> bool:
    """Check if an object is not equal to a specific value or any value in a tuple.

    Args:
        obj: The object to check.
        value: The value or tuple of values to compare against.

    Returns:
        bool: True if the object is not equal to the value(s), False otherwise.
    """
    if isinstance(value, tuple):
        return obj not in value
    return obj != value


def equal_value(obj: Any, value: Any | tuple[Any, ...]) -> bool:
    """Check if an object is equal to a specific value or any value in a tuple.

    Args:
        obj: The object to check.
        value: The value or tuple of values to compare against.

    Returns:
        bool: True if the object is equal to the value(s), False otherwise.
    """
    if isinstance(value, tuple):
        return obj in value
    return obj == value


def always_true(*_, **__) -> LitTrue:
    """A function that always returns True."""
    return True


def always_false(*_, **__) -> LitFalse:
    """A function that always returns False."""
    return False


def get_instance(obj: type | Any) -> Any | None:
    """Get an instance of a class or return the object itself if it's not a class.

    Args:
        service (Any): The service class or instance.
    """
    try:
        if inspect.isclass(obj):
            return obj()
        return obj
    except Exception:
        return None


@cache
def n_in_range(n: int, low: int, high: int) -> bool:
    """Check if n is within the inclusive range [low, high].

    Args:
        n: The value to check.
        low: The lower bound of the range.
        high: The upper bound of the range.

    Returns:
        True if n is within the range, else False.
    """
    return low <= n <= high


@cache
def less_than_max(n: int, n_max: int) -> bool:
    """Check if n is less than or equal to n_max.

    Args:
        n: The value to check.
        n_max: The maximum bound.

    Returns:
        True if n is less than or equal to n_max, else False.
    """
    return n <= n_max


def a_or_b(a: Callable, b: Callable, otherwise: Callable | None = None) -> Callable[..., Any]:
    """Return a function that applies either a or b based on the type of the document.

    Depends on whether the document is a mapping or an object.

    Args:
        a: Function to apply if the document is a mapping.
        b: Function to apply if the document is an object.
        otherwise: Function to apply if neither condition is met.

    Returns:
        A function that applies either a or b based on the document type.
    """
    choices: dict[Callable[[Any], bool], Callable[..., Any]] = {
        is_mapping: a,
        is_object: b,
    }

    return mini_dispatch(choices, otherwise)


def mini_dispatch(
    choices: dict[Callable[[Any], bool], Callable[..., Any]],
    otherwise: Callable | None = None,
) -> Callable[..., Any]:
    """A mini dispatcher function.

    A simplified version of a dispatcher that selects a function to apply
    based on a set of conditions.

    Example:
        def is_even(n):
            return n % 2 == 0

        def is_odd(n):
            return n % 2 == 1

        def handle_even(n):
            return f"{n} is even"

        def handle_odd(n):
            return f"{n} is odd"

        def handle_other(n):
            return f"{n} is neither even nor odd"

        choices = {
            is_even: handle_even,
            is_odd: handle_odd,
        }

        func = mini_dispatch(choices, handle_other)

        print(func(4))  # Output: "4 is even"
        print(func(7))  # Output: "7 is odd"
        print(func(3.5))  # Output: "3.5 is neither even nor odd"

    Args:
        choices: A dictionary mapping condition functions to their corresponding action functions.
        otherwise: A function to apply if no conditions match.

    Returns:
        A function that applies the first matching action function based on the conditions.
    """

    def wrapper(doc: Any) -> Any:
        for condition, func in choices.items():
            if condition(doc):
                return func(doc)
        return otherwise(doc) if otherwise else NOT_FOUND

    return wrapper


def monkey[T](cls: T, name: str | None = None) -> Callable[..., T]:
    """Monkey patches class or module by adding to it decorated function.

    Anything overwritten could be accessed via .original attribute of decorated object.

    Example:
        class MyClass:
            def greet(self):
                return "Hello"

        @monkey(MyClass)
        def greet(self):
            return "Hi there!"

        obj = MyClass()
        print(obj.greet())  # Output: Hi there!
        print(obj.greet.original(obj))  # Output: Hello

    Args:
        cls: The class or module to monkey patch.
        name: Optional name for the function being added. If not provided, the original function's
            name will be used.

    Returns:
        A decorator that adds the decorated function to the specified class or module.
    """
    from bear_dereth.stringing import cut_prefix

    if not (isclass(cls) or ismodule(cls)):
        raise TypeError("Attempting to monkey patch non-class and non-module")

    def decorator(value: Any) -> Any:
        func: Any = getattr(value, "fget", value)  # Support properties
        func_name: str = name or cut_prefix(s=func.__name__, prefix=f"{cls.__name__}__")

        func.__name__ = func_name
        func.original = getattr(cls, func_name, None)

        setattr(cls, func_name, value)
        return value

    return decorator


# ruff: noqa: PLC0415

__all__ = [
    "a_or_b",
    "all_of",
    "always_false",
    "always_true",
    "any_of",
    "complement",
    "compose",
    "const",
    "equal_value",
    "get_instance",
    "has_attrs",
    "identity",
    "if_in_list",
    "is_bool",
    "is_float",
    "is_infinite",
    "is_instance_of",
    "is_int",
    "is_list",
    "is_none",
    "is_not_instance",
    "is_sequence",
    "is_set",
    "is_str",
    "is_tuple",
    "less_than_max",
    "mini_dispatch",
    "n_in_range",
    "none_of",
    "not_equal_value",
    "pipe",
]
