"""Utility functions and classes for type checking and type hinting."""

from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping, MutableMapping, Sequence
import math
from types import NoneType
from typing import TYPE_CHECKING, Any, Protocol, TypeGuard

ObjExclude = (
    int
    | float
    | str
    | bool
    | list
    | tuple
    | set
    | bytes
    | bytearray
    | memoryview
    | frozenset
    | Mapping
    | NoneType
    | complex
)
MappingExcludes = list | tuple | set | str | bytes | bytearray
SequenceExclude = Mapping | str | bytes | bytearray


def TypeHint[T](hint: type[T]) -> type[T]:  # noqa: N802
    """Add type hints from a specified class to a base class:

    >>> class Foo(TypeHint(Bar)):
    ...     pass

    This would add type hints from class ``Bar`` to class ``Foo``.

    Args:
        hint: The class to use for type hints.

    Returns:
        A base class with type hints from the specified class during
        type checking, otherwise a generic base class. We use a generic
        base class at runtime instead of object to avoid potential MRO
        conflicts and general generic support issues.
    """
    if TYPE_CHECKING:
        return hint  # This adds type hints for type checkers

    class _TypeHintBase: ...

    return _TypeHintBase


class ArrayLike(ABC):
    """A protocol representing array-like structures (list, tuple, set)."""

    @abstractmethod
    def __iter__(self) -> Any: ...

    @classmethod
    @abstractmethod
    def __subclasshook__(cls, subclass: type) -> bool:
        return hasattr(subclass, "__iter__") and subclass in (list, tuple, set)


class JSONLike(ABC):
    """A protocol representing JSON-like structures (dict, list)."""

    @abstractmethod
    def __setitem__(self, key: Any, value: Any) -> None: ...

    @abstractmethod
    def get(self, key: Any, default: Any = None) -> Any:
        """Get a value by key with an optional default."""

    @classmethod
    @abstractmethod
    def __subclasshook__(cls, subclass: type) -> bool:
        return hasattr(subclass, "__setitem__") and subclass in (dict, list)


class SupportsBool(Protocol):
    """Protocol for return values providing a dedicated truthiness hook."""

    def __bool__(self) -> bool: ...


def is_instance_of(obj: Any, types: type | tuple[type, ...]) -> bool:
    """Check if an obj is an instance of a given type or types.

    Args:
        obj: The obj to check.
        types: The type or tuple of types to check against.

    Returns:
        bool: True if the obj is an instance of the given type(s), False otherwise.
    """
    return isinstance(obj, types)


def is_not_instance(obj: Any, types: type | tuple[type, ...]) -> bool:
    """Check if an obj is not an instance of a given type or types.

    Args:
        obj: The obj to check.
        types: The type or tuple of types to check against.

    Returns:
        bool: True if the obj is not an instance of the given type(s), False otherwise.
    """
    return not isinstance(obj, types)


def isa(*types) -> Callable[..., bool]:
    """Creates a function checking if its argument is of any of given types.

    Args:
        *types: The types to check against.

    Returns:
        A function that checks if its argument is an instance of any of the given types.
    """

    def checker(obj: Any) -> bool:
        return isinstance(obj, types)

    return checker


def is_json_like(instance: Any) -> TypeGuard[JSONLike]:
    """Check if an instance is JSON-like (dict or list)."""
    return isinstance(instance, (dict | list))


def is_array_like(instance: Any) -> TypeGuard[ArrayLike]:
    """Check if an instance is array-like (list, tuple, set)."""
    return isinstance(instance, (list | tuple | set))


def is_mapping(doc: Any) -> TypeGuard[MutableMapping]:
    """Check if a document is a mapping (like a dict)."""
    return isinstance(doc, MutableMapping) or (not isinstance(doc, MappingExcludes) and hasattr(doc, "__getitem__"))


def is_object(doc: Any) -> TypeGuard[object]:
    """Check if a document is a non-mapping object."""
    return not isinstance(doc, ObjExclude) and isinstance(doc, object)


def is_sequence(doc: Any) -> TypeGuard[Sequence]:
    """Check if a document is a sequence (like a list or tuple)."""
    return isinstance(doc, Sequence) and not isinstance(doc, SequenceExclude)


def is_none(obj: Any) -> bool:
    """Check if an obj is None.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is None, False otherwise.
    """
    return obj is None


def is_bool(obj: Any) -> bool:
    """Check if an obj is a bool.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a bool, False otherwise.
    """
    return isinstance(obj, bool)


def is_int(obj: Any, exclude_bool: bool = True) -> bool:
    """Check if an obj is an int.

    Args:
        obj: The obj to check.
        exclude_bool: Whether to exclude bools (subclass of int) from being considered ints.

    Returns:
        bool: True if the obj is an int, False otherwise.
    """
    if exclude_bool:
        return isinstance(obj, int) and not isinstance(obj, bool)
    return isinstance(obj, int)


def is_str(obj: Any) -> bool:
    """Check if an obj is a str.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a str, False otherwise.
    """
    return isinstance(obj, str)


def is_float(obj: Any) -> bool:
    """Check if an obj is a float.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a float, False otherwise.
    """
    return isinstance(obj, float)


def is_infinite(obj: Any) -> bool:
    """Check if an obj is infinite (positive or negative).

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is infinite, False otherwise.
    """
    return isinstance(obj, float) and math.isinf(obj)


def is_list(obj: Any) -> bool:
    """Check if an obj is a list.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a list, False otherwise.
    """
    return isinstance(obj, list)


def is_tuple(obj: Any) -> bool:
    """Check if an obj is a tuple.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a tuple, False otherwise.
    """
    return isinstance(obj, tuple)


def is_set(obj: Any) -> bool:
    """Check if an obj is a set.

    Args:
        obj: The obj to check.

    Returns:
        bool: True if the obj is a set, False otherwise.
    """
    return isinstance(obj, set)


__all__ = [
    "ArrayLike",
    "JSONLike",
    "SupportsBool",
    "TypeHint",
    "is_array_like",
    "is_bool",
    "is_float",
    "is_infinite",
    "is_instance_of",
    "is_int",
    "is_json_like",
    "is_list",
    "is_mapping",
    "is_none",
    "is_not_instance",
    "is_object",
    "is_sequence",
    "is_set",
    "is_str",
    "is_tuple",
    "isa",
]
