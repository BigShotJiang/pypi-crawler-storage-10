"""A set of type aliases and utility functions for type validation and inspection."""

from collections.abc import Callable, Sized
from typing import Any, Literal, NoReturn, TypeGuard

from bear_dereth.typing_tools.utils import (
    ArrayLike,
    JSONLike,
    SupportsBool,
    TypeHint,
    is_array_like,
    is_json_like,
    is_mapping,
    is_object,
)

from .builtin_tools import check_for_conflicts
from .from_type import type_to_str
from .infer import infer_inner_type, infer_type, str_to_bool
from .introspection import (
    find_type_hints,
    get_function_signature,
    introspect_types,
    isinstance_in_annotation,
    not_in_bound,
    resolve_string_to_type,
    type_in_annotation,
)
from .to_type import coerce_to_type, mapping_to_type, str_to_type, value_to_type
from .type_helper import TypeHelper, all_same_type, num_type_params, type_param, validate_type

type LitInt = Literal["int"]
type LitFloat = Literal["float"]
type LitStr = Literal["str"]
type LitBool = Literal["bool"]
type LitList = Literal["list"]
type LitDict = Literal["dict"]
type LitTuple = Literal["tuple"]
type LitSet = Literal["set"]
type LitPath = Literal["path"]
type LitBytes = Literal["bytes"]

StringTypes = LitStr | LitInt | LitFloat | LitBool | LitList | LitDict | LitTuple | LitSet | LitPath | LitBytes

type LitFalse = Literal[False]
type LitTrue = Literal[True]

type OptInt = int | None
type OptFloat = float | None
type OptStr = str | None
type OptBool = bool | None

type OptStrList = list[str] | None
type OptStrDict = dict[str, str] | None

type NoReturnCall = Callable[..., NoReturn]
type TruthReturnedCall = Callable[..., SupportsBool | bool | Sized]
type SupportsTruthiness = SupportsBool | Sized


def has_exception(e: Exception | None) -> TypeGuard[Exception]:
    """Check if an exception is present.

    Args:
        e: The exception to check
    Returns:
        True if an exception is present, False otherwise
    """
    return e is not None


def format_default_value(value: Any) -> str:
    """Format a default value for string representation in code.

    Args:
        value (Any): The value to format.

    Returns:
        str: The formatted string representation of the value.
    """
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int | float)):
        return str(value)
    return repr(value)


__all__ = [
    "ArrayLike",
    "JSONLike",
    "LitBool",
    "LitBytes",
    "LitDict",
    "LitFalse",
    "LitFloat",
    "LitInt",
    "LitList",
    "LitPath",
    "LitSet",
    "LitStr",
    "LitTrue",
    "LitTuple",
    "NoReturnCall",
    "OptBool",
    "OptFloat",
    "OptInt",
    "OptStr",
    "OptStrDict",
    "OptStrList",
    "SupportsTruthiness",
    "TruthReturnedCall",
    "TypeHelper",
    "TypeHint",
    "all_same_type",
    "check_for_conflicts",
    "coerce_to_type",
    "find_type_hints",
    "format_default_value",
    "get_function_signature",
    "has_exception",
    "infer_inner_type",
    "infer_type",
    "introspect_types",
    "is_array_like",
    "is_json_like",
    "is_mapping",
    "is_object",
    "isinstance_in_annotation",
    "mapping_to_type",
    "not_in_bound",
    "num_type_params",
    "resolve_string_to_type",
    "str_to_bool",
    "str_to_type",
    "type_in_annotation",
    "type_param",
    "type_to_str",
    "validate_type",
    "value_to_type",
]
