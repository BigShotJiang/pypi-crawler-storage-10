"""Tools related to string manipulation."""

from .flatten_data import FlattenPower, flatten
from .manipulation import (
    CaseConverter,
    detect_case,
    slugify,
    to_camel,
    to_kebab,
    to_pascal,
    to_screaming_snake,
    to_snake,
    truncate,
)


def to_lines(raw: str) -> list[str]:
    """Return a list of non-empty, stripped lines from the raw data.

    Args:
        raw: The raw string data to be processed.

    Returns:
        A list of non-empty, stripped lines.
    """
    return [line for line in raw.strip().splitlines() if line.strip()]


def cut_prefix(s: str, prefix: str) -> str:
    """Cuts prefix from given string if it's present.

    Args:
        s: The original string.
        prefix: The prefix to cut.

    Returns:
        The string without the prefix if it was present, otherwise the original string.
    """
    return s[len(prefix) :] if s.startswith(prefix) else s


def cut_suffix(s: str, suffix: str) -> str:
    """Cuts suffix from given string if it's present.

    Args:
        s: The original string.
        suffix: The suffix to cut.

    Returns:
        The string without the suffix if it was present, otherwise the original string.
    """
    if not suffix:
        return s
    return s[: -len(suffix)] if s.endswith(suffix) else s


__all__ = [
    "CaseConverter",
    "FlattenPower",
    "cut_prefix",
    "cut_suffix",
    "detect_case",
    "flatten",
    "slugify",
    "to_camel",
    "to_kebab",
    "to_lines",
    "to_pascal",
    "to_screaming_snake",
    "to_snake",
    "truncate",
]
