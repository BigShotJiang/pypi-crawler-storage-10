xhtmlInput = '''
'''
