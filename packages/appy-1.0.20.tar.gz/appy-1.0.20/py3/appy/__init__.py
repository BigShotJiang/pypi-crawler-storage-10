'''Appy is the simpliest way to build complex webapps'''

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Copyright (C) 2007-2025 Gaetan Delannay

# This file is part of Appy.

# Appy is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.

# Appy is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with
# Appy. If not, see <http://www.gnu.org/licenses/>.

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
import pathlib

# Store here the path to the Appy root package, it is often requested
path = pathlib.Path(__file__).parent

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
n = None

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
class Config:
    '''Root of all configuration options for your app'''

    # These options are those managed by the app developer: they are not meant
    # to be edited during the app lifetime by end users. For such "end-user"
    # configuration options, you must extend the appy.model.tool.Tool class,
    # designed for that purpose. In short, this Config file represents the "RAM"
    # configuration, while the unique appy.model.tool.Tool instance within every
    # app contains its "DB" configuration.

    # In your app/__init__.py, create a class named "Config" that inherits from
    # this one and will override some of the atttibutes defined here, ie:

    # import appy
    # class Config(appy.Config):
    #     someAttribute = "someValue"

    # If "someAttribute" is not a standard Appy attribute, this is a way to add
    # your own configuration attributes.

    # If you want to modify existing attributes, like model configuration or
    # user interface configuration (that, if you have used appy/bin/make to
    # generate your app, are already instantiated in attributes "model" and
    # "ui"), after the attribute definition, modify it like this:

    # class Config(appy.Config):
    #     ...
    #     ui.languages = ('en', 'fr')
    #     model.rootClasses = ['MyClass']

    # Place here a appy.server.Config instance defining the configuration
    # of the Appy HTTP server.
    server = n
    # Place here a appy.server.guard.Config instance defining security options
    security = n
    # Place here a appy.database.Config instance defining database options
    database = n
    # Place here a appy.database.log.Config instance defining logging options
    log = n
    # Place here a appy.model.Config instance defining the application model
    model = n
    # Place here a appy.ui.Config instance defining user-interface options
    ui = n
    # When using a SMTP mail server for sending emails from your app, place an
    # instance of class appy.utils.mail.Config in the field below.
    mail = n
    # Place here a appy.server.scheduler.Config instance, defining cron-like
    # actions being automatically triggered.
    jobs = n
    # Place here an instance of appy.server.backup.Config if you want to backup
    # data and logs from a Appy site.
    backup = n
    # Place here a appy.deploy.Config instance defining how to deploy this app
    # on distant servers.
    deploy = n
    # In order to enable Google Analytics on your app, place here an instance of
    # appy.utils.analytics.Analytics.
    analytics = n
    # If you want to call Google Web Services, specify here a Google API key
    googleApiKey = n
    # When using Worldline for online payments, place an instance of class
    # appy.model.fields.worldline.Config in the field below.
    worldline = n
    # When using POD fields for producing documents with appy.pod, place here an
    # instance of appy.model.fields.pod.Config.
    pod = n
    # When the app has an extension, the name of this latter will be stored
    # in the following attribute. Do not set it directly: it must be done via
    # method m_declareExt below. If you use script appy/bin/make to create an
    # ext, a call to declareExt will be present in the generated ext's
    # __init__.py file.
    ext = n
    # An Appy site may communicate with peer sites. Defining peer sites is done
    # by placing, in the following attribute, an instance of appy.peer.Config.
    peers = n

    @classmethod
    def declareExt(class_, path):
        '''Declares an extension to this app, whose path is p_path'''
        name = path.name
        class_.ext = name
        # Add the ext's "static" folder to the static map
        class_.server.static.map[name] = path / 'static'

    @classmethod
    def check(self):
        '''Ensures the config is valid. Called at server startup'''
        # Collect potential warning or info messages
        messages = []
        self.server.check(messages)
        self.server.static.check(messages)
        self.security.check(messages)
        if self.jobs:
            self.jobs.check(messages)
        if self.backup:
            self.backup.check(messages)
        return messages
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
