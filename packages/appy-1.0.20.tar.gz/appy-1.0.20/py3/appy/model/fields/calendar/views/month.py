#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Copyright (C) 2007-2025 Gaetan Delannay

# This file is part of Appy.

# Appy is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.

# Appy is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with
# Appy. If not, see <http://www.gnu.org/licenses/>.

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
import time
from DateTime import DateTime

from appy.px import Px
from appy.ui.criteria import Criteria
from appy.utils import dates as dutils
from appy.model.utils import Object as O
from appy.model.fields.calendar.views import View

#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
class Month(View):
    '''Represents a calendar, monthly view for an individual calendar'''

    # Default month format
    periodFormat = '%Y/%m'

    def __init__(self, o, field):
        # Call the base constructor
        super().__init__(o, field)
        # Determine the month to show
        self.month = self.req.month or self.defaultDateS
        # What is the first day of the month ?
        self.monthDayOne = DateTime(f'{self.month}/01')
        # Set the grid
        self.grid = self.getGrid()
        # Get the surrounding months
        self.around = self.getSurrounding()

    def getOthers(self):
        '''Returns the names of the other views the user may switch to from this
           one.'''
        # All calendars do not allow switching between views (ie, the Picker
        # doesn't allow it).
        if not self.field.switchViews: return
        # Currently, the only view to switch to is "week"
        return [('week', {'day': self.monthDayOne.strftime('%Y-%m-%d')})]

    def getInfo(self, first):
        '''Returns an Object instance representing information about the month
           having this day as p_first day (DateTime object).'''
        text = self.tool.formatDate(first, '%MT %Y', withHour=False)
        return O(id=first.strftime(self.periodFormat), text=text)

    def getGrid(self, period=None):
        '''Creates a list of DateTime objects representing the calendar grid to
           render for the current p_self.month, or the month specified in
           p_period if passed. If p_self is a Month object, it is a list of
           lists (one sub-list for every week; indeed, every week is rendered as
           a row). If p_self is a MonthMulti object, the result is a linear list
           of DateTime objects.'''
        # Month is a string "YYYY/mm"
        month = period or self.month
        currentDay = DateTime(f'{month}/01 UTC')
        currentMonth = currentDay.month()
        isLinear = self.multiple
        r = [] if isLinear else [[]]
        dayOneNb = currentDay.dow() or 7 # This way, Sunday is 7 and not 0
        strictMonths = self.field.strictMonths
        if dayOneNb != 1 and not strictMonths:
            # If I write "previousDate = DateTime(currentDay)", the date is
            # converted from UTC to GMT
            previousDate = DateTime(f'{month}/01 UTC')
            # If the 1st day of the month is not a Monday, integrate the last
            # days of the previous month.
            for i in range(1, dayOneNb):
                previousDate -= 1
                target = r if isLinear else r[0]
                target.insert(0, previousDate)
        finished = False
        while not finished:
            # Insert currentDay in the result
            if isLinear:
                r.append(currentDay)
            else:
                if len(r[-1]) == 7:
                    # Create a new row
                    r.append([currentDay])
                else:
                    r[-1].append(currentDay)
            currentDay += 1
            if currentDay.month() != currentMonth:
                finished = True
        # Complete, if needed, the last row with the first days of the next
        # month. Indeed, we may need to have a complete week, ending with a
        # Sunday.
        if not strictMonths:
            target = r if isLinear else r[-1]
            while target[-1].dow() != 0:
                target.append(currentDay)
                currentDay += 1
        return r

    def getSurrounding(self):
        '''Gets the months surrounding the current one'''
        first = self.monthDayOne
        r = O(next=None, previous=None, all=[self.getInfo(first)])
        # Calibrate p_startDate and p_endDate to the first and last days of
        # their month. Indeed, we are interested in months, not days, but we use
        # arithmetic on days.
        start = self.startDate
        if start: start = DateTime(start.strftime('%Y/%m/01 UTC'))
        end = self.endDate
        if end: end = dutils.Month.getLastDay(end)
        # Get the x months after p_first
        mfirst = first
        i = 1
        selectable = self.field.selectableMonths
        # Get the months in the future
        while i <= selectable:
            # Get the first day of the next *m*onth
            mfirst = DateTime((mfirst + 33).strftime('%Y/%m/01 UTC'))
            # Stop if we are above self.endDate
            if end and mfirst > end:
                break
            info = self.getInfo(mfirst)
            r.all.append(info)
            if i == 1:
                r.next = info
            i += 1
        # Get the x months before p_first
        mfirst = first
        i = 1
        while i <= selectable:
            # Get the first day of the previous month
            mfirst = DateTime((mfirst - 2).strftime('%Y/%m/01 UTC'))
            # Stop if we are below self.startDate
            if start and mfirst < start:
                break
            info = self.getInfo(mfirst)
            r.all.insert(0, info)
            if i == 1:
                r.previous = info
            i += 1
        return r

    def getCellClass(self, date):
        '''What CSS class(es) must apply to the table cell representing p_date
           in the calendar?'''
        r = []
        # We must distinguish between past and future dates
        r.append('odd' if date < self.today else 'even')
        # Week-end days must have a specific style
        if date.aDay() in ('Sat', 'Sun'): r.append('cellWE')
        return ' '.join(r)

    def getEventTypeOnChange(self):
        '''If p_self.field defines a slot map, configure a JS function that will
           update selectable timeslots in the timeslot selector, everytime an
           event type is selected in the event type selector.'''
        return 'updateTimeslots(this)' if self.field.slotMap else ''

    def getSlotsFor(self, eventType):
        '''Returns a comma-separated list of timeslots one may select when
           creating an event of this p_eventType.'''
        slotMap = self.field.slotMap
        if slotMap:
            r = slotMap(self.o, eventType)
            if r:
                return ','.join(r)
        return ''

    def mayAppyCreate(self, c):
        '''Must the "create" button be rendered in the cell corresponding to
           this p_day, for triggering the creation of a Appy object ?'''
        # Do not confuse the creation of an Appy object via a calendar (being
        # enabled by attribute p_field.createObjects) and the creation of
        # calendar events (being determined by field.eventTypes).
        #
        # A calendar event is created within the calendar data structure as
        # stored on the concerned object, while an Appy object is never created
        # in this data structure. It is created in the Appy database as any
        # other Appy object. Creating Appy objects via a calendar view is just
        # proposed as a convenient way to create such objects.
        method = c.field.createObjects
        if not method: return
        # A method is there. Call it.
        o = c.o
        r = method(o, c.date, c.preComputed)
        if not r: return
        # Get the class for which the "create" button must be rendered
        className, attributes = r
        if not className: return
        # Is the user allowed to create instances of this class ?
        class_ = o.model.classes[className]
        cache = o.cache
        key = f'_may_{className}'
        if key in cache:
            may = cache[key]
        else:
            may = cache[key] = o.guard.mayInstantiate(class_)
        if not may: return
        # Complete, when relevant, attributes with the current day
        dateField = class_.fields.get('date')
        if dateField:
            # Set the hour to the current hour, if the field uses the "hour"
            # part.
            if dateField.format == dateField.WITH_HOUR:
                now = time.localtime()
                hour = f'{str(now.tm_hour).zfill(2)}:{str(now.tm_min).zfill(2)}'
                date = DateTime(f"{c.date.strftime('%Y/%m/%d')} {hour}")
            else:
                date = c.date
            attributes.date = date
        # If we are here, an Appy object may be created. Instead of returning
        # True, return a tuple containing the class name and attributes,
        # marshalled in a string (by reusing class Criteria).
        return className, Criteria.dictAsString(attributes.d())

    #- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    #                                  PXs
    #- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    # Month selector
    pxPeriodSelector = Px('''
     <div var="around=view.around;
               iid=str(o.iid);
               name=name|field.name;
               goBack=view.mayGo(back=True);
               goForward=view.mayGo(back=False)">

      <!-- Go to the previous month -->
      <img class="calicon iconS" if="goBack"
           var2="prev=around.previous" title=":prev.text"
           src=":svg('arrow')" style="transform:rotate(90deg)"
           onclick=":f'askMonth({q(iid)},{q(name)},{q(prev.id)})'"/>

      <!-- Go back to the default date -->
      <input type="button" if="goBack or goForward"
        var2="fmt=view.periodFormat;
              sdef=view.defaultDateS;
              disabled=sdef == view.monthDayOne.strftime(fmt);
        label='today' if sdef == view.today.strftime(fmt) else 'go_back'"
        value=":_(label)" disabled=":disabled"
        style=":'color:%s' % ('grey' if disabled else 'black')"
        onclick=":f'askMonth({q(iid)},{q(name)},{q(view.defaultDateS)})'"/>

      <!-- Display the current month and allow to select another one -->
      <select id="monthChooser"
              onchange=":f'askMonth({q(iid)},{q(name)},this.value)'">
       <option for="m in around.all" value=":m.id"
               selected=":m.id == view.month">:m.text</option>
      </select>

      <!-- Go to the next month -->
      <img if="goForward" class="calicon iconS"
           var2="next=around.next" title=":next.text" src=":svg('arrow')"
           style="transform:rotate(270deg)"
           onclick=":f'askMonth({q(iid)},{q(name)},{q(next.id)})'"/>
     </div>''')

    # Popup for adding or updating an event in the month view
    pxEditPopup = Px('''
     <div var="popupId=f'{hook}_edit';
               submitJs=f'new EventPopup(this,`{hook}`,`new`).run(
                           {field.name}_maxEventLength)'"
          id=":popupId" class="popup" align="center">
      <form id=":f'{popupId}Form'" method="post" data-sub="process">
       <input type="hidden" name="actionType" value="createEvent"/>
       <input type="hidden" name="day"/>

       <!-- Choose an event type -->
       <div align="center" id="newEventLabel">:_(field.createEventLabel)</div>
       <select name="eventType" class="calSelect"
               onchange=":view.getEventTypeOnChange()">
        <option value="">:_('choose_a_value')</option>
        <option for="eventType in allowedEventTypes"
                data-slots=":view.getSlotsFor(eventType)"
                value=":eventType">:typeInfo[eventType].name</option>
       </select>

       <!-- Choose a timeslot -->
       <div if="showTimeslots" id="slotZone">
        <label class="calSpan">:_('timeslot')</label> 
        <select if="showTimeslots" name="timeslot" class="calSelect">
         <option for="sname, slot in field.Timeslot.getAllNamed(o, timeslots)"
                 value=":slot.id">:sname</option>
        </select>
       </div>

       <!-- Span the event on several days -->
       <div align="center" class="calSpan" id="spanZone">
        <x>::_('event_span')</x>
        <input type="text" size="1" name="eventSpan"
               onkeypress="return (event.keyCode != 13)"/>
       </div>

       <!-- An optional comment (use a Poor widget) -->
       <div class="calSpan" if="field.useEventComments"
            var2="field=view.Poor(viewCss=None, label='None', width='96%',
                               height='5em', placeholder=_('workflow_comment'));
                  x=field.init(None, 'comment'); name=field.name; value=None;
                  lg=None; inRequest=False; requestValue=None;
                  hostLayout=None">:field.editUni</div>

       <!-- Save and cancel buttons -->
       <input type="button" value=":_('object_save')" onclick=":submitJs"/>
       <input type="button" value=":_('object_cancel')"
              onclick=":f'closePopup({q(popupId)})'"/>
      </form>
     </div>''',

     js='''
       function updateTimeslots(typeSelector) {
         const option = typeSelector.options[typeSelector.selectedIndex],
               slotSelector = typeSelector.form['timeslot'];
         let slots = option.dataset.slots, i = 0, defaultFound = false,
             opt, show;
         if (slots) slots = slots.split(',');
         // Walk all options
         for (opt of slotSelector.options) {
           // Hide or show it. Hide options disabled by the EventPopup class.
           show = ((!slots || slots.includes(opt.value)) && !opt.disabled);
           opt.style.display = (show)? 'block': 'none';
           // Set the first visible option as the selected one
           if (!defaultFound && show) {
             defaultFound = true;
             slotSelector.selectedIndex = i;
           }
           i += 1;
         }
       }''')

    # Popup for removing events in the month view
    pxDelPopup = Px('''
     <div var="popupId=f'{hook}_del'"
          id=":popupId" class="popup" align="center">
      <form id=":f'{popupId}Form'" method="post" data-sub="process">
       <input type="hidden" name="actionType" value="deleteEvent"/>
       <input type="hidden" name="timeslot" value="*"/>
       <input type="hidden" name="day"/>
       <div align="center"
            style="margin-bottom: 5px">:_('action_confirm')</div>

       <!-- Delete successive events ? -->
       <div class="discreet" style="margin-bottom:10px"
            id=":f'{hook}_DelNextEvent'"
            var="cbId=f'{popupId}_cb'; hdId=f'{popupId}_hd'">
         <input type="checkbox" name="deleteNext_cb" id=":cbId"
                onClick="toggleCheckbox(this)"/><input
          type="hidden" id=":hdId" name="deleteNext"/>
         <label lfor=":cbId" class="simpleLabel">:_('del_next_events')</label>
       </div>
       <input type="button" value=":_('yes')"
              onClick=":f'new EventPopup(this,`{hook}`,`del`).run()'"/>
       <input type="button" value=":_('no')"
              onclick=":f'closePopup({q(popupId)})'"/>
      </form>
     </div>''')

    # Render events in a particular calendar cell
    pxEvents = Px('''
     <x if="events">
      <div for="event in events" style="color:grey" if="view.unfiltered(event)">

       <!-- Checkbox for validating the event -->
       <input type="checkbox" checked="checked" class="smallbox"
              if="mayValidate and field.validation.isWish(o, event.eventType)"
              id=":'%s_%s_%s' % (date.strftime('%Y%m%d'), event.eventType,
                                 event.getTimeMark())"
              onclick=":f'onCheckCbCell(this,{q(hook)})'"/>

       <!-- The event name -->
       <x>::event.getName(o, field, timeslots, typeInfo)</x>

        <!-- Edit this particular event -->
        <img if="mayEdit and event.eventType in allowedEventTypes"
             class="calicon iconS" src=":svg('edit')" style="opacity:0"
             onclick=":f'new EventPopup(this,`{hook}`,`edit`,`{dayString}`,
                        `{event.timeslot}`).openEdit(`{okTypes.eventTypes}`,
                        `{okTypes.message}`,null,`{event.eventType}`)'"/>

        <!-- Delete this particular event -->
        <img if="mayDelete and not single" class="calicon iconS"
             src=":svg('deleteS')" style="opacity:0"
             onclick=":f'new EventPopup(this,`{hook}`,`del`,`{dayString}`,
                        `{event.timeslot}`).openDelete()'"/>
      </div>
     </x>

     <!-- Events from other calendars -->
     <x if="others"
        var2="otherEvents=field.Other.getEventsAt(field, date, others,
                                                 typeInfo, view, preComputed)">
      <div for="event in otherEvents"
           style=":f'color:{event.color};font-style:italic'">:event.name</div>
     </x>''')

    # PX rendering a calendar cell
    pxCell = Px('''
     <td var="events=field.getEventsAt(o, date, typeInfo=typeInfo);
              single=events and len(events) == 1;
              spansDays=field.hasEventsAt(o, date+1, events);
              spansDaysJs='true' if spansDays else 'false';
              mayCreate=mayEdit and allowedEventTypes and not field.dayIsFull(o,
                          date, events, timeslots);
              mayDelete=mayEdit and events and field.mayDelete(o, events);
              mayAppyCreate=view.mayAppyCreate(_ctx_);
              okTypes=field.getApplicableEventTypesAt(o, date, eventTypes,
                         preComputed, True) if (mayCreate or mayEdit) else None;
              js='itoggle(this)' if mayEdit or mayAppyCreate else ''"
         class=":cssClasses" style=":cellStyle"
         onmouseover=":js" onmouseout=":js">
      <span>:day</span> 
      <span if="day == 1">:_(f'month_{date.aMonth()}_short')</span>

      <!-- Icon for adding an event -->
      <x if="mayCreate">
       <img class="calicon" style="opacity:0"
            if="okTypes and okTypes.eventTypes" src=":url('plus')"
            var2="freeSlots=field.Timeslot.getFreeAt(o, date, events, timeslots,
                                                     slotIdsStr, True)"
            onclick=":f'new EventPopup(this,`{hook}`,`new`,`{dayString}`,
                       null).openEdit(`{okTypes.eventTypes}`,
                       `{okTypes.message}`,`{freeSlots}`,null)'"/>
      </x>

      <!-- Icon for adding an Appy object -->
      <x if="mayAppyCreate" var2="cname,attrs=mayAppyCreate">
       <img class="calicon" style="opacity:0" src=":url('plus')"
            onclick=":f'postAndClick(`{cname}_add`,`{attrs}`)'"/>
      </x>

      <!-- Icon for deleting event(s) -->
      <img if="mayDelete" class="calicon iconS" style="opacity:0"
           src=":svg('deleteS' if single else 'deleteMany')"
           onclick=":f'new EventPopup(this,`{hook}`,`del`,`{dayString}`,
                     `*`).openDelete({spansDaysJs})'"/>

      <!-- Events -->
      <x>:view.pxEvents</x>

      <!-- Additional info -->
      <x var="info=field.getAdditionalInfoAt(o,date,None,'month',preComputed)"
         if="info">::info</x>
     </td>''')

    # PX rendering a calendar cell in a Picker field
    pxCellPick = Px('''
     <td class=":cssClasses" style=":cellStyle"
         var="exclude=field.mustExclude(o, date, preComputed);
              onEdit=layout == 'edit'">
      <!-- This day cannot be picked and a message must be rendered -->
      <abbr if="isinstance(exclude, str)" title=":exclude"
            class="pickSB">🚫</abbr>

      <!-- This day can be picked -->
      <x if="not exclude"
         var2="hasEvent=field.hasEventAt(o, date, preComputed._ci_)">

       <!-- On edit, render a checkbox -->
       <x if="onEdit" var2="suffix='on' if hasEvent else 'off'">
        <input type="hidden" name=":field.name"
               value=":f'{dayString}_{suffix}'"/>
        <input type="checkbox" class="pickCB" name=":f'cb_{field.name}'"
               id=":dayString" value=":dayString" checked=":hasEvent"
               onchange="updatePicked(this)"/>
       </x>

       <!-- On view, render a symbol -->
       <span if="not onEdit and hasEvent" class="pickSB">✅</span>
      </x>

      <!-- Show the day number, and month name when relevant -->
      <span>:day</span> 
      <span if="day == 1">:_(f'month_{date.aMonth()}_short')</span>
     </td>''')

    # Main PX
    px = Px('''
     <table cellpadding="0" cellspacing="0" width=":field.width"
            class=":field.style" id=":f'{hook}_cal'"
            var="rowHeight=int(field.height/float(len(view.grid)))">

      <!-- 1st row: names of days -->
      <tr height="22px">
       <th for="dayId in field.weekDays"
           width="14%">:namesOfDays[dayId].short</th>
      </tr>

      <!-- The calendar in itself -->
      <tr for="row in view.grid" valign="top" height=":rowHeight">
       <x for="date in row"
          var2="inRange=field.dateInRange(date, view);
                cssClasses=view.getCellClass(date)">

        <!-- Dump an empty cell if we are out of the supported date range -->
        <td if="not inRange" class=":cssClasses"></td>

        <!-- Dump a normal cell if we are in range -->
        <x if="inRange"
           var2="cellWeight='bold' if date.isCurrentDay() else 'normal';
                 cellStyle=f'font-weight:{cellWeight}';
                 dayString=date.strftime(field.dayKey);
                 day=date.day();">:getattr(view, field.monthCell)</x>
       </x>
      </tr>
     </table>

     <!-- Popups for creating, updating or deleting a calendar event -->
     <x if="mayEdit and eventTypes">
      <x>:view.pxEditPopup</x><x>:view.pxDelPopup</x></x>

     <!-- Popup for validating events -->
     <x if="mayEdit and field.validation">:field.validation.pxPopup</x>''',

     css='''.pickCB { margin:0 4px 0 0 }
            .pickSB { padding-right: 0.3em}''')
#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
