# earth_rover_mini_plus_sdk

API for the Earth Rover Mini+. Installable using pip. Documentation coming soon.

## Installation

Windows:
```bash
py -m pip install earth_rover_mini_plus_sdk
```

Unix/MacOS:
```bash
python3 -m pip install earth_rover_mini_plus_sdk
```

## Example Usage

Below is an example of how to use the code.

```python
from earth_rover_mini_plus_sdk import EarthRoverMini
import asyncio, time

async def main():
    rover = EarthRoverMini("192.168.11.1", 8888)
    await rover.connect()

    await rover.safe_ping()
    # await rover.ctrl_packet(60, 0)
    await asyncio.sleep(2)
    # await rover.ctrl_packet(0, 0)
    await rover.move(3, 60, 360)
    await asyncio.sleep(1)
    await rover.imu_mag_read()

    await rover.disconnect()

if __name__ == "__main__":
    asyncio.run(main())
```

# GitHub
GitHub link: https://github.com/SIGRobotics-UIUC/earth_rover_mini_plus_sdk.git
Development Repo: https://github.com/SIGRobotics-UIUC/earth-rover-mini-OpenSource

