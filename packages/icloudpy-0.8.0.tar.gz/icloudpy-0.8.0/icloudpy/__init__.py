"""The iCloudPy library."""

import logging

from icloudpy.base import ICloudPyService  # # noqa: F401

logging.getLogger(__name__).addHandler(logging.NullHandler())
