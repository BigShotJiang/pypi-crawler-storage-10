__all__ = ["get_system_info", "encrypt", "decrypt", "dumps", "loads", "Run"]

try:
    from .PyProtectorX import (
        get_system_info as _info,
        encrypt as _encrypt,
        decrypt as _decrypt,
        dumps as _dumps,
        loads as _loads,
        Run as _run,
    )

    def get_system_info():
        return _info()

    def encrypt(data, password):
        return _encrypt(data, password)

    def decrypt(data, password):
        return _decrypt(data, password)

    def dumps(source):
        return _dumps(source)

    def loads(data):
        return _loads(data)

    def Run(data):
        return _run(data)

except Exception as e:
    import sys
    sys.stderr.write(f"[PyProtectorX] ⚠️ Failed to load native extension: {e}\n")

    def get_system_info():
        return {"version": "3v", "architecture": "fallback", "os": "unknown"}

    def encrypt(data, password):
        raise RuntimeError("Native extension not available")

    def decrypt(data, password):
        raise RuntimeError("Native extension not available")

    def dumps(source):
        raise RuntimeError("Native extension not available")

    def loads(data):
        raise RuntimeError("Native extension not available")

    def Run(data):
        raise RuntimeError("Native extension not available")

