import os
import platform
import tempfile
import ctypes
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BLOBS = {
    ("Linux", "x86_64"): "_blobs/linux-x86_64.enc",
    ("Linux", "aarch64"): "_blobs/linux-aarch64.enc",
    ("Windows", "AMD64"): "_blobs/win-amd64.enc",
    ("Darwin", "arm64"): "_blobs/macos-arm64.enc",
}

def _platform_key():
    raise NotImplementedError("Implement key retrieval (server or local derivation)")

def _select_blob():
    sysname = platform.system()
    machine = platform.machine()
    return BLOBS.get((sysname, machine))

def load_protected_lib():
    blob_rel = _select_blob()
    if not blob_rel:
        raise RuntimeError(f"No binary blob for platform {platform.system()}/{platform.machine()}")
    blob_path = Path(__file__).parent / blob_rel
    if not blob_path.exists():
        raise FileNotFoundError(f"Encrypted blob not found: {blob_path}")

    aes_key = _platform_key()
    raw = blob_path.read_bytes()
    nonce, ct = raw[:12], raw[12:]
    aes = AESGCM(aes_key)
    plain = aes.decrypt(nonce, ct, None)

    suffix = {"Linux": ".so", "Windows": ".dll", "Darwin": ".dylib"}.get(platform.system(), ".so")
    fd, tmp_path = tempfile.mkstemp(suffix=suffix)
    os.write(fd, plain)
    os.close(fd)
    os.chmod(tmp_path, 0o755)

    lib = ctypes.CDLL(tmp_path)
    return lib

