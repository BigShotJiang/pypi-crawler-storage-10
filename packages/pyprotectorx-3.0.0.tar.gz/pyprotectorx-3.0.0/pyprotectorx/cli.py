import argparse
import sys
import time
from pathlib import Path
from rich.console import Console
from rich.table import Table
from . import get_system_info, dumps

console = Console()

def human_size(n):
    for unit in ['B','KB','MB','GB']:
        if n < 1024.0:
            return f"{n:.2f} {unit}"
        n /= 1024.0
    return f"{n:.2f} TB"

def cmd_encrypt(args):
    path = Path(args.file)
    if not path.exists():
        console.print(f"[red]File not found:[/red] {path}")
        sys.exit(2)

    if path.suffix != ".py":
        console.print(f"[red]Unsupported file type:[/red] Only .py files are supported for self-executable generation.")
        sys.exit(3)

    start = time.time()

    try:
        source = path.read_text(encoding="utf-8")
        encrypted_data = dumps(source)
        launcher_code = f"""# Auto-generated protected script by PyProtectorX
from pyprotectorx import Run
Run({repr(encrypted_data)})
"""
        out_path = path.with_stem(path.stem + "_protected")
        out_path.write_text(launcher_code, encoding="utf-8")

        end = time.time()
        table = Table.grid(expand=False)
        table.add_column(justify='left')
        table.add_column(justify='right')
        table.add_row('[green]Input File[/green]', str(path))
        table.add_row('[green]Output File[/green]', str(out_path))
        table.add_row('[green]Original Size[/green]', human_size(len(source.encode('utf-8'))))
        table.add_row('[green]Protected Size[/green]', human_size(len(launcher_code.encode('utf-8'))))
        table.add_row('[green]Time Taken[/green]', f"{(end-start):.3f}s")
        table.add_row('[green]Version[/green]', str(get_system_info().get('version','3v')))
        console.print(table)
        console.print('[bold green]✅ Encryption complete and runnable file created![/bold green]')

    except Exception as e:
        console.print(f"[red]Encryption failed:[/red] {e}")
        sys.exit(4)

def main():
    parser = argparse.ArgumentParser(prog='pyprotectorx', description="PyProtectorX CLI — Encrypt and protect Python source files.")
    sub = parser.add_subparsers()
    p_enc = sub.add_parser('encrypt', help='Encrypt a Python file into a runnable protected .py')
    p_enc.add_argument('file', help='Path to the Python file (.py)')
    p_enc.set_defaults(func=cmd_encrypt)

    args = parser.parse_args()
    if not hasattr(args, 'func'):
        parser.print_help()
        sys.exit(1)
    args.func(args)

if __name__ == '__main__':
    main()

