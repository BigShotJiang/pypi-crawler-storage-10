
# PyProtectorX v3 - Ready-to-build (CLI encrypt only)

This package provides a C extension and a CLI `pyprotectorx encrypt <file>` that:
- Uses internal password generation (no interactive prompt)
- For `.py` files uses `dumps()` (compile+marshal+compress+encrypt+base64|password) and writes that blob to `<file>.py.enc`
- For other files attempts to encrypt bytes using internal `encrypt` and an internally-derived password

Build:
```
python -m pip install -U build setuptools wheel
python -m build
# or quick test
python setup.py build_ext --inplace
pip install -e .
```

Use:
```
pyprotectorx encrypt test.py
```


