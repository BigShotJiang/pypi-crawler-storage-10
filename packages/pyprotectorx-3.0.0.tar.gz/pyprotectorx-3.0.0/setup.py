from setuptools import setup, find_packages

setup(
    name="pyprotectorx",
    version="3.0.0",
    description="PyProtectorX extension and CLI (v3)",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "pyprotectorx=pyprotectorx.cli:main",
        ]
    },
    python_requires=">=3.8",
)
