'''
When the pycmsisdapswitcher package is executed from the CLI: 
    (python -m) pycmsisdapswitcher
or by the debugger debugpy, the __main__.py file is executed; the condition
    if __name__ == "__main__":
is true in this case, so _cli_parser_main() is called
But I could also have a function in __main__ that would be callable after importing __main__:
    from pycmsisdapswitcher import __main__ as main
    main.function()
'''

import sys

from pycmsisdapswitcher.cli_parser import main as _cli_parser_main

if __name__ == "__main__":
    sys.exit(_cli_parser_main())
