'''
A module to retrieve an Intel HEX file for the prompted target from packs.download public server
'''

import contextlib
import logging
import os
import shutil
import tempfile
import zipfile
import zlib
from typing import Generator, List, Tuple
import xml.etree.ElementTree
from xml.etree.ElementTree import Element

import requests
from packaging.version import parse as versionparse
from requests.exceptions import RequestException, Timeout as requestTimeout

from pycmsisdapswitcher.cache_manager import CacheManager
from pycmsisdapswitcher.errors import ServerAccessError
from pycmsisdapswitcher.targets_info import TARGETS_INFO as info

# Named logger
logger = logging.getLogger(__name__)


REQUEST_TIMEOUT_SEC = 5

MICROCHIP_PACK_SERVER_URL = 'https://packs.download.microchip.com'
PACKS_INDEX_URL = MICROCHIP_PACK_SERVER_URL + '/index.idx.gz'
PACK_INDEX_NAMESPACE = 'http://packs.download.atmel.com/pack-idx-atmel-extension'


@contextlib.contextmanager
def _tempdir_manager(dir_prefix: str) -> Generator[str, None, None]:
    '''
    Create a temporary directory inside a calling 'with' block and destroy it when exiting the block
    # NOTE: the calling function gets the path to the temporary directory w/out the called function
    #       terminating (yield used instead of return), hence the Generator annotation.
    '''
    tmpdir = tempfile.mkdtemp(prefix=dir_prefix)
    try:
        yield tmpdir
    finally:
        shutil.rmtree(tmpdir)


def _download_packs_info() -> Tuple[Element, List[str]]:
    '''
    Download from the server the packs index and a list of all packs names

    Raises: ServerAccessError
    '''
    try:
        # Get the packs index (.gzip file)
        response = requests.get(
            PACKS_INDEX_URL, allow_redirects=True, timeout=REQUEST_TIMEOUT_SEC)
        response.raise_for_status()
        # Decompress the packs index into an .xml file
        packs_index_xml = zlib.decompress(response.content,
                                          zlib.MAX_WBITS | 32)
        # Parse the .xml file into an XML tree
        # NOTE: .decode('utf-8') to get a string from bytes, as expected
        packs_index = xml.etree.ElementTree.fromstring(
            packs_index_xml.decode('utf-8'))

        # Now parse the tree looking for the .pdsc (pack descriptor) elements
        # to create a list of all packs retrieving the 'name' attribute in each pdsc element
        # NOTE: the .pdsc elements are namespaced in the XML file, hence the namespace
        #       (defined an an URL) needs to be included in the search
        packs_list = []
        for pack in packs_index.findall('./pdsc'):
            packs_list.append(pack.attrib.get(
                f'{{{PACK_INDEX_NAMESPACE}}}name'))

        return packs_index, packs_list

    except (requestTimeout, RequestException, Exception) as e:
        logger.error("%s: unable to access packs server (%s)", __name__, e)

        raise ServerAccessError("unable to access packs server") from e


def _get_latest_tool_pack_version(tool_pack_name: str, packs_index: Element) -> str:
    all_tool_pack_releases = []

    # Outer loop: iterate over the .pdsc elements with a namespaced name
    # matching tool_pack_name
    # Inner loop: iterate over the release elements (again, namespaced) of
    # the current pack in the outer loop and append a dictionary with two keys,
    # 'version' and 'description' to the all_tool_pack_releases list
    for pack in packs_index.findall(f'./pdsc[@atmel:name="{tool_pack_name}"]',
                                    namespaces={'atmel': PACK_INDEX_NAMESPACE}):
        for release in pack.findall('atmel:releases/atmel:release',
                                    namespaces={'atmel': PACK_INDEX_NAMESPACE}):
            all_tool_pack_releases.append({'version': release.attrib.get('version'),
                                           'description': list(release)[0].text})

    # Find the latest version of the tool pack for the prompted target on the packs server
    # NOTE: tool pack versions follow the SemVer notation: Major.Minor.Patch
    # hence the need for versionparse from the packaging library
    latest_version = all_tool_pack_releases[0]['version']
    for release in all_tool_pack_releases:
        if versionparse(release['version']) > versionparse(latest_version):
            latest_version = release

    return latest_version


def _download_tool_pack_as_zip(toolpack_name: str, latest_version: str,
                               toolpack_tempdir_path: str) -> str:
    '''
    Download from the server the latest tool pack (.zip file) in a temporary directory
    :return: the name (full path) of the .zip file
    # NOTE: because of the size of the toolpack, download is set to happen in streamed chunks
            instead of immediately as it was done in _download_packs_info()
    Raises: ServerAccessError
    '''
    toolpack_url = f"{MICROCHIP_PACK_SERVER_URL}/Microchip.{toolpack_name}.{latest_version}.atpack"
    try:
        response = requests.get(toolpack_url, allow_redirects=True, stream=True,
                                timeout=REQUEST_TIMEOUT_SEC)
        response.raise_for_status()

        file_name = f"{toolpack_tempdir_path}/{toolpack_name}.{latest_version}.zip"
        with open(file_name, 'wb') as file_content:
            for chunk in response.iter_content(chunk_size=128):
                file_content.write(chunk)
            # NOTE: another example (like _tempdir_manager()) of a context manager;
            #       here the resource is The .zip file, closed exiting the 'with' block

        return file_name
    except (requestTimeout, RequestException, Exception) as e:
        logger.error("%s: unable to access packs server (%s)", __name__, e)

        raise ServerAccessError("unable to access packs server") from e


def extract_file_from_tool_pack_zip(
    file_name: str,
    zipfile_name: str,
    toolpack_tempdir_path: str
) -> str:
    '''
    Extract from the tool pack zip file the requested file

    Raises: ServerAccessError
    '''
    with zipfile.ZipFile(zipfile_name) as tool_pack_zip_file:
        file_path = None

        for name in tool_pack_zip_file.namelist():
            if file_name == os.path.basename(name):
                tool_pack_zip_file.extract(name,
                                           path=toolpack_tempdir_path)
                file_path = os.path.join(toolpack_tempdir_path,
                                         name)
                break

        if not file_path:
            logger.error("%s: application file %s not found",
                         __name__, file_name)

            raise ServerAccessError(f"application file {file_name} not found")
        return file_path


def download_file(target: str, fw_type=None) -> str:
    '''
    Retrieves the file from the server and saves it to the cache

    Returns: the path (in cache) to the file

    Raises: ServerAccessError, CacheAccessError
    '''
    toolpack_name = info[target].toolpack_name

    if fw_type == 'boot':
        file_name = info[target].file_name.boot
    elif fw_type == 'mplab':
        file_name = info[target].file_name.app_mplab
    else:
        file_name = info[target].file_name.app_cmsis

    packs_index, packs_list = _download_packs_info()

    if toolpack_name not in packs_list:
        logger.error("%s: required toolpack not found", __name__)

        raise ServerAccessError("required toolpack not found")

    toolpack_latest_version = _get_latest_tool_pack_version(toolpack_name,
                                                            packs_index)

    with _tempdir_manager('toolpack_from_server') as toolpack_tempdir_path:
        # Download from the server the latest tool pack in a temporary directory
        # Find in the downloaded pack the requested file and return it as an IntelHex object
        # NOTE: the temporary directory will be destroyed exiting the with block
        zipfile_name = _download_tool_pack_as_zip(toolpack_name, toolpack_latest_version,
                                                  toolpack_tempdir_path)

        file_path = extract_file_from_tool_pack_zip(file_name,
                                                    zipfile_name,
                                                    toolpack_tempdir_path)

        logger.debug("File %s found in %s tool pack version %s",
                     file_name, toolpack_name, toolpack_latest_version)

        if file_name in ('boot.hex', 'app.hex'):
            # Rename file before saving to cache
            directory, file_name = os.path.split(file_path)
            new_file_name = target + '_' + file_name
            new_file_path = os.path.join(directory, new_file_name)
            os.rename(file_path, new_file_path)

            logger.debug(
                "file %s renamed to %s before saving it to cache", file_name, new_file_name)

            file_path = new_file_path

        cache_manager = CacheManager()

        cache_manager.check_create_cache()

        cache_manager.put_file(file_path)

        return os.path.join(cache_manager.get_cache_dir(), os.path.basename(file_path))


def extract_hex_from_atpack(atpack_path: str, hex_filename: str) -> str:
    """
    Unzips the .atpack file and extracts the .hex file with the given name from 'firmware/' subfolder,
    placing it in the same directory as the .atpack file.

    :Raises: FileNotFoundError if not found
    """
    extract_to = os.path.dirname(atpack_path) or "."
    firmware_subdir = f"firmware/{hex_filename}"

    with zipfile.ZipFile(atpack_path, 'r') as zf:
        # Check if the .hex file exists inside firmware/
        if firmware_subdir not in zf.namelist():
            raise FileNotFoundError(
                f"{hex_filename} not found in firmware/ subfolder of {atpack_path}"
            )
        # Extract to the same directory as the .atpack file
        zf.extract(firmware_subdir, extract_to)
        # Build the full path to the extracted file (may be in a subdirectory)
        extracted_file_path = os.path.join(extract_to, firmware_subdir)
        if os.path.exists(extracted_file_path):
            return extracted_file_path

        # Fallback: join by filename only
        alt_path = os.path.join(extract_to, hex_filename)
        if os.path.exists(alt_path):
            return alt_path

        # Raise error
        raise FileNotFoundError(
            f"Extraction failed, {hex_filename} present in archive but not found after extraction"
        )
