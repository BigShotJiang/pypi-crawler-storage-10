'''
Helper module to create and access the bootloader or application files cache
'''
import logging
import os
import shutil
from pathlib import Path

from pycmsisdapswitcher.errors import CacheAccessError

# Named logger
logger = logging.getLogger(__name__)


class CacheManager:
    '''
    Manages a local file cache.

    The CacheManager handles creating, reading, and saving files within a
    dedicated cache directory.
    It ensures that the directory exists, permits putting new files into the cache,
    and allows retrieval of cached files by name.

    Attributes:
        SWITCHER_CACHE (str): Name of the cache directory.
        cache_dir (Path): Path to the cache directory.

    Methods:
        get_cache_dir(): Returns the Path object for the cache directory.
        check_create_cache(): Ensures the cache directory exists; creates it if not.
        put_file(src_file_path): Copies a file into the cache directory,
            overwriting if it exists.
        get_file(file_name): Retrieves a file path from the cache by its name.

    Raises:
        CacheAccessError: For errors related to cache access, directory creation, or missing files.
    '''
    SWITCHER_CACHE = 'cmsis_switcher_cache'

    def __init__(self):
        self.cache_dir = Path.home() / self.SWITCHER_CACHE

    def get_cache_dir(self) -> Path:
        '''
        Returns:
            the Path object representing the cache directory.
        '''
        return Path.home() / self.SWITCHER_CACHE

    def check_create_cache(self) -> None:
        '''
        Checks if the cache directory exists; creates it if not

        Raises:
            CacheAccessError: If directory creation fails due to permissions or other issues.
        '''
        try:
            if not self.cache_dir.exists():
                self.cache_dir.mkdir(parents=True, exist_ok=True)
                logger.debug("created cache at %s", self.cache_dir)
        except PermissionError as e:
            logger.error(
                "%s: unable to create cache directory (permission denied)", __name__)

            raise CacheAccessError("unable to create cache directory") from e

    def put_file(self, src_file_path: str) -> None:
        '''
        Saves a file into the cache, replacing if a file w/ the same name exists

        Args:
            src_file_path (str): Path to the source file to be cached.
        '''
        dest_file = os.path.join(self.cache_dir,
                                 os.path.basename(src_file_path))

        shutil.copy2(src_file_path, dest_file)

        logger.debug("File %s saved to cache", os.path.basename(src_file_path))

    def get_file(self, file_name: str) -> str:
        '''
        Retrieve the path of a file in the cache

        Args:
            file_name (str): Name of the file to find in the cache

        Returns:
            str: Absolute path to the cached file

        Raises:
            CacheAccessError: If the file is not found or cache does not exist.
        '''
        if self.cache_dir.exists():
            path_in_cache = os.path.join(self.cache_dir, file_name)

            if Path(path_in_cache).is_file():
                logger.debug("File %s found in cache", file_name)

                return path_in_cache

            logger.error("%s: file %s not found in cache", __name__, file_name)

            raise CacheAccessError(f"file {file_name} not found in cache")

        logger.error("%s: no cache found", __name__)

        raise CacheAccessError("no cache found")
