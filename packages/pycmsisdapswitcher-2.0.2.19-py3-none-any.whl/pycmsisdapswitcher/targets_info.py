'''
Supported targets info
# NOTE: the 'boot_cache' and 'app_mplab_cache' keys exist because the bootloader file name 
        and the mplab type application file names had to be changed from the ones
        in the tool pack to be unique in the cache
# NOTE: ICD 5, ICD 4 and ICE 4 have no CMSIS-DAP v2 application firmware implementation
        The corresponding entries in the dictionary still need a value (consistent with 
        the current naming conventions) for the software to look for those files in the 
        Microchip Packs Repository (and fail with a ServerAccessError)
'''

from typing import Optional, Tuple, Union, Dict
from dataclasses import dataclass
import textwrap

VIDs = {
    'MCHP': 0x04D8,
    'ATMEL': 0x03EB,
}


@dataclass
class FileNames:
    """
    Represents the filenames for different firmware images related to a target device.
    """
    boot: str
    boot_cache: str
    app_mplab: str
    app_mplab_cache: str
    app_cmsis: str


@dataclass
class PIDs:
    """
    Stores USB Product IDs (PIDs) for different firmware modes of a target device.
    """
    mplab_boot_pid: Optional[Union[int, Tuple[int, ...]]]
    mplab_app_pid: Optional[Union[int, Tuple[int, ...]]]
    cmsis_app_pid: Optional[Union[int, Tuple[int, ...]]] = None
    cmsis_v2_app_pid: Optional[Union[int, Tuple[int, ...]]] = None


@dataclass
class TargetInfo:
    """
    Encapsulates information about a hardware target device, including display name,
    supporting toolpack, firmware filenames, recovery instructions, and USB product IDs.
    """
    target_output_name: str
    toolpack_name: str
    file_name: FileNames
    howto: str
    pids: PIDs


TARGETS_INFO: Dict[str, TargetInfo] = {
    'pickitbasic': TargetInfo(
        target_output_name='PICkit Basic',
        toolpack_name='PICkitBasic_TP',
        file_name=FileNames(
            boot='pickit_basic_boot.hex',
            boot_cache='pickit_basic_boot.hex',
            app_mplab='pickit_basic_app.hex',
            app_mplab_cache='pickit_basic_app.hex',
            app_cmsis='pickit_basic_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the type C USB cable to the PICkit Basic and then plug the other end of the USB cable into your computer
            2) Locate the recovery button on the top left corner of the PICkit Basic front, where the PICkit Basic icon is
            3) Using a straightened paper clip, push on the recovery button for at least 4 seconds and then release the button
            4) Wait at least 10 seconds
            The PICkit Basic will now be in the recovery boot mode. Both of its LEDs should be off
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9057,
            mplab_app_pid=(0x9054, 0x9055, 0x9056),
            cmsis_v2_app_pid=(0x90AB, 0x90AC, 0x90AD, 0x90AE)
        ),
    ),
    'evalboard': TargetInfo(
        target_output_name='evaluation board',
        toolpack_name='PKOB4_TP',
        file_name=FileNames(
            boot='pkob4_boot.hex',
            boot_cache='pkob4_boot.hex',
            app_mplab='pkob4_app.hex',
            app_mplab_cache='pkob4_app.hex',
            app_cmsis='pkob4_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the USB cable to the debug connector on the evaluation board and then plug the other end of the USB cable into your computer
            2) Locate the recovery jumper on the board back. Please note that the location of this jumper may vary from
            board to board. Please refer to the documentation for a particular board if in doubt
            3) Using small tweezers or a piece of wire, connect (short) the two holes of the recovery jumper for at least 4 seconds
            4) Remove the tweezers or piece of wire and then wait at least 10 seconds
            The evaluation board will now be in the recovery boot mode.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x810A,
            mplab_app_pid=(0x8109, 0x810B, 0x810C, 0x810D),
            cmsis_app_pid=0x2175,
            cmsis_v2_app_pid=(0x904A, 0x904B, 0x904C, 0x904D)
        ),
    ),
    'snap': TargetInfo(
        target_output_name='Snap',
        toolpack_name='Snap_TP',
        file_name=FileNames(
            boot='snap_boot.hex',
            boot_cache='snap_boot.hex',
            app_mplab='snap_app.hex',
            app_mplab_cache='snap_app.hex',
            app_cmsis='snap_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the USB cable to the debug connector on the Snap and then plug the other end of the USB cable into your computer
            2) Locate the recovery jumper on the Snap back, where the Snap icon is. Please refer to the Snap documentation if in doubt
            3) Using small tweezers or a piece of wire, connect (short) the two holes of the recovery jumper for at least 4 seconds
            4) Remove the tweezers or a piece of wire and then wait at least 10 seconds
            The Snap will now be in the recovery boot mode. Both of its LEDs should be off
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9019,
            mplab_app_pid=(0x9018, 0x901C, 0x901E, 0x9029),
            cmsis_v2_app_pid=0x90B1
        ),
    ),
    'pickit5': TargetInfo(
        target_output_name='PICkit 5',
        toolpack_name='PICkit5_TP',
        file_name=FileNames(
            boot='boot.hex',
            boot_cache='pickit5_boot.hex',
            app_mplab='app.hex',
            app_mplab_cache='pickit5_app.hex',
            app_cmsis='pickit5_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the USB cable to the PICkit 5 and then plug the other end of the USB cable into your computer
            2) Locate the recovery button close to the USB connector on the PICkit 5
            3) Using a straightened paper clip, push on the recovery button for at least 4 seconds
            4) Release the recovery button and then wait at least 10 seconds
            5) Unplug the PICkit 5, wait at least 2 seconds then plug the PICkit 5 back into your computer
            The PICkit5 will now be in the recovery boot mode. The indicator light strip will be off.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9035,
            mplab_app_pid=0x9036,
            cmsis_v2_app_pid=0x90B0
        ),
    ),
    'icd5': TargetInfo(
        target_output_name='ICD5',
        toolpack_name='ICD5_TP',
        file_name=FileNames(
            boot='boot.hex',
            boot_cache='icd5_boot.hex',
            app_mplab='app.hex',
            app_mplab_cache='icd5_app.hex',
            app_cmsis='icd5_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the type C USB cable to the ICD5 and then plug the other end of the USB cable into your computer
            2) Locate the recovery button on the ICD5 back
            3) Using a straightened paper clip, push on the recovery button for at least 4 seconds and then release the button
            4) Wait at least 10 seconds
            The ICD5 will now be in the recovery boot mode. The indicator light strip should be off.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9037,
            mplab_app_pid=(0x9038, 0x903F),
            cmsis_v2_app_pid=None
        ),
    ),
    'icd4': TargetInfo(
        target_output_name='ICD4',
        toolpack_name='ICD4_TP',
        file_name=FileNames(
            boot='boot.hex',
            boot_cache='icd4_boot.hex',
            app_mplab='app.hex',
            app_mplab_cache='icd4_app.hex',
            app_cmsis='icd4_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Unplug all power (USB and external adapter) from ICD 4
            2) Insert a metal screwdriver into the 9V barrel jack, making contact with both the center pin and metal tang
            3) Reconnect the USB cable while the screwdriver is still in the jack
            4) Watch the LEDs:
            When both LEDs flash quickly, immediately remove the screwdriver (within 1 second)
            5) Check LEDs:
            Purple (steady): Recovery mode entered.
            Blue: Repeat steps 1–4.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9015,
            mplab_app_pid=0x9015,
            cmsis_v2_app_pid=None
        ),
    ),
    'ice4': TargetInfo(
        target_output_name='ICE4',
        toolpack_name='ICE4_TP',
        file_name=FileNames(
            boot='ice4_boot.hex',
            boot_cache='ice4_boot.hex',
            app_mplab='ice4_app.hex',
            app_mplab_cache='ice4_app.hex',
            app_cmsis='ice4_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the 9V power supply cable to the ICE4
            2) Locate the recovery button on the ICE4 back
            3) Using a straightened paper clip, push on the recovery button for at least 4 seconds and then release the button
            4) Wait at least 10 seconds
            The ICE4 will now be in the recovery boot mode. The indicator light strip should be off.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x901F,
            mplab_app_pid=(0x9020, 0x9021, 0x9022, 0x9023),
            cmsis_v2_app_pid=None
        ),
    ),
    'pickit4': TargetInfo(
        target_output_name='PICkit4',
        toolpack_name='PICkit4_TP',
        file_name=FileNames(
            boot='boot.hex',
            boot_cache='pickit4_boot.hex',
            app_mplab='app.hex',
            app_mplab_cache='pickit4_app.hex',
            app_cmsis='pickit4_app_cmsis-dap.hex',
        ),
        howto=textwrap.dedent('''\
            1) Connect the USB cable to the PICkit4 and then plug the other end of the USB cable into your computer
            2) Locate the recovery button close to the USB connector on the PICkit4
            3) Using a straightened paper clip, push on the recovery button for at least 4 seconds
            4) Release the recovery button and then wait at least 10 seconds
            The PICkit4 will now be in the recovery boot mode. The indicator light strip should be off.
        '''),
        pids=PIDs(
            mplab_boot_pid=0x9017,
            mplab_app_pid=(0x9012, 0x901B, 0x901D, 0x9028),
            cmsis_v2_app_pid=0x90AF
        ),
    ),
}
