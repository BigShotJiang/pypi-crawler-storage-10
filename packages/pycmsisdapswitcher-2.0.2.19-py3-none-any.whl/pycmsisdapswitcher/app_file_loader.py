'''
Helper module: loads the new firmware file into the target
'''
import os
import sys
import time
import math
import zlib
import array
import struct
import threading
import logging
from typing import Tuple

import usb.core
from intelhex import IntelHex
from tqdm import tqdm

from pycmsisdapswitcher.targets_info import (
    TARGETS_INFO as targets_info,
    VIDs
)
from pycmsisdapswitcher.errors import AppFileLoaderError

# Named logger
logger = logging.getLogger(__name__)


# Named constants
commands = {
    'ENTER_BOOT_MODE': 0xEB,
    'JUMP_TO_APP': 0xEC,
    'ERASE_FLASH': 0xE2,
    'ERASE_APPLICATION': 0xFA,
    'WRITE_PAGE': 0xE3,
    'READ_CRC32': 0xE5,
    'SOFTWARE_RESET': 0xED,
}

endpoints_numbers = {
    # NOTE: directions referred to the host
    'COMMAND_OUT_MPLAB_FW_TYPE': 0x02,
    'COMMAND_OUT_CMSIS_DAP_V2_FW_TYPE': 0x01,
    'COMMAND_OUT_MPLAB_BOOT': 0x02,
    'COMMAND_IN_MPLAB_BOOT': 0x81,
}

usb_transmit_offsets = {
    'COMMAND_OPCODE': 0,
    'FIRST_ARGUMENT': 1,
    'SECOND_ARGUMENT': 13,
}

usb_receive_offsets = {
    'COMMAND_OPCODE_ECHO': 0,
    'ERASE_FLASH_ERROR_CODE': 2,
    'WRITE_PAGE_ERROR_CODE': 13,
}

timeouts_ms = {
    'USB_COMM': 4_000,
    'USB_ENUM': 30_000,
    'USB_DE_ENUM': 30_000,
    'ERASE_FLASH': 60_000,
    'WRITE_FLASH_PAGE': 1_000,
    'READ_CRC32': 5_000,
}

BOOTLOADER_IMAGE_SIZE_IN_BYTES = 48 * 1024
APPLICATION_IMAGE_SIZE_IN_BYTES = (
    2 * 1024 * 1024) - BOOTLOADER_IMAGE_SIZE_IN_BYTES
BOOTLOADER_IMAGE_CRC_BASE_ADDRESS = BOOTLOADER_IMAGE_SIZE_IN_BYTES - 4
APPLICATION_IMAGE_CRC_BASE_ADDRESS = APPLICATION_IMAGE_SIZE_IN_BYTES - 4
ERASE_STATUS_SIZE_IN_BYTES = 3
WRITE_PAGE_STATUS_SIZE_IN_BYTES = 14
NO_COMMAND_ERROR = 0
FLASH_PAGE_SIZE_IN_BYTES = 512
APPLICATION_START_ADDRESS = 0x0040_C000
WRITE_FLASH_PAGE_COMMAND_SIZE_IN_BYTES = 525
FLASH_ADDRESS_SIZE_IN_BYTES = 4
READ_CRC32_STATUS_SIZE_IN_BYTES = 256
CRC32_SIZE_IN_BYTES = 4


class FWFileLoader:  # pylint: disable=too-few-public-methods
    '''
    Provides methods to load the new firmware file into the target
    '''

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    def __init__(self,
                 target: str,
                 usb_device: usb.core.Device,
                 current_fw_type: str,
                 new_fw_file_path: str,
                 new_fw_type: str) -> None:
        self.target = target
        self.usb_device = usb_device
        self.current_fw_type = current_fw_type
        self.new_fw_file_path = new_fw_file_path
        self.new_fw_type = new_fw_type

    def _get_pid_dictionary_keys(self, what: str) -> Tuple[str, str]:
        '''
        Sets PID dictionary keys and sub-keys
        # NOTE: the application PIDs are tuples, while the bootloader has an unique PID
        '''

        target_key = self.target

        if what == 'mplab_app':
            target_subkey = "mplab_app_pid"
        elif what == 'cmsis_v2_app':
            target_subkey = "cmsis_v2_app_pid"
        else:
            target_subkey = "mplab_boot_pid"

        return target_key, target_subkey

    def _did_it_de_enumerate(self, what: str):
        '''
        Keeps finding the target in application or boot mode until it disappears or time-out happens
        :return: True if application or boot de-enumerated in time, else (timeout) False
        '''

        # Get PID dictionary keys and sub-keys
        # NOTE: the application PIDs are tuples, while the bootloader has an unique PID
        target_key, target_subkey = self._get_pid_dictionary_keys(what)

        start_time_s = time.perf_counter()  # In fractional seconds

        it_de_enumerated = False

        while not it_de_enumerated:
            value = getattr(targets_info[target_key].pids, target_subkey)

            if isinstance(value, tuple):
                device_list = []

                for pid in value:
                    self.usb_device = usb.core.find(

                        idVendor=VIDs['MCHP'],
                        idProduct=pid,
                        find_all=False)

                    if self.usb_device:
                        device_list.append(self.usb_device)

                if len(device_list) == 0:
                    it_de_enumerated = True
                    break
            else:
                self.usb_device = usb.core.find(

                    idVendor=VIDs['MCHP'],

                    idProduct=getattr(
                        targets_info[target_key].pids, target_subkey),
                    find_all=False)

                if not self.usb_device:
                    it_de_enumerated = True
                    break

            elapsed_time_s = time.perf_counter() - start_time_s
            if elapsed_time_s >= timeouts_ms['USB_DE_ENUM'] / 1_000:
                break

        return it_de_enumerated

    def _find_usb_device_with_config(self, vid, pid) -> bool:
        """
        Attempts to find the USB device with given VID/PID and check active configuration.
        Returns True if device found and has active configuration.
        """
        self.usb_device = usb.core.find(
            idVendor=vid, idProduct=pid, find_all=False)
        if not self.usb_device:
            return False

        try:
            configuration = self.usb_device.get_active_configuration()
            if configuration:
                return True
        except (usb.core.USBError, NotImplementedError):
            return False

        return True

    def _did_it_enumerate(self, what: str) -> bool:
        '''
        Keeps looking for the target in application or boot mode until it finds it or times-out
        :return: True if the application or boot enumerated in time, else (timeout) False
        '''
        # Get PID dictionary keys and sub-keys
        # NOTE: the application PIDs are tuples, while the bootloader has an unique PID
        target_key, target_subkey = self._get_pid_dictionary_keys(what)

        start_time_s = time.perf_counter()  # In fractional seconds

        do_loop = True
        pid_enumerated = False

        while do_loop:
            elapsed_time_s = time.perf_counter() - start_time_s
            if elapsed_time_s >= timeouts_ms['USB_ENUM'] / 1_000:
                break

            # Always store PIDs as a tuple so pid_sequence is iterable
            # NOTE: uses a Python conditional expression aka ternary operator
            pid_sequence = (value if isinstance(value := getattr(
                targets_info[target_key].pids, target_subkey), tuple) else (value,))

            for pid in pid_sequence:
                pid_enumerated = self._find_usb_device_with_config(
                    VIDs['MCHP'], pid)
                if pid_enumerated:
                    #                    has_active_configuration = True
                    do_loop = False
                    break

        return pid_enumerated

    def _enter_boot_mode_mplab(self) -> None:
        '''
        Sends to mplab type application the command to enter boot mode

        Raises: AppFileLoaderError
        '''
        command = bytearray(1)  # USB comm expects a sequence of bytes
        command[usb_transmit_offsets['COMMAND_OPCODE']
                ] = commands['ENTER_BOOT_MODE']

        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_MPLAB_FW_TYPE'],
                                                      command,
                                                      timeouts_ms['USB_COMM'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s entering boot mode error (%s)",
                         __name__, self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} entering boot mode error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s entering boot mode error ())write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} entering boot mode error: write to endpoint size mismatch")

        if not self._did_it_de_enumerate('mplab_app'):
            logger.error(
                "%s: %s entering boot mode error (the application didn't de-enumerate)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} entering boot mode error: the application didn't de-enumerate")

        if self._did_it_enumerate('boot'):
            logger.debug("%s entered bootloader mode", self.target)
        else:
            logger.error(
                "%s: %s bootloader mode not entered", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} bootloader mode not entered")

    def _enter_boot_mode_cmsisv2(self) -> None:
        '''
        Sends to cmsisv2 type application the command to enter boot mode,

        Raises: AppFileLoaderError
        '''

        command_tuple = (0x80, 0x11, 0x00, 0x0B, 0x0E, 0x00,
                         0x01, 0x00, 0x01, 0x50, 0x00, 0x31, 0x72, 0x7C, 0x10)
        command = bytearray(command_tuple)

        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_CMSIS_DAP_V2_FW_TYPE'],
                                                      command,
                                                      timeouts_ms['USB_COMM'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s entering boot mode error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} entering boot mode error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s entering boot mode error (write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(f"{self.target} entering boot mode error: "
                                     "write to endpoint size mismatch")

        if not self._did_it_de_enumerate('cmsis_v2_app'):
            logger.error(
                "%s: %s entering boot mode error (the application didn't de-enumerate)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} entering boot mode error: the application didn't de-enumerate")

        if self._did_it_enumerate('boot'):
            logger.debug("%s entered bootloader mode", self.target)
        else:
            logger.error(
                "%s: %s bootloader mode not entered", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} bootloader mode not entered")

    def _enter_boot_mode(self) -> None:
        '''
        Sends to the target the command to enter boot mode, de-enumerating from app mode,

        Raises: AppFileLoaderError

        # NOTE: boot mode is persistent (power cycling won't exit it)
        '''

        if self.current_fw_type == 'mplab':
            self._enter_boot_mode_mplab()
        else:
            self._enter_boot_mode_cmsisv2()

    def _jump_to_app_mplab_boot(self):
        '''
        Sends to the target in MPLAB type bootloader mode
        the command to enter app_type mode, de-enumerating from boot mode

        Raises: AppFileLoaderError

         # NOTE: app mode is persistent (power cycling won't exit it)
        '''
        if self.new_fw_type == 'mplab':
            fw_type = "mplab_app"
        else:
            fw_type = "cmsis_v2_app"

        command = bytearray(1)  # USB comm expects a sequence of bytes
        command[usb_transmit_offsets['COMMAND_OPCODE']
                ] = commands['JUMP_TO_APP']

        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_MPLAB_FW_TYPE'],
                                                      command,
                                                      timeouts_ms['USB_COMM'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s jumping to application command error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} jumping to application command error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s jumping to application command error (write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(
                F"{self.target} jumping to application command error: write to endpoint size mismatch")

        if not self._did_it_de_enumerate('boot'):
            logger.error(
                "%s: %s jumping to application command error (the bootloader didn't de-enumerate)",
                __name__,
                self.target
            )

            raise AppFileLoaderError(
                F"{self.target} jumping to application command error: the bootloader didn't de-enumerate")

        if self._did_it_enumerate(fw_type):
            logger.debug("%s entered %s mode", self.target, fw_type)
        else:
            logger.error(
                "%s: %s %s mode not entered", __name__, self.target, fw_type)

            raise AppFileLoaderError(
                f"{self.target} {fw_type} mode not entered")

    def _pre_process_app_file(self) -> Tuple[array.array, int]:
        '''
        Converts the app .hex into an array of bytes (*)
        Calculates the CRC32 and writes it to the last 4 bytes of the array
        (*) : the array needs to be of a given size - that's already taken care of
              in the PKOB4 .hex, but not in the CMSIS-DAP v2 .hex: hence
              the resulting array needs to be padded with 0xFFs

        Raises: AppFileLoaderError
        '''
        app_file_hex = IntelHex()

        app_file_hex.fromfile(self.new_fw_file_path, format='hex')

        app_file_image = app_file_hex.tobinarray()

        if self.new_fw_type == 'cmsis':
            padding_length = APPLICATION_IMAGE_SIZE_IN_BYTES - len(
                app_file_image)
            padding = array.array('B', [0xFF] * padding_length)
            app_file_image = app_file_image + padding

        # Make sure the resulting app image byte array has the expected size
        if len(app_file_image) != APPLICATION_IMAGE_SIZE_IN_BYTES:
            logger.error("%s: %s has an invalid size (%s)",
                         __name__,
                         os.path.basename(self.new_fw_file_path),
                         {len(app_file_image)}
                         )

            raise AppFileLoaderError(
                f"{os.path.basename(self.new_fw_file_path)} has an invalid size: ({len(app_file_image)})")

        # Calculate the app image byte array CRC32 except the last 4 bytes
        # where the calculated CRC32 will be written
        app_file_image_crc32 = zlib.crc32(
            bytes(app_file_image[:APPLICATION_IMAGE_SIZE_IN_BYTES - 4]))

        # Make sure the value is a 32-bit unsigned integer
        app_file_image_crc32 &= 0xFFFF_FFFF

        return app_file_image, app_file_image_crc32

    def _erase_app_flash(self) -> None:
        '''
        Raises: AppFileLoaderError
        '''
        logger.debug("erasing flash")

        command = bytearray(2)
        command[0] = commands['ERASE_FLASH']
        command[1] = commands['ERASE_APPLICATION']

        # Send command
        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_MPLAB_FW_TYPE'],
                                                      command,
                                                      timeouts_ms['USB_COMM'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s erasing app Flash error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} erasing app Flash error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s erasing app Flash error (write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} erasing app Flash error: write to endpoint size mismatch")

        # Check if Flash was erased w/out issues

        # Pause required between back-to-back access to USB
        time.sleep(2)

        try:
            erase_status = self.usb_device.read(endpoints_numbers['COMMAND_IN_MPLAB_BOOT'],
                                                ERASE_STATUS_SIZE_IN_BYTES,
                                                timeouts_ms['ERASE_FLASH'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s erasing app Flash error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} erasing app Flash error") from usb_comm_error

        if not erase_status:
            logger.error(
                "%s: cannot read status from %s following Flash erase", __name__, self.target)

            raise AppFileLoaderError(
                f"cannot read status from {self.target} following Flash erase")

        if erase_status[usb_receive_offsets['COMMAND_OPCODE_ECHO']] != commands['ERASE_FLASH']:
            logger.error(
                "%s: erase status didn't echo ERASE_FLASH command", __name__)

            raise AppFileLoaderError(
                "erase status didn't echo ERASE_FLASH command")

        error_code = erase_status[usb_receive_offsets['ERASE_FLASH_ERROR_CODE']]
        if error_code != NO_COMMAND_ERROR:
            logger.error("%s: %s code erasing %s Flash",
                         __name__, error_code, self.target)

            raise AppFileLoaderError(
                f"{error_code} code erasing {self.target} Flash")

    def _write_a_page_to_flash(self, start_address: int, data: bytearray) -> None:
        '''
        Raises: AppFileLoaderError
        '''
        command = bytearray(WRITE_FLASH_PAGE_COMMAND_SIZE_IN_BYTES)

        # Populate command array: opcode, start address, data
        # NOTE: there is an 8 bytes gap (reserved) between addr and data
        command[usb_transmit_offsets['COMMAND_OPCODE']] = commands['WRITE_PAGE']

        start_addr_as_bytes = start_address.to_bytes(
            FLASH_ADDRESS_SIZE_IN_BYTES, byteorder='little')
        command[usb_transmit_offsets['FIRST_ARGUMENT']:usb_transmit_offsets['FIRST_ARGUMENT'] +
                len(start_addr_as_bytes)] = start_addr_as_bytes

        command[usb_transmit_offsets['SECOND_ARGUMENT']:usb_transmit_offsets['SECOND_ARGUMENT'] +
                FLASH_PAGE_SIZE_IN_BYTES] = data[:FLASH_PAGE_SIZE_IN_BYTES]

        # Send command
        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_MPLAB_BOOT'],
                                                      command,
                                                      timeouts_ms['USB_COMM'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s writing to Flash page error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} writing to Flash page error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s writing to Flash page error (write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} writing to Flash page error: write to endpoint size mismatch")

        try:
            write_page_status = self.usb_device.read(endpoints_numbers['COMMAND_IN_MPLAB_BOOT'],
                                                     WRITE_PAGE_STATUS_SIZE_IN_BYTES,
                                                     timeouts_ms['WRITE_FLASH_PAGE'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s writing to Flash page error (%s)", __name__,
                         self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} writing to Flash pag error") from usb_comm_error

        if not write_page_status:
            logger.error(
                "%s: cannot read status from %s writing to Flash page", __name__, self.target)

            raise AppFileLoaderError(
                f"cannot read status from {self.target} writing to Flash page")

        if write_page_status[usb_receive_offsets['COMMAND_OPCODE_ECHO']] != commands['WRITE_PAGE']:
            logger.error(
                "%s: write status didn't echo WRITE_PAGE command", __name__)

            raise AppFileLoaderError(
                "write status didn't echo WRITE_PAGE command")

        error_code = write_page_status[usb_receive_offsets['WRITE_PAGE_ERROR_CODE']]
        if error_code != NO_COMMAND_ERROR:
            logger.error("%s: %s code writing %s Flash page", __name__,
                         error_code, self.target)

            raise AppFileLoaderError(
                f"{error_code} code writing {self.target} Flash page")

    def _write_app_flash(self, aap_file_image: array.array, target: str) -> None:
        '''
        Writes the application file into the target Flash, page by page

        Raises: AppFileLoaderError
        '''
        logger.info("application being written and verified")

        number_of_percentage_updates = 20

        pages_in_array_of_bytes = math.ceil(
            len(aap_file_image) / FLASH_PAGE_SIZE_IN_BYTES)

        pages_per_update = math.ceil(
            pages_in_array_of_bytes / number_of_percentage_updates)

        percentage_value = 0
        pages_counter = 0

        data_array = bytearray(FLASH_PAGE_SIZE_IN_BYTES)

        for flash_page_start_address in range(0, len(aap_file_image), FLASH_PAGE_SIZE_IN_BYTES):
            # Write to Flash a page of aap_file_image data
            data_array = bytearray(aap_file_image[flash_page_start_address:flash_page_start_address +
                                                  FLASH_PAGE_SIZE_IN_BYTES])

            self._write_a_page_to_flash(
                APPLICATION_START_ADDRESS + flash_page_start_address, data_array)

            # Update the percentage?
            pages_counter += 1
            if pages_counter == pages_per_update:
                pages_counter = 0
                percentage_value += 5
                print(
                    f' Application write progress: {percentage_value}%', end='\r')
                sys.stdout.flush()

        print(' ' * 30, end='\r')  # Clear the line by printing spaces
        sys.stdout.flush()

        logger.info(
            'application write and verify completed, waiting for %s ready ..',
            targets_info[target].target_output_name
        )

    def _get_crc32(self) -> int:
        '''
        Raises: AppFileLoaderError
        '''
        command = bytearray(1)
        command[usb_transmit_offsets['COMMAND_OPCODE']] = commands['READ_CRC32']

        try:
            bytes_to_endpoint = self.usb_device.write(endpoints_numbers['COMMAND_OUT_MPLAB_BOOT'],
                                                      command,
                                                      timeouts_ms['READ_CRC32'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s reading CRC32 error (%s)",
                         __name__, self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} reading CRC32 error") from usb_comm_error

        if len(command) != bytes_to_endpoint:
            logger.error(
                "%s: %s reading CRC32 error (write to endpoint size mismatch)", __name__, self.target)

            raise AppFileLoaderError(
                f"{self.target} reading CRC32 error: write to endpoint size mismatch")

        # Pause required between back-to-back access to USB
        time.sleep(2)

        try:
            read_crc32_status = self.usb_device.read(endpoints_numbers['COMMAND_IN_MPLAB_BOOT'],
                                                     READ_CRC32_STATUS_SIZE_IN_BYTES,
                                                     timeouts_ms['READ_CRC32'])
        except usb.core.USBError as usb_comm_error:
            logger.error("%s: %s reading CRC32 error (%s)",
                         __name__, self.target, usb_comm_error)

            raise AppFileLoaderError(
                f"{self.target} reading CRC32 error") from usb_comm_error

        if not read_crc32_status:
            logger.error("%s: cannot read CRC32 from %s",
                         __name__, self.target)

            raise AppFileLoaderError(f"cannot read CRC32 from {self.target}")

        if read_crc32_status[usb_receive_offsets['COMMAND_OPCODE_ECHO']] != commands['READ_CRC32']:
            logger.error("%s: no command echo reading %s app CRC32",
                         __name__, self.target)

            raise AppFileLoaderError(
                f"no command echo reading {self.target} app CRC32")

        crc32_value = struct.unpack('<I', read_crc32_status[1:5])[0]

        return crc32_value

    def _show_progress_bar(self, stop_event):
        """
        Displays a continuously updating progress bar using tqdm to indicate
        the progress of the application de-enumerating

        The progress bar animates in a loop until the provided stop_event is set
        (when the application de-enumerates), at which point the progress bar is
        deleted from the terminal.

        Args:
            stop_event (threading.Event): An event object used to signal when
            the progress bar should stop updating and be deleted.
        """
        with tqdm(total=100, desc="preparing application write", bar_format="{desc}: {bar}", leave=False) as pbar:
            while not stop_event.is_set():
                pbar.update(1)
                if pbar.n >= 10:
                    pbar.n = 0  # Reset for continuous animation, OS update style
                    pbar.last_print_n = 0
                    pbar.refresh()
                time.sleep(0.25)

    def execute(self, is_action_recovery=False) -> None:
        """
        Executes the application file loading process.

        Args:
            is_action_recovery (bool, optional):
                Indicates whether this is the second step of a target recovery process.

        Returns:
            None

        Raises: AppFileLoaderError
        """
        # Convert the app .hex into an array of bytes (padded if needed) and add its CRC32
        app_file_image, app_file_image_crc32 = self._pre_process_app_file()
        crc32_as_byte_array = app_file_image_crc32.to_bytes(
            4, byteorder='little')

        for pos in range(CRC32_SIZE_IN_BYTES):
            app_file_image[APPLICATION_IMAGE_CRC_BASE_ADDRESS +
                           pos] = crc32_as_byte_array[pos]

        # If the current firmware is not a bootloader (1), start a progress bar in a separate thread,
        # enter boot mode, then stop and join the progress bar thread once boot mode is entered.
        #
        # (1) meaning that the code called this function as part of an application switch,
        # not a boot + app recovery.
        if self.current_fw_type != 'bootloader':
            stop_event = threading.Event()
            progress_thread = threading.Thread(
                target=self._show_progress_bar, args=(stop_event,))
            progress_thread.start()

            self._enter_boot_mode()

            stop_event.set()
            progress_thread.join()

        # It could be best to wait for the USB device (bootloader) to complete enumeration
        # after the PID is detected
        time.sleep(.500)

        # If this is the second step of a target recovery process, the Flash has already been erased
        if not is_action_recovery:
            self._erase_app_flash()

        # Write to the Flash page by page the app.hex
        self._write_app_flash(app_file_image, self.target)

        # Read the CRC32 from Flash and check it matches the one previously calculated
        crc32_value_from_flash = self._get_crc32()

        # If CRC32 match, back to app
        # If they don't, raise error (user will be offered to try switching again)
        if app_file_image_crc32 == crc32_value_from_flash:
            logger.debug("application firmware written and CRC32-verified")

            self._jump_to_app_mplab_boot()

            # It could be best to wait for the USB device (application) to complete enumeration
            # after the PID is detected
            time.sleep(.500)
        else:
            raise AppFileLoaderError(
                f"CRC32 mismatch reading {self.target} Flash")
