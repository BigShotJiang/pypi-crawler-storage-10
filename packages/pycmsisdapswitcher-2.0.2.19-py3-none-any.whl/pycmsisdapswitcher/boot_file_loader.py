'''
Provides functions to write the bootloader file to the ATSAM flash
and read it back for write verify
'''
import logging
import math

from typing import Tuple

from serial import Serial

from pycmsisdapswitcher.errors import FlashWriteError, FlashVerifyError

from pycmsisdapswitcher.samba_comm import (
    write_word, send_command,
    read_bytes_page_by_page
)


# Named logger
logger = logging.getLogger(__name__)

# Named constants
FLASH_WORD_SIZE = 4    # Bytes
FLASH_PAGE_SIZE = 512  # Bytes
BASE_FLASH_ADDRESS = 0x00400000
RELATIVE_BOOT_FLASH_START_ADDRESS = 0   # To be added to the base flash address
NUMBER_OF_LOCK_BITS = 128  # ATSAME70Q21-N21
LOCK_REGION_SIZE = 16*1024  # Bytes

# Commands
CLEAR_LOCK_BIT_COMMAND = 0x09
WRITE_FLASH_PAGE_COMMAND = 0x01


def _clear_lock_bits(target_serial_port: Serial, boot_file_array_of_bytes: bytearray) -> bool:
    '''
    Clears the ATSAM lock bits covering the flash regions corresponding to the bootloader file,
    allowing the flash to be written

    Returns:
        bool: True if all necessary lock bits were successfully cleared (i.e., the bootloader
              flash region is fully unlocked); False otherwise.    
    '''
    lock_start = 0
    lock_end = 0
    current_flash_addr = RELATIVE_BOOT_FLASH_START_ADDRESS
    flash_end_addr = current_flash_addr + len(boot_file_array_of_bytes)

    lock_bits_cleared = False

    for lock_bit_number in range(NUMBER_OF_LOCK_BITS):
        lock_end = lock_start + LOCK_REGION_SIZE

        if lock_start <= current_flash_addr < lock_end:
            # Try to unlock the current flash region by clearing its lock bit
            if send_command(target_serial_port, CLEAR_LOCK_BIT_COMMAND, lock_bit_number):
                current_flash_addr = lock_end

                if current_flash_addr >= flash_end_addr:
                    # Done, all flash corresponding to the boot file has been unlocked
                    lock_bits_cleared = True
                    break
            else:
                break

        lock_start += LOCK_REGION_SIZE

    return lock_bits_cleared


def _print_write_progress(pages_counter, pages_per_update, percentage_value) -> Tuple[int, int]:
    '''
    Updates and displays the write progress percentage on the terminal.

    Returns:
        tuple: Updated (pages_counter, percentage_value).
    '''
    pages_counter += 1
    if pages_counter == pages_per_update:
        pages_counter = 0
        percentage_value += 5
        print(f' Write progress: {percentage_value}%', end='\r')

    return pages_counter, percentage_value


def _write_flash_page(target_serial_port: Serial, current_page_number):
    '''
    Writes the current flash page to the target device via the provided serial port.

    Raises:
        FlashWriteError: If writing to the flash page fails.
    '''
    if not send_command(target_serial_port, WRITE_FLASH_PAGE_COMMAND, current_page_number):
        logger.error("%s: failed to write to Flash page", __name__)

        raise FlashWriteError("failed to write to Flash page")


def _write_flash_words_loop(target_serial_port, boot_file_array_of_bytes):
    '''
    Writes an array of bytes to the device's flash memory word by word,
    committing each flash page when it is filled or when all bytes
    have been written.

    Raises:
        FlashWriteError: If writing a word to flash fails.    
    '''
    bytes_left_to_write = len(boot_file_array_of_bytes)
    current_index = 0
    current_flash_addr = RELATIVE_BOOT_FLASH_START_ADDRESS
    current_page_number = current_flash_addr // FLASH_PAGE_SIZE
    number_of_percentage_updates = 20

    pages_in_array_of_bytes = math.ceil(
        len(boot_file_array_of_bytes) / FLASH_PAGE_SIZE)
    pages_per_update = math.ceil(
        pages_in_array_of_bytes / number_of_percentage_updates)
    percentage_value = 0
    pages_counter = 0

    while bytes_left_to_write > 0:
        current_flash_word = int.from_bytes(
            boot_file_array_of_bytes[current_index:current_index + 4], byteorder='little', signed=False)
        if not write_word(target_serial_port, BASE_FLASH_ADDRESS + current_flash_addr, current_flash_word):
            logger.error("%s: failed to write to Flash word", __name__)

            raise FlashWriteError("failed to write to Flash word")

        bytes_left_to_write -= FLASH_WORD_SIZE
        current_index += FLASH_WORD_SIZE
        current_flash_addr += FLASH_WORD_SIZE

        # Determine if page should be written
        if bytes_left_to_write == 0 or current_flash_addr // FLASH_PAGE_SIZE != current_page_number:
            _write_flash_page(target_serial_port, current_page_number)
            current_page_number = current_flash_addr // FLASH_PAGE_SIZE
            pages_counter, percentage_value = _print_write_progress(
                pages_counter, pages_per_update, percentage_value)

    print(' ' * 30, end='\r')  # Clear the line by printing spaces


def write_boot_file(target_serial_port: Serial, boot_file_array_of_bytes: bytearray):
    '''
     Writes the provided boot file data to the target device via the given serial port.

    Raises:
        FlashWriteError: If unable to unlock the device's flash memory for writing.
    '''
    if not _clear_lock_bits(target_serial_port, boot_file_array_of_bytes):
        logger.error("%s: failed to unlock the Flash for writing", __name__)

        raise FlashWriteError("failed to unlock the Flash for writing")

    _write_flash_words_loop(target_serial_port, boot_file_array_of_bytes)


def verify_boot_file(target_serial_port: Serial, boot_file_array_of_bytes: bytearray) -> None:
    """
    Verifies that the bootloader file has been correctly written to the target, reading it back
    and comparing the result with the provided file

    Args:
        target_serial_port (Serial): The serial port associated with the target device.
        boot_file_array_of_bytes (bytearray): The expected bootloader file contents as a byte array.

    Raises:
        FlashVerifyError: If the verification fails
    """
    bytes_read = read_bytes_page_by_page(target_serial_port,
                                         BASE_FLASH_ADDRESS + RELATIVE_BOOT_FLASH_START_ADDRESS,
                                         len(boot_file_array_of_bytes)
                                         )

    if not (bytes_read and bytes_read == boot_file_array_of_bytes):
        logger.error("%s: couldn't verify bootloader write", __name__)

        raise FlashVerifyError("couldn't verify bootloader write")
