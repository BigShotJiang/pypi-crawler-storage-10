'''
Main module of the pycmsisdapswitcher for firmware switcher action
'''
import os
import logging
import argparse
from typing import Tuple

import time

import usb.core
import usb.backend.libusb1

import libusb_package

from pycmsisdapswitcher.app_file_loader import timeouts_ms

from pycmsisdapswitcher.errors import (
    TargetError,
    USBBackendNotFoundError,
    RecoveryError,
    SwitchError
)
from pycmsisdapswitcher.targets_info import (
    TARGETS_INFO as targets_info,
    VIDs,
)
from pycmsisdapswitcher.app_file_loader import FWFileLoader
from pycmsisdapswitcher.hex_file_downloader import (download_file,
                                                    extract_hex_from_atpack)
from pycmsisdapswitcher.cache_manager import CacheManager

# Named logger
logger = logging.getLogger(__name__)


# Helpers

def _get_libusb1_backend():
    '''
    Returns a libusb1 backend instance for pyusb operations.
    '''
    return usb.backend.libusb1.get_backend(find_library=libusb_package.find_library)


def _search_targets_app_mode(backend, target: str) -> Tuple[str, usb.core.Device, str]:
    '''
    Search for a USB device in application mode
    '''

    usb_device_mplab = []
    target_name = None
    usb_device = None
    fw_type = None

    mplab_app_pid = targets_info[target].pids.mplab_app_pid
    if not isinstance(mplab_app_pid, tuple):
        mplab_app_pid = [mplab_app_pid]

    for pid in mplab_app_pid:
        usb_device_mplab.extend(list(usb.core.find(

            idVendor=VIDs['MCHP'],
            idProduct=pid,
            find_all=True,
            backend=backend)))

    usb_device_cmsis2 = []

    mplab_app_pid = targets_info[target].pids.cmsis_v2_app_pid
    if not isinstance(mplab_app_pid, tuple):
        mplab_app_pid = [mplab_app_pid]

    for pid in mplab_app_pid:
        usb_device_cmsis2.extend(list(usb.core.find(
            idVendor=VIDs['MCHP'],
            idProduct=pid,
            find_all=True,
            backend=backend)))

    if len(usb_device_mplab) + len(usb_device_cmsis2) > 1:
        logger.error(
            "%s: more than one %s found in application mode", __name__, target)

        raise TargetError(f"more than one {target} found in application mode")

    if len(usb_device_mplab) == 1:
        target_name = target
        usb_device = usb_device_mplab[0]
        fw_type = 'mplab'

    elif len(usb_device_cmsis2) == 1:
        target_name = target
        usb_device = usb_device_cmsis2[0]
        fw_type = 'cmsisv2'

    return target_name, usb_device, fw_type


def _search_targets_boot_mode(backend, target: str) -> Tuple[str, usb.core.Device, str]:
    '''
    Search for a USB device in bootloader mode
    '''
    usb_device_boot = []
    target_name = None
    usb_device = None
    fw_type = None

    found_devices = usb.core.find(
        idVendor=VIDs['MCHP'],
        idProduct=targets_info[target].pids.mplab_boot_pid,
        find_all=True,
        backend=backend)

    if found_devices is not None:
        usb_device_boot.extend(list(found_devices))

        if len(usb_device_boot) > 1:
            logger.error(
                "%s: more than one %s found in bootloader mode", __name__, target)

            raise TargetError(
                f"more than one {target} found in bootloader mode")

        if len(usb_device_boot) == 1:
            target_name = target
            usb_device = usb_device_boot[0]
            fw_type = 'bootloader'

    return target_name, usb_device, fw_type


def _find_device(backend, is_action_recovery) -> tuple[str, usb.core.Device, str]:
    '''
    Search for a USB device either in application mode or in bootloader mode

    Returns:
        tuple[str,usb.core.Device, str]: The name and object associated to the found USB device
        and its firmware type ("mplab", "cmsisv2", or "bootloader")

    Raises:
        USBBackendNotFoundError: If a compatible libusb backend cannot be found.
        TargetError: If more than one relevant device is found or if no device is found.
    '''

    # Scan all USB devices before filtering for specific targets (VID, PID).
    # This avoids OS-specific enumeration issues — especially on Windows —
    # and is considered best practice for reliable, cross-platform USB detection.
    usb.core.find(find_all=True)

    # Collect all matches (either application or bootloader)
    matches = []
    seen_pids = set()

    for target in targets_info:
        if not is_action_recovery:
            # If this is the second step of a target recovery process, targets in application mode can be ignored
            # The code only needs to check if there are multiple targets in bootloader mode.
            match_app = _search_targets_app_mode(backend, target)
            if match_app[1] is not None and match_app[1] not in seen_pids:
                matches.append(match_app)
                seen_pids.add(match_app[1])

        match_boot = _search_targets_boot_mode(backend, target)
        if match_boot[1] is not None and match_boot[1] not in seen_pids:
            matches.append(match_boot)
            seen_pids.add(match_boot[1])

    if len(matches) == 1:
        return matches[0]

    if len(matches) > 1:
        logger.error(
            "%s: Multiple targets detected.\n"
            "Please disconnect all targets except the one you want to operate on, then retry.\n"
            "Run pycmsisdapswitcher --help for more info.", __name__)
        raise TargetError(
            "Multiple targets detected.\n"
            "Please disconnect all targets except the one you want to operate on, then retry.\n"
            "Run pycmsisdapswitcher --help for more info.")

    # If no match found, check for nEDBG devices
    usb_device_cmsis = list(
        usb.core.find(
            idVendor=VIDs['ATMEL'],
            idProduct=targets_info['evalboard'].pids.cmsis_app_pid,
            find_all=True,
            backend=backend
        )
    )
    if len(usb_device_cmsis) > 0:
        logger.error(
            "%s: nEDBG board(s) detected, already supporting CMSIS-DAP (v1)", __name__)
        raise TargetError(
            "nEDBG board(s) detected, already supporting CMSIS-DAP (v1)")

    logger.error(
        "%s: no target found - please make sure a supported target is plugged in.\n"
        "Run pycmsisdapswitcher --help for more info.",
        __name__,
    )

    raise TargetError(
        "No target found - please make sure a supported target is plugged in.\n"
        "Run pycmsisdapswitcher --help for more info."
    )


def _wait_boot_enumerate(target: str, backend) -> None:
    '''
    Wait for the bootloader to enumerate.

    Raises:
        RecoveryError: if the bootloader enumeration times out
    '''
    POLL_INTERVAL_S = 0.2  # pylint: disable=invalid-name

    target_key, target_subkey = target, "mplab_boot_pid"
    start_time_s = time.perf_counter()

    boot_pid = getattr(targets_info[target_key].pids, target_subkey)

    while True:
        elapsed_time_s = time.perf_counter() - start_time_s
        if elapsed_time_s >= timeouts_ms['USB_ENUM'] / 1_000:

            logger.error("%s: bootloader didn't enumerate", __name__)

            raise RecoveryError("bootloader didn't enumerate")

        if usb.core.find(idVendor=VIDs['MCHP'],
                         idProduct=boot_pid,
                         find_all=False,
                         backend=backend) is not None:

            logger.debug("bootloader enumerated")

            return

        time.sleep(POLL_INTERVAL_S)


def switch(fw_source: str = 'server', fw_type: str = 'cmsis',
           is_action_recovery: bool = False, boot_target: str = ''):
    '''
    Switch the application firmware

    Args:
        fw_source (str, optional): The source of the firmware file. Can be a path to a .hex file,
            'server', or 'cache'. Defaults to 'server'.
        fw_type (str, optional): The type of firmware to switch to. Can be 'cmsis' or 'mplab'.
            Defaults to 'cmsis'.
        is_action_recovery (bool, optional): If True, skips the flash erase step.
            Defaults to False.
        boot_target (str, optional): The target name to wait for during the recovery process.
            Used to ensure the correct bootloader enumerates on USB during recovery.
            Defaults to an empty string.

    Raises:
        SwitchError: If any error occurs during the device finding, firmware file retrieval,
            or firmware switching process.
    '''
    backend = _get_libusb1_backend()
    if backend is None:
        logger.error("no libusb backend found")

        raise USBBackendNotFoundError("no libusb backend found")

    # If this is the second step of recovery, let's make sure that the bootloader enumerated
    if is_action_recovery:
        _wait_boot_enumerate(boot_target, backend)

    try:
        # Find the device, either in application mode or in bootloader mode
        usb_device = None

        target, usb_device, current_fw_type = _find_device(
            backend, is_action_recovery)

        logger.info("found %s, S/N %s running %s firmware",
                    targets_info[target].target_output_name, usb_device.serial_number, current_fw_type)

        # Figure out which HEX file to write as an application
        if fw_source.lower().endswith('.hex'):
            # HEX file provided with CLI command
            fw_file_path = fw_source

            if not os.path.isabs(fw_file_path):
                fw_file_path = os.path.join(os.getcwd(), fw_file_path)
        elif fw_source.lower().endswith('.atpack'):
            # HEX file to be retrieved from local .atpack
            app_type = 'app_mplab' if fw_type == 'mplab' else 'app_cmsis'

            try:
                fw_file_path = extract_hex_from_atpack(
                    fw_source,
                    getattr(targets_info[target].file_name, app_type)
                )
            except FileNotFoundError as exc:
                raise SwitchError(
                    f'Firmware file not found in .atpack: {fw_source}') from exc

        elif fw_source == 'server':
            # HEX file from packs.download server
            fw_file_path = download_file(
                target, fw_type)
        else:
            # HEX file from cache
            cache = CacheManager()

            if fw_type == 'mplab':
                app = 'app_mplab_cache'
            else:
                app = 'app_cmsis'

            fw_file_path = cache.get_file(
                file_name=getattr(targets_info[target].file_name, app))

        logger.info("using application file %s", fw_file_path)

        # Go through the steps for application recovery or switch
        loader = FWFileLoader(target,
                              usb_device,
                              current_fw_type,
                              fw_file_path,
                              fw_type)

        loader.execute(is_action_recovery)
    finally:
        if usb_device:
            usb.util.dispose_resources(usb_device)


def _parse_arguments(arguments: argparse.Namespace) -> Tuple[str, str]:
    fw_source = arguments.appsource
    if not fw_source:
        fw_source = 'server'

    fw_type = arguments.fwtype
    if not fw_type:
        fw_type = 'cmsis'

    return fw_source, fw_type


def main(arguments: argparse.Namespace, has_app_flash_already_been_erased=False, boot_target='') -> None:
    '''
    Main function: process the arguments from the CLI command to switch the application firmware

    Args:
        arguments (argparse.Namespace): Parsed command line arguments specifying
                                        firmware source, and firmware type.
        has_app_flash_already_been_erased (bool, optional): Whether the application flash
                                        has already been erased. Defaults to False.

    '''
    fw_source, fw_type = _parse_arguments(arguments)

    # This function can be called as part of the pycmsisdapswitcher library with named arguments
    switch(fw_source, fw_type,
           has_app_flash_already_been_erased, boot_target)
