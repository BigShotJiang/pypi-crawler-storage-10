'''
Exception definitions for the pycmsisdapswitcher.
# NOTE Each exception is derived from PyCmsisDapSwitcherError.
'''


class PyCmsisDapSwitcherError(Exception):
    '''
    Base exception for pycmsisdapswitcher errors.
    '''


class SwitchError(PyCmsisDapSwitcherError):
    '''
    Exception raised when an error occurs while switching
    the target application firmware.
    '''


class RecoveryError(PyCmsisDapSwitcherError):
    '''
    Exception raised when an error occurs while recovering
    the target application firmware.
    '''


class ServerAccessError(PyCmsisDapSwitcherError):
    '''
    Exception raised when there is a failure accessing
    the public pack server.
    '''


class CacheAccessError(PyCmsisDapSwitcherError):
    '''
    Exception raised when there is a failure accessing
    the internal cache.
    '''


class TargetError(PyCmsisDapSwitcherError):
    '''
    Exception raised when no target is found in the expected
    mode or multiple targets are found.
    '''


class USBBackendNotFoundError(PyCmsisDapSwitcherError):
    '''
    Exception raised when no libusb backend for the operating system 
    and machine architecture is found.
    '''


class BootFileLoaderError(PyCmsisDapSwitcherError):
    '''
     Exception raised when the bootloader file cannot be written
     to the target or write verify fails.
     '''


class AppFileLoaderError(PyCmsisDapSwitcherError):
    '''
     Exception raised when the application file cannot be written
     to the target or write verify fails.
     '''


class FlashWriteError(PyCmsisDapSwitcherError):
    '''
     Exception raised when the target flash cannot be unlocked for write
     or when unlocked cannot be written with the bootloader or application file.
     '''


class FlashVerifyError(PyCmsisDapSwitcherError):
    '''
     Exception raised when the bootloader file write to the target flash
     cannot be verified.
     '''
