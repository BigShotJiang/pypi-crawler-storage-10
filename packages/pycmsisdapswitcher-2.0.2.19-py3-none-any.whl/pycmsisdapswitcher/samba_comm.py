'''
Provides functions to access the ATSAM on the hardware tool in recovery mode
using the protocol implemented by the SAMBA Monitor code running in the ATSAM ROM
'''
import logging
import time

from typing import Tuple, Optional

from serial import Serial

# Named logger
logger = logging.getLogger(__name__)


# Memory mapping
FLASH_WORD_SIZE = 4    # Bytes
FLASH_PAGE_SIZE = 512  # Bytes

EEFC_BASE_ADDRESS = 0x400E0C00   # EEFC = Enhanced Embedded Flash Controller
FLASH_COMMAND_REGISTER_ADDRESS = 0x00000004
FLASH_STATUS_REGISTER_ADDRESS = 0x00000008

# Command strings
# NOTE: e.g., formatted_string = 'R{:08x},{:08x}#'.format(number1, number2)
WRITE_WORD_COMMAND = "W{:08x},{:08x}#"
READ_WORD_COMMAND = "w{:08x},#"
READ_BYTES_COMMAND = "R{:08x},{:08x}#"

# Flash Status Register bits masks(left shifted based on position in the register)
FLASH_READY_BITMASK = 1

# EEFC Commands
WRITE_PROTECTION_KEY = 0x5A << 24  # Goes into FLASH_COMMAND_REGISTER[31:24].
SET_GPNVM_BIT = 0x0B  # Bit 1 used to switch boot mode
DO_SOFTWARE_RESET = 0xA5000001

# Reset controller (RSTC) base address and registers offsets
RESET_CONTROLLER_BASE = 0x400E1800
RSTC_CONTROL_REGISTER = 0x00000000
RSTC_STATUS_REGISTER = 0x00000004

# Timeouts
WRITE_TIMEOUT_SECONDS = 3


def write_word(target_serial_port: Serial, absolute_addr: int, data: int) -> bool:
    '''
    Writes a word (4 bytes) to flash

    :absolute_addr: the absolute address (base address + relative address) in flash
    :return: True if the write was successful, else False
    '''
    command_string = WRITE_WORD_COMMAND.format(absolute_addr, data)

    command = command_string.encode('utf-8')

    return target_serial_port.write(command) == len(command)


def read_word(target_serial_port: Serial, absolute_addr: int) -> Tuple[bool, int]:
    '''
    Reads a word (4 bytes) from flash

    :absolute_addr: the absolute address (base address + relative address) in flash
    :return: whether the read was successful and if successful, the value read
    '''
    command_string = READ_WORD_COMMAND.format(absolute_addr)

    command = command_string.encode('utf-8')

    if target_serial_port.write(command) == len(command):
        bytes_read = target_serial_port.read(FLASH_WORD_SIZE)
        if len(bytes_read) == FLASH_WORD_SIZE:
            word_read = int.from_bytes(
                bytes_read[:4], byteorder='little', signed=False)

        return True, word_read

    return False, None


def send_command(target_serial_port: Serial, command: int, argument: int) -> bool:
    '''
    Writes a command (with an optional argument in bits 15:8) to the FLASH_COMMAND_REGISTER

    :return: True if the write was successful, else False
    '''
    if write_word(target_serial_port,
                  EEFC_BASE_ADDRESS + FLASH_COMMAND_REGISTER_ADDRESS,
                  WRITE_PROTECTION_KEY | command | (argument << 8)
                  ):
        # Wait for flash ready for new commands, or timeout
        start_time = time.time()  # In seconds
        while time.time() - start_time < WRITE_TIMEOUT_SECONDS:
            result, data = read_word(target_serial_port,
                                     EEFC_BASE_ADDRESS + FLASH_STATUS_REGISTER_ADDRESS)
            if result and (data & FLASH_READY_BITMASK == 1):
                return True

            time.sleep(0.1)

    return False


def read_bytes_page_by_page(target_serial_port: Serial,
                            absolute_start_addr: int,
                            number_of_bytes_to_read: int
                            ) -> Optional[bytearray]:
    '''
    Reads bytes from the flash, page by page

    :absolute_start_addr: the absolute start address (base address + relative address) in flash
    :return: an array of bytes if the read was successful, or None
    '''
    # Init
    result = bytearray(number_of_bytes_to_read)
    result_index = 0
    current_absolute_start_address = absolute_start_addr
    bytes_remaining_to_read = number_of_bytes_to_read

    # First, read page by page
    page_read = bytearray(FLASH_PAGE_SIZE)
    for _ in range(number_of_bytes_to_read // FLASH_PAGE_SIZE):
        command = READ_BYTES_COMMAND.format(
            current_absolute_start_address, FLASH_PAGE_SIZE - 1).encode()
        if target_serial_port.write(command) == len(command):
            page_read = bytearray(target_serial_port.read(FLASH_PAGE_SIZE - 1))

            # Nww read the remaining byte in the current page and add it to page_read
            command = READ_BYTES_COMMAND.format(
                current_absolute_start_address + FLASH_PAGE_SIZE - 1, 1).encode()
            if target_serial_port.write(command) == len(command):
                page_read.append(target_serial_port.read(1)[0])
            else:
                return None

            if len(page_read) == FLASH_PAGE_SIZE:
                # Update
                result[result_index:result_index +
                       FLASH_PAGE_SIZE] = page_read
                result_index += FLASH_PAGE_SIZE
                bytes_remaining_to_read -= FLASH_PAGE_SIZE
                current_absolute_start_address += FLASH_PAGE_SIZE
            else:
                return None
        else:
            return None

    # Then if no failure so far, read the remaining bytes (if any)
    if bytes_remaining_to_read != 0:
        logger.debug(
            "boot write verify: now reading remaining %s ..", bytes_remaining_to_read)
        bytes_remaining_read = bytearray(bytes_remaining_to_read)
        command = READ_BYTES_COMMAND.format(
            current_absolute_start_address, bytes_remaining_to_read).encode()
        if target_serial_port.write(command) == len(command):
            bytes_read = target_serial_port.read(bytes_remaining_read)
            if len(bytes_read) == bytes_remaining_read:
                # Update
                result[result_index:result_index +
                       bytes_remaining_to_read] = bytes_remaining_read
            else:
                return None
        else:
            return None

    return result


def set_boot_mode_to_flash(target_serial_port: Serial) -> None:
    '''
    Switches boot mode from ROM to Flash so that after reset
    the bootloader will be executed instead of the SAMBA code in ROM
    '''
    send_command(target_serial_port, SET_GPNVM_BIT, 1)


def execute_software_reset(target_serial_port: Serial) -> None:
    '''
    Avoids the need of a hardware reset to start running the bootloader
    after successful recovery
    '''
    write_word(target_serial_port, RESET_CONTROLLER_BASE +
               RSTC_CONTROL_REGISTER, DO_SOFTWARE_RESET)
