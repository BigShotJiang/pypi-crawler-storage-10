'''
Parses the CLI command
'''

import importlib.resources

import argparse
import textwrap
import logging
import logging.config
import yaml


from pycmsisdapswitcher.switcher_main import main as _switcher_main
from pycmsisdapswitcher.recover_main import main as _recover_main
from pycmsisdapswitcher.targets_info import TARGETS_INFO as targets_info
from pycmsisdapswitcher.__init__ import __version__
from pycmsisdapswitcher.errors import PyCmsisDapSwitcherError


def __setup_args_parser() -> argparse.ArgumentParser:
    '''
    Set up the argument parser for the pycmsisdapswitcher CLI command

    Returns:
        argparse.ArgumentParser: A fully configured argument parser for CLI argument parsing.
    '''
    # The following text is displayed when
    # pycmsisdapswitcher --help
    # is prompted, before (prologue) and after (epilogue) args and options help
    prologue = textwrap.dedent(f'''\
        Microchip pycmsisdapswitcher version {__version__}
        A Python standalone package and library for bootloader and application firmware recovery or application firmware switch based on CLI prompts
    ''')

    epilogue = textwrap.dedent('''\
        Prompts for usage as standalone package:

            Show how to put supported_target in recovery mode:
            pycmsisdapswitcher --action recover --target supported_target --showhowto

            Recover bootloader + CMSIS-DAP v2 type app on supported_target, retrieve both files from pack server, set logging verbosity level to debug:
            pycmsisdapswitcher --action recover --target supported_target --verbose debug

            Recover bootloader + MPLAB type app on supported_target, retrieve both files from cache:
            pycmsisdapswitcher --action recover --target supported_target --bootsource cache --appsource cache --fwtype mplab

            Recover bootloader + MPLAB type app on supported_target, retrieve boot file from pack server, use provided .hex or .atpack files for app:
            pycmsisdapswitcher --action recover --target supported_target --appsource path_to_appfile --fwtype mplab

            Recover bootloader + CMSIS-DAP v2 type app on supported_target, retrieve boot file from pack server, retrieve app file from cache:
            pycmsisdapswitcher --action recover --target supported_target --appsource cache

            Recover bootloader + CMSIS-DAP v2 type app on supported_target, use provided .hex or .atpack files for both boot and app:
            pycmsisdapswitcher --action recover --target supported_target --boothex path_to_bootfile  --apphex path_to_appfile

            Switch application on supported_target to CMSIS-DAP v2 type app, retrieve app file from pack server, set logging verbosity level to debug:
            pycmsisdapswitcher --verbose debug

            Switch application on supported_target to MPLAB type app, retrieve app file from cache:
            pycmsisdapswitcher --appsource cache --fwtype =mplab

            Switch application on supported_target to CMSIS-DAP v2 type, use provided .hex or .atpack files for app:
            pycmsisdapswitcher  --apphex path_to_appfile
    ''')

    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description=prologue,
        epilog=epilogue
    )

    parser.add_argument('--action', type=str,
                        choices=['recover', 'switch'],
                        default='switch',
                        help='Action to be performed')

    target_choices = list(targets_info.keys())
    parser.add_argument('--target', type=str,
                        choices=target_choices,
                        help='Supported Microchip tool or board to act on')

    parser.add_argument('--bootsource', type=str,
                        default='server',
                        help='Bootloader file source: "server", "cache" or a file path')

    parser.add_argument('--appsource', '--source', type=str,
                        default='server',
                        help='Application file source: "server" (default), "cache" or a file path')

    parser.add_argument('--fwtype', type=str,
                        choices=['cmsis', 'mplab'],
                        default='cmsis',
                        help='Firmware type for application file')

    parser.add_argument('--showhowto',
                        action='store_true',  # Boolean
                        help='Shows instructions to put target in recovery mode')

    parser.add_argument('--version',
                        action='store_true',  # Boolean
                        help='Shows pycmsisdapswitcher installed version')

    parser.add_argument('--verbose', '--v', type=str,
                        choices=["debug",
                                 "info",
                                 "warning",
                                 "error",
                                 "critical"],
                        default="info",
                        help='Logging verbosity level')

    return parser


def _setup_root_logger() -> logging.Logger:
    '''
    Set up the root logger

    Returns:
        logging.Logger: The root logger.

    '''
    try:
        with importlib.resources.open_text("pycmsisdapswitcher", "logging_config.yaml") as f:
            config = yaml.safe_load(f)
            logging.config.dictConfig(config)
    except FileNotFoundError:
        # Fallback to basic configuration if YAML file is not found
        logging.basicConfig(level=logging.DEBUG)
        logging.getLogger().warning(
            "Logger configuration file not found. Using basic logging configuration")
    except Exception:  # pylint: disable=broad-except
        # Handle other exceptions, e.g., YAML parsing errors
        logging.basicConfig(level=logging.DEBUG)

        logging.getLogger().warning(
            "Failed to load or parse logging configuration file. Using basic logging configuration; "
            "logging level set to DEBUG if not otherwise specified.")

    return logging.getLogger()


def main() -> int:
    """
    Main entry point for the pycmsisdapswitcher CLI.

    Parses command-line arguments, sets up logging, and executes the selected action
    (application switch or recovery) for the specified target.

    Returns:
        int: Exit code. 0 on success, or error code 2 on failure.
    """
    exit_code = 0  # Set to 2 on failure before returning

    # Set up the CLI command arguments parser
    parser = __setup_args_parser()

    # Parse the CLI arguments
    args = parser.parse_args()

    # Set up the root logger
    logger = _setup_root_logger()

    # Change the root logger level based on the CLI command
    logger.setLevel(args.verbose.upper())

    # Execute the CLI command
    if args.version:
        print(f"Current version installed: {__version__}")

    elif not args.target and args.action != 'switch':
        logger.error("no target provided")

        exit_code = 2

    elif args.action == 'recover':
        if args.showhowto:
            # Output instructions to put target in recovery mode
            print(
                f"To put the {targets_info[args.target].target_output_name} in recovery mode,")
            print(targets_info[args.target].howto)

        # Start bootloader, then application recovery
        else:
            try:
                logger.info("bootloader and application recovery started")

                _recover_main(args)

                logger.info("bootloader and application recovery successful")
            except PyCmsisDapSwitcherError as e:
                logger.error("Recovery failed: %s", e)

                exit_code = 2
            except Exception as e:  # pylint: disable=broad-except
                logger.exception("unexpected: %s", e)

                exit_code = 2

    elif args.action == 'switch':
        # Start application switch
        try:
            logger.info("application switch started")

            _switcher_main(args)

            logger.info("application switch successful")
        except PyCmsisDapSwitcherError as e:
            logger.error("application switch failed: %s", e)

            exit_code = 2
        except Exception as e:  # pylint: disable=broad-except
            logger.exception("unexpected")

            exit_code = 2

    return exit_code
