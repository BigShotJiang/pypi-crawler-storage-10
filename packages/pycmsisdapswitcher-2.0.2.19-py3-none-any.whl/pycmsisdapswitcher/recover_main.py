'''
Main module of the pycmsisdapswitcher for bootloader + application recovery action
'''
import argparse
import logging
import os

from typing import Tuple

import serial.tools.list_ports

from pycmsisdapswitcher.cache_manager import CacheManager
from pycmsisdapswitcher.errors import (
    RecoveryError,
    TargetError,
)
from pycmsisdapswitcher.hex_file_downloader import (
    download_file, extract_hex_from_atpack)
from pycmsisdapswitcher.recovery_steps import do_recover
from pycmsisdapswitcher.switcher_main import switch
from pycmsisdapswitcher.targets_info import TARGETS_INFO as targets_info


# Named logger
logger = logging.getLogger(__name__)


# Helpers

def _detect_target_port(target: str) -> serial.Serial:
    '''
    Detect the serial port object associated to a target in recovery mode

    Args:
        target (str): The name of the target

    Returns:
        serial.Serial: The serial port object associated to the target

    Raises: TargetError

    '''
    # Get a list of the serial ports
    comports_list = list(serial.tools.list_ports.comports())

    # Find all the target serial ports matching the ATSAM in recovery mode (USB CDC)
    VID = 0x03eb  # pylint: disable=invalid-name
    PID = 0x6124  # pylint: disable=invalid-name

    matches = [port for port in comports_list if port.vid and port.vid ==
               VID and port.pid == PID]

    # Cannot operate on more than one target in recovery mode
    if len(matches) == 1:
        logger.info(
            "found %s in recovery mode, device path: %s", targets_info[target].target_output_name, matches[0])

        return serial.Serial(
            matches[0].device,
            baudrate=115200,
            bytesize=8,
            parity='N',
            stopbits=1,
        )

    if len(matches) > 1:
        logger.error(
            "%s: Multiple targets detected.\n"
            "Please disconnect all targets except the one you want to operate on, then retry.\n"
            "Run pycmsisdapswitcher --help for more info.", __name__)

        raise TargetError(
            "Multiple targets detected.\n"
            "Please disconnect all targets except the one you want to operate on, then retry.\n"
            "Run pycmsisdapswitcher --help for more info.")

    logger.error("%s: no target or board found in recovery mode", __name__)

    raise TargetError("no target or board found in recovery mode")


def _parse_arguments(arguments: argparse.Namespace) -> Tuple[str, str, str, str]:
    target = arguments.target

    bootsource = arguments.bootsource
    if not bootsource:
        bootsource = 'server'

    fw_source = arguments.appsource
    if not fw_source:
        fw_source = 'server'

    fw_type = arguments.fwtype
    if not fw_type:
        fw_type = 'cmsis'

    return target, bootsource, fw_source, fw_type


def recover(target: str, bootsource: str = 'server', appsource: str = 'server', fw_type: str = 'cmsis'):
    '''
    Recover bootloader and application firmware of a tool or board in recovery mode

    Args:
        target (str): The identifier of the target device to recover.
        bootsource (str, optional): Source for the bootloader HEX file. Can be a file path, 'server',
            or 'cache'. Defaults to 'server'.
        appsource (str, optional): Source for the application firmware. Can be a file path, 'server',
            or 'cache'. Defaults to 'server'.
        fw_type (str, optional): Firmware type to use for recovery. Defaults to 'cmsis'.

    Raises:
        RecoveryError: If no target is found in recovery mode, if there is an error accessing the server
            or cache to find the bootloader file, if the bootloader file cannot be written and verified 
            or if the bootloader enumeration times out.
    '''
    # Find the target in recovery mode
    with _detect_target_port(target) as target_serial_port:
        # Figure out which HEX file to write as a bootloader
        if bootsource.lower().endswith('.hex'):
            # HEX file directly provided in CLI command
            boot_hex_path = bootsource

            if not os.path.isabs(boot_hex_path):
                boot_hex_path = os.path.join(os.getcwd(), boot_hex_path)
        elif bootsource.lower().endswith('.atpack'):
            # HEX file to be retrieved from local .atpack
            try:
                boot_hex_path = extract_hex_from_atpack(
                    bootsource, targets_info[target].file_name.boot)
            except FileNotFoundError as exc:
                raise RecoveryError(
                    f'Firmware file not found in .atpack: {bootsource}') from exc
        elif bootsource == 'server':
            # HEX file from packs.download server
            boot_hex_path = download_file(
                target, fw_type='boot')
        else:
            # HEX file from cache
            cache = CacheManager()

            boot_hex_path = cache.get_file(
                file_name=targets_info[target].file_name.boot_cache)

        logger.info("using bootloader file %s", boot_hex_path)

        # Go through the bootloader recovery steps
        do_recover(target_serial_port, boot_hex_path)

    # Switch also works with the target already in bootloader mode,
    # so let's use it now to recover the application firmware
    # NOTE: entering recovery mode, the ATSAM Flash has been erased, so no need to erase it again switching app firmware
    #       Also when checking for multiple targets when switching app firmware, if this is the second step of recovery
    #       any target in application mode can be ignored
    switch(appsource, fw_type,
           is_action_recovery=True, boot_target=target)


def main(arguments: argparse.Namespace) -> int:
    '''
    Main function: process the arguments from the CLI command to recover the bootloader and application firmware

    Args:
        arguments (argparse.Namespace): Parsed command line arguments specifying target,
                                        boot source, firmware source and firmware type.    
    Raises: 
        RecoveryError
    '''
    target, bootsource, fw_source, fw_type = _parse_arguments(arguments)

    # This function can be called as part of the pycmsisdapswitcher library with named arguments
    recover(target, bootsource, fw_source, fw_type)
