'''
Provides functions to go through the bootloader file recovery steps
'''
import logging

import time

import usb.core

import serial
from serial import Serial
from intelhex import IntelHex

from pycmsisdapswitcher.boot_file_loader import (
    write_boot_file,
    verify_boot_file,
)

from pycmsisdapswitcher.samba_comm import (
    set_boot_mode_to_flash,
    execute_software_reset,
)

from pycmsisdapswitcher.errors import BootFileLoaderError, FlashWriteError, FlashVerifyError


# Named logger
logger = logging.getLogger(__name__)

# Helpers


def _set_binary_mode(target_serial_port: Serial) -> None:
    '''
    Set the target serial port to send and receive raw binary data

    Args:
        target_serial_port (Serial): The serial port used to communicate with the SAMBA monitor on the target

    Raises:
        serial.SerialException: If the binary mode couldn't be set

    '''
    command = b'N#'
    bytes_written = target_serial_port.write(command)
    if bytes_written == len(command):
        # NOTE: SAMBA Monitor replies here w/ b'\n\r'
        bytes_read = target_serial_port.read(len(command))
        if len(bytes_read) != len(command):
            logger.error("%s: failed to init target serial port", __name__)

            raise serial.SerialException("failed to init target serial port")
    else:
        logger.error("%s: failed to init target serial port", __name__)

        raise serial.SerialException("failed to init target serial port")


def _convert_boot_file(boot_hex_path: str) -> bytearray:
    boot_file_hex = IntelHex()

    boot_file_hex.fromfile(boot_hex_path, format='hex')

    return boot_file_hex.tobinarray()


def _wait_samba_monitor_de_enumerate():
    '''
    Wait for the SAMBA monitor USB CDC device to de-enumerate, or timeout

    Raises: BootFileLoaderError if the SAMBA monitor didn't de-enumerate
    '''
    # pylint: disable=invalid-name
    VID_MONITOR = 0x03eb  # ATMEL
    PID_MONITOR = 0x6124  # ATSAM
    USB_DE_ENUM_MS = 30_000
    POLL_INTERVAL_S = 0.2
    # pylint: enable=invalid-name

    start_time_s = time.perf_counter()

    while True:
        usb_device = usb.core.find(
            idVendor=VID_MONITOR, idProduct=PID_MONITOR, find_all=False)

        if usb_device is None:
            logger.debug("SAMBA monitor de-enumerated")

            break

        elapsed_time_s = time.perf_counter() - start_time_s
        if elapsed_time_s >= USB_DE_ENUM_MS / 1_000:
            logger.error("%s: SAMBA monitor didn't de-enumerate", __name__)

            raise BootFileLoaderError("SAMBA monitor didn't de-enumerate")

        time.sleep(POLL_INTERVAL_S)

# Main function


def do_recover(target_serial_port: serial.Serial, boot_file_hex_path: str) -> None:
    '''
    Opens a serial connection to the target device and performs the bootloader update sequence.

    Exceptions:
        Raises BootFileLoaderError on serial connection issues or if bootloader write/verify fails.
    '''
    try:
        # with serial.Serial(target_port, baudrate=115200, bytesize=8, parity="N", stopbits=1) as target_serial_port:
        # Because of the context manager, the serial port will be closed exiting the with block,
        # no matter what happens in it
        _set_binary_mode(target_serial_port)

        logger.debug("target serial port opened and configured")

        boot_file_array_of_bytes = _convert_boot_file(boot_file_hex_path)

        logger.info("bootloader being written and verified")

        write_boot_file(target_serial_port, boot_file_array_of_bytes)

        verify_boot_file(target_serial_port, boot_file_array_of_bytes)

        set_boot_mode_to_flash(target_serial_port)

        execute_software_reset(target_serial_port)

        _wait_samba_monitor_de_enumerate()
    except serial.SerialException as e:
        logger.error(e)
        raise BootFileLoaderError(f"{e}") from serial.SerialException
    except (FlashWriteError, FlashVerifyError) as e:
        raise BootFileLoaderError(f"{e}") from serial.SerialException
