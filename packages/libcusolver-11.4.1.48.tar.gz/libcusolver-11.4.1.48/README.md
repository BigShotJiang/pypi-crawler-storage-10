# libcusolver

A useful Python package with utility functions.

## Installation

```bash
pip install libcusolver
```

## Usage

```python
import libcusolver

print(libcusolver.hello_world())
result = libcusolver.add_numbers(5, 3)
print(result)
```
