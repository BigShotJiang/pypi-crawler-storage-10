"""
libcusolver - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libcusolver!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libcusolver",
        "version": "11.4.1.48",
        "description": "A useful Python package"
    }

# Package version
__version__ = "11.4.1.48"
