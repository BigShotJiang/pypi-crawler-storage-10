import sys
from setuptools import setup

ERROR_MESSAGE = '''⚠️ THIS PROJECT 'nvidia-cuda-profiler-api-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-profiler-api' instead.

To install the correct package, use:

    pip install nvidia-cuda-profiler-api

For more information, visit: https://pypi.org/project/nvidia-cuda-profiler-api/

'''

if any(arg in sys.argv for arg in ('bdist_wheel', 'bdist', 'wheel')):
    print(ERROR_MESSAGE, file=sys.stderr)
    sys.exit(1)

setup()
