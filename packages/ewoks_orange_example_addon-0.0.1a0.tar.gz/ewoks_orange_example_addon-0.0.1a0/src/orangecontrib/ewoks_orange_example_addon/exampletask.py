from AnyQt import QtWidgets
from ewoksorange.bindings import OWEwoksWidgetOneThread

from ewoks_orange_example_addon.tasks.exampletask import ExampleTask

__all__ = ["OWExampleTask"]


class OWExampleTask(OWEwoksWidgetOneThread, ewokstaskclass=ExampleTask):
    """Orange widget that delegates the computational aspect to an Ewoks task.

    The class stores two types of inputs:

    - Default inputs: user inputs saved in the workflow file.
    - Dynamic inputs: inputs from upstream nodes, not saved in the workflow file.

    This class implements Qt widgets to display the Ewoks task inputs and outputs.
    """

    name = "Demo"
    description = "Add +1 to a number"

    def __init__(self) -> None:
        super().__init__()
        self._init_control_area()
        self._init_main_area()

    def _init_control_area(self) -> None:
        """Widgets for user inputs."""
        super()._init_control_area()

        layout = self._get_control_layout()

        # Widget with callback for user input.
        label = QtWidgets.QLabel("Number")
        self._widgetNumber_value = QtWidgets.QSpinBox()
        self._widgetNumber_value.editingFinished.connect(self._default_inputs_changed)
        layout.addWidget(label)
        layout.addWidget(self._widgetNumber_value)

        layout.addStretch()

    def _init_main_area(self) -> None:
        """Widgets for results."""
        super()._init_main_area()
        layout = self._get_main_layout()

        # Output widget to show Ewoks task execution result.
        label = QtWidgets.QLabel("Result")
        self._widgetResult_value = QtWidgets.QLineEdit()
        self._widgetResult_value.setReadOnly(True)
        layout.addWidget(label)
        layout.addWidget(self._widgetResult_value)

        layout.addStretch()

    def _initialize_widgets(self) -> None:
        """Initialize widgets with inputs saved in the workflow file."""
        number = self.get_default_input_value("number", None)
        if number is not None:
            self._widgetNumber_value.setValue(number)

    def _default_inputs_changed(self) -> None:
        """Handle user inputs."""
        self.update_default_inputs(number=self._widgetNumber_value.value())

    def handleNewSignals(self) -> None:
        """Display parameters from upstream tasks."""
        number = self.get_dynamic_input_value("number", None)
        if number is not None:
            self._widgetNumber_value.setValue(number)
            self._widgetNumber_value.setReadOnly(True)
        else:
            self._widgetNumber_value.setReadOnly(False)
        super().handleNewSignals()

    def task_output_changed(self) -> None:
        """Display Ewoks task outputs."""
        result = self.get_task_output_value("result", None)
        if result is not None:
            self._widgetResult_value.setText(str(result))
        super().task_output_changed()
