NAME = "Ewoks Orange Demo"

DESCRIPTION = "An Ewoks project"
