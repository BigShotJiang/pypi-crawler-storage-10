from ewokscore import Task


class ExampleTask(Task, input_names=["number"], output_names=["result"]):
    """Add +1 to a number"""

    def run(self):
        self.outputs.result = self.inputs.number + 1
