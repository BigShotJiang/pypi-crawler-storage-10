from ewoksorange.tests.utils import execute_task

from orangecontrib.ewoks_orange_example_addon.exampletask import OWExampleTask


def test_example_task():
    assert_example_task(OWExampleTask, None)


def test_example_task_widget(qtapp):
    assert_example_task(OWExampleTask, qtapp)


def assert_example_task(widget, qtapp):
    task = widget.ewokstaskclass if qtapp is None else widget
    results = execute_task(task, inputs={"number": 1})
    assert results == {"result": 2}
