# yolodetection

`yolodetection` is a lightweight wrapper around Ultralytics YOLO + SAHI sliced inference.  
It’s designed so that **you only ever interact with one class: `YOLOInstance`**.

Main goals:
- Simple interface
- Handles large images using SAHI slicing
- Exports clean, JSON-ready detections (with centroids)
- Optional saving of prediction JSON + visualization masks to disk

---

## 🔧 Installation

```bash
pip install yolodetection
```

## Usage
```
from yolodetect import YoloInstance

instance = YoloInstance("models/best.pt")
instance.predict(/home/images/)
```