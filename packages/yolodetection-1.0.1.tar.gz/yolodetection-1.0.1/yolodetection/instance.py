from sahi import AutoDetectionModel
from predict import sliced_predict

class YOLOInstance:
    def __init__(self, weights="yolo11n.pt", device="cpu"):
        """
        :param weights: path to weights (e.g. yolo11n.pt)
        :param device: device to use ['cpu', 'cuda:0']
        """
        self.model = AutoDetectionModel.from_pretrained(
            model_type="ultralytics",
            model_path=weights,
            device=device
        )
    def predict(self, images, options=None):
        detections = sliced_predict(images, self.model, options)
        return detections