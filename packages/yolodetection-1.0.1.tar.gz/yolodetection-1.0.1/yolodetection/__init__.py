from .predict import sliced_predict
from .instance import YOLOInstance