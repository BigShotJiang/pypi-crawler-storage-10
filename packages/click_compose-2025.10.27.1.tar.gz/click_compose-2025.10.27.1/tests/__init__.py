"""
Tests for click-compose.
"""
