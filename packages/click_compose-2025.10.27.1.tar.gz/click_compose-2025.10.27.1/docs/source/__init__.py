"""
Documentation for click-compose.
"""
