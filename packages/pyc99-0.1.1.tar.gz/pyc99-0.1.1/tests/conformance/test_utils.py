"""
Utility functions for C99 conformance tests
"""

from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.utils.error_reporter import ErrorReporter


def compile_and_analyze(code: str, filename: str = "test.c"):
    """
    Compile and analyze C99 code.
    
    Args:
        code: C99 source code
        filename: Source filename
        
    Returns:
        tuple: (ast, error_reporter, analyzer)
    """
    tokenizer = Tokenizer(code, filename)
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    analyzer.analyze()
    return ast, error_reporter, analyzer


def assert_no_errors(code: str, filename: str = "test.c"):
    """
    Assert that code compiles without errors.
    
    Args:
        code: C99 source code
        filename: Source filename
    """
    _, error_reporter, _ = compile_and_analyze(code, filename)
    if error_reporter.has_errors():
        # Print errors for debugging
        error_reporter.print_diagnostics()
    assert not error_reporter.has_errors(), "Expected no errors but compilation failed"


def assert_has_errors(code: str, filename: str = "test.c"):
    """
    Assert that code produces compilation errors.
    
    Args:
        code: C99 source code
        filename: Source filename
    """
    _, error_reporter, _ = compile_and_analyze(code, filename)
    assert error_reporter.has_errors(), "Expected errors but compilation succeeded"
