"""
C99 Pointers and Arrays Conformance Tests

Tests C99 pointer and array features including:
- Pointer declarations and operations
- Array declarations and indexing
- Pointer arithmetic
- Multi-dimensional arrays
- Array-pointer relationships
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99Pointers:
    """Test C99 pointer features"""
    
    def test_pointer_declaration(self):
        """Test pointer declarations"""
        code = """
        int *p1;
        int **p2;
        int ***p3;
        void *vp;
        """
        assert_no_errors(code)
    
    def test_address_of_operator(self):
        """Test address-of operator"""
        code = """
        int test(void) {
            int x = 10;
            int *p = &x;
            return *p;
        }
        """
        assert_no_errors(code)
    
    def test_dereference_operator(self):
        """Test dereference operator"""
        code = """
        int test(int *p) {
            return *p;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic(self):
        """Test pointer arithmetic"""
        code = """
        int test(int *p, int n) {
            int *q = p + n;
            int *r = p - n;
            int diff = q - p;
            p++;
            p--;
            return diff;
        }
        """
        assert_no_errors(code)
    
    def test_null_pointer(self):
        """Test null pointer"""
        code = """
        int test(void) {
            int *p = 0;
            void *vp = 0;
            return p == 0;
        }
        """
        assert_no_errors(code)


class TestC99Arrays:
    """Test C99 array features"""
    
    def test_array_declaration(self):
        """Test array declarations"""
        code = """
        int arr1[10];
        int arr2[5][10];
        int arr3[3][4][5];
        """
        assert_no_errors(code)
    
    def test_array_initialization(self):
        """Test array initialization"""
        code = """
        int arr1[5] = {1, 2, 3, 4, 5};
        int arr2[5] = {1, 2, 3};
        int arr3[] = {1, 2, 3, 4, 5};
        char str[] = "hello";
        """
        assert_no_errors(code)
    
    def test_array_indexing(self):
        """Test array indexing"""
        code = """
        int test(void) {
            int arr[10];
            arr[0] = 1;
            arr[5] = 10;
            return arr[0] + arr[5];
        }
        """
        assert_no_errors(code)
    
    def test_multidimensional_arrays(self):
        """Test multi-dimensional array access"""
        code = """
        int test(void) {
            int matrix[3][4];
            matrix[0][0] = 1;
            matrix[2][3] = 10;
            return matrix[0][0] + matrix[2][3];
        }
        """
        assert_no_errors(code)


class TestC99ArrayPointerRelationship:
    """Test C99 array-pointer relationship"""
    
    def test_array_to_pointer_decay(self):
        """Test array to pointer decay"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            return p[0];
        }
        """
        assert_no_errors(code)
    
    def test_array_parameter(self):
        """Test array as function parameter"""
        code = """
        int sum(int arr[], int n) {
            int total = 0;
            for (int i = 0; i < n; i++) {
                total += arr[i];
            }
            return total;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_indexing(self):
        """Test pointer indexing like array"""
        code = """
        int test(int *p) {
            return p[0] + p[1] + p[2];
        }
        """
        assert_no_errors(code)


class TestC99StringLiterals:
    """Test C99 string literal features"""
    
    def test_string_literal_declaration(self):
        """Test string literal declarations"""
        code = """
        char *s1 = "hello";
        char s2[] = "world";
        """
        assert_no_errors(code)
    
    def test_string_escape_sequences(self):
        """Test string escape sequences"""
        code = """
        char *s1 = "hello\\nworld";
        char *s2 = "tab\\there";
        char *s3 = "quote\\"here";
        char *s4 = "backslash\\\\here";
        """
        assert_no_errors(code)
