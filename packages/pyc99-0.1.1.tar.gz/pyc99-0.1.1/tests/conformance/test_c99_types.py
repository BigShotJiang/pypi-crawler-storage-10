"""
C99 Type System Conformance Tests

Tests all C99 type features including:
- Basic types (char, int, float, double)
- Type qualifiers (const, volatile, restrict)
- Storage classes (static, extern, auto, register)
- Complex declarators
- Type compatibility
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99BasicTypes:
    """Test C99 basic type declarations and usage"""
    
    def test_all_integer_types(self):
        """Test all C99 integer types"""
        code = """
        char c = 'a';
        signed char sc = -1;
        unsigned char uc = 255;
        short s = -100;
        unsigned short us = 100;
        int i = -1000;
        unsigned int ui = 1000;
        long l = -100000L;
        unsigned long ul = 100000UL;
        long long ll = -1000000LL;
        unsigned long long ull = 1000000ULL;
        """
        assert_no_errors(code)
    
    def test_floating_point_types(self):
        """Test all C99 floating-point types"""
        code = """
        float f = 3.14f;
        double d = 3.14159;
        long double ld = 3.14159265358979L;
        """
        assert_no_errors(code)
    
    def test_void_type(self):
        """Test void type in function declarations"""
        code = """
        void func(void) {
            return;
        }
        """
        assert_no_errors(code)


class TestC99TypeQualifiers:
    """Test C99 type qualifiers"""
    
    def test_const_qualifier(self):
        """Test const type qualifier"""
        code = """
        const int ci = 10;
        int const ic = 20;
        const int *cip;
        int *const ipc = 0;
        const int *const cipc = 0;
        """
        assert_no_errors(code)
    
    def test_volatile_qualifier(self):
        """Test volatile type qualifier"""
        code = """
        volatile int vi = 0;
        int volatile iv = 0;
        volatile int *vip;
        """
        assert_no_errors(code)
    
    def test_restrict_qualifier(self):
        """Test restrict type qualifier (C99)"""
        code = """
        void func(int *restrict p1, int *restrict p2) {
            *p1 = *p2;
        }
        """
        assert_no_errors(code)


class TestC99StorageClasses:
    """Test C99 storage class specifiers"""
    
    def test_static_storage(self):
        """Test static storage class"""
        code = """
        static int si = 10;
        
        void func(void) {
            static int local_static = 0;
            local_static++;
        }
        """
        assert_no_errors(code)
    
    def test_extern_storage(self):
        """Test extern storage class"""
        code = """
        extern int ei;
        extern void external_func(void);
        """
        assert_no_errors(code)


class TestC99ComplexDeclarators:
    """Test complex C99 declarators"""
    
    def test_pointer_declarators(self):
        """Test pointer declarators"""
        code = """
        int *p;
        int **pp;
        int ***ppp;
        """
        assert_no_errors(code)
    
    def test_array_declarators(self):
        """Test array declarators"""
        code = """
        int arr[10];
        int matrix[5][10];
        int cube[3][4][5];
        """
        assert_no_errors(code)
    
    def test_function_pointer_declarators(self):
        """Test function pointer declarators"""
        code = """
        int (*fp)(int, int);
        int (*fpa[10])(void);
        int (**fpp)(int);
        """
        assert_no_errors(code)
    
    def test_mixed_declarators(self):
        """Test complex mixed declarators"""
        code = """
        int *arr[10];
        int (*parr)[10];
        int *(*fp)(int);
        """
        assert_no_errors(code)
