"""
C99 Statement Conformance Tests

Tests all C99 statement types including:
- Expression statements
- Compound statements
- Selection statements (if, switch)
- Iteration statements (while, do-while, for)
- Jump statements (goto, continue, break, return)
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99SelectionStatements:
    """Test C99 selection statements"""
    
    def test_if_statement(self):
        """Test if statement"""
        code = """
        int test(int x) {
            if (x > 0) {
                return 1;
            }
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_if_else_statement(self):
        """Test if-else statement"""
        code = """
        int test(int x) {
            if (x > 0) {
                return 1;
            } else {
                return -1;
            }
        }
        """
        assert_no_errors(code)
    
    def test_nested_if(self):
        """Test nested if statements"""
        code = """
        int test(int x, int y) {
            if (x > 0) {
                if (y > 0) {
                    return 1;
                } else {
                    return 2;
                }
            } else {
                return 3;
            }
        }
        """
        assert_no_errors(code)
    
    def test_switch_statement(self):
        """Test switch statement"""
        code = """
        int test(int x) {
            switch (x) {
                case 1:
                    return 10;
                case 2:
                    return 20;
                default:
                    return 0;
            }
        }
        """
        assert_no_errors(code)
    
    def test_switch_fallthrough(self):
        """Test switch statement with fall-through"""
        code = """
        int test(int x) {
            int result = 0;
            switch (x) {
                case 1:
                    result += 1;
                case 2:
                    result += 2;
                    break;
                case 3:
                    result += 3;
                    break;
                default:
                    result = -1;
            }
            return result;
        }
        """
        assert_no_errors(code)


class TestC99IterationStatements:
    """Test C99 iteration statements"""
    
    def test_while_loop(self):
        """Test while loop"""
        code = """
        int test(int n) {
            int sum = 0;
            int i = 0;
            while (i < n) {
                sum += i;
                i++;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_do_while_loop(self):
        """Test do-while loop"""
        code = """
        int test(int n) {
            int sum = 0;
            int i = 0;
            do {
                sum += i;
                i++;
            } while (i < n);
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_for_loop(self):
        """Test for loop"""
        code = """
        int test(int n) {
            int sum = 0;
            for (int i = 0; i < n; i++) {
                sum += i;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_nested_loops(self):
        """Test nested loops"""
        code = """
        int test(int n, int m) {
            int sum = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    sum += i * j;
                }
            }
            return sum;
        }
        """
        assert_no_errors(code)


class TestC99JumpStatements:
    """Test C99 jump statements"""
    
    def test_break_statement(self):
        """Test break statement"""
        code = """
        int test(int n) {
            int i = 0;
            while (1) {
                if (i >= n) {
                    break;
                }
                i++;
            }
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_continue_statement(self):
        """Test continue statement"""
        code = """
        int test(int n) {
            int sum = 0;
            for (int i = 0; i < n; i++) {
                if (i % 2 == 0) {
                    continue;
                }
                sum += i;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_return_statement(self):
        """Test return statement"""
        code = """
        int test1(void) {
            return 42;
        }
        
        void test2(void) {
            return;
        }
        """
        assert_no_errors(code)
    
    def test_goto_statement(self):
        """Test goto statement"""
        code = """
        int test(int n) {
            int i = 0;
            loop:
            if (i < n) {
                i++;
                goto loop;
            }
            return i;
        }
        """
        assert_no_errors(code)


class TestC99CompoundStatements:
    """Test C99 compound statements"""
    
    def test_empty_compound(self):
        """Test empty compound statement"""
        code = """
        void test(void) {
            {}
        }
        """
        assert_no_errors(code)
    
    def test_nested_scopes(self):
        """Test nested scopes in compound statements"""
        code = """
        int test(void) {
            int x = 1;
            {
                int x = 2;
                {
                    int x = 3;
                }
            }
            return x;
        }
        """
        assert_no_errors(code)
