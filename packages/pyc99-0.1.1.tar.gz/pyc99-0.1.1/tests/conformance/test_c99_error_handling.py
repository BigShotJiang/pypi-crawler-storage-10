"""
C99 Error Handling Conformance Tests

Tests that the compiler correctly detects and reports errors for:
- Syntax errors
- Type errors
- Semantic errors
- Undefined behavior
"""

import pytest
from tests.conformance.test_utils import assert_has_errors
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser


class TestC99SyntaxErrors:
    """Test C99 syntax error detection"""
    
    def test_missing_semicolon(self):
        """Test detection of missing semicolon"""
        code = """
        int test(void) {
            int x = 10
            return x;
        }
        """
        tokenizer = Tokenizer(code, "test.c")
        parser = Parser(tokenizer)
        with pytest.raises(Exception):
            parser.parse_translation_unit()
    
    def test_unmatched_braces(self):
        """Test detection of unmatched braces"""
        code = """
        int test(void) {
            int x = 10;
            return x;
        """
        tokenizer = Tokenizer(code, "test.c")
        parser = Parser(tokenizer)
        with pytest.raises(Exception):
            parser.parse_translation_unit()
    
    def test_invalid_expression(self):
        """Test detection of invalid expression"""
        code = """
        int test(void) {
            int x = 10 +;
            return x;
        }
        """
        tokenizer = Tokenizer(code, "test.c")
        parser = Parser(tokenizer)
        with pytest.raises(Exception):
            parser.parse_translation_unit()


class TestC99TypeErrors:
    """Test C99 type error detection"""
    
    def test_type_mismatch_assignment(self):
        """Test detection of type mismatch in assignment"""
        code = """
        int test(void) {
            int *p;
            int x = p;
            return x;
        }
        """
        assert_has_errors(code)
    
    def test_incompatible_pointer_types(self):
        """Test detection of incompatible pointer types"""
        code = """
        int test(void) {
            int *ip;
            float *fp = ip;
            return 0;
        }
        """
        assert_has_errors(code)
    
    def test_invalid_operand_types(self):
        """Test detection of invalid operand types"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(void) {
            struct Point p1, p2;
            struct Point p3 = p1 + p2;
            return 0;
        }
        """
        assert_has_errors(code)


class TestC99SemanticErrors:
    """Test C99 semantic error detection"""
    
    def test_undefined_variable(self):
        """Test detection of undefined variable"""
        code = """
        int test(void) {
            return undefined_var;
        }
        """
        assert_has_errors(code)
    
    def test_undefined_function(self):
        """Test detection of undefined function"""
        code = """
        int test(void) {
            return undefined_func();
        }
        """
        assert_has_errors(code)
    
    def test_redeclaration(self):
        """Test detection of variable redeclaration"""
        code = """
        int test(void) {
            int x = 10;
            int x = 20;
            return x;
        }
        """
        assert_has_errors(code)
    
    def test_wrong_argument_count(self):
        """Test detection of wrong argument count"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        
        int test(void) {
            return add(10);
        }
        """
        assert_has_errors(code)
    
    def test_return_type_mismatch(self):
        """Test detection of return type mismatch"""
        code = """
        int test(void) {
            return "string";
        }
        """
        assert_has_errors(code)


class TestC99StructErrors:
    """Test C99 struct-related error detection"""
    
    def test_undefined_struct_member(self):
        """Test detection of undefined struct member"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(void) {
            struct Point p;
            return p.z;
        }
        """
        assert_has_errors(code)
    
    def test_member_access_on_non_struct(self):
        """Test detection of member access on non-struct"""
        code = """
        int test(void) {
            int x = 10;
            return x.field;
        }
        """
        assert_has_errors(code)


class TestC99PointerErrors:
    """Test C99 pointer-related error detection"""
    
    def test_dereference_non_pointer(self):
        """Test detection of dereferencing non-pointer"""
        code = """
        int test(void) {
            int x = 10;
            return *x;
        }
        """
        assert_has_errors(code)
    
    def test_address_of_non_lvalue(self):
        """Test detection of address-of on non-lvalue"""
        code = """
        int test(void) {
            int *p = &(10 + 20);
            return 0;
        }
        """
        assert_has_errors(code)
