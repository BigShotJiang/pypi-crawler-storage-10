"""
C99 Function Conformance Tests

Tests C99 function features including:
- Function declarations and definitions
- Function parameters
- Function return values
- Function pointers
- Variadic functions
- Recursion
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99Functions:
    """Test C99 function features"""
    
    def test_function_declaration(self):
        """Test function declarations"""
        code = """
        int func1(void);
        int func2(int x);
        int func3(int x, int y);
        void func4(void);
        """
        assert_no_errors(code)
    
    def test_function_definition(self):
        """Test function definitions"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        """
        assert_no_errors(code)
    
    def test_function_call(self):
        """Test function calls"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        
        int test(void) {
            return add(10, 20);
        }
        """
        assert_no_errors(code)
    
    def test_void_function(self):
        """Test void functions"""
        code = """
        void print_message(void) {
            return;
        }
        
        void test(void) {
            print_message();
        }
        """
        assert_no_errors(code)


class TestC99FunctionParameters:
    """Test C99 function parameter features"""
    
    def test_multiple_parameters(self):
        """Test functions with multiple parameters"""
        code = """
        int func(int a, int b, int c, int d) {
            return a + b + c + d;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_parameters(self):
        """Test pointer parameters"""
        code = """
        void swap(int *a, int *b) {
            int temp = *a;
            *a = *b;
            *b = temp;
        }
        """
        assert_no_errors(code)
    
    def test_array_parameters(self):
        """Test array parameters"""
        code = """
        int sum(int arr[], int n) {
            int total = 0;
            for (int i = 0; i < n; i++) {
                total += arr[i];
            }
            return total;
        }
        """
        assert_no_errors(code)
    
    def test_struct_parameters(self):
        """Test struct parameters"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int distance_squared(struct Point p1, struct Point p2) {
            int dx = p2.x - p1.x;
            int dy = p2.y - p1.y;
            return dx * dx + dy * dy;
        }
        """
        assert_no_errors(code)


class TestC99FunctionPointers:
    """Test C99 function pointer features"""
    
    def test_function_pointer_declaration(self):
        """Test function pointer declarations"""
        code = """
        int (*fp)(int, int);
        void (*vfp)(void);
        """
        assert_no_errors(code)
    
    def test_function_pointer_assignment(self):
        """Test function pointer assignment"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        
        int test(void) {
            int (*fp)(int, int) = add;
            return fp(10, 20);
        }
        """
        assert_no_errors(code)
    
    def test_function_pointer_parameter(self):
        """Test function pointer as parameter"""
        code = """
        int apply(int (*op)(int, int), int a, int b) {
            return op(a, b);
        }
        
        int add(int a, int b) {
            return a + b;
        }
        
        int test(void) {
            return apply(add, 10, 20);
        }
        """
        assert_no_errors(code)


class TestC99VariadicFunctions:
    """Test C99 variadic function features"""
    
    def test_variadic_declaration(self):
        """Test variadic function declarations"""
        code = """
        int printf(const char *fmt, ...);
        int sum(int count, ...);
        """
        assert_no_errors(code)
    
    def test_variadic_definition(self):
        """Test variadic function definitions"""
        code = """
        int sum(int count, ...) {
            return 0;
        }
        """
        assert_no_errors(code)


class TestC99Recursion:
    """Test C99 recursive functions"""
    
    def test_simple_recursion(self):
        """Test simple recursive function"""
        code = """
        int factorial(int n) {
            if (n <= 1) {
                return 1;
            }
            return n * factorial(n - 1);
        }
        """
        assert_no_errors(code)
    
    def test_mutual_recursion(self):
        """Test mutually recursive functions"""
        code = """
        int is_even(int n);
        int is_odd(int n);
        
        int is_even(int n) {
            if (n == 0) return 1;
            return is_odd(n - 1);
        }
        
        int is_odd(int n) {
            if (n == 0) return 0;
            return is_even(n - 1);
        }
        """
        assert_no_errors(code)
