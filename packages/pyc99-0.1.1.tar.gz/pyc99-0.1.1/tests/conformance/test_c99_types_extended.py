"""
Extended C99 Type System Conformance Tests

Comprehensive tests for complex type declarations, typedef chains,
function pointer types, and advanced type system features.
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestComplexTypeDeclarations:
    """Test complex and nested type declarations"""
    
    def test_pointer_to_array(self):
        """Test pointer to array type"""
        code = """
        int (*ptr)[10];
        int arr[10];
        ptr = &arr;
        """
        assert_no_errors(code)
    
    def test_array_of_pointers(self):
        """Test array of pointers type"""
        code = """
        int *arr[10];
        int x = 5;
        arr[0] = &x;
        """
        assert_no_errors(code)
    
    def test_pointer_to_pointer_to_array(self):
        """Test pointer to pointer to array"""
        code = """
        int (*(*ppa)[10]);
        int (*pa)[10];
        ppa = &pa;
        """
        assert_no_errors(code)
    
    def test_array_of_array_of_pointers(self):
        """Test multi-dimensional array of pointers"""
        code = """
        int *arr[5][10];
        int x = 42;
        arr[0][0] = &x;
        """
        assert_no_errors(code)
    
    def test_pointer_to_function_returning_pointer(self):
        """Test pointer to function returning pointer"""
        code = """
        int *(*fp)(int);
        int *func(int x) {
            return 0;
        }
        fp = func;
        """
        assert_no_errors(code)
    
    def test_function_returning_pointer_to_array(self):
        """Test function returning pointer to array"""
        code = """
        int (*func(void))[10] {
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_array_of_function_pointers(self):
        """Test array of function pointers"""
        code = """
        int (*arr[10])(int, int);
        int add(int a, int b) { return a + b; }
        arr[0] = add;
        """
        assert_no_errors(code)
    
    def test_pointer_to_array_of_function_pointers(self):
        """Test pointer to array of function pointers"""
        code = """
        int (*(*parr)[10])(int);
        """
        assert_no_errors(code)
    
    def test_const_pointer_to_const_pointer(self):
        """Test const pointer to const pointer"""
        code = """
        const int * const * const ppc = 0;
        """
        assert_no_errors(code)
    
    def test_volatile_pointer_to_volatile(self):
        """Test volatile pointer to volatile data"""
        code = """
        volatile int * volatile vp;
        """
        assert_no_errors(code)


class TestTypedefChains:
    """Test typedef chains and complex typedef scenarios"""
    
    def test_simple_typedef_chain(self):
        """Test simple typedef chain"""
        code = """
        typedef int Int;
        typedef Int MyInt;
        typedef MyInt YourInt;
        YourInt x = 42;
        """
        assert_no_errors(code)
    
    def test_pointer_typedef_chain(self):
        """Test typedef chain with pointers"""
        code = """
        typedef int* IntPtr;
        typedef IntPtr* IntPtrPtr;
        typedef IntPtrPtr* IntPtrPtrPtr;
        IntPtrPtrPtr pppp;
        """
        assert_no_errors(code)
    
    def test_array_typedef_chain(self):
        """Test typedef chain with arrays"""
        code = """
        typedef int IntArray[10];
        typedef IntArray IntMatrix[5];
        IntMatrix matrix;
        """
        assert_no_errors(code)
    
    def test_struct_typedef_chain(self):
        """Test typedef chain with structs"""
        code = """
        typedef struct { int x; int y; } Point;
        typedef Point Point2D;
        typedef Point2D Coordinate;
        Coordinate c;
        """
        assert_no_errors(code)
    
    def test_function_pointer_typedef_chain(self):
        """Test typedef chain with function pointers"""
        code = """
        typedef int (*BinaryOp)(int, int);
        typedef BinaryOp Operation;
        typedef Operation Calculator;
        Calculator calc;
        """
        assert_no_errors(code)
    
    def test_mixed_typedef_chain(self):
        """Test typedef chain mixing different types"""
        code = """
        typedef int Int;
        typedef Int* IntPtr;
        typedef IntPtr IntPtrArray[10];
        typedef IntPtrArray* IntPtrArrayPtr;
        IntPtrArrayPtr paptr;
        """
        assert_no_errors(code)
    
    def test_typedef_with_qualifiers_chain(self):
        """Test typedef chain preserving qualifiers"""
        code = """
        typedef const int ConstInt;
        typedef ConstInt* ConstIntPtr;
        typedef ConstIntPtr const ConstConstIntPtr;
        ConstConstIntPtr ccip = 0;
        """
        assert_no_errors(code)
    
    def test_typedef_circular_reference(self):
        """Test typedef with struct for circular reference"""
        code = """
        typedef struct Node Node;
        struct Node {
            int data;
            Node *next;
        };
        Node n;
        """
        assert_no_errors(code)


class TestFunctionPointerTypes:
    """Test function pointer type declarations and usage"""
    
    def test_simple_function_pointer(self):
        """Test simple function pointer"""
        code = """
        int (*fp)(int);
        int square(int x) { return x * x; }
        fp = square;
        int result = fp(5);
        """
        assert_no_errors(code)
    
    def test_function_pointer_no_parameters(self):
        """Test function pointer with no parameters"""
        code = """
        int (*fp)(void);
        int get_value(void) { return 42; }
        fp = get_value;
        """
        assert_no_errors(code)
    
    def test_function_pointer_multiple_parameters(self):
        """Test function pointer with multiple parameters"""
        code = """
        int (*fp)(int, int, int);
        int sum3(int a, int b, int c) { return a + b + c; }
        fp = sum3;
        """
        assert_no_errors(code)
    
    def test_function_pointer_returning_pointer(self):
        """Test function pointer returning pointer"""
        code = """
        int *(*fp)(int);
        int *alloc(int size) { return 0; }
        fp = alloc;
        """
        assert_no_errors(code)
    
    def test_function_pointer_taking_pointer(self):
        """Test function pointer taking pointer parameter"""
        code = """
        void (*fp)(int*);
        void process(int *p) { *p = 10; }
        fp = process;
        """
        assert_no_errors(code)
    
    def test_function_pointer_taking_function_pointer(self):
        """Test function pointer taking function pointer"""
        code = """
        int (*fp)(int (*)(int));
        int apply(int (*f)(int)) { return f(5); }
        fp = apply;
        """
        assert_no_errors(code)
    
    def test_function_pointer_returning_function_pointer(self):
        """Test function pointer returning function pointer"""
        code = """
        int (*(*fp)(void))(int);
        int square(int x) { return x * x; }
        int (*get_func(void))(int) { return square; }
        fp = get_func;
        """
        assert_no_errors(code)
    
    def test_array_of_function_pointers_usage(self):
        """Test using array of function pointers"""
        code = """
        int add(int a, int b) { return a + b; }
        int sub(int a, int b) { return a - b; }
        int mul(int a, int b) { return a * b; }
        
        int (*ops[3])(int, int);
        ops[0] = add;
        ops[1] = sub;
        ops[2] = mul;
        
        int result = ops[0](5, 3);
        """
        assert_no_errors(code)
    
    def test_struct_with_function_pointers(self):
        """Test struct containing function pointers"""
        code = """
        typedef struct {
            int (*add)(int, int);
            int (*sub)(int, int);
        } Operations;
        
        int add_impl(int a, int b) { return a + b; }
        int sub_impl(int a, int b) { return a - b; }
        
        Operations ops;
        ops.add = add_impl;
        ops.sub = sub_impl;
        """
        assert_no_errors(code)
    
    def test_typedef_function_pointer_in_struct(self):
        """Test typedef'd function pointer in struct"""
        code = """
        typedef int (*Callback)(int);
        
        typedef struct {
            Callback on_event;
            int data;
        } Handler;
        
        Handler h;
        """
        assert_no_errors(code)


class TestComplexStructTypes:
    """Test complex struct type declarations"""
    
    def test_struct_with_pointer_to_self(self):
        """Test struct with pointer to itself"""
        code = """
        struct Node {
            int data;
            struct Node *next;
        };
        struct Node n;
        """
        assert_no_errors(code)
    
    def test_struct_with_array_member(self):
        """Test struct with array member"""
        code = """
        struct Buffer {
            char data[256];
            int size;
        };
        struct Buffer buf;
        """
        assert_no_errors(code)
    
    def test_struct_with_nested_struct(self):
        """Test struct with nested struct"""
        code = """
        struct Inner {
            int x;
        };
        struct Outer {
            struct Inner inner;
            int y;
        };
        struct Outer o;
        """
        assert_no_errors(code)
    
    def test_struct_with_anonymous_nested_struct(self):
        """Test struct with anonymous nested struct"""
        code = """
        struct Outer {
            struct {
                int x;
                int y;
            } point;
            int z;
        };
        struct Outer o;
        """
        assert_no_errors(code)
    
    def test_struct_with_function_pointer_member(self):
        """Test struct with function pointer member"""
        code = """
        struct Callback {
            void (*handler)(int);
            int data;
        };
        struct Callback cb;
        """
        assert_no_errors(code)
    
    def test_struct_with_const_members(self):
        """Test struct with const members"""
        code = """
        struct Config {
            const int max_size;
            const char *name;
        };
        """
        assert_no_errors(code)
    
    def test_typedef_struct_with_pointer_to_typedef(self):
        """Test typedef struct with pointer to typedef"""
        code = """
        typedef struct Node Node;
        struct Node {
            int data;
            Node *next;
            Node *prev;
        };
        """
        assert_no_errors(code)


class TestQualifiedTypes:
    """Test type qualifiers in complex scenarios"""
    
    def test_const_array(self):
        """Test const array"""
        code = """
        const int arr[10] = {0};
        """
        assert_no_errors(code)
    
    def test_array_of_const(self):
        """Test array of const elements"""
        code = """
        const int *arr[10];
        """
        assert_no_errors(code)
    
    def test_const_pointer_to_array(self):
        """Test const pointer to array"""
        code = """
        int (*const ptr)[10];
        """
        assert_no_errors(code)
    
    def test_pointer_to_const_array(self):
        """Test pointer to const array"""
        code = """
        const int (*ptr)[10];
        """
        assert_no_errors(code)
    
    def test_volatile_struct_member(self):
        """Test volatile struct member"""
        code = """
        struct Device {
            volatile int status;
            int data;
        };
        """
        assert_no_errors(code)
    
    def test_const_struct_pointer(self):
        """Test const struct pointer"""
        code = """
        struct Point { int x; int y; };
        const struct Point *cp;
        """
        assert_no_errors(code)
    
    def test_restrict_pointers_in_function(self):
        """Test restrict pointers in function"""
        code = """
        void copy(int *restrict dest, const int *restrict src, int n) {
            for (int i = 0; i < n; i++) {
                dest[i] = src[i];
            }
        }
        """
        assert_no_errors(code)
    
    def test_multiple_qualifiers_combination(self):
        """Test multiple qualifiers on same type"""
        code = """
        const volatile int cvi = 0;
        const volatile int *cvip;
        """
        assert_no_errors(code)


class TestUnionTypes:
    """Test union type declarations"""
    
    def test_simple_union(self):
        """Test simple union"""
        code = """
        union Data {
            int i;
            float f;
            char c;
        };
        union Data d;
        """
        assert_no_errors(code)
    
    def test_union_with_array(self):
        """Test union with array member"""
        code = """
        union Buffer {
            char bytes[4];
            int value;
        };
        union Buffer buf;
        """
        assert_no_errors(code)
    
    def test_union_with_struct(self):
        """Test union with struct member"""
        code = """
        union Mixed {
            struct { int x; int y; } point;
            long long value;
        };
        union Mixed m;
        """
        assert_no_errors(code)
    
    def test_typedef_union(self):
        """Test typedef with union"""
        code = """
        typedef union {
            int i;
            float f;
        } Number;
        Number n;
        """
        assert_no_errors(code)
    
    def test_union_in_struct(self):
        """Test union as struct member"""
        code = """
        struct Variant {
            int type;
            union {
                int i;
                float f;
                char *s;
            } value;
        };
        struct Variant v;
        """
        assert_no_errors(code)


class TestEnumTypes:
    """Test enum type declarations"""
    
    def test_enum_with_explicit_values(self):
        """Test enum with explicit values"""
        code = """
        enum Status {
            OK = 0,
            ERROR = -1,
            PENDING = 1
        };
        enum Status s = OK;
        """
        assert_no_errors(code)
    
    def test_enum_with_mixed_values(self):
        """Test enum with mixed explicit and implicit values"""
        code = """
        enum Flags {
            FLAG_A = 1,
            FLAG_B,
            FLAG_C = 10,
            FLAG_D
        };
        """
        assert_no_errors(code)
    
    def test_typedef_enum_usage(self):
        """Test typedef enum usage"""
        code = """
        typedef enum {
            RED, GREEN, BLUE
        } Color;
        Color c = RED;
        """
        assert_no_errors(code)
    
    def test_enum_in_struct(self):
        """Test enum as struct member"""
        code = """
        enum State { IDLE, RUNNING, STOPPED };
        struct Process {
            enum State state;
            int pid;
        };
        """
        assert_no_errors(code)


class TestTypeCompatibility:
    """Test type compatibility and conversions"""
    
    def test_pointer_to_void_conversion(self):
        """Test pointer to void* conversion"""
        code = """
        int x = 5;
        int *ip = &x;
        void *vp = ip;
        int *ip2 = vp;
        """
        assert_no_errors(code)
    
    def test_array_to_pointer_decay(self):
        """Test array to pointer decay"""
        code = """
        int arr[10];
        int *p = arr;
        """
        assert_no_errors(code)
    
    def test_function_to_pointer_decay(self):
        """Test function to pointer decay"""
        code = """
        int func(int x) { return x; }
        int (*fp)(int) = func;
        """
        assert_no_errors(code)
    
    def test_null_pointer_constant(self):
        """Test null pointer constant"""
        code = """
        int *p1 = 0;
        char *p2 = 0;
        void *p3 = 0;
        """
        assert_no_errors(code)


class TestSizeofOperator:
    """Test sizeof operator with complex types"""
    
    def test_sizeof_basic_types(self):
        """Test sizeof with basic types"""
        code = """
        int s1 = sizeof(char);
        int s2 = sizeof(int);
        int s3 = sizeof(long);
        int s4 = sizeof(float);
        int s5 = sizeof(double);
        """
        assert_no_errors(code)
    
    def test_sizeof_pointer_types(self):
        """Test sizeof with pointer types"""
        code = """
        int s1 = sizeof(int*);
        int s2 = sizeof(char*);
        int s3 = sizeof(void*);
        """
        assert_no_errors(code)
    
    def test_sizeof_array_types(self):
        """Test sizeof with array types"""
        code = """
        int arr[10];
        int s1 = sizeof(arr);
        int s2 = sizeof(arr[0]);
        """
        assert_no_errors(code)
    
    def test_sizeof_struct_types(self):
        """Test sizeof with struct types"""
        code = """
        struct Point { int x; int y; };
        int s1 = sizeof(struct Point);
        struct Point p;
        int s2 = sizeof(p);
        """
        assert_no_errors(code)
    
    def test_sizeof_typedef_types(self):
        """Test sizeof with typedef types"""
        code = """
        typedef int IntArray[10];
        int s = sizeof(IntArray);
        """
        assert_no_errors(code)


class TestCastExpressions:
    """Test type casting"""
    
    def test_basic_casts(self):
        """Test basic type casts"""
        code = """
        int i = 10;
        float f = (float)i;
        char c = (char)i;
        long l = (long)i;
        """
        assert_no_errors(code)
    
    def test_pointer_casts(self):
        """Test pointer casts"""
        code = """
        int x = 5;
        int *ip = &x;
        void *vp = (void*)ip;
        char *cp = (char*)vp;
        """
        assert_no_errors(code)
    
    def test_function_pointer_cast(self):
        """Test function pointer cast"""
        code = """
        int func(int x) { return x; }
        void *vp = (void*)func;
        int (*fp)(int) = (int(*)(int))vp;
        """
        assert_no_errors(code)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
