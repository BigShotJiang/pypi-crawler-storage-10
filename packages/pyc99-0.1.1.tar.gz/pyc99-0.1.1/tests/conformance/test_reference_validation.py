"""
Reference Compiler Validation Tests

Tests that compare our compiler's output with GCC and Clang to ensure:
- ABI compatibility
- Correct code generation
- Consistent behavior
"""

import pytest
import os
import tempfile
import subprocess
import shutil


def has_gcc():
    """Check if GCC is available"""
    return shutil.which('gcc') is not None


def has_clang():
    """Check if Clang is available"""
    return shutil.which('clang') is not None


def compile_with_gcc(code, output_file):
    """Compile code with GCC"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
        f.write(code)
        source_file = f.name
    
    try:
        result = subprocess.run(
            ['gcc', '-S', '-O0', source_file, '-o', output_file],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.returncode == 0, result.stderr
    finally:
        os.unlink(source_file)


def compile_with_clang(code, output_file):
    """Compile code with Clang"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
        f.write(code)
        source_file = f.name
    
    try:
        result = subprocess.run(
            ['clang', '-S', '-O0', source_file, '-o', output_file],
            capture_output=True,
            text=True,
            timeout=10
        )
        return result.returncode == 0, result.stderr
    finally:
        os.unlink(source_file)


def compile_with_our_compiler(code, output_file):
    """Compile code with our compiler"""
    from src.lexer.tokenizer import Tokenizer
    from src.parser.parser import Parser
    from src.semantic.analyzer import SemanticAnalyzer
    from src.ir.ir_generator import IRGenerator
    from src.codegen.x86.x86_codegen import X86CodeGenerator
    from src.utils.error_reporter import ErrorReporter
    
    try:
        tokenizer = Tokenizer(code, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        if error_reporter.has_errors():
            return False, "Compilation errors"
        
        ir_gen = IRGenerator(ast)
        ir_module = ir_gen.generate()
        
        codegen = X86CodeGenerator(ir_module)
        asm_code = codegen.generate()
        
        with open(output_file, 'w') as f:
            f.write(asm_code)
        
        return True, None
    except Exception as e:
        return False, str(e)


@pytest.mark.skipif(not has_gcc(), reason="GCC not available")
class TestGCCCompatibility:
    """Test compatibility with GCC"""
    
    def test_simple_function_gcc(self):
        """Test that simple function compiles with both compilers"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        """
        
        with tempfile.TemporaryDirectory() as tmpdir:
            gcc_output = os.path.join(tmpdir, 'gcc.s')
            our_output = os.path.join(tmpdir, 'our.s')
            
            gcc_success, gcc_error = compile_with_gcc(code, gcc_output)
            our_success, our_error = compile_with_our_compiler(code, our_output)
            
            assert gcc_success, f"GCC failed: {gcc_error}"
            assert our_success, f"Our compiler failed: {our_error}"
            
            # Both should produce assembly files
            assert os.path.exists(gcc_output)
            assert os.path.exists(our_output)
    
    def test_struct_layout_gcc(self):
        """Test that struct layout matches GCC"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int get_x(struct Point *p) {
            return p->x;
        }
        """
        
        with tempfile.TemporaryDirectory() as tmpdir:
            gcc_output = os.path.join(tmpdir, 'gcc.s')
            our_output = os.path.join(tmpdir, 'our.s')
            
            gcc_success, _ = compile_with_gcc(code, gcc_output)
            our_success, _ = compile_with_our_compiler(code, our_output)
            
            # Both should compile successfully
            assert gcc_success
            assert our_success
    
    def test_calling_convention_gcc(self):
        """Test that calling convention matches GCC"""
        code = """
        int func(int a, int b, int c, int d, int e, int f) {
            return a + b + c + d + e + f;
        }
        """
        
        with tempfile.TemporaryDirectory() as tmpdir:
            gcc_output = os.path.join(tmpdir, 'gcc.s')
            our_output = os.path.join(tmpdir, 'our.s')
            
            gcc_success, _ = compile_with_gcc(code, gcc_output)
            our_success, _ = compile_with_our_compiler(code, our_output)
            
            assert gcc_success
            assert our_success


@pytest.mark.skipif(not has_clang(), reason="Clang not available")
class TestClangCompatibility:
    """Test compatibility with Clang"""
    
    def test_simple_function_clang(self):
        """Test that simple function compiles with both compilers"""
        code = """
        int multiply(int a, int b) {
            return a * b;
        }
        """
        
        with tempfile.TemporaryDirectory() as tmpdir:
            clang_output = os.path.join(tmpdir, 'clang.s')
            our_output = os.path.join(tmpdir, 'our.s')
            
            clang_success, clang_error = compile_with_clang(code, clang_output)
            our_success, our_error = compile_with_our_compiler(code, our_output)
            
            assert clang_success, f"Clang failed: {clang_error}"
            assert our_success, f"Our compiler failed: {our_error}"
            
            # Both should produce assembly files
            assert os.path.exists(clang_output)
            assert os.path.exists(our_output)
    
    def test_array_access_clang(self):
        """Test that array access compiles with both compilers"""
        code = """
        int sum_array(int arr[], int n) {
            int sum = 0;
            for (int i = 0; i < n; i++) {
                sum += arr[i];
            }
            return sum;
        }
        """
        
        with tempfile.TemporaryDirectory() as tmpdir:
            clang_output = os.path.join(tmpdir, 'clang.s')
            our_output = os.path.join(tmpdir, 'our.s')
            
            clang_success, _ = compile_with_clang(code, clang_output)
            our_success, _ = compile_with_our_compiler(code, our_output)
            
            assert clang_success
            assert our_success


class TestABICompatibility:
    """Test ABI compatibility"""
    
    def test_sizeof_basic_types(self):
        """Test that sizeof basic types matches standard"""
        code = """
        int test_sizeof(void) {
            int sizes[8];
            sizes[0] = sizeof(char);
            sizes[1] = sizeof(short);
            sizes[2] = sizeof(int);
            sizes[3] = sizeof(long);
            sizes[4] = sizeof(float);
            sizes[5] = sizeof(double);
            sizes[6] = sizeof(void*);
            sizes[7] = sizeof(long long);
            return sizes[0];
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)
    
    def test_struct_alignment(self):
        """Test that struct alignment follows ABI"""
        code = """
        struct Aligned {
            char c;
            int i;
            char c2;
        };
        
        int test_alignment(void) {
            return sizeof(struct Aligned);
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)
    
    def test_function_parameter_passing(self):
        """Test that function parameters are passed correctly"""
        code = """
        int test_params(int a, int b, int c, int d, int e, int f, int g, int h) {
            return a + b + c + d + e + f + g + h;
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)


class TestCodeGenConsistency:
    """Test code generation consistency"""
    
    def test_arithmetic_operations(self):
        """Test that arithmetic operations are consistent"""
        code = """
        int test_arithmetic(int a, int b) {
            int sum = a + b;
            int diff = a - b;
            int prod = a * b;
            int quot = a / b;
            int rem = a % b;
            return sum + diff + prod + quot + rem;
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)
    
    def test_control_flow(self):
        """Test that control flow is consistent"""
        code = """
        int test_control_flow(int n) {
            int result = 0;
            
            if (n > 0) {
                result = 1;
            } else if (n < 0) {
                result = -1;
            } else {
                result = 0;
            }
            
            for (int i = 0; i < n; i++) {
                result += i;
            }
            
            return result;
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)
    
    def test_pointer_operations(self):
        """Test that pointer operations are consistent"""
        code = """
        int test_pointers(int *p, int n) {
            int sum = 0;
            for (int i = 0; i < n; i++) {
                sum += *(p + i);
            }
            return sum;
        }
        """
        
        from tests.conformance.test_utils import assert_no_errors
        assert_no_errors(code)
