"""
C99 Conformance Test Suite

This package contains comprehensive tests for C99 language features,
edge cases, and error handling.
"""
