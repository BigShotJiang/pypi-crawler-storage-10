"""
C99 Struct and Union Conformance Tests

Tests C99 struct and union features including:
- Struct declarations
- Union declarations
- Member access
- Nested structures
- Designated initializers
- Typedef with structs
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99Structs:
    """Test C99 struct features"""
    
    def test_struct_declaration(self):
        """Test struct declarations"""
        code = """
        struct Point {
            int x;
            int y;
        };
        """
        assert_no_errors(code)
    
    def test_struct_variable(self):
        """Test struct variable declaration"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point p;
        """
        assert_no_errors(code)
    
    def test_struct_initialization(self):
        """Test struct initialization"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point p = {10, 20};
        """
        assert_no_errors(code)
    
    def test_designated_initializers(self):
        """Test C99 designated initializers"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point p = {.x = 10, .y = 20};
        struct Point q = {.y = 30, .x = 40};
        """
        assert_no_errors(code)
    
    def test_member_access(self):
        """Test struct member access"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(void) {
            struct Point p;
            p.x = 10;
            p.y = 20;
            return p.x + p.y;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_member_access(self):
        """Test struct pointer member access"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(struct Point *p) {
            p->x = 10;
            p->y = 20;
            return p->x + p->y;
        }
        """
        assert_no_errors(code)


class TestC99NestedStructs:
    """Test C99 nested struct features"""
    
    def test_nested_struct(self):
        """Test nested struct declarations"""
        code = """
        struct Rectangle {
            struct Point {
                int x;
                int y;
            } top_left;
            struct Point bottom_right;
        };
        """
        assert_no_errors(code)
    
    def test_nested_member_access(self):
        """Test nested struct member access"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Rectangle {
            struct Point top_left;
            struct Point bottom_right;
        };
        
        int test(void) {
            struct Rectangle r;
            r.top_left.x = 0;
            r.top_left.y = 0;
            r.bottom_right.x = 100;
            r.bottom_right.y = 100;
            return r.bottom_right.x;
        }
        """
        assert_no_errors(code)


class TestC99Unions:
    """Test C99 union features"""
    
    def test_union_declaration(self):
        """Test union declarations"""
        code = """
        union Data {
            int i;
            float f;
            char c;
        };
        """
        assert_no_errors(code)
    
    def test_union_member_access(self):
        """Test union member access"""
        code = """
        union Data {
            int i;
            float f;
        };
        
        int test(void) {
            union Data d;
            d.i = 42;
            return d.i;
        }
        """
        assert_no_errors(code)


class TestC99TypedefStructs:
    """Test typedef with structs"""
    
    def test_typedef_struct(self):
        """Test typedef with struct"""
        code = """
        typedef struct {
            int x;
            int y;
        } Point;
        
        Point p;
        """
        assert_no_errors(code)
    
    def test_typedef_named_struct(self):
        """Test typedef with named struct"""
        code = """
        typedef struct Point {
            int x;
            int y;
        } Point;
        
        Point p;
        struct Point q;
        """
        assert_no_errors(code)


class TestComplexStructLayouts:
    """Test complex struct layouts and alignment"""
    
    def test_struct_with_mixed_types(self):
        """Test struct with different sized members"""
        code = """
        struct Mixed {
            char c;
            int i;
            short s;
            long l;
            char c2;
        };
        
        struct Mixed m;
        """
        assert_no_errors(code)
    
    def test_struct_with_arrays(self):
        """Test struct containing arrays"""
        code = """
        struct ArrayStruct {
            int arr[10];
            char str[20];
            float values[5];
        };
        
        struct ArrayStruct s;
        """
        assert_no_errors(code)
    
    def test_struct_with_pointers(self):
        """Test struct containing pointers"""
        code = """
        struct PointerStruct {
            int *ptr;
            char *str;
            void *data;
        };
        
        struct PointerStruct s;
        """
        assert_no_errors(code)
    
    def test_struct_with_function_pointers(self):
        """Test struct containing function pointers"""
        code = """
        struct FuncPtrStruct {
            int (*func)(int, int);
            void (*callback)(void);
            float (*compute)(float);
        };
        
        struct FuncPtrStruct s;
        """
        assert_no_errors(code)
    
    def test_deeply_nested_structs(self):
        """Test deeply nested struct declarations"""
        code = """
        struct Level1 {
            int a;
            struct Level2 {
                int b;
                struct Level3 {
                    int c;
                    struct Level4 {
                        int d;
                    } l4;
                } l3;
            } l2;
        };
        
        struct Level1 s;
        """
        assert_no_errors(code)
    
    def test_struct_with_nested_unions(self):
        """Test struct containing unions"""
        code = """
        struct StructWithUnion {
            int type;
            union {
                int i;
                float f;
                char c;
            } data;
        };
        
        struct StructWithUnion s;
        """
        assert_no_errors(code)
    
    def test_struct_array_member_access(self):
        """Test accessing array members in struct"""
        code = """
        struct ArrayContainer {
            int values[5];
        };
        
        int test(void) {
            struct ArrayContainer c;
            c.values[0] = 10;
            c.values[4] = 50;
            return c.values[0] + c.values[4];
        }
        """
        assert_no_errors(code)
    
    def test_struct_pointer_arithmetic(self):
        """Test pointer arithmetic with structs"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(struct Point *arr) {
            struct Point *p = arr + 1;
            return p->x;
        }
        """
        assert_no_errors(code)
    
    def test_struct_assignment(self):
        """Test struct assignment"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(void) {
            struct Point p1 = {10, 20};
            struct Point p2;
            p2 = p1;
            return p2.x;
        }
        """
        assert_no_errors(code)
    
    def test_struct_as_return_value(self):
        """Test returning struct from function"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point create_point(int x, int y) {
            struct Point p;
            p.x = x;
            p.y = y;
            return p;
        }
        """
        assert_no_errors(code)
    
    def test_struct_as_parameter(self):
        """Test passing struct as parameter"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int sum_coords(struct Point p) {
            return p.x + p.y;
        }
        """
        assert_no_errors(code)


class TestAnonymousStructsUnions:
    """Test anonymous struct and union features"""
    
    def test_anonymous_struct_in_union(self):
        """Test anonymous struct inside union"""
        code = """
        union Data {
            struct {
                int x;
                int y;
            };
            long long combined;
        };
        
        union Data d;
        """
        assert_no_errors(code)
    
    def test_anonymous_union_in_struct(self):
        """Test anonymous union inside struct"""
        code = """
        struct Variant {
            int type;
            union {
                int i;
                float f;
                char *s;
            };
        };
        
        struct Variant v;
        """
        assert_no_errors(code)
    
    def test_nested_anonymous_structs(self):
        """Test nested anonymous structs"""
        code = """
        struct Outer {
            struct {
                struct {
                    int inner_value;
                };
                int middle_value;
            };
            int outer_value;
        };
        
        struct Outer o;
        """
        assert_no_errors(code)


class TestUnionAdvanced:
    """Test advanced union features"""
    
    def test_union_with_arrays(self):
        """Test union containing arrays"""
        code = """
        union ArrayUnion {
            int ints[4];
            char bytes[16];
            float floats[4];
        };
        
        union ArrayUnion u;
        """
        assert_no_errors(code)
    
    def test_union_with_structs(self):
        """Test union containing structs"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Color {
            unsigned char r;
            unsigned char g;
            unsigned char b;
            unsigned char a;
        };
        
        union Variant {
            struct Point point;
            struct Color color;
            int raw;
        };
        
        union Variant v;
        """
        assert_no_errors(code)
    
    def test_union_initialization(self):
        """Test union initialization"""
        code = """
        union Data {
            int i;
            float f;
        };
        
        union Data d = {42};
        """
        assert_no_errors(code)
    
    def test_union_designated_initializer(self):
        """Test union with designated initializer"""
        code = """
        union Data {
            int i;
            float f;
        };
        
        union Data d = {.f = 3.14};
        """
        assert_no_errors(code)
    
    def test_union_pointer_access(self):
        """Test union pointer member access"""
        code = """
        union Data {
            int i;
            float f;
        };
        
        float test(union Data *d) {
            d->f = 3.14;
            return d->f;
        }
        """
        assert_no_errors(code)


class TestEnumExtended:
    """Test extended enum features"""
    
    def test_enum_basic(self):
        """Test basic enum declaration"""
        code = """
        enum Color {
            RED,
            GREEN,
            BLUE
        };
        
        enum Color c = RED;
        """
        assert_no_errors(code)
    
    def test_enum_with_values(self):
        """Test enum with explicit values"""
        code = """
        enum Status {
            OK = 0,
            ERROR = -1,
            PENDING = 100
        };
        
        enum Status s = OK;
        """
        assert_no_errors(code)
    
    def test_enum_auto_increment(self):
        """Test enum auto-increment values"""
        code = """
        enum Flags {
            FLAG_A = 1,
            FLAG_B,
            FLAG_C,
            FLAG_D = 10,
            FLAG_E
        };
        
        enum Flags f = FLAG_B;
        """
        assert_no_errors(code)
    
    def test_enum_in_expressions(self):
        """Test using enum values in expressions"""
        code = """
        enum Numbers {
            ONE = 1,
            TWO = 2,
            THREE = 3
        };
        
        int test(void) {
            return ONE + TWO + THREE;
        }
        """
        assert_no_errors(code)
    
    def test_typedef_enum(self):
        """Test typedef with enum"""
        code = """
        typedef enum {
            NORTH,
            SOUTH,
            EAST,
            WEST
        } Direction;
        
        Direction d = NORTH;
        """
        assert_no_errors(code)
    
    def test_enum_as_function_parameter(self):
        """Test enum as function parameter"""
        code = """
        enum State {
            IDLE,
            RUNNING,
            STOPPED
        };
        
        int check_state(enum State s) {
            return s == RUNNING;
        }
        """
        assert_no_errors(code)
    
    def test_enum_as_return_type(self):
        """Test enum as function return type"""
        code = """
        enum Result {
            SUCCESS,
            FAILURE
        };
        
        enum Result do_operation(void) {
            return SUCCESS;
        }
        """
        assert_no_errors(code)
    
    def test_enum_in_struct(self):
        """Test enum as struct member"""
        code = """
        enum Priority {
            LOW,
            MEDIUM,
            HIGH
        };
        
        struct Task {
            enum Priority priority;
            int id;
        };
        
        struct Task t;
        """
        assert_no_errors(code)


class TestStructInitializationAdvanced:
    """Test advanced struct initialization"""
    
    def test_partial_initialization(self):
        """Test partial struct initialization"""
        code = """
        struct Data {
            int a;
            int b;
            int c;
        };
        
        struct Data d = {10, 20};
        """
        assert_no_errors(code)
    
    def test_nested_designated_initializers(self):
        """Test nested designated initializers"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Rectangle {
            struct Point top_left;
            struct Point bottom_right;
        };
        
        struct Rectangle r = {
            .top_left = {.x = 0, .y = 0},
            .bottom_right = {.x = 100, .y = 100}
        };
        """
        assert_no_errors(code)
    
    def test_array_of_structs_initialization(self):
        """Test initializing array of structs"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point points[3] = {
            {0, 0},
            {10, 20},
            {30, 40}
        };
        """
        assert_no_errors(code)
    
    def test_struct_with_string_initialization(self):
        """Test struct with string member initialization"""
        code = """
        struct Person {
            char name[50];
            int age;
        };
        
        struct Person p = {"John", 30};
        """
        assert_no_errors(code)


class TestForwardDeclarations:
    """Test forward declarations and incomplete types"""
    
    def test_struct_forward_declaration(self):
        """Test struct forward declaration"""
        code = """
        struct Node;
        
        struct Node {
            int data;
            struct Node *next;
        };
        """
        assert_no_errors(code)
    
    def test_self_referential_struct(self):
        """Test self-referential struct"""
        code = """
        struct Node {
            int data;
            struct Node *next;
            struct Node *prev;
        };
        """
        assert_no_errors(code)
    
    def test_mutually_referential_structs(self):
        """Test mutually referential structs"""
        code = """
        struct A;
        struct B;
        
        struct A {
            int value;
            struct B *b_ptr;
        };
        
        struct B {
            int value;
            struct A *a_ptr;
        };
        """
        assert_no_errors(code)


class TestStructAlignment:
    """Test struct alignment and padding"""
    
    def test_struct_with_char_and_int(self):
        """Test struct with char followed by int (padding)"""
        code = """
        struct Padded {
            char c;
            int i;
        };
        
        struct Padded p;
        """
        assert_no_errors(code)
    
    def test_struct_member_order_matters(self):
        """Test that member order affects layout"""
        code = """
        struct Order1 {
            char c1;
            int i;
            char c2;
        };
        
        struct Order2 {
            int i;
            char c1;
            char c2;
        };
        
        struct Order1 o1;
        struct Order2 o2;
        """
        assert_no_errors(code)
    
    def test_struct_with_double(self):
        """Test struct with double (8-byte alignment)"""
        code = """
        struct WithDouble {
            char c;
            double d;
            int i;
        };
        
        struct WithDouble s;
        """
        assert_no_errors(code)
