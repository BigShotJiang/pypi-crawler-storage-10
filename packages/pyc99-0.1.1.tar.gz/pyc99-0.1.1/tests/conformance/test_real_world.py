"""
Real-World Program Tests

Tests compilation of real-world C programs including:
- Data structure implementations
- Algorithm implementations
- Small utilities
"""

import pytest
import os
import tempfile
import subprocess
from tests.conformance.test_utils import compile_and_analyze, assert_no_errors


class TestDataStructures:
    """Test data structure implementations"""
    
    def test_linked_list(self):
        """Test linked list implementation"""
        code = """
        struct Node {
            int data;
            struct Node *next;
        };
        
        struct Node* create_node(int data) {
            struct Node *node = 0;  // Would be malloc in real code
            return node;
        }
        
        void insert(struct Node **head, int data) {
            struct Node *new_node = create_node(data);
            new_node->next = *head;
            *head = new_node;
        }
        
        int find(struct Node *head, int data) {
            struct Node *current = head;
            while (current != 0) {
                if (current->data == data) {
                    return 1;
                }
                current = current->next;
            }
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_binary_tree(self):
        """Test binary tree implementation"""
        code = """
        struct TreeNode {
            int value;
            struct TreeNode *left;
            struct TreeNode *right;
        };
        
        struct TreeNode* create_node(int value) {
            struct TreeNode *node = 0;  // Would be malloc in real code
            return node;
        }
        
        void insert_tree(struct TreeNode **root, int value) {
            if (*root == 0) {
                *root = create_node(value);
                return;
            }
            
            if (value < (*root)->value) {
                insert_tree(&(*root)->left, value);
            } else {
                insert_tree(&(*root)->right, value);
            }
        }
        
        int search_tree(struct TreeNode *root, int value) {
            if (root == 0) {
                return 0;
            }
            
            if (root->value == value) {
                return 1;
            }
            
            if (value < root->value) {
                return search_tree(root->left, value);
            } else {
                return search_tree(root->right, value);
            }
        }
        """
        assert_no_errors(code)
    
    def test_stack(self):
        """Test stack implementation"""
        code = """
        #define MAX_SIZE 100
        
        struct Stack {
            int data[MAX_SIZE];
            int top;
        };
        
        void init_stack(struct Stack *s) {
            s->top = -1;
        }
        
        int is_empty(struct Stack *s) {
            return s->top == -1;
        }
        
        int is_full(struct Stack *s) {
            return s->top == MAX_SIZE - 1;
        }
        
        void push(struct Stack *s, int value) {
            if (!is_full(s)) {
                s->top++;
                s->data[s->top] = value;
            }
        }
        
        int pop(struct Stack *s) {
            if (!is_empty(s)) {
                int value = s->data[s->top];
                s->top--;
                return value;
            }
            return -1;
        }
        """
        assert_no_errors(code)
    
    def test_queue(self):
        """Test queue implementation"""
        code = """
        #define MAX_SIZE 100
        
        struct Queue {
            int data[MAX_SIZE];
            int front;
            int rear;
            int size;
        };
        
        void init_queue(struct Queue *q) {
            q->front = 0;
            q->rear = -1;
            q->size = 0;
        }
        
        int is_empty_queue(struct Queue *q) {
            return q->size == 0;
        }
        
        int is_full_queue(struct Queue *q) {
            return q->size == MAX_SIZE;
        }
        
        void enqueue(struct Queue *q, int value) {
            if (!is_full_queue(q)) {
                q->rear = (q->rear + 1) % MAX_SIZE;
                q->data[q->rear] = value;
                q->size++;
            }
        }
        
        int dequeue(struct Queue *q) {
            if (!is_empty_queue(q)) {
                int value = q->data[q->front];
                q->front = (q->front + 1) % MAX_SIZE;
                q->size--;
                return value;
            }
            return -1;
        }
        """
        assert_no_errors(code)


class TestAlgorithms:
    """Test algorithm implementations"""
    
    def test_bubble_sort(self):
        """Test bubble sort algorithm"""
        code = """
        void bubble_sort(int arr[], int n) {
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (arr[j] > arr[j + 1]) {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
        }
        """
        assert_no_errors(code)
    
    def test_quick_sort(self):
        """Test quick sort algorithm"""
        code = """
        void swap(int *a, int *b) {
            int temp = *a;
            *a = *b;
            *b = temp;
        }
        
        int partition(int arr[], int low, int high) {
            int pivot = arr[high];
            int i = low - 1;
            
            for (int j = low; j < high; j++) {
                if (arr[j] < pivot) {
                    i++;
                    swap(&arr[i], &arr[j]);
                }
            }
            swap(&arr[i + 1], &arr[high]);
            return i + 1;
        }
        
        void quick_sort(int arr[], int low, int high) {
            if (low < high) {
                int pi = partition(arr, low, high);
                quick_sort(arr, low, pi - 1);
                quick_sort(arr, pi + 1, high);
            }
        }
        """
        assert_no_errors(code)
    
    def test_binary_search(self):
        """Test binary search algorithm"""
        code = """
        int binary_search(int arr[], int n, int target) {
            int left = 0;
            int right = n - 1;
            
            while (left <= right) {
                int mid = left + (right - left) / 2;
                
                if (arr[mid] == target) {
                    return mid;
                }
                
                if (arr[mid] < target) {
                    left = mid + 1;
                } else {
                    right = mid - 1;
                }
            }
            
            return -1;
        }
        """
        assert_no_errors(code)
    
    def test_fibonacci_iterative(self):
        """Test iterative Fibonacci"""
        code = """
        int fibonacci(int n) {
            if (n <= 1) {
                return n;
            }
            
            int a = 0;
            int b = 1;
            int result = 0;
            
            for (int i = 2; i <= n; i++) {
                result = a + b;
                a = b;
                b = result;
            }
            
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_gcd(self):
        """Test greatest common divisor (Euclidean algorithm)"""
        code = """
        int gcd(int a, int b) {
            while (b != 0) {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        
        int gcd_recursive(int a, int b) {
            if (b == 0) {
                return a;
            }
            return gcd_recursive(b, a % b);
        }
        """
        assert_no_errors(code)


class TestUtilities:
    """Test small utility functions"""
    
    def test_string_length(self):
        """Test string length function"""
        code = """
        int string_length(const char *str) {
            int len = 0;
            while (str[len] != '\\0') {
                len++;
            }
            return len;
        }
        """
        assert_no_errors(code)
    
    def test_string_copy(self):
        """Test string copy function"""
        code = """
        void string_copy(char *dest, const char *src) {
            int i = 0;
            while (src[i] != '\\0') {
                dest[i] = src[i];
                i++;
            }
            dest[i] = '\\0';
        }
        """
        assert_no_errors(code)
    
    def test_string_compare(self):
        """Test string compare function"""
        code = """
        int string_compare(const char *s1, const char *s2) {
            int i = 0;
            while (s1[i] != '\\0' && s2[i] != '\\0') {
                if (s1[i] != s2[i]) {
                    return s1[i] - s2[i];
                }
                i++;
            }
            return s1[i] - s2[i];
        }
        """
        assert_no_errors(code)
    
    def test_is_palindrome(self):
        """Test palindrome checker"""
        code = """
        int string_length(const char *str) {
            int len = 0;
            while (str[len] != '\\0') {
                len++;
            }
            return len;
        }
        
        int is_palindrome(const char *str) {
            int len = string_length(str);
            int left = 0;
            int right = len - 1;
            
            while (left < right) {
                if (str[left] != str[right]) {
                    return 0;
                }
                left++;
                right--;
            }
            
            return 1;
        }
        """
        assert_no_errors(code)
    
    def test_power_function(self):
        """Test power function"""
        code = """
        int power(int base, int exp) {
            int result = 1;
            for (int i = 0; i < exp; i++) {
                result *= base;
            }
            return result;
        }
        
        int power_recursive(int base, int exp) {
            if (exp == 0) {
                return 1;
            }
            return base * power_recursive(base, exp - 1);
        }
        """
        assert_no_errors(code)


class TestComplexPrograms:
    """Test more complex programs"""
    
    def test_calculator(self):
        """Test simple calculator"""
        code = """
        int add(int a, int b) { return a + b; }
        int subtract(int a, int b) { return a - b; }
        int multiply(int a, int b) { return a * b; }
        int divide(int a, int b) {
            if (b != 0) {
                return a / b;
            }
            return 0;
        }
        
        int calculate(char op, int a, int b) {
            switch (op) {
                case '+':
                    return add(a, b);
                case '-':
                    return subtract(a, b);
                case '*':
                    return multiply(a, b);
                case '/':
                    return divide(a, b);
                default:
                    return 0;
            }
        }
        """
        assert_no_errors(code)
    
    def test_matrix_operations(self):
        """Test matrix operations"""
        code = """
        #define SIZE 3
        
        void matrix_add(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    result[i][j] = a[i][j] + b[i][j];
                }
            }
        }
        
        void matrix_multiply(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
            for (int i = 0; i < SIZE; i++) {
                for (int j = 0; j < SIZE; j++) {
                    result[i][j] = 0;
                    for (int k = 0; k < SIZE; k++) {
                        result[i][j] += a[i][k] * b[k][j];
                    }
                }
            }
        }
        """
        assert_no_errors(code)
