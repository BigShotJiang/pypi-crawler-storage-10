# C99 Conformance Test Suite

This directory contains comprehensive conformance tests for the C99 compiler. These tests verify that the compiler correctly implements C99 language features, handles edge cases, and properly detects errors.

## Test Organization

### test_c99_types.py
Tests for C99 type system:
- Basic types (char, int, float, double, void)
- Type qualifiers (const, volatile, restrict)
- Storage class specifiers (static, extern, auto, register)
- Complex declarators (pointers, arrays, function pointers)
- Type compatibility and conversions

### test_c99_expressions.py
Tests for C99 expressions:
- Arithmetic operators (+, -, *, /, %)
- Logical operators (&&, ||, !)
- Bitwise operators (&, |, ^, ~, <<, >>)
- Assignment operators (=, +=, -=, etc.)
- Increment/decrement operators (++, --)
- Special operators (? :, comma, sizeof)
- Operator precedence and associativity

### test_c99_statements.py
Tests for C99 statements:
- Selection statements (if, if-else, switch)
- Iteration statements (while, do-while, for)
- Jump statements (break, continue, return, goto)
- Compound statements and scoping

### test_c99_pointers_arrays.py
Tests for C99 pointers and arrays:
- Pointer declarations and operations
- Array declarations and indexing
- Pointer arithmetic
- Multi-dimensional arrays
- Array-pointer relationships
- String literals

### test_c99_structs.py
Tests for C99 structs and unions:
- Struct declarations and initialization
- Union declarations
- Member access (. and ->)
- Nested structures
- Designated initializers (C99 feature)
- Typedef with structs

### test_c99_functions.py
Tests for C99 functions:
- Function declarations and definitions
- Function parameters (various types)
- Function return values
- Function pointers
- Variadic functions
- Recursion

### test_c99_preprocessor.py
Tests for C99 preprocessor:
- Macro definitions (object-like and function-like)
- Macro expansion
- Stringification (#) and token pasting (##)
- Conditional compilation (#if, #ifdef, #ifndef, #elif, #else)
- Predefined macros (__FILE__, __LINE__, __STDC__)
- Include guards and #pragma once

### test_c99_error_handling.py
Tests for error detection:
- Syntax errors
- Type errors
- Semantic errors
- Undefined behavior detection

## Running the Tests

### Run all conformance tests:
```bash
pytest tests/conformance/ -v
```

### Run specific test file:
```bash
pytest tests/conformance/test_c99_types.py -v
```

### Run specific test class:
```bash
pytest tests/conformance/test_c99_types.py::TestC99BasicTypes -v
```

### Run specific test:
```bash
pytest tests/conformance/test_c99_types.py::TestC99BasicTypes::test_all_integer_types -v
```

### Run with coverage:
```bash
pytest tests/conformance/ --cov=src --cov-report=html
```

## Test Coverage Goals

These conformance tests aim to cover:
- ✅ All C99 language features
- ✅ Edge cases and corner cases
- ✅ Error handling and diagnostics
- ✅ Type system compliance
- ✅ Operator precedence and associativity
- ✅ Scoping rules
- ✅ Function calling conventions
- ✅ Preprocessor directives

## Adding New Tests

When adding new conformance tests:
1. Follow the existing test structure and naming conventions
2. Use descriptive test names that explain what is being tested
3. Include docstrings explaining the test purpose
4. Test both positive cases (valid code) and negative cases (errors)
5. Keep tests focused on a single feature or behavior
6. Add comments for complex test scenarios

## Test Methodology

Each test follows this pattern:
1. Create C99 source code as a string
2. Tokenize the code
3. Parse into AST
4. Perform semantic analysis
5. Verify expected behavior (no errors for valid code, errors for invalid code)

For error tests, we verify that the compiler correctly detects and reports errors.

## C99 Features Tested

### Core Language Features
- [x] Basic types and type qualifiers
- [x] Storage class specifiers
- [x] Operators and expressions
- [x] Control flow statements
- [x] Functions and function pointers
- [x] Pointers and pointer arithmetic
- [x] Arrays and multi-dimensional arrays
- [x] Structs and unions
- [x] Typedef and enums
- [x] String literals

### C99-Specific Features
- [x] Designated initializers
- [x] Variable-length arrays (VLA)
- [x] Flexible array members
- [x] Restrict qualifier
- [x] Inline functions
- [x] Variadic macros
- [x] // comments
- [x] Mixed declarations and code
- [x] Long long type
- [x] Hexadecimal floating-point literals

### Preprocessor Features
- [x] Object-like macros
- [x] Function-like macros
- [x] Stringification (#)
- [x] Token pasting (##)
- [x] Conditional compilation
- [x] Predefined macros
- [x] Include directives

## Known Limitations

Some C99 features may have limited support:
- Complex numbers (_Complex)
- Variable-length arrays in some contexts
- Some obscure type compatibility rules
- Full Unicode support

## References

- ISO/IEC 9899:1999 (C99 Standard)
- C99 Rationale Document
- GCC C99 Status
- Clang C99 Status
