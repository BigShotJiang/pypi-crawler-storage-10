"""
Extended C99 Statement Tests

Comprehensive tests for nested control structures, edge cases,
and complex statement patterns.
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestNestedLoops:
    """Test nested loop structures"""
    
    def test_nested_for_loops(self):
        """Test nested for loops"""
        code = """
        int test(void) {
            int sum = 0;
            int i, j;
            for (i = 0; i < 3; i++) {
                for (j = 0; j < 3; j++) {
                    sum += i * j;
                }
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_nested_while_loops(self):
        """Test nested while loops"""
        code = """
        int test(void) {
            int sum = 0;
            int i = 0;
            while (i < 3) {
                int j = 0;
                while (j < 3) {
                    sum += i + j;
                    j++;
                }
                i++;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_mixed_nested_loops(self):
        """Test mixed nested loops"""
        code = """
        int test(void) {
            int sum = 0;
            int i;
            for (i = 0; i < 3; i++) {
                int j = 0;
                while (j < 3) {
                    int k;
                    for (k = 0; k < 2; k++) {
                        sum++;
                    }
                    j++;
                }
            }
            return sum;
        }
        """
        assert_no_errors(code)


class TestLoopControl:
    """Test loop control statements"""
    
    def test_break_in_for(self):
        """Test break in for loop"""
        code = """
        int test(void) {
            int i, sum = 0;
            for (i = 0; i < 10; i++) {
                if (i == 5) break;
                sum += i;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_continue_in_for(self):
        """Test continue in for loop"""
        code = """
        int test(void) {
            int i, sum = 0;
            for (i = 0; i < 10; i++) {
                if (i % 2 == 0) continue;
                sum += i;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_break_in_while(self):
        """Test break in while loop"""
        code = """
        int test(void) {
            int i = 0, sum = 0;
            while (i < 10) {
                if (i == 5) break;
                sum += i;
                i++;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_continue_in_while(self):
        """Test continue in while loop"""
        code = """
        int test(void) {
            int i = 0, sum = 0;
            while (i < 10) {
                i++;
                if (i % 2 == 0) continue;
                sum += i;
            }
            return sum;
        }
        """
        assert_no_errors(code)
    
    def test_nested_break(self):
        """Test break in nested loops"""
        code = """
        int test(void) {
            int i, j, found = 0;
            for (i = 0; i < 5; i++) {
                for (j = 0; j < 5; j++) {
                    if (i * j == 6) {
                        found = 1;
                        break;
                    }
                }
                if (found) break;
            }
            return found;
        }
        """
        assert_no_errors(code)


class TestSwitchStatements:
    """Test switch statement variations"""
    
    def test_switch_with_default(self):
        """Test switch with default case"""
        code = """
        int test(int x) {
            int result;
            switch (x) {
                case 1:
                    result = 10;
                    break;
                case 2:
                    result = 20;
                    break;
                default:
                    result = 0;
                    break;
            }
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_switch_fallthrough(self):
        """Test switch fallthrough"""
        code = """
        int test(int x) {
            int result = 0;
            switch (x) {
                case 1:
                    result += 1;
                case 2:
                    result += 2;
                case 3:
                    result += 3;
                    break;
                default:
                    result = 0;
            }
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_switch_multiple_cases(self):
        """Test switch with multiple cases"""
        code = """
        int test(int x) {
            int result;
            switch (x) {
                case 1:
                case 2:
                case 3:
                    result = 1;
                    break;
                case 4:
                case 5:
                    result = 2;
                    break;
                default:
                    result = 0;
            }
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_nested_switch(self):
        """Test nested switch statements"""
        code = """
        int test(int x, int y) {
            int result = 0;
            switch (x) {
                case 1:
                    switch (y) {
                        case 1:
                            result = 11;
                            break;
                        case 2:
                            result = 12;
                            break;
                    }
                    break;
                case 2:
                    result = 20;
                    break;
            }
            return result;
        }
        """
        assert_no_errors(code)


class TestConditionalStatements:
    """Test conditional statement variations"""
    
    def test_if_else_chain(self):
        """Test if-else chain"""
        code = """
        int test(int x) {
            int result;
            if (x < 0) {
                result = -1;
            } else if (x == 0) {
                result = 0;
            } else if (x < 10) {
                result = 1;
            } else {
                result = 2;
            }
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_nested_if(self):
        """Test deeply nested if statements"""
        code = """
        int test(int x, int y, int z) {
            int result = 0;
            if (x > 0) {
                if (y > 0) {
                    if (z > 0) {
                        result = 1;
                    } else {
                        result = 2;
                    }
                } else {
                    result = 3;
                }
            } else {
                result = 4;
            }
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_if_with_complex_condition(self):
        """Test if with complex conditions"""
        code = """
        int test(int x, int y, int z) {
            int result = 0;
            if ((x > 0 && y > 0) || (z > 0 && x < 10)) {
                result = 1;
            }
            return result;
        }
        """
        assert_no_errors(code)


class TestGotoAndLabels:
    """Test goto statements and labels"""
    
    def test_simple_goto(self):
        """Test simple goto"""
        code = """
        int test(void) {
            int x = 0;
            goto skip;
            x = 10;
        skip:
            x += 5;
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_goto_forward(self):
        """Test forward goto"""
        code = """
        int test(void) {
            int x = 0;
            if (x == 0) {
                goto end;
            }
            x = 10;
        end:
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_goto_backward(self):
        """Test backward goto (loop)"""
        code = """
        int test(void) {
            int x = 0;
        loop:
            x++;
            if (x < 5) {
                goto loop;
            }
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_multiple_labels(self):
        """Test multiple labels"""
        code = """
        int test(int x) {
            int result = 0;
            if (x == 1) goto label1;
            if (x == 2) goto label2;
            goto end;
        label1:
            result = 10;
            goto end;
        label2:
            result = 20;
        end:
            return result;
        }
        """
        assert_no_errors(code)


class TestCompoundStatements:
    """Test compound statement variations"""
    
    def test_empty_block(self):
        """Test empty compound statement"""
        code = """
        int test(void) {
            {}
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_nested_blocks(self):
        """Test nested compound statements"""
        code = """
        int test(void) {
            int x = 1;
            {
                int y = 2;
                {
                    int z = 3;
                    x = x + y + z;
                }
            }
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_block_scope(self):
        """Test variable scope in blocks"""
        code = """
        int test(void) {
            int x = 1;
            {
                int x = 2;
                x = x + 1;
            }
            return x;
        }
        """
        assert_no_errors(code)


class TestLoopEdgeCases:
    """Test loop edge cases"""
    
    def test_empty_for_loop(self):
        """Test for loop with empty body"""
        code = """
        int test(void) {
            int i;
            for (i = 0; i < 10; i++) {
            }
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_for_loop_no_init(self):
        """Test for loop without initialization"""
        code = """
        int test(void) {
            int i = 0;
            for (; i < 10; i++) {
                i = i + 1;
            }
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_for_loop_no_condition(self):
        """Test for loop without condition"""
        code = """
        int test(void) {
            int i;
            for (i = 0; ; i++) {
                if (i >= 5) break;
            }
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_for_loop_no_increment(self):
        """Test for loop without increment"""
        code = """
        int test(void) {
            int i;
            for (i = 0; i < 10; ) {
                i++;
            }
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_infinite_loop_with_break(self):
        """Test infinite loop with break"""
        code = """
        int test(void) {
            int i = 0;
            while (1) {
                i++;
                if (i >= 5) break;
            }
            return i;
        }
        """
        assert_no_errors(code)
