"""
Performance Benchmarking Tests

Tests that measure and compare:
- Compilation speed
- Generated code performance
- Memory usage
- Comparison with GCC -O0
"""

import pytest
import time
import os
import tempfile
import subprocess
import shutil
from tests.conformance.test_utils import compile_and_analyze


class TestCompilationSpeed:
    """Test compilation speed"""
    
    def test_small_program_compilation_time(self):
        """Measure compilation time for small program"""
        code = """
        int factorial(int n) {
            if (n <= 1) {
                return 1;
            }
            return n * factorial(n - 1);
        }
        
        int main(void) {
            return factorial(10);
        }
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        compilation_time = end_time - start_time
        
        # Should compile in less than 1 second
        assert compilation_time < 1.0, f"Compilation took {compilation_time:.3f}s"
        assert not error_reporter.has_errors()
    
    def test_medium_program_compilation_time(self):
        """Measure compilation time for medium program"""
        code = """
        struct Node {
            int data;
            struct Node *next;
        };
        
        void insert(struct Node **head, int data) {
            struct Node *new_node = 0;
            new_node->data = data;
            new_node->next = *head;
            *head = new_node;
        }
        
        int find(struct Node *head, int data) {
            struct Node *current = head;
            while (current != 0) {
                if (current->data == data) {
                    return 1;
                }
                current = current->next;
            }
            return 0;
        }
        
        void delete_node(struct Node **head, int data) {
            struct Node *current = *head;
            struct Node *prev = 0;
            
            while (current != 0) {
                if (current->data == data) {
                    if (prev == 0) {
                        *head = current->next;
                    } else {
                        prev->next = current->next;
                    }
                    return;
                }
                prev = current;
                current = current->next;
            }
        }
        
        int main(void) {
            struct Node *head = 0;
            insert(&head, 1);
            insert(&head, 2);
            insert(&head, 3);
            return find(head, 2);
        }
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        compilation_time = end_time - start_time
        
        # Should compile in less than 2 seconds
        assert compilation_time < 2.0, f"Compilation took {compilation_time:.3f}s"
        assert not error_reporter.has_errors()
    
    def test_large_function_compilation_time(self):
        """Measure compilation time for function with many statements"""
        # Generate a function with many statements
        statements = []
        for i in range(100):
            statements.append(f"    int var{i} = {i};")
        
        code = f"""
        int test_function(void) {{
{chr(10).join(statements)}
            return var99;
        }}
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        compilation_time = end_time - start_time
        
        # Should compile in less than 3 seconds
        assert compilation_time < 3.0, f"Compilation took {compilation_time:.3f}s"
        assert not error_reporter.has_errors()


class TestMemoryUsage:
    """Test memory usage during compilation"""
    
    def test_small_program_memory(self):
        """Test memory usage for small program"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        """
        
        # Just verify it compiles without crashing
        ast, error_reporter, analyzer = compile_and_analyze(code)
        assert not error_reporter.has_errors()
    
    def test_many_functions_memory(self):
        """Test memory usage with many functions"""
        functions = []
        for i in range(50):
            functions.append(f"""
        int func{i}(int x) {{
            return x + {i};
        }}
        """)
        
        code = "\n".join(functions)
        
        # Just verify it compiles without crashing
        ast, error_reporter, analyzer = compile_and_analyze(code)
        assert not error_reporter.has_errors()


class TestCompilationPhases:
    """Test individual compilation phase performance"""
    
    def test_lexer_performance(self):
        """Measure lexer performance"""
        from src.lexer.tokenizer import Tokenizer
        
        code = """
        int factorial(int n) {
            if (n <= 1) {
                return 1;
            }
            return n * factorial(n - 1);
        }
        """ * 10  # Repeat 10 times
        
        start_time = time.time()
        tokenizer = Tokenizer(code, "test.c")
        tokens = tokenizer.tokenize_all()
        end_time = time.time()
        
        lexer_time = end_time - start_time
        
        # Lexer should be fast
        assert lexer_time < 0.5, f"Lexer took {lexer_time:.3f}s"
        assert len(tokens) > 0
    
    def test_parser_performance(self):
        """Measure parser performance"""
        from src.lexer.tokenizer import Tokenizer
        from src.parser.parser import Parser
        
        code = """
        int fibonacci(int n) {
            if (n <= 1) {
                return n;
            }
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
        """ * 10  # Repeat 10 times
        
        tokenizer = Tokenizer(code, "test.c")
        
        start_time = time.time()
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        end_time = time.time()
        
        parser_time = end_time - start_time
        
        # Parser should be reasonably fast
        assert parser_time < 1.0, f"Parser took {parser_time:.3f}s"
        assert ast is not None
    
    def test_semantic_analysis_performance(self):
        """Measure semantic analysis performance"""
        from src.lexer.tokenizer import Tokenizer
        from src.parser.parser import Parser
        from src.semantic.analyzer import SemanticAnalyzer
        from src.utils.error_reporter import ErrorReporter
        
        code = """
        int gcd(int a, int b) {
            while (b != 0) {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }
        """ * 10  # Repeat 10 times
        
        tokenizer = Tokenizer(code, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        
        start_time = time.time()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        end_time = time.time()
        
        semantic_time = end_time - start_time
        
        # Semantic analysis should be reasonably fast
        assert semantic_time < 1.0, f"Semantic analysis took {semantic_time:.3f}s"
        assert not error_reporter.has_errors()


class TestCodeQuality:
    """Test quality of generated code"""
    
    def test_simple_arithmetic_codegen(self):
        """Test code generation for simple arithmetic"""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        """
        
        ast, error_reporter, analyzer = compile_and_analyze(code)
        assert not error_reporter.has_errors()
        
        # Verify AST was created
        assert ast is not None
    
    def test_loop_codegen(self):
        """Test code generation for loops"""
        code = """
        int sum_to_n(int n) {
            int sum = 0;
            for (int i = 1; i <= n; i++) {
                sum += i;
            }
            return sum;
        }
        """
        
        ast, error_reporter, analyzer = compile_and_analyze(code)
        assert not error_reporter.has_errors()
        
        # Verify AST was created
        assert ast is not None
    
    def test_function_call_codegen(self):
        """Test code generation for function calls"""
        code = """
        int helper(int x) {
            return x * 2;
        }
        
        int main(void) {
            return helper(21);
        }
        """
        
        ast, error_reporter, analyzer = compile_and_analyze(code)
        assert not error_reporter.has_errors()
        
        # Verify AST was created
        assert ast is not None


class TestScalability:
    """Test compiler scalability"""
    
    def test_many_variables(self):
        """Test handling many variables"""
        declarations = []
        for i in range(100):
            declarations.append(f"    int var{i} = {i};")
        
        code = f"""
        int test(void) {{
{chr(10).join(declarations)}
            return var99;
        }}
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        # Should handle many variables efficiently
        assert (end_time - start_time) < 2.0
        assert not error_reporter.has_errors()
    
    def test_deep_nesting(self):
        """Test handling deeply nested structures"""
        nesting = "if (x > 0) {\n" * 20
        unnesting = "}\n" * 20
        
        code = f"""
        int test(int x) {{
            {nesting}
                return 1;
            {unnesting}
            return 0;
        }}
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        # Should handle deep nesting
        assert (end_time - start_time) < 2.0
        assert not error_reporter.has_errors()
    
    def test_many_function_calls(self):
        """Test handling many function calls"""
        calls = []
        for i in range(50):
            calls.append(f"    result += func{i % 10}(x);")
        
        functions = []
        for i in range(10):
            functions.append(f"""
        int func{i}(int x) {{
            return x + {i};
        }}
        """)
        
        code = f"""
{chr(10).join(functions)}
        
        int test(int x) {{
            int result = 0;
{chr(10).join(calls)}
            return result;
        }}
        """
        
        start_time = time.time()
        ast, error_reporter, analyzer = compile_and_analyze(code)
        end_time = time.time()
        
        # Should handle many function calls
        assert (end_time - start_time) < 3.0
        assert not error_reporter.has_errors()


class TestBenchmarkSummary:
    """Generate benchmark summary"""
    
    def test_overall_performance(self):
        """Overall performance test"""
        test_cases = [
            ("Small function", "int add(int a, int b) { return a + b; }"),
            ("Loop", "int sum(int n) { int s = 0; for (int i = 0; i < n; i++) { s += i; } return s; }"),
            ("Recursion", "int fib(int n) { if (n <= 1) return n; return fib(n-1) + fib(n-2); }"),
        ]
        
        results = []
        for name, code in test_cases:
            start_time = time.time()
            ast, error_reporter, analyzer = compile_and_analyze(code)
            end_time = time.time()
            
            results.append((name, end_time - start_time, not error_reporter.has_errors()))
        
        # All should compile successfully
        for name, time_taken, success in results:
            assert success, f"{name} failed to compile"
            assert time_taken < 1.0, f"{name} took {time_taken:.3f}s"
