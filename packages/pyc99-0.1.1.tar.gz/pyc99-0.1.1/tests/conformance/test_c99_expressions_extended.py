"""
Extended C99 Expression Tests

Comprehensive tests for all expression types, operator combinations,
precedence, and type conversions.
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestOperatorCombinations:
    """Test complex operator combinations"""
    
    def test_mixed_arithmetic(self):
        """Test mixed arithmetic operations"""
        code = """
        int test(void) {
            int a = 10, b = 5, c = 3;
            int result = a + b * c - a / b;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_nested_arithmetic(self):
        """Test deeply nested arithmetic"""
        code = """
        int test(void) {
            int x = ((10 + 5) * (20 - 8)) / ((3 + 2) * 2);
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_bitwise_combinations(self):
        """Test bitwise operator combinations"""
        code = """
        int test(void) {
            int a = 0xFF, b = 0x0F;
            int result = (a & b) | (a ^ b) | (~a & b);
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_shift_operations(self):
        """Test shift operations"""
        code = """
        int test(void) {
            int x = 1;
            int left = x << 3;
            int right = left >> 2;
            return left + right;
        }
        """
        assert_no_errors(code)
    
    def test_logical_short_circuit(self):
        """Test logical operator short-circuit evaluation"""
        code = """
        int test(void) {
            int a = 1, b = 0;
            int result1 = a && b;
            int result2 = a || b;
            return result1 + result2;
        }
        """
        assert_no_errors(code)
    
    def test_comparison_chains(self):
        """Test comparison operator chains"""
        code = """
        int test(void) {
            int a = 5, b = 10, c = 15;
            int result = (a < b) && (b < c);
            return result;
        }
        """
        assert_no_errors(code)


class TestTypeConversions:
    """Test type conversions in expressions"""
    
    def test_integer_promotion(self):
        """Test integer promotion"""
        code = """
        int test(void) {
            char c = 10;
            short s = 20;
            int result = c + s;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_float_conversion(self):
        """Test float conversions"""
        code = """
        float test(void) {
            int i = 10;
            float f = 3.14f;
            float result = i + f;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_implicit_cast(self):
        """Test implicit type casting"""
        code = """
        int test(void) {
            float f = 3.7f;
            int i = f;
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_types(self):
        """Test pointer arithmetic with different types"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int *q = p + 5;
            return q - p;
        }
        """
        assert_no_errors(code)


class TestOperatorPrecedenceExtended:
    """Extended operator precedence tests"""
    
    def test_precedence_arithmetic_logical(self):
        """Test precedence between arithmetic and logical"""
        code = """
        int test(void) {
            int a = 5, b = 10;
            int result = a + b > 10 && a < b;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_precedence_bitwise_logical(self):
        """Test precedence between bitwise and logical"""
        code = """
        int test(void) {
            int a = 5, b = 3;
            int result = a & b && a | b;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_precedence_assignment(self):
        """Test assignment precedence"""
        code = """
        int test(void) {
            int a, b, c;
            a = b = c = 10;
            return a + b + c;
        }
        """
        assert_no_errors(code)
    
    def test_precedence_ternary(self):
        """Test ternary operator precedence"""
        code = """
        int test(void) {
            int a = 5, b = 10;
            int result = a > b ? a : b;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_precedence_complex(self):
        """Test complex precedence"""
        code = """
        int test(void) {
            int a = 5, b = 10, c = 15;
            int result = a + b * c > a * b + c ? a : b;
            return result;
        }
        """
        assert_no_errors(code)


class TestUnaryOperators:
    """Test unary operators"""
    
    def test_unary_minus(self):
        """Test unary minus"""
        code = """
        int test(void) {
            int a = 10;
            int b = -a;
            return b;
        }
        """
        assert_no_errors(code)
    
    def test_unary_plus(self):
        """Test unary plus"""
        code = """
        int test(void) {
            int a = -10;
            int b = +a;
            return b;
        }
        """
        assert_no_errors(code)
    
    def test_logical_not(self):
        """Test logical NOT"""
        code = """
        int test(void) {
            int a = 0;
            int b = !a;
            int c = !b;
            return c;
        }
        """
        assert_no_errors(code)
    
    def test_bitwise_not(self):
        """Test bitwise NOT"""
        code = """
        int test(void) {
            int a = 0xFF;
            int b = ~a;
            return b;
        }
        """
        assert_no_errors(code)
    
    def test_address_and_dereference(self):
        """Test address-of and dereference"""
        code = """
        int test(void) {
            int a = 42;
            int *p = &a;
            int b = *p;
            return b;
        }
        """
        assert_no_errors(code)


class TestCompoundAssignment:
    """Test compound assignment operators"""
    
    def test_add_assign(self):
        """Test += operator"""
        code = """
        int test(void) {
            int a = 10;
            a += 5;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_sub_assign(self):
        """Test -= operator"""
        code = """
        int test(void) {
            int a = 10;
            a -= 3;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_mul_assign(self):
        """Test *= operator"""
        code = """
        int test(void) {
            int a = 5;
            a *= 3;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_div_assign(self):
        """Test /= operator"""
        code = """
        int test(void) {
            int a = 20;
            a /= 4;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_mod_assign(self):
        """Test %= operator"""
        code = """
        int test(void) {
            int a = 17;
            a %= 5;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_bitwise_assign(self):
        """Test bitwise compound assignments"""
        code = """
        int test(void) {
            int a = 0xFF;
            a &= 0x0F;
            a |= 0xF0;
            a ^= 0x55;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_shift_assign(self):
        """Test shift compound assignments"""
        code = """
        int test(void) {
            int a = 1;
            a <<= 3;
            a >>= 1;
            return a;
        }
        """
        assert_no_errors(code)


class TestIncrementDecrement:
    """Test increment and decrement operators"""
    
    def test_prefix_increment(self):
        """Test prefix increment"""
        code = """
        int test(void) {
            int a = 5;
            int b = ++a;
            return a + b;
        }
        """
        assert_no_errors(code)
    
    def test_postfix_increment(self):
        """Test postfix increment"""
        code = """
        int test(void) {
            int a = 5;
            int b = a++;
            return a + b;
        }
        """
        assert_no_errors(code)
    
    def test_prefix_decrement(self):
        """Test prefix decrement"""
        code = """
        int test(void) {
            int a = 5;
            int b = --a;
            return a + b;
        }
        """
        assert_no_errors(code)
    
    def test_postfix_decrement(self):
        """Test postfix decrement"""
        code = """
        int test(void) {
            int a = 5;
            int b = a--;
            return a + b;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_increment(self):
        """Test pointer increment"""
        code = """
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            int *p = arr;
            p++;
            return *p;
        }
        """
        assert_no_errors(code)


class TestArraySubscript:
    """Test array subscript expressions"""
    
    def test_simple_subscript(self):
        """Test simple array subscript"""
        code = """
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            return arr[2];
        }
        """
        assert_no_errors(code)
    
    def test_computed_subscript(self):
        """Test computed array subscript"""
        code = """
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            int i = 2;
            return arr[i + 1];
        }
        """
        assert_no_errors(code)
    
    def test_multidimensional_subscript(self):
        """Test multidimensional array subscript"""
        code = """
        int test(void) {
            int arr[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
            return arr[1][2];
        }
        """
        assert_no_errors(code)
    
    def test_pointer_subscript(self):
        """Test pointer subscript"""
        code = """
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            int *p = arr;
            return p[3];
        }
        """
        assert_no_errors(code)


class TestConditionalExpression:
    """Test conditional (ternary) expressions"""
    
    def test_simple_ternary(self):
        """Test simple ternary operator"""
        code = """
        int test(void) {
            int a = 10, b = 20;
            int max = a > b ? a : b;
            return max;
        }
        """
        assert_no_errors(code)
    
    def test_nested_ternary(self):
        """Test nested ternary operators"""
        code = """
        int test(void) {
            int a = 5, b = 10, c = 15;
            int max = a > b ? (a > c ? a : c) : (b > c ? b : c);
            return max;
        }
        """
        assert_no_errors(code)
    
    def test_ternary_with_side_effects(self):
        """Test ternary with side effects"""
        code = """
        int test(void) {
            int a = 5, b = 10;
            int result = a > b ? a++ : b++;
            return result + a + b;
        }
        """
        assert_no_errors(code)


class TestSizeofOperator:
    """Test sizeof operator"""
    
    def test_sizeof_type(self):
        """Test sizeof with type"""
        code = """
        int test(void) {
            int size = sizeof(int);
            return size;
        }
        """
        assert_no_errors(code)
    
    def test_sizeof_expression(self):
        """Test sizeof with expression"""
        code = """
        int test(void) {
            int a = 10;
            int size = sizeof(a);
            return size;
        }
        """
        assert_no_errors(code)
    
    def test_sizeof_array(self):
        """Test sizeof with array"""
        code = """
        int test(void) {
            int arr[10];
            int size = sizeof(arr);
            return size;
        }
        """
        assert_no_errors(code)
    
    def test_sizeof_struct(self):
        """Test sizeof with struct"""
        code = """
        struct Point {
            int x;
            int y;
        };
        
        int test(void) {
            struct Point p;
            int size = sizeof(p);
            return size;
        }
        """
        assert_no_errors(code)


class TestCastExpressions:
    """Test cast expressions"""
    
    def test_int_to_float_cast(self):
        """Test int to float cast"""
        code = """
        float test(void) {
            int i = 10;
            float f = (float)i;
            return f;
        }
        """
        assert_no_errors(code)
    
    def test_float_to_int_cast(self):
        """Test float to int cast"""
        code = """
        int test(void) {
            float f = 3.7f;
            int i = (int)f;
            return i;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_cast(self):
        """Test pointer cast"""
        code = """
        int test(void) {
            int a = 42;
            void *vp = (void*)&a;
            int *ip = (int*)vp;
            return *ip;
        }
        """
        assert_no_errors(code)
    
    def test_const_cast(self):
        """Test const cast"""
        code = """
        int test(void) {
            const int a = 42;
            int *p = (int*)&a;
            return *p;
        }
        """
        assert_no_errors(code)
