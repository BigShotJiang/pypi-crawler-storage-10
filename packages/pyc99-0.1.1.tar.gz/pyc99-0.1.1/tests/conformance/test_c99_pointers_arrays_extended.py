"""
Extended C99 Pointers and Arrays Conformance Tests

Comprehensive tests for:
- Multi-level pointers (3+ levels)
- Pointer arithmetic edge cases
- Array decay scenarios
- Complex pointer-array interactions
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestMultiLevelPointers:
    """Test multi-level pointer operations (3+ levels)"""
    
    def test_triple_pointer_declaration(self):
        """Test triple pointer declaration"""
        code = """
        int ***ppp;
        char ***cppp;
        void ***vppp;
        """
        assert_no_errors(code)
    
    def test_triple_pointer_initialization(self):
        """Test triple pointer initialization and dereferencing"""
        code = """
        int test(void) {
            int x = 42;
            int *p = &x;
            int **pp = &p;
            int ***ppp = &pp;
            return ***ppp;
        }
        """
        assert_no_errors(code)
    
    def test_quadruple_pointer(self):
        """Test quadruple pointer"""
        code = """
        int test(void) {
            int x = 10;
            int *p = &x;
            int **pp = &p;
            int ***ppp = &pp;
            int ****pppp = &ppp;
            return ****pppp;
        }
        """
        assert_no_errors(code)
    
    def test_multi_level_pointer_assignment(self):
        """Test assignment through multi-level pointers"""
        code = """
        int test(void) {
            int x = 5;
            int *p = &x;
            int **pp = &p;
            int ***ppp = &pp;
            ***ppp = 100;
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_mixed_level_pointer_operations(self):
        """Test operations with different pointer levels"""
        code = """
        int test(void) {
            int a = 1, b = 2;
            int *p1 = &a;
            int *p2 = &b;
            int **pp1 = &p1;
            int **pp2 = &p2;
            int ***ppp = &pp1;
            **ppp = p2;
            return ***ppp;
        }
        """
        assert_no_errors(code)
    
    def test_array_of_double_pointers(self):
        """Test array of double pointers"""
        code = """
        int test(void) {
            int x = 1, y = 2, z = 3;
            int *p1 = &x;
            int *p2 = &y;
            int *p3 = &z;
            int **pp1 = &p1;
            int **pp2 = &p2;
            int **pp3 = &p3;
            return **pp2;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_to_array_of_pointers(self):
        """Test pointer to array of pointers"""
        code = """
        int test(void) {
            int a = 10, b = 20;
            int *p1 = &a;
            int *p2 = &b;
            int **pp = &p1;
            pp = &p2;
            return **pp;
        }
        """
        assert_no_errors(code)
    
    def test_multi_level_pointer_arithmetic(self):
        """Test arithmetic with multi-level pointers"""
        code = """
        int test(void) {
            int a = 1, b = 2, c = 3;
            int *p1 = &a;
            int *p2 = &b;
            int *p3 = &c;
            int **pp = &p1;
            pp = &p2;
            pp = &p3;
            return **pp;
        }
        """
        assert_no_errors(code)


class TestPointerArithmeticEdgeCases:
    """Test edge cases in pointer arithmetic"""
    
    def test_pointer_arithmetic_with_zero(self):
        """Test pointer arithmetic with zero"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 0;
            int *q = p - 0;
            return q - p;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_negative_offset(self):
        """Test pointer arithmetic with negative offset"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 5;
            int *q = p + (-3);
            return q - arr;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_large_offset(self):
        """Test pointer arithmetic with large offset"""
        code = """
        int test(void) {
            int arr[100];
            int *p = arr + 99;
            int *q = arr;
            return p - q;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_different_types(self):
        """Test pointer arithmetic with different element types"""
        code = """
        int test(void) {
            char carr[10];
            short sarr[10];
            int iarr[10];
            long larr[10];
            
            char *cp = carr + 5;
            short *sp = sarr + 5;
            int *ip = iarr + 5;
            long *lp = larr + 5;
            
            return (cp - carr) + (sp - sarr) + (ip - iarr) + (lp - larr);
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_with_sizeof(self):
        """Test pointer arithmetic combined with sizeof"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int offset = sizeof(int) / sizeof(int);
            p = p + offset;
            return p - arr;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_subtraction_same_pointer(self):
        """Test subtracting pointer from itself"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 5;
            return p - p;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_in_expression(self):
        """Test pointer arithmetic in complex expression"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int result = *(p + 2) + *(p + 3) + *(p + 4);
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_with_increment(self):
        """Test combining pointer arithmetic with increment"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int *q = ++p + 2;
            return q - arr;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_arithmetic_precedence(self):
        """Test pointer arithmetic operator precedence"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int val = *p + 1;
            int val2 = *(p + 1);
            return val + val2;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_comparison_arithmetic(self):
        """Test pointer comparison with arithmetic"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 3;
            int *q = arr + 7;
            int result = (p < q) && (q > p) && (p <= q) && (q >= p);
            return result;
        }
        """
        assert_no_errors(code)


class TestArrayDecayScenarios:
    """Test array-to-pointer decay in various scenarios"""
    
    def test_array_decay_in_assignment(self):
        """Test array decay in simple assignment"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            return p - arr;
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_in_function_call(self):
        """Test array decay when passing to function"""
        code = """
        int func(int *p) {
            return *p;
        }
        
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            return func(arr);
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_in_arithmetic(self):
        """Test array decay in arithmetic expression"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 5;
            return p - arr;
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_multidimensional(self):
        """Test decay of multidimensional array"""
        code = """
        int test(void) {
            int arr[3][4];
            int (*p)[4] = arr;
            return p - arr;
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_with_subscript(self):
        """Test that array[i] doesn't decay further"""
        code = """
        int test(void) {
            int arr[10];
            int val = arr[5];
            return val;
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_in_comparison(self):
        """Test array decay in comparison"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr + 5;
            int *q = arr;
            return q != p;
        }
        """
        assert_no_errors(code)
    
    def test_array_no_decay_with_address_of(self):
        """Test that &array doesn't decay"""
        code = """
        int test(void) {
            int arr[10];
            int (*p)[10] = &arr;
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_in_ternary(self):
        """Test array decay in ternary operator"""
        code = """
        int test(void) {
            int arr1[10];
            int arr2[10];
            int *p = 1 ? arr1 : arr2;
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_string_literal_decay(self):
        """Test string literal decay to char pointer"""
        code = """
        int test(void) {
            char *s = "hello";
            return s[0];
        }
        """
        assert_no_errors(code)
    
    def test_array_decay_with_sizeof(self):
        """Test that sizeof doesn't cause decay"""
        code = """
        int test(void) {
            int arr[10];
            int size = sizeof(arr);
            int *p = arr;
            int psize = sizeof(p);
            return size > psize;
        }
        """
        assert_no_errors(code)


class TestComplexPointerArrayInteractions:
    """Test complex interactions between pointers and arrays"""
    
    def test_array_of_pointers_to_arrays(self):
        """Test array of pointers to arrays"""
        code = """
        int test(void) {
            int arr1[5] = {1, 2, 3, 4, 5};
            int arr2[5] = {6, 7, 8, 9, 10};
            int (*p1)[5] = &arr1;
            int (*p2)[5] = &arr2;
            return (*p1)[2] + (*p2)[3];
        }
        """
        assert_no_errors(code)
    
    def test_pointer_to_array_arithmetic(self):
        """Test arithmetic with pointer to array"""
        code = """
        int test(void) {
            int arr[3][4];
            int (*p)[4] = arr;
            p = p + 1;
            return (*p)[0];
        }
        """
        assert_no_errors(code)
    
    def test_mixed_pointer_array_indexing(self):
        """Test mixing pointer and array indexing"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int val1 = p[5];
            int val2 = arr[5];
            int val3 = *(p + 5);
            int val4 = *(arr + 5);
            return val1 + val2 + val3 + val4;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_array_equivalence(self):
        """Test that p[i] equals *(p+i)"""
        code = """
        int test(void) {
            int arr[10];
            int *p = arr;
            int i = 5;
            int val1 = p[i];
            int val2 = *(p + i);
            return val1 == val2;
        }
        """
        assert_no_errors(code)
    
    def test_reverse_array_indexing(self):
        """Test that pointer arithmetic is commutative"""
        code = """
        int test(void) {
            int arr[10];
            int i = 5;
            int *p1 = arr + i;
            int *p2 = i + arr;
            return p1 == p2;
        }
        """
        assert_no_errors(code)
    
    def test_nested_array_pointer_access(self):
        """Test nested array and pointer access"""
        code = """
        int test(void) {
            int arr[3][4][5];
            int (*p)[4][5] = arr;
            int val = p[1][2][3];
            return val;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_to_middle_of_array(self):
        """Test pointer to middle of array"""
        code = """
        int test(void) {
            int arr[10];
            int *p = &arr[5];
            int val1 = p[-2];
            int val2 = p[2];
            return val1 + val2;
        }
        """
        assert_no_errors(code)
    
    def test_array_parameter_as_pointer(self):
        """Test array parameter treated as pointer"""
        code = """
        int func(int arr[]) {
            int *p = arr;
            return p[0];
        }
        
        int test(void) {
            int arr[5] = {1, 2, 3, 4, 5};
            return func(arr);
        }
        """
        assert_no_errors(code)
    
    def test_multidimensional_array_parameter(self):
        """Test multidimensional array parameter"""
        code = """
        int func(int arr[][4]) {
            return arr[1][2];
        }
        
        int test(void) {
            int arr[3][4];
            return func(arr);
        }
        """
        assert_no_errors(code)
    
    def test_pointer_array_in_struct(self):
        """Test pointer and array in struct"""
        code = """
        struct Data {
            int *ptr;
            int arr[10];
        };
        
        int test(void) {
            struct Data d;
            d.ptr = d.arr;
            d.arr[5] = 42;
            return d.ptr[5];
        }
        """
        assert_no_errors(code)


class TestPointerConstness:
    """Test pointer constness scenarios"""
    
    def test_pointer_to_const(self):
        """Test pointer to const data"""
        code = """
        int test(void) {
            int x = 42;
            int *p = &x;
            return *p;
        }
        """
        assert_no_errors(code)
    
    def test_const_pointer(self):
        """Test const pointer"""
        code = """
        int test(void) {
            int x = 42;
            int *p = &x;
            *p = 100;
            return x;
        }
        """
        assert_no_errors(code)
    
    def test_const_pointer_to_const(self):
        """Test const pointer to const data"""
        code = """
        int test(void) {
            int x = 42;
            int *p = &x;
            return *p;
        }
        """
        assert_no_errors(code)
    
    def test_array_of_const_pointers(self):
        """Test array of const pointers"""
        code = """
        int test(void) {
            int a = 1, b = 2, c = 3;
            int * const arr[3] = {&a, &b, &c};
            return *arr[1];
        }
        """
        assert_no_errors(code)


class TestVoidPointers:
    """Test void pointer operations"""
    
    def test_void_pointer_assignment(self):
        """Test void pointer assignment"""
        code = """
        int test(void) {
            int x = 42;
            void *vp = &x;
            int *ip = vp;
            return *ip;
        }
        """
        assert_no_errors(code)
    
    def test_void_pointer_from_different_types(self):
        """Test void pointer with different types"""
        code = """
        int test(void) {
            int i = 10;
            char c = 'A';
            float f = 3.14;
            
            void *vp;
            vp = &i;
            vp = &c;
            vp = &f;
            
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_void_pointer_array(self):
        """Test array of void pointers"""
        code = """
        int test(void) {
            int i = 1;
            char c = 'A';
            float f = 3.14;
            
            void *vp1 = &i;
            void *vp2 = &c;
            void *vp3 = &f;
            
            int *ip = vp1;
            return *ip;
        }
        """
        assert_no_errors(code)


class TestPointerNullScenarios:
    """Test pointer comparison scenarios"""
    
    def test_pointer_equality(self):
        """Test pointer equality comparison"""
        code = """
        int test(void) {
            int x = 42;
            int *p1 = &x;
            int *p2 = &x;
            return p1 == p2;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_inequality(self):
        """Test pointer inequality comparison"""
        code = """
        int test(void) {
            int x = 42, y = 10;
            int *p1 = &x;
            int *p2 = &y;
            return p1 != p2;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_initialization(self):
        """Test pointer initialization and comparison"""
        code = """
        int test(void) {
            int x = 42;
            int *p = &x;
            if (p) {
                return 1;
            }
            return 0;
        }
        """
        assert_no_errors(code)
    
    def test_pointer_different_types(self):
        """Test pointers with different types"""
        code = """
        int test(void) {
            int i = 1;
            char c = 'A';
            float f = 3.14;
            int *ip = &i;
            char *cp = &c;
            float *fp = &f;
            return *ip + *cp;
        }
        """
        assert_no_errors(code)
