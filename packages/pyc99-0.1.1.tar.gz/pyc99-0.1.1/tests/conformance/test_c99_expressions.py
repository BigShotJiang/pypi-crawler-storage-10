"""
C99 Expression Conformance Tests

Tests all C99 expression features including:
- Arithmetic operators
- Logical operators
- Bitwise operators
- Assignment operators
- Increment/decrement
- Conditional operator
- Comma operator
- sizeof operator
"""

import pytest
from tests.conformance.test_utils import assert_no_errors


class TestC99ArithmeticOperators:
    """Test C99 arithmetic operators"""
    
    def test_basic_arithmetic(self):
        """Test basic arithmetic operators"""
        code = """
        int test(void) {
            int a = 10, b = 5;
            int sum = a + b;
            int diff = a - b;
            int prod = a * b;
            int quot = a / b;
            int rem = a % b;
            return sum + diff + prod + quot + rem;
        }
        """
        assert_no_errors(code)
    
    def test_unary_operators(self):
        """Test unary arithmetic operators"""
        code = """
        int test(void) {
            int a = 10;
            int neg = -a;
            int pos = +a;
            return neg + pos;
        }
        """
        assert_no_errors(code)


class TestC99LogicalOperators:
    """Test C99 logical operators"""
    
    def test_logical_operators(self):
        """Test logical AND, OR, NOT"""
        code = """
        int test(int a, int b) {
            int and_result = a && b;
            int or_result = a || b;
            int not_result = !a;
            return and_result || or_result || not_result;
        }
        """
        assert_no_errors(code)
    
    def test_comparison_operators(self):
        """Test comparison operators"""
        code = """
        int test(int a, int b) {
            int eq = a == b;
            int ne = a != b;
            int lt = a < b;
            int le = a <= b;
            int gt = a > b;
            int ge = a >= b;
            return eq + ne + lt + le + gt + ge;
        }
        """
        assert_no_errors(code)


class TestC99BitwiseOperators:
    """Test C99 bitwise operators"""
    
    def test_bitwise_operators(self):
        """Test bitwise operators"""
        code = """
        int test(int a, int b) {
            int and_op = a & b;
            int or_op = a | b;
            int xor_op = a ^ b;
            int not_op = ~a;
            int lshift = a << 2;
            int rshift = a >> 2;
            return and_op + or_op + xor_op + not_op + lshift + rshift;
        }
        """
        assert_no_errors(code)


class TestC99AssignmentOperators:
    """Test C99 assignment operators"""
    
    def test_simple_assignment(self):
        """Test simple assignment"""
        code = """
        int test(void) {
            int a;
            a = 10;
            return a;
        }
        """
        assert_no_errors(code)
    
    def test_compound_assignment(self):
        """Test compound assignment operators"""
        code = """
        int test(void) {
            int a = 10;
            a += 5;
            a -= 3;
            a *= 2;
            a /= 4;
            a %= 3;
            a &= 0xFF;
            a |= 0x0F;
            a ^= 0xF0;
            a <<= 1;
            a >>= 1;
            return a;
        }
        """
        assert_no_errors(code)


class TestC99IncrementDecrement:
    """Test C99 increment and decrement operators"""
    
    def test_prefix_operators(self):
        """Test prefix increment and decrement"""
        code = """
        int test(void) {
            int a = 10;
            int b = ++a;
            int c = --a;
            return a + b + c;
        }
        """
        assert_no_errors(code)
    
    def test_postfix_operators(self):
        """Test postfix increment and decrement"""
        code = """
        int test(void) {
            int a = 10;
            int b = a++;
            int c = a--;
            return a + b + c;
        }
        """
        assert_no_errors(code)


class TestC99SpecialOperators:
    """Test C99 special operators"""
    
    def test_conditional_operator(self):
        """Test ternary conditional operator"""
        code = """
        int test(int a, int b) {
            int max = a > b ? a : b;
            return max;
        }
        """
        assert_no_errors(code)
    
    def test_comma_operator(self):
        """Test comma operator"""
        code = """
        int test(void) {
            int a, b, c;
            c = (a = 1, b = 2, a + b);
            return c;
        }
        """
        assert_no_errors(code)
    
    def test_sizeof_operator(self):
        """Test sizeof operator"""
        code = """
        int test(void) {
            int a;
            int size1 = sizeof(int);
            int size2 = sizeof(a);
            int size3 = sizeof a;
            return size1 + size2 + size3;
        }
        """
        assert_no_errors(code)


class TestC99OperatorPrecedence:
    """Test C99 operator precedence"""
    
    def test_precedence_arithmetic(self):
        """Test arithmetic operator precedence"""
        code = """
        int test(void) {
            int result = 2 + 3 * 4;
            return result;
        }
        """
        assert_no_errors(code)
    
    def test_precedence_mixed(self):
        """Test mixed operator precedence"""
        code = """
        int test(void) {
            int result = 1 + 2 * 3 < 4 && 5 > 6 || 7 == 8;
            return result;
        }
        """
        assert_no_errors(code)
