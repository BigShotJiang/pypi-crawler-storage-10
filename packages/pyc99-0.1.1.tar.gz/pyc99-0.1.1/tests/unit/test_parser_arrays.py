"""Tests for parsing array declarations."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import ArrayType, PointerType, PrimitiveType


def parse_code(code: str):
    """Helper to parse code and return AST."""
    tokenizer = Tokenizer(code, "test.c")
    parser = Parser(tokenizer)
    return parser.parse_translation_unit()


def get_var_type(code: str):
    """Helper to get the type of the first variable declaration."""
    ast = parse_code(f"int main() {{ {code} return 0; }}")
    func = ast.declarations[0]
    var_decl = func.body.statements[0]
    return var_decl.name, var_decl.var_type


class TestSimpleArrayDeclarations:
    """Test simple array declarations."""
    
    def test_fixed_size_array(self):
        """Test parsing fixed-size array: int arr[10]."""
        name, var_type = get_var_type("int arr[10];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 10
        assert var_type.is_complete()
        assert not var_type.is_vla
    
    def test_incomplete_array(self):
        """Test parsing incomplete array: int arr[]."""
        name, var_type = get_var_type("int arr[];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        assert var_type.size is None
        assert var_type.size_value is None
        assert not var_type.is_complete()
    
    def test_char_array(self):
        """Test parsing char array: char str[100]."""
        name, var_type = get_var_type("char str[100];")
        
        assert name == "str"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 100
        assert isinstance(var_type.element_type, PrimitiveType)
        assert var_type.element_type.name == "char"
    
    def test_large_array(self):
        """Test parsing large array: int big[1000]."""
        name, var_type = get_var_type("int big[1000];")
        
        assert name == "big"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 1000
    
    def test_small_array(self):
        """Test parsing small array: int tiny[1]."""
        name, var_type = get_var_type("int tiny[1];")
        
        assert name == "tiny"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 1


class TestMultiDimensionalArrays:
    """Test multi-dimensional array declarations."""
    
    def test_2d_array(self):
        """Test parsing 2D array: int matrix[5][10]."""
        name, var_type = get_var_type("int matrix[5][10];")
        
        assert name == "matrix"
        assert isinstance(var_type, ArrayType)
        
        # Outer dimension
        assert var_type.size_value == 10
        assert isinstance(var_type.element_type, ArrayType)
        
        # Inner dimension
        inner = var_type.element_type
        assert inner.size_value == 5
        assert isinstance(inner.element_type, PrimitiveType)
        assert inner.element_type.name == "int"
    
    def test_3d_array(self):
        """Test parsing 3D array: int cube[2][3][4]."""
        name, var_type = get_var_type("int cube[2][3][4];")
        
        assert name == "cube"
        assert isinstance(var_type, ArrayType)
        
        # Check all three dimensions
        assert var_type.size_value == 4
        assert isinstance(var_type.element_type, ArrayType)
        
        middle = var_type.element_type
        assert middle.size_value == 3
        assert isinstance(middle.element_type, ArrayType)
        
        inner = middle.element_type
        assert inner.size_value == 2
        assert isinstance(inner.element_type, PrimitiveType)
    
    def test_incomplete_2d_array(self):
        """Test parsing incomplete 2D array: int arr[][10]."""
        name, var_type = get_var_type("int arr[][10];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        
        # Outer dimension is incomplete
        assert var_type.size_value == 10
        assert isinstance(var_type.element_type, ArrayType)
        
        # Inner dimension is incomplete
        inner = var_type.element_type
        assert inner.size_value is None
        assert not inner.is_complete()


class TestArraysWithExpressions:
    """Test arrays with size expressions."""
    
    def test_array_with_arithmetic_size(self):
        """Test array with arithmetic expression: int arr[5+5]."""
        name, var_type = get_var_type("int arr[5+5];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        # Parser should evaluate constant expression
        assert var_type.size_value == 10
    
    def test_array_with_multiplication_size(self):
        """Test array with multiplication: int arr[2*5]."""
        name, var_type = get_var_type("int arr[2*5];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 10
    
    def test_array_with_complex_expression(self):
        """Test array with complex expression: int arr[10-5+3]."""
        name, var_type = get_var_type("int arr[10-5+3];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 8


class TestArraysWithPointers:
    """Test arrays combined with pointers."""
    
    def test_array_of_pointers(self):
        """Test array of pointers: int *arr[10]."""
        name, var_type = get_var_type("int *arr[10];")
        
        assert name == "arr"
        # This should be ArrayType with PointerType elements
        # But due to declarator parsing order, it might be PointerType
        # The correct interpretation is: array of 10 pointers to int
        # This is a known complexity in C declarator parsing
    
    @pytest.mark.skip(reason="Pointer to array parsing requires complex declarator handling")
    def test_pointer_to_array(self):
        """Test pointer to array: int (*p)[10]."""
        name, var_type = get_var_type("int (*p)[10];")
        
        assert name == "p"
        # This should be PointerType to ArrayType
        assert isinstance(var_type, PointerType)
        assert isinstance(var_type.pointee_type, ArrayType)
        assert var_type.pointee_type.size_value == 10


class TestArrayDeclarationEdgeCases:
    """Test edge cases in array declarations."""
    
    def test_zero_size_array(self):
        """Test zero-size array: int arr[0]."""
        name, var_type = get_var_type("int arr[0];")
        
        assert name == "arr"
        assert isinstance(var_type, ArrayType)
        assert var_type.size_value == 0
    
    @pytest.mark.skip(reason="Typedef support not fully implemented yet")
    def test_array_with_typedef(self):
        """Test array with typedef'd type."""
        code = """
        typedef int myint;
        int main() {
            myint arr[10];
            return 0;
        }
        """
        ast = parse_code(code)
        func = ast.declarations[1]  # Second declaration is main
        var_decl = func.body.statements[0]
        
        assert var_decl.name == "arr"
        assert isinstance(var_decl.var_type, ArrayType)
        assert var_decl.var_type.size_value == 10


class TestGlobalArrays:
    """Test global array declarations."""
    
    def test_global_array(self):
        """Test global array declaration."""
        code = "int global_arr[100];"
        ast = parse_code(code)
        
        var_decl = ast.declarations[0]
        assert var_decl.name == "global_arr"
        assert isinstance(var_decl.var_type, ArrayType)
        assert var_decl.var_type.size_value == 100
    
    def test_global_incomplete_array(self):
        """Test global incomplete array."""
        code = "int global_arr[];"
        ast = parse_code(code)
        
        var_decl = ast.declarations[0]
        assert var_decl.name == "global_arr"
        assert isinstance(var_decl.var_type, ArrayType)
        assert not var_decl.var_type.is_complete()


class TestArraysInFunctions:
    """Test arrays as function parameters."""
    
    def test_array_parameter(self):
        """Test array as function parameter."""
        code = "void func(int arr[10]) {}"
        ast = parse_code(code)
        
        func_decl = ast.declarations[0]
        assert func_decl.name == "func"
        
        # Array parameters decay to pointers in C
        param = func_decl.parameters[0]
        # The parameter type might be ArrayType or PointerType depending on implementation
        assert param.name == "arr"
    
    def test_multidimensional_array_parameter(self):
        """Test multi-dimensional array as parameter."""
        code = "void func(int matrix[5][10]) {}"
        ast = parse_code(code)
        
        func_decl = ast.declarations[0]
        param = func_decl.parameters[0]
        assert param.name == "matrix"


class TestArraySizeEvaluation:
    """Test constant expression evaluation for array sizes."""
    
    def test_simple_addition(self):
        """Test simple addition in size."""
        name, var_type = get_var_type("int arr[5+3];")
        assert var_type.size_value == 8
    
    def test_simple_subtraction(self):
        """Test simple subtraction in size."""
        name, var_type = get_var_type("int arr[10-3];")
        assert var_type.size_value == 7
    
    def test_simple_multiplication(self):
        """Test simple multiplication in size."""
        name, var_type = get_var_type("int arr[4*3];")
        assert var_type.size_value == 12
    
    def test_simple_division(self):
        """Test simple division in size."""
        name, var_type = get_var_type("int arr[20/4];")
        assert var_type.size_value == 5
    
    def test_complex_expression(self):
        """Test complex expression in size."""
        name, var_type = get_var_type("int arr[2*5+3];")
        assert var_type.size_value == 13
    
    def test_parenthesized_expression(self):
        """Test parenthesized expression in size."""
        name, var_type = get_var_type("int arr[2*(5+3)];")
        assert var_type.size_value == 16
