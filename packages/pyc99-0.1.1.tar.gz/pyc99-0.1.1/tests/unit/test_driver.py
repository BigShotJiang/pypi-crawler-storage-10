"""Unit tests for compiler driver and toolchain."""

import pytest
import tempfile
import os
from pathlib import Path

from src.driver.compiler_driver import (
    CompilerDriver, CompilerOptions, CompilationPhase, CompilationResult
)
from src.driver.toolchain import Toolchain, ToolchainResult


class TestCompilerDriver:
    """Test cases for CompilerDriver."""
    
    def test_driver_initialization(self):
        """Test driver initialization with options."""
        options = CompilerOptions(
            target="x86",
            optimization_level=1,
            verbose=True
        )
        driver = CompilerDriver(options)
        
        assert driver.options.target == "x86"
        assert driver.options.optimization_level == 1
        assert driver.options.verbose is True
        assert driver.error_reporter is not None
    
    def test_compile_simple_program(self):
        """Test compiling a simple C program."""
        # Create temporary source file
        source_code = """
int main() {
    return 0;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(target="x86", optimization_level=0)
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            assert isinstance(result, CompilationResult)
            # May succeed or fail depending on implementation completeness
            # Just verify we get a result
        finally:
            os.unlink(source_file)
    
    def test_compile_with_syntax_error(self):
        """Test compilation fails with syntax error."""
        source_code = """
int main() {
    return 0  // Missing semicolon
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(target="x86")
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            assert result.success is False
            assert result.error_reporter is not None
            assert result.error_reporter.has_errors()
        finally:
            os.unlink(source_file)
    
    def test_compile_stop_after_lexing(self):
        """Test stopping compilation after lexing phase."""
        source_code = """
int main() {
    return 0;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(
                target="x86",
                stop_after=CompilationPhase.LEXING
            )
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            if result.success:
                assert result.stopped_at == CompilationPhase.LEXING
                assert result.output is not None
        finally:
            os.unlink(source_file)
    
    def test_compile_stop_after_parsing(self):
        """Test stopping compilation after parsing phase."""
        source_code = """
int main() {
    return 0;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(
                target="x86",
                stop_after=CompilationPhase.PARSING
            )
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            if result.success:
                assert result.stopped_at == CompilationPhase.PARSING
        finally:
            os.unlink(source_file)
    
    def test_compile_with_optimization(self):
        """Test compilation with optimization enabled."""
        source_code = """
int main() {
    int x = 1 + 2;
    return x;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(
                target="x86",
                optimization_level=1
            )
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            # Verify optimization was attempted
        finally:
            os.unlink(source_file)
    
    def test_compile_for_arm_target(self):
        """Test compilation for ARM target."""
        source_code = """
int main() {
    return 0;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(target="arm")
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            # Verify ARM code generation was attempted
        finally:
            os.unlink(source_file)
    
    def test_compile_nonexistent_file(self):
        """Test compilation fails for nonexistent file."""
        options = CompilerOptions(target="x86")
        driver = CompilerDriver(options)
        
        result = driver.compile("nonexistent_file.c")
        
        assert result is not None
        assert result.success is False
        assert result.error_reporter.has_errors()
    
    def test_phase_orchestration(self):
        """Test that all phases are executed in order."""
        source_code = """
int add(int a, int b) {
    return a + b;
}

int main() {
    int result = add(1, 2);
    return result;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(
                target="x86",
                optimization_level=1,
                verbose=False
            )
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            # If successful, all phases should have executed
            if result.success:
                assert result.stopped_at == CompilationPhase.CODE_GENERATION
                assert result.output is not None
        finally:
            os.unlink(source_file)
    
    def test_error_propagation(self):
        """Test that errors are properly propagated between phases."""
        # Code with semantic error (undefined variable)
        source_code = """
int main() {
    return undefined_variable;
}
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.c', delete=False) as f:
            f.write(source_code)
            source_file = f.name
        
        try:
            options = CompilerOptions(target="x86")
            driver = CompilerDriver(options)
            
            result = driver.compile(source_file)
            
            assert result is not None
            assert result.success is False
            assert result.error_reporter.has_errors()
            # Should stop at semantic analysis phase
            assert result.stopped_at == CompilationPhase.SEMANTIC_ANALYSIS
        finally:
            os.unlink(source_file)


class TestToolchain:
    """Test cases for Toolchain."""
    
    def test_toolchain_initialization(self):
        """Test toolchain initialization."""
        toolchain = Toolchain(target="x86", verbose=True)
        
        assert toolchain.target == "x86"
        assert toolchain.verbose is True
        assert toolchain.error_reporter is not None
        assert toolchain.temp_files == []
    
    def test_find_x86_assembler(self):
        """Test finding x86 assembler."""
        toolchain = Toolchain(target="x86")
        assembler = toolchain._find_x86_assembler()
        
        # May or may not find assembler depending on system
        # Just verify method returns string or None
        assert assembler is None or isinstance(assembler, str)
    
    def test_find_x86_linker(self):
        """Test finding x86 linker."""
        toolchain = Toolchain(target="x86")
        linker = toolchain._find_x86_linker()
        
        # May or may not find linker depending on system
        assert linker is None or isinstance(linker, str)
    
    def test_find_arm_assembler(self):
        """Test finding ARM assembler."""
        toolchain = Toolchain(target="arm")
        assembler = toolchain._find_arm_assembler()
        
        # May or may not find assembler depending on system
        assert assembler is None or isinstance(assembler, str)
    
    def test_find_arm_linker(self):
        """Test finding ARM linker."""
        toolchain = Toolchain(target="arm")
        linker = toolchain._find_arm_linker()
        
        # May or may not find linker depending on system
        assert linker is None or isinstance(linker, str)
    
    def test_assemble_x86(self):
        """Test assembling x86 assembly code."""
        # Create simple assembly file
        asm_code = """
\t.text
\t.globl main
main:
\tmovq $0, %rax
\tret
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.s', delete=False) as f:
            f.write(asm_code)
            asm_file = f.name
        
        try:
            toolchain = Toolchain(target="x86")
            
            # Try to assemble
            result = toolchain.assemble(asm_file)
            
            assert result is not None
            assert isinstance(result, ToolchainResult)
            
            # If assembler is available, check result
            if toolchain._find_x86_assembler():
                if result.success:
                    assert result.output_file is not None
                    assert os.path.exists(result.output_file)
                    # Clean up
                    if result.output_file:
                        try:
                            os.unlink(result.output_file)
                        except Exception:
                            pass
        finally:
            os.unlink(asm_file)
            toolchain.cleanup()
    
    def test_link_x86(self):
        """Test linking x86 object files."""
        # This test requires a valid object file
        # Skip if assembler not available
        toolchain = Toolchain(target="x86")
        
        if not toolchain._find_x86_assembler() or not toolchain._find_x86_linker():
            pytest.skip("x86 toolchain not available")
        
        # Create simple assembly file
        asm_code = """
\t.text
\t.globl main
main:
\tmovq $0, %rax
\tret
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.s', delete=False) as f:
            f.write(asm_code)
            asm_file = f.name
        
        try:
            # Assemble first
            asm_result = toolchain.assemble(asm_file)
            
            if asm_result.success and asm_result.output_file:
                # Try to link
                with tempfile.NamedTemporaryFile(delete=False) as f:
                    output_file = f.name
                
                try:
                    link_result = toolchain.link([asm_result.output_file], output_file)
                    
                    assert link_result is not None
                    assert isinstance(link_result, ToolchainResult)
                    
                    if link_result.success:
                        assert os.path.exists(output_file)
                finally:
                    try:
                        os.unlink(output_file)
                    except Exception:
                        pass
        finally:
            os.unlink(asm_file)
            toolchain.cleanup()
    
    def test_cleanup_temp_files(self):
        """Test cleanup of temporary files."""
        toolchain = Toolchain(target="x86")
        
        # Create a temporary file and add to cleanup list
        fd, temp_file = tempfile.mkstemp()
        os.close(fd)
        toolchain.temp_files.append(temp_file)
        
        assert os.path.exists(temp_file)
        
        # Cleanup
        toolchain.cleanup()
        
        assert not os.path.exists(temp_file)
        assert toolchain.temp_files == []
    
    def test_invalid_target(self):
        """Test toolchain with invalid target."""
        toolchain = Toolchain(target="invalid")
        
        # Create dummy assembly file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.s', delete=False) as f:
            f.write(".text\n")
            asm_file = f.name
        
        try:
            result = toolchain.assemble(asm_file)
            
            assert result is not None
            assert result.success is False
        finally:
            os.unlink(asm_file)
    
    def test_command_exists(self):
        """Test command existence check."""
        toolchain = Toolchain(target="x86")
        
        # Test with a command that should exist
        assert toolchain._command_exists('ls') or toolchain._command_exists('dir')
        
        # Test with a command that shouldn't exist
        assert not toolchain._command_exists('nonexistent_command_xyz123')


class TestCompilerOptions:
    """Test cases for CompilerOptions."""
    
    def test_default_options(self):
        """Test default compiler options."""
        options = CompilerOptions()
        
        assert options.target == "x86"
        assert options.optimization_level == 0
        assert options.output_file is None
        assert options.stop_after is None
        assert options.verbose is False
        assert options.debug is False
    
    def test_custom_options(self):
        """Test custom compiler options."""
        options = CompilerOptions(
            target="arm",
            optimization_level=1,
            output_file="output.s",
            stop_after=CompilationPhase.CODE_GENERATION,
            verbose=True,
            debug=True
        )
        
        assert options.target == "arm"
        assert options.optimization_level == 1
        assert options.output_file == "output.s"
        assert options.stop_after == CompilationPhase.CODE_GENERATION
        assert options.verbose is True
        assert options.debug is True


class TestCompilationResult:
    """Test cases for CompilationResult."""
    
    def test_success_result(self):
        """Test successful compilation result."""
        result = CompilationResult(
            success=True,
            output="assembly code",
            stopped_at=CompilationPhase.CODE_GENERATION
        )
        
        assert result.success is True
        assert result.output == "assembly code"
        assert result.stopped_at == CompilationPhase.CODE_GENERATION
    
    def test_error_result(self):
        """Test error compilation result."""
        from src.utils.error_reporter import ErrorReporter
        
        error_reporter = ErrorReporter()
        error_reporter.error(None, "Test error")
        
        result = CompilationResult(
            success=False,
            error_reporter=error_reporter,
            stopped_at=CompilationPhase.PARSING
        )
        
        assert result.success is False
        assert result.error_reporter is not None
        assert result.error_reporter.has_errors()
        assert result.stopped_at == CompilationPhase.PARSING
