"""Tests for C99 operators."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import (
    AssignmentExpr, UnaryExpr, ConditionalExpr, CommaExpr, SizeofExpr,
    BinaryExpr, Identifier, Literal
)


class TestCompoundAssignmentOperators:
    """Test compound assignment operators (+=, -=, etc.)."""
    
    def test_plus_assign(self):
        """Test += operator."""
        source = "void foo() { x += 5; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assert isinstance(expr_stmt.expression, AssignmentExpr)
        assert expr_stmt.expression.operator == "+="
    
    def test_minus_assign(self):
        """Test -= operator."""
        source = "void foo() { x -= 5; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assert isinstance(expr_stmt.expression, AssignmentExpr)
        assert expr_stmt.expression.operator == "-="
    
    def test_all_compound_assignments(self):
        """Test all compound assignment operators."""
        operators = ["+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>="]
        for op in operators:
            source = f"void foo() {{ x {op} 5; }}"
            tokenizer = Tokenizer(source)
            parser = Parser(tokenizer)
            ast = parser.parse_translation_unit()
            
            func = ast.declarations[0]
            expr_stmt = func.body.statements[0]
            assert isinstance(expr_stmt.expression, AssignmentExpr)
            assert expr_stmt.expression.operator == op


class TestIncrementDecrementOperators:
    """Test increment and decrement operators (++, --)."""
    
    def test_prefix_increment(self):
        """Test prefix ++ operator."""
        source = "void foo() { x = ++y; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, UnaryExpr)
        assert assign_expr.rhs.operator == "++"
        assert assign_expr.rhs.is_prefix == True
    
    def test_postfix_increment(self):
        """Test postfix ++ operator."""
        source = "void foo() { x = y++; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, UnaryExpr)
        assert assign_expr.rhs.operator == "++"
        assert assign_expr.rhs.is_prefix == False
    
    def test_prefix_decrement(self):
        """Test prefix -- operator."""
        source = "void foo() { x = --y; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, UnaryExpr)
        assert assign_expr.rhs.operator == "--"
        assert assign_expr.rhs.is_prefix == True
    
    def test_postfix_decrement(self):
        """Test postfix -- operator."""
        source = "void foo() { x = y--; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, UnaryExpr)
        assert assign_expr.rhs.operator == "--"
        assert assign_expr.rhs.is_prefix == False
    
    def test_multiple_increments(self):
        """Test multiple increment operators in one expression."""
        source = "void foo() { x = ++y + z++; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, BinaryExpr)
        assert isinstance(assign_expr.rhs.left, UnaryExpr)
        assert assign_expr.rhs.left.is_prefix == True
        assert isinstance(assign_expr.rhs.right, UnaryExpr)
        assert assign_expr.rhs.right.is_prefix == False


class TestConditionalOperator:
    """Test conditional (ternary) operator (? :)."""
    
    def test_simple_conditional(self):
        """Test simple conditional expression."""
        source = "void foo() { x = a ? b : c; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, ConditionalExpr)
        assert isinstance(assign_expr.rhs.condition, Identifier)
        assert isinstance(assign_expr.rhs.true_expr, Identifier)
        assert isinstance(assign_expr.rhs.false_expr, Identifier)
    
    def test_nested_conditional(self):
        """Test nested conditional expressions."""
        source = "void foo() { x = a ? (b ? c : d) : e; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, ConditionalExpr)
        assert isinstance(assign_expr.rhs.true_expr, ConditionalExpr)
    
    def test_conditional_with_arithmetic(self):
        """Test conditional with arithmetic expressions."""
        source = "void foo() { x = a > b ? a + 1 : b - 1; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, ConditionalExpr)
        assert isinstance(assign_expr.rhs.condition, BinaryExpr)
        assert isinstance(assign_expr.rhs.true_expr, BinaryExpr)
        assert isinstance(assign_expr.rhs.false_expr, BinaryExpr)


class TestCommaOperator:
    """Test comma operator."""
    
    def test_simple_comma(self):
        """Test simple comma expression."""
        source = "void foo() { x = (1, 2, 3); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, CommaExpr)
        assert len(assign_expr.rhs.expressions) == 3
    
    def test_comma_with_assignments(self):
        """Test comma operator with assignments."""
        source = "void foo() { x = (a = 1, b = 2, a + b); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, CommaExpr)
        assert len(assign_expr.rhs.expressions) == 3
        assert isinstance(assign_expr.rhs.expressions[0], AssignmentExpr)
        assert isinstance(assign_expr.rhs.expressions[1], AssignmentExpr)
        assert isinstance(assign_expr.rhs.expressions[2], BinaryExpr)
    
    def test_comma_in_for_loop(self):
        """Test comma operator in for loop."""
        source = "void foo() { for (i = 0, j = 10; i < j; i++, j--) { } }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        for_stmt = func.body.statements[0]
        # The init and increment should contain comma expressions
        assert isinstance(for_stmt.init, CommaExpr)
        assert isinstance(for_stmt.increment, CommaExpr)


class TestSizeofOperator:
    """Test sizeof operator."""
    
    def test_sizeof_type(self):
        """Test sizeof with type."""
        source = "void foo() { x = sizeof(int); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, SizeofExpr)
        assert assign_expr.rhs.is_type == True
    
    def test_sizeof_expression(self):
        """Test sizeof with expression."""
        source = "void foo() { x = sizeof(y); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, SizeofExpr)
        assert assign_expr.rhs.is_type == False
        assert isinstance(assign_expr.rhs.operand, Identifier)
    
    def test_sizeof_pointer(self):
        """Test sizeof with pointer variable."""
        source = "void foo() { int *p; x = sizeof(p); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[1]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, SizeofExpr)
        assert assign_expr.rhs.is_type == False
    
    def test_sizeof_array(self):
        """Test sizeof with array."""
        source = "void foo() { int arr[10]; x = sizeof(arr); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[1]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, SizeofExpr)
        assert assign_expr.rhs.is_type == False
    
    def test_sizeof_in_expression(self):
        """Test sizeof in arithmetic expression."""
        source = "void foo() { x = sizeof(int) + sizeof(char); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        assert isinstance(assign_expr, AssignmentExpr)
        assert isinstance(assign_expr.rhs, BinaryExpr)
        assert isinstance(assign_expr.rhs.left, SizeofExpr)
        assert isinstance(assign_expr.rhs.right, SizeofExpr)


class TestOperatorPrecedence:
    """Test operator precedence and associativity."""
    
    def test_comma_lowest_precedence(self):
        """Test that comma has lowest precedence."""
        source = "void foo() { x = (a = 1, b = 2); }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        # The comma should group the assignments
        assert isinstance(assign_expr.rhs, CommaExpr)
        assert len(assign_expr.rhs.expressions) == 2
    
    def test_conditional_precedence(self):
        """Test conditional operator precedence."""
        source = "void foo() { x = a ? b : c; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        # The conditional should be the RHS
        assert isinstance(assign_expr.rhs, ConditionalExpr)
        assert isinstance(assign_expr.rhs.condition, Identifier)
        assert isinstance(assign_expr.rhs.true_expr, Identifier)
        assert isinstance(assign_expr.rhs.false_expr, Identifier)
    
    def test_increment_with_arithmetic(self):
        """Test increment/decrement with arithmetic."""
        source = "void foo() { x = ++a * b++; }"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        func = ast.declarations[0]
        expr_stmt = func.body.statements[0]
        assign_expr = expr_stmt.expression
        # Should be: x = (++a) * (b++)
        assert isinstance(assign_expr.rhs, BinaryExpr)
        assert isinstance(assign_expr.rhs.left, UnaryExpr)
        assert isinstance(assign_expr.rhs.right, UnaryExpr)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
