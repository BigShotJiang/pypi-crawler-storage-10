"""Comprehensive tests for variable declarations and usage in semantic analyzer."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.utils.error_reporter import ErrorReporter


def compile_and_analyze(code: str):
    """Helper to compile and analyze code.
    
    Returns:
        tuple: (success, error_reporter, analyzer)
    """
    tokenizer = Tokenizer(code, "test.c")
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    analyzer.analyze()
    
    return not error_reporter.has_errors(), error_reporter, analyzer


class TestSimpleVariableDeclarations:
    """Test simple variable declarations."""
    
    def test_simple_declaration(self):
        """Test simple variable declaration."""
        code = "int main() { int x; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Simple declaration should succeed"
    
    def test_initialized_declaration(self):
        """Test initialized variable declaration."""
        code = "int main() { int x = 5; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Initialized declaration should succeed"
    
    def test_multiple_declarations(self):
        """Test multiple variable declarations."""
        code = "int main() { int a; int b; int c; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Multiple declarations should succeed"
    
    @pytest.mark.skip(reason="Parser doesn't support comma-separated declarations yet")
    def test_multiple_declarations_one_line(self):
        """Test multiple declarations in one statement."""
        code = "int main() { int a, b, c; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Multiple declarations in one line should succeed"
    
    def test_different_types(self):
        """Test declarations of different types."""
        code = """
        int main() {
            int i;
            char c;
            float f;
            double d;
            return 0;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Different type declarations should succeed"


class TestVariableUsage:
    """Test variable usage after declaration."""
    
    def test_variable_assignment(self):
        """Test assigning to a variable."""
        code = "int main() { int x; x = 5; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable assignment should succeed"
    
    def test_variable_in_expression(self):
        """Test using variable in expression."""
        code = "int main() { int x; int y; x = 5; y = x + 10; return y; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in expression should succeed"
    
    def test_variable_in_return(self):
        """Test returning a variable."""
        code = "int main() { int x; x = 5; return x; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Returning variable should succeed"
    
    def test_variable_in_condition(self):
        """Test using variable in condition."""
        code = "int main() { int x; x = 5; if (x > 0) { return 1; } return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in condition should succeed"
    
    def test_multiple_variable_usage(self):
        """Test using multiple variables."""
        code = """
        int main() {
            int a;
            int b;
            int c;
            a = 1;
            b = 2;
            c = a + b;
            return c;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Multiple variable usage should succeed"


class TestVariableScoping:
    """Test variable scoping rules."""
    
    def test_nested_scope(self):
        """Test variable in nested scope."""
        code = """
        int main() {
            int x;
            x = 5;
            {
                int y;
                y = 10;
            }
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Nested scope should succeed"
    
    def test_variable_shadowing(self):
        """Test variable shadowing in nested scope."""
        code = """
        int main() {
            int x;
            x = 5;
            {
                int x;
                x = 10;
            }
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable shadowing should succeed"
    
    def test_multiple_nested_scopes(self):
        """Test multiple levels of nested scopes."""
        code = """
        int main() {
            int a;
            a = 1;
            {
                int b;
                b = 2;
                {
                    int c;
                    c = 3;
                }
            }
            return a;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Multiple nested scopes should succeed"
    
    def test_scope_in_if_statement(self):
        """Test variable scope in if statement."""
        code = """
        int main() {
            int x;
            x = 5;
            if (x > 0) {
                int y;
                y = 10;
            }
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Scope in if statement should succeed"
    
    def test_scope_in_while_loop(self):
        """Test variable scope in while loop."""
        code = """
        int main() {
            int i;
            i = 0;
            while (i < 10) {
                int temp;
                temp = i;
                i = i + 1;
            }
            return i;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Scope in while loop should succeed"
    
    def test_scope_in_for_loop(self):
        """Test variable scope in for loop."""
        code = """
        int main() {
            int i;
            for (i = 0; i < 10; i = i + 1) {
                int temp;
                temp = i;
            }
            return i;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Scope in for loop should succeed"


class TestVariableErrors:
    """Test error detection for variables."""
    
    def test_undeclared_variable(self):
        """Test error for undeclared variable."""
        code = "int main() { x = 5; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert not success, "Undeclared variable should fail"
        assert any("Undeclared identifier" in diag.message 
                  for diag in error_reporter.diagnostics)
    
    def test_redeclaration_same_scope(self):
        """Test error for redeclaration in same scope."""
        code = "int main() { int x; int x; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert not success, "Redeclaration should fail"
        assert any("Redeclaration" in diag.message 
                  for diag in error_reporter.diagnostics)
    
    def test_use_before_declaration(self):
        """Test error for using variable before declaration."""
        code = "int main() { x = 5; int x; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert not success, "Use before declaration should fail"
    
    def test_variable_out_of_scope(self):
        """Test error for using variable out of scope."""
        code = """
        int main() {
            {
                int x;
                x = 5;
            }
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert not success, "Variable out of scope should fail"
        assert any("Undeclared identifier" in diag.message 
                  for diag in error_reporter.diagnostics)


class TestVariableWarnings:
    """Test warnings for variables."""
    
    def test_uninitialized_variable_warning(self):
        """Test warning for uninitialized variable."""
        code = "int main() { int x; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Uninitialized variable should compile"
        # Check for warning
        warnings = [diag for diag in error_reporter.diagnostics if not diag.is_error]
        assert len(warnings) > 0, "Should have warning for uninitialized variable"
        assert any("without initializer" in diag.message for diag in warnings)
    
    def test_unused_variable_warning(self):
        """Test warning for unused variable."""
        code = "int main() { int x; x = 5; return 0; }"
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Unused variable should compile"
        # Note: unused variable warnings are generated at end of analysis


class TestVariablesInControlFlow:
    """Test variables in control flow statements."""
    
    def test_variable_in_if_condition(self):
        """Test variable in if condition."""
        code = """
        int main() {
            int x;
            x = 5;
            if (x > 0) {
                return 1;
            }
            return 0;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in if condition should succeed"
    
    def test_variable_in_while_condition(self):
        """Test variable in while condition."""
        code = """
        int main() {
            int i;
            i = 0;
            while (i < 10) {
                i = i + 1;
            }
            return i;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in while condition should succeed"
    
    def test_variable_in_for_loop(self):
        """Test variable in for loop."""
        code = """
        int main() {
            int i;
            for (i = 0; i < 10; i = i + 1) {
            }
            return i;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in for loop should succeed"
    
    def test_variable_modified_in_loop(self):
        """Test variable modified in loop."""
        code = """
        int main() {
            int sum;
            int i;
            sum = 0;
            for (i = 0; i < 10; i = i + 1) {
                sum = sum + i;
            }
            return sum;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable modified in loop should succeed"


class TestVariablesWithFunctions:
    """Test variables with function calls."""
    
    def test_variable_as_function_argument(self):
        """Test passing variable as function argument."""
        code = """
        int add(int a, int b) {
            return a + b;
        }
        
        int main() {
            int x;
            int y;
            int result;
            x = 5;
            y = 10;
            result = add(x, y);
            return result;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable as function argument should succeed"
    
    def test_variable_from_function_return(self):
        """Test assigning function return to variable."""
        code = """
        int get_value() {
            return 42;
        }
        
        int main() {
            int x;
            x = get_value();
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable from function return should succeed"
    
    def test_local_variable_vs_parameter(self):
        """Test local variable with same name as parameter."""
        code = """
        int func(int x) {
            int y;
            y = x + 1;
            return y;
        }
        
        int main() {
            int x;
            x = 5;
            return func(x);
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Local variable vs parameter should succeed"


class TestComplexVariableScenarios:
    """Test complex variable scenarios."""
    
    def test_multiple_assignments(self):
        """Test multiple assignments to same variable."""
        code = """
        int main() {
            int x;
            x = 1;
            x = 2;
            x = 3;
            return x;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Multiple assignments should succeed"
    
    def test_variable_in_complex_expression(self):
        """Test variable in complex expression."""
        code = """
        int main() {
            int a;
            int b;
            int c;
            int result;
            a = 1;
            b = 2;
            c = 3;
            result = a + b * c - a / b;
            return result;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable in complex expression should succeed"
    
    def test_variable_swap(self):
        """Test swapping two variables."""
        code = """
        int main() {
            int a;
            int b;
            int temp;
            a = 1;
            b = 2;
            temp = a;
            a = b;
            b = temp;
            return a;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Variable swap should succeed"
    
    def test_deeply_nested_scopes(self):
        """Test deeply nested scopes with variables."""
        code = """
        int main() {
            int a;
            a = 1;
            {
                int b;
                b = 2;
                {
                    int c;
                    c = 3;
                    {
                        int d;
                        d = 4;
                        {
                            int e;
                            e = 5;
                        }
                    }
                }
            }
            return a;
        }
        """
        success, error_reporter, analyzer = compile_and_analyze(code)
        assert success, "Deeply nested scopes should succeed"
