"""Unit tests for ARM code generator."""

import pytest
from src.codegen.arm.arm_codegen import ARMCodeGenerator
from src.codegen.arm.arm_registers import ARMRegister
from src.codegen.arm.arm_instructions import ImmediateOperand
from src.ir.ir_module import IRModule, IRFunction
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, VirtualRegister, Constant, Label, GlobalVariable
)
from src.ir.basic_block import BasicBlock
from src.parser.ast_nodes import PrimitiveType
from src.utils.source_location import SourceLocation


# Helper function to create types
def int_type():
    """Create an int type."""
    return PrimitiveType(name="int", location=SourceLocation("test", 1, 1))


def void_type():
    """Create a void type."""
    return PrimitiveType(name="void", location=SourceLocation("test", 1, 1))


class TestInstructionSelection:
    """Test instruction selection for all IR operations."""
    
    def test_add_instruction(self):
        """Test ADD instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_add", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        assert "add" in code.lower()
        assert "test_add:" in code
    
    def test_sub_instruction(self):
        """Test SUB instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_sub", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.SUB, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        assert "sub" in code.lower()

    def test_mul_instruction(self):
        """Test MUL instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_mul", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.MUL, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        assert "mul" in code.lower()
    
    def test_div_instruction(self):
        """Test DIV instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_div", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.DIV, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        assert "sdiv" in code.lower()
    
    def test_comparison_eq(self):
        """Test EQ comparison instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_eq", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.EQ, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        assert "cmp" in code.lower()
        assert "moveq" in code.lower() or "mov" in code.lower()


class TestCallingConvention:
    """Test ARM EABI calling convention compliance."""
    
    def test_function_prologue(self):
        """Test function prologue generation."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Check for standard prologue
        assert "push" in code.lower() or "stmdb" in code.lower()
        assert "lr" in code.lower()
    
    def test_return_value_in_r0(self):
        """Test that return value is placed in R0."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v1]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Return value should be moved to R0
        assert "r0" in code.lower()
    
    def test_parameter_passing_registers(self):
        """Test that parameters are passed in correct registers."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        # Add parameters
        p1 = VirtualRegister("%p1", int_type())
        p2 = VirtualRegister("%p2", int_type())
        func.add_parameter(p1)
        func.add_parameter(p2)
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [p1, p2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # First two parameters should use R0 and R1
        assert "r0" in code.lower() or "r1" in code.lower()
    
    def test_function_call_instruction(self):
        """Test function call instruction generation."""
        module = IRModule("test")
        func = IRFunction("test_caller", int_type())
        
        entry = BasicBlock(Label("entry"))
        callee = GlobalVariable(name="callee", value_type=int_type())
        arg1 = VirtualRegister("%arg1", int_type())
        arg2 = VirtualRegister("%arg2", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.CALL, result, [callee, arg1, arg2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Check for call instruction (bl in ARM)
        assert "bl" in code.lower()
        assert "callee" in code.lower()


class TestImmediateEncoding:
    """Test ARM immediate value encoding restrictions."""
    
    def test_valid_immediate(self):
        """Test that valid immediates are encoded directly."""
        # Test various valid immediates
        assert ImmediateOperand.is_valid_immediate(0)
        assert ImmediateOperand.is_valid_immediate(255)
        assert ImmediateOperand.is_valid_immediate(0xFF)
    
    def test_invalid_immediate_uses_movw_movt(self):
        """Test that invalid immediates use MOVW/MOVT."""
        module = IRModule("test")
        func = IRFunction("test_large_imm", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        large_value = 0x12345678  # Cannot be encoded as ARM immediate
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, v1, [Constant(value=10, value_type=int_type()), 
                              Constant(value=large_value, value_type=int_type())]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v1]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Should use MOVW/MOVT for large immediate
        assert "movw" in code.lower() or "movt" in code.lower() or "ldr" in code.lower()


class TestControlFlow:
    """Test control flow instruction generation."""
    
    def test_unconditional_branch(self):
        """Test unconditional branch generation."""
        module = IRModule("test")
        func = IRFunction("test_branch", int_type())
        
        entry = BasicBlock(Label("entry"))
        target = BasicBlock(Label("target"))
        
        entry.add_instruction(IRInstruction(
            IROpcode.BR, None, [Label("target")]
        ))
        
        target.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        func.add_basic_block(target)
        
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Should generate b instruction
        assert "b " in code.lower() or "\tb" in code.lower()
        assert "target:" in code.lower()
    
    def test_conditional_branch(self):
        """Test conditional branch generation."""
        module = IRModule("test")
        func = IRFunction("test_cond_branch", int_type())
        
        entry = BasicBlock(Label("entry"))
        true_block = BasicBlock(Label("true_branch"))
        false_block = BasicBlock(Label("false_branch"))
        
        condition = VirtualRegister("%cond", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.COND_BR, None, [condition, Label("true_branch"), Label("false_branch")]
        ))
        
        true_block.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=1, value_type=int_type())]
        ))
        
        false_block.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        func.add_basic_block(true_block)
        func.add_basic_block(false_block)
        
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Should generate cmp and conditional branch
        assert "cmp" in code.lower()
        assert "bne" in code.lower() or "beq" in code.lower()
        assert "true_branch:" in code.lower()
        assert "false_branch:" in code.lower()


class TestFunctionGeneration:
    """Test complete function generation."""
    
    def test_simple_function(self):
        """Test generation of a simple function."""
        module = IRModule("test")
        func = IRFunction("add_numbers", int_type())
        
        p1 = VirtualRegister("%p1", int_type())
        p2 = VirtualRegister("%p2", int_type())
        func.add_parameter(p1)
        func.add_parameter(p2)
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [p1, p2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Check function structure
        assert ".text" in code
        assert ".globl add_numbers" in code
        assert "add_numbers:" in code
        assert "push" in code.lower() or "stmdb" in code.lower()
        assert "pop" in code.lower() or "ldmia" in code.lower() or "bx" in code.lower()
    
    def test_assembly_directives(self):
        """Test that ARM-specific assembly directives are present."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = ARMCodeGenerator(module)
        code = codegen.generate()
        
        # Check for ARM-specific directives
        assert ".syntax unified" in code
        assert ".arch armv7-a" in code
