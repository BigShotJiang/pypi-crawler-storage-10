"""Unit tests for variadic function support."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import (
    FunctionDecl, VarDecl, FunctionType, PrimitiveType, Parameter
)
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.utils.error_reporter import ErrorReporter


class TestVariadicFunctionParsing:
    """Test parsing of variadic function declarations."""
    
    def test_simple_variadic_function_declaration(self):
        """Test parsing: int printf(char *fmt, ...);"""
        source = "int printf(char *fmt, ...);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, FunctionDecl)
        assert decl.name == "printf"
        assert decl.is_variadic is True
        assert len(decl.parameters) == 1
        assert decl.parameters[0].name == "fmt"
    
    def test_variadic_function_with_multiple_params(self):
        """Test parsing: int func(int a, int b, ...);"""
        source = "int func(int a, int b, ...);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, FunctionDecl)
        assert decl.name == "func"
        assert decl.is_variadic is True
        assert len(decl.parameters) == 2
        assert decl.parameters[0].name == "a"
        assert decl.parameters[1].name == "b"
    
    def test_variadic_function_definition(self):
        """Test parsing variadic function with body."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, FunctionDecl)
        assert decl.name == "sum"
        assert decl.is_variadic is True
        assert decl.body is not None
        assert len(decl.parameters) == 1
    
    def test_non_variadic_function(self):
        """Test that non-variadic functions are correctly identified."""
        source = "int add(int a, int b);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, FunctionDecl)
        assert decl.is_variadic is False


class TestVariadicFunctionSemantics:
    """Test semantic analysis of variadic functions."""
    
    def test_variadic_function_type_checking(self):
        """Test that variadic function types are correctly handled."""
        source = """
        int printf(char *fmt, ...);
        
        int main() {
            printf("Hello");
            printf("Number: %d", 42);
            printf("Two numbers: %d %d", 1, 2);
            return 0;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
    
    def test_variadic_function_too_few_args(self):
        """Test that calling variadic function with too few args is an error."""
        source = """
        int printf(char *fmt, ...);
        
        int main() {
            printf();  // Error: missing required fmt parameter
            return 0;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Should have error about too few arguments
        assert error_reporter.has_errors()
    
    def test_variadic_function_accepts_extra_args(self):
        """Test that variadic functions accept extra arguments."""
        source = """
        int sum(int count, ...);
        
        int main() {
            sum(3, 1, 2, 3);  // OK: 3 extra args
            sum(5, 10, 20, 30, 40, 50);  // OK: 5 extra args
            return 0;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
    
    def test_va_list_builtin_type(self):
        """Test that va_list builtin type is registered in semantic analyzer."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        
        # Check that va_list is registered as a type
        va_list_symbol = analyzer.symbol_table.lookup("va_list")
        assert va_list_symbol is not None
        assert va_list_symbol.kind.name == "TYPE"
    
    def test_builtin_va_functions(self):
        """Test that builtin va_* functions are registered."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        
        # Check that builtin va functions are registered
        va_start = analyzer.symbol_table.lookup("__builtin_va_start")
        va_arg = analyzer.symbol_table.lookup("__builtin_va_arg")
        va_end = analyzer.symbol_table.lookup("__builtin_va_end")
        
        assert va_start is not None
        assert va_arg is not None
        assert va_end is not None
        assert va_start.kind.name == "FUNCTION"
        assert va_arg.kind.name == "FUNCTION"
        assert va_end.kind.name == "FUNCTION"


class TestVariadicFunctionIR:
    """Test IR generation for variadic functions."""
    
    def test_variadic_function_ir_generation(self):
        """Test that variadic functions generate correct IR."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Check that function is marked as variadic
        assert len(ir_module.functions) == 1
        ir_func = ir_module.functions[0]
        assert ir_func.name == "sum"
        assert ir_func.is_variadic is True
        assert len(ir_func.parameters) == 1
    
    def test_variadic_function_call_ir(self):
        """Test IR generation for variadic function calls."""
        source = """
        int printf(char *fmt, ...);
        
        int main() {
            printf("Hello %d %d", 1, 2);
            return 0;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Should generate IR without errors
        assert not error_reporter.has_errors()
        assert len(ir_module.functions) == 1
        
        # Check that main function has call instruction with 3 arguments
        main_func = ir_module.functions[0]
        assert main_func.name == "main"
        
        # Find CALL instruction in the IR
        has_call = False
        for block in main_func.get_all_blocks():
            for inst in block.instructions:
                if inst.opcode.name == "CALL":
                    has_call = True
                    # Should have function + 3 arguments (fmt, 1, 2)
                    assert len(inst.operands) >= 3
        
        assert has_call, "Should have CALL instruction"


class TestVariadicFunctionCodeGen:
    """Test code generation for variadic functions."""
    
    def test_variadic_function_x86_codegen(self):
        """Test x86 code generation for variadic functions."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Generate x86 code
        from src.codegen.x86.x86_codegen import X86CodeGenerator
        codegen = X86CodeGenerator(ir_module)
        asm_code = codegen.generate()
        
        # Should generate assembly without errors
        assert asm_code is not None
        assert "sum:" in asm_code
        assert "ret" in asm_code
    
    def test_variadic_function_arm_codegen(self):
        """Test ARM code generation for variadic functions."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Generate ARM code
        from src.codegen.arm.arm_codegen import ARMCodeGenerator
        codegen = ARMCodeGenerator(ir_module)
        asm_code = codegen.generate()
        
        # Should generate assembly without errors
        assert asm_code is not None
        assert "sum:" in asm_code
        assert "bx" in asm_code.lower() or "pop" in asm_code.lower()


class TestVariadicFunctionExamples:
    """Test realistic variadic function examples."""
    
    def test_custom_printf_like_function(self):
        """Test a custom printf-like function."""
        source = """
        int my_printf(char *format, ...) {
            return 0;
        }
        
        int main() {
            my_printf("Hello");
            my_printf("Number: %d", 42);
            my_printf("Two: %d %d", 1, 2);
            return 0;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Should have two functions
        assert len(ir_module.functions) == 2
        
        # my_printf should be variadic
        my_printf = next(f for f in ir_module.functions if f.name == "my_printf")
        assert my_printf.is_variadic is True
    
    def test_variadic_sum_function(self):
        """Test a variadic sum function (simplified without va_list usage)."""
        source = """
        int sum(int count, ...) {
            return count;
        }
        
        int main() {
            int result = sum(3, 10, 20, 30);
            return result;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzed_ast = analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
        
        # Generate IR
        ir_gen = IRGenerator(analyzed_ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Should have two functions
        assert len(ir_module.functions) == 2
        
        # sum should be variadic
        sum_func = next(f for f in ir_module.functions if f.name == "sum")
        assert sum_func.is_variadic is True
        assert len(sum_func.parameters) == 1
