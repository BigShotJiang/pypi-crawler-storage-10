"""Unit tests for struct and union support."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import (
    StructDecl, StructType, VarDecl, MemberAccess, InitializerList
)
from src.semantic.analyzer import SemanticAnalyzer
from src.semantic.struct_layout import StructLayoutCalculator
from src.utils.error_reporter import ErrorReporter


class TestStructParsing:
    """Test parsing of struct declarations."""
    
    def test_parse_simple_struct(self):
        """Test parsing a simple struct declaration."""
        source = """
        struct Point {
            int x;
            int y;
        };
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, StructDecl)
        assert decl.name == "Point"
        assert not decl.is_union
        assert decl.members is not None
        assert len(decl.members) == 2
        assert decl.members[0].name == "x"
        assert decl.members[1].name == "y"
    
    def test_parse_union(self):
        """Test parsing a union declaration."""
        source = """
        union Data {
            int i;
            float f;
        };
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, StructDecl)
        assert decl.name == "Data"
        assert decl.is_union
        assert len(decl.members) == 2
    
    def test_parse_forward_declaration(self):
        """Test parsing a forward declaration."""
        source = """
        struct Point;
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, StructDecl)
        assert decl.name == "Point"
        assert decl.members is None
    
    def test_parse_anonymous_struct(self):
        """Test parsing an anonymous struct."""
        source = """
        struct {
            int x;
            int y;
        } point;
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, VarDecl)
        assert decl.name == "point"
        assert isinstance(decl.var_type, StructType)
        assert decl.var_type.name is None  # Anonymous
        assert len(decl.var_type.members) == 2
    
    def test_parse_nested_struct(self):
        """Test parsing nested struct definitions."""
        source = """
        struct Outer {
            int a;
            struct Inner {
                int b;
                int c;
            } inner;
        };
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, StructDecl)
        assert decl.name == "Outer"
        assert len(decl.members) == 2
        
        # Check nested struct
        inner_member = decl.members[1]
        assert inner_member.name == "inner"
        assert isinstance(inner_member.var_type, StructType)
        assert inner_member.var_type.name == "Inner"
    
    def test_parse_multiple_declarators(self):
        """Test parsing multiple declarators in one declaration."""
        source = """
        struct Point {
            int x, y, z;
        };
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert len(decl.members) == 3
        assert decl.members[0].name == "x"
        assert decl.members[1].name == "y"
        assert decl.members[2].name == "z"


class TestStructLayout:
    """Test struct layout calculation."""
    
    def test_simple_struct_layout(self):
        """Test layout of a simple struct."""
        from src.parser.ast_nodes import PrimitiveType, SourceLocation
        
        loc = SourceLocation("test.c", 1, 1)
        
        # Create struct Point { int x; int y; }
        members = (
            VarDecl(loc, "x", PrimitiveType(loc, "int"), None, [], None),
            VarDecl(loc, "y", PrimitiveType(loc, "int"), None, [], None),
        )
        struct_type = StructType(loc, "Point", False, members)
        
        # Calculate layout
        calc = StructLayoutCalculator(target_platform='x86')
        calc.calculate_layout(struct_type)
        
        # Check layout
        assert struct_type.size == 8  # 2 * 4 bytes
        assert struct_type.alignment == 4
        assert struct_type.get_member_offset("x") == 0
        assert struct_type.get_member_offset("y") == 4
    
    def test_struct_with_padding(self):
        """Test struct layout with padding."""
        from src.parser.ast_nodes import PrimitiveType, SourceLocation
        
        loc = SourceLocation("test.c", 1, 1)
        
        # Create struct { char c; int i; }
        members = (
            VarDecl(loc, "c", PrimitiveType(loc, "char"), None, [], None),
            VarDecl(loc, "i", PrimitiveType(loc, "int"), None, [], None),
        )
        struct_type = StructType(loc, "Test", False, members)
        
        # Calculate layout
        calc = StructLayoutCalculator(target_platform='x86')
        calc.calculate_layout(struct_type)
        
        # Check layout - should have padding after char
        assert struct_type.get_member_offset("c") == 0
        assert struct_type.get_member_offset("i") == 4  # Aligned to 4 bytes
        assert struct_type.size == 8  # 4 bytes for char+padding, 4 for int
    
    def test_union_layout(self):
        """Test union layout."""
        from src.parser.ast_nodes import PrimitiveType, SourceLocation
        
        loc = SourceLocation("test.c", 1, 1)
        
        # Create union { int i; float f; }
        members = (
            VarDecl(loc, "i", PrimitiveType(loc, "int"), None, [], None),
            VarDecl(loc, "f", PrimitiveType(loc, "float"), None, [], None),
        )
        union_type = StructType(loc, "Data", True, members)
        
        # Calculate layout
        calc = StructLayoutCalculator(target_platform='x86')
        calc.calculate_layout(union_type)
        
        # Check layout - all members at offset 0
        assert union_type.get_member_offset("i") == 0
        assert union_type.get_member_offset("f") == 0
        assert union_type.size == 4  # Max of int and float
    
    def test_nested_struct_layout(self):
        """Test layout of nested structs."""
        from src.parser.ast_nodes import PrimitiveType, SourceLocation
        
        loc = SourceLocation("test.c", 1, 1)
        
        # Create inner struct { int a; int b; }
        inner_members = (
            VarDecl(loc, "a", PrimitiveType(loc, "int"), None, [], None),
            VarDecl(loc, "b", PrimitiveType(loc, "int"), None, [], None),
        )
        inner_type = StructType(loc, "Inner", False, inner_members)
        
        # Calculate inner layout first
        calc = StructLayoutCalculator(target_platform='x86')
        calc.calculate_layout(inner_type)
        
        # Create outer struct { int x; Inner inner; }
        outer_members = (
            VarDecl(loc, "x", PrimitiveType(loc, "int"), None, [], None),
            VarDecl(loc, "inner", inner_type, None, [], None),
        )
        outer_type = StructType(loc, "Outer", False, outer_members)
        
        # Calculate outer layout
        calc.calculate_layout(outer_type)
        
        # Check layout
        assert outer_type.get_member_offset("x") == 0
        assert outer_type.get_member_offset("inner") == 4
        assert outer_type.size == 12  # 4 + 8


class TestStructSemantics:
    """Test semantic analysis of structs."""
    
    def test_struct_declaration(self):
        """Test semantic analysis of struct declaration."""
        source = """
        struct Point {
            int x;
            int y;
        };
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_struct_variable_declaration(self):
        """Test declaring a variable of struct type."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point p;
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_member_access(self):
        """Test member access type checking."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        int main() {
            struct Point p;
            int a = p.x;
            return 0;
        }
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_arrow_operator(self):
        """Test arrow operator for pointer member access."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        int main() {
            struct Point *p;
            int a = p->x;
            return 0;
        }
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_invalid_member_access(self):
        """Test error on accessing non-existent member."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        int main() {
            struct Point p;
            int a = p.z;
            return 0;
        }
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert error_reporter.has_errors()
    
    def test_struct_initialization(self):
        """Test struct initialization."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        struct Point p = {10, 20};
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_partial_struct_initialization(self):
        """Test partial struct initialization."""
        source = """
        struct Point {
            int x;
            int y;
            int z;
        };
        
        struct Point p = {10, 20};
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_nested_struct_initialization(self):
        """Test nested struct initialization."""
        source = """
        struct Inner {
            int a;
            int b;
        };
        
        struct Outer {
            int x;
            struct Inner inner;
        };
        
        struct Outer o = {10, {20, 30}};
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()


class TestStructIntegration:
    """Integration tests for struct support."""
    
    def test_struct_example_program(self):
        """Test the struct example program."""
        source = """
        struct Point {
            int x;
            int y;
        };
        
        int main() {
            struct Point p = {10, 20};
            int sum = p.x + p.y;
            return sum;
        }
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()
    
    def test_struct_pointer_program(self):
        """Test struct with pointers."""
        source = """
        struct Node {
            int value;
            struct Node *next;
        };
        
        int main() {
            struct Node n;
            n.value = 42;
            n.next = 0;
            return n.value;
        }
        """
        tokenizer = Tokenizer(source, "test.c")
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        assert not error_reporter.has_errors()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
