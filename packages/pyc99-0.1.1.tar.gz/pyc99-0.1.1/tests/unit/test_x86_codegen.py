"""Unit tests for x86 code generator."""

import pytest
import sys
from src.codegen.x86.x86_codegen import X86CodeGenerator
from src.codegen.x86.x86_registers import X86Register
from src.ir.ir_module import IRModule, IRFunction
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, VirtualRegister, Constant, Label, GlobalVariable
)
from src.ir.basic_block import BasicBlock, ControlFlowGraph
from src.parser.ast_nodes import PrimitiveType
from src.utils.source_location import SourceLocation


# Helper function to create types
def int_type():
    """Create an int type."""
    return PrimitiveType(name="int", location=SourceLocation("test", 1, 1))


def void_type():
    """Create a void type."""
    return PrimitiveType(name="void", location=SourceLocation("test", 1, 1))


# Helper functions for syntax-aware testing
def has_register(code, reg_name):
    """Check if code contains a register in either Intel or AT&T syntax.
    
    Args:
        code: Assembly code string
        reg_name: Register name without prefix (e.g., 'rax', 'rdx')
    
    Returns:
        True if register is found in either syntax
    """
    code_lower = code.lower()
    # Intel syntax: no prefix
    if reg_name.lower() in code_lower:
        return True
    # AT&T syntax: % prefix
    if f"%{reg_name.lower()}" in code_lower:
        return True
    return False


def has_immediate(code, value):
    """Check if code contains an immediate value in either Intel or AT&T syntax.
    
    Args:
        code: Assembly code string
        value: Immediate value
    
    Returns:
        True if immediate is found in either syntax
    """
    # Intel syntax: no prefix
    if str(value) in code:
        return True
    # AT&T syntax: $ prefix
    if f"${value}" in code:
        return True
    return False


def get_syntax_from_code(code):
    """Determine which syntax is used in the generated code.
    
    Args:
        code: Assembly code string
    
    Returns:
        'intel' or 'att'
    """
    if '.intel_syntax' in code:
        return 'intel'
    return 'att'


class TestInstructionSelection:
    """Test instruction selection for all IR operations."""
    
    def test_add_instruction(self):
        """Test ADD instruction selection."""
        # Create IR module and function
        module = IRModule("test")
        func = IRFunction("test_add", int_type())
        
        # Create basic block with ADD instruction
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Generate code
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Verify ADD instruction is generated
        assert "add" in code.lower()
        assert "test_add:" in code
    
    def test_sub_instruction(self):
        """Test SUB instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_sub", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.SUB, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "sub" in code.lower()
    
    def test_mul_instruction(self):
        """Test MUL instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_mul", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.MUL, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "imul" in code.lower()

    def test_div_instruction(self):
        """Test DIV instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_div", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.DIV, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "idiv" in code.lower()
        assert "cqo" in code.lower()  # Sign extension
    
    def test_mod_instruction(self):
        """Test MOD instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_mod", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.MOD, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "idiv" in code.lower()
        assert has_register(code, "rdx")  # Remainder in RDX

    def test_and_instruction(self):
        """Test AND instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_and", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.AND, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "and" in code.lower()
    
    def test_or_instruction(self):
        """Test OR instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_or", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.OR, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "or" in code.lower()

    def test_xor_instruction(self):
        """Test XOR instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_xor", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.XOR, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "xor" in code.lower()
    
    def test_shift_left_instruction(self):
        """Test SHL instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_shl", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = Constant(value=2, value_type=int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.SHL, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "shl" in code.lower()

    def test_shift_right_instruction(self):
        """Test SHR instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_shr", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = Constant(value=2, value_type=int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.SHR, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "shr" in code.lower()
    
    def test_comparison_eq(self):
        """Test EQ comparison instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_eq", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.EQ, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "cmp" in code.lower()
        assert "sete" in code.lower()

    def test_comparison_lt(self):
        """Test LT comparison instruction selection."""
        module = IRModule("test")
        func = IRFunction("test_lt", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.LT, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "cmp" in code.lower()
        assert "setl" in code.lower()


class TestCallingConvention:
    """Test System V AMD64 calling convention compliance."""
    
    def test_function_prologue(self):
        """Test function prologue generation."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Check for standard prologue
        assert "push" in code.lower() and has_register(code, "rbp")
        assert "mov" in code.lower() and has_register(code, "rsp")

    def test_function_epilogue(self):
        """Test function epilogue generation."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=42, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Check for standard epilogue
        assert "mov" in code.lower() and has_register(code, "rbp") and has_register(code, "rsp")
        assert "pop" in code.lower() and has_register(code, "rbp")
        assert "ret" in code.lower()
    
    def test_return_value_in_rax(self):
        """Test that return value is placed in RAX."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v1]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Return value should be moved to RAX
        assert has_register(code, "rax")
    
    def test_parameter_passing_registers(self):
        """Test that parameters are passed in correct registers."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        # Add parameters
        p1 = VirtualRegister("%p1", int_type())
        p2 = VirtualRegister("%p2", int_type())
        func.add_parameter(p1)
        func.add_parameter(p2)
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [p1, p2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # First two parameters should use RDI and RSI
        assert has_register(code, "rdi") or has_register(code, "rsi")

    def test_function_call_instruction(self):
        """Test function call instruction generation."""
        module = IRModule("test")
        func = IRFunction("test_caller", int_type())
        
        entry = BasicBlock(Label("entry"))
        callee = GlobalVariable(name="callee", value_type=int_type())
        arg1 = VirtualRegister("%arg1", int_type())
        arg2 = VirtualRegister("%arg2", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.CALL, result, [callee, arg1, arg2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Check for call instruction
        assert "call" in code.lower()
        assert "callee" in code.lower()
    
    def test_callee_saved_registers(self):
        """Test that callee-saved registers are preserved."""
        module = IRModule("test")
        func = IRFunction("test_func", int_type())
        
        entry = BasicBlock(Label("entry"))
        # Use many virtual registers to force use of callee-saved registers
        regs = [VirtualRegister(f"%v{i}", int_type()) for i in range(15)]
        
        # Create a chain of additions
        for i in range(len(regs) - 1):
            entry.add_instruction(IRInstruction(
                IROpcode.ADD, regs[i+1], [regs[i], Constant(value=1, value_type=int_type())]
            ))
        
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [regs[-1]]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should save and restore callee-saved registers
        # Check for push/pop of callee-saved registers like RBX, R12-R15
        callee_saved_found = any(reg in code.lower() for reg in ["%rbx", "%r12", "%r13", "%r14", "%r15"])
        if callee_saved_found:
            assert "push" in code.lower()
            assert "pop" in code.lower()


class TestRegisterAllocation:
    """Test register allocation and spilling."""

    def test_simple_register_allocation(self):
        """Test basic register allocation."""
        module = IRModule("test")
        func = IRFunction("test_alloc", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%1", int_type())
        v2 = VirtualRegister("%2", int_type())
        v3 = VirtualRegister("%3", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, v3, [v1, v2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [v3]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate valid assembly
        assert "test_alloc:" in code
        assert "ret" in code.lower()
    
    def test_register_spilling(self):
        """Test register spilling when registers are exhausted."""
        module = IRModule("test")
        func = IRFunction("test_spill", int_type())
        
        entry = BasicBlock(Label("entry"))
        
        # Create many virtual registers to force spilling
        num_regs = 20
        regs = [VirtualRegister(f"%v{i}", int_type()) for i in range(num_regs)]
        
        # Initialize all registers
        for i, reg in enumerate(regs):
            entry.add_instruction(IRInstruction(
                IROpcode.ADD, reg, [Constant(i, int_type()), Constant(value=1, value_type=int_type())]
            ))
        
        # Use all registers in a final computation
        result = regs[0]
        for i in range(1, num_regs):
            new_result = VirtualRegister(f"%r{i}", int_type())
            entry.add_instruction(IRInstruction(
                IROpcode.ADD, new_result, [result, regs[i]]
            ))
            result = new_result
        
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate code with memory operations for spilled registers
        assert "test_spill:" in code
        # Spilling typically involves stack operations
        lines = code.split('\n')
        mov_count = sum(1 for line in lines if 'mov' in line.lower())
        assert mov_count > 0  # Should have mov instructions

    def test_register_allocation_with_parameters(self):
        """Test register allocation with function parameters."""
        module = IRModule("test")
        func = IRFunction("test_params", int_type())
        
        # Add 3 parameters
        p1 = VirtualRegister("%p1", int_type())
        p2 = VirtualRegister("%p2", int_type())
        p3 = VirtualRegister("%p3", int_type())
        func.add_parameter(p1)
        func.add_parameter(p2)
        func.add_parameter(p3)
        
        entry = BasicBlock(Label("entry"))
        temp1 = VirtualRegister("%temp1", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, temp1, [p1, p2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [temp1, p3]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Parameters should be handled according to calling convention
        assert "test_params:" in code
        # First 3 params use RDI, RSI, RDX
        assert has_register(code, "rdi") or has_register(code, "rsi") or has_register(code, "rdx")


class TestMemoryOperations:
    """Test memory load and store operations."""
    
    def test_load_instruction(self):
        """Test LOAD instruction generation."""
        module = IRModule("test")
        func = IRFunction("test_load", int_type())
        
        entry = BasicBlock(Label("entry"))
        addr = VirtualRegister("%addr", int_type())
        value = VirtualRegister("%value", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.LOAD, value, [addr]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [value]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate mov from memory
        assert "mov" in code.lower()
        assert "test_load:" in code

    def test_store_instruction(self):
        """Test STORE instruction generation."""
        module = IRModule("test")
        func = IRFunction("test_store", void_type())
        
        entry = BasicBlock(Label("entry"))
        value = VirtualRegister("%value", int_type())
        addr = VirtualRegister("%addr", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.STORE, None, [value, addr]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, []
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate mov to memory
        assert "mov" in code.lower()
        assert "test_store:" in code
    
    def test_alloca_instruction(self):
        """Test ALLOCA instruction generation."""
        module = IRModule("test")
        func = IRFunction("test_alloca", int_type())
        
        entry = BasicBlock(Label("entry"))
        ptr = VirtualRegister("%ptr", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ALLOCA, ptr, []
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate lea for stack allocation
        assert "lea" in code.lower()
        assert has_register(code, "rbp")


class TestControlFlow:
    """Test control flow instruction generation."""
    
    def test_unconditional_branch(self):
        """Test unconditional branch generation."""
        module = IRModule("test")
        func = IRFunction("test_branch", int_type())
        
        entry = BasicBlock(Label("entry"))
        target = BasicBlock(Label("target"))
        
        entry.add_instruction(IRInstruction(
            IROpcode.BR, None, [Label("target")]
        ))
        
        target.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        func.add_basic_block(target)
        
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate jmp instruction
        assert "jmp" in code.lower()
        assert "target:" in code.lower()

    def test_conditional_branch(self):
        """Test conditional branch generation."""
        module = IRModule("test")
        func = IRFunction("test_cond_branch", int_type())
        
        entry = BasicBlock(Label("entry"))
        true_block = BasicBlock(Label("true_branch"))
        false_block = BasicBlock(Label("false_branch"))
        
        condition = VirtualRegister("%cond", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.COND_BR, None, [condition, Label("true_branch"), Label("false_branch")]
        ))
        
        true_block.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=1, value_type=int_type())]
        ))
        
        false_block.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        func.add_basic_block(true_block)
        func.add_basic_block(false_block)
        
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should generate cmp and conditional jump
        assert "cmp" in code.lower()
        assert "jne" in code.lower() or "je" in code.lower()
        assert "true_branch:" in code.lower()
        assert "false_branch:" in code.lower()


class TestComplexExpressions:
    """Test code generation for complex expressions."""
    
    def test_arithmetic_expression(self):
        """Test complex arithmetic expression: (a + b) * (c - d)"""
        module = IRModule("test")
        func = IRFunction("test_expr", int_type())
        
        entry = BasicBlock(Label("entry"))
        a = VirtualRegister("%a", int_type())
        b = VirtualRegister("%b", int_type())
        c = VirtualRegister("%c", int_type())
        d = VirtualRegister("%d", int_type())
        
        temp1 = VirtualRegister("%temp1", int_type())
        temp2 = VirtualRegister("%temp2", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, temp1, [a, b]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.SUB, temp2, [c, d]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.MUL, result, [temp1, temp2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should contain all operations
        assert "add" in code.lower()
        assert "sub" in code.lower()
        assert "imul" in code.lower()

    def test_mixed_operations(self):
        """Test mixed arithmetic and logical operations."""
        module = IRModule("test")
        func = IRFunction("test_mixed", int_type())
        
        entry = BasicBlock(Label("entry"))
        x = VirtualRegister("%x", int_type())
        y = VirtualRegister("%y", int_type())
        
        temp1 = VirtualRegister("%temp1", int_type())
        temp2 = VirtualRegister("%temp2", int_type())
        result = VirtualRegister("%result", int_type())
        
        # (x + 5) & (y << 2)
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, temp1, [x, Constant(value=5, value_type=int_type())]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.SHL, temp2, [y, Constant(value=2, value_type=int_type())]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.AND, result, [temp1, temp2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "add" in code.lower()
        assert "shl" in code.lower()
        assert "and" in code.lower()


class TestFunctionGeneration:
    """Test complete function generation."""
    
    def test_simple_function(self):
        """Test generation of a simple function."""
        module = IRModule("test")
        func = IRFunction("add_numbers", int_type())
        
        p1 = VirtualRegister("%p1", int_type())
        p2 = VirtualRegister("%p2", int_type())
        func.add_parameter(p1)
        func.add_parameter(p2)
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [p1, p2]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Check function structure
        # Intel syntax uses __TEXT,__text on macOS, AT&T uses .text
        assert ".text" in code.lower() or "__text" in code.lower()
        # On macOS with Intel syntax, functions get _ prefix
        assert ".globl" in code and ("add_numbers" in code or "_add_numbers" in code)
        assert "add_numbers:" in code or "_add_numbers:" in code
        assert "push" in code.lower() and has_register(code, "rbp")
        assert "ret" in code.lower()

    def test_multiple_functions(self):
        """Test generation of multiple functions."""
        module = IRModule("test")
        
        # First function
        func1 = IRFunction("func1", int_type())
        entry1 = BasicBlock(Label("entry"))
        entry1.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=1, value_type=int_type())]
        ))
        func1.add_basic_block(entry1)
        module.add_function(func1)
        
        # Second function
        func2 = IRFunction("func2", int_type())
        entry2 = BasicBlock(Label("entry"))
        entry2.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=2, value_type=int_type())]
        ))
        func2.add_basic_block(entry2)
        module.add_function(func2)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Both functions should be present (with or without _ prefix)
        assert "func1:" in code or "_func1:" in code
        assert "func2:" in code or "_func2:" in code
        assert ".globl" in code and ("func1" in code or "_func1" in code)
        assert ".globl" in code and ("func2" in code or "_func2" in code)
    
    def test_function_with_multiple_blocks(self):
        """Test function with multiple basic blocks."""
        module = IRModule("test")
        func = IRFunction("test_blocks", int_type())
        
        entry = BasicBlock(Label("entry"))
        block1 = BasicBlock(Label("block1"))
        block2 = BasicBlock(Label("block2"))
        
        cond = VirtualRegister("%cond", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.COND_BR, None, [cond, Label("block1"), Label("block2")]
        ))
        
        block1.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=10, value_type=int_type())]
        ))
        
        block2.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=20, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        func.add_basic_block(block1)
        func.add_basic_block(block2)
        
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # All blocks should be present
        assert "entry:" in code.lower()
        assert "block1:" in code.lower()
        assert "block2:" in code.lower()


class TestEdgeCases:
    """Test edge cases and special scenarios."""
    
    def test_empty_function(self):
        """Test generation of function with only return."""
        module = IRModule("test")
        func = IRFunction("empty_func", void_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, []
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "empty_func:" in code
        assert "ret" in code.lower()

    def test_constant_operands(self):
        """Test operations with constant operands."""
        module = IRModule("test")
        func = IRFunction("test_const", int_type())
        
        entry = BasicBlock(Label("entry"))
        v1 = VirtualRegister("%v1", int_type())
        result = VirtualRegister("%result", int_type())
        
        # Create constant with integer value, not type
        const_val = Constant(value=20, value_type=int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [v1, const_val]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        # Should handle immediate values
        assert "$20" in code or "20" in code
    
    def test_negation_operation(self):
        """Test NEG unary operation."""
        module = IRModule("test")
        func = IRFunction("test_neg", int_type())
        
        entry = BasicBlock(Label("entry"))
        x = VirtualRegister("%x", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.NEG, result, [x]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "neg" in code.lower()
    
    def test_not_operation(self):
        """Test NOT unary operation."""
        module = IRModule("test")
        func = IRFunction("test_not", int_type())
        
        entry = BasicBlock(Label("entry"))
        x = VirtualRegister("%x", int_type())
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.NOT, result, [x]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        codegen = X86CodeGenerator(module)
        code = codegen.generate()
        
        assert "not" in code.lower()


class TestATTSyntax:
    """Test AT&T syntax formatting."""
    
    def test_att_register_format(self):
        """Test that registers use % prefix in AT&T syntax."""
        module = IRModule("test")
        func = IRFunction("test_att", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Explicitly use AT&T syntax
        codegen = X86CodeGenerator(module, syntax='att')
        code = codegen.generate()
        
        # AT&T syntax uses % for registers
        assert "%r" in code.lower()
        # Should not have Intel syntax directive
        assert ".intel_syntax" not in code
    
    def test_att_immediate_format(self):
        """Test that immediates use $ prefix in AT&T syntax."""
        module = IRModule("test")
        func = IRFunction("test_imm", int_type())
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [Constant(value=42, value_type=int_type()), Constant(value=1, value_type=int_type())]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Explicitly use AT&T syntax
        codegen = X86CodeGenerator(module, syntax='att')
        code = codegen.generate()
        
        # AT&T syntax uses $ for immediates
        assert "$" in code
        # Should not have Intel syntax directive
        assert ".intel_syntax" not in code


class TestIntelSyntax:
    """Test Intel syntax formatting."""
    
    def test_intel_register_format(self):
        """Test that registers don't use % prefix in Intel syntax."""
        module = IRModule("test")
        func = IRFunction("test_intel", int_type())
        
        entry = BasicBlock(Label("entry"))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Explicitly use Intel syntax
        codegen = X86CodeGenerator(module, syntax='intel')
        code = codegen.generate()
        
        # Intel syntax should have the directive
        assert ".intel_syntax" in code
        # Intel syntax doesn't use % for registers
        # Check that we have register names without %
        assert "rax" in code.lower() or "rbp" in code.lower() or "rsp" in code.lower()
    
    def test_intel_immediate_format(self):
        """Test that immediates don't use $ prefix in Intel syntax."""
        module = IRModule("test")
        func = IRFunction("test_imm", int_type())
        
        entry = BasicBlock(Label("entry"))
        result = VirtualRegister("%result", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ADD, result, [Constant(value=42, value_type=int_type()), Constant(value=1, value_type=int_type())]
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [result]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Explicitly use Intel syntax
        codegen = X86CodeGenerator(module, syntax='intel')
        code = codegen.generate()
        
        # Intel syntax should have the directive
        assert ".intel_syntax" in code
        # Intel syntax doesn't use $ for immediates
        # The immediate values should appear without $
        assert "42" in code or "1" in code
        # Make sure we don't have AT&T style $42
        assert "$42" not in code
    
    def test_intel_memory_operand_format(self):
        """Test Intel syntax memory operand formatting."""
        module = IRModule("test")
        func = IRFunction("test_mem", int_type())
        
        entry = BasicBlock(Label("entry"))
        ptr = VirtualRegister("%ptr", int_type())
        
        entry.add_instruction(IRInstruction(
            IROpcode.ALLOCA, ptr, []
        ))
        entry.add_instruction(IRInstruction(
            IROpcode.RET, None, [Constant(value=0, value_type=int_type())]
        ))
        
        func.add_basic_block(entry)
        module.add_function(func)
        
        # Explicitly use Intel syntax
        codegen = X86CodeGenerator(module, syntax='intel')
        code = codegen.generate()
        
        # Intel syntax should have the directive
        assert ".intel_syntax" in code
        # Intel syntax uses [base+offset] format
        assert "[" in code and "]" in code
