"""Unit tests for control flow statements (switch, break, continue, goto, labels)."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.utils.error_reporter import ErrorReporter


def parse_and_analyze(code: str):
    """Helper to parse and analyze code."""
    tokenizer = Tokenizer(code, filename="test.c")
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    analyzer.analyze()
    
    return ast, error_reporter


def parse_analyze_and_generate_ir(code: str):
    """Helper to parse, analyze, and generate IR."""
    ast, error_reporter = parse_and_analyze(code)
    
    if error_reporter.has_errors():
        return ast, error_reporter, None
    
    ir_gen = IRGenerator(ast, error_reporter)
    ir_module = ir_gen.generate()
    
    return ast, error_reporter, ir_module


class TestSwitchStatements:
    """Tests for switch statements."""
    
    def test_simple_switch(self):
        """Test simple switch statement."""
        code = """
        int test(int x) {
            switch (x) {
                case 1:
                    return 10;
                case 2:
                    return 20;
                default:
                    return 0;
            }
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_switch_with_fallthrough(self):
        """Test switch with fall-through behavior."""
        code = """
        int test(int x) {
            int result = 0;
            switch (x) {
                case 1:
                    result = 10;
                case 2:
                    result = result + 20;
                    break;
                case 3:
                    result = 30;
                    break;
            }
            return result;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_switch_without_default(self):
        """Test switch without default case."""
        code = """
        int test(int x) {
            switch (x) {
                case 1:
                    return 10;
                case 2:
                    return 20;
            }
            return 0;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_nested_switch(self):
        """Test nested switch statements."""
        code = """
        int test(int x, int y) {
            switch (x) {
                case 1:
                    switch (y) {
                        case 10:
                            return 100;
                        case 20:
                            return 200;
                    }
                    break;
                case 2:
                    return 2;
            }
            return 0;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_switch_non_integer_error(self):
        """Test that switch with non-integer condition produces error."""
        code = """
        int test(float x) {
            switch (x) {
                case 1:
                    return 10;
            }
            return 0;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()
    
    def test_case_outside_switch_error(self):
        """Test that case outside switch produces error."""
        code = """
        int test(int x) {
            case 1:
                return 10;
            return 0;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()


class TestBreakContinue:
    """Tests for break and continue statements."""
    
    def test_break_in_while(self):
        """Test break in while loop."""
        code = """
        int test(int n) {
            int i = 0;
            while (i < n) {
                if (i == 5) {
                    break;
                }
                i = i + 1;
            }
            return i;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_continue_in_for(self):
        """Test continue in for loop."""
        code = """
        int test(int n) {
            int sum = 0;
            int i;
            for (i = 0; i < n; i = i + 1) {
                if (i == 5) {
                    continue;
                }
                sum = sum + i;
            }
            return sum;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_break_in_switch(self):
        """Test break in switch statement."""
        code = """
        int test(int x) {
            switch (x) {
                case 1:
                    break;
                case 2:
                    return 20;
            }
            return 0;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_break_outside_loop_error(self):
        """Test that break outside loop/switch produces error."""
        code = """
        int test(int x) {
            break;
            return 0;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()
    
    def test_continue_outside_loop_error(self):
        """Test that continue outside loop produces error."""
        code = """
        int test(int x) {
            continue;
            return 0;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()
    
    def test_nested_loops_with_break(self):
        """Test break in nested loops."""
        code = """
        int test(int n) {
            int i = 0;
            int j;
            while (i < n) {
                j = 0;
                while (j < n) {
                    if (j == 3) {
                        break;
                    }
                    j = j + 1;
                }
                i = i + 1;
            }
            return i;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None


class TestGotoLabels:
    """Tests for goto and label statements."""
    
    def test_simple_goto(self):
        """Test simple goto statement."""
        code = """
        int test(int x) {
            if (x > 0) {
                goto positive;
            }
            return -1;
        positive:
            return 1;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_forward_goto(self):
        """Test forward goto."""
        code = """
        int test(int x) {
            goto end;
            x = x + 1;
        end:
            return x;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_backward_goto(self):
        """Test backward goto (loop)."""
        code = """
        int test(int n) {
            int i = 0;
        loop:
            if (i >= n) {
                goto end;
            }
            i = i + 1;
            goto loop;
        end:
            return i;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_multiple_labels(self):
        """Test multiple labels."""
        code = """
        int test(int x) {
            if (x == 1) goto label1;
            if (x == 2) goto label2;
            if (x == 3) goto label3;
            return 0;
        label1:
            return 1;
        label2:
            return 2;
        label3:
            return 3;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_undefined_label_error(self):
        """Test that goto to undefined label produces error."""
        code = """
        int test(int x) {
            goto undefined_label;
            return 0;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()
    
    def test_duplicate_label_error(self):
        """Test that duplicate labels produce error."""
        code = """
        int test(int x) {
        label:
            x = x + 1;
        label:
            return x;
        }
        """
        ast, error_reporter = parse_and_analyze(code)
        assert error_reporter.has_errors()
    
    def test_label_in_nested_scope(self):
        """Test labels in nested scopes."""
        code = """
        int test(int x) {
            if (x > 0) {
            inner_label:
                x = x - 1;
            }
            goto inner_label;
            return x;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        # Labels have function scope, so this should work
        assert not error_reporter.has_errors()
        assert ir_module is not None


class TestNestedControlFlow:
    """Tests for nested control flow statements."""
    
    def test_switch_in_loop(self):
        """Test switch inside loop."""
        code = """
        int test(int n) {
            int i;
            int sum = 0;
            for (i = 0; i < n; i = i + 1) {
                switch (i) {
                    case 0:
                        sum = sum + 1;
                        break;
                    case 1:
                        sum = sum + 2;
                        break;
                    default:
                        sum = sum + i;
                        break;
                }
            }
            return sum;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_loop_in_switch(self):
        """Test loop inside switch."""
        code = """
        int test(int x) {
            int sum = 0;
            switch (x) {
                case 1:
                    {
                        int i;
                        for (i = 0; i < 10; i = i + 1) {
                            sum = sum + i;
                        }
                    }
                    break;
                case 2:
                    {
                        int i = 0;
                        while (i < 5) {
                            sum = sum + i;
                            i = i + 1;
                        }
                    }
                    break;
            }
            return sum;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_goto_across_switch(self):
        """Test goto jumping into/out of switch."""
        code = """
        int test(int x) {
            if (x < 0) {
                goto skip_switch;
            }
            switch (x) {
                case 1:
                    goto after_switch;
                case 2:
                    return 2;
            }
        skip_switch:
            x = 0;
        after_switch:
            return x;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_complex_nested_control_flow(self):
        """Test complex nested control flow."""
        code = """
        int test(int x, int y) {
            int result = 0;
            int i;
            
            for (i = 0; i < x; i = i + 1) {
                switch (y) {
                    case 1:
                        if (i > 5) {
                            goto early_exit;
                        }
                        result = result + i;
                        break;
                    case 2:
                        {
                            int j = 0;
                            while (j < i) {
                                result = result + 1;
                                j = j + 1;
                                if (j == 3) {
                                    continue;
                                }
                            }
                        }
                        break;
                    default:
                        if (i == 10) {
                            break;
                        }
                        result = result + 2;
                        break;
                }
            }
            
        early_exit:
            return result;
        }
        """
        ast, error_reporter, ir_module = parse_analyze_and_generate_ir(code)
        assert not error_reporter.has_errors()
        assert ir_module is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
