"""Tests for array indexing in semantic analyzer."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.utils.error_reporter import ErrorReporter


def analyze_code(code: str):
    """Helper to parse and analyze code.
    
    Returns:
        tuple: (success, error_reporter)
    """
    tokenizer = Tokenizer(code, "test.c")
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    analyzer.analyze()
    
    return not error_reporter.has_errors(), error_reporter


class TestBasicArrayIndexing:
    """Test basic array indexing."""
    
    def test_simple_array_indexing(self):
        """Test simple array indexing: arr[5]."""
        code = "int main() { int arr[10]; int x; x = arr[5]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Simple array indexing should succeed"
    
    def test_array_indexing_with_variable(self):
        """Test array indexing with variable: arr[i]."""
        code = "int main() { int arr[10]; int i; i = 5; int x; x = arr[i]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Array indexing with variable should succeed"
    
    def test_array_indexing_first_element(self):
        """Test indexing first element: arr[0]."""
        code = "int main() { int arr[10]; int x; x = arr[0]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Indexing first element should succeed"
    
    def test_array_indexing_in_expression(self):
        """Test array indexing in expression: arr[i] + 1."""
        code = "int main() { int arr[10]; int i; i = 5; int x; x = arr[i] + 1; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Array indexing in expression should succeed"
    
    def test_array_indexing_assignment(self):
        """Test assigning to array element: arr[i] = 5."""
        code = "int main() { int arr[10]; int i; i = 5; arr[i] = 42; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Assigning to array element should succeed"


class TestMultiDimensionalArrayIndexing:
    """Test multi-dimensional array indexing."""
    
    def test_2d_array_indexing(self):
        """Test 2D array indexing: matrix[i][j]."""
        code = "int main() { int matrix[5][10]; int x; x = matrix[2][3]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "2D array indexing should succeed"
    
    def test_2d_array_with_variables(self):
        """Test 2D array indexing with variables."""
        code = "int main() { int matrix[5][10]; int i; int j; i = 2; j = 3; int x; x = matrix[i][j]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "2D array indexing with variables should succeed"
    
    def test_2d_array_assignment(self):
        """Test assigning to 2D array element."""
        code = "int main() { int matrix[5][10]; matrix[2][3] = 42; return 0; }"
        success, _ = analyze_code(code)
        assert success, "2D array assignment should succeed"
    
    def test_3d_array_indexing(self):
        """Test 3D array indexing: cube[i][j][k]."""
        code = "int main() { int cube[2][3][4]; int x; x = cube[1][2][3]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "3D array indexing should succeed"


class TestArrayIndexingWithDifferentTypes:
    """Test array indexing with different element types."""
    
    def test_char_array_indexing(self):
        """Test char array indexing."""
        code = "int main() { char arr[10]; char c; c = arr[5]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Char array indexing should succeed"
    
    def test_float_array_indexing(self):
        """Test float array indexing."""
        code = "int main() { float arr[10]; float f; f = arr[5]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Float array indexing should succeed"
    
    def test_double_array_indexing(self):
        """Test double array indexing."""
        code = "int main() { double arr[10]; double d; d = arr[5]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Double array indexing should succeed"


class TestArrayIndexingWithExpressions:
    """Test array indexing with complex index expressions."""
    
    def test_indexing_with_arithmetic(self):
        """Test indexing with arithmetic: arr[i+1]."""
        code = "int main() { int arr[10]; int i; i = 5; int x; x = arr[i+1]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Indexing with arithmetic should succeed"
    
    def test_indexing_with_multiplication(self):
        """Test indexing with multiplication: arr[i*2]."""
        code = "int main() { int arr[10]; int i; i = 2; int x; x = arr[i*2]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Indexing with multiplication should succeed"
    
    def test_indexing_with_complex_expression(self):
        """Test indexing with complex expression."""
        code = "int main() { int arr[10]; int i; int j; i = 2; j = 3; int x; x = arr[i+j-1]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Indexing with complex expression should succeed"


class TestArrayIndexingErrors:
    """Test error detection in array indexing."""
    
    def test_indexing_non_array(self):
        """Test error when indexing non-array."""
        code = "int main() { int x; x = 5; int y; y = x[0]; return 0; }"
        success, error_reporter = analyze_code(code)
        assert not success, "Indexing non-array should fail"
        assert any("not an array" in diag.message.lower() 
                  for diag in error_reporter.diagnostics if diag.is_error)
    
    def test_non_integer_index(self):
        """Test error when index is not integer."""
        code = "int main() { int arr[10]; float f; f = 1.5; int x; x = arr[f]; return 0; }"
        success, error_reporter = analyze_code(code)
        assert not success, "Non-integer index should fail"
        assert any("integer" in diag.message.lower() 
                  for diag in error_reporter.diagnostics if diag.is_error)
    
    def test_indexing_undeclared_array(self):
        """Test error when array is undeclared."""
        code = "int main() { int x; x = arr[0]; return 0; }"
        success, error_reporter = analyze_code(code)
        assert not success, "Indexing undeclared array should fail"


class TestArrayIndexingInLoops:
    """Test array indexing in loops."""
    
    def test_array_in_for_loop(self):
        """Test array indexing in for loop."""
        code = """
        int main() {
            int arr[10];
            int i;
            int sum;
            sum = 0;
            for (i = 0; i < 10; i = i + 1) {
                sum = sum + arr[i];
            }
            return sum;
        }
        """
        success, _ = analyze_code(code)
        assert success, "Array indexing in for loop should succeed"
    
    def test_array_in_while_loop(self):
        """Test array indexing in while loop."""
        code = """
        int main() {
            int arr[10];
            int i;
            int sum;
            i = 0;
            sum = 0;
            while (i < 10) {
                sum = sum + arr[i];
                i = i + 1;
            }
            return sum;
        }
        """
        success, _ = analyze_code(code)
        assert success, "Array indexing in while loop should succeed"


class TestArrayIndexingWithFunctions:
    """Test array indexing with function calls."""
    
    def test_array_element_as_argument(self):
        """Test passing array element to function."""
        code = """
        int func(int x) {
            return x + 1;
        }
        
        int main() {
            int arr[10];
            int result;
            result = func(arr[5]);
            return result;
        }
        """
        success, _ = analyze_code(code)
        assert success, "Passing array element to function should succeed"
    
    def test_function_return_as_index(self):
        """Test using function return as index."""
        code = """
        int get_index() {
            return 5;
        }
        
        int main() {
            int arr[10];
            int x;
            x = arr[get_index()];
            return x;
        }
        """
        success, _ = analyze_code(code)
        assert success, "Using function return as index should succeed"


class TestArrayIndexingEdgeCases:
    """Test edge cases in array indexing."""
    
    def test_nested_array_indexing(self):
        """Test nested array indexing: arr[arr[i]]."""
        code = "int main() { int arr[10]; int i; i = 5; int x; x = arr[arr[i]]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Nested array indexing should succeed"
    
    def test_array_indexing_in_condition(self):
        """Test array indexing in condition."""
        code = """
        int main() {
            int arr[10];
            if (arr[5] > 0) {
                return 1;
            }
            return 0;
        }
        """
        success, _ = analyze_code(code)
        assert success, "Array indexing in condition should succeed"
    
    def test_array_indexing_in_return(self):
        """Test array indexing in return statement."""
        code = "int main() { int arr[10]; return arr[5]; }"
        success, _ = analyze_code(code)
        assert success, "Array indexing in return should succeed"
    
    def test_multiple_array_indexing(self):
        """Test multiple array indexing in one expression."""
        code = "int main() { int arr1[10]; int arr2[10]; int x; x = arr1[5] + arr2[3]; return 0; }"
        success, _ = analyze_code(code)
        assert success, "Multiple array indexing should succeed"


class TestArrayIndexingWithPointers:
    """Test array indexing with pointers."""
    
    def test_pointer_indexing(self):
        """Test pointer indexing: ptr[i]."""
        code = """
        int main() {
            int arr[10];
            int *ptr;
            ptr = arr;
            int x;
            x = ptr[5];
            return 0;
        }
        """
        success, _ = analyze_code(code)
        # This might fail if pointer assignment isn't fully implemented
        # assert success, "Pointer indexing should succeed"
    
    def test_array_decay_to_pointer(self):
        """Test that arrays decay to pointers in expressions."""
        code = """
        int main() {
            int arr[10];
            int *ptr;
            ptr = arr;
            return 0;
        }
        """
        success, _ = analyze_code(code)
        # This might fail if array-to-pointer decay isn't fully implemented
        # assert success, "Array decay to pointer should succeed"
