"""Tests for ArrayType in the type system."""

import pytest
from src.parser.ast_nodes import ArrayType, PrimitiveType, PointerType
from src.semantic.type_utils import (
    is_array_type, get_array_element_type, get_array_base_type,
    get_array_dimensions, array_to_pointer_decay, is_complete_array_type,
    is_incomplete_array_type, can_assign_array_types, types_equal
)
from src.utils.source_location import SourceLocation


@pytest.fixture
def location():
    """Create a test source location."""
    return SourceLocation("test.c", 1, 1)


@pytest.fixture
def int_type(location):
    """Create an int type."""
    return PrimitiveType(location=location, name='int', is_signed=True)


@pytest.fixture
def char_type(location):
    """Create a char type."""
    return PrimitiveType(location=location, name='char', is_signed=True)


class TestArrayTypeBasics:
    """Test basic ArrayType functionality."""
    
    def test_create_fixed_size_array(self, location, int_type):
        """Test creating a fixed-size array."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        assert array.element_type == int_type
        assert array.size_value == 10
        assert array.is_complete()
        assert not array.is_vla
    
    def test_create_incomplete_array(self, location, int_type):
        """Test creating an incomplete array (no size)."""
        array = ArrayType(location=location, element_type=int_type)
        assert array.element_type == int_type
        assert array.size is None
        assert array.size_value is None
        assert not array.is_complete()
    
    def test_create_vla(self, location, int_type):
        """Test creating a variable-length array."""
        array = ArrayType(location=location, element_type=int_type, is_vla=True)
        assert array.is_vla
        assert array.element_type == int_type
    
    def test_is_array_type(self, location, int_type):
        """Test is_array_type utility."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        assert is_array_type(array)
        assert not is_array_type(int_type)


class TestMultiDimensionalArrays:
    """Test multi-dimensional array support."""
    
    def test_create_2d_array(self, location, int_type):
        """Test creating a 2D array: int[5][10]."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        assert outer_array.size_value == 5
        assert isinstance(outer_array.element_type, ArrayType)
        assert outer_array.element_type.size_value == 10
    
    def test_get_array_base_type(self, location, int_type):
        """Test getting base type of multi-dimensional array."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        base_type = get_array_base_type(outer_array)
        assert base_type == int_type
    
    def test_get_array_dimensions(self, location, int_type):
        """Test getting dimensions of multi-dimensional array."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        dimensions = get_array_dimensions(outer_array)
        assert dimensions == [5, 10]
    
    def test_get_total_size_2d(self, location, int_type):
        """Test getting total size of 2D array."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        total_size = outer_array.get_total_size()
        assert total_size == 50  # 5 * 10
    
    def test_create_3d_array(self, location, int_type):
        """Test creating a 3D array: int[2][3][4]."""
        inner = ArrayType(location=location, element_type=int_type, size_value=4)
        middle = ArrayType(location=location, element_type=inner, size_value=3)
        outer = ArrayType(location=location, element_type=middle, size_value=2)
        
        dimensions = get_array_dimensions(outer)
        assert dimensions == [2, 3, 4]
        assert outer.get_total_size() == 24  # 2 * 3 * 4


class TestArrayToPointerDecay:
    """Test array-to-pointer decay."""
    
    def test_simple_array_decay(self, location, int_type):
        """Test decaying int[10] to int*."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        pointer = array_to_pointer_decay(array)
        
        assert isinstance(pointer, PointerType)
        assert pointer.pointee_type == int_type
    
    def test_2d_array_decay(self, location, int_type):
        """Test decaying int[5][10] to int(*)[10]."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        pointer = array_to_pointer_decay(outer_array)
        
        assert isinstance(pointer, PointerType)
        assert isinstance(pointer.pointee_type, ArrayType)
        assert pointer.pointee_type.size_value == 10
    
    def test_char_array_decay(self, location, char_type):
        """Test decaying char[] to char*."""
        array = ArrayType(location=location, element_type=char_type)
        pointer = array_to_pointer_decay(array)
        
        assert isinstance(pointer, PointerType)
        assert pointer.pointee_type == char_type


class TestArrayTypeCompletion:
    """Test array type completion checks."""
    
    def test_complete_array(self, location, int_type):
        """Test that sized array is complete."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        assert is_complete_array_type(array)
        assert not is_incomplete_array_type(array)
    
    def test_incomplete_array(self, location, int_type):
        """Test that unsized array is incomplete."""
        array = ArrayType(location=location, element_type=int_type)
        assert is_incomplete_array_type(array)
        assert not is_complete_array_type(array)
    
    def test_vla_is_complete(self, location, int_type):
        """Test that VLA is considered complete (has size at runtime)."""
        array = ArrayType(location=location, element_type=int_type, is_vla=True, size_value=None)
        # VLA without size_value is incomplete at compile time
        assert is_incomplete_array_type(array)


class TestArrayTypeCompatibility:
    """Test array type compatibility."""
    
    def test_same_size_arrays_compatible(self, location, int_type):
        """Test that arrays of same size are compatible."""
        array1 = ArrayType(location=location, element_type=int_type, size_value=10)
        array2 = ArrayType(location=location, element_type=int_type, size_value=10)
        
        assert can_assign_array_types(array1, array2)
    
    def test_different_size_arrays_incompatible(self, location, int_type):
        """Test that arrays of different sizes are incompatible."""
        array1 = ArrayType(location=location, element_type=int_type, size_value=10)
        array2 = ArrayType(location=location, element_type=int_type, size_value=20)
        
        assert not can_assign_array_types(array1, array2)
    
    def test_incomplete_array_accepts_any_size(self, location, int_type):
        """Test that incomplete array can accept any size."""
        incomplete = ArrayType(location=location, element_type=int_type)
        complete = ArrayType(location=location, element_type=int_type, size_value=10)
        
        assert can_assign_array_types(incomplete, complete)
    
    def test_different_element_types_incompatible(self, location, int_type, char_type):
        """Test that arrays of different element types are incompatible."""
        int_array = ArrayType(location=location, element_type=int_type, size_value=10)
        char_array = ArrayType(location=location, element_type=char_type, size_value=10)
        
        assert not can_assign_array_types(int_array, char_array)
    
    def test_array_type_equality(self, location, int_type):
        """Test array type equality."""
        array1 = ArrayType(location=location, element_type=int_type, size_value=10)
        array2 = ArrayType(location=location, element_type=int_type, size_value=10)
        array3 = ArrayType(location=location, element_type=int_type, size_value=20)
        
        # Arrays are equal if element types match (size not checked in types_equal)
        assert types_equal(array1, array2)
        assert types_equal(array1, array3)  # Size difference doesn't affect type equality


class TestArrayElementAccess:
    """Test array element type access."""
    
    def test_get_element_type_1d(self, location, int_type):
        """Test getting element type of 1D array."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        element_type = get_array_element_type(array)
        
        assert element_type == int_type
    
    def test_get_element_type_2d(self, location, int_type):
        """Test getting element type of 2D array."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array, size_value=5)
        
        element_type = get_array_element_type(outer_array)
        
        assert isinstance(element_type, ArrayType)
        assert element_type.size_value == 10
    
    def test_get_base_type_1d(self, location, int_type):
        """Test getting base type of 1D array."""
        array = ArrayType(location=location, element_type=int_type, size_value=10)
        base_type = get_array_base_type(array)
        
        assert base_type == int_type
    
    def test_get_base_type_3d(self, location, int_type):
        """Test getting base type of 3D array."""
        inner = ArrayType(location=location, element_type=int_type, size_value=4)
        middle = ArrayType(location=location, element_type=inner, size_value=3)
        outer = ArrayType(location=location, element_type=middle, size_value=2)
        
        base_type = get_array_base_type(outer)
        
        assert base_type == int_type


class TestArrayEdgeCases:
    """Test edge cases for arrays."""
    
    def test_array_of_pointers(self, location, int_type):
        """Test array of pointers: int*[10]."""
        pointer_type = PointerType(location=location, pointee_type=int_type, qualifiers=())
        array = ArrayType(location=location, element_type=pointer_type, size_value=10)
        
        assert isinstance(array.element_type, PointerType)
        assert array.size_value == 10
    
    def test_incomplete_multidimensional_array(self, location, int_type):
        """Test incomplete multi-dimensional array: int[][10]."""
        inner_array = ArrayType(location=location, element_type=int_type, size_value=10)
        outer_array = ArrayType(location=location, element_type=inner_array)
        
        assert is_incomplete_array_type(outer_array)
        assert is_complete_array_type(inner_array)
    
    def test_zero_size_array(self, location, int_type):
        """Test zero-size array (allowed in some contexts)."""
        array = ArrayType(location=location, element_type=int_type, size_value=0)
        
        assert array.size_value == 0
        assert array.is_complete()
        assert array.get_total_size() == 0
