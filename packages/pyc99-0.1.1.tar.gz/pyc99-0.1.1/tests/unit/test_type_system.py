"""Unit tests for the type system (qualifiers, storage classes, conversions)."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import *
from src.semantic.analyzer import SemanticAnalyzer
from src.semantic.type_utils import (
    integer_promotion, usual_arithmetic_conversions, is_compatible_type,
    can_convert_implicitly, pointer_conversion
)
from src.utils.error_reporter import ErrorReporter
from src.utils.source_location import SourceLocation


def parse_and_analyze(source: str):
    """Helper function to parse and analyze source code.
    
    Args:
        source: C source code to parse and analyze
        
    Returns:
        Tuple of (ast, error_reporter)
    """
    tokenizer = Tokenizer(source)
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    analyzer.analyze()
    
    return ast, error_reporter


class TestTypeQualifiers:
    """Test type qualifier parsing and semantics."""
    
    def test_const_variable_declaration(self):
        """Test const variable declaration."""
        source = "const int x = 5;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        # Check that variable has const qualifier
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert TypeQualifier.CONST in var_decl.qualifiers
    
    def test_volatile_variable_declaration(self):
        """Test volatile variable declaration."""
        source = "volatile int x;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert TypeQualifier.VOLATILE in var_decl.qualifiers
    
    def test_restrict_pointer_declaration(self):
        """Test restrict pointer declaration."""
        source = "int * restrict ptr;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        # Restrict applies to pointer type
        assert isinstance(var_decl.var_type, PointerType)
    
    def test_const_volatile_combination(self):
        """Test combining const and volatile qualifiers."""
        source = "const volatile int x;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert TypeQualifier.CONST in var_decl.qualifiers
        assert TypeQualifier.VOLATILE in var_decl.qualifiers
    
    def test_const_pointer_to_const(self):
        """Test const pointer to const data."""
        source = "const int * const ptr;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert isinstance(var_decl.var_type, PointerType)


class TestStorageClassSpecifiers:
    """Test storage class specifier parsing and semantics."""
    
    def test_static_variable_declaration(self):
        """Test static variable declaration."""
        source = "static int x = 5;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert var_decl.storage_class == StorageClass.STATIC
    
    def test_extern_variable_declaration(self):
        """Test extern variable declaration."""
        source = "extern int x;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        var_decl = ast.declarations[0]
        assert isinstance(var_decl, VarDecl)
        assert var_decl.storage_class == StorageClass.EXTERN
    
    def test_static_function_declaration(self):
        """Test static function declaration."""
        source = "static int foo(void);"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        func_decl = ast.declarations[0]
        assert isinstance(func_decl, FunctionDecl)
        assert func_decl.storage_class == StorageClass.STATIC
    
    def test_extern_function_declaration(self):
        """Test extern function declaration."""
        source = "extern int foo(void);"
        ast, error_reporter = parse_and_analyze(source)
        
        assert not error_reporter.has_errors()
        func_decl = ast.declarations[0]
        assert isinstance(func_decl, FunctionDecl)
        assert func_decl.storage_class == StorageClass.EXTERN
    
    def test_auto_at_file_scope_error(self):
        """Test that auto storage class is not allowed at file scope."""
        source = "auto int x;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert error_reporter.has_errors()
    
    def test_register_at_file_scope_error(self):
        """Test that register storage class is not allowed at file scope."""
        source = "register int x;"
        ast, error_reporter = parse_and_analyze(source)
        
        assert error_reporter.has_errors()
    
    def test_auto_storage_class_for_function_error(self):
        """Test that auto storage class is not allowed for functions."""
        source = "auto int foo(void);"
        ast, error_reporter = parse_and_analyze(source)
        
        assert error_reporter.has_errors()
    
    def test_register_storage_class_for_function_error(self):
        """Test that register storage class is not allowed for functions."""
        source = "register int foo(void);"
        ast, error_reporter = parse_and_analyze(source)
        
        assert error_reporter.has_errors()


class TestTypeCompatibility:
    """Test type compatibility rules."""
    
    def test_same_primitive_types_compatible(self):
        """Test that same primitive types are compatible."""
        loc = SourceLocation("test.c", 1, 1)
        type1 = PrimitiveType(loc, "int", True, None)
        type2 = PrimitiveType(loc, "int", True, None)
        
        assert is_compatible_type(type1, type2)
    
    def test_different_primitive_types_incompatible(self):
        """Test that different primitive types are incompatible."""
        loc = SourceLocation("test.c", 1, 1)
        type1 = PrimitiveType(loc, "int", True, None)
        type2 = PrimitiveType(loc, "float", True, None)
        
        assert not is_compatible_type(type1, type2)
    
    def test_signed_unsigned_incompatible(self):
        """Test that signed and unsigned are incompatible."""
        loc = SourceLocation("test.c", 1, 1)
        type1 = PrimitiveType(loc, "int", True, None)
        type2 = PrimitiveType(loc, "int", False, None)
        
        assert not is_compatible_type(type1, type2)
    
    def test_pointer_types_compatible(self):
        """Test that pointers to compatible types are compatible."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        type1 = PointerType(loc, int_type, ())
        type2 = PointerType(loc, int_type, ())
        
        assert is_compatible_type(type1, type2)
    
    def test_array_types_compatible(self):
        """Test that arrays of compatible types are compatible."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        type1 = ArrayType(loc, int_type, None, False, 10)
        type2 = ArrayType(loc, int_type, None, False, 20)
        
        # Arrays are compatible if element types are compatible
        assert is_compatible_type(type1, type2)


class TestIntegerPromotion:
    """Test integer promotion rules."""
    
    def test_char_promoted_to_int(self):
        """Test that char is promoted to int."""
        loc = SourceLocation("test.c", 1, 1)
        char_type = PrimitiveType(loc, "char", True, None)
        promoted = integer_promotion(char_type)
        
        assert isinstance(promoted, PrimitiveType)
        assert promoted.name == "int"
    
    def test_short_promoted_to_int(self):
        """Test that short is promoted to int."""
        loc = SourceLocation("test.c", 1, 1)
        short_type = PrimitiveType(loc, "short", True, None)
        promoted = integer_promotion(short_type)
        
        assert isinstance(promoted, PrimitiveType)
        assert promoted.name == "int"
    
    def test_int_not_promoted(self):
        """Test that int is not promoted."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        promoted = integer_promotion(int_type)
        
        assert promoted is int_type


class TestUsualArithmeticConversions:
    """Test usual arithmetic conversion rules."""
    
    def test_int_int_returns_int(self):
        """Test that int + int returns int."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        result = usual_arithmetic_conversions(int_type, int_type)
        
        assert isinstance(result, PrimitiveType)
        assert result.name == "int"
    
    def test_int_float_returns_float(self):
        """Test that int + float returns float."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        float_type = PrimitiveType(loc, "float", True, None)
        result = usual_arithmetic_conversions(int_type, float_type)
        
        assert isinstance(result, PrimitiveType)
        assert result.name == "float"
    
    def test_float_double_returns_double(self):
        """Test that float + double returns double."""
        loc = SourceLocation("test.c", 1, 1)
        float_type = PrimitiveType(loc, "float", True, None)
        double_type = PrimitiveType(loc, "double", True, None)
        result = usual_arithmetic_conversions(float_type, double_type)
        
        assert isinstance(result, PrimitiveType)
        assert result.name == "double"
    
    def test_char_short_returns_int(self):
        """Test that char + short returns int (after promotion)."""
        loc = SourceLocation("test.c", 1, 1)
        char_type = PrimitiveType(loc, "char", True, None)
        short_type = PrimitiveType(loc, "short", True, None)
        result = usual_arithmetic_conversions(char_type, short_type)
        
        assert isinstance(result, PrimitiveType)
        assert result.name == "int"


class TestImplicitConversions:
    """Test implicit type conversion rules."""
    
    def test_int_to_float_conversion(self):
        """Test that int can implicitly convert to float."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        float_type = PrimitiveType(loc, "float", True, None)
        
        assert can_convert_implicitly(int_type, float_type)
    
    def test_float_to_int_conversion(self):
        """Test that float can implicitly convert to int."""
        loc = SourceLocation("test.c", 1, 1)
        float_type = PrimitiveType(loc, "float", True, None)
        int_type = PrimitiveType(loc, "int", True, None)
        
        assert can_convert_implicitly(float_type, int_type)
    
    def test_pointer_to_void_pointer_conversion(self):
        """Test that any pointer can convert to void*."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        void_type = PrimitiveType(loc, "void", True, None)
        int_ptr = PointerType(loc, int_type, ())
        void_ptr = PointerType(loc, void_type, ())
        
        assert can_convert_implicitly(int_ptr, void_ptr)
    
    def test_void_pointer_to_pointer_conversion(self):
        """Test that void* can convert to any pointer."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        void_type = PrimitiveType(loc, "void", True, None)
        int_ptr = PointerType(loc, int_type, ())
        void_ptr = PointerType(loc, void_type, ())
        
        assert can_convert_implicitly(void_ptr, int_ptr)
    
    def test_array_to_pointer_decay(self):
        """Test that array decays to pointer."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        array_type = ArrayType(loc, int_type, None, False, 10)
        ptr_type = PointerType(loc, int_type, ())
        
        assert can_convert_implicitly(array_type, ptr_type)
    
    def test_const_correctness_prevents_conversion(self):
        """Test that const correctness prevents removing const."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        const_int_ptr = PointerType(loc, int_type, (TypeQualifier.CONST,))
        int_ptr = PointerType(loc, int_type, ())
        
        # Can't convert const int* to int* (removes const)
        assert not can_convert_implicitly(const_int_ptr, int_ptr)
    
    def test_adding_const_allowed(self):
        """Test that adding const is allowed."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        const_int_ptr = PointerType(loc, int_type, (TypeQualifier.CONST,))
        int_ptr = PointerType(loc, int_type, ())
        
        # Can convert int* to const int* (adds const)
        assert can_convert_implicitly(int_ptr, const_int_ptr)


class TestPointerConversions:
    """Test pointer conversion rules."""
    
    def test_compatible_pointer_conversion(self):
        """Test conversion between compatible pointer types."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        ptr1 = PointerType(loc, int_type, ())
        ptr2 = PointerType(loc, int_type, ())
        
        assert pointer_conversion(ptr1, ptr2)
    
    def test_pointer_to_void_conversion(self):
        """Test conversion to void pointer."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        void_type = PrimitiveType(loc, "void", True, None)
        int_ptr = PointerType(loc, int_type, ())
        void_ptr = PointerType(loc, void_type, ())
        
        assert pointer_conversion(int_ptr, void_ptr)
    
    def test_incompatible_pointer_conversion(self):
        """Test that incompatible pointers can't convert."""
        loc = SourceLocation("test.c", 1, 1)
        int_type = PrimitiveType(loc, "int", True, None)
        float_type = PrimitiveType(loc, "float", True, None)
        int_ptr = PointerType(loc, int_type, ())
        float_ptr = PointerType(loc, float_type, ())
        
        # Direct conversion between int* and float* not allowed
        assert not pointer_conversion(int_ptr, float_ptr)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
