"""Tests for string literal support in IR and code generation."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.codegen.x86.x86_codegen import X86CodeGenerator
from src.codegen.arm.arm_codegen import ARMCodeGenerator
from src.utils.error_reporter import ErrorReporter


def compile_code(source: str):
    """Helper to compile code through all phases.
    
    Returns:
        Tuple of (ir_module, x86_asm, arm_asm, error_reporter)
    """
    error_reporter = ErrorReporter()
    
    # Lex
    tokenizer = Tokenizer(source, filename="test.c")
    
    # Parse
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    if error_reporter.has_errors():
        return None, None, None, error_reporter
    
    # Semantic analysis
    analyzer = SemanticAnalyzer(ast, error_reporter)
    annotated_ast = analyzer.analyze()
    
    if error_reporter.has_errors():
        return None, None, None, error_reporter
    
    # IR generation
    ir_gen = IRGenerator(annotated_ast, error_reporter)
    ir_module = ir_gen.generate()
    
    if error_reporter.has_errors():
        return ir_module, None, None, error_reporter
    
    # Code generation
    x86_gen = X86CodeGenerator(ir_module)
    x86_asm = x86_gen.generate()
    
    arm_gen = ARMCodeGenerator(ir_module)
    arm_asm = arm_gen.generate()
    
    return ir_module, x86_asm, arm_asm, error_reporter


class TestStringLiteralDataSection:
    """Test string literals in data section."""
    
    def test_string_literal_in_data_section(self):
        """Test that string literals are added to data section."""
        source = '''
        int main() {
            char *s = "hello";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that string literal was added to IR module
        string_literals = ir_module.get_string_literals()
        assert len(string_literals) == 1
        assert string_literals[0].value == '"hello"'
        assert not string_literals[0].is_wide
    
    def test_string_literal_deduplication(self):
        """Test that duplicate string literals are deduplicated."""
        source = '''
        int main() {
            char *s1 = "hello";
            char *s2 = "hello";
            char *s3 = "world";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that only 2 unique strings are stored
        string_literals = ir_module.get_string_literals()
        assert len(string_literals) == 2
        
        # Check that both strings are present
        values = [lit.value for lit in string_literals]
        assert '"hello"' in values
        assert '"world"' in values
    
    def test_string_literal_labels(self):
        """Test that string literals get unique labels."""
        source = '''
        int main() {
            char *s1 = "first";
            char *s2 = "second";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that labels are unique
        string_literals = ir_module.get_string_literals()
        labels = [lit.label for lit in string_literals]
        assert len(labels) == len(set(labels))  # All labels are unique
        
        # Check label format
        for label in labels:
            assert label.startswith('.str')


class TestStringInitialization:
    """Test string initialization of char arrays."""
    
    def test_char_array_string_init(self):
        """Test char array initialization with string literal."""
        source = '''
        int main() {
            char s[] = "hello";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
    
    def test_char_pointer_string_init(self):
        """Test char pointer initialization with string literal."""
        source = '''
        int main() {
            char *s = "hello";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None


class TestStringLiteralCodeGeneration:
    """Test code generation for string literals."""
    
    def test_x86_rodata_section(self):
        """Test that x86 generates .rodata section for strings."""
        source = '''
        int main() {
            char *s = "hello";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert x86_asm is not None
        
        # Check for .rodata section
        assert '.section .rodata' in x86_asm or '.rodata' in x86_asm
        
        # Check for string label
        assert '.str0:' in x86_asm or '.str1:' in x86_asm
        
        # Check for .asciz directive
        assert '.asciz' in x86_asm
    
    def test_arm_rodata_section(self):
        """Test that ARM generates .rodata section for strings."""
        source = '''
        int main() {
            char *s = "hello";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert arm_asm is not None
        
        # Check for .rodata section
        assert '.section .rodata' in arm_asm or '.rodata' in arm_asm
        
        # Check for string label
        assert '.str0:' in arm_asm or '.str1:' in arm_asm
        
        # Check for .asciz directive
        assert '.asciz' in arm_asm
    
    def test_escape_sequences_in_assembly(self):
        """Test that escape sequences are properly handled in assembly."""
        source = r'''
        int main() {
            char *s = "hello\nworld\t!";
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert x86_asm is not None
        assert arm_asm is not None
        
        # Check that escape sequences are in the assembly
        # (they should be escaped for assembly syntax)
        assert '\\n' in x86_asm or 'hello' in x86_asm
        assert '\\n' in arm_asm or 'hello' in arm_asm


class TestStringLiteralUsage:
    """Test usage of string literals in code."""
    
    def test_string_as_function_argument(self):
        """Test passing string literal as function argument."""
        source = '''
        void print(char *s);
        
        int main() {
            print("hello");
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that string literal was added
        string_literals = ir_module.get_string_literals()
        assert len(string_literals) == 1
    
    def test_multiple_string_literals(self):
        """Test multiple string literals in same function."""
        source = '''
        void print(char *s);
        
        int main() {
            print("first");
            print("second");
            print("third");
            return 0;
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that all string literals were added
        string_literals = ir_module.get_string_literals()
        assert len(string_literals) == 3
    
    def test_string_in_return_statement(self):
        """Test returning string literal."""
        source = '''
        char* get_message() {
            return "hello";
        }
        '''
        
        ir_module, x86_asm, arm_asm, error_reporter = compile_code(source)
        
        assert not error_reporter.has_errors()
        assert ir_module is not None
        
        # Check that string literal was added
        string_literals = ir_module.get_string_literals()
        assert len(string_literals) == 1
