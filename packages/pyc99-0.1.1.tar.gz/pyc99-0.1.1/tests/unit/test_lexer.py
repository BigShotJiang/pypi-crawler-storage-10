"""Unit tests for the lexer/tokenizer."""

import pytest
from src.lexer.tokenizer import Tokenizer, Token
from src.lexer.token_types import TokenType


class TestBasicTokenization:
    """Test basic tokenization of all token types."""
    
    def test_keywords(self):
        """Test tokenization of C99 keywords."""
        source = "int void return if else while for"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.INT,
            TokenType.VOID,
            TokenType.RETURN,
            TokenType.IF,
            TokenType.ELSE,
            TokenType.WHILE,
            TokenType.FOR,
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type
    
    def test_all_keywords(self):
        """Test all C99 keywords are recognized."""
        keywords = [
            ('auto', TokenType.AUTO),
            ('break', TokenType.BREAK),
            ('case', TokenType.CASE),
            ('char', TokenType.CHAR),
            ('const', TokenType.CONST),
            ('continue', TokenType.CONTINUE),
            ('default', TokenType.DEFAULT),
            ('do', TokenType.DO),
            ('double', TokenType.DOUBLE),
            ('else', TokenType.ELSE),
            ('enum', TokenType.ENUM),
            ('extern', TokenType.EXTERN),
            ('float', TokenType.FLOAT),
            ('for', TokenType.FOR),
            ('goto', TokenType.GOTO),
            ('if', TokenType.IF),
            ('inline', TokenType.INLINE),
            ('int', TokenType.INT),
            ('long', TokenType.LONG),
            ('register', TokenType.REGISTER),
            ('restrict', TokenType.RESTRICT),
            ('return', TokenType.RETURN),
            ('short', TokenType.SHORT),
            ('signed', TokenType.SIGNED),
            ('sizeof', TokenType.SIZEOF),
            ('static', TokenType.STATIC),
            ('struct', TokenType.STRUCT),
            ('switch', TokenType.SWITCH),
            ('typedef', TokenType.TYPEDEF),
            ('union', TokenType.UNION),
            ('unsigned', TokenType.UNSIGNED),
            ('void', TokenType.VOID),
            ('volatile', TokenType.VOLATILE),
            ('while', TokenType.WHILE),
            ('_Bool', TokenType._BOOL),
            ('_Complex', TokenType._COMPLEX),
            ('_Imaginary', TokenType._IMAGINARY),
        ]
        
        for keyword, expected_type in keywords:
            tokenizer = Tokenizer(keyword)
            token = tokenizer.next_token()
            assert token.type == expected_type
            assert token.value == keyword
    
    def test_identifiers(self):
        """Test tokenization of identifiers."""
        source = "foo bar _test var123 _123"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_values = ["foo", "bar", "_test", "var123", "_123"]
        
        for i, expected_value in enumerate(expected_values):
            assert tokens[i].type == TokenType.IDENTIFIER
            assert tokens[i].value == expected_value
    
    def test_integer_literals(self):
        """Test tokenization of integer literals."""
        test_cases = [
            ("0", "0"),
            ("123", "123"),
            ("456789", "456789"),
            ("0x1A", "0x1A"),
            ("0xFF", "0xFF"),
            ("0777", "0777"),
            ("123u", "123u"),
            ("456L", "456L"),
            ("789UL", "789UL"),
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.INTEGER_LITERAL
            assert token.value == expected_value
    
    def test_float_literals(self):
        """Test tokenization of floating-point literals."""
        test_cases = [
            ("3.14", "3.14"),
            ("0.5", "0.5"),
            ("2.0f", "2.0f"),
            ("1.5F", "1.5F"),
            ("3.14159L", "3.14159L"),
            ("1e10", "1e10"),
            ("2.5e-3", "2.5e-3"),
            ("1.0E+5", "1.0E+5"),
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.FLOAT_LITERAL
            assert token.value == expected_value
    
    def test_hexadecimal_float_literals(self):
        """Test tokenization of hexadecimal floating-point literals (C99)."""
        test_cases = [
            ("0x1.8p3", "0x1.8p3"),           # 1.5 * 2^3 = 12.0
            ("0x1p-1", "0x1p-1"),             # 1 * 2^-1 = 0.5
            ("0x1.0p0", "0x1.0p0"),           # 1.0 * 2^0 = 1.0
            ("0xA.Bp2", "0xA.Bp2"),           # 10.6875 * 2^2
            ("0x1.FFFFFEp127", "0x1.FFFFFEp127"),  # Large float
            ("0x1p+10", "0x1p+10"),           # With explicit + in exponent
            ("0x1.8p3f", "0x1.8p3f"),         # With float suffix
            ("0x1.8p3F", "0x1.8p3F"),         # With uppercase float suffix
            ("0x1.8p3l", "0x1.8p3l"),         # With long double suffix
            ("0x1.8p3L", "0x1.8p3L"),         # With uppercase long double suffix
            ("0X1.8P3", "0X1.8P3"),           # Uppercase X and P
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.FLOAT_LITERAL, f"Failed for {source}"
            assert token.value == expected_value, f"Failed for {source}"
    
    def test_string_literals(self):
        """Test tokenization of string literals."""
        test_cases = [
            ('"hello"', '"hello"'),
            ('"world"', '"world"'),
            ('""', '""'),
            ('"test string"', '"test string"'),
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.STRING_LITERAL
            assert token.value == expected_value
    
    def test_char_literals(self):
        """Test tokenization of character literals."""
        test_cases = [
            ("'a'", "'a'"),
            ("'Z'", "'Z'"),
            ("'0'", "'0'"),
            ("' '", "' '"),
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.CHAR_LITERAL
            assert token.value == expected_value


class TestOperators:
    """Test tokenization of operators."""
    
    def test_single_char_operators(self):
        """Test single-character operators."""
        operators = [
            ('+', TokenType.PLUS),
            ('-', TokenType.MINUS),
            ('*', TokenType.STAR),
            ('/', TokenType.SLASH),
            ('%', TokenType.PERCENT),
            ('&', TokenType.AMPERSAND),
            ('|', TokenType.PIPE),
            ('^', TokenType.CARET),
            ('~', TokenType.TILDE),
            ('!', TokenType.EXCLAMATION),
            ('?', TokenType.QUESTION),
            (':', TokenType.COLON),
            ('=', TokenType.ASSIGN),
            ('<', TokenType.LT),
            ('>', TokenType.GT),
        ]
        
        for op, expected_type in operators:
            tokenizer = Tokenizer(op)
            token = tokenizer.next_token()
            assert token.type == expected_type
            assert token.value == op
    
    def test_two_char_operators(self):
        """Test two-character operators."""
        operators = [
            ('++', TokenType.PLUS_PLUS),
            ('--', TokenType.MINUS_MINUS),
            ('->', TokenType.ARROW),
            ('+=', TokenType.PLUS_ASSIGN),
            ('-=', TokenType.MINUS_ASSIGN),
            ('*=', TokenType.STAR_ASSIGN),
            ('/=', TokenType.SLASH_ASSIGN),
            ('%=', TokenType.PERCENT_ASSIGN),
            ('&=', TokenType.AMPERSAND_ASSIGN),
            ('|=', TokenType.PIPE_ASSIGN),
            ('^=', TokenType.CARET_ASSIGN),
            ('<<', TokenType.LSHIFT),
            ('>>', TokenType.RSHIFT),
            ('==', TokenType.EQ),
            ('!=', TokenType.NE),
            ('<=', TokenType.LE),
            ('>=', TokenType.GE),
            ('&&', TokenType.LOGICAL_AND),
            ('||', TokenType.LOGICAL_OR),
        ]
        
        for op, expected_type in operators:
            tokenizer = Tokenizer(op)
            token = tokenizer.next_token()
            assert token.type == expected_type
            assert token.value == op
    
    def test_three_char_operators(self):
        """Test three-character operators."""
        operators = [
            ('...', TokenType.ELLIPSIS),
            ('<<=', TokenType.LSHIFT_ASSIGN),
            ('>>=', TokenType.RSHIFT_ASSIGN),
        ]
        
        for op, expected_type in operators:
            tokenizer = Tokenizer(op)
            token = tokenizer.next_token()
            assert token.type == expected_type
            assert token.value == op


class TestPunctuation:
    """Test tokenization of punctuation."""
    
    def test_punctuation(self):
        """Test all punctuation tokens."""
        punctuation = [
            ('(', TokenType.LPAREN),
            (')', TokenType.RPAREN),
            ('{', TokenType.LBRACE),
            ('}', TokenType.RBRACE),
            ('[', TokenType.LBRACKET),
            (']', TokenType.RBRACKET),
            (';', TokenType.SEMICOLON),
            (',', TokenType.COMMA),
            ('.', TokenType.DOT),
            ('#', TokenType.HASH),
        ]
        
        for punct, expected_type in punctuation:
            tokenizer = Tokenizer(punct)
            token = tokenizer.next_token()
            assert token.type == expected_type
            assert token.value == punct


class TestEscapeSequences:
    """Test string and character escape sequences."""
    
    def test_string_escape_sequences(self):
        """Test escape sequences in strings."""
        test_cases = [
            (r'"hello\nworld"', r'"hello\nworld"'),
            (r'"tab\there"', r'"tab\there"'),
            (r'"quote\"test"', r'"quote\"test"'),
            (r'"backslash\\"', r'"backslash\\"'),
            (r'"\r\n"', r'"\r\n"'),
            (r'"\x41"', r'"\x41"'),  # Hex escape
            (r'"\101"', r'"\101"'),  # Octal escape
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.STRING_LITERAL
            assert token.value == expected_value
    
    def test_char_escape_sequences(self):
        """Test escape sequences in character literals."""
        test_cases = [
            (r"'\n'", r"'\n'"),
            (r"'\t'", r"'\t'"),
            (r"'\''", r"'\''"),
            (r"'\\'", r"'\\'"),
        ]
        
        for source, expected_value in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.CHAR_LITERAL
            assert token.value == expected_value


class TestComments:
    """Test comment handling."""
    
    def test_line_comments(self):
        """Test line comments are skipped."""
        source = """
        int x; // this is a comment
        int y;
        """
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should get: int, x, ;, int, y, ;, EOF
        token_types = [t.type for t in tokens]
        assert TokenType.INT in token_types
        assert token_types.count(TokenType.IDENTIFIER) == 2
        assert token_types.count(TokenType.SEMICOLON) == 2
    
    def test_block_comments(self):
        """Test block comments are skipped."""
        source = """
        int x; /* this is a
        multi-line comment */
        int y;
        """
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should get: int, x, ;, int, y, ;, EOF
        token_types = [t.type for t in tokens]
        assert TokenType.INT in token_types
        assert token_types.count(TokenType.IDENTIFIER) == 2
        assert token_types.count(TokenType.SEMICOLON) == 2
    
    def test_nested_comment_content(self):
        """Test that /* inside block comments doesn't cause issues."""
        source = "int x; /* comment with /* nested */ int y;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should get: int, x, ;, int, y, ;, EOF
        token_types = [t.type for t in tokens]
        assert token_types.count(TokenType.INT) == 2


class TestErrorHandling:
    """Test error handling for invalid input."""
    
    def test_invalid_character(self):
        """Test that invalid characters are reported."""
        source = "int x @ y;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should report error but continue tokenizing
        assert tokenizer.error_reporter.has_errors()
    
    def test_unterminated_string(self):
        """Test unterminated string literal error."""
        source = '"unterminated string'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        
        assert token.type == TokenType.STRING_LITERAL
        assert tokenizer.error_reporter.has_errors()
    
    def test_unterminated_string_with_newline(self):
        """Test unterminated string with newline."""
        source = '"unterminated\nstring"'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        
        assert tokenizer.error_reporter.has_errors()
    
    def test_unterminated_char(self):
        """Test unterminated character literal error."""
        source = "'x"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        
        assert token.type == TokenType.CHAR_LITERAL
        assert tokenizer.error_reporter.has_errors()
    
    def test_unterminated_block_comment(self):
        """Test unterminated block comment error."""
        source = "/* unterminated comment"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        assert tokenizer.error_reporter.has_errors()
    
    def test_invalid_hex_literal(self):
        """Test invalid hexadecimal literal."""
        source = "0x"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        
        assert tokenizer.error_reporter.has_errors()
    
    def test_invalid_exponent(self):
        """Test invalid exponent in float literal."""
        source = "1.0e"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        
        assert tokenizer.error_reporter.has_errors()


class TestSourceLocation:
    """Test source location tracking."""
    
    def test_single_line_locations(self):
        """Test column tracking on a single line."""
        source = "int x = 5;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # int at column 1
        assert tokens[0].location.line == 1
        assert tokens[0].location.column == 1
        
        # x at column 5
        assert tokens[1].location.line == 1
        assert tokens[1].location.column == 5
        
        # = at column 7
        assert tokens[2].location.line == 1
        assert tokens[2].location.column == 7
    
    def test_multi_line_locations(self):
        """Test line and column tracking across multiple lines."""
        source = """int x;
int y;
int z;"""
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # First line
        assert tokens[0].location.line == 1  # int
        assert tokens[1].location.line == 1  # x
        
        # Second line
        assert tokens[3].location.line == 2  # int
        assert tokens[4].location.line == 2  # y
        
        # Third line
        assert tokens[6].location.line == 3  # int
        assert tokens[7].location.line == 3  # z
    
    def test_location_with_comments(self):
        """Test location tracking with comments."""
        source = """int x; // comment
int y;"""
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # First line
        assert tokens[0].location.line == 1  # int
        
        # Second line (after comment)
        assert tokens[3].location.line == 2  # int
    
    def test_filename_in_location(self):
        """Test that filename is tracked in location."""
        source = "int x;"
        tokenizer = Tokenizer(source, filename="test.c")
        token = tokenizer.next_token()
        
        assert token.location.filename == "test.c"


class TestComplexExpressions:
    """Test tokenization of complex expressions."""
    
    def test_arithmetic_expression(self):
        """Test tokenization of arithmetic expression."""
        source = "x + y * z - 10"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.IDENTIFIER,  # x
            TokenType.PLUS,        # +
            TokenType.IDENTIFIER,  # y
            TokenType.STAR,        # *
            TokenType.IDENTIFIER,  # z
            TokenType.MINUS,       # -
            TokenType.INTEGER_LITERAL,  # 10
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type
    
    def test_function_call(self):
        """Test tokenization of function call."""
        source = "printf(\"hello %d\", x);"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.IDENTIFIER,      # printf
            TokenType.LPAREN,          # (
            TokenType.STRING_LITERAL,  # "hello %d"
            TokenType.COMMA,           # ,
            TokenType.IDENTIFIER,      # x
            TokenType.RPAREN,          # )
            TokenType.SEMICOLON,       # ;
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type
    
    def test_pointer_dereference(self):
        """Test tokenization of pointer operations."""
        source = "*ptr = &value;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.STAR,        # *
            TokenType.IDENTIFIER,  # ptr
            TokenType.ASSIGN,      # =
            TokenType.AMPERSAND,   # &
            TokenType.IDENTIFIER,  # value
            TokenType.SEMICOLON,   # ;
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type
    
    def test_struct_access(self):
        """Test tokenization of struct member access."""
        source = "obj.field = ptr->member;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.IDENTIFIER,  # obj
            TokenType.DOT,         # .
            TokenType.IDENTIFIER,  # field
            TokenType.ASSIGN,      # =
            TokenType.IDENTIFIER,  # ptr
            TokenType.ARROW,       # ->
            TokenType.IDENTIFIER,  # member
            TokenType.SEMICOLON,   # ;
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type


class TestWhitespace:
    """Test whitespace handling."""
    
    def test_spaces(self):
        """Test that spaces are properly skipped."""
        source = "int    x    =    5;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should get same tokens regardless of spacing
        expected_types = [
            TokenType.INT,
            TokenType.IDENTIFIER,
            TokenType.ASSIGN,
            TokenType.INTEGER_LITERAL,
            TokenType.SEMICOLON,
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type
    
    def test_tabs_and_newlines(self):
        """Test that tabs and newlines are properly skipped."""
        source = "int\tx\n=\t\n5;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        expected_types = [
            TokenType.INT,
            TokenType.IDENTIFIER,
            TokenType.ASSIGN,
            TokenType.INTEGER_LITERAL,
            TokenType.SEMICOLON,
            TokenType.EOF
        ]
        
        assert len(tokens) == len(expected_types)
        for token, expected_type in zip(tokens, expected_types):
            assert token.type == expected_type


class TestPeekToken:
    """Test peek_token functionality."""
    
    def test_peek_does_not_consume(self):
        """Test that peek_token doesn't consume the token."""
        source = "int x;"
        tokenizer = Tokenizer(source)
        
        # Peek at first token
        peeked = tokenizer.peek_token()
        assert peeked.type == TokenType.INT
        
        # Next token should be the same
        next_token = tokenizer.next_token()
        assert next_token.type == TokenType.INT
        assert next_token.value == peeked.value
    
    def test_multiple_peeks(self):
        """Test multiple peeks return the same token."""
        source = "int x;"
        tokenizer = Tokenizer(source)
        
        peek1 = tokenizer.peek_token()
        peek2 = tokenizer.peek_token()
        
        assert peek1.type == peek2.type
        assert peek1.value == peek2.value


class TestTokenizeAll:
    """Test tokenize_all functionality."""
    
    def test_tokenize_all_includes_eof(self):
        """Test that tokenize_all includes EOF token."""
        source = "int x;"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        assert tokens[-1].type == TokenType.EOF
    
    def test_empty_source(self):
        """Test tokenizing empty source."""
        source = ""
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        assert len(tokens) == 1
        assert tokens[0].type == TokenType.EOF
    
    def test_whitespace_only(self):
        """Test tokenizing whitespace-only source."""
        source = "   \n\t  \n  "
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        assert len(tokens) == 1
        assert tokens[0].type == TokenType.EOF


class TestRealWorldCode:
    """Test tokenization of real-world C code snippets."""
    
    def test_simple_function(self):
        """Test tokenization of a simple function."""
        source = """
        int add(int a, int b) {
            return a + b;
        }
        """
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Verify we get all expected token types
        token_types = [t.type for t in tokens]
        assert TokenType.INT in token_types
        assert TokenType.IDENTIFIER in token_types
        assert TokenType.LPAREN in token_types
        assert TokenType.RPAREN in token_types
        assert TokenType.LBRACE in token_types
        assert TokenType.RBRACE in token_types
        assert TokenType.RETURN in token_types
        assert TokenType.PLUS in token_types
        assert TokenType.SEMICOLON in token_types
    
    def test_variable_declarations(self):
        """Test tokenization of variable declarations."""
        source = """
        int x = 10;
        float y = 3.14;
        char *str = "hello";
        """
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        token_types = [t.type for t in tokens]
        assert token_types.count(TokenType.INT) == 1
        assert token_types.count(TokenType.FLOAT) == 1
        assert token_types.count(TokenType.CHAR) == 1
        assert TokenType.STAR in token_types
        assert TokenType.STRING_LITERAL in token_types
    
    def test_control_flow(self):
        """Test tokenization of control flow statements."""
        source = """
        if (x > 0) {
            while (y < 10) {
                y++;
            }
        } else {
            for (int i = 0; i < 5; i++) {
                break;
            }
        }
        """
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        token_types = [t.type for t in tokens]
        assert TokenType.IF in token_types
        assert TokenType.ELSE in token_types
        assert TokenType.WHILE in token_types
        assert TokenType.FOR in token_types
        assert TokenType.BREAK in token_types
        assert TokenType.PLUS_PLUS in token_types



class TestEdgeCases:
    """Test edge cases and corner scenarios."""
    
    def test_string_with_all_escape_sequences(self):
        """Test string with various escape sequences."""
        source = r'"\n\t\r\f\v\a\b\'\"\\\?"'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.STRING_LITERAL
    
    def test_string_with_octal_escape(self):
        """Test string with octal escape sequences."""
        source = r'"\101\102\103"'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.STRING_LITERAL
        assert r'\101' in token.value
    
    def test_string_with_hex_escape(self):
        """Test string with hex escape sequences."""
        source = r'"\x41\x42\x43"'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.STRING_LITERAL
        assert r'\x41' in token.value
    
    def test_string_ending_with_backslash_eof(self):
        """Test string ending with backslash at EOF."""
        source = '"test\\'
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert tokenizer.error_reporter.has_errors()
    
    def test_octal_number_edge_case(self):
        """Test octal number with valid digits."""
        source = "01234567"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.INTEGER_LITERAL
        assert token.value == "01234567"
    
    def test_hex_with_uppercase_x(self):
        """Test hex number with uppercase X."""
        source = "0X1A2B"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.INTEGER_LITERAL
        assert token.value == "0X1A2B"
    
    def test_float_with_long_double_suffix(self):
        """Test float with long double suffix."""
        source = "3.14L"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.FLOAT_LITERAL
        assert token.value == "3.14L"
    
    def test_multiple_integer_suffixes(self):
        """Test integer with multiple suffixes."""
        source = "123ULL"
        tokenizer = Tokenizer(source)
        token = tokenizer.next_token()
        assert token.type == TokenType.INTEGER_LITERAL
        assert token.value == "123ULL"
    
    def test_operator_disambiguation(self):
        """Test that operators are correctly distinguished."""
        # Test that << is not confused with < <
        source = "a<<b"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        assert tokens[1].type == TokenType.LSHIFT
        
        # Test that >> is not confused with > >
        source = "a>>b"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        assert tokens[1].type == TokenType.RSHIFT
    
    def test_consecutive_operators(self):
        """Test consecutive operators without spaces."""
        source = "a+++b"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        # Should be: a, ++, +, b
        assert tokens[1].type == TokenType.PLUS_PLUS
        assert tokens[2].type == TokenType.PLUS
    
    def test_mixed_line_endings(self):
        """Test handling of different line endings."""
        source = "int x;\r\nint y;\rint z;\n"
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        
        # Should tokenize correctly regardless of line endings
        token_types = [t.type for t in tokens]
        assert token_types.count(TokenType.INT) == 3
    
    def test_very_long_identifier(self):
        """Test very long identifier."""
        long_id = "a" * 1000
        tokenizer = Tokenizer(long_id)
        token = tokenizer.next_token()
        assert token.type == TokenType.IDENTIFIER
        assert len(token.value) == 1000
    
    def test_zero_with_suffix(self):
        """Test zero with various suffixes."""
        test_cases = ["0u", "0L", "0UL", "0ll"]
        for source in test_cases:
            tokenizer = Tokenizer(source)
            token = tokenizer.next_token()
            assert token.type == TokenType.INTEGER_LITERAL
    
    def test_float_without_leading_digit(self):
        """Test that .5 style floats work (if supported)."""
        # Note: C99 requires at least one digit before or after decimal
        # This tests the current implementation behavior
        source = "x.5"  # This should be: x, ., 5
        tokenizer = Tokenizer(source)
        tokens = tokenizer.tokenize_all()
        assert tokens[0].type == TokenType.IDENTIFIER
        assert tokens[1].type == TokenType.DOT
        assert tokens[2].type == TokenType.INTEGER_LITERAL
