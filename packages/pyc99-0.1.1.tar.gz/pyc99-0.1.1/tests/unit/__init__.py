"""Unit tests for compiler components."""
