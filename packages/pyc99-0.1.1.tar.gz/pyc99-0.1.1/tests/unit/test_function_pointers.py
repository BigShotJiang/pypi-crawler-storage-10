"""Unit tests for function pointer support."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.parser.ast_nodes import (
    FunctionDecl, VarDecl, FunctionType, PointerType, PrimitiveType,
    ArrayType, CallExpr, Identifier
)
from src.semantic.analyzer import SemanticAnalyzer
from src.utils.error_reporter import ErrorReporter


class TestFunctionPointerParsing:
    """Test parsing of function pointer declarations."""
    
    def test_simple_function_pointer_declaration(self):
        """Test parsing: int (*fp)(int, int);"""
        source = "int (*fp)(int, int);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, VarDecl)
        assert decl.name == "fp"
        
        # Type should be pointer to function
        assert isinstance(decl.var_type, PointerType)
        func_type = decl.var_type.pointee_type
        assert isinstance(func_type, FunctionType)
        assert isinstance(func_type.return_type, PrimitiveType)
        assert func_type.return_type.name == "int"
        assert len(func_type.parameter_types) == 2
    
    def test_function_pointer_with_void_params(self):
        """Test parsing: void (*fp)(void);"""
        source = "void (*fp)(void);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, VarDecl)
        assert decl.name == "fp"
        
        # Type should be pointer to function
        assert isinstance(decl.var_type, PointerType)
        func_type = decl.var_type.pointee_type
        assert isinstance(func_type, FunctionType)
        assert func_type.return_type.name == "void"
        assert len(func_type.parameter_types) == 0
    
    def test_array_of_function_pointers(self):
        """Test parsing: int (*arr[10])(void);"""
        source = "int (*arr[10])(void);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        assert isinstance(decl, VarDecl)
        assert decl.name == "arr"
        
        # Type should be array of pointers to functions
        assert isinstance(decl.var_type, ArrayType)
        assert decl.var_type.size_value == 10
        
        # Element type should be pointer to function
        elem_type = decl.var_type.element_type
        assert isinstance(elem_type, PointerType)
        func_type = elem_type.pointee_type
        assert isinstance(func_type, FunctionType)
        assert func_type.return_type.name == "int"
    
    def test_function_returning_function_pointer(self):
        """Test parsing: int (*get_func(void))(int);
        
        Note: This complex declarator is parsed as a variable declaration
        in our simplified parser. Full C99 support would require more
        sophisticated declarator parsing.
        """
        source = "int (*get_func(void))(int);"
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        assert len(ast.declarations) == 1
        decl = ast.declarations[0]
        # Our parser treats this as a variable for now
        assert isinstance(decl, VarDecl)
        assert decl.name == "get_func"
        
        # Type should be pointer to function
        assert isinstance(decl.var_type, PointerType)
        func_type = decl.var_type.pointee_type
        assert isinstance(func_type, FunctionType)


class TestFunctionPointerSemantics:
    """Test semantic analysis of function pointers."""
    
    def test_function_pointer_assignment(self):
        """Test assigning function to function pointer."""
        source = """
        int add(int a, int b) { return a + b; }
        int (*fp)(int, int);
        void test() {
            fp = add;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
    
    def test_function_pointer_call(self):
        """Test calling function through pointer."""
        source = """
        int add(int a, int b) { return a + b; }
        int (*fp)(int, int);
        int test() {
            fp = add;
            return fp(1, 2);
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()
    
    def test_incompatible_function_pointer_assignment(self):
        """Test error on incompatible function pointer assignment."""
        source = """
        int add(int a, int b) { return a + b; }
        void (*fp)(int);
        void test() {
            fp = add;
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        # Should have type error
        assert error_reporter.has_errors()
    
    def test_function_pointer_parameter(self):
        """Test function pointer as parameter."""
        source = """
        int apply(int (*func)(int), int x) {
            return func(x);
        }
        int double_val(int x) { return x * 2; }
        int test() {
            return apply(double_val, 5);
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        analyzer.analyze()
        
        # Should not have errors
        assert not error_reporter.has_errors()


class TestFunctionPointerIR:
    """Test IR generation for function pointers."""
    
    def test_function_pointer_call_ir(self):
        """Test IR generation for indirect call."""
        source = """
        int add(int a, int b) { return a + b; }
        int test() {
            int (*fp)(int, int);
            fp = add;
            return fp(1, 2);
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        ast = analyzer.analyze()
        
        from src.ir.ir_generator import IRGenerator
        ir_gen = IRGenerator(ast, error_reporter)
        ir_module = ir_gen.generate()
        
        # Should have generated IR for test function
        test_func = None
        for func in ir_module.functions:
            if func.name == "test":
                test_func = func
                break
        
        assert test_func is not None
        
        # Should have CALL instruction for indirect call
        has_call = False
        for block in test_func.basic_blocks:
            for inst in block.instructions:
                if inst.opcode.name == "CALL":
                    has_call = True
                    break
        
        assert has_call


class TestFunctionPointerCodegen:
    """Test code generation for function pointers."""
    
    def test_x86_indirect_call(self):
        """Test x86 code generation for indirect call."""
        source = """
        int add(int a, int b) { return a + b; }
        int test() {
            int (*fp)(int, int);
            fp = add;
            return fp(1, 2);
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        ast = analyzer.analyze()
        
        from src.ir.ir_generator import IRGenerator
        ir_gen = IRGenerator(ast, error_reporter)
        ir_module = ir_gen.generate()
        
        from src.codegen.x86.x86_codegen import X86CodeGenerator
        codegen = X86CodeGenerator(ir_module)
        asm_code = codegen.generate()
        
        # Should contain call instruction
        assert "call" in asm_code.lower()
    
    def test_arm_indirect_call(self):
        """Test ARM code generation for indirect call."""
        source = """
        int add(int a, int b) { return a + b; }
        int test() {
            int (*fp)(int, int);
            fp = add;
            return fp(1, 2);
        }
        """
        tokenizer = Tokenizer(source)
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        ast = analyzer.analyze()
        
        from src.ir.ir_generator import IRGenerator
        ir_gen = IRGenerator(ast, error_reporter)
        ir_module = ir_gen.generate()
        
        from src.codegen.arm.arm_codegen import ARMCodeGenerator
        codegen = ARMCodeGenerator(ir_module)
        asm_code = codegen.generate()
        
        # Should contain blx instruction for indirect call
        assert "blx" in asm_code.lower()
