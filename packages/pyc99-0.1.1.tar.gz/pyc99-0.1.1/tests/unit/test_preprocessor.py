"""Unit tests for the preprocessor."""

import pytest
from src.preprocessor.preprocessor import Preprocessor, PreprocessorDirective
from src.utils.error_reporter import ErrorReporter


def test_preprocessor_initialization():
    """Test preprocessor initialization."""
    preprocessor = Preprocessor()
    assert preprocessor is not None
    assert len(preprocessor.system_include_paths) > 0


def test_standard_header_recognition():
    """Test recognition of standard library headers."""
    preprocessor = Preprocessor()
    
    # Test stdio.h
    source = '#include <stdio.h>\nint main() { return 0; }'
    result = preprocessor.preprocess(source)
    
    assert 'printf' in result
    assert 'scanf' in result
    assert 'main' in result


def test_stdlib_header():
    """Test stdlib.h header."""
    preprocessor = Preprocessor()
    
    source = '#include <stdlib.h>\nint main() { return 0; }'
    result = preprocessor.preprocess(source)
    
    assert 'malloc' in result
    assert 'free' in result
    assert 'exit' in result


def test_string_header():
    """Test string.h header."""
    preprocessor = Preprocessor()
    
    source = '#include <string.h>\nint main() { return 0; }'
    result = preprocessor.preprocess(source)
    
    assert 'strlen' in result
    assert 'strcpy' in result
    assert 'strcmp' in result


def test_math_header():
    """Test math.h header."""
    preprocessor = Preprocessor()
    
    source = '#include <math.h>\nint main() { return 0; }'
    result = preprocessor.preprocess(source)
    
    assert 'sin' in result
    assert 'cos' in result
    assert 'sqrt' in result


def test_multiple_includes():
    """Test multiple include directives."""
    preprocessor = Preprocessor()
    
    source = '''#include <stdio.h>
#include <stdlib.h>
int main() { return 0; }'''
    
    result = preprocessor.preprocess(source)
    
    assert 'printf' in result
    assert 'malloc' in result
    assert 'main' in result


def test_parse_directives():
    """Test parsing preprocessor directives."""
    preprocessor = Preprocessor()
    
    source = '''#include <stdio.h>
#define MAX 100
#ifdef DEBUG
#endif'''
    
    directives = preprocessor.parse_directives(source)
    
    assert len(directives) == 4
    assert directives[0].type == 'include'
    assert directives[1].type == 'define'
    assert directives[2].type == 'ifdef'
    assert directives[3].type == 'endif'


def test_include_path():
    """Test adding custom include paths."""
    import tempfile
    import os
    
    preprocessor = Preprocessor()
    
    # Create a temporary directory and add it as include path
    with tempfile.TemporaryDirectory() as tmpdir:
        preprocessor.add_include_path(tmpdir)
        assert tmpdir in preprocessor.include_paths
    
    # Test that non-existent paths are not added
    initial_count = len(preprocessor.include_paths)
    preprocessor.add_include_path('/nonexistent/path/that/does/not/exist')
    assert len(preprocessor.include_paths) == initial_count


def test_circular_include_prevention():
    """Test that circular includes are prevented."""
    preprocessor = Preprocessor()
    
    # Include the same header twice
    source = '''#include <stdio.h>
#include <stdio.h>
int main() { return 0; }'''
    
    result = preprocessor.preprocess(source)
    
    # Should only include once (check that printf doesn't appear twice in a row)
    # This is a simplified test - in reality we'd check the structure more carefully
    assert result.count('// #include <stdio.h>') == 2


def test_unknown_header_error():
    """Test error reporting for unknown headers."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '#include "nonexistent.h"\nint main() { return 0; }'
    result = preprocessor.preprocess(source)
    
    # Should have an error
    assert error_reporter.has_errors()


def test_standard_headers_list():
    """Test that standard headers are recognized."""
    assert 'stdio.h' in Preprocessor.STANDARD_HEADERS
    assert 'stdlib.h' in Preprocessor.STANDARD_HEADERS
    assert 'string.h' in Preprocessor.STANDARD_HEADERS
    assert 'math.h' in Preprocessor.STANDARD_HEADERS
    assert 'stdint.h' in Preprocessor.STANDARD_HEADERS
    assert 'stdbool.h' in Preprocessor.STANDARD_HEADERS


def test_stdlib_declarations():
    """Test that standard library declarations are available."""
    preprocessor = Preprocessor()
    
    # Test stdio.h declarations
    stdio_decls = preprocessor._get_stdlib_declarations('stdio.h')
    assert 'printf' in stdio_decls
    assert 'scanf' in stdio_decls
    
    # Test stdlib.h declarations
    stdlib_decls = preprocessor._get_stdlib_declarations('stdlib.h')
    assert 'malloc' in stdlib_decls
    assert 'free' in stdlib_decls
    
    # Test string.h declarations
    string_decls = preprocessor._get_stdlib_declarations('string.h')
    assert 'strlen' in string_decls
    assert 'strcpy' in string_decls


def test_preprocess_preserves_code():
    """Test that preprocessing preserves non-directive code."""
    preprocessor = Preprocessor()
    
    source = '''int add(int a, int b) {
    return a + b;
}

int main() {
    int x = add(1, 2);
    return 0;
}'''
    
    result = preprocessor.preprocess(source)
    
    assert 'int add(int a, int b)' in result
    assert 'return a + b' in result
    assert 'int main()' in result


# Macro tests

def test_object_like_macro_simple():
    """Test simple object-like macro."""
    preprocessor = Preprocessor()
    
    source = '''#define MAX 100
int x = MAX;'''
    
    result = preprocessor.preprocess(source)
    
    assert '100' in result
    assert 'int x = 100' in result


def test_object_like_macro_expression():
    """Test object-like macro with expression."""
    preprocessor = Preprocessor()
    
    source = '''#define SIZE (10 * 20)
int arr[SIZE];'''
    
    result = preprocessor.preprocess(source)
    
    assert '( 10 * 20 )' in result or '(10 * 20)' in result


def test_function_like_macro_simple():
    """Test simple function-like macro."""
    preprocessor = Preprocessor()
    
    source = '''#define SQUARE(x) ((x) * (x))
int y = SQUARE(5);'''
    
    result = preprocessor.preprocess(source)
    
    assert '( ( 5 ) * ( 5 ) )' in result or '((5) * (5))' in result


def test_function_like_macro_multiple_params():
    """Test function-like macro with multiple parameters."""
    preprocessor = Preprocessor()
    
    source = '''#define ADD(a, b) ((a) + (b))
int sum = ADD(10, 20);'''
    
    result = preprocessor.preprocess(source)
    
    assert '10' in result
    assert '20' in result
    assert '+' in result


def test_macro_undef():
    """Test #undef directive."""
    preprocessor = Preprocessor()
    
    source = '''#define MAX 100
int x = MAX;
#undef MAX
int y = MAX;'''
    
    result = preprocessor.preprocess(source)
    
    # First MAX should be expanded
    lines = result.split('\n')
    assert any('100' in line and 'int x' in line for line in lines)
    
    # Second MAX should not be expanded (remains as identifier)
    assert any('MAX' in line and 'int y' in line for line in lines)


def test_stringification_operator():
    """Test stringification operator (#)."""
    preprocessor = Preprocessor()
    
    source = '''#define STRINGIFY(x) #x
char *s = STRINGIFY(hello);'''
    
    result = preprocessor.preprocess(source)
    
    assert '"hello"' in result


def test_token_pasting_operator():
    """Test token pasting operator (##)."""
    preprocessor = Preprocessor()
    
    source = '''#define CONCAT(a, b) a##b
int xy = 10;
int z = CONCAT(x, y);'''
    
    result = preprocessor.preprocess(source)
    
    assert 'xy' in result


def test_predefined_macro_stdc():
    """Test __STDC__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''int x = __STDC__;'''
    
    result = preprocessor.preprocess(source)
    
    assert '1' in result


def test_predefined_macro_stdc_version():
    """Test __STDC_VERSION__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''long v = __STDC_VERSION__;'''
    
    result = preprocessor.preprocess(source)
    
    assert '199901L' in result


def test_predefined_macro_file():
    """Test __FILE__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''char *f = __FILE__;'''
    
    result = preprocessor.preprocess(source, 'test.c')
    
    assert '"test.c"' in result


def test_predefined_macro_line():
    """Test __LINE__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''int a = 1;
int line = __LINE__;'''
    
    result = preprocessor.preprocess(source)
    
    assert '2' in result


def test_predefined_macro_date():
    """Test __DATE__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''char *d = __DATE__;'''
    
    result = preprocessor.preprocess(source)
    
    # Should contain a date string
    assert '"' in result
    # Date format is "MMM DD YYYY"
    import re
    assert re.search(r'"\w{3}\s+\d{1,2}\s+\d{4}"', result)


def test_predefined_macro_time():
    """Test __TIME__ predefined macro."""
    preprocessor = Preprocessor()
    
    source = '''char *t = __TIME__;'''
    
    result = preprocessor.preprocess(source)
    
    # Should contain a time string
    assert '"' in result
    # Time format is "HH:MM:SS"
    import re
    assert re.search(r'"\d{2}:\d{2}:\d{2}"', result)


def test_macro_recursive_expansion_prevention():
    """Test that recursive macro expansion is prevented."""
    preprocessor = Preprocessor()
    
    source = '''#define FOO FOO
int x = FOO;'''
    
    result = preprocessor.preprocess(source)
    
    # Should not expand recursively - FOO should remain
    assert 'FOO' in result


def test_nested_macro_expansion():
    """Test nested macro expansion."""
    preprocessor = Preprocessor()
    
    source = '''#define A 10
#define B A
int x = B;'''
    
    result = preprocessor.preprocess(source)
    
    assert '10' in result


def test_macro_in_macro_expansion():
    """Test macro used in another macro's expansion."""
    preprocessor = Preprocessor()
    
    source = '''#define SIZE 100
#define BUFFER_SIZE (SIZE * 2)
int buf[BUFFER_SIZE];'''
    
    result = preprocessor.preprocess(source)
    
    assert '100' in result
    assert '2' in result


def test_function_macro_with_macro_argument():
    """Test function-like macro with macro as argument."""
    preprocessor = Preprocessor()
    
    source = '''#define VALUE 42
#define DOUBLE(x) ((x) * 2)
int y = DOUBLE(VALUE);'''
    
    result = preprocessor.preprocess(source)
    
    assert '42' in result
    assert '2' in result


def test_empty_macro():
    """Test empty macro definition."""
    preprocessor = Preprocessor()
    
    source = '''#define EMPTY
int x = 1 EMPTY + 2;'''
    
    result = preprocessor.preprocess(source)
    
    # EMPTY should expand to nothing
    assert 'int x = 1  + 2' in result or 'int x = 1 + 2' in result


def test_macro_with_no_arguments():
    """Test function-like macro with no arguments."""
    preprocessor = Preprocessor()
    
    source = '''#define GETVAL() 42
int x = GETVAL();'''
    
    result = preprocessor.preprocess(source)
    
    assert '42' in result


def test_macro_edge_case_whitespace():
    """Test macro with various whitespace."""
    preprocessor = Preprocessor()
    
    source = '''#define   SPACED   100  
int x = SPACED;'''
    
    result = preprocessor.preprocess(source)
    
    assert '100' in result


def test_multiple_macros():
    """Test multiple macro definitions."""
    preprocessor = Preprocessor()
    
    source = '''#define A 1
#define B 2
#define C 3
int sum = A + B + C;'''
    
    result = preprocessor.preprocess(source)
    
    assert '1' in result
    assert '2' in result
    assert '3' in result


def test_macro_redefine():
    """Test macro redefinition."""
    preprocessor = Preprocessor()
    
    source = '''#define MAX 100
int x = MAX;
#undef MAX
#define MAX 200
int y = MAX;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # First usage should be 100
    assert any('100' in line and 'int x' in line for line in lines)
    # Second usage should be 200
    assert any('200' in line and 'int y' in line for line in lines)


def test_stringification_with_spaces():
    """Test stringification with spaces in argument."""
    preprocessor = Preprocessor()
    
    source = '''#define STR(x) #x
char *s = STR(hello world);'''
    
    result = preprocessor.preprocess(source)
    
    assert '"hello world"' in result or '"hello  world"' in result


def test_token_pasting_numbers():
    """Test token pasting with numbers."""
    preprocessor = Preprocessor()
    
    source = '''#define MAKE_NUM(a, b) a##b
int x = MAKE_NUM(12, 34);'''
    
    result = preprocessor.preprocess(source)
    
    assert '1234' in result


def test_complex_macro_expression():
    """Test complex macro with multiple operations."""
    preprocessor = Preprocessor()
    
    source = '''#define MAX(a, b) ((a) > (b) ? (a) : (b))
int m = MAX(10, 20);'''
    
    result = preprocessor.preprocess(source)
    
    assert '10' in result
    assert '20' in result
    assert '>' in result
    assert '?' in result


# Conditional compilation tests

def test_ifdef_true():
    """Test #ifdef with defined macro."""
    preprocessor = Preprocessor()
    
    source = '''#define DEBUG
#ifdef DEBUG
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_ifdef_false():
    """Test #ifdef with undefined macro."""
    preprocessor = Preprocessor()
    
    source = '''#ifdef DEBUG
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be commented out
    assert '// int x = 1' in result
    assert 'int y = 2' in result


def test_ifndef_true():
    """Test #ifndef with undefined macro."""
    preprocessor = Preprocessor()
    
    source = '''#ifndef DEBUG
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_ifndef_false():
    """Test #ifndef with defined macro."""
    preprocessor = Preprocessor()
    
    source = '''#define DEBUG
#ifndef DEBUG
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be commented out
    assert '// int x = 1' in result
    assert 'int y = 2' in result


def test_if_true():
    """Test #if with true condition."""
    preprocessor = Preprocessor()
    
    source = '''#if 1
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_if_false():
    """Test #if with false condition."""
    preprocessor = Preprocessor()
    
    source = '''#if 0
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be commented out
    assert '// int x = 1' in result
    assert 'int y = 2' in result


def test_if_expression():
    """Test #if with expression."""
    preprocessor = Preprocessor()
    
    source = '''#define VALUE 10
#if VALUE > 5
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_if_else_true():
    """Test #if #else with true condition."""
    preprocessor = Preprocessor()
    
    source = '''#if 1
int x = 1;
#else
int x = 2;
#endif
int y = 3;'''
    
    result = preprocessor.preprocess(source)
    
    # First x should be included
    lines = result.split('\n')
    assert any('int x = 1' in line and not line.strip().startswith('//') for line in lines)
    # Second x should be commented out
    assert any('int x = 2' in line and line.strip().startswith('//') for line in lines)
    assert 'int y = 3' in result


def test_if_else_false():
    """Test #if #else with false condition."""
    preprocessor = Preprocessor()
    
    source = '''#if 0
int x = 1;
#else
int x = 2;
#endif
int y = 3;'''
    
    result = preprocessor.preprocess(source)
    
    # First x should be commented out
    lines = result.split('\n')
    assert any('int x = 1' in line and line.strip().startswith('//') for line in lines)
    # Second x should be included
    assert any('int x = 2' in line and not line.strip().startswith('//') for line in lines)
    assert 'int y = 3' in result


def test_if_elif_else():
    """Test #if #elif #else chain."""
    preprocessor = Preprocessor()
    
    source = '''#define VALUE 2
#if VALUE == 1
int x = 1;
#elif VALUE == 2
int x = 2;
#else
int x = 3;
#endif
int y = 4;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # First x should be commented out
    assert any('int x = 1' in line and line.strip().startswith('//') for line in lines)
    # Second x should be included
    assert any('int x = 2' in line and not line.strip().startswith('//') for line in lines)
    # Third x should be commented out
    assert any('int x = 3' in line and line.strip().startswith('//') for line in lines)
    assert 'int y = 4' in result


def test_nested_conditionals():
    """Test nested conditional directives."""
    preprocessor = Preprocessor()
    
    source = '''#define OUTER
#define INNER
#ifdef OUTER
int a = 1;
#ifdef INNER
int b = 2;
#endif
int c = 3;
#endif
int d = 4;'''
    
    result = preprocessor.preprocess(source)
    
    # All should be included
    assert 'int a = 1' in result
    assert 'int b = 2' in result
    assert 'int c = 3' in result
    assert 'int d = 4' in result


def test_nested_conditionals_outer_false():
    """Test nested conditionals with outer condition false."""
    preprocessor = Preprocessor()
    
    source = '''#define INNER
#ifdef OUTER
int a = 1;
#ifdef INNER
int b = 2;
#endif
int c = 3;
#endif
int d = 4;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # All inner code should be commented out
    assert any('int a = 1' in line and line.strip().startswith('//') for line in lines)
    assert any('int b = 2' in line and line.strip().startswith('//') for line in lines)
    assert any('int c = 3' in line and line.strip().startswith('//') for line in lines)
    # d should be included
    assert 'int d = 4' in result


def test_nested_conditionals_inner_false():
    """Test nested conditionals with inner condition false."""
    preprocessor = Preprocessor()
    
    source = '''#define OUTER
#ifdef OUTER
int a = 1;
#ifdef INNER
int b = 2;
#endif
int c = 3;
#endif
int d = 4;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # a and c should be included
    assert any('int a = 1' in line and not line.strip().startswith('//') for line in lines)
    assert any('int c = 3' in line and not line.strip().startswith('//') for line in lines)
    # b should be commented out
    assert any('int b = 2' in line and line.strip().startswith('//') for line in lines)
    # d should be included
    assert 'int d = 4' in result


def test_defined_operator_in_if():
    """Test 'defined' operator in #if."""
    preprocessor = Preprocessor()
    
    source = '''#define DEBUG
#if defined(DEBUG)
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_defined_operator_without_parens():
    """Test 'defined' operator without parentheses."""
    preprocessor = Preprocessor()
    
    source = '''#define DEBUG
#if defined DEBUG
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_defined_operator_false():
    """Test 'defined' operator with undefined macro."""
    preprocessor = Preprocessor()
    
    source = '''#if defined(DEBUG)
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be commented out
    assert '// int x = 1' in result
    assert 'int y = 2' in result


def test_defined_operator_negated():
    """Test negated 'defined' operator."""
    preprocessor = Preprocessor()
    
    source = '''#if !defined(DEBUG)
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_constant_expression_arithmetic():
    """Test constant expression with arithmetic."""
    preprocessor = Preprocessor()
    
    source = '''#if 2 + 3 > 4
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included (2 + 3 = 5 > 4)
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_constant_expression_logical():
    """Test constant expression with logical operators."""
    preprocessor = Preprocessor()
    
    source = '''#if 1 && 1
int x = 1;
#endif
#if 1 || 0
int y = 2;
#endif
#if 0 && 1
int z = 3;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # x and y should be included
    assert any('int x = 1' in line and not line.strip().startswith('//') for line in lines)
    assert any('int y = 2' in line and not line.strip().startswith('//') for line in lines)
    # z should be commented out
    assert any('int z = 3' in line and line.strip().startswith('//') for line in lines)


def test_constant_expression_with_macros():
    """Test constant expression with macro expansion."""
    preprocessor = Preprocessor()
    
    source = '''#define A 10
#define B 20
#if A < B
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be included (10 < 20)
    assert 'int x = 1' in result
    assert 'int y = 2' in result


def test_elif_first_true():
    """Test #elif with first condition true."""
    preprocessor = Preprocessor()
    
    source = '''#if 1
int x = 1;
#elif 1
int x = 2;
#endif
int y = 3;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # First x should be included
    assert any('int x = 1' in line and not line.strip().startswith('//') for line in lines)
    # Second x should be commented out
    assert any('int x = 2' in line and line.strip().startswith('//') for line in lines)


def test_elif_second_true():
    """Test #elif with second condition true."""
    preprocessor = Preprocessor()
    
    source = '''#if 0
int x = 1;
#elif 1
int x = 2;
#endif
int y = 3;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # First x should be commented out
    assert any('int x = 1' in line and line.strip().startswith('//') for line in lines)
    # Second x should be included
    assert any('int x = 2' in line and not line.strip().startswith('//') for line in lines)


def test_multiple_elif():
    """Test multiple #elif directives."""
    preprocessor = Preprocessor()
    
    source = '''#define VALUE 3
#if VALUE == 1
int x = 1;
#elif VALUE == 2
int x = 2;
#elif VALUE == 3
int x = 3;
#else
int x = 4;
#endif
int y = 5;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # Only third x should be included
    assert any('int x = 1' in line and line.strip().startswith('//') for line in lines)
    assert any('int x = 2' in line and line.strip().startswith('//') for line in lines)
    assert any('int x = 3' in line and not line.strip().startswith('//') for line in lines)
    assert any('int x = 4' in line and line.strip().startswith('//') for line in lines)


def test_include_guard_pattern():
    """Test typical include guard pattern."""
    preprocessor = Preprocessor()
    
    source = '''#ifndef HEADER_H
#define HEADER_H
int foo(void);
#endif'''
    
    result = preprocessor.preprocess(source)
    
    # foo should be included
    assert 'int foo(void)' in result


def test_conditional_with_include():
    """Test conditional compilation with includes."""
    preprocessor = Preprocessor()
    
    source = '''#define USE_STDIO
#ifdef USE_STDIO
#include <stdio.h>
#endif
int main() { return 0; }'''
    
    result = preprocessor.preprocess(source)
    
    # stdio functions should be included
    assert 'printf' in result
    assert 'main' in result


def test_conditional_skips_define():
    """Test that #define in false block doesn't define macro."""
    preprocessor = Preprocessor()
    
    source = '''#if 0
#define SKIP_ME
#endif
#ifdef SKIP_ME
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # x should be commented out (SKIP_ME not defined)
    assert any('int x = 1' in line and line.strip().startswith('//') for line in lines)
    assert 'int y = 2' in result


def test_undefined_identifier_in_expression():
    """Test that undefined identifiers evaluate to 0."""
    preprocessor = Preprocessor()
    
    source = '''#if UNDEFINED_MACRO
int x = 1;
#endif
int y = 2;'''
    
    result = preprocessor.preprocess(source)
    
    # x should be commented out (undefined evaluates to 0)
    assert '// int x = 1' in result
    assert 'int y = 2' in result


def test_complex_nested_conditionals():
    """Test complex nested conditional structure."""
    preprocessor = Preprocessor()
    
    source = '''#define LEVEL1
#ifdef LEVEL1
int a = 1;
#ifdef LEVEL2
int b = 2;
#else
int c = 3;
#ifdef LEVEL3
int d = 4;
#else
int e = 5;
#endif
#endif
int f = 6;
#endif
int g = 7;'''
    
    result = preprocessor.preprocess(source)
    
    lines = result.split('\n')
    # a, c, e, f, g should be included
    assert any('int a = 1' in line and not line.strip().startswith('//') for line in lines)
    assert any('int c = 3' in line and not line.strip().startswith('//') for line in lines)
    assert any('int e = 5' in line and not line.strip().startswith('//') for line in lines)
    assert any('int f = 6' in line and not line.strip().startswith('//') for line in lines)
    assert any('int g = 7' in line and not line.strip().startswith('//') for line in lines)
    # b, d should be commented out
    assert any('int b = 2' in line and line.strip().startswith('//') for line in lines)
    assert any('int d = 4' in line and line.strip().startswith('//') for line in lines)


def test_error_elif_without_if():
    """Test error for #elif without #if."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''#elif 1
int x = 1;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


def test_error_else_without_if():
    """Test error for #else without #if."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''#else
int x = 1;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


def test_error_endif_without_if():
    """Test error for #endif without #if."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''int x = 1;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


def test_error_duplicate_else():
    """Test error for duplicate #else."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''#if 1
int x = 1;
#else
int y = 2;
#else
int z = 3;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


def test_error_elif_after_else():
    """Test error for #elif after #else."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''#if 1
int x = 1;
#else
int y = 2;
#elif 1
int z = 3;
#endif'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


def test_error_unclosed_conditional():
    """Test error for unclosed conditional."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '''#if 1
int x = 1;'''
    
    result = preprocessor.preprocess(source)
    
    assert error_reporter.has_errors()


# Include system tests

def test_local_include_current_directory():
    """Test #include "file" searches current directory first."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a local header file
        header_path = os.path.join(tmpdir, 'local.h')
        with open(header_path, 'w') as f:
            f.write('int local_func(void);')
        
        # Create a source file that includes it
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "local.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        assert 'local_func' in result


def test_local_include_with_include_path():
    """Test #include "file" searches -I paths."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a subdirectory with a header
        include_dir = os.path.join(tmpdir, 'include')
        os.makedirs(include_dir)
        
        header_path = os.path.join(include_dir, 'myheader.h')
        with open(header_path, 'w') as f:
            f.write('int my_func(void);')
        
        # Create a source file in a different directory
        source_dir = os.path.join(tmpdir, 'src')
        os.makedirs(source_dir)
        source_path = os.path.join(source_dir, 'test.c')
        
        source = '#include "myheader.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        preprocessor.add_include_path(include_dir)
        result = preprocessor.preprocess(source, source_path)
        
        assert 'my_func' in result


def test_system_include_with_include_path():
    """Test #include <file> searches -I paths before system paths."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a custom "system" header in include path
        header_path = os.path.join(tmpdir, 'custom.h')
        with open(header_path, 'w') as f:
            f.write('int custom_func(void);')
        
        source = '#include <custom.h>\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        preprocessor.add_include_path(tmpdir)
        result = preprocessor.preprocess(source, 'test.c')
        
        assert 'custom_func' in result


def test_include_search_order_local():
    """Test that local includes search current dir before -I paths."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create header in include path
        include_dir = os.path.join(tmpdir, 'include')
        os.makedirs(include_dir)
        header1_path = os.path.join(include_dir, 'test.h')
        with open(header1_path, 'w') as f:
            f.write('int include_path_func(void);')
        
        # Create header in current directory (should take precedence)
        current_dir = os.path.join(tmpdir, 'src')
        os.makedirs(current_dir)
        header2_path = os.path.join(current_dir, 'test.h')
        with open(header2_path, 'w') as f:
            f.write('int current_dir_func(void);')
        
        source_path = os.path.join(current_dir, 'main.c')
        source = '#include "test.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        preprocessor.add_include_path(include_dir)
        result = preprocessor.preprocess(source, source_path)
        
        # Should find the one in current directory
        assert 'current_dir_func' in result
        assert 'include_path_func' not in result


def test_include_search_order_system():
    """Test that system includes don't search current directory."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create header in current directory
        current_dir = os.path.join(tmpdir, 'src')
        os.makedirs(current_dir)
        header_path = os.path.join(current_dir, 'test.h')
        with open(header_path, 'w') as f:
            f.write('int current_dir_func(void);')
        
        source_path = os.path.join(current_dir, 'main.c')
        source = '#include <test.h>\nint main() { return 0; }'
        
        error_reporter = ErrorReporter()
        preprocessor = Preprocessor(error_reporter)
        result = preprocessor.preprocess(source, source_path)
        
        # Should NOT find the file (system includes don't search current dir)
        assert error_reporter.has_errors()


def test_multiple_include_paths():
    """Test multiple -I paths are searched in order."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create two include directories
        include_dir1 = os.path.join(tmpdir, 'include1')
        include_dir2 = os.path.join(tmpdir, 'include2')
        os.makedirs(include_dir1)
        os.makedirs(include_dir2)
        
        # Create different headers in each
        header1_path = os.path.join(include_dir1, 'first.h')
        with open(header1_path, 'w') as f:
            f.write('int first_func(void);')
        
        header2_path = os.path.join(include_dir2, 'second.h')
        with open(header2_path, 'w') as f:
            f.write('int second_func(void);')
        
        source = '#include "first.h"\n#include "second.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        preprocessor.add_include_path(include_dir1)
        preprocessor.add_include_path(include_dir2)
        result = preprocessor.preprocess(source, 'test.c')
        
        assert 'first_func' in result
        assert 'second_func' in result


def test_pragma_once():
    """Test #pragma once prevents re-inclusion."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a header with #pragma once
        header_path = os.path.join(tmpdir, 'once.h')
        with open(header_path, 'w') as f:
            f.write('#pragma once\nint once_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "once.h"\n#include "once.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Should only include once
        assert result.count('once_func') == 1


def test_include_guard_detection():
    """Test detection of traditional include guards."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a header with traditional include guard
        header_path = os.path.join(tmpdir, 'guarded.h')
        with open(header_path, 'w') as f:
            f.write('''#ifndef GUARDED_H
#define GUARDED_H
int guarded_func(void);
#endif''')
        
        source_path = os.path.join(tmpdir, 'test.c')
        
        preprocessor = Preprocessor()
        
        # Read the header content
        with open(header_path, 'r') as f:
            content = f.read()
        
        # Detect the include guard
        guard = preprocessor._detect_include_guard(content, header_path)
        
        assert guard == 'GUARDED_H'


def test_include_guard_optimization():
    """Test that include guard optimization prevents re-reading."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a header with traditional include guard
        header_path = os.path.join(tmpdir, 'guarded.h')
        with open(header_path, 'w') as f:
            f.write('''#ifndef GUARDED_H
#define GUARDED_H
int guarded_func(void);
#endif''')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "guarded.h"\n#include "guarded.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Should only include once (guard prevents second inclusion)
        assert result.count('guarded_func') == 1


def test_include_guard_with_comments():
    """Test include guard detection with comments."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a header with comments before guard
        header_path = os.path.join(tmpdir, 'commented.h')
        with open(header_path, 'w') as f:
            f.write('''// Copyright notice
// More comments

#ifndef COMMENTED_H
#define COMMENTED_H

int commented_func(void);

#endif // COMMENTED_H''')
        
        preprocessor = Preprocessor()
        
        with open(header_path, 'r') as f:
            content = f.read()
        
        guard = preprocessor._detect_include_guard(content, header_path)
        
        assert guard == 'COMMENTED_H'


def test_include_guard_invalid_pattern():
    """Test that invalid include guard patterns are not detected."""
    preprocessor = Preprocessor()
    
    # Missing #define
    content1 = '''#ifndef GUARD_H
int func(void);
#endif'''
    assert preprocessor._detect_include_guard(content1, 'test.h') is None
    
    # Different macro names
    content2 = '''#ifndef GUARD_H
#define OTHER_H
int func(void);
#endif'''
    assert preprocessor._detect_include_guard(content2, 'test.h') is None
    
    # No #endif
    content3 = '''#ifndef GUARD_H
#define GUARD_H
int func(void);'''
    assert preprocessor._detect_include_guard(content3, 'test.h') is None


def test_nested_includes():
    """Test nested include files."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create header A that includes header B
        header_b_path = os.path.join(tmpdir, 'b.h')
        with open(header_b_path, 'w') as f:
            f.write('int b_func(void);')
        
        header_a_path = os.path.join(tmpdir, 'a.h')
        with open(header_a_path, 'w') as f:
            f.write('#include "b.h"\nint a_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "a.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        assert 'a_func' in result
        assert 'b_func' in result


def test_include_with_relative_path():
    """Test include with relative path."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create subdirectory structure
        subdir = os.path.join(tmpdir, 'subdir')
        os.makedirs(subdir)
        
        header_path = os.path.join(subdir, 'header.h')
        with open(header_path, 'w') as f:
            f.write('int sub_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "subdir/header.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        assert 'sub_func' in result


def test_include_standard_and_local():
    """Test mixing standard and local includes."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a local header
        header_path = os.path.join(tmpdir, 'local.h')
        with open(header_path, 'w') as f:
            f.write('int local_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '''#include <stdio.h>
#include "local.h"
int main() { return 0; }'''
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        assert 'printf' in result  # from stdio.h
        assert 'local_func' in result  # from local.h


def test_include_path_normalization():
    """Test that include paths are normalized correctly."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create header
        header_path = os.path.join(tmpdir, 'test.h')
        with open(header_path, 'w') as f:
            f.write('int test_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '#include "test.h"\n#include "test.h"\nint main() { return 0; }'
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Even without include guards, the basic circular include prevention
        # should prevent issues (though content may be duplicated)
        assert 'test_func' in result


def test_include_with_macro_in_guard():
    """Test include guard with macro expansion in guard name."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create header with include guard
        header_path = os.path.join(tmpdir, 'macro_guard.h')
        with open(header_path, 'w') as f:
            f.write('''#ifndef MACRO_GUARD_H
#define MACRO_GUARD_H
int macro_guard_func(void);
#endif''')
        
        source_path = os.path.join(tmpdir, 'test.c')
        # Include twice - second should be skipped
        source = '''#include "macro_guard.h"
#include "macro_guard.h"
int main() { return 0; }'''
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Function should appear only once
        assert result.count('macro_guard_func') == 1


def test_pragma_once_multiple_files():
    """Test #pragma once works independently for different files."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create two headers with #pragma once
        header1_path = os.path.join(tmpdir, 'once1.h')
        with open(header1_path, 'w') as f:
            f.write('#pragma once\nint once1_func(void);')
        
        header2_path = os.path.join(tmpdir, 'once2.h')
        with open(header2_path, 'w') as f:
            f.write('#pragma once\nint once2_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '''#include "once1.h"
#include "once2.h"
#include "once1.h"
#include "once2.h"
int main() { return 0; }'''
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Each function should appear only once
        assert result.count('once1_func') == 1
        assert result.count('once2_func') == 1


def test_include_error_message():
    """Test that include errors provide helpful messages."""
    error_reporter = ErrorReporter()
    preprocessor = Preprocessor(error_reporter)
    
    source = '#include "nonexistent_file_12345.h"\nint main() { return 0; }'
    result = preprocessor.preprocess(source, 'test.c')
    
    assert error_reporter.has_errors()
    # Check that error message mentions the file
    diagnostics = error_reporter.diagnostics
    assert len(diagnostics) > 0
    assert 'nonexistent_file_12345.h' in diagnostics[0].message


def test_include_system_paths_discovered():
    """Test that system include paths are discovered."""
    preprocessor = Preprocessor()
    
    # Should have discovered at least some system paths
    assert len(preprocessor.system_include_paths) > 0
    
    # Common paths should be present (if they exist on the system)
    import os
    if os.path.isdir('/usr/include'):
        assert '/usr/include' in preprocessor.system_include_paths


def test_include_with_conditional():
    """Test include inside conditional compilation."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a header
        header_path = os.path.join(tmpdir, 'conditional.h')
        with open(header_path, 'w') as f:
            f.write('int conditional_func(void);')
        
        source_path = os.path.join(tmpdir, 'test.c')
        source = '''#define USE_HEADER
#ifdef USE_HEADER
#include "conditional.h"
#endif
int main() { return 0; }'''
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        assert 'conditional_func' in result


def test_include_skipped_in_false_conditional():
    """Test that include in false conditional is not processed."""
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdir:
        source_path = os.path.join(tmpdir, 'test.c')
        source = '''#ifdef UNDEFINED_MACRO
#include "nonexistent.h"
#endif
int main() { return 0; }'''
        
        preprocessor = Preprocessor()
        result = preprocessor.preprocess(source, source_path)
        
        # Should not error on nonexistent file since it's in false block
        assert not preprocessor.error_reporter.has_errors()
        assert 'main' in result
