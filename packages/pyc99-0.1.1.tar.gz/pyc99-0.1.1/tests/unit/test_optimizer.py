"""Unit tests for optimizer passes."""

import pytest
from src.optimizer.optimizer import Optimizer, OptimizationPass, OptimizationLevel
from src.optimizer.constant_folding import ConstantFoldingPass
from src.optimizer.dead_code import DeadCodeEliminationPass
from src.optimizer.strength_reduction import StrengthReductionPass
from src.ir.ir_module import IRModule, IRFunction
from src.ir.basic_block import BasicBlock, ControlFlowGraph
from src.ir.ir_nodes import *
from src.parser.ast_nodes import PrimitiveType
from src.utils.source_location import SourceLocation


def make_int_type() -> PrimitiveType:
    """Helper to create an int type for testing."""
    return PrimitiveType(
        location=SourceLocation(filename="test", line=1, column=1),
        name="int"
    )


def make_ptr_type() -> PrimitiveType:
    """Helper to create a pointer type for testing."""
    return PrimitiveType(
        location=SourceLocation(filename="test", line=1, column=1),
        name="int*"
    )


def create_test_function(name: str = "test_func") -> IRFunction:
    """Helper to create a test function with basic structure.
    
    Args:
        name: Function name
        
    Returns:
        IRFunction with entry block
    """
    func = IRFunction(name=name, return_type=make_int_type())
    entry_block = BasicBlock(label=Label(name="entry"))
    func.add_basic_block(entry_block)
    return func


def create_test_module() -> IRModule:
    """Helper to create a test IR module.
    
    Returns:
        Empty IRModule
    """
    return IRModule(name="test_module")


class TestOptimizationFramework:
    """Test the optimization framework."""
    
    def test_optimizer_creation(self):
        """Test creating an optimizer."""
        optimizer = Optimizer(optimization_level=0)
        assert optimizer.optimization_level == OptimizationLevel.O0
    
    def test_optimizer_add_pass(self):
        """Test adding optimization passes."""
        optimizer = Optimizer(optimization_level=1)
        pass_instance = ConstantFoldingPass()
        optimizer.add_pass(pass_instance)
        assert len(optimizer.passes) == 1
    
    def test_optimizer_o0_no_optimization(self):
        """Test that O0 performs no optimization."""
        optimizer = Optimizer(optimization_level=0)
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Add a simple instruction
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[Constant(value=1, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Optimize
        result = optimizer.optimize(module)
        
        # Should be unchanged
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_optimizer_configure_for_level(self):
        """Test configuring optimizer for different levels."""
        optimizer = Optimizer()
        
        # Configure for O1
        optimizer.configure_for_level(1)
        assert optimizer.optimization_level == OptimizationLevel.O1
        assert len(optimizer.passes) == 3  # Constant folding, DCE, strength reduction
        
        # Configure for O0
        optimizer.configure_for_level(0)
        assert optimizer.optimization_level == OptimizationLevel.O0
        assert len(optimizer.passes) == 0
    
    def test_optimizer_run_passes_sequentially(self):
        """Test that passes run in sequence."""
        optimizer = Optimizer(optimization_level=1)
        optimizer.configure_for_level(1)
        
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Optimize
        result = optimizer.optimize(module)
        assert result is not None


class TestConstantFoldingPass:
    """Test constant folding optimization pass."""
    
    def test_constant_folding_addition(self):
        """Test folding constant addition."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 1 + 2
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[Constant(value=1, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        # Instruction should still exist but operands might be folded
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_folding_subtraction(self):
        """Test folding constant subtraction."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 10 - 5
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.SUB,
            result=reg1,
            operands=[Constant(value=10, value_type=make_int_type()),
                     Constant(value=5, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_folding_multiplication(self):
        """Test folding constant multiplication."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 3 * 4
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.MUL,
            result=reg1,
            operands=[Constant(value=3, value_type=make_int_type()),
                     Constant(value=4, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_folding_division(self):
        """Test folding constant division."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 10 / 2
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.DIV,
            result=reg1,
            operands=[Constant(value=10, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_folding_comparison(self):
        """Test folding constant comparisons."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 1 < 2
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.LT,
            result=reg1,
            operands=[Constant(value=1, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_folding_division_by_zero(self):
        """Test that division by zero is not folded."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create: result = 10 / 0
        reg1 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.DIV,
            result=reg1,
            operands=[Constant(value=10, value_type=make_int_type()),
                     Constant(value=0, value_type=make_int_type())]
        )
        func.get_all_blocks()[0].add_instruction(inst)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        # Should not crash, instruction remains
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 1
    
    def test_constant_propagation(self):
        """Test constant propagation through assignments."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = 5
        reg0 = func.allocate_register(make_int_type())
        inst1 = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg0,
            operands=[Constant(value=5, value_type=make_int_type()),
                     Constant(value=0, value_type=make_int_type())]
        )
        block.add_instruction(inst1)
        
        # Create: %1 = %0 + 3
        reg1 = func.allocate_register(make_int_type())
        inst2 = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[reg0, Constant(value=3, value_type=make_int_type())]
        )
        block.add_instruction(inst2)
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        # Both instructions should remain
        assert len(result.functions[0].get_all_blocks()[0].instructions) == 2



class TestDeadCodeEliminationPass:
    """Test dead code elimination optimization pass."""
    
    def test_remove_unreachable_blocks(self):
        """Test removing unreachable basic blocks."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        # Create entry block with unconditional branch
        entry_block = func.get_all_blocks()[0]
        reachable_block = BasicBlock(label=Label(name="reachable"))
        unreachable_block = BasicBlock(label=Label(name="unreachable"))
        
        func.add_basic_block(reachable_block)
        func.add_basic_block(unreachable_block)
        
        # Add branch from entry to reachable
        entry_block.add_instruction(IRInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[Label(name="reachable")]
        ))
        entry_block.add_successor(reachable_block)
        reachable_block.add_predecessor(entry_block)
        
        # unreachable_block has no predecessors
        
        # Apply DCE
        pass_instance = DeadCodeEliminationPass()
        result = pass_instance.run(module)
        
        # Unreachable block should be removed
        blocks = result.functions[0].get_all_blocks()
        block_names = [b.label.name for b in blocks]
        assert "entry" in block_names
        assert "reachable" in block_names
        assert "unreachable" not in block_names
    
    def test_remove_unused_assignments(self):
        """Test removing assignments to unused variables."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = 5 + 3 (unused)
        reg0 = func.allocate_register(make_int_type())
        inst1 = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg0,
            operands=[Constant(value=5, value_type=make_int_type()),
                     Constant(value=3, value_type=make_int_type())]
        )
        block.add_instruction(inst1)
        
        # Create: %1 = 10 + 20 (used in return)
        reg1 = func.allocate_register(make_int_type())
        inst2 = IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[Constant(value=10, value_type=make_int_type()),
                     Constant(value=20, value_type=make_int_type())]
        )
        block.add_instruction(inst2)
        
        # Create: return %1
        inst3 = IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[reg1]
        )
        block.add_instruction(inst3)
        
        # Apply DCE
        pass_instance = DeadCodeEliminationPass()
        result = pass_instance.run(module)
        
        # First instruction should be removed, second and third should remain
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 2  # Only inst2 and inst3
    
    def test_keep_side_effect_instructions(self):
        """Test that instructions with side effects are kept."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: store 42 to address (has side effect)
        addr = func.allocate_register(make_ptr_type())
        inst1 = IRInstruction(
            opcode=IROpcode.STORE,
            result=None,
            operands=[Constant(value=42, value_type=make_int_type()), addr]
        )
        block.add_instruction(inst1)
        
        # Create: call foo() (has side effect)
        void_type = PrimitiveType(
            location=SourceLocation(filename="test", line=1, column=1),
            name="void"
        )
        inst2 = IRInstruction(
            opcode=IROpcode.CALL,
            result=None,
            operands=[GlobalVariable(name="foo", value_type=void_type)]
        )
        block.add_instruction(inst2)
        
        # Apply DCE
        pass_instance = DeadCodeEliminationPass()
        result = pass_instance.run(module)
        
        # Both instructions should be kept
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 2
    
    def test_keep_terminator_instructions(self):
        """Test that terminator instructions are always kept."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: return (terminator)
        inst = IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[]
        )
        block.add_instruction(inst)
        
        # Apply DCE
        pass_instance = DeadCodeEliminationPass()
        result = pass_instance.run(module)
        
        # Return should be kept
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.RET


class TestStrengthReductionPass:
    """Test strength reduction optimization pass."""
    
    def test_multiply_by_power_of_two(self):
        """Test converting multiplication by power of 2 to shift."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = x * 8
        reg_x = func.allocate_register(make_int_type())
        reg0 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.MUL,
            result=reg0,
            operands=[reg_x, Constant(value=8, value_type=make_int_type())]
        )
        block.add_instruction(inst)
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Should be converted to SHL
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.SHL
        # Shift amount should be 3 (since 8 = 2^3)
        assert instructions[0].operands[1].value == 3
    
    def test_divide_by_power_of_two(self):
        """Test converting division by power of 2 to shift."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = x / 4
        reg_x = func.allocate_register(make_int_type())
        reg0 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.DIV,
            result=reg0,
            operands=[reg_x, Constant(value=4, value_type=make_int_type())]
        )
        block.add_instruction(inst)
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Should be converted to SHR
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.SHR
        # Shift amount should be 2 (since 4 = 2^2)
        assert instructions[0].operands[1].value == 2
    
    def test_modulo_by_power_of_two(self):
        """Test converting modulo by power of 2 to AND."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = x % 16
        reg_x = func.allocate_register(make_int_type())
        reg0 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.MOD,
            result=reg0,
            operands=[reg_x, Constant(value=16, value_type=make_int_type())]
        )
        block.add_instruction(inst)
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Should be converted to AND
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.AND
        # Mask should be 15 (16 - 1 = 0xF)
        assert instructions[0].operands[1].value == 15
    
    def test_no_reduction_for_non_power_of_two(self):
        """Test that non-power-of-2 operations are not reduced."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = x * 7 (not a power of 2)
        reg_x = func.allocate_register(make_int_type())
        reg0 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.MUL,
            result=reg0,
            operands=[reg_x, Constant(value=7, value_type=make_int_type())]
        )
        block.add_instruction(inst)
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Should remain as MUL
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.MUL
    
    def test_multiply_commutative(self):
        """Test that multiplication reduction works with operands swapped."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = 8 * x (constant on left)
        reg_x = func.allocate_register(make_int_type())
        reg0 = func.allocate_register(make_int_type())
        inst = IRInstruction(
            opcode=IROpcode.MUL,
            result=reg0,
            operands=[Constant(value=8, value_type=make_int_type()), reg_x]
        )
        block.add_instruction(inst)
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Should be converted to SHL
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.SHL


class TestOptimizationCorrectness:
    """Test that optimizations preserve program semantics."""
    
    def test_constant_folding_preserves_semantics(self):
        """Test that constant folding produces correct results."""
        pass_instance = ConstantFoldingPass()
        
        # Test various operations
        test_cases = [
            (IROpcode.ADD, 5, 3, 8),
            (IROpcode.SUB, 10, 4, 6),
            (IROpcode.MUL, 3, 7, 21),
            (IROpcode.DIV, 20, 4, 5),
            (IROpcode.MOD, 17, 5, 2),
        ]
        
        for opcode, left, right, expected in test_cases:
            result = pass_instance._evaluate_operation(
                opcode,
                [Constant(value=left, value_type=make_int_type()),
                 Constant(value=right, value_type=make_int_type())]
            )
            assert result is not None
            assert result.value == expected
    
    def test_strength_reduction_preserves_semantics(self):
        """Test that strength reduction produces equivalent operations."""
        pass_instance = StrengthReductionPass()
        
        # Test power of 2 detection
        assert pass_instance._get_power_of_two(
            Constant(value=1, value_type=make_int_type())
        ) == 0
        assert pass_instance._get_power_of_two(
            Constant(value=2, value_type=make_int_type())
        ) == 1
        assert pass_instance._get_power_of_two(
            Constant(value=4, value_type=make_int_type())
        ) == 2
        assert pass_instance._get_power_of_two(
            Constant(value=8, value_type=make_int_type())
        ) == 3
        assert pass_instance._get_power_of_two(
            Constant(value=16, value_type=make_int_type())
        ) == 4
        
        # Non-powers of 2 should return None
        assert pass_instance._get_power_of_two(
            Constant(value=3, value_type=make_int_type())
        ) is None
        assert pass_instance._get_power_of_two(
            Constant(value=7, value_type=make_int_type())
        ) is None


class TestOptimizationEffectiveness:
    """Test that optimizations actually improve code."""
    
    def test_constant_folding_reduces_operations(self):
        """Test that constant folding can reduce operation count."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create a chain of constant operations
        # %0 = 1 + 2
        # %1 = %0 + 3
        # %2 = %1 + 4
        # return %2
        
        reg0 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.ADD,
            result=reg0,
            operands=[Constant(value=1, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        ))
        
        reg1 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[reg0, Constant(value=3, value_type=make_int_type())]
        ))
        
        reg2 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.ADD,
            result=reg2,
            operands=[reg1, Constant(value=4, value_type=make_int_type())]
        ))
        
        block.add_instruction(IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[reg2]
        ))
        
        # Apply constant folding
        pass_instance = ConstantFoldingPass()
        result = pass_instance.run(module)
        
        # Instructions should still be there but with folded constants
        instructions = result.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 4
    
    def test_dce_reduces_instruction_count(self):
        """Test that DCE reduces instruction count."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create several unused instructions
        for i in range(5):
            reg = func.allocate_register(make_int_type())
            block.add_instruction(IRInstruction(
                opcode=IROpcode.ADD,
                result=reg,
                operands=[Constant(value=i, value_type=make_int_type()),
                         Constant(value=i+1, value_type=make_int_type())]
            ))
        
        # Add a return that doesn't use any of them
        block.add_instruction(IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[Constant(value=42, value_type=make_int_type())]
        ))
        
        initial_count = len(block.instructions)
        
        # Apply DCE
        pass_instance = DeadCodeEliminationPass()
        result = pass_instance.run(module)
        
        # Should remove unused instructions
        final_count = len(result.functions[0].get_all_blocks()[0].instructions)
        assert final_count < initial_count
        assert final_count == 1  # Only return should remain
    
    def test_strength_reduction_improves_performance(self):
        """Test that strength reduction replaces expensive operations."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create expensive operations that can be reduced
        reg_x = func.allocate_register(make_int_type())
        
        # x * 16 -> x << 4
        reg0 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.MUL,
            result=reg0,
            operands=[reg_x, Constant(value=16, value_type=make_int_type())]
        ))
        
        # x / 8 -> x >> 3
        reg1 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.DIV,
            result=reg1,
            operands=[reg_x, Constant(value=8, value_type=make_int_type())]
        ))
        
        # Apply strength reduction
        pass_instance = StrengthReductionPass()
        result = pass_instance.run(module)
        
        # Check that operations were replaced
        instructions = result.functions[0].get_all_blocks()[0].instructions
        opcodes = [inst.opcode for inst in instructions]
        
        # Should have shifts instead of mul/div
        assert IROpcode.SHL in opcodes
        assert IROpcode.SHR in opcodes
        assert IROpcode.MUL not in opcodes
        assert IROpcode.DIV not in opcodes


class TestCombinedOptimizations:
    """Test multiple optimization passes working together."""
    
    def test_constant_folding_then_dce(self):
        """Test constant folding followed by DCE."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        # Create: %0 = 1 + 2 (can be folded, result unused)
        reg0 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.ADD,
            result=reg0,
            operands=[Constant(value=1, value_type=make_int_type()),
                     Constant(value=2, value_type=make_int_type())]
        ))
        
        # Create: return 42
        block.add_instruction(IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[Constant(value=42, value_type=make_int_type())]
        ))
        
        # Apply both passes
        cf_pass = ConstantFoldingPass()
        dce_pass = DeadCodeEliminationPass()
        
        module = cf_pass.run(module)
        module = dce_pass.run(module)
        
        # Should only have return instruction
        instructions = module.functions[0].get_all_blocks()[0].instructions
        assert len(instructions) == 1
        assert instructions[0].opcode == IROpcode.RET
    
    def test_full_optimization_pipeline(self):
        """Test full optimization pipeline with all passes."""
        module = create_test_module()
        func = create_test_function()
        module.add_function(func)
        
        block = func.get_all_blocks()[0]
        
        reg_x = func.allocate_register(make_int_type())
        
        # Create: %0 = x * 8 (can be strength reduced)
        reg0 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.MUL,
            result=reg0,
            operands=[reg_x, Constant(value=8, value_type=make_int_type())]
        ))
        
        # Create: %1 = 5 + 3 (can be folded, unused)
        reg1 = func.allocate_register(make_int_type())
        block.add_instruction(IRInstruction(
            opcode=IROpcode.ADD,
            result=reg1,
            operands=[Constant(value=5, value_type=make_int_type()),
                     Constant(value=3, value_type=make_int_type())]
        ))
        
        # Create: return %0
        block.add_instruction(IRInstruction(
            opcode=IROpcode.RET,
            result=None,
            operands=[reg0]
        ))
        
        # Apply all optimizations
        optimizer = Optimizer(optimization_level=1)
        optimizer.configure_for_level(1)
        result = optimizer.optimize(module)
        
        # Check results
        instructions = result.functions[0].get_all_blocks()[0].instructions
        
        # Should have: SHL (from strength reduction), RET
        # The unused ADD should be removed by DCE
        assert len(instructions) == 2
        
        # First instruction should be SHL (strength reduced from MUL)
        assert instructions[0].opcode == IROpcode.SHL
        
        # Last instruction should be RET
        assert instructions[1].opcode == IROpcode.RET
