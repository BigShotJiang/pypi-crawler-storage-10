"""Integration tests for standard library support."""

import pytest
import tempfile
import os
import subprocess
from pathlib import Path

from src.driver.compiler_driver import CompilerDriver, CompilerOptions, CompilationPhase
from src.driver.toolchain import Toolchain


def test_hello_world_with_printf():
    """Test compiling a hello world program using printf."""
    source_code = '''#include <stdio.h>

int main() {
    printf("Hello, World!\\n");
    return 0;
}
'''
    
    with tempfile.TemporaryDirectory() as tmpdir:
        # Write source file
        source_file = os.path.join(tmpdir, 'hello.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Compile to assembly
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            verbose=False
        )
        
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        # Check compilation succeeded
        assert result.success, "Compilation should succeed"
        assert result.output is not None, "Should generate assembly code"
        assert 'printf' in result.output, "Should reference printf"
        assert 'main' in result.output, "Should have main function"
        
        # Verify the assembly contains proper function call setup
        assert 'call' in result.output, "Should have call instruction"


def test_stdlib_malloc_free():
    """Test that stdlib.h declarations are included."""
    source_code = '''#include <stdlib.h>

int main() {
    return 0;
}
'''
    
    with tempfile.TemporaryDirectory() as tmpdir:
        source_file = os.path.join(tmpdir, 'malloc_test.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Test preprocessing phase
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            stop_after=CompilationPhase.PREPROCESSING
        )
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, "Preprocessing should succeed"
        assert 'malloc' in result.output, "Should include malloc declaration"
        assert 'free' in result.output, "Should include free declaration"


def test_string_functions():
    """Test that string.h declarations are included."""
    source_code = '''#include <string.h>

int main() {
    return 0;
}
'''
    
    with tempfile.TemporaryDirectory() as tmpdir:
        source_file = os.path.join(tmpdir, 'string_test.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Test preprocessing phase
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            stop_after=CompilationPhase.PREPROCESSING
        )
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, "Preprocessing should succeed"
        assert 'strlen' in result.output, "Should include strlen declaration"
        assert 'strcpy' in result.output, "Should include strcpy declaration"
        assert 'strcmp' in result.output, "Should include strcmp declaration"


def test_math_functions():
    """Test that math.h declarations are included."""
    source_code = '''#include <math.h>

int main() {
    return 0;
}
'''
    
    with tempfile.TemporaryDirectory() as tmpdir:
        source_file = os.path.join(tmpdir, 'math_test.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Test preprocessing phase
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            stop_after=CompilationPhase.PREPROCESSING
        )
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, "Preprocessing should succeed"
        assert 'sqrt' in result.output, "Should include sqrt declaration"
        assert 'sin' in result.output, "Should include sin declaration"
        assert 'cos' in result.output, "Should include cos declaration"


def test_multiple_stdlib_headers():
    """Test including multiple standard library headers."""
    source_code = '''#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    return 0;
}
'''
    
    with tempfile.TemporaryDirectory() as tmpdir:
        source_file = os.path.join(tmpdir, 'multi_test.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Test preprocessing phase
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            stop_after=CompilationPhase.PREPROCESSING
        )
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, "Preprocessing should succeed"
        assert 'malloc' in result.output, "Should include stdlib declarations"
        assert 'strcpy' in result.output, "Should include string declarations"
        assert 'printf' in result.output, "Should include stdio declarations"
        assert 'free' in result.output, "Should include stdlib declarations"


def test_preprocessor_include_paths():
    """Test custom include paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create a custom header
        header_dir = os.path.join(tmpdir, 'include')
        os.makedirs(header_dir)
        
        header_file = os.path.join(header_dir, 'custom.h')
        with open(header_file, 'w') as f:
            f.write('int custom_function(int x);')
        
        # Create source that includes custom header
        source_code = '''#include "custom.h"

int main() {
    int result = custom_function(42);
    return 0;
}

int custom_function(int x) {
    return x * 2;
}
'''
        
        source_file = os.path.join(tmpdir, 'test.c')
        with open(source_file, 'w') as f:
            f.write(source_code)
        
        # Compile with custom include path
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            include_paths=[header_dir]
        )
        
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, "Compilation should succeed with custom include path"
        assert 'custom_function' in result.output


def test_libc_linking_configuration():
    """Test that toolchain is configured to link against libc."""
    toolchain = Toolchain('x86', verbose=False)
    
    # Verify that the toolchain has the link_libc parameter
    # and that it can find a linker
    linker = toolchain._find_x86_linker()
    assert linker is not None, "Should find a linker"
    
    # Verify linker args include libc support
    args = toolchain._get_x86_linker_args(['test.o'], 'test', link_libc=True)
    assert 'test.o' in args, "Should include object file"
    assert 'test' in args, "Should include output file"
    
    # When link_libc is False, should include -nostdlib
    args_no_libc = toolchain._get_x86_linker_args(['test.o'], 'test', link_libc=False)
    assert '-nostdlib' in args_no_libc, "Should include -nostdlib when link_libc=False"
    
    toolchain.cleanup()
