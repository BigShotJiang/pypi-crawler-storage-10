"""End-to-end integration tests for the C99 compiler.

Tests compile, assemble, link, and execute complete C programs,
verifying the output matches expected results.
"""

import pytest
import tempfile
import os
import subprocess
import platform
from pathlib import Path

from src.driver.compiler_driver import CompilerDriver, CompilerOptions, CompilationPhase
from src.driver.toolchain import Toolchain


def compile_and_run(source_file, target='x86', optimization_level=0):
    """Helper function to compile and run a C program.
    
    Args:
        source_file: Path to the C source file
        target: Target architecture ('x86' or 'arm')
        optimization_level: Optimization level (0-1)
    
    Returns:
        tuple: (success, stdout, stderr, return_code)
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        output_file = os.path.join(tmpdir, 'program')
        asm_file = os.path.join(tmpdir, 'program.s')
        obj_file = os.path.join(tmpdir, 'program.o')
        
        # Compile to assembly
        options = CompilerOptions(
            target=target,
            optimization_level=optimization_level,
            output_file=asm_file,
            verbose=False
        )
        
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        if not result.success:
            errors = str(result.error_reporter) if result.error_reporter else "Unknown error"
            return False, "", errors, -1
        
        # Write assembly to file
        with open(asm_file, 'w') as f:
            f.write(result.output)
        
        # Assemble and link
        toolchain = Toolchain(target, verbose=False)
        
        try:
            # Assemble
            assemble_result = toolchain.assemble(asm_file, obj_file)
            
            if not assemble_result.success:
                return False, "", assemble_result.stderr, -1
            
            # Link
            link_result = toolchain.link([obj_file], output_file, link_libc=True)
            
            if not link_result.success:
                return False, "", link_result.stderr, -1
            
            # Execute
            if target == 'arm' and platform.machine() != 'aarch64' and platform.machine() != 'armv7l':
                # Use QEMU for ARM on non-ARM platforms
                cmd = ['qemu-arm', '-L', '/usr/arm-linux-gnueabihf', output_file]
            else:
                cmd = [output_file]
            
            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                return True, proc.stdout, proc.stderr, proc.returncode
            except subprocess.TimeoutExpired:
                return False, "", "Program execution timed out", -1
            except FileNotFoundError:
                if target == 'arm':
                    # QEMU not available, skip ARM test
                    pytest.skip("QEMU not available for ARM testing")
                raise
        
        finally:
            toolchain.cleanup()


class TestHelloWorld:
    """Test hello world program."""
    
    def test_hello_world_x86(self):
        """Test hello world on x86."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='x86')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"
        assert "Hello, World!" in stdout, f"Expected output not found. Got: {stdout}"
    
    def test_hello_world_arm(self):
        """Test hello world on ARM."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='arm')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"
        assert "Hello, World!" in stdout, f"Expected output not found. Got: {stdout}"


class TestFibonacci:
    """Test fibonacci program."""
    
    def test_fibonacci_x86(self):
        """Test fibonacci on x86."""
        source_file = 'examples/fibonacci.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='x86')
        
        assert success, f"Compilation/execution failed: {stderr}"
        # Fibonacci(10) = 55, which is the return code
        assert returncode == 55, f"Program returned {returncode}, expected 55"
    
    def test_fibonacci_arm(self):
        """Test fibonacci on ARM."""
        source_file = 'examples/fibonacci.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='arm')
        
        assert success, f"Compilation/execution failed: {stderr}"
        # Fibonacci(10) = 55, which is the return code
        assert returncode == 55, f"Program returned {returncode}, expected 55"
    
    def test_fibonacci_optimized(self):
        """Test fibonacci with optimization."""
        source_file = 'examples/fibonacci.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(
            source_file, target='x86', optimization_level=1
        )
        
        assert success, f"Compilation/execution failed: {stderr}"
        # Fibonacci(10) = 55, which is the return code
        assert returncode == 55, f"Program returned {returncode}, expected 55"


class TestFactorial:
    """Test factorial program."""
    
    def test_factorial_x86(self):
        """Test factorial on x86."""
        source_file = 'examples/factorial.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='x86')
        
        assert success, f"Compilation/execution failed: {stderr}"
        # Factorial(5) = 120, which is the return code
        assert returncode == 120, f"Program returned {returncode}, expected 120"
    
    def test_factorial_arm(self):
        """Test factorial on ARM."""
        source_file = 'examples/factorial.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='arm')
        
        assert success, f"Compilation/execution failed: {stderr}"
        # Factorial(5) = 120, which is the return code
        assert returncode == 120, f"Program returned {returncode}, expected 120"


class TestStructExample:
    """Test struct manipulation program."""
    
    @pytest.mark.skip(reason="Struct support not fully implemented yet")
    def test_struct_example_x86(self):
        """Test struct example on x86."""
        source_file = 'examples/struct_example.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='x86')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"
    
    @pytest.mark.skip(reason="Struct support not fully implemented yet")
    def test_struct_example_arm(self):
        """Test struct example on ARM."""
        source_file = 'examples/struct_example.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='arm')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"


class TestArrayExample:
    """Test array operations program."""
    
    @pytest.mark.skip(reason="Array support not fully implemented yet")
    def test_array_example_x86(self):
        """Test array example on x86."""
        source_file = 'examples/array_example.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='x86')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"
    
    @pytest.mark.skip(reason="Array support not fully implemented yet")
    def test_array_example_arm(self):
        """Test array example on ARM."""
        source_file = 'examples/array_example.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        success, stdout, stderr, returncode = compile_and_run(source_file, target='arm')
        
        assert success, f"Compilation/execution failed: {stderr}"
        assert returncode == 0, f"Program returned non-zero: {returncode}"


class TestCompilationPhases:
    """Test stopping at different compilation phases."""
    
    def test_stop_at_assembly(self):
        """Test stopping after assembly generation."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        with tempfile.TemporaryDirectory() as tmpdir:
            asm_file = os.path.join(tmpdir, 'hello.s')
            
            options = CompilerOptions(
                target='x86',
                optimization_level=0,
                output_file=asm_file,
                stop_after=CompilationPhase.CODE_GENERATION,
                verbose=False
            )
            
            driver = CompilerDriver(options)
            result = driver.compile(source_file)
            
            assert result.success, f"Compilation failed: {result.errors}"
            assert result.output is not None, "Should generate assembly"
            assert 'main' in result.output, "Should contain main function"
    
    def test_stop_at_ir(self):
        """Test stopping after IR generation."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            stop_after=CompilationPhase.IR_GENERATION,
            verbose=False
        )
        
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, f"Compilation failed: {result.error_reporter}"
        assert result.output is not None, "Should generate IR output"
    
    def test_optimization_levels(self):
        """Test different optimization levels."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        # Compile with O0
        options_o0 = CompilerOptions(
            target='x86',
            optimization_level=0,
            verbose=False
        )
        driver_o0 = CompilerDriver(options_o0)
        result_o0 = driver_o0.compile(source_file)
        
        assert result_o0.success, "O0 compilation should succeed"
        
        # Compile with O1
        options_o1 = CompilerOptions(
            target='x86',
            optimization_level=1,
            verbose=False
        )
        driver_o1 = CompilerDriver(options_o1)
        result_o1 = driver_o1.compile(source_file)
        
        assert result_o1.success, "O1 compilation should succeed"
        
        # Both should produce valid assembly
        assert 'main' in result_o0.output, "O0 should contain main function"
        assert 'main' in result_o1.output, "O1 should contain main function"


class TestErrorHandling:
    """Test error handling and reporting."""
    
    def test_syntax_error(self):
        """Test that syntax errors are properly reported."""
        source_code = '''
int main() {
    int x = 5
    return 0;
}
'''
        
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = os.path.join(tmpdir, 'syntax_error.c')
            with open(source_file, 'w') as f:
                f.write(source_code)
            
            options = CompilerOptions(
                target='x86',
                optimization_level=0,
                verbose=False
            )
            
            driver = CompilerDriver(options)
            result = driver.compile(source_file)
            
            assert not result.success, "Compilation should fail"
            assert result.error_reporter is not None, "Should have error reporter"
            assert result.error_reporter.has_errors(), "Should have error messages"
    
    def test_compilation_phases_complete(self):
        """Test that all compilation phases can complete successfully."""
        source_file = 'examples/hello_world.c'
        
        if not os.path.exists(source_file):
            pytest.skip(f"Source file {source_file} not found")
        
        options = CompilerOptions(
            target='x86',
            optimization_level=0,
            verbose=False
        )
        
        driver = CompilerDriver(options)
        result = driver.compile(source_file)
        
        assert result.success, f"Compilation should succeed: {result.error_reporter}"
        assert result.output is not None, "Should generate assembly code"
        assert 'main' in result.output, "Should contain main function"
