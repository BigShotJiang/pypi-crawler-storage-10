"""Integration tests for array compilation (lexer -> parser -> semantic -> IR -> codegen)."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.codegen.x86.x86_codegen import X86CodeGenerator
from src.codegen.arm.arm_codegen import ARMCodeGenerator
from src.utils.error_reporter import ErrorReporter


def compile_code(code: str, target='x86'):
    """Compile code through the full pipeline.
    
    Args:
        code: C source code
        target: Target architecture ('x86' or 'arm')
        
    Returns:
        tuple: (success, assembly_code, error_reporter)
    """
    # Tokenize
    tokenizer = Tokenizer(code, 'test.c')
    
    # Parse
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    # Semantic analysis
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    ast = analyzer.analyze()
    
    if error_reporter.has_errors():
        return False, None, error_reporter
    
    # Generate IR
    generator = IRGenerator(ast, error_reporter)
    ir_module = generator.generate()
    
    if error_reporter.has_errors():
        return False, None, error_reporter
    
    # Generate assembly
    if target == 'x86':
        codegen = X86CodeGenerator(ir_module)
    elif target == 'arm':
        codegen = ARMCodeGenerator(ir_module)
    else:
        raise ValueError(f"Unknown target: {target}")
    
    asm_code = codegen.generate()
    
    return True, asm_code, error_reporter


class TestBasicArrayCompilation:
    """Test basic array compilation."""
    
    def test_simple_array_declaration(self):
        """Test compiling simple array declaration."""
        code = '''
        int main() {
            int arr[10];
            return 0;
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Simple array declaration should compile"
        assert asm is not None
        assert 'main:' in asm
    
    def test_array_initialization_and_access(self):
        """Test compiling array initialization and access."""
        code = '''
        int main() {
            int arr[5];
            arr[0] = 10;
            arr[1] = 20;
            return arr[0];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array initialization and access should compile"
        assert asm is not None
        # Check for array operations in assembly
        assert 'mov' in asm.lower()
    
    def test_array_arithmetic(self):
        """Test compiling array arithmetic."""
        code = '''
        int main() {
            int arr[3];
            arr[0] = 5;
            arr[1] = 10;
            arr[2] = 15;
            return arr[0] + arr[1] + arr[2];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array arithmetic should compile"
        assert asm is not None
        assert 'add' in asm.lower()


class TestMultiDimensionalArrayCompilation:
    """Test multi-dimensional array compilation."""
    
    def test_2d_array_compilation(self):
        """Test compiling 2D array."""
        code = '''
        int main() {
            int matrix[2][3];
            matrix[0][0] = 1;
            matrix[1][2] = 6;
            return matrix[0][0] + matrix[1][2];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "2D array should compile"
        assert asm is not None
    
    def test_3d_array_compilation(self):
        """Test compiling 3D array."""
        code = '''
        int main() {
            int cube[2][2][2];
            cube[0][0][0] = 1;
            cube[1][1][1] = 8;
            return cube[0][0][0] + cube[1][1][1];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "3D array should compile"
        assert asm is not None


class TestArrayInLoops:
    """Test array compilation in loops."""
    
    def test_array_in_for_loop(self):
        """Test compiling array operations in for loop."""
        code = '''
        int main() {
            int arr[10];
            int i;
            int sum;
            sum = 0;
            for (i = 0; i < 10; i = i + 1) {
                arr[i] = i;
                sum = sum + arr[i];
            }
            return sum;
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array in for loop should compile"
        assert asm is not None
    
    def test_array_in_while_loop(self):
        """Test compiling array operations in while loop."""
        code = '''
        int main() {
            int arr[5];
            int i;
            i = 0;
            while (i < 5) {
                arr[i] = i * 2;
                i = i + 1;
            }
            return arr[4];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array in while loop should compile"
        assert asm is not None


class TestArrayWithDifferentTypes:
    """Test array compilation with different element types."""
    
    def test_char_array_compilation(self):
        """Test compiling char array."""
        code = '''
        int main() {
            char arr[10];
            arr[0] = 'a';
            arr[1] = 'b';
            return arr[0];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Char array should compile"
        assert asm is not None
    
    def test_float_array_compilation(self):
        """Test compiling float array."""
        code = '''
        int main() {
            float arr[5];
            arr[0] = 1.0;
            arr[1] = 2.0;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Float array should compile"
        assert asm is not None


class TestArrayCodegenX86:
    """Test x86-specific array code generation."""
    
    def test_x86_array_addressing(self):
        """Test x86 array addressing modes."""
        code = '''
        int main() {
            int arr[5];
            arr[2] = 42;
            return arr[2];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "x86 array addressing should work"
        assert asm is not None
        # Check for x86-specific instructions
        assert any(instr in asm.lower() for instr in ['lea', 'mov', 'add'])
    
    def test_x86_array_with_variable_index(self):
        """Test x86 array with variable index."""
        code = '''
        int main() {
            int arr[10];
            int i;
            i = 5;
            arr[i] = 100;
            return arr[i];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "x86 variable index should work"
        assert asm is not None
        # Should have multiplication for scaling
        assert 'imul' in asm.lower()


class TestArrayCodegenARM:
    """Test ARM-specific array code generation."""
    
    def test_arm_array_addressing(self):
        """Test ARM array addressing modes."""
        code = '''
        int main() {
            int arr[5];
            arr[2] = 42;
            return arr[2];
        }
        '''
        success, asm, _ = compile_code(code, 'arm')
        assert success, "ARM array addressing should work"
        assert asm is not None
        # Check for ARM-specific instructions
        assert any(instr in asm.lower() for instr in ['ldr', 'str', 'add'])
    
    def test_arm_array_with_variable_index(self):
        """Test ARM array with variable index."""
        code = '''
        int main() {
            int arr[10];
            int i;
            i = 5;
            arr[i] = 100;
            return arr[i];
        }
        '''
        success, asm, _ = compile_code(code, 'arm')
        assert success, "ARM variable index should work"
        assert asm is not None
        # Should have multiplication for scaling
        assert 'mul' in asm.lower()


class TestArrayEdgeCases:
    """Test edge cases in array compilation."""
    
    def test_array_with_zero_index(self):
        """Test array with index 0."""
        code = '''
        int main() {
            int arr[5];
            arr[0] = 42;
            return arr[0];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array with zero index should compile"
        assert asm is not None
    
    def test_array_with_last_index(self):
        """Test array with last valid index."""
        code = '''
        int main() {
            int arr[10];
            arr[9] = 99;
            return arr[9];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array with last index should compile"
        assert asm is not None
    
    def test_nested_array_indexing(self):
        """Test nested array indexing: arr[arr[i]]."""
        code = '''
        int main() {
            int arr[10];
            int i;
            i = 2;
            arr[i] = 5;
            arr[arr[i]] = 100;
            return arr[5];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Nested array indexing should compile"
        assert asm is not None


class TestArrayComplexExpressions:
    """Test arrays with complex expressions."""
    
    def test_array_index_with_arithmetic(self):
        """Test array index with arithmetic expression."""
        code = '''
        int main() {
            int arr[10];
            int i;
            i = 2;
            arr[i + 1] = 42;
            return arr[3];
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array index with arithmetic should compile"
        assert asm is not None
    
    def test_array_in_complex_expression(self):
        """Test array in complex expression."""
        code = '''
        int main() {
            int arr1[5];
            int arr2[5];
            arr1[0] = 10;
            arr1[1] = 20;
            arr2[0] = 5;
            arr2[1] = 15;
            return (arr1[0] + arr2[0]) * (arr1[1] - arr2[1]);
        }
        '''
        success, asm, _ = compile_code(code, 'x86')
        assert success, "Array in complex expression should compile"
        assert asm is not None


class TestArrayCompilationBothTargets:
    """Test that arrays compile correctly for both x86 and ARM."""
    
    def test_same_code_both_targets(self):
        """Test that same code compiles for both targets."""
        code = '''
        int main() {
            int arr[5];
            arr[0] = 1;
            arr[1] = 2;
            arr[2] = 3;
            return arr[0] + arr[1] + arr[2];
        }
        '''
        success_x86, asm_x86, _ = compile_code(code, 'x86')
        success_arm, asm_arm, _ = compile_code(code, 'arm')
        
        assert success_x86, "Should compile for x86"
        assert success_arm, "Should compile for ARM"
        assert asm_x86 is not None
        assert asm_arm is not None
        assert asm_x86 != asm_arm, "x86 and ARM assembly should be different"
    
    def test_multidimensional_both_targets(self):
        """Test multi-dimensional arrays compile for both targets."""
        code = '''
        int main() {
            int matrix[3][3];
            matrix[0][0] = 1;
            matrix[1][1] = 5;
            matrix[2][2] = 9;
            return matrix[1][1];
        }
        '''
        success_x86, asm_x86, _ = compile_code(code, 'x86')
        success_arm, asm_arm, _ = compile_code(code, 'arm')
        
        assert success_x86, "Multi-dimensional array should compile for x86"
        assert success_arm, "Multi-dimensional array should compile for ARM"


class TestArrayIRGeneration:
    """Test IR generation for arrays."""
    
    def test_array_ir_has_alloca(self):
        """Test that array IR contains ALLOCA instruction."""
        code = '''
        int main() {
            int arr[10];
            return 0;
        }
        '''
        tokenizer = Tokenizer(code, 'test.c')
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        ast = analyzer.analyze()
        
        generator = IRGenerator(ast, error_reporter)
        ir_module = generator.generate()
        
        # Check that IR contains ALLOCA
        func = list(ir_module.get_functions())[0]
        blocks = func.get_all_blocks()
        instructions = [instr for block in blocks for instr in block.instructions]
        
        assert any('ALLOCA' in str(instr) for instr in instructions), \
            "IR should contain ALLOCA instruction for array"
    
    def test_array_indexing_ir_has_arithmetic(self):
        """Test that array indexing IR contains pointer arithmetic."""
        code = '''
        int main() {
            int arr[10];
            arr[5] = 42;
            return 0;
        }
        '''
        tokenizer = Tokenizer(code, 'test.c')
        parser = Parser(tokenizer)
        ast = parser.parse_translation_unit()
        
        error_reporter = ErrorReporter()
        analyzer = SemanticAnalyzer(ast, error_reporter)
        ast = analyzer.analyze()
        
        generator = IRGenerator(ast, error_reporter)
        ir_module = generator.generate()
        
        # Check that IR contains MUL and ADD for pointer arithmetic
        func = list(ir_module.get_functions())[0]
        blocks = func.get_all_blocks()
        instructions = [instr for block in blocks for instr in block.instructions]
        
        has_mul = any('MUL' in str(instr) for instr in instructions)
        has_add = any('ADD' in str(instr) for instr in instructions)
        
        assert has_mul, "IR should contain MUL for index scaling"
        assert has_add, "IR should contain ADD for address calculation"
