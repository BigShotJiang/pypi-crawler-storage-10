"""Integration tests for pointer compilation."""

import pytest
from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.codegen.x86.x86_codegen import X86CodeGenerator
from src.codegen.arm.arm_codegen import ARMCodeGenerator
from src.utils.error_reporter import ErrorReporter


def compile_code(code: str, target='x86'):
    """Compile code through the full pipeline."""
    tokenizer = Tokenizer(code, 'test.c')
    parser = Parser(tokenizer)
    ast = parser.parse_translation_unit()
    
    error_reporter = ErrorReporter()
    analyzer = SemanticAnalyzer(ast, error_reporter)
    ast = analyzer.analyze()
    
    if error_reporter.has_errors():
        return False, None, error_reporter
    
    generator = IRGenerator(ast, error_reporter)
    ir_module = generator.generate()
    
    if error_reporter.has_errors():
        return False, None, error_reporter
    
    if target == 'x86':
        codegen = X86CodeGenerator(ir_module)
    elif target == 'arm':
        codegen = ARMCodeGenerator(ir_module)
    else:
        raise ValueError(f"Unknown target: {target}")
    
    asm_code = codegen.generate()
    return True, asm_code, error_reporter


class TestPointerDeclarations:
    """Test pointer declaration compilation."""
    
    def test_simple_pointer_declaration(self):
        """Test simple pointer declaration."""
        code = '''
        int main() {
            int *p;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Simple pointer declaration should compile"
        assert asm is not None
    
    def test_pointer_to_pointer(self):
        """Test pointer-to-pointer declaration."""
        code = '''
        int main() {
            int **pp;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer-to-pointer should compile"
        assert asm is not None
    
    def test_multiple_pointer_types(self):
        """Test multiple pointer types."""
        code = '''
        int main() {
            int *ip;
            char *cp;
            float *fp;
            void *vp;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Multiple pointer types should compile"
        assert asm is not None


class TestAddressOfOperator:
    """Test address-of operator (&) compilation."""
    
    def test_address_of_variable(self):
        """Test taking address of variable."""
        code = '''
        int main() {
            int x;
            int *p;
            x = 42;
            p = &x;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Address-of variable should compile"
        assert asm is not None
    
    def test_address_of_array_element(self):
        """Test taking address of array element."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = &arr[5];
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Address-of array element should compile"
        assert asm is not None
    
    def test_nested_address_of(self):
        """Test nested address-of operations."""
        code = '''
        int main() {
            int x;
            int *p;
            int **pp;
            x = 42;
            p = &x;
            pp = &p;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Nested address-of should compile"
        assert asm is not None


class TestDereferenceOperator:
    """Test dereference operator (*) compilation."""
    
    def test_simple_dereference(self):
        """Test simple pointer dereference."""
        code = '''
        int main() {
            int x;
            int *p;
            int y;
            x = 42;
            p = &x;
            y = *p;
            return y;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Simple dereference should compile"
        assert asm is not None
    
    def test_dereference_assignment(self):
        """Test assignment through pointer."""
        code = '''
        int main() {
            int x;
            int *p;
            x = 10;
            p = &x;
            *p = 42;
            return x;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Dereference assignment should compile"
        assert asm is not None
    
    def test_double_dereference(self):
        """Test double dereference."""
        code = '''
        int main() {
            int x;
            int *p;
            int **pp;
            int y;
            x = 42;
            p = &x;
            pp = &p;
            y = **pp;
            return y;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Double dereference should compile"
        assert asm is not None


class TestPointerArithmetic:
    """Test pointer arithmetic compilation."""
    
    def test_pointer_plus_integer(self):
        """Test pointer + integer."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr + 5;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer + integer should compile"
        assert asm is not None
    
    def test_pointer_minus_integer(self):
        """Test pointer - integer."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr + 8;
            p = p - 3;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer - integer should compile"
        assert asm is not None
    
    def test_integer_plus_pointer(self):
        """Test integer + pointer (commutative)."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = 5 + arr;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Integer + pointer should compile"
        assert asm is not None
    
    def test_pointer_difference(self):
        """Test pointer - pointer."""
        code = '''
        int main() {
            int arr[10];
            int *p1;
            int *p2;
            long diff;
            p1 = arr;
            p2 = arr + 5;
            diff = p2 - p1;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer difference should compile"
        assert asm is not None
    
    def test_pointer_increment(self):
        """Test pointer increment."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr;
            p++;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer increment should compile"
        assert asm is not None
    
    def test_pointer_decrement(self):
        """Test pointer decrement."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr + 5;
            p--;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer decrement should compile"
        assert asm is not None


class TestPointerWithArrays:
    """Test pointers with arrays."""
    
    def test_array_to_pointer_decay(self):
        """Test array-to-pointer decay."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr;
            return 0;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Array-to-pointer decay should compile"
        assert asm is not None
    
    def test_pointer_indexing(self):
        """Test pointer indexing like array."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            int x;
            p = arr;
            x = p[5];
            return x;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer indexing should compile"
        assert asm is not None
    
    def test_pointer_arithmetic_with_dereference(self):
        """Test pointer arithmetic with dereference."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            int x;
            p = arr;
            x = *(p + 5);
            return x;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer arithmetic with dereference should compile"
        assert asm is not None


class TestPointerInLoops:
    """Test pointers in loops."""
    
    def test_pointer_iteration(self):
        """Test iterating with pointers."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            int sum;
            sum = 0;
            p = arr;
            int i;
            for (i = 0; i < 10; i = i + 1) {
                sum = sum + *p;
                p++;
            }
            return sum;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer iteration should compile"
        assert asm is not None
    
    def test_pointer_comparison_in_loop(self):
        """Test pointer comparison in loop."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            int *end;
            int sum;
            sum = 0;
            p = arr;
            end = arr + 10;
            while (p < end) {
                sum = sum + *p;
                p++;
            }
            return sum;
        }
        '''
        success, asm, _ = compile_code(code)
        # This might fail if pointer comparison isn't fully implemented
        # assert success, "Pointer comparison in loop should compile"


class TestComplexPointerOperations:
    """Test complex pointer operations."""
    
    def test_pointer_swap(self):
        """Test swapping values through pointers."""
        code = '''
        int main() {
            int x;
            int y;
            int *px;
            int *py;
            int temp;
            x = 10;
            y = 20;
            px = &x;
            py = &y;
            temp = *px;
            *px = *py;
            *py = temp;
            return x;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer swap should compile"
        assert asm is not None
    
    def test_pointer_chain(self):
        """Test chain of pointer operations."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            int *q;
            int *r;
            p = arr + 2;
            q = p + 3;
            r = q - 1;
            *r = 42;
            return *r;
        }
        '''
        success, asm, _ = compile_code(code)
        assert success, "Pointer chain should compile"
        assert asm is not None


class TestPointerCodegenBothTargets:
    """Test pointer compilation for both x86 and ARM."""
    
    def test_pointer_operations_both_targets(self):
        """Test that pointer operations compile for both targets."""
        code = '''
        int main() {
            int x;
            int *p;
            int y;
            x = 42;
            p = &x;
            y = *p;
            return y;
        }
        '''
        success_x86, asm_x86, _ = compile_code(code, 'x86')
        success_arm, asm_arm, _ = compile_code(code, 'arm')
        
        assert success_x86, "Should compile for x86"
        assert success_arm, "Should compile for ARM"
        assert asm_x86 is not None
        assert asm_arm is not None
    
    def test_pointer_arithmetic_both_targets(self):
        """Test pointer arithmetic for both targets."""
        code = '''
        int main() {
            int arr[10];
            int *p;
            p = arr + 5;
            p = p - 2;
            return *p;
        }
        '''
        success_x86, asm_x86, _ = compile_code(code, 'x86')
        success_arm, asm_arm, _ = compile_code(code, 'arm')
        
        assert success_x86, "Pointer arithmetic should compile for x86"
        assert success_arm, "Pointer arithmetic should compile for ARM"
