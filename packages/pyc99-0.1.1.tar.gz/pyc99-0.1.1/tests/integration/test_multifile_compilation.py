"""Integration tests for multi-file compilation.

Tests separate compilation of multiple C files, extern declarations,
static linkage, and linking multiple object files together.
"""

import pytest
import tempfile
import os
import subprocess
import platform
from pathlib import Path

from src.driver.compiler_driver import CompilerDriver, CompilerOptions
from src.driver.toolchain import Toolchain


def compile_multiple_files(source_files, target='x86', optimization_level=0):
    """Helper function to compile and link multiple C files.
    
    Args:
        source_files: List of paths to C source files
        target: Target architecture ('x86' or 'arm')
        optimization_level: Optimization level (0-1)
    
    Returns:
        tuple: (success, stdout, stderr, return_code)
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        output_file = os.path.join(tmpdir, 'program')
        object_files = []
        
        # Compile each source file to object file
        options = CompilerOptions(
            target=target,
            optimization_level=optimization_level,
            verbose=False
        )
        
        driver = CompilerDriver(options)
        toolchain = Toolchain(target, verbose=False)
        
        try:
            for i, source_file in enumerate(source_files):
                asm_file = os.path.join(tmpdir, f'file{i}.s')
                obj_file = os.path.join(tmpdir, f'file{i}.o')
                
                # Compile to assembly
                result = driver.compile(source_file)
                
                if not result.success:
                    errors = str(result.error_reporter) if result.error_reporter else "Unknown error"
                    return False, "", errors, -1
                
                # Write assembly to file
                with open(asm_file, 'w') as f:
                    f.write(result.output)
                
                # Assemble
                assemble_result = toolchain.assemble(asm_file, obj_file)
                
                if not assemble_result.success:
                    return False, "", assemble_result.stderr, -1
                
                object_files.append(obj_file)
            
            # Link all object files
            link_result = toolchain.link(object_files, output_file, link_libc=True)
            
            if not link_result.success:
                return False, "", link_result.stderr, -1
            
            # Execute
            if target == 'arm' and platform.machine() not in ('aarch64', 'armv7l'):
                # Use QEMU for ARM on non-ARM platforms
                cmd = ['qemu-arm', '-L', '/usr/arm-linux-gnueabihf', output_file]
            else:
                cmd = [output_file]
            
            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                return True, proc.stdout, proc.stderr, proc.returncode
            except subprocess.TimeoutExpired:
                return False, "", "Program execution timed out", -1
            except FileNotFoundError:
                if target == 'arm':
                    # QEMU not available, skip ARM test
                    pytest.skip("QEMU not available for ARM testing")
                raise
        
        finally:
            toolchain.cleanup()


class TestExternDeclarations:
    """Test extern declarations across files."""
    
    def test_extern_variable(self):
        """Test extern variable declaration and usage."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Define global variable
            file1 = os.path.join(tmpdir, 'globals.c')
            with open(file1, 'w') as f:
                f.write("""
int global_value = 42;
""")
            
            # File 2: Use extern variable
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int global_value;

int main() {
    printf("%d\\n", global_value);
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "42", f"Expected '42', got '{stdout.strip()}'"
    
    def test_extern_function(self):
        """Test extern function declaration and usage."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Define function
            file1 = os.path.join(tmpdir, 'utils.c')
            with open(file1, 'w') as f:
                f.write("""
int add(int a, int b) {
    return a + b;
}
""")
            
            # File 2: Use extern function
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int add(int a, int b);

int main() {
    int result = add(10, 20);
    printf("%d\\n", result);
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "30", f"Expected '30', got '{stdout.strip()}'"
    
    def test_multiple_extern_variables(self):
        """Test multiple extern variables across files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Define global variables
            file1 = os.path.join(tmpdir, 'globals.c')
            with open(file1, 'w') as f:
                f.write("""
int x = 10;
int y = 20;
int z = 30;
""")
            
            # File 2: Use extern variables
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int x;
extern int y;
extern int z;

int main() {
    printf("%d\\n", x + y + z);
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "60", f"Expected '60', got '{stdout.strip()}'"


class TestStaticLinkage:
    """Test static linkage."""
    
    def test_static_function(self):
        """Test static function is not visible outside file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Define static function
            file1 = os.path.join(tmpdir, 'utils.c')
            with open(file1, 'w') as f:
                f.write("""
static int helper() {
    return 42;
}

int get_value() {
    return helper();
}
""")
            
            # File 2: Use public function
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int get_value();

int main() {
    printf("%d\\n", get_value());
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "42", f"Expected '42', got '{stdout.strip()}'"
    
    def test_static_variable(self):
        """Test static variable is not visible outside file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Define static variable and accessor
            file1 = os.path.join(tmpdir, 'counter.c')
            with open(file1, 'w') as f:
                f.write("""
static int counter = 0;

int increment() {
    counter++;
    return counter;
}

int get_counter() {
    return counter;
}
""")
            
            # File 2: Use accessor functions
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int increment();
extern int get_counter();

int main() {
    increment();
    increment();
    increment();
    printf("%d\\n", get_counter());
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "3", f"Expected '3', got '{stdout.strip()}'"


class TestMultiFilePrograms:
    """Test complete multi-file programs."""
    
    def test_calculator_program(self):
        """Test a simple calculator split across multiple files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Math operations
            file1 = os.path.join(tmpdir, 'math_ops.c')
            with open(file1, 'w') as f:
                f.write("""
int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

int divide(int a, int b) {
    if (b == 0) return 0;
    return a / b;
}
""")
            
            # File 2: Main program
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int add(int a, int b);
extern int subtract(int a, int b);
extern int multiply(int a, int b);
extern int divide(int a, int b);

int main() {
    int x = 10;
    int y = 5;
    
    printf("%d\\n", add(x, y));
    printf("%d\\n", subtract(x, y));
    printf("%d\\n", multiply(x, y));
    printf("%d\\n", divide(x, y));
    
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            
            lines = stdout.strip().split('\n')
            assert len(lines) == 4, f"Expected 4 lines of output, got {len(lines)}"
            assert lines[0] == "15", f"Expected '15', got '{lines[0]}'"
            assert lines[1] == "5", f"Expected '5', got '{lines[1]}'"
            assert lines[2] == "50", f"Expected '50', got '{lines[2]}'"
            assert lines[3] == "2", f"Expected '2', got '{lines[3]}'"
    
    def test_three_file_program(self):
        """Test program split across three files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Data
            file1 = os.path.join(tmpdir, 'data.c')
            with open(file1, 'w') as f:
                f.write("""
int numbers[5] = {1, 2, 3, 4, 5};
int count = 5;
""")
            
            # File 2: Processing
            file2 = os.path.join(tmpdir, 'process.c')
            with open(file2, 'w') as f:
                f.write("""
extern int numbers[];
extern int count;

int sum_array() {
    int sum = 0;
    int i;
    for (i = 0; i < count; i++) {
        sum = sum + numbers[i];
    }
    return sum;
}
""")
            
            # File 3: Main
            file3 = os.path.join(tmpdir, 'main.c')
            with open(file3, 'w') as f:
                f.write("""
#include <stdio.h>

extern int sum_array();

int main() {
    printf("%d\\n", sum_array());
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2, file3])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "15", f"Expected '15', got '{stdout.strip()}'"
    
    def test_struct_across_files(self):
        """Test struct definition shared across files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1: Struct operations
            file1 = os.path.join(tmpdir, 'point.c')
            with open(file1, 'w') as f:
                f.write("""
struct Point {
    int x;
    int y;
};

struct Point create_point(int x, int y) {
    struct Point p;
    p.x = x;
    p.y = y;
    return p;
}

int distance_squared(struct Point p) {
    return p.x * p.x + p.y * p.y;
}
""")
            
            # File 2: Main
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

struct Point {
    int x;
    int y;
};

extern struct Point create_point(int x, int y);
extern int distance_squared(struct Point p);

int main() {
    struct Point p = create_point(3, 4);
    printf("%d\\n", distance_squared(p));
    return 0;
}
""")
            
            success, stdout, stderr, returncode = compile_multiple_files([file1, file2])
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "25", f"Expected '25', got '{stdout.strip()}'"


class TestLinking:
    """Test linking behavior."""
    
    def test_link_order_independence(self):
        """Test that link order doesn't matter for simple cases."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # File 1
            file1 = os.path.join(tmpdir, 'func.c')
            with open(file1, 'w') as f:
                f.write("""
int get_value() {
    return 100;
}
""")
            
            # File 2
            file2 = os.path.join(tmpdir, 'main.c')
            with open(file2, 'w') as f:
                f.write("""
#include <stdio.h>

extern int get_value();

int main() {
    printf("%d\\n", get_value());
    return 0;
}
""")
            
            # Try both link orders
            success1, stdout1, stderr1, returncode1 = compile_multiple_files([file1, file2])
            success2, stdout2, stderr2, returncode2 = compile_multiple_files([file2, file1])
            
            assert success1, f"Compilation failed (order 1): {stderr1}"
            assert success2, f"Compilation failed (order 2): {stderr2}"
            assert stdout1.strip() == stdout2.strip() == "100"
    
    def test_multiple_object_files(self):
        """Test linking many object files together."""
        with tempfile.TemporaryDirectory() as tmpdir:
            files = []
            
            # Create 5 files with functions
            for i in range(5):
                filename = os.path.join(tmpdir, f'func{i}.c')
                with open(filename, 'w') as f:
                    f.write(f"""
int func{i}() {{
    return {i * 10};
}}
""")
                files.append(filename)
            
            # Main file
            main_file = os.path.join(tmpdir, 'main.c')
            with open(main_file, 'w') as f:
                f.write("""
#include <stdio.h>

extern int func0();
extern int func1();
extern int func2();
extern int func3();
extern int func4();

int main() {
    int sum = func0() + func1() + func2() + func3() + func4();
    printf("%d\\n", sum);
    return 0;
}
""")
            files.append(main_file)
            
            success, stdout, stderr, returncode = compile_multiple_files(files)
            
            assert success, f"Compilation failed: {stderr}"
            assert returncode == 0, f"Program returned {returncode}"
            assert stdout.strip() == "100", f"Expected '100', got '{stdout.strip()}'"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
