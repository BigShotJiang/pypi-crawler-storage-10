"""C preprocessor for handling #include and other directives."""

import os
import re
from dataclasses import dataclass
from typing import List, Optional, Set, Dict, Tuple
from pathlib import Path
from datetime import datetime

from src.utils.error_reporter import ErrorReporter
from src.utils.source_location import SourceLocation


@dataclass
class PreprocessorDirective:
    """Represents a preprocessor directive.
    
    Attributes:
        type: Type of directive ('include', 'define', 'ifdef', etc.)
        content: Content of the directive
        location: Source location
    """
    type: str
    content: str
    location: SourceLocation


@dataclass
class ConditionalState:
    """Tracks the state of conditional compilation.
    
    Attributes:
        condition_met: Whether the current condition is true
        else_seen: Whether an #else has been seen in this block
        skip_mode: Whether we're currently skipping code
    """
    condition_met: bool
    else_seen: bool
    skip_mode: bool


@dataclass
class Macro:
    """Represents a preprocessor macro.
    
    Attributes:
        name: Macro name
        parameters: List of parameter names (None for object-like macros)
        replacement: Replacement token list
        is_function_like: True if function-like macro
        location: Source location where defined
    """
    name: str
    parameters: Optional[List[str]]
    replacement: List[str]
    is_function_like: bool
    location: SourceLocation


class Preprocessor:
    """Handles C preprocessor directives.
    
    This preprocessor focuses on #include directives for standard library
    support. It locates system headers and processes include directives.
    
    Attributes:
        error_reporter: Error reporter for diagnostics
        include_paths: List of directories to search for headers
        system_include_paths: List of system include directories
        included_files: Set of already included files (for include guards)
    """
    
    # Standard C library headers
    STANDARD_HEADERS = {
        'assert.h', 'ctype.h', 'errno.h', 'float.h', 'limits.h',
        'locale.h', 'math.h', 'setjmp.h', 'signal.h', 'stdarg.h',
        'stddef.h', 'stdio.h', 'stdlib.h', 'string.h', 'time.h',
        'iso646.h', 'wchar.h', 'wctype.h', 'stdbool.h', 'stdint.h',
        'inttypes.h', 'tgmath.h', 'complex.h', 'fenv.h'
    }
    
    # Standard library function declarations (simplified subset)
    # Note: Simplified to avoid const qualifiers and variadic functions
    # which the parser doesn't fully support yet
    STDLIB_DECLARATIONS = {
        'stdio.h': '''
int printf(char *format);
int scanf(char *format);
int fprintf(void *stream, char *format);
int sprintf(char *str, char *format);
int snprintf(char *str, unsigned long size, char *format);
int puts(char *str);
int putchar(int c);
int getchar(void);
char *fgets(char *str, int n, void *stream);
void *fopen(char *filename, char *mode);
int fclose(void *stream);
int feof(void *stream);
int ferror(void *stream);
void clearerr(void *stream);
unsigned long fread(void *ptr, unsigned long size, unsigned long nmemb, void *stream);
unsigned long fwrite(void *ptr, unsigned long size, unsigned long nmemb, void *stream);
int fseek(void *stream, long offset, int whence);
long ftell(void *stream);
void rewind(void *stream);
''',
        'stdlib.h': '''
void *malloc(unsigned long size);
void *calloc(unsigned long nmemb, unsigned long size);
void *realloc(void *ptr, unsigned long size);
void free(void *ptr);
void exit(int status);
int atoi(char *str);
long atol(char *str);
double atof(char *str);
int abs(int n);
long labs(long n);
int rand(void);
void srand(unsigned int seed);
char *getenv(char *name);
int system(char *command);
''',
        'string.h': '''
unsigned long strlen(char *str);
char *strcpy(char *dest, char *src);
char *strncpy(char *dest, char *src, unsigned long n);
char *strcat(char *dest, char *src);
char *strncat(char *dest, char *src, unsigned long n);
int strcmp(char *s1, char *s2);
int strncmp(char *s1, char *s2, unsigned long n);
char *strchr(char *str, int c);
char *strrchr(char *str, int c);
char *strstr(char *haystack, char *needle);
void *memcpy(void *dest, void *src, unsigned long n);
void *memmove(void *dest, void *src, unsigned long n);
void *memset(void *s, int c, unsigned long n);
int memcmp(void *s1, void *s2, unsigned long n);
''',
        'math.h': '''
double sin(double x);
double cos(double x);
double tan(double x);
double asin(double x);
double acos(double x);
double atan(double x);
double atan2(double y, double x);
double sinh(double x);
double cosh(double x);
double tanh(double x);
double exp(double x);
double log(double x);
double log10(double x);
double pow(double x, double y);
double sqrt(double x);
double ceil(double x);
double floor(double x);
double fabs(double x);
double fmod(double x, double y);
''',
        'ctype.h': '''
int isalnum(int c);
int isalpha(int c);
int isdigit(int c);
int isxdigit(int c);
int islower(int c);
int isupper(int c);
int isspace(int c);
int ispunct(int c);
int isprint(int c);
int isgraph(int c);
int iscntrl(int c);
int tolower(int c);
int toupper(int c);
''',
        'stddef.h': '''
typedef unsigned long size_t;
typedef long ptrdiff_t;
''',
        'stdint.h': '''
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
''',
        'stdbool.h': '''
typedef int bool;
''',
    }
    
    def __init__(self, error_reporter: Optional[ErrorReporter] = None):
        """Initialize preprocessor.
        
        Args:
            error_reporter: Error reporter for diagnostics
        """
        self.error_reporter = error_reporter or ErrorReporter()
        self.include_paths: List[str] = []
        self.system_include_paths: List[str] = []
        self.included_files: Set[str] = set()
        self.macros: Dict[str, Macro] = {}
        self.conditional_stack: List[ConditionalState] = []
        
        # Include guard optimization
        self.pragma_once_files: Set[str] = set()
        self.include_guard_macros: Dict[str, str] = {}  # file -> guard macro name
        
        # Initialize predefined macros
        self._init_predefined_macros()
        
        # Discover system include paths
        self._discover_system_includes()
    
    def _init_predefined_macros(self):
        """Initialize predefined macros."""
        # C99 standard macros
        self._define_macro('__STDC__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
        self._define_macro('__STDC_VERSION__', [], ['199901L'], False, SourceLocation('<builtin>', 0, 0))
        
        # Context-dependent macros (handled specially during expansion)
        self._define_macro('__FILE__', [], [], False, SourceLocation('<builtin>', 0, 0))
        self._define_macro('__LINE__', [], [], False, SourceLocation('<builtin>', 0, 0))
        self._define_macro('__DATE__', [], [], False, SourceLocation('<builtin>', 0, 0))
        self._define_macro('__TIME__', [], [], False, SourceLocation('<builtin>', 0, 0))
        
        # Platform-specific macros (simplified)
        import platform
        system = platform.system()
        if system == 'Linux':
            self._define_macro('__linux__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
            self._define_macro('__unix__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
        elif system == 'Darwin':
            self._define_macro('__APPLE__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
            self._define_macro('__MACH__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
            self._define_macro('__unix__', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
        elif system == 'Windows':
            self._define_macro('_WIN32', [], ['1'], False, SourceLocation('<builtin>', 0, 0))
    
    def _define_macro(self, name: str, parameters: Optional[List[str]], 
                     replacement: List[str], is_function_like: bool,
                     location: SourceLocation):
        """Define a macro.
        
        Args:
            name: Macro name
            parameters: Parameter names (None for object-like)
            replacement: Replacement tokens
            is_function_like: True if function-like macro
            location: Source location
        """
        self.macros[name] = Macro(
            name=name,
            parameters=parameters,
            replacement=replacement,
            is_function_like=is_function_like,
            location=location
        )
    
    def _undefine_macro(self, name: str):
        """Undefine a macro.
        
        Args:
            name: Macro name to undefine
        """
        if name in self.macros:
            del self.macros[name]
    
    def _parse_define_directive(self, content: str, location: SourceLocation) -> Optional[Macro]:
        """Parse a #define directive.
        
        Args:
            content: Content after #define
            location: Source location
            
        Returns:
            Parsed Macro object, or None on error
        """
        content = content.strip()
        if not content:
            self.error_reporter.error(location, "Empty #define directive")
            return None
        
        # Check for function-like macro: NAME(params)
        func_match = re.match(r'^(\w+)\s*\(([^)]*)\)\s*(.*)', content)
        if func_match:
            name = func_match.group(1)
            params_str = func_match.group(2).strip()
            replacement_str = func_match.group(3).strip()
            
            # Parse parameters
            parameters = []
            if params_str:
                parameters = [p.strip() for p in params_str.split(',')]
                # Validate parameter names
                for param in parameters:
                    if not re.match(r'^\w+$', param):
                        self.error_reporter.error(
                            location,
                            f"Invalid macro parameter name: {param}"
                        )
                        return None
            
            # Tokenize replacement
            replacement = self._tokenize_replacement(replacement_str)
            
            return Macro(
                name=name,
                parameters=parameters,
                replacement=replacement,
                is_function_like=True,
                location=location
            )
        
        # Object-like macro: NAME replacement
        obj_match = re.match(r'^(\w+)\s*(.*)', content)
        if obj_match:
            name = obj_match.group(1)
            replacement_str = obj_match.group(2).strip()
            
            # Tokenize replacement
            replacement = self._tokenize_replacement(replacement_str)
            
            return Macro(
                name=name,
                parameters=None,
                replacement=replacement,
                is_function_like=False,
                location=location
            )
        
        self.error_reporter.error(location, f"Invalid #define directive: {content}")
        return None
    
    def _tokenize_replacement(self, text: str) -> List[str]:
        """Tokenize macro replacement text.
        
        Args:
            text: Replacement text
            
        Returns:
            List of tokens
        """
        if not text:
            return []
        
        tokens = []
        i = 0
        
        while i < len(text):
            # Skip whitespace
            if text[i].isspace():
                i += 1
                continue
            
            # Check for ## (token pasting)
            if i + 1 < len(text) and text[i:i+2] == '##':
                tokens.append('##')
                i += 2
                continue
            
            # Check for identifiers
            if text[i].isalpha() or text[i] == '_':
                j = i
                while j < len(text) and (text[j].isalnum() or text[j] == '_'):
                    j += 1
                tokens.append(text[i:j])
                i = j
                continue
            
            # Check for numbers
            if text[i].isdigit():
                j = i
                while j < len(text) and (text[j].isdigit() or text[j] == '.'):
                    j += 1
                tokens.append(text[i:j])
                i = j
                continue
            
            # Single character token
            tokens.append(text[i])
            i += 1
        
        return tokens
    
    def _expand_macros_in_line(self, line: str, filename: str, line_num: int) -> str:
        """Expand all macros in a line of code.
        
        Args:
            line: Line of code
            filename: Source filename
            line_num: Line number
            
        Returns:
            Line with macros expanded
        """
        # Track which macros are currently being expanded to prevent recursion
        expanding = set()
        return self._expand_macros(line, filename, line_num, expanding)
    
    def _expand_macros(self, text: str, filename: str, line_num: int, 
                      expanding: Set[str]) -> str:
        """Recursively expand macros in text.
        
        Args:
            text: Text to expand
            filename: Source filename
            line_num: Line number
            expanding: Set of macro names currently being expanded
            
        Returns:
            Text with macros expanded
        """
        result = []
        i = 0
        
        while i < len(text):
            # Try to match an identifier
            if text[i].isalpha() or text[i] == '_':
                # Extract identifier
                j = i
                while j < len(text) and (text[j].isalnum() or text[j] == '_'):
                    j += 1
                identifier = text[i:j]
                
                # Check if it's a macro
                if identifier in self.macros and identifier not in expanding:
                    macro = self.macros[identifier]
                    
                    if macro.is_function_like:
                        # Look for opening parenthesis
                        k = j
                        while k < len(text) and text[k].isspace():
                            k += 1
                        
                        if k < len(text) and text[k] == '(':
                            # Parse arguments
                            args, end_pos = self._parse_macro_arguments(text, k)
                            if args is not None:
                                # Expand function-like macro
                                expanded = self._expand_function_macro(
                                    macro, args, filename, line_num, expanding
                                )
                                result.append(expanded)
                                i = end_pos
                                continue
                    else:
                        # Expand object-like macro
                        expanded = self._expand_object_macro(
                            macro, filename, line_num, expanding
                        )
                        result.append(expanded)
                        i = j
                        continue
                
                # Not a macro or already expanding
                result.append(identifier)
                i = j
            else:
                result.append(text[i])
                i += 1
        
        return ''.join(result)
    
    def _parse_macro_arguments(self, text: str, start: int) -> Tuple[Optional[List[str]], int]:
        """Parse macro function arguments.
        
        Args:
            text: Text containing macro call
            start: Position of opening parenthesis
            
        Returns:
            Tuple of (argument list, end position) or (None, start) on error
        """
        if start >= len(text) or text[start] != '(':
            return None, start
        
        args = []
        current_arg = []
        paren_depth = 0
        i = start + 1
        
        while i < len(text):
            c = text[i]
            
            if c == '(':
                paren_depth += 1
                current_arg.append(c)
            elif c == ')':
                if paren_depth == 0:
                    # End of arguments
                    arg_text = ''.join(current_arg).strip()
                    if arg_text or len(args) > 0:
                        args.append(arg_text)
                    return args, i + 1
                else:
                    paren_depth -= 1
                    current_arg.append(c)
            elif c == ',' and paren_depth == 0:
                # Argument separator
                args.append(''.join(current_arg).strip())
                current_arg = []
            else:
                current_arg.append(c)
            
            i += 1
        
        # Unclosed parenthesis
        return None, start
    
    def _expand_object_macro(self, macro: Macro, filename: str, line_num: int,
                            expanding: Set[str]) -> str:
        """Expand an object-like macro.
        
        Args:
            macro: Macro to expand
            filename: Source filename
            line_num: Line number
            expanding: Set of macros being expanded
            
        Returns:
            Expanded text
        """
        # Handle special predefined macros
        if macro.name == '__FILE__':
            return f'"{filename}"'
        elif macro.name == '__LINE__':
            return str(line_num)
        elif macro.name == '__DATE__':
            return f'"{datetime.now().strftime("%b %d %Y")}"'
        elif macro.name == '__TIME__':
            return f'"{datetime.now().strftime("%H:%M:%S")}"'
        
        # Mark as expanding to prevent recursion
        expanding = expanding.copy()
        expanding.add(macro.name)
        
        # Join replacement tokens
        replacement_text = ' '.join(macro.replacement)
        
        # Recursively expand macros in replacement
        return self._expand_macros(replacement_text, filename, line_num, expanding)
    
    def _expand_function_macro(self, macro: Macro, args: List[str], 
                              filename: str, line_num: int,
                              expanding: Set[str]) -> str:
        """Expand a function-like macro.
        
        Args:
            macro: Macro to expand
            args: Argument values
            filename: Source filename
            line_num: Line number
            expanding: Set of macros being expanded
            
        Returns:
            Expanded text
        """
        # Check argument count
        expected_args = len(macro.parameters) if macro.parameters else 0
        if len(args) != expected_args:
            location = SourceLocation(filename, line_num, 1)
            self.error_reporter.error(
                location,
                f"Macro {macro.name} expects {expected_args} arguments, got {len(args)}"
            )
            return macro.name
        
        # Mark as expanding
        expanding = expanding.copy()
        expanding.add(macro.name)
        
        # Build parameter substitution map
        param_map = {}
        if macro.parameters:
            for param, arg in zip(macro.parameters, args):
                param_map[param] = arg
        
        # Process replacement tokens
        result = []
        i = 0
        while i < len(macro.replacement):
            token = macro.replacement[i]
            
            # Handle stringification operator (#)
            if token == '#' and i + 1 < len(macro.replacement):
                next_token = macro.replacement[i + 1]
                if next_token in param_map:
                    # Stringify the argument
                    arg_value = param_map[next_token]
                    stringified = self._stringify(arg_value)
                    result.append(stringified)
                    i += 2
                    continue
            
            # Handle token pasting operator (##)
            if token == '##':
                # Remove last token from result and next token, paste them
                if result and i + 1 < len(macro.replacement):
                    left = result.pop()
                    right = macro.replacement[i + 1]
                    
                    # Substitute parameters (no expansion for token pasting)
                    if right in param_map:
                        right = param_map[right]
                    
                    # Paste tokens (no space between)
                    pasted = left + right
                    result.append(pasted)
                    i += 2
                    continue
            
            # Check if next token is ##
            if i + 1 < len(macro.replacement) and macro.replacement[i + 1] == '##':
                # Substitute parameter but don't expand yet (for token pasting)
                if token in param_map:
                    result.append(param_map[token])
                else:
                    result.append(token)
                i += 1
                continue
            
            # Regular token - substitute parameter
            if token in param_map:
                # Expand macros in argument before substitution
                arg_expanded = self._expand_macros(
                    param_map[token], filename, line_num, expanding
                )
                result.append(arg_expanded)
            else:
                result.append(token)
            
            i += 1
        
        # Join result with spaces
        replacement_text = ' '.join(result)
        
        # Recursively expand macros in result
        return self._expand_macros(replacement_text, filename, line_num, expanding)
    
    def _stringify(self, text: str) -> str:
        """Convert text to a string literal (stringification operator).
        
        Args:
            text: Text to stringify
            
        Returns:
            String literal
        """
        # Escape special characters
        escaped = text.replace('\\', '\\\\').replace('"', '\\"')
        return f'"{escaped}"'
    
    def _discover_system_includes(self):
        """Discover system include directories.
        
        Attempts to find standard system include paths by checking
        common locations and querying the compiler.
        """
        # Common system include paths
        common_paths = [
            '/usr/include',
            '/usr/local/include',
            '/usr/include/x86_64-linux-gnu',
            '/usr/include/aarch64-linux-gnu',
            '/usr/include/arm-linux-gnueabihf',
        ]
        
        for path in common_paths:
            if os.path.isdir(path):
                self.system_include_paths.append(path)
        
        # Try to get paths from gcc
        try:
            import subprocess
            result = subprocess.run(
                ['gcc', '-E', '-Wp,-v', '-xc', '/dev/null'],
                capture_output=True,
                text=True,
                check=False
            )
            
            # Parse include paths from stderr
            in_include_section = False
            for line in result.stderr.split('\n'):
                line = line.strip()
                if line == '#include <...> search starts here:':
                    in_include_section = True
                    continue
                elif line == 'End of search list.':
                    break
                elif in_include_section and line and os.path.isdir(line):
                    if line not in self.system_include_paths:
                        self.system_include_paths.append(line)
        except Exception:
            # If we can't query gcc, just use common paths
            pass
    
    def add_include_path(self, path: str):
        """Add a directory to the include search path.
        
        Args:
            path: Directory path to add
        """
        if os.path.isdir(path):
            self.include_paths.append(path)
    
    def _is_macro_defined(self, name: str) -> bool:
        """Check if a macro is defined.
        
        Args:
            name: Macro name
            
        Returns:
            True if macro is defined
        """
        return name in self.macros
    
    def _evaluate_constant_expression(self, expr: str, filename: str, line_num: int) -> int:
        """Evaluate a constant expression for #if directive.
        
        Args:
            expr: Expression to evaluate
            filename: Source filename
            line_num: Line number
            
        Returns:
            Integer result of evaluation
        """
        # Handle 'defined' operator BEFORE macro expansion
        # defined(NAME) or defined NAME
        def replace_defined(match):
            macro_name = match.group(1) or match.group(2)
            return '1' if self._is_macro_defined(macro_name) else '0'
        
        expanded = re.sub(r'defined\s*\(\s*(\w+)\s*\)', replace_defined, expr)
        expanded = re.sub(r'defined\s+(\w+)', replace_defined, expanded)
        
        # Now expand macros in the expression
        expanded = self._expand_macros_in_line(expanded, filename, line_num)
        
        # Replace any remaining undefined identifiers with 0
        def replace_undefined(match):
            identifier = match.group(0)
            # Check if it's a number
            if identifier.isdigit():
                return identifier
            # Check if it's a defined macro
            if self._is_macro_defined(identifier):
                return identifier  # Already expanded
            # Undefined identifier evaluates to 0
            return '0'
        
        expanded = re.sub(r'\b[a-zA-Z_]\w*\b', replace_undefined, expanded)
        
        # Convert C operators to Python operators
        # Logical operators
        expanded = expanded.replace('&&', ' and ')
        expanded = expanded.replace('||', ' or ')
        expanded = expanded.replace('!', ' not ')
        
        # Bitwise operators are the same in C and Python: &, |, ^, ~, <<, >>
        # Comparison operators are the same: ==, !=, <, >, <=, >=
        # Arithmetic operators are the same: +, -, *, /, %
        
        # Try to evaluate the expression
        try:
            # Use Python's eval for simplicity (in production, use a proper expression parser)
            # Restrict to safe operations
            result = eval(expanded, {"__builtins__": {}}, {})
            return int(result)
        except Exception as e:
            location = SourceLocation(filename, line_num, 1)
            self.error_reporter.error(
                location,
                f"Cannot evaluate constant expression: {expr} (expanded to: {expanded})"
            )
            return 0
    
    def _should_skip_code(self) -> bool:
        """Check if we should skip code based on conditional stack.
        
        Returns:
            True if code should be skipped
        """
        # Skip if any level in the stack is in skip mode
        return any(state.skip_mode for state in self.conditional_stack)
    
    def _handle_if_directive(self, condition_expr: str, filename: str, line_num: int):
        """Handle #if directive.
        
        Args:
            condition_expr: Condition expression
            filename: Source filename
            line_num: Line number
        """
        # Evaluate the condition
        result = self._evaluate_constant_expression(condition_expr, filename, line_num)
        condition_met = (result != 0)
        
        # Push new conditional state
        # If we're already skipping, continue skipping
        skip_mode = self._should_skip_code() or not condition_met
        
        self.conditional_stack.append(ConditionalState(
            condition_met=condition_met,
            else_seen=False,
            skip_mode=skip_mode
        ))
    
    def _handle_ifdef_directive(self, macro_name: str):
        """Handle #ifdef directive.
        
        Args:
            macro_name: Macro name to check
        """
        condition_met = self._is_macro_defined(macro_name)
        
        # If we're already skipping, continue skipping
        skip_mode = self._should_skip_code() or not condition_met
        
        self.conditional_stack.append(ConditionalState(
            condition_met=condition_met,
            else_seen=False,
            skip_mode=skip_mode
        ))
    
    def _handle_ifndef_directive(self, macro_name: str):
        """Handle #ifndef directive.
        
        Args:
            macro_name: Macro name to check
        """
        condition_met = not self._is_macro_defined(macro_name)
        
        # If we're already skipping, continue skipping
        skip_mode = self._should_skip_code() or not condition_met
        
        self.conditional_stack.append(ConditionalState(
            condition_met=condition_met,
            else_seen=False,
            skip_mode=skip_mode
        ))
    
    def _handle_elif_directive(self, condition_expr: str, filename: str, line_num: int, location: SourceLocation):
        """Handle #elif directive.
        
        Args:
            condition_expr: Condition expression
            filename: Source filename
            line_num: Line number
            location: Source location for errors
        """
        if not self.conditional_stack:
            self.error_reporter.error(location, "#elif without #if")
            return
        
        state = self.conditional_stack[-1]
        
        if state.else_seen:
            self.error_reporter.error(location, "#elif after #else")
            return
        
        # If we're in a parent skip mode, stay in skip mode
        parent_skip = len(self.conditional_stack) > 1 and any(
            s.skip_mode for s in self.conditional_stack[:-1]
        )
        
        if parent_skip:
            state.skip_mode = True
        elif state.condition_met:
            # Previous condition was true, skip this elif
            state.skip_mode = True
        else:
            # Evaluate this condition
            result = self._evaluate_constant_expression(condition_expr, filename, line_num)
            condition_met = (result != 0)
            
            if condition_met:
                state.condition_met = True
                state.skip_mode = False
            else:
                state.skip_mode = True
    
    def _handle_else_directive(self, location: SourceLocation):
        """Handle #else directive.
        
        Args:
            location: Source location for errors
        """
        if not self.conditional_stack:
            self.error_reporter.error(location, "#else without #if")
            return
        
        state = self.conditional_stack[-1]
        
        if state.else_seen:
            self.error_reporter.error(location, "Duplicate #else")
            return
        
        state.else_seen = True
        
        # If we're in a parent skip mode, stay in skip mode
        parent_skip = len(self.conditional_stack) > 1 and any(
            s.skip_mode for s in self.conditional_stack[:-1]
        )
        
        if parent_skip:
            state.skip_mode = True
        elif state.condition_met:
            # Previous condition was true, skip the else
            state.skip_mode = True
        else:
            # No previous condition was true, include the else
            state.skip_mode = False
    
    def _handle_endif_directive(self, location: SourceLocation):
        """Handle #endif directive.
        
        Args:
            location: Source location for errors
        """
        if not self.conditional_stack:
            self.error_reporter.error(location, "#endif without #if")
            return
        
        self.conditional_stack.pop()
    
    def preprocess(self, source_code: str, filename: str = "<input>") -> str:
        """Preprocess source code, handling directives and macro expansion.
        
        Args:
            source_code: Source code to preprocess
            filename: Source filename for error reporting
            
        Returns:
            Preprocessed source code with includes expanded and macros expanded
        """
        lines = source_code.split('\n')
        result_lines = []
        line_num = 1
        
        # Reset conditional stack for new preprocessing
        self.conditional_stack = []
        
        for line in lines:
            location = SourceLocation(filename, line_num, 1)
            
            # Check for preprocessor directives
            directive_match = re.match(r'^\s*#\s*(\w+)\s*(.*)', line)
            if directive_match:
                directive_type = directive_match.group(1)
                directive_content = directive_match.group(2).strip()
                
                # Handle conditional directives first (they affect skipping)
                if directive_type == 'if':
                    self._handle_if_directive(directive_content, filename, line_num)
                    result_lines.append(f'// #if {directive_content}')
                
                elif directive_type == 'ifdef':
                    macro_name_match = re.match(r'^(\w+)', directive_content)
                    if macro_name_match:
                        macro_name = macro_name_match.group(1)
                        self._handle_ifdef_directive(macro_name)
                    else:
                        self.error_reporter.error(location, "Invalid #ifdef directive")
                    result_lines.append(f'// #ifdef {directive_content}')
                
                elif directive_type == 'ifndef':
                    macro_name_match = re.match(r'^(\w+)', directive_content)
                    if macro_name_match:
                        macro_name = macro_name_match.group(1)
                        self._handle_ifndef_directive(macro_name)
                    else:
                        self.error_reporter.error(location, "Invalid #ifndef directive")
                    result_lines.append(f'// #ifndef {directive_content}')
                
                elif directive_type == 'elif':
                    self._handle_elif_directive(directive_content, filename, line_num, location)
                    result_lines.append(f'// #elif {directive_content}')
                
                elif directive_type == 'else':
                    self._handle_else_directive(location)
                    result_lines.append(f'// #else')
                
                elif directive_type == 'endif':
                    self._handle_endif_directive(location)
                    result_lines.append(f'// #endif')
                
                # Skip other directives if we're in skip mode
                elif self._should_skip_code():
                    result_lines.append(f'// {line}')
                
                elif directive_type == 'include':
                    # Process #include
                    include_match = re.match(r'([<"])([^>"]+)([>"])', directive_content)
                    if include_match:
                        bracket_type = include_match.group(1)
                        header_name = include_match.group(2)
                        
                        included_content = self._process_include(
                            header_name,
                            bracket_type == '<',
                            location
                        )
                        
                        if included_content is not None:
                            # Include was processed (may be empty due to include guard optimization)
                            result_lines.append(f'// #include {bracket_type}{header_name}{include_match.group(3)}')
                            if included_content:  # Only append if not empty
                                result_lines.append(included_content)
                        else:
                            # Include failed (file not found)
                            result_lines.append(line)
                    else:
                        self.error_reporter.error(location, f"Invalid #include directive")
                        result_lines.append(line)
                
                elif directive_type == 'define':
                    # Process #define
                    macro = self._parse_define_directive(directive_content, location)
                    if macro:
                        self._define_macro(
                            macro.name,
                            macro.parameters,
                            macro.replacement,
                            macro.is_function_like,
                            location
                        )
                    # Comment out the directive
                    result_lines.append(f'// #define {directive_content}')
                
                elif directive_type == 'undef':
                    # Process #undef
                    undef_match = re.match(r'^(\w+)', directive_content)
                    if undef_match:
                        macro_name = undef_match.group(1)
                        self._undefine_macro(macro_name)
                    else:
                        self.error_reporter.error(location, f"Invalid #undef directive")
                    # Comment out the directive
                    result_lines.append(f'// #undef {directive_content}')
                
                elif directive_type == 'pragma':
                    # Process #pragma directives
                    if directive_content.strip() == 'once':
                        # #pragma once - mark this file as included once
                        normalized_path = os.path.abspath(filename)
                        self.pragma_once_files.add(normalized_path)
                        result_lines.append(f'// #pragma once')
                    else:
                        # Other pragmas - keep as comment
                        result_lines.append(f'// #pragma {directive_content}')
                
                else:
                    # Keep other directives as-is for now
                    result_lines.append(line)
            else:
                # Skip code if we're in a false conditional block
                if self._should_skip_code():
                    result_lines.append(f'// {line}')
                else:
                    # Expand macros in non-directive lines
                    expanded_line = self._expand_macros_in_line(line, filename, line_num)
                    result_lines.append(expanded_line)
            
            line_num += 1
        
        # Check for unclosed conditionals
        if self.conditional_stack:
            location = SourceLocation(filename, line_num, 1)
            self.error_reporter.error(location, f"Unclosed conditional directive (missing #endif)")
        
        return '\n'.join(result_lines)
    
    def _detect_include_guard(self, content: str, filename: str) -> Optional[str]:
        """Detect include guard pattern in a header file.
        
        Detects the traditional include guard pattern:
        #ifndef GUARD_MACRO
        #define GUARD_MACRO
        ...
        #endif
        
        This optimization allows the preprocessor to skip re-reading files
        whose include guard macro is already defined.
        
        Args:
            content: File content
            filename: Filename for tracking
            
        Returns:
            Guard macro name if detected, None otherwise
        """
        lines = content.split('\n')
        
        # Skip empty lines, comments, and whitespace at the beginning
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            # Skip empty lines, single-line comments, and block comment starts
            if line and not line.startswith('//') and not line.startswith('/*'):
                break
            i += 1
        
        if i >= len(lines):
            return None
        
        # First non-comment line must be #ifndef MACRO
        ifndef_match = re.match(r'^\s*#\s*ifndef\s+(\w+)', lines[i])
        if not ifndef_match:
            return None
        
        guard_macro = ifndef_match.group(1)
        i += 1
        
        # Skip empty lines and comments after #ifndef
        while i < len(lines):
            line = lines[i].strip()
            if line and not line.startswith('//') and not line.startswith('/*'):
                break
            i += 1
        
        if i >= len(lines):
            return None
        
        # Next non-comment line must be #define MACRO (same macro name)
        define_match = re.match(r'^\s*#\s*define\s+(\w+)', lines[i])
        if not define_match or define_match.group(1) != guard_macro:
            return None
        
        # Check that the file ends with #endif
        # Look for the last non-empty, non-comment line
        last_directive_idx = -1
        for j in range(len(lines) - 1, -1, -1):
            line = lines[j].strip()
            if line and not line.startswith('//') and not line.startswith('/*'):
                last_directive_idx = j
                break
        
        if last_directive_idx == -1:
            return None
        
        # The last directive should be #endif
        if re.match(r'^\s*#\s*endif', lines[last_directive_idx]):
            # Found valid include guard pattern
            return guard_macro
        
        return None
    
    def _process_include(self, header_name: str, is_system: bool, 
                        location: SourceLocation) -> Optional[str]:
        """Process an #include directive.
        
        Implements include guard optimization:
        - Detects #pragma once and skips re-reading the file
        - Detects traditional include guards (#ifndef GUARD / #define GUARD)
        - Skips re-reading files whose include guard macro is already defined
        
        Args:
            header_name: Name of header file to include
            is_system: True if using <>, False if using ""
            location: Source location of directive
            
        Returns:
            Content of included file, or None if not found
        """
        # Check if this is a standard library header
        if is_system and header_name in self.STANDARD_HEADERS:
            return self._get_stdlib_declarations(header_name)
        
        # Try to find the header file
        header_path = self._find_header(header_name, is_system, location)
        
        if header_path is None:
            # For standard headers, provide declarations even if file not found
            if is_system and header_name in self.STANDARD_HEADERS:
                return self._get_stdlib_declarations(header_name)
            
            self.error_reporter.error(
                location,
                f"Cannot find include file: {header_name}"
            )
            return None
        
        # Normalize path for consistent tracking
        header_path = os.path.abspath(header_path)
        
        # OPTIMIZATION: Check for #pragma once
        # If this file has #pragma once and we've seen it before, skip it
        if header_path in self.pragma_once_files:
            return ""  # Already included with #pragma once, skip re-reading
        
        # OPTIMIZATION: Check for include guard
        # If we've detected an include guard for this file and the guard macro
        # is already defined, we can skip re-reading the file entirely
        if header_path in self.include_guard_macros:
            guard_macro = self.include_guard_macros[header_path]
            if self._is_macro_defined(guard_macro):
                return ""  # Include guard macro is defined, skip file
        
        # Read the header file
        try:
            with open(header_path, 'r') as f:
                content = f.read()
        except Exception as e:
            self.error_reporter.error(
                location,
                f"Error reading include file {header_name}: {str(e)}"
            )
            return None
        
        # OPTIMIZATION: Detect include guard pattern before preprocessing
        # This allows us to skip the file on subsequent includes
        if header_path not in self.include_guard_macros:
            guard_macro = self._detect_include_guard(content, header_path)
            if guard_macro:
                self.include_guard_macros[header_path] = guard_macro
        
        # Recursively preprocess the included file
        result = self.preprocess(content, header_path)
        
        return result
    
    def _find_header(self, header_name: str, is_system: bool,
                    location: SourceLocation) -> Optional[str]:
        """Find a header file in the include paths.
        
        Search order for #include "file":
          1. Current directory (directory of the file containing the #include)
          2. User-specified include paths (-I options)
          3. System include paths
        
        Search order for #include <file>:
          1. User-specified include paths (-I options)
          2. System include paths
        
        Args:
            header_name: Name of header file
            is_system: True if using <>, False if using ""
            location: Source location for error reporting
            
        Returns:
            Full path to header file, or None if not found
        """
        search_paths = []
        
        if is_system:
            # System includes: search user include paths, then system paths
            # Note: -I paths are searched before system paths for <> includes
            search_paths = self.include_paths + self.system_include_paths
        else:
            # Local includes: search current directory, then include paths, then system paths
            current_dir = os.path.dirname(location.filename) if location.filename != "<input>" else "."
            search_paths = [current_dir] + self.include_paths + self.system_include_paths
        
        for search_path in search_paths:
            full_path = os.path.join(search_path, header_name)
            if os.path.isfile(full_path):
                return full_path
        
        return None
    
    def _get_stdlib_declarations(self, header_name: str) -> str:
        """Get standard library declarations for a header.
        
        Args:
            header_name: Name of standard header
            
        Returns:
            C declarations for the standard library functions
        """
        return self.STDLIB_DECLARATIONS.get(header_name, '')
    
    def parse_directives(self, source_code: str, filename: str = "<input>") -> List[PreprocessorDirective]:
        """Parse preprocessor directives from source code.
        
        Args:
            source_code: Source code to parse
            filename: Source filename for error reporting
            
        Returns:
            List of preprocessor directives found
        """
        directives = []
        lines = source_code.split('\n')
        line_num = 1
        
        for line in lines:
            location = SourceLocation(filename, line_num, 1)
            
            # Match preprocessor directives
            directive_match = re.match(r'^\s*#\s*(\w+)\s*(.*)', line)
            if directive_match:
                directive_type = directive_match.group(1)
                directive_content = directive_match.group(2).strip()
                
                directives.append(PreprocessorDirective(
                    type=directive_type,
                    content=directive_content,
                    location=location
                ))
            
            line_num += 1
        
        return directives
