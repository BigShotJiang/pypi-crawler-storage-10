"""Preprocessor module for handling C preprocessor directives."""

from src.preprocessor.preprocessor import Preprocessor, PreprocessorDirective

__all__ = ['Preprocessor', 'PreprocessorDirective']
