"""Optimizer module for IR optimization passes."""

from src.optimizer.optimizer import Optimizer, OptimizationPass, OptimizationLevel
from src.optimizer.constant_folding import ConstantFoldingPass
from src.optimizer.dead_code import DeadCodeEliminationPass
from src.optimizer.strength_reduction import StrengthReductionPass

__all__ = [
    'Optimizer',
    'OptimizationPass',
    'OptimizationLevel',
    'ConstantFoldingPass',
    'DeadCodeEliminationPass',
    'StrengthReductionPass'
]
