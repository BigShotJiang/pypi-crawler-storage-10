"""Strength reduction optimization pass."""

import math

from src.optimizer.optimizer import OptimizationPass
from src.ir.ir_module import IRModule, IRFunction
from src.ir.basic_block import BasicBlock
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, Constant, VirtualRegister
)


class StrengthReductionPass(OptimizationPass):
    """Strength reduction optimization pass.
    
    This pass replaces expensive operations with cheaper equivalents:
    - Multiplication by powers of 2 → Left shift
    - Division by powers of 2 → Right shift
    - Modulo by powers of 2 → Bitwise AND
    
    These transformations are only valid for integer operations.
    """
    
    def get_name(self) -> str:
        """Get the name of this optimization pass."""
        return "Strength Reduction"
    
    def run(self, ir_module: IRModule) -> IRModule:
        """Run strength reduction on all functions in the module.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module
        """
        for function in ir_module.get_functions():
            self._reduce_function(function)
        
        return ir_module
    
    def _reduce_function(self, function: IRFunction) -> None:
        """Apply strength reduction to a single function.
        
        Args:
            function: Function to optimize
        """
        for block in function.get_all_blocks():
            self._reduce_block(block)
    
    def _reduce_block(self, block: BasicBlock) -> None:
        """Apply strength reduction to a single basic block.
        
        Args:
            block: Basic block to optimize
        """
        new_instructions = []
        
        for instruction in block.instructions:
            # Try to reduce this instruction
            reduced = self._reduce_instruction(instruction)
            
            if reduced is not None:
                # Instruction was reduced to a cheaper operation
                new_instructions.append(reduced)
            else:
                # Keep original instruction
                new_instructions.append(instruction)
        
        block.instructions = new_instructions
    
    def _reduce_instruction(self, instruction: IRInstruction) -> IRInstruction | None:
        """Try to reduce an instruction to a cheaper equivalent.
        
        Args:
            instruction: Instruction to reduce
            
        Returns:
            Reduced instruction if possible, None to keep original
        """
        # Only handle binary operations
        if len(instruction.operands) != 2:
            return None
        
        left_operand = instruction.operands[0]
        right_operand = instruction.operands[1]
        
        # Check for multiplication by power of 2
        if instruction.opcode == IROpcode.MUL:
            power = self._get_power_of_two(right_operand)
            if power is not None:
                # Replace MUL with SHL
                shift_amount = Constant(value=power, value_type=right_operand.value_type)
                return IRInstruction(
                    opcode=IROpcode.SHL,
                    result=instruction.result,
                    operands=[left_operand, shift_amount],
                    location=instruction.location
                )
            
            # Also check if left operand is power of 2 (commutative)
            power = self._get_power_of_two(left_operand)
            if power is not None:
                shift_amount = Constant(value=power, value_type=left_operand.value_type)
                return IRInstruction(
                    opcode=IROpcode.SHL,
                    result=instruction.result,
                    operands=[right_operand, shift_amount],
                    location=instruction.location
                )
        
        # Check for division by power of 2
        elif instruction.opcode == IROpcode.DIV:
            power = self._get_power_of_two(right_operand)
            if power is not None:
                # Replace DIV with SHR (arithmetic right shift for signed)
                shift_amount = Constant(value=power, value_type=right_operand.value_type)
                return IRInstruction(
                    opcode=IROpcode.SHR,
                    result=instruction.result,
                    operands=[left_operand, shift_amount],
                    location=instruction.location
                )
        
        # Check for modulo by power of 2
        elif instruction.opcode == IROpcode.MOD:
            power = self._get_power_of_two(right_operand)
            if power is not None:
                # Replace MOD with AND
                # x % (2^n) = x & (2^n - 1)
                mask_value = (1 << power) - 1
                mask = Constant(value=mask_value, value_type=right_operand.value_type)
                return IRInstruction(
                    opcode=IROpcode.AND,
                    result=instruction.result,
                    operands=[left_operand, mask],
                    location=instruction.location
                )
        
        return None
    
    def _get_power_of_two(self, operand) -> int | None:
        """Check if an operand is a constant power of 2.
        
        Args:
            operand: Operand to check
            
        Returns:
            The power (n where operand = 2^n) if operand is a power of 2,
            None otherwise
        """
        if not isinstance(operand, Constant):
            return None
        
        value = operand.value
        
        # Must be a positive integer
        if not isinstance(value, int) or value <= 0:
            return None
        
        # Check if value is a power of 2
        # A number is a power of 2 if it has exactly one bit set
        if value & (value - 1) != 0:
            return None
        
        # Calculate the power
        # log2(value) gives us the power
        power = int(math.log2(value))
        
        # Verify (in case of floating point errors)
        if (1 << power) == value:
            return power
        
        return None
