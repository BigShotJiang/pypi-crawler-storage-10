"""Dead code elimination optimization pass."""

from typing import Set

from src.optimizer.optimizer import OptimizationPass
from src.ir.ir_module import IRModule, IRFunction
from src.ir.basic_block import BasicBlock
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, VirtualRegister
)


class DeadCodeEliminationPass(OptimizationPass):
    """Dead code elimination optimization pass.
    
    This pass removes:
    - Unreachable basic blocks (blocks with no path from entry)
    - Unused variable assignments (assignments whose results are never used)
    
    The pass uses liveness analysis to determine which instructions
    are actually needed.
    """
    
    def get_name(self) -> str:
        """Get the name of this optimization pass."""
        return "Dead Code Elimination"
    
    def run(self, ir_module: IRModule) -> IRModule:
        """Run dead code elimination on all functions in the module.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module
        """
        for function in ir_module.get_functions():
            self._eliminate_dead_code(function)
        
        return ir_module
    
    def _eliminate_dead_code(self, function: IRFunction) -> None:
        """Eliminate dead code in a single function.
        
        Args:
            function: Function to optimize
        """
        # First, remove unreachable basic blocks
        self._remove_unreachable_blocks(function)
        
        # Then, remove unused variable assignments
        self._remove_unused_assignments(function)
    
    def _remove_unreachable_blocks(self, function: IRFunction) -> None:
        """Remove basic blocks that are unreachable from entry.
        
        Args:
            function: Function to optimize
        """
        cfg = function.get_cfg()
        
        # Find reachable blocks using depth-first search
        reachable = set()
        stack = [cfg.entry_block]
        
        while stack:
            block = stack.pop()
            if block in reachable:
                continue
            
            reachable.add(block)
            for successor in block.successors:
                if successor not in reachable:
                    stack.append(successor)
        
        # Remove unreachable blocks from CFG
        original_count = len(cfg.blocks)
        cfg.blocks = [block for block in cfg.blocks if block in reachable]
        
        # Update predecessor/successor relationships
        for block in cfg.blocks:
            # Remove unreachable predecessors
            block.predecessors = {pred for pred in block.predecessors if pred in reachable}
            # Remove unreachable successors
            block.successors = {succ for succ in block.successors if succ in reachable}
    
    def _remove_unused_assignments(self, function: IRFunction) -> None:
        """Remove assignments to variables that are never used.
        
        This performs a simple liveness analysis to determine which
        registers are actually used.
        
        Args:
            function: Function to optimize
        """
        # Collect all used registers
        used_registers = self._collect_used_registers(function)
        
        # Remove instructions that assign to unused registers
        for block in function.get_all_blocks():
            new_instructions = []
            
            for instruction in block.instructions:
                # Keep instruction if:
                # 1. It has no result (side effects like stores, calls, branches)
                # 2. Its result is used
                # 3. It's a terminator instruction (branch, return)
                if (instruction.result is None or
                    instruction.result.name in used_registers or
                    self._is_terminator(instruction) or
                    self._has_side_effects(instruction)):
                    new_instructions.append(instruction)
            
            block.instructions = new_instructions
    
    def _collect_used_registers(self, function: IRFunction) -> Set[str]:
        """Collect all registers that are used as operands.
        
        Args:
            function: Function to analyze
            
        Returns:
            Set of register names that are used
        """
        used = set()
        
        for block in function.get_all_blocks():
            for instruction in block.instructions:
                # Add all register operands to used set
                for operand in instruction.operands:
                    if isinstance(operand, VirtualRegister):
                        used.add(operand.name)
        
        return used
    
    def _is_terminator(self, instruction: IRInstruction) -> bool:
        """Check if an instruction is a terminator (branch or return).
        
        Args:
            instruction: Instruction to check
            
        Returns:
            True if instruction is a terminator
        """
        return instruction.opcode in {
            IROpcode.BR,
            IROpcode.COND_BR,
            IROpcode.RET
        }
    
    def _has_side_effects(self, instruction: IRInstruction) -> bool:
        """Check if an instruction has side effects.
        
        Instructions with side effects must be kept even if their
        results are unused.
        
        Args:
            instruction: Instruction to check
            
        Returns:
            True if instruction has side effects
        """
        # Instructions with side effects:
        # - STORE: Modifies memory
        # - CALL: May have side effects (I/O, global state)
        # - Terminators: Control flow
        return instruction.opcode in {
            IROpcode.STORE,
            IROpcode.CALL,
            IROpcode.BR,
            IROpcode.COND_BR,
            IROpcode.RET
        }
