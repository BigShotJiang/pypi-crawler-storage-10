"""Optimization framework for IR optimization passes."""

from abc import ABC, abstractmethod
from typing import List
from enum import IntEnum

from src.ir.ir_module import IRModule


class OptimizationLevel(IntEnum):
    """Optimization levels for the compiler.
    
    Attributes:
        O0: No optimization
        O1: Basic optimizations (constant folding, dead code elimination)
        O2: More aggressive optimizations (future expansion)
        O3: Maximum optimizations (future expansion)
    """
    O0 = 0
    O1 = 1
    O2 = 2
    O3 = 3


class OptimizationPass(ABC):
    """Abstract base class for optimization passes.
    
    Each optimization pass operates on an IR module and returns
    a modified version. Passes should preserve program semantics.
    """
    
    @abstractmethod
    def run(self, ir_module: IRModule) -> IRModule:
        """Run the optimization pass on an IR module.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module (may be the same object, modified in place)
        """
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Get the name of this optimization pass.
        
        Returns:
            Pass name for logging and debugging
        """
        pass


class Optimizer:
    """Coordinates execution of optimization passes.
    
    The optimizer runs a sequence of optimization passes on an IR module
    based on the configured optimization level.
    
    Attributes:
        optimization_level: Level of optimization to apply
        passes: List of optimization passes to run
        verbose: Whether to print optimization progress
    """
    
    def __init__(self, optimization_level: int = 0, verbose: bool = False):
        """Initialize the optimizer.
        
        Args:
            optimization_level: Optimization level (0-3)
            verbose: Whether to print optimization progress
        """
        self.optimization_level = OptimizationLevel(optimization_level)
        self.passes: List[OptimizationPass] = []
        self.verbose = verbose
    
    def add_pass(self, pass_instance: OptimizationPass) -> None:
        """Add an optimization pass to the sequence.
        
        Args:
            pass_instance: Optimization pass to add
        """
        self.passes.append(pass_instance)
    
    def optimize(self, ir_module: IRModule) -> IRModule:
        """Run all optimization passes on an IR module.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module
        """
        if self.optimization_level == OptimizationLevel.O0:
            # No optimization
            if self.verbose:
                print("Optimization disabled (O0)")
            return ir_module
        
        if self.verbose:
            print(f"Running optimization passes (O{self.optimization_level})...")
        
        # Run each pass in sequence
        for pass_instance in self.passes:
            if self.verbose:
                print(f"  Running {pass_instance.get_name()}...")
            ir_module = pass_instance.run(ir_module)
        
        if self.verbose:
            print("Optimization complete")
        
        return ir_module
    
    def configure_for_level(self, optimization_level: int) -> None:
        """Configure optimization passes for a specific level.
        
        This method sets up the appropriate passes for the given
        optimization level. It should be called after creating the
        optimizer but before calling optimize().
        
        Args:
            optimization_level: Optimization level (0-3)
        """
        self.optimization_level = OptimizationLevel(optimization_level)
        self.passes.clear()
        
        if self.optimization_level == OptimizationLevel.O0:
            # No passes for O0
            return
        
        # Import passes here to avoid circular dependencies
        from src.optimizer.constant_folding import ConstantFoldingPass
        from src.optimizer.dead_code import DeadCodeEliminationPass
        from src.optimizer.strength_reduction import StrengthReductionPass
        
        if self.optimization_level >= OptimizationLevel.O1:
            # Basic optimizations
            self.add_pass(ConstantFoldingPass())
            self.add_pass(DeadCodeEliminationPass())
            self.add_pass(StrengthReductionPass())
        
        # Future: Add more aggressive passes for O2 and O3
        if self.optimization_level >= OptimizationLevel.O2:
            # Placeholder for future optimizations
            pass
        
        if self.optimization_level >= OptimizationLevel.O3:
            # Placeholder for future optimizations
            pass
