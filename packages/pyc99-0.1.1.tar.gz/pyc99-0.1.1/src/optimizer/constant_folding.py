"""Constant folding optimization pass."""

from typing import Dict, Optional
import operator

from src.optimizer.optimizer import OptimizationPass
from src.ir.ir_module import IRModule, IRFunction
from src.ir.basic_block import BasicBlock
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, IRValue, Constant, VirtualRegister
)


class ConstantFoldingPass(OptimizationPass):
    """Constant folding optimization pass.
    
    This pass evaluates constant expressions at compile time and
    propagates constants through assignments. It handles:
    - Arithmetic operations on integer and float constants
    - Logical operations on boolean constants
    - Comparison operations on constants
    - Constant propagation through assignments
    """
    
    def get_name(self) -> str:
        """Get the name of this optimization pass."""
        return "Constant Folding"
    
    def run(self, ir_module: IRModule) -> IRModule:
        """Run constant folding on all functions in the module.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module
        """
        for function in ir_module.get_functions():
            self._fold_function(function)
        
        return ir_module
    
    def _fold_function(self, function: IRFunction) -> None:
        """Fold constants in a single function.
        
        Args:
            function: Function to optimize
        """
        # Track known constant values for registers
        constant_values: Dict[str, Constant] = {}
        
        # Process each basic block
        for block in function.get_all_blocks():
            self._fold_block(block, constant_values)
    
    def _fold_block(self, block: BasicBlock, constant_values: Dict[str, Constant]) -> None:
        """Fold constants in a single basic block.
        
        Args:
            block: Basic block to optimize
            constant_values: Dictionary mapping register names to constant values
        """
        new_instructions = []
        
        for instruction in block.instructions:
            # Try to fold this instruction
            folded = self._fold_instruction(instruction, constant_values)
            
            if folded is not None:
                # Instruction was folded to a constant
                if instruction.result:
                    # Track the constant value for this register
                    constant_values[instruction.result.name] = folded
                    
                    # Replace instruction with a move from constant
                    # (In a real compiler, we might have a MOV instruction,
                    # but for simplicity we'll keep the original instruction
                    # and replace operands)
                    new_instructions.append(instruction)
            else:
                # Instruction couldn't be folded, but we can still
                # replace operands with constants if available
                self._replace_operands_with_constants(instruction, constant_values)
                new_instructions.append(instruction)
        
        block.instructions = new_instructions
    
    def _fold_instruction(
        self, 
        instruction: IRInstruction, 
        constant_values: Dict[str, Constant]
    ) -> Optional[Constant]:
        """Try to fold an instruction to a constant.
        
        Args:
            instruction: Instruction to fold
            constant_values: Known constant values
            
        Returns:
            Constant result if instruction can be folded, None otherwise
        """
        # Get constant operands
        const_operands = []
        for operand in instruction.operands:
            if isinstance(operand, Constant):
                const_operands.append(operand)
            elif isinstance(operand, VirtualRegister):
                # Check if this register has a known constant value
                const_val = constant_values.get(operand.name)
                if const_val:
                    const_operands.append(const_val)
                else:
                    # Operand is not constant, can't fold
                    return None
            else:
                # Operand is not constant
                return None
        
        # If we don't have all operands as constants, can't fold
        if len(const_operands) != len(instruction.operands):
            return None
        
        # Try to evaluate the operation
        return self._evaluate_operation(instruction.opcode, const_operands)
    
    def _evaluate_operation(
        self, 
        opcode: IROpcode, 
        operands: list[Constant]
    ) -> Optional[Constant]:
        """Evaluate an operation on constant operands.
        
        Args:
            opcode: Operation to evaluate
            operands: Constant operands
            
        Returns:
            Constant result if operation can be evaluated, None otherwise
        """
        if len(operands) == 0:
            return None
        
        # Binary arithmetic operations
        if len(operands) == 2:
            left_val = operands[0].value
            right_val = operands[1].value
            result_type = operands[0].value_type
            
            try:
                if opcode == IROpcode.ADD:
                    result = left_val + right_val
                elif opcode == IROpcode.SUB:
                    result = left_val - right_val
                elif opcode == IROpcode.MUL:
                    result = left_val * right_val
                elif opcode == IROpcode.DIV:
                    if right_val == 0:
                        # Division by zero, can't fold
                        return None
                    result = left_val / right_val if isinstance(left_val, float) else left_val // right_val
                elif opcode == IROpcode.MOD:
                    if right_val == 0:
                        return None
                    result = left_val % right_val
                
                # Logical operations
                elif opcode == IROpcode.AND:
                    result = left_val and right_val
                elif opcode == IROpcode.OR:
                    result = left_val or right_val
                elif opcode == IROpcode.XOR:
                    result = left_val ^ right_val if isinstance(left_val, int) else None
                
                # Bitwise shift operations
                elif opcode == IROpcode.SHL:
                    result = left_val << right_val if isinstance(left_val, int) else None
                elif opcode == IROpcode.SHR:
                    result = left_val >> right_val if isinstance(left_val, int) else None
                
                # Comparison operations
                elif opcode == IROpcode.EQ:
                    result = 1 if left_val == right_val else 0
                elif opcode == IROpcode.NE:
                    result = 1 if left_val != right_val else 0
                elif opcode == IROpcode.LT:
                    result = 1 if left_val < right_val else 0
                elif opcode == IROpcode.LE:
                    result = 1 if left_val <= right_val else 0
                elif opcode == IROpcode.GT:
                    result = 1 if left_val > right_val else 0
                elif opcode == IROpcode.GE:
                    result = 1 if left_val >= right_val else 0
                else:
                    return None
                
                if result is not None:
                    return Constant(value=result, value_type=result_type)
            except (TypeError, ValueError, ZeroDivisionError):
                # Operation failed, can't fold
                return None
        
        # Unary operations
        elif len(operands) == 1:
            val = operands[0].value
            result_type = operands[0].value_type
            
            try:
                if opcode == IROpcode.NEG:
                    result = -val
                elif opcode == IROpcode.NOT:
                    result = not val
                else:
                    return None
                
                return Constant(value=result, value_type=result_type)
            except (TypeError, ValueError):
                return None
        
        return None
    
    def _replace_operands_with_constants(
        self, 
        instruction: IRInstruction, 
        constant_values: Dict[str, Constant]
    ) -> None:
        """Replace register operands with constants where possible.
        
        This modifies the instruction in place.
        
        Args:
            instruction: Instruction to modify
            constant_values: Known constant values
        """
        new_operands = []
        
        for operand in instruction.operands:
            if isinstance(operand, VirtualRegister):
                # Check if this register has a known constant value
                const_val = constant_values.get(operand.name)
                if const_val:
                    new_operands.append(const_val)
                else:
                    new_operands.append(operand)
            else:
                new_operands.append(operand)
        
        instruction.operands = new_operands
