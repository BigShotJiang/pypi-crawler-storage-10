"""Token type definitions for the lexer."""

from enum import Enum, auto


class TokenType(Enum):
    """Enumeration of all token types in C99."""
    
    # End of file
    EOF = auto()
    
    # Identifiers and literals
    IDENTIFIER = auto()
    INTEGER_LITERAL = auto()
    FLOAT_LITERAL = auto()
    STRING_LITERAL = auto()
    CHAR_LITERAL = auto()
    
    # Keywords
    AUTO = auto()
    BREAK = auto()
    CASE = auto()
    CHAR = auto()
    CONST = auto()
    CONTINUE = auto()
    DEFAULT = auto()
    DO = auto()
    DOUBLE = auto()
    ELSE = auto()
    ENUM = auto()
    EXTERN = auto()
    FLOAT = auto()
    FOR = auto()
    GOTO = auto()
    IF = auto()
    INLINE = auto()
    INT = auto()
    LONG = auto()
    REGISTER = auto()
    RESTRICT = auto()
    RETURN = auto()
    SHORT = auto()
    SIGNED = auto()
    SIZEOF = auto()
    STATIC = auto()
    STRUCT = auto()
    SWITCH = auto()
    TYPEDEF = auto()
    UNION = auto()
    UNSIGNED = auto()
    VOID = auto()
    VOLATILE = auto()
    WHILE = auto()
    _BOOL = auto()
    _COMPLEX = auto()
    _IMAGINARY = auto()
    
    # Operators
    PLUS = auto()           # +
    MINUS = auto()          # -
    STAR = auto()           # *
    SLASH = auto()          # /
    PERCENT = auto()        # %
    AMPERSAND = auto()      # &
    PIPE = auto()           # |
    CARET = auto()          # ^
    TILDE = auto()          # ~
    EXCLAMATION = auto()    # !
    QUESTION = auto()       # ?
    COLON = auto()          # :
    ASSIGN = auto()         # =
    LT = auto()             # <
    GT = auto()             # >
    
    # Compound operators
    PLUS_PLUS = auto()      # ++
    MINUS_MINUS = auto()    # --
    ARROW = auto()          # ->
    PLUS_ASSIGN = auto()    # +=
    MINUS_ASSIGN = auto()   # -=
    STAR_ASSIGN = auto()    # *=
    SLASH_ASSIGN = auto()   # /=
    PERCENT_ASSIGN = auto() # %=
    AMPERSAND_ASSIGN = auto()  # &=
    PIPE_ASSIGN = auto()    # |=
    CARET_ASSIGN = auto()   # ^=
    LSHIFT = auto()         # <<
    RSHIFT = auto()         # >>
    LSHIFT_ASSIGN = auto()  # <<=
    RSHIFT_ASSIGN = auto()  # >>=
    EQ = auto()             # ==
    NE = auto()             # !=
    LE = auto()             # <=
    GE = auto()             # >=
    LOGICAL_AND = auto()    # &&
    LOGICAL_OR = auto()     # ||
    
    # Punctuation
    LPAREN = auto()         # (
    RPAREN = auto()         # )
    LBRACE = auto()         # {
    RBRACE = auto()         # }
    LBRACKET = auto()       # [
    RBRACKET = auto()       # ]
    SEMICOLON = auto()      # ;
    COMMA = auto()          # ,
    DOT = auto()            # .
    ELLIPSIS = auto()       # ...
    
    # Preprocessor (basic recognition)
    HASH = auto()           # #


# Keyword mapping
KEYWORDS = {
    'auto': TokenType.AUTO,
    'break': TokenType.BREAK,
    'case': TokenType.CASE,
    'char': TokenType.CHAR,
    'const': TokenType.CONST,
    'continue': TokenType.CONTINUE,
    'default': TokenType.DEFAULT,
    'do': TokenType.DO,
    'double': TokenType.DOUBLE,
    'else': TokenType.ELSE,
    'enum': TokenType.ENUM,
    'extern': TokenType.EXTERN,
    'float': TokenType.FLOAT,
    'for': TokenType.FOR,
    'goto': TokenType.GOTO,
    'if': TokenType.IF,
    'inline': TokenType.INLINE,
    'int': TokenType.INT,
    'long': TokenType.LONG,
    'register': TokenType.REGISTER,
    'restrict': TokenType.RESTRICT,
    'return': TokenType.RETURN,
    'short': TokenType.SHORT,
    'signed': TokenType.SIGNED,
    'sizeof': TokenType.SIZEOF,
    'static': TokenType.STATIC,
    'struct': TokenType.STRUCT,
    'switch': TokenType.SWITCH,
    'typedef': TokenType.TYPEDEF,
    'union': TokenType.UNION,
    'unsigned': TokenType.UNSIGNED,
    'void': TokenType.VOID,
    'volatile': TokenType.VOLATILE,
    'while': TokenType.WHILE,
    '_Bool': TokenType._BOOL,
    '_Complex': TokenType._COMPLEX,
    '_Imaginary': TokenType._IMAGINARY,
}
