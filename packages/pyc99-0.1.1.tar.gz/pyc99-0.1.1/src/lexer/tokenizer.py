"""Tokenizer for C99 source code."""

from dataclasses import dataclass
from typing import Optional, List
from src.lexer.token_types import TokenType, KEYWORDS
from src.utils.source_location import SourceLocation
from src.utils.error_reporter import ErrorReporter


@dataclass(frozen=True, slots=True)
class Token:
    """Represents a single token in the source code.
    
    Attributes:
        type: The type of token
        value: The string value of the token
        location: Source location where the token was found
    """
    type: TokenType
    value: str
    location: SourceLocation
    
    def __str__(self) -> str:
        """Format token for debugging."""
        return f"Token({self.type.name}, '{self.value}', {self.location})"


class Tokenizer:
    """Tokenizes C99 source code into a stream of tokens.
    
    This lexer uses a character-by-character state machine approach to
    scan the source text and produce tokens.
    """
    
    def __init__(self, source: str, filename: str = "<input>"):
        """Initialize the tokenizer.
        
        Args:
            source: The source code to tokenize
            filename: Name of the source file for error reporting
        """
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1
        self.error_reporter = ErrorReporter()
        
    def current_location(self) -> SourceLocation:
        """Get the current source location."""
        return SourceLocation(self.filename, self.line, self.column)
    
    def peek(self, offset: int = 0) -> Optional[str]:
        """Peek at a character without consuming it.
        
        Args:
            offset: How many characters ahead to peek (0 = current)
            
        Returns:
            The character at the position, or None if at EOF
        """
        pos = self.pos + offset
        if pos < len(self.source):
            return self.source[pos]
        return None
    
    def advance(self) -> Optional[str]:
        """Consume and return the current character.
        
        Returns:
            The consumed character, or None if at EOF
        """
        if self.pos >= len(self.source):
            return None
        
        char = self.source[self.pos]
        self.pos += 1
        
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        
        return char
    
    def skip_whitespace(self):
        """Skip whitespace characters."""
        while self.peek() and self.peek() in ' \t\n\r':
            self.advance()
    
    def skip_line_comment(self):
        """Skip a line comment starting with //."""
        # Skip the //
        self.advance()
        self.advance()
        
        # Skip until end of line or EOF
        while self.peek() and self.peek() != '\n':
            self.advance()
    
    def skip_block_comment(self):
        """Skip a block comment /* ... */."""
        start_location = self.current_location()
        
        # Skip the /*
        self.advance()
        self.advance()
        
        # Skip until */ or EOF
        while True:
            if self.peek() is None:
                self.error_reporter.error(
                    start_location,
                    "Unterminated block comment"
                )
                break
            
            if self.peek() == '*' and self.peek(1) == '/':
                self.advance()  # *
                self.advance()  # /
                break
            
            self.advance()
    
    def read_identifier(self) -> Token:
        """Read an identifier or keyword.
        
        Returns:
            Token with type IDENTIFIER or a keyword type
        """
        start_location = self.current_location()
        chars = []
        
        # First character must be letter or underscore
        while self.peek() and (self.peek().isalnum() or self.peek() == '_'):
            chars.append(self.advance())
        
        value = ''.join(chars)
        
        # Check if it's a keyword
        token_type = KEYWORDS.get(value, TokenType.IDENTIFIER)
        
        return Token(token_type, value, start_location)
    
    def read_number(self) -> Token:
        """Read a numeric literal (integer or float, including hex and octal).
        
        Returns:
            Token with type INTEGER_LITERAL or FLOAT_LITERAL
        """
        start_location = self.current_location()
        value = ""
        is_float = False
        
        # Check for hex (0x or 0X)
        if self.peek() == '0' and self.peek(1) and self.peek(1) in 'xX':
            value += self.advance()  # 0
            value += self.advance()  # x or X
            
            # Read hex digits
            if not (self.peek() and self.peek() in '0123456789abcdefABCDEF.'):
                self.error_reporter.error(
                    start_location,
                    "Invalid hexadecimal literal"
                )
            
            while self.peek() and self.peek() in '0123456789abcdefABCDEF':
                value += self.advance()
            
            # Check for hexadecimal floating-point (C99: 0x1.8p3)
            if self.peek() == '.':
                is_float = True
                value += self.advance()  # .
                
                # Read fractional hex digits
                while self.peek() and self.peek() in '0123456789abcdefABCDEF':
                    value += self.advance()
            
            # Check for binary exponent (p or P) - required for hex floats
            if self.peek() and self.peek() in 'pP':
                is_float = True
                value += self.advance()  # p or P
                
                # Optional sign
                if self.peek() and self.peek() in '+-':
                    value += self.advance()
                
                # Exponent digits (decimal, not hex)
                if not (self.peek() and self.peek().isdigit()):
                    self.error_reporter.error(
                        start_location,
                        "Invalid exponent in hexadecimal floating-point literal"
                    )
                
                while self.peek() and self.peek().isdigit():
                    value += self.advance()
            
            # Handle suffixes
            if is_float:
                # Float suffixes: f, F, l, L
                if self.peek() and self.peek() in 'fFlL':
                    value += self.advance()
            else:
                # Integer suffixes: u, U, l, L
                while self.peek() and self.peek() in 'uUlL':
                    value += self.advance()
            
            token_type = TokenType.FLOAT_LITERAL if is_float else TokenType.INTEGER_LITERAL
            return Token(token_type, value, start_location)
        
        # Check for octal (starts with 0)
        if self.peek() == '0' and self.peek(1) and self.peek(1).isdigit():
            value += self.advance()  # 0
            
            # Read octal digits
            while self.peek() and self.peek() in '01234567':
                value += self.advance()
            
            # Handle integer suffixes
            while self.peek() and self.peek() in 'uUlL':
                value += self.advance()
            
            return Token(TokenType.INTEGER_LITERAL, value, start_location)
        
        # Read decimal number
        while self.peek() and self.peek().isdigit():
            value += self.advance()
        
        # Check for decimal point
        if self.peek() == '.' and self.peek(1) and self.peek(1).isdigit():
            is_float = True
            value += self.advance()  # .
            
            while self.peek() and self.peek().isdigit():
                value += self.advance()
        
        # Check for exponent (e or E)
        if self.peek() and self.peek() in 'eE':
            is_float = True
            value += self.advance()  # e or E
            
            # Optional sign
            if self.peek() and self.peek() in '+-':
                value += self.advance()
            
            # Exponent digits
            if not (self.peek() and self.peek().isdigit()):
                self.error_reporter.error(
                    start_location,
                    "Invalid exponent in floating-point literal"
                )
            
            while self.peek() and self.peek().isdigit():
                value += self.advance()
        
        # Handle suffixes
        if is_float:
            # Float suffixes: f, F (float), l, L (long double)
            if self.peek() and self.peek() in 'fFlL':
                value += self.advance()
        else:
            # Integer suffixes: u, U, l, L
            while self.peek() and self.peek() in 'uUlL':
                value += self.advance()
        
        token_type = TokenType.FLOAT_LITERAL if is_float else TokenType.INTEGER_LITERAL
        return Token(token_type, value, start_location)

    def read_string(self) -> Token:
        """Read a string literal with escape sequences.
        
        Returns:
            Token with type STRING_LITERAL
        """
        start_location = self.current_location()
        value = ""
        
        # Skip opening quote
        value += self.advance()  # "
        
        while True:
            char = self.peek()
            
            if char is None or char == '\n':
                self.error_reporter.error(
                    start_location,
                    "Unterminated string literal"
                )
                break
            
            if char == '"':
                value += self.advance()  # closing "
                break
            
            if char == '\\':
                # Handle escape sequences
                value += self.advance()  # \
                next_char = self.peek()
                
                if next_char is None:
                    self.error_reporter.error(
                        start_location,
                        "Unterminated string literal"
                    )
                    break
                
                # Common escape sequences
                if next_char in 'ntrfvab\'"\\?':
                    value += self.advance()
                elif next_char in '0123456789':
                    # Octal escape sequence
                    for _ in range(3):
                        if self.peek() and self.peek() in '01234567':
                            value += self.advance()
                        else:
                            break
                elif next_char == 'x':
                    # Hex escape sequence
                    value += self.advance()  # x
                    while self.peek() and self.peek() in '0123456789abcdefABCDEF':
                        value += self.advance()
                else:
                    # Unknown escape sequence - just include it
                    value += self.advance()
            else:
                value += self.advance()
        
        return Token(TokenType.STRING_LITERAL, value, start_location)
    
    def read_char(self) -> Token:
        """Read a character literal.
        
        Returns:
            Token with type CHAR_LITERAL
        """
        start_location = self.current_location()
        value = ""
        
        # Skip opening quote
        value += self.advance()  # '
        
        if self.peek() == '\\':
            # Escape sequence
            value += self.advance()  # \
            if self.peek():
                value += self.advance()
        elif self.peek() and self.peek() != "'":
            value += self.advance()
        
        # Expect closing quote
        if self.peek() == "'":
            value += self.advance()  # '
        else:
            self.error_reporter.error(
                start_location,
                "Unterminated character literal"
            )
        
        return Token(TokenType.CHAR_LITERAL, value, start_location)
    
    def read_operator_or_punctuation(self) -> Optional[Token]:
        """Read an operator or punctuation token.
        
        Returns:
            Token with appropriate type, or None if not recognized
        """
        start_location = self.current_location()
        char = self.peek()
        
        if char is None:
            return None
        
        # Three-character operators
        if char == '.' and self.peek(1) == '.' and self.peek(2) == '.':
            value = self.advance() + self.advance() + self.advance()
            return Token(TokenType.ELLIPSIS, value, start_location)
        
        if char == '<' and self.peek(1) == '<' and self.peek(2) == '=':
            value = self.advance() + self.advance() + self.advance()
            return Token(TokenType.LSHIFT_ASSIGN, value, start_location)
        
        if char == '>' and self.peek(1) == '>' and self.peek(2) == '=':
            value = self.advance() + self.advance() + self.advance()
            return Token(TokenType.RSHIFT_ASSIGN, value, start_location)
        
        # Two-character operators
        two_char_ops = {
            '++': TokenType.PLUS_PLUS,
            '--': TokenType.MINUS_MINUS,
            '->': TokenType.ARROW,
            '+=': TokenType.PLUS_ASSIGN,
            '-=': TokenType.MINUS_ASSIGN,
            '*=': TokenType.STAR_ASSIGN,
            '/=': TokenType.SLASH_ASSIGN,
            '%=': TokenType.PERCENT_ASSIGN,
            '&=': TokenType.AMPERSAND_ASSIGN,
            '|=': TokenType.PIPE_ASSIGN,
            '^=': TokenType.CARET_ASSIGN,
            '<<': TokenType.LSHIFT,
            '>>': TokenType.RSHIFT,
            '==': TokenType.EQ,
            '!=': TokenType.NE,
            '<=': TokenType.LE,
            '>=': TokenType.GE,
            '&&': TokenType.LOGICAL_AND,
            '||': TokenType.LOGICAL_OR,
        }
        
        two_char = char + (self.peek(1) or '')
        if two_char in two_char_ops:
            value = self.advance() + self.advance()
            return Token(two_char_ops[two_char], value, start_location)
        
        # Single-character operators and punctuation
        single_char_ops = {
            '+': TokenType.PLUS,
            '-': TokenType.MINUS,
            '*': TokenType.STAR,
            '/': TokenType.SLASH,
            '%': TokenType.PERCENT,
            '&': TokenType.AMPERSAND,
            '|': TokenType.PIPE,
            '^': TokenType.CARET,
            '~': TokenType.TILDE,
            '!': TokenType.EXCLAMATION,
            '?': TokenType.QUESTION,
            ':': TokenType.COLON,
            '=': TokenType.ASSIGN,
            '<': TokenType.LT,
            '>': TokenType.GT,
            '(': TokenType.LPAREN,
            ')': TokenType.RPAREN,
            '{': TokenType.LBRACE,
            '}': TokenType.RBRACE,
            '[': TokenType.LBRACKET,
            ']': TokenType.RBRACKET,
            ';': TokenType.SEMICOLON,
            ',': TokenType.COMMA,
            '.': TokenType.DOT,
            '#': TokenType.HASH,
        }
        
        if char in single_char_ops:
            value = self.advance()
            return Token(single_char_ops[char], value, start_location)
        
        return None
    
    def next_token(self) -> Token:
        """Get the next token from the source.
        
        Returns:
            The next token, or EOF token if at end of source
        """
        # Skip whitespace and comments
        while True:
            self.skip_whitespace()
            
            # Check for comments
            if self.peek() == '/' and self.peek(1) == '/':
                self.skip_line_comment()
            elif self.peek() == '/' and self.peek(1) == '*':
                self.skip_block_comment()
            else:
                break
        
        # Check for EOF
        if self.peek() is None:
            return Token(TokenType.EOF, "", self.current_location())
        
        char = self.peek()
        
        # Identifier or keyword
        if char.isalpha() or char == '_':
            return self.read_identifier()
        
        # Number
        if char.isdigit():
            return self.read_number()
        
        # String literal
        if char == '"':
            return self.read_string()
        
        # Character literal
        if char == "'":
            return self.read_char()
        
        # Operator or punctuation
        token = self.read_operator_or_punctuation()
        if token:
            return token
        
        # Invalid character
        location = self.current_location()
        invalid_char = self.advance()
        self.error_reporter.error(
            location,
            f"Invalid character: '{invalid_char}'"
        )
        
        # Continue tokenizing after error
        return self.next_token()
    
    def peek_token(self) -> Token:
        """Peek at the next token without consuming it.
        
        Returns:
            The next token
        """
        # Save current state
        saved_pos = self.pos
        saved_line = self.line
        saved_column = self.column
        
        # Get next token
        token = self.next_token()
        
        # Restore state
        self.pos = saved_pos
        self.line = saved_line
        self.column = saved_column
        
        return token
    
    def tokenize_all(self) -> List[Token]:
        """Tokenize the entire source into a list of tokens.
        
        Returns:
            List of all tokens including EOF
        """
        tokens = []
        
        while True:
            token = self.next_token()
            tokens.append(token)
            
            if token.type == TokenType.EOF:
                break
        
        return tokens
