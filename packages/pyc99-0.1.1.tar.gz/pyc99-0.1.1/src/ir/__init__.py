"""Intermediate representation module for platform-independent code."""

from src.ir.ir_nodes import (
    IROpcode,
    IRValue,
    VirtualRegister,
    Constant,
    GlobalVariable,
    Label,
    IRInstruction,
    BinaryInstruction,
    UnaryInstruction,
    LoadInstruction,
    StoreInstruction,
    AllocaInstruction,
    BranchInstruction,
    ConditionalBranchInstruction,
    ReturnInstruction,
    CallInstruction,
    CastInstruction,
)

from src.ir.basic_block import (
    BasicBlock,
    ControlFlowGraph,
)

from src.ir.ir_module import (
    IRFunction,
    IRModule,
)

from src.ir.ir_generator import (
    IRGenerator,
)

__all__ = [
    # Opcodes
    'IROpcode',
    
    # Values
    'IRValue',
    'VirtualRegister',
    'Constant',
    'GlobalVariable',
    'Label',
    
    # Instructions
    'IRInstruction',
    'BinaryInstruction',
    'UnaryInstruction',
    'LoadInstruction',
    'StoreInstruction',
    'AllocaInstruction',
    'BranchInstruction',
    'ConditionalBranchInstruction',
    'ReturnInstruction',
    'CallInstruction',
    'CastInstruction',
    
    # Control flow
    'BasicBlock',
    'ControlFlowGraph',
    
    # Module
    'IRFunction',
    'IRModule',
    
    # Generator
    'IRGenerator',
]
