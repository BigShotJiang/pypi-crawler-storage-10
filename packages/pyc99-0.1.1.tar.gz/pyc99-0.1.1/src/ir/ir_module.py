"""IR module and function definitions."""

from dataclasses import dataclass, field
from typing import List, Optional, Dict

from src.parser.ast_nodes import Type
from src.ir.ir_nodes import IRValue, VirtualRegister, GlobalVariable
from src.ir.basic_block import BasicBlock, ControlFlowGraph


@dataclass
class IRFunction:
    """Represents a function in IR.
    
    Attributes:
        name: Function name
        return_type: Return type
        parameters: List of parameter registers
        cfg: Control flow graph
        local_variables: Dictionary of local variable allocations
        next_register_id: Counter for generating unique register names
        next_label_id_counter: Counter for generating unique label names
        is_variadic: Whether function accepts variable arguments
    """
    name: str
    return_type: Type
    parameters: List[VirtualRegister] = field(default_factory=list)
    cfg: Optional[ControlFlowGraph] = None
    local_variables: Dict[str, VirtualRegister] = field(default_factory=dict)
    next_register_id: int = 0
    next_label_id_counter: int = 0
    is_variadic: bool = False
    
    def next_label_id(self) -> int:
        """Get next unique label ID.
        
        Returns:
            Unique label ID
        """
        label_id = self.next_label_id_counter
        self.next_label_id_counter += 1
        return label_id
    
    def add_parameter(self, param: VirtualRegister) -> None:
        """Add a parameter to the function.
        
        Args:
            param: Parameter register
        """
        self.parameters.append(param)
    
    def add_basic_block(self, block: BasicBlock) -> None:
        """Add a basic block to the function's CFG.
        
        Args:
            block: Basic block to add
        """
        if self.cfg is None:
            # First block becomes entry block
            self.cfg = ControlFlowGraph(entry_block=block)
        self.cfg.add_block(block)
    
    def add_block(self, block: BasicBlock) -> None:
        """Alias for add_basic_block.
        
        Args:
            block: Basic block to add
        """
        self.add_basic_block(block)
    
    def get_cfg(self) -> ControlFlowGraph:
        """Get the control flow graph.
        
        Returns:
            Control flow graph
        """
        if self.cfg is None:
            raise ValueError(f"Function {self.name} has no CFG")
        return self.cfg
    
    def allocate_register(self, value_type: Type, name: Optional[str] = None) -> VirtualRegister:
        """Allocate a new virtual register.
        
        Args:
            value_type: Type of value to store in register
            name: Optional name hint for the register
            
        Returns:
            New virtual register
        """
        if name is None:
            name = f"%{self.next_register_id}"
            self.next_register_id += 1
        else:
            name = f"%{name}"
        
        return VirtualRegister(name=name, value_type=value_type)
    
    def add_local_variable(self, var_name: str, register: VirtualRegister) -> None:
        """Add a local variable mapping.
        
        Args:
            var_name: Variable name
            register: Register allocated for the variable
        """
        self.local_variables[var_name] = register
    
    def get_local_variable(self, var_name: str) -> Optional[VirtualRegister]:
        """Get the register for a local variable.
        
        Args:
            var_name: Variable name
            
        Returns:
            Register for the variable, or None if not found
        """
        return self.local_variables.get(var_name)
    
    def get_all_blocks(self) -> List[BasicBlock]:
        """Get all basic blocks in the function.
        
        Returns:
            List of basic blocks
        """
        return self.cfg.blocks if self.cfg else []
    
    def __repr__(self) -> str:
        param_str = ", ".join(str(p) for p in self.parameters)
        return f"IRFunction({self.name}({param_str}) -> {self.return_type})"


@dataclass
class IRModule:
    """Represents a complete IR module (translation unit).
    
    Attributes:
        name: Module name (usually source filename)
        functions: List of functions in the module
        global_variables: Dictionary of global variables
        string_literals: Dictionary of string literals (value -> StringLiteral)
        next_string_id: Counter for generating unique string labels
    """
    name: str
    functions: List[IRFunction] = field(default_factory=list)
    global_variables: Dict[str, GlobalVariable] = field(default_factory=dict)
    string_literals: Dict[str, 'StringLiteral'] = field(default_factory=dict)
    next_string_id: int = 0
    
    def add_function(self, function: IRFunction) -> None:
        """Add a function to the module.
        
        Args:
            function: Function to add
        """
        self.functions.append(function)
    
    def get_function(self, name: str) -> Optional[IRFunction]:
        """Get a function by name.
        
        Args:
            name: Function name
            
        Returns:
            Function with the given name, or None if not found
        """
        for func in self.functions:
            if func.name == name:
                return func
        return None
    
    def get_functions(self) -> List[IRFunction]:
        """Get all functions in the module.
        
        Returns:
            List of functions
        """
        return self.functions
    
    def add_global_variable(self, var: GlobalVariable) -> None:
        """Add a global variable to the module.
        
        Args:
            var: Global variable
        """
        self.global_variables[var.name] = var
    
    def get_global_variable(self, name: str) -> Optional[GlobalVariable]:
        """Get a global variable by name.
        
        Args:
            name: Variable name
            
        Returns:
            Global variable, or None if not found
        """
        return self.global_variables.get(name)
    
    def add_string_literal(self, value: str, is_wide: bool = False) -> 'StringLiteral':
        """Add a string literal to the data section with deduplication.
        
        If the same string already exists, returns the existing StringLiteral.
        
        Args:
            value: String value
            is_wide: Whether this is a wide string (L"...")
            
        Returns:
            StringLiteral object
        """
        from src.ir.ir_nodes import StringLiteral
        
        # Create a key for deduplication (include is_wide in key)
        key = (value, is_wide)
        
        # Check if string already exists
        if key in self.string_literals:
            return self.string_literals[key]
        
        # Create new string literal
        label = f".str{self.next_string_id}"
        self.next_string_id += 1
        
        str_lit = StringLiteral(label=label, value=value, is_wide=is_wide)
        self.string_literals[key] = str_lit
        
        return str_lit
    
    def get_string_literals(self) -> List['StringLiteral']:
        """Get all string literals in the module.
        
        Returns:
            List of string literals
        """
        return list(self.string_literals.values())
    
    def __repr__(self) -> str:
        return f"IRModule({self.name}, functions={len(self.functions)}, globals={len(self.global_variables)}, strings={len(self.string_literals)})"
