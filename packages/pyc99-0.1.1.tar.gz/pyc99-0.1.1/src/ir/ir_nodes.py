"""IR instruction and value definitions for the compiler."""

from dataclasses import dataclass, field
from typing import Optional, List, Any
from enum import Enum, auto

from src.parser.ast_nodes import Type
from src.utils.source_location import SourceLocation


# ============================================================================
# IR Opcodes
# ============================================================================

class IROpcode(Enum):
    """Opcodes for IR instructions."""
    # Integer arithmetic operations
    ADD = auto()
    SUB = auto()
    MUL = auto()
    DIV = auto()
    MOD = auto()
    NEG = auto()  # Unary negation
    
    # Floating-point arithmetic operations
    FADD = auto()  # Float add
    FSUB = auto()  # Float subtract
    FMUL = auto()  # Float multiply
    FDIV = auto()  # Float divide
    FNEG = auto()  # Float negation
    
    # Logical operations
    AND = auto()
    OR = auto()
    NOT = auto()
    XOR = auto()
    
    # Bitwise operations
    SHL = auto()  # Shift left
    SHR = auto()  # Shift right
    
    # Integer comparison operations
    EQ = auto()   # Equal
    NE = auto()   # Not equal
    LT = auto()   # Less than
    LE = auto()   # Less than or equal
    GT = auto()   # Greater than
    GE = auto()   # Greater than or equal
    
    # Floating-point comparison operations
    FEQ = auto()  # Float equal
    FNE = auto()  # Float not equal
    FLT = auto()  # Float less than
    FLE = auto()  # Float less than or equal
    FGT = auto()  # Float greater than
    FGE = auto()  # Float greater than or equal
    
    # Memory operations
    LOAD = auto()      # Load from memory
    STORE = auto()     # Store to memory
    ALLOCA = auto()    # Allocate stack space
    
    # Control flow operations
    BR = auto()        # Unconditional branch
    COND_BR = auto()   # Conditional branch
    RET = auto()       # Return from function
    CALL = auto()      # Function call
    
    # Type conversion operations
    CAST = auto()      # Type cast
    TRUNC = auto()     # Truncate to smaller type
    EXTEND = auto()    # Extend to larger type
    SEXT = auto()      # Sign extend
    ZEXT = auto()      # Zero extend
    
    # Float conversion operations
    FPTOSI = auto()    # Float to signed integer
    FPTOUI = auto()    # Float to unsigned integer
    SITOFP = auto()    # Signed integer to float
    UITOFP = auto()    # Unsigned integer to float
    FPTRUNC = auto()   # Float truncate (double to float)
    FPEXT = auto()     # Float extend (float to double)
    
    # Address operations
    ADDR_OF = auto()   # Get address of variable
    
    # Phi node for SSA (optional, for future use)
    PHI = auto()


# ============================================================================
# IR Values
# ============================================================================

@dataclass(unsafe_hash=True)
class IRValue:
    """Base class for IR values."""
    value_type: Type
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"


@dataclass(unsafe_hash=True)
class VirtualRegister(IRValue):
    """Virtual register in IR.
    
    Virtual registers have infinite supply and are mapped to physical
    registers during code generation.
    
    Attributes:
        name: Register name (e.g., '%0', '%1', '%temp')
        value_type: Type of value stored in register
    """
    name: str
    
    def __repr__(self) -> str:
        return f"{self.name}"


@dataclass(unsafe_hash=True)
class Constant(IRValue):
    """Constant value in IR.
    
    Attributes:
        value: The constant value
        value_type: Type of the constant
    """
    value: Any
    
    def __repr__(self) -> str:
        return f"{self.value}"


@dataclass(unsafe_hash=True)
class GlobalVariable(IRValue):
    """Global variable reference in IR.
    
    Attributes:
        name: Variable name
        value_type: Type of the variable
    """
    name: str
    
    def __repr__(self) -> str:
        return f"@{self.name}"


@dataclass
class Label:
    """Label for basic blocks.
    
    Attributes:
        name: Label name
    """
    name: str
    
    def __repr__(self) -> str:
        return f".{self.name}"


@dataclass
class StringLiteral:
    """String literal in data section.
    
    Attributes:
        label: Unique label for the string
        value: String value (with escape sequences resolved)
        is_wide: Whether this is a wide string (L"...")
    """
    label: str
    value: str
    is_wide: bool = False
    
    def __repr__(self) -> str:
        return f"StringLiteral({self.label}, {repr(self.value)})"


# ============================================================================
# IR Instructions
# ============================================================================

@dataclass
class IRInstruction:
    """Base class for IR instructions.
    
    Attributes:
        opcode: Instruction opcode
        result: Result register (None for instructions without result)
        operands: List of operand values
        location: Source location for debugging
    """
    opcode: IROpcode
    result: Optional[VirtualRegister]
    operands: List[IRValue]
    location: Optional[SourceLocation] = None
    
    def __repr__(self) -> str:
        result_str = f"{self.result} = " if self.result else ""
        operands_str = ", ".join(str(op) for op in self.operands)
        return f"{result_str}{self.opcode.name} {operands_str}"


# ============================================================================
# Specialized Instruction Classes
# ============================================================================

@dataclass
class BinaryInstruction(IRInstruction):
    """Binary operation instruction.
    
    Attributes:
        opcode: Operation (ADD, SUB, MUL, etc.)
        result: Result register
        left: Left operand
        right: Right operand
    """
    left: IRValue = field(init=False)
    right: IRValue = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 2:
            self.left = self.operands[0]
            self.right = self.operands[1]


@dataclass
class UnaryInstruction(IRInstruction):
    """Unary operation instruction.
    
    Attributes:
        opcode: Operation (NEG, NOT, etc.)
        result: Result register
        operand: Operand value
    """
    operand: IRValue = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 1:
            self.operand = self.operands[0]


@dataclass
class LoadInstruction(IRInstruction):
    """Load from memory instruction.
    
    Attributes:
        result: Result register
        address: Address to load from
    """
    address: IRValue = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 1:
            self.address = self.operands[0]


@dataclass
class StoreInstruction(IRInstruction):
    """Store to memory instruction.
    
    Attributes:
        value: Value to store
        address: Address to store to
    """
    value: IRValue = field(init=False)
    address: IRValue = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 2:
            self.value = self.operands[0]
            self.address = self.operands[1]


@dataclass
class AllocaInstruction(IRInstruction):
    """Allocate stack space instruction.
    
    Attributes:
        result: Result register (pointer to allocated space)
        alloc_type: Type of value to allocate space for
        count: Number of elements (None for single element)
    """
    alloc_type: Optional[Type] = None
    count: Optional[IRValue] = None


@dataclass
class BranchInstruction(IRInstruction):
    """Unconditional branch instruction.
    
    Attributes:
        target: Target basic block label
    """
    target: Label = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 1:
            self.target = self.operands[0]


@dataclass
class ConditionalBranchInstruction(IRInstruction):
    """Conditional branch instruction.
    
    Attributes:
        condition: Condition value
        true_target: Target if condition is true
        false_target: Target if condition is false
    """
    condition: IRValue = field(init=False)
    true_target: Label = field(init=False)
    false_target: Label = field(init=False)
    
    def __post_init__(self):
        if len(self.operands) >= 3:
            self.condition = self.operands[0]
            self.true_target = self.operands[1]
            self.false_target = self.operands[2]


@dataclass
class ReturnInstruction(IRInstruction):
    """Return from function instruction.
    
    Attributes:
        value: Return value (None for void return)
    """
    value: Optional[IRValue] = field(init=False)
    
    def __post_init__(self):
        self.value = self.operands[0] if self.operands else None


@dataclass
class CallInstruction(IRInstruction):
    """Function call instruction.
    
    Attributes:
        result: Result register (None for void functions)
        function: Function to call (name or function pointer)
        arguments: List of argument values
    """
    function: IRValue = field(init=False)
    arguments: List[IRValue] = field(init=False, default_factory=list)
    
    def __post_init__(self):
        if len(self.operands) >= 1:
            self.function = self.operands[0]
            self.arguments = self.operands[1:] if len(self.operands) > 1 else []


@dataclass
class CastInstruction(IRInstruction):
    """Type cast instruction.
    
    Attributes:
        result: Result register
        operand: Value to cast
        target_type: Type to cast to
    """
    target_type: Optional[Type] = None
    operand: IRValue = field(init=False, default=None)
    
    def __post_init__(self):
        if len(self.operands) >= 1:
            self.operand = self.operands[0]
