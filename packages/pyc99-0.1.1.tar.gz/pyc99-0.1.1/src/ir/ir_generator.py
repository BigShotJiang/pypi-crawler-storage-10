"""IR generator that transforms AST to IR."""

from typing import Optional, Dict, List

from src.parser.ast_nodes import (
    ASTNode, TranslationUnit, Declaration, Statement, Expression,
    FunctionDecl, VarDecl, CompoundStmt, ExpressionStmt, IfStmt,
    WhileStmt, DoWhileStmt, ForStmt, ReturnStmt, BreakStmt, ContinueStmt,
    SwitchStmt, CaseStmt, GotoStmt, LabelStmt,
    BinaryExpr, UnaryExpr, Literal, Identifier, CallExpr, AssignmentExpr,
    CastExpr, ArraySubscript, MemberAccess, ConditionalExpr, CommaExpr,
    SizeofExpr, PrimitiveType, PointerType, ArrayType, Type
)
from src.ir.ir_nodes import (
    IROpcode, IRValue, VirtualRegister, Constant, GlobalVariable, Label,
    IRInstruction, BinaryInstruction, UnaryInstruction, LoadInstruction,
    StoreInstruction, AllocaInstruction, BranchInstruction,
    ConditionalBranchInstruction, ReturnInstruction, CallInstruction,
    CastInstruction
)
from src.ir.basic_block import BasicBlock, ControlFlowGraph
from src.ir.ir_module import IRFunction, IRModule
from src.utils.error_reporter import ErrorReporter


class IRGenerator:
    """Generates IR from annotated AST.
    
    This class traverses the AST and generates three-address code IR
    with explicit control flow.
    
    Attributes:
        ast: Annotated AST to generate IR from
        error_reporter: Error reporter for diagnostics
        module: IR module being built
        current_function: Currently processed function
        current_block: Currently active basic block
        next_label_id: Counter for generating unique labels
        break_targets: Stack of break target labels
        continue_targets: Stack of continue target labels
    """
    
    def __init__(self, ast: TranslationUnit, error_reporter: ErrorReporter):
        """Initialize IR generator.
        
        Args:
            ast: Annotated AST
            error_reporter: Error reporter
        """
        self.ast = ast
        self.error_reporter = error_reporter
        self.module: Optional[IRModule] = None
        self.current_function: Optional[IRFunction] = None
        self.current_block: Optional[BasicBlock] = None
        self.next_label_id = 0
        
        # Control flow tracking
        self.break_targets: List[Label] = []
        self.continue_targets: List[Label] = []
        
        # Label tracking for goto/label statements
        self.label_map: Dict[str, Label] = {}  # Maps label names to IR labels
        
        # Switch statement tracking
        self.switch_end_labels: List[Label] = []  # Stack of switch end labels
    
    def generate(self) -> IRModule:
        """Generate IR module from AST.
        
        Returns:
            Generated IR module
        """
        # Create module
        self.module = IRModule(name="main")
        
        # Process all top-level declarations
        for decl in self.ast.declarations:
            self._generate_declaration(decl)
        
        return self.module
    
    def _generate_label(self, hint: str = "label") -> Label:
        """Generate a unique label.
        
        Args:
            hint: Hint for label name
            
        Returns:
            New label
        """
        label = Label(name=f"{hint}_{self.next_label_id}")
        self.next_label_id += 1
        return label
    
    def _generate_declaration(self, decl: Declaration) -> None:
        """Generate IR for a declaration.
        
        Args:
            decl: Declaration to process
        """
        if isinstance(decl, VarDecl):
            self._generate_var_decl(decl)
        elif isinstance(decl, FunctionDecl):
            self._generate_function_decl(decl)
        # Other declaration types (struct, enum, typedef) don't generate IR
    
    def _generate_var_decl(self, decl: VarDecl) -> None:
        """Generate IR for a variable declaration.
        
        Args:
            decl: Variable declaration
        """
        from src.parser.ast_nodes import StructType, InitializerList
        
        if self.current_function is None:
            # Global variable
            global_var = GlobalVariable(name=decl.name, value_type=decl.var_type)
            self.module.add_global_variable(global_var)
        else:
            # Local variable - allocate on stack
            result_reg = self.current_function.allocate_register(
                PointerType(pointee_type=decl.var_type, qualifiers=(), location=decl.location)
            )
            
            alloca_inst = AllocaInstruction(
                opcode=IROpcode.ALLOCA,
                result=result_reg,
                operands=[],
                alloc_type=decl.var_type,
                location=decl.location
            )
            self.current_block.add_instruction(alloca_inst)
            
            # Track local variable
            self.current_function.add_local_variable(decl.name, result_reg)
            
            # Generate initializer if present
            if decl.initializer is not None:
                # Special handling for struct initialization
                if isinstance(decl.var_type, StructType) and isinstance(decl.initializer, InitializerList):
                    self._generate_struct_initialization(result_reg, decl.var_type, decl.initializer)
                # Special handling for array initialization with string literal
                elif isinstance(decl.var_type, ArrayType) and isinstance(decl.initializer, Literal) and decl.initializer.literal_type == 'string':
                    self._generate_string_array_initialization(result_reg, decl.var_type, decl.initializer)
                else:
                    init_value = self._generate_expression(decl.initializer)
                    store_inst = StoreInstruction(
                        opcode=IROpcode.STORE,
                        result=None,
                        operands=[init_value, result_reg],
                        location=decl.location
                    )
                    self.current_block.add_instruction(store_inst)
    
    def _generate_function_decl(self, decl: FunctionDecl) -> None:
        """Generate IR for a function declaration.
        
        Args:
            decl: Function declaration
        """
        # Only generate IR for function definitions (with body)
        if decl.body is None:
            return
        
        # Create IR function
        ir_func = IRFunction(
            name=decl.name,
            return_type=decl.return_type,
            is_variadic=decl.is_variadic
        )
        
        # Add parameters
        for param in decl.parameters:
            if param.name is not None:
                param_reg = ir_func.allocate_register(param.param_type, param.name)
                ir_func.add_parameter(param_reg)
                # Also track as local variable
                ir_func.add_local_variable(param.name, param_reg)
        
        self.current_function = ir_func
        
        # Clear label map for this function
        self.label_map = {}
        
        # Create entry block
        entry_label = Label(name=f"{decl.name}_entry")
        entry_block = BasicBlock(label=entry_label)
        ir_func.add_basic_block(entry_block)
        self.current_block = entry_block
        
        # Generate function body
        self._generate_statement(decl.body)
        
        # Add implicit return if function doesn't end with one
        last_inst = self.current_block.get_terminator()
        if last_inst is None or last_inst.opcode != IROpcode.RET:
            # Add return void or return 0 for int main
            from src.semantic.type_utils import is_void_type
            if is_void_type(decl.return_type):
                ret_inst = ReturnInstruction(
                    opcode=IROpcode.RET,
                    result=None,
                    operands=[],
                    location=decl.location
                )
            else:
                # Return 0 for non-void functions (mainly for main)
                zero = Constant(value=0, value_type=decl.return_type)
                ret_inst = ReturnInstruction(
                    opcode=IROpcode.RET,
                    result=None,
                    operands=[zero],
                    location=decl.location
                )
            self.current_block.add_instruction(ret_inst)
        
        # Add function to module
        self.module.add_function(ir_func)
        self.current_function = None
        self.current_block = None

    
    def _generate_statement(self, stmt: Statement) -> None:
        """Generate IR for a statement.
        
        Args:
            stmt: Statement to process
        """
        if isinstance(stmt, CompoundStmt):
            self._generate_compound_stmt(stmt)
        elif isinstance(stmt, ExpressionStmt):
            self._generate_expression_stmt(stmt)
        elif isinstance(stmt, IfStmt):
            self._generate_if_stmt(stmt)
        elif isinstance(stmt, WhileStmt):
            self._generate_while_stmt(stmt)
        elif isinstance(stmt, DoWhileStmt):
            self._generate_do_while_stmt(stmt)
        elif isinstance(stmt, ForStmt):
            self._generate_for_stmt(stmt)
        elif isinstance(stmt, ReturnStmt):
            self._generate_return_stmt(stmt)
        elif isinstance(stmt, BreakStmt):
            self._generate_break_stmt(stmt)
        elif isinstance(stmt, ContinueStmt):
            self._generate_continue_stmt(stmt)
        elif isinstance(stmt, SwitchStmt):
            self._generate_switch_stmt(stmt)
        elif isinstance(stmt, CaseStmt):
            self._generate_case_stmt(stmt)
        elif isinstance(stmt, GotoStmt):
            self._generate_goto_stmt(stmt)
        elif isinstance(stmt, LabelStmt):
            self._generate_label_stmt(stmt)
        elif isinstance(stmt, Declaration):
            # Declarations can appear as statements in C99
            self._generate_declaration(stmt)
    
    def _generate_compound_stmt(self, stmt: CompoundStmt) -> None:
        """Generate IR for a compound statement.
        
        Args:
            stmt: Compound statement
        """
        for s in stmt.statements:
            self._generate_statement(s)
    
    def _generate_expression_stmt(self, stmt: ExpressionStmt) -> None:
        """Generate IR for an expression statement.
        
        Args:
            stmt: Expression statement
        """
        if stmt.expression is not None:
            self._generate_expression(stmt.expression)
    
    def _generate_if_stmt(self, stmt: IfStmt) -> None:
        """Generate IR for an if statement.
        
        Args:
            stmt: If statement
        """
        # Generate condition
        cond_value = self._generate_expression(stmt.condition)
        
        # Create labels
        then_label = self._generate_label("if_then")
        else_label = self._generate_label("if_else")
        end_label = self._generate_label("if_end")
        
        # Generate conditional branch
        if stmt.else_stmt is not None:
            cond_br = ConditionalBranchInstruction(
                opcode=IROpcode.COND_BR,
                result=None,
                operands=[cond_value, then_label, else_label],
                location=stmt.location
            )
        else:
            cond_br = ConditionalBranchInstruction(
                opcode=IROpcode.COND_BR,
                result=None,
                operands=[cond_value, then_label, end_label],
                location=stmt.location
            )
        self.current_block.add_instruction(cond_br)
        
        # Generate then block
        then_block = BasicBlock(label=then_label)
        self.current_function.add_basic_block(then_block)
        self.current_function.cfg.add_edge(self.current_block, then_block)
        self.current_block = then_block
        
        self._generate_statement(stmt.then_stmt)
        
        # Branch to end if no terminator
        if self.current_block.get_terminator() is None or \
           self.current_block.get_terminator().opcode not in [IROpcode.RET, IROpcode.BR]:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[end_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Generate else block if present
        if stmt.else_stmt is not None:
            else_block = BasicBlock(label=else_label)
            self.current_function.add_basic_block(else_block)
            self.current_function.cfg.add_edge(self.current_block, else_block)
            self.current_block = else_block
            
            self._generate_statement(stmt.else_stmt)
            
            # Branch to end if no terminator
            if self.current_block.get_terminator() is None or \
               self.current_block.get_terminator().opcode not in [IROpcode.RET, IROpcode.BR]:
                br = BranchInstruction(
                    opcode=IROpcode.BR,
                    result=None,
                    operands=[end_label],
                    location=stmt.location
                )
                self.current_block.add_instruction(br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(self.current_block, end_block)
        self.current_block = end_block
    
    def _generate_while_stmt(self, stmt: WhileStmt) -> None:
        """Generate IR for a while statement.
        
        Args:
            stmt: While statement
        """
        # Create labels
        cond_label = self._generate_label("while_cond")
        body_label = self._generate_label("while_body")
        end_label = self._generate_label("while_end")
        
        # Branch to condition
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[cond_label],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
        
        # Generate condition block
        cond_block = BasicBlock(label=cond_label)
        self.current_function.add_basic_block(cond_block)
        self.current_function.cfg.add_edge(self.current_block, cond_block)
        self.current_block = cond_block
        
        cond_value = self._generate_expression(stmt.condition)
        cond_br = ConditionalBranchInstruction(
            opcode=IROpcode.COND_BR,
            result=None,
            operands=[cond_value, body_label, end_label],
            location=stmt.location
        )
        self.current_block.add_instruction(cond_br)
        
        # Generate body block
        body_block = BasicBlock(label=body_label)
        self.current_function.add_basic_block(body_block)
        self.current_function.cfg.add_edge(self.current_block, body_block)
        self.current_block = body_block
        
        # Track break/continue targets
        self.break_targets.append(end_label)
        self.continue_targets.append(cond_label)
        
        self._generate_statement(stmt.body)
        
        self.break_targets.pop()
        self.continue_targets.pop()
        
        # Branch back to condition
        if self.current_block.get_terminator() is None or \
           self.current_block.get_terminator().opcode not in [IROpcode.RET, IROpcode.BR]:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[cond_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(cond_block, end_block)
        self.current_block = end_block
    
    def _generate_do_while_stmt(self, stmt: DoWhileStmt) -> None:
        """Generate IR for a do-while statement.
        
        Args:
            stmt: Do-while statement
        """
        # Create labels
        body_label = self._generate_label("do_body")
        cond_label = self._generate_label("do_cond")
        end_label = self._generate_label("do_end")
        
        # Branch to body
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[body_label],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
        
        # Generate body block
        body_block = BasicBlock(label=body_label)
        self.current_function.add_basic_block(body_block)
        self.current_function.cfg.add_edge(self.current_block, body_block)
        self.current_block = body_block
        
        # Track break/continue targets
        self.break_targets.append(end_label)
        self.continue_targets.append(cond_label)
        
        self._generate_statement(stmt.body)
        
        self.break_targets.pop()
        self.continue_targets.pop()
        
        # Branch to condition
        if self.current_block.get_terminator() is None or \
           self.current_block.get_terminator().opcode not in [IROpcode.RET, IROpcode.BR]:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[cond_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Generate condition block
        cond_block = BasicBlock(label=cond_label)
        self.current_function.add_basic_block(cond_block)
        self.current_function.cfg.add_edge(self.current_block, cond_block)
        self.current_block = cond_block
        
        cond_value = self._generate_expression(stmt.condition)
        cond_br = ConditionalBranchInstruction(
            opcode=IROpcode.COND_BR,
            result=None,
            operands=[cond_value, body_label, end_label],
            location=stmt.location
        )
        self.current_block.add_instruction(cond_br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(cond_block, end_block)
        self.current_block = end_block
    
    def _generate_for_stmt(self, stmt: ForStmt) -> None:
        """Generate IR for a for statement.
        
        Args:
            stmt: For statement
        """
        # Generate init
        if stmt.init is not None:
            if isinstance(stmt.init, Declaration):
                self._generate_declaration(stmt.init)
            else:
                self._generate_expression(stmt.init)
        
        # Create labels
        cond_label = self._generate_label("for_cond")
        body_label = self._generate_label("for_body")
        inc_label = self._generate_label("for_inc")
        end_label = self._generate_label("for_end")
        
        # Branch to condition
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[cond_label],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
        
        # Generate condition block
        cond_block = BasicBlock(label=cond_label)
        self.current_function.add_basic_block(cond_block)
        self.current_function.cfg.add_edge(self.current_block, cond_block)
        self.current_block = cond_block
        
        if stmt.condition is not None:
            cond_value = self._generate_expression(stmt.condition)
            cond_br = ConditionalBranchInstruction(
                opcode=IROpcode.COND_BR,
                result=None,
                operands=[cond_value, body_label, end_label],
                location=stmt.location
            )
            self.current_block.add_instruction(cond_br)
        else:
            # No condition means infinite loop
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[body_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Generate body block
        body_block = BasicBlock(label=body_label)
        self.current_function.add_basic_block(body_block)
        self.current_function.cfg.add_edge(self.current_block, body_block)
        self.current_block = body_block
        
        # Track break/continue targets
        self.break_targets.append(end_label)
        self.continue_targets.append(inc_label)
        
        self._generate_statement(stmt.body)
        
        self.break_targets.pop()
        self.continue_targets.pop()
        
        # Branch to increment
        if self.current_block.get_terminator() is None or \
           self.current_block.get_terminator().opcode not in [IROpcode.RET, IROpcode.BR]:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[inc_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Generate increment block
        inc_block = BasicBlock(label=inc_label)
        self.current_function.add_basic_block(inc_block)
        self.current_function.cfg.add_edge(self.current_block, inc_block)
        self.current_block = inc_block
        
        if stmt.increment is not None:
            self._generate_expression(stmt.increment)
        
        # Branch back to condition
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[cond_label],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(cond_block, end_block)
        self.current_block = end_block
    
    def _generate_return_stmt(self, stmt: ReturnStmt) -> None:
        """Generate IR for a return statement.
        
        Args:
            stmt: Return statement
        """
        if stmt.value is not None:
            value = self._generate_expression(stmt.value)
            ret_inst = ReturnInstruction(
                opcode=IROpcode.RET,
                result=None,
                operands=[value],
                location=stmt.location
            )
        else:
            ret_inst = ReturnInstruction(
                opcode=IROpcode.RET,
                result=None,
                operands=[],
                location=stmt.location
            )
        self.current_block.add_instruction(ret_inst)
    
    def _generate_break_stmt(self, stmt: BreakStmt) -> None:
        """Generate IR for a break statement.
        
        Args:
            stmt: Break statement
        """
        if not self.break_targets:
            self.error_reporter.error(
                stmt.location,
                "Break statement outside of loop or switch"
            )
            return
        
        target = self.break_targets[-1]
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[target],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
    
    def _generate_continue_stmt(self, stmt: ContinueStmt) -> None:
        """Generate IR for a continue statement.
        
        Args:
            stmt: Continue statement
        """
        if not self.continue_targets:
            self.error_reporter.error(
                stmt.location,
                "Continue statement outside of loop"
            )
            return
        
        target = self.continue_targets[-1]
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[target],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
    
    def _generate_switch_stmt(self, stmt: SwitchStmt) -> None:
        """Generate IR for a switch statement.
        
        This implementation generates a series of comparisons and branches.
        For dense case values, a jump table could be used (future optimization).
        
        Args:
            stmt: Switch statement
        """
        # Generate switch condition
        switch_value = self._generate_expression(stmt.condition)
        
        # Create end label for break statements
        end_label = self._generate_label("switch_end")
        self.break_targets.append(end_label)
        self.switch_end_labels.append(end_label)
        
        # Collect all case statements by traversing the body
        # We need to do a first pass to find all cases and default
        cases = []  # List of (value, label) tuples
        default_label = None
        
        # Helper to collect cases from statement tree
        def collect_cases(s: Statement):
            if isinstance(s, CaseStmt):
                if s.value is None:
                    # Default case
                    nonlocal default_label
                    if default_label is None:
                        default_label = self._generate_label("switch_default")
                else:
                    # Regular case
                    case_label = self._generate_label("switch_case")
                    cases.append((s.value, case_label))
            elif isinstance(s, CompoundStmt):
                for sub_stmt in s.statements:
                    collect_cases(sub_stmt)
            elif isinstance(s, LabelStmt):
                collect_cases(s.statement)
        
        collect_cases(stmt.body)
        
        # If no default, use end label
        if default_label is None:
            default_label = end_label
        
        # Generate comparison chain for each case
        # For each case, compare switch_value with case value
        # If equal, branch to case label, otherwise continue to next comparison
        for i, (case_value, case_label) in enumerate(cases):
            # Evaluate case value (should be constant)
            case_ir_value = self._generate_expression(case_value)
            
            # Compare switch_value == case_value
            cmp_result = self.current_function.allocate_register(
                PrimitiveType(name='int', location=stmt.location)
            )
            cmp_inst = BinaryInstruction(
                opcode=IROpcode.EQ,
                result=cmp_result,
                operands=[switch_value, case_ir_value],
                location=stmt.location
            )
            self.current_block.add_instruction(cmp_inst)
            
            # Create next comparison block or use default
            if i < len(cases) - 1:
                next_cmp_label = self._generate_label("switch_cmp")
            else:
                next_cmp_label = default_label
            
            # Conditional branch
            cond_br = ConditionalBranchInstruction(
                opcode=IROpcode.COND_BR,
                result=None,
                operands=[cmp_result, case_label, next_cmp_label],
                location=stmt.location
            )
            self.current_block.add_instruction(cond_br)
            
            # Create next comparison block if not last
            if i < len(cases) - 1:
                next_block = BasicBlock(label=next_cmp_label)
                self.current_function.add_basic_block(next_block)
                self.current_function.cfg.add_edge(self.current_block, next_block)
                self.current_block = next_block
        
        # Now generate the actual switch body with case labels
        # We need to track which case label to emit next
        self.case_labels = {id(case_value): case_label for case_value, case_label in cases}
        if default_label != end_label:
            self.default_label = default_label
        else:
            self.default_label = None
        
        # Generate the body (this will emit case labels as it encounters CaseStmt)
        self._generate_statement(stmt.body)
        
        # Clean up tracking
        self.case_labels = {}
        self.default_label = None
        
        # If current block doesn't have terminator, branch to end
        if self.current_block.get_terminator() is None:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[end_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(self.current_block, end_block)
        self.current_block = end_block
        
        # Pop break target
        self.break_targets.pop()
        self.switch_end_labels.pop()
    
    def _generate_case_stmt(self, stmt: CaseStmt) -> None:
        """Generate IR for a case statement.
        
        This creates a new basic block with the case label and continues
        generating code for the statement following the case.
        
        Args:
            stmt: Case statement
        """
        # Get the label for this case (set up by switch statement)
        if stmt.value is None:
            # Default case
            if hasattr(self, 'default_label') and self.default_label is not None:
                case_label = self.default_label
            else:
                # No default label set up, create one
                case_label = self._generate_label("switch_default")
        else:
            # Regular case - look up label
            if hasattr(self, 'case_labels') and id(stmt.value) in self.case_labels:
                case_label = self.case_labels[id(stmt.value)]
            else:
                # Fallback: create a new label
                case_label = self._generate_label("switch_case")
        
        # If current block doesn't have terminator, add branch to case block
        if self.current_block.get_terminator() is None:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[case_label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Create case block
        case_block = BasicBlock(label=case_label)
        self.current_function.add_basic_block(case_block)
        self.current_function.cfg.add_edge(self.current_block, case_block)
        self.current_block = case_block
        
        # Generate statement following case
        self._generate_statement(stmt.statement)
    
    def _generate_goto_stmt(self, stmt: GotoStmt) -> None:
        """Generate IR for a goto statement.
        
        Args:
            stmt: Goto statement
        """
        # Get or create label for target
        if stmt.label not in self.label_map:
            self.label_map[stmt.label] = self._generate_label(f"label_{stmt.label}")
        
        target_label = self.label_map[stmt.label]
        
        # Generate branch
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[target_label],
            location=stmt.location
        )
        self.current_block.add_instruction(br)
    
    def _generate_label_stmt(self, stmt: LabelStmt) -> None:
        """Generate IR for a label statement.
        
        Args:
            stmt: Label statement
        """
        # Get or create label
        if stmt.label not in self.label_map:
            self.label_map[stmt.label] = self._generate_label(f"label_{stmt.label}")
        
        label = self.label_map[stmt.label]
        
        # If current block doesn't have terminator, add branch to label block
        if self.current_block.get_terminator() is None:
            br = BranchInstruction(
                opcode=IROpcode.BR,
                result=None,
                operands=[label],
                location=stmt.location
            )
            self.current_block.add_instruction(br)
        
        # Create label block
        label_block = BasicBlock(label=label)
        self.current_function.add_basic_block(label_block)
        self.current_function.cfg.add_edge(self.current_block, label_block)
        self.current_block = label_block
        
        # Generate statement following label
        self._generate_statement(stmt.statement)

    
    def _generate_expression(self, expr: Expression) -> IRValue:
        """Generate IR for an expression.
        
        Args:
            expr: Expression to process
            
        Returns:
            IR value representing the expression result
        """
        if isinstance(expr, Literal):
            return self._generate_literal(expr)
        elif isinstance(expr, Identifier):
            return self._generate_identifier(expr)
        elif isinstance(expr, BinaryExpr):
            return self._generate_binary_expr(expr)
        elif isinstance(expr, UnaryExpr):
            return self._generate_unary_expr(expr)
        elif isinstance(expr, CallExpr):
            return self._generate_call_expr(expr)
        elif isinstance(expr, AssignmentExpr):
            return self._generate_assignment_expr(expr)
        elif isinstance(expr, CastExpr):
            return self._generate_cast_expr(expr)
        elif isinstance(expr, ConditionalExpr):
            return self._generate_conditional_expr(expr)
        elif isinstance(expr, CommaExpr):
            return self._generate_comma_expr(expr)
        elif isinstance(expr, ArraySubscript):
            return self._generate_array_subscript(expr)
        elif isinstance(expr, MemberAccess):
            return self._generate_member_access(expr)
        elif isinstance(expr, SizeofExpr):
            return self._generate_sizeof_expr(expr)
        else:
            self.error_reporter.error(
                expr.location,
                f"Unsupported expression type: {type(expr).__name__}"
            )
            # Return dummy value
            return Constant(value=0, value_type=PrimitiveType(name='int', location=expr.location))
    
    def _generate_literal(self, expr: Literal) -> IRValue:
        """Generate IR for a literal.
        
        Args:
            expr: Literal expression
            
        Returns:
            Constant value or reference to string literal
        """
        # Get type from expression (set by semantic analyzer)
        expr_type = getattr(expr, 'expr_type', None)
        if expr_type is None:
            # Fallback to inferring type from literal_type
            if expr.literal_type == 'int':
                expr_type = PrimitiveType(name='int', location=expr.location)
            elif expr.literal_type == 'float':
                expr_type = PrimitiveType(name='float', location=expr.location)
            elif expr.literal_type == 'char':
                expr_type = PrimitiveType(name='char', location=expr.location)
            elif expr.literal_type == 'string':
                # String literals are char arrays
                expr_type = PointerType(
                    pointee_type=PrimitiveType(name='char', location=expr.location),
                    qualifiers=(),
                    location=expr.location
                )
            else:
                expr_type = PrimitiveType(name='int', location=expr.location)
        
        # Handle string literals specially - add to data section
        if expr.literal_type == 'string':
            # Check if this is a wide string (starts with L")
            is_wide = isinstance(expr.value, str) and len(expr.value) > 0 and expr.value[0] == 'L'
            string_value = expr.value
            
            # Add string to data section (with deduplication)
            str_lit = self.module.add_string_literal(string_value, is_wide)
            
            # Return a constant with the label as the value
            # The label will be resolved to an address during code generation
            return Constant(value=str_lit.label, value_type=expr_type)
        
        return Constant(value=expr.value, value_type=expr_type)
    
    def _generate_identifier(self, expr: Identifier) -> IRValue:
        """Generate IR for an identifier.
        
        Args:
            expr: Identifier expression
            
        Returns:
            IR value for the identifier
        """
        # Check if it's a local variable
        local_var = self.current_function.get_local_variable(expr.name)
        if local_var is not None:
            # Load from local variable
            expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
            result_reg = self.current_function.allocate_register(expr_type)
            
            load_inst = LoadInstruction(
                opcode=IROpcode.LOAD,
                result=result_reg,
                operands=[local_var],
                location=expr.location
            )
            self.current_block.add_instruction(load_inst)
            return result_reg
        
        # Check if it's a global variable
        global_var = self.module.get_global_variable(expr.name)
        if global_var is not None:
            # Load from global variable
            expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
            result_reg = self.current_function.allocate_register(expr_type)
            
            load_inst = LoadInstruction(
                opcode=IROpcode.LOAD,
                result=result_reg,
                operands=[global_var],
                location=expr.location
            )
            self.current_block.add_instruction(load_inst)
            return result_reg
        
        # Might be a function name or enum constant
        # For now, return as a constant (will be handled by semantic analyzer)
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        return Constant(value=expr.name, value_type=expr_type)
    
    def _generate_binary_expr(self, expr: BinaryExpr) -> IRValue:
        """Generate IR for a binary expression.
        
        Args:
            expr: Binary expression
            
        Returns:
            IR value for the result
        """
        # Handle logical operators with short-circuit evaluation
        if expr.operator in ('&&', '||'):
            return self._generate_logical_expr(expr)
        
        # Generate operands
        left = self._generate_expression(expr.left)
        right = self._generate_expression(expr.right)
        
        # Get result type
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        
        # Check if this is a floating-point operation
        from src.semantic.type_utils import is_floating_type
        is_float_op = is_floating_type(expr_type)
        
        # Map operator to opcode (integer or float)
        if is_float_op:
            op_map = {
                '+': IROpcode.FADD,
                '-': IROpcode.FSUB,
                '*': IROpcode.FMUL,
                '/': IROpcode.FDIV,
                '==': IROpcode.FEQ,
                '!=': IROpcode.FNE,
                '<': IROpcode.FLT,
                '<=': IROpcode.FLE,
                '>': IROpcode.FGT,
                '>=': IROpcode.FGE,
            }
        else:
            op_map = {
                '+': IROpcode.ADD,
                '-': IROpcode.SUB,
                '*': IROpcode.MUL,
                '/': IROpcode.DIV,
                '%': IROpcode.MOD,
                '&': IROpcode.AND,
                '|': IROpcode.OR,
                '^': IROpcode.XOR,
                '<<': IROpcode.SHL,
                '>>': IROpcode.SHR,
                '==': IROpcode.EQ,
                '!=': IROpcode.NE,
                '<': IROpcode.LT,
                '<=': IROpcode.LE,
                '>': IROpcode.GT,
                '>=': IROpcode.GE,
            }
        
        opcode = op_map.get(expr.operator)
        if opcode is None:
            self.error_reporter.error(
                expr.location,
                f"Unsupported binary operator: {expr.operator}"
            )
            return left
        
        # For comparison operations, result is always int (boolean)
        if expr.operator in ('==', '!=', '<', '<=', '>', '>='):
            result_type = PrimitiveType(name='int', location=expr.location)
        else:
            result_type = expr_type
        
        result_reg = self.current_function.allocate_register(result_type)
        
        # Generate instruction
        bin_inst = BinaryInstruction(
            opcode=opcode,
            result=result_reg,
            operands=[left, right],
            location=expr.location
        )
        self.current_block.add_instruction(bin_inst)
        
        return result_reg
    
    def _generate_logical_expr(self, expr: BinaryExpr) -> IRValue:
        """Generate IR for logical && or || operators.
        
        For simplicity, we evaluate both operands and use bitwise operations.
        This doesn't implement short-circuit evaluation but is simpler.
        
        Args:
            expr: Binary expression with && or ||
            
        Returns:
            IR value for the result
        """
        result_type = PrimitiveType(name='int', location=expr.location)
        
        # Evaluate both operands
        left_val = self._generate_expression(expr.left)
        right_val = self._generate_expression(expr.right)
        
        # Convert left to boolean (compare with 0)
        left_bool = self.current_function.allocate_register(result_type)
        cmp_inst1 = BinaryInstruction(
            opcode=IROpcode.NE,
            result=left_bool,
            operands=[left_val, Constant(value=0, value_type=result_type)],
            location=expr.location
        )
        self.current_block.add_instruction(cmp_inst1)
        
        # Convert right to boolean (compare with 0)
        right_bool = self.current_function.allocate_register(result_type)
        cmp_inst2 = BinaryInstruction(
            opcode=IROpcode.NE,
            result=right_bool,
            operands=[right_val, Constant(value=0, value_type=result_type)],
            location=expr.location
        )
        self.current_block.add_instruction(cmp_inst2)
        
        # Combine using bitwise AND or OR
        result_reg = self.current_function.allocate_register(result_type)
        if expr.operator == '&&':
            # Logical AND: both must be true
            combine_inst = BinaryInstruction(
                opcode=IROpcode.AND,
                result=result_reg,
                operands=[left_bool, right_bool],
                location=expr.location
            )
        else:  # ||
            # Logical OR: at least one must be true
            combine_inst = BinaryInstruction(
                opcode=IROpcode.OR,
                result=result_reg,
                operands=[left_bool, right_bool],
                location=expr.location
            )
        
        self.current_block.add_instruction(combine_inst)
        
        return result_reg
    
    def _generate_unary_expr(self, expr: UnaryExpr) -> IRValue:
        """Generate IR for a unary expression.
        
        Args:
            expr: Unary expression
            
        Returns:
            IR value for the result
        """
        # Handle address-of operator
        if expr.operator == '&':
            # Get address of operand
            if isinstance(expr.operand, Identifier):
                # Get variable address
                local_var = self.current_function.get_local_variable(expr.operand.name)
                if local_var is not None:
                    return local_var  # Already a pointer
                
                global_var = self.module.get_global_variable(expr.operand.name)
                if global_var is not None:
                    return global_var  # Already a pointer
            
            # For other cases, generate the operand and take its address
            operand = self._generate_expression(expr.operand)
            return operand
        
        # Handle dereference operator
        if expr.operator == '*':
            # Load from pointer
            operand = self._generate_expression(expr.operand)
            expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
            result_reg = self.current_function.allocate_register(expr_type)
            
            load_inst = LoadInstruction(
                opcode=IROpcode.LOAD,
                result=result_reg,
                operands=[operand],
                location=expr.location
            )
            self.current_block.add_instruction(load_inst)
            return result_reg
        
        # Handle increment/decrement operators
        if expr.operator in ('++', '--'):
            # Get operand address
            operand_addr = self._generate_lvalue_address(expr.operand)
            
            # Get operand type
            operand_type = getattr(expr.operand, 'expr_type', PrimitiveType(name='int', location=expr.location))
            
            # Load current value
            current_value = self.current_function.allocate_register(operand_type)
            load_inst = LoadInstruction(
                opcode=IROpcode.LOAD,
                result=current_value,
                operands=[operand_addr],
                location=expr.location
            )
            self.current_block.add_instruction(load_inst)
            
            # Determine increment/decrement amount
            # For pointers, increment by size of pointed-to type
            # For integers, increment by 1
            from src.semantic.type_utils import is_pointer_type, get_pointer_base_type
            if is_pointer_type(operand_type):
                base_type = get_pointer_base_type(operand_type)
                increment_amount = self._get_type_size(base_type)
            else:
                increment_amount = 1
            
            # Create constant for increment/decrement
            increment_const = Constant(value=increment_amount, value_type=operand_type)
            
            # Perform addition or subtraction
            opcode = IROpcode.ADD if expr.operator == '++' else IROpcode.SUB
            new_value = self.current_function.allocate_register(operand_type)
            arith_inst = BinaryInstruction(
                opcode=opcode,
                result=new_value,
                operands=[current_value, increment_const],
                location=expr.location
            )
            self.current_block.add_instruction(arith_inst)
            
            # Store new value back
            store_inst = StoreInstruction(
                opcode=IROpcode.STORE,
                result=None,
                operands=[new_value, operand_addr],
                location=expr.location
            )
            self.current_block.add_instruction(store_inst)
            
            # Return value depends on prefix vs postfix
            # Prefix: return new value
            # Postfix: return old value
            if expr.is_prefix:
                return new_value
            else:
                return current_value
        
        # Generate operand
        operand = self._generate_expression(expr.operand)
        
        # Get result type
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        
        # Check if this is a floating-point operation
        from src.semantic.type_utils import is_floating_type
        is_float_op = is_floating_type(expr_type)
        
        # Map operator to opcode
        if expr.operator == '-':
            opcode = IROpcode.FNEG if is_float_op else IROpcode.NEG
        elif expr.operator == '!':
            opcode = IROpcode.NOT
        elif expr.operator == '~':
            opcode = IROpcode.NOT  # Bitwise NOT
        else:
            self.error_reporter.error(
                expr.location,
                f"Unsupported unary operator: {expr.operator}"
            )
            return operand
        
        result_reg = self.current_function.allocate_register(expr_type)
        
        # Generate instruction
        unary_inst = UnaryInstruction(
            opcode=opcode,
            result=result_reg,
            operands=[operand],
            location=expr.location
        )
        self.current_block.add_instruction(unary_inst)
        
        return result_reg
    
    def _generate_call_expr(self, expr: CallExpr) -> IRValue:
        """Generate IR for a function call.
        
        Handles:
        - Direct function calls: func(args)
        - Indirect calls through function pointers: (*fp)(args) or fp(args)
        
        Args:
            expr: Call expression
            
        Returns:
            IR value for the result
        """
        from src.parser.ast_nodes import FunctionType
        from src.semantic.type_utils import is_function_type, is_pointer_type, get_pointer_base_type
        
        # Generate function reference
        if isinstance(expr.function, Identifier):
            # Direct function call by name
            func_name = expr.function.name
            
            # Check if this is a function or function pointer variable
            func_type = getattr(expr.function, 'expr_type', None)
            
            if func_type and is_pointer_type(func_type):
                # This is a function pointer variable - need to load it
                pointee = get_pointer_base_type(func_type)
                if is_function_type(pointee):
                    # Load the function pointer value
                    local_var = self.current_function.get_local_variable(func_name)
                    if local_var is not None:
                        # Load from local variable
                        func_reg = self.current_function.allocate_register(func_type)
                        load_inst = LoadInstruction(
                            opcode=IROpcode.LOAD,
                            result=func_reg,
                            operands=[local_var],
                            location=expr.location
                        )
                        self.current_block.add_instruction(load_inst)
                        func_value = func_reg
                    else:
                        # Global function pointer
                        global_var = self.module.get_global_variable(func_name)
                        if global_var is not None:
                            func_reg = self.current_function.allocate_register(func_type)
                            load_inst = LoadInstruction(
                                opcode=IROpcode.LOAD,
                                result=func_reg,
                                operands=[global_var],
                                location=expr.location
                            )
                            self.current_block.add_instruction(load_inst)
                            func_value = func_reg
                        else:
                            func_value = Constant(value=func_name, value_type=None)
                else:
                    func_value = Constant(value=func_name, value_type=None)
            else:
                # Direct function name
                func_value = Constant(value=func_name, value_type=None)
        else:
            # Complex expression (e.g., (*fp), array[i], etc.)
            func_value = self._generate_expression(expr.function)
        
        # Generate arguments
        args = [self._generate_expression(arg) for arg in expr.arguments]
        
        # Get result type
        expr_type = getattr(expr, 'expr_type', None)
        
        # Allocate result register if function returns a value
        from src.semantic.type_utils import is_void_type
        if expr_type is not None and not is_void_type(expr_type):
            result_reg = self.current_function.allocate_register(expr_type)
        else:
            result_reg = None
        
        # Generate call instruction
        # For indirect calls, the func_value will be a register containing the function pointer
        call_inst = CallInstruction(
            opcode=IROpcode.CALL,
            result=result_reg,
            operands=[func_value] + args,
            location=expr.location
        )
        self.current_block.add_instruction(call_inst)
        
        return result_reg if result_reg is not None else Constant(value=0, value_type=PrimitiveType(name='void', location=expr.location))
    
    def _generate_assignment_expr(self, expr: AssignmentExpr) -> IRValue:
        """Generate IR for an assignment expression.
        
        Args:
            expr: Assignment expression
            
        Returns:
            IR value for the result (the assigned value)
        """
        # Generate RHS
        rhs_value = self._generate_expression(expr.rhs)
        
        # Get LHS address
        if isinstance(expr.lhs, Identifier):
            # Simple variable assignment
            local_var = self.current_function.get_local_variable(expr.lhs.name)
            if local_var is not None:
                lhs_addr = local_var
            else:
                global_var = self.module.get_global_variable(expr.lhs.name)
                if global_var is not None:
                    lhs_addr = global_var
                else:
                    self.error_reporter.error(
                        expr.lhs.location,
                        f"Undefined variable: {expr.lhs.name}"
                    )
                    return rhs_value
        else:
            # Complex lvalue (array subscript, member access, dereference)
            lhs_addr = self._generate_lvalue_address(expr.lhs)
        
        # Handle compound assignment operators
        if expr.operator != '=':
            # Load current value
            expr_type = getattr(expr.lhs, 'expr_type', PrimitiveType(name='int', location=expr.location))
            current_value = self.current_function.allocate_register(expr_type)
            load_inst = LoadInstruction(
                opcode=IROpcode.LOAD,
                result=current_value,
                operands=[lhs_addr],
                location=expr.location
            )
            self.current_block.add_instruction(load_inst)
            
            # Map compound operator to binary operator
            op_map = {
                '+=': '+', '-=': '-', '*=': '*', '/=': '/', '%=': '%',
                '&=': '&', '|=': '|', '^=': '^', '<<=': '<<', '>>=': '>>'
            }
            binary_op = op_map.get(expr.operator)
            if binary_op:
                # Create temporary binary expression
                temp_expr = BinaryExpr(
                    operator=binary_op,
                    left=expr.lhs,
                    right=expr.rhs,
                    location=expr.location
                )
                # Generate binary operation manually
                op_opcode_map = {
                    '+': IROpcode.ADD, '-': IROpcode.SUB, '*': IROpcode.MUL,
                    '/': IROpcode.DIV, '%': IROpcode.MOD, '&': IROpcode.AND,
                    '|': IROpcode.OR, '^': IROpcode.XOR, '<<': IROpcode.SHL, '>>': IROpcode.SHR
                }
                opcode = op_opcode_map[binary_op]
                result_reg = self.current_function.allocate_register(expr_type)
                bin_inst = BinaryInstruction(
                    opcode=opcode,
                    result=result_reg,
                    operands=[current_value, rhs_value],
                    location=expr.location
                )
                self.current_block.add_instruction(bin_inst)
                rhs_value = result_reg
        
        # Store value
        store_inst = StoreInstruction(
            opcode=IROpcode.STORE,
            result=None,
            operands=[rhs_value, lhs_addr],
            location=expr.location
        )
        self.current_block.add_instruction(store_inst)
        
        return rhs_value
    
    def _generate_lvalue_address(self, expr: Expression) -> IRValue:
        """Generate IR to get the address of an lvalue.
        
        Args:
            expr: Lvalue expression
            
        Returns:
            IR value representing the address
        """
        if isinstance(expr, Identifier):
            local_var = self.current_function.get_local_variable(expr.name)
            if local_var is not None:
                return local_var
            
            global_var = self.module.get_global_variable(expr.name)
            if global_var is not None:
                return global_var
        
        elif isinstance(expr, ArraySubscript):
            # For array subscripts, calculate the address without loading
            return self._generate_array_address(expr)
        
        # For other cases, generate the expression
        return self._generate_expression(expr)
    
    def _generate_cast_expr(self, expr: CastExpr) -> IRValue:
        """Generate IR for a cast expression.
        
        Args:
            expr: Cast expression
            
        Returns:
            IR value for the result
        """
        operand = self._generate_expression(expr.operand)
        
        # Determine source and target types
        from src.semantic.type_utils import is_floating_type, is_integer_type
        source_type = getattr(expr.operand, 'expr_type', None)
        target_type = expr.target_type
        
        # Determine the appropriate cast opcode
        opcode = IROpcode.CAST  # Default
        
        if source_type and target_type:
            source_is_float = is_floating_type(source_type)
            target_is_float = is_floating_type(target_type)
            source_is_int = is_integer_type(source_type)
            target_is_int = is_integer_type(target_type)
            
            if source_is_float and target_is_int:
                # Float to integer conversion
                # Check if target is signed or unsigned
                if isinstance(target_type, PrimitiveType) and not target_type.is_signed:
                    opcode = IROpcode.FPTOUI
                else:
                    opcode = IROpcode.FPTOSI
            elif source_is_int and target_is_float:
                # Integer to float conversion
                if isinstance(source_type, PrimitiveType) and not source_type.is_signed:
                    opcode = IROpcode.UITOFP
                else:
                    opcode = IROpcode.SITOFP
            elif source_is_float and target_is_float:
                # Float to float conversion (e.g., double to float or vice versa)
                # Determine if we're truncating or extending
                source_size = self._get_float_type_size(source_type)
                target_size = self._get_float_type_size(target_type)
                if target_size < source_size:
                    opcode = IROpcode.FPTRUNC
                elif target_size > source_size:
                    opcode = IROpcode.FPEXT
                # else: same size, use generic CAST
        
        # Allocate result register
        result_reg = self.current_function.allocate_register(target_type)
        
        # Generate cast instruction
        cast_inst = CastInstruction(
            opcode=opcode,
            result=result_reg,
            operands=[operand],
            target_type=target_type,
            location=expr.location
        )
        self.current_block.add_instruction(cast_inst)
        
        return result_reg
    
    def _get_float_type_size(self, type_obj: Type) -> int:
        """Get the size of a floating-point type.
        
        Args:
            type_obj: Type to get size of
            
        Returns:
            Size in bytes (4 for float, 8 for double, 16 for long double)
        """
        if isinstance(type_obj, PrimitiveType):
            if type_obj.name == 'float':
                return 4
            elif type_obj.name == 'double':
                if type_obj.size_modifier == 'long':
                    return 16  # long double
                return 8
        return 8  # Default to double size
    
    def _generate_conditional_expr(self, expr: ConditionalExpr) -> IRValue:
        """Generate IR for a conditional expression (ternary operator).
        
        Args:
            expr: Conditional expression
            
        Returns:
            IR value for the result
        """
        # Generate condition
        cond_value = self._generate_expression(expr.condition)
        
        # Create labels
        true_label = self._generate_label("cond_true")
        false_label = self._generate_label("cond_false")
        end_label = self._generate_label("cond_end")
        
        # Allocate result register
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        result_reg = self.current_function.allocate_register(expr_type)
        
        # Generate conditional branch
        cond_br = ConditionalBranchInstruction(
            opcode=IROpcode.COND_BR,
            result=None,
            operands=[cond_value, true_label, false_label],
            location=expr.location
        )
        self.current_block.add_instruction(cond_br)
        
        # Generate true block
        true_block = BasicBlock(label=true_label)
        self.current_function.add_basic_block(true_block)
        self.current_function.cfg.add_edge(self.current_block, true_block)
        self.current_block = true_block
        
        true_value = self._generate_expression(expr.true_expr)
        # Store to result (simplified - in full SSA we'd use PHI nodes)
        
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[end_label],
            location=expr.location
        )
        self.current_block.add_instruction(br)
        
        # Generate false block
        false_block = BasicBlock(label=false_label)
        self.current_function.add_basic_block(false_block)
        self.current_function.cfg.add_edge(self.current_block, false_block)
        self.current_block = false_block
        
        false_value = self._generate_expression(expr.false_expr)
        
        br = BranchInstruction(
            opcode=IROpcode.BR,
            result=None,
            operands=[end_label],
            location=expr.location
        )
        self.current_block.add_instruction(br)
        
        # Create end block
        end_block = BasicBlock(label=end_label)
        self.current_function.add_basic_block(end_block)
        self.current_function.cfg.add_edge(true_block, end_block)
        self.current_function.cfg.add_edge(false_block, end_block)
        self.current_block = end_block
        
        # For simplicity, return one of the values
        # In a full implementation, we'd use PHI nodes here
        return result_reg
    
    def _generate_comma_expr(self, expr: CommaExpr) -> IRValue:
        """Generate IR for a comma expression.
        
        The comma operator evaluates all expressions left-to-right
        and returns the value of the rightmost expression.
        
        Args:
            expr: Comma expression
            
        Returns:
            IR value for the result (value of last expression)
        """
        if not expr.expressions:
            # Empty comma expression - shouldn't happen, but handle it
            return Constant(value=0, value_type=PrimitiveType(name='int', location=expr.location))
        
        # Generate IR for all expressions
        result = None
        for sub_expr in expr.expressions:
            result = self._generate_expression(sub_expr)
        
        # Return the value of the last expression
        return result
    
    def _generate_sizeof_expr(self, expr: SizeofExpr) -> IRValue:
        """Generate IR for a sizeof expression.
        
        Sizeof is evaluated at compile time and replaced with a constant.
        
        Args:
            expr: Sizeof expression
            
        Returns:
            IR constant value representing the size
        """
        # Determine the type to get size of
        if expr.is_type:
            # sizeof(type)
            target_type = expr.operand
        else:
            # sizeof expression - get the type of the expression
            target_type = getattr(expr.operand, 'expr_type', None)
            if target_type is None:
                # If type not set, default to int
                target_type = PrimitiveType(name='int', location=expr.location)
        
        # Calculate size at compile time
        size = self._get_type_size(target_type)
        
        # Return as a constant
        # sizeof returns size_t, which we represent as unsigned long
        size_t_type = PrimitiveType(name='long', is_signed=False, location=expr.location)
        return Constant(value=size, value_type=size_t_type)
    
    def _generate_array_address(self, expr: ArraySubscript) -> IRValue:
        """Generate IR to calculate array element address without loading.
        
        This is used for lvalue contexts (e.g., arr[i] = x).
        
        Args:
            expr: Array subscript expression
            
        Returns:
            IR value representing the address of the array element
        """
        # Generate index value
        index_value = self._generate_expression(expr.index)
        
        # Get array base address (without loading)
        if isinstance(expr.array, Identifier):
            # Check if it's a local variable
            local_var = self.current_function.get_local_variable(expr.array.name)
            if local_var is not None:
                array_base = local_var  # Use address directly
            else:
                # Check if it's a global variable
                global_var = self.module.get_global_variable(expr.array.name)
                if global_var is not None:
                    array_base = global_var  # Use address directly
                else:
                    # Fallback: generate expression normally
                    array_base = self._generate_expression(expr.array)
        else:
            # For complex expressions (e.g., pointer dereference), generate normally
            array_base = self._generate_expression(expr.array)
        
        # Get element type and size
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        element_size = self._get_type_size(expr_type)
        
        # Create pointer type for address calculation
        ptr_type = PointerType(
            location=expr.location,
            pointee_type=expr_type,
            qualifiers=()
        )
        
        # Calculate offset = index * element_size
        if element_size > 1:
            # Create constant for element size
            size_const = Constant(
                value=element_size,
                value_type=PrimitiveType(name='int', location=expr.location)
            )
            
            # Multiply: offset = index * size
            offset_reg = self.current_function.allocate_register(
                PrimitiveType(name='int', location=expr.location)
            )
            mul_inst = BinaryInstruction(
                opcode=IROpcode.MUL,
                result=offset_reg,
                operands=[index_value, size_const],
                location=expr.location
            )
            self.current_block.add_instruction(mul_inst)
        else:
            # Element size is 1, no multiplication needed
            offset_reg = index_value
        
        # Calculate address = base + offset
        addr_reg = self.current_function.allocate_register(ptr_type)
        add_inst = BinaryInstruction(
            opcode=IROpcode.ADD,
            result=addr_reg,
            operands=[array_base, offset_reg],
            location=expr.location
        )
        self.current_block.add_instruction(add_inst)
        
        return addr_reg
    
    def _generate_array_subscript(self, expr: ArraySubscript) -> IRValue:
        """Generate IR for array subscript: arr[i].
        
        In C, arr[i] is equivalent to *(arr + i * sizeof(element)).
        This generates:
        1. Get address of array element
        2. Load from that address
        
        Args:
            expr: Array subscript expression
            
        Returns:
            IR value for the result (loaded element value)
        """
        # Get the address of the array element
        addr_reg = self._generate_array_address(expr)
        
        # Load from the address
        expr_type = getattr(expr, 'expr_type', PrimitiveType(name='int', location=expr.location))
        result_reg = self.current_function.allocate_register(expr_type)
        load_inst = LoadInstruction(
            opcode=IROpcode.LOAD,
            result=result_reg,
            operands=[addr_reg],
            location=expr.location
        )
        self.current_block.add_instruction(load_inst)
        
        return result_reg
    
    def _get_type_size(self, type_obj: Type) -> int:
        """Get the size of a type in bytes.
        
        Args:
            type_obj: Type to get size of
            
        Returns:
            Size in bytes
        """
        if isinstance(type_obj, PrimitiveType):
            # Standard sizes (platform-dependent, using common values)
            sizes = {
                'char': 1,
                'short': 2,
                'int': 4,
                'long': 8,
                'float': 4,
                'double': 8,
                'void': 1,  # void* arithmetic uses 1
            }
            return sizes.get(type_obj.name, 4)  # Default to 4
        elif isinstance(type_obj, PointerType):
            return 8  # Pointer size (64-bit)
        elif isinstance(type_obj, ArrayType):
            # Array size = element_size * num_elements
            element_size = self._get_type_size(type_obj.element_type)
            if type_obj.size_value:
                return element_size * type_obj.size_value
            return element_size  # Incomplete array
        else:
            return 4  # Default size
    
    def _generate_member_access(self, expr: MemberAccess) -> IRValue:
        """Generate IR for member access (struct.member or ptr->member).
        
        Generates:
        1. Get base address (object or dereferenced pointer)
        2. Calculate member offset
        3. Add offset to base address
        4. Load value from resulting address
        
        Args:
            expr: Member access expression
            
        Returns:
            IR value for the member address (for lvalue) or loaded value
        """
        from src.parser.ast_nodes import StructType
        from src.semantic.type_utils import is_pointer_type, get_pointer_base_type
        
        # Get the object expression
        obj_value = self._generate_expression(expr.object)
        
        # Determine the struct type
        obj_type = getattr(expr.object, 'expr_type', None)
        if obj_type is None:
            self.error_reporter.error(
                expr.location,
                f"Cannot determine type of object in member access"
            )
            return obj_value
        
        # For arrow operator, dereference the pointer
        if expr.is_arrow:
            if not is_pointer_type(obj_type):
                self.error_reporter.error(
                    expr.location,
                    f"Arrow operator requires pointer type"
                )
                return obj_value
            struct_type = get_pointer_base_type(obj_type)
            # obj_value is already the pointer, no need to dereference for address calculation
        else:
            struct_type = obj_type
            # For dot operator, we need the address of the object
            # If obj_value is not already an address, we need to get it
            # For now, assume obj_value is the address
        
        # Verify it's a struct/union type
        if not isinstance(struct_type, StructType):
            self.error_reporter.error(
                expr.location,
                f"Member access requires struct or union type"
            )
            return obj_value
        
        # If struct type is incomplete, try to get it from the expression's type annotation
        # The semantic analyzer should have already resolved this
        if not struct_type.is_complete and hasattr(expr, 'expr_type'):
            # The expr_type is the member type, but we can try to get the struct from the object
            # Actually, the semantic analyzer should have already ensured the struct is complete
            # If we're here with an incomplete struct, it's a bug in semantic analysis
            pass
        
        # Get member offset
        member_offset = struct_type.get_member_offset(expr.member)
        if member_offset is None:
            self.error_reporter.error(
                expr.location,
                f"Struct/union has no member '{expr.member}' or layout not computed"
            )
            return obj_value
        
        # Calculate member address: base + offset
        if member_offset == 0:
            # Member is at offset 0, use base address directly
            member_addr = obj_value
        else:
            # Create offset constant
            offset_const = Constant(value=member_offset, type=PrimitiveType(name='int', location=expr.location))
            
            # Add offset to base address
            ptr_type = PointerType(pointee_type=PrimitiveType(name='char', location=expr.location), location=expr.location)
            member_addr = self.current_function.allocate_register(ptr_type)
            
            add_inst = BinaryInstruction(
                opcode=IROpcode.ADD,
                result=member_addr,
                operands=[obj_value, offset_const],
                location=expr.location
            )
            self.current_block.add_instruction(add_inst)
        
        # Return the member address (for lvalue contexts like assignment)
        # The caller will load from this address if needed
        return member_addr

    def _generate_struct_initialization(self, struct_addr: IRValue, struct_type: 'StructType', 
                                       initializer: 'InitializerList') -> None:
        """Generate IR for struct initialization with initializer list.
        
        Generates stores to each member at the appropriate offset.
        
        Args:
            struct_addr: Address of the struct being initialized
            struct_type: Type of the struct
            initializer: Initializer list expression
        """
        from src.parser.ast_nodes import StructType, InitializerList
        
        if not struct_type.is_complete or struct_type.members is None:
            return
        
        # Initialize each member
        for i, init_expr in enumerate(initializer.initializers):
            if i >= len(struct_type.members):
                break
            
            member = struct_type.members[i]
            member_offset = struct_type.get_member_offset(member.name)
            
            if member_offset is None:
                continue
            
            # Calculate member address
            if member_offset == 0:
                member_addr = struct_addr
            else:
                offset_const = Constant(value=member_offset, 
                                       type=PrimitiveType(name='int', location=init_expr.location))
                ptr_type = PointerType(pointee_type=PrimitiveType(name='char', location=init_expr.location),
                                      location=init_expr.location)
                member_addr = self.current_function.allocate_register(ptr_type)
                
                add_inst = BinaryInstruction(
                    opcode=IROpcode.ADD,
                    result=member_addr,
                    operands=[struct_addr, offset_const],
                    location=init_expr.location
                )
                self.current_block.add_instruction(add_inst)
            
            # Handle nested struct initialization
            if isinstance(member.var_type, StructType) and isinstance(init_expr, InitializerList):
                self._generate_struct_initialization(member_addr, member.var_type, init_expr)
            else:
                # Generate initializer value and store it
                init_value = self._generate_expression(init_expr)
                store_inst = StoreInstruction(
                    opcode=IROpcode.STORE,
                    result=None,
                    operands=[init_value, member_addr],
                    location=init_expr.location
                )
                self.current_block.add_instruction(store_inst)

    def _generate_string_array_initialization(self, array_addr: IRValue, array_type: ArrayType, 
                                             string_literal: Literal) -> None:
        """Generate IR for array initialization with string literal.
        
        Handles: char s[] = "hello" or char s[10] = "hello"
        
        This generates a loop or series of stores to copy the string literal
        into the array.
        
        Args:
            array_addr: Address of the array being initialized
            array_type: Type of the array
            string_literal: String literal expression
        """
        # Add string to data section
        is_wide = isinstance(string_literal.value, str) and len(string_literal.value) > 0 and string_literal.value[0] == 'L'
        str_lit = self.module.add_string_literal(string_literal.value, is_wide)
        
        # For simplicity, we'll generate a memcpy-like operation
        # In a real implementation, we might call memcpy or generate a loop
        
        # Get string length (including null terminator)
        str_len = len(string_literal.value) + 1
        
        # Generate stores for each character
        for i in range(min(str_len, array_type.size_value if array_type.size_value else str_len)):
            # Calculate element address: array_addr + i
            if i == 0:
                elem_addr = array_addr
            else:
                offset_const = Constant(value=i, value_type=PrimitiveType(name='int', location=string_literal.location))
                ptr_type = PointerType(pointee_type=PrimitiveType(name='char', location=string_literal.location),
                                      qualifiers=(), location=string_literal.location)
                elem_addr = self.current_function.allocate_register(ptr_type)
                
                add_inst = BinaryInstruction(
                    opcode=IROpcode.ADD,
                    result=elem_addr,
                    operands=[array_addr, offset_const],
                    location=string_literal.location
                )
                self.current_block.add_instruction(add_inst)
            
            # Get character value
            if i < len(string_literal.value):
                char_value = ord(string_literal.value[i])
            else:
                char_value = 0  # Null terminator
            
            char_const = Constant(value=char_value, value_type=PrimitiveType(name='char', location=string_literal.location))
            
            # Store character
            store_inst = StoreInstruction(
                opcode=IROpcode.STORE,
                result=None,
                operands=[char_const, elem_addr],
                location=string_literal.location
            )
            self.current_block.add_instruction(store_inst)
