"""Basic block and control flow graph definitions."""

from dataclasses import dataclass, field
from typing import List, Set, Optional

from src.ir.ir_nodes import IRInstruction, Label


@dataclass
class BasicBlock:
    """Represents a basic block in the control flow graph.
    
    A basic block is a sequence of instructions with:
    - Single entry point (first instruction)
    - Single exit point (last instruction, usually a branch or return)
    - No branches except at the end
    
    Attributes:
        label: Label identifying this basic block
        instructions: List of instructions in this block
        predecessors: Set of basic blocks that can jump to this block
        successors: Set of basic blocks this block can jump to
    """
    label: Label
    instructions: List[IRInstruction] = field(default_factory=list)
    predecessors: Set['BasicBlock'] = field(default_factory=set)
    successors: Set['BasicBlock'] = field(default_factory=set)
    
    def add_instruction(self, instruction: IRInstruction) -> None:
        """Add an instruction to this basic block.
        
        Args:
            instruction: Instruction to add
        """
        self.instructions.append(instruction)
    
    def add_predecessor(self, block: 'BasicBlock') -> None:
        """Add a predecessor block.
        
        Args:
            block: Predecessor block
        """
        self.predecessors.add(block)
    
    def add_successor(self, block: 'BasicBlock') -> None:
        """Add a successor block.
        
        Args:
            block: Successor block
        """
        self.successors.add(block)
    
    def is_empty(self) -> bool:
        """Check if this block has no instructions.
        
        Returns:
            True if block is empty
        """
        return len(self.instructions) == 0
    
    def get_terminator(self) -> Optional[IRInstruction]:
        """Get the terminator instruction (last instruction).
        
        Returns:
            Last instruction or None if block is empty
        """
        return self.instructions[-1] if self.instructions else None
    
    def __repr__(self) -> str:
        return f"BasicBlock({self.label.name})"
    
    def __hash__(self) -> int:
        return hash(self.label.name)
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, BasicBlock):
            return False
        return self.label.name == other.label.name


@dataclass
class ControlFlowGraph:
    """Control flow graph for a function.
    
    Attributes:
        entry_block: Entry basic block
        exit_block: Exit basic block (may be None)
        blocks: List of all basic blocks in the CFG
    """
    entry_block: BasicBlock
    exit_block: Optional[BasicBlock] = None
    blocks: List[BasicBlock] = field(default_factory=list)
    
    def add_block(self, block: BasicBlock) -> None:
        """Add a basic block to the CFG.
        
        Args:
            block: Block to add
        """
        if block not in self.blocks:
            self.blocks.append(block)
    
    def add_edge(self, from_block: BasicBlock, to_block: BasicBlock) -> None:
        """Add a control flow edge between two blocks.
        
        Args:
            from_block: Source block
            to_block: Destination block
        """
        from_block.add_successor(to_block)
        to_block.add_predecessor(from_block)
    
    def get_block_by_label(self, label: Label) -> Optional[BasicBlock]:
        """Find a basic block by its label.
        
        Args:
            label: Label to search for
            
        Returns:
            Basic block with the given label, or None if not found
        """
        for block in self.blocks:
            if block.label.name == label.name:
                return block
        return None
    
    def remove_unreachable_blocks(self) -> None:
        """Remove basic blocks that are unreachable from entry.
        
        This is useful for dead code elimination.
        """
        # Find reachable blocks using DFS
        reachable = set()
        stack = [self.entry_block]
        
        while stack:
            block = stack.pop()
            if block in reachable:
                continue
            
            reachable.add(block)
            for successor in block.successors:
                if successor not in reachable:
                    stack.append(successor)
        
        # Remove unreachable blocks
        self.blocks = [block for block in self.blocks if block in reachable]
    
    def __repr__(self) -> str:
        return f"CFG(entry={self.entry_block.label.name}, blocks={len(self.blocks)})"
