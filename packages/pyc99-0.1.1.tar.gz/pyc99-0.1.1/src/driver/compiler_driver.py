"""Compiler driver that orchestrates all compilation phases."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
from pathlib import Path

from src.lexer.tokenizer import Tokenizer
from src.parser.parser import Parser
from src.semantic.analyzer import SemanticAnalyzer
from src.ir.ir_generator import IRGenerator
from src.optimizer.optimizer import Optimizer
from src.codegen.x86.x86_codegen import X86CodeGenerator
from src.codegen.arm.arm_codegen import ARMCodeGenerator
from src.utils.error_reporter import ErrorReporter
from src.preprocessor.preprocessor import Preprocessor


class CompilationPhase(Enum):
    """Compilation phases."""
    PREPROCESSING = "preprocessing"
    LEXING = "lexing"
    PARSING = "parsing"
    SEMANTIC_ANALYSIS = "semantic_analysis"
    IR_GENERATION = "ir_generation"
    OPTIMIZATION = "optimization"
    CODE_GENERATION = "code_generation"


@dataclass
class CompilerOptions:
    """Compiler configuration options.
    
    Attributes:
        target: Target architecture ('x86' or 'arm')
        optimization_level: Optimization level (0-3)
        output_file: Output file path
        stop_after: Stop compilation after this phase
        include_paths: Additional include search paths
        verbose: Enable verbose output
        debug: Enable debug output
    """
    target: str = "x86"
    optimization_level: int = 0
    output_file: Optional[str] = None
    stop_after: Optional[CompilationPhase] = None
    include_paths: list = None
    verbose: bool = False
    debug: bool = False
    
    def __post_init__(self):
        """Initialize mutable default values."""
        if self.include_paths is None:
            self.include_paths = []


@dataclass
class CompilationResult:
    """Result of compilation.
    
    Attributes:
        success: Whether compilation succeeded
        output: Generated output (assembly code, IR, etc.)
        error_reporter: Error reporter with diagnostics
        stopped_at: Phase where compilation stopped
    """
    success: bool
    output: Optional[str] = None
    error_reporter: Optional[ErrorReporter] = None
    stopped_at: Optional[CompilationPhase] = None


class CompilerDriver:
    """Orchestrates all compilation phases.
    
    The compiler driver coordinates the execution of all compilation phases
    from lexing through code generation, with error handling between phases.
    
    Attributes:
        options: Compiler configuration options
        error_reporter: Error reporter for diagnostics
    """
    
    def __init__(self, options: CompilerOptions):
        """Initialize compiler driver.
        
        Args:
            options: Compiler configuration options
        """
        self.options = options
        self.error_reporter = ErrorReporter()
    
    def compile(self, source_file: str) -> CompilationResult:
        """Compile a source file through all phases.
        
        Args:
            source_file: Path to source file to compile
            
        Returns:
            CompilationResult with success status and output
        """
        return self._compile_single_file(source_file)
    
    def compile_multiple(self, source_files: list) -> list:
        """Compile multiple source files independently.
        
        Each file is compiled to an object file separately, allowing
        for separate compilation and later linking.
        
        Args:
            source_files: List of source file paths to compile
            
        Returns:
            List of CompilationResult objects, one per source file
        """
        results = []
        for source_file in source_files:
            result = self._compile_single_file(source_file)
            results.append(result)
            
            # Stop on first error if not continuing
            if not result.success:
                break
        
        return results
    
    def _compile_single_file(self, source_file: str) -> CompilationResult:
        """Compile a single source file through all phases.
        
        Args:
            source_file: Path to source file to compile
            
        Returns:
            CompilationResult with success status and output
        """
        try:
            # Read source file
            source_path = Path(source_file)
            if not source_path.exists():
                self.error_reporter.error(
                    None,
                    f"Source file not found: {source_file}"
                )
                return CompilationResult(
                    success=False,
                    error_reporter=self.error_reporter
                )
            
            source_code = source_path.read_text()
            
            # Phase 0: Preprocessing
            if self.options.verbose:
                print(f"Phase 0: Preprocessing...")
            
            preprocessed_code = self._run_preprocessor(source_code, str(source_path))
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.PREPROCESSING)
            
            if self.options.stop_after == CompilationPhase.PREPROCESSING:
                return self._create_success_result(
                    preprocessed_code,
                    CompilationPhase.PREPROCESSING
                )
            
            # Phase 1: Lexical Analysis
            if self.options.verbose:
                print(f"Phase 1: Lexical analysis...")
            
            tokens = self._run_lexer(preprocessed_code, str(source_path))
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.LEXING)
            
            if self.options.stop_after == CompilationPhase.LEXING:
                return self._create_success_result(
                    self._format_tokens(tokens),
                    CompilationPhase.LEXING
                )
            
            # Phase 2: Parsing
            if self.options.verbose:
                print(f"Phase 2: Parsing...")
            
            ast = self._run_parser(preprocessed_code, str(source_path))
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.PARSING)
            
            if self.options.stop_after == CompilationPhase.PARSING:
                return self._create_success_result(
                    self._format_ast(ast),
                    CompilationPhase.PARSING
                )
            
            # Phase 3: Semantic Analysis
            if self.options.verbose:
                print(f"Phase 3: Semantic analysis...")
            
            annotated_ast = self._run_semantic_analysis(ast)
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.SEMANTIC_ANALYSIS)
            
            if self.options.stop_after == CompilationPhase.SEMANTIC_ANALYSIS:
                return self._create_success_result(
                    self._format_ast(annotated_ast),
                    CompilationPhase.SEMANTIC_ANALYSIS
                )
            
            # Phase 4: IR Generation
            if self.options.verbose:
                print(f"Phase 4: IR generation...")
            
            ir_module = self._run_ir_generation(annotated_ast)
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.IR_GENERATION)
            
            if self.options.stop_after == CompilationPhase.IR_GENERATION:
                return self._create_success_result(
                    self._format_ir(ir_module),
                    CompilationPhase.IR_GENERATION
                )
            
            # Phase 5: Optimization
            if self.options.verbose:
                print(f"Phase 5: Optimization (level {self.options.optimization_level})...")
            
            optimized_ir = self._run_optimization(ir_module)
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.OPTIMIZATION)
            
            if self.options.stop_after == CompilationPhase.OPTIMIZATION:
                return self._create_success_result(
                    self._format_ir(optimized_ir),
                    CompilationPhase.OPTIMIZATION
                )
            
            # Phase 6: Code Generation
            if self.options.verbose:
                print(f"Phase 6: Code generation for {self.options.target}...")
            
            assembly_code = self._run_code_generation(optimized_ir)
            if self.error_reporter.has_errors():
                return self._create_error_result(CompilationPhase.CODE_GENERATION)
            
            if self.options.verbose:
                print(f"Compilation successful!")
            
            return self._create_success_result(
                assembly_code,
                CompilationPhase.CODE_GENERATION
            )
            
        except Exception as e:
            self.error_reporter.error(None, f"Internal compiler error: {str(e)}")
            if self.options.debug:
                import traceback
                traceback.print_exc()
            return CompilationResult(
                success=False,
                error_reporter=self.error_reporter
            )
    
    def _run_preprocessor(self, source_code: str, filename: str) -> str:
        """Run preprocessing phase.
        
        Args:
            source_code: Source code to preprocess
            filename: Source filename for error reporting
            
        Returns:
            Preprocessed source code
        """
        preprocessor = Preprocessor(self.error_reporter)
        
        # Add user-specified include paths
        for include_path in self.options.include_paths:
            preprocessor.add_include_path(include_path)
        
        preprocessed_code = preprocessor.preprocess(source_code, filename)
        return preprocessed_code
    
    def _run_lexer(self, source_code: str, filename: str):
        """Run lexical analysis phase.
        
        Args:
            source_code: Source code to tokenize
            filename: Source filename for error reporting
            
        Returns:
            List of tokens
        """
        tokenizer = Tokenizer(source_code, filename)
        # Share error reporter
        tokenizer.error_reporter = self.error_reporter
        tokens = tokenizer.tokenize_all()
        return tokens
    
    def _run_parser(self, source_code: str, filename: str):
        """Run parsing phase.
        
        Args:
            source_code: Source code to parse
            filename: Source filename for error reporting
            
        Returns:
            AST (TranslationUnit)
        """
        tokenizer = Tokenizer(source_code, filename)
        tokenizer.error_reporter = self.error_reporter
        
        parser = Parser(tokenizer)
        parser.error_reporter = self.error_reporter
        
        ast = parser.parse_translation_unit()
        return ast
    
    def _run_semantic_analysis(self, ast):
        """Run semantic analysis phase.
        
        Args:
            ast: AST to analyze
            
        Returns:
            Annotated AST
        """
        analyzer = SemanticAnalyzer(ast, self.error_reporter)
        annotated_ast = analyzer.analyze()
        return annotated_ast
    
    def _run_ir_generation(self, ast):
        """Run IR generation phase.
        
        Args:
            ast: Annotated AST
            
        Returns:
            IR module
        """
        generator = IRGenerator(ast, self.error_reporter)
        ir_module = generator.generate()
        return ir_module
    
    def _run_optimization(self, ir_module):
        """Run optimization phase.
        
        Args:
            ir_module: IR module to optimize
            
        Returns:
            Optimized IR module
        """
        optimizer = Optimizer(
            optimization_level=self.options.optimization_level,
            verbose=self.options.verbose
        )
        optimizer.configure_for_level(self.options.optimization_level)
        optimized_ir = optimizer.optimize(ir_module)
        return optimized_ir
    
    def _run_code_generation(self, ir_module):
        """Run code generation phase.
        
        Args:
            ir_module: IR module to generate code from
            
        Returns:
            Assembly code as string
        """
        if self.options.target == "x86":
            # Detect platform and use appropriate syntax
            import platform
            syntax = 'intel' if platform.system() == 'Darwin' else 'att'
            codegen = X86CodeGenerator(ir_module, syntax=syntax)
        elif self.options.target == "arm":
            codegen = ARMCodeGenerator(ir_module)
        else:
            self.error_reporter.error(
                None,
                f"Unknown target architecture: {self.options.target}"
            )
            return None
        
        assembly_code = codegen.generate()
        return assembly_code
    
    def _create_success_result(self, output: str, stopped_at: CompilationPhase) -> CompilationResult:
        """Create a successful compilation result.
        
        Args:
            output: Generated output
            stopped_at: Phase where compilation stopped
            
        Returns:
            CompilationResult
        """
        return CompilationResult(
            success=True,
            output=output,
            error_reporter=self.error_reporter,
            stopped_at=stopped_at
        )
    
    def _create_error_result(self, stopped_at: CompilationPhase) -> CompilationResult:
        """Create an error compilation result.
        
        Args:
            stopped_at: Phase where compilation failed
            
        Returns:
            CompilationResult
        """
        if self.options.verbose:
            print(f"Compilation failed at phase: {stopped_at.value}")
        
        return CompilationResult(
            success=False,
            error_reporter=self.error_reporter,
            stopped_at=stopped_at
        )
    
    def _format_tokens(self, tokens) -> str:
        """Format tokens for output.
        
        Args:
            tokens: List of tokens
            
        Returns:
            Formatted string representation
        """
        lines = []
        for token in tokens:
            lines.append(str(token))
        return '\n'.join(lines)
    
    def _format_ast(self, ast) -> str:
        """Format AST for output.
        
        Args:
            ast: AST node
            
        Returns:
            Formatted string representation
        """
        # Simple string representation
        return str(ast)
    
    def _format_ir(self, ir_module) -> str:
        """Format IR module for output.
        
        Args:
            ir_module: IR module
            
        Returns:
            Formatted string representation
        """
        lines = []
        lines.append(f"Module: {ir_module.name}")
        lines.append("")
        
        # Global variables
        if ir_module.global_variables:
            lines.append("Global Variables:")
            for gvar in ir_module.global_variables.values():
                lines.append(f"  {gvar.name}: {gvar.value_type}")
            lines.append("")
        
        # Functions
        for function in ir_module.get_functions():
            lines.append(f"Function: {function.name}")
            lines.append(f"  Return type: {function.return_type}")
            lines.append(f"  Parameters: {[str(p) for p in function.parameters]}")
            lines.append("")
            
            # Basic blocks
            for block in function.get_cfg().blocks:
                lines.append(f"  {block.label.name}:")
                for instr in block.instructions:
                    lines.append(f"    {instr}")
                lines.append("")
        
        return '\n'.join(lines)
