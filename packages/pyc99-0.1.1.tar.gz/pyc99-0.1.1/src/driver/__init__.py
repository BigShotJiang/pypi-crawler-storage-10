"""Compiler driver module for orchestrating compilation phases."""
