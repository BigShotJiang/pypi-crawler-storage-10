"""Toolchain integration for invoking external assemblers and linkers."""

import subprocess
import tempfile
import os
from pathlib import Path
from typing import Optional, List
from dataclasses import dataclass

from src.utils.error_reporter import ErrorReporter


@dataclass
class ToolchainResult:
    """Result of toolchain invocation.
    
    Attributes:
        success: Whether the tool invocation succeeded
        output_file: Path to output file if successful
        stdout: Standard output from the tool
        stderr: Standard error from the tool
        return_code: Tool return code
    """
    success: bool
    output_file: Optional[str] = None
    stdout: str = ""
    stderr: str = ""
    return_code: int = 0


class Toolchain:
    """Manages invocation of external assemblers and linkers.
    
    This class handles invoking system tools like as, gas, ld, and gcc
    to assemble and link generated assembly code.
    
    Attributes:
        target: Target architecture ('x86' or 'arm')
        verbose: Enable verbose output
        error_reporter: Error reporter for diagnostics
        temp_files: List of temporary files to clean up
    """
    
    def __init__(self, target: str, verbose: bool = False, 
                 error_reporter: Optional[ErrorReporter] = None):
        """Initialize toolchain.
        
        Args:
            target: Target architecture ('x86' or 'arm')
            verbose: Enable verbose output
            error_reporter: Error reporter for diagnostics
        """
        self.target = target
        self.verbose = verbose
        self.error_reporter = error_reporter or ErrorReporter()
        self.temp_files: List[str] = []
    
    def assemble(self, assembly_file: str, output_file: Optional[str] = None) -> ToolchainResult:
        """Assemble an assembly file to object code.
        
        Args:
            assembly_file: Path to assembly source file
            output_file: Path to output object file (optional)
            
        Returns:
            ToolchainResult with success status and output file
        """
        # Determine output file
        if output_file is None:
            # Create temporary object file
            fd, output_file = tempfile.mkstemp(suffix='.o', prefix='c99_')
            os.close(fd)
            self.temp_files.append(output_file)
        
        # Select assembler based on target
        if self.target == "x86":
            assembler = self._find_x86_assembler()
            args = self._get_x86_assembler_args(assembly_file, output_file)
        elif self.target == "arm":
            assembler = self._find_arm_assembler()
            args = self._get_arm_assembler_args(assembly_file, output_file)
        else:
            self.error_reporter.error(None, f"Unknown target: {self.target}")
            return ToolchainResult(success=False)
        
        if assembler is None:
            self.error_reporter.error(
                None,
                f"Assembler not found for target {self.target}"
            )
            return ToolchainResult(success=False)
        
        # Build command
        command = [assembler] + args
        
        if self.verbose:
            print(f"Assembling: {' '.join(command)}")
        
        # Run assembler
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False
            )
            
            if self.verbose and result.stdout:
                print(result.stdout)
            
            if result.returncode != 0:
                self.error_reporter.error(
                    None,
                    f"Assembly failed with return code {result.returncode}"
                )
                if result.stderr:
                    self.error_reporter.error(None, result.stderr)
                
                return ToolchainResult(
                    success=False,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    return_code=result.returncode
                )
            
            return ToolchainResult(
                success=True,
                output_file=output_file,
                stdout=result.stdout,
                stderr=result.stderr,
                return_code=result.returncode
            )
            
        except FileNotFoundError:
            self.error_reporter.error(
                None,
                f"Assembler not found: {assembler}"
            )
            return ToolchainResult(success=False)
        except Exception as e:
            self.error_reporter.error(
                None,
                f"Error running assembler: {str(e)}"
            )
            return ToolchainResult(success=False)
    
    def link(self, object_files: List[str], output_file: str, 
             link_libc: bool = True) -> ToolchainResult:
        """Link object files to create an executable.
        
        Args:
            object_files: List of object file paths
            output_file: Path to output executable
            link_libc: Whether to link against libc
            
        Returns:
            ToolchainResult with success status
        """
        # Select linker based on target
        if self.target == "x86":
            linker = self._find_x86_linker()
            args = self._get_x86_linker_args(object_files, output_file, link_libc)
        elif self.target == "arm":
            linker = self._find_arm_linker()
            args = self._get_arm_linker_args(object_files, output_file, link_libc)
        else:
            self.error_reporter.error(None, f"Unknown target: {self.target}")
            return ToolchainResult(success=False)
        
        if linker is None:
            self.error_reporter.error(
                None,
                f"Linker not found for target {self.target}"
            )
            return ToolchainResult(success=False)
        
        # Build command
        command = [linker] + args
        
        if self.verbose:
            print(f"Linking: {' '.join(command)}")
        
        # Run linker
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False
            )
            
            if self.verbose and result.stdout:
                print(result.stdout)
            
            if result.returncode != 0:
                self.error_reporter.error(
                    None,
                    f"Linking failed with return code {result.returncode}"
                )
                if result.stderr:
                    self.error_reporter.error(None, result.stderr)
                
                return ToolchainResult(
                    success=False,
                    output_file=output_file,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    return_code=result.returncode
                )
            
            return ToolchainResult(
                success=True,
                output_file=output_file,
                stdout=result.stdout,
                stderr=result.stderr,
                return_code=result.returncode
            )
            
        except FileNotFoundError:
            self.error_reporter.error(
                None,
                f"Linker not found: {linker}"
            )
            return ToolchainResult(success=False)
        except Exception as e:
            self.error_reporter.error(
                None,
                f"Error running linker: {str(e)}"
            )
            return ToolchainResult(success=False)
    
    def cleanup(self):
        """Clean up temporary files."""
        for temp_file in self.temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    if self.verbose:
                        print(f"Removed temporary file: {temp_file}")
            except Exception as e:
                if self.verbose:
                    print(f"Warning: Could not remove {temp_file}: {e}")
        
        self.temp_files.clear()
    
    # X86 toolchain methods
    
    def _find_x86_assembler(self) -> Optional[str]:
        """Find x86 assembler (as or gas).
        
        Returns:
            Path to assembler or None if not found
        """
        # Try to find GNU assembler
        for assembler in ['as', 'gas', 'x86_64-linux-gnu-as']:
            if self._command_exists(assembler):
                return assembler
        return None
    
    def _get_x86_assembler_args(self, input_file: str, output_file: str) -> List[str]:
        """Get arguments for x86 assembler.
        
        Args:
            input_file: Input assembly file
            output_file: Output object file
            
        Returns:
            List of command-line arguments
        """
        return [
            '-o', output_file,
            input_file
        ]
    
    def _find_x86_linker(self) -> Optional[str]:
        """Find x86 linker (gcc or ld).
        
        Returns:
            Path to linker or None if not found
        """
        # Prefer gcc for linking as it handles libc automatically
        for linker in ['gcc', 'x86_64-linux-gnu-gcc', 'ld']:
            if self._command_exists(linker):
                return linker
        return None
    
    def _get_x86_linker_args(self, object_files: List[str], output_file: str,
                            link_libc: bool) -> List[str]:
        """Get arguments for x86 linker.
        
        Args:
            object_files: List of object files
            output_file: Output executable
            link_libc: Whether to link against libc
            
        Returns:
            List of command-line arguments
        """
        args = ['-o', output_file]
        args.extend(object_files)
        
        # If using ld directly, need to specify libc
        # If using gcc, it handles libc automatically
        if not link_libc:
            args.append('-nostdlib')
        
        return args
    
    # ARM toolchain methods
    
    def _find_arm_assembler(self) -> Optional[str]:
        """Find ARM assembler.
        
        Returns:
            Path to assembler or None if not found
        """
        # Try to find ARM cross-compiler assembler
        for assembler in ['arm-linux-gnueabi-as', 'arm-linux-gnueabihf-as', 
                         'arm-none-eabi-as', 'as']:
            if self._command_exists(assembler):
                return assembler
        return None
    
    def _get_arm_assembler_args(self, input_file: str, output_file: str) -> List[str]:
        """Get arguments for ARM assembler.
        
        Args:
            input_file: Input assembly file
            output_file: Output object file
            
        Returns:
            List of command-line arguments
        """
        return [
            '-march=armv7-a',
            '-o', output_file,
            input_file
        ]
    
    def _find_arm_linker(self) -> Optional[str]:
        """Find ARM linker.
        
        Returns:
            Path to linker or None if not found
        """
        # Try to find ARM cross-compiler linker
        for linker in ['arm-linux-gnueabi-gcc', 'arm-linux-gnueabihf-gcc',
                      'arm-none-eabi-gcc', 'gcc']:
            if self._command_exists(linker):
                return linker
        return None
    
    def _get_arm_linker_args(self, object_files: List[str], output_file: str,
                            link_libc: bool) -> List[str]:
        """Get arguments for ARM linker.
        
        Args:
            object_files: List of object files
            output_file: Output executable
            link_libc: Whether to link against libc
            
        Returns:
            List of command-line arguments
        """
        args = ['-o', output_file]
        args.extend(object_files)
        
        if not link_libc:
            args.append('-nostdlib')
        
        return args
    
    # Utility methods
    
    def _command_exists(self, command: str) -> bool:
        """Check if a command exists in PATH.
        
        Args:
            command: Command name to check
            
        Returns:
            True if command exists, False otherwise
        """
        try:
            result = subprocess.run(
                ['which', command],
                capture_output=True,
                check=False
            )
            return result.returncode == 0
        except Exception:
            return False
