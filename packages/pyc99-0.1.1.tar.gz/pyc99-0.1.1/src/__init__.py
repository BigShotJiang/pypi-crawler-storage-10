"""C99 Compiler - An educational C compiler written in Python."""

__version__ = "0.1.0"
