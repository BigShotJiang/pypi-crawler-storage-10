"""Recursive descent parser for C99."""

from typing import Optional, List, Union
from src.lexer.tokenizer import Token, Tokenizer
from src.lexer.token_types import TokenType
from src.parser.ast_nodes import *
from src.utils.error_reporter import ErrorReporter
from src.utils.source_location import SourceLocation
from src.utils.error_suggestions import ErrorSuggestions


class Parser:
    """Recursive descent parser for C99.
    
    This parser implements a subset of the C99 grammar using recursive descent
    with operator precedence parsing for expressions.
    """
    
    def __init__(self, tokenizer: Tokenizer):
        """Initialize the parser.
        
        Args:
            tokenizer: The tokenizer to get tokens from
        """
        self.tokenizer = tokenizer
        self.current_token = self.tokenizer.next_token()
        self.error_reporter = ErrorReporter()
        # Track typedef names for disambiguation
        self.typedef_names = set()
        # Temporary storage for function parameters parsed by declarator
        self._last_function_parameters = None
        
    def peek(self) -> Token:
        """Peek at the current token without consuming it."""
        return self.current_token
    
    def advance(self) -> Token:
        """Consume and return the current token."""
        token = self.current_token
        if token.type != TokenType.EOF:
            self.current_token = self.tokenizer.next_token()
        return token
    
    def expect(self, token_type: TokenType) -> Token:
        """Consume a token of the expected type or report an error.
        
        Args:
            token_type: The expected token type
            
        Returns:
            The consumed token
        """
        if self.peek().type == token_type:
            return self.advance()
        else:
            # Generate helpful suggestion based on expected token
            suggestion = None
            if token_type == TokenType.SEMICOLON:
                suggestion = ErrorSuggestions.suggest_for_missing_semicolon()
            elif token_type == TokenType.RBRACE:
                suggestion = ErrorSuggestions.suggest_for_missing_brace('closing')
            elif token_type == TokenType.LBRACE:
                suggestion = ErrorSuggestions.suggest_for_missing_brace('opening')
            elif token_type in (TokenType.RPAREN, TokenType.LPAREN):
                suggestion = ErrorSuggestions.suggest_for_missing_parenthesis()
            
            self.error_reporter.error(
                self.peek().location,
                f"Expected {token_type.name}, got {self.peek().type.name}",
                suggestion=suggestion
            )
            # Return a dummy token to continue parsing
            return Token(token_type, "", self.peek().location)
    
    def match(self, *token_types: TokenType) -> bool:
        """Check if current token matches any of the given types."""
        return self.peek().type in token_types
    
    def synchronize(self):
        """Synchronize parser state after an error.
        
        Skip tokens until we reach a statement boundary (semicolon or brace).
        """
        self.advance()
        
        while not self.match(TokenType.EOF):
            if self.peek().type == TokenType.SEMICOLON:
                self.advance()
                return
            
            if self.peek().type in (TokenType.LBRACE, TokenType.RBRACE):
                return
            
            # Also stop at keywords that start statements/declarations
            if self.peek().type in (
                TokenType.IF, TokenType.WHILE, TokenType.FOR, TokenType.RETURN,
                TokenType.INT, TokenType.CHAR, TokenType.FLOAT, TokenType.DOUBLE,
                TokenType.VOID, TokenType.STRUCT, TokenType.UNION, TokenType.ENUM
            ):
                return
            
            self.advance()
    
    # ========================================================================
    # Top-level parsing
    # ========================================================================
    
    def parse_translation_unit(self) -> TranslationUnit:
        """Parse a translation unit (complete source file).
        
        Returns:
            TranslationUnit AST node
        """
        location = self.peek().location
        declarations = []
        
        while not self.match(TokenType.EOF):
            try:
                decl = self.parse_declaration()
                if decl:
                    declarations.append(decl)
            except Exception as e:
                # Error recovery
                self.synchronize()
        
        return TranslationUnit(location, declarations)
    
    # ========================================================================
    # Declaration parsing
    # ========================================================================
    
    def parse_declaration(self) -> Optional[Declaration]:
        """Parse a declaration (variable, function, struct, etc.).
        
        Returns:
            Declaration AST node or None
        """
        location = self.peek().location
        
        # Parse declaration specifiers (storage class, type qualifiers, type specifiers, inline)
        storage_class, qualifiers, base_type, is_inline = self.parse_declaration_specifiers()
        
        if not base_type:
            self.error_reporter.error(location, "Expected type specifier")
            self.synchronize()
            return None
        
        # Struct/union/enum declaration without declarator
        if isinstance(base_type, (StructType, EnumType)) and self.match(TokenType.SEMICOLON):
            self.advance()
            if isinstance(base_type, StructType):
                return StructDecl(location, base_type.name, base_type.is_union, 
                                list(base_type.members) if base_type.members else None)
            else:
                return EnumDecl(location, base_type.name, base_type.enumerators)
        
        # Parse declarator (name and type modifiers)
        name, full_type = self.parse_declarator(base_type)
        
        if not name:
            self.error_reporter.error(location, "Expected identifier in declaration")
            self.synchronize()
            return None
        
        # Apply qualifiers to the base type
        full_type = self._apply_qualifiers_to_type(full_type, qualifiers)
        
        # Check if this is a typedef
        if storage_class == StorageClass.TYPEDEF:
            self.expect(TokenType.SEMICOLON)
            # Add typedef name to the set for future parsing
            self.typedef_names.add(name)
            return TypedefDecl(location, name, full_type)
        
        # Check if this is a function declaration/definition
        # The declarator may have already parsed the function signature
        if isinstance(full_type, FunctionType):
            # The declarator already parsed the function type
            # Now check for function body or semicolon
            body = None
            if self.match(TokenType.LBRACE):
                body = self.parse_compound_statement()
            else:
                self.expect(TokenType.SEMICOLON)
            
            # Use the parameters that were stored by parse_direct_declarator
            # If not available, create abstract parameters from types
            if self._last_function_parameters is not None:
                parameters = self._last_function_parameters
                self._last_function_parameters = None  # Clear for next use
            else:
                parameters = [
                    Parameter(location, None, param_type)
                    for param_type in full_type.parameter_types
                ]
            
            return FunctionDecl(
                location=location,
                name=name,
                return_type=full_type.return_type,
                parameters=parameters,
                body=body,
                storage_class=storage_class,
                is_inline=is_inline,
                is_variadic=full_type.is_variadic
            )
        elif self.match(TokenType.LPAREN):
            return self.parse_function_declaration(
                location, name, full_type, storage_class, is_inline
            )
        
        # Variable declaration - may have multiple declarators
        # Parse first declarator's initializer
        initializer = None
        if self.match(TokenType.ASSIGN):
            self.advance()
            initializer = self.parse_initializer()
        
        first_var = VarDecl(
            location, name, full_type, storage_class, qualifiers, initializer
        )
        
        # Check for additional declarators (comma-separated)
        if self.match(TokenType.COMMA):
            # Multiple declarators - need to return a compound statement with multiple VarDecls
            # For now, we'll create a list and wrap it
            declarations = [first_var]
            
            while self.match(TokenType.COMMA):
                self.advance()
                
                # Parse next declarator
                next_name, next_type = self.parse_declarator(base_type)
                if not next_name:
                    self.error_reporter.error(location, "Expected identifier in declaration")
                    break
                
                # Apply qualifiers
                next_type = self._apply_qualifiers_to_type(next_type, qualifiers)
                
                # Parse initializer if present
                next_initializer = None
                if self.match(TokenType.ASSIGN):
                    self.advance()
                    next_initializer = self.parse_initializer()
                
                declarations.append(VarDecl(
                    location, next_name, next_type, storage_class, qualifiers, next_initializer
                ))
            
            self.expect(TokenType.SEMICOLON)
            
            # Return a compound statement containing all declarations
            # This is a bit of a hack, but it works for statement context
            from src.parser.ast_nodes import CompoundStmt
            return CompoundStmt(location, declarations)
        
        self.expect(TokenType.SEMICOLON)
        
        return first_var
    
    def parse_declaration_specifiers(self) -> tuple[Optional[StorageClass], List[TypeQualifier], Optional[Type], bool]:
        """Parse declaration specifiers (storage class, qualifiers, type, inline).
        
        Returns:
            Tuple of (storage_class, qualifiers, base_type, is_inline)
        """
        storage_class = None
        qualifiers = []
        base_type = None
        is_inline = False
        
        # Parse storage class, qualifiers, inline, and type specifiers in any order
        while True:
            # Storage class
            if self.match(TokenType.STATIC, TokenType.EXTERN, TokenType.AUTO,
                         TokenType.REGISTER, TokenType.TYPEDEF):
                if storage_class is not None:
                    self.error_reporter.error(
                        self.peek().location,
                        "Multiple storage class specifiers"
                    )
                storage_token = self.advance()
                storage_class = self._token_to_storage_class(storage_token.type)
                continue
            
            # Inline specifier
            if self.match(TokenType.INLINE):
                self.advance()
                is_inline = True
                continue
            
            # Type qualifiers
            if self.match(TokenType.CONST, TokenType.VOLATILE, TokenType.RESTRICT):
                qual_token = self.advance()
                qualifier = self._token_to_qualifier(qual_token.type)
                if qualifier not in qualifiers:
                    qualifiers.append(qualifier)
                continue
            
            # Type specifier
            if base_type is None:
                base_type = self.parse_type_specifier()
                if base_type:
                    continue
            
            # No more specifiers
            break
        
        return storage_class, qualifiers, base_type, is_inline

    def parse_function_declaration(
        self,
        location: SourceLocation,
        name: str,
        return_type: Type,
        storage_class: Optional[StorageClass],
        is_inline: bool = False
    ) -> FunctionDecl:
        """Parse a function declaration or definition.
        
        Args:
            location: Source location
            name: Function name
            return_type: Return type
            storage_class: Storage class specifier
            is_inline: Whether function is declared inline
            
        Returns:
            FunctionDecl AST node
        """
        # Parse parameter list
        self.expect(TokenType.LPAREN)
        parameters, is_variadic = self.parse_parameter_list()
        self.expect(TokenType.RPAREN)
        
        # Check for function body
        body = None
        if self.match(TokenType.LBRACE):
            body = self.parse_compound_statement()
        else:
            self.expect(TokenType.SEMICOLON)
        
        return FunctionDecl(
            location, name, return_type, parameters, body,
            storage_class, is_inline, is_variadic
        )
    
    def parse_parameter_list(self) -> tuple[List[Parameter], bool]:
        """Parse function parameter list.
        
        Returns:
            Tuple of (parameters list, is_variadic)
        """
        parameters = []
        is_variadic = False
        
        # Empty parameter list or void
        if self.match(TokenType.RPAREN):
            return parameters, is_variadic
        
        if self.match(TokenType.VOID):
            next_token = self.tokenizer.peek_token()
            if next_token.type == TokenType.RPAREN:
                self.advance()  # consume void
                return parameters, is_variadic
        
        # Parse parameters
        while True:
            # Check for variadic parameter
            if self.match(TokenType.ELLIPSIS):
                self.advance()
                is_variadic = True
                break
            
            location = self.peek().location
            
            # Parse type qualifiers (const, volatile, restrict)
            qualifiers = []
            while self.match(TokenType.CONST, TokenType.VOLATILE, TokenType.RESTRICT):
                qual_token = self.advance()
                qualifier = self._token_to_qualifier(qual_token.type)
                if qualifier not in qualifiers:
                    qualifiers.append(qualifier)
            
            param_type = self.parse_type_specifier()
            
            if not param_type:
                break
            
            # Parse declarator (may be abstract)
            name, full_type = self.parse_declarator(param_type)
            
            # Apply qualifiers to the type if needed
            # Note: qualifiers on parameters are mostly ignored in C, but we parse them
            
            parameters.append(Parameter(location, name, full_type))
            
            if not self.match(TokenType.COMMA):
                break
            
            self.advance()  # consume comma
        
        return parameters, is_variadic
    
    def parse_struct_declaration(self) -> StructDecl:
        """Parse struct or union declaration.
        
        Handles:
        - Named structs: struct Point { int x; int y; };
        - Anonymous structs: struct { int x; int y; } var;
        - Forward declarations: struct Point;
        - Nested struct definitions
        
        Returns:
            StructDecl AST node
        """
        location = self.peek().location
        is_union = self.match(TokenType.UNION)
        self.advance()  # consume struct/union
        
        # Optional tag name
        name = None
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
        
        # Optional member list
        members = None
        if self.match(TokenType.LBRACE):
            self.advance()
            members = []
            
            while not self.match(TokenType.RBRACE, TokenType.EOF):
                # Parse member declaration
                member_type = self.parse_type_specifier()
                if not member_type:
                    break
                
                # Parse declarator (can have multiple declarators separated by commas)
                while True:
                    member_name, full_type = self.parse_declarator(member_type)
                    
                    if member_name:
                        members.append(VarDecl(
                            location, member_name, full_type, None, [], None
                        ))
                    
                    # Check for comma (multiple declarators)
                    if self.match(TokenType.COMMA):
                        self.advance()
                        continue
                    else:
                        break
                
                self.expect(TokenType.SEMICOLON)
            
            self.expect(TokenType.RBRACE)
            
            # Convert to tuple for hashability
            if members is not None:
                members = tuple(members)
        
        self.expect(TokenType.SEMICOLON)
        
        return StructDecl(location, name, is_union, members)
    
    def parse_enum_declaration(self) -> EnumDecl:
        """Parse enum declaration.
        
        Returns:
            EnumDecl AST node
        """
        location = self.peek().location
        self.expect(TokenType.ENUM)
        
        # Optional tag name
        name = None
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
        
        # Optional enumerator list
        enumerators = None
        if self.match(TokenType.LBRACE):
            self.advance()
            enumerators = []
            
            while not self.match(TokenType.RBRACE, TokenType.EOF):
                enum_name = self.expect(TokenType.IDENTIFIER).value
                
                # Optional value
                value = None
                if self.match(TokenType.ASSIGN):
                    self.advance()
                    # Parse assignment expression (precedence 2) to exclude comma and assignment operators
                    value = self.parse_expression(precedence=2)
                
                enumerators.append((enum_name, value))
                
                if not self.match(TokenType.COMMA):
                    break
                self.advance()
            
            self.expect(TokenType.RBRACE)
        
        self.expect(TokenType.SEMICOLON)
        
        return EnumDecl(location, name, enumerators)
    
    # ========================================================================
    # Type parsing
    # ========================================================================
    
    def parse_type_specifier(self) -> Optional[Type]:
        """Parse a type specifier.
        
        Returns:
            Type AST node or None
        """
        location = self.peek().location
        
        # Simple types
        if self.match(TokenType.VOID):
            self.advance()
            return PrimitiveType(location, "void")
        
        if self.match(TokenType.CHAR):
            self.advance()
            return PrimitiveType(location, "char")
        
        if self.match(TokenType.INT):
            self.advance()
            return PrimitiveType(location, "int")
        
        if self.match(TokenType.FLOAT):
            self.advance()
            return PrimitiveType(location, "float")
        
        if self.match(TokenType.DOUBLE):
            self.advance()
            return PrimitiveType(location, "double")
        
        # Signed/unsigned modifiers
        is_signed = None
        if self.match(TokenType.SIGNED):
            self.advance()
            is_signed = True
        elif self.match(TokenType.UNSIGNED):
            self.advance()
            is_signed = False
        
        # Size modifiers
        size_modifier = None
        if self.match(TokenType.SHORT):
            self.advance()
            size_modifier = "short"
        elif self.match(TokenType.LONG):
            self.advance()
            size_modifier = "long"
            # Check for long long
            if self.match(TokenType.LONG):
                self.advance()
                size_modifier = "long long"
            # Check for long double
            elif self.match(TokenType.DOUBLE):
                self.advance()
                return PrimitiveType(location, "double", True, "long")
        
        # If we have modifiers, default to int
        if is_signed is not None or size_modifier:
            # Optional int keyword
            if self.match(TokenType.INT):
                self.advance()
            # Default is_signed to True if not specified
            if is_signed is None:
                is_signed = True
            return PrimitiveType(location, "int", is_signed, size_modifier)
        
        # Struct/union types
        if self.match(TokenType.STRUCT, TokenType.UNION):
            is_union = self.match(TokenType.UNION)
            self.advance()
            
            name = None
            if self.match(TokenType.IDENTIFIER):
                name = self.advance().value
            
            # Check for inline definition
            members = None
            if self.match(TokenType.LBRACE):
                self.advance()
                members = []
                
                while not self.match(TokenType.RBRACE, TokenType.EOF):
                    member_type = self.parse_type_specifier()
                    if not member_type:
                        break
                    
                    # Parse declarator (can have multiple declarators separated by commas)
                    while True:
                        member_name, full_type = self.parse_declarator(member_type)
                        if member_name:
                            members.append(VarDecl(
                                location, member_name, full_type, None, [], None
                            ))
                        
                        # Check for comma (multiple declarators)
                        if self.match(TokenType.COMMA):
                            self.advance()
                            continue
                        else:
                            break
                    
                    self.expect(TokenType.SEMICOLON)
                
                self.expect(TokenType.RBRACE)
                
                # Convert to tuple for hashability
                if members is not None:
                    members = tuple(members)
            
            return StructType(location, name, is_union, members)
        
        # Enum types
        if self.match(TokenType.ENUM):
            self.advance()
            
            name = None
            if self.match(TokenType.IDENTIFIER):
                name = self.advance().value
            
            enumerators = None
            if self.match(TokenType.LBRACE):
                self.advance()
                enumerators = []
                
                while not self.match(TokenType.RBRACE, TokenType.EOF):
                    enum_name = self.expect(TokenType.IDENTIFIER).value
                    
                    value = None
                    if self.match(TokenType.ASSIGN):
                        self.advance()
                        # Parse assignment expression (precedence 2) to exclude comma operator
                        value = self.parse_expression(precedence=2)
                    
                    enumerators.append((enum_name, value))
                    
                    if not self.match(TokenType.COMMA):
                        break
                    self.advance()
                
                self.expect(TokenType.RBRACE)
            
            return EnumType(location, name, enumerators)
        
        # Typedef name (identifier) - only if it's a known typedef
        if self.match(TokenType.IDENTIFIER):
            name = self.peek().value
            if name in self.typedef_names:
                self.advance()
                return TypedefType(location, name)
        
        return None
    
    def parse_declarator(self, base_type: Type) -> tuple[Optional[str], Type]:
        """Parse a declarator (name with type modifiers like pointers, arrays).
        
        Args:
            base_type: The base type from type specifier
            
        Returns:
            Tuple of (name, full_type)
        """
        location = self.peek().location
        
        # Parse pointer prefix
        pointer_count = 0
        qualifiers_list = []
        while self.match(TokenType.STAR):
            self.advance()
            pointer_count += 1
            
            # Type qualifiers after *
            quals = []
            while self.match(TokenType.CONST, TokenType.VOLATILE, TokenType.RESTRICT):
                qual_token = self.advance()
                quals.append(self._token_to_qualifier(qual_token.type))
            qualifiers_list.append(quals)
        
        # Apply pointers to base type first (right-to-left)
        # This creates the "base" that the direct declarator will modify
        modified_base = base_type
        for i in range(pointer_count - 1, -1, -1):
            modified_base = PointerType(location, modified_base, tuple(qualifiers_list[i]))
        
        # Parse direct declarator (name, arrays, function pointers)
        # This will apply arrays and function types to the modified base
        name, result_type = self.parse_direct_declarator(modified_base)
        
        return name, result_type
    
    def parse_direct_declarator(self, base_type: Type) -> tuple[Optional[str], Type]:
        """Parse a direct declarator (name, arrays, function pointers).
        
        Handles:
        - Simple identifiers: int x
        - Parenthesized declarators: int (*fp)
        - Arrays: int arr[10]
        - Function pointers: int (*fp)(int, int)
        - Arrays of function pointers: int (*arr[10])(void)
        
        Args:
            base_type: The base type
            
        Returns:
            Tuple of (name, type)
        """
        location = self.peek().location
        name = None
        result_type = base_type
        
        # Parenthesized declarator or function pointer
        if self.match(TokenType.LPAREN):
            # Need to look ahead to distinguish:
            # - Function pointer: ( * identifier ) ( params )
            # - Parenthesized declarator: ( declarator )
            # - Function parameter list: ( params ) - handled elsewhere
            
            self.advance()  # consume (
            
            # Check if this is a function pointer or parenthesized declarator
            # If we see *, it's likely a function pointer or pointer declarator
            # If we see identifier or another (, it's a parenthesized declarator
            # If we see type specifier, it's a parameter list (not a declarator)
            
            is_param_list = self._is_parameter_list_start()
            
            if is_param_list:
                # This is a function parameter list, not a parenthesized declarator
                # Parse it as part of postfix
                # We need to back up - but since we can't easily backtrack,
                # we'll handle this case by parsing parameters here
                parameters, is_variadic = self.parse_parameter_list()
                self.expect(TokenType.RPAREN)
                
                # Extract parameter types
                param_types = tuple(param.param_type for param in parameters)
                
                # Create function type with base_type as return type
                result_type = FunctionType(
                    location=location,
                    return_type=base_type,
                    parameter_types=param_types,
                    is_variadic=is_variadic
                )
                # No name for abstract declarator
                return None, result_type
            else:
                # This is a parenthesized declarator (possibly function pointer)
                # Example: int (*fp)(int) or int (*arr[10])(void)
                # Parse the inner declarator - this handles pointers and arrays inside the parens
                name, inner_type = self.parse_declarator(base_type)
                self.expect(TokenType.RPAREN)
                
                # After the closing paren, we may have postfix operators (arrays, function calls)
                # These should be applied to the base type that the innermost pointer points to
                # For example: int (*arr[10])(void)
                #   - inner_type is Array[10] of (Pointer to int)
                #   - postfix (void) should make it Array[10] of (Pointer to (Function returning int))
                #   - So we need to apply postfix to the 'int' part, then wrap it back
                
                # Extract all type layers from inner_type down to base_type
                type_layers = []
                current = inner_type
                while current != base_type:
                    if isinstance(current, PointerType):
                        type_layers.append(('pointer', current.qualifiers))
                        current = current.pointee_type
                    elif isinstance(current, ArrayType):
                        type_layers.append(('array', current.size, current.is_vla, current.size_value))
                        current = current.element_type
                    else:
                        break
                
                # Now current should be base_type, and type_layers has all modifications
                # We'll apply postfix to base_type, then re-apply the type layers
                result_type = base_type
                has_inner_layers = len(type_layers) > 0
                inner_type_layers = type_layers if has_inner_layers else None
        elif self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            result_type = base_type
            has_inner_layers = False
            inner_type_layers = None
        else:
            # Abstract declarator (no name)
            result_type = base_type
            has_inner_layers = False
            inner_type_layers = None
        
        # Parse postfix (arrays and function pointers)
        # This applies to whatever we parsed above (identifier, parenthesized declarator, or nothing)
        while True:
            if self.match(TokenType.LBRACKET):
                # Array declarator: type[size]
                self.advance()
                size_expr = None
                size_value = None
                is_vla = False
                
                if not self.match(TokenType.RBRACKET):
                    # Parse size expression
                    size_expr = self.parse_expression()
                    
                    # Try to evaluate constant size
                    size_value = self._try_evaluate_constant_expr(size_expr)
                    
                    # If size is not constant, it's a VLA (C99 feature)
                    if size_value is None and size_expr is not None:
                        is_vla = True
                
                self.expect(TokenType.RBRACKET)
                
                # Create array type with enhanced information
                result_type = ArrayType(
                    location=location,
                    element_type=result_type,
                    size=size_expr,
                    is_vla=is_vla,
                    size_value=size_value
                )
            elif self.match(TokenType.LPAREN):
                # Function declarator: type(params)
                # This creates a function type where result_type is the return type
                self.advance()
                parameters, is_variadic = self.parse_parameter_list()
                self.expect(TokenType.RPAREN)
                
                # Store parameters for later use (in case this is a function declaration)
                self._last_function_parameters = parameters
                
                # Extract parameter types
                param_types = tuple(param.param_type for param in parameters)
                
                # Create function type
                result_type = FunctionType(
                    location=location,
                    return_type=result_type,
                    parameter_types=param_types,
                    is_variadic=is_variadic
                )
            else:
                break
        
        # If we had a parenthesized declarator with type layers, apply them now
        # Apply in reverse order (innermost to outermost) to reconstruct the type correctly
        if has_inner_layers and inner_type_layers:
            for layer in reversed(inner_type_layers):
                if layer[0] == 'pointer':
                    quals = layer[1]
                    result_type = PointerType(location, result_type, quals)
                elif layer[0] == 'array':
                    size_expr, is_vla, size_value = layer[1], layer[2], layer[3]
                    result_type = ArrayType(
                        location=location,
                        element_type=result_type,
                        size=size_expr,
                        is_vla=is_vla,
                        size_value=size_value
                    )
        
        return name, result_type
    
    def _is_parameter_list_start(self) -> bool:
        """Check if current position starts a parameter list.
        
        This helps distinguish between:
        - Parenthesized declarator: (declarator)
        - Function parameter list: (type name, ...)
        
        Returns:
            True if this looks like a parameter list, False otherwise
        """
        # Empty parameter list
        if self.match(TokenType.RPAREN):
            return True
        
        # void parameter
        if self.match(TokenType.VOID):
            return True
        
        # Type specifiers indicate parameter list
        if self.match(
            TokenType.INT, TokenType.CHAR, TokenType.FLOAT, TokenType.DOUBLE,
            TokenType.VOID, TokenType.SHORT, TokenType.LONG, TokenType.SIGNED,
            TokenType.UNSIGNED, TokenType.STRUCT, TokenType.UNION, TokenType.ENUM,
            TokenType.CONST, TokenType.VOLATILE, TokenType.RESTRICT
        ):
            return True
        
        # Check if identifier is a typedef name
        if self.match(TokenType.IDENTIFIER):
            name = self.peek().value
            if name in self.typedef_names:
                return True
        
        # Otherwise, assume it's a parenthesized declarator
        return False
    
    def parse_initializer(self) -> Expression:
        """Parse an initializer (expression or initializer list).
        
        Returns:
            Expression AST node
        """
        if self.match(TokenType.LBRACE):
            return self.parse_initializer_list()
        else:
            # Parse expression with precedence 1 to exclude comma operator
            # This prevents "int a = 10, b = 5" from parsing ", b = 5" as part of initializer
            return self.parse_expression(precedence=1)
    
    def parse_initializer_list(self) -> InitializerList:
        """Parse an initializer list { ... }.
        
        Returns:
            InitializerList AST node
        """
        location = self.peek().location
        self.expect(TokenType.LBRACE)
        
        initializers = []
        while not self.match(TokenType.RBRACE, TokenType.EOF):
            initializers.append(self.parse_initializer())
            
            if not self.match(TokenType.COMMA):
                break
            self.advance()
        
        self.expect(TokenType.RBRACE)
        
        return InitializerList(location, initializers)

    # ========================================================================
    # Statement parsing
    # ========================================================================
    
    def parse_statement(self) -> Statement:
        """Parse a statement.
        
        Returns:
            Statement AST node
        """
        location = self.peek().location
        
        # Compound statement
        if self.match(TokenType.LBRACE):
            return self.parse_compound_statement()
        
        # If statement
        if self.match(TokenType.IF):
            return self.parse_if_statement()
        
        # While statement
        if self.match(TokenType.WHILE):
            return self.parse_while_statement()
        
        # Do-while statement
        if self.match(TokenType.DO):
            return self.parse_do_while_statement()
        
        # For statement
        if self.match(TokenType.FOR):
            return self.parse_for_statement()
        
        # Return statement
        if self.match(TokenType.RETURN):
            return self.parse_return_statement()
        
        # Break statement
        if self.match(TokenType.BREAK):
            self.advance()
            self.expect(TokenType.SEMICOLON)
            return BreakStmt(location)
        
        # Continue statement
        if self.match(TokenType.CONTINUE):
            self.advance()
            self.expect(TokenType.SEMICOLON)
            return ContinueStmt(location)
        
        # Switch statement
        if self.match(TokenType.SWITCH):
            return self.parse_switch_statement()
        
        # Case/default statement
        if self.match(TokenType.CASE):
            return self.parse_case_statement()
        
        if self.match(TokenType.DEFAULT):
            return self.parse_default_statement()
        
        # Goto statement
        if self.match(TokenType.GOTO):
            self.advance()
            label = self.expect(TokenType.IDENTIFIER).value
            self.expect(TokenType.SEMICOLON)
            return GotoStmt(location, label)
        
        # Check for label (identifier followed by colon)
        if self.match(TokenType.IDENTIFIER):
            next_token = self.tokenizer.peek_token()
            if next_token.type == TokenType.COLON:
                label = self.advance().value
                self.advance()  # consume colon
                stmt = self.parse_statement()
                return LabelStmt(location, label, stmt)
        
        # Declaration (variable declaration in statement context)
        # In C99, declarations can appear as statements
        if self.is_type_specifier():
            return self.parse_declaration()
        
        # Expression statement
        return self.parse_expression_statement()
    
    def parse_compound_statement(self) -> CompoundStmt:
        """Parse a compound statement (block).
        
        Returns:
            CompoundStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.LBRACE)
        
        statements = []
        while not self.match(TokenType.RBRACE, TokenType.EOF):
            # Check for declarations (C99 allows declarations as statements)
            if self.is_type_specifier():
                decl = self.parse_declaration()
                statements.append(decl)
            else:
                statements.append(self.parse_statement())
        
        self.expect(TokenType.RBRACE)
        
        return CompoundStmt(location, statements)
    
    def parse_expression_statement(self) -> ExpressionStmt:
        """Parse an expression statement.
        
        Returns:
            ExpressionStmt AST node
        """
        location = self.peek().location
        
        # Empty statement
        if self.match(TokenType.SEMICOLON):
            self.advance()
            return ExpressionStmt(location, None)
        
        expr = self.parse_expression()
        self.expect(TokenType.SEMICOLON)
        
        return ExpressionStmt(location, expr)
    
    def parse_if_statement(self) -> IfStmt:
        """Parse an if statement.
        
        Returns:
            IfStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.IF)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        then_stmt = self.parse_statement()
        
        else_stmt = None
        if self.match(TokenType.ELSE):
            self.advance()
            else_stmt = self.parse_statement()
        
        return IfStmt(location, condition, then_stmt, else_stmt)
    
    def parse_while_statement(self) -> WhileStmt:
        """Parse a while statement.
        
        Returns:
            WhileStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.WHILE)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        body = self.parse_statement()
        
        return WhileStmt(location, condition, body)
    
    def parse_do_while_statement(self) -> DoWhileStmt:
        """Parse a do-while statement.
        
        Returns:
            DoWhileStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.DO)
        
        body = self.parse_statement()
        
        self.expect(TokenType.WHILE)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        self.expect(TokenType.SEMICOLON)
        
        return DoWhileStmt(location, body, condition)
    
    def parse_for_statement(self) -> ForStmt:
        """Parse a for statement.
        
        Returns:
            ForStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.FOR)
        self.expect(TokenType.LPAREN)
        
        # Init (expression, declaration, or empty)
        init = None
        if not self.match(TokenType.SEMICOLON):
            if self.is_type_specifier():
                init = self.parse_declaration()
                # Don't expect semicolon, declaration already consumed it
            else:
                init = self.parse_expression()
                self.expect(TokenType.SEMICOLON)
        else:
            self.advance()  # consume semicolon
        
        # Condition (expression or empty)
        condition = None
        if not self.match(TokenType.SEMICOLON):
            condition = self.parse_expression()
        self.expect(TokenType.SEMICOLON)
        
        # Increment (expression or empty)
        increment = None
        if not self.match(TokenType.RPAREN):
            increment = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        body = self.parse_statement()
        
        return ForStmt(location, init, condition, increment, body)
    
    def parse_return_statement(self) -> ReturnStmt:
        """Parse a return statement.
        
        Returns:
            ReturnStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.RETURN)
        
        value = None
        if not self.match(TokenType.SEMICOLON):
            value = self.parse_expression()
        
        self.expect(TokenType.SEMICOLON)
        
        return ReturnStmt(location, value)
    
    def parse_switch_statement(self) -> SwitchStmt:
        """Parse a switch statement.
        
        Returns:
            SwitchStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.SWITCH)
        self.expect(TokenType.LPAREN)
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN)
        
        body = self.parse_statement()
        
        return SwitchStmt(location, condition, body)
    
    def parse_case_statement(self) -> CaseStmt:
        """Parse a case statement.
        
        Returns:
            CaseStmt AST node
        """
        location = self.peek().location
        self.expect(TokenType.CASE)
        value = self.parse_expression()
        self.expect(TokenType.COLON)
        statement = self.parse_statement()
        
        return CaseStmt(location, value, statement)
    
    def parse_default_statement(self) -> CaseStmt:
        """Parse a default statement.
        
        Returns:
            CaseStmt AST node (with None value)
        """
        location = self.peek().location
        self.expect(TokenType.DEFAULT)
        self.expect(TokenType.COLON)
        statement = self.parse_statement()
        
        return CaseStmt(location, None, statement)

    # ========================================================================
    # Expression parsing with operator precedence
    # ========================================================================
    
    def parse_expression(self, precedence: int = 0) -> Expression:
        """Parse an expression using operator precedence parsing.
        
        Args:
            precedence: Minimum precedence level to parse
            
        Returns:
            Expression AST node
        """
        # Parse primary/prefix expression
        left = self.parse_prefix_expression()
        
        # Parse infix/postfix operators
        while True:
            # Check for comma operator (lowest precedence)
            if self.match(TokenType.COMMA):
                if precedence > 0:  # Comma has lowest precedence (0)
                    break
                # Collect all comma-separated expressions
                expressions = [left]
                while self.match(TokenType.COMMA):
                    self.advance()
                    expressions.append(self.parse_expression(1))  # Parse next with higher precedence
                left = CommaExpr(left.location, expressions)
                continue
            
            # Check for assignment operators
            if self.is_assignment_operator():
                if precedence > 1:  # Assignment has precedence 1
                    break
                op = self.advance().value
                right = self.parse_expression(1)
                left = AssignmentExpr(left.location, op, left, right)
                continue
            
            # Check for ternary conditional
            if self.match(TokenType.QUESTION):
                if precedence > 2:
                    break
                self.advance()
                true_expr = self.parse_expression()
                self.expect(TokenType.COLON)
                false_expr = self.parse_expression(2)
                left = ConditionalExpr(left.location, left, true_expr, false_expr)
                continue
            
            # Check for binary operators
            if self.is_binary_operator():
                op_precedence = self.get_operator_precedence(self.peek().type)
                if precedence > op_precedence:
                    break
                
                op = self.advance().value
                right = self.parse_expression(op_precedence + 1)
                left = BinaryExpr(left.location, op, left, right)
                continue
            
            # Check for postfix operators
            if self.match(TokenType.PLUS_PLUS, TokenType.MINUS_MINUS):
                op = self.advance().value
                left = UnaryExpr(left.location, op, left, False)
                continue
            
            # Array subscript
            if self.match(TokenType.LBRACKET):
                self.advance()
                index = self.parse_expression()
                self.expect(TokenType.RBRACKET)
                left = ArraySubscript(left.location, left, index)
                continue
            
            # Function call
            if self.match(TokenType.LPAREN):
                self.advance()
                args = []
                while not self.match(TokenType.RPAREN, TokenType.EOF):
                    # Parse assignment expression (precedence 1) to avoid parsing comma as operator
                    args.append(self.parse_expression(1))
                    if not self.match(TokenType.COMMA):
                        break
                    self.advance()
                self.expect(TokenType.RPAREN)
                left = CallExpr(left.location, left, args)
                continue
            
            # Member access
            if self.match(TokenType.DOT):
                self.advance()
                member = self.expect(TokenType.IDENTIFIER).value
                left = MemberAccess(left.location, left, member, False)
                continue
            
            if self.match(TokenType.ARROW):
                self.advance()
                member = self.expect(TokenType.IDENTIFIER).value
                left = MemberAccess(left.location, left, member, True)
                continue
            
            # No more operators
            break
        
        return left
    
    def parse_prefix_expression(self) -> Expression:
        """Parse a prefix expression (unary operators, primary expressions).
        
        Returns:
            Expression AST node
        """
        location = self.peek().location
        
        # Unary operators
        if self.match(TokenType.PLUS, TokenType.MINUS, TokenType.EXCLAMATION,
                     TokenType.TILDE, TokenType.STAR, TokenType.AMPERSAND):
            op = self.advance().value
            operand = self.parse_prefix_expression()
            return UnaryExpr(location, op, operand, True)
        
        # Prefix increment/decrement
        if self.match(TokenType.PLUS_PLUS, TokenType.MINUS_MINUS):
            op = self.advance().value
            operand = self.parse_prefix_expression()
            return UnaryExpr(location, op, operand, True)
        
        # Sizeof
        if self.match(TokenType.SIZEOF):
            self.advance()
            
            # Check if sizeof(type) or sizeof expression
            if self.match(TokenType.LPAREN):
                # Look ahead to see if it's a type
                saved_pos = self.tokenizer.pos
                saved_line = self.tokenizer.line
                saved_column = self.tokenizer.column
                saved_token = self.current_token
                
                self.advance()  # consume (
                is_type = self.is_type_specifier()
                
                # Restore state
                self.tokenizer.pos = saved_pos
                self.tokenizer.line = saved_line
                self.tokenizer.column = saved_column
                self.current_token = saved_token
                
                if is_type:
                    self.advance()  # consume (
                    type_node = self.parse_type_specifier()
                    self.expect(TokenType.RPAREN)
                    return SizeofExpr(location, type_node, True)
            
            # sizeof expression
            operand = self.parse_prefix_expression()
            return SizeofExpr(location, operand, False)
        
        # Cast expression
        if self.match(TokenType.LPAREN):
            # Look ahead to see if it's a cast
            saved_pos = self.tokenizer.pos
            saved_line = self.tokenizer.line
            saved_column = self.tokenizer.column
            saved_token = self.current_token
            
            self.advance()  # consume (
            is_type = self.is_type_specifier()
            
            # Restore state
            self.tokenizer.pos = saved_pos
            self.tokenizer.line = saved_line
            self.tokenizer.column = saved_column
            self.current_token = saved_token
            
            if is_type:
                self.advance()  # consume (
                target_type = self.parse_type_specifier()
                self.expect(TokenType.RPAREN)
                operand = self.parse_prefix_expression()
                return CastExpr(location, target_type, operand)
        
        # Primary expression
        return self.parse_primary_expression()
    
    def parse_primary_expression(self) -> Expression:
        """Parse a primary expression (literals, identifiers, parenthesized).
        
        Returns:
            Expression AST node
        """
        location = self.peek().location
        
        # Integer literal
        if self.match(TokenType.INTEGER_LITERAL):
            value = self.advance().value
            return Literal(location, value, "int")
        
        # Float literal
        if self.match(TokenType.FLOAT_LITERAL):
            value = self.advance().value
            return Literal(location, value, "float")
        
        # String literal
        if self.match(TokenType.STRING_LITERAL):
            value = self.advance().value
            return Literal(location, value, "string")
        
        # Character literal
        if self.match(TokenType.CHAR_LITERAL):
            value = self.advance().value
            return Literal(location, value, "char")
        
        # Identifier
        if self.match(TokenType.IDENTIFIER):
            name = self.advance().value
            return Identifier(location, name)
        
        # Parenthesized expression
        if self.match(TokenType.LPAREN):
            self.advance()
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN)
            return expr
        
        # Error
        self.error_reporter.error(location, f"Unexpected token: {self.peek().type.name}")
        self.advance()
        return Identifier(location, "<error>")
    
    # ========================================================================
    # Helper methods
    # ========================================================================
    
    def is_type_specifier(self) -> bool:
        """Check if current token starts a type specifier."""
        # Check for built-in type keywords
        if self.match(
            TokenType.VOID, TokenType.CHAR, TokenType.SHORT, TokenType.INT,
            TokenType.LONG, TokenType.FLOAT, TokenType.DOUBLE,
            TokenType.SIGNED, TokenType.UNSIGNED,
            TokenType.STRUCT, TokenType.UNION, TokenType.ENUM,
            TokenType.CONST, TokenType.VOLATILE, TokenType.RESTRICT
        ):
            return True
        
        # Check if identifier is a typedef name
        if self.match(TokenType.IDENTIFIER):
            name = self.peek().value
            return name in self.typedef_names
        
        return False
    
    def is_binary_operator(self) -> bool:
        """Check if current token is a binary operator."""
        return self.match(
            TokenType.PLUS, TokenType.MINUS, TokenType.STAR, TokenType.SLASH,
            TokenType.PERCENT, TokenType.AMPERSAND, TokenType.PIPE, TokenType.CARET,
            TokenType.LSHIFT, TokenType.RSHIFT,
            TokenType.EQ, TokenType.NE, TokenType.LT, TokenType.LE,
            TokenType.GT, TokenType.GE,
            TokenType.LOGICAL_AND, TokenType.LOGICAL_OR
        )
    
    def is_assignment_operator(self) -> bool:
        """Check if current token is an assignment operator."""
        return self.match(
            TokenType.ASSIGN, TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN,
            TokenType.STAR_ASSIGN, TokenType.SLASH_ASSIGN, TokenType.PERCENT_ASSIGN,
            TokenType.AMPERSAND_ASSIGN, TokenType.PIPE_ASSIGN, TokenType.CARET_ASSIGN,
            TokenType.LSHIFT_ASSIGN, TokenType.RSHIFT_ASSIGN
        )
    
    def get_operator_precedence(self, token_type: TokenType) -> int:
        """Get the precedence level for an operator.
        
        Higher numbers = higher precedence (binds tighter).
        """
        precedence_table = {
            # Multiplicative
            TokenType.STAR: 12,
            TokenType.SLASH: 12,
            TokenType.PERCENT: 12,
            
            # Additive
            TokenType.PLUS: 11,
            TokenType.MINUS: 11,
            
            # Shift
            TokenType.LSHIFT: 10,
            TokenType.RSHIFT: 10,
            
            # Relational
            TokenType.LT: 9,
            TokenType.LE: 9,
            TokenType.GT: 9,
            TokenType.GE: 9,
            
            # Equality
            TokenType.EQ: 8,
            TokenType.NE: 8,
            
            # Bitwise AND
            TokenType.AMPERSAND: 7,
            
            # Bitwise XOR
            TokenType.CARET: 6,
            
            # Bitwise OR
            TokenType.PIPE: 5,
            
            # Logical AND
            TokenType.LOGICAL_AND: 4,
            
            # Logical OR
            TokenType.LOGICAL_OR: 3,
        }
        
        return precedence_table.get(token_type, 0)
    
    def _token_to_storage_class(self, token_type: TokenType) -> StorageClass:
        """Convert token type to storage class enum."""
        mapping = {
            TokenType.AUTO: StorageClass.AUTO,
            TokenType.REGISTER: StorageClass.REGISTER,
            TokenType.STATIC: StorageClass.STATIC,
            TokenType.EXTERN: StorageClass.EXTERN,
            TokenType.TYPEDEF: StorageClass.TYPEDEF,
        }
        return mapping[token_type]
    
    def _token_to_qualifier(self, token_type: TokenType) -> TypeQualifier:
        """Convert token type to type qualifier enum."""
        mapping = {
            TokenType.CONST: TypeQualifier.CONST,
            TokenType.VOLATILE: TypeQualifier.VOLATILE,
            TokenType.RESTRICT: TypeQualifier.RESTRICT,
        }
        return mapping[token_type]

    def _try_evaluate_constant_expr(self, expr: Expression) -> Optional[int]:
        """Try to evaluate a constant expression at parse time.
        
        This is a simple constant evaluator for array sizes. It only handles
        integer literals and simple arithmetic. Full constant expression
        evaluation is done in semantic analysis.
        
        Args:
            expr: Expression to evaluate
            
        Returns:
            Integer value if expression is a constant, None otherwise
        """
        if isinstance(expr, Literal):
            # Integer literal
            if expr.literal_type == 'int':
                try:
                    return int(expr.value)
                except (ValueError, TypeError):
                    return None
            return None
        
        elif isinstance(expr, BinaryExpr):
            # Try to evaluate binary expression
            left_val = self._try_evaluate_constant_expr(expr.left)
            right_val = self._try_evaluate_constant_expr(expr.right)
            
            if left_val is None or right_val is None:
                return None
            
            # Evaluate based on operator
            if expr.operator == '+':
                return left_val + right_val
            elif expr.operator == '-':
                return left_val - right_val
            elif expr.operator == '*':
                return left_val * right_val
            elif expr.operator == '/':
                if right_val == 0:
                    return None
                return left_val // right_val
            elif expr.operator == '%':
                if right_val == 0:
                    return None
                return left_val % right_val
            else:
                return None
        
        elif isinstance(expr, UnaryExpr):
            # Try to evaluate unary expression
            operand_val = self._try_evaluate_constant_expr(expr.operand)
            
            if operand_val is None:
                return None
            
            if expr.operator == '+':
                return operand_val
            elif expr.operator == '-':
                return -operand_val
            else:
                return None
        
        # For other expressions (identifiers, function calls, etc.), 
        # we can't evaluate at parse time
        return None

    # ========================================================================
    # Helper methods for type qualifiers and storage classes
    # ========================================================================
    
    def _token_to_storage_class(self, token_type: TokenType) -> Optional[StorageClass]:
        """Convert a token type to a storage class specifier.
        
        Args:
            token_type: Token type to convert
            
        Returns:
            StorageClass enum value or None
        """
        mapping = {
            TokenType.AUTO: StorageClass.AUTO,
            TokenType.REGISTER: StorageClass.REGISTER,
            TokenType.STATIC: StorageClass.STATIC,
            TokenType.EXTERN: StorageClass.EXTERN,
            TokenType.TYPEDEF: StorageClass.TYPEDEF,
        }
        return mapping.get(token_type)
    
    def _token_to_qualifier(self, token_type: TokenType) -> Optional[TypeQualifier]:
        """Convert a token type to a type qualifier.
        
        Args:
            token_type: Token type to convert
            
        Returns:
            TypeQualifier enum value or None
        """
        mapping = {
            TokenType.CONST: TypeQualifier.CONST,
            TokenType.VOLATILE: TypeQualifier.VOLATILE,
            TokenType.RESTRICT: TypeQualifier.RESTRICT,
        }
        return mapping.get(token_type)

    def _apply_qualifiers_to_type(self, type_obj: Type, qualifiers: List[TypeQualifier]) -> Type:
        """Apply type qualifiers to a type.
        
        Args:
            type_obj: Type to apply qualifiers to
            qualifiers: List of qualifiers to apply
            
        Returns:
            Type with qualifiers applied
        """
        if not qualifiers:
            return type_obj
        
        # Convert list to tuple for hashability
        qual_tuple = tuple(qualifiers)
        
        # Apply qualifiers based on type
        if isinstance(type_obj, PrimitiveType):
            return PrimitiveType(
                location=type_obj.location,
                name=type_obj.name,
                is_signed=type_obj.is_signed,
                size_modifier=type_obj.size_modifier,
                qualifiers=qual_tuple
            )
        elif isinstance(type_obj, PointerType):
            # Qualifiers apply to the pointee type
            return PointerType(
                location=type_obj.location,
                pointee_type=type_obj.pointee_type,
                qualifiers=qual_tuple
            )
        else:
            # For other types, return as-is (qualifiers are stored separately in VarDecl)
            return type_obj
