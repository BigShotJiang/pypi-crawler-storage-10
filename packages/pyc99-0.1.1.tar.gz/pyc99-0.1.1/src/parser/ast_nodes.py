"""Abstract Syntax Tree node definitions for C99."""

from dataclasses import dataclass
from typing import Optional, List, Any
from enum import Enum, auto

from src.utils.source_location import SourceLocation


# ============================================================================
# Base Classes
# ============================================================================

@dataclass
class ASTNode:
    """Base class for all AST nodes.
    
    Attributes:
        location: Source location where this node was parsed
    """
    location: SourceLocation
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return f"{self.__class__.__name__}()"


# ============================================================================
# Type System
# ============================================================================

class TypeQualifier(Enum):
    """Type qualifiers in C99."""
    CONST = auto()
    VOLATILE = auto()
    RESTRICT = auto()


class StorageClass(Enum):
    """Storage class specifiers in C99."""
    AUTO = auto()
    REGISTER = auto()
    STATIC = auto()
    EXTERN = auto()
    TYPEDEF = auto()


@dataclass(unsafe_hash=True)
class Type(ASTNode):
    """Base class for type representations."""
    pass


@dataclass(unsafe_hash=True)
class PrimitiveType(Type):
    """Primitive types (int, char, float, etc.).
    
    Attributes:
        name: Type name (e.g., 'int', 'char', 'float', 'double', 'void')
        is_signed: Whether the type is signed (for integer types)
        size_modifier: Size modifier ('short', 'long', 'long long', or None)
        qualifiers: Type qualifiers (const, volatile, restrict)
    """
    name: str
    is_signed: bool = True
    size_modifier: Optional[str] = None
    qualifiers: tuple = ()
    
    def is_const(self) -> bool:
        """Check if type is const qualified."""
        return TypeQualifier.CONST in self.qualifiers
    
    def is_volatile(self) -> bool:
        """Check if type is volatile qualified."""
        return TypeQualifier.VOLATILE in self.qualifiers


@dataclass(unsafe_hash=True)
class PointerType(Type):
    """Pointer type.
    
    Attributes:
        pointee_type: Type being pointed to
        qualifiers: Type qualifiers (const, volatile, restrict) applied to the pointee
    """
    pointee_type: Type
    qualifiers: tuple = ()  # Changed from List to tuple for hashability
    
    def is_const(self) -> bool:
        """Check if pointer points to const data."""
        return TypeQualifier.CONST in self.qualifiers
    
    def is_volatile(self) -> bool:
        """Check if pointer points to volatile data."""
        return TypeQualifier.VOLATILE in self.qualifiers
    
    def is_restrict(self) -> bool:
        """Check if pointer has restrict qualifier."""
        return TypeQualifier.RESTRICT in self.qualifiers


@dataclass
class ArrayType(Type):
    """Array type.
    
    Represents C array types including:
    - Fixed-size arrays: int arr[10]
    - Incomplete arrays: int arr[]
    - Multi-dimensional arrays: int arr[5][10]
    - Variable-length arrays (VLA): int arr[n] (C99)
    
    Attributes:
        element_type: Type of array elements (can be another ArrayType for multi-dimensional)
        size: Size expression (None for incomplete/unsized arrays)
        is_vla: True if this is a variable-length array (size depends on runtime value)
        size_value: Computed constant size (None if not constant or VLA)
    """
    element_type: Type
    size: Optional['Expression'] = None
    is_vla: bool = False
    size_value: Optional[int] = None
    
    def __hash__(self):
        """Custom hash that excludes size expression (which is unhashable)."""
        # Hash based on element type, size_value, and is_vla
        # Exclude 'size' field as it contains Expression which is unhashable
        return hash((self.element_type, self.size_value, self.is_vla))
    
    def is_complete(self) -> bool:
        """Check if array type is complete (has known size).
        
        Returns:
            True if array has a size, False for incomplete arrays
        """
        return self.size is not None or self.size_value is not None
    
    def get_total_size(self) -> Optional[int]:
        """Get total number of elements (for multi-dimensional arrays).
        
        Returns:
            Total number of elements, or None if size is not constant
        """
        if self.size_value is None:
            return None
        
        if isinstance(self.element_type, ArrayType):
            inner_size = self.element_type.get_total_size()
            if inner_size is None:
                return None
            return self.size_value * inner_size
        
        return self.size_value


@dataclass(unsafe_hash=True)
class FunctionType(Type):
    """Function type.
    
    Attributes:
        return_type: Return type of the function
        parameter_types: Tuple of parameter types (tuple for hashability)
        is_variadic: Whether function accepts variable arguments
    """
    return_type: Type = None
    parameter_types: tuple = ()  # Changed from List to tuple for hashability
    is_variadic: bool = False


@dataclass(unsafe_hash=True)
class StructType(Type):
    """Struct or union type.
    
    Represents C struct and union types with layout information:
    - Struct: members laid out sequentially with padding for alignment
    - Union: all members share the same memory location
    
    Attributes:
        name: Struct/union tag name (None for anonymous)
        is_union: True for union, False for struct
        members: List of member declarations (None if incomplete/forward declaration)
        member_offsets: Dictionary mapping member names to byte offsets (computed during layout)
        size: Total size in bytes (computed during layout, None if incomplete)
        alignment: Required alignment in bytes (computed during layout, None if incomplete)
        is_complete: Whether this is a complete type (has member definitions)
    """
    name: Optional[str] = None
    is_union: bool = False
    members: Optional[tuple] = None  # Changed from List to tuple for hashability
    member_offsets: Optional[dict] = None  # Maps member name -> byte offset
    size: Optional[int] = None  # Total size in bytes
    alignment: Optional[int] = None  # Required alignment in bytes
    is_complete: bool = False  # True if members are defined
    
    def __post_init__(self):
        """Initialize computed fields."""
        # Mark as complete if members are provided
        if self.members is not None:
            object.__setattr__(self, 'is_complete', True)
    
    def get_member(self, name: str) -> Optional['VarDecl']:
        """Get a member by name.
        
        Args:
            name: Member name to look up
            
        Returns:
            VarDecl for the member, or None if not found
        """
        if self.members is None:
            return None
        
        for member in self.members:
            if member.name == name:
                return member
        
        return None
    
    def get_member_offset(self, name: str) -> Optional[int]:
        """Get the byte offset of a member.
        
        Args:
            name: Member name to look up
            
        Returns:
            Byte offset of the member, or None if not found or layout not computed
        """
        if self.member_offsets is None:
            return None
        
        return self.member_offsets.get(name)


@dataclass(unsafe_hash=True)
class EnumType(Type):
    """Enum type.
    
    Attributes:
        name: Enum tag name (None for anonymous)
        enumerators: List of (name, value) tuples (None if incomplete)
    """
    name: Optional[str] = None
    enumerators: Optional[tuple] = None  # Changed from List to tuple for hashability


@dataclass(unsafe_hash=True)
class TypedefType(Type):
    """Typedef'd type reference.
    
    Attributes:
        name: Name of the typedef
        actual_type: The actual type (filled in by semantic analysis)
    """
    name: str = ""
    actual_type: Optional[Type] = None


# ============================================================================
# Expressions
# ============================================================================

@dataclass
class Expression(ASTNode):
    """Base class for all expressions.
    
    Note: expr_type attribute will be added by semantic analyzer.
    """
    pass


@dataclass
class Literal(Expression):
    """Literal value (integer, float, string, char).
    
    Attributes:
        value: The literal value
        literal_type: Type of literal ('int', 'float', 'string', 'char')
    """
    value: Any
    literal_type: str


@dataclass
class Identifier(Expression):
    """Variable or function identifier.
    
    Attributes:
        name: Identifier name
    """
    name: str


@dataclass
class BinaryExpr(Expression):
    """Binary operation.
    
    Attributes:
        operator: Operator string ('+', '-', '*', '/', etc.)
        left: Left operand
        right: Right operand
    """
    operator: str
    left: Expression
    right: Expression


@dataclass
class UnaryExpr(Expression):
    """Unary operation.
    
    Attributes:
        operator: Operator string ('+', '-', '!', '~', '*', '&', '++', '--', 'sizeof')
        operand: Operand expression
        is_prefix: True for prefix operators, False for postfix
    """
    operator: str
    operand: Expression
    is_prefix: bool = True


@dataclass
class CallExpr(Expression):
    """Function call.
    
    Attributes:
        function: Expression evaluating to function (usually Identifier)
        arguments: List of argument expressions
    """
    function: Expression
    arguments: List[Expression]


@dataclass
class CastExpr(Expression):
    """Type cast.
    
    Attributes:
        target_type: Type to cast to
        operand: Expression being cast
    """
    target_type: Type
    operand: Expression


@dataclass
class ArraySubscript(Expression):
    """Array subscript (array[index]).
    
    Attributes:
        array: Array expression
        index: Index expression
    """
    array: Expression
    index: Expression


@dataclass
class MemberAccess(Expression):
    """Struct/union member access (obj.member or ptr->member).
    
    Attributes:
        object: Object expression
        member: Member name
        is_arrow: True for '->', False for '.'
    """
    object: Expression
    member: str
    is_arrow: bool


@dataclass
class ConditionalExpr(Expression):
    """Ternary conditional (condition ? true_expr : false_expr).
    
    Attributes:
        condition: Condition expression
        true_expr: Expression if condition is true
        false_expr: Expression if condition is false
    """
    condition: Expression
    true_expr: Expression
    false_expr: Expression


@dataclass
class AssignmentExpr(Expression):
    """Assignment expression.
    
    Attributes:
        operator: Assignment operator ('=', '+=', '-=', etc.)
        lhs: Left-hand side (lvalue)
        rhs: Right-hand side
    """
    operator: str
    lhs: Expression
    rhs: Expression


@dataclass
class SizeofExpr(Expression):
    """Sizeof expression.
    
    Attributes:
        operand: Expression or Type to get size of
        is_type: True if operand is a Type, False if Expression
    """
    operand: Any  # Expression or Type
    is_type: bool


@dataclass
class CommaExpr(Expression):
    """Comma expression (evaluates left to right, returns rightmost value).
    
    Attributes:
        expressions: List of expressions to evaluate in order
    """
    expressions: List[Expression]


@dataclass
class InitializerList(Expression):
    """Initializer list for arrays and structs.
    
    Attributes:
        initializers: List of initializer expressions
    """
    initializers: List[Expression]


# ============================================================================
# Statements
# ============================================================================

@dataclass
class Statement(ASTNode):
    """Base class for all statements."""
    pass


@dataclass
class CompoundStmt(Statement):
    """Compound statement (block).
    
    Attributes:
        statements: List of statements in the block
    """
    statements: List[Statement]


@dataclass
class ExpressionStmt(Statement):
    """Expression statement.
    
    Attributes:
        expression: Expression to evaluate (None for empty statement)
    """
    expression: Optional[Expression]


@dataclass
class IfStmt(Statement):
    """If statement.
    
    Attributes:
        condition: Condition expression
        then_stmt: Statement to execute if condition is true
        else_stmt: Statement to execute if condition is false (None if no else)
    """
    condition: Expression
    then_stmt: Statement
    else_stmt: Optional[Statement]


@dataclass
class WhileStmt(Statement):
    """While loop.
    
    Attributes:
        condition: Loop condition
        body: Loop body statement
    """
    condition: Expression
    body: Statement


@dataclass
class DoWhileStmt(Statement):
    """Do-while loop.
    
    Attributes:
        body: Loop body statement
        condition: Loop condition
    """
    body: Statement
    condition: Expression


@dataclass
class ForStmt(Statement):
    """For loop.
    
    Attributes:
        init: Initialization (expression or declaration, None if empty)
        condition: Loop condition (None if empty)
        increment: Increment expression (None if empty)
        body: Loop body statement
    """
    init: Optional[Any]  # Expression, VarDecl, or None
    condition: Optional[Expression]
    increment: Optional[Expression]
    body: Statement


@dataclass
class ReturnStmt(Statement):
    """Return statement.
    
    Attributes:
        value: Return value expression (None for void return)
    """
    value: Optional[Expression]


@dataclass
class BreakStmt(Statement):
    """Break statement."""
    pass


@dataclass
class ContinueStmt(Statement):
    """Continue statement."""
    pass


@dataclass
class SwitchStmt(Statement):
    """Switch statement.
    
    Attributes:
        condition: Switch condition expression
        body: Switch body (usually CompoundStmt with case labels)
    """
    condition: Expression
    body: Statement


@dataclass
class CaseStmt(Statement):
    """Case label in switch.
    
    Attributes:
        value: Case value expression (None for default case)
        statement: Statement following the case label
    """
    value: Optional[Expression]
    statement: Statement


@dataclass
class GotoStmt(Statement):
    """Goto statement.
    
    Attributes:
        label: Target label name
    """
    label: str


@dataclass
class LabelStmt(Statement):
    """Label statement.
    
    Attributes:
        label: Label name
        statement: Statement following the label
    """
    label: str
    statement: Statement


# ============================================================================
# Declarations
# ============================================================================

@dataclass
class Declaration(ASTNode):
    """Base class for declarations."""
    pass


@dataclass
class VarDecl(Declaration):
    """Variable declaration.
    
    Attributes:
        name: Variable name
        var_type: Variable type
        storage_class: Storage class specifier (None if not specified)
        qualifiers: Type qualifiers
        initializer: Initializer expression (None if not initialized)
    """
    name: str
    var_type: Type
    storage_class: Optional[StorageClass] = None
    qualifiers: List[TypeQualifier] = None
    initializer: Optional[Expression] = None
    
    def __post_init__(self):
        if self.qualifiers is None:
            self.qualifiers = []


@dataclass
class Parameter(ASTNode):
    """Function parameter.
    
    Attributes:
        name: Parameter name (None for abstract declarators)
        param_type: Parameter type
    """
    name: Optional[str]
    param_type: Type


@dataclass
class FunctionDecl(Declaration):
    """Function declaration or definition.
    
    Attributes:
        name: Function name
        return_type: Return type
        parameters: List of parameters
        body: Function body (None for declarations without definition)
        storage_class: Storage class specifier
        is_inline: Whether function is declared inline
        is_variadic: Whether function accepts variable arguments
    """
    name: str
    return_type: Type
    parameters: List[Parameter]
    body: Optional[CompoundStmt] = None
    storage_class: Optional[StorageClass] = None
    is_inline: bool = False
    is_variadic: bool = False


@dataclass
class StructDecl(Declaration):
    """Struct or union declaration.
    
    Attributes:
        name: Struct/union tag name (None for anonymous)
        is_union: True for union, False for struct
        members: List of member declarations (None for forward declaration)
    """
    name: Optional[str]
    is_union: bool
    members: Optional[List[VarDecl]]


@dataclass
class EnumDecl(Declaration):
    """Enum declaration.
    
    Attributes:
        name: Enum tag name (None for anonymous)
        enumerators: List of (name, value) tuples (None for forward declaration)
    """
    name: Optional[str]
    enumerators: Optional[List[tuple[str, Optional[Expression]]]]


@dataclass
class TypedefDecl(Declaration):
    """Typedef declaration.
    
    Attributes:
        name: New type name
        actual_type: The type being aliased
    """
    name: str
    actual_type: Type


# ============================================================================
# Translation Unit
# ============================================================================

@dataclass
class TranslationUnit(ASTNode):
    """Root node representing a complete C source file.
    
    Attributes:
        declarations: List of top-level declarations
    """
    declarations: List[Declaration]
