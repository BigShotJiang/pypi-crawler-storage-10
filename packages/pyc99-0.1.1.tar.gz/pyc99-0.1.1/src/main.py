"""Main entry point for the C99 compiler CLI."""

import click
import sys
import tempfile
import os
from pathlib import Path

from src.driver.compiler_driver import CompilerDriver, CompilerOptions, CompilationPhase
from src.driver.toolchain import Toolchain


@click.command()
@click.argument('source_files', nargs=-1, required=True, type=click.Path(exists=True))
@click.option('--target', '-t', type=click.Choice(['x86', 'arm']), default='x86',
              help='Target architecture (default: x86)')
@click.option('--output', '-o', type=click.Path(), default=None,
              help='Output file name (default: a.out for executable, source.s for assembly)')
@click.option('--optimization', '-O', type=click.IntRange(0, 1), default=0,
              help='Optimization level: 0 (none) or 1 (basic)')
@click.option('--stop-after', type=click.Choice(['preprocess', 'lex', 'parse', 'semantic', 'ir', 'optimize', 'codegen']),
              help='Stop compilation after specified phase')
@click.option('--include', '-I', 'include_paths', multiple=True, type=click.Path(exists=True),
              help='Add directory to include search path')
@click.option('--assembly-only', '-S', is_flag=True,
              help='Generate assembly file only (do not assemble or link)')
@click.option('--compile-only', '-c', is_flag=True,
              help='Generate object file only (do not link)')
@click.option('--verbose', '-v', is_flag=True,
              help='Enable verbose output')
@click.option('--debug', '-d', is_flag=True,
              help='Enable debug output')
def main(source_files, target, output, optimization, stop_after, include_paths,
         assembly_only, compile_only, verbose, debug):
    """C99 Compiler - Compile C source files to x86 or ARM assembly.
    
    Example usage:
        c99cc program.c                    # Compile to executable
        c99cc program.c -S                 # Generate assembly only
        c99cc program.c -c                 # Generate object file only
        c99cc program.c -t arm -o program  # Compile for ARM
        c99cc program.c -O1 -v             # Optimize with verbose output
        c99cc main.c utils.c -o program    # Compile multiple files
    """
    if verbose:
        click.echo(f"C99 Compiler v0.1.0")
        click.echo(f"Source files: {', '.join(source_files)}")
        click.echo(f"Target: {target}")
        click.echo(f"Optimization: -O{optimization}")
    
    # Determine stop phase
    stop_phase = None
    if stop_after:
        phase_map = {
            'preprocess': CompilationPhase.PREPROCESSING,
            'lex': CompilationPhase.LEXING,
            'parse': CompilationPhase.PARSING,
            'semantic': CompilationPhase.SEMANTIC_ANALYSIS,
            'ir': CompilationPhase.IR_GENERATION,
            'optimize': CompilationPhase.OPTIMIZATION,
            'codegen': CompilationPhase.CODE_GENERATION
        }
        stop_phase = phase_map.get(stop_after)
    
    # Handle single file vs multiple files
    if len(source_files) == 1 and not compile_only:
        # Single file compilation - can output assembly or executable directly
        source_file = source_files[0]
        source_path = Path(source_file)
        
        # Determine output file
        if output is None:
            if assembly_only:
                output = str(source_path.with_suffix('.s'))
            elif compile_only:
                output = str(source_path.with_suffix('.o'))
            else:
                output = 'a.out'
        
        # Create compiler options
        options = CompilerOptions(
            target=target,
            optimization_level=optimization,
            output_file=output,
            stop_after=stop_phase,
            include_paths=list(include_paths) if include_paths else [],
            verbose=verbose,
            debug=debug
        )
        
        # Create compiler driver
        driver = CompilerDriver(options)
        
        # Compile source file
        result = driver.compile(source_file)
        
        # Check for compilation errors
        if not result.success:
            if result.error_reporter:
                result.error_reporter.print_diagnostics()
            click.echo(f"\nCompilation failed.", err=True)
            return 1
        
        # Handle output based on flags
        if stop_after or assembly_only:
            # Write output to file
            if result.output:
                with open(output, 'w') as f:
                    f.write(result.output)
                if verbose:
                    click.echo(f"\nOutput written to: {output}")
            return 0
        
        # We have assembly code, now assemble and link if requested
        assembly_code = result.output
        
        # Create temporary assembly file
        fd, asm_file = tempfile.mkstemp(suffix='.s', prefix='c99_')
        try:
            with os.fdopen(fd, 'w') as f:
                f.write(assembly_code)
            
            # Create toolchain
            toolchain = Toolchain(target, verbose=verbose, error_reporter=driver.error_reporter)
            
            try:
                if compile_only:
                    # Assemble only
                    asm_result = toolchain.assemble(asm_file, output)
                    if not asm_result.success:
                        click.echo(f"\nAssembly failed.", err=True)
                        return 1
                    
                    if verbose:
                        click.echo(f"\nObject file created: {output}")
                else:
                    # Assemble and link
                    asm_result = toolchain.assemble(asm_file)
                    if not asm_result.success:
                        click.echo(f"\nAssembly failed.", err=True)
                        return 1
                    
                    object_file = asm_result.output_file
                    
                    # Link
                    link_result = toolchain.link([object_file], output, link_libc=True)
                    if not link_result.success:
                        click.echo(f"\nLinking failed.", err=True)
                        return 1
                    
                    if verbose:
                        click.echo(f"\nExecutable created: {output}")
            finally:
                # Clean up temporary files
                toolchain.cleanup()
        finally:
            # Clean up temporary assembly file
            try:
                os.remove(asm_file)
            except Exception:
                pass
        
        # Print warnings if any
        if result.error_reporter and result.error_reporter.has_warnings():
            result.error_reporter.print_diagnostics()
        
        if verbose:
            click.echo(f"\nCompilation successful!")
        
        return 0
    
    else:
        # Multiple file compilation or compile-only mode
        # Compile each file to object file separately
        
        # Create compiler options
        options = CompilerOptions(
            target=target,
            optimization_level=optimization,
            stop_after=stop_phase,
            include_paths=list(include_paths) if include_paths else [],
            verbose=verbose,
            debug=debug
        )
        
        # Create compiler driver
        driver = CompilerDriver(options)
        
        # Create toolchain
        toolchain = Toolchain(target, verbose=verbose, error_reporter=driver.error_reporter)
        
        object_files = []
        temp_files = []
        
        try:
            # Compile each source file to object file
            for source_file in source_files:
                source_path = Path(source_file)
                
                if verbose:
                    click.echo(f"\nCompiling {source_file}...")
                
                # Compile to assembly
                result = driver.compile(source_file)
                
                if not result.success:
                    if result.error_reporter:
                        result.error_reporter.print_diagnostics()
                    click.echo(f"\nCompilation of {source_file} failed.", err=True)
                    return 1
                
                # Handle stop-after phases
                if stop_after:
                    # For multiple files with stop-after, write each output separately
                    output_file = str(source_path.with_suffix('.out'))
                    with open(output_file, 'w') as f:
                        f.write(result.output)
                    if verbose:
                        click.echo(f"Output written to: {output_file}")
                    continue
                
                # Write assembly to temporary file
                fd, asm_file = tempfile.mkstemp(suffix='.s', prefix='c99_')
                temp_files.append(asm_file)
                
                with os.fdopen(fd, 'w') as f:
                    f.write(result.output)
                
                # Determine object file name
                if compile_only and len(source_files) == 1 and output:
                    obj_file = output
                else:
                    obj_file = str(source_path.with_suffix('.o'))
                
                # Assemble to object file
                asm_result = toolchain.assemble(asm_file, obj_file)
                if not asm_result.success:
                    click.echo(f"\nAssembly of {source_file} failed.", err=True)
                    return 1
                
                object_files.append(obj_file)
                
                if verbose:
                    click.echo(f"Object file created: {obj_file}")
            
            # If compile-only, we're done
            if compile_only or stop_after:
                if verbose:
                    click.echo(f"\nCompilation successful!")
                return 0
            
            # Link all object files together
            if output is None:
                output = 'a.out'
            
            if verbose:
                click.echo(f"\nLinking {len(object_files)} object files...")
            
            link_result = toolchain.link(object_files, output, link_libc=True)
            if not link_result.success:
                click.echo(f"\nLinking failed.", err=True)
                return 1
            
            if verbose:
                click.echo(f"Executable created: {output}")
                click.echo(f"\nCompilation successful!")
            
            return 0
            
        finally:
            # Clean up temporary files
            toolchain.cleanup()
            for temp_file in temp_files:
                try:
                    os.remove(temp_file)
                except Exception:
                    pass


if __name__ == '__main__':
    sys.exit(main())
