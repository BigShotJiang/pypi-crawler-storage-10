"""x86-64 code generator."""

from typing import Dict, List, Optional, Set
from dataclasses import dataclass

from src.codegen.base_codegen import CodeGenerator
from src.ir.ir_module import IRModule, IRFunction
from src.ir.ir_nodes import (
    IRInstruction, IROpcode, VirtualRegister, Constant, 
    IRValue, Label, GlobalVariable
)
from src.ir.basic_block import BasicBlock
from src.codegen.x86.x86_registers import X86Register
from src.codegen.x86.x86_instructions import (
    X86Instruction, X86InstructionType, X86Operand,
    RegisterOperand, ImmediateOperand, MemoryOperand, LabelOperand,
    mov, add, sub, imul, push, pop, call, ret, jmp, cmp, lea
)
from src.codegen.x86.register_allocator import allocate_registers
from src.parser.ast_nodes import Type, PrimitiveType


@dataclass
class StackSlot:
    """Represents a stack slot for a spilled variable.
    
    Attributes:
        offset: Offset from RBP (negative for local variables)
        size: Size in bytes
    """
    offset: int
    size: int


class X86CodeGenerator(CodeGenerator):
    """x86-64 code generator following System V AMD64 ABI.
    
    Calling convention:
    - Arguments: RDI, RSI, RDX, RCX, R8, R9, then stack
    - Return value: RAX
    - Callee-saved: RBX, RBP, R12-R15
    - Caller-saved: RAX, RCX, RDX, RSI, RDI, R8-R11
    - Stack alignment: 16 bytes
    
    Attributes:
        ir_module: IR module to generate code from
        register_allocation: Map from virtual registers to physical registers
        stack_slots: Map from virtual registers to stack slots (for spilled regs)
        current_function: Current function being generated
        stack_offset: Current stack offset for local variables
    """
    
    def __init__(self, ir_module: IRModule, syntax: str = 'intel'):
        """Initialize x86 code generator.
        
        Args:
            ir_module: IR module to generate code from
            syntax: Assembly syntax ('intel' or 'att')
        """
        super().__init__(ir_module)
        self.register_allocation: Dict[VirtualRegister, X86Register] = {}
        self.stack_slots: Dict[VirtualRegister, StackSlot] = {}
        self.current_function: Optional[IRFunction] = None
        self.stack_offset: int = 0
        self.label_counter: int = 0
        self.syntax: str = syntax
    
    def get_target_name(self) -> str:
        """Get the target architecture name.
        
        Returns:
            'x86'
        """
        return "x86"
    
    def _format_instruction(self, instruction: X86Instruction) -> str:
        """Format an instruction using the selected syntax.
        
        Args:
            instruction: Instruction to format
            
        Returns:
            Formatted instruction string
        """
        if self.syntax == 'intel':
            return instruction.format_intel()
        else:
            return instruction.format_att()
    
    def generate(self) -> str:
        """Generate assembly code for the entire module.
        
        Returns:
            Complete assembly code as a string
        """
        lines = []
        
        # Add syntax directive
        if self.syntax == 'intel':
            lines.append("\t.intel_syntax noprefix")
        
        # Generate data section for string literals
        string_literals = self.ir_module.get_string_literals()
        if string_literals:
            if self.syntax == 'intel':
                lines.append("\t.section __TEXT,__text")
            else:
                lines.append("\t.section .rodata")
            for str_lit in string_literals:
                lines.extend(self._generate_string_literal(str_lit))
            lines.append("")
        
        # Assembly header for code section
        if self.syntax == 'intel':
            lines.append("\t.section __TEXT,__text")
        else:
            lines.append("\t.text")
        
        # Generate code for each function
        for function in self.ir_module.get_functions():
            lines.append("")
            lines.extend(self.generate_function(function).split('\n'))
        
        return '\n'.join(lines)
    
    def generate_function(self, function: IRFunction) -> str:
        """Generate assembly code for a single function.
        
        Args:
            function: IR function to generate code for
            
        Returns:
            Assembly code for the function
        """
        self.current_function = function
        self.stack_offset = 0
        
        # Perform register allocation
        allocation, spill_slots, used_callee_saved = allocate_registers(function)
        self.register_allocation = allocation
        
        # Convert spill slots to stack slots
        self.stack_slots = {}
        for vreg, offset in spill_slots.items():
            self.stack_slots[vreg] = StackSlot(offset, 8)
        
        lines = []
        
        # Function label and global directive
        # On macOS, function names need _ prefix
        func_name = f"_{function.name}" if self.syntax == 'intel' else function.name
        lines.append(f"\t.globl {func_name}")
        if self.syntax != 'intel':
            lines.append(f"\t.type {func_name}, @function")
        lines.append(f"{func_name}:")
        
        # Generate prologue
        lines.extend(self._generate_prologue(function, used_callee_saved))
        
        # Generate code for each basic block
        cfg = function.get_cfg()
        for block in cfg.blocks:
            lines.extend(self._generate_basic_block(block))
        
        # Don't generate epilogue here - it's generated by return instructions
        # If there's no return instruction, the function is malformed
        
        return '\n'.join(lines)
    
    def _generate_prologue(self, function: IRFunction, 
                          used_callee_saved: Set[X86Register]) -> List[str]:
        """Generate function prologue.
        
        Sets up stack frame and saves callee-saved registers.
        
        Args:
            function: Function to generate prologue for
            used_callee_saved: Set of callee-saved registers used by function
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        
        # Save old base pointer and set up new frame
        lines.append(self._format_instruction(push(RegisterOperand(X86Register.RBP), "Save old base pointer")))
        lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RSP), 
                        RegisterOperand(X86Register.RBP), 
                        "Set up new frame")))
        
        # Calculate stack space needed for local variables and spills
        stack_space = self._calculate_stack_space(function)
        if stack_space > 0:
            lines.append(self._format_instruction(sub(ImmediateOperand(stack_space), 
                           RegisterOperand(X86Register.RSP),
                           f"Allocate {stack_space} bytes for locals")))
        
        # Save callee-saved registers that we'll use
        for reg in sorted(used_callee_saved, key=lambda r: r.value):
            lines.append(self._format_instruction(push(RegisterOperand(reg), f"Save {reg}")))
        
        # Move parameters from argument registers to their locations
        arg_regs = X86Register.get_argument_registers()
        for i, param in enumerate(function.parameters):
            if i < len(arg_regs):
                # Parameter is in register
                # Check if parameter has an allocation
                if param in self.register_allocation:
                    # Move to allocated register
                    target_reg = self.register_allocation[param]
                    if target_reg != arg_regs[i]:
                        lines.append(self._format_instruction(mov(RegisterOperand(arg_regs[i]),
                                       RegisterOperand(target_reg),
                                       f"Move parameter {param.name}")))
                elif param not in self.stack_slots:
                    # Allocate stack slot for parameter
                    self.stack_offset -= 8
                    self.stack_slots[param] = StackSlot(self.stack_offset, 8)
                    lines.append(self._format_instruction(mov(RegisterOperand(arg_regs[i]),
                                   MemoryOperand(base=X86Register.RBP, offset=self.stack_offset),
                                   f"Save parameter {param.name}")))
            else:
                # Parameter is on stack (passed by caller)
                if param not in self.stack_slots:
                    # Calculate offset: 16 (return addr + saved RBP) + 8 * (i - 6)
                    param_offset = 16 + 8 * (i - len(arg_regs))
                    self.stack_slots[param] = StackSlot(param_offset, 8)
        
        return lines
    
    def _generate_epilogue(self, used_callee_saved: Set[X86Register]) -> List[str]:
        """Generate function epilogue.
        
        Restores callee-saved registers and stack frame.
        
        Args:
            used_callee_saved: Set of callee-saved registers used by function
        
        Returns:
            List of assembly instruction strings
        """
        lines = []
        
        # Restore callee-saved registers
        for reg in reversed(sorted(used_callee_saved, key=lambda r: r.value)):
            lines.append(self._format_instruction(pop(RegisterOperand(reg), f"Restore {reg}")))
        
        # Restore stack frame
        lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RBP),
                        RegisterOperand(X86Register.RSP),
                        "Restore stack pointer")))
        lines.append(self._format_instruction(pop(RegisterOperand(X86Register.RBP), "Restore base pointer")))
        lines.append(self._format_instruction(ret("Return")))
        
        return lines
    
    def _generate_basic_block(self, block: BasicBlock) -> List[str]:
        """Generate code for a basic block.
        
        Args:
            block: Basic block to generate code for
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        
        # Block label
        lines.append(f"{block.label.name}:")
        
        # Generate code for each instruction
        for instruction in block.instructions:
            instr_lines = self._generate_instruction(instruction)
            lines.extend(instr_lines)
        
        return lines
    
    def _generate_instruction(self, instruction: IRInstruction) -> List[str]:
        """Generate code for a single IR instruction.
        
        Args:
            instruction: IR instruction to generate code for
            
        Returns:
            List of assembly instruction strings
        """
        opcode = instruction.opcode
        
        # Integer arithmetic operations
        if opcode == IROpcode.ADD:
            return self._generate_binary_op(instruction, X86InstructionType.ADD)
        elif opcode == IROpcode.SUB:
            return self._generate_binary_op(instruction, X86InstructionType.SUB)
        elif opcode == IROpcode.MUL:
            return self._generate_multiply(instruction)
        elif opcode == IROpcode.DIV:
            return self._generate_divide(instruction)
        elif opcode == IROpcode.MOD:
            return self._generate_modulo(instruction)
        elif opcode == IROpcode.NEG:
            return self._generate_negate(instruction)
        
        # Floating-point arithmetic operations
        elif opcode == IROpcode.FADD:
            return self._generate_float_binary_op(instruction, X86InstructionType.ADDSS, X86InstructionType.ADDSD)
        elif opcode == IROpcode.FSUB:
            return self._generate_float_binary_op(instruction, X86InstructionType.SUBSS, X86InstructionType.SUBSD)
        elif opcode == IROpcode.FMUL:
            return self._generate_float_binary_op(instruction, X86InstructionType.MULSS, X86InstructionType.MULSD)
        elif opcode == IROpcode.FDIV:
            return self._generate_float_binary_op(instruction, X86InstructionType.DIVSS, X86InstructionType.DIVSD)
        elif opcode == IROpcode.FNEG:
            return self._generate_float_negate(instruction)
        
        # Logical operations
        elif opcode == IROpcode.AND:
            return self._generate_binary_op(instruction, X86InstructionType.AND)
        elif opcode == IROpcode.OR:
            return self._generate_binary_op(instruction, X86InstructionType.OR)
        elif opcode == IROpcode.XOR:
            return self._generate_binary_op(instruction, X86InstructionType.XOR)
        elif opcode == IROpcode.NOT:
            return self._generate_not(instruction)
        
        # Shift operations
        elif opcode == IROpcode.SHL:
            return self._generate_shift(instruction, X86InstructionType.SHL)
        elif opcode == IROpcode.SHR:
            return self._generate_shift(instruction, X86InstructionType.SHR)
        
        # Integer comparison operations
        elif opcode in (IROpcode.EQ, IROpcode.NE, IROpcode.LT, 
                       IROpcode.LE, IROpcode.GT, IROpcode.GE):
            return self._generate_comparison(instruction)
        
        # Floating-point comparison operations
        elif opcode in (IROpcode.FEQ, IROpcode.FNE, IROpcode.FLT,
                       IROpcode.FLE, IROpcode.FGT, IROpcode.FGE):
            return self._generate_float_comparison(instruction)
        
        # Memory operations
        elif opcode == IROpcode.LOAD:
            return self._generate_load(instruction)
        elif opcode == IROpcode.STORE:
            return self._generate_store(instruction)
        elif opcode == IROpcode.ALLOCA:
            return self._generate_alloca(instruction)
        
        # Control flow operations
        elif opcode == IROpcode.BR:
            return self._generate_branch(instruction)
        elif opcode == IROpcode.COND_BR:
            return self._generate_conditional_branch(instruction)
        elif opcode == IROpcode.RET:
            return self._generate_return(instruction)
        elif opcode == IROpcode.CALL:
            return self._generate_call(instruction)
        
        # Type conversion
        elif opcode in (IROpcode.CAST, IROpcode.SEXT, IROpcode.ZEXT):
            return self._generate_cast(instruction)
        elif opcode in (IROpcode.FPTOSI, IROpcode.FPTOUI, IROpcode.SITOFP, 
                       IROpcode.UITOFP, IROpcode.FPTRUNC, IROpcode.FPEXT):
            return self._generate_float_conversion(instruction)
        
        else:
            return [f"\t# TODO: Implement {opcode.name}"]
    
    def _generate_binary_op(self, instruction: IRInstruction, 
                           x86_op: X86InstructionType) -> List[str]:
        """Generate code for binary operations (ADD, SUB, AND, OR, XOR).
        
        Args:
            instruction: IR instruction
            x86_op: x86 instruction type
            
        Returns:
            List of assembly instructions
        """
        lines = []
        left = instruction.operands[0]
        right = instruction.operands[1]
        result = instruction.result
        
        # Load left operand into result location
        left_op = self._get_operand(left)
        result_op = self._get_operand(result)
        
        if isinstance(result_op, RegisterOperand):
            # Move left to result register
            lines.append(self._format_instruction(mov(left_op, result_op, f"{instruction.opcode.name} operation")))
            # Apply operation with right operand
            right_op = self._get_operand(right)
            lines.append(self._format_instruction(X86Instruction(x86_op, [right_op, result_op])))
        else:
            # Result is in memory, use temporary register
            lines.append(self._format_instruction(mov(left_op, RegisterOperand(X86Register.RAX))))
            right_op = self._get_operand(right)
            lines.append(self._format_instruction(X86Instruction(x86_op, [right_op, RegisterOperand(X86Register.RAX)])))
            lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), result_op)))
        
        return lines

    def _generate_multiply(self, instruction: IRInstruction) -> List[str]:
        """Generate code for multiplication.
        
        Args:
            instruction: MUL instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        left = instruction.operands[0]
        right = instruction.operands[1]
        result = instruction.result
        
        # Use IMUL for signed multiplication
        left_op = self._get_operand(left)
        right_op = self._get_operand(right)
        result_op = self._get_operand(result)
        
        # IMUL dest, src (dest = dest * src)
        lines.append(self._format_instruction(mov(left_op, RegisterOperand(X86Register.RAX))))
        lines.append(self._format_instruction(imul(right_op, RegisterOperand(X86Register.RAX))))
        lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), result_op)))
        
        return lines
    
    def _generate_divide(self, instruction: IRInstruction) -> List[str]:
        """Generate code for division.
        
        Args:
            instruction: DIV instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        left = instruction.operands[0]
        right = instruction.operands[1]
        result = instruction.result
        
        # IDIV uses RDX:RAX as dividend, result in RAX, remainder in RDX
        left_op = self._get_operand(left)
        right_op = self._get_operand(right)
        result_op = self._get_operand(result)
        
        lines.append(self._format_instruction(mov(left_op, RegisterOperand(X86Register.RAX))))
        lines.append(self._format_instruction(X86Instruction(X86InstructionType.CQO, [], "Sign extend RAX to RDX:RAX")))
        
        # IDIV requires operand in register or memory, not immediate
        if isinstance(right_op, ImmediateOperand):
            lines.append(self._format_instruction(mov(right_op, RegisterOperand(X86Register.RCX))))
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.IDIV, [RegisterOperand(X86Register.RCX)])))
        else:
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.IDIV, [right_op])))
        
        lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), result_op)))
        
        return lines
    
    def _generate_modulo(self, instruction: IRInstruction) -> List[str]:
        """Generate code for modulo operation.
        
        Args:
            instruction: MOD instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        left = instruction.operands[0]
        right = instruction.operands[1]
        result = instruction.result
        
        # IDIV puts remainder in RDX
        left_op = self._get_operand(left)
        right_op = self._get_operand(right)
        result_op = self._get_operand(result)
        
        lines.append(self._format_instruction(mov(left_op, RegisterOperand(X86Register.RAX))))
        lines.append(self._format_instruction(X86Instruction(X86InstructionType.CQO, [], "Sign extend RAX to RDX:RAX")))
        
        if isinstance(right_op, ImmediateOperand):
            lines.append(self._format_instruction(mov(right_op, RegisterOperand(X86Register.RCX))))
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.IDIV, [RegisterOperand(X86Register.RCX)])))
        else:
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.IDIV, [right_op])))
        
        lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RDX), result_op, "Move remainder to result")))
        
        return lines
    
    def _generate_negate(self, instruction: IRInstruction) -> List[str]:
        """Generate code for negation.
        
        Args:
            instruction: NEG instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        operand = instruction.operands[0]
        result = instruction.result
        
        operand_op = self._get_operand(operand)
        result_op = self._get_operand(result)
        
        lines.append(self._format_instruction(mov(operand_op, result_op)))
        lines.append(self._format_instruction(X86Instruction(X86InstructionType.NEG, [result_op])))
        
        return lines
    
    def _generate_not(self, instruction: IRInstruction) -> List[str]:
        """Generate code for logical NOT.
        
        Args:
            instruction: NOT instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        operand = instruction.operands[0]
        result = instruction.result
        
        operand_op = self._get_operand(operand)
        result_op = self._get_operand(result)
        
        lines.append(self._format_instruction(mov(operand_op, result_op)))
        lines.append(self._format_instruction(X86Instruction(X86InstructionType.NOT, [result_op])))
        
        return lines
    
    def _generate_shift(self, instruction: IRInstruction, 
                       x86_op: X86InstructionType) -> List[str]:
        """Generate code for shift operations.
        
        Args:
            instruction: Shift instruction
            x86_op: x86 shift instruction type
            
        Returns:
            List of assembly instructions
        """
        lines = []
        value = instruction.operands[0]
        shift_amount = instruction.operands[1]
        result = instruction.result
        
        value_op = self._get_operand(value)
        result_op = self._get_operand(result)
        
        lines.append(self._format_instruction(mov(value_op, result_op)))
        
        # Shift amount must be in CL register or immediate
        if isinstance(shift_amount, Constant):
            lines.append(self._format_instruction(X86Instruction(x86_op, [ImmediateOperand(shift_amount.value), result_op])))
        else:
            shift_op = self._get_operand(shift_amount)
            lines.append(self._format_instruction(mov(shift_op, RegisterOperand(X86Register.RCX))))
            lines.append(self._format_instruction(X86Instruction(x86_op, [RegisterOperand(X86Register.CL), result_op])))
        
        return lines
    
    def _generate_comparison(self, instruction: IRInstruction) -> List[str]:
        """Generate code for comparison operations.
        
        Args:
            instruction: Comparison instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        left = instruction.operands[0]
        right = instruction.operands[1]
        result = instruction.result
        
        left_op = self._get_operand(left)
        right_op = self._get_operand(right)
        result_op = self._get_operand(result)
        
        # Compare left and right
        lines.append(self._format_instruction(mov(left_op, RegisterOperand(X86Register.RAX))))
        lines.append(self._format_instruction(cmp(right_op, RegisterOperand(X86Register.RAX))))
        
        # Set result based on comparison
        opcode_to_setcc = {
            IROpcode.EQ: X86InstructionType.SETE,
            IROpcode.NE: X86InstructionType.SETNE,
            IROpcode.LT: X86InstructionType.SETL,
            IROpcode.LE: X86InstructionType.SETLE,
            IROpcode.GT: X86InstructionType.SETG,
            IROpcode.GE: X86InstructionType.SETGE,
        }
        
        setcc = opcode_to_setcc.get(instruction.opcode)
        if setcc:
            # SETCC sets a byte register
            lines.append(self._format_instruction(X86Instruction(setcc, [RegisterOperand(X86Register.AL)])))
            # Zero-extend to full register
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.MOVZX, 
                                       [RegisterOperand(X86Register.AL), 
                                        RegisterOperand(X86Register.RAX)])))
            lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), result_op)))
        
        return lines
    
    def _generate_load(self, instruction: IRInstruction) -> List[str]:
        """Generate code for load from memory.
        
        Args:
            instruction: LOAD instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        address = instruction.operands[0]
        result = instruction.result
        
        # Get the memory address
        if isinstance(address, VirtualRegister):
            # Address is in a register
            addr_op = self._get_operand(address)
            if isinstance(addr_op, RegisterOperand):
                mem_op = MemoryOperand(base=addr_op.register)
            else:
                # Address is on stack, load it first
                lines.append(self._format_instruction(mov(addr_op, RegisterOperand(X86Register.RAX))))
                mem_op = MemoryOperand(base=X86Register.RAX)
        else:
            # Direct memory reference
            mem_op = self._get_operand(address)
        
        result_op = self._get_operand(result)
        lines.append(self._format_instruction(mov(mem_op, result_op, "Load from memory")))
        
        return lines
    
    def _generate_store(self, instruction: IRInstruction) -> List[str]:
        """Generate code for store to memory.
        
        Args:
            instruction: STORE instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        value = instruction.operands[0]
        address = instruction.operands[1]
        
        value_op = self._get_operand(value)
        
        # Get the memory address
        if isinstance(address, VirtualRegister):
            addr_op = self._get_operand(address)
            if isinstance(addr_op, RegisterOperand):
                mem_op = MemoryOperand(base=addr_op.register)
            else:
                lines.append(self._format_instruction(mov(addr_op, RegisterOperand(X86Register.RAX))))
                mem_op = MemoryOperand(base=X86Register.RAX)
        else:
            mem_op = self._get_operand(address)
        
        # Store value to memory
        if isinstance(value_op, ImmediateOperand) or isinstance(value_op, RegisterOperand):
            lines.append(self._format_instruction(mov(value_op, mem_op, "Store to memory")))
        else:
            lines.append(self._format_instruction(mov(value_op, RegisterOperand(X86Register.RAX))))
            lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), mem_op, "Store to memory")))
        
        return lines
    
    def _generate_alloca(self, instruction: IRInstruction) -> List[str]:
        """Generate code for stack allocation.
        
        Args:
            instruction: ALLOCA instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        result = instruction.result
        
        # Allocate space on stack
        size = 8  # Default to 8 bytes (pointer size)
        self.stack_offset -= size
        
        # Store the address in result
        result_op = self._get_operand(result)
        lines.append(self._format_instruction(lea(MemoryOperand(base=X86Register.RBP, offset=self.stack_offset),
                        result_op,
                        "Allocate stack space")))
        
        return lines
    
    def _generate_branch(self, instruction: IRInstruction) -> List[str]:
        """Generate code for unconditional branch.
        
        Args:
            instruction: BR instruction
            
        Returns:
            List of assembly instructions
        """
        target = instruction.operands[0]
        if isinstance(target, Label):
            return [self._format_instruction(jmp(target.name))]
        return []
    
    def _generate_conditional_branch(self, instruction: IRInstruction) -> List[str]:
        """Generate code for conditional branch.
        
        Args:
            instruction: COND_BR instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        condition = instruction.operands[0]
        true_target = instruction.operands[1]
        false_target = instruction.operands[2]
        
        # Test condition
        cond_op = self._get_operand(condition)
        lines.append(self._format_instruction(cmp(ImmediateOperand(0), cond_op, "Test condition")))
        
        # Jump to true target if not zero
        if isinstance(true_target, Label):
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.JNE, 
                                       [LabelOperand(true_target.name)],
                                       "Jump if true")))
        
        # Fall through or jump to false target
        if isinstance(false_target, Label):
            lines.append(self._format_instruction(jmp(false_target.name, "Jump to false branch")))
        
        return lines
    
    def _generate_return(self, instruction: IRInstruction) -> List[str]:
        """Generate code for return statement.
        
        Args:
            instruction: RET instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        
        # Move return value to RAX if present
        if instruction.operands:
            value = instruction.operands[0]
            value_op = self._get_operand(value)
            lines.append(self._format_instruction(mov(value_op, RegisterOperand(X86Register.RAX), "Set return value")))
        
        # Get used callee-saved registers from register allocation
        # We need to reconstruct this from the allocation
        used_callee_saved = set()
        for vreg, phys_reg in self.register_allocation.items():
            if phys_reg.is_callee_saved():
                used_callee_saved.add(phys_reg)
        
        # Generate epilogue and return
        lines.extend(self._generate_epilogue(used_callee_saved))
        
        return lines
    
    def _generate_call(self, instruction: IRInstruction) -> List[str]:
        """Generate code for function call.
        
        Handles both regular and variadic function calls according to System V AMD64 ABI:
        - First 6 integer/pointer arguments in registers (RDI, RSI, RDX, RCX, R8, R9)
        - Additional arguments on stack (right to left)
        - For variadic functions, all variadic arguments are passed on stack
        - AL register contains number of vector registers used (for floating point)
        
        Args:
            instruction: CALL instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        function = instruction.operands[0]
        arguments = instruction.operands[1:] if len(instruction.operands) > 1 else []
        result = instruction.result
        
        # Save caller-saved registers if needed
        # (Simplified - should only save registers that are live)
        
        # Pass arguments according to System V ABI
        arg_regs = X86Register.get_argument_registers()
        
        # Arguments in registers
        for i, arg in enumerate(arguments[:len(arg_regs)]):
            arg_op = self._get_operand(arg)
            lines.append(self._format_instruction(mov(arg_op, RegisterOperand(arg_regs[i]), 
                           f"Pass argument {i}")))
        
        # Arguments on stack (right to left)
        for i in range(len(arguments) - 1, len(arg_regs) - 1, -1):
            if i >= 0:
                arg_op = self._get_operand(arguments[i])
                lines.append(self._format_instruction(push(arg_op, f"Push argument {i}")))
        
        # Call the function
        if isinstance(function, GlobalVariable):
            # Direct call to named function
            lines.append(self._format_instruction(call(function.name)))
        elif isinstance(function, Constant):
            # Direct call to named function (from constant)
            lines.append(self._format_instruction(call(str(function.value))))
        else:
            # Indirect call through function pointer (register or memory)
            func_op = self._get_operand(function)
            # For indirect calls, we need to use "call *operand" syntax in AT&T
            # The operand should be a register containing the function address
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.CALL, [func_op], 
                                       "Indirect call")))
        
        # Clean up stack arguments if any
        stack_args = max(0, len(arguments) - len(arg_regs))
        if stack_args > 0:
            lines.append(self._format_instruction(add(ImmediateOperand(stack_args * 8), 
                           RegisterOperand(X86Register.RSP),
                           "Clean up stack arguments")))
        
        # Move return value to result if present
        if result:
            result_op = self._get_operand(result)
            lines.append(self._format_instruction(mov(RegisterOperand(X86Register.RAX), result_op, 
                           "Get return value")))
        
        return lines
    
    def _generate_cast(self, instruction: IRInstruction) -> List[str]:
        """Generate code for type cast.
        
        Args:
            instruction: CAST instruction
            
        Returns:
            List of assembly instructions
        """
        lines = []
        operand = instruction.operands[0]
        result = instruction.result
        
        operand_op = self._get_operand(operand)
        result_op = self._get_operand(result)
        
        # Simple move for now (proper casting would check sizes)
        if instruction.opcode == IROpcode.SEXT:
            # Sign extend
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.MOVSX, 
                                       [operand_op, result_op],
                                       "Sign extend")))
        elif instruction.opcode == IROpcode.ZEXT:
            # Zero extend
            lines.append(self._format_instruction(X86Instruction(X86InstructionType.MOVZX, 
                                       [operand_op, result_op],
                                       "Zero extend")))
        else:
            # Regular cast
            lines.append(self._format_instruction(mov(operand_op, result_op, "Cast")))
        
        return lines
    
    def _get_operand(self, value: IRValue) -> X86Operand:
        """Convert an IR value to an x86 operand.
        
        Args:
            value: IR value
            
        Returns:
            x86 operand
        """
        if isinstance(value, Constant):
            # Check if this is a string literal label (starts with .str)
            if isinstance(value.value, str) and value.value.startswith('.str'):
                # Return label operand for string literal
                return LabelOperand(value.value)
            return ImmediateOperand(value.value)
        elif isinstance(value, GlobalVariable):
            return MemoryOperand(offset=value.name)
        elif isinstance(value, VirtualRegister):
            # Check if register is allocated
            if value in self.register_allocation:
                return RegisterOperand(self.register_allocation[value])
            # Check if register is spilled to stack
            elif value in self.stack_slots:
                slot = self.stack_slots[value]
                return MemoryOperand(base=X86Register.RBP, offset=slot.offset)
            else:
                # Allocate stack slot for this register
                self.stack_offset -= 8
                self.stack_slots[value] = StackSlot(self.stack_offset, 8)
                return MemoryOperand(base=X86Register.RBP, offset=self.stack_offset)
        elif isinstance(value, Label):
            return LabelOperand(value.name)
        else:
            # Default to immediate 0
            return ImmediateOperand(0)
    
    def _calculate_stack_space(self, function: IRFunction) -> int:
        """Calculate stack space needed for local variables and spills.
        
        Args:
            function: Function to calculate stack space for
            
        Returns:
            Stack space in bytes
        """
        # Calculate space needed for spilled registers and locals
        space = 0
        
        # Space for spilled registers
        if self.stack_slots:
            # Find the minimum (most negative) offset
            min_offset = min(slot.offset for slot in self.stack_slots.values())
            space = abs(min_offset)
        
        # Space for local variables
        num_locals = len(function.local_variables)
        space += num_locals * 8
        
        # Align to 16 bytes (required by System V ABI)
        if space % 16 != 0:
            space = ((space // 16) + 1) * 16
        
        return space

    def _generate_string_literal(self, str_lit) -> List[str]:
        """Generate assembly for a string literal in the data section.
        
        Args:
            str_lit: StringLiteral object
            
        Returns:
            List of assembly lines
        """
        lines = []
        
        # Label for the string
        lines.append(f"{str_lit.label}:")
        
        # Emit string data
        if str_lit.is_wide:
            # Wide string - emit as .long (4 bytes per character)
            lines.append(f"\t.long {', '.join(str(ord(c)) for c in str_lit.value)}, 0")
        else:
            # Regular string - emit as .asciz (null-terminated)
            # Escape special characters for assembly
            escaped = str_lit.value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '\\t')
            lines.append(f'\t.asciz "{escaped}"')
        
        return lines

    def _generate_float_binary_op(self, instruction: IRInstruction,
                                   float_op: X86InstructionType,
                                   double_op: X86InstructionType) -> List[str]:
        """Generate code for floating-point binary operations.
        
        Args:
            instruction: IR instruction
            float_op: x86 instruction for float (single-precision)
            double_op: x86 instruction for double (double-precision)
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        result = instruction.result
        operands = instruction.operands
        
        if len(operands) != 2:
            return [f"\t# Error: Expected 2 operands for float binary op"]
        
        left, right = operands
        
        # Determine if this is float or double based on result type
        from src.semantic.type_utils import is_floating_type
        result_type = result.value_type if result else None
        is_float = False
        if result_type and isinstance(result_type, PrimitiveType):
            is_float = result_type.name == 'float'
        
        # Choose appropriate instruction
        x86_op = float_op if is_float else double_op
        
        # Get operand locations
        left_loc = self._get_operand_location(left)
        right_loc = self._get_operand_location(right)
        result_loc = self._get_operand_location(result)
        
        # SSE instructions work with XMM registers
        # For now, use a simple approach: load operands, perform operation, store result
        lines.append(f"\t# Float binary op: {x86_op.value}")
        
        # Move left operand to result location (if different)
        if left_loc != result_loc:
            mov_op = X86InstructionType.MOVSS if is_float else X86InstructionType.MOVSD
            lines.append(f"\t{mov_op.value} {left_loc}, {result_loc}")
        
        # Perform operation with right operand
        lines.append(f"\t{x86_op.value} {right_loc}, {result_loc}")
        
        return lines
    
    def _generate_float_negate(self, instruction: IRInstruction) -> List[str]:
        """Generate code for floating-point negation.
        
        Args:
            instruction: IR instruction
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        result = instruction.result
        operand = instruction.operands[0] if instruction.operands else None
        
        if not operand:
            return [f"\t# Error: No operand for float negate"]
        
        # Determine if this is float or double
        result_type = result.value_type if result else None
        is_float = False
        if result_type and isinstance(result_type, PrimitiveType):
            is_float = result_type.name == 'float'
        
        operand_loc = self._get_operand_location(operand)
        result_loc = self._get_operand_location(result)
        
        lines.append(f"\t# Float negate")
        
        # XOR with sign bit to negate
        # For float: XOR with 0x80000000
        # For double: XOR with 0x8000000000000000
        # This is a simplified approach - proper implementation would use a constant in memory
        
        # Move operand to result
        mov_op = X86InstructionType.MOVSS if is_float else X86InstructionType.MOVSD
        lines.append(f"\t{mov_op.value} {operand_loc}, {result_loc}")
        
        # TODO: Implement proper negation using XOR with sign bit mask
        lines.append(f"\t# TODO: Implement float negation properly")
        
        return lines
    
    def _generate_float_comparison(self, instruction: IRInstruction) -> List[str]:
        """Generate code for floating-point comparison operations.
        
        Args:
            instruction: IR instruction
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        result = instruction.result
        operands = instruction.operands
        
        if len(operands) != 2:
            return [f"\t# Error: Expected 2 operands for float comparison"]
        
        left, right = operands
        
        # Determine if this is float or double based on operand types
        left_type = left.value_type if hasattr(left, 'value_type') else None
        is_float = False
        if left_type and isinstance(left_type, PrimitiveType):
            is_float = left_type.name == 'float'
        
        # Get operand locations
        left_loc = self._get_operand_location(left)
        right_loc = self._get_operand_location(right)
        result_loc = self._get_operand_location(result)
        
        # Use UCOMISS/UCOMISD for comparison
        cmp_op = X86InstructionType.UCOMISS if is_float else X86InstructionType.UCOMISD
        lines.append(f"\t{cmp_op.value} {right_loc}, {left_loc}")
        
        # Set result based on comparison flags
        opcode = instruction.opcode
        opcode_to_setcc = {
            IROpcode.FEQ: X86InstructionType.SETE,
            IROpcode.FNE: X86InstructionType.SETNE,
            IROpcode.FLT: X86InstructionType.SETL,
            IROpcode.FLE: X86InstructionType.SETLE,
            IROpcode.FGT: X86InstructionType.SETG,
            IROpcode.FGE: X86InstructionType.SETGE,
        }
        
        setcc = opcode_to_setcc.get(opcode, X86InstructionType.SETE)
        
        # Set byte based on condition, then extend to full register
        # For simplicity, use result_loc directly
        lines.append(f"\t{setcc.value} {result_loc}")
        lines.append(f"\tmovzx {result_loc}, {result_loc}")  # Zero-extend byte to full register
        
        return lines
    
    def _generate_float_conversion(self, instruction: IRInstruction) -> List[str]:
        """Generate code for floating-point conversion operations.
        
        Args:
            instruction: IR instruction
            
        Returns:
            List of assembly instruction strings
        """
        lines = []
        result = instruction.result
        operand = instruction.operands[0] if instruction.operands else None
        opcode = instruction.opcode
        
        if not operand:
            return [f"\t# Error: No operand for float conversion"]
        
        operand_loc = self._get_operand_location(operand)
        result_loc = self._get_operand_location(result)
        
        # Map IR opcode to x86 instruction
        if opcode == IROpcode.FPTOSI:
            # Float to signed int
            # Determine if source is float or double
            operand_type = operand.value_type if hasattr(operand, 'value_type') else None
            is_float = False
            if operand_type and isinstance(operand_type, PrimitiveType):
                is_float = operand_type.name == 'float'
            
            cvt_op = X86InstructionType.CVTSS2SI if is_float else X86InstructionType.CVTSD2SI
            lines.append(f"\t{cvt_op.value} {operand_loc}, {result_loc}")
        
        elif opcode == IROpcode.FPTOUI:
            # Float to unsigned int (similar to signed for now)
            operand_type = operand.value_type if hasattr(operand, 'value_type') else None
            is_float = False
            if operand_type and isinstance(operand_type, PrimitiveType):
                is_float = operand_type.name == 'float'
            
            cvt_op = X86InstructionType.CVTSS2SI if is_float else X86InstructionType.CVTSD2SI
            lines.append(f"\t{cvt_op.value} {operand_loc}, {result_loc}")
        
        elif opcode == IROpcode.SITOFP:
            # Signed int to float
            result_type = result.value_type if result else None
            is_float = False
            if result_type and isinstance(result_type, PrimitiveType):
                is_float = result_type.name == 'float'
            
            cvt_op = X86InstructionType.CVTSI2SS if is_float else X86InstructionType.CVTSI2SD
            lines.append(f"\t{cvt_op.value} {operand_loc}, {result_loc}")
        
        elif opcode == IROpcode.UITOFP:
            # Unsigned int to float (similar to signed for now)
            result_type = result.value_type if result else None
            is_float = False
            if result_type and isinstance(result_type, PrimitiveType):
                is_float = result_type.name == 'float'
            
            cvt_op = X86InstructionType.CVTSI2SS if is_float else X86InstructionType.CVTSI2SD
            lines.append(f"\t{cvt_op.value} {operand_loc}, {result_loc}")
        
        elif opcode == IROpcode.FPTRUNC:
            # Double to float
            lines.append(f"\t{X86InstructionType.CVTSD2SS.value} {operand_loc}, {result_loc}")
        
        elif opcode == IROpcode.FPEXT:
            # Float to double
            lines.append(f"\t{X86InstructionType.CVTSS2SD.value} {operand_loc}, {result_loc}")
        
        else:
            lines.append(f"\t# TODO: Implement float conversion {opcode.name}")
        
        return lines
