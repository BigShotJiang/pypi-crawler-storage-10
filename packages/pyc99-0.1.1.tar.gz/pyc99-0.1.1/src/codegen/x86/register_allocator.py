"""Register allocation for x86-64 using linear scan algorithm."""

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Tuple

from src.ir.ir_module import IRFunction
from src.ir.ir_nodes import VirtualRegister, IRInstruction, IROpcode
from src.ir.basic_block import BasicBlock
from src.codegen.x86.x86_registers import X86Register


@dataclass
class LiveInterval:
    """Represents the live range of a virtual register.
    
    Attributes:
        virtual_reg: Virtual register
        start: Start position (instruction index)
        end: End position (instruction index)
        physical_reg: Allocated physical register (None if spilled)
        spill_slot: Stack slot offset if spilled
    """
    virtual_reg: VirtualRegister
    start: int
    end: int
    physical_reg: Optional[X86Register] = None
    spill_slot: Optional[int] = None
    
    def overlaps(self, other: 'LiveInterval') -> bool:
        """Check if this interval overlaps with another.
        
        Args:
            other: Other live interval
            
        Returns:
            True if intervals overlap
        """
        return not (self.end < other.start or other.end < self.start)
    
    def __lt__(self, other: 'LiveInterval') -> bool:
        """Compare intervals by start position.
        
        Args:
            other: Other interval
            
        Returns:
            True if this interval starts before the other
        """
        return self.start < other.start


class RegisterAllocator:
    """Linear scan register allocator for x86-64.
    
    Implements a simplified linear scan algorithm:
    1. Compute live intervals for all virtual registers
    2. Sort intervals by start position
    3. Allocate registers in order, spilling when necessary
    4. Preserve callee-saved registers
    
    Attributes:
        function: Function to allocate registers for
        intervals: Live intervals for all virtual registers
        active: Currently active intervals
        allocation: Map from virtual registers to physical registers
        spill_slots: Map from virtual registers to stack offsets
        next_spill_offset: Next available stack offset for spilling
        available_registers: Set of available physical registers
    """
    
    def __init__(self, function: IRFunction):
        """Initialize register allocator.
        
        Args:
            function: Function to allocate registers for
        """
        self.function = function
        self.intervals: List[LiveInterval] = []
        self.active: List[LiveInterval] = []
        self.allocation: Dict[VirtualRegister, X86Register] = {}
        self.spill_slots: Dict[VirtualRegister, int] = {}
        self.next_spill_offset: int = 0
        self.available_registers: Set[X86Register] = set(X86Register.get_allocatable_registers())
        self.used_callee_saved: Set[X86Register] = set()
    
    def allocate(self) -> Tuple[Dict[VirtualRegister, X86Register], 
                                Dict[VirtualRegister, int],
                                Set[X86Register]]:
        """Perform register allocation.
        
        Returns:
            Tuple of (allocation map, spill slots map, used callee-saved registers)
        """
        # Compute live intervals
        self._compute_live_intervals()
        
        # Sort intervals by start position
        self.intervals.sort()
        
        # Allocate registers using linear scan
        self._linear_scan()
        
        return self.allocation, self.spill_slots, self.used_callee_saved
    
    def _compute_live_intervals(self) -> None:
        """Compute live intervals for all virtual registers.
        
        A virtual register is live from its first definition to its last use.
        """
        # Map virtual registers to their live intervals
        reg_intervals: Dict[VirtualRegister, LiveInterval] = {}
        
        # Number instructions sequentially using list index
        position = 0
        
        cfg = self.function.get_cfg()
        for block in cfg.blocks:
            for instruction in block.instructions:
                # Process result (definition)
                if instruction.result and isinstance(instruction.result, VirtualRegister):
                    reg = instruction.result
                    if reg not in reg_intervals:
                        reg_intervals[reg] = LiveInterval(reg, position, position)
                    else:
                        # Update start if this is an earlier definition
                        reg_intervals[reg].start = min(reg_intervals[reg].start, position)
                        reg_intervals[reg].end = max(reg_intervals[reg].end, position)
                
                # Process operands (uses)
                for operand in instruction.operands:
                    if isinstance(operand, VirtualRegister):
                        reg = operand
                        if reg not in reg_intervals:
                            # First use without definition (parameter?)
                            reg_intervals[reg] = LiveInterval(reg, 0, position)
                        else:
                            # Extend live range to this use
                            reg_intervals[reg].end = max(reg_intervals[reg].end, position)
                
                position += 1
        
        # Store intervals
        self.intervals = list(reg_intervals.values())
    
    def _linear_scan(self) -> None:
        """Perform linear scan register allocation.
        
        For each interval in sorted order:
        1. Expire old intervals that are no longer active
        2. Try to allocate a free register
        3. If no free register, spill a register
        """
        for interval in self.intervals:
            # Expire old intervals
            self._expire_old_intervals(interval)
            
            # Try to allocate a register
            if self.available_registers:
                # Allocate a free register
                reg = self._choose_register(interval)
                self.allocation[interval.virtual_reg] = reg
                interval.physical_reg = reg
                self.active.append(interval)
                self.available_registers.remove(reg)
                
                # Track callee-saved register usage
                if reg.is_callee_saved():
                    self.used_callee_saved.add(reg)
            else:
                # No free registers, need to spill
                self._spill(interval)
    
    def _expire_old_intervals(self, interval: LiveInterval) -> None:
        """Expire intervals that are no longer active.
        
        Args:
            interval: Current interval being processed
        """
        # Remove intervals that end before current interval starts
        expired = []
        for active_interval in self.active:
            if active_interval.end < interval.start:
                expired.append(active_interval)
        
        for active_interval in expired:
            self.active.remove(active_interval)
            if active_interval.physical_reg:
                self.available_registers.add(active_interval.physical_reg)
    
    def _choose_register(self, interval: LiveInterval) -> X86Register:
        """Choose a physical register for allocation.
        
        Prefers caller-saved registers to avoid saving/restoring.
        
        Args:
            interval: Interval to allocate register for
            
        Returns:
            Chosen physical register
        """
        # Prefer caller-saved registers
        caller_saved = [reg for reg in self.available_registers if reg.is_caller_saved()]
        if caller_saved:
            return caller_saved[0]
        
        # Use callee-saved registers if no caller-saved available
        callee_saved = [reg for reg in self.available_registers if reg.is_callee_saved()]
        if callee_saved:
            return callee_saved[0]
        
        # Return any available register
        return next(iter(self.available_registers))
    
    def _spill(self, interval: LiveInterval) -> None:
        """Spill a register to the stack.
        
        Chooses between spilling the current interval or an active interval.
        Spills the interval with the furthest end point.
        
        Args:
            interval: Interval to potentially spill
        """
        # Find the active interval with the furthest end point
        spill_candidate = max(self.active, key=lambda i: i.end, default=None)
        
        if spill_candidate and spill_candidate.end > interval.end:
            # Spill the active interval instead
            self.allocation[interval.virtual_reg] = spill_candidate.physical_reg
            interval.physical_reg = spill_candidate.physical_reg
            
            # Spill the candidate
            self._allocate_spill_slot(spill_candidate)
            del self.allocation[spill_candidate.virtual_reg]
            spill_candidate.physical_reg = None
            
            # Update active list
            self.active.remove(spill_candidate)
            self.active.append(interval)
        else:
            # Spill the current interval
            self._allocate_spill_slot(interval)
    
    def _allocate_spill_slot(self, interval: LiveInterval) -> None:
        """Allocate a stack slot for a spilled register.
        
        Args:
            interval: Interval to allocate spill slot for
        """
        # Allocate 8 bytes (64-bit register)
        self.next_spill_offset -= 8
        self.spill_slots[interval.virtual_reg] = self.next_spill_offset
        interval.spill_slot = self.next_spill_offset
    
    def get_allocation(self, virtual_reg: VirtualRegister) -> Optional[X86Register]:
        """Get the physical register allocated to a virtual register.
        
        Args:
            virtual_reg: Virtual register
            
        Returns:
            Physical register, or None if spilled
        """
        return self.allocation.get(virtual_reg)
    
    def get_spill_slot(self, virtual_reg: VirtualRegister) -> Optional[int]:
        """Get the spill slot for a virtual register.
        
        Args:
            virtual_reg: Virtual register
            
        Returns:
            Stack offset, or None if not spilled
        """
        return self.spill_slots.get(virtual_reg)
    
    def is_spilled(self, virtual_reg: VirtualRegister) -> bool:
        """Check if a virtual register is spilled.
        
        Args:
            virtual_reg: Virtual register
            
        Returns:
            True if spilled
        """
        return virtual_reg in self.spill_slots
    
    def get_used_callee_saved_registers(self) -> List[X86Register]:
        """Get list of callee-saved registers that were used.
        
        Returns:
            List of used callee-saved registers
        """
        return sorted(list(self.used_callee_saved), key=lambda r: r.value)


def allocate_registers(function: IRFunction) -> Tuple[Dict[VirtualRegister, X86Register],
                                                      Dict[VirtualRegister, int],
                                                      Set[X86Register]]:
    """Allocate registers for a function.
    
    Convenience function that creates an allocator and runs allocation.
    
    Args:
        function: Function to allocate registers for
        
    Returns:
        Tuple of (allocation map, spill slots map, used callee-saved registers)
    """
    allocator = RegisterAllocator(function)
    return allocator.allocate()
