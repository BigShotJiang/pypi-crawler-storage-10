"""x86 assembly instruction definitions and formatting."""

from dataclasses import dataclass
from typing import Optional, Union, List
from enum import Enum, auto

from src.codegen.x86.x86_registers import X86Register


class X86InstructionType(Enum):
    """Types of x86 instructions."""
    # Data movement
    MOV = "mov"
    MOVSX = "movsx"  # Move with sign extension
    MOVZX = "movzx"  # Move with zero extension
    LEA = "lea"      # Load effective address
    PUSH = "push"
    POP = "pop"
    
    # Arithmetic
    ADD = "add"
    SUB = "sub"
    IMUL = "imul"    # Signed multiply
    IDIV = "idiv"    # Signed divide
    NEG = "neg"
    INC = "inc"
    DEC = "dec"
    
    # Logical
    AND = "and"
    OR = "or"
    XOR = "xor"
    NOT = "not"
    
    # Shift
    SHL = "shl"      # Shift left
    SHR = "shr"      # Shift right (logical)
    SAR = "sar"      # Shift arithmetic right
    
    # Comparison
    CMP = "cmp"
    TEST = "test"
    
    # Control flow
    JMP = "jmp"
    JE = "je"        # Jump if equal
    JNE = "jne"      # Jump if not equal
    JL = "jl"        # Jump if less
    JLE = "jle"      # Jump if less or equal
    JG = "jg"        # Jump if greater
    JGE = "jge"      # Jump if greater or equal
    JZ = "jz"        # Jump if zero
    JNZ = "jnz"      # Jump if not zero
    CALL = "call"
    RET = "ret"
    
    # Special
    NOP = "nop"
    LEAVE = "leave"
    CDQ = "cdq"      # Convert doubleword to quadword (sign extend EAX to EDX:EAX)
    CQO = "cqo"      # Convert quadword to octword (sign extend RAX to RDX:RAX)
    
    # Set byte on condition
    SETE = "sete"
    SETNE = "setne"
    SETL = "setl"
    SETLE = "setle"
    SETG = "setg"
    SETGE = "setge"
    
    # SSE2 floating-point instructions
    MOVSS = "movss"    # Move scalar single-precision float
    MOVSD = "movsd"    # Move scalar double-precision float
    ADDSS = "addss"    # Add scalar single-precision float
    ADDSD = "addsd"    # Add scalar double-precision float
    SUBSS = "subss"    # Subtract scalar single-precision float
    SUBSD = "subsd"    # Subtract scalar double-precision float
    MULSS = "mulss"    # Multiply scalar single-precision float
    MULSD = "mulsd"    # Multiply scalar double-precision float
    DIVSS = "divss"    # Divide scalar single-precision float
    DIVSD = "divsd"    # Divide scalar double-precision float
    UCOMISS = "ucomiss"  # Unordered compare scalar single-precision float
    UCOMISD = "ucomisd"  # Unordered compare scalar double-precision float
    CVTSI2SS = "cvtsi2ss"  # Convert signed int to single-precision float
    CVTSI2SD = "cvtsi2sd"  # Convert signed int to double-precision float
    CVTSS2SI = "cvtss2si"  # Convert single-precision float to signed int
    CVTSD2SI = "cvtsd2si"  # Convert double-precision float to signed int
    CVTSS2SD = "cvtss2sd"  # Convert single-precision to double-precision
    CVTSD2SS = "cvtsd2ss"  # Convert double-precision to single-precision


@dataclass
class X86Operand:
    """Base class for x86 operands."""
    
    def format_att(self) -> str:
        """Format operand in AT&T syntax.
        
        Returns:
            Formatted operand string
        """
        raise NotImplementedError
    
    def format_intel(self) -> str:
        """Format operand in Intel syntax.
        
        Returns:
            Formatted operand string
        """
        raise NotImplementedError


@dataclass
class RegisterOperand(X86Operand):
    """Register operand.
    
    Attributes:
        register: The register
    """
    register: X86Register
    
    def format_att(self) -> str:
        return str(self.register)
    
    def format_intel(self) -> str:
        # Intel syntax: no % prefix
        return self.register.value


@dataclass
class ImmediateOperand(X86Operand):
    """Immediate (constant) operand.
    
    Attributes:
        value: The immediate value
    """
    value: Union[int, str]
    
    def format_att(self) -> str:
        if isinstance(self.value, str):
            return f"${self.value}"
        return f"${self.value}"
    
    def format_intel(self) -> str:
        # Intel syntax: no $ prefix
        return str(self.value)


@dataclass
class MemoryOperand(X86Operand):
    """Memory operand with addressing mode.
    
    Supports: offset(%base, %index, scale)
    
    Attributes:
        base: Base register (optional)
        offset: Offset value (optional)
        index: Index register (optional)
        scale: Scale factor (1, 2, 4, or 8)
    """
    base: Optional[X86Register] = None
    offset: Optional[Union[int, str]] = None
    index: Optional[X86Register] = None
    scale: int = 1
    
    def format_att(self) -> str:
        """Format memory operand in AT&T syntax.
        
        Examples:
            (%rax)           - base only
            8(%rax)          - offset + base
            (%rax,%rbx,4)    - base + index * scale
            8(%rax,%rbx,4)   - offset + base + index * scale
            symbol           - absolute address
        """
        parts = []
        
        # Offset
        if self.offset is not None:
            if isinstance(self.offset, str):
                parts.append(self.offset)
            else:
                parts.append(str(self.offset))
        
        # Base and index
        if self.base or self.index:
            addr_parts = []
            if self.base:
                addr_parts.append(str(self.base))
            if self.index:
                if not self.base:
                    addr_parts.append("")
                addr_parts.append(str(self.index))
                if self.scale != 1:
                    addr_parts.append(str(self.scale))
            
            parts.append(f"({','.join(addr_parts)})")
        
        return "".join(parts) if parts else "0"
    
    def format_intel(self) -> str:
        """Format memory operand in Intel syntax.
        
        Examples:
            [rax]              - base only
            [rax+8]            - base + offset
            [rax+rbx*4]        - base + index * scale
            [rax+rbx*4+8]      - base + index * scale + offset
            symbol             - absolute address
        """
        if self.offset is not None and not self.base and not self.index:
            # Absolute address
            return str(self.offset)
        
        parts = []
        
        # Base
        if self.base:
            parts.append(self.base.value)
        
        # Index with scale
        if self.index:
            if self.scale != 1:
                parts.append(f"{self.index.value}*{self.scale}")
            else:
                parts.append(self.index.value)
        
        # Offset
        if self.offset is not None:
            if isinstance(self.offset, int):
                if self.offset >= 0:
                    parts.append(f"+{self.offset}")
                else:
                    parts.append(str(self.offset))
            else:
                parts.append(f"+{self.offset}")
        
        if parts:
            return f"[{'+'.join(parts).replace('+-', '-')}]"
        return "[0]"


@dataclass
class LabelOperand(X86Operand):
    """Label operand for jumps and calls.
    
    Attributes:
        label: Label name
    """
    label: str
    
    def format_att(self) -> str:
        return self.label
    
    def format_intel(self) -> str:
        return self.label


@dataclass
class X86Instruction:
    """Represents an x86 assembly instruction.
    
    Attributes:
        opcode: Instruction type
        operands: List of operands (destination last for AT&T syntax)
        comment: Optional comment for the instruction
    """
    opcode: X86InstructionType
    operands: List[X86Operand]
    comment: Optional[str] = None
    
    def format_att(self) -> str:
        """Format instruction in AT&T syntax.
        
        AT&T syntax: opcode source, destination
        
        Returns:
            Formatted instruction string
        """
        # Format operands
        operand_strs = [op.format_att() for op in self.operands]
        
        # Build instruction string
        if operand_strs:
            instr = f"\t{self.opcode.value} {', '.join(operand_strs)}"
        else:
            instr = f"\t{self.opcode.value}"
        
        # Add comment if present (disabled for compatibility)
        # if self.comment:
        #     instr += f"\t# {self.comment}"
        
        return instr
    
    def format_intel(self) -> str:
        """Format instruction in Intel syntax.
        
        Intel syntax: opcode destination, source
        
        Returns:
            Formatted instruction string
        """
        # Format operands
        operand_strs = [op.format_intel() for op in self.operands]
        
        # Reverse operands for Intel syntax (destination first)
        if len(operand_strs) == 2:
            operand_strs = [operand_strs[1], operand_strs[0]]
        
        # Build instruction string
        if operand_strs:
            instr = f"\t{self.opcode.value} {', '.join(operand_strs)}"
        else:
            instr = f"\t{self.opcode.value}"
        
        return instr
    
    def __str__(self) -> str:
        return self.format_att()


# ============================================================================
# Instruction Builder Helper Functions
# ============================================================================

def mov(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a MOV instruction."""
    return X86Instruction(X86InstructionType.MOV, [src, dst], comment)


def add(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create an ADD instruction."""
    return X86Instruction(X86InstructionType.ADD, [src, dst], comment)


def sub(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a SUB instruction."""
    return X86Instruction(X86InstructionType.SUB, [src, dst], comment)


def imul(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create an IMUL instruction."""
    return X86Instruction(X86InstructionType.IMUL, [src, dst], comment)


def push(operand: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a PUSH instruction."""
    return X86Instruction(X86InstructionType.PUSH, [operand], comment)


def pop(operand: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a POP instruction."""
    return X86Instruction(X86InstructionType.POP, [operand], comment)


def call(target: Union[str, X86Operand], comment: Optional[str] = None) -> X86Instruction:
    """Create a CALL instruction."""
    if isinstance(target, str):
        target = LabelOperand(target)
    return X86Instruction(X86InstructionType.CALL, [target], comment)


def ret(comment: Optional[str] = None) -> X86Instruction:
    """Create a RET instruction."""
    return X86Instruction(X86InstructionType.RET, [], comment)


def jmp(label: str, comment: Optional[str] = None) -> X86Instruction:
    """Create a JMP instruction."""
    return X86Instruction(X86InstructionType.JMP, [LabelOperand(label)], comment)


def cmp(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a CMP instruction."""
    return X86Instruction(X86InstructionType.CMP, [src, dst], comment)


def lea(src: X86Operand, dst: X86Operand, comment: Optional[str] = None) -> X86Instruction:
    """Create a LEA instruction."""
    return X86Instruction(X86InstructionType.LEA, [src, dst], comment)
