"""x86 register definitions and management."""

from enum import Enum, auto
from typing import Set, Optional


class X86Register(Enum):
    """x86-64 general-purpose registers.
    
    Follows System V AMD64 ABI conventions:
    - RAX: Return value, caller-saved
    - RBX: Callee-saved
    - RCX: 4th argument, caller-saved
    - RDX: 3rd argument, caller-saved
    - RSI: 2nd argument, caller-saved
    - RDI: 1st argument, caller-saved
    - RBP: Base pointer, callee-saved
    - RSP: Stack pointer
    - R8: 5th argument, caller-saved
    - R9: 6th argument, caller-saved
    - R10-R11: Caller-saved
    - R12-R15: Callee-saved
    """
    # 64-bit registers
    RAX = "rax"
    RBX = "rbx"
    RCX = "rcx"
    RDX = "rdx"
    RSI = "rsi"
    RDI = "rdi"
    RBP = "rbp"
    RSP = "rsp"
    R8 = "r8"
    R9 = "r9"
    R10 = "r10"
    R11 = "r11"
    R12 = "r12"
    R13 = "r13"
    R14 = "r14"
    R15 = "r15"
    
    # 32-bit registers (lower 32 bits)
    EAX = "eax"
    EBX = "ebx"
    ECX = "ecx"
    EDX = "edx"
    ESI = "esi"
    EDI = "edi"
    EBP = "ebp"
    ESP = "esp"
    R8D = "r8d"
    R9D = "r9d"
    R10D = "r10d"
    R11D = "r11d"
    R12D = "r12d"
    R13D = "r13d"
    R14D = "r14d"
    R15D = "r15d"
    
    # 16-bit registers
    AX = "ax"
    BX = "bx"
    CX = "cx"
    DX = "dx"
    SI = "si"
    DI = "di"
    BP = "bp"
    SP = "sp"
    
    # 8-bit registers
    AL = "al"
    BL = "bl"
    CL = "cl"
    DL = "dl"
    
    def __str__(self) -> str:
        return f"%{self.value}"
    
    def is_caller_saved(self) -> bool:
        """Check if this register is caller-saved (volatile).
        
        Returns:
            True if caller-saved
        """
        caller_saved = {
            X86Register.RAX, X86Register.RCX, X86Register.RDX,
            X86Register.RSI, X86Register.RDI, X86Register.R8,
            X86Register.R9, X86Register.R10, X86Register.R11
        }
        return self in caller_saved
    
    def is_callee_saved(self) -> bool:
        """Check if this register is callee-saved (non-volatile).
        
        Returns:
            True if callee-saved
        """
        callee_saved = {
            X86Register.RBX, X86Register.RBP, X86Register.R12,
            X86Register.R13, X86Register.R14, X86Register.R15
        }
        return self in callee_saved
    
    def is_argument_register(self) -> bool:
        """Check if this register is used for argument passing.
        
        Returns:
            True if used for arguments
        """
        arg_regs = {
            X86Register.RDI, X86Register.RSI, X86Register.RDX,
            X86Register.RCX, X86Register.R8, X86Register.R9
        }
        return self in arg_regs
    
    @staticmethod
    def get_argument_registers() -> list['X86Register']:
        """Get the list of registers used for argument passing in order.
        
        Returns:
            List of argument registers (RDI, RSI, RDX, RCX, R8, R9)
        """
        return [
            X86Register.RDI,
            X86Register.RSI,
            X86Register.RDX,
            X86Register.RCX,
            X86Register.R8,
            X86Register.R9
        ]
    
    @staticmethod
    def get_caller_saved_registers() -> Set['X86Register']:
        """Get all caller-saved registers.
        
        Returns:
            Set of caller-saved registers
        """
        return {
            X86Register.RAX, X86Register.RCX, X86Register.RDX,
            X86Register.RSI, X86Register.RDI, X86Register.R8,
            X86Register.R9, X86Register.R10, X86Register.R11
        }
    
    @staticmethod
    def get_callee_saved_registers() -> Set['X86Register']:
        """Get all callee-saved registers.
        
        Returns:
            Set of callee-saved registers
        """
        return {
            X86Register.RBX, X86Register.RBP, X86Register.R12,
            X86Register.R13, X86Register.R14, X86Register.R15
        }
    
    @staticmethod
    def get_allocatable_registers() -> list['X86Register']:
        """Get registers available for allocation.
        
        Excludes RSP (stack pointer) and RBP (base pointer).
        
        Returns:
            List of allocatable registers
        """
        return [
            X86Register.RAX, X86Register.RBX, X86Register.RCX,
            X86Register.RDX, X86Register.RSI, X86Register.RDI,
            X86Register.R8, X86Register.R9, X86Register.R10,
            X86Register.R11, X86Register.R12, X86Register.R13,
            X86Register.R14, X86Register.R15
        ]
    
    def get_size_variant(self, size: int) -> Optional['X86Register']:
        """Get the register variant for a specific size.
        
        Args:
            size: Size in bytes (1, 2, 4, or 8)
            
        Returns:
            Register variant for the given size, or None if not available
        """
        # Map 64-bit registers to their variants
        variants = {
            X86Register.RAX: {8: X86Register.RAX, 4: X86Register.EAX, 2: X86Register.AX, 1: X86Register.AL},
            X86Register.RBX: {8: X86Register.RBX, 4: X86Register.EBX, 2: X86Register.BX, 1: X86Register.BL},
            X86Register.RCX: {8: X86Register.RCX, 4: X86Register.ECX, 2: X86Register.CX, 1: X86Register.CL},
            X86Register.RDX: {8: X86Register.RDX, 4: X86Register.EDX, 2: X86Register.DX, 1: X86Register.DL},
            X86Register.RSI: {8: X86Register.RSI, 4: X86Register.ESI, 2: X86Register.SI},
            X86Register.RDI: {8: X86Register.RDI, 4: X86Register.EDI, 2: X86Register.DI},
            X86Register.RBP: {8: X86Register.RBP, 4: X86Register.EBP, 2: X86Register.BP},
            X86Register.RSP: {8: X86Register.RSP, 4: X86Register.ESP, 2: X86Register.SP},
            X86Register.R8: {8: X86Register.R8, 4: X86Register.R8D},
            X86Register.R9: {8: X86Register.R9, 4: X86Register.R9D},
            X86Register.R10: {8: X86Register.R10, 4: X86Register.R10D},
            X86Register.R11: {8: X86Register.R11, 4: X86Register.R11D},
            X86Register.R12: {8: X86Register.R12, 4: X86Register.R12D},
            X86Register.R13: {8: X86Register.R13, 4: X86Register.R13D},
            X86Register.R14: {8: X86Register.R14, 4: X86Register.R14D},
            X86Register.R15: {8: X86Register.R15, 4: X86Register.R15D},
        }
        
        # Find the base 64-bit register
        base_reg = self
        for reg_64, size_map in variants.items():
            if self in size_map.values():
                base_reg = reg_64
                break
        
        return variants.get(base_reg, {}).get(size)
