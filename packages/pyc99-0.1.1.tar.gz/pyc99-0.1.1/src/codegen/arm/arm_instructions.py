"""ARM assembly instruction definitions and formatting."""

from dataclasses import dataclass
from typing import Optional, Union, List
from enum import Enum

from src.codegen.arm.arm_registers import ARMRegister


class ARMInstructionType(Enum):
    """Types of ARM instructions."""
    # Data movement
    MOV = "mov"
    MOVW = "movw"    # Move 16-bit immediate
    MOVT = "movt"    # Move top 16 bits
    LDR = "ldr"      # Load register
    STR = "str"      # Store register
    PUSH = "push"
    POP = "pop"
    
    # Arithmetic
    ADD = "add"
    SUB = "sub"
    MUL = "mul"
    SDIV = "sdiv"    # Signed divide (ARMv7-A and later)
    UDIV = "udiv"    # Unsigned divide
    RSB = "rsb"      # Reverse subtract
    
    # Logical
    AND = "and"
    ORR = "orr"      # Logical OR
    EOR = "eor"      # Exclusive OR (XOR)
    BIC = "bic"      # Bit clear
    MVN = "mvn"      # Move NOT
    
    # Shift
    LSL = "lsl"      # Logical shift left
    LSR = "lsr"      # Logical shift right
    ASR = "asr"      # Arithmetic shift right
    ROR = "ror"      # Rotate right
    
    # Comparison
    CMP = "cmp"
    CMN = "cmn"      # Compare negative
    TST = "tst"      # Test bits
    TEQ = "teq"      # Test equivalence
    
    # Control flow
    B = "b"          # Branch
    BL = "bl"        # Branch with link (call)
    BX = "bx"        # Branch and exchange
    BLX = "blx"      # Branch with link and exchange
    
    # Conditional branches
    BEQ = "beq"      # Branch if equal
    BNE = "bne"      # Branch if not equal
    BLT = "blt"      # Branch if less than
    BLE = "ble"      # Branch if less or equal
    BGT = "bgt"      # Branch if greater than
    BGE = "bge"      # Branch if greater or equal
    BHI = "bhi"      # Branch if higher (unsigned)
    BLS = "bls"      # Branch if lower or same (unsigned)
    
    # Special
    NOP = "nop"
    
    # Multiply and accumulate
    MLA = "mla"      # Multiply accumulate
    MLS = "mls"      # Multiply subtract
    
    # Load/Store multiple
    LDMIA = "ldmia"  # Load multiple increment after
    STMDB = "stmdb"  # Store multiple decrement before
    
    # VFP (Vector Floating Point) instructions
    VMOV = "vmov"        # Move between VFP and ARM registers
    VMOV_F32 = "vmov.f32"  # Move single-precision float
    VMOV_F64 = "vmov.f64"  # Move double-precision float
    VLDR = "vldr"        # Load VFP register
    VSTR = "vstr"        # Store VFP register
    VADD_F32 = "vadd.f32"  # Add single-precision floats
    VADD_F64 = "vadd.f64"  # Add double-precision floats
    VSUB_F32 = "vsub.f32"  # Subtract single-precision floats
    VSUB_F64 = "vsub.f64"  # Subtract double-precision floats
    VMUL_F32 = "vmul.f32"  # Multiply single-precision floats
    VMUL_F64 = "vmul.f64"  # Multiply double-precision floats
    VDIV_F32 = "vdiv.f32"  # Divide single-precision floats
    VDIV_F64 = "vdiv.f64"  # Divide double-precision floats
    VNEG_F32 = "vneg.f32"  # Negate single-precision float
    VNEG_F64 = "vneg.f64"  # Negate double-precision float
    VCMP_F32 = "vcmp.f32"  # Compare single-precision floats
    VCMP_F64 = "vcmp.f64"  # Compare double-precision floats
    VMRS = "vmrs"        # Move VFP status to ARM register
    VCVT_F32_S32 = "vcvt.f32.s32"  # Convert signed int to float
    VCVT_F64_S32 = "vcvt.f64.s32"  # Convert signed int to double
    VCVT_S32_F32 = "vcvt.s32.f32"  # Convert float to signed int
    VCVT_S32_F64 = "vcvt.s32.f64"  # Convert double to signed int
    VCVT_F32_F64 = "vcvt.f32.f64"  # Convert double to float
    VCVT_F64_F32 = "vcvt.f64.f32"  # Convert float to double


class ARMCondition(Enum):
    """ARM condition codes."""
    EQ = "eq"  # Equal
    NE = "ne"  # Not equal
    LT = "lt"  # Less than (signed)
    LE = "le"  # Less than or equal (signed)
    GT = "gt"  # Greater than (signed)
    GE = "ge"  # Greater than or equal (signed)
    HI = "hi"  # Higher (unsigned)
    LS = "ls"  # Lower or same (unsigned)
    AL = ""    # Always (default, usually omitted)


@dataclass
class ARMOperand:
    """Base class for ARM operands."""
    
    def format(self) -> str:
        """Format operand in ARM syntax.
        
        Returns:
            Formatted operand string
        """
        raise NotImplementedError


@dataclass
class RegisterOperand(ARMOperand):
    """Register operand.
    
    Attributes:
        register: The register
    """
    register: ARMRegister
    
    def format(self) -> str:
        return str(self.register)


@dataclass
class ImmediateOperand(ARMOperand):
    """Immediate (constant) operand.
    
    ARM has restrictions on immediate values - they must be encodable
    as an 8-bit value rotated by an even number of bits.
    
    Attributes:
        value: The immediate value
    """
    value: Union[int, str]
    
    def format(self) -> str:
        if isinstance(self.value, str):
            return f"#{self.value}"
        return f"#{self.value}"
    
    @staticmethod
    def is_valid_immediate(value: int) -> bool:
        """Check if a value can be encoded as an ARM immediate.
        
        ARM immediates must be an 8-bit value rotated right by an even number.
        
        Args:
            value: Value to check
            
        Returns:
            True if value can be encoded as immediate
        """
        if value < 0:
            value = value & 0xFFFFFFFF  # Convert to unsigned 32-bit
        
        # Check if value is already 8-bit
        if value <= 0xFF:
            return True
        
        # Try all possible rotations
        for rotation in range(0, 32, 2):
            rotated = ((value << rotation) | (value >> (32 - rotation))) & 0xFFFFFFFF
            if rotated <= 0xFF:
                return True
        
        return False


@dataclass
class MemoryOperand(ARMOperand):
    """Memory operand with addressing mode.
    
    Supports various ARM addressing modes:
    - [Rn] - Register indirect
    - [Rn, #offset] - Register with offset
    - [Rn, Rm] - Register with register offset
    - [Rn, Rm, LSL #shift] - Register with shifted register offset
    
    Attributes:
        base: Base register
        offset: Offset value (optional)
        index: Index register (optional)
        shift_type: Shift type for index register (optional)
        shift_amount: Shift amount (optional)
        writeback: Whether to write back the address to base register
        pre_indexed: Whether offset is applied before access (True) or after (False)
    """
    base: ARMRegister
    offset: Optional[Union[int, str]] = None
    index: Optional[ARMRegister] = None
    shift_type: Optional[str] = None  # "lsl", "lsr", "asr", "ror"
    shift_amount: Optional[int] = None
    writeback: bool = False
    pre_indexed: bool = True
    
    def format(self) -> str:
        """Format memory operand in ARM syntax.
        
        Examples:
            [r0]              - base only
            [r0, #4]          - base + offset
            [r0, r1]          - base + index
            [r0, r1, lsl #2]  - base + (index << 2)
            [r0, #4]!         - pre-indexed with writeback
            [r0], #4          - post-indexed
        """
        parts = [str(self.base)]
        
        if self.pre_indexed:
            # Pre-indexed: [base, offset]
            if self.offset is not None:
                if isinstance(self.offset, str):
                    parts.append(f"#{self.offset}")
                else:
                    parts.append(f"#{self.offset}")
            elif self.index is not None:
                index_str = str(self.index)
                if self.shift_type and self.shift_amount is not None:
                    index_str += f", {self.shift_type} #{self.shift_amount}"
                parts.append(index_str)
            
            result = f"[{', '.join(parts)}]"
            if self.writeback:
                result += "!"
        else:
            # Post-indexed: [base], offset
            result = f"[{parts[0]}]"
            if self.offset is not None:
                if isinstance(self.offset, str):
                    result += f", #{self.offset}"
                else:
                    result += f", #{self.offset}"
            elif self.index is not None:
                index_str = str(self.index)
                if self.shift_type and self.shift_amount is not None:
                    index_str += f", {self.shift_type} #{self.shift_amount}"
                result += f", {index_str}"
        
        return result


@dataclass
class LabelOperand(ARMOperand):
    """Label operand for branches and calls.
    
    Attributes:
        label: Label name
    """
    label: str
    
    def format(self) -> str:
        return self.label


@dataclass
class RegisterListOperand(ARMOperand):
    """Register list operand for push/pop and load/store multiple.
    
    Attributes:
        registers: List of registers
    """
    registers: List[ARMRegister]
    
    def format(self) -> str:
        """Format as {r0, r1, r2, ...}"""
        reg_strs = [str(reg) for reg in self.registers]
        return "{" + ", ".join(reg_strs) + "}"


@dataclass
class ShiftedRegisterOperand(ARMOperand):
    """Register with shift operation.
    
    Attributes:
        register: The register
        shift_type: Type of shift (lsl, lsr, asr, ror)
        shift_amount: Amount to shift (immediate or register)
    """
    register: ARMRegister
    shift_type: str
    shift_amount: Union[int, ARMRegister]
    
    def format(self) -> str:
        if isinstance(self.shift_amount, ARMRegister):
            return f"{self.register}, {self.shift_type} {self.shift_amount}"
        else:
            return f"{self.register}, {self.shift_type} #{self.shift_amount}"


@dataclass
class ARMInstruction:
    """Represents an ARM assembly instruction.
    
    Attributes:
        opcode: Instruction type
        operands: List of operands
        condition: Optional condition code
        comment: Optional comment for the instruction
    """
    opcode: ARMInstructionType
    operands: List[ARMOperand]
    condition: Optional[ARMCondition] = None
    comment: Optional[str] = None
    
    def format(self) -> str:
        """Format instruction in ARM syntax.
        
        Returns:
            Formatted instruction string
        """
        # Build opcode with condition
        opcode_str = self.opcode.value
        if self.condition and self.condition != ARMCondition.AL:
            opcode_str += self.condition.value
        
        # Format operands
        operand_strs = [op.format() for op in self.operands]
        
        # Build instruction string
        if operand_strs:
            instr = f"\t{opcode_str} {', '.join(operand_strs)}"
        else:
            instr = f"\t{opcode_str}"
        
        # Add comment if present
        if self.comment:
            instr += f"\t@ {self.comment}"
        
        return instr
    
    def __str__(self) -> str:
        return self.format()


# ============================================================================
# Instruction Builder Helper Functions
# ============================================================================

def mov(src: ARMOperand, dst: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a MOV instruction."""
    return ARMInstruction(ARMInstructionType.MOV, [src, dst], comment=comment)


def add(src1: ARMOperand, src2: ARMOperand, dst: ARMOperand, 
        comment: Optional[str] = None) -> ARMInstruction:
    """Create an ADD instruction."""
    return ARMInstruction(ARMInstructionType.ADD, [dst, src1, src2], comment=comment)


def sub(src1: ARMOperand, src2: ARMOperand, dst: ARMOperand,
        comment: Optional[str] = None) -> ARMInstruction:
    """Create a SUB instruction."""
    return ARMInstruction(ARMInstructionType.SUB, [dst, src1, src2], comment=comment)


def mul(src1: ARMOperand, src2: ARMOperand, dst: ARMOperand,
        comment: Optional[str] = None) -> ARMInstruction:
    """Create a MUL instruction."""
    return ARMInstruction(ARMInstructionType.MUL, [dst, src1, src2], comment=comment)


def ldr(src: ARMOperand, dst: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a LDR instruction."""
    return ARMInstruction(ARMInstructionType.LDR, [dst, src], comment=comment)


def str_instr(src: ARMOperand, dst: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a STR instruction."""
    return ARMInstruction(ARMInstructionType.STR, [src, dst], comment=comment)


def push(operand: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a PUSH instruction."""
    return ARMInstruction(ARMInstructionType.PUSH, [operand], comment=comment)


def pop(operand: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a POP instruction."""
    return ARMInstruction(ARMInstructionType.POP, [operand], comment=comment)


def bl(target: Union[str, ARMOperand], comment: Optional[str] = None) -> ARMInstruction:
    """Create a BL (branch with link / call) instruction."""
    if isinstance(target, str):
        target = LabelOperand(target)
    return ARMInstruction(ARMInstructionType.BL, [target], comment=comment)


def bx(register: ARMRegister, comment: Optional[str] = None) -> ARMInstruction:
    """Create a BX (branch and exchange) instruction."""
    return ARMInstruction(ARMInstructionType.BX, [RegisterOperand(register)], comment=comment)


def b(label: str, condition: Optional[ARMCondition] = None, 
      comment: Optional[str] = None) -> ARMInstruction:
    """Create a B (branch) instruction."""
    return ARMInstruction(ARMInstructionType.B, [LabelOperand(label)], 
                         condition=condition, comment=comment)


def cmp(src1: ARMOperand, src2: ARMOperand, comment: Optional[str] = None) -> ARMInstruction:
    """Create a CMP instruction."""
    return ARMInstruction(ARMInstructionType.CMP, [src1, src2], comment=comment)
