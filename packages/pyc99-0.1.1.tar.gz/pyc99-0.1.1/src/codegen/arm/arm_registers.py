"""ARM register definitions and management."""

from enum import Enum
from typing import Set, Optional


class ARMRegister(Enum):
    """ARM general-purpose registers.
    
    Follows ARM EABI conventions:
    - R0-R3: Argument/result registers, caller-saved
    - R4-R11: Callee-saved registers
    - R12 (IP): Intra-procedure call scratch register, caller-saved
    - R13 (SP): Stack pointer
    - R14 (LR): Link register (return address)
    - R15 (PC): Program counter
    """
    # General-purpose registers
    R0 = "r0"
    R1 = "r1"
    R2 = "r2"
    R3 = "r3"
    R4 = "r4"
    R5 = "r5"
    R6 = "r6"
    R7 = "r7"
    R8 = "r8"
    R9 = "r9"
    R10 = "r10"
    R11 = "r11"
    R12 = "r12"  # IP (Intra-Procedure call scratch)
    
    # Special registers
    SP = "sp"    # R13 - Stack Pointer
    LR = "lr"    # R14 - Link Register
    PC = "pc"    # R15 - Program Counter
    
    def __str__(self) -> str:
        return self.value
    
    def is_caller_saved(self) -> bool:
        """Check if this register is caller-saved (volatile).
        
        Returns:
            True if caller-saved
        """
        caller_saved = {
            ARMRegister.R0, ARMRegister.R1, ARMRegister.R2,
            ARMRegister.R3, ARMRegister.R12
        }
        return self in caller_saved
    
    def is_callee_saved(self) -> bool:
        """Check if this register is callee-saved (non-volatile).
        
        Returns:
            True if callee-saved
        """
        callee_saved = {
            ARMRegister.R4, ARMRegister.R5, ARMRegister.R6,
            ARMRegister.R7, ARMRegister.R8, ARMRegister.R9,
            ARMRegister.R10, ARMRegister.R11
        }
        return self in callee_saved
    
    def is_argument_register(self) -> bool:
        """Check if this register is used for argument passing.
        
        Returns:
            True if used for arguments
        """
        arg_regs = {
            ARMRegister.R0, ARMRegister.R1,
            ARMRegister.R2, ARMRegister.R3
        }
        return self in arg_regs
    
    @staticmethod
    def get_argument_registers() -> list['ARMRegister']:
        """Get the list of registers used for argument passing in order.
        
        Returns:
            List of argument registers (R0-R3)
        """
        return [
            ARMRegister.R0,
            ARMRegister.R1,
            ARMRegister.R2,
            ARMRegister.R3
        ]
    
    @staticmethod
    def get_caller_saved_registers() -> Set['ARMRegister']:
        """Get all caller-saved registers.
        
        Returns:
            Set of caller-saved registers
        """
        return {
            ARMRegister.R0, ARMRegister.R1, ARMRegister.R2,
            ARMRegister.R3, ARMRegister.R12
        }
    
    @staticmethod
    def get_callee_saved_registers() -> Set['ARMRegister']:
        """Get all callee-saved registers.
        
        Returns:
            Set of callee-saved registers
        """
        return {
            ARMRegister.R4, ARMRegister.R5, ARMRegister.R6,
            ARMRegister.R7, ARMRegister.R8, ARMRegister.R9,
            ARMRegister.R10, ARMRegister.R11
        }
    
    @staticmethod
    def get_allocatable_registers() -> list['ARMRegister']:
        """Get registers available for allocation.
        
        Excludes SP (stack pointer), LR (link register), and PC (program counter).
        
        Returns:
            List of allocatable registers
        """
        return [
            ARMRegister.R0, ARMRegister.R1, ARMRegister.R2,
            ARMRegister.R3, ARMRegister.R4, ARMRegister.R5,
            ARMRegister.R6, ARMRegister.R7, ARMRegister.R8,
            ARMRegister.R9, ARMRegister.R10, ARMRegister.R11,
            ARMRegister.R12
        ]
