"""Abstract base class for code generators."""

from abc import ABC, abstractmethod
from typing import Dict, List

from src.ir.ir_module import IRModule, IRFunction
from src.ir.ir_nodes import VirtualRegister


class CodeGenerator(ABC):
    """Abstract base class for target-specific code generators.
    
    Subclasses implement code generation for specific architectures
    (x86, ARM, etc.).
    
    Attributes:
        ir_module: IR module to generate code from
    """
    
    def __init__(self, ir_module: IRModule):
        """Initialize code generator.
        
        Args:
            ir_module: IR module to generate code from
        """
        self.ir_module = ir_module
    
    @abstractmethod
    def generate(self) -> str:
        """Generate assembly code for the entire module.
        
        Returns:
            Assembly code as a string
        """
        pass
    
    @abstractmethod
    def generate_function(self, function: IRFunction) -> str:
        """Generate assembly code for a single function.
        
        Args:
            function: IR function to generate code for
            
        Returns:
            Assembly code for the function
        """
        pass
    
    @abstractmethod
    def get_target_name(self) -> str:
        """Get the name of the target architecture.
        
        Returns:
            Target architecture name (e.g., 'x86', 'arm')
        """
        pass
