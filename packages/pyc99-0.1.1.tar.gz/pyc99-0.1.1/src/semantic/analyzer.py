"""Semantic analyzer for C99 AST."""

from typing import Optional, List

from src.parser.ast_nodes import (
    ASTNode, TranslationUnit, Declaration, Statement, Expression,
    FunctionDecl, VarDecl, StructDecl, EnumDecl, TypedefDecl,
    CompoundStmt, ExpressionStmt, IfStmt, WhileStmt, DoWhileStmt,
    ForStmt, ReturnStmt, BreakStmt, ContinueStmt, SwitchStmt,
    CaseStmt, GotoStmt, LabelStmt, Type, FunctionType, PrimitiveType,
    StructType
)
from src.semantic.symbol import Symbol
from src.semantic.symbol_kinds import SymbolKind
from src.semantic.symbol_table import SymbolTable
from src.semantic.type_checker import TypeChecker
from src.utils.error_reporter import ErrorReporter
from src.utils.error_suggestions import ErrorSuggestions


class SemanticAnalyzer:
    """Performs semantic analysis on C99 AST.
    
    This class traverses the AST, builds symbol tables, performs type checking,
    and validates semantic rules. It also generates warnings for potential issues.
    
    Attributes:
        ast: The AST to analyze
        symbol_table: Symbol table for scope management
        type_checker: Type checker for expressions
        error_reporter: Error reporter for diagnostics
        current_function: Currently analyzed function (for return checking)
        in_loop: Whether currently inside a loop (for break/continue)
        in_switch: Whether currently inside a switch (for case/default)
    """
    
    def __init__(self, ast: TranslationUnit, error_reporter: ErrorReporter):
        """Initialize semantic analyzer.
        
        Args:
            ast: AST to analyze
            error_reporter: Error reporter for diagnostics
        """
        self.ast = ast
        self.error_reporter = error_reporter
        self.symbol_table = SymbolTable()
        self.type_checker = TypeChecker(self.symbol_table, error_reporter)
        
        # Context tracking
        self.current_function: Optional[FunctionDecl] = None
        self.in_loop = 0  # Counter for nested loops
        self.in_switch = 0  # Counter for nested switches
        
        # Label tracking for goto/label validation
        self.function_labels: dict[str, LabelStmt] = {}  # Labels defined in current function
        self.function_gotos: List[GotoStmt] = []  # Goto statements in current function
        
        # Register built-in types and functions for variadic support
        self._register_variadic_builtins()
    
    def _register_variadic_builtins(self) -> None:
        """Register built-in types and functions for variadic function support.
        
        This registers:
        - va_list: opaque type for holding variadic arguments
        - __builtin_va_start: initialize va_list
        - __builtin_va_arg: retrieve next argument
        - __builtin_va_end: cleanup va_list
        """
        from src.parser.ast_nodes import TypedefType, PointerType
        from src.utils.source_location import SourceLocation
        
        # Create a dummy location for built-ins
        builtin_loc = SourceLocation(filename="<builtin>", line=0, column=0)
        
        # va_list is typically implemented as a pointer to char or a struct
        # For simplicity, we'll treat it as an opaque pointer type
        va_list_type = TypedefType(
            name="va_list",
            actual_type=PointerType(
                pointee_type=PrimitiveType(name='char', location=builtin_loc),
                qualifiers=(),
                location=builtin_loc
            ),
            location=builtin_loc
        )
        
        # Register va_list as a typedef
        va_list_symbol = Symbol(
            name="va_list",
            symbol_type=va_list_type.actual_type,
            kind=SymbolKind.TYPE,
            scope_level=0,
            location=builtin_loc,
            is_defined=True,
            is_used=False
        )
        self.symbol_table.declare(va_list_symbol)
        
        # Register __builtin_va_start as a function
        # void __builtin_va_start(va_list ap, last_param)
        va_start_type = FunctionType(
            return_type=PrimitiveType(name='void', location=builtin_loc),
            parameter_types=(va_list_type.actual_type, PrimitiveType(name='int', location=builtin_loc)),
            is_variadic=False,
            location=builtin_loc
        )
        va_start_symbol = Symbol(
            name="__builtin_va_start",
            symbol_type=va_start_type,
            kind=SymbolKind.FUNCTION,
            scope_level=0,
            location=builtin_loc,
            is_defined=True,
            is_used=False
        )
        self.symbol_table.declare(va_start_symbol)
        
        # Register __builtin_va_arg as a function
        # T __builtin_va_arg(va_list ap, type)
        # Note: This is a special function that returns different types
        # For now, we'll register it with a generic int return type
        va_arg_type = FunctionType(
            return_type=PrimitiveType(name='int', location=builtin_loc),
            parameter_types=(va_list_type.actual_type,),
            is_variadic=False,
            location=builtin_loc
        )
        va_arg_symbol = Symbol(
            name="__builtin_va_arg",
            symbol_type=va_arg_type,
            kind=SymbolKind.FUNCTION,
            scope_level=0,
            location=builtin_loc,
            is_defined=True,
            is_used=False
        )
        self.symbol_table.declare(va_arg_symbol)
        
        # Register __builtin_va_end as a function
        # void __builtin_va_end(va_list ap)
        va_end_type = FunctionType(
            return_type=PrimitiveType(name='void', location=builtin_loc),
            parameter_types=(va_list_type.actual_type,),
            is_variadic=False,
            location=builtin_loc
        )
        va_end_symbol = Symbol(
            name="__builtin_va_end",
            symbol_type=va_end_type,
            kind=SymbolKind.FUNCTION,
            scope_level=0,
            location=builtin_loc,
            is_defined=True,
            is_used=False
        )
        self.symbol_table.declare(va_end_symbol)
    
    def analyze(self) -> TranslationUnit:
        """Perform semantic analysis on the AST.
        
        Returns:
            The annotated AST with type information
        """
        # Process all top-level declarations
        for decl in self.ast.declarations:
            self._analyze_declaration(decl)
        
        # Check for unused symbols and generate warnings
        self._check_unused_symbols()
        
        return self.ast
    
    def _resolve_type(self, type_obj: Type) -> Type:
        """Resolve a type, including typedef resolution.
        
        Args:
            type_obj: Type to resolve
            
        Returns:
            Resolved type
        """
        from src.parser.ast_nodes import TypedefType, PointerType, ArrayType, FunctionType
        from src.semantic.type_utils import resolve_typedef
        
        # Fully resolve typedef chains
        if isinstance(type_obj, TypedefType):
            # Look up the typedef in the symbol table
            if type_obj.actual_type is None:
                typedef_symbol = self.symbol_table.lookup(type_obj.name)
                if typedef_symbol is not None:
                    type_obj.actual_type = typedef_symbol.symbol_type
            
            # Recursively resolve the typedef chain
            type_obj = resolve_typedef(type_obj, self.symbol_table)
        
        # Recursively resolve nested types
        if isinstance(type_obj, PointerType):
            type_obj.pointee_type = self._resolve_type(type_obj.pointee_type)
        elif isinstance(type_obj, ArrayType):
            type_obj.element_type = self._resolve_type(type_obj.element_type)
        elif isinstance(type_obj, FunctionType):
            type_obj.return_type = self._resolve_type(type_obj.return_type)
            type_obj.parameter_types = tuple(
                self._resolve_type(param_type) for param_type in type_obj.parameter_types
            )
        
        return type_obj
    
    def _analyze_declaration(self, decl: Declaration) -> None:
        """Analyze a declaration.
        
        Args:
            decl: Declaration to analyze
        """
        if isinstance(decl, VarDecl):
            self._analyze_var_decl(decl)
        elif isinstance(decl, FunctionDecl):
            self._analyze_function_decl(decl)
        elif isinstance(decl, StructDecl):
            self._analyze_struct_decl(decl)
        elif isinstance(decl, EnumDecl):
            self._analyze_enum_decl(decl)
        elif isinstance(decl, TypedefDecl):
            self._analyze_typedef_decl(decl)
        else:
            self.error_reporter.error(
                decl.location,
                f"Unknown declaration type: {type(decl).__name__}"
            )
    
    def _analyze_var_decl(self, decl: VarDecl) -> None:
        """Analyze a variable declaration.
        
        Args:
            decl: Variable declaration to analyze
        """
        from src.parser.ast_nodes import StorageClass, TypedefType
        from src.semantic.type_utils import resolve_typedef
        
        # Resolve struct/union types
        decl.var_type = self._resolve_struct_types(decl.var_type)
        
        # Resolve typedef types
        decl.var_type = self._resolve_type(decl.var_type)
        
        # Handle storage class semantics
        if decl.storage_class == StorageClass.EXTERN:
            # Extern declaration - check if already declared
            existing = self.symbol_table.lookup(decl.name)
            if existing is not None:
                # Verify types match
                from src.semantic.type_utils import types_equal
                if not types_equal(existing.symbol_type, decl.var_type):
                    self.error_reporter.error(
                        decl.location,
                        f"Conflicting types for '{decl.name}'"
                    )
                    self.error_reporter.error(
                        existing.location,
                        f"Previous declaration was here"
                    )
                return
            
            # Create extern symbol (not defined, just declared)
            symbol = Symbol(
                name=decl.name,
                symbol_type=decl.var_type,
                kind=SymbolKind.VARIABLE,
                scope_level=self.symbol_table.get_current_scope_level(),
                location=decl.location,
                is_defined=False,  # Extern is not a definition
                is_used=False
            )
            self.symbol_table.declare(symbol)
            return
        
        # Check if variable is already declared in current scope
        existing = self.symbol_table.lookup_current_scope(decl.name)
        if existing is not None:
            # Static local variables can be redeclared
            if decl.storage_class == StorageClass.STATIC and existing.scope_level > 0:
                suggestion = ErrorSuggestions.suggest_for_redeclaration(
                    decl.name, 
                    str(existing.location)
                )
                self.error_reporter.error(
                    decl.location,
                    f"Redeclaration of static variable '{decl.name}'",
                    note=f"Previous declaration was at {existing.location}"
                )
            else:
                suggestion = ErrorSuggestions.suggest_for_redeclaration(
                    decl.name,
                    str(existing.location)
                )
                self.error_reporter.error(
                    decl.location,
                    f"Redeclaration of '{decl.name}'",
                    note=f"Previous declaration was at {existing.location}"
                )
            return
        
        # Validate storage class usage
        if decl.storage_class == StorageClass.AUTO:
            if self.symbol_table.is_global_scope():
                self.error_reporter.error(
                    decl.location,
                    "'auto' storage class not allowed at file scope"
                )
        elif decl.storage_class == StorageClass.REGISTER:
            if self.symbol_table.is_global_scope():
                self.error_reporter.error(
                    decl.location,
                    "'register' storage class not allowed at file scope"
                )
        
        # Create symbol
        symbol = Symbol(
            name=decl.name,
            symbol_type=decl.var_type,
            kind=SymbolKind.VARIABLE,
            scope_level=self.symbol_table.get_current_scope_level(),
            location=decl.location,
            is_defined=True,
            is_used=False
        )
        
        # Add to symbol table
        self.symbol_table.declare(symbol)
        
        # Check initializer if present
        if decl.initializer is not None:
            # Special handling for array initialization
            from src.parser.ast_nodes import ArrayType, InitializerList, Literal, StructType
            if isinstance(decl.var_type, ArrayType):
                self._check_array_initialization(decl.var_type, decl.initializer, decl)
            elif isinstance(decl.var_type, StructType):
                self._check_struct_initialization(decl.var_type, decl.initializer, decl)
            else:
                init_type = self.type_checker.check_expression(decl.initializer)
                if init_type is not None:
                    # Check if initializer type is compatible with variable type
                    # Special case: NULL pointer constant (0) can initialize any pointer
                    from src.semantic.type_utils import is_pointer_type, is_null_pointer_constant
                    is_null_to_pointer = (is_pointer_type(decl.var_type) and 
                                          is_null_pointer_constant(decl.initializer))
                    
                    if not is_null_to_pointer:
                        self.type_checker.check_assignment(
                            decl.var_type,
                            init_type,
                            decl.initializer.location
                        )
        else:
            # Warn about uninitialized local variables (except extern and static)
            if not self.symbol_table.is_global_scope():
                if decl.storage_class not in (StorageClass.EXTERN, StorageClass.STATIC):
                    self.error_reporter.warning(
                        decl.location,
                        f"Variable '{decl.name}' declared without initializer"
                    )
    
    def _analyze_function_decl(self, decl: FunctionDecl) -> None:
        """Analyze a function declaration.
        
        Args:
            decl: Function declaration to analyze
        """
        from src.parser.ast_nodes import StorageClass
        
        # Resolve typedef types in return type and parameters
        decl.return_type = self._resolve_type(decl.return_type)
        decl.return_type = self._resolve_struct_types(decl.return_type)
        for param in decl.parameters:
            param.param_type = self._resolve_type(param.param_type)
            param.param_type = self._resolve_struct_types(param.param_type)
        
        # Validate storage class for functions
        if decl.storage_class == StorageClass.AUTO:
            self.error_reporter.error(
                decl.location,
                "'auto' storage class not allowed for functions"
            )
        elif decl.storage_class == StorageClass.REGISTER:
            self.error_reporter.error(
                decl.location,
                "'register' storage class not allowed for functions"
            )
        
        # Check if function is already declared
        existing = self.symbol_table.lookup_current_scope(decl.name)
        
        if existing is not None:
            # Check if it's a compatible redeclaration
            if existing.kind != SymbolKind.FUNCTION:
                self.error_reporter.error(
                    decl.location,
                    f"'{decl.name}' redeclared as different kind of symbol"
                )
                return
            
            # Check storage class compatibility
            # Static functions can't be redeclared as extern and vice versa
            # (This is a simplified check - full C99 rules are more complex)
            
            # Check if function types match
            # (In a full implementation, we'd check parameter types too)
            if decl.body is not None and existing.is_defined:
                self.error_reporter.error(
                    decl.location,
                    f"Redefinition of function '{decl.name}'"
                )
                return
            
            # Update definition status if this is a definition
            if decl.body is not None:
                existing.is_defined = True
        else:
            # Create function type
            param_types = tuple(param.param_type for param in decl.parameters)
            func_type = FunctionType(
                return_type=decl.return_type,
                parameter_types=param_types,
                is_variadic=decl.is_variadic,
                location=decl.location
            )
            
            # Create symbol
            symbol = Symbol(
                name=decl.name,
                symbol_type=func_type,
                kind=SymbolKind.FUNCTION,
                scope_level=0,  # Functions are always global
                location=decl.location,
                is_defined=decl.body is not None,
                is_used=False
            )
            
            # Add to symbol table
            self.symbol_table.declare(symbol)
        
        # If function has a body, analyze it
        if decl.body is not None:
            self.current_function = decl
            
            # Clear label tracking for this function
            self.function_labels = {}
            self.function_gotos = []
            
            # Enter function scope
            self.symbol_table.enter_scope()
            
            # Add parameters to scope
            for param in decl.parameters:
                if param.name is not None:  # Skip abstract declarators
                    param_symbol = Symbol(
                        name=param.name,
                        symbol_type=param.param_type,
                        kind=SymbolKind.PARAMETER,
                        scope_level=self.symbol_table.get_current_scope_level(),
                        location=param.location,
                        is_defined=True,
                        is_used=False
                    )
                    self.symbol_table.declare(param_symbol)
            
            # Analyze function body
            self._analyze_statement(decl.body)
            
            # Validate all goto statements reference existing labels
            for goto_stmt in self.function_gotos:
                if goto_stmt.label not in self.function_labels:
                    self.error_reporter.error(
                        goto_stmt.location,
                        f"Label '{goto_stmt.label}' used but not defined"
                    )
            
            # Exit function scope
            self.symbol_table.exit_scope()
            
            self.current_function = None
    
    def _analyze_struct_decl(self, decl: StructDecl) -> None:
        """Analyze a struct or union declaration.
        
        Args:
            decl: Struct/union declaration to analyze
        """
        if decl.name is not None:
            # Check if struct/union is already declared
            existing = self.symbol_table.lookup_current_scope(decl.name)
            
            if existing is not None and existing.kind == SymbolKind.TYPE:
                # Check if this is a redefinition (both have members)
                if isinstance(existing.symbol_type, StructType):
                    if existing.symbol_type.is_complete and decl.members is not None:
                        self.error_reporter.error(
                            decl.location,
                            f"Redefinition of {'union' if decl.is_union else 'struct'} '{decl.name}'"
                        )
                        return
                    # If existing is incomplete and this has members, update it
                    if not existing.symbol_type.is_complete and decl.members is not None:
                        # Update the existing type with members
                        struct_type = existing.symbol_type
                        object.__setattr__(struct_type, 'members', decl.members)
                        object.__setattr__(struct_type, 'is_complete', True)
                        
                        # Calculate layout
                        from src.semantic.struct_layout import StructLayoutCalculator
                        layout_calc = StructLayoutCalculator()
                        layout_calc.calculate_layout(struct_type)
                        
                        existing.is_defined = True
                        return
            else:
                # Create symbol for struct/union type
                struct_type = StructType(
                    name=decl.name,
                    is_union=decl.is_union,
                    members=decl.members,
                    location=decl.location
                )
                
                # Calculate layout if members are present
                if decl.members is not None:
                    from src.semantic.struct_layout import StructLayoutCalculator
                    layout_calc = StructLayoutCalculator()
                    layout_calc.calculate_layout(struct_type)
                
                symbol = Symbol(
                    name=decl.name,
                    symbol_type=struct_type,
                    kind=SymbolKind.TYPE,
                    scope_level=self.symbol_table.get_current_scope_level(),
                    location=decl.location,
                    is_defined=decl.members is not None,
                    is_used=False
                )
                
                self.symbol_table.declare(symbol)
        
        # Analyze member declarations if present
        if decl.members is not None:
            for member in decl.members:
                # Members don't go in symbol table, but we check their types
                if member.initializer is not None:
                    self.error_reporter.error(
                        member.location,
                        f"Struct/union members cannot have initializers"
                    )
    
    def _analyze_enum_decl(self, decl: EnumDecl) -> None:
        """Analyze an enum declaration.
        
        Args:
            decl: Enum declaration to analyze
        """
        if decl.name is not None:
            # Create symbol for enum type
            from src.parser.ast_nodes import EnumType
            enum_type = EnumType(
                name=decl.name,
                enumerators=decl.enumerators,
                location=decl.location
            )
            
            symbol = Symbol(
                name=decl.name,
                symbol_type=enum_type,
                kind=SymbolKind.TYPE,
                scope_level=self.symbol_table.get_current_scope_level(),
                location=decl.location,
                is_defined=decl.enumerators is not None,
                is_used=False
            )
            
            self.symbol_table.declare(symbol)
        
        # Add enumerators to symbol table as constants
        if decl.enumerators is not None:
            for name, value in decl.enumerators:
                # Check if enumerator is already declared
                existing = self.symbol_table.lookup_current_scope(name)
                if existing is not None:
                    self.error_reporter.error(
                        decl.location,
                        f"Redeclaration of enumerator '{name}'"
                    )
                    continue
                
                # Enumerators have type int
                int_type = PrimitiveType(name='int', is_signed=True, 
                                        location=decl.location)
                
                enum_symbol = Symbol(
                    name=name,
                    symbol_type=int_type,
                    kind=SymbolKind.ENUM_CONSTANT,
                    scope_level=self.symbol_table.get_current_scope_level(),
                    location=decl.location,
                    is_defined=True,
                    is_used=False
                )
                
                self.symbol_table.declare(enum_symbol)
                
                # Check value expression if present
                if value is not None:
                    self.type_checker.check_expression(value)
    
    def _analyze_typedef_decl(self, decl: TypedefDecl) -> None:
        """Analyze a typedef declaration.
        
        Args:
            decl: Typedef declaration to analyze
        """
        # Check if typedef is already declared
        existing = self.symbol_table.lookup_current_scope(decl.name)
        if existing is not None:
            self.error_reporter.error(
                decl.location,
                f"Redeclaration of '{decl.name}'"
            )
            return
        
        # If typedef is for an enum type with enumerators, register them
        from src.parser.ast_nodes import EnumType
        if isinstance(decl.actual_type, EnumType) and decl.actual_type.enumerators is not None:
            for name, value in decl.actual_type.enumerators:
                # Check if enumerator is already declared
                existing_enum = self.symbol_table.lookup_current_scope(name)
                if existing_enum is not None:
                    self.error_reporter.error(
                        decl.location,
                        f"Redeclaration of enumerator '{name}'"
                    )
                    continue
                
                # Enumerators have type int
                int_type = PrimitiveType(name='int', is_signed=True, 
                                        location=decl.location)
                
                enum_symbol = Symbol(
                    name=name,
                    symbol_type=int_type,
                    kind=SymbolKind.ENUM_CONSTANT,
                    scope_level=self.symbol_table.get_current_scope_level(),
                    location=decl.location,
                    is_defined=True,
                    is_used=False
                )
                
                self.symbol_table.declare(enum_symbol)
                
                # Check value expression if present
                if value is not None:
                    self.type_checker.check_expression(value)
        
        # Create symbol
        symbol = Symbol(
            name=decl.name,
            symbol_type=decl.actual_type,
            kind=SymbolKind.TYPE,
            scope_level=self.symbol_table.get_current_scope_level(),
            location=decl.location,
            is_defined=True,
            is_used=False
        )
        
        self.symbol_table.declare(symbol)

    def _analyze_statement(self, stmt: Statement) -> None:
        """Analyze a statement.
        
        Args:
            stmt: Statement to analyze
        """
        if isinstance(stmt, CompoundStmt):
            self._analyze_compound_stmt(stmt)
        elif isinstance(stmt, ExpressionStmt):
            self._analyze_expression_stmt(stmt)
        elif isinstance(stmt, IfStmt):
            self._analyze_if_stmt(stmt)
        elif isinstance(stmt, WhileStmt):
            self._analyze_while_stmt(stmt)
        elif isinstance(stmt, DoWhileStmt):
            self._analyze_do_while_stmt(stmt)
        elif isinstance(stmt, ForStmt):
            self._analyze_for_stmt(stmt)
        elif isinstance(stmt, ReturnStmt):
            self._analyze_return_stmt(stmt)
        elif isinstance(stmt, BreakStmt):
            self._analyze_break_stmt(stmt)
        elif isinstance(stmt, ContinueStmt):
            self._analyze_continue_stmt(stmt)
        elif isinstance(stmt, SwitchStmt):
            self._analyze_switch_stmt(stmt)
        elif isinstance(stmt, CaseStmt):
            self._analyze_case_stmt(stmt)
        elif isinstance(stmt, GotoStmt):
            self._analyze_goto_stmt(stmt)
        elif isinstance(stmt, LabelStmt):
            self._analyze_label_stmt(stmt)
        elif isinstance(stmt, Declaration):
            # Declarations can appear as statements in C99
            self._analyze_declaration(stmt)
        else:
            self.error_reporter.error(
                stmt.location,
                f"Unknown statement type: {type(stmt).__name__}"
            )
    
    def _analyze_compound_stmt(self, stmt: CompoundStmt) -> None:
        """Analyze a compound statement (block).
        
        Args:
            stmt: Compound statement to analyze
        """
        # Check if this is a synthetic compound statement (multiple declarators)
        # These don't create a new scope
        is_synthetic = all(isinstance(s, VarDecl) for s in stmt.statements)
        
        # Enter new scope (unless synthetic)
        if not is_synthetic:
            self.symbol_table.enter_scope()
        
        # Analyze all statements in the block
        for s in stmt.statements:
            self._analyze_statement(s)
        
        # Exit scope (unless synthetic)
        if not is_synthetic:
            self.symbol_table.exit_scope()
    
    def _analyze_expression_stmt(self, stmt: ExpressionStmt) -> None:
        """Analyze an expression statement.
        
        Args:
            stmt: Expression statement to analyze
        """
        if stmt.expression is not None:
            self.type_checker.check_expression(stmt.expression)
    
    def _analyze_if_stmt(self, stmt: IfStmt) -> None:
        """Analyze an if statement.
        
        Args:
            stmt: If statement to analyze
        """
        # Check condition
        cond_type = self.type_checker.check_expression(stmt.condition)
        if cond_type is not None:
            from src.semantic.type_utils import is_scalar_type
            if not is_scalar_type(cond_type):
                self.error_reporter.error(
                    stmt.condition.location,
                    f"Condition must be scalar type"
                )
        
        # Analyze then branch
        self._analyze_statement(stmt.then_stmt)
        
        # Analyze else branch if present
        if stmt.else_stmt is not None:
            self._analyze_statement(stmt.else_stmt)
    
    def _analyze_while_stmt(self, stmt: WhileStmt) -> None:
        """Analyze a while statement.
        
        Args:
            stmt: While statement to analyze
        """
        # Check condition
        cond_type = self.type_checker.check_expression(stmt.condition)
        if cond_type is not None:
            from src.semantic.type_utils import is_scalar_type
            if not is_scalar_type(cond_type):
                self.error_reporter.error(
                    stmt.condition.location,
                    f"Condition must be scalar type"
                )
        
        # Analyze body
        self.in_loop += 1
        self._analyze_statement(stmt.body)
        self.in_loop -= 1
    
    def _analyze_do_while_stmt(self, stmt: DoWhileStmt) -> None:
        """Analyze a do-while statement.
        
        Args:
            stmt: Do-while statement to analyze
        """
        # Analyze body
        self.in_loop += 1
        self._analyze_statement(stmt.body)
        self.in_loop -= 1
        
        # Check condition
        cond_type = self.type_checker.check_expression(stmt.condition)
        if cond_type is not None:
            from src.semantic.type_utils import is_scalar_type
            if not is_scalar_type(cond_type):
                self.error_reporter.error(
                    stmt.condition.location,
                    f"Condition must be scalar type"
                )
    
    def _analyze_for_stmt(self, stmt: ForStmt) -> None:
        """Analyze a for statement.
        
        Args:
            stmt: For statement to analyze
        """
        # Enter scope for loop variable
        self.symbol_table.enter_scope()
        
        # Check init
        if stmt.init is not None:
            if isinstance(stmt.init, Declaration):
                self._analyze_declaration(stmt.init)
            else:
                self.type_checker.check_expression(stmt.init)
        
        # Check condition
        if stmt.condition is not None:
            cond_type = self.type_checker.check_expression(stmt.condition)
            if cond_type is not None:
                from src.semantic.type_utils import is_scalar_type
                if not is_scalar_type(cond_type):
                    self.error_reporter.error(
                        stmt.condition.location,
                        f"Condition must be scalar type"
                    )
        
        # Check increment
        if stmt.increment is not None:
            self.type_checker.check_expression(stmt.increment)
        
        # Analyze body
        self.in_loop += 1
        self._analyze_statement(stmt.body)
        self.in_loop -= 1
        
        # Exit scope
        self.symbol_table.exit_scope()
    
    def _analyze_return_stmt(self, stmt: ReturnStmt) -> None:
        """Analyze a return statement.
        
        Args:
            stmt: Return statement to analyze
        """
        if self.current_function is None:
            self.error_reporter.error(
                stmt.location,
                f"Return statement outside of function"
            )
            return
        
        return_type = self.current_function.return_type
        
        # Check return value
        if stmt.value is not None:
            value_type = self.type_checker.check_expression(stmt.value)
            
            # Check if return type is void
            from src.semantic.type_utils import is_void_type
            if is_void_type(return_type):
                self.error_reporter.error(
                    stmt.location,
                    f"Void function should not return a value"
                )
            elif value_type is not None:
                # Check if value type is compatible with return type
                self.type_checker.check_assignment(
                    return_type,
                    value_type,
                    stmt.value.location
                )
        else:
            # No return value
            from src.semantic.type_utils import is_void_type
            if not is_void_type(return_type):
                self.error_reporter.warning(
                    stmt.location,
                    f"Non-void function should return a value"
                )
    
    def _analyze_break_stmt(self, stmt: BreakStmt) -> None:
        """Analyze a break statement.
        
        Args:
            stmt: Break statement to analyze
        """
        if self.in_loop == 0 and self.in_switch == 0:
            suggestion = ErrorSuggestions.suggest_for_break_continue_outside_loop('break')
            self.error_reporter.error(
                stmt.location,
                f"Break statement not within loop or switch",
                suggestion=suggestion
            )
    
    def _analyze_continue_stmt(self, stmt: ContinueStmt) -> None:
        """Analyze a continue statement.
        
        Args:
            stmt: Continue statement to analyze
        """
        if self.in_loop == 0:
            suggestion = ErrorSuggestions.suggest_for_break_continue_outside_loop('continue')
            self.error_reporter.error(
                stmt.location,
                f"Continue statement not within loop",
                suggestion=suggestion
            )
    
    def _analyze_switch_stmt(self, stmt: SwitchStmt) -> None:
        """Analyze a switch statement.
        
        Args:
            stmt: Switch statement to analyze
        """
        # Check condition
        cond_type = self.type_checker.check_expression(stmt.condition)
        if cond_type is not None:
            from src.semantic.type_utils import is_integer_type
            if not is_integer_type(cond_type):
                self.error_reporter.error(
                    stmt.condition.location,
                    f"Switch condition must be integer type"
                )
        
        # Analyze body
        self.in_switch += 1
        self._analyze_statement(stmt.body)
        self.in_switch -= 1
    
    def _analyze_case_stmt(self, stmt: CaseStmt) -> None:
        """Analyze a case statement.
        
        Args:
            stmt: Case statement to analyze
        """
        if self.in_switch == 0:
            self.error_reporter.error(
                stmt.location,
                f"Case label not within switch statement"
            )
        
        # Check case value if present (None for default)
        if stmt.value is not None:
            self.type_checker.check_expression(stmt.value)
        
        # Analyze statement following case
        self._analyze_statement(stmt.statement)
    
    def _analyze_goto_stmt(self, stmt: GotoStmt) -> None:
        """Analyze a goto statement.
        
        Args:
            stmt: Goto statement to analyze
        """
        # Track goto for later validation (after all labels are collected)
        self.function_gotos.append(stmt)
    
    def _analyze_label_stmt(self, stmt: LabelStmt) -> None:
        """Analyze a label statement.
        
        Args:
            stmt: Label statement to analyze
        """
        # Check for duplicate labels in the same function
        if stmt.label in self.function_labels:
            self.error_reporter.error(
                stmt.location,
                f"Duplicate label '{stmt.label}'"
            )
            prev_label = self.function_labels[stmt.label]
            self.error_reporter.error(
                prev_label.location,
                f"Previous definition of label '{stmt.label}' was here"
            )
        else:
            self.function_labels[stmt.label] = stmt
        
        # Analyze the statement following the label
        self._analyze_statement(stmt.statement)
    
    def _check_unused_symbols(self) -> None:
        """Check for unused symbols and generate warnings."""
        # Get all symbols from global scope
        for symbol in self.symbol_table.global_scope.get_all_symbols():
            if not symbol.is_used and symbol.kind == SymbolKind.VARIABLE:
                self.error_reporter.warning(
                    symbol.location,
                    f"Unused variable '{symbol.name}'"
                )
            elif not symbol.is_used and symbol.kind == SymbolKind.FUNCTION:
                # Don't warn about unused functions (might be library functions)
                pass

    def _check_array_initialization(self, array_type: 'ArrayType', initializer: 'Expression', decl: 'VarDecl') -> None:
        """Check array initialization for correctness.
        
        Handles:
        - Aggregate initialization: int arr[5] = {1, 2, 3, 4, 5}
        - Partial initialization: int arr[5] = {1, 2} (rest zero-filled)
        - Size inference: int arr[] = {1, 2, 3}
        - String initialization: char s[] = "hello"
        - Nested initialization: int matrix[2][3] = {{1,2,3}, {4,5,6}}
        
        Args:
            array_type: The array type being initialized
            initializer: The initializer expression
            decl: The variable declaration (for updating size if needed)
        """
        from src.parser.ast_nodes import InitializerList, Literal, ArrayType
        
        # String initialization for char arrays
        if isinstance(initializer, Literal) and initializer.literal_type == 'string':
            # Check if it's a char array
            from src.semantic.type_utils import get_array_base_type
            base_type = get_array_base_type(array_type)
            
            if hasattr(base_type, 'name') and base_type.name == 'char':
                # String literal initialization
                string_length = len(initializer.value) + 1  # +1 for null terminator
                
                if array_type.size_value is None:
                    # Infer size from string: char s[] = "hello" -> size = 6
                    array_type.size_value = string_length
                elif array_type.size_value < string_length:
                    # String too long for array
                    self.error_reporter.error(
                        initializer.location,
                        f"String literal too long for array (need {string_length}, have {array_type.size_value})"
                    )
                
                # Type check the initializer
                self.type_checker.check_expression(initializer)
                return
            else:
                self.error_reporter.error(
                    initializer.location,
                    f"Cannot initialize non-char array with string literal"
                )
                return
        
        # Aggregate initialization with initializer list
        if isinstance(initializer, InitializerList):
            num_initializers = len(initializer.initializers)
            
            # Check if array size needs to be inferred
            if array_type.size_value is None:
                # Infer size from initializer: int arr[] = {1, 2, 3} -> size = 3
                array_type.size_value = num_initializers
            elif num_initializers > array_type.size_value:
                # Too many initializers
                self.error_reporter.error(
                    initializer.location,
                    f"Too many initializers for array (expected {array_type.size_value}, got {num_initializers})"
                )
            
            # Check each initializer
            for i, init_expr in enumerate(initializer.initializers):
                # For multi-dimensional arrays, element type is also an array
                if isinstance(array_type.element_type, ArrayType):
                    # Nested array initialization
                    self._check_array_initialization(array_type.element_type, init_expr, decl)
                else:
                    # Check element type compatibility
                    init_type = self.type_checker.check_expression(init_expr)
                    if init_type is not None:
                        self.type_checker.check_assignment(
                            array_type.element_type,
                            init_type,
                            init_expr.location
                        )
            
            return
        
        # Single expression initialization (not allowed for arrays in C)
        self.error_reporter.error(
            initializer.location,
            f"Array must be initialized with initializer list or string literal"
        )

    def _resolve_struct_types(self, type_obj):
        """Recursively resolve struct/union types by looking up complete definitions.
        
        Args:
            type_obj: The type to resolve
            
        Returns:
            The resolved type
        """
        from src.parser.ast_nodes import PointerType, ArrayType, FunctionType
        
        if isinstance(type_obj, StructType):
            # If struct has a name but is incomplete, try to look up the complete definition
            if type_obj.name and not type_obj.is_complete:
                struct_symbol = self.symbol_table.lookup(type_obj.name)
                if struct_symbol and struct_symbol.kind == SymbolKind.TYPE:
                    if isinstance(struct_symbol.symbol_type, StructType):
                        # Use the complete definition from the symbol table
                        return struct_symbol.symbol_type
            return type_obj
        elif isinstance(type_obj, PointerType):
            # Resolve pointee type
            resolved_pointee = self._resolve_struct_types(type_obj.pointee_type)
            if resolved_pointee != type_obj.pointee_type:
                return PointerType(
                    location=type_obj.location,
                    pointee_type=resolved_pointee,
                    qualifiers=type_obj.qualifiers
                )
            return type_obj
        elif isinstance(type_obj, ArrayType):
            # Resolve element type
            resolved_element = self._resolve_struct_types(type_obj.element_type)
            if resolved_element != type_obj.element_type:
                return ArrayType(
                    location=type_obj.location,
                    element_type=resolved_element,
                    size=type_obj.size,
                    is_vla=type_obj.is_vla,
                    size_value=type_obj.size_value,
                    qualifiers=type_obj.qualifiers
                )
            return type_obj
        elif isinstance(type_obj, FunctionType):
            # Resolve return type and parameter types
            resolved_return = self._resolve_struct_types(type_obj.return_type)
            resolved_params = tuple(self._resolve_struct_types(p) for p in type_obj.parameter_types)
            if resolved_return != type_obj.return_type or resolved_params != type_obj.parameter_types:
                return FunctionType(
                    location=type_obj.location,
                    return_type=resolved_return,
                    parameter_types=resolved_params,
                    is_variadic=type_obj.is_variadic
                )
            return type_obj
        else:
            return type_obj

    def _check_struct_initialization(self, struct_type: 'StructType', initializer: 'Expression', decl: 'VarDecl') -> None:
        """Check struct/union initialization for correctness.
        
        Handles:
        - Aggregate initialization: struct Point p = {10, 20}
        - Partial initialization: struct Point p = {10} (rest zero-filled)
        - Designated initializers: struct Point p = {.x = 10, .y = 20} (C99 feature)
        - Nested struct initialization
        
        Args:
            struct_type: The struct/union type being initialized
            initializer: The initializer expression
            decl: The variable declaration (for error reporting)
        """
        from src.parser.ast_nodes import InitializerList, StructType
        
        # Struct must be complete to initialize
        if not struct_type.is_complete:
            self.error_reporter.error(
                initializer.location,
                f"Cannot initialize incomplete {'union' if struct_type.is_union else 'struct'} type"
            )
            return
        
        # Must use initializer list for struct initialization
        if not isinstance(initializer, InitializerList):
            self.error_reporter.error(
                initializer.location,
                f"Struct/union must be initialized with initializer list"
            )
            return
        
        # Check if this is designated initialization (C99 feature)
        # For now, we'll support positional initialization
        # TODO: Add support for designated initializers (.member = value)
        
        num_initializers = len(initializer.initializers)
        num_members = len(struct_type.members) if struct_type.members else 0
        
        if num_initializers > num_members:
            self.error_reporter.error(
                initializer.location,
                f"Too many initializers for {'union' if struct_type.is_union else 'struct'} "
                f"(expected {num_members}, got {num_initializers})"
            )
        
        # For unions, only the first member can be initialized
        if struct_type.is_union and num_initializers > 1:
            self.error_reporter.warning(
                initializer.location,
                f"Excess initializers for union (only first member is initialized)"
            )
        
        # Check each initializer against corresponding member
        for i, init_expr in enumerate(initializer.initializers):
            if i >= num_members:
                break
            
            member = struct_type.members[i]
            
            # For nested structs, recursively check initialization
            if isinstance(member.var_type, StructType):
                if isinstance(init_expr, InitializerList):
                    self._check_struct_initialization(member.var_type, init_expr, decl)
                else:
                    self.error_reporter.error(
                        init_expr.location,
                        f"Nested struct member '{member.name}' requires initializer list"
                    )
            else:
                # Check member type compatibility
                init_type = self.type_checker.check_expression(init_expr)
                if init_type is not None:
                    self.type_checker.check_assignment(
                        member.var_type,
                        init_type,
                        init_expr.location
                    )
