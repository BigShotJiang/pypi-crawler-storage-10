"""Symbol table implementation for scope management."""

from typing import Optional, Dict, List
from dataclasses import dataclass, field

from src.semantic.symbol import Symbol
from src.semantic.symbol_kinds import SymbolKind
from src.utils.source_location import SourceLocation


@dataclass
class Scope:
    """Represents a single scope level.
    
    Attributes:
        level: Nesting level (0 for global scope)
        symbols: Dictionary mapping symbol names to Symbol objects
        parent: Parent scope (None for global scope)
    """
    level: int
    symbols: Dict[str, Symbol] = field(default_factory=dict)
    parent: Optional['Scope'] = None
    
    def declare(self, symbol: Symbol) -> None:
        """Add a symbol to this scope.
        
        Args:
            symbol: Symbol to add
        """
        self.symbols[symbol.name] = symbol
    
    def lookup_local(self, name: str) -> Optional[Symbol]:
        """Look up a symbol in this scope only.
        
        Args:
            name: Symbol name to look up
            
        Returns:
            Symbol if found in this scope, None otherwise
        """
        return self.symbols.get(name)
    
    def get_all_symbols(self) -> List[Symbol]:
        """Get all symbols in this scope.
        
        Returns:
            List of all symbols in this scope
        """
        return list(self.symbols.values())


class SymbolTable:
    """Manages symbol scopes and lookups.
    
    The symbol table maintains a stack of scopes, with the global scope
    at the bottom and nested scopes on top. It supports entering and
    exiting scopes, declaring symbols, and looking up symbols with
    proper shadowing rules.
    """
    
    def __init__(self):
        """Initialize symbol table with global scope."""
        self.global_scope = Scope(level=0)
        self.current_scope = self.global_scope
        self.scope_stack: List[Scope] = [self.global_scope]
    
    def enter_scope(self) -> None:
        """Enter a new nested scope."""
        new_level = self.current_scope.level + 1
        new_scope = Scope(level=new_level, parent=self.current_scope)
        self.scope_stack.append(new_scope)
        self.current_scope = new_scope
    
    def exit_scope(self) -> List[Symbol]:
        """Exit the current scope and return to parent.
        
        Returns:
            List of symbols that were in the exited scope
            
        Raises:
            RuntimeError: If attempting to exit global scope
        """
        if len(self.scope_stack) <= 1:
            raise RuntimeError("Cannot exit global scope")
        
        exited_scope = self.scope_stack.pop()
        self.current_scope = self.scope_stack[-1]
        return exited_scope.get_all_symbols()
    
    def declare(self, symbol: Symbol) -> None:
        """Declare a symbol in the current scope.
        
        Args:
            symbol: Symbol to declare
        """
        symbol.scope_level = self.current_scope.level
        self.current_scope.declare(symbol)
    
    def lookup(self, name: str) -> Optional[Symbol]:
        """Look up a symbol by name, searching from current scope upward.
        
        This implements proper shadowing: if a symbol is found in an inner
        scope, it shadows any symbol with the same name in outer scopes.
        
        Args:
            name: Symbol name to look up
            
        Returns:
            Symbol if found, None otherwise
        """
        scope = self.current_scope
        while scope is not None:
            symbol = scope.lookup_local(name)
            if symbol is not None:
                return symbol
            scope = scope.parent
        return None
    
    def lookup_current_scope(self, name: str) -> Optional[Symbol]:
        """Look up a symbol in the current scope only.
        
        Args:
            name: Symbol name to look up
            
        Returns:
            Symbol if found in current scope, None otherwise
        """
        return self.current_scope.lookup_local(name)
    
    def is_global_scope(self) -> bool:
        """Check if currently in global scope.
        
        Returns:
            True if in global scope, False otherwise
        """
        return self.current_scope.level == 0
    
    def get_current_scope_level(self) -> int:
        """Get the current scope nesting level.
        
        Returns:
            Current scope level (0 for global)
        """
        return self.current_scope.level
    
    def get_all_symbols_in_scope(self) -> List[Symbol]:
        """Get all symbols in the current scope.
        
        Returns:
            List of symbols in current scope
        """
        return self.current_scope.get_all_symbols()
    
    def mark_used(self, name: str) -> None:
        """Mark a symbol as used.
        
        Args:
            name: Name of symbol to mark as used
        """
        symbol = self.lookup(name)
        if symbol is not None:
            symbol.is_used = True
    
    def get_all_symbols(self) -> List[Symbol]:
        """Get all symbols from all scopes.
        
        Returns:
            List of all symbols in all scopes
        """
        all_symbols = []
        for scope in self.scope_stack:
            all_symbols.extend(scope.get_all_symbols())
        return all_symbols
