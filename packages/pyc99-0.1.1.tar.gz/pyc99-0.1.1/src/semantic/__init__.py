"""Semantic analysis module for type checking and validation."""

from src.semantic.symbol import Symbol
from src.semantic.symbol_kinds import SymbolKind
from src.semantic.symbol_table import SymbolTable, Scope
from src.semantic.type_checker import TypeChecker
from src.semantic.analyzer import SemanticAnalyzer
from src.semantic.type_utils import (
    types_equal,
    is_integer_type,
    is_floating_type,
    is_arithmetic_type,
    is_pointer_type,
    is_array_type,
    is_function_type,
    is_struct_or_union_type,
    is_void_type,
    is_scalar_type,
    get_pointer_base_type,
    get_array_element_type,
    get_type_size_rank,
    promote_type,
    get_common_type,
    can_convert_implicitly,
)

__all__ = [
    'Symbol',
    'SymbolKind',
    'SymbolTable',
    'Scope',
    'TypeChecker',
    'SemanticAnalyzer',
    'types_equal',
    'is_integer_type',
    'is_floating_type',
    'is_arithmetic_type',
    'is_pointer_type',
    'is_array_type',
    'is_function_type',
    'is_struct_or_union_type',
    'is_void_type',
    'is_scalar_type',
    'get_pointer_base_type',
    'get_array_element_type',
    'get_type_size_rank',
    'promote_type',
    'get_common_type',
    'can_convert_implicitly',
]
