"""Symbol kind definitions for semantic analysis."""

from enum import Enum, auto


class SymbolKind(Enum):
    """Enumeration of symbol kinds in the symbol table."""
    
    VARIABLE = auto()      # Local or global variable
    PARAMETER = auto()     # Function parameter
    FUNCTION = auto()      # Function declaration/definition
    TYPE = auto()          # Type definition (typedef, struct, union, enum)
    ENUM_CONSTANT = auto() # Enumeration constant
    LABEL = auto()         # Label for goto statements
