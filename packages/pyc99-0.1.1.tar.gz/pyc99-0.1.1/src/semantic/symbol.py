"""Symbol class for symbol table entries."""

from dataclasses import dataclass
from typing import Optional

from src.parser.ast_nodes import Type
from src.semantic.symbol_kinds import SymbolKind
from src.utils.source_location import SourceLocation


@dataclass
class Symbol:
    """Represents a symbol in the symbol table.
    
    Attributes:
        name: Symbol name
        symbol_type: Type of the symbol
        kind: Kind of symbol (variable, function, type, etc.)
        scope_level: Nesting level of the scope where symbol is declared
        location: Source location where symbol was declared
        is_defined: Whether symbol has a definition (vs just declaration)
        is_used: Whether symbol has been referenced
    """
    name: str
    symbol_type: Type
    kind: SymbolKind
    scope_level: int
    location: SourceLocation
    is_defined: bool = True
    is_used: bool = False
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return (f"Symbol(name={self.name}, kind={self.kind.name}, "
                f"type={self.symbol_type.__class__.__name__}, "
                f"scope={self.scope_level})")
