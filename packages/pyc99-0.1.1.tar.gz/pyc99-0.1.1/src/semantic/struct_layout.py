"""Struct and union layout calculation.

This module handles computing the memory layout of struct and union types,
including member offsets, padding, and total size according to C99 rules
and platform-specific alignment requirements.
"""

from typing import Dict, Optional
import sys

from src.parser.ast_nodes import (
    StructType, VarDecl, Type, PrimitiveType, PointerType, ArrayType, FunctionType
)


class StructLayoutCalculator:
    """Calculates memory layout for struct and union types.
    
    Handles:
    - Member offset calculation with proper alignment
    - Padding insertion between members
    - Total struct/union size calculation
    - Platform-specific alignment rules
    
    Attributes:
        target_platform: Target platform ('x86' or 'arm')
        pointer_size: Size of pointers in bytes
        default_alignment: Default alignment for the platform
    """
    
    def __init__(self, target_platform: str = 'x86'):
        """Initialize layout calculator.
        
        Args:
            target_platform: Target platform ('x86' or 'arm')
        """
        self.target_platform = target_platform
        
        # Platform-specific settings
        if target_platform == 'x86':
            self.pointer_size = 8  # 64-bit pointers
            self.default_alignment = 8  # x86-64 default alignment
        elif target_platform == 'arm':
            self.pointer_size = 4  # 32-bit pointers (ARMv7)
            self.default_alignment = 4  # ARM default alignment
        else:
            # Default to x86-64
            self.pointer_size = 8
            self.default_alignment = 8
    
    def calculate_layout(self, struct_type: StructType) -> None:
        """Calculate and set the layout for a struct or union type.
        
        This modifies the struct_type in place, setting:
        - member_offsets: Dictionary mapping member names to byte offsets
        - size: Total size in bytes
        - alignment: Required alignment in bytes
        
        Args:
            struct_type: Struct or union type to calculate layout for
        """
        if struct_type.members is None:
            # Incomplete type - no layout to calculate
            return
        
        if struct_type.is_union:
            self._calculate_union_layout(struct_type)
        else:
            self._calculate_struct_layout(struct_type)
    
    def _calculate_struct_layout(self, struct_type: StructType) -> None:
        """Calculate layout for a struct type.
        
        Members are laid out sequentially with padding for alignment.
        
        Args:
            struct_type: Struct type to calculate layout for
        """
        member_offsets: Dict[str, int] = {}
        current_offset = 0
        max_alignment = 1
        
        for member in struct_type.members:
            # Get member type alignment
            member_alignment = self.get_type_alignment(member.var_type)
            max_alignment = max(max_alignment, member_alignment)
            
            # Align current offset to member alignment
            current_offset = self._align_up(current_offset, member_alignment)
            
            # Store member offset
            member_offsets[member.name] = current_offset
            
            # Advance offset by member size
            member_size = self.get_type_size(member.var_type)
            current_offset += member_size
        
        # Add trailing padding to align struct size to its alignment
        total_size = self._align_up(current_offset, max_alignment)
        
        # Update struct type with layout information
        # Use object.__setattr__ to bypass frozen dataclass
        object.__setattr__(struct_type, 'member_offsets', member_offsets)
        object.__setattr__(struct_type, 'size', total_size)
        object.__setattr__(struct_type, 'alignment', max_alignment)
    
    def _calculate_union_layout(self, struct_type: StructType) -> None:
        """Calculate layout for a union type.
        
        All members share the same offset (0), and the union size is the
        maximum of all member sizes.
        
        Args:
            struct_type: Union type to calculate layout for
        """
        member_offsets: Dict[str, int] = {}
        max_size = 0
        max_alignment = 1
        
        for member in struct_type.members:
            # All members start at offset 0 in a union
            member_offsets[member.name] = 0
            
            # Track maximum size and alignment
            member_size = self.get_type_size(member.var_type)
            member_alignment = self.get_type_alignment(member.var_type)
            
            max_size = max(max_size, member_size)
            max_alignment = max(max_alignment, member_alignment)
        
        # Union size must be aligned to its alignment requirement
        total_size = self._align_up(max_size, max_alignment)
        
        # Update union type with layout information
        object.__setattr__(struct_type, 'member_offsets', member_offsets)
        object.__setattr__(struct_type, 'size', total_size)
        object.__setattr__(struct_type, 'alignment', max_alignment)
    
    def get_type_size(self, type_obj: Type) -> int:
        """Get the size of a type in bytes.
        
        Args:
            type_obj: Type to get size of
            
        Returns:
            Size in bytes
        """
        if isinstance(type_obj, PrimitiveType):
            return self._get_primitive_size(type_obj)
        elif isinstance(type_obj, PointerType):
            return self.pointer_size
        elif isinstance(type_obj, ArrayType):
            if type_obj.size_value is None:
                # Incomplete array type - size unknown
                return 0
            element_size = self.get_type_size(type_obj.element_type)
            return element_size * type_obj.size_value
        elif isinstance(type_obj, StructType):
            if type_obj.size is not None:
                return type_obj.size
            # If size not computed yet, calculate it
            if type_obj.members is not None:
                self.calculate_layout(type_obj)
                return type_obj.size if type_obj.size is not None else 0
            return 0  # Incomplete type
        elif isinstance(type_obj, FunctionType):
            # Functions don't have a size, but function pointers do
            return self.pointer_size
        else:
            # Unknown type - return default
            return self.default_alignment
    
    def get_type_alignment(self, type_obj: Type) -> int:
        """Get the alignment requirement of a type in bytes.
        
        Args:
            type_obj: Type to get alignment of
            
        Returns:
            Alignment in bytes
        """
        if isinstance(type_obj, PrimitiveType):
            return self._get_primitive_alignment(type_obj)
        elif isinstance(type_obj, PointerType):
            return self.pointer_size
        elif isinstance(type_obj, ArrayType):
            # Array alignment is same as element alignment
            return self.get_type_alignment(type_obj.element_type)
        elif isinstance(type_obj, StructType):
            if type_obj.alignment is not None:
                return type_obj.alignment
            # If alignment not computed yet, calculate it
            if type_obj.members is not None:
                self.calculate_layout(type_obj)
                return type_obj.alignment if type_obj.alignment is not None else self.default_alignment
            return self.default_alignment  # Incomplete type
        elif isinstance(type_obj, FunctionType):
            # Functions don't have alignment, but function pointers do
            return self.pointer_size
        else:
            # Unknown type - return default alignment
            return self.default_alignment
    
    def _get_primitive_size(self, prim_type: PrimitiveType) -> int:
        """Get size of a primitive type.
        
        Args:
            prim_type: Primitive type
            
        Returns:
            Size in bytes
        """
        name = prim_type.name
        size_mod = prim_type.size_modifier
        
        if name == 'void':
            return 1  # void has size 1 for pointer arithmetic
        elif name == 'char':
            return 1
        elif name == 'short' or (name == 'int' and size_mod == 'short'):
            return 2
        elif name == 'int':
            if size_mod == 'long':
                return 8 if self.target_platform == 'x86' else 4
            elif size_mod == 'long long':
                return 8
            else:
                return 4
        elif name == 'long':
            if size_mod == 'long':  # long long
                return 8
            else:
                return 8 if self.target_platform == 'x86' else 4
        elif name == 'float':
            return 4
        elif name == 'double':
            if size_mod == 'long':  # long double
                return 16 if self.target_platform == 'x86' else 8
            else:
                return 8
        else:
            return 4  # Default
    
    def _get_primitive_alignment(self, prim_type: PrimitiveType) -> int:
        """Get alignment of a primitive type.
        
        Args:
            prim_type: Primitive type
            
        Returns:
            Alignment in bytes
        """
        # For most types, alignment equals size (up to platform default)
        size = self._get_primitive_size(prim_type)
        return min(size, self.default_alignment)
    
    def _align_up(self, offset: int, alignment: int) -> int:
        """Align an offset up to the next multiple of alignment.
        
        Args:
            offset: Current offset
            alignment: Required alignment
            
        Returns:
            Aligned offset
        """
        if alignment == 0:
            return offset
        return ((offset + alignment - 1) // alignment) * alignment
