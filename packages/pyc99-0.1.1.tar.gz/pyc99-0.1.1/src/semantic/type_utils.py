"""Type utility functions for semantic analysis."""

from typing import Optional

from src.parser.ast_nodes import (
    Type, PrimitiveType, PointerType, ArrayType, FunctionType,
    StructType, EnumType, TypedefType
)


def resolve_typedef(type_obj: Type, symbol_table=None) -> Type:
    """Resolve a typedef to its actual type.
    
    Args:
        type_obj: Type to resolve (may be TypedefType)
        symbol_table: Symbol table for looking up typedef definitions (optional)
        
    Returns:
        The resolved type (follows typedef chain to the actual type)
    """
    # Follow typedef chain
    while isinstance(type_obj, TypedefType):
        if type_obj.actual_type is not None:
            type_obj = type_obj.actual_type
        elif symbol_table is not None:
            # Try to resolve from symbol table
            symbol = symbol_table.lookup(type_obj.name)
            if symbol is not None and symbol.symbol_type is not None:
                type_obj = symbol.symbol_type
            else:
                # Can't resolve further
                break
        else:
            # Can't resolve without symbol table
            break
    
    return type_obj


def types_equal(type1: Type, type2: Type) -> bool:
    """Check if two types are equal.
    
    Args:
        type1: First type
        type2: Second type
        
    Returns:
        True if types are equal, False otherwise
    """
    # Handle None cases
    if type1 is None or type2 is None:
        return type1 == type2
    
    # Must be same type class
    if type(type1) != type(type2):
        return False
    
    if isinstance(type1, PrimitiveType):
        # For type equality, qualifiers should match
        return (type1.name == type2.name and
                type1.is_signed == type2.is_signed and
                type1.size_modifier == type2.size_modifier and
                type1.qualifiers == type2.qualifiers)
    
    elif isinstance(type1, PointerType):
        # For pointer equality, both pointee type and qualifiers should match
        return (types_equal(type1.pointee_type, type2.pointee_type) and
                type1.qualifiers == type2.qualifiers)
    
    elif isinstance(type1, ArrayType):
        # Array types are equal if element types match
        # (size comparison is complex and not always required)
        return types_equal(type1.element_type, type2.element_type)
    
    elif isinstance(type1, FunctionType):
        if not types_equal(type1.return_type, type2.return_type):
            return False
        if len(type1.parameter_types) != len(type2.parameter_types):
            return False
        if type1.is_variadic != type2.is_variadic:
            return False
        return all(types_equal(p1, p2) 
                  for p1, p2 in zip(type1.parameter_types, type2.parameter_types))
    
    elif isinstance(type1, StructType):
        # Struct types are equal if they have the same name
        # (structural equality is more complex)
        return type1.name == type2.name and type1.is_union == type2.is_union
    
    elif isinstance(type1, EnumType):
        # Enum types are equal if they have the same name
        return type1.name == type2.name
    
    elif isinstance(type1, TypedefType):
        # Compare actual types if resolved
        if type1.actual_type and type2.actual_type:
            return types_equal(type1.actual_type, type2.actual_type)
        return type1.name == type2.name
    
    return False


def is_integer_type(type_obj: Type) -> bool:
    """Check if a type is an integer type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is an integer type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    
    if isinstance(type_obj, PrimitiveType):
        return type_obj.name in ('int', 'char', 'short', 'long')
    elif isinstance(type_obj, EnumType):
        return True  # Enums are integer types
    return False


def is_floating_type(type_obj: Type) -> bool:
    """Check if a type is a floating-point type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a floating-point type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    
    if isinstance(type_obj, PrimitiveType):
        return type_obj.name in ('float', 'double')
    return False


def is_arithmetic_type(type_obj: Type) -> bool:
    """Check if a type is an arithmetic type (integer or floating).
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is an arithmetic type, False otherwise
    """
    return is_integer_type(type_obj) or is_floating_type(type_obj)


def is_pointer_type(type_obj: Type) -> bool:
    """Check if a type is a pointer type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a pointer type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    return isinstance(type_obj, PointerType)


def is_array_type(type_obj: Type) -> bool:
    """Check if a type is an array type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is an array type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    return isinstance(type_obj, ArrayType)


def is_function_type(type_obj: Type) -> bool:
    """Check if a type is a function type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a function type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    return isinstance(type_obj, FunctionType)


def is_struct_or_union_type(type_obj: Type) -> bool:
    """Check if a type is a struct or union type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a struct or union type, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    return isinstance(type_obj, StructType)


def is_void_type(type_obj: Type) -> bool:
    """Check if a type is void.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is void, False otherwise
    """
    # Resolve typedef
    type_obj = resolve_typedef(type_obj)
    return isinstance(type_obj, PrimitiveType) and type_obj.name == 'void'


def is_scalar_type(type_obj: Type) -> bool:
    """Check if a type is a scalar type (arithmetic or pointer).
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a scalar type, False otherwise
    """
    return is_arithmetic_type(type_obj) or is_pointer_type(type_obj)


def get_pointer_base_type(type_obj: Type) -> Optional[Type]:
    """Get the base type of a pointer.
    
    Args:
        type_obj: Pointer type
        
    Returns:
        Base type if type_obj is a pointer, None otherwise
    """
    if isinstance(type_obj, PointerType):
        return type_obj.pointee_type
    return None


def get_array_element_type(type_obj: Type) -> Optional[Type]:
    """Get the element type of an array.
    
    Args:
        type_obj: Array type
        
    Returns:
        Element type if type_obj is an array, None otherwise
    """
    if isinstance(type_obj, ArrayType):
        return type_obj.element_type
    return None


def get_type_size_rank(type_obj: Type) -> int:
    """Get the size rank of a type for integer promotion.
    
    Higher rank means larger type. Used for determining result types
    in arithmetic operations.
    
    Args:
        type_obj: Type to rank
        
    Returns:
        Integer rank (higher = larger type)
    """
    if not isinstance(type_obj, PrimitiveType):
        return 0
    
    # Size ranks for integer promotion
    ranks = {
        'char': 1,
        'short': 2,
        'int': 3,
        'long': 4,
        'float': 5,
        'double': 6,
    }
    
    base_rank = ranks.get(type_obj.name, 0)
    
    # Adjust for size modifiers
    if type_obj.size_modifier == 'long long':
        base_rank += 2
    elif type_obj.size_modifier == 'long':
        base_rank += 1
    
    return base_rank


def promote_type(type_obj: Type) -> Type:
    """Apply integer promotion to a type.
    
    Integer types smaller than int are promoted to int.
    
    Args:
        type_obj: Type to promote
        
    Returns:
        Promoted type
    """
    if isinstance(type_obj, PrimitiveType):
        if type_obj.name in ('char', 'short'):
            return PrimitiveType(
                name='int',
                is_signed=True,
                size_modifier=None,
                location=type_obj.location
            )
    return type_obj


def get_common_type(type1: Type, type2: Type) -> Optional[Type]:
    """Get the common type for arithmetic operations.
    
    Implements usual arithmetic conversions from C99.
    
    Args:
        type1: First type
        type2: Second type
        
    Returns:
        Common type, or None if types are incompatible
    """
    # Promote both types
    type1 = promote_type(type1)
    type2 = promote_type(type2)
    
    # If types are equal, return either one
    if types_equal(type1, type2):
        return type1
    
    # If either is double, result is double
    if is_floating_type(type1) or is_floating_type(type2):
        rank1 = get_type_size_rank(type1)
        rank2 = get_type_size_rank(type2)
        return type1 if rank1 >= rank2 else type2
    
    # Both are integers - return the larger type
    if is_integer_type(type1) and is_integer_type(type2):
        rank1 = get_type_size_rank(type1)
        rank2 = get_type_size_rank(type2)
        return type1 if rank1 >= rank2 else type2
    
    return None


def can_convert_implicitly(from_type: Type, to_type: Type) -> bool:
    """Check if a type can be implicitly converted to another type.
    
    Implements C99 implicit conversion rules including const correctness:
    - Can add const but not remove it
    - Can convert between arithmetic types
    - Can convert pointers with proper const handling
    - Can convert function to function pointer (function-to-pointer decay)
    - Can convert compatible function pointers
    
    Args:
        from_type: Source type
        to_type: Target type
        
    Returns:
        True if implicit conversion is allowed, False otherwise
    """
    # Resolve typedefs first
    from_type = resolve_typedef(from_type)
    to_type = resolve_typedef(to_type)
    
    # Same types can always convert
    if types_equal(from_type, to_type):
        return True
    
    # Arithmetic types can convert to other arithmetic types
    if is_arithmetic_type(from_type) and is_arithmetic_type(to_type):
        return True
    
    # Function to function pointer decay
    # In C, function names automatically decay to function pointers
    if is_function_type(from_type) and is_pointer_type(to_type):
        to_base = get_pointer_base_type(to_type)
        if is_function_type(to_base):
            # Check if function types are compatible
            return types_equal(from_type, to_base)
    
    # Function pointer to function pointer conversion
    if is_pointer_type(from_type) and is_pointer_type(to_type):
        from_base = get_pointer_base_type(from_type)
        to_base = get_pointer_base_type(to_type)
        
        # Function pointer conversions
        if is_function_type(from_base) and is_function_type(to_base):
            # Function pointers must have compatible types
            return types_equal(from_base, to_base)
        
        # Pointer to void* conversion (can add const)
        if is_void_type(to_base):
            # Check const correctness: can't remove const
            if isinstance(from_type, PointerType) and isinstance(to_type, PointerType):
                # If from is const, to must be const
                from src.parser.ast_nodes import TypeQualifier
                if TypeQualifier.CONST in from_type.qualifiers:
                    if TypeQualifier.CONST not in to_type.qualifiers:
                        return False
            return True
        
        # void* to pointer conversion (can add const)
        if is_void_type(from_base):
            return True
        
        # Pointer type conversion with const checking
        if types_equal(from_base, to_base):
            # Can add const but not remove it
            if isinstance(from_type, PointerType) and isinstance(to_type, PointerType):
                from src.parser.ast_nodes import TypeQualifier
                # If from is const, to must be const
                if TypeQualifier.CONST in from_type.qualifiers:
                    if TypeQualifier.CONST not in to_type.qualifiers:
                        return False
            return True
    
    # Array to pointer decay
    if is_array_type(from_type) and is_pointer_type(to_type):
        array_elem = get_array_element_type(from_type)
        ptr_base = get_pointer_base_type(to_type)
        return types_equal(array_elem, ptr_base)
    
    # Null pointer constant (0) to pointer
    # (This is handled at the expression level)
    
    return False


def get_array_element_type(array_type: ArrayType) -> Type:
    """Get the element type of an array.
    
    Args:
        array_type: Array type
        
    Returns:
        Element type of the array
    """
    return array_type.element_type


def get_array_base_type(array_type: ArrayType) -> Type:
    """Get the base type of a multi-dimensional array.
    
    For example, int[5][10] returns int.
    
    Args:
        array_type: Array type
        
    Returns:
        Base element type (non-array type)
    """
    if isinstance(array_type.element_type, ArrayType):
        return get_array_base_type(array_type.element_type)
    return array_type.element_type


def get_array_dimensions(array_type: ArrayType) -> list:
    """Get all dimensions of a multi-dimensional array.
    
    Args:
        array_type: Array type
        
    Returns:
        List of dimension sizes (None for incomplete dimensions)
    """
    dimensions = [array_type.size_value]
    if isinstance(array_type.element_type, ArrayType):
        dimensions.extend(get_array_dimensions(array_type.element_type))
    return dimensions


def array_to_pointer_decay(array_type: ArrayType) -> PointerType:
    """Convert array type to pointer type (array-to-pointer decay).
    
    In C, arrays decay to pointers in most contexts.
    For example, int[10] decays to int*.
    
    Args:
        array_type: Array type to decay
        
    Returns:
        Pointer type to array element
    """
    return PointerType(
        location=array_type.location,
        pointee_type=array_type.element_type,
        qualifiers=()
    )


def is_complete_array_type(array_type: ArrayType) -> bool:
    """Check if an array type is complete (has known size).
    
    Args:
        array_type: Array type to check
        
    Returns:
        True if array has a size, False otherwise
    """
    return array_type.is_complete()


def is_incomplete_array_type(array_type: ArrayType) -> bool:
    """Check if an array type is incomplete (no size).
    
    Args:
        array_type: Array type to check
        
    Returns:
        True if array has no size, False otherwise
    """
    return not array_type.is_complete()


def can_assign_array_types(dest_type: ArrayType, src_type: ArrayType) -> bool:
    """Check if one array type can be assigned to another.
    
    In C, array assignment is not allowed, but we check type compatibility
    for initialization and parameter passing.
    
    Args:
        dest_type: Destination array type
        src_type: Source array type
        
    Returns:
        True if types are compatible, False otherwise
    """
    # Element types must match
    if not types_equal(dest_type.element_type, src_type.element_type):
        return False
    
    # If destination is incomplete, source can be any size
    if not dest_type.is_complete():
        return True
    
    # If both are complete, sizes must match
    if dest_type.size_value is not None and src_type.size_value is not None:
        return dest_type.size_value == src_type.size_value
    
    # If sizes are not constant, we can't check at compile time
    return True


def is_struct_type(type_obj: Type) -> bool:
    """Check if a type is a struct type (not union).
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a struct, False otherwise
    """
    return isinstance(type_obj, StructType) and not type_obj.is_union


def is_union_type(type_obj: Type) -> bool:
    """Check if a type is a union type.
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a union, False otherwise
    """
    return isinstance(type_obj, StructType) and type_obj.is_union


def is_complete_struct_type(type_obj: Type) -> bool:
    """Check if a struct/union type is complete (has member definitions).
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is a complete struct/union, False otherwise
    """
    return isinstance(type_obj, StructType) and type_obj.is_complete


def is_incomplete_struct_type(type_obj: Type) -> bool:
    """Check if a struct/union type is incomplete (forward declaration).
    
    Args:
        type_obj: Type to check
        
    Returns:
        True if type is an incomplete struct/union, False otherwise
    """
    return isinstance(type_obj, StructType) and not type_obj.is_complete


def struct_types_compatible(type1: StructType, type2: StructType) -> bool:
    """Check if two struct/union types are compatible.
    
    In C, struct types are compatible if they have the same tag.
    
    Args:
        type1: First struct/union type
        type2: Second struct/union type
        
    Returns:
        True if types are compatible, False otherwise
    """
    # Must both be struct or both be union
    if type1.is_union != type2.is_union:
        return False
    
    # If both have names, they must match
    if type1.name is not None and type2.name is not None:
        return type1.name == type2.name
    
    # Anonymous structs are only compatible if they're the same object
    return type1 is type2



def integer_promotion(type_obj: Type) -> Type:
    """Apply integer promotion rules (C99 6.3.1.1).
    
    Integer types smaller than int are promoted to int or unsigned int.
    
    Args:
        type_obj: Type to promote
        
    Returns:
        Promoted type
    """
    if not isinstance(type_obj, PrimitiveType):
        return type_obj
    
    # char, short, and bit-fields are promoted to int if int can represent
    # all values of the original type, otherwise to unsigned int
    if type_obj.name in ('char', 'short'):
        return PrimitiveType(
            name='int',
            is_signed=True,
            size_modifier=None,
            qualifiers=type_obj.qualifiers,
            location=type_obj.location
        )
    
    # _Bool is promoted to int
    if type_obj.name == '_Bool':
        return PrimitiveType(
            name='int',
            is_signed=True,
            size_modifier=None,
            qualifiers=type_obj.qualifiers,
            location=type_obj.location
        )
    
    return type_obj


def usual_arithmetic_conversions(type1: Type, type2: Type) -> Type:
    """Apply usual arithmetic conversions (C99 6.3.1.8).
    
    Determines the common real type for binary arithmetic operations.
    
    Args:
        type1: First operand type
        type2: Second operand type
        
    Returns:
        Common type for the operation
    """
    # First, apply integer promotions
    type1 = integer_promotion(type1)
    type2 = integer_promotion(type2)
    
    # If both are the same type, return it
    if types_equal(type1, type2):
        return type1
    
    # If either is long double, result is long double
    if isinstance(type1, PrimitiveType) and type1.name == 'double' and type1.size_modifier == 'long':
        return type1
    if isinstance(type2, PrimitiveType) and type2.name == 'double' and type2.size_modifier == 'long':
        return type2
    
    # If either is double, result is double
    if isinstance(type1, PrimitiveType) and type1.name == 'double':
        return type1
    if isinstance(type2, PrimitiveType) and type2.name == 'double':
        return type2
    
    # If either is float, result is float
    if isinstance(type1, PrimitiveType) and type1.name == 'float':
        return type1
    if isinstance(type2, PrimitiveType) and type2.name == 'float':
        return type2
    
    # Both are integers - apply integer conversion rank rules
    if isinstance(type1, PrimitiveType) and isinstance(type2, PrimitiveType):
        rank1 = get_type_size_rank(type1)
        rank2 = get_type_size_rank(type2)
        
        # If both have the same signedness, convert to the one with greater rank
        if type1.is_signed == type2.is_signed:
            return type1 if rank1 >= rank2 else type2
        
        # If unsigned operand has rank >= signed operand, convert to unsigned
        if not type1.is_signed and rank1 >= rank2:
            return type1
        if not type2.is_signed and rank2 >= rank1:
            return type2
        
        # If signed operand can represent all values of unsigned operand, convert to signed
        # (Simplified: just use the higher rank)
        return type1 if rank1 > rank2 else type2
    
    # Fallback
    return type1


def composite_type(type1: Type, type2: Type) -> Optional[Type]:
    """Determine the composite type of two compatible types (C99 6.2.7).
    
    Args:
        type1: First type
        type2: Second type
        
    Returns:
        Composite type, or None if types are not compatible
    """
    # For now, just return the first type if they're equal
    # Full composite type rules are complex
    if types_equal(type1, type2):
        return type1
    
    # Array types: composite has known size if either has known size
    if isinstance(type1, ArrayType) and isinstance(type2, ArrayType):
        if types_equal(type1.element_type, type2.element_type):
            # Use the size from whichever array has a size
            if type1.size_value is not None:
                return type1
            elif type2.size_value is not None:
                return type2
            else:
                return type1
    
    # Function types: composite combines parameter information
    if isinstance(type1, FunctionType) and isinstance(type2, FunctionType):
        if types_equal(type1.return_type, type2.return_type):
            # Use the more specific parameter list
            if len(type1.parameter_types) > 0:
                return type1
            else:
                return type2
    
    return None


def is_compatible_type(type1: Type, type2: Type) -> bool:
    """Check if two types are compatible (C99 6.2.7).
    
    Two types are compatible if they are the same type or if they
    satisfy certain compatibility rules.
    
    Args:
        type1: First type
        type2: Second type
        
    Returns:
        True if types are compatible, False otherwise
    """
    # Same types are compatible
    if types_equal(type1, type2):
        return True
    
    # Qualified versions of compatible types are compatible
    # (ignoring qualifiers for compatibility check)
    if isinstance(type1, PrimitiveType) and isinstance(type2, PrimitiveType):
        return (type1.name == type2.name and
                type1.is_signed == type2.is_signed and
                type1.size_modifier == type2.size_modifier)
    
    # Array types are compatible if element types are compatible
    if isinstance(type1, ArrayType) and isinstance(type2, ArrayType):
        return is_compatible_type(type1.element_type, type2.element_type)
    
    # Pointer types are compatible if pointee types are compatible
    if isinstance(type1, PointerType) and isinstance(type2, PointerType):
        return is_compatible_type(type1.pointee_type, type2.pointee_type)
    
    # Function types are compatible if return types and parameters are compatible
    if isinstance(type1, FunctionType) and isinstance(type2, FunctionType):
        if not is_compatible_type(type1.return_type, type2.return_type):
            return False
        
        # If one has no parameters, they're compatible
        if len(type1.parameter_types) == 0 or len(type2.parameter_types) == 0:
            return True
        
        # Otherwise, parameter counts and types must match
        if len(type1.parameter_types) != len(type2.parameter_types):
            return False
        
        return all(is_compatible_type(p1, p2) 
                  for p1, p2 in zip(type1.parameter_types, type2.parameter_types))
    
    # Struct/union types are compatible if they have the same tag
    if isinstance(type1, StructType) and isinstance(type2, StructType):
        return struct_types_compatible(type1, type2)
    
    return False


def pointer_conversion(from_type: Type, to_type: Type) -> bool:
    """Check if pointer conversion is allowed (C99 6.3.2.3).
    
    Args:
        from_type: Source pointer type
        to_type: Target pointer type
        
    Returns:
        True if conversion is allowed, False otherwise
    """
    if not (is_pointer_type(from_type) and is_pointer_type(to_type)):
        return False
    
    from_base = get_pointer_base_type(from_type)
    to_base = get_pointer_base_type(to_type)
    
    # Pointer to void conversions
    if is_void_type(to_base) or is_void_type(from_base):
        return True
    
    # Pointer to compatible types
    if is_compatible_type(from_base, to_base):
        return True
    
    return False


def function_to_pointer_decay(func_type: FunctionType) -> PointerType:
    """Convert function type to pointer to function (C99 6.3.2.1).
    
    Args:
        func_type: Function type
        
    Returns:
        Pointer to function type
    """
    return PointerType(
        location=func_type.location,
        pointee_type=func_type,
        qualifiers=()
    )


def is_null_pointer_constant(expr: 'Expression') -> bool:
    """Check if expression is a null pointer constant (C99 6.3.2.3).
    
    A null pointer constant is an integer constant expression with value 0,
    or such an expression cast to void*.
    
    Args:
        expr: Expression to check
        
    Returns:
        True if expression is a null pointer constant
    """
    from src.parser.ast_nodes import Literal, CastExpr
    
    # Integer literal 0
    if isinstance(expr, Literal) and expr.literal_type == 'int':
        try:
            if int(expr.value) == 0:
                return True
        except (ValueError, TypeError):
            pass
    
    # Cast to void* of integer 0
    if isinstance(expr, CastExpr):
        if is_pointer_type(expr.target_type):
            base = get_pointer_base_type(expr.target_type)
            if is_void_type(base):
                return is_null_pointer_constant(expr.operand)
    
    return False
