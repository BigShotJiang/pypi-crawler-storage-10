"""Type checking for expressions and statements."""

from typing import Optional

from src.parser.ast_nodes import (
    Expression, BinaryExpr, UnaryExpr, Literal, Identifier, CallExpr,
    CastExpr, ArraySubscript, MemberAccess, ConditionalExpr, AssignmentExpr,
    CommaExpr, SizeofExpr, InitializerList, Type, PrimitiveType, PointerType, ArrayType,
    FunctionType, StructType
)
from src.semantic.symbol_table import SymbolTable, SymbolKind
from src.semantic.type_utils import (
    types_equal, is_arithmetic_type, is_integer_type, is_pointer_type,
    is_array_type, is_scalar_type, is_void_type, get_common_type,
    can_convert_implicitly, get_pointer_base_type, get_array_element_type,
    is_function_type, array_to_pointer_decay, integer_promotion,
    usual_arithmetic_conversions, is_compatible_type, pointer_conversion,
    function_to_pointer_decay, is_null_pointer_constant
)
from src.utils.error_reporter import ErrorReporter
from src.utils.source_location import SourceLocation
from src.utils.error_suggestions import ErrorSuggestions


class TypeChecker:
    """Performs type checking on expressions.
    
    Attributes:
        symbol_table: Symbol table for looking up identifiers
        error_reporter: Error reporter for type errors
    """
    
    def __init__(self, symbol_table: SymbolTable, error_reporter: ErrorReporter):
        """Initialize type checker.
        
        Args:
            symbol_table: Symbol table for identifier lookups
            error_reporter: Error reporter for diagnostics
        """
        self.symbol_table = symbol_table
        self.error_reporter = error_reporter
    
    def check_expression(self, expr: Expression) -> Optional[Type]:
        """Check the type of an expression and annotate it.
        
        Args:
            expr: Expression to type check
            
        Returns:
            Type of the expression, or None if type checking failed
        """
        if isinstance(expr, Literal):
            return self._check_literal(expr)
        elif isinstance(expr, Identifier):
            return self._check_identifier(expr)
        elif isinstance(expr, BinaryExpr):
            return self._check_binary_expr(expr)
        elif isinstance(expr, UnaryExpr):
            return self._check_unary_expr(expr)
        elif isinstance(expr, CallExpr):
            return self._check_call_expr(expr)
        elif isinstance(expr, CastExpr):
            return self._check_cast_expr(expr)
        elif isinstance(expr, ArraySubscript):
            return self._check_array_subscript(expr)
        elif isinstance(expr, MemberAccess):
            return self._check_member_access(expr)
        elif isinstance(expr, ConditionalExpr):
            return self._check_conditional_expr(expr)
        elif isinstance(expr, AssignmentExpr):
            return self._check_assignment_expr(expr)
        elif isinstance(expr, CommaExpr):
            return self._check_comma_expr(expr)
        elif isinstance(expr, SizeofExpr):
            return self._check_sizeof_expr(expr)
        elif isinstance(expr, InitializerList):
            return self._check_initializer_list(expr)
        else:
            self.error_reporter.error(
                expr.location,
                f"Unknown expression type: {type(expr).__name__}"
            )
            return None
    
    def _check_literal(self, expr: Literal) -> Type:
        """Check literal expression type."""
        location = expr.location
        
        if expr.literal_type == 'int':
            expr_type = PrimitiveType(name='int', is_signed=True, location=location)
        elif expr.literal_type == 'float':
            # Determine float type based on suffix
            value = expr.value
            if value.endswith('f') or value.endswith('F'):
                # float suffix
                expr_type = PrimitiveType(name='float', location=location)
            elif value.endswith('l') or value.endswith('L'):
                # long double suffix
                expr_type = PrimitiveType(name='double', size_modifier='long', location=location)
            else:
                # No suffix or just exponent - default to double
                expr_type = PrimitiveType(name='double', location=location)
        elif expr.literal_type == 'char':
            expr_type = PrimitiveType(name='char', is_signed=True, location=location)
        elif expr.literal_type == 'string':
            # String literal is array of char
            char_type = PrimitiveType(name='char', is_signed=True, location=location)
            expr_type = ArrayType(element_type=char_type, size=None, location=location)
        else:
            self.error_reporter.error(
                location,
                f"Unknown literal type: {expr.literal_type}"
            )
            return None
        
        # Annotate expression with its type
        expr.expr_type = expr_type
        return expr_type
    
    def _check_identifier(self, expr: Identifier) -> Optional[Type]:
        """Check identifier expression type."""
        symbol = self.symbol_table.lookup(expr.name)
        
        if symbol is None:
            # Get available identifiers for suggestion
            available_names = [s.name for s in self.symbol_table.get_all_symbols()]
            suggestion = ErrorSuggestions.suggest_for_undeclared_identifier(expr.name, available_names)
            
            self.error_reporter.error(
                expr.location,
                f"Undeclared identifier '{expr.name}'",
                suggestion=suggestion
            )
            return None
        
        # Mark symbol as used
        self.symbol_table.mark_used(expr.name)
        
        # Annotate expression with its type
        expr.expr_type = symbol.symbol_type
        return symbol.symbol_type
    
    def _check_binary_expr(self, expr: BinaryExpr) -> Optional[Type]:
        """Check binary expression type."""
        left_type = self.check_expression(expr.left)
        right_type = self.check_expression(expr.right)
        
        if left_type is None or right_type is None:
            return None
        
        op = expr.operator
        
        # Arithmetic operators: +, -, *, /, %
        if op in ('+', '-', '*', '/', '%'):
            return self._check_arithmetic_binary(expr, left_type, right_type)
        
        # Relational operators: <, >, <=, >=, ==, !=
        elif op in ('<', '>', '<=', '>=', '==', '!='):
            return self._check_relational_binary(expr, left_type, right_type)
        
        # Logical operators: &&, ||
        elif op in ('&&', '||'):
            return self._check_logical_binary(expr, left_type, right_type)
        
        # Bitwise operators: &, |, ^, <<, >>
        elif op in ('&', '|', '^', '<<', '>>'):
            return self._check_bitwise_binary(expr, left_type, right_type)
        
        else:
            self.error_reporter.error(
                expr.location,
                f"Unknown binary operator: {op}"
            )
            return None
    
    def _check_arithmetic_binary(self, expr: BinaryExpr, left_type: Type, 
                                 right_type: Type) -> Optional[Type]:
        """Check arithmetic binary operation."""
        op = expr.operator
        
        # Apply array-to-pointer decay for pointer arithmetic
        if is_array_type(left_type):
            left_type = array_to_pointer_decay(left_type)
        if is_array_type(right_type):
            right_type = array_to_pointer_decay(right_type)
        
        # Special case: pointer arithmetic
        if op in ('+', '-'):
            if is_pointer_type(left_type) and is_integer_type(right_type):
                expr.expr_type = left_type
                return left_type
            elif is_integer_type(left_type) and is_pointer_type(right_type):
                expr.expr_type = right_type
                return right_type
            elif op == '-' and is_pointer_type(left_type) and is_pointer_type(right_type):
                # Pointer difference returns ptrdiff_t (we'll use long)
                result_type = PrimitiveType(name='long', is_signed=True, 
                                           location=expr.location)
                expr.expr_type = result_type
                return result_type
        
        # Modulo requires integer operands
        if op == '%':
            if not (is_integer_type(left_type) and is_integer_type(right_type)):
                self.error_reporter.error(
                    expr.location,
                    f"Modulo operator requires integer operands"
                )
                return None
            # Apply integer promotions and usual arithmetic conversions
            result_type = usual_arithmetic_conversions(left_type, right_type)
            expr.expr_type = result_type
            return result_type
        
        # Regular arithmetic requires arithmetic types
        if not (is_arithmetic_type(left_type) and is_arithmetic_type(right_type)):
            self.error_reporter.error(
                expr.location,
                f"Arithmetic operator '{op}' requires arithmetic operands"
            )
            return None
        
        # Apply usual arithmetic conversions (C99 6.3.1.8)
        result_type = usual_arithmetic_conversions(left_type, right_type)
        if result_type is None:
            self.error_reporter.error(
                expr.location,
                f"Cannot find common type for operands"
            )
            return None
        
        expr.expr_type = result_type
        return result_type

    def _check_relational_binary(self, expr: BinaryExpr, left_type: Type,
                                 right_type: Type) -> Optional[Type]:
        """Check relational binary operation."""
        # Relational operators require scalar types
        if not (is_scalar_type(left_type) and is_scalar_type(right_type)):
            self.error_reporter.error(
                expr.location,
                f"Relational operator '{expr.operator}' requires scalar operands"
            )
            return None
        
        # Result is always int (boolean)
        result_type = PrimitiveType(name='int', is_signed=True, location=expr.location)
        expr.expr_type = result_type
        return result_type
    
    def _check_logical_binary(self, expr: BinaryExpr, left_type: Type,
                             right_type: Type) -> Optional[Type]:
        """Check logical binary operation."""
        # Logical operators require scalar types
        if not (is_scalar_type(left_type) and is_scalar_type(right_type)):
            self.error_reporter.error(
                expr.location,
                f"Logical operator '{expr.operator}' requires scalar operands"
            )
            return None
        
        # Result is always int (boolean)
        result_type = PrimitiveType(name='int', is_signed=True, location=expr.location)
        expr.expr_type = result_type
        return result_type
    
    def _check_bitwise_binary(self, expr: BinaryExpr, left_type: Type,
                             right_type: Type) -> Optional[Type]:
        """Check bitwise binary operation."""
        # Bitwise operators require integer types
        if not (is_integer_type(left_type) and is_integer_type(right_type)):
            self.error_reporter.error(
                expr.location,
                f"Bitwise operator '{expr.operator}' requires integer operands"
            )
            return None
        
        # For shifts, result type is left operand type
        if expr.operator in ('<<', '>>'):
            expr.expr_type = left_type
            return left_type
        
        # For other bitwise ops, use common type
        result_type = get_common_type(left_type, right_type)
        if result_type is None:
            self.error_reporter.error(
                expr.location,
                f"Cannot find common type for operands"
            )
            return None
        
        expr.expr_type = result_type
        return result_type
    
    def _check_unary_expr(self, expr: UnaryExpr) -> Optional[Type]:
        """Check unary expression type."""
        operand_type = self.check_expression(expr.operand)
        
        if operand_type is None:
            return None
        
        op = expr.operator
        
        # Arithmetic unary: +, -, ~, !
        if op in ('+', '-'):
            if not is_arithmetic_type(operand_type):
                self.error_reporter.error(
                    expr.location,
                    f"Unary '{op}' requires arithmetic operand"
                )
                return None
            # Apply integer promotion
            result_type = integer_promotion(operand_type)
            expr.expr_type = result_type
            return result_type
        
        elif op == '~':
            if not is_integer_type(operand_type):
                self.error_reporter.error(
                    expr.location,
                    f"Bitwise NOT requires integer operand"
                )
                return None
            # Apply integer promotion
            result_type = integer_promotion(operand_type)
            expr.expr_type = result_type
            return result_type
        
        elif op == '!':
            if not is_scalar_type(operand_type):
                self.error_reporter.error(
                    expr.location,
                    f"Logical NOT requires scalar operand"
                )
                return None
            result_type = PrimitiveType(name='int', is_signed=True, 
                                       location=expr.location)
            expr.expr_type = result_type
            return result_type
        
        # Address-of operator: &
        elif op == '&':
            # Result is pointer to operand type
            result_type = PointerType(pointee_type=operand_type, qualifiers=(),
                                     location=expr.location)
            expr.expr_type = result_type
            return result_type
        
        # Dereference operator: *
        elif op == '*':
            if not is_pointer_type(operand_type):
                self.error_reporter.error(
                    expr.location,
                    f"Dereference requires pointer operand"
                )
                return None
            result_type = get_pointer_base_type(operand_type)
            expr.expr_type = result_type
            return result_type
        
        # Increment/decrement: ++, --
        elif op in ('++', '--'):
            if not is_scalar_type(operand_type):
                self.error_reporter.error(
                    expr.location,
                    f"Increment/decrement requires scalar operand"
                )
                return None
            expr.expr_type = operand_type
            return operand_type
        
        else:
            self.error_reporter.error(
                expr.location,
                f"Unknown unary operator: {op}"
            )
            return None
    
    def _check_call_expr(self, expr: CallExpr) -> Optional[Type]:
        """Check function call expression type.
        
        Handles:
        - Direct function calls: func(args)
        - Indirect calls through function pointers: (*fp)(args) or fp(args)
        """
        func_type = self.check_expression(expr.function)
        
        if func_type is None:
            return None
        
        # Apply function-to-pointer decay if needed
        # In C, function names automatically decay to function pointers
        if is_function_type(func_type):
            # Direct function call - use the function type as-is
            pass
        elif is_pointer_type(func_type):
            # Indirect call through function pointer
            # Dereference the pointer to get the function type
            pointee = get_pointer_base_type(func_type)
            if not is_function_type(pointee):
                self.error_reporter.error(
                    expr.location,
                    f"Called object is not a function or function pointer"
                )
                return None
            func_type = pointee
        else:
            self.error_reporter.error(
                expr.location,
                f"Called object is not a function or function pointer"
            )
            return None
        
        func_type: FunctionType
        
        # Check argument count
        expected_args = len(func_type.parameter_types)
        actual_args = len(expr.arguments)
        
        if not func_type.is_variadic and actual_args != expected_args:
            suggestion = ErrorSuggestions.suggest_for_function_call_mismatch(expected_args, actual_args)
            self.error_reporter.error(
                expr.location,
                f"Function expects {expected_args} arguments, got {actual_args}",
                suggestion=suggestion
            )
            return None
        
        if actual_args < expected_args:
            suggestion = ErrorSuggestions.suggest_for_function_call_mismatch(expected_args, actual_args)
            self.error_reporter.error(
                expr.location,
                f"Too few arguments to function (expected {expected_args}, got {actual_args})",
                suggestion=suggestion
            )
            return None
        
        # Check argument types
        for i, (arg, param_type) in enumerate(zip(expr.arguments, func_type.parameter_types)):
            arg_type = self.check_expression(arg)
            if arg_type is None:
                continue
            
            if not can_convert_implicitly(arg_type, param_type):
                self.error_reporter.error(
                    arg.location,
                    f"Argument {i+1}: cannot convert from "
                    f"'{self._type_to_string(arg_type)}' to "
                    f"'{self._type_to_string(param_type)}'"
                )
        
        # Return type is function's return type
        expr.expr_type = func_type.return_type
        return func_type.return_type
    
    def _check_cast_expr(self, expr: CastExpr) -> Type:
        """Check cast expression type."""
        # Check operand type
        operand_type = self.check_expression(expr.operand)
        
        # Result type is the target type
        expr.expr_type = expr.target_type
        return expr.target_type
    
    def _check_array_subscript(self, expr: ArraySubscript) -> Optional[Type]:
        """Check array subscript expression type.
        
        Handles:
        - Array indexing: arr[i]
        - Pointer indexing: ptr[i]
        - Multi-dimensional arrays: matrix[i][j]
        - Array-to-pointer decay
        
        In C, arr[i] is equivalent to *(arr + i), so both array and pointer
        types are valid for subscripting.
        """
        array_type = self.check_expression(expr.array)
        index_type = self.check_expression(expr.index)
        
        if array_type is None or index_type is None:
            return None
        
        # Determine the element type
        result_type = None
        
        if is_array_type(array_type):
            # Array subscripting: arr[i]
            # Result is the element type of the array
            result_type = get_array_element_type(array_type)
            
        elif is_pointer_type(array_type):
            # Pointer subscripting: ptr[i]
            # Result is the pointed-to type
            result_type = get_pointer_base_type(array_type)
            
        else:
            # Not an array or pointer
            self.error_reporter.error(
                expr.location,
                f"Subscripted value is not an array or pointer"
            )
            return None
        
        # Index must be integer type
        if not is_integer_type(index_type):
            type_name = self._type_to_string(index_type)
            suggestion = ErrorSuggestions.suggest_for_array_index_type(type_name)
            self.error_reporter.error(
                expr.index.location,
                f"Array subscript must be an integer type, got {type_name}",
                suggestion=suggestion
            )
            # Continue anyway to provide result type
        
        # Annotate expression with result type
        expr.expr_type = result_type
        return result_type
    
    def _check_member_access(self, expr: MemberAccess) -> Optional[Type]:
        """Check struct/union member access expression type."""
        object_type = self.check_expression(expr.object)
        
        if object_type is None:
            return None
        
        # For arrow operator, dereference pointer
        if expr.is_arrow:
            if not is_pointer_type(object_type):
                self.error_reporter.error(
                    expr.location,
                    f"Member access with '->' requires pointer to struct/union"
                )
                return None
            object_type = get_pointer_base_type(object_type)
        
        # Object must be struct or union type
        if not isinstance(object_type, StructType):
            self.error_reporter.error(
                expr.location,
                f"Member access requires struct or union type"
            )
            return None
        
        # Resolve incomplete struct types by looking up complete definition
        if object_type.name and not object_type.is_complete:
            struct_symbol = self.symbol_table.lookup(object_type.name)
            if struct_symbol and struct_symbol.kind == SymbolKind.TYPE:
                if isinstance(struct_symbol.symbol_type, StructType):
                    object_type = struct_symbol.symbol_type
        
        # Find member in struct
        if object_type.members is None:
            self.error_reporter.error(
                expr.location,
                f"Incomplete struct/union type"
            )
            return None
        
        for member in object_type.members:
            if member.name == expr.member:
                expr.expr_type = member.var_type
                return member.var_type
        
        self.error_reporter.error(
            expr.location,
            f"Struct/union has no member named '{expr.member}'"
        )
        return None
    
    def _check_conditional_expr(self, expr: ConditionalExpr) -> Optional[Type]:
        """Check ternary conditional expression type."""
        cond_type = self.check_expression(expr.condition)
        true_type = self.check_expression(expr.true_expr)
        false_type = self.check_expression(expr.false_expr)
        
        if cond_type is None or true_type is None or false_type is None:
            return None
        
        # Condition must be scalar
        if not is_scalar_type(cond_type):
            self.error_reporter.error(
                expr.condition.location,
                f"Condition must be scalar type"
            )
        
        # Result type is common type of true and false expressions
        result_type = get_common_type(true_type, false_type)
        if result_type is None:
            self.error_reporter.error(
                expr.location,
                f"Incompatible types in conditional expression"
            )
            return None
        
        expr.expr_type = result_type
        return result_type
    
    def _check_assignment_expr(self, expr: AssignmentExpr) -> Optional[Type]:
        """Check assignment expression type."""
        lhs_type = self.check_expression(expr.lhs)
        rhs_type = self.check_expression(expr.rhs)
        
        if lhs_type is None or rhs_type is None:
            return None
        
        # Check const correctness
        self.check_const_assignment(expr.lhs, expr.location)
        
        # For compound assignments (+=, -=, etc.), check operation
        if expr.operator != '=':
            # Extract base operator
            base_op = expr.operator[:-1]  # Remove '='
            
            # Create temporary binary expression to check operation
            temp_binary = BinaryExpr(
                operator=base_op,
                left=expr.lhs,
                right=expr.rhs,
                location=expr.location
            )
            result_type = self._check_binary_expr(temp_binary)
            
            if result_type is None:
                return None
            
            # Check if result can be assigned back to lhs
            if not can_convert_implicitly(result_type, lhs_type):
                self.error_reporter.error(
                    expr.location,
                    f"Cannot assign result of '{base_op}' back to left operand"
                )
        else:
            # Simple assignment - check if rhs can convert to lhs
            # Special case: NULL pointer constant (0) can be assigned to any pointer
            is_null_to_pointer = (is_pointer_type(lhs_type) and 
                                  is_null_pointer_constant(expr.rhs))
            
            if not is_null_to_pointer and not can_convert_implicitly(rhs_type, lhs_type):
                self.error_reporter.error(
                    expr.location,
                    f"Cannot assign '{self._type_to_string(rhs_type)}' to "
                    f"'{self._type_to_string(lhs_type)}'"
                )
        
        # Result type is lhs type
        expr.expr_type = lhs_type
        return lhs_type
    
    def _check_comma_expr(self, expr: CommaExpr) -> Optional[Type]:
        """Check comma expression type.
        
        The comma operator evaluates all expressions left-to-right
        and returns the type and value of the rightmost expression.
        """
        if not expr.expressions:
            return None
        
        # Type check all expressions
        for sub_expr in expr.expressions:
            self.check_expression(sub_expr)
        
        # Result type is the type of the last expression
        last_type = self.check_expression(expr.expressions[-1])
        expr.expr_type = last_type
        return last_type
    
    def _check_sizeof_expr(self, expr: SizeofExpr) -> Type:
        """Check sizeof expression type."""
        # Sizeof always returns size_t (we'll use unsigned long)
        result_type = PrimitiveType(name='long', is_signed=False, 
                                   location=expr.location)
        expr.expr_type = result_type
        return result_type
    
    def _check_initializer_list(self, expr: InitializerList) -> Optional[Type]:
        """Check initializer list expression type."""
        # Check all initializers
        for init in expr.initializers:
            self.check_expression(init)
        
        # Type will be determined by context (variable declaration)
        # For now, return None to indicate it needs context
        return None
    
    def check_assignment(self, lhs_type: Type, rhs_type: Type, 
                        location: SourceLocation) -> bool:
        """Check if an assignment is valid.
        
        Args:
            lhs_type: Type of left-hand side
            rhs_type: Type of right-hand side
            location: Source location for error reporting
            
        Returns:
            True if assignment is valid, False otherwise
        """
        if can_convert_implicitly(rhs_type, lhs_type):
            return True
        
        self.error_reporter.error(
            location,
            f"Cannot assign '{self._type_to_string(rhs_type)}' to "
            f"'{self._type_to_string(lhs_type)}'"
        )
        return False
    
    def implicit_cast(self, expr: Expression, target_type: Type) -> Expression:
        """Insert an implicit cast node if needed.
        
        Args:
            expr: Expression to cast
            target_type: Target type
            
        Returns:
            Original expression or new CastExpr node
        """
        expr_type = getattr(expr, 'expr_type', None)
        
        if expr_type is None:
            return expr
        
        if types_equal(expr_type, target_type):
            return expr
        
        # Create implicit cast
        cast_expr = CastExpr(
            target_type=target_type,
            operand=expr,
            location=expr.location
        )
        cast_expr.expr_type = target_type
        return cast_expr
    
    def _type_to_string(self, type_obj: Type) -> str:
        """Convert a type to a string for error messages.
        
        Args:
            type_obj: Type to convert
            
        Returns:
            String representation of type
        """
        if isinstance(type_obj, PrimitiveType):
            parts = []
            if type_obj.size_modifier:
                parts.append(type_obj.size_modifier)
            if not type_obj.is_signed and type_obj.name != 'float' and type_obj.name != 'double':
                parts.append('unsigned')
            parts.append(type_obj.name)
            return ' '.join(parts)
        elif isinstance(type_obj, PointerType):
            return f"{self._type_to_string(type_obj.pointee_type)}*"
        elif isinstance(type_obj, ArrayType):
            return f"{self._type_to_string(type_obj.element_type)}[]"
        elif isinstance(type_obj, FunctionType):
            return "function"
        elif isinstance(type_obj, StructType):
            kind = "union" if type_obj.is_union else "struct"
            name = type_obj.name if type_obj.name else "<anonymous>"
            return f"{kind} {name}"
        else:
            return type_obj.__class__.__name__

    
    def check_const_assignment(self, lhs: Expression, location: SourceLocation) -> bool:
        """Check if assignment to lhs violates const correctness.
        
        Args:
            lhs: Left-hand side expression
            location: Source location for error reporting
            
        Returns:
            True if assignment is valid, False if it violates const
        """
        # Get the type of the lhs
        lhs_type = getattr(lhs, 'expr_type', None)
        if lhs_type is None:
            return True  # Can't check without type info
        
        # Check if trying to assign to const variable
        if isinstance(lhs_type, PrimitiveType) and lhs_type.is_const():
            self.error_reporter.error(
                location,
                "Cannot assign to const-qualified variable"
            )
            return False
        
        # Check if trying to modify through const pointer
        if isinstance(lhs, UnaryExpr) and lhs.operator == '*':
            # Dereferencing a pointer
            ptr_type = getattr(lhs.operand, 'expr_type', None)
            if isinstance(ptr_type, PointerType) and ptr_type.is_const():
                self.error_reporter.error(
                    location,
                    "Cannot modify through pointer to const"
                )
                return False
        
        return True
