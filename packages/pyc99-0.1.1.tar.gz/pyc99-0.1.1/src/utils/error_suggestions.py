"""Common error suggestions and helpful messages."""

from typing import Optional, Tuple


class ErrorSuggestions:
    """Provides helpful suggestions for common compiler errors."""
    
    @staticmethod
    def suggest_for_undeclared_identifier(name: str, available_names: list[str]) -> Optional[str]:
        """Suggest a correction for an undeclared identifier.
        
        Args:
            name: The undeclared identifier
            available_names: List of available identifiers in scope
            
        Returns:
            A suggestion string if a close match is found, None otherwise
        """
        if not available_names:
            return None
        
        # Find close matches using simple edit distance
        close_matches = []
        for available in available_names:
            distance = ErrorSuggestions._levenshtein_distance(name, available)
            # Only suggest if distance is small relative to name length
            if distance <= max(1, len(name) // 3):
                close_matches.append((distance, available))
        
        if close_matches:
            close_matches.sort()
            best_match = close_matches[0][1]
            return f"did you mean '{best_match}'?"
        
        return None
    
    @staticmethod
    def suggest_for_type_mismatch(expected: str, got: str) -> Optional[str]:
        """Suggest a fix for type mismatch errors.
        
        Args:
            expected: Expected type name
            got: Actual type name
            
        Returns:
            A suggestion string
        """
        # Common type conversion suggestions
        if expected in ('int', 'long', 'short') and got in ('float', 'double'):
            return f"use an explicit cast: (int){got}"
        elif expected in ('float', 'double') and got in ('int', 'long', 'short'):
            return f"use an explicit cast: (float){got}"
        elif expected.endswith('*') and got == 'int':
            return "use NULL or cast the integer to a pointer type"
        elif expected == 'int' and got.endswith('*'):
            return "use an explicit cast: (int)pointer or dereference the pointer"
        
        return None
    
    @staticmethod
    def suggest_for_missing_semicolon() -> str:
        """Suggest fix for missing semicolon."""
        return "add a semicolon ';' at the end of the statement"
    
    @staticmethod
    def suggest_for_missing_brace(brace_type: str) -> str:
        """Suggest fix for missing brace.
        
        Args:
            brace_type: Type of brace ('opening' or 'closing')
            
        Returns:
            A suggestion string
        """
        if brace_type == 'opening':
            return "add an opening brace '{' before the block"
        else:
            return "add a closing brace '}' to match the opening brace"
    
    @staticmethod
    def suggest_for_missing_parenthesis() -> str:
        """Suggest fix for missing parenthesis."""
        return "check that all parentheses are properly matched"
    
    @staticmethod
    def suggest_for_function_call_mismatch(expected: int, got: int) -> str:
        """Suggest fix for function call argument count mismatch.
        
        Args:
            expected: Expected number of arguments
            got: Actual number of arguments
            
        Returns:
            A suggestion string
        """
        if got < expected:
            missing = expected - got
            return f"add {missing} more argument(s) to the function call"
        else:
            extra = got - expected
            return f"remove {extra} extra argument(s) from the function call"
    
    @staticmethod
    def suggest_for_redeclaration(name: str, original_location: str) -> str:
        """Suggest fix for redeclaration error.
        
        Args:
            name: Name of the redeclared identifier
            original_location: Location of original declaration
            
        Returns:
            A suggestion string
        """
        return f"'{name}' was previously declared at {original_location}"
    
    @staticmethod
    def suggest_for_break_continue_outside_loop(stmt_type: str) -> str:
        """Suggest fix for break/continue outside loop.
        
        Args:
            stmt_type: 'break' or 'continue'
            
        Returns:
            A suggestion string
        """
        return f"'{stmt_type}' statement must be inside a loop (for, while, do-while) or switch statement"
    
    @staticmethod
    def suggest_for_return_type_mismatch(expected: str, got: str) -> str:
        """Suggest fix for return type mismatch.
        
        Args:
            expected: Expected return type
            got: Actual return type
            
        Returns:
            A suggestion string
        """
        if expected == 'void' and got != 'void':
            return "remove the return value (function returns void)"
        elif expected != 'void' and got == 'void':
            return f"add a return value of type '{expected}'"
        else:
            return f"cast the return value to '{expected}' or change the function return type"
    
    @staticmethod
    def suggest_for_array_index_type(got: str) -> str:
        """Suggest fix for non-integer array index.
        
        Args:
            got: Actual type used for indexing
            
        Returns:
            A suggestion string
        """
        return f"array index must be an integer type, not '{got}'"
    
    @staticmethod
    def suggest_for_pointer_arithmetic(operation: str) -> str:
        """Suggest fix for invalid pointer arithmetic.
        
        Args:
            operation: The invalid operation
            
        Returns:
            A suggestion string
        """
        return f"pointer arithmetic operation '{operation}' is not valid; you can add/subtract integers from pointers or subtract two pointers"
    
    @staticmethod
    def _levenshtein_distance(s1: str, s2: str) -> int:
        """Calculate Levenshtein distance between two strings.
        
        Args:
            s1: First string
            s2: Second string
            
        Returns:
            Edit distance between the strings
        """
        if len(s1) < len(s2):
            return ErrorSuggestions._levenshtein_distance(s2, s1)
        
        if len(s2) == 0:
            return len(s1)
        
        previous_row = range(len(s2) + 1)
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                # Cost of insertions, deletions, or substitutions
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return previous_row[-1]
