"""Source location tracking for error reporting."""

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True, slots=True)
class SourceLocation:
    """Represents a location in source code.
    
    Attributes:
        filename: Name of the source file
        line: Line number (1-indexed)
        column: Column number (1-indexed)
    """
    filename: str
    line: int
    column: int
    
    def __str__(self) -> str:
        """Format as filename:line:column."""
        return f"{self.filename}:{self.line}:{self.column}"
    
    @classmethod
    def unknown(cls) -> 'SourceLocation':
        """Create a location for unknown/generated code."""
        return cls("<unknown>", 0, 0)
