"""Error and warning reporting with formatted output."""

import sys
from typing import List, Optional
from dataclasses import dataclass
from .source_location import SourceLocation


@dataclass
class Diagnostic:
    """Represents a single diagnostic message.
    
    Attributes:
        location: Source location of the diagnostic
        message: Diagnostic message text
        is_error: True for errors, False for warnings
        source_line: Optional source code line for context
        suggestion: Optional suggestion for fixing the error
        note: Optional additional note for context
    """
    location: SourceLocation
    message: str
    is_error: bool
    source_line: Optional[str] = None
    suggestion: Optional[str] = None
    note: Optional[str] = None


class ErrorReporter:
    """Centralized error and warning reporting.
    
    Collects diagnostics during compilation and provides formatted output
    with source context and color coding for terminal display.
    """
    
    def __init__(self, use_color: bool = True):
        """Initialize the error reporter.
        
        Args:
            use_color: Whether to use ANSI color codes in output
        """
        self.diagnostics: List[Diagnostic] = []
        self.use_color = use_color and sys.stdout.isatty()
        self._error_count = 0
        self._warning_count = 0
        
    def error(self, location: SourceLocation, message: str, source_line: Optional[str] = None,
              suggestion: Optional[str] = None, note: Optional[str] = None):
        """Report an error.
        
        Args:
            location: Source location of the error
            message: Error message
            source_line: Optional source code line for context
            suggestion: Optional suggestion for fixing the error
            note: Optional additional note for context
        """
        self.diagnostics.append(Diagnostic(location, message, True, source_line, suggestion, note))
        self._error_count += 1
        
    def warning(self, location: SourceLocation, message: str, source_line: Optional[str] = None,
                suggestion: Optional[str] = None, note: Optional[str] = None):
        """Report a warning.
        
        Args:
            location: Source location of the warning
            message: Warning message
            source_line: Optional source code line for context
            suggestion: Optional suggestion for fixing the warning
            note: Optional additional note for context
        """
        self.diagnostics.append(Diagnostic(location, message, False, source_line, suggestion, note))
        self._warning_count += 1
        
    def has_errors(self) -> bool:
        """Check if any errors have been reported.
        
        Returns:
            True if there are errors, False otherwise
        """
        return self._error_count > 0
    
    def has_warnings(self) -> bool:
        """Check if any warnings have been reported.
        
        Returns:
            True if there are warnings, False otherwise
        """
        return self._warning_count > 0
    
    def error_count(self) -> int:
        """Get the number of errors reported."""
        return self._error_count
    
    def warning_count(self) -> int:
        """Get the number of warnings reported."""
        return self._warning_count
    
    def print_diagnostics(self, file=sys.stderr):
        """Print all diagnostics with formatting.
        
        Args:
            file: Output file stream (default: stderr)
        """
        for diag in self.diagnostics:
            self._print_diagnostic(diag, file)
            
        if self.diagnostics:
            file.write("\n")
            summary = f"{self._error_count} error(s), {self._warning_count} warning(s)\n"
            if self.use_color:
                if self._error_count > 0:
                    summary = f"\033[1;31m{summary}\033[0m"
                else:
                    summary = f"\033[1;33m{summary}\033[0m"
            file.write(summary)
    
    def _print_diagnostic(self, diag: Diagnostic, file):
        """Print a single diagnostic with formatting.
        
        Args:
            diag: Diagnostic to print
            file: Output file stream
        """
        # Format: filename:line:column: error/warning: message
        kind = "error" if diag.is_error else "warning"
        
        if self.use_color:
            if diag.is_error:
                kind_colored = f"\033[1;31m{kind}\033[0m"
                location_colored = f"\033[1m{diag.location}\033[0m"
            else:
                kind_colored = f"\033[1;33m{kind}\033[0m"
                location_colored = f"\033[1m{diag.location}\033[0m"
            file.write(f"{location_colored}: {kind_colored}: {diag.message}\n")
        else:
            file.write(f"{diag.location}: {kind}: {diag.message}\n")
        
        # Print source line with caret if available
        if diag.source_line:
            file.write(f"    {diag.source_line}\n")
            # Add caret pointing to the column
            caret_line = " " * (4 + diag.location.column - 1) + "^"
            if self.use_color:
                caret_line = f"\033[1;32m{caret_line}\033[0m"
            file.write(f"{caret_line}\n")
        
        # Print suggestion if available
        if diag.suggestion:
            if self.use_color:
                file.write(f"\033[1;36msuggestion:\033[0m {diag.suggestion}\n")
            else:
                file.write(f"suggestion: {diag.suggestion}\n")
        
        # Print note if available
        if diag.note:
            if self.use_color:
                file.write(f"\033[1;34mnote:\033[0m {diag.note}\n")
            else:
                file.write(f"note: {diag.note}\n")
    
    def clear(self):
        """Clear all diagnostics."""
        self.diagnostics.clear()
        self._error_count = 0
        self._warning_count = 0
