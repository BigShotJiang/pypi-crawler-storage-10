"""Utility modules for error reporting and source tracking."""
