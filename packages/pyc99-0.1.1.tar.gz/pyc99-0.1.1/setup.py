"""Setup configuration for the pyc99 compiler package."""

from setuptools import setup, find_packages
import os


def read_readme():
    """Read the README file."""
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ''


setup(
    name='pyc99',
    version='0.1.1',
    description='Educational C99 compiler written in Python - compiles C to x86/ARM assembly',
    long_description=read_readme(),
    long_description_content_type='text/markdown',
    author='Igor B.',
    author_email='stellprices@gmail.com',
    url='https://github.com/scobi84/pyc99',
    project_urls={
        'Bug Reports': 'https://github.com/scobi84/pyc99/issues',
        'Source': 'https://github.com/scobi84/pyc99',
    },
    license='MIT',
    python_requires='>=3.11',
    packages=find_packages(exclude=['tests', 'tests.*', 'examples', 'docs']),
    install_requires=[
        'click>=8.1.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.4.0',
            'pytest-cov>=4.1.0',
        ],
    },
    entry_points={
        'console_scripts': [
            'pyc99=src.main:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Education',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Compilers',
        'Topic :: Education',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: C',
        'Operating System :: OS Independent',
    ],
    keywords='compiler c99 education assembly x86 arm code-generation parser lexer',
    include_package_data=True,
    zip_safe=False,
)
