// Command-Line Argument Parser
// Demonstrates: argument parsing, option handling, string comparison

#define MAX_ARGS 20
#define MAX_ARG_LEN 100

struct Option {
    char short_name;
    char long_name[MAX_ARG_LEN];
    char value[MAX_ARG_LEN];
    int has_value;
    int is_set;
};

struct ArgParser {
    struct Option options[MAX_ARGS];
    int option_count;
    char positional[MAX_ARGS][MAX_ARG_LEN];
    int positional_count;
};

int str_cmp(char* s1, char* s2) {
    int i = 0;
    while (s1[i] != '\0' && s2[i] != '\0') {
        if (s1[i] != s2[i])
            return s1[i] - s2[i];
        i++;
    }
    return s1[i] - s2[i];
}

void str_copy(char* dest, char* src) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

void add_option(struct ArgParser* parser, char short_name, char* long_name) {
    int idx = parser->option_count++;
    parser->options[idx].short_name = short_name;
    str_copy(parser->options[idx].long_name, long_name);
    parser->options[idx].has_value = 0;
    parser->options[idx].is_set = 0;
}

void parse_args(struct ArgParser* parser, int argc, char* argv[]) {
    int i;
    parser->positional_count = 0;
    
    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            if (argv[i][1] == '-') {
                // Long option
                char* opt_name = argv[i] + 2;
                int j;
                
                for (j = 0; j < parser->option_count; j++) {
                    if (str_cmp(parser->options[j].long_name, opt_name) == 0) {
                        parser->options[j].is_set = 1;
                        
                        // Check if next arg is value
                        if (i + 1 < argc && argv[i + 1][0] != '-') {
                            str_copy(parser->options[j].value, argv[i + 1]);
                            parser->options[j].has_value = 1;
                            i++;
                        }
                        break;
                    }
                }
            } else {
                // Short option
                char opt_char = argv[i][1];
                int j;
                
                for (j = 0; j < parser->option_count; j++) {
                    if (parser->options[j].short_name == opt_char) {
                        parser->options[j].is_set = 1;
                        
                        // Check if next arg is value
                        if (i + 1 < argc && argv[i + 1][0] != '-') {
                            str_copy(parser->options[j].value, argv[i + 1]);
                            parser->options[j].has_value = 1;
                            i++;
                        }
                        break;
                    }
                }
            }
        } else {
            // Positional argument
            str_copy(parser->positional[parser->positional_count], argv[i]);
            parser->positional_count++;
        }
    }
}

int is_set(struct ArgParser* parser, char short_name) {
    int i;
    for (i = 0; i < parser->option_count; i++) {
        if (parser->options[i].short_name == short_name) {
            return parser->options[i].is_set;
        }
    }
    return 0;
}

int main() {
    struct ArgParser parser;
    parser.option_count = 0;
    
    add_option(&parser, 'v', "verbose");
    add_option(&parser, 'o', "output");
    add_option(&parser, 'h', "help");
    
    // Simulate: program -v --output file.txt input.c
    char* test_argv[5];
    char arg0[] = "program";
    char arg1[] = "-v";
    char arg2[] = "--output";
    char arg3[] = "file.txt";
    char arg4[] = "input.c";
    
    test_argv[0] = arg0;
    test_argv[1] = arg1;
    test_argv[2] = arg2;
    test_argv[3] = arg3;
    test_argv[4] = arg4;
    
    parse_args(&parser, 5, test_argv);
    
    // Return 1 if verbose is set
    return is_set(&parser, 'v');
}
