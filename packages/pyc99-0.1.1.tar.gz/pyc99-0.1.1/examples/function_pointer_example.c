/* Function pointer example demonstrating:
 * - Function pointer declarations
 * - Function pointer assignments
 * - Indirect function calls
 * - Function pointers as parameters
 */

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

/* Function that takes a function pointer as parameter */
int apply_operation(int (*operation)(int, int), int x, int y) {
    return operation(x, y);
}

int main() {
    /* Declare a function pointer */
    int (*fp)(int, int);
    
    /* Assign function to pointer */
    fp = add;
    
    /* Call function through pointer */
    int result1 = fp(10, 5);  /* result1 = 15 */
    
    /* Reassign to different function */
    fp = subtract;
    int result2 = fp(10, 5);  /* result2 = 5 */
    
    /* Use function pointer as argument */
    int result3 = apply_operation(multiply, 10, 5);  /* result3 = 50 */
    
    return result1 + result2 + result3;  /* Returns 70 */
}
