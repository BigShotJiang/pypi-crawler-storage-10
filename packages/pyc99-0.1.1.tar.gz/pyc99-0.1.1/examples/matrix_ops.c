// Matrix Operations
// Demonstrates: 2D arrays, matrix algorithms, mathematical operations

#define N 3

void matrix_multiply(int a[N][N], int b[N][N], int result[N][N]) {
    int i, j, k;
    
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            result[i][j] = 0;
            for (k = 0; k < N; k++) {
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}

void matrix_transpose(int matrix[N][N], int result[N][N]) {
    int i, j;
    
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            result[j][i] = matrix[i][j];
        }
    }
}

int matrix_determinant(int matrix[N][N]) {
    // For 3x3 matrix using cofactor expansion
    int det = 0;
    
    det = matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]);
    
    return det;
}

void matrix_add(int a[N][N], int b[N][N], int result[N][N]) {
    int i, j;
    
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            result[i][j] = a[i][j] + b[i][j];
        }
    }
}

int main() {
    int a[N][N] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    
    int b[N][N] = {
        {9, 8, 7},
        {6, 5, 4},
        {3, 2, 1}
    };
    
    int result[N][N];
    
    matrix_multiply(a, b, result);
    
    // Return result[0][0] (should be 30)
    return result[0][0];
}
