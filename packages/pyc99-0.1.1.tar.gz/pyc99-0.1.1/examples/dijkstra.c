// Dijkstra's Shortest Path Algorithm
// Demonstrates: 2D arrays, complex algorithms, graph processing

#define V 9
#define INF 999999

int min_distance(int dist[], int visited[]) {
    int min = INF;
    int min_index = 0;
    int v;
    
    for (v = 0; v < V; v++) {
        if (visited[v] == 0 && dist[v] <= min) {
            min = dist[v];
            min_index = v;
        }
    }
    
    return min_index;
}

int dijkstra(int graph[V][V], int src, int dest) {
    int dist[V];
    int visited[V];
    int i, count, v;
    
    // Initialize distances and visited array
    for (i = 0; i < V; i++) {
        dist[i] = INF;
        visited[i] = 0;
    }
    
    dist[src] = 0;
    
    // Find shortest path for all vertices
    for (count = 0; count < V - 1; count++) {
        int u = min_distance(dist, visited);
        visited[u] = 1;
        
        for (v = 0; v < V; v++) {
            if (!visited[v] && graph[u][v] && 
                dist[u] != INF && 
                dist[u] + graph[u][v] < dist[v]) {
                dist[v] = dist[u] + graph[u][v];
            }
        }
    }
    
    return dist[dest];
}

int main() {
    int graph[V][V] = {
        {0, 4, 0, 0, 0, 0, 0, 8, 0},
        {4, 0, 8, 0, 0, 0, 0, 11, 0},
        {0, 8, 0, 7, 0, 4, 0, 0, 2},
        {0, 0, 7, 0, 9, 14, 0, 0, 0},
        {0, 0, 0, 9, 0, 10, 0, 0, 0},
        {0, 0, 4, 14, 10, 0, 2, 0, 0},
        {0, 0, 0, 0, 0, 2, 0, 1, 6},
        {8, 11, 0, 0, 0, 0, 1, 0, 7},
        {0, 0, 2, 0, 0, 0, 6, 7, 0}
    };
    
    // Find shortest path from vertex 0 to vertex 4
    int result = dijkstra(graph, 0, 4);
    
    // Return result (should be 21)
    return result;
}
