// Simple Shell (Command Interpreter)
// Demonstrates: command parsing, built-in commands, string processing

#define MAX_CMD_LEN 100
#define MAX_ARGS 10
#define MAX_ARG_LEN 50
#define MAX_HISTORY 20

struct Command {
    char name[MAX_ARG_LEN];
    char args[MAX_ARGS][MAX_ARG_LEN];
    int arg_count;
};

struct Shell {
    char history[MAX_HISTORY][MAX_CMD_LEN];
    int history_count;
    int exit_code;
};

void init_shell(struct Shell* shell) {
    shell->history_count = 0;
    shell->exit_code = 0;
}

int str_cmp(char* s1, char* s2) {
    int i = 0;
    while (s1[i] != '\0' && s2[i] != '\0') {
        if (s1[i] != s2[i])
            return s1[i] - s2[i];
        i++;
    }
    return s1[i] - s2[i];
}

void str_copy(char* dest, char* src) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

void parse_command(char* input, struct Command* cmd) {
    int i = 0;
    int arg_idx = 0;
    int char_idx = 0;
    int in_name = 1;
    
    cmd->arg_count = 0;
    
    while (input[i] != '\0' && input[i] != '\n') {
        if (input[i] == ' ') {
            if (in_name && char_idx > 0) {
                cmd->name[char_idx] = '\0';
                in_name = 0;
                char_idx = 0;
            } else if (!in_name && char_idx > 0) {
                cmd->args[arg_idx][char_idx] = '\0';
                arg_idx++;
                cmd->arg_count++;
                char_idx = 0;
            }
        } else {
            if (in_name) {
                cmd->name[char_idx++] = input[i];
            } else {
                cmd->args[arg_idx][char_idx++] = input[i];
            }
        }
        i++;
    }
    
    if (in_name && char_idx > 0) {
        cmd->name[char_idx] = '\0';
    } else if (!in_name && char_idx > 0) {
        cmd->args[arg_idx][char_idx] = '\0';
        cmd->arg_count++;
    }
}

int execute_builtin(struct Shell* shell, struct Command* cmd) {
    char echo[] = "echo";
    char history[] = "history";
    char exit_cmd[] = "exit";
    
    if (str_cmp(cmd->name, echo) == 0) {
        // Echo command - just return arg count
        return cmd->arg_count;
    } else if (str_cmp(cmd->name, history) == 0) {
        // History command - return history count
        return shell->history_count;
    } else if (str_cmp(cmd->name, exit_cmd) == 0) {
        // Exit command
        shell->exit_code = 1;
        return 0;
    }
    
    return -1;  // Unknown command
}

void add_to_history(struct Shell* shell, char* cmd) {
    if (shell->history_count < MAX_HISTORY) {
        str_copy(shell->history[shell->history_count], cmd);
        shell->history_count++;
    }
}

int main() {
    struct Shell shell;
    init_shell(&shell);
    
    // Simulate some commands
    char cmd1[] = "echo hello world";
    char cmd2[] = "history";
    
    struct Command parsed;
    
    parse_command(cmd1, &parsed);
    add_to_history(&shell, cmd1);
    int result1 = execute_builtin(&shell, &parsed);
    
    parse_command(cmd2, &parsed);
    add_to_history(&shell, cmd2);
    int result2 = execute_builtin(&shell, &parsed);
    
    // Return history count (should be 2)
    return result2;
}
