// Simple Regular Expression Matcher
// Demonstrates: pattern matching, recursion, string processing
// Supports: . (any char), * (zero or more), ^ (start), $ (end)

int match_here(char* pattern, char* text);

int match_star(char c, char* pattern, char* text) {
    // Try matching zero occurrences first
    if (match_here(pattern, text))
        return 1;
    
    // Try matching one or more occurrences
    while (*text != '\0' && (*text == c || c == '.')) {
        text++;
        if (match_here(pattern, text))
            return 1;
    }
    
    return 0;
}

int match_here(char* pattern, char* text) {
    // End of pattern
    if (pattern[0] == '\0')
        return 1;
    
    // Check for $ at end
    if (pattern[0] == '$' && pattern[1] == '\0')
        return *text == '\0';
    
    // Check for * operator
    if (pattern[1] == '*')
        return match_star(pattern[0], pattern + 2, text);
    
    // End of text but pattern remains
    if (*text == '\0')
        return 0;
    
    // Match single character
    if (pattern[0] == '.' || pattern[0] == *text)
        return match_here(pattern + 1, text + 1);
    
    return 0;
}

int match(char* pattern, char* text) {
    // Check for ^ at start
    if (pattern[0] == '^')
        return match_here(pattern + 1, text);
    
    // Try matching at each position
    do {
        if (match_here(pattern, text))
            return 1;
    } while (*text++ != '\0');
    
    return 0;
}

int main() {
    char pattern1[] = "h.*o";
    char text1[] = "hello";
    
    char pattern2[] = "^test$";
    char text2[] = "test";
    
    char pattern3[] = "a*b";
    char text3[] = "aaab";
    
    int result1 = match(pattern1, text1);  // Should be 1
    int result2 = match(pattern2, text2);  // Should be 1
    int result3 = match(pattern3, text3);  // Should be 1
    
    // Return sum (should be 3)
    return result1 + result2 + result3;
}
