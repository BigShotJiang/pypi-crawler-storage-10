// Simple Memory Allocator (Bump Allocator)
// Demonstrates: memory management, pointer arithmetic, allocation strategies

#define HEAP_SIZE 1024

struct Allocator {
    char heap[HEAP_SIZE];
    int offset;
};

void init_allocator(struct Allocator* alloc) {
    alloc->offset = 0;
}

void* allocate(struct Allocator* alloc, int size) {
    // Align to 8 bytes
    int aligned_size = (size + 7) & ~7;
    
    if (alloc->offset + aligned_size > HEAP_SIZE) {
        return (void*)0;  // Out of memory
    }
    
    void* ptr = (void*)(&alloc->heap[alloc->offset]);
    alloc->offset += aligned_size;
    
    return ptr;
}

void reset_allocator(struct Allocator* alloc) {
    alloc->offset = 0;
}

int get_used_memory(struct Allocator* alloc) {
    return alloc->offset;
}

int get_free_memory(struct Allocator* alloc) {
    return HEAP_SIZE - alloc->offset;
}

// Simple free list allocator
#define MAX_BLOCKS 50

struct Block {
    int offset;
    int size;
    int is_free;
};

struct FreeListAllocator {
    char heap[HEAP_SIZE];
    struct Block blocks[MAX_BLOCKS];
    int block_count;
};

void init_freelist(struct FreeListAllocator* alloc) {
    alloc->block_count = 1;
    alloc->blocks[0].offset = 0;
    alloc->blocks[0].size = HEAP_SIZE;
    alloc->blocks[0].is_free = 1;
}

void* allocate_freelist(struct FreeListAllocator* alloc, int size) {
    int i;
    int aligned_size = (size + 7) & ~7;
    
    // Find first free block that fits
    for (i = 0; i < alloc->block_count; i++) {
        if (alloc->blocks[i].is_free && alloc->blocks[i].size >= aligned_size) {
            // Split block if necessary
            if (alloc->blocks[i].size > aligned_size && alloc->block_count < MAX_BLOCKS) {
                int new_block = alloc->block_count++;
                alloc->blocks[new_block].offset = alloc->blocks[i].offset + aligned_size;
                alloc->blocks[new_block].size = alloc->blocks[i].size - aligned_size;
                alloc->blocks[new_block].is_free = 1;
                
                alloc->blocks[i].size = aligned_size;
            }
            
            alloc->blocks[i].is_free = 0;
            return (void*)(&alloc->heap[alloc->blocks[i].offset]);
        }
    }
    
    return (void*)0;  // Out of memory
}

void free_block(struct FreeListAllocator* alloc, void* ptr) {
    int offset = (char*)ptr - alloc->heap;
    int i;
    
    for (i = 0; i < alloc->block_count; i++) {
        if (alloc->blocks[i].offset == offset) {
            alloc->blocks[i].is_free = 1;
            return;
        }
    }
}

int main() {
    struct Allocator alloc;
    init_allocator(&alloc);
    
    // Allocate some memory
    int* ptr1 = (int*)allocate(&alloc, sizeof(int) * 10);
    char* ptr2 = (char*)allocate(&alloc, 100);
    int* ptr3 = (int*)allocate(&alloc, sizeof(int) * 5);
    
    int used = get_used_memory(&alloc);
    
    // Return used memory (should be around 184 with alignment)
    return used;
}
