/* Example program demonstrating standard library support */
#include <stdio.h>

int main() {
    printf("Hello from the C99 compiler!\n");
    printf("Standard library support is working!\n");
    return 0;
}
