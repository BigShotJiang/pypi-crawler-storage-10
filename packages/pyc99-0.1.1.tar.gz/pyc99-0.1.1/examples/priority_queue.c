// Priority Queue (Min Heap) Implementation
// Demonstrates: arrays, heap operations, priority queue

#define MAX_SIZE 100

struct PriorityQueue {
    int data[MAX_SIZE];
    int size;
};

void init_queue(struct PriorityQueue* pq) {
    pq->size = 0;
}

void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int parent(int i) {
    return (i - 1) / 2;
}

int left_child(int i) {
    return 2 * i + 1;
}

int right_child(int i) {
    return 2 * i + 2;
}

void heapify_up(struct PriorityQueue* pq, int index) {
    while (index > 0 && pq->data[parent(index)] > pq->data[index]) {
        swap(&pq->data[parent(index)], &pq->data[index]);
        index = parent(index);
    }
}

void heapify_down(struct PriorityQueue* pq, int index) {
    int min_index = index;
    int l = left_child(index);
    int r = right_child(index);
    
    if (l < pq->size && pq->data[l] < pq->data[min_index])
        min_index = l;
    
    if (r < pq->size && pq->data[r] < pq->data[min_index])
        min_index = r;
    
    if (index != min_index) {
        swap(&pq->data[index], &pq->data[min_index]);
        heapify_down(pq, min_index);
    }
}

void insert(struct PriorityQueue* pq, int value) {
    if (pq->size >= MAX_SIZE)
        return;
    
    pq->data[pq->size] = value;
    heapify_up(pq, pq->size);
    pq->size++;
}

int extract_min(struct PriorityQueue* pq) {
    if (pq->size == 0)
        return -1;
    
    int min = pq->data[0];
    pq->data[0] = pq->data[pq->size - 1];
    pq->size--;
    heapify_down(pq, 0);
    
    return min;
}

int peek(struct PriorityQueue* pq) {
    if (pq->size == 0)
        return -1;
    return pq->data[0];
}

int main() {
    struct PriorityQueue pq;
    init_queue(&pq);
    
    insert(&pq, 30);
    insert(&pq, 10);
    insert(&pq, 50);
    insert(&pq, 20);
    insert(&pq, 40);
    
    int first = extract_min(&pq);   // Should be 10
    int second = extract_min(&pq);  // Should be 20
    
    // Return sum (should be 30)
    return first + second;
}
