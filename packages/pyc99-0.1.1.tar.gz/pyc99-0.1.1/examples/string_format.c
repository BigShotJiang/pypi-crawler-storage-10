// String Formatting Utility
// Demonstrates: string building, number to string conversion, formatting

#define MAX_OUTPUT 200

void int_to_str(int num, char* str) {
    int i = 0;
    int is_negative = 0;
    
    if (num == 0) {
        str[0] = '0';
        str[1] = '\0';
        return;
    }
    
    if (num < 0) {
        is_negative = 1;
        num = -num;
    }
    
    while (num > 0) {
        str[i++] = (num % 10) + '0';
        num = num / 10;
    }
    
    if (is_negative)
        str[i++] = '-';
    
    str[i] = '\0';
    
    // Reverse the string
    int start = 0;
    int end = i - 1;
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

int str_len(char* str) {
    int len = 0;
    while (str[len] != '\0')
        len++;
    return len;
}

void str_append(char* dest, char* src) {
    int dest_len = str_len(dest);
    int i = 0;
    
    while (src[i] != '\0') {
        dest[dest_len + i] = src[i];
        i++;
    }
    dest[dest_len + i] = '\0';
}

// Simple format function: supports %d (int) and %s (string)
void format(char* output, char* fmt, int arg1, char* arg2) {
    int i = 0;
    int out_idx = 0;
    
    output[0] = '\0';
    
    while (fmt[i] != '\0') {
        if (fmt[i] == '%' && fmt[i + 1] != '\0') {
            if (fmt[i + 1] == 'd') {
                char num_str[20];
                int_to_str(arg1, num_str);
                str_append(output, num_str);
                i += 2;
            } else if (fmt[i + 1] == 's') {
                str_append(output, arg2);
                i += 2;
            } else {
                output[out_idx++] = fmt[i++];
            }
        } else {
            int len = str_len(output);
            output[len] = fmt[i];
            output[len + 1] = '\0';
            i++;
        }
    }
}

int main() {
    char output[MAX_OUTPUT];
    char fmt[] = "Value: %d, Name: %s";
    char name[] = "test";
    
    format(output, fmt, 42, name);
    
    // Return length of formatted string
    return str_len(output);
}
