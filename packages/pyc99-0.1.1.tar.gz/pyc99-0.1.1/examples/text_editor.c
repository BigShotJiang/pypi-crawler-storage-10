// Basic Text Editor (Buffer Management)
// Demonstrates: text buffer, cursor movement, editing operations

#define MAX_LINES 100
#define MAX_LINE_LEN 200
#define MAX_UNDO 50

struct Line {
    char data[MAX_LINE_LEN];
    int length;
};

struct TextBuffer {
    struct Line lines[MAX_LINES];
    int line_count;
    int cursor_line;
    int cursor_col;
};

struct UndoState {
    struct TextBuffer buffer;
};

struct Editor {
    struct TextBuffer buffer;
    struct UndoState undo_stack[MAX_UNDO];
    int undo_count;
};

void init_editor(struct Editor* editor) {
    editor->buffer.line_count = 1;
    editor->buffer.lines[0].length = 0;
    editor->buffer.lines[0].data[0] = '\0';
    editor->buffer.cursor_line = 0;
    editor->buffer.cursor_col = 0;
    editor->undo_count = 0;
}

void insert_char(struct Editor* editor, char c) {
    struct Line* line = &editor->buffer.lines[editor->buffer.cursor_line];
    
    if (line->length < MAX_LINE_LEN - 1) {
        // Shift characters right
        int i;
        for (i = line->length; i > editor->buffer.cursor_col; i--) {
            line->data[i] = line->data[i - 1];
        }
        
        line->data[editor->buffer.cursor_col] = c;
        line->length++;
        line->data[line->length] = '\0';
        editor->buffer.cursor_col++;
    }
}

void delete_char(struct Editor* editor) {
    struct Line* line = &editor->buffer.lines[editor->buffer.cursor_line];
    
    if (editor->buffer.cursor_col > 0) {
        // Shift characters left
        int i;
        for (i = editor->buffer.cursor_col - 1; i < line->length - 1; i++) {
            line->data[i] = line->data[i + 1];
        }
        
        line->length--;
        line->data[line->length] = '\0';
        editor->buffer.cursor_col--;
    }
}

void insert_line(struct Editor* editor) {
    if (editor->buffer.line_count < MAX_LINES) {
        // Shift lines down
        int i;
        for (i = editor->buffer.line_count; i > editor->buffer.cursor_line + 1; i--) {
            editor->buffer.lines[i] = editor->buffer.lines[i - 1];
        }
        
        editor->buffer.line_count++;
        editor->buffer.cursor_line++;
        editor->buffer.lines[editor->buffer.cursor_line].length = 0;
        editor->buffer.lines[editor->buffer.cursor_line].data[0] = '\0';
        editor->buffer.cursor_col = 0;
    }
}

void move_cursor_left(struct Editor* editor) {
    if (editor->buffer.cursor_col > 0) {
        editor->buffer.cursor_col--;
    }
}

void move_cursor_right(struct Editor* editor) {
    struct Line* line = &editor->buffer.lines[editor->buffer.cursor_line];
    if (editor->buffer.cursor_col < line->length) {
        editor->buffer.cursor_col++;
    }
}

void move_cursor_up(struct Editor* editor) {
    if (editor->buffer.cursor_line > 0) {
        editor->buffer.cursor_line--;
        struct Line* line = &editor->buffer.lines[editor->buffer.cursor_line];
        if (editor->buffer.cursor_col > line->length) {
            editor->buffer.cursor_col = line->length;
        }
    }
}

void move_cursor_down(struct Editor* editor) {
    if (editor->buffer.cursor_line < editor->buffer.line_count - 1) {
        editor->buffer.cursor_line++;
        struct Line* line = &editor->buffer.lines[editor->buffer.cursor_line];
        if (editor->buffer.cursor_col > line->length) {
            editor->buffer.cursor_col = line->length;
        }
    }
}

int get_total_chars(struct Editor* editor) {
    int total = 0;
    int i;
    for (i = 0; i < editor->buffer.line_count; i++) {
        total += editor->buffer.lines[i].length;
    }
    return total;
}

int main() {
    struct Editor editor;
    init_editor(&editor);
    
    // Simulate typing "Hello"
    insert_char(&editor, 'H');
    insert_char(&editor, 'e');
    insert_char(&editor, 'l');
    insert_char(&editor, 'l');
    insert_char(&editor, 'o');
    
    // Insert new line
    insert_line(&editor);
    
    // Type "World"
    insert_char(&editor, 'W');
    insert_char(&editor, 'o');
    insert_char(&editor, 'r');
    insert_char(&editor, 'l');
    insert_char(&editor, 'd');
    
    // Return total character count (should be 10)
    return get_total_chars(&editor);
}
