// Run-Length Encoding (RLE) Compression
// Demonstrates: compression algorithms, encoding/decoding, data transformation

#define MAX_INPUT 200
#define MAX_OUTPUT 400

int encode_rle(char* input, int input_len, char* output) {
    int i = 0;
    int out_idx = 0;
    
    while (i < input_len) {
        char current = input[i];
        int count = 1;
        
        // Count consecutive occurrences
        while (i + count < input_len && input[i + count] == current && count < 255) {
            count++;
        }
        
        // Write count and character
        output[out_idx++] = (char)count;
        output[out_idx++] = current;
        
        i += count;
    }
    
    return out_idx;
}

int decode_rle(char* input, int input_len, char* output) {
    int i = 0;
    int out_idx = 0;
    
    while (i < input_len) {
        int count = (unsigned char)input[i++];
        char character = input[i++];
        
        int j;
        for (j = 0; j < count; j++) {
            output[out_idx++] = character;
        }
    }
    
    return out_idx;
}

int calculate_compression_ratio(int original_size, int compressed_size) {
    // Return percentage: (compressed / original) * 100
    return (compressed_size * 100) / original_size;
}

int main() {
    char input[] = "aaaaaabbbbbcccccddddd";
    int input_len = 21;
    
    char encoded[MAX_OUTPUT];
    char decoded[MAX_OUTPUT];
    
    int encoded_len = encode_rle(input, input_len, encoded);
    int decoded_len = decode_rle(encoded, encoded_len, decoded);
    
    // Verify decoded matches original
    int matches = 1;
    int i;
    for (i = 0; i < input_len; i++) {
        if (input[i] != decoded[i]) {
            matches = 0;
            break;
        }
    }
    
    // Return compression ratio (should be around 57%)
    return calculate_compression_ratio(input_len, encoded_len);
}
