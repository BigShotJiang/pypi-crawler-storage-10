// Trie (Prefix Tree) Implementation
// Demonstrates: tree structures, string processing, character arrays

#define ALPHABET_SIZE 26
#define MAX_NODES 1000

struct TrieNode {
    int children[ALPHABET_SIZE];  // Indices to child nodes (-1 if null)
    int is_end_of_word;
};

struct Trie {
    struct TrieNode nodes[MAX_NODES];
    int node_count;
};

void init_trie(struct Trie* trie) {
    int i, j;
    trie->node_count = 1;  // Root node
    
    for (i = 0; i < MAX_NODES; i++) {
        trie->nodes[i].is_end_of_word = 0;
        for (j = 0; j < ALPHABET_SIZE; j++) {
            trie->nodes[i].children[j] = -1;
        }
    }
}

int create_node(struct Trie* trie) {
    int idx = trie->node_count++;
    int i;
    trie->nodes[idx].is_end_of_word = 0;
    for (i = 0; i < ALPHABET_SIZE; i++) {
        trie->nodes[idx].children[i] = -1;
    }
    return idx;
}

void insert(struct Trie* trie, char* word) {
    int node_idx = 0;  // Start at root
    int i = 0;
    
    while (word[i] != '\0') {
        int index = word[i] - 'a';
        
        if (index < 0 || index >= ALPHABET_SIZE)
            return;
        
        if (trie->nodes[node_idx].children[index] == -1) {
            trie->nodes[node_idx].children[index] = create_node(trie);
        }
        
        node_idx = trie->nodes[node_idx].children[index];
        i++;
    }
    
    trie->nodes[node_idx].is_end_of_word = 1;
}

int search(struct Trie* trie, char* word) {
    int node_idx = 0;  // Start at root
    int i = 0;
    
    while (word[i] != '\0') {
        int index = word[i] - 'a';
        
        if (index < 0 || index >= ALPHABET_SIZE)
            return 0;
        
        if (trie->nodes[node_idx].children[index] == -1)
            return 0;
        
        node_idx = trie->nodes[node_idx].children[index];
        i++;
    }
    
    return trie->nodes[node_idx].is_end_of_word;
}

int starts_with(struct Trie* trie, char* prefix) {
    int node_idx = 0;  // Start at root
    int i = 0;
    
    while (prefix[i] != '\0') {
        int index = prefix[i] - 'a';
        
        if (index < 0 || index >= ALPHABET_SIZE)
            return 0;
        
        if (trie->nodes[node_idx].children[index] == -1)
            return 0;
        
        node_idx = trie->nodes[node_idx].children[index];
        i++;
    }
    
    return 1;
}

int main() {
    struct Trie trie;
    init_trie(&trie);
    
    char word1[] = "hello";
    char word2[] = "world";
    char word3[] = "help";
    
    insert(&trie, word1);
    insert(&trie, word2);
    insert(&trie, word3);
    
    char search1[] = "hello";
    char search2[] = "hel";
    char prefix[] = "hel";
    
    int found1 = search(&trie, search1);  // Should be 1
    int found2 = search(&trie, search2);  // Should be 0
    int has_prefix = starts_with(&trie, prefix);  // Should be 1
    
    // Return sum (should be 2)
    return found1 + found2 + has_prefix;
}
