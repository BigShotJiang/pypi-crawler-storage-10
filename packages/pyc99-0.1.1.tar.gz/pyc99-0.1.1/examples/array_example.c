int main() {
    int numbers[5];
    numbers[0] = 10;
    numbers[1] = 25;
    numbers[2] = 5;
    numbers[3] = 42;
    numbers[4] = 18;
    
    return numbers[0] + numbers[1];
}
