// Sieve of Eratosthenes - Prime Number Generator
// Demonstrates: arrays, algorithms, number theory

#define MAX_N 100

void sieve_of_eratosthenes(int n, int primes[], int* prime_count) {
    int is_prime[MAX_N];
    int i, j;
    
    // Initialize all as prime
    for (i = 0; i < n; i++) {
        is_prime[i] = 1;
    }
    
    is_prime[0] = 0;  // 0 is not prime
    is_prime[1] = 0;  // 1 is not prime
    
    // Sieve
    for (i = 2; i * i < n; i++) {
        if (is_prime[i]) {
            for (j = i * i; j < n; j += i) {
                is_prime[j] = 0;
            }
        }
    }
    
    // Collect primes
    *prime_count = 0;
    for (i = 2; i < n; i++) {
        if (is_prime[i]) {
            primes[*prime_count] = i;
            (*prime_count)++;
        }
    }
}

int is_prime_simple(int n) {
    int i;
    
    if (n <= 1)
        return 0;
    if (n <= 3)
        return 1;
    if (n % 2 == 0 || n % 3 == 0)
        return 0;
    
    for (i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0)
            return 0;
    }
    
    return 1;
}

int nth_prime(int n) {
    int count = 0;
    int num = 2;
    
    while (count < n) {
        if (is_prime_simple(num)) {
            count++;
            if (count == n)
                return num;
        }
        num++;
    }
    
    return -1;
}

int main() {
    int primes[MAX_N];
    int prime_count;
    
    sieve_of_eratosthenes(50, primes, &prime_count);
    
    // Return number of primes less than 50 (should be 15)
    return prime_count;
}
