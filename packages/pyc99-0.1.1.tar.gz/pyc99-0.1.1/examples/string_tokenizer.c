// String Tokenizer
// Demonstrates: string manipulation, parsing, character processing

#define MAX_TOKENS 50
#define MAX_TOKEN_LEN 100

struct Token {
    char data[MAX_TOKEN_LEN];
    int length;
};

struct Tokenizer {
    struct Token tokens[MAX_TOKENS];
    int token_count;
};

int is_delimiter(char c, char* delimiters) {
    int i = 0;
    while (delimiters[i] != '\0') {
        if (c == delimiters[i])
            return 1;
        i++;
    }
    return 0;
}

void tokenize(struct Tokenizer* tokenizer, char* str, char* delimiters) {
    int i = 0;
    int token_idx = 0;
    int char_idx = 0;
    
    tokenizer->token_count = 0;
    
    while (str[i] != '\0') {
        if (is_delimiter(str[i], delimiters)) {
            if (char_idx > 0) {
                tokenizer->tokens[token_idx].data[char_idx] = '\0';
                tokenizer->tokens[token_idx].length = char_idx;
                token_idx++;
                tokenizer->token_count++;
                char_idx = 0;
            }
        } else {
            tokenizer->tokens[token_idx].data[char_idx] = str[i];
            char_idx++;
        }
        i++;
    }
    
    if (char_idx > 0) {
        tokenizer->tokens[token_idx].data[char_idx] = '\0';
        tokenizer->tokens[token_idx].length = char_idx;
        tokenizer->token_count++;
    }
}

int main() {
    struct Tokenizer tokenizer;
    char str[] = "hello,world,this,is,a,test";
    char delimiters[] = ",";
    
    tokenize(&tokenizer, str, delimiters);
    
    // Return number of tokens (should be 6)
    return tokenizer.token_count;
}
