// Vector Operations
// Demonstrates: arrays as vectors, mathematical operations, floating point

#define DIM 3

struct Vector {
    float x;
    float y;
    float z;
};

float vector_dot(struct Vector* a, struct Vector* b) {
    return a->x * b->x + a->y * b->y + a->z * b->z;
}

struct Vector vector_cross(struct Vector* a, struct Vector* b) {
    struct Vector result;
    result.x = a->y * b->z - a->z * b->y;
    result.y = a->z * b->x - a->x * b->z;
    result.z = a->x * b->y - a->y * b->x;
    return result;
}

struct Vector vector_add(struct Vector* a, struct Vector* b) {
    struct Vector result;
    result.x = a->x + b->x;
    result.y = a->y + b->y;
    result.z = a->z + b->z;
    return result;
}

struct Vector vector_scale(struct Vector* v, float scalar) {
    struct Vector result;
    result.x = v->x * scalar;
    result.y = v->y * scalar;
    result.z = v->z * scalar;
    return result;
}

float vector_magnitude(struct Vector* v) {
    float sum = v->x * v->x + v->y * v->y + v->z * v->z;
    
    // Simple square root approximation using Newton's method
    float x = sum;
    float guess = sum / 2.0f;
    int i;
    
    for (i = 0; i < 10; i++) {
        if (guess == 0.0f)
            break;
        guess = (guess + x / guess) / 2.0f;
    }
    
    return guess;
}

int main() {
    struct Vector a;
    a.x = 1.0f;
    a.y = 2.0f;
    a.z = 3.0f;
    
    struct Vector b;
    b.x = 4.0f;
    b.y = 5.0f;
    b.z = 6.0f;
    
    float dot = vector_dot(&a, &b);
    struct Vector cross = vector_cross(&a, &b);
    
    // Return dot product as int (should be 32)
    return (int)dot;
}
