// Simple JSON Parser (supports objects, strings, numbers only)
// Demonstrates: recursive parsing, state machines, data structures

#define MAX_TOKENS 100
#define MAX_STRING_LEN 100

enum TokenType {
    TOKEN_LBRACE,
    TOKEN_RBRACE,
    TOKEN_LBRACKET,
    TOKEN_RBRACKET,
    TOKEN_COLON,
    TOKEN_COMMA,
    TOKEN_STRING,
    TOKEN_NUMBER,
    TOKEN_EOF
};

struct Token {
    enum TokenType type;
    char string_value[MAX_STRING_LEN];
    int number_value;
};

struct Tokenizer {
    char* input;
    int pos;
};

void skip_whitespace(struct Tokenizer* t) {
    while (t->input[t->pos] == ' ' || t->input[t->pos] == '\n' || 
           t->input[t->pos] == '\r' || t->input[t->pos] == '\t') {
        t->pos++;
    }
}

struct Token next_token(struct Tokenizer* t) {
    struct Token token;
    skip_whitespace(t);
    
    char c = t->input[t->pos];
    
    if (c == '\0') {
        token.type = TOKEN_EOF;
        return token;
    }
    
    if (c == '{') {
        token.type = TOKEN_LBRACE;
        t->pos++;
        return token;
    }
    
    if (c == '}') {
        token.type = TOKEN_RBRACE;
        t->pos++;
        return token;
    }
    
    if (c == ':') {
        token.type = TOKEN_COLON;
        t->pos++;
        return token;
    }
    
    if (c == ',') {
        token.type = TOKEN_COMMA;
        t->pos++;
        return token;
    }
    
    if (c == '"') {
        token.type = TOKEN_STRING;
        t->pos++;
        int i = 0;
        
        while (t->input[t->pos] != '"' && t->input[t->pos] != '\0') {
            token.string_value[i++] = t->input[t->pos++];
        }
        token.string_value[i] = '\0';
        
        if (t->input[t->pos] == '"')
            t->pos++;
        
        return token;
    }
    
    if (c >= '0' && c <= '9') {
        token.type = TOKEN_NUMBER;
        token.number_value = 0;
        
        while (t->input[t->pos] >= '0' && t->input[t->pos] <= '9') {
            token.number_value = token.number_value * 10 + (t->input[t->pos] - '0');
            t->pos++;
        }
        
        return token;
    }
    
    token.type = TOKEN_EOF;
    return token;
}

int parse_value(struct Tokenizer* t) {
    struct Token token = next_token(t);
    
    if (token.type == TOKEN_NUMBER) {
        return token.number_value;
    }
    
    if (token.type == TOKEN_LBRACE) {
        // Parse object
        while (1) {
            struct Token key = next_token(t);
            if (key.type == TOKEN_RBRACE)
                break;
            
            next_token(t);  // Skip colon
            int value = parse_value(t);
            
            struct Token comma = next_token(t);
            if (comma.type == TOKEN_RBRACE)
                break;
        }
    }
    
    return 0;
}

int main() {
    char json[] = "{\"name\":\"test\",\"age\":25,\"score\":95}";
    
    struct Tokenizer t;
    t.input = json;
    t.pos = 0;
    
    parse_value(&t);
    
    // Simple test: return 1 if parsing succeeded
    return 1;
}
