// Example demonstrating floating-point support in the C99 compiler

float add_floats(float a, float b) {
    return a + b;
}

double multiply_doubles(double x, double y) {
    return x * y;
}

float convert_int_to_float(int n) {
    return n;
}

int convert_float_to_int(float f) {
    return f;
}

int compare_floats(float a, float b) {
    if (a < b) {
        return -1;
    } else if (a > b) {
        return 1;
    } else {
        return 0;
    }
}

int main() {
    // Float literals with different suffixes
    float f1 = 3.14f;           // float suffix
    float f2 = 2.71828f;        // float suffix
    double d1 = 3.14159;        // default double
    long double ld = 2.71828L;  // long double suffix
    
    // Hexadecimal float literals (C99)
    float hex_float = 0x1.8p3f;  // 1.5 * 2^3 = 12.0
    double hex_double = 0x1.0p0; // 1.0 * 2^0 = 1.0
    
    // Arithmetic operations
    float sum = add_floats(f1, f2);
    double product = multiply_doubles(d1, 3.0);
    
    // Type conversions
    float from_int = convert_int_to_float(42);
    int to_int = convert_float_to_int(3.14f);
    
    // Comparisons
    int cmp_result = compare_floats(f1, f2);
    
    // Mixed arithmetic
    float mixed = f1 + 10;  // int promoted to float
    
    return 0;
}
