// AVL Tree Implementation (simplified)
// Demonstrates: structs, recursion, tree operations, balancing

#define MAX_NODES 100

struct Node {
    int key;
    int height;
    int left;   // Index in array (-1 if null)
    int right;  // Index in array (-1 if null)
};

struct AVLTree {
    struct Node nodes[MAX_NODES];
    int node_count;
};

int max(int a, int b) {
    return (a > b) ? a : b;
}

int get_height(struct AVLTree* tree, int node_idx) {
    if (node_idx == -1)
        return 0;
    return tree->nodes[node_idx].height;
}

int get_balance(struct AVLTree* tree, int node_idx) {
    if (node_idx == -1)
        return 0;
    return get_height(tree, tree->nodes[node_idx].left) - 
           get_height(tree, tree->nodes[node_idx].right);
}

int create_node(struct AVLTree* tree, int key) {
    int idx = tree->node_count++;
    tree->nodes[idx].key = key;
    tree->nodes[idx].height = 1;
    tree->nodes[idx].left = -1;
    tree->nodes[idx].right = -1;
    return idx;
}

int rotate_right(struct AVLTree* tree, int y_idx) {
    int x_idx = tree->nodes[y_idx].left;
    int T2_idx = tree->nodes[x_idx].right;
    
    tree->nodes[x_idx].right = y_idx;
    tree->nodes[y_idx].left = T2_idx;
    
    tree->nodes[y_idx].height = max(get_height(tree, tree->nodes[y_idx].left),
                                     get_height(tree, tree->nodes[y_idx].right)) + 1;
    tree->nodes[x_idx].height = max(get_height(tree, tree->nodes[x_idx].left),
                                     get_height(tree, tree->nodes[x_idx].right)) + 1;
    
    return x_idx;
}

int rotate_left(struct AVLTree* tree, int x_idx) {
    int y_idx = tree->nodes[x_idx].right;
    int T2_idx = tree->nodes[y_idx].left;
    
    tree->nodes[y_idx].left = x_idx;
    tree->nodes[x_idx].right = T2_idx;
    
    tree->nodes[x_idx].height = max(get_height(tree, tree->nodes[x_idx].left),
                                     get_height(tree, tree->nodes[x_idx].right)) + 1;
    tree->nodes[y_idx].height = max(get_height(tree, tree->nodes[y_idx].left),
                                     get_height(tree, tree->nodes[y_idx].right)) + 1;
    
    return y_idx;
}

int insert(struct AVLTree* tree, int node_idx, int key) {
    if (node_idx == -1)
        return create_node(tree, key);
    
    if (key < tree->nodes[node_idx].key)
        tree->nodes[node_idx].left = insert(tree, tree->nodes[node_idx].left, key);
    else if (key > tree->nodes[node_idx].key)
        tree->nodes[node_idx].right = insert(tree, tree->nodes[node_idx].right, key);
    else
        return node_idx;
    
    tree->nodes[node_idx].height = 1 + max(get_height(tree, tree->nodes[node_idx].left),
                                             get_height(tree, tree->nodes[node_idx].right));
    
    int balance = get_balance(tree, node_idx);
    
    // Left Left Case
    if (balance > 1 && key < tree->nodes[tree->nodes[node_idx].left].key)
        return rotate_right(tree, node_idx);
    
    // Right Right Case
    if (balance < -1 && key > tree->nodes[tree->nodes[node_idx].right].key)
        return rotate_left(tree, node_idx);
    
    // Left Right Case
    if (balance > 1 && key > tree->nodes[tree->nodes[node_idx].left].key) {
        tree->nodes[node_idx].left = rotate_left(tree, tree->nodes[node_idx].left);
        return rotate_right(tree, node_idx);
    }
    
    // Right Left Case
    if (balance < -1 && key < tree->nodes[tree->nodes[node_idx].right].key) {
        tree->nodes[node_idx].right = rotate_right(tree, tree->nodes[node_idx].right);
        return rotate_left(tree, node_idx);
    }
    
    return node_idx;
}

int main() {
    struct AVLTree tree;
    tree.node_count = 0;
    
    int root = -1;
    root = insert(&tree, root, 10);
    root = insert(&tree, root, 20);
    root = insert(&tree, root, 30);
    root = insert(&tree, root, 40);
    root = insert(&tree, root, 50);
    
    // Return root key (should be 20 after balancing)
    return tree.nodes[root].key;
}
