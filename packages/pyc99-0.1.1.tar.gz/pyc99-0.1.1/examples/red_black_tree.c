// Red-Black Tree (simplified insertion only)
// Demonstrates: complex tree operations, balancing, color properties

#define MAX_NODES 100
#define RED 0
#define BLACK 1

struct Node {
    int key;
    int color;
    int left;
    int right;
    int parent;
};

struct RBTree {
    struct Node nodes[MAX_NODES];
    int node_count;
    int root;
};

void init_tree(struct RBTree* tree) {
    tree->node_count = 0;
    tree->root = -1;
}

int create_node(struct RBTree* tree, int key) {
    int idx = tree->node_count++;
    tree->nodes[idx].key = key;
    tree->nodes[idx].color = RED;
    tree->nodes[idx].left = -1;
    tree->nodes[idx].right = -1;
    tree->nodes[idx].parent = -1;
    return idx;
}

void rotate_left(struct RBTree* tree, int x) {
    int y = tree->nodes[x].right;
    tree->nodes[x].right = tree->nodes[y].left;
    
    if (tree->nodes[y].left != -1)
        tree->nodes[tree->nodes[y].left].parent = x;
    
    tree->nodes[y].parent = tree->nodes[x].parent;
    
    if (tree->nodes[x].parent == -1)
        tree->root = y;
    else if (x == tree->nodes[tree->nodes[x].parent].left)
        tree->nodes[tree->nodes[x].parent].left = y;
    else
        tree->nodes[tree->nodes[x].parent].right = y;
    
    tree->nodes[y].left = x;
    tree->nodes[x].parent = y;
}

void rotate_right(struct RBTree* tree, int y) {
    int x = tree->nodes[y].left;
    tree->nodes[y].left = tree->nodes[x].right;
    
    if (tree->nodes[x].right != -1)
        tree->nodes[tree->nodes[x].right].parent = y;
    
    tree->nodes[x].parent = tree->nodes[y].parent;
    
    if (tree->nodes[y].parent == -1)
        tree->root = x;
    else if (y == tree->nodes[tree->nodes[y].parent].right)
        tree->nodes[tree->nodes[y].parent].right = x;
    else
        tree->nodes[tree->nodes[y].parent].left = x;
    
    tree->nodes[x].right = y;
    tree->nodes[y].parent = x;
}

void fix_insert(struct RBTree* tree, int k) {
    while (k != tree->root && tree->nodes[tree->nodes[k].parent].color == RED) {
        int parent = tree->nodes[k].parent;
        int grandparent = tree->nodes[parent].parent;
        
        if (parent == tree->nodes[grandparent].left) {
            int uncle = tree->nodes[grandparent].right;
            
            if (uncle != -1 && tree->nodes[uncle].color == RED) {
                tree->nodes[parent].color = BLACK;
                tree->nodes[uncle].color = BLACK;
                tree->nodes[grandparent].color = RED;
                k = grandparent;
            } else {
                if (k == tree->nodes[parent].right) {
                    k = parent;
                    rotate_left(tree, k);
                    parent = tree->nodes[k].parent;
                    grandparent = tree->nodes[parent].parent;
                }
                tree->nodes[parent].color = BLACK;
                tree->nodes[grandparent].color = RED;
                rotate_right(tree, grandparent);
            }
        } else {
            int uncle = tree->nodes[grandparent].left;
            
            if (uncle != -1 && tree->nodes[uncle].color == RED) {
                tree->nodes[parent].color = BLACK;
                tree->nodes[uncle].color = BLACK;
                tree->nodes[grandparent].color = RED;
                k = grandparent;
            } else {
                if (k == tree->nodes[parent].left) {
                    k = parent;
                    rotate_right(tree, k);
                    parent = tree->nodes[k].parent;
                    grandparent = tree->nodes[parent].parent;
                }
                tree->nodes[parent].color = BLACK;
                tree->nodes[grandparent].color = RED;
                rotate_left(tree, grandparent);
            }
        }
    }
    tree->nodes[tree->root].color = BLACK;
}

void insert(struct RBTree* tree, int key) {
    int new_node = create_node(tree, key);
    
    if (tree->root == -1) {
        tree->root = new_node;
        tree->nodes[new_node].color = BLACK;
        return;
    }
    
    int current = tree->root;
    int parent = -1;
    
    while (current != -1) {
        parent = current;
        if (key < tree->nodes[current].key)
            current = tree->nodes[current].left;
        else
            current = tree->nodes[current].right;
    }
    
    tree->nodes[new_node].parent = parent;
    
    if (key < tree->nodes[parent].key)
        tree->nodes[parent].left = new_node;
    else
        tree->nodes[parent].right = new_node;
    
    fix_insert(tree, new_node);
}

int main() {
    struct RBTree tree;
    init_tree(&tree);
    
    insert(&tree, 10);
    insert(&tree, 20);
    insert(&tree, 30);
    insert(&tree, 15);
    
    // Return root key
    return tree.nodes[tree.root].key;
}
