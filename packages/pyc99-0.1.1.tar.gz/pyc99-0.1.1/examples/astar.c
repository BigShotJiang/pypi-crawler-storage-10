// A* Pathfinding Algorithm (simplified grid-based)
// Demonstrates: complex algorithms, structs, priority queue simulation

#define GRID_SIZE 5
#define MAX_NODES 100

struct Node {
    int x;
    int y;
    int g;  // Cost from start
    int h;  // Heuristic to goal
    int f;  // Total cost (g + h)
    int closed;
};

int abs_val(int x) {
    return x < 0 ? -x : x;
}

int manhattan_distance(int x1, int y1, int x2, int y2) {
    return abs_val(x1 - x2) + abs_val(y1 - y2);
}

int find_min_f(struct Node nodes[], int count) {
    int min_idx = -1;
    int min_f = 999999;
    int i;
    
    for (i = 0; i < count; i++) {
        if (!nodes[i].closed && nodes[i].f < min_f) {
            min_f = nodes[i].f;
            min_idx = i;
        }
    }
    
    return min_idx;
}

int astar(int grid[GRID_SIZE][GRID_SIZE], int start_x, int start_y, 
          int goal_x, int goal_y) {
    struct Node nodes[MAX_NODES];
    int node_count = 0;
    int found = 0;
    
    // Add start node
    nodes[0].x = start_x;
    nodes[0].y = start_y;
    nodes[0].g = 0;
    nodes[0].h = manhattan_distance(start_x, start_y, goal_x, goal_y);
    nodes[0].f = nodes[0].h;
    nodes[0].closed = 0;
    node_count = 1;
    
    // Simplified A* - just find path cost
    while (node_count > 0 && !found) {
        int current = find_min_f(nodes, node_count);
        
        if (current == -1)
            break;
        
        struct Node* curr = &nodes[current];
        
        if (curr->x == goal_x && curr->y == goal_y) {
            found = 1;
            return curr->g;
        }
        
        curr->closed = 1;
        
        // Check neighbors (simplified - only right and down)
        int dx[2] = {1, 0};
        int dy[2] = {0, 1};
        int i;
        
        for (i = 0; i < 2; i++) {
            int nx = curr->x + dx[i];
            int ny = curr->y + dy[i];
            
            if (nx < GRID_SIZE && ny < GRID_SIZE && 
                grid[nx][ny] == 0 && node_count < MAX_NODES) {
                nodes[node_count].x = nx;
                nodes[node_count].y = ny;
                nodes[node_count].g = curr->g + 1;
                nodes[node_count].h = manhattan_distance(nx, ny, goal_x, goal_y);
                nodes[node_count].f = nodes[node_count].g + nodes[node_count].h;
                nodes[node_count].closed = 0;
                node_count++;
            }
        }
    }
    
    return -1;  // No path found
}

int main() {
    int grid[GRID_SIZE][GRID_SIZE] = {
        {0, 0, 0, 0, 0},
        {0, 1, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {0, 0, 1, 1, 0},
        {0, 0, 0, 0, 0}
    };
    
    int path_cost = astar(grid, 0, 0, 4, 4);
    
    // Return path cost (should be 8)
    return path_cost;
}
