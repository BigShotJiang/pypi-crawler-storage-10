// Example demonstrating macro usage

#include <stdio.h>

// Object-like macros
#define MAX_SIZE 100
#define PI 3.14159

// Function-like macros
#define SQUARE(x) ((x) * (x))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))

// Stringification
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

// Token pasting
#define CONCAT(a, b) a##b

int main() {
    // Using object-like macros
    int buffer[MAX_SIZE];
    double circle_area = PI * SQUARE(5);
    
    // Using function-like macros
    int a = 10;
    int b = 20;
    int maximum = MAX(a, b);
    int minimum = MIN(a, b);
    
    // Using stringification
    char *name = STRINGIFY(hello);
    char *version = TOSTRING(MAX_SIZE);
    
    // Using token pasting
    int xy = 42;
    int value = CONCAT(x, y);
    
    // Predefined macros
    printf("File: %s\n", __FILE__);
    printf("Line: %d\n", __LINE__);
    printf("Date: %s\n", __DATE__);
    printf("Time: %s\n", __TIME__);
    printf("C Standard: %ld\n", __STDC_VERSION__);
    
    return 0;
}
