// INI File Parser
// Demonstrates: configuration parsing, string processing, key-value pairs

#define MAX_SECTIONS 10
#define MAX_KEYS 50
#define MAX_NAME_LEN 50
#define MAX_VALUE_LEN 100

struct KeyValue {
    char key[MAX_NAME_LEN];
    char value[MAX_VALUE_LEN];
};

struct Section {
    char name[MAX_NAME_LEN];
    struct KeyValue pairs[MAX_KEYS];
    int pair_count;
};

struct INIFile {
    struct Section sections[MAX_SECTIONS];
    int section_count;
};

int is_whitespace(char c) {
    return c == ' ' || c == '\t' || c == '\r';
}

void trim(char* str) {
    int start = 0;
    int end = 0;
    int i = 0;
    
    // Find first non-whitespace
    while (str[start] != '\0' && is_whitespace(str[start]))
        start++;
    
    // Find last non-whitespace
    while (str[i] != '\0') {
        if (!is_whitespace(str[i]))
            end = i;
        i++;
    }
    
    // Copy trimmed string
    for (i = 0; i <= end - start; i++) {
        str[i] = str[start + i];
    }
    str[i] = '\0';
}

void parse_ini(char* input, struct INIFile* ini) {
    int i = 0;
    int current_section = -1;
    char line[MAX_VALUE_LEN];
    int line_idx = 0;
    
    ini->section_count = 0;
    
    while (input[i] != '\0') {
        char c = input[i];
        
        if (c == '\n' || input[i + 1] == '\0') {
            if (input[i + 1] == '\0' && c != '\n')
                line[line_idx++] = c;
            
            line[line_idx] = '\0';
            trim(line);
            
            // Skip empty lines and comments
            if (line[0] != '\0' && line[0] != ';' && line[0] != '#') {
                // Section header
                if (line[0] == '[') {
                    int j = 1;
                    current_section = ini->section_count++;
                    ini->sections[current_section].pair_count = 0;
                    
                    int name_idx = 0;
                    while (line[j] != ']' && line[j] != '\0') {
                        ini->sections[current_section].name[name_idx++] = line[j++];
                    }
                    ini->sections[current_section].name[name_idx] = '\0';
                }
                // Key-value pair
                else if (current_section >= 0) {
                    int j = 0;
                    int key_idx = 0;
                    int value_idx = 0;
                    
                    // Parse key
                    while (line[j] != '=' && line[j] != '\0') {
                        if (!is_whitespace(line[j])) {
                            ini->sections[current_section].pairs[ini->sections[current_section].pair_count].key[key_idx++] = line[j];
                        }
                        j++;
                    }
                    ini->sections[current_section].pairs[ini->sections[current_section].pair_count].key[key_idx] = '\0';
                    
                    if (line[j] == '=') {
                        j++;
                        while (is_whitespace(line[j]))
                            j++;
                        
                        // Parse value
                        while (line[j] != '\0') {
                            ini->sections[current_section].pairs[ini->sections[current_section].pair_count].value[value_idx++] = line[j++];
                        }
                        ini->sections[current_section].pairs[ini->sections[current_section].pair_count].value[value_idx] = '\0';
                        
                        ini->sections[current_section].pair_count++;
                    }
                }
            }
            
            line_idx = 0;
        } else {
            line[line_idx++] = c;
        }
        
        i++;
    }
}

int main() {
    struct INIFile ini;
    char input[] = "[database]\nhost=localhost\nport=5432\n[server]\nport=8080";
    
    parse_ini(input, &ini);
    
    // Return number of sections (should be 2)
    return ini.section_count;
}
