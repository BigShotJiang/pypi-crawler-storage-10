# Example C Programs

This directory contains example C programs that demonstrate the capabilities of the C99 compiler.

## Basic Examples

### hello_world.c
A simple "Hello, World!" program using printf from the standard library.

### factorial.c
Recursive factorial implementation demonstrating recursive function calls and conditional statements.

### fibonacci.c
Recursive Fibonacci implementation demonstrating multiple recursive calls.

### struct_example.c
Struct manipulation example demonstrating struct declarations, member access, and initialization.

### array_example.c
Array operations example demonstrating array declarations, indexing, and initialization.

### float_example.c
Floating-point operations demonstrating float arithmetic and type conversions.

### function_pointer_example.c
Function pointers demonstrating indirect function calls and function pointer arrays.

### macro_example.c
Preprocessor macros demonstrating object-like and function-like macros.

### variadic_example.c
Variadic functions demonstrating variable argument lists.

## Classic Algorithms

### merge_sort.c
Merge sort algorithm demonstrating:
- Recursive divide-and-conquer
- Array manipulation
- Merge operations

### heap_sort.c
Heap sort algorithm demonstrating:
- Heap data structure
- In-place sorting
- Heapify operations

### dijkstra.c
Dijkstra's shortest path algorithm demonstrating:
- Graph algorithms
- 2D arrays
- Priority queue simulation

### astar.c
A* pathfinding algorithm demonstrating:
- Heuristic search
- Grid-based pathfinding
- Complex algorithm implementation

### hash_table.c
Hash table implementation demonstrating:
- Hash functions
- Collision resolution (linear probing)
- Key-value storage

## Data Structures

### avl_tree.c
AVL tree (self-balancing BST) demonstrating:
- Tree rotations
- Balance factor maintenance
- Recursive tree operations

### red_black_tree.c
Red-black tree demonstrating:
- Color properties
- Complex balancing rules
- Tree rotations

### priority_queue.c
Priority queue (min heap) demonstrating:
- Heap operations
- Priority-based extraction
- Heapify up/down

### trie.c
Trie (prefix tree) demonstrating:
- String storage
- Prefix matching
- Tree-based string operations

### hash_map.c
Hash map with string keys demonstrating:
- String hashing
- String comparison
- Key-value mapping

## String Utilities

### string_tokenizer.c
String tokenizer demonstrating:
- String parsing
- Delimiter-based splitting
- Token extraction

### regex_matcher.c
Simple regular expression matcher demonstrating:
- Pattern matching
- Wildcard support (., *)
- Recursive matching

### string_format.c
String formatting utility demonstrating:
- Format string parsing
- Number to string conversion
- String building

### base64.c
Base64 encoder/decoder demonstrating:
- Bit manipulation
- Encoding/decoding algorithms
- Lookup tables

## Math Utilities

### matrix_ops.c
Matrix operations demonstrating:
- Matrix multiplication
- Matrix transpose
- Determinant calculation
- 2D array manipulation

### vector_ops.c
Vector operations demonstrating:
- Dot product
- Cross product
- Vector arithmetic
- Floating-point math

### polynomial.c
Polynomial evaluation demonstrating:
- Horner's method
- Polynomial arithmetic
- Derivative calculation

### prime_sieve.c
Sieve of Eratosthenes demonstrating:
- Prime number generation
- Array-based algorithms
- Number theory

## File Format Parsers

### csv_parser.c
CSV parser demonstrating:
- State machine parsing
- Quote handling
- Data extraction

### json_parser.c
Simple JSON parser demonstrating:
- Recursive descent parsing
- Token-based parsing
- Object/value parsing

### ini_parser.c
INI file parser demonstrating:
- Configuration file parsing
- Section/key-value extraction
- String trimming

### arg_parser.c
Command-line argument parser demonstrating:
- Option parsing
- Short/long option support
- Positional arguments

## Mini Applications

### calculator.c
Calculator with variables demonstrating:
- Expression evaluation
- Variable storage
- Operator parsing

### memory_allocator.c
Memory allocator demonstrating:
- Bump allocation
- Free list allocation
- Memory management

### rle_compression.c
Run-length encoding compression demonstrating:
- Compression algorithms
- Encoding/decoding
- Data transformation

### simple_shell.c
Simple shell demonstrating:
- Command parsing
- Built-in commands
- Command history

### text_editor.c
Basic text editor demonstrating:
- Buffer management
- Cursor movement
- Text insertion/deletion

## Compilation Examples

### Compile to assembly (x86)
```bash
python3 -m src.main examples/hello_world.c -o hello_world.s --target x86
```

### Compile to assembly (ARM)
```bash
python3 -m src.main examples/hello_world.c -o hello_world.s --target arm
```

### Compile with optimization
```bash
python3 -m src.main examples/fibonacci.c -o fibonacci.s -O1
```

### Stop at different phases
```bash
# Stop after preprocessing
python3 -m src.main examples/hello_world.c --stop-after preprocessing

# Stop after parsing
python3 -m src.main examples/hello_world.c --stop-after parsing

# Stop after IR generation
python3 -m src.main examples/hello_world.c --stop-after ir_generation
```

## Testing

The integration tests in `tests/integration/test_end_to_end.py` use these examples to verify:
- Compilation succeeds for all phases
- Generated assembly is valid
- Programs execute correctly (when toolchain is available)
- Both x86 and ARM targets work
- Optimization levels work correctly
