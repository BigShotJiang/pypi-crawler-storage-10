// Hash Map with String Keys
// Demonstrates: string handling, hashing, collision resolution

#define TABLE_SIZE 20
#define MAX_KEY_LEN 50

struct Entry {
    char key[MAX_KEY_LEN];
    int value;
    int used;
};

struct HashMap {
    struct Entry entries[TABLE_SIZE];
};

int str_len(char* str) {
    int len = 0;
    while (str[len] != '\0')
        len++;
    return len;
}

int str_cmp(char* s1, char* s2) {
    int i = 0;
    while (s1[i] != '\0' && s2[i] != '\0') {
        if (s1[i] != s2[i])
            return s1[i] - s2[i];
        i++;
    }
    return s1[i] - s2[i];
}

void str_copy(char* dest, char* src) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

int hash_string(char* str) {
    int hash = 0;
    int i = 0;
    
    while (str[i] != '\0') {
        hash = (hash * 31 + str[i]) % TABLE_SIZE;
        i++;
    }
    
    return hash < 0 ? -hash : hash;
}

void init_map(struct HashMap* map) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        map->entries[i].used = 0;
    }
}

void put(struct HashMap* map, char* key, int value) {
    int index = hash_string(key);
    int original_index = index;
    
    while (map->entries[index].used) {
        if (str_cmp(map->entries[index].key, key) == 0) {
            map->entries[index].value = value;
            return;
        }
        index = (index + 1) % TABLE_SIZE;
        
        if (index == original_index)
            return;
    }
    
    str_copy(map->entries[index].key, key);
    map->entries[index].value = value;
    map->entries[index].used = 1;
}

int get(struct HashMap* map, char* key) {
    int index = hash_string(key);
    int original_index = index;
    
    while (map->entries[index].used) {
        if (str_cmp(map->entries[index].key, key) == 0) {
            return map->entries[index].value;
        }
        index = (index + 1) % TABLE_SIZE;
        
        if (index == original_index)
            break;
    }
    
    return -1;
}

int main() {
    struct HashMap map;
    init_map(&map);
    
    char key1[] = "apple";
    char key2[] = "banana";
    char key3[] = "cherry";
    
    put(&map, key1, 100);
    put(&map, key2, 200);
    put(&map, key3, 300);
    
    char search[] = "banana";
    int result = get(&map, search);
    
    // Return result (should be 200)
    return result;
}
