// CSV Parser
// Demonstrates: string parsing, state machines, data extraction

#define MAX_ROWS 50
#define MAX_COLS 10
#define MAX_CELL_LEN 100

struct CSVData {
    char cells[MAX_ROWS][MAX_COLS][MAX_CELL_LEN];
    int rows;
    int cols;
};

void parse_csv(char* input, struct CSVData* data) {
    int row = 0;
    int col = 0;
    int cell_idx = 0;
    int i = 0;
    int in_quotes = 0;
    
    data->rows = 0;
    data->cols = 0;
    
    while (input[i] != '\0' && row < MAX_ROWS) {
        char c = input[i];
        
        if (c == '"') {
            in_quotes = !in_quotes;
        } else if (c == ',' && !in_quotes) {
            data->cells[row][col][cell_idx] = '\0';
            col++;
            cell_idx = 0;
            
            if (col > data->cols)
                data->cols = col;
        } else if (c == '\n' && !in_quotes) {
            data->cells[row][col][cell_idx] = '\0';
            
            if (col > data->cols)
                data->cols = col;
            
            row++;
            col = 0;
            cell_idx = 0;
        } else {
            if (cell_idx < MAX_CELL_LEN - 1) {
                data->cells[row][col][cell_idx] = c;
                cell_idx++;
            }
        }
        
        i++;
    }
    
    // Handle last cell if no trailing newline
    if (cell_idx > 0 || col > 0) {
        data->cells[row][col][cell_idx] = '\0';
        row++;
    }
    
    data->rows = row;
    data->cols++;  // cols is 0-indexed, convert to count
}

int str_to_int(char* str) {
    int result = 0;
    int i = 0;
    int sign = 1;
    
    if (str[0] == '-') {
        sign = -1;
        i = 1;
    }
    
    while (str[i] != '\0') {
        if (str[i] >= '0' && str[i] <= '9') {
            result = result * 10 + (str[i] - '0');
        }
        i++;
    }
    
    return result * sign;
}

int main() {
    struct CSVData data;
    char csv[] = "name,age,score\nAlice,25,95\nBob,30,87\nCharlie,22,92";
    
    parse_csv(csv, &data);
    
    // Get Bob's score (row 2, col 2)
    int score = str_to_int(data.cells[2][2]);
    
    // Return score (should be 87)
    return score;
}
