// Base64 Encoder/Decoder
// Demonstrates: bit manipulation, encoding/decoding, lookup tables

char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int find_char_index(char c) {
    int i;
    for (i = 0; i < 64; i++) {
        if (base64_chars[i] == c)
            return i;
    }
    return -1;
}

int encode_base64(char* input, int input_len, char* output) {
    int i, j = 0;
    
    for (i = 0; i < input_len; i += 3) {
        int b1 = input[i];
        int b2 = (i + 1 < input_len) ? input[i + 1] : 0;
        int b3 = (i + 2 < input_len) ? input[i + 2] : 0;
        
        int combined = (b1 << 16) | (b2 << 8) | b3;
        
        output[j++] = base64_chars[(combined >> 18) & 0x3F];
        output[j++] = base64_chars[(combined >> 12) & 0x3F];
        output[j++] = (i + 1 < input_len) ? base64_chars[(combined >> 6) & 0x3F] : '=';
        output[j++] = (i + 2 < input_len) ? base64_chars[combined & 0x3F] : '=';
    }
    
    output[j] = '\0';
    return j;
}

int decode_base64(char* input, int input_len, char* output) {
    int i, j = 0;
    
    for (i = 0; i < input_len; i += 4) {
        int c1 = find_char_index(input[i]);
        int c2 = find_char_index(input[i + 1]);
        int c3 = (input[i + 2] != '=') ? find_char_index(input[i + 2]) : 0;
        int c4 = (input[i + 3] != '=') ? find_char_index(input[i + 3]) : 0;
        
        int combined = (c1 << 18) | (c2 << 12) | (c3 << 6) | c4;
        
        output[j++] = (combined >> 16) & 0xFF;
        if (input[i + 2] != '=')
            output[j++] = (combined >> 8) & 0xFF;
        if (input[i + 3] != '=')
            output[j++] = combined & 0xFF;
    }
    
    output[j] = '\0';
    return j;
}

int main() {
    char input[] = "Hello";
    char encoded[100];
    char decoded[100];
    
    int encoded_len = encode_base64(input, 5, encoded);
    int decoded_len = decode_base64(encoded, encoded_len, decoded);
    
    // Return decoded length (should be 5)
    return decoded_len;
}
