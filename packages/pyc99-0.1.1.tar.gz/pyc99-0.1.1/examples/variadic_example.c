/* Example demonstrating variadic function support */

/* Simple variadic function that returns the count */
int count_args(int n, ...) {
    return n;
}

/* Another variadic function */
int sum_first_two(int a, int b, ...) {
    return a + b;
}

int main() {
    /* Call variadic functions with different numbers of arguments */
    int result1 = count_args(3, 10, 20, 30);
    int result2 = count_args(5, 1, 2, 3, 4, 5);
    
    int sum1 = sum_first_two(10, 20);
    int sum2 = sum_first_two(5, 15, 100, 200);
    
    return result1 + result2 + sum1 + sum2;
}
