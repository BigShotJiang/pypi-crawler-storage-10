// Hash Table Implementation
// Demonstrates: structs, pointers, dynamic-like behavior with arrays

#define TABLE_SIZE 10
#define MAX_ENTRIES 100

struct Entry {
    int key;
    int value;
    int used;
};

struct HashTable {
    struct Entry entries[TABLE_SIZE];
};

int hash_function(int key) {
    return key % TABLE_SIZE;
}

void init_table(struct HashTable* table) {
    int i;
    for (i = 0; i < TABLE_SIZE; i++) {
        table->entries[i].used = 0;
    }
}

void insert(struct HashTable* table, int key, int value) {
    int index = hash_function(key);
    int original_index = index;
    
    // Linear probing for collision resolution
    while (table->entries[index].used) {
        if (table->entries[index].key == key) {
            // Update existing key
            table->entries[index].value = value;
            return;
        }
        index = (index + 1) % TABLE_SIZE;
        
        // Table is full
        if (index == original_index)
            return;
    }
    
    table->entries[index].key = key;
    table->entries[index].value = value;
    table->entries[index].used = 1;
}

int get(struct HashTable* table, int key) {
    int index = hash_function(key);
    int original_index = index;
    
    while (table->entries[index].used) {
        if (table->entries[index].key == key) {
            return table->entries[index].value;
        }
        index = (index + 1) % TABLE_SIZE;
        
        if (index == original_index)
            break;
    }
    
    return -1;  // Not found
}

int main() {
    struct HashTable table;
    init_table(&table);
    
    // Insert some values
    insert(&table, 5, 100);
    insert(&table, 15, 200);
    insert(&table, 25, 300);
    insert(&table, 35, 400);
    
    // Retrieve a value
    int result = get(&table, 25);
    
    // Return result (should be 300)
    return result;
}
