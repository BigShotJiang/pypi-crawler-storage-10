// Calculator with Variables
// Demonstrates: expression evaluation, variable storage, parsing

#define MAX_VARS 26
#define MAX_EXPR_LEN 100

struct Calculator {
    int variables[MAX_VARS];
};

void init_calculator(struct Calculator* calc) {
    int i;
    for (i = 0; i < MAX_VARS; i++) {
        calc->variables[i] = 0;
    }
}

int get_var(struct Calculator* calc, char name) {
    if (name >= 'a' && name <= 'z') {
        return calc->variables[name - 'a'];
    }
    return 0;
}

void set_var(struct Calculator* calc, char name, int value) {
    if (name >= 'a' && name <= 'z') {
        calc->variables[name - 'a'] = value;
    }
}

int is_digit(char c) {
    return c >= '0' && c <= '9';
}

int is_var(char c) {
    return c >= 'a' && c <= 'z';
}

// Simple expression evaluator (supports +, -, *, /, variables, and numbers)
int evaluate(struct Calculator* calc, char* expr, int* pos) {
    int result = 0;
    int sign = 1;
    
    while (expr[*pos] == ' ')
        (*pos)++;
    
    // Parse first term
    if (is_digit(expr[*pos])) {
        while (is_digit(expr[*pos])) {
            result = result * 10 + (expr[*pos] - '0');
            (*pos)++;
        }
    } else if (is_var(expr[*pos])) {
        result = get_var(calc, expr[*pos]);
        (*pos)++;
    }
    
    // Parse operators and subsequent terms
    while (expr[*pos] != '\0' && expr[*pos] != '\n') {
        while (expr[*pos] == ' ')
            (*pos)++;
        
        char op = expr[*pos];
        if (op != '+' && op != '-' && op != '*' && op != '/')
            break;
        
        (*pos)++;
        
        while (expr[*pos] == ' ')
            (*pos)++;
        
        int operand = 0;
        if (is_digit(expr[*pos])) {
            while (is_digit(expr[*pos])) {
                operand = operand * 10 + (expr[*pos] - '0');
                (*pos)++;
            }
        } else if (is_var(expr[*pos])) {
            operand = get_var(calc, expr[*pos]);
            (*pos)++;
        }
        
        if (op == '+')
            result = result + operand;
        else if (op == '-')
            result = result - operand;
        else if (op == '*')
            result = result * operand;
        else if (op == '/')
            result = operand != 0 ? result / operand : 0;
    }
    
    return result;
}

int main() {
    struct Calculator calc;
    init_calculator(&calc);
    
    // Set some variables
    set_var(&calc, 'x', 10);
    set_var(&calc, 'y', 5);
    
    // Evaluate: x + y * 2
    char expr[] = "10 + 5 * 2";
    int pos = 0;
    int result = evaluate(&calc, expr, &pos);
    
    // Note: This simple evaluator doesn't handle precedence correctly
    // It evaluates left to right: (10 + 5) * 2 = 30
    // Return result
    return result;
}
