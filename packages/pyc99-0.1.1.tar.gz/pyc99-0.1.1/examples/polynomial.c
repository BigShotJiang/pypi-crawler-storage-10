// Polynomial Evaluation and Operations
// Demonstrates: arrays, mathematical algorithms, Horner's method

#define MAX_DEGREE 10

struct Polynomial {
    float coefficients[MAX_DEGREE];  // coefficients[i] is coefficient of x^i
    int degree;
};

// Evaluate polynomial at x using Horner's method
float evaluate(struct Polynomial* poly, float x) {
    float result = poly->coefficients[poly->degree];
    int i;
    
    for (i = poly->degree - 1; i >= 0; i--) {
        result = result * x + poly->coefficients[i];
    }
    
    return result;
}

// Add two polynomials
struct Polynomial add(struct Polynomial* a, struct Polynomial* b) {
    struct Polynomial result;
    int i;
    
    result.degree = (a->degree > b->degree) ? a->degree : b->degree;
    
    for (i = 0; i <= result.degree; i++) {
        float coeff_a = (i <= a->degree) ? a->coefficients[i] : 0.0f;
        float coeff_b = (i <= b->degree) ? b->coefficients[i] : 0.0f;
        result.coefficients[i] = coeff_a + coeff_b;
    }
    
    return result;
}

// Multiply polynomial by a scalar
struct Polynomial scale(struct Polynomial* poly, float scalar) {
    struct Polynomial result;
    int i;
    
    result.degree = poly->degree;
    
    for (i = 0; i <= poly->degree; i++) {
        result.coefficients[i] = poly->coefficients[i] * scalar;
    }
    
    return result;
}

// Compute derivative
struct Polynomial derivative(struct Polynomial* poly) {
    struct Polynomial result;
    int i;
    
    if (poly->degree == 0) {
        result.degree = 0;
        result.coefficients[0] = 0.0f;
        return result;
    }
    
    result.degree = poly->degree - 1;
    
    for (i = 0; i <= result.degree; i++) {
        result.coefficients[i] = poly->coefficients[i + 1] * (float)(i + 1);
    }
    
    return result;
}

int main() {
    struct Polynomial poly;
    
    // Represent polynomial: 3x^2 + 2x + 1
    poly.degree = 2;
    poly.coefficients[0] = 1.0f;
    poly.coefficients[1] = 2.0f;
    poly.coefficients[2] = 3.0f;
    
    // Evaluate at x = 2: 3(4) + 2(2) + 1 = 17
    float result = evaluate(&poly, 2.0f);
    
    // Return result as int (should be 17)
    return (int)result;
}
