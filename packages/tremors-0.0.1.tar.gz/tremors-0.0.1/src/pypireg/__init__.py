"""The main package."""

__authors__ = ["Narvin Singh"]
__project__ = "PyPi Registration"
__version__ = "0.0.1"
