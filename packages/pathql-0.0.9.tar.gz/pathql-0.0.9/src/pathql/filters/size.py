"""Utilities and a filter for parsing and matching file sizes."""

from __future__ import annotations

import pathlib
import re
from types import NotImplementedType
from typing import Callable, Final, Mapping, Pattern

from .alias import StatProxyOrNone
from .attribute_filter import AttributeFilter

# Accept ints, floats, or strings like "1.5 kb". Default to binary units (KB=1024).
_SIZE_RE_STRING = r"^\s*([0-9]+(?:\.[0-9]+)?)\s*([kmgtpe]?i?b?|b)?\s*$"
_SIZE_RE: Final[Pattern[str]] = re.compile(_SIZE_RE_STRING, re.IGNORECASE)


# Table lookup for multiplier strings -> multiplier.
_UNIT_MULTIPLIERS: Final[Mapping[str, int]] = {
    "": 1,
    "b": 1,
    # SI (decimal) for plain suffixes
    "k": 1000,
    "kb": 1000,
    "m": 1000**2,
    "mb": 1000**2,
    "g": 1000**3,
    "gb": 1000**3,
    "t": 1000**4,
    "tb": 1000**4,
    "p": 1000**5,
    "pb": 1000**5,
    "e": 1000**6,
    "eb": 1000**6,
    "zb": 1000**9,
    # IEC (binary) for explicit "i" suffixes
    "kib": 1024,
    "mib": 1024**2,
    "gib": 1024**3,
    "tib": 1024**4,
    "pib": 1024**5,
    "eib": 1024**6,
    "zib": 1024**9,
}


def _parse_size(value: object) -> int | NotImplementedType:
    """Parse int/float/string sizes into bytes.

    Returns NotImplemented for unsupported operand types so Python can try
    the reflected operation.
    """
    # direct ints/floats
    if isinstance(value, int):
        val = float(value)
    elif isinstance(value, float):
        val = value
    elif isinstance(value, str):
        m = _SIZE_RE.match(value)
        if not m:
            raise ValueError(f"invalid size string: {value!r}")
        num_str, unit = m.group(1), (m.group(2) or "").lower()
        try:
            num = float(num_str)
        except ValueError as exc:
            raise ValueError(f"invalid numeric value in size: {value!r}") from exc
        multiplier = _UNIT_MULTIPLIERS.get(unit)
        if multiplier is None:
            raise ValueError(f"unknown size unit: {unit!r}")
        val = num * multiplier
    else:
        return NotImplemented

    if val < 0:
        raise ValueError("size must be non-negative")

    return int(val)


def parse_size(value: object) -> int:
    """
    Parse a file size value and return the byte count as an int.

    Accepts:
        - int or float: Interpreted as bytes.
        - str: Accepts human-friendly formats, e.g.:
            '1.5 KB', '2MiB', '1000', '3 gb', '4.2k', '5MB', '7.5 GiB', etc.
            Supports SI (decimal) and IEC (binary) units:
                SI: k, kb, m, mb, g, gb, t, tb, p, pb, e, eb, z, zb
                IEC: kib, mib, gib, tib, pib, eib, zib
            Case-insensitive, spaces optional.
    Returns:
        int: Size in bytes.
    Raises:
        ValueError: For invalid strings, unknown units, or negative sizes.
        TypeError: For unsupported operand types (e.g., lists, dicts).
    """
    res = _parse_size(value)
    if res is NotImplemented:
        raise TypeError("unsupported operand type for parse_size")
    return res


def _extract_size(
    path: pathlib.Path, stat_proxy: StatProxyOrNone, now: object = None
) -> int:
    if stat_proxy is None:
        raise ValueError("stat_proxy required for size extraction")
    st = stat_proxy.stat()
    return st.st_size


class Size(AttributeFilter):
    """Filter for file size (in bytes), supports operator overloads."""

    def __init__(self, op: Callable[[int, int], bool] = None, value: object = None):
        """
        Initialize a Size filter for file size in bytes.
        Args:
            op: Comparison operator (e.g., operator.lt).
            value: Size threshold (int, float, or str).
        """
        parsed_value = parse_size(value) if value is not None else None
        super().__init__(_extract_size, op, parsed_value, requires_stat=True)

    def __le__(self, other: object) -> "Size":
        """
        Return a Size filter for files <= other bytes.
        """
        return Size(lambda x, y: x <= y, parse_size(other))

    def __lt__(self, other: object) -> "Size":
        """
        Return a Size filter for files < other bytes.
        """
        return Size(lambda x, y: x < y, parse_size(other))

    def __ge__(self, other: object) -> "Size":
        """
        Return a Size filter for files >= other bytes.
        """
        return Size(lambda x, y: x >= y, parse_size(other))

    def __gt__(self, other: object) -> "Size":
        """
        Return a Size filter for files > other bytes.
        """
        return Size(lambda x, y: x > y, parse_size(other))

    def __eq__(self, other: object) -> "Size":
        """
        Return a Size filter for files == other bytes.
        """
        return Size(lambda x, y: x == y, parse_size(other))

    def __ne__(self, other: object) -> "Size":
        """
        Return a Size filter for files != other bytes.
        """
        return Size(lambda x, y: x != y, parse_size(other))
