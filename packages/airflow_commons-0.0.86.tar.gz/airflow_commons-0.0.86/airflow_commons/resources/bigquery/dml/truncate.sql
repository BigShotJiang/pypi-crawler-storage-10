TRUNCATE TABLE
    `{project_id}.{dataset_id}.{table_id}`