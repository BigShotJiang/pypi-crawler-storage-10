DELETE FROM
    `{project_id}.{dataset_id}.{table_id}`
WHERE
    {where_statement};
