# jsonshift

A lightweight Python package to **convert one JSON payload into another** using a declarative mapping spec defined in JSON.

**Engine rules (designed for system integrations):**

* If the **source path does not exist** → raises **`MappingMissingError`**.
* If the **source value is `null` / `None`** → the destination receives **`None`** (not replaced).
* `defaults` only fills values when the **destination field is absent** (does not overwrite `None` or existing values).
* Supports **dotted and indexed paths**, e.g. `a.b[0].c`.

---

## Local installation

```bash
pip install .
# or
pip install -e .  # development mode
```

---

## Basic usage

```python
from jsonshift import Mapper

payload = {
    "customer_name": "John Doe",
    "cpf": None,
    "amount": 1000.0,
    "installments": 12
}

spec = {
  "map": {
    "customer.name": "customer_name",
    "customer.cpf": "cpf",          # None is preserved
    "contract.amount": "amount",
    "contract.installments": "installments"
  },
  "defaults": {
    "contract.type": "CCB",
    "contract.origin": "ORQ"
  }
}

mapper = Mapper()
out = mapper.transform(spec, payload)
print(out)
# {
#   "customer": {"name": "John Doe", "cpf": null},
#   "contract": {"amount": 1000.0, "installments": 12, "type": "CCB", "origin": "ORQ"}
# }
```

---

## Command-line interface (CLI)

```bash
# Transform using JSON files
jsonshift --spec spec.json --input payload.json

# or via stdin
cat payload.json | jsonshift --spec spec.json
```

---

## ▶️ Run the example (from the repository)

This repository includes ready-to-use files under the [`examples/`](./examples) folder.

To test `jsonshift` end-to-end:

```bash
# From the project root
jsonshift --spec examples/spec.json --input examples/payload.json
```

**Expected output:**

```json
{
  "customer": {
    "name": "John Doe",
    "cpf": "12345678901"
  },
  "contract": {
    "amount": 1500.0,
    "installments": 6,
    "type": "CCB",
    "origin": "ORQ"
  }
}
```

---

## Spec format

```json
{
  "map": { "destination.path": "source.path", "...": "..." },
  "defaults": { "destination.path": "<fixed_value>" }
}
```

---

## Error handling

* **`MappingMissingError`** — source path is missing (required field not found).
* **`InvalidDestinationPath`** — invalid destination path (e.g., indexed destination).

---

## License

MIT