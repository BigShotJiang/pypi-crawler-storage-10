from .middlewares import register_middleware

__all__ = ["register_middleware"]
