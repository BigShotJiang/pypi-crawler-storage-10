"""
DumbEmu - Cross-platform x86/x64 emulator for malware analysis.

Supports both Windows PE and Linux ELF executables.
Built on Unicorn Engine with automatic format detection.
Simple and focused on practical reverse engineering.
"""
from __future__ import annotations
from .core import (
    DumbEmu,
    EmuError, LoaderError, FormatError, MemoryError,
    ExecutionError, EmuLimitError, SegFaultError,
    StubError, ArgumentError
)

__all__ = [
    "DumbEmu",
    "EmuError", "LoaderError", "FormatError", "MemoryError",
    "ExecutionError", "EmuLimitError", "SegFaultError",
    "StubError", "ArgumentError"
]