#include "GtfDictView.h"

#include "../formats/gtf.h"

// generic

static void GtfDict_View_dealloc(GtfDict_view *self) {
    Py_DECREF(self->dict);
    PyObject_Free(self);
}

static Py_ssize_t GtfDict_view_length(GtfDict_view *self) {
    return CORE_FIELD_COUNT + hashmap_num_entries(&self->dict->attributes);
}

static Py_ssize_t GtfDict_view_len(GtfDict_view *self) {
    return GtfDict_view_length(self);
}

// keys view

struct iterate_keys_context {
    PyObject *tuple;
    unsigned int index;
};

static int iterate_keys(void *const context, void *const e) {
    struct map_tuple *tuple = (struct map_tuple *)e;
    struct iterate_keys_context *ctx = (struct iterate_keys_context *)context;
    Py_INCREF(tuple->key);
    return PyTuple_SetItem(ctx->tuple, ctx->index++, tuple->key) >= 0;
}

static PyObject *GtfDict_KeyView_iter(GtfDict_view *self) {
    PyObject *keys = PyTuple_New(GtfDict_view_length(self));
    if (keys == NULL) {
        return NULL;
    }

    for (unsigned int i = 0; i < CORE_FIELD_COUNT; i++) {
        PyObject *key =
            PyUnicode_DecodeUTF8(keywords[i], keyword_sizes[i], NULL);
        if (key == NULL) {
            Py_DECREF(keys);
            return NULL;
        }
        if (PyTuple_SetItem(keys, i, key) < 0) {
            Py_DECREF(keys);
            return NULL;
        }
    }

    struct iterate_keys_context ctx = {.tuple = keys,
                                       .index = CORE_FIELD_COUNT};

    if (hashmap_iterate(&self->dict->attributes, iterate_keys, &ctx) != 0) {
        Py_DECREF(keys);
        return NULL;
    }
    PyObject *iter = PyObject_GetIter(keys);
    Py_DECREF(keys);
    return iter;
}

static int iterate_check_key(void *const context, void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;
    return !PyObject_RichCompareBool(tuple->key, context, Py_EQ);
}

static int GtfDict_KeyView_contains(GtfDict_view *self, PyObject *key) {
    Py_ssize_t key_len;
    const char *key_str = PyUnicode_AsUTF8AndSize(key, &key_len);
    if (key_str == NULL) {
        return -1;
    }
    for (size_t i = 0; i < CORE_FIELD_COUNT; i++) {
        if (strcmp(key_str, keywords[i]) == 0) {
            return true;
        }
    }
    return hashmap_iterate(&self->dict->attributes, iterate_check_key, key);
}

static int iterate_check_key_in(void *const context, void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;
    GtfDict_view *other = (GtfDict_view *)context;
    return hashmap_iterate(&other->dict->attributes, iterate_check_key,
                           tuple->key) != 0; // returns 1 if key is not found
}

static PyObject *GtfDict_KeyView_richcompare(GtfDict_view *restrict self,
                                             PyObject *restrict other,
                                             const int op) {
    if (!Py_IS_TYPE(other, &GtfDict_KeyViewType)) {
        Py_RETURN_FALSE;
    }

    // true if we have a key that is not in the other view
    bool not_found =
        hashmap_iterate(&self->dict->attributes, iterate_check_key_in, other);

    switch (op) {
    case Py_EQ:
        not_found = !not_found;
        break;
    default:
        Py_RETURN_NOTIMPLEMENTED;
    }

    return PyBool_FromLong(not_found);
}

static PySequenceMethods GtfDict_KeyViewSeq = {
    .sq_contains = (objobjproc)GtfDict_KeyView_contains,
    .sq_length = (lenfunc)GtfDict_view_len};

PyTypeObject GtfDict_KeyViewType = {
    PyVarObject_HEAD_INIT(NULL, 0).tp_name = "eccLib.GtfDict_KeyView",
    .tp_basicsize = sizeof(GtfDict_view),
    .tp_doc = PyDoc_STR("A view of the keys in the GtfDict"),
    .tp_itemsize = 0,
    .tp_flags = Py_TPFLAGS_DEFAULT,
    .tp_richcompare = (richcmpfunc)GtfDict_KeyView_richcompare,
    .tp_iter = (getiterfunc)GtfDict_KeyView_iter,
    .tp_dealloc = (destructor)GtfDict_View_dealloc,
    .tp_as_sequence = &GtfDict_KeyViewSeq,
};

// value view

static int iterate_values(void *const context, void *const e) {
    struct map_tuple *tuple = (struct map_tuple *)e;
    struct iterate_keys_context *ctx = (struct iterate_keys_context *)context;

    Py_INCREF(tuple->value);
    return PyTuple_SetItem(ctx->tuple, ctx->index++, tuple->value) >= 0;
}

static PyObject *GtfDict_ValueView_iter(GtfDict_view *self) {
    PyObject *values = PyTuple_New(GtfDict_view_length(self));
    if (values == NULL) {
        return NULL;
    }

    for (unsigned int i = 0; i < CORE_FIELD_COUNT; i++) {
        PyObject *value = self->dict->core[i];
        Py_INCREF(value);
        if (PyTuple_SetItem(values, i, value) < 0) {
            Py_DECREF(values);
            return NULL;
        }
    }

    struct iterate_keys_context ctx = {.tuple = values,
                                       .index = CORE_FIELD_COUNT};

    if (hashmap_iterate(&self->dict->attributes, iterate_values, &ctx) != 0) {
        Py_DECREF(values);
        return NULL;
    }
    PyObject *iter = PyObject_GetIter(values);
    Py_DECREF(values);
    return iter;
}

static int iterate_check_value(void *const context, void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;
    return !PyObject_RichCompareBool(tuple->value, context, Py_EQ);
}

static int GtfDict_ValueView_contains(GtfDict_view *self, PyObject *value) {
    for (size_t i = 0; i < CORE_FIELD_COUNT; i++) {
        if (PyObject_RichCompareBool(value, self->dict->core[i], Py_EQ))
            return true;
    }
    return hashmap_iterate(&self->dict->attributes, iterate_check_value, value);
}

static int iterate_check_value_in(void *const context, void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;
    GtfDict_view *other = (GtfDict_view *)context;
    return hashmap_iterate(&other->dict->attributes, iterate_check_value,
                           tuple->value) != 0;
}

static PyObject *GtfDict_ValueView_richcompare(GtfDict_view *restrict self,
                                               PyObject *restrict other,
                                               const int op) {
    if (!Py_IS_TYPE(other, &GtfDict_ValueViewType)) {
        Py_RETURN_FALSE;
    }

    if (op != Py_EQ && op != Py_NE) {
        Py_RETURN_NOTIMPLEMENTED;
    }

    GtfDict_view *other_view = (GtfDict_view *)other;
    for (int i = 0; i < CORE_FIELD_COUNT; i++) {
        if (!PyObject_RichCompareBool(self->dict->core[i],
                                      other_view->dict->core[i], op))
            Py_RETURN_FALSE;
    }

    // true if we have a key that is not in the other view
    bool not_found =
        hashmap_iterate(&self->dict->attributes, iterate_check_value_in, other);

    if (op == Py_EQ) {
        not_found = !not_found;
    }

    return PyBool_FromLong(not_found);
}

static PySequenceMethods GtfDict_ValueViewSeq = {
    .sq_contains = (objobjproc)GtfDict_ValueView_contains,
    .sq_length = (lenfunc)GtfDict_view_len};

PyTypeObject GtfDict_ValueViewType = {
    PyVarObject_HEAD_INIT(NULL, 0).tp_name = "eccLib.GtfDict_ValueView",
    .tp_basicsize = sizeof(GtfDict_view),
    .tp_doc = PyDoc_STR("A view of the values in the GtfDict"),
    .tp_itemsize = 0,
    .tp_flags = Py_TPFLAGS_DEFAULT,
    .tp_richcompare = (richcmpfunc)GtfDict_ValueView_richcompare,
    .tp_iter = (getiterfunc)GtfDict_ValueView_iter,
    .tp_dealloc = (destructor)GtfDict_View_dealloc,
    .tp_as_sequence = &GtfDict_ValueViewSeq,
};

// items view

static int iterate_items(void *const context, void *const e) {
    struct map_tuple *tuple = (struct map_tuple *)e;
    struct iterate_keys_context *ctx = (struct iterate_keys_context *)context;

    PyObject *pair = Py_BuildValue("(OO)", tuple->key, tuple->value);

    if (pair == NULL) {
        return 0;
    }
    return PyTuple_SetItem(ctx->tuple, ctx->index++, pair) >= 0;
}

static PyObject *GtfDict_ItemView_iter(GtfDict_view *self) {
    PyObject *items = PyTuple_New(GtfDict_view_length(self));
    if (items == NULL) {
        return NULL;
    }

    for (unsigned int i = 0; i < CORE_FIELD_COUNT; i++) {
        PyObject *value = self->dict->core[i];

        PyObject *key =
            PyUnicode_DecodeUTF8(keywords[i], keyword_sizes[i], NULL);
        if (key == NULL) {
            Py_DECREF(items);
            return NULL;
        }

        PyObject *item = Py_BuildValue("(OO)", key, value);
        Py_DECREF(key);
        if (item == NULL) {
            Py_DECREF(items);
            return NULL;
        }

        if (PyTuple_SetItem(items, i, item) < 0) {
            Py_DECREF(item);
            Py_DECREF(items);
            return NULL;
        }
    }

    struct iterate_keys_context ctx = {.tuple = items,
                                       .index = CORE_FIELD_COUNT};

    if (hashmap_iterate(&self->dict->attributes, iterate_items, &ctx) != 0) {
        Py_DECREF(items);
        return NULL;
    }
    PyObject *iter = PyObject_GetIter(items);
    Py_DECREF(items);
    return iter;
}

static int iterate_check_item(void *const context, void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;

    PyObject *context_key = PyTuple_GetItem(context, 0);
    PyObject *context_value = PyTuple_GetItem(context, 1);

    return (!PyObject_RichCompareBool(tuple->value, context_value, Py_EQ)) ||
           (!PyObject_RichCompareBool(tuple->key, context_key, Py_EQ));
}

static int GtfDict_ItemView_contains(GtfDict_view *self, PyObject *value) {
    PyObject *key = PyTuple_GetItem(value, 0);
    if (key == NULL)
        return -1;

    const char *key_str = PyUnicode_AsUTF8(key);
    if (key_str == NULL)
        return -1;

    PyObject *val = PyTuple_GetItem(value, 1);
    if (val == NULL)
        return -1;

    for (size_t i = 0; i < CORE_FIELD_COUNT; i++) {
        if (PyObject_RichCompareBool(val, self->dict->core[i], Py_EQ) &&
            strcmp(key_str, keywords[i]) == 0)
            return true;
    }
    return hashmap_iterate(&self->dict->attributes, iterate_check_item, value);
}

static int iterate_check_item_map_tuple(void *const context,
                                        void *const value) {
    struct map_tuple *tuple = (struct map_tuple *)value;
    struct map_tuple *other = (struct map_tuple *)context;
    return (!PyObject_RichCompareBool(tuple->value, other->value, Py_EQ)) ||
           (!PyObject_RichCompareBool(tuple->key, other->key, Py_EQ));
}

static int iterate_check_item_in(void *const context, void *const value) {
    GtfDict_view *other = (GtfDict_view *)context;
    return !hashmap_iterate(&other->dict->attributes,
                            iterate_check_item_map_tuple, value);
}

static PyObject *GtfDict_ItemView_richcompare(GtfDict_view *restrict self,
                                              PyObject *restrict other,
                                              const int op) {
    if (!Py_IS_TYPE(other, &GtfDict_ItemViewType)) {
        Py_RETURN_FALSE;
    }

    if (op != Py_EQ && op != Py_NE) {
        Py_RETURN_NOTIMPLEMENTED;
    }

    GtfDict_view *other_view = (GtfDict_view *)other;
    for (int i = 0; i < CORE_FIELD_COUNT; i++) {
        if (!PyObject_RichCompareBool(self->dict->core[i],
                                      other_view->dict->core[i], op))
            Py_RETURN_FALSE;
    }

    // true if we have a key that is not in the other view
    bool not_found =
        hashmap_iterate(&self->dict->attributes, iterate_check_item_in, other);

    if (op == Py_EQ) {
        not_found = !not_found;
    }

    return PyBool_FromLong(not_found);
}

PySequenceMethods GtfDict_ItemViewSeq = {
    .sq_contains = (objobjproc)GtfDict_ItemView_contains,
    .sq_length = (lenfunc)GtfDict_view_len};

PyTypeObject GtfDict_ItemViewType = {
    PyVarObject_HEAD_INIT(NULL, 0).tp_name = "eccLib.GtfDict_ItemView",
    .tp_basicsize = sizeof(GtfDict_view),
    .tp_doc = PyDoc_STR("A view of the items in the GtfDict"),
    .tp_itemsize = 0,
    .tp_flags = Py_TPFLAGS_DEFAULT,
    .tp_richcompare = (richcmpfunc)GtfDict_ItemView_richcompare,
    .tp_iter = (getiterfunc)GtfDict_ItemView_iter,
    .tp_dealloc = (destructor)GtfDict_View_dealloc,
    .tp_as_sequence = &GtfDict_ItemViewSeq,
};
