#ifndef GTFDICT_VIEW_H
#define GTFDICT_VIEW_H

#include <Python.h>

#include "GtfDict.h"

typedef struct {
    PyObject_HEAD GtfDict *dict;
} GtfDict_view;

extern PyTypeObject GtfDict_ValueViewType;
extern PyTypeObject GtfDict_KeyViewType;
extern PyTypeObject GtfDict_ItemViewType;

#endif
