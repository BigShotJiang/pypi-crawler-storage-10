"""
Database migrations for PyArchInit-Mini
"""

from .add_i18n_columns import run_migration

__all__ = ['run_migration']
