"""Service layer for feature-based functions used by Quip orchestrator."""

# Intentionally empty; modules are imported directly where needed to avoid
# premature heavy imports (e.g., PIL) and circular dependencies.
