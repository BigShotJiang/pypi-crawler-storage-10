Changes
=======

0.2 (2025-10-25)
----------------

- Pin upper versions of dependencies.
  [rnix]


0.1 (2021-11-21)
----------------

- Initial release.
  [rnix]
