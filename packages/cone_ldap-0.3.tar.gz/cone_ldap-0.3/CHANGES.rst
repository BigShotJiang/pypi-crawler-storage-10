Changes
=======

0.3 (2025-10-25)
----------------

- Pin upper versions of dependencies.
  [rnix]


0.2 (2022-12-05)
----------------

- Move ``users_expires_attr`` and ``users_expires_unit`` settings from cone.ugm,
  since they always have been used only for LDAP UGM backend.


0.1 (2020-07-09)
----------------

- Initial release.
