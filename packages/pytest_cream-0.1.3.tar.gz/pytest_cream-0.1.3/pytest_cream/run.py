import subprocess
import sys


def run_tests(output_file: str = "test_durations.log", tests_dir: str = "tests", python_executable: str = None):
    """Run tests and log their durations."""
    
    # Determine python command
    if python_executable:
        if not python_executable.startswith("python"):
            python_cmd = f"python{python_executable}" if python_executable[0].isdigit() else python_executable
        else:
            python_cmd = python_executable
    else:
        python_cmd = sys.executable
    
    command = [
        python_cmd,
        "-m",
        "pytest",
        tests_dir + "/",
        "--durations=0",
        "--durations-min=0",
        "--tb=short",
        "--disable-warnings",
        "-q",
        "-m",
        "not slow",
    ]
    with open(output_file, "w") as f:
        subprocess.run(command, stdout=f, check=True)
