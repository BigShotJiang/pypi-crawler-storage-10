import os
import subprocess
from pytest_cream.run import run_tests


def test_run_tests(tmp_path):
    output_file = tmp_path / "test_durations.log"

    def mock_run(command, stdout, check):
        with open(stdout.name, "w") as f:
            f.write("Mocked test output\n")

    subprocess.run = mock_run
    run_tests(output_file=str(output_file))

    assert output_file.exists()
    with open(output_file, "r") as f:
        content = f.read()
    assert "Mocked test output" in content
