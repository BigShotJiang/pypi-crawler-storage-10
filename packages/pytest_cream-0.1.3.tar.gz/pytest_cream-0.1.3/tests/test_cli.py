import subprocess


def test_cli_fetch():
    def mock_run(command, capture_output):
        return subprocess.CompletedProcess(args=command, returncode=0)

    subprocess.run = mock_run
    result = subprocess.run(
        ["python", "-m", "pytest_cream.cli", "fetch", "--branch", "main"],
        capture_output=True,
    )
    assert result.returncode == 0


def test_cli_run():
    def mock_run(command, capture_output):
        return subprocess.CompletedProcess(args=command, returncode=0)

    subprocess.run = mock_run
    result = subprocess.run(
        ["python", "-m", "pytest_cream.cli", "run", "--output", "test_durations.log"],
        capture_output=True,
    )
    assert result.returncode == 0


def test_cli_filter():
    def mock_run(command, capture_output):
        return subprocess.CompletedProcess(args=command, returncode=0)

    subprocess.run = mock_run
    result = subprocess.run(
        [
            "python",
            "-m",
            "pytest_cream.cli",
            "filter",
            "--input",
            "input.log",
            "--output",
            "output.log",
            "--threshold",
            "0.5",
        ],
        capture_output=True,
    )
    assert result.returncode == 0
