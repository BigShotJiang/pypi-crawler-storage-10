"""
Canine Olfactory Optimizer (COO)
========================================================

A Novel Bio-Inspired Metaheuristic Algorithm for optimization

Author: Your Name
License: MIT
"""
__version__ = "2.3.0"
__author__ = "Sandip Garai"
__email__ = "sandipnicksandy@gmail.com"

from .coo import (
    CanineOlfactoryOptimization,
    SurrogateEnsemble,
    COO
)

__all__ = [
    "CanineOlfactoryOptimization",
    "SurrogateEnsemble",
    "COO"
]
