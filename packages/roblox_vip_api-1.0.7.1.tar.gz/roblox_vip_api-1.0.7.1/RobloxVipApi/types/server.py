import json
from typing import Optional, List, Dict, Any
from ..utils.http_client import HttpClient


class Server:
    """
    Класс для работы с VIP сервером Roblox.
    
    Args:
        server (dict): Словарь с данными сервера из API
    """
    
    def __init__(self, server: dict):
        """
        Инициализирует объект сервера.
        
        Args:
            server (dict): Словарь с данными сервера
        """
        self.id: int = server['id']
        """ID сервера"""
        
        self.name: str = server['name']
        """Название сервера"""
        
        self.place: Dict[str, Any] = server['game']['rootPlace']
        """Информация о месте (игре)"""
        
        self.status: bool = server['active']
        """Статус сервера (включен/выключен)"""
        
        self.subscription: Dict[str, Any] = server['subscription']
        """Информация о подписке"""
        
        self.permissions: Dict[str, Any] = server['permissions']
        """Права доступа"""
        
        self.voice_settings: Dict[str, Any] = server['voiceSettings']
        """Настройки голосового чата"""
        
        self.link: Optional[str] = server['link']
        """Ссылка для присоединения к серверу"""
        
        self.join_code: Optional[str] = server.get('joinCode')
        """Код для присоединения к серверу"""

    def get_players(self, client: object, get_avatar: Optional[bool] = False) -> Optional[List[Dict[str, Any]]]:
        """
        Получает список игроков на сервере.
        
        Args:
            client (object): Клиент для аутентификации
            get_avatar (Optional[bool]): Получить аватары игроков. По умолчанию False
            
        Returns:
            Optional[List[Dict[str, Any]]]: Список игроков или None если сервер не найден
        """
        # Используем HttpClient из клиента
        if not hasattr(client, 'http_client') or not isinstance(client.http_client, HttpClient):
            print("❌ Клиент не имеет корректного HTTP клиента")
            return None

        # Получаем список приватных серверов
        response = client.http_client.get(
            f"https://games.roblox.com/v1/games/{self.place['id']}/private-servers"
        )
        
        if not response or response.status_code != 200:
            print(f"❌ Ошибка при получении списка серверов: {response.status_code if response else 'No response'}")
            return None

        result = None

        # Ищем наш сервер в списке
        for server_data in json.loads(response.text)['data']:
            if server_data['vipServerId'] == self.id:
                result = server_data['players']
                
                # Если запрошены аватары
                if get_avatar and result:
                    json_req = []
                    for user in result:
                        json_req.append({
                            "requestId": f"{user['id']}::AvatarHeadshot:150x150:webp:regular:",
                            "type": "AvatarHeadShot",
                            "targetId": user['id'],
                            "token": "",
                            "format": "webp",
                            "size": "150x150",
                            "version": ""
                        })

                    # Получаем аватары через HttpClient
                    avatars_response = client.http_client.post(
                        "https://thumbnails.roblox.com/v1/batch",
                        json=json_req
                    )
                    
                    if avatars_response and avatars_response.status_code == 200:
                        # Получаем данные из поля "data"
                        avatars_data = json.loads(avatars_response.text).get('data', [])
                        
                        # Создаем словарь для быстрого поиска аватаров по ID
                        avatars_dict = {}
                        for avatar in avatars_data:
                            if avatar.get('errorCode') == 0:
                                avatars_dict[avatar['targetId']] = avatar['imageUrl']
                        
                        # Добавляем аватары пользователям
                        for user in result:
                            user_id = user['id']
                            if user_id in avatars_dict:
                                user['avatar'] = avatars_dict[user_id]
                            else:
                                user['avatar'] = None
                    else:
                        print("❌ Ошибка при получении аватаров игроков")

        return result