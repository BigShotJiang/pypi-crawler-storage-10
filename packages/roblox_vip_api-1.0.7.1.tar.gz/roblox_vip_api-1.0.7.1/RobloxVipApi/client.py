from typing import Optional, Dict, Any
import json
from .types.server import Server
from .utils.http_client import HttpClient


class Client:
    """
    Клиент для работы с VIP серверами Roblox.
    
    Args:
        ROBLOSECURITY (str): Куки .ROBLOSECURITY для аутентификации
    """
    
    def __init__(self, ROBLOSECURITY):
        self.http_client = HttpClient(ROBLOSECURITY)
        self.servers = []

    def get(self, servers: Optional[list] = None):
        """
        Получает информацию о серверах.
        
        Args:
            servers (Optional[list]): Список ID серверов для получения информации
        """
        if servers is not None:
            for server in servers:
                resp = self.http_client.get(
                    f"https://games.roblox.com/v1/vip-servers/{server}"
                )
                if resp and resp.status_code == 200:
                    self.servers.append(Server(json.loads(resp.text)))
        
        return self

    def set_server_status(self, server: Server, status: bool, join_link: Optional[bool] = False):
        """
        Изменяет статус сервера и настройки ссылки присоединения.
        
        Args:
            server (Server): Объект сервера
            status (bool): Новый статус сервера
            join_link (Optional[bool]): Создать новую ссылку присоединения
        """
        if status == False and join_link == True:
            raise ValueError("Нельзя получить ссылку на выключенном сервере")

        data = {
            "active": status,
            "newJoinCode": join_link
        }

        response = self.http_client.patch(
            f"https://games.roblox.com/v1/vip-servers/{server.id}",
            json=data
        )

        if not response or response.status_code != 200:
            return None

        result_data = json.loads(response.text)
        
        # Обновляем объект сервера в списке
        for s in self.servers:
            if s.id == server.id:
                s.status = status
                s.link = result_data.get('link', '')
                s.join_code = result_data.get('joinCode')
                break
        
        # Если сервер выключается, очищаем ссылку и код присоединения в ответе
        if status == False:
            result_data["link"] = ""
            result_data["joinCode"] = None

        return result_data