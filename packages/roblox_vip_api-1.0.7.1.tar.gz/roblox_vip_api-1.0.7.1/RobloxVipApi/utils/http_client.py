import requests
from bs4 import BeautifulSoup
from typing import Optional, Dict, Any
import json


class HttpClient:
    """
    Универсальный HTTP клиент для работы с API.
    
    Args:
        roblosecurity (str): Кука .ROBLOSECURITY для аутентификации
        base_url (str, optional): Базовый URL для всех запросов
    """
    
    def __init__(self, roblosecurity: str, base_url: Optional[str] = None):
        self.roblosecurity = roblosecurity
        self.base_url = base_url or ""

    def _get_x_csrf_token(self) -> Optional[str]:
        """
        Получает актуальный X-CSRF-токен с сервера Roblox.
        
        Returns:
            Optional[str]: X-CSRF-токен или None в случае ошибки
        """
        try:
            response = requests.get(
                "https://www.roblox.com/home", 
                cookies={".ROBLOSECURITY": self.roblosecurity}
            )

            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                csrf_token = soup.find('meta', attrs={'data-token': True})
                
                if csrf_token:
                    return csrf_token.get("data-token")
                else:
                    print("❌ CSRF-токен не найден на странице")
                    return None
            else:
                print(f"❌ Ошибка при получении страницы: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"❌ Ошибка при получении CSRF-токена: {e}")
            return None

    def _prepare_url(self, endpoint: str) -> str:
        """
        Формирует полный URL из базового URL и endpoint.
        
        Args:
            endpoint (str): Конечная точка API
            
        Returns:
            str: Полный URL
        """
        if endpoint.startswith(('http://', 'https://')):
            return endpoint
        return f"{self.base_url}{endpoint}"

    def request(self, method: str, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет HTTP запрос с автоматическим получением X-CSRF-токена.
        
        Args:
            method (str): HTTP метод (GET, POST, PATCH, PUT, DELETE)
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        # Получаем актуальный токен
        x_csrf_token = self._get_x_csrf_token()
        if not x_csrf_token:
            return None

        # Подготавливаем URL
        url = self._prepare_url(endpoint)

        # Устанавливаем заголовки
        headers = kwargs.get('headers', {})
        headers.update({
            "X-CSRF-Token": x_csrf_token,
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })
        kwargs['headers'] = headers
        
        # Устанавливаем куки
        cookies = kwargs.get('cookies', {})
        cookies.update({".ROBLOSECURITY": self.roblosecurity})
        kwargs['cookies'] = cookies

        try:
            response = requests.request(method, url, **kwargs)
            return response
        except Exception as e:
            print(f"❌ Ошибка при выполнении запроса {method} {url}: {e}")
            return None

    def get(self, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет GET запрос.
        
        Args:
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        return self.request("GET", endpoint, **kwargs)

    def post(self, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет POST запрос.
        
        Args:
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        return self.request("POST", endpoint, **kwargs)

    def patch(self, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет PATCH запрос.
        
        Args:
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        return self.request("PATCH", endpoint, **kwargs)

    def put(self, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет PUT запрос.
        
        Args:
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        return self.request("PUT", endpoint, **kwargs)

    def delete(self, endpoint: str, **kwargs) -> Optional[requests.Response]:
        """
        Выполняет DELETE запрос.
        
        Args:
            endpoint (str): Конечная точка API или полный URL
            **kwargs: Дополнительные аргументы для requests
            
        Returns:
            Optional[requests.Response]: Response object или None в случае ошибки
        """
        return self.request("DELETE", endpoint, **kwargs)