from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="roblox-vip-api",
    version="1.0.7.1",
    author="Garou",
    author_email="tpagarou@gmail.com",
    description="API для управления VIP серверами Roblox",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Garoika/roblox-vip-api",
    packages=find_packages(include=['RobloxVipApi', 'RobloxVipApi.*']),
    package_dir={'RobloxVipApi': 'RobloxVipApi'},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
        "beautifulsoup4>=4.9.0",
    ],
    keywords="roblox api vip server private",
)