from setuptools import setup

setup(
   name='murey',
   version='1.0.0',
   author='Aimen Abdesselam',
   author_email='ai.abdesselam@esi-sba.dz',
   packages=['murey'],
   url='http://pypi.python.org/pypi/murey/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=[]
)