"""Calibration service for converting scores to probabilities."""

import math

from resolvekit.calibration.features import FeatureExtractor
from resolvekit.calibration.models import CalibrationModel
from resolvekit.types import Candidate

try:
    import numpy as np

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class Calibrator:
    """
    Applies calibration models to candidates.

    Supports logistic regression models or heuristic fallback when no model available.
    """

    def __init__(self, model: CalibrationModel | None = None):
        """
        Initialize calibrator.

        Args:
            model: Optional calibration model. If None, uses heuristic fallback.
        """
        self.model = model
        self.feature_extractor = FeatureExtractor()

    def calibrate(self, candidate: Candidate) -> float:
        """
        Calibrate single candidate to confidence probability.

        Args:
            candidate: Candidate to calibrate

        Returns:
            Calibrated confidence in [0.0, 1.0]
        """
        if self.model:
            return self._apply_logistic(candidate)
        else:
            # Use heuristic fallback
            return self._apply_heuristic(candidate)

    def _apply_heuristic(self, candidate: Candidate) -> float:
        """
        Apply rule-based heuristic scoring.

        Tier 1: Exact matches (0.85-0.95)
        Tier 2: Fuzzy matches (0.5-0.8)
        Tier 3: FTS only (0.3-0.6)
        Fallback: Raw score

        Args:
            candidate: Candidate to score

        Returns:
            Heuristic confidence
        """
        features = candidate.features

        # Tier 1: Exact matches
        if features.get("exact_code"):
            return 0.95
        if features.get("canonical_exact"):
            return 0.90
        if features.get("alias_exact"):
            return 0.85

        # Tier 2: Fuzzy matches
        fuzzy_score = features.get("fuzzy_score")
        if fuzzy_score is not None and fuzzy_score >= 0:
            return float(0.5 + (fuzzy_score * 0.3))

        # Tier 3: FTS only
        fts_score = features.get("fts_score")
        if fts_score is not None and fts_score >= 0:
            return float(0.3 + (min(fts_score, 1.0) * 0.3))

        # Fallback: raw matcher score
        return candidate.score

    def _apply_logistic(self, candidate: Candidate) -> float:
        """
        Apply logistic regression model: sigmoid(w·x + b).

        Uses Python math.exp (works without numpy).

        Args:
            candidate: Candidate to calibrate

        Returns:
            Calibrated probability in [0.0, 1.0]
        """
        # Extract features in model's feature order
        features_dict = self.feature_extractor.extract(candidate)
        feature_vector = [features_dict.get(f, -1.0) for f in self.model.features]

        # Compute logit: w·x + b
        logit = (
            sum(w * x for w, x in zip(self.model.weights, feature_vector, strict=False))
            + self.model.bias
        )

        # Clamp extreme values to prevent overflow
        logit = max(min(logit, 20.0), -20.0)

        # Apply sigmoid: 1 / (1 + exp(-logit))
        return 1.0 / (1.0 + math.exp(-logit))

    def calibrate_batch(self, candidates: list[Candidate]) -> list[float]:
        """
        Calibrate multiple candidates efficiently.

        Uses vectorized numpy operations when available (fast path),
        falls back to Python loop otherwise (slow path).

        Args:
            candidates: List of candidates to calibrate

        Returns:
            List of confidence scores [0.0-1.0] in same order
        """
        if not candidates:
            return []

        if self.model and HAS_NUMPY:
            # Fast path: vectorized with numpy
            return self._calibrate_batch_vectorized(candidates)
        else:
            # Slow path: Python loop (no numpy or heuristic mode)
            return [self.calibrate(c) for c in candidates]

    def _calibrate_batch_vectorized(self, candidates: list[Candidate]) -> list[float]:
        """
        Vectorized calibration (requires numpy).

        Args:
            candidates: List of candidates

        Returns:
            List of confidence scores
        """
        # Extract features as numpy array (n_candidates, n_features)
        feature_matrix = self.feature_extractor.extract_batch(candidates)

        # Build feature matrix in model's feature order
        # Handle unknown features (not in FEATURE_SCHEMA) by using sentinel -1.0
        feature_names = list(self.feature_extractor.FEATURE_SCHEMA.keys())

        # Build column indices for known features, None for unknown
        model_feature_indices = []
        for f in self.model.features:
            try:
                model_feature_indices.append(feature_names.index(f))
            except ValueError:
                # Feature not in schema - will use sentinel
                model_feature_indices.append(None)

        # Build feature matrix for model features (n_candidates, n_model_features)
        x = np.zeros((feature_matrix.shape[0], len(self.model.features)))
        for i, idx in enumerate(model_feature_indices):
            if idx is not None:
                x[:, i] = feature_matrix[:, idx]
            else:
                # Unknown feature - use sentinel -1.0
                x[:, i] = -1.0

        # Vectorized logistic: sigmoid(x @ w + b)
        weights = np.array(self.model.weights)
        logits = x @ weights + self.model.bias

        # Clamp to prevent overflow
        logits = np.clip(logits, -20.0, 20.0)

        # Sigmoid
        probabilities = 1.0 / (1.0 + np.exp(-logits))

        return probabilities.tolist()
