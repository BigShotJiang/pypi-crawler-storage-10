"""Feature extraction for calibration."""

from typing import ClassVar

from resolvekit.types import Candidate

# At top of file
try:
    import numpy as np

    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class FeatureExtractor:
    """
    Extracts standardized features from candidates for calibration.

    Reads from candidate.features dict (populated by matchers and constraints)
    and converts to normalized feature vector with sentinel values for missing data.
    """

    # Feature schema: feature_name -> expected type
    FEATURE_SCHEMA: ClassVar[dict[str, type]] = {
        # Match type features (boolean -> float)
        "f_exact_code": bool,
        "f_canonical_exact": bool,
        "f_alias_exact": bool,
        # Similarity features (float or None -> float with sentinel)
        "f_fts_score": float,
        "f_fts_rank_inv": float,  # Derived from fts_rank
        "f_edit_similarity": float,
        "f_trigram_jaccard": float,
        "f_fuzzy_score": float,
        # Constraint features (boolean -> float)
        "f_parent_valid": bool,
        "f_parent_depth": float,  # Normalized 0-1
        "f_type_valid": bool,
        "f_date_valid": bool,
        "f_membership_valid": bool,
    }

    def extract(self, candidate: Candidate) -> dict[str, float]:
        """
        Extract standardized features from candidate.

        Args:
            candidate: Candidate with features dict from matchers/constraints

        Returns:
            Dict of feature_name -> float value
            Missing numeric features use sentinel -1.0
            Missing boolean features use 0.0 (False)
        """
        raw = candidate.features
        features = {}

        # Match type features (boolean -> 1.0 or 0.0)
        features["f_exact_code"] = 1.0 if raw.get("exact_code") else 0.0
        features["f_canonical_exact"] = 1.0 if raw.get("canonical_exact") else 0.0
        features["f_alias_exact"] = 1.0 if raw.get("alias_exact") else 0.0

        # Similarity features (with sentinel -1.0 for missing)
        features["f_fts_score"] = self._get_float(raw, "fts_score", -1.0)
        features["f_edit_similarity"] = self._get_float(raw, "edit_similarity", -1.0)
        features["f_trigram_jaccard"] = self._get_float(raw, "trigram_jaccard", -1.0)
        features["f_fuzzy_score"] = self._get_float(raw, "fuzzy_score", -1.0)

        # FTS rank inverse (1/rank, or -1.0 if missing)
        fts_rank = raw.get("fts_rank")
        features["f_fts_rank_inv"] = (
            1.0 / fts_rank if fts_rank and fts_rank > 0 else -1.0
        )

        # Constraint features (three-state: -1.0=not checked, 0.0=failed, 1.0=passed)
        features["f_parent_valid"] = self._get_constraint_feature(raw, "parent_valid")
        features["f_type_valid"] = self._get_constraint_feature(raw, "type_valid")
        features["f_date_valid"] = self._get_constraint_feature(raw, "date_valid")
        features["f_membership_valid"] = self._get_constraint_feature(
            raw, "membership_valid"
        )

        # Parent depth normalized (depth / 3, capped at 1.0, or -1.0 if not checked)
        parent_depth = raw.get("parent_depth")
        if parent_depth is None:
            features["f_parent_depth"] = -1.0  # Not checked
        else:
            features["f_parent_depth"] = min(parent_depth / 3.0, 1.0)

        return features

    def _get_float(self, raw: dict, key: str, default: float) -> float:
        """Get float value or default if missing/None."""
        value = raw.get(key)
        return float(value) if value is not None else default

    def _get_constraint_feature(self, raw: dict, key: str) -> float:
        """
        Get constraint feature with three-state logic.

        Returns:
            -1.0: Constraint not checked (key missing)
             0.0: Constraint checked and failed (value is False)
             1.0: Constraint checked and passed (value is True)
        """
        value = raw.get(key)
        if value is None:
            return -1.0  # Not checked
        return 1.0 if value else 0.0  # Checked: True→1.0, False→0.0

    def extract_batch(
        self, candidates: list[Candidate]
    ) -> "np.ndarray | list[dict[str, float]]":
        """
        Extract features from multiple candidates.

        Args:
            candidates: List of candidates

        Returns:
            If numpy available: numpy array of shape (n_candidates, n_features)
            If numpy unavailable: list of feature dicts
        """
        if not candidates:
            return np.array([]) if HAS_NUMPY else []

        # Extract features for all candidates
        feature_dicts = [self.extract(c) for c in candidates]

        if not HAS_NUMPY:
            return feature_dicts

        # Convert to numpy array (all dicts have same keys in same order)
        feature_names = list(self.FEATURE_SCHEMA.keys())
        feature_matrix = np.array(
            [[fd[fname] for fname in feature_names] for fd in feature_dicts]
        )
        return feature_matrix
