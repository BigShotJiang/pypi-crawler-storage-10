# Calibration Module

## Purpose

The calibration module converts raw matcher scores into calibrated confidence probabilities that reflect actual precision, enabling reliable threshold-based decision making.

## Components

### Core Components

**Currently Implemented:**

1. **CalibrationModel** (`models.py`)
   - Pydantic schema for calibration model configuration
   - JSON loading and validation
   - Model metadata (ECE, training date, notes)

2. **Feature Extractor** (`features.py`)
   - Extracts standardized features from candidates
   - Converts matcher-specific features to normalized values
   - Handles missing features with sentinel values
   - Optional numpy vectorization for batch processing

3. **Calibrator** (`calibrator.py`)
   - Applies calibration models to candidates
   - Returns probability P(correct match | features)
   - Supports logistic regression models
   - Heuristic fallback when no model available
   - Batch processing with optional numpy acceleration

**Planned for Future Phases:**

4. **Model Trainer** (`trainer.py` - not yet implemented)
   - Trains calibration models on labeled data
   - Evaluates calibration quality (ECE - Expected Calibration Error)
   - Exports models to JSON for data packs

5. **Score Fusion** (`fusion.py` - not yet implemented)
   - Combines scores from multiple matchers
   - Handles missing features (when matchers not invoked)
   - Normalizes scores to comparable scales

## Feature Set

Features extracted per (query, candidate) pair:

### Match Type Features (binary)
- `f_exact_code`: Matched via exact code lookup
- `f_canonical_exact`: Matched via canonical name
- `f_alias_exact`: Matched via exact alias
- `f_alias_type_*`: One-hot encoding of alias type (canonical/endonym/exonym/abbr/code)

### Similarity Features (continuous)
- `f_fts_score`: BM25-like score from FTS
- `f_fts_rank_inv`: Inverse rank (1/rank)
- `f_edit_distance_norm`: Normalized edit distance
- `f_trigram_jaccard`: Trigram Jaccard similarity

### Constraint Features (binary)
- `f_parent_valid`: Passes parent constraint
- `f_type_valid`: Passes type constraint
- `f_date_valid`: Passes temporal constraint

### Semantic Features (optional)
- `f_sem_used`: Semantic matcher was invoked
- `f_sem_sim`: Cosine similarity from embeddings (0-1)

### Context Features
- `f_ambiguity_flag`: Query in ambiguity registry
- `f_region_hint_match`: Candidate matches region hint

## Calibration Model

### Logistic Regression (default)

```python
import numpy as np

def calibrate_logistic(features: np.ndarray, weights: np.ndarray, bias: float) -> float:
    """Compute calibrated probability via logistic regression."""
    logit = np.dot(weights, features) + bias
    probability = 1 / (1 + np.exp(-logit))
    return probability
```

### Model Format (JSON)

```json
{
  "type": "logistic",
  "features": ["f_exact_code", "f_canonical_exact", ...],
  "weights": [2.3, 1.6, 0.9, ...],
  "bias": -1.4,
  "ece": 0.032,
  "trained_on": "2025-10-15",
  "notes": "Global calibration; overlays may append."
}
```

## Calibration Quality Metrics

- **ECE (Expected Calibration Error)**: Measures deviation between predicted probabilities and observed accuracy
- **Brier Score**: Mean squared error of probabilistic predictions
- **Reliability Diagram**: Plots predicted vs observed probabilities in bins

Target: ECE < 0.05 (well-calibrated)

## Design Principles

1. **Interpretable**: Use simple models (logistic) for explainability
2. **Calibrated**: Probabilities should match empirical accuracy
3. **Versioned**: Models versioned with data packs
4. **Updatable**: Overlays can fine-tune calibration with delta weights

## Usage Examples

### Basic Usage - Heuristic Fallback

When no calibration model is available, the calibrator uses rule-based heuristics:

```python
from resolvekit.calibration import Calibrator
from resolvekit.types import Candidate, Entity, EntityType, MatcherType

# Create calibrator without model (uses heuristic)
calibrator = Calibrator(model=None)

# Example candidate from exact code matcher
candidate = Candidate(
    entity=Entity(
        dcid="country/USA",
        canonical_name="United States",
        entity_type=EntityType.COUNTRY,
    ),
    score=1.0,
    matcher_type=MatcherType.EXACT_CODE,
    features={"exact_code": True, "code_system": "iso3"},
)

# Calibrate to get confidence probability
confidence = calibrator.calibrate(candidate)
print(f"Confidence: {confidence}")  # 0.95 for exact code matches
```

### Loading and Using a Trained Model

Load a calibration model from a data pack and use it for calibration:

```python
from pathlib import Path
from resolvekit.calibration import Calibrator, load_calibration_model

# Load model from JSON file in data pack
model_path = Path("data/base/calibration_model.json")
model = load_calibration_model(model_path)

if model:
    print(f"Loaded model with {len(model.features)} features")
    print(f"ECE: {model.ece}")  # Expected Calibration Error

    # Create calibrator with model
    calibrator = Calibrator(model=model)

    # Calibrate candidates using logistic regression
    confidence = calibrator.calibrate(candidate)
    print(f"Model-calibrated confidence: {confidence}")
else:
    print("Model not found, falling back to heuristic")
    calibrator = Calibrator(model=None)
```

### Batch Processing for Efficiency

Process multiple candidates efficiently using batch calibration:

```python
from resolvekit.calibration import Calibrator

# Prepare multiple candidates
candidates = [
    Candidate(
        entity=Entity(dcid="country/USA", canonical_name="United States",
                     entity_type=EntityType.COUNTRY),
        score=1.0,
        matcher_type=MatcherType.EXACT_CODE,
        features={"exact_code": True},
    ),
    Candidate(
        entity=Entity(dcid="country/FRA", canonical_name="France",
                     entity_type=EntityType.COUNTRY),
        score=0.9,
        matcher_type=MatcherType.CANONICAL_NAME,
        features={"canonical_exact": True},
    ),
    Candidate(
        entity=Entity(dcid="country/DEU", canonical_name="Germany",
                     entity_type=EntityType.COUNTRY),
        score=0.75,
        matcher_type=MatcherType.FUZZY,
        features={"fuzzy_score": 0.78, "fts_score": 0.82},
    ),
]

calibrator = Calibrator(model=None)

# Batch calibration (uses numpy vectorization if available)
confidences = calibrator.calibrate_batch(candidates)

# Results correspond to input order
for candidate, confidence in zip(candidates, confidences):
    print(f"{candidate.entity.canonical_name}: {confidence:.2f}")
# Output:
# United States: 0.95
# France: 0.90
# Germany: 0.73
```

### Feature Extraction

Extract standardized features from candidates for analysis or custom calibration:

```python
from resolvekit.calibration import FeatureExtractor

extractor = FeatureExtractor()

# Extract features from a candidate
features = extractor.extract(candidate)

# Features dict contains standardized feature values
print(features)
# {
#   'f_exact_code': 1.0,
#   'f_canonical_exact': 0.0,
#   'f_alias_exact': 0.0,
#   'f_fts_score': -1.0,  # Sentinel value (not used)
#   'f_fts_rank_inv': -1.0,
#   'f_edit_similarity': -1.0,
#   'f_trigram_jaccard': -1.0,
#   'f_fuzzy_score': -1.0,
#   'f_parent_valid': 0.0,
#   'f_parent_depth': 0.0,
#   'f_type_valid': 0.0,
#   'f_date_valid': 0.0,
#   'f_membership_valid': 0.0,
# }

# Extract features from multiple candidates
feature_dicts = extractor.extract_batch(candidates)
# Returns list of dicts (or numpy array if numpy available)
```

### Creating a Calibration Model

Define a custom calibration model programmatically:

```python
from resolvekit.calibration import CalibrationModel
from datetime import date

# Create a simple logistic regression model
model = CalibrationModel(
    type="logistic",
    features=["f_exact_code", "f_canonical_exact", "f_fts_score"],
    weights=[4.0, 3.5, 1.5],
    bias=-2.0,
    ece=0.025,
    trained_on=date(2025, 10, 15),
    notes="Custom calibration model",
)

# Use the model
calibrator = Calibrator(model=model)
confidence = calibrator.calibrate(candidate)
```

### Integration with Resolver Pipeline

Typical usage within the resolver cascade:

```python
from resolvekit.calibration import Calibrator, load_calibration_model
from pathlib import Path

# Initialize calibrator at resolver startup
model = load_calibration_model(Path("data/base/calibration_model.json"))
calibrator = Calibrator(model=model)

# During resolution, matchers populate candidate.features
# Then calibrator converts to confidence probabilities

def resolve(query: str) -> list[tuple[Candidate, float]]:
    # 1. Matchers generate candidates with features
    candidates = run_matcher_cascade(query)

    # 2. Calibrator converts to confidence probabilities
    confidences = calibrator.calibrate_batch(candidates)

    # 3. Return ranked results
    results = list(zip(candidates, confidences))
    results.sort(key=lambda x: x[1], reverse=True)  # Sort by confidence

    return results
```

### Heuristic Scoring Rules

When using heuristic mode (no model), confidence scores follow these rules:

- **Tier 1 - Exact Matches** (0.85-0.95):
  - Exact code match: 0.95
  - Canonical name exact: 0.90
  - Alias exact: 0.85

- **Tier 2 - Fuzzy Matches** (0.5-0.8):
  - Base: 0.5 + (fuzzy_score × 0.3)
  - Example: fuzzy_score=0.78 → confidence=0.734

- **Tier 3 - FTS Only** (0.3-0.6):
  - Base: 0.3 + (fts_score × 0.3)
  - Example: fts_score=0.7 → confidence=0.51

- **Fallback**: Returns raw matcher score if no features match

### Performance Considerations

```python
# Batch processing is faster for multiple candidates
import time

# Single-item processing
start = time.time()
for candidate in candidates:
    confidence = calibrator.calibrate(candidate)
single_time = time.time() - start

# Batch processing (with numpy)
start = time.time()
confidences = calibrator.calibrate_batch(candidates)
batch_time = time.time() - start

print(f"Single: {single_time:.4f}s")
print(f"Batch: {batch_time:.4f}s")
print(f"Speedup: {single_time / batch_time:.1f}x")
# With numpy: 5-10x speedup for 100+ candidates
# Without numpy: Similar performance (both use Python loop)
```

## Implementation Priority

**Phase A** - Core resolver
