"""Calibration model data structures."""

import json
from datetime import date
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from resolvekit.utils.logging import get_logger

logger = get_logger(__name__)


class CalibrationModel(BaseModel):
    """
    Calibration model configuration.

    Loaded from JSON files in data packs. Defines logistic regression
    parameters for converting features to calibrated probabilities.

    Attributes:
        type: Model type (currently only "logistic" supported)
        features: Ordered list of feature names
        weights: Logistic regression weights (one per feature)
        bias: Logistic regression bias term
        ece: Expected Calibration Error (optional, for model quality tracking)
        trained_on: Date model was trained (optional)
        notes: Human-readable notes (optional)
    """

    model_config = ConfigDict(frozen=True)

    type: Literal["logistic"] = Field(
        default="logistic", description="Calibration model type"
    )
    features: list[str] = Field(..., min_length=1, description="Feature names in order")
    weights: list[float] = Field(..., min_length=1, description="Logistic weights")
    bias: float = Field(..., description="Logistic bias term")
    ece: float | None = Field(
        None, ge=0.0, le=1.0, description="Expected Calibration Error"
    )
    trained_on: date | None = Field(None, description="Training date")
    notes: str | None = Field(None, description="Human-readable notes")

    @model_validator(mode="after")
    def validate_weights_match_features(self) -> "CalibrationModel":
        """Validate that weights count matches features count."""
        if len(self.weights) != len(self.features):
            raise ValueError(
                f"Weights count ({len(self.weights)}) must match "
                f"features count ({len(self.features)})"
            )
        return self


def load_calibration_model(path: Path) -> CalibrationModel | None:
    """
    Load calibration model from JSON file.

    Args:
        path: Path to calibration_model.json file

    Returns:
        CalibrationModel if file exists and is valid, None otherwise
    """
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text())
        return CalibrationModel.model_validate(data)
    except json.JSONDecodeError as e:
        logger.warning(f"Invalid JSON in calibration model at {path}: {e}")
        return None
    except ValidationError as e:
        logger.warning(f"Invalid calibration model schema at {path}: {e}")
        return None
