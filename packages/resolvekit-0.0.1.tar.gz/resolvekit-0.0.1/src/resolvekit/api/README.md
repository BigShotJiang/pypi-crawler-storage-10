# API Module

## Purpose

The API module provides the primary Python programmatic interface for entity resolution, code conversion, and related operations.

## Components

### Core API Classes

1. **Resolver** (`resolver.py`)
   - Main entry point for all resolution operations
   - Manages configuration and data pack loading
   - Orchestrates matchers, constraints, and calibration

2. **Resolution** (`resolution.py`)
   - Data class representing resolution results
   - Contains matched entity, alternatives, confidence, explanation
   - Supports JSON serialization

3. **Config** (`config.py`)
   - Configuration management
   - User-provided settings (thresholds, data paths, etc.)
   - Environment variable support

### API Operations

- `resolve.py`: Single entity resolution
- `batch.py`: Batch resolution operations
- `convert.py`: Code system conversion
- `hierarchy.py`: Hierarchy navigation
- `extract.py`: Entity extraction from text (Phase F)
- `membership.py`: Group membership queries

## Primary API: Resolver Class

```python
from resolvekit.api import Resolver
from datetime import date

# Initialize resolver
resolver = Resolver(
    data_path="/path/to/data/packs",
    custom_overlays=["custom_aliases.yaml"],
    min_confidence=0.7
)

# Single entity resolution
result = resolver.resolve(
    "Cote d Ivoire",
    entity_type=None,
    parent=None,
    at=None,
    context=None,
    return_alternates=5,
    explain=False
)

# Access results
print(result.entity.dcid)           # "country/CIV"
print(result.entity.canonical_name)  # "Côte d'Ivoire"
print(result.confidence)             # 0.95
print(result.alternatives)           # [Entity, Entity, ...]

# Code conversion
dcid = resolver.code_to_dcid("FRA", code_type="iso3")
codes = resolver.dcid_to_codes("country/FRA")

# Batch operations
import pandas as pd
df = pd.DataFrame({"location": ["France", "UK", "Türkiye"]})
results = resolver.resolve_many(df["location"].tolist())

# Temporal queries
eu_2004 = resolver.get_group_members("EU", as_of=date(2004, 1, 1))
was_member = resolver.check_membership(
    "country/POL",
    group="EU",
    as_of=date(2003, 12, 31)
)

# Hierarchy navigation
children = resolver.get_children("country/FRA", admin_level=1)
parent = resolver.get_parent("geoId/06")
path = resolver.get_hierarchy_path("some/admin3/entity")
```

## Resolution Result Structure

```python
@dataclass
class Resolution:
    """Resolution result."""

    entity: Entity | None          # Primary match
    confidence: float              # Calibrated probability
    alternatives: list[Entity]     # Alternative candidates
    explanation: Explanation | None  # Why this match (if explain=True)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        ...

    def to_json(self) -> str:
        """Serialize to JSON."""
        ...

@dataclass
class Entity:
    """Resolved entity."""

    dcid: str
    canonical_name: str
    entity_type: str
    codes: dict[str, str]  # {system: code}
    parent_dcid: str | None
    valid_from: date | None
    valid_until: date | None

@dataclass
class Explanation:
    """Resolution explanation."""

    stages: list[str]              # Stages executed
    candidates: list[Candidate]    # All candidates with features
    rules_applied: list[str]       # Disambiguation rules
    calibration: dict              # Model details
```

## Design Principles

1. **Pythonic**: Snake_case, context managers, type hints
2. **Sensible defaults**: Works out of box without configuration
3. **Progressive disclosure**: Simple for basic use, powerful for advanced
4. **Type safety**: Full type annotations for IDE support
5. **Pandas integration**: Native support for DataFrame operations

## Error Handling

```python
from resolvekit.api import Resolver, ResolutionError, ConfigError

try:
    resolver = Resolver()
except ConfigError as e:
    # Handle configuration errors
    print(f"Config error: {e}")

try:
    result = resolver.resolve("invalid input")
except ResolutionError as e:
    # Handle resolution errors
    print(f"Resolution failed: {e}")

# No match returns None, not exception
result = resolver.resolve("zzzzzz")
if result.entity is None:
    print("No match found")
```

## Implementation Priority

**Phase A** - Core resolver (Resolver class, resolve, batch)
**Phase B** - Code conversion and hierarchy APIs
**Phase F** - Entity extraction
