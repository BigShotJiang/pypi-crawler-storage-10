"""Public Resolver API."""

from resolvekit.api.convenience import resolve, resolve_many
from resolvekit.api.resolver import Resolver

__all__ = [
    "Resolver",
    "resolve",
    "resolve_many",
]
