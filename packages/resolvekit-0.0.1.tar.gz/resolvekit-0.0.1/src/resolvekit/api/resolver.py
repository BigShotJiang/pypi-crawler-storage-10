"""Main Resolver API."""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from resolvekit.calibration.calibrator import Calibrator
from resolvekit.calibration.models import load_calibration_model
from resolvekit.constraints.constraint_engine import ConstraintEngine
from resolvekit.data.alias_repository import AliasRepository
from resolvekit.data.code_repository import CodeRepository
from resolvekit.data.db_manager import DatabaseManager
from resolvekit.data.entity_repository import EntityRepository
from resolvekit.data.membership_repository import MembershipRepository
from resolvekit.matchers.alias_exact import AliasExactMatcher
from resolvekit.matchers.canonical_name import CanonicalNameMatcher
from resolvekit.matchers.cascade import MatcherCascade
from resolvekit.matchers.exact_code import ExactCodeMatcher
from resolvekit.matchers.fts_matcher import FTSMatcher
from resolvekit.matchers.fuzzy_matcher import FuzzyMatcher
from resolvekit.normalization.normalizer import TextNormalizer
from resolvekit.types import (
    Candidate,
    EntityType,
    Explanation,
    ExplanationMode,
    MatchContext,
    Resolution,
)
from resolvekit.utils.dates import parse_date

if TYPE_CHECKING:
    import pandas as pd


class Resolver:
    """
    Main entity resolution API.

    Orchestrates matchers, constraints, and calibration to resolve
    entity strings to canonical entities with confidence scores.
    """

    def __init__(
        self,
        *,
        data_pack: str | Path | None = None,
        overlays: list[str | Path] | None = None,
        min_confidence: float = 0.5,
        explanation_mode: ExplanationMode = ExplanationMode.STANDARD,
        top_k: int = 12,
        calibration_model: str | Path | None = None,
    ):
        """
        Initialize resolver with data pack and configuration.

        Args:
            data_pack: Optional path to data pack. If None, uses default bundled pack.
            overlays: Optional list of overlay data packs (user/org customizations)
            min_confidence: Minimum confidence threshold (default 0.5)
            explanation_mode: Level of detail in explanations
            top_k: Maximum candidates to consider
            calibration_model: Optional path to calibration model
        """
        self.min_confidence = min_confidence
        self.explanation_mode = explanation_mode
        self.top_k = top_k

        # Initialize normalizer (needed by repositories)
        self.normalizer = TextNormalizer()

        # Initialize database and repositories
        # TODO: Auto-discover default data pack if None
        if data_pack is not None:
            data_pack_path = (
                Path(data_pack) if isinstance(data_pack, str) else data_pack
            )
        else:
            # TODO: Auto-discover default data pack
            data_pack_path = Path("data.db")  # Temporary placeholder

        # Convert overlays to Path objects
        overlay_paths: list[Path] | None = None
        if overlays:
            overlay_paths = [
                Path(overlay) if isinstance(overlay, str) else overlay
                for overlay in overlays
            ]

        self.db_manager = DatabaseManager(data_pack_path, overlays=overlay_paths)
        self.db_manager.connect()
        self.entity_repo = EntityRepository(self.db_manager)
        self.alias_repo = AliasRepository(self.db_manager, self.normalizer)
        self.code_repo = CodeRepository(self.db_manager, self.entity_repo)
        self.membership_repo = MembershipRepository(self.db_manager)

        # Initialize matchers
        self.exact_code = ExactCodeMatcher(self.code_repo)
        self.canonical_name = CanonicalNameMatcher(self.entity_repo, self.normalizer)
        self.alias_exact = AliasExactMatcher(self.alias_repo)
        self.fts = FTSMatcher(self.alias_repo)
        self.fuzzy = FuzzyMatcher(self.normalizer)

        # Initialize cascade
        self.cascade = MatcherCascade(
            exact_code=self.exact_code,
            canonical_name=self.canonical_name,
            alias_exact=self.alias_exact,
            fts=self.fts,
            fuzzy=self.fuzzy,
            normalizer=self.normalizer,
        )

        # Initialize constraint engine
        self.constraint_engine = ConstraintEngine(
            entity_repo=self.entity_repo,
            membership_repo=self.membership_repo,
        )

        # Initialize calibrator
        if calibration_model:
            calibration_model_path = (
                Path(calibration_model)
                if isinstance(calibration_model, str)
                else calibration_model
            )
            model = load_calibration_model(calibration_model_path)
            self.calibrator = Calibrator(model)
        else:
            # Heuristic mode (no model)
            self.calibrator = Calibrator()

    def resolve(
        self,
        query: str,
        context: MatchContext | None = None,
    ) -> Resolution:
        """
        Resolve single entity query.

        Args:
            query: Entity string to resolve
            context: Optional match context for filtering/disambiguation

        Returns:
            Resolution result
        """
        # Stage 1: Cascade (normalization + matching)
        candidates = self.cascade.resolve(query, context=context, top_k=self.top_k)

        # No candidates found
        if not candidates:
            return Resolution(
                entity=None,
                confidence=0.0,
                alternatives=[],
                explanation=self._build_explanation_empty(query)
                if self.explanation_mode != ExplanationMode.MINIMAL
                else None,
            )

        # Stage 2: Constraint engine (KG/temporal validation)
        candidates = self.constraint_engine.apply_constraints(candidates, context)

        # All filtered by constraints
        if not candidates:
            return Resolution(
                entity=None,
                confidence=0.0,
                alternatives=[],
                explanation=self._build_explanation_filtered(query)
                if self.explanation_mode != ExplanationMode.MINIMAL
                else None,
            )

        # Stage 3: Calibration (score → confidence probability)
        calibrated_scores = self.calibrator.calibrate_batch(candidates)

        # Stage 4: Sort by calibrated confidence
        sorted_candidates = sorted(
            zip(candidates, calibrated_scores, strict=False),
            key=lambda x: x[1],
            reverse=True,
        )

        # Stage 5: Threshold filtering
        top_candidate, top_confidence = sorted_candidates[0]
        entity = None if top_confidence < self.min_confidence else top_candidate.entity

        # Stage 6: Build alternatives (next 2-5 candidates)
        alternatives = [c.entity for c, score in sorted_candidates[1:6]]

        # Stage 7: Build explanation
        explanation = self._build_explanation(
            top_candidate,
            sorted_candidates,
            query,
        )

        return Resolution(
            entity=entity,
            confidence=top_confidence,
            alternatives=alternatives,
            explanation=explanation,
        )

    def _build_explanation_empty(self, query: str) -> Explanation | None:
        """Build explanation for empty results."""
        if self.explanation_mode == ExplanationMode.MINIMAL:
            return None
        return Explanation(
            stages=["cascade"],
            trace={"query": query, "reason": "no_candidates"},
        )

    def _build_explanation_filtered(self, query: str) -> Explanation | None:
        """Build explanation for constraint-filtered results."""
        if self.explanation_mode == ExplanationMode.MINIMAL:
            return None
        return Explanation(
            stages=["cascade", "constraints"],
            trace={"query": query, "reason": "filtered_by_constraints"},
        )

    def _build_explanation(
        self,
        top_candidate: Candidate,
        sorted_candidates: list[tuple[Candidate, float]],
        query: str,
    ) -> Explanation | None:
        """
        Build explanation based on mode.

        Args:
            top_candidate: Top candidate
            sorted_candidates: All candidates with scores
            query: Original query

        Returns:
            Explanation or None (for MINIMAL mode)
        """
        if self.explanation_mode == ExplanationMode.MINIMAL:
            return None

        # STANDARD mode
        explanation = Explanation(
            matcher_used=top_candidate.matcher_type,
            features=top_candidate.features.copy(),
            stages=["cascade", "constraints", "calibration"],
            candidates=[c for c, _ in sorted_candidates[1:4]],  # Next 3 as alternatives
        )

        # FULL mode - add trace
        if self.explanation_mode == ExplanationMode.FULL:
            explanation.trace = {
                "query": query,
                "total_candidates": len(sorted_candidates),
                "all_candidates": [
                    {
                        "dcid": c.entity.dcid,
                        "name": c.entity.canonical_name,
                        "score": float(score),
                        "matcher": c.matcher_type.value,
                    }
                    for c, score in sorted_candidates
                ],
            }

        return explanation

    def resolve_many(
        self,
        queries: list[str],
        context: MatchContext | list[MatchContext | None] | None = None,
    ) -> list[Resolution]:
        """
        Resolve multiple queries.

        Args:
            queries: List of query strings
            context: Optional context - applies to all queries if MatchContext,
                    or per-query if list (must match length of queries)

        Returns:
            List of Resolution objects (same order as queries)
        """
        # Validate per-query context length
        if isinstance(context, list):
            if len(context) != len(queries):
                raise ValueError(
                    f"context list length ({len(context)}) must match queries length ({len(queries)})"
                )
            # Per-query contexts - resolve individually
            return [
                self.resolve(query, ctx)
                for query, ctx in zip(queries, context, strict=True)
            ]

        # Shared context - deduplicate queries for efficiency
        unique_queries = list(dict.fromkeys(queries))

        # Resolve only unique queries
        unique_resolutions = {
            query: self.resolve(query, context) for query in unique_queries
        }

        # Map results back to original query order
        return [unique_resolutions[query] for query in queries]

    def __enter__(self) -> "Resolver":
        """Context manager entry."""
        return self

    def __exit__(self, *args: object) -> None:
        """Context manager exit - clean up resources."""
        # Close database connections
        if hasattr(self, "db_manager"):
            self.db_manager.close()

    def resolve_dataframe(  # noqa: PLR0912
        self,
        df: "pd.DataFrame",
        query_column: str,
        resolve_to: str | list[str] = "dcid",
        *,
        context_columns: dict[str, str] | None = None,
        context: MatchContext | None = None,
        include_confidence: bool = True,
        output_prefix: str = "",
    ) -> "pd.DataFrame":
        """
        Resolve entities from DataFrame column to specified code system(s).

        Args:
            df: Input DataFrame
            query_column: Column name containing entity strings to resolve
            resolve_to: What to resolve to (default: "dcid")
            context_columns: Map MatchContext fields to DataFrame columns
            context: Single MatchContext for all rows
            include_confidence: Add confidence score column
            output_prefix: Prefix for output columns

        Returns:
            DataFrame with resolution results added as columns
        """
        # Import pandas only when needed
        try:
            import pandas as pd
        except ImportError as e:
            raise ImportError("pandas is required for resolve_dataframe(). ") from e

        # Validate inputs
        if query_column not in df.columns:
            raise ValueError(f"Column '{query_column}' not found in DataFrame")

        # Normalize resolve_to to list
        if isinstance(resolve_to, str):
            resolve_to = [resolve_to]

        # Deduplication optimization
        if context_columns is None:
            # Simple case: shared context, dedupe on query only
            unique_queries = df[query_column].unique().tolist()
            unique_resolutions = self.resolve_many(unique_queries, context=context)

            # Create lookup dict
            lookup = dict(zip(unique_queries, unique_resolutions, strict=True))

            # Map back to all rows
            resolutions = [lookup[q] for q in df[query_column]]
        else:
            # Build per-row contexts from context_columns
            queries = df[query_column].tolist()

            # Validate context columns exist
            for field_name, col_name in context_columns.items():
                if col_name not in df.columns:
                    raise ValueError(
                        f"Context column '{col_name}' (for field '{field_name}') not found in DataFrame"
                    )

            # Build MatchContext for each row
            # Extract only the columns we need and convert to list of dicts
            context_df = df[list(context_columns.values())]
            records = context_df.to_dict("records")

            # Map column names to field names for lookup
            col_to_field = {
                col_name: field_name for field_name, col_name in context_columns.items()
            }

            # Build contexts from records
            contexts = []
            for record in records:
                context_kwargs: dict[str, Any] = {}
                for col_name_raw, value in record.items():
                    col_name = str(col_name_raw)  # Convert Hashable to str
                    if pd.isna(value):
                        continue

                    field_name = col_to_field[col_name]

                    # Type conversions
                    if field_name == "entity_type":
                        context_kwargs[field_name] = EntityType(value)
                    elif field_name == "as_of":
                        context_kwargs[field_name] = parse_date(value)
                    else:
                        context_kwargs[field_name] = value

                contexts.append(
                    MatchContext(**context_kwargs) if context_kwargs else None
                )

            resolutions = self.resolve_many(queries, context=contexts)

        # Build output DataFrame
        return self._build_output_dataframe(
            df, resolutions, resolve_to, include_confidence, output_prefix
        )

    def _build_output_dataframe(
        self,
        df: "pd.DataFrame",
        resolutions: list[Resolution],
        resolve_to: list[str],
        include_confidence: bool,
        output_prefix: str,
    ) -> "pd.DataFrame":
        """Build output DataFrame with resolution results."""

        # Copy input DataFrame
        result_df = df.copy()

        # Extract requested fields from resolutions
        for field in resolve_to:
            col_name = f"{output_prefix}{field}"
            values: list[str | None] = []

            for res in resolutions:
                if res.entity is None:
                    values.append(None)
                elif field == "dcid":
                    values.append(res.entity.dcid)
                elif field == "canonical_name":
                    values.append(res.entity.canonical_name)
                else:
                    # Code system (iso3, m49, etc.)
                    values.append(res.entity.codes.get(field))

            result_df[col_name] = values

        # Add confidence column
        if include_confidence:
            conf_col = f"{output_prefix}confidence"
            result_df[conf_col] = [r.confidence for r in resolutions]

        return result_df
