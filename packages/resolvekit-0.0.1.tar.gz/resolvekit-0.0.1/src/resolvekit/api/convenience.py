"""Convenience functions for quick one-off queries."""

from typing import Any

from resolvekit.api.resolver import Resolver
from resolvekit.types import MatchContext, Resolution


def resolve(
    query: str,
    context: MatchContext | None = None,
    **resolver_kwargs: Any,
) -> Resolution:
    """
    Resolve single entity (convenience function).

    Creates ephemeral Resolver instance for one-off queries.
    For repeated queries, create a Resolver instance for better performance.

    Args:
        query: Entity string to resolve
        context: Optional match context
        **resolver_kwargs: Passed to Resolver() constructor
            (min_confidence, explanation_mode, etc.)

    Returns:
        Resolution result
    """
    with Resolver(**resolver_kwargs) as resolver:
        return resolver.resolve(query, context=context)


def resolve_many(
    queries: list[str],
    context: MatchContext | list[MatchContext | None] | None = None,
    **resolver_kwargs: Any,
) -> list[Resolution]:
    """
    Resolve multiple entities (convenience function).

    Creates ephemeral Resolver instance.
    For repeated queries, create a Resolver instance for better performance.

    Args:
        queries: List of query strings
        context: Optional context (shared or per-query list)
        **resolver_kwargs: Passed to Resolver() constructor

    Returns:
        List of Resolution objects
    """
    with Resolver(**resolver_kwargs) as resolver:
        return resolver.resolve_many(queries, context=context)
