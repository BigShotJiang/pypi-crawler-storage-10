"""Text normalization module for resolvekit."""

import re
from dataclasses import dataclass
from typing import ClassVar

from resolvekit.utils.cache import lru_cache
from resolvekit.utils.text import (
    case_fold,
    normalize_unicode,
    normalize_whitespace,
    remove_diacritics,
)


@dataclass(frozen=True)
class NormalizationLevel:
    """Configuration for a normalization level."""

    name: str
    unicode_norm: bool
    remove_diacritics: bool
    case_fold: bool
    normalize_whitespace: bool
    remove_punctuation: bool


class TextNormalizer:
    """Text normalizer with preset levels and LRU caching."""

    LEVELS: ClassVar[dict[str, NormalizationLevel]] = {
        "strict": NormalizationLevel(
            name="strict",
            unicode_norm=True,
            remove_diacritics=False,
            case_fold=False,
            normalize_whitespace=True,
            remove_punctuation=False,
        ),
        "standard": NormalizationLevel(
            name="standard",
            unicode_norm=True,
            remove_diacritics=True,
            case_fold=True,
            normalize_whitespace=True,
            remove_punctuation=False,
        ),
        "aggressive": NormalizationLevel(
            name="aggressive",
            unicode_norm=True,
            remove_diacritics=True,
            case_fold=True,
            normalize_whitespace=True,
            remove_punctuation=True,
        ),
    }

    @lru_cache(maxsize=10000)
    def normalize(self, text: str, level: str = "standard") -> str:
        """
        Normalize text using preset level.

        Args:
            text: Text to normalize
            level: Normalization level (strict, standard, aggressive)

        Returns:
            Normalized text

        Examples:
            >>> normalizer = TextNormalizer()
            >>> normalizer.normalize("Côte d'Ivoire")
            "cote d'ivoire"
        """
        # Handle empty/whitespace-only strings
        if not text or not text.strip():
            return ""

        # Get level config
        level_config = self.LEVELS[level]

        # Apply normalizations
        return self._apply_normalizations(text, level_config)

    def _apply_normalizations(self, text: str, config: NormalizationLevel) -> str:
        """
        Apply normalizations based on configuration.

        Args:
            text: Text to normalize
            config: Normalization level configuration

        Returns:
            Normalized text
        """
        # Unicode normalization
        if config.unicode_norm:
            text = normalize_unicode(text)

        # Remove diacritics
        if config.remove_diacritics:
            text = remove_diacritics(text)

        # Case folding
        if config.case_fold:
            text = case_fold(text)

        # Normalize whitespace
        if config.normalize_whitespace:
            text = normalize_whitespace(text)

        # Remove punctuation
        if config.remove_punctuation:
            text = self._remove_punctuation(text)

        return text

    @staticmethod
    def _remove_punctuation(text: str) -> str:
        """
        Remove punctuation from text.

        Args:
            text: Input text

        Returns:
            Text without punctuation
        """
        # Remove common punctuation but keep spaces and alphanumerics
        return re.sub(r"[^\w\s]", "", text)

    def normalize_batch(self, texts: list[str], level: str = "standard") -> list[str]:
        """
        Normalize multiple texts efficiently.

        Args:
            texts: List of texts to normalize
            level: Normalization level (strict, standard, aggressive)

        Returns:
            List of normalized texts

        Examples:
            >>> normalizer = TextNormalizer()
            >>> normalizer.normalize_batch(["France", "Germany"])
            ["france", "germany"]
        """
        # Delegate to normalize() to reuse guard logic and benefit from cache
        return [self.normalize(text, level) for text in texts]

    def get_level_config(self, level: str) -> NormalizationLevel:
        """
        Get configuration for a normalization level.

        Args:
            level: Normalization level name

        Returns:
            NormalizationLevel configuration

        Raises:
            KeyError: If level name is invalid
        """
        return self.LEVELS[level]
