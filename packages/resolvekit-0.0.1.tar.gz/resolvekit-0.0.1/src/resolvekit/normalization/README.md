# Normalization Module

## Purpose

The normalization module handles text preprocessing to ensure consistent string matching across different input formats and languages. It provides three preset levels optimized for different use cases.

## Implementation Status

✅ **Implemented** - Phase A complete with 94% test coverage

## Features

- **Three Preset Levels**: strict, standard, aggressive
- **Performance-First**: LRU caching for repeated queries (10,000 entry cache)
- **Unicode Handling**: NFKD normalization for consistent representation
- **Diacritic Removal**: Configurable diacritical mark handling
- **Batch Operations**: Efficient processing of multiple texts
- **Graceful Error Handling**: Handles edge cases (empty strings, None, etc.)

## Quick Start

```python
from resolvekit.normalization import TextNormalizer

# Create normalizer (stateless, reusable)
normalizer = TextNormalizer()

# Basic usage (default: standard level)
result = normalizer.normalize("Côte d'Ivoire")
print(result)  # Output: "cote d'ivoire"

# Batch processing
countries = ["France", "Côte d'Ivoire", "Germany"]
normalized = normalizer.normalize_batch(countries)
print(normalized)  # ['france', "cote d'ivoire", 'germany']
```

## Normalization Levels

### Strict
**Use for**: Exact matching where case and diacritics matter (e.g., ISO codes)

```python
normalizer.normalize("USA", level="strict")  # "USA"
normalizer.normalize("Côte d'Ivoire", level="strict")  # "Côte d'Ivoire" (decomposed unicode)
```

- ✅ Unicode normalization (NFKD)
- ✅ Whitespace normalization
- ❌ Diacritic removal
- ❌ Case folding
- ❌ Punctuation removal

### Standard (Default)
**Use for**: General entity resolution and fuzzy matching

```python
normalizer.normalize("Côte d'Ivoire")  # "cote d'ivoire"
normalizer.normalize("U.S.A.")  # "u.s.a."
```

- ✅ Unicode normalization (NFKD)
- ✅ Diacritic removal
- ✅ Case folding
- ✅ Whitespace normalization
- ❌ Punctuation removal

### Aggressive
**Use for**: Noisy data, user input with typos, low-quality sources

```python
normalizer.normalize("U.S.A.", level="aggressive")  # "usa"
normalizer.normalize("Côte-d'Ivoire!!!", level="aggressive")  # "cote divoire"
```

- ✅ Unicode normalization (NFKD)
- ✅ Diacritic removal
- ✅ Case folding
- ✅ Whitespace normalization
- ✅ Punctuation removal

## API Reference

### TextNormalizer

```python
class TextNormalizer:
    def normalize(text: str, level: str = "standard") -> str:
        """Normalize single text with LRU caching."""

    def normalize_batch(texts: list[str], level: str = "standard") -> list[str]:
        """Normalize multiple texts efficiently."""

    def get_level_config(level: str) -> NormalizationLevel:
        """Get configuration for a level (for introspection)."""
```

### Examples

```python
from resolvekit.normalization import TextNormalizer

normalizer = TextNormalizer()

# Different levels
normalizer.normalize("Türkiye", level="strict")      # "Türkiye"
normalizer.normalize("Türkiye", level="standard")    # "turkiye"
normalizer.normalize("Türkiye", level="aggressive")  # "turkiye"

# Batch processing
texts = ["France", "Germany", "Italy"]
normalized = normalizer.normalize_batch(texts)  # ["france", "germany", "italy"]

# Edge cases (handled gracefully)
normalizer.normalize("")         # ""
normalizer.normalize("   ")      # ""
normalizer.normalize(None)       # ""

# Introspection
config = normalizer.get_level_config("standard")
print(config.remove_diacritics)  # True
```

## Performance

The normalization module is optimized for high-throughput entity resolution:

- **Caching**: 10,000-entry LRU cache for repeated queries
- **Speed**: < 0.001ms per cached normalization
- **Batch**: Efficient config reuse for multiple texts
- **Coverage**: 94% test coverage with performance benchmarks

### Performance Examples

```python
# Cached calls are 10-100x faster
normalizer.normalize("France")  # First call: ~0.01ms
normalizer.normalize("France")  # Cached: ~0.0001ms

# Batch processing is efficient
texts = ["France"] * 1000
normalizer.normalize_batch(texts)  # Config reused for all texts
```

## Design Principles

1. **Thin Orchestrator**: Wraps existing `utils.text` functions
2. **Preset Levels**: Simple API with sensible defaults
3. **Performance-First**: LRU caching from day one
4. **Graceful Degradation**: Handles edge cases without crashing
5. **Testable**: 19 comprehensive tests with 94% coverage

## Integration

The normalizer integrates with the matcher cascade:

| Matcher | Level | Rationale |
|---------|-------|-----------|
| ExactCodeMatcher | strict | Codes are case-sensitive |
| CanonicalNameMatcher | standard | Canonical names need normalization |
| AliasExactMatcher | standard | Aliases need diacritic/case handling |
| FuzzyMatchers | standard/aggressive | Depends on data quality |

## Future Enhancements

- **Transliteration**: Cyrillic→Latin, Arabic→Latin (deferred to Phase B+)
- **Custom levels**: User-defined normalization configs
- **Language hints**: Language-aware normalization rules
- **Normalization metadata**: Track applied transformations for debugging

## Testing

Run normalization tests:

```bash
# All normalization tests
uv run pytest tests/test_normalization.py -v

# Performance tests only
uv run pytest tests/test_normalization.py::TestPerformance -v

# With coverage
uv run pytest tests/test_normalization.py --cov=src/resolvekit/normalization
```

## Files

```
src/resolvekit/normalization/
├── __init__.py          # Exports TextNormalizer, NormalizationLevel
└── normalizer.py        # Implementation (40 SLOC, 94% coverage)
```
