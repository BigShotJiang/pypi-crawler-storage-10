# Disambiguation Module

## Purpose

The disambiguation module handles ambiguous queries where multiple entities are plausible matches, using context and semantic understanding to select the most likely entity.

## Components

### Core Components

1. **Ambiguity Detector** (`detector.py`)
   - Computes score margin between top candidates
   - Checks ambiguity registry for known ambiguous terms
   - Determines when to invoke semantic disambiguation

2. **Ambiguity Registry** (`registry.py`)
   - SQLite table of known ambiguous surface forms
   - Maps ambiguous terms to likely entity types and notes
   - Examples: "Georgia" → {country, state}, "Congo" → {COD, COG}

3. **Micro-Semantic Sidecar** (`semantic_sidecar.py`)
   - HNSW ANN index for semantic similarity search
   - Only stores embeddings for curated ambiguous aliases
   - Uses PQ/4-bit quantization for memory efficiency
   - Optional component (requires `resolver[semantic]`)

4. **Context Analyzer** (`context.py`)
   - Extracts disambiguation hints from context
   - Handles co-mentioned entities, parent regions, coordinates
   - Computes context-candidate compatibility scores

5. **Default Heuristics** (`heuristics.py`)
   - Non-semantic disambiguation rules
   - Examples: prefer countries over subdivisions by default
   - Global prominence scores, population-based ranking

### Key Files

- `ambiguity_model.py`: Data models for ambiguity metadata
- `encoder.py`: Optional tiny encoder (MiniLM-class, ~80MB)
- `sidecar_builder.py`: Tools to build ambiguity sidecar from registry

## Ambiguity Detection Logic

```python
# Compute margin between top 2 candidates
margin = score(top1) - score(top2)

# Trigger semantic if:
is_ambiguous = (
    margin < threshold  # Small margin (e.g., < 0.15)
    or query in ambiguity_registry  # Known ambiguous term
)

if is_ambiguous and semantic_available():
    # Re-rank using semantic similarity
    rerank_with_semantics(candidates, query_embedding)
else:
    # Use lexicon-only heuristics
    apply_default_heuristics(candidates)
```

## Design Principles

1. **Selective invocation**: Only use expensive semantic search when needed
2. **Explainable defaults**: Clear rules for non-semantic disambiguation
3. **Graceful degradation**: Works without semantic components
4. **User override**: Allow explicit disambiguation via parameters

## Implementation Priority

**Phase E** - Ambiguity subsystem
