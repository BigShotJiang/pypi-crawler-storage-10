# Extraction Module

## Purpose

The extraction module identifies and extracts entities from unstructured text (sentences, paragraphs, documents), resolving them to canonical entities.

## Components

### Core Components

1. **Text Extractor** (`extractor.py`)
   - Main extraction pipeline
   - Orchestrates NER and resolution
   - Returns entities with spans and confidence

2. **Dictionary Matcher** (`dictionary_matcher.py`)
   - Aho-Corasick or FlashText for fast dictionary matching
   - Matches known entity names and aliases in text
   - Efficient for large dictionaries

3. **NER Assistant** (`ner.py`)
   - Optional spaCy integration for named entity recognition
   - Helps identify entity boundaries
   - Filters false positives (common words)

4. **Context Extractor** (`context.py`)
   - Extract surrounding context for disambiguation
   - Co-mentioned entities, geographic hints
   - Sentence/paragraph boundaries

5. **Span Manager** (`spans.py`)
   - Handle overlapping and nested entities
   - Deduplication (same entity mentioned multiple times)
   - Link acronyms to full forms

### Filters and Validators

- `stoplist.py`: Common words that aren't entities ("March", "Reading")
- `pos_filter.py`: Part-of-speech filters to reduce false positives
- `confidence_thresholds.py`: Extraction-specific confidence tuning

## Extraction Pipeline

```python
from resolvekit.extraction import TextExtractor

extractor = TextExtractor(min_confidence=0.8)

text = """
The agreement was signed by representatives from France, Germany,
and Côte d'Ivoire. Regional coordination will be managed through
the West African Economic and Monetary Union (UEMOA) headquarters
in Burkina Faso.
"""

# Extract entities
entities = extractor.extract(text)

# Results
for entity in entities:
    print(f"{entity.text} [{entity.span}]")
    print(f"  → {entity.dcid} ({entity.type})")
    print(f"  Confidence: {entity.confidence}")
```

## Extracted Entity Structure

```python
@dataclass
class ExtractedEntity:
    """Entity extracted from text."""

    text: str                   # Original text span
    span: tuple[int, int]       # Character offsets (start, end)
    dcid: str                   # Resolved entity DCID
    canonical_name: str         # Canonical entity name
    entity_type: str            # Entity type (country, org, etc.)
    confidence: float           # Resolution confidence
    context: str | None         # Surrounding context
    method: str                 # Extraction method (dictionary, ner, etc.)
```

## Extraction Modes

### 1. Dictionary-First (Fast)

```python
# Use only dictionary matching
extractor = TextExtractor(mode="dictionary")
entities = extractor.extract(text)
```

- Fast: O(n) where n = text length
- High precision for known names
- May miss creative mentions

### 2. NER-Assisted (Accurate)

```python
# Use spaCy NER + dictionary
extractor = TextExtractor(mode="ner")
entities = extractor.extract(text)
```

- Better entity boundary detection
- Catches variations not in dictionary
- Slower, requires spaCy model

### 3. Hybrid (Recommended)

```python
# Dictionary first, NER for gaps
extractor = TextExtractor(mode="hybrid")
entities = extractor.extract(text)
```

- Best of both: fast + accurate
- Dictionary for common entities
- NER for rare/variant mentions

## Context-Aware Disambiguation

```python
text = "Georgia joined the UN in 1992."

# Without context: ambiguous
entities = extractor.extract(text, use_context=False)
# → Georgia (country) with confidence 0.6

# With context: disambiguated
entities = extractor.extract(text, use_context=True)
# → Georgia (country) with confidence 0.95 (UN membership hint)
```

Context signals:
- Co-mentioned entities (nearby countries suggest geography)
- Temporal hints (dates in EU/UN membership context)
- Acronym expansions (UEMOA → West African Union)
- Document topic (academic paper vs. news article)

## Handling Special Cases

### Overlapping/Nested Entities

```text
"Paris, France"
       ^^^^^^  → France (country)
 ^^^^^        → Paris (city)
```

Strategy: Return both with relationship noted

### Acronyms and Full Forms

```text
"West African Economic and Monetary Union (UEMOA)"
 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  → org/UEMOA (full form)
                                           ^^^^^^ → org/UEMOA (acronym)
```

Strategy: Link acronym to full form, return single entity

### False Positives

```text
"We will meet in March in Reading."
                 ^^^^^  → Month, not country
                       ^^^^^^^ → City, not event
```

Filtering:
- Stoplist (common words)
- POS tagging (proper nouns only)
- Capitalization checks
- Context validation

## Performance

### Dictionary Size vs. Speed

- 10K aliases: ~1ms per sentence
- 100K aliases: ~5ms per sentence
- 1M aliases: ~50ms per sentence

Use Aho-Corasick for efficient multi-pattern matching.

### Document Length

- Sentences (<100 words): <10ms
- Paragraphs (<500 words): <50ms
- Full documents (>5000 words): <1s

Batch processing recommended for large corpora.

## Design Principles

1. **Precision over recall**: Avoid false positives
2. **Context-aware**: Use surrounding text for disambiguation
3. **Configurable**: Adjustable confidence thresholds
4. **Efficient**: Handle large documents without timeouts

## Implementation Priority

**Phase F** - Entity extraction add-on
