# resolvekit Package Structure

This directory contains the main resolvekit package implementation.

## Module Overview

### Core Resolution Pipeline

1. **normalization/** - Text preprocessing and normalization
   - Unicode normalization (NFKC/NFKD)
   - Diacritic handling and case folding
   - Transliteration support

2. **matchers/** - Candidate generation cascade
   - Exact code matcher (ISO, DCID, etc.)
   - Canonical name matcher
   - Alias exact matcher
   - FTS matcher (SQLite FTS5)
   - Fuzzy matcher (bounded)
   - Semantic matcher (optional)

3. **disambiguation/** - Ambiguity resolution
   - Ambiguity detection
   - Semantic sidecar (HNSW)
   - Context analysis
   - Default heuristics

4. **constraints/** - KG and temporal validation
   - Type validation
   - Hierarchy validation
   - Temporal validity
   - Membership validation

5. **calibration/** - Confidence scoring
   - Feature extraction
   - Calibration models
   - Score fusion

### Data Management

6. **data/** - Data storage and access
   - SQLite database management
   - Schema definitions
   - Data models and loaders
   - Query builders

7. **overlays/** - Custom data extensions
   - Overlay management
   - Precedence handling
   - Overlay writers and validators

8. **builders/** - Data pack building
   - ETL pipelines
   - Pack builders
   - Calibration training
   - Quality assurance

### Interfaces

9. **api/** - Python API
   - Main Resolver class
   - Resolution operations
   - Code conversion
   - Hierarchy navigation

10. **cli/** - Command-line interface
    - CLI commands
    - Output formatters
    - Interactive prompts

### Additional Features

11. **extraction/** - Entity extraction from text
    - Dictionary matching
    - NER assistance
    - Context extraction

12. **utils/** - Shared utilities
    - Logging
    - Validation
    - Text utilities
    - Caching

## Key Files

- **types.py** - Type definitions and data classes
- **constants.py** - Constants and configuration defaults
- **__init__.py** - Package initialization and exports

## Implementation Status

Current status: **Phase A - Core Resolver** (scaffolding complete)

See `implementation-plan.md` in the repository root for the full implementation roadmap.

## Development Workflow

1. Each module has its own README explaining its purpose and components
2. Start with Phase A modules: normalization, matchers, data, calibration, api, cli
3. Follow test-driven development (write tests first)
4. Maintain type hints and docstrings for all public APIs
5. Run linting and type checking before commits

## Quick Start for Developers

```bash
# Install dependencies
uv sync

# Run tests (when available)
uv run pytest

# Run linting
uv run ruff check src/resolvekit

# Run type checking
uv run mypy src/resolvekit

# Run CLI
uv run resolvekit
```

## Architecture Principles

1. **Bounded cascade**: Fail-fast with early matchers, limit expensive operations
2. **Offline-first**: Zero runtime network dependencies
3. **Explainable**: Return confidence scores and alternatives with reasoning
4. **Extensible**: Support overlays at data, config, and code levels
5. **Temporal-aware**: Handle time-varying data from day one
6. **Type-safe**: Full type annotations throughout

## Next Steps

See individual module READMEs for implementation details and priorities.
