# CLI Module

## Purpose

The CLI module provides a command-line interface for interactive entity resolution, batch processing, and data pack management.

## Components

### Command Modules

1. **Main CLI** (`main.py`)
   - Entry point for CLI application
   - Uses `click` or `typer` for argument parsing
   - Global options and configuration

2. **Query Command** (`query.py`)
   - Single entity resolution from command line
   - Interactive disambiguation prompts
   - Human-readable output with colors

3. **Convert Command** (`convert.py`)
   - Code system conversion
   - Supports single codes or batch files

4. **Batch Command** (`batch.py`)
   - Batch processing of CSV/JSON files
   - Progress bars for large files
   - Error reporting and partial results

5. **Extract Command** (`extract.py`)
   - Entity extraction from text files
   - Supports various input formats
   - (Phase F)

6. **Info Command** (`info.py`)
   - Display detailed entity information
   - Show codes, hierarchy, memberships

7. **Members Command** (`members.py`)
   - List group members
   - Temporal support (as_of date)

8. **Update Command** (`update.py`)
   - Check for data pack updates
   - Download and install new versions

9. **Version Command** (`version.py`)
   - Show tool and data pack versions
   - Component information

### Output Formatters

- `formatters.py`: Output formatting (table, JSON, CSV)
- `colors.py`: Terminal color support
- `progress.py`: Progress bars for long operations

## CLI Commands

### Query

```bash
# Simple query
resolvekit query "Georgia"

# Output:
# ⚠️  Ambiguous input. Top matches:
#
# 1. Georgia (Country) [dcid: country/GEO]
#    - Confidence: 0.60
#    - Codes: ISO2=GE, ISO3=GEO, M49=268
#
# 2. Georgia (US State) [dcid: geoId/13]
#    - Confidence: 0.40
#    - Codes: FIPS=13

# With context
resolvekit query "Georgia" --context "Tbilisi"

# With constraints
resolvekit query "Paris" --entity-type country
resolvekit query "Ontario" --parent country/CAN

# JSON output
resolvekit query "France" --format json

# With explanation
resolvekit query "Türkiye" --explain
```

### Convert

```bash
# Single code conversion
resolvekit convert FRA --from iso3 --to dcid
# Output: country/FRA

# Get all codes
resolvekit convert country/FRA --from dcid
# Output:
# iso2: FR
# iso3: FRA
# m49: 250
# nuts: FR
# wikidata: Q142

# Batch file
resolvekit convert codes.csv --from iso3 --to dcid --output results.csv
```

### Batch

```bash
# Process CSV file
resolvekit batch input.csv \
    --column location \
    --output enriched.csv \
    --min-confidence 0.8

# With additional context columns
resolvekit batch data.csv \
    --column country_name \
    --context-column region \
    --output results.csv

# JSON input/output
resolvekit batch input.json --format json --output results.json
```

### Info

```bash
# Entity details
resolvekit info country/FRA

# Output:
# Entity: France
# DCID: country/FRA
# Type: country
# Codes:
#   ISO2: FR
#   ISO3: FRA
#   M49: 250
# Parent: None
# Children (ADM1): 18 regions
# Memberships: EU, OECD, G7, G20, ...
```

### Members

```bash
# Current members
resolvekit members EU

# Historical members
resolvekit members EU --as-of 2004-01-01

# Output as list of DCIDs
resolvekit members OECD --format dcids
```

### Update

```bash
# Check for updates
resolvekit update --check

# Download and install latest
resolvekit update --install

# List available versions
resolvekit update --list
```

### Version

```bash
# Show versions
resolvekit version

# Output:
# resolvekit: 0.1.0
# Data pack: 1.2.0 (2025-10-20)
# Python: 3.13
```

## Output Formats

### Human-readable (default)
- Colored terminal output
- Formatted tables
- Progress indicators

### JSON
- Machine-readable
- Full result structure
- Suitable for piping

### CSV
- Batch results
- Compatible with spreadsheets
- Configurable columns

## Design Principles

1. **Unix-friendly**: Composable with pipes, appropriate exit codes
2. **Interactive**: Clear prompts for ambiguous cases
3. **Informative**: Helpful error messages with suggestions
4. **Fast feedback**: Show progress for long operations

## Implementation Priority

**Phase A** - Core resolver (query, batch, version)
**Phase B** - Code conversion (convert, info, members)
**Phase D** - Package updates (update)
**Phase F** - Entity extraction (extract)
