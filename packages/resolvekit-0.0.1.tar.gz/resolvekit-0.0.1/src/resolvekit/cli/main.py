"""CLI entry point for resolvekit."""

import sys


def cli() -> None:
    """Main CLI entry point."""
    print("resolvekit CLI - Coming soon!")
    print()
    print("Available commands (to be implemented):")
    print("  resolvekit query <text>         - Resolve entity from text")
    print("  resolvekit convert <code>       - Convert between code systems")
    print("  resolvekit batch <file>         - Batch process CSV/JSON file")
    print("  resolvekit info <dcid>          - Show entity information")
    print("  resolvekit members <group>      - List group members")
    print("  resolvekit update               - Update data packs")
    print("  resolvekit version              - Show version information")
    sys.exit(0)
