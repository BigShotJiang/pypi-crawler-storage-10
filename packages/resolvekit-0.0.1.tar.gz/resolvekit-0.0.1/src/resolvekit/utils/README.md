# Utils Module

## Purpose

The utils module contains shared utilities, helpers, and common functionality used across other modules.

## Components

### Core Utilities

1. **Logging** (`logging.py`)
   - Structured logging configuration
   - Log levels and formatters
   - Privacy-aware logging (no query content by default)

2. **Validation** (`validation.py`)
   - Input validation utilities
   - Schema validation
   - Error message generation

3. **Text Utils** (`text.py`)
   - Common text processing functions
   - Unicode utilities
   - String similarity metrics

4. **Date Utils** (`dates.py`)
   - Date parsing and formatting
   - Temporal validity checks
   - ISO date utilities

5. **File Utils** (`files.py`)
   - File I/O helpers
   - Path management
   - Checksum computation

6. **Cache** (`cache.py`)
   - LRU cache implementations
   - Cache warming strategies
   - Cache invalidation

### Data Structures

- `priority_queue.py`: Priority queue for candidate ranking
- `trie.py`: Trie for prefix matching
- `bloom_filter.py`: Bloom filter for quick existence checks

### Error Classes

```python
# errors.py

class ResolvekitError(Exception):
    """Base exception for resolvekit."""
    pass

class ConfigError(ResolvekitError):
    """Configuration error."""
    pass

class DataPackError(ResolvekitError):
    """Data pack error."""
    pass

class ResolutionError(ResolvekitError):
    """Resolution error."""
    pass

class ValidationError(ResolvekitError):
    """Validation error."""
    pass
```

### Metrics and Performance

- `metrics.py`: Performance metrics collection
- `profiling.py`: Profiling utilities
- `benchmarks.py`: Benchmark utilities

### Testing Utilities

- `test_helpers.py`: Test fixtures and helpers
- `mock_data.py`: Mock data generators
- `assertions.py`: Custom assertions

## Common Patterns

### Logging

```python
from resolvekit.utils.logging import get_logger

logger = get_logger(__name__)

logger.info("Resolver initialized", extra={
    "data_pack_version": "1.2.0",
    "overlays": 2
})

logger.debug("Candidate generation", extra={
    "query": "[REDACTED]",  # Privacy
    "candidates_found": 5,
    "stage": "fts"
})
```

### Validation

```python
from resolvekit.utils.validation import validate_dcid, validate_date

# Validate DCID format
if not validate_dcid(dcid):
    raise ValidationError(f"Invalid DCID format: {dcid}")

# Validate date
try:
    date_obj = validate_date(date_str)
except ValidationError as e:
    logger.error(f"Invalid date: {e}")
```

### Caching

```python
from resolvekit.utils.cache import lru_cache

@lru_cache(maxsize=10000)
def expensive_lookup(key: str) -> Entity | None:
    """Cached entity lookup."""
    return database.get_entity(key)
```

### Text Similarity

```python
from resolvekit.utils.text import (
    edit_distance,
    trigram_similarity,
    jaccard_similarity
)

# Compute similarities
edit_dist = edit_distance("france", "frence")  # 1
trigram_sim = trigram_similarity("germany", "germeny")  # 0.85
jaccard_sim = jaccard_similarity("turkey", "türkiye")  # 0.71
```

### Date Handling

```python
from resolvekit.utils.dates import parse_date, is_valid_at
from datetime import date

# Parse various date formats
d = parse_date("2025-01-01")  # ISO
d = parse_date("2025-1-1")    # Flexible
d = parse_date("01/01/2025")  # US format

# Check validity
entity = get_entity("country/YUG")  # Yugoslavia
is_valid = is_valid_at(entity, date(1990, 1, 1))  # True
is_valid = is_valid_at(entity, date(2000, 1, 1))  # False (dissolved)
```

### Checksums

```python
from resolvekit.utils.files import compute_checksum, verify_checksum

# Compute SHA-256 checksum
checksum = compute_checksum("base.sqlite")

# Verify checksum
if not verify_checksum("base.sqlite", expected_checksum):
    raise DataPackError("Checksum mismatch - data may be corrupted")
```

## Design Principles

1. **DRY**: Shared code lives here, not duplicated
2. **Type-safe**: Full type annotations
3. **Tested**: High test coverage for utilities
4. **Documented**: Clear docstrings with examples

## Implementation Priority

**Phase A** - Core utilities (logging, validation, text, dates)
**Ongoing** - Add utilities as needed by other modules
