"""Caching utilities for resolvekit.

This module provides thin wrappers and utilities around Python's standard
library caching mechanisms. We use functools.lru_cache for function memoization
and simple dicts for data caching.
"""

from collections.abc import Callable, Hashable
from functools import lru_cache as _stdlib_lru_cache
from typing import Any

# Re-export standard library lru_cache
lru_cache = _stdlib_lru_cache

__all__ = ["DictCache", "lru_cache", "warm_cache"]


class DictCache:
    """
    Simple dictionary-based cache for pre-loaded data.

    This is just a thin wrapper around a dict for semantic clarity
    when caching entities, codes, etc. For most cases, a plain dict is fine.

    Use this when:
    - You need to cache a known set of data at startup
    - You want semantic distinction between "cache" and "dict"
    - You need simple get/set operations with a clear intent
    """

    def __init__(self, name: str = "cache"):
        """
        Initialize dictionary cache.

        Args:
            name: Cache name for identification
        """
        self.name = name
        self._data: dict[Hashable, Any] = {}

    def load(self, data: dict[Hashable, Any]) -> None:
        """
        Load data into cache.

        Args:
            data: Dictionary of data to cache
        """
        self._data = data.copy()

    def get(self, key: Hashable, default: Any = None) -> Any:
        """Get value from cache."""
        return self._data.get(key, default)

    def get_many(self, keys: list[Hashable]) -> dict[Hashable, Any]:
        """Get multiple values from cache."""
        return {key: self._data[key] for key in keys if key in self._data}

    def set(self, key: Hashable, value: Any) -> None:
        """Set value in cache."""
        self._data[key] = value

    def update(self, data: dict[Hashable, Any]) -> None:
        """Update cache with new data."""
        self._data.update(data)

    def clear(self) -> None:
        """Clear all cached data."""
        self._data.clear()

    def __contains__(self, key: Hashable) -> bool:
        """Check if key is in cache."""
        return key in self._data

    def __len__(self) -> int:
        """Get number of cached items."""
        return len(self._data)

    def __getitem__(self, key: Hashable) -> Any:
        """Get item using bracket notation."""
        return self._data[key]

    def __setitem__(self, key: Hashable, value: Any) -> None:
        """Set item using bracket notation."""
        self._data[key] = value


def warm_cache(
    cache: DictCache | dict,
    loader: Callable[[], dict[Hashable, Any]],
) -> None:
    """
    Warm a cache by loading data.

    Args:
        cache: Cache to warm (DictCache or plain dict)
        loader: Function that returns data dictionary

    Example:
        >>> entity_cache = {}
        >>> warm_cache(entity_cache, lambda: load_entities_from_db())
    """
    data = loader()

    if isinstance(cache, DictCache):
        cache.load(data)
    elif isinstance(cache, dict):
        cache.update(data)
    else:
        raise TypeError(f"Unsupported cache type: {type(cache)}")
