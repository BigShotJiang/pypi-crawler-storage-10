"""Validation utilities for resolvekit."""

import re
from datetime import date
from typing import Any

from resolvekit.constants import CODE_SYSTEMS
from resolvekit.types import AliasType, EntityType
from resolvekit.utils.errors import CodeFormatError, ValidationError


def validate_dcid(dcid: str) -> bool:
    """
    Validate DCID format.

    Args:
        dcid: DCID to validate

    Returns:
        True if valid, False otherwise

    Examples:
        >>> validate_dcid("country/USA")
        True
        >>> validate_dcid("invalid")
        False
    """
    if not dcid or not isinstance(dcid, str):
        return False

    pattern = CODE_SYSTEMS["dcid"]["format"]
    return bool(re.match(pattern, dcid))


def validate_code_format(code: str, code_system: str, strict: bool = True) -> bool:
    """
    Validate code format for a given code system.

    Args:
        code: Code to validate
        code_system: Code system (iso2, iso3, m49, etc.)
        strict: If True, raise exception on invalid format

    Returns:
        True if valid

    Raises:
        CodeFormatError: If strict=True and code is invalid
    """
    if not code or not isinstance(code, str):
        if strict:
            raise CodeFormatError(str(code), code_system, "non-empty string")
        return False

    if code_system not in CODE_SYSTEMS:
        if strict:
            raise ValidationError(
                f"Unknown code system: {code_system}",
                details={"code_system": code_system},
            )
        return False

    pattern = CODE_SYSTEMS[code_system]["format"]
    is_valid = bool(re.match(pattern, code))

    if not is_valid and strict:
        example = CODE_SYSTEMS[code_system]["example"]
        raise CodeFormatError(code, code_system, f"{pattern} (e.g., {example})")

    return is_valid


def validate_iso2(code: str, strict: bool = True) -> bool:
    """Validate ISO 3166-1 alpha-2 code."""
    return validate_code_format(code, "iso2", strict=strict)


def validate_iso3(code: str, strict: bool = True) -> bool:
    """Validate ISO 3166-1 alpha-3 code."""
    return validate_code_format(code, "iso3", strict=strict)


def validate_iso_numeric(code: str, strict: bool = True) -> bool:
    """Validate ISO 3166-1 numeric code."""
    return validate_code_format(code, "iso_numeric", strict=strict)


def validate_m49(code: str, strict: bool = True) -> bool:
    """Validate UN M49 code."""
    return validate_code_format(code, "m49", strict=strict)


def validate_wikidata_qid(qid: str, strict: bool = True) -> bool:
    """Validate Wikidata QID."""
    return validate_code_format(qid, "wikidata", strict=strict)


def validate_confidence(confidence: float) -> bool:
    """
    Validate confidence score.

    Args:
        confidence: Confidence score

    Returns:
        True if valid (0.0 <= confidence <= 1.0)
    """
    if not isinstance(confidence, int | float):
        return False
    return 0.0 <= confidence <= 1.0


def validate_date_string(date_str: str) -> bool:
    """
    Validate ISO date string format.

    Args:
        date_str: Date string in ISO format (YYYY-MM-DD)

    Returns:
        True if valid

    Examples:
        >>> validate_date_string("2025-01-01")
        True
        >>> validate_date_string("2025-1-1")
        False
    """
    if not date_str or not isinstance(date_str, str):
        return False

    pattern = r"^\d{4}-\d{2}-\d{2}$"
    if not re.match(pattern, date_str):
        return False

    # Try parsing to ensure it's a valid date
    try:
        year, month, day = map(int, date_str.split("-"))
        date(year, month, day)
        return True
    except ValueError:
        return False


def validate_temporal_range(
    valid_from: date | None,
    valid_until: date | None,
    strict: bool = True,
) -> bool:
    """
    Validate temporal validity range.

    Args:
        valid_from: Start date (inclusive)
        valid_until: End date (exclusive)
        strict: If True, raise exception on invalid range

    Returns:
        True if valid

    Raises:
        ValidationError: If strict=True and range is invalid
    """
    if valid_from is None and valid_until is None:
        return True

    if valid_from is not None and valid_until is not None and valid_from >= valid_until:
        if strict:
            raise ValidationError(
                f"Invalid temporal range: valid_from ({valid_from}) "
                f"must be before valid_until ({valid_until})",
                details={"valid_from": valid_from, "valid_until": valid_until},
            )
        return False

    return True


def validate_entity_type(entity_type: str) -> bool:
    """
    Validate entity type against EntityType enum values.

    Args:
        entity_type: Entity type to validate

    Returns:
        True if valid
    """
    return entity_type in {t.value for t in EntityType}


def validate_alias_type(alias_type: str) -> bool:
    """
    Validate alias type against AliasType enum values.

    Args:
        alias_type: Alias type to validate

    Returns:
        True if valid
    """
    return alias_type in {t.value for t in AliasType}


def validate_language_code(lang_code: str) -> bool:
    """
    Validate ISO 639-1 language code (basic validation).

    Args:
        lang_code: Language code (e.g., "en", "fr")

    Returns:
        True if format is valid (2 lowercase letters)
    """
    if not lang_code or not isinstance(lang_code, str):
        return False
    return bool(re.match(r"^[a-z]{2}$", lang_code))


def validate_non_empty_string(value: Any, field_name: str = "value") -> str:
    """
    Validate that value is a non-empty string.

    Args:
        value: Value to validate
        field_name: Field name for error message

    Returns:
        The validated string

    Raises:
        ValidationError: If value is not a non-empty string
    """
    if not isinstance(value, str):
        raise ValidationError(
            f"{field_name} must be a string",
            details={"field": field_name, "type": type(value).__name__},
        )

    if not value.strip():
        raise ValidationError(
            f"{field_name} must not be empty",
            details={"field": field_name},
        )

    return value


def validate_precedence(precedence: int) -> bool:
    """
    Validate overlay precedence value.

    Args:
        precedence: Precedence value (0-999)

    Returns:
        True if valid
    """
    return isinstance(precedence, int) and 0 <= precedence <= 999


def sanitize_query(query: str) -> str:
    """
    Sanitize query string.

    Args:
        query: Raw query string

    Returns:
        Sanitized query string
    """
    if not isinstance(query, str):
        return ""

    # Strip whitespace
    query = query.strip()

    # Collapse multiple spaces
    query = re.sub(r"\s+", " ", query)

    # Remove control characters
    query = "".join(char for char in query if ord(char) >= 32 or char in "\n\t")

    return query


def validate_schema_version(version: str) -> bool:
    """
    Validate semantic version string.

    Args:
        version: Version string (e.g., "1.2.3")

    Returns:
        True if valid semantic version
    """
    if not version or not isinstance(version, str):
        return False

    pattern = r"^\d+\.\d+\.\d+(-[a-zA-Z0-9.-]+)?(\+[a-zA-Z0-9.-]+)?$"
    return bool(re.match(pattern, version))
