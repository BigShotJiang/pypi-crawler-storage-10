"""Logging utilities for resolvekit."""

import json
import logging
import sys
from pathlib import Path
from typing import Any

from resolvekit.constants import LOG_DATE_FORMAT, LOG_FORMAT


class StructuredFormatter(logging.Formatter):
    """JSON structured log formatter."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_data = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add extra fields
        if hasattr(record, "extra"):
            log_data.update(record.extra)

        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data)


class PrivacyFilter(logging.Filter):
    """Filter to prevent logging sensitive query content by default."""

    def __init__(self, redact_queries: bool = True):
        """Initialize privacy filter."""
        super().__init__()
        self.redact_queries = redact_queries

    def filter(self, record: logging.LogRecord) -> bool:
        """Redact query content if privacy is enabled."""
        if self.redact_queries and hasattr(record, "query"):
            record.query = "[REDACTED]"
        return True


def setup_logging(
    level: str | int = logging.INFO,
    format_type: str = "human",
    log_file: Path | str | None = None,
    redact_queries: bool = True,
) -> None:
    """
    Set up logging configuration.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        format_type: "human" for human-readable, "json" for structured JSON
        log_file: Optional file path for logging to file
        redact_queries: Whether to redact query content (default: True for privacy)
    """
    # Convert string level to int
    if isinstance(level, str):
        level = getattr(logging, level.upper())

    # Create handlers
    handlers: list[logging.Handler] = []

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    if format_type == "json":
        console_handler.setFormatter(StructuredFormatter(datefmt=LOG_DATE_FORMAT))
    else:
        console_handler.setFormatter(logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT))

    handlers.append(console_handler)

    # File handler if specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(level)
        if format_type == "json":
            file_handler.setFormatter(StructuredFormatter(datefmt=LOG_DATE_FORMAT))
        else:
            file_handler.setFormatter(logging.Formatter(LOG_FORMAT, LOG_DATE_FORMAT))
        handlers.append(file_handler)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Add new handlers
    for handler in handlers:
        root_logger.addHandler(handler)

    # Add privacy filter
    privacy_filter = PrivacyFilter(redact_queries=redact_queries)
    for handler in handlers:
        handler.addFilter(privacy_filter)


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Logger instance
    """
    return logging.getLogger(name)


def log_performance(
    logger: logging.Logger,
    operation: str,
    duration_ms: float,
    extra: dict[str, Any] | None = None,
) -> None:
    """
    Log performance metrics.

    Args:
        logger: Logger instance
        operation: Operation name
        duration_ms: Duration in milliseconds
        extra: Additional context to log
    """
    log_data = {
        "operation": operation,
        "duration_ms": round(duration_ms, 2),
    }
    if extra:
        log_data.update(extra)

    logger.info(f"Performance: {operation} took {duration_ms:.2f}ms", extra=log_data)


def log_resolution(
    logger: logging.Logger,
    query: str,
    result_dcid: str | None,
    confidence: float | None,
    num_candidates: int,
    duration_ms: float,
    redact_query: bool = True,
) -> None:
    """
    Log resolution operation.

    Args:
        logger: Logger instance
        query: Query string (will be redacted if redact_query=True)
        result_dcid: Resolved entity DCID (None if no match)
        confidence: Confidence score
        num_candidates: Number of candidates found
        duration_ms: Resolution duration in milliseconds
        redact_query: Whether to redact query content
    """
    log_data = {
        "query": "[REDACTED]" if redact_query else query,
        "result_dcid": result_dcid,
        "confidence": round(confidence, 3) if confidence else None,
        "num_candidates": num_candidates,
        "duration_ms": round(duration_ms, 2),
        "success": result_dcid is not None,
    }

    if result_dcid:
        # Format confidence if present, otherwise indicate it's missing
        conf_str = f"{confidence:.3f}" if confidence is not None else "unknown"
        logger.info(
            f"Resolved query to {result_dcid} (confidence={conf_str})",
            extra=log_data,
        )
    else:
        logger.warning("No match found for query", extra=log_data)


def log_stage(
    logger: logging.Logger,
    stage: str,
    candidates_before: int,
    candidates_after: int,
    duration_ms: float | None = None,
) -> None:
    """
    Log resolution stage.

    Args:
        logger: Logger instance
        stage: Stage name
        candidates_before: Number of candidates before stage
        candidates_after: Number of candidates after stage
        duration_ms: Stage duration in milliseconds
    """
    log_data = {
        "stage": stage,
        "candidates_before": candidates_before,
        "candidates_after": candidates_after,
        "filtered": candidates_before - candidates_after,
    }
    if duration_ms is not None:
        log_data["duration_ms"] = round(duration_ms, 2)

    logger.debug(
        f"Stage '{stage}': {candidates_before} → {candidates_after} candidates",
        extra=log_data,
    )
