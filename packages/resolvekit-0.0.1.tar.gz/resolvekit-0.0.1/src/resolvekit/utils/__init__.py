"""Utilities module for resolvekit.

For most utilities, import directly from submodules:
    from resolvekit.utils.text import normalize_unicode
    from resolvekit.utils.dates import parse_date
    from resolvekit.utils.validation import validate_dcid

This module only re-exports commonly used items for convenience.
"""

# Re-export error classes (used throughout codebase)
from resolvekit.utils.errors import (
    AmbiguousQueryError,
    CalibrationError,
    ChecksumMismatchError,
    CodeFormatError,
    ConfigError,
    DatabaseError,
    DataPackError,
    EntityNotFoundError,
    ExtractionError,
    HierarchyError,
    IncompatibleVersionError,
    ResolvekitError,
    OverlayError,
    ResolutionError,
    TemporalValidityError,
    ValidationError,
)

__all__ = [
    "AmbiguousQueryError",
    "CalibrationError",
    "ChecksumMismatchError",
    "CodeFormatError",
    "ConfigError",
    "DataPackError",
    "DatabaseError",
    "EntityNotFoundError",
    "ExtractionError",
    "HierarchyError",
    "IncompatibleVersionError",
    "ResolvekitError",
    "OverlayError",
    "ResolutionError",
    "TemporalValidityError",
    "ValidationError",
]
