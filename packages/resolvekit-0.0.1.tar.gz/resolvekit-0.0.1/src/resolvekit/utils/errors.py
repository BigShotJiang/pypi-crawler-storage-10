"""Error classes for resolvekit."""


class ResolvekitError(Exception):
    """Base exception for all resolvekit errors."""

    def __init__(self, message: str, details: dict | None = None):
        """Initialize error with message and optional details."""
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def __str__(self) -> str:
        """String representation of error."""
        if self.details:
            details_str = ", ".join(f"{k}={v}" for k, v in self.details.items())
            return f"{self.message} ({details_str})"
        return self.message


class ConfigError(ResolvekitError):
    """Configuration error."""

    pass


class DataPackError(ResolvekitError):
    """Data pack error (corrupt, missing, incompatible)."""

    pass


class ResolutionError(ResolvekitError):
    """Resolution error."""

    pass


class ValidationError(ResolvekitError):
    """Validation error."""

    pass


class OverlayError(ResolvekitError):
    """Overlay error."""

    pass


class DatabaseError(ResolvekitError):
    """Database error."""

    pass


class CalibrationError(ResolvekitError):
    """Calibration error."""

    pass


class ExtractionError(ResolvekitError):
    """Entity extraction error."""

    pass


class CodeFormatError(ValidationError):
    """Code format validation error."""

    def __init__(self, code: str, code_system: str, expected_format: str):
        """Initialize code format error."""
        super().__init__(
            f"Invalid {code_system} code format: '{code}'. Expected format: {expected_format}",
            details={"code": code, "system": code_system, "format": expected_format},
        )


class EntityNotFoundError(ResolutionError):
    """Entity not found error."""

    def __init__(self, query: str, min_confidence: float | None = None):
        """Initialize entity not found error."""
        msg = f"No entity found for query: '{query}'"
        if min_confidence:
            msg += f" (min_confidence={min_confidence})"
        super().__init__(
            msg, details={"query": query, "min_confidence": min_confidence}
        )


class AmbiguousQueryError(ResolutionError):
    """Ambiguous query error when strict mode is enabled."""

    def __init__(self, query: str, candidates: list[str]):
        """Initialize ambiguous query error."""
        super().__init__(
            f"Ambiguous query: '{query}'. Multiple candidates: {', '.join(candidates[:5])}",
            details={"query": query, "num_candidates": len(candidates)},
        )


class TemporalValidityError(ValidationError):
    """Temporal validity error."""

    def __init__(self, entity: str, date: str, reason: str):
        """Initialize temporal validity error."""
        super().__init__(
            f"Entity '{entity}' not valid at date '{date}': {reason}",
            details={"entity": entity, "date": date, "reason": reason},
        )


class HierarchyError(ValidationError):
    """Hierarchy validation error."""

    def __init__(self, child: str, parent: str, reason: str):
        """Initialize hierarchy error."""
        super().__init__(
            f"Invalid hierarchy: '{child}' not a child of '{parent}': {reason}",
            details={"child": child, "parent": parent, "reason": reason},
        )


class ChecksumMismatchError(DataPackError):
    """Checksum mismatch error."""

    def __init__(self, file_path: str, expected: str, actual: str):
        """Initialize checksum mismatch error."""
        super().__init__(
            f"Checksum mismatch for '{file_path}'. Expected: {expected[:16]}..., Got: {actual[:16]}...",
            details={"file": file_path, "expected": expected, "actual": actual},
        )


class IncompatibleVersionError(DataPackError):
    """Incompatible version error."""

    def __init__(self, component: str, required: str, found: str):
        """Initialize incompatible version error."""
        super().__init__(
            f"Incompatible {component} version. Required: {required}, Found: {found}",
            details={"component": component, "required": required, "found": found},
        )
