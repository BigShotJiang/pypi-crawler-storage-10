"""Configuration management for resolvekit using Pydantic Settings."""

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ResolvekitConfig(BaseSettings):
    """
    Configuration for resolvekit resolver.

    This uses Pydantic Settings to read configuration from:
    1. Environment variables (prefixed with RESOLVEKIT_)
    2. .env file (if present)
    3. Default values

    Example:
        # Set via environment
        export RESOLVEKIT_DATA_DIR="/path/to/data"
        export RESOLVEKIT_MIN_CONFIDENCE=0.8

        # Or in .env file
        RESOLVEKIT_DATA_DIR=/path/to/data
        RESOLVEKIT_MIN_CONFIDENCE=0.8

        # Use in code
        config = ResolvekitConfig()
        print(config.data_dir)  # Path('/path/to/data')
    """

    model_config = SettingsConfigDict(
        env_prefix="RESOLVEKIT_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Paths
    data_dir: Path = Field(
        default=Path.home() / ".resolvekit" / "data",
        description="Directory containing data packs",
    )
    cache_dir: Path = Field(
        default=Path.home() / ".resolvekit" / "cache",
        description="Cache directory",
    )

    # Resolution settings
    min_confidence: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum confidence threshold for matches",
    )
    max_candidates: int = Field(
        default=50,
        gt=0,
        le=1000,
        description="Maximum number of candidates to consider",
    )
    max_alternates: int = Field(
        default=5,
        gt=0,
        le=100,
        description="Maximum number of alternative matches to return",
    )

    # FTS settings
    fts_top_k: int = Field(
        default=50,
        gt=0,
        le=1000,
        description="Top K results from FTS",
    )
    fuzzy_top_k: int = Field(
        default=12,
        gt=0,
        le=100,
        description="Top K results after fuzzy matching",
    )

    # Ambiguity detection
    margin_threshold: float = Field(
        default=0.15,
        ge=0.0,
        le=1.0,
        description="Score margin threshold for ambiguity detection",
    )

    # Logging
    log_level: str = Field(
        default="INFO",
        pattern=r"^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$",
        description="Logging level",
    )
    log_format: str = Field(
        default="human",
        pattern=r"^(human|json)$",
        description="Log format (human or json)",
    )
    redact_queries: bool = Field(
        default=True,
        description="Redact query content in logs for privacy",
    )

    # Performance
    batch_size: int = Field(
        default=1000,
        gt=0,
        le=100000,
        description="Batch size for batch processing",
    )
    num_workers: int = Field(
        default=4,
        gt=0,
        le=64,
        description="Number of worker processes for parallel processing",
    )

    def ensure_dirs(self) -> None:
        """Create data and cache directories if they don't exist."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)


# Global config instance (can be overridden)
config = ResolvekitConfig()
