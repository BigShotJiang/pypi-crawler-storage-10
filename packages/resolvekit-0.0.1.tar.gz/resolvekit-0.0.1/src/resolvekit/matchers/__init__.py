"""Matcher cascade module for entity resolution."""

from typing import TYPE_CHECKING

# Lazy imports to avoid circular dependency with data.code_repository
# The code_repository needs code_validators, but if we eagerly import
# cascade/exact_code here, they will try to import code_repository
if TYPE_CHECKING:
    from resolvekit.matchers.alias_exact import AliasExactMatcher
    from resolvekit.matchers.canonical_name import CanonicalNameMatcher
    from resolvekit.matchers.cascade import MatcherCascade
    from resolvekit.matchers.exact_code import ExactCodeMatcher
    from resolvekit.matchers.fts_matcher import FTSMatcher
    from resolvekit.matchers.fuzzy_matcher import FuzzyMatcher

# These are safe to import eagerly as they don't depend on data layer
from resolvekit.matchers.code_validators import CODE_VALIDATORS, get_validator
from resolvekit.matchers.priorities import InferencePriority
from resolvekit.matchers.protocols import CodeValidatorProtocol, MatcherProtocol
from resolvekit.types import Candidate, MatchContext

__all__ = [
    "CODE_VALIDATORS",
    "AliasExactMatcher",
    "Candidate",
    "CanonicalNameMatcher",
    "CodeValidatorProtocol",
    "ExactCodeMatcher",
    "FTSMatcher",
    "FuzzyMatcher",
    "InferencePriority",
    "MatchContext",
    "MatcherCascade",
    "MatcherProtocol",
    "get_validator",
]


def __getattr__(name: str) -> object:
    """Lazy load matcher classes to avoid circular imports."""
    if name == "AliasExactMatcher":
        from resolvekit.matchers.alias_exact import AliasExactMatcher

        return AliasExactMatcher
    elif name == "CanonicalNameMatcher":
        from resolvekit.matchers.canonical_name import CanonicalNameMatcher

        return CanonicalNameMatcher
    elif name == "MatcherCascade":
        from resolvekit.matchers.cascade import MatcherCascade

        return MatcherCascade
    elif name == "ExactCodeMatcher":
        from resolvekit.matchers.exact_code import ExactCodeMatcher

        return ExactCodeMatcher
    elif name == "FTSMatcher":
        from resolvekit.matchers.fts_matcher import FTSMatcher

        return FTSMatcher
    elif name == "FuzzyMatcher":
        from resolvekit.matchers.fuzzy_matcher import FuzzyMatcher

        return FuzzyMatcher
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
