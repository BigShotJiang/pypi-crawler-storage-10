"""FTS matcher using SQLite FTS5 for text search."""

from resolvekit.data.alias_repository import AliasRepository
from resolvekit.types import Candidate, MatchContext, MatcherType


class FTSMatcher:
    """
    Full-text search using SQLite FTS5.

    Tier 3 matcher: Returns top-K ranked candidates.

    Uses FTS5 BM25 ranking with LIMIT pushed to SQL for performance.
    """

    def __init__(self, alias_repo: AliasRepository):
        """
        Initialize matcher.

        Args:
            alias_repo: Alias repository for FTS queries
        """
        self.alias_repo = alias_repo

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 50,
        context: MatchContext | None = None,
    ) -> list[Candidate]:
        """
        FTS5 BM25 ranking with LIMIT pushed to SQL.

        Performance:
        - LIMIT in SQL (not Python filtering)
        - UNION ALL for overlays
        - Returns top-K candidates

        Args:
            query: Original query string (unused)
            normalized_query: Normalized query string
            limit: Maximum candidates to return (default 50 for Tier 3)
            context: Optional filtering context

        Returns:
            List of candidates ordered by FTS score (descending)
        """
        # FTS query with limit
        matches = self.alias_repo.search_fts(
            query=normalized_query, limit=limit, context=context
        )

        if not matches:
            return []

        # Convert to candidates
        candidates = []
        for entity, bm25_score, rank in matches:
            # Normalize BM25 score to 0-1 range
            # FTS rank is relative, use inverse rank as approximation
            normalized_score = self._normalize_bm25(bm25_score, rank, len(matches))

            candidates.append(
                Candidate(
                    entity=entity,
                    score=normalized_score,
                    matcher_type=MatcherType.FTS,
                    features={"fts_score": bm25_score, "fts_rank": rank},
                    matched_alias=None,
                )
            )

        return candidates

    def _normalize_bm25(self, bm25_score: float, rank: int, total: int) -> float:
        """
        Normalize BM25 score to 0-1 range.

        BM25 scores are unbounded, so we use a combination of:
        - Rank position (1/rank)
        - Total results (context)

        This is a simple heuristic; calibration will learn better weights.

        Args:
            bm25_score: Raw BM25 score (positive)
            rank: Rank position (1-indexed)
            total: Total number of results

        Returns:
            Normalized score (0-1)
        """
        # Simple rank-based normalization
        # Top result gets ~0.9, subsequent results decay
        # This is a placeholder; calibration will learn actual mapping
        if rank == 1:
            return 0.9
        elif rank <= 3:
            return 0.8
        elif rank <= 10:
            return 0.7
        elif rank <= 20:
            return 0.6
        else:
            return 0.5
