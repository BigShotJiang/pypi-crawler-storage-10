"""Canonical name matcher for exact name lookups."""

from resolvekit.data.entity_repository import EntityRepository
from resolvekit.normalization.normalizer import TextNormalizer
from resolvekit.types import Candidate, MatchContext, MatcherType


class CanonicalNameMatcher:
    """
    Matches exact canonical names (normalized).

    Tier 1 matcher: Deterministic, returns single match, stops cascade.

    Matches against normalized canonical names using exact lookup.
    """

    def __init__(self, entity_repo: EntityRepository, normalizer: TextNormalizer):
        """
        Initialize matcher.

        Args:
            entity_repo: Entity repository for lookups
            normalizer: Text normalizer (for consistency)
        """
        self.entity_repo = entity_repo
        self.normalizer = normalizer

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 10,
        context: MatchContext | None = None,
    ) -> list[Candidate]:
        """
        Lookup by normalized canonical name.

        Args:
            query: Original query string (unused)
            normalized_query: Normalized query string
            limit: Maximum candidates (unused, always returns 0 or 1)
            context: Optional filtering context

        Returns:
            List with single candidate if match found, empty list otherwise
        """
        # Lookup by normalized canonical name
        entity = self.entity_repo.find_by_canonical_name(normalized_query, context)

        if not entity:
            return []

        # Return single candidate
        return [
            Candidate(
                entity=entity,
                score=1.0,
                matcher_type=MatcherType.CANONICAL_NAME,
                features={"canonical_exact": True},
                matched_alias=None,
            )
        ]
