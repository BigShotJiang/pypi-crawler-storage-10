"""Exact alias matcher for normalized alias lookups."""

from resolvekit.data.alias_repository import AliasRepository
from resolvekit.types import Candidate, MatchContext, MatcherType


class AliasExactMatcher:
    """
    Matches exact aliases (normalized).

    Tier 2 matcher: May return multiple candidates (ambiguous).
    Cascade stops if single match, continues if multiple.

    Matches against normalized aliases using exact lookup.
    """

    def __init__(self, alias_repo: AliasRepository):
        """
        Initialize matcher.

        Args:
            alias_repo: Alias repository for lookups
        """
        self.alias_repo = alias_repo

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 10,
        context: MatchContext | None = None,
    ) -> list[Candidate]:
        """
        Find all entities with exact normalized alias match.

        Args:
            query: Original query string (unused)
            normalized_query: Normalized query string
            limit: Maximum candidates to return
            context: Optional filtering context

        Returns:
            List of candidates (may be multiple for ambiguous aliases)
        """
        # Find all entities with this alias
        matches = self.alias_repo.find_exact_normalized(normalized_query, context)

        if not matches:
            return []

        # Convert to candidates
        candidates = []
        for entity, matched_alias in matches:
            candidates.append(
                Candidate(
                    entity=entity,
                    score=1.0,
                    matcher_type=MatcherType.ALIAS_EXACT,
                    features={"alias_exact": True, "matched_alias": matched_alias},
                    matched_alias=matched_alias,
                )
            )

        # Limit results
        return candidates[:limit]
