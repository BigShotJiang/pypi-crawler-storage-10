"""Code system inference priority presets for different domains."""

from resolvekit.types import CodeSystem


class InferencePriority:
    """
    Preset priority orderings for code system inference.

    Different domains have different priorities for ambiguous codes.
    For example, a 3-letter code "USA" could be ISO3 or World Bank -
    the correct interpretation depends on context.

    Usage:
        # Use a preset
        cascade = MatcherCascade(..., code_priority=InferencePriority.humanitarian())

        # Or customize
        custom_priority = [CodeSystem.WB, CodeSystem.ISO2, CodeSystem.ISO3]
        cascade = MatcherCascade(..., code_priority=custom_priority)
    """

    @staticmethod
    def default() -> list[CodeSystem]:
        """
        General-purpose priority order.

        Prioritizes:
        1. Most unique patterns (DCID, Wikidata)
        2. Common standards (ISO codes)
        3. Specialized systems (NUTS, P-codes, etc.)

        This is the fallback when no domain context is specified.
        """
        return [
            # Tier 1: Unique patterns (fast path handles these)
            CodeSystem.DCID,  # "country/USA" - slash is unique
            CodeSystem.WIKIDATA,  # "Q30" - Q prefix is unique
            # Tier 2: Common standards
            CodeSystem.ISO2,  # 2-letter country codes (most common)
            CodeSystem.ISO_NUMERIC,  # 3-digit numeric (UN official)
            CodeSystem.M49,  # 3-digit UN region codes
            CodeSystem.ISO3,  # 3-letter country codes
            CodeSystem.ISO3166_2,  # "US-CA" subdivision codes
            # Tier 3: Domain-specific
            CodeSystem.GEONAMES,  # Numeric GeoNames ID
            CodeSystem.WB,  # World Bank codes (2-3 letters)
            CodeSystem.DAC,  # OECD DAC codes
            CodeSystem.NUTS,  # EU statistical regions
            CodeSystem.LAU,  # EU local admin units
            CodeSystem.PCODE,  # OCHA humanitarian P-codes
            CodeSystem.FIPS,  # Deprecated FIPS codes (last resort)
        ]

    @staticmethod
    def humanitarian() -> list[CodeSystem]:
        """
        Humanitarian/OCHA context priority.

        Prioritizes OCHA P-codes for humanitarian coordination,
        followed by UN standards and ISO codes.

        Use when working with:
        - UN OCHA data
        - Humanitarian response datasets
        - Emergency coordination systems
        """
        return [
            CodeSystem.DCID,
            CodeSystem.WIKIDATA,
            CodeSystem.PCODE,  # OCHA P-codes prioritized
            CodeSystem.M49,  # UN M49 regions
            CodeSystem.ISO2,
            CodeSystem.ISO3,
            CodeSystem.ISO_NUMERIC,
            CodeSystem.ISO3166_2,
            CodeSystem.GEONAMES,
            CodeSystem.WB,
            CodeSystem.DAC,
            CodeSystem.NUTS,
            CodeSystem.LAU,
            CodeSystem.FIPS,
        ]

    @staticmethod
    def world_bank() -> list[CodeSystem]:
        """
        World Bank context priority.

        Prioritizes World Bank codes for development datasets,
        followed by OECD DAC and ISO standards.

        Use when working with:
        - World Bank datasets
        - Development indicators
        - OECD DAC data
        """
        return [
            CodeSystem.DCID,
            CodeSystem.WIKIDATA,
            CodeSystem.WB,  # World Bank codes prioritized
            CodeSystem.DAC,  # OECD DAC codes
            CodeSystem.ISO2,
            CodeSystem.ISO3,
            CodeSystem.ISO_NUMERIC,
            CodeSystem.M49,
            CodeSystem.ISO3166_2,
            CodeSystem.GEONAMES,
            CodeSystem.PCODE,
            CodeSystem.NUTS,
            CodeSystem.LAU,
            CodeSystem.FIPS,
        ]

    @staticmethod
    def european_union() -> list[CodeSystem]:
        """
        European Union statistical context priority.

        Prioritizes EU NUTS and LAU codes for European regional statistics,
        followed by ISO codes.

        Use when working with:
        - Eurostat datasets
        - EU regional statistics
        - NUTS/LAU hierarchies
        """
        return [
            CodeSystem.DCID,
            CodeSystem.WIKIDATA,
            CodeSystem.NUTS,  # EU NUTS regions prioritized
            CodeSystem.LAU,  # EU local admin units
            CodeSystem.ISO2,
            CodeSystem.ISO3,
            CodeSystem.ISO3166_2,
            CodeSystem.ISO_NUMERIC,
            CodeSystem.M49,
            CodeSystem.GEONAMES,
            CodeSystem.WB,
            CodeSystem.DAC,
            CodeSystem.PCODE,
            CodeSystem.FIPS,
        ]

    @staticmethod
    def academic() -> list[CodeSystem]:
        """
        Academic/research context priority.

        Prioritizes Wikidata and GeoNames for research datasets,
        followed by ISO standards.

        Use when working with:
        - Research datasets
        - Wikidata-based knowledge graphs
        - GeoNames geographic data
        - Academic publications
        """
        return [
            CodeSystem.WIKIDATA,  # Wikidata prioritized for research
            CodeSystem.DCID,
            CodeSystem.GEONAMES,  # GeoNames prioritized for geography
            CodeSystem.ISO2,
            CodeSystem.ISO3,
            CodeSystem.ISO_NUMERIC,
            CodeSystem.M49,
            CodeSystem.ISO3166_2,
            CodeSystem.WB,
            CodeSystem.DAC,
            CodeSystem.NUTS,
            CodeSystem.LAU,
            CodeSystem.PCODE,
            CodeSystem.FIPS,
        ]
