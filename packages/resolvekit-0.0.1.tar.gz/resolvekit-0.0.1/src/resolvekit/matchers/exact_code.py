"""Exact code matcher for deterministic code lookups."""

from resolvekit.data.code_repository import CodeRepository
from resolvekit.matchers.code_validators import get_validator
from resolvekit.matchers.priorities import InferencePriority
from resolvekit.types import Candidate, CodeSystem, MatchContext, MatcherType


class ExactCodeMatcher:
    """
    Matches exact code lookups with validation.

    Tier 1 matcher: Deterministic, returns single match, stops cascade.

    Supports:
    - Explicit code system: "iso2:US", "dcid:country/USA"
    - Inferred code system: "US" (tries ISO2), "840" (tries ISO_NUMERIC)
    """

    def __init__(
        self,
        code_repo: CodeRepository,
        priority_order: list[CodeSystem] | None = None,
    ):
        """
        Initialize matcher.

        Args:
            code_repo: Code repository for validation and lookup
            priority_order: Optional priority order for code system inference.
                          If None, uses InferencePriority.default()
        """
        self.code_repo = code_repo
        self.priority = priority_order or InferencePriority.default()

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 10,
        context: MatchContext | None = None,
    ) -> list[Candidate]:
        """
        Try to parse query as code and lookup.

        Args:
            query: Original query string
            normalized_query: Normalized query (unused for code matching)
            limit: Maximum candidates (unused, always returns 0 or 1)
            context: Optional filtering context

        Returns:
            List with single candidate if match found, empty list otherwise
        """
        # Parse code: "system:value" or just "value"
        systems, value = self._parse_code(query)

        if not systems or value is None:
            return []

        # Try each candidate system in priority order until lookup succeeds
        for system in systems:
            # Validate code format
            is_valid, _ = self.code_repo.validate_code(system, value)
            if not is_valid:
                continue

            # Lookup entity
            entity = self.code_repo.find_by_code(system, value, context)
            if entity:
                # Return single candidate with exact_code feature
                return [
                    Candidate(
                        entity=entity,
                        score=1.0,
                        matcher_type=MatcherType.EXACT_CODE,
                        features={"exact_code": True, "code_system": system.value},
                        matched_alias=None,
                    )
                ]

        # No match found in any candidate system
        return []

    def _parse_code(self, query: str) -> tuple[list[CodeSystem], str | None]:
        """
        Parse query as code with optional system prefix.

        Formats:
            - "system:value" -> explicit system (single-item list)
            - "value" -> infer systems from format (priority-ordered list)

        Args:
            query: Query string

        Returns:
            Tuple of (code_systems_list, code_value) or ([], None) if unparseable
        """
        # Check for explicit system
        if ":" in query:
            parts = query.split(":", 1)
            if len(parts) == 2:
                system_str, value = parts
                try:
                    system = CodeSystem(system_str.lower())
                    return [system], value
                except ValueError:
                    return [], None

        # Infer systems from format (returns priority-ordered list)
        systems = self._infer_code_system(query)
        return systems, query if systems else ([], None)

    def _infer_code_system(self, value: str) -> list[CodeSystem]:
        """
        Infer candidate code systems from value format using hybrid approach.

        Strategy:
        1. Fast path: Check unique patterns (DCID with "/", Wikidata "Q123")
           - If found, return single-item list (unambiguous)
        2. Priority iteration: Collect all validators that pass in priority order
           - Returns list of candidates to try

        Args:
            value: Code value

        Returns:
            List of candidate code systems in priority order (empty if none match)
        """
        # Fast path for unambiguous patterns (O(1) checks)
        fast_path_result = self._fast_path_inference(value)
        if fast_path_result is not None:
            # Unambiguous pattern - return single candidate
            return [fast_path_result]

        # Priority-based validation: collect ALL matching systems in priority order
        candidates = []
        for system in self.priority:
            # Skip systems already checked in fast path
            if system in {CodeSystem.DCID, CodeSystem.WIKIDATA}:
                continue

            validator = get_validator(system)
            is_valid, _ = validator.validate(value)
            if is_valid:
                candidates.append(system)

        return candidates

    def _fast_path_inference(self, value: str) -> CodeSystem | None:
        """
        Fast path for unique patterns that don't need validation.

        These patterns are unambiguous and can be identified with simple
        string operations, avoiding validator lookups.

        Args:
            value: Code value

        Returns:
            Code system if unique pattern detected, None otherwise
        """
        # DCID: Contains "/" (e.g., "country/USA", "geoId/06")
        if "/" in value:
            return CodeSystem.DCID

        # Wikidata: Starts with "Q" followed by digits (e.g., "Q30")
        if len(value) > 1 and value[0].upper() == "Q" and value[1:].isdigit():
            return CodeSystem.WIKIDATA

        # ISO3166-2: Contains "-" with 2-3 char country prefix (e.g., "US-CA")
        if "-" in value:
            parts = value.split("-", 1)
            if len(parts) == 2 and 2 <= len(parts[0]) <= 3 and parts[0].isalpha():
                return CodeSystem.ISO3166_2

        return None
