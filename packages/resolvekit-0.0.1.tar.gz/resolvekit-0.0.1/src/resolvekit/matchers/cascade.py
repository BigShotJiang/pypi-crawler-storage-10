"""Matcher cascade orchestrator with tier-based short-circuiting."""

from resolvekit.matchers.alias_exact import AliasExactMatcher
from resolvekit.matchers.canonical_name import CanonicalNameMatcher
from resolvekit.matchers.exact_code import ExactCodeMatcher
from resolvekit.matchers.fts_matcher import FTSMatcher
from resolvekit.matchers.fuzzy_matcher import FuzzyMatcher
from resolvekit.normalization.normalizer import TextNormalizer
from resolvekit.types import Candidate, CodeSystem, MatchContext


class MatcherCascade:
    """
    Orchestrates matcher execution with tier-based short-circuiting.

    Cascade Tiers:
        Tier 1 (Deterministic): ExactCode, CanonicalName -> STOP if found
        Tier 2 (Exact Multi): AliasExact -> STOP if unambiguous
        Tier 3 (Fuzzy): FTS + Fuzzy -> Return top-K

    Performance Target:
        - Tier 1: p50 < 10ms (most queries)
        - Tier 3: p95 < 50ms (complex queries)
    """

    def __init__(
        self,
        exact_code: ExactCodeMatcher,
        canonical_name: CanonicalNameMatcher,
        alias_exact: AliasExactMatcher,
        fts: FTSMatcher,
        fuzzy: FuzzyMatcher,
        normalizer: TextNormalizer,
        code_priority: list[CodeSystem] | None = None,
    ):
        """
        Initialize cascade with all matchers.

        Args:
            exact_code: Tier 1 exact code matcher
            canonical_name: Tier 1 canonical name matcher
            alias_exact: Tier 2 alias exact matcher
            fts: Tier 3 FTS matcher
            fuzzy: Tier 3 fuzzy matcher
            normalizer: Text normalizer
            code_priority: Optional code system inference priority.
                         If provided, overrides the exact_code matcher's priority.
                         Use InferencePriority presets (humanitarian, world_bank, etc.)
                         or provide a custom list of CodeSystem values.
        """
        self.exact_code = exact_code
        self.canonical_name = canonical_name
        self.alias_exact = alias_exact
        self.fts = fts
        self.fuzzy = fuzzy
        self.normalizer = normalizer

        # Apply code priority if provided (cascade-level configuration)
        if code_priority is not None:
            self.exact_code.priority = code_priority

    def resolve(  # noqa: PLR0911
        self, query: str, context: MatchContext | None = None, top_k: int = 12
    ) -> list[Candidate]:
        """
        Execute cascade with tier-based short-circuiting.

        Multiple returns are intentional - each tier has early exit conditions
        for optimal performance (short-circuiting pattern).

        Args:
            query: Query string to resolve
            context: Optional filtering context
            top_k: Maximum candidates to return

        Returns:
            List of candidates ordered by score (descending)
        """
        # Fast reject for empty/whitespace queries
        if not query or not query.strip():
            return []

        # Truncate long queries (DoS protection)
        if len(query) > 1000:
            query = query[:1000]

        # Normalize once for all matchers
        normalized = self.normalizer.normalize(query)

        # Empty after normalization? (e.g., only punctuation)
        if not normalized:
            return []

        # TIER 1: Deterministic exact matches (STOP if found)

        # Try exact code first (fastest)
        candidates = self.exact_code.match(query, normalized, context=context)
        if candidates:
            return candidates  # Single match, high confidence, STOP

        # Try canonical name
        candidates = self.canonical_name.match(query, normalized, context=context)
        if candidates:
            return candidates  # Single match, high confidence, STOP

        # TIER 2: Exact alias (may be multiple, continue if ambiguous)
        candidates = self.alias_exact.match(query, normalized, context=context)
        if len(candidates) == 1:
            return candidates  # Unambiguous, STOP
        elif len(candidates) > 1:
            # Ambiguous - return multiple for calibration to decide
            return candidates[:top_k]

        # TIER 3: FTS + Fuzzy (ranked candidates)

        # FTS returns top-50
        fts_candidates = self.fts.match(query, normalized, limit=50, context=context)

        if not fts_candidates:
            return []  # No matches

        # Fuzzy refines to top-K
        refined = self.fuzzy.match(
            query, normalized, limit=top_k, fts_candidates=fts_candidates
        )

        return refined
