# Matchers Module

## Purpose

The matchers module implements the candidate generation cascade - a series of increasingly sophisticated matching strategies applied in sequence until candidates are found.

## Components

### Matcher Classes

1. **ExactCodeMatcher** (`exact_code.py`)
   - Direct lookup of standardized codes (ISO, M49, NUTS, OCHA P-codes, DCIDs)
   - Validates code format before lookup
   - Highest priority matcher (deterministic)

2. **CanonicalNameMatcher** (`canonical_name.py`)
   - Exact match against normalized canonical entity names
   - Uses hash table for O(1) lookup
   - Second-highest priority

3. **AliasExactMatcher** (`alias_exact.py`)
   - Exact match against normalized aliases
   - Handles multilingual aliases
   - Returns all matching entities (may be multiple)

4. **FTSMatcher** (`fts_matcher.py`)
   - Full-text search using SQLite FTS5
   - Returns top-K candidates ranked by BM25-like score
   - Queries across base pack + overlay FTS indexes

5. **FuzzyMatcher** (`fuzzy_matcher.py`)
   - Bounded fuzzy matching on FTS candidates
   - Uses edit distance, trigram similarity, Jaccard coefficient
   - Reduces top-K to top-K' highest-scoring candidates

6. **SemanticMatcher** (`semantic_matcher.py`)
   - Optional semantic similarity via embeddings
   - Only invoked on ambiguous cases (low margin or registry hit)
   - Requires `resolver[semantic]` extra

### Shared Components

- `base.py`: Abstract base class for all matchers
- `cascade.py`: Orchestrates matcher execution in priority order
- `candidate.py`: Candidate data structures and scoring

## Matcher Cascade Flow

```
Input Query
    ↓
[1. ExactCodeMatcher] → Found? → Return
    ↓ Not found
[2. CanonicalNameMatcher] → Found? → Return
    ↓ Not found
[3. AliasExactMatcher] → Found? → Return candidates
    ↓ Not found or ambiguous
[4. FTSMatcher] → top-K candidates (K=50)
    ↓
[5. FuzzyMatcher] → refine to top-K' (K'=12)
    ↓
[6. SemanticMatcher] → re-rank if ambiguous (optional)
    ↓
Return ranked candidates
```

## Design Principles

1. **Fail-fast**: Early matchers return immediately on high-confidence matches
2. **Bounded computation**: Limit fuzzy/semantic work to top-K candidates
3. **Pluggable**: Easy to add custom matchers
4. **Feature extraction**: Each matcher emits features for calibration

## Implementation Priority

**Phase A** - Core resolver (items 1-5)
**Phase E** - Ambiguity subsystem (item 6)
