"""Protocols for matcher implementations."""

from typing import Protocol

from resolvekit.types import Candidate, MatchContext


class MatcherProtocol(Protocol):
    """
    Structural protocol for matchers.

    Matchers do not need to inherit from this class.
    Any class implementing the match() method signature
    automatically satisfies this protocol (duck typing).
    """

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 10,
        context: MatchContext | None = None,
    ) -> list[Candidate]:
        """
        Find matching candidates for a query.

        Args:
            query: Original query string
            normalized_query: Normalized version (from TextNormalizer)
            limit: Maximum candidates to return
            context: Optional filtering context

        Returns:
            List of candidates ordered by score (descending)
        """
        ...


class CodeValidatorProtocol(Protocol):
    """
    Structural protocol for code system validators.

    Each code system (ISO2, ISO3, M49, etc.) implements
    this protocol to validate and normalize codes.
    """

    def validate(self, value: str) -> tuple[bool, str | None]:
        """
        Validate code format.

        Args:
            value: Code value to validate

        Returns:
            Tuple of (is_valid, error_message).
            If valid, error_message is None.
        """
        ...

    def normalize(self, value: str) -> str:
        """
        Normalize code to canonical form.

        Examples:
            - "us" -> "US" (ISO2)
            - "fra" -> "FRA" (ISO3)
            - "Q123" -> "Q123" (Wikidata, case-sensitive)

        Args:
            value: Code value to normalize

        Returns:
            Normalized code value
        """
        ...
