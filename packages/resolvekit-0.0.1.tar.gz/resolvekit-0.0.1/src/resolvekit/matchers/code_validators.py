"""Code system validators for format validation and normalization."""

import re
from typing import TYPE_CHECKING

from resolvekit.types import CodeSystem

if TYPE_CHECKING:
    from resolvekit.matchers.protocols import CodeValidatorProtocol


class ISO2Validator:
    """Validator for ISO 3166-1 alpha-2 codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate ISO2 format (2 letters)."""
        if len(value) != 2 or not value.isalpha():
            return False, "ISO2 must be 2 letters"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class ISO3Validator:
    """Validator for ISO 3166-1 alpha-3 codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate ISO3 format (3 letters)."""
        if len(value) != 3 or not value.isalpha():
            return False, "ISO3 must be 3 letters"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class ISONumericValidator:
    """Validator for ISO 3166-1 numeric codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate ISO numeric format (3 digits)."""
        if len(value) != 3 or not value.isdigit():
            return False, "ISO numeric must be 3 digits"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize preserves digits."""
        return value


class DCIDValidator:
    """Validator for Data Commons IDs."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate DCID format (prefix/identifier)."""
        if "/" not in value:
            return False, "DCID must contain '/'"
        return True, None

    def normalize(self, value: str) -> str:
        """DCIDs are case-sensitive, no normalization."""
        return value


class M49Validator:
    """Validator for UN M49 region codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate M49 format (3 digits)."""
        if len(value) != 3 or not value.isdigit():
            return False, "M49 must be 3 digits"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize preserves digits."""
        return value


class ISO31662Validator:
    """Validator for ISO 3166-2 subdivision codes."""

    _PATTERN = re.compile(r"^[A-Z]{2}-[A-Z0-9]{1,3}$")

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate ISO 3166-2 format (CC-SSS)."""
        if not self._PATTERN.match(value.upper()):
            return False, "ISO3166-2 must be format CC-SSS (e.g., US-CA)"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class NUTSValidator:
    """Validator for EU NUTS codes."""

    _PATTERN = re.compile(r"^[A-Z]{2}[0-9A-Z]{0,3}$")

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate NUTS format (CC[0-9A-Z]{0,3})."""
        if not self._PATTERN.match(value.upper()):
            return False, "NUTS must be format CC[0-9A-Z]{0,3} (e.g., DE3, FR10)"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class LAUValidator:
    """Validator for EU LAU codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate LAU format (variable by country)."""
        # LAU format is variable, accept any non-empty string
        if not value or not value.strip():
            return False, "LAU code cannot be empty"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class PCodeValidator:
    """Validator for OCHA P-codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate P-code format (variable format)."""
        # P-codes have variable format, accept any non-empty alphanumeric
        if not value or not value.strip():
            return False, "P-code cannot be empty"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class WikidataValidator:
    """Validator for Wikidata QIDs."""

    _PATTERN = re.compile(r"^Q[0-9]+$")

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate Wikidata format (Q[0-9]+)."""
        if not self._PATTERN.match(value.upper()):
            return False, "Wikidata QID must be format Q[0-9]+ (e.g., Q30)"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class GeoNamesValidator:
    """Validator for GeoNames IDs."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate GeoNames format (numeric ID)."""
        if not value.isdigit():
            return False, "GeoNames ID must be numeric"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize preserves digits."""
        return value


class WorldBankValidator:
    """Validator for World Bank country codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate World Bank format (2-3 letters)."""
        if len(value) not in (2, 3) or not value.isalpha():
            return False, "World Bank code must be 2-3 letters"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


class DACValidator:
    """Validator for OECD DAC codes."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate DAC format (numeric)."""
        if not value.isdigit():
            return False, "DAC code must be numeric"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize preserves digits."""
        return value


class FIPSValidator:
    """Validator for FIPS codes (deprecated but still used)."""

    def validate(self, value: str) -> tuple[bool, str | None]:
        """Validate FIPS format (2 letters)."""
        if len(value) != 2 or not value.isalpha():
            return False, "FIPS must be 2 letters"
        return True, None

    def normalize(self, value: str) -> str:
        """Normalize to uppercase."""
        return value.upper()


# Simple constant dict - no registration ceremony
# Note: Using object type here to avoid circular import with protocols
# All validators implement CodeValidatorProtocol structurally
CODE_VALIDATORS: dict[CodeSystem, object] = {
    CodeSystem.ISO2: ISO2Validator(),
    CodeSystem.ISO3: ISO3Validator(),
    CodeSystem.ISO_NUMERIC: ISONumericValidator(),
    CodeSystem.DCID: DCIDValidator(),
    CodeSystem.M49: M49Validator(),
    CodeSystem.ISO3166_2: ISO31662Validator(),
    CodeSystem.NUTS: NUTSValidator(),
    CodeSystem.LAU: LAUValidator(),
    CodeSystem.PCODE: PCodeValidator(),
    CodeSystem.WIKIDATA: WikidataValidator(),
    CodeSystem.GEONAMES: GeoNamesValidator(),
    CodeSystem.WB: WorldBankValidator(),
    CodeSystem.DAC: DACValidator(),
    CodeSystem.FIPS: FIPSValidator(),
}


def get_validator(system: CodeSystem) -> "CodeValidatorProtocol":
    """
    Get validator for code system.

    Args:
        system: Code system enum value

    Returns:
        Validator instance implementing CodeValidatorProtocol

    Raises:
        KeyError: If code system not supported
    """
    return CODE_VALIDATORS[system]  # type: ignore[return-value]
