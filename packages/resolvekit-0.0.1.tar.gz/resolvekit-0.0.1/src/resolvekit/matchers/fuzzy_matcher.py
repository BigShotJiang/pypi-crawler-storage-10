"""Fuzzy matcher for refining FTS results with similarity scoring."""

from rapidfuzz import fuzz

from resolvekit.normalization.normalizer import TextNormalizer
from resolvekit.types import Candidate, MatchContext


class FuzzyMatcher:
    """
    Bounded fuzzy matching on FTS candidates.

    Tier 3 matcher: Refines FTS results, returns top-K'.

    Uses rapidfuzz for edit distance and trigram similarity.
    Only operates on FTS candidates (bounded computation).
    """

    def __init__(self, normalizer: TextNormalizer):
        """
        Initialize matcher.

        Args:
            normalizer: Text normalizer for canonical name normalization
        """
        self.normalizer = normalizer

    def match(
        self,
        query: str,
        normalized_query: str,
        limit: int = 12,
        context: MatchContext | None = None,
        fts_candidates: list[Candidate] | None = None,
    ) -> list[Candidate]:
        """
        Refine FTS candidates with fuzzy scoring.

        Performance:
        - Only operates on FTS candidates (bounded)
        - Uses rapidfuzz
        - Combined score: 0.6 * edit + 0.4 * trigram

        Args:
            query: Original query string (unused)
            normalized_query: Normalized query string
            limit: Maximum candidates to return (top-K')
            context: Optional filtering context (unused)
            fts_candidates: FTS candidates to refine

        Returns:
            List of refined candidates ordered by fuzzy score (descending)
        """
        if not fts_candidates:
            return []

        # Compute fuzzy features for each candidate
        scored = []
        for candidate in fts_candidates:
            # Edit similarity (rapidfuzz.fuzz.ratio returns 0-100)
            edit_score = (
                fuzz.ratio(
                    normalized_query,
                    self.normalizer.normalize(candidate.entity.canonical_name),
                )
                / 100.0
            )

            # Trigram Jaccard similarity
            trigram_score = self._trigram_jaccard(
                normalized_query, candidate.entity.canonical_name
            )

            # Combined fuzzy score
            fuzzy_score = 0.6 * edit_score + 0.4 * trigram_score

            # Update candidate features
            candidate.features.update(
                {
                    "edit_similarity": edit_score,
                    "trigram_jaccard": trigram_score,
                    "fuzzy_score": fuzzy_score,
                }
            )

            # Update score (take max of FTS score and fuzzy score)
            candidate.score = max(candidate.score, fuzzy_score)

            scored.append(candidate)

        # Sort by score (descending) and return top-K'
        scored.sort(key=lambda c: c.score, reverse=True)
        return scored[:limit]

    def _trigram_jaccard(self, s1: str, s2: str) -> float:
        """
        Compute trigram Jaccard similarity.

        Trigrams are 3-character sequences.
        Jaccard = |intersection| / |union|

        Args:
            s1: First string
            s2: Second string

        Returns:
            Jaccard similarity (0-1)
        """
        # Normalize second string
        s2_norm = self.normalizer.normalize(s2)

        # Generate trigrams
        trigrams1 = self._get_trigrams(s1)
        trigrams2 = self._get_trigrams(s2_norm)

        if not trigrams1 or not trigrams2:
            return 0.0

        # Compute Jaccard
        intersection = trigrams1 & trigrams2
        union = trigrams1 | trigrams2

        return len(intersection) / len(union) if union else 0.0

    def _get_trigrams(self, s: str) -> set[str]:
        """
        Generate trigrams from string.

        Examples:
            "abc" -> {"abc"}
            "abcd" -> {"abc", "bcd"}

        Args:
            s: Input string

        Returns:
            Set of trigrams
        """
        if len(s) < 3:
            return set()

        return {s[i : i + 3] for i in range(len(s) - 2)}
