"""Hierarchy constraint validator."""

from sqlalchemy import text
from sqlmodel import Session

from resolvekit.data.entity_repository import EntityRepository
from resolvekit.types import Candidate, MatchContext
from resolvekit.utils.logging import get_logger

logger = get_logger(__name__)


class HierarchyValidator:
    """
    Validates parent-child hierarchy constraints.

    Hard filtering: Removes candidates that are not descendants of context.parent_dcid
    Features: Adds f_parent_valid and f_parent_depth
    """

    def __init__(self, entity_repo: EntityRepository, depth_limit: int = 3):
        """
        Initialize hierarchy validator.

        Args:
            entity_repo: Repository for entity lookups
            depth_limit: Maximum depth to traverse up the hierarchy
        """
        self.entity_repo = entity_repo
        self.depth_limit = depth_limit

    def validate(
        self, candidates: list[Candidate], context: MatchContext
    ) -> list[Candidate]:
        """
        Validate hierarchy constraints.

        Optimized to check each unique entity_dcid only once, even if multiple
        candidates share the same entity.

        Args:
            candidates: List of candidates to validate
            context: Match context with optional parent_dcid constraint

        Returns:
            Filtered candidates with f_parent_valid and f_parent_depth features
        """
        # Fast path: no parent constraint
        if context.parent_dcid is None:
            for candidate in candidates:
                candidate.features["parent_valid"] = True
                candidate.features["parent_depth"] = 0
            return candidates

        # Batch query: check all unique entities in single DB query
        entity_dcids = list({c.entity.dcid for c in candidates})
        entity_results = self._batch_check_descendants(
            entity_dcids, context.parent_dcid
        )

        # Apply results to all candidates
        for candidate in candidates:
            is_valid, depth = entity_results[candidate.entity.dcid]
            candidate.features["parent_valid"] = is_valid
            candidate.features["parent_depth"] = depth

        # Hard filter: remove invalid candidates
        return [c for c in candidates if c.features["parent_valid"]]

    def _batch_check_descendants(
        self, entity_dcids: list[str], parent_dcid: str
    ) -> dict[str, tuple[bool, int]]:
        """
        Check which entities are descendants of parent using recursive CTE.

        Single database query to check all entities at once, dramatically faster
        than sequential lookups for large candidate sets. Respects overlay
        precedence - if an overlay changes an entity's parent_dcid, the overlay
        version is used for hierarchy traversal.

        Args:
            entity_dcids: List of entity DCIDs to check
            parent_dcid: Parent to find in ancestry

        Returns:
            Dict mapping entity_dcid -> (is_descendant, depth)
        """
        if not self.entity_repo.db.engine:
            raise RuntimeError("Database not connected. Call connect() first.")

        if not entity_dcids:
            return {}

        # Build placeholders for IN clause
        placeholders = ", ".join(f":dcid_{i}" for i in range(len(entity_dcids)))
        params = {f"dcid_{i}": dcid for i, dcid in enumerate(entity_dcids)}
        params["parent"] = parent_dcid
        params["depth_limit"] = self.depth_limit

        # Build best_entities CTE - dedupe by precedence
        # This ensures overlay parent_dcid overrides base parent_dcid
        best_selects = ["SELECT dcid, parent_dcid, 0 AS precedence FROM main.entities"]
        for schema_name, precedence in self.entity_repo.db.overlays:
            best_selects.append(
                f"SELECT dcid, parent_dcid, {precedence} AS precedence FROM {schema_name}.entities"
            )

        best_entities_query = "\nUNION ALL\n".join(best_selects)

        # Build recursive CTE - track original candidate through traversal
        # Uses best_entities to ensure we traverse using highest-precedence parent links
        # ROW_NUMBER() deduplicates by dcid, keeping highest precedence row
        sql = f"""
        WITH RECURSIVE
        best_entities AS (
            SELECT dcid, parent_dcid
            FROM (
                SELECT dcid, parent_dcid,
                       ROW_NUMBER() OVER (PARTITION BY dcid ORDER BY precedence DESC) as rn
                FROM ({best_entities_query}) all_entities
            ) ranked
            WHERE rn = 1
        ),
        ancestors AS (
            SELECT dcid AS original_dcid, dcid AS current_dcid, parent_dcid, 0 AS depth
            FROM best_entities
            WHERE dcid IN ({placeholders})

            UNION ALL

            SELECT a.original_dcid, e.dcid AS current_dcid, e.parent_dcid, a.depth + 1
            FROM best_entities e
            INNER JOIN ancestors a ON e.dcid = a.parent_dcid
            WHERE a.depth < :depth_limit AND a.parent_dcid IS NOT NULL
        )
        SELECT original_dcid AS dcid, MIN(depth) + 1 AS depth
        FROM ancestors
        WHERE parent_dcid = :parent AND depth + 1 <= :depth_limit
        GROUP BY original_dcid
        """

        # Execute query
        with Session(self.entity_repo.db.engine) as session:
            result = session.execute(text(sql), params)
            valid_entities = {row.dcid: (True, row.depth) for row in result}

        # Build full results map (invalid = False for entities not in results)
        return {dcid: valid_entities.get(dcid, (False, 0)) for dcid in entity_dcids}
