"""Protocols for constraint validators."""

from typing import Protocol

from resolvekit.types import Candidate, MatchContext


class Validator(Protocol):
    """
    Protocol for constraint validators.

    Validators filter candidates or enrich them with validation features.
    They may perform hard filtering (removing invalid candidates) or soft
    validation (adding features for calibration to consider).
    """

    def validate(
        self, candidates: list[Candidate], context: MatchContext
    ) -> list[Candidate]:
        """
        Validate candidates against constraints.

        May filter candidates (hard filtering) or enrich them with
        validation features (soft validation).

        Args:
            candidates: List of candidates to validate
            context: Match context with constraint parameters

        Returns:
            Validated/enriched candidates
        """
        ...
