"""Constraint engine orchestrator."""

from resolvekit.constraints.hierarchy_validator import HierarchyValidator
from resolvekit.constraints.membership_validator import MembershipValidator
from resolvekit.constraints.temporal_validator import TemporalValidator
from resolvekit.constraints.type_validator import TypeValidator
from resolvekit.data.entity_repository import EntityRepository
from resolvekit.data.membership_repository import MembershipRepository
from resolvekit.types import Candidate, MatchContext


class ConstraintEngine:
    """
    Orchestrates constraint validation with hybrid filtering.

    Hard filtering (removes candidates):
    - Type constraint (when context.entity_type is set)
    - Parent constraint (when context.parent_dcid is set)

    Soft features (marks but doesn't filter):
    - Temporal validity (when context.as_of is set)
    - Membership validity (when context.group_dcid is set)
    """

    def __init__(
        self,
        entity_repo: EntityRepository,
        membership_repo: MembershipRepository,
        hierarchy_depth: int = 3,
    ):
        """
        Initialize constraint engine.

        Args:
            entity_repo: Repository for entity lookups
            membership_repo: Repository for membership queries
            hierarchy_depth: Maximum depth for hierarchy traversal (default 3)
        """
        self.type_validator = TypeValidator()
        self.hierarchy_validator = HierarchyValidator(entity_repo, hierarchy_depth)
        self.temporal_validator = TemporalValidator()
        self.membership_validator = MembershipValidator(membership_repo)
        self.hierarchy_depth = hierarchy_depth

    def apply_constraints(
        self, candidates: list[Candidate], context: MatchContext | None
    ) -> list[Candidate]:
        """
        Apply all constraints with hybrid filtering.

        Args:
            candidates: List of candidates to validate
            context: Match context with optional constraints

        Returns:
            Validated/enriched candidates
        """
        # Fast path: empty candidate list
        if not candidates:
            return candidates

        # Fast path: no context
        if context is None:
            return candidates

        # Fast path: empty context (all fields None)
        if self._is_empty_context(context):
            return candidates

        # HARD FILTERS (reduce candidate set)
        # Order: cheapest first to minimize downstream work
        candidates = self.type_validator.validate(candidates, context)
        if not candidates:  # Early exit if all filtered
            return candidates

        # Early exit: Skip hierarchy validation if no parent constraint
        if context.parent_dcid is not None:
            candidates = self.hierarchy_validator.validate(candidates, context)
            if not candidates:  # Early exit if all filtered
                return candidates
        else:
            # Add default parent features even when constraint is absent.
            # This ensures calibration model receives consistent feature vectors -
            # all candidates have the same features regardless of which constraints
            # are active. Default values indicate "no constraint" rather than "constraint failed".
            for candidate in candidates:
                candidate.features["parent_valid"] = True
                candidate.features["parent_depth"] = 0

        # SOFT FEATURES (enrich remaining candidates)
        candidates = self.temporal_validator.validate(candidates, context)
        candidates = self.membership_validator.validate(candidates, context)

        return candidates

    def _is_empty_context(self, context: MatchContext) -> bool:
        """
        Check if context has any constraints.

        Args:
            context: Match context to check

        Returns:
            True if all constraint fields are None
        """
        return (
            context.entity_type is None
            and context.parent_dcid is None
            and context.as_of is None
            and context.group_dcid is None
        )
