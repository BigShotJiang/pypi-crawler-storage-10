"""Membership constraint validator."""

from datetime import date

from resolvekit.data.membership_repository import MembershipRepository
from resolvekit.types import Candidate, MatchContext


class MembershipValidator:
    """
    Validates group membership constraints.

    Soft validation only: Adds f_membership_valid feature, does not filter.
    """

    def __init__(self, membership_repo: MembershipRepository):
        """
        Initialize membership validator.

        Args:
            membership_repo: Repository for membership queries
        """
        self.membership_repo = membership_repo

    def validate(
        self, candidates: list[Candidate], context: MatchContext
    ) -> list[Candidate]:
        """
        Validate membership constraints.

        Args:
            candidates: List of candidates to validate
            context: Match context with optional group_dcid constraint

        Returns:
            Candidates with f_membership_valid feature (no filtering)
        """
        # If no group constraint, mark all as valid (no constraint to check)
        if context.group_dcid is None:
            for candidate in candidates:
                candidate.features["membership_valid"] = True
            return candidates

        # Use as_of date or default to today
        as_of = context.as_of if context.as_of is not None else date.today()

        # Batch query all candidates
        entity_dcids = [c.entity.dcid for c in candidates]
        members = self.membership_repo.check_memberships_batch(
            entity_dcids=entity_dcids,
            group_dcid=context.group_dcid,
            as_of=as_of,
        )

        # Mark membership validity
        for candidate in candidates:
            candidate.features["membership_valid"] = candidate.entity.dcid in members

        # Soft validation: return all candidates (don't filter)
        return candidates
