"""Temporal constraint validator."""

from resolvekit.types import Candidate, MatchContext
from resolvekit.utils.dates import is_valid_at


class TemporalValidator:
    """
    Validates temporal validity of entities.

    Soft validation only: Adds f_date_valid feature, does not filter.
    Uses existing is_valid_at() utility from utils/dates.py.
    """

    def validate(
        self, candidates: list[Candidate], context: MatchContext
    ) -> list[Candidate]:
        """
        Validate temporal constraints.

        Args:
            candidates: List of candidates to validate
            context: Match context with optional as_of date

        Returns:
            Candidates with f_date_valid feature (no filtering)
        """
        # If no as_of constraint, mark all as having no temporal constraint
        if context.as_of is None:
            for candidate in candidates:
                candidate.features["date_valid"] = True
            return candidates

        # Check validity for each candidate
        for candidate in candidates:
            candidate.features["date_valid"] = is_valid_at(
                as_of=context.as_of,
                valid_from=candidate.entity.valid_from,
                valid_until=candidate.entity.valid_until,
            )

        # Soft validation: return all candidates (don't filter)
        return candidates
