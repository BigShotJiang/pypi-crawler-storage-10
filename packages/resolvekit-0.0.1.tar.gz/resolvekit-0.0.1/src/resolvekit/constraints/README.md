# Constraints Module

## Purpose

The constraints module enforces Knowledge Graph (KG) and temporal constraints on candidate entities, filtering out invalid matches based on type, hierarchy, temporal validity, and group memberships.

## Components

### Constraint Validators

1. **Type Validator** (`type_validator.py`)
   - Enforces entity type constraints when provided
   - Example: If `entity_type="country"`, filter out states/cities

2. **Hierarchy Validator** (`hierarchy_validator.py`)
   - Checks parent-child containment relationships
   - Example: If `parent="country/FRA"`, only keep French subdivisions
   - Validates full hierarchy paths

3. **Temporal Validator** (`temporal_validator.py`)
   - Checks validity ranges (valid_from, valid_until)
   - Handles historical entity names
   - Default: current date (pack build date)
   - Supports `as_of` parameter for historical queries

4. **Membership Validator** (`membership_validator.py`)
   - Validates group memberships at specific dates
   - Example: Check if entity was EU member in 2005
   - Handles joining/leaving events (Brexit, EU expansions)

### Helper Components

- `constraint_engine.py`: Orchestrates constraint validation
- `validity.py`: Temporal validity utilities
- `hierarchy.py`: Hierarchy traversal utilities

## Constraint Application Flow

```python
def apply_constraints(
    candidates: list[Candidate],
    entity_type: str | None,
    parent: str | None,
    at: date | None,
    group: str | None
) -> list[Candidate]:
    """Apply all constraints to filter candidates."""

    # Type constraint
    if entity_type:
        candidates = [c for c in candidates if c.type == entity_type]

    # Hierarchy constraint
    if parent:
        candidates = [c for c in candidates if is_child_of(c.dcid, parent)]

    # Temporal constraint
    if at:
        candidates = [c for c in candidates if is_valid_at(c, at)]

    # Membership constraint
    if group and at:
        candidates = [c for c in candidates
                     if is_member_at(c.dcid, group, at)]

    # Mark validity in features
    for c in candidates:
        c.features.type_valid = (entity_type is None or c.type == entity_type)
        c.features.parent_valid = (parent is None or is_child_of(c.dcid, parent))
        c.features.date_valid = (at is None or is_valid_at(c, at))

    return candidates
```

## Design Principles

1. **Additive filtering**: Each constraint narrows candidate set
2. **Feature tracking**: Record which constraints passed/failed for calibration
3. **Graceful degradation**: Missing temporal data doesn't crash queries
4. **Efficient lookups**: Pre-computed indexes for hierarchy/membership

## Temporal Validity Model

All temporal-aware tables include:
- `valid_from`: Start date (ISO format) or NULL (always valid)
- `valid_until`: End date (ISO format, exclusive) or NULL (still valid)

Validity check:
```python
def is_valid_at(entity, as_of: date) -> bool:
    """Check if entity is valid at given date."""
    if entity.valid_from and as_of < entity.valid_from:
        return False
    if entity.valid_until and as_of >= entity.valid_until:
        return False
    return True
```

## Implementation Priority

**Phase A** - Core resolver (type, hierarchy, basic temporal)
**Phase B** - Full membership queries with temporal support
