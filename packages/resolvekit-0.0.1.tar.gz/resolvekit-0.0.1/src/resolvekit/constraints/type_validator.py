"""Type constraint validator."""

from resolvekit.types import Candidate, MatchContext


class TypeValidator:
    """
    Validates entity type constraints.

    Hard filtering: Removes candidates that don't match context.entity_type
    Feature: Adds f_type_valid boolean to all candidates
    """

    def validate(
        self, candidates: list[Candidate], context: MatchContext
    ) -> list[Candidate]:
        """
        Validate entity type constraints.

        Args:
            candidates: List of candidates to validate
            context: Match context with optional entity_type constraint

        Returns:
            Filtered candidates with f_type_valid feature
        """
        # Add feature to all candidates
        for candidate in candidates:
            if context.entity_type is None:
                candidate.features["type_valid"] = True
            else:
                candidate.features["type_valid"] = (
                    candidate.entity.entity_type == context.entity_type
                )

        # Hard filter if type constraint is present
        if context.entity_type is not None:
            candidates = [
                c for c in candidates if c.entity.entity_type == context.entity_type
            ]

        return candidates
