"""Constants for resolvekit."""

from resolvekit.types import EntityType

# Version
VERSION = "0.0.1"

# Default configuration
DEFAULT_MIN_CONFIDENCE = 0.7
DEFAULT_MAX_CANDIDATES = 50
DEFAULT_MAX_ALTERNATES = 5
DEFAULT_FTS_TOP_K = 50
DEFAULT_FUZZY_TOP_K = 12

# Ambiguity detection
DEFAULT_MARGIN_THRESHOLD = 0.15  # Trigger semantic if margin < this

# File paths
DEFAULT_DATA_DIR = "~/.resolvekit/data"
DEFAULT_CACHE_DIR = "~/.resolvekit/cache"

# Database configuration
DB_PRAGMAS = {
    "journal_mode": "OFF",
    "synchronous": "OFF",
    "temp_store": "MEMORY",
    "mmap_size": 268435456,  # ~256MB
    "cache_size": -100000,  # ~100MB
}

# FTS5 configuration
FTS5_TOKENIZER = "unicode61 remove_diacritics 2 tokenchars '.-'"
FTS5_PREFIX = "2,3"

# Performance targets (milliseconds)
TARGET_LATENCY_P50 = 10
TARGET_LATENCY_P95 = 50
TARGET_STARTUP_TIME = 5000  # 5 seconds

# Memory targets (MB)
TARGET_MEMORY_BASE = 2048  # 2GB
TARGET_MEMORY_EMBEDDINGS = 4096  # 4GB
TARGET_MEMORY_FULL = 6144  # 6GB

# Batch processing
DEFAULT_BATCH_SIZE = 1000
DEFAULT_NUM_WORKERS = 4

# Entity type hierarchy
ENTITY_TYPE_HIERARCHY = {
    EntityType.COUNTRY: [
        EntityType.ADMIN1,
        EntityType.ADMIN2,
        EntityType.ADMIN3,
        EntityType.ADMIN4,
        EntityType.CITY,
    ],
    EntityType.ADMIN1: [
        EntityType.ADMIN2,
        EntityType.ADMIN3,
        EntityType.ADMIN4,
        EntityType.CITY,
    ],
    EntityType.ADMIN2: [EntityType.ADMIN3, EntityType.ADMIN4, EntityType.CITY],
    EntityType.ADMIN3: [EntityType.ADMIN4, EntityType.CITY],
    EntityType.ADMIN4: [EntityType.CITY],
    EntityType.ORGANIZATION: [EntityType.GROUP],
}

# Code system metadata
CODE_SYSTEMS = {
    "dcid": {
        "name": "Data Commons ID",
        "authority": "Google Data Commons",
        "format": r"^[a-zA-Z]+/[A-Z0-9]+$",
        "example": "country/USA",
    },
    "iso2": {
        "name": "ISO 3166-1 alpha-2",
        "authority": "ISO",
        "format": r"^[A-Z]{2}$",
        "example": "US",
    },
    "iso3": {
        "name": "ISO 3166-1 alpha-3",
        "authority": "ISO",
        "format": r"^[A-Z]{3}$",
        "example": "USA",
    },
    "iso_numeric": {
        "name": "ISO 3166-1 numeric",
        "authority": "ISO",
        "format": r"^\d{3}$",
        "example": "840",
    },
    "m49": {
        "name": "UN M49",
        "authority": "UN Statistics Division",
        "format": r"^\d{3}$",
        "example": "840",
    },
    "nuts": {
        "name": "NUTS codes",
        "authority": "Eurostat",
        "format": r"^[A-Z]{2}[A-Z0-9]{0,3}$",
        "example": "FR",
    },
    "pcode": {
        "name": "OCHA P-codes",
        "authority": "UN OCHA",
        "format": r"^[A-Z]{2}[A-Z0-9]+$",
        "example": "FR01",
    },
    "wikidata": {
        "name": "Wikidata QID",
        "authority": "Wikidata",
        "format": r"^Q\d+$",
        "example": "Q30",
    },
    "geonames": {
        "name": "GeoNames ID",
        "authority": "GeoNames",
        "format": r"^\d+$",
        "example": "6252001",
    },
}

# Source precedence (higher = higher priority)
SOURCE_PRECEDENCE = {
    "user": 100,
    "custom": 90,
    "datacommons": 80,
    "iso": 70,
    "un": 60,
    "eurostat": 60,
    "ocha": 60,
    "wikidata": 50,
    "geonames": 40,
    "other": 10,
}

# Overlay precedence ranges
OVERLAY_PRECEDENCE = {
    "user": (100, 999),
    "org": (10, 99),
    "base": (0, 0),
}

# Calibration features
CALIBRATION_FEATURES = [
    "f_exact_code",
    "f_canonical_exact",
    "f_alias_exact",
    "f_alias_type_canonical",
    "f_alias_type_endonym",
    "f_alias_type_exonym",
    "f_alias_type_abbr",
    "f_alias_type_code",
    "f_fts_score",
    "f_fts_rank_inv",
    "f_edit_distance_norm",
    "f_trigram_jaccard",
    "f_parent_valid",
    "f_type_valid",
    "f_date_valid",
    "f_sem_used",
    "f_sem_sim",
    "f_ambiguity_flag",
    "f_region_hint_match",
]

# Known ambiguous terms (partial list - full list in ambiguity registry)
KNOWN_AMBIGUOUS = {
    "georgia": ["country/GEO", "geoId/13"],
    "congo": ["country/COD", "country/COG"],
    "guinea": ["country/GIN", "country/GNQ", "country/GNB", "country/PNG"],
    "korea": ["country/KOR", "country/PRK"],
    "macedonia": ["country/MKD", "geoId/GR-MAC"],
    "springfield": [],  # Too many to list
}

# Common stopwords that aren't entities
ENTITY_STOPWORDS = {
    # Months
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
    # Days
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
    # Common words that look like places
    "reading",
    "normal",
    "mobile",
    "phoenix",  # Problematic: city vs. mythical bird
    "aurora",
    "victoria",  # Problematic: can be place
    # Directions
    "north",
    "south",
    "east",
    "west",
}

# Data pack manifest schema version
MANIFEST_SCHEMA_VERSION = "1.0.0"

# Supported languages (ISO 639-1 codes)
SUPPORTED_LANGUAGES = [
    "en",  # English
    "es",  # Spanish
    "fr",  # French
    "de",  # German
    "it",  # Italian
    "pt",  # Portuguese
    "nl",  # Dutch
    "ru",  # Russian (Cyrillic script)
    "ar",  # Arabic (Arabic script)
    "zh",  # Chinese (CJK)
    "ja",  # Japanese (CJK)
    "ko",  # Korean (Hangul)
]

# Logging configuration
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# API defaults
API_RATE_LIMIT = 100  # requests per second
API_TIMEOUT = 30  # seconds
API_MAX_BATCH_SIZE = 10000

# CLI defaults
CLI_MAX_DISPLAY_ALTERNATES = 5
CLI_COLOR_PRIMARY = "blue"
CLI_COLOR_SUCCESS = "green"
CLI_COLOR_WARNING = "yellow"
CLI_COLOR_ERROR = "red"
