# Builders Module

## Purpose

The builders module contains tools for building data packs from source data, including ETL pipelines, validation, and packaging.

## Components

### Core Builders

1. **Pack Builder** (`pack_builder.py`)
   - Orchestrates full data pack build process
   - Runs extract, transform, validate, enrich, package stages
   - Generates manifests and checksums

2. **Schema Builder** (`schema_builder.py`)
   - Creates SQLite databases with proper schema
   - Builds FTS5 indexes
   - Applies optimizations (PRAGMA, indexes)

3. **Calibration Trainer** (`calibration_trainer.py`)
   - Trains calibration models on labeled data
   - Evaluates model quality (ECE, Brier score)
   - Exports models to JSON

4. **Sidecar Builder** (`sidecar_builder.py`)
   - Builds ambiguity sidecar (HNSW index)
   - Curates ambiguous aliases
   - Generates embeddings and quantizes (Phase E)

### ETL Pipeline

- `extractors.py`: Extract data from sources (APIs, dumps, files)
- `transformers.py`: Normalize, align, resolve conflicts
- `validators.py`: Referential integrity, format validation
- `enrichers.py`: Derive hierarchies, compute statistics
- `packagers.py`: Create archives, generate metadata

### Data Sources

- `sources/`: Source-specific extractors
  - `data_commons.py`: Data Commons entity extraction
  - `iso.py`: ISO 3166 codes
  - `wikidata.py`: Wikidata aliases and temporal data
  - `geonames.py`: GeoNames data
  - `custom.py`: Custom data ingestion

### Quality Assurance

- `quality_checks.py`: Data quality validation
- `coverage_metrics.py`: Coverage analysis
- `conflict_resolver.py`: Handle source conflicts
- `deduplicator.py`: Entity deduplication

## Build Pipeline Stages

### 1. Extract

```python
# Extract from multiple sources
entities_dc = extract_data_commons()
entities_iso = extract_iso_codes()
entities_wd = extract_wikidata()
```

### 2. Transform

```python
# Normalize and align entities
entities = align_entities(entities_dc, entities_iso, entities_wd)
entities = normalize_text(entities)
entities = resolve_conflicts(entities, precedence_rules)
```

### 3. Validate

```python
# Validate data quality
check_referential_integrity(entities)
check_code_formats(entities)
check_temporal_consistency(entities)
flag_suspicious_data(entities)
```

### 4. Enrich

```python
# Compute derived data
compute_hierarchy_paths(entities)
build_fts_indexes(entities)
generate_statistics(entities)
```

### 5. Package

```python
# Create data pack
export_to_sqlite(entities, "base.sqlite")
build_manifest(pack_info)
compute_checksums(files)
create_archive("resolvekit-data-1.2.0.tar.gz")
```

## CLI for Building

```bash
# Build full data pack
resolvekit-build pack \
    --sources wikidata,iso,datacommons \
    --output packs/1.2.0/ \
    --validate

# Build overlay from CSV
resolvekit-build overlay \
    --input custom_aliases.csv \
    --name my-custom-pack \
    --output overlays/

# Train calibration model
resolvekit-build calibration \
    --training-data labeled_pairs.csv \
    --output calibration.json

# Build ambiguity sidecar
resolvekit-build sidecar \
    --registry ambiguity_registry.csv \
    --base base.sqlite \
    --output ambiguity.hnsw
```

## Manifest Generation

```python
manifest = {
    "pack_name": "resolvekit-core-countries",
    "version": "1.2.0",
    "build_time": datetime.now(UTC).isoformat(),
    "schema_hash": compute_schema_hash(),
    "sources": [
        {"name": "DataCommons", "snapshot": "2025-09-15"},
        {"name": "ISO3166", "snapshot": "2025-09-01"}
    ],
    "components": {
        "base_sqlite": "base.sqlite",
        "fts_built": True,
        "ambiguity_registry": True,
        "calibration": "calibration.json"
    },
    "checksums": {
        "base.sqlite": compute_sha256("base.sqlite"),
        "calibration.json": compute_sha256("calibration.json")
    },
    "license": "CC-BY 4.0 (data), Apache-2.0 (code)",
    "compat": {
        "resolver_min": "0.9.0",
        "resolver_max": "<2.0.0"
    }
}
```

## Design Principles

1. **Automated**: CI/CD pipeline for regular builds
2. **Reproducible**: Same sources → same output
3. **Validated**: Quality gates prevent bad data
4. **Versioned**: Semantic versioning for packs

## Implementation Priority

**Phase A** - Basic schema builder
**Phase C** - Overlay builders
**Phase D** - Full pack building and distribution
**Phase E** - Sidecar builder
