# Overlays Module

## Purpose

The overlays module manages custom data packs that extend or override the base data pack. Overlays enable users to install domain-specific packs (e.g., humanitarian-orgs-pack, schools-pack, corporate-entities-pack) or create their own custom aliases and entities.

## Components

### Core Components

1. **Overlay Manager** (`overlay_manager.py`)
   - Load and attach overlay databases
   - Manage precedence rules
   - Handle overlay conflicts

2. **Overlay Writer** (`overlay_writer.py`)
   - Create new overlay packs
   - Add/update aliases, entities, memberships
   - Build FTS indexes for overlays

3. **Overlay Validator** (`validator.py`)
   - Validate overlay schemas
   - Check for conflicts with base pack
   - Verify referential integrity

4. **Overlay Merger** (`merger.py`)
   - Merge queries across base + overlays
   - Apply precedence rules
   - Deduplicate results

### Data Models

- `overlay_config.py`: Overlay configuration and metadata
- `precedence.py`: Precedence rule engine

## Overlay Structure

Each overlay is a SQLite database with the same schema as base pack:

```
my-overlay.sqlite
├── entities (custom entities only)
├── aliases (custom aliases + overrides)
├── aliases_fts (FTS index)
├── codes (custom codes)
├── memberships (custom memberships)
└── manifest (overlay metadata)
```

## Overlay Manifest

```json
{
  "pack_name": "humanitarian-orgs.overlay",
  "version": "0.3.0",
  "base_compat": ">=1.2.0",
  "components": {
    "overlay_sqlite": "humanitarian-orgs.overlay.sqlite",
    "fts_built": true,
    "calibration_delta": null
  },
  "description": "Humanitarian organization names and aliases",
  "author": "OCHA",
  "created": "2025-10-20T10:00:00Z"
}
```

**Note:** Precedence is not stored in the manifest. It's determined by the order in which overlays are loaded (earlier in list = higher precedence).

## Precedence Rules

Precedence is determined by the order in the overlays list:

- **First overlay in list**: Highest precedence (100)
- **Second overlay**: Precedence 99
- **Third overlay**: Precedence 98
- **...and so on** (max 5 overlays)
- **Base pack**: Precedence 0 (lowest)

When the same alias maps to different entities:
1. Use the highest precedence mapping (earliest in the list)
2. Log warning about conflict
3. Optional: Surface conflict to user for resolution

**Example:**
```python
resolver = Resolver(overlays=["personal.sqlite", "humanitarian.sqlite", "schools.sqlite"])
# personal.sqlite: precedence 100 (highest)
# humanitarian.sqlite: precedence 99
# schools.sqlite: precedence 98
# base pack: precedence 0 (lowest)
```

## Creating Overlays

### From CSV

```python
from resolvekit.overlays import OverlayWriter

# Create overlay from CSV
writer = OverlayWriter("my-overlay")

# Add aliases
writer.add_aliases_from_csv("custom_aliases.csv")
# CSV columns: dcid, alias_text, alias_type, language

# Add custom entities
writer.add_entities_from_csv("custom_entities.csv")
# CSV columns: dcid, canonical_name, entity_type, parent_dcid

# Add memberships
writer.add_memberships_from_csv("memberships.csv")
# CSV columns: entity_dcid, group_dcid, valid_from, valid_until

# Build and save
writer.build("my-overlay.sqlite")
```

### From YAML

```yaml
# custom_data.yaml
entities:
  - dcid: "custom/MyOrg"
    name: "My Organization"
    type: "organization"
    aliases:
      - "MyOrg"
      - "The Organization"
    codes:
      internal_id: "ORG-001"

  - dcid: "country/COD"  # Extend existing entity
    custom_aliases:
      - "Congo-Kinshasa"
      - "DROC"  # Internal shorthand

groups:
  - dcid: "custom/OurPartners"
    name: "Our Partner Countries"
    members:
      - country/KEN
      - country/TZA
      - country/UGA
```

### Via API

```python
from resolvekit.overlays import create_overlay

overlay = create_overlay(
    name="my-custom-overlay",
    base_pack_version="1.2.0"
)

# Add custom alias
overlay.add_alias(
    entity_dcid="country/COD",
    alias_text="Congo-Kinshasa",
    alias_type="exonym",
    language="en"
)

# Add custom entity
overlay.add_entity(
    dcid="custom/MyEntity",
    canonical_name="My Custom Entity",
    entity_type="organization"
)

# Save overlay
overlay.save("my-custom.overlay.sqlite")
```

**Note:** Precedence is determined when loading overlays into the Resolver, not when creating them.

## Loading Overlays

```python
from resolvekit.api import Resolver

# Load resolver with overlays (order = precedence)
resolver = Resolver(
    overlays=[
        "path/to/personal-customizations.sqlite",  # Highest precedence (100)
        "path/to/humanitarian-orgs.sqlite",        # Precedence 99
        "path/to/schools-pack.sqlite"              # Precedence 98
    ]
)

# Overlays are automatically applied to all queries
result = resolver.resolve("DROC")  # Matches custom alias from highest-precedence overlay

# Maximum 5 overlays supported
# Order in the list determines precedence (first = highest)
```

## Conflict Resolution

When conflicts detected:

```python
# Log warning
logger.warning(
    "Alias 'Georgia' maps to both country/GEO (precedence: 0) "
    "and geoId/13 (precedence: 50). Using geoId/13."
)

# Optionally return conflict info
result = resolver.resolve("Georgia", return_conflicts=True)
if result.conflicts:
    print(f"Conflicts: {result.conflicts}")
```

## Design Principles

1. **Non-destructive**: Overlays don't modify base pack
2. **Composable**: Multiple overlays can coexist
3. **Validated**: Schema validation on overlay creation
4. **Transparent**: Clear precedence rules, conflict reporting

## Implementation Priority

**Phase C** - Overlay system and builders
