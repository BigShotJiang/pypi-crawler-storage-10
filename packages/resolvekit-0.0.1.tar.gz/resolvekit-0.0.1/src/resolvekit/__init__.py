"""
resolvekit - An open offline resolver for places and entities.

resolvekit is a local, offline-first entity and place resolution system that maps
messy place/entity strings and codes to canonical entities with calibrated
confidence scores.
"""

from resolvekit.api import Resolver, resolve, resolve_many
from resolvekit.config import ResolvekitConfig
from resolvekit.constants import VERSION
from resolvekit.types import (
    AliasType,
    Candidate,
    CodeSystem,
    Entity,
    EntityType,
    Explanation,
    ExplanationMode,
    ExtractedEntity,
    MatchContext,
    Membership,
    OutputFormat,
    Resolution,
)

__version__ = VERSION

__all__ = [
    "VERSION",
    "AliasType",
    "Candidate",
    "CodeSystem",
    "Entity",
    "EntityType",
    "Explanation",
    "ExplanationMode",
    "ExtractedEntity",
    "MatchContext",
    "Membership",
    "ResolvekitConfig",
    "OutputFormat",
    "Resolution",
    "Resolver",
    "__version__",
    "resolve",
    "resolve_many",
]


def main() -> None:
    """CLI entry point."""
    # Import here to avoid circular imports
    from resolvekit.cli.main import cli

    cli()


# Package metadata
__author__ = "Jorge Rivera"
__email__ = "jorge.rivera@one.org"
__license__ = "MIT"
__description__ = (
    "A local, offline-first entity and place resolution system that maps "
    "messy place/entity strings and codes to canonical entities with "
    "calibrated confidence scores"
)
