"""Database connection manager."""

from contextlib import AbstractContextManager, suppress
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import StaticPool

if TYPE_CHECKING:
    from sqlalchemy.engine import Connection

from resolvekit.utils.logging import get_logger

logger = get_logger(__name__)


class DatabaseManager:
    """
    Manages SQLite database connections with overlay support.

    Handles:
    - Connection creation with SQLAlchemy
    - Performance PRAGMA application
    - Overlay database attachment
    - Transaction management
    """

    def __init__(
        self,
        base_path: Path,
        overlays: list[Path] | None = None,
        read_only: bool = True,
    ):
        """
        Initialize database manager.

        Args:
            base_path: Path to base database file
            overlays: Optional list of overlay databases (max 5, ordered by precedence)
            read_only: Whether database is read-only

        Raises:
            ValueError: If database paths are not unique or too many overlays
        """
        # Validate overlay count
        if overlays and len(overlays) > 5:
            raise ValueError(
                f"Maximum 5 overlays supported, got {len(overlays)}. "
                "Too many overlays can impact performance."
            )

        # Validate that all paths are unique
        paths = [base_path]
        if overlays:
            paths.extend(overlays)

        # Resolve paths to catch symbolic links and relative paths
        resolved_paths = [p.resolve() for p in paths]

        if len(resolved_paths) != len(set(resolved_paths)):
            raise ValueError(
                f"Database paths must be unique. Got duplicates in: {paths}"
            )

        self.base_path = base_path
        self.overlay_paths = overlays or []
        self.read_only = read_only
        self.overlays: list[tuple[str, int]] = []
        self.engine: Engine | None = None

    def connect(self) -> None:
        """Initialize connection with pragmas and overlay attachment."""
        # Create SQLAlchemy engine
        uri = f"sqlite:///{self.base_path}"
        self.engine = create_engine(
            uri,
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
            echo=False,
        )

        # Apply pragmas
        self._apply_pragmas()

        # Attach overlays
        self._attach_overlays()

    def _apply_pragmas(self) -> None:
        """Apply performance pragmas from CLAUDE.md."""
        if not self.engine:
            raise RuntimeError("Engine not initialized")

        pragmas = [
            "PRAGMA foreign_keys=ON",
            "PRAGMA journal_mode=OFF",
            "PRAGMA synchronous=OFF",
            "PRAGMA temp_store=MEMORY",
            "PRAGMA mmap_size=268435456",
            "PRAGMA cache_size=-100000",
        ]

        # Add read-only enforcement if requested
        if self.read_only:
            pragmas.append("PRAGMA query_only=ON")

        with self.engine.connect() as conn:
            for pragma in pragmas:
                conn.execute(text(pragma))
            conn.commit()

    def _attach_overlays(self) -> None:
        """
        Attach overlay databases with precedence tracking.

        Precedence is assigned based on list order:
        - First overlay: precedence 100 (highest)
        - Second overlay: precedence 99
        - Third overlay: precedence 98
        - etc.
        """
        if not self.engine:
            raise RuntimeError("Engine not initialized")

        # Clear overlays list to prevent duplicates on reconnect
        self.overlays.clear()

        with self.engine.connect() as conn:
            # Attach overlays in order, assigning descending precedence
            for idx, overlay_path in enumerate(self.overlay_paths):
                schema_name = f"overlay_{idx}"
                precedence = 100 - idx  # First=100, second=99, etc.

                conn.execute(text(f"ATTACH DATABASE '{overlay_path}' AS {schema_name}"))
                self.overlays.append((schema_name, precedence))

            conn.commit()

    def execute(self, query: str, params: dict[str, Any] | None = None) -> Any:
        """
        Execute a query.

        Args:
            query: SQL query string
            params: Optional parameters dict

        Returns:
            List of Row objects for SELECT queries, empty list for non-SELECT
        """
        if not self.engine:
            raise RuntimeError("Database not connected. Call connect() first.")

        with self.engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            conn.commit()
            # Consume results before connection closes (if query returns rows)
            if result.returns_rows:
                return result.fetchall()
            return []

    def transaction(self) -> AbstractContextManager["Connection"]:
        """
        Get transaction context manager.

        Returns:
            Transaction context manager
        """
        if not self.engine:
            raise RuntimeError("Database not connected. Call connect() first.")

        return self.engine.begin()

    def close(self) -> None:
        """Close database connection and detach overlays."""
        if self.engine:
            # Detach overlays before disposing engine
            if self.overlays:
                try:
                    with self.engine.connect() as conn:
                        for overlay_name, _ in self.overlays:
                            conn.execute(text(f"DETACH DATABASE {overlay_name}"))
                        conn.commit()
                except Exception as e:
                    # Log but don't fail - connection may already be closed
                    logger.debug(f"Error detaching overlays during close: {e}")
                finally:
                    self.overlays.clear()

            self.engine.dispose()
            self.engine = None

    def __del__(self) -> None:
        """Cleanup: Close database connection when object is garbage collected."""
        with suppress(Exception):
            self.close()
