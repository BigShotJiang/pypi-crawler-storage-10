# Data Module

## Purpose

The data module handles all data storage, retrieval, and management including SQLite database operations, data pack loading, and overlay management.

## Components

### Core Components

1. **Database Manager** (`db_manager.py`)
   - SQLite connection management
   - PRAGMA configuration for performance
   - Database attachment (base + overlays)
   - Transaction management

2. **Schema** (`schema.py`)
   - SQL schema definitions for all tables
   - FTS5 virtual table configuration
   - Indexes and constraints
   - Migration utilities

3. **Models** (`models.py`)
   - Python data classes for entities, aliases, codes, etc.
   - ORM-like interface (or raw SQL with dataclass mapping)
   - Type-safe data access

4. **Loaders** (`loaders.py`)
   - Load entities, aliases, codes from SQLite
   - Cache frequently accessed data
   - Lazy loading for large datasets

5. **Query Builder** (`query_builder.py`)
   - Construct SQL queries for various operations
   - Handle union queries across base + overlays
   - FTS query construction with proper escaping

### Data Access Layer

- `entities.py`: Entity CRUD operations
- `aliases.py`: Alias lookup and search
- `codes.py`: Code system lookups
- `hierarchies.py`: Hierarchy traversal queries
- `memberships.py`: Group membership queries
- `provenance.py`: Data source attribution

## Database Schema

### Main Tables

```sql
-- Entities table
CREATE TABLE entities (
    dcid TEXT PRIMARY KEY,
    canonical_name TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    parent_dcid TEXT,
    centroid_lat REAL,
    centroid_lon REAL,
    valid_from TEXT,
    valid_until TEXT,
    FOREIGN KEY (parent_dcid) REFERENCES entities(dcid)
);

-- Aliases table
CREATE TABLE aliases (
    alias_id INTEGER PRIMARY KEY,
    entity_dcid TEXT NOT NULL,
    alias_text TEXT NOT NULL,
    alias_norm TEXT NOT NULL,
    language TEXT,
    alias_type TEXT CHECK(alias_type IN ('canonical','endonym','exonym','abbr','code')),
    valid_from TEXT,
    valid_until TEXT,
    source TEXT,
    alias_uid TEXT UNIQUE,
    FOREIGN KEY (entity_dcid) REFERENCES entities(dcid)
);

-- FTS5 virtual table
CREATE VIRTUAL TABLE aliases_fts USING fts5(
    alias_norm,
    content='aliases',
    content_rowid='alias_id',
    tokenize = "unicode61 remove_diacritics 2 tokenchars '.-'",
    prefix='2,3'
);

-- Codes table
CREATE TABLE codes (
    entity_dcid TEXT NOT NULL,
    code_system TEXT NOT NULL,
    code_value TEXT NOT NULL,
    valid_from TEXT,
    valid_until TEXT,
    source TEXT,
    PRIMARY KEY (entity_dcid, code_system),
    FOREIGN KEY (entity_dcid) REFERENCES entities(dcid)
);

-- Memberships table
CREATE TABLE memberships (
    id INTEGER PRIMARY KEY,
    entity_dcid TEXT NOT NULL,
    group_dcid TEXT NOT NULL,
    valid_from TEXT NOT NULL,
    valid_until TEXT,
    source TEXT,
    FOREIGN KEY (entity_dcid) REFERENCES entities(dcid),
    FOREIGN KEY (group_dcid) REFERENCES entities(dcid)
);

-- Ambiguity registry
CREATE TABLE ambiguity (
    surface TEXT PRIMARY KEY,
    types TEXT,
    notes TEXT
);

-- Provenance table
CREATE TABLE provenance (
    id INTEGER PRIMARY KEY,
    entity_dcid TEXT NOT NULL,
    field TEXT,
    source TEXT,
    license TEXT,
    quality INTEGER,
    last_updated TEXT,
    FOREIGN KEY (entity_dcid) REFERENCES entities(dcid)
);
```

## SQLite Configuration

Performance pragmas applied on connection:

```python
PRAGMA journal_mode=OFF;
PRAGMA synchronous=OFF;
PRAGMA temp_store=MEMORY;
PRAGMA mmap_size=268435456;  # ~256MB
PRAGMA cache_size=-100000;   # ~100MB
```

## Overlay Precedence

When querying across base + overlays:

1. User overlays (precedence: 100+)
2. Organization overlays (precedence: 10-99)
3. Base pack (precedence: 0)

Queries use `UNION ALL` with deduplication by `alias_uid` or `dcid`, keeping highest precedence.

## Design Principles

1. **Read-optimized**: Pre-built indexes, no writes at runtime
2. **Efficient caching**: Cache hot data (codes, popular entities)
3. **Overlay transparency**: Queries automatically span all attached databases
4. **Type safety**: Use dataclasses for structured data access

## Implementation Priority

**Phase A** - Core resolver (schema, basic loaders)
**Phase C** - Overlay system
