"""Entity repository."""

from datetime import date
from typing import Any, ClassVar, overload

from resolvekit.data.context_filters import ContextFilterBuilder
from resolvekit.data.db_manager import DatabaseManager
from resolvekit.data.query_builder import QueryBuilder
from resolvekit.types import Entity, EntityRow, MatchContext


class EntityRepository:
    """Repository for entity operations."""

    # Derive column list from EntityRow model (single source of truth)
    ENTITY_COLUMNS: ClassVar[list[str]] = list(EntityRow.model_fields.keys())

    def __init__(self, db_manager: DatabaseManager):
        """
        Initialize repository.

        Args:
            db_manager: Database manager instance
        """
        self.db = db_manager
        self.query_builder = QueryBuilder(db_manager)

    @overload
    def find_by_dcid(
        self,
        dcid: str,
        as_of: date | None = None,
        include_codes: bool = False,
    ) -> Entity | None: ...

    @overload
    def find_by_dcid(
        self,
        dcid: list[str],
        as_of: date | None = None,
        include_codes: bool = False,
    ) -> dict[str, Entity]: ...

    def find_by_dcid(
        self,
        dcid: str | list[str],
        as_of: date | None = None,
        include_codes: bool = False,
    ) -> Entity | None | dict[str, Entity]:
        """
        Find entity by DCID.

        Args:
            dcid: Single DCID or list of DCIDs
            as_of: Optional date for temporal filtering
            include_codes: Whether to include code mappings

        Returns:
            Single entity, dict of entities, or None
        """
        if isinstance(dcid, str):
            return self._find_single_by_dcid(dcid, as_of, include_codes)
        else:
            return self._find_batch_by_dcid(dcid, as_of, include_codes)

    def _find_single_by_dcid(
        self,
        dcid: str,
        as_of: date | None = None,
        include_codes: bool = False,
    ) -> Entity | None:
        """Find single entity by DCID."""
        sql, params = self.query_builder.build_union_query(
            table="entities",
            columns=self.ENTITY_COLUMNS,
            where_clause="dcid = :dcid",
            params={"dcid": dcid},
            unique_key="dcid",
            as_of=as_of,
        )

        rows = self.db.execute(sql, params)

        if not rows:
            return None

        row = rows[0]
        entity = self._row_to_entity(row)

        # Load codes if requested
        if include_codes:
            self._load_codes_for_entities([entity])

        return entity

    def _find_batch_by_dcid(
        self,
        dcids: list[str],
        as_of: date | None = None,
        include_codes: bool = False,
    ) -> dict[str, Entity]:
        """Find multiple entities by DCID."""
        if not dcids:
            return {}

        # Build IN clause
        placeholders = ", ".join(f":dcid_{i}" for i in range(len(dcids)))
        params = {f"dcid_{i}": dcid for i, dcid in enumerate(dcids)}

        sql, params = self.query_builder.build_union_query(
            table="entities",
            columns=self.ENTITY_COLUMNS,
            where_clause=f"dcid IN ({placeholders})",
            params=params,
            unique_key="dcid",
            as_of=as_of,
        )

        result = self.db.execute(sql, params)

        entities = {}
        for row in result:
            entity = self._row_to_entity(row)
            entities[entity.dcid] = entity

        # Load codes if requested
        if include_codes and entities:
            self._load_codes_for_entities(list(entities.values()))

        return entities

    @overload
    def find_by_code(
        self, code_system: str, code_value: str, context: MatchContext | None = None
    ) -> Entity | None: ...

    @overload
    def find_by_code(
        self,
        code_system: str,
        code_value: list[str],
        context: MatchContext | None = None,
    ) -> dict[str, Entity]: ...

    def find_by_code(
        self,
        code_system: str,
        code_value: str | list[str],
        context: MatchContext | None = None,
    ) -> Entity | None | dict[str, Entity]:
        """
        Find entity by code.

        Args:
            code_system: Code system (e.g., "iso2", "iso3")
            code_value: Single code or list of codes
            context: Optional filtering context

        Returns:
            Single entity, dict of entities, or None
        """
        if isinstance(code_value, str):
            return self._find_single_by_code(code_system, code_value, context)
        else:
            return self._find_batch_by_code(code_system, code_value, context)

    def _find_single_by_code(
        self, code_system: str, code_value: str, context: MatchContext | None = None
    ) -> Entity | None:
        """Find single entity by code."""
        sql, params = self.query_builder.build_code_lookup_union(
            code_system=code_system,
            code_values=code_value,
            entity_columns=self.ENTITY_COLUMNS,
            include_code_value=False,
        )

        # Apply context filters if provided
        if context:
            # Build context filters (no table prefix - subquery columns don't have aliases)
            temporal_filter, type_filter, parent_filter = (
                ContextFilterBuilder.build_filters(context, params, table_prefix="")
            )
            # Wrap the union query and apply filters
            sql = f"""
                SELECT * FROM ({sql}) AS filtered
                WHERE 1=1
                {temporal_filter}
                {type_filter}
                {parent_filter}
            """

        # Order by precedence DESC to respect overlay precedence
        sql += "\nORDER BY precedence DESC LIMIT 1"

        rows = self.db.execute(sql, params)

        if not rows:
            return None

        row = rows[0]
        return self._row_to_entity(row)

    def _find_batch_by_code(
        self,
        code_system: str,
        code_values: list[str],
        context: MatchContext | None = None,
    ) -> dict[str, Entity]:
        """Find multiple entities by code."""
        if not code_values:
            return {}

        sql, params = self.query_builder.build_code_lookup_union(
            code_system=code_system,
            code_values=code_values,
            entity_columns=self.ENTITY_COLUMNS,
            include_code_value=True,
        )

        # Apply context filters if provided
        if context:
            # Build context filters (no table prefix - subquery columns don't have aliases)
            temporal_filter, type_filter, parent_filter = (
                ContextFilterBuilder.build_filters(context, params, table_prefix="")
            )
            # Wrap the union query and apply filters
            sql = f"""
                SELECT * FROM ({sql}) AS filtered
                WHERE 1=1
                {temporal_filter}
                {type_filter}
                {parent_filter}
            """

        # Order by code_value and precedence to group overlays together
        sql += "\nORDER BY code_value, precedence DESC"

        result = self.db.execute(sql, params)

        # Deduplicate by code_value, keeping highest precedence
        entities = {}
        for row in result:
            code_val = row.code_value
            # Only add if we haven't seen this code_value or this has higher precedence
            if code_val not in entities:
                entity = self._row_to_entity(row)
                entities[code_val] = entity

        return entities

    def get_parent(self, dcid: str, as_of: date | None = None) -> Entity | None:
        """
        Get parent entity.

        Args:
            dcid: Entity DCID
            as_of: Optional date for temporal filtering

        Returns:
            Parent entity or None
        """
        # Optimized single-query version using JOIN
        entity_cols = ", ".join(f"parent.{col}" for col in self.ENTITY_COLUMNS)

        # Build temporal filter if needed
        temporal_filter = ""
        params: dict[str, Any] = {"dcid": dcid}
        if as_of is not None:
            # Apply temporal filter to BOTH child and parent to ensure correct historical row selection
            temporal_filter = """
                AND (child.valid_from IS NULL OR child.valid_from <= :as_of)
                AND (child.valid_until IS NULL OR child.valid_until >= :as_of)
                AND (parent.valid_from IS NULL OR parent.valid_from <= :as_of)
                AND (parent.valid_until IS NULL OR parent.valid_until >= :as_of)
            """
            params["as_of"] = as_of.isoformat()

        # Query from main database
        sql = f"""
            SELECT {entity_cols}, 0 AS precedence, 'main' AS source_db
            FROM main.entities child
            INNER JOIN main.entities parent ON child.parent_dcid = parent.dcid
            WHERE child.dcid = :dcid{temporal_filter}
        """

        # Add overlays if present (join child from any source with parent from any source)
        for schema_name, precedence in self.db.overlays:
            # Child in overlay, parent in overlay
            sql += f"""
                UNION ALL
                SELECT {entity_cols}, {precedence} AS precedence, '{schema_name}' AS source_db
                FROM {schema_name}.entities child
                INNER JOIN {schema_name}.entities parent ON child.parent_dcid = parent.dcid
                WHERE child.dcid = :dcid{temporal_filter}
            """
            # Child in overlay, parent in main
            sql += f"""
                UNION ALL
                SELECT {entity_cols}, {precedence // 2} AS precedence, 'mixed' AS source_db
                FROM {schema_name}.entities child
                INNER JOIN main.entities parent ON child.parent_dcid = parent.dcid
                WHERE child.dcid = :dcid{temporal_filter}
            """
            # Child in main, parent in overlay (respect overlay precedence)
            sql += f"""
                UNION ALL
                SELECT {entity_cols}, {precedence} AS precedence, '{schema_name}' AS source_db
                FROM main.entities child
                INNER JOIN {schema_name}.entities parent ON child.parent_dcid = parent.dcid
                WHERE child.dcid = :dcid{temporal_filter}
            """

        # Order by precedence to get highest precedence result
        sql += "\nORDER BY precedence DESC LIMIT 1"

        rows = self.db.execute(sql, params)

        if not rows:
            return None

        row = rows[0]
        return self._row_to_entity(row)

    def get_children(self, dcid: str, as_of: date | None = None) -> list[Entity]:
        """
        Get child entities.

        Args:
            dcid: Parent entity DCID
            as_of: Optional date for temporal filtering

        Returns:
            List of child entities
        """
        sql, params = self.query_builder.build_union_query(
            table="entities",
            columns=self.ENTITY_COLUMNS,
            where_clause="parent_dcid = :parent_dcid",
            params={"parent_dcid": dcid},
            unique_key="dcid",
            as_of=as_of,
        )

        result = self.db.execute(sql, params)

        return [self._row_to_entity(row) for row in result]

    def _row_to_entity(self, row: Any) -> Entity:
        """Convert database row to Entity model via Pydantic validation."""
        # Convert SQLAlchemy Row to dict using only entity columns
        row_dict = {col: getattr(row, col) for col in self.ENTITY_COLUMNS}

        # Validate through EntityRow model
        entity_row = EntityRow.model_validate(row_dict)

        # Convert EntityRow to Entity (adding computed fields)
        return Entity(
            **entity_row.model_dump(),
            codes={},
            provenance={},
        )

    def find_by_canonical_name(
        self, normalized_canonical: str, context: MatchContext | None = None
    ) -> Entity | None:
        """
        Find entity by normalized canonical name.

        Uses the indexed normalized_canonical column for efficient lookups.

        Args:
            normalized_canonical: Normalized canonical name
            context: Optional filtering context

        Returns:
            Entity if found, None otherwise
        """
        params: dict[str, Any] = {"normalized": normalized_canonical}

        # Build context filters using shared utility
        temporal_filter, type_filter, parent_filter = (
            ContextFilterBuilder.build_filters(context, params, table_prefix="")
        )

        # Query from main database using indexed normalized_canonical column
        entity_cols = ", ".join(self.ENTITY_COLUMNS)
        sql = f"""
        SELECT {entity_cols}, 0 AS precedence
        FROM main.entities
        WHERE normalized_canonical = :normalized
        {temporal_filter}
        {type_filter}
        {parent_filter}
    """

        # Add overlays if present
        for schema_name, precedence in self.db.overlays:
            sql += f"""
            UNION ALL
            SELECT {entity_cols}, {precedence} AS precedence
            FROM {schema_name}.entities
            WHERE normalized_canonical = :normalized
            {temporal_filter}
            {type_filter}
            {parent_filter}
        """

        # Order by precedence to get highest precedence result
        sql += "\nORDER BY precedence DESC LIMIT 1"

        rows = self.db.execute(sql, params)

        if not rows:
            return None

        row = rows[0]
        return self._row_to_entity(row)

    def _load_codes_for_entities(self, entities: list[Entity]) -> None:
        """
        Load codes for entities and populate their codes dict in place.

        Args:
            entities: List of entities to load codes for
        """
        if not entities:
            return

        # Get all DCIDs
        dcids = [e.dcid for e in entities]

        # Build placeholders for IN clause
        placeholders = ", ".join(f":dcid_{i}" for i in range(len(dcids)))
        params = {f"dcid_{i}": dcid for i, dcid in enumerate(dcids)}

        # Query codes from main database
        sql = f"""
            SELECT entity_dcid, code_system, code_value
            FROM main.codes
            WHERE entity_dcid IN ({placeholders})
        """

        # Add overlays if present
        for schema_name, _ in self.db.overlays:
            sql += f"""
                UNION ALL
                SELECT entity_dcid, code_system, code_value
                FROM {schema_name}.codes
                WHERE entity_dcid IN ({placeholders})
            """

        result = self.db.execute(sql, params)

        # Group codes by entity_dcid
        codes_by_dcid: dict[str, dict[str, str]] = {}
        for row in result:
            dcid = row.entity_dcid
            if dcid not in codes_by_dcid:
                codes_by_dcid[dcid] = {}
            codes_by_dcid[dcid][row.code_system] = row.code_value

        # Populate codes in entities
        for entity in entities:
            if entity.dcid in codes_by_dcid:
                entity.codes = codes_by_dcid[entity.dcid]
