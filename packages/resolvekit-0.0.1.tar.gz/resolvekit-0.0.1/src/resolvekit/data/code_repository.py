"""Repository for code validation and lookup."""

from resolvekit.data.db_manager import DatabaseManager
from resolvekit.data.entity_repository import EntityRepository
from resolvekit.matchers.code_validators import get_validator
from resolvekit.types import CodeSystem, Entity, MatchContext


class CodeRepository:
    """Repository for code validation and lookup."""

    def __init__(self, db_manager: DatabaseManager, entity_repo: EntityRepository):
        """
        Initialize repository.

        Args:
            db_manager: Database manager instance
            entity_repo: Entity repository for lookups
        """
        self.db = db_manager
        self.entity_repo = entity_repo

    def validate_code(self, system: CodeSystem, value: str) -> tuple[bool, str | None]:
        """
        Validate code format using registered validator.

        Args:
            system: Code system
            value: Code value to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            validator = get_validator(system)
            return validator.validate(value)
        except KeyError:
            return False, f"Unsupported code system: {system}"

    def find_by_code(
        self, system: CodeSystem, value: str, context: MatchContext | None = None
    ) -> Entity | None:
        """
        Validate, normalize, then lookup entity by code.

        Args:
            system: Code system
            value: Code value
            context: Optional filtering context

        Returns:
            Entity if found, None otherwise
        """
        # Validate format
        is_valid, error = self.validate_code(system, value)
        if not is_valid:
            return None

        # Normalize code
        validator = get_validator(system)
        normalized_value = validator.normalize(value)

        # Special case: DCID is the entity primary key, not stored in codes table
        if system == CodeSystem.DCID:
            entity = self.entity_repo.find_by_dcid(
                dcid=normalized_value,
                as_of=context.as_of if context else None,
            )

            # Apply remaining context filters
            if entity and context:
                # Check entity_type filter
                if context.entity_type and entity.entity_type != context.entity_type:
                    return None

                # Check parent filter
                if context.parent_dcid and entity.parent_dcid != context.parent_dcid:
                    return None

            return entity

        # Lookup via EntityRepository.find_by_code (with context for SQL-level filtering)
        entity = self.entity_repo.find_by_code(system.value, normalized_value, context)

        return entity
