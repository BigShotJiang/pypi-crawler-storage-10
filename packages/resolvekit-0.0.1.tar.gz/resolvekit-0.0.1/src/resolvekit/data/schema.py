"""Database schema definitions using SQLModel.

Schema is automatically generated from SQLModel definitions:
- Table definitions in types.py (EntityRow, AliasRow, CodeRow, MembershipRow)
- Constraints, indexes, and foreign keys defined in SQLModel
- FTS5 virtual table requires raw SQL (SQLAlchemy doesn't support FTS5)
"""

from sqlalchemy import Index, text
from sqlalchemy.engine import Engine
from sqlmodel import SQLModel

from resolvekit.types import AliasRow, CodeRow, EntityRow, MembershipRow

# Schema version
SCHEMA_VERSION = 1

# ==============================================================================
# Indexes (additional indexes beyond those defined in SQLModel)
# ==============================================================================

# Note: Primary indexes are already defined in the SQLModel classes
# These are additional composite or coverage indexes

indexes = [
    Index("idx_entities_type", EntityRow.__table__.c.entity_type),
    Index("idx_entities_parent", EntityRow.__table__.c.parent_dcid),
    Index(
        "idx_entities_valid",
        EntityRow.__table__.c.valid_from,
        EntityRow.__table__.c.valid_until,
    ),
    Index("idx_aliases_dcid", AliasRow.__table__.c.entity_dcid),
    # idx_aliases_norm already defined in SQLModel via index=True
    Index("idx_aliases_type", AliasRow.__table__.c.alias_type),
    Index(
        "idx_codes_lookup",
        CodeRow.__table__.c.code_system,
        CodeRow.__table__.c.code_value,
    ),
    Index(
        "idx_memberships_entity",
        MembershipRow.__table__.c.entity_dcid,
        MembershipRow.__table__.c.valid_from,
        MembershipRow.__table__.c.valid_until,
    ),
    Index("idx_memberships_group", MembershipRow.__table__.c.group_dcid),
]

# ==============================================================================
# FTS Virtual Table (requires raw SQL)
# ==============================================================================

# FTS5 virtual tables must be created with raw SQL
# (SQLAlchemy doesn't have native FTS5 support)
ALIASES_FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS aliases_fts USING fts5(
    alias_norm,
    content='aliases',
    content_rowid='alias_id',
    tokenize = "unicode61 remove_diacritics 2 tokenchars '.-'",
    prefix='2,3'
)
"""


def create_schema(engine: Engine) -> None:
    """
    Create database schema with all tables and indexes.

    Uses SQLModel metadata to create tables, then raw SQL for FTS5.

    Args:
        engine: SQLAlchemy engine
    """
    # Create all tables via SQLModel metadata
    SQLModel.metadata.create_all(engine)

    # Create additional indexes
    for index in indexes:
        index.create(engine, checkfirst=True)

    # Create FTS virtual table (requires raw SQL)
    with engine.connect() as conn:
        conn.execute(text(ALIASES_FTS_SQL))

        # Create schema_version table manually (not a SQLModel)
        conn.execute(
            text("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        )

        # Insert schema version if not exists
        result = conn.execute(text("SELECT COUNT(*) FROM schema_version"))
        if result.fetchone()[0] == 0:
            conn.execute(
                text("INSERT INTO schema_version (version) VALUES (:version)"),
                {"version": SCHEMA_VERSION},
            )
        conn.commit()


def get_schema_version(engine: Engine) -> int:
    """
    Get current schema version.

    Args:
        engine: SQLAlchemy engine

    Returns:
        Schema version number
    """
    with engine.connect() as conn:
        result = conn.execute(
            text("SELECT version FROM schema_version ORDER BY updated_at DESC LIMIT 1")
        )
        row = result.fetchone()
        return row[0] if row else 0
