"""Query builder for overlay precedence."""

from datetime import date
from typing import Any


class QueryBuilder:
    """
    Builds SQL queries with overlay precedence support.

    Constructs UNION queries across main + overlay databases,
    with deduplication keeping highest precedence.
    """

    def __init__(self, db_manager: Any):
        """
        Initialize query builder.

        Args:
            db_manager: DatabaseManager instance
        """
        self.db = db_manager
        self.overlays = db_manager.overlays

    def build_union_query(
        self,
        table: str,
        columns: list[str],
        where_clause: str,
        params: dict[str, Any],
        unique_key: str,
        as_of: date | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """
        Build UNION query across all databases with deduplication.

        Args:
            table: Table name
            columns: Column names to select
            where_clause: WHERE clause (using named parameters)
            params: Query parameters
            unique_key: Column for deduplication (e.g., "dcid", "alias_uid")
            as_of: Optional date for temporal filtering

        Returns:
            Tuple of (SQL query, parameters dict)
        """
        queries = []
        col_list = ", ".join(columns)

        # Add temporal filtering to where clause if as_of is provided
        full_where = where_clause
        if as_of is not None:
            full_where += " AND (valid_from IS NULL OR valid_from <= :as_of)"
            full_where += " AND (valid_until IS NULL OR valid_until >= :as_of)"
            params = {**params, "as_of": as_of.isoformat()}

        # Main database (precedence 0)
        queries.append(f"""
            SELECT {col_list}, 0 AS precedence, 'main' AS source_db
            FROM main.{table}
            WHERE {full_where}
        """)

        # Overlay databases with their precedence
        for schema_name, precedence in self.overlays:
            queries.append(f"""
                SELECT {col_list}, {precedence} AS precedence, '{schema_name}' AS source_db
                FROM {schema_name}.{table}
                WHERE {full_where}
            """)

        # Union all results
        union_query = " UNION ALL ".join(queries)

        # Deduplicate by unique_key keeping highest precedence using window functions
        final_query = f"""
            WITH all_results AS ({union_query}),
            ranked AS (
                SELECT *, ROW_NUMBER() OVER (PARTITION BY {unique_key} ORDER BY precedence DESC) as rn
                FROM all_results
            )
            SELECT * FROM ranked WHERE rn = 1
            ORDER BY precedence DESC
        """

        return final_query, params

    def build_code_lookup_union(
        self,
        code_system: str,
        code_values: str | list[str],
        entity_columns: list[str],
        include_code_value: bool = False,
    ) -> tuple[str, dict[str, Any]]:
        """
        Build UNION query for code lookups across all databases.

        Args:
            code_system: Code system to search
            code_values: Single code value or list of code values
            entity_columns: Entity column names to select
            include_code_value: Whether to include code_value in results (for batch lookups)

        Returns:
            Tuple of (SQL query, parameters dict)
        """
        # Build column list
        entity_cols = ", ".join(f"e.{col}" for col in entity_columns)

        # Build CTE columns and WHERE clause
        is_batch = isinstance(code_values, list)
        params: dict[str, Any] = {"code_system": code_system}

        if is_batch:
            placeholders = ", ".join(f":code_{i}" for i in range(len(code_values)))
            params.update({f"code_{i}": code for i, code in enumerate(code_values)})
            where_clause = (
                f"code_system = :code_system AND code_value IN ({placeholders})"
            )
            cte_columns = (
                "entity_dcid, code_value" if include_code_value else "entity_dcid"
            )
        else:
            params["code_value"] = code_values
            where_clause = "code_system = :code_system AND code_value = :code_value"
            cte_columns = (
                "entity_dcid, code_value" if include_code_value else "entity_dcid"
            )

        # Select clause for results
        result_columns = (
            f"{entity_cols}, c.code_value" if include_code_value else entity_cols
        )

        # Build query for main database
        sql = f"""
            WITH code_lookup AS (
                SELECT {cte_columns}
                FROM main.codes
                WHERE {where_clause}
            )
            SELECT {result_columns}, 0 AS precedence, 'main' AS source_db
            FROM main.entities e
            INNER JOIN code_lookup c ON e.dcid = c.entity_dcid
        """

        # Add overlays
        for schema_name, precedence in self.overlays:
            sql += f"""
                UNION ALL
                SELECT {result_columns}, {precedence} AS precedence, '{schema_name}' AS source_db
                FROM {schema_name}.entities e
                INNER JOIN (
                    SELECT {cte_columns}
                    FROM {schema_name}.codes
                    WHERE {where_clause}
                ) c ON e.dcid = c.entity_dcid
            """

        return sql, params

    def escape_fts_query(self, query: str) -> str:
        """
        Escape FTS5 special characters.

        Args:
            query: Raw query string

        Returns:
            Escaped query string
        """
        # Escape double quotes
        escaped = query.replace('"', '""')

        # Wrap in quotes for phrase search
        return f'"{escaped}"'
