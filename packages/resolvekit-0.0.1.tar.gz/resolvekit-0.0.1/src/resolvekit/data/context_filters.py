"""Shared utilities for building SQL context filters."""

from typing import Any

from resolvekit.types import MatchContext


class ContextFilterBuilder:
    """Builder for SQL filter clauses from match context."""

    @staticmethod
    def build_filters(
        context: MatchContext | None,
        params: dict[str, Any],
        table_prefix: str = "",
    ) -> tuple[str, str, str]:
        """
        Build SQL filter clauses from match context.

        Args:
            context: Optional filtering context
            params: Parameters dict to update with filter values
            table_prefix: Optional table alias prefix (e.g., "e" or "")
                         Will be converted to "e." format if non-empty

        Returns:
            Tuple of (temporal_filter, type_filter, parent_filter) SQL clauses
        """
        prefix = f"{table_prefix}." if table_prefix else ""

        temporal_filter = ""
        if context and context.as_of:
            temporal_filter = f"""
                AND ({prefix}valid_from IS NULL OR {prefix}valid_from <= :as_of)
                AND ({prefix}valid_until IS NULL OR {prefix}valid_until >= :as_of)
            """
            params["as_of"] = context.as_of.isoformat()

        type_filter = ""
        if context and context.entity_type:
            type_filter = f"AND {prefix}entity_type = :entity_type"
            params["entity_type"] = context.entity_type.value

        parent_filter = ""
        if context and context.parent_dcid:
            parent_filter = f"AND {prefix}parent_dcid = :parent_dcid"
            params["parent_dcid"] = context.parent_dcid

        return temporal_filter, type_filter, parent_filter
