"""Repository for group membership queries."""

from datetime import date

from sqlalchemy import text
from sqlmodel import Session

from resolvekit.data.db_manager import DatabaseManager


class MembershipRepository:
    """Repository for querying group memberships with temporal support."""

    def __init__(self, db_manager: DatabaseManager):
        """
        Initialize repository.

        Args:
            db_manager: Database manager instance
        """
        self.db = db_manager

    def check_memberships_batch(
        self, entity_dcids: list[str], group_dcid: str, as_of: date
    ) -> set[str]:
        """
        Check which entities are members of a group at a given date.

        Uses a single batch query for efficiency. Respects overlay databases -
        if any source (base or overlay) indicates membership at the given date,
        the entity is considered a member.

        Args:
            entity_dcids: List of entity DCIDs to check
            group_dcid: Group DCID to check membership in
            as_of: Date to check membership at

        Returns:
            Set of entity DCIDs that are members of the group at the given date

        Raises:
            RuntimeError: If database is not connected
        """
        if not self.db.engine:
            raise RuntimeError("Database not connected. Call connect() first.")

        if not entity_dcids:
            return set()

        # Build parameterized query with IN clause
        placeholders = ", ".join(f":dcid_{i}" for i in range(len(entity_dcids)))

        # Build union of all membership sources (main + overlays)
        # Collect all rows first, then deduplicate by precedence
        all_sources = [
            f"""
            SELECT entity_dcid, group_dcid, valid_from, valid_until, 0 AS precedence
            FROM main.memberships
            WHERE entity_dcid IN ({placeholders})
              AND group_dcid = :group_dcid
            """
        ]

        for schema_name, precedence in self.db.overlays:
            all_sources.append(f"""
            SELECT entity_dcid, group_dcid, valid_from, valid_until, {precedence} AS precedence
            FROM {schema_name}.memberships
            WHERE entity_dcid IN ({placeholders})
              AND group_dcid = :group_dcid
            """)

        # Deduplicate by (entity_dcid, group_dcid) keeping highest precedence,
        # THEN apply temporal filter. This ensures overlay rows override base rows.
        query = text(f"""
            WITH best_memberships AS (
                SELECT entity_dcid, valid_from, valid_until
                FROM (
                    SELECT entity_dcid, group_dcid, valid_from, valid_until,
                           ROW_NUMBER() OVER (
                               PARTITION BY entity_dcid, group_dcid
                               ORDER BY precedence DESC
                           ) as rn
                    FROM (
                        {" UNION ALL ".join(all_sources)}
                    ) all_memberships
                ) ranked
                WHERE rn = 1
            )
            SELECT DISTINCT entity_dcid
            FROM best_memberships
            WHERE valid_from <= :as_of
              AND (valid_until IS NULL OR valid_until > :as_of)
        """)

        # Build parameters dict
        params = {
            "group_dcid": group_dcid,
            "as_of": as_of.isoformat(),
        }
        for i, dcid in enumerate(entity_dcids):
            params[f"dcid_{i}"] = dcid

        with Session(self.db.engine) as session:
            result = session.execute(query, params)
            members = {row[0] for row in result.fetchall()}

        return members
