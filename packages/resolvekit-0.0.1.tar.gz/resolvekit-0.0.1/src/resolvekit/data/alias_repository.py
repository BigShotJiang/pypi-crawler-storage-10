"""Repository for alias and FTS operations."""

from typing import Any, ClassVar

from resolvekit.data.context_filters import ContextFilterBuilder
from resolvekit.data.db_manager import DatabaseManager
from resolvekit.data.query_builder import QueryBuilder
from resolvekit.normalization.normalizer import TextNormalizer
from resolvekit.types import Entity, EntityRow, MatchContext


class AliasRepository:
    """Repository for alias and FTS operations."""

    # Derive column list from EntityRow model (single source of truth)
    ENTITY_COLUMNS: ClassVar[list[str]] = list(EntityRow.model_fields.keys())

    def __init__(self, db_manager: DatabaseManager, normalizer: TextNormalizer):
        """
        Initialize repository.

        Args:
            db_manager: Database manager instance
            normalizer: Text normalizer instance
        """
        self.db = db_manager
        self.normalizer = normalizer
        self.query_builder = QueryBuilder(db_manager)

    def find_exact_normalized(
        self, normalized: str, context: MatchContext | None = None
    ) -> list[tuple[Entity, str]]:
        """
        Find entities with exact normalized alias match.

        Performance:
        - Uses idx_aliases_norm index
        - UNION ALL for overlays (no deduplication in SQL)
        - Dedupe in Python by DCID (keep highest precedence)

        Args:
            normalized: Normalized alias string to match
            context: Optional filtering context

        Returns:
            List of (entity, matched_alias) tuples
        """
        params: dict[str, Any] = {"normalized": normalized}

        # Build context filters using shared utility
        temporal_filter, type_filter, parent_filter = (
            ContextFilterBuilder.build_filters(context, params, table_prefix="e")
        )

        # Query from main database
        entity_cols = ", ".join(f"e.{col}" for col in self.ENTITY_COLUMNS)
        sql = f"""
            SELECT {entity_cols}, a.alias_text, 0 AS precedence
            FROM main.aliases a
            JOIN main.entities e ON a.entity_dcid = e.dcid
            WHERE a.alias_norm = :normalized
            {temporal_filter}
            {type_filter}
            {parent_filter}
        """

        # Add overlays if present
        for schema_name, precedence in self.db.overlays:
            sql += f"""
                UNION ALL
                SELECT {entity_cols}, a.alias_text, {precedence} AS precedence
                FROM {schema_name}.aliases a
                JOIN {schema_name}.entities e ON a.entity_dcid = e.dcid
                WHERE a.alias_norm = :normalized
                {temporal_filter}
                {type_filter}
                {parent_filter}
            """

        # Order by precedence to prioritize overlays
        sql += "\nORDER BY precedence DESC"

        result = self.db.execute(sql, params)

        # Dedupe by DCID (keep first occurrence = highest precedence)
        seen_dcids = set()
        matches = []

        for row in result:
            entity = self._row_to_entity(row)

            if entity.dcid not in seen_dcids:
                seen_dcids.add(entity.dcid)
                matches.append((entity, row.alias_text))

        return matches

    def search_fts(
        self, query: str, limit: int = 50, context: MatchContext | None = None
    ) -> list[tuple[Entity, float, int]]:
        """
        FTS5 search with BM25 ranking.

        Performance:
        - LIMIT pushed to SQL
        - UNION ALL for overlays
        - ORDER BY rank LIMIT in SQL

        Args:
            query: Query string for FTS search
            limit: Maximum results to return
            context: Optional filtering context

        Returns:
            List of (entity, bm25_score, rank) tuples
        """
        params: dict[str, Any] = {"query": query}

        # Build context filters using shared utility
        temporal_filter, type_filter, parent_filter = (
            ContextFilterBuilder.build_filters(context, params, table_prefix="e")
        )

        # Entity columns for SELECT
        entity_cols = ", ".join(f"e.{col}" for col in self.ENTITY_COLUMNS)

        # Query from main database
        # Note: FTS5 rank is negative (closer to 0 = better)
        # fts.rank is equivalent to bm25(aliases_fts) in SQLite 3.20.0+
        sql = f"""
            SELECT {entity_cols}, fts.rank as rank, 0 AS precedence
            FROM main.aliases_fts fts
            JOIN main.aliases a ON fts.rowid = a.alias_id
            JOIN main.entities e ON a.entity_dcid = e.dcid
            WHERE fts.alias_norm MATCH :query
            {temporal_filter}
            {type_filter}
            {parent_filter}
        """

        # Add overlays if present
        for schema_name, precedence in self.db.overlays:
            sql += f"""
                UNION ALL
                SELECT {entity_cols}, fts.rank as rank, {precedence} AS precedence
                FROM {schema_name}.aliases_fts fts
                JOIN {schema_name}.aliases a ON fts.rowid = a.alias_id
                JOIN {schema_name}.entities e ON a.entity_dcid = e.dcid
                WHERE fts.alias_norm MATCH :query
                {temporal_filter}
                {type_filter}
                {parent_filter}
            """

        # Order by rank (ascending, since negative), then precedence
        # Apply generous SQL LIMIT to reduce memory/IO while leaving headroom for deduplication
        sql += f"""
            ORDER BY rank ASC, precedence DESC
            LIMIT {limit * 10}
        """

        result = self.db.execute(sql, params)

        # Dedupe by DCID (keep first occurrence = best rank + highest precedence)
        seen_dcids = set()
        matches = []
        rank = 1

        for row in result:
            entity = self._row_to_entity(row)

            if entity.dcid not in seen_dcids:
                seen_dcids.add(entity.dcid)
                # FTS rank is negative, convert to positive score
                bm25_score = abs(row.rank)
                matches.append((entity, bm25_score, rank))
                rank += 1

                # Stop once we have enough unique results
                if len(matches) >= limit:
                    break

        return matches

    def _row_to_entity(self, row: Any) -> Entity:
        """
        Convert database row to Entity model via Pydantic validation.

        Args:
            row: Database row object

        Returns:
            Validated Entity instance
        """
        # Convert SQLAlchemy Row to dict using only entity columns
        row_dict = {col: getattr(row, col) for col in self.ENTITY_COLUMNS}

        # Validate through EntityRow model
        entity_row = EntityRow.model_validate(row_dict)

        # Convert EntityRow to Entity (adding computed fields)
        return Entity(
            **entity_row.model_dump(),
            codes={},
            provenance={},
        )
