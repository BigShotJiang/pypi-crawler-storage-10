JWT_ALGORITHMS = 'jwt_algorithms'  # a comma-separated list of algorithms that are supported by PyJWT
