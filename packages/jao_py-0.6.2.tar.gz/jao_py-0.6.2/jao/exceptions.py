class NoMatchingDataError(Exception):
    pass
