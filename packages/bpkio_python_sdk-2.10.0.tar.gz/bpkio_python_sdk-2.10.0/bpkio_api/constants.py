from importlib.metadata import version

__version__ = version("bpkio-python-sdk")
api_client = f"bpkio-python-sdk/{__version__}"
