# unique-dict

A simple utility to remove duplicate dict entries across fiscal years.

## Installation
```bash
pip install unique-dict
