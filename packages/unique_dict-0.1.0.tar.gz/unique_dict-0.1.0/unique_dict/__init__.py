from .core import unique_dict

__all__ = ["unique_dict"]
__version__ = "0.1.0"
