def unique_dict(dict1, dict2, fy):
# Create a dictionary to keep track of the count of entries to delete for each unique key
	entries_to_delete = {}
	unique_dict = {}

	# Iterate through dict2 and count matching entries
	for entry2 in dict2[fy]:
		section2 = entry2["section"]
		date2 = entry2["date"]
		amount2 = entry2["amount"]

		key = (section2, date2, amount2)
		entries_to_delete[key] = entries_to_delete.get(key, 0) + 1

	# Iterate through dict1 and remove matching entries up to the counted limit
	new_dict1_entries = []

	for entry1 in dict1[fy]:
		section1 = entry1["section"]
		date1 = entry1["date"]
		amount1 = entry1["amount"]
		key = (section1, date1, amount1)
		if key in entries_to_delete and entries_to_delete[key] > 0:
			entries_to_delete[key] -= 1
		else:
			new_dict1_entries.append(entry1)
	unique_dict[fy] = new_dict1_entries
	return unique_dict
