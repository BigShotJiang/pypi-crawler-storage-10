# AI Shrey Codes

A Python package containing implementations of various AI algorithms including A* search, Alpha-Beta pruning, and graph traversal algorithms.

## Features

- **A* Informed Search**: Implementation of the A* pathfinding algorithm with visualization
- **Alpha-Beta Pruning**: Minimax algorithm with alpha-beta pruning optimization
- **Graph Traversal**: Breadth-First Search (BFS) and Depth-First Search (DFS) implementations

## Installation

```bash
pip install ai-shrey-codes
```

## Usage

### A* Search Algorithm

```python
from ai_shrey_codes import Node, a_star, visualize_graph_with_path_and_heuristic

# Define your graph and heuristic
neighbors = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('C', 2), ('D', 5)],
    'C': [('A', 4), ('B', 2), ('D', 1)],
    'D': [('B', 5), ('C', 1)]
}

heuristic = {
    'A': 7,
    'B': 6,
    'C': 2,
    'D': 0
}

# Create start and goal nodes
start_node = Node('A', g=0, h=heuristic['A'])
goal_node = Node('D')

# Find path using A*
path = a_star(start_node, goal_node, neighbors, heuristic)
print("Path:", path)

# Visualize the graph
visualize_graph_with_path_and_heuristic(neighbors, heuristic)
```

### Alpha-Beta Pruning

```python
from ai_shrey_codes import alpha_beta_pruning
import math

# Leaf node values for a complete binary tree
values = [10,5,7,11,12,8,9,8,5,12,11,12,9,8,7,10]
depth = 4  # Height of the tree

# Find optimal value using alpha-beta pruning
optimal_value = alpha_beta_pruning(depth, 0, True, values, -math.inf, math.inf)
print(f"The optimal value is: {optimal_value}")
```

### Graph Traversal

```python
from ai_shrey_codes import bfs, dfs

# Define your graph
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

# BFS traversal
print("BFS traversal:")
bfs(graph, 'A')

# DFS traversal
print("\nDFS traversal:")
dfs(graph, 'A')
```

## Requirements

- Python >= 3.8
- matplotlib >= 3.5.0
- networkx >= 2.6

## Development

To install in development mode:

```bash
git clone https://github.com/shreyaspansare/ai-shrey-codes.git
cd ai-shrey-codes
pip install -e .
```

## License

This project is licensed under the MIT License.

## Author

**shreyas pansare**
- Email: shreyaspansare123@gmail.com
