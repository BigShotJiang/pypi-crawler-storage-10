"""
AI Algorithm Implementations Package

This package contains implementations of various AI algorithms including:
- A* informed search algorithm
- Alpha-Beta pruning for minimax
- Breadth-First Search (BFS) and Depth-First Search (DFS) traversal

Author: shreyas pansare
Email: shreyaspansare123@gmail.com
Version: 1.0.0
"""

from .AStarInformedSearch import Node, a_star, visualize_graph_with_path_and_heuristic
from .AlphaBetaPruning import alpha_beta_pruning
from .BfsDfsTraversal import bfs, dfs

__version__ = "1.0.0"
__author__ = "shreyas pansare"
__email__ = "shreyaspansare123@gmail.com"

__all__ = [
    "Node",
    "a_star",
    "visualize_graph_with_path_and_heuristic",
    "alpha_beta_pruning",
    "bfs",
    "dfs",
]
