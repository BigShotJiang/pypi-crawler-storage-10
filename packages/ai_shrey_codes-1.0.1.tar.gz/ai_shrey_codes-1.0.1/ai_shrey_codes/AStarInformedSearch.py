import heapq
import networkx as nx
import matplotlib.pyplot as plt


class Node:
    def __init__(self, name, g=0, h=0, parent=None):
        self.name = name      # Node identifier
        self.g = g            # Cost from start node
        self.h = h            # Heuristic estimate to goal
        self.f = g + h        # Total cost
        self.parent = parent  # Parent node in path

    def __lt__(self, other):
        return self.f < other.f


def a_star(start, goal, neighbors, heuristic):
    open_list = []
    heapq.heappush(open_list, start)
    closed_list = set()

    while open_list:
        current = heapq.heappop(open_list)
        if current.name == goal.name:
            # Reconstruct path
            path = []
            while current:
                path.append(current.name)
                current = current.parent
            return path[::-1]
        closed_list.add(current.name)

        for neighbor_name, cost in neighbors[current.name]:
            if neighbor_name in closed_list:
                continue
            g_cost = current.g + cost
            h_cost = heuristic[neighbor_name]
            neighbor_node = Node(neighbor_name, g_cost, h_cost, current)
            # Check if neighbor in open_list with a lower f
            for node in open_list:
                if node.name == neighbor_name and node.f <= neighbor_node.f:
                    break
            else:
                heapq.heappush(open_list, neighbor_node)
    return None


def visualize_graph_with_path_and_heuristic(neighbors, heuristic):
    G = nx.Graph()

    # Add edges with weights
    for node, edges in neighbors.items():
        for neighbor, cost in edges:
            G.add_edge(node, neighbor, weight=cost)

    pos = nx.spring_layout(G)  # Layout for nodes

    # Draw nodes and edges
    nx.draw(G, pos, with_labels=True, node_color='lightblue', node_size=500, font_size=12)

    # Draw edge weights
    edge_labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)

    # Draw node heuristic values (node weight) as a label beside the node
    heuristic_labels = {node: f"h={heuristic[node]}" for node in G.nodes()}
    label_pos = {k: (v[0], v[1] - 0.1) for k, v in pos.items()}  # Slightly offset downward

    nx.draw_networkx_labels(G, label_pos, labels=heuristic_labels, font_color='green', font_size=10)

    plt.title('Graph Visualization with A* Path and Heuristic Values')
    plt.show()


# Example graph and heuristic
neighbors = {
    'A': [('B', 1), ('C', 4)],
    'B': [('A', 1), ('C', 2), ('D', 5)],
    'C': [('A', 4), ('B', 2), ('D', 1)],
    'D': [('B', 5), ('C', 1)]
}

heuristic = {
    'A': 7,
    'B': 6,
    'C': 2,
    'D': 0
}

start_node = Node('A', g=0, h=heuristic['A'])
goal_node = Node('D')

path = a_star(start_node, goal_node, neighbors, heuristic)
print("Path:", path)

visualize_graph_with_path_and_heuristic(neighbors, heuristic)
