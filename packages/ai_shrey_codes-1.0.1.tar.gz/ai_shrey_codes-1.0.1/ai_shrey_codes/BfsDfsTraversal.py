import networkx as nx
import matplotlib.pyplot as plt
from collections import deque


def bfs(graph, start):
    visited = set()
    queue = deque([start])

    while queue:
        vertex = queue.popleft()
        if vertex not in visited:
            print(vertex)
            visited.add(vertex)
            queue.extend(
                [neighbor for neighbor in graph[vertex] if neighbor not in visited]
            )


def dfs(graph, start, visited=None):
    if visited is None:
        visited = set()
    print(start)
    visited.add(start)
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)


# Your graph as adjacency dictionary
graph = {
    "A": ["B", "C"],
    "B": ["A", "D", "E"],
    "C": ["A", "F"],
    "D": ["B"],
    "E": ["B", "F"],
    "F": ["C", "E"],
}

print("BFS traversal:")
bfs(graph, "A")

print("\nDFS traversal:")
dfs(graph, "A")

# Create a NetworkX graph from adjacency dictionary
G = nx.Graph()
for node, neighbors in graph.items():
    for neighbor in neighbors:
        G.add_edge(node, neighbor)

# Draw the graph
plt.figure(figsize=(8, 6))
nx.draw(
    G,
    with_labels=True,
    node_color="skyblue",
    node_size=1500,
    font_size=16,
    font_weight="bold",
    edge_color="gray",
)
plt.title("Graph Visualization")
plt.show()
