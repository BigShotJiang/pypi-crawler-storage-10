n\_dimensions
=============

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.n_dimensions