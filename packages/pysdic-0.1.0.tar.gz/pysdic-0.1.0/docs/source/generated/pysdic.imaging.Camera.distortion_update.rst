distortion\_update
==================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.distortion_update