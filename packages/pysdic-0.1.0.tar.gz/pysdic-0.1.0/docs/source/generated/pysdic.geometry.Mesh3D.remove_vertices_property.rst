remove\_vertices\_property
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.remove_vertices_property