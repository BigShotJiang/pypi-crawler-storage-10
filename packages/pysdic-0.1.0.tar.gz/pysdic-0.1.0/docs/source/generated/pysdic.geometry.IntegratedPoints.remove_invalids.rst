remove\_invalids
================

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.remove_invalids