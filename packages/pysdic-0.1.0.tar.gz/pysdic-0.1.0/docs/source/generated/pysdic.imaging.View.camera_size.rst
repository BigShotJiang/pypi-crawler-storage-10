camera\_size
============

.. currentmodule:: pysdic.imaging

.. autoproperty:: View.camera_size