get\_elements\_property
=======================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.get_elements_property