n\_valids
=========

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.n_valids