merge\_inplace
==============

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.merge_inplace