get\_camera\_pixel\_points
==========================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.get_camera_pixel_points