get\_camera\_rays
=================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.get_camera_rays