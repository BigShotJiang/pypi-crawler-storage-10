cast\_rays
==========

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.cast_rays