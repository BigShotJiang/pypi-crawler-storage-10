interpolation\_function
=======================

.. currentmodule:: pysdic.imaging

.. autoproperty:: View.interpolation_function