evaluate\_image\_jacobian\_dy\_at\_pixel\_points
================================================

.. currentmodule:: pysdic.imaging

.. automethod:: View.evaluate_image_jacobian_dy_at_pixel_points