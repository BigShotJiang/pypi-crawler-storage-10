shape
=====

.. currentmodule:: pysdic.geometry

.. autoproperty:: PointCloud3D.shape