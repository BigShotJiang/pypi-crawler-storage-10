frame\_transform\_inplace
=========================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.frame_transform_inplace