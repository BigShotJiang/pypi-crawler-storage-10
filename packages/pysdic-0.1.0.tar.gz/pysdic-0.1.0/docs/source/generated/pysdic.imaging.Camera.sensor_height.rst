sensor\_height
==============

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.sensor_height