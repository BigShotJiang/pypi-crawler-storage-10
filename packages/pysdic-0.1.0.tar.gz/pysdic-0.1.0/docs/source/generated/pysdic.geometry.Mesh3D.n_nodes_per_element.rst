n\_nodes\_per\_element
======================

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.n_nodes_per_element