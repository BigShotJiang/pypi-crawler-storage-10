allclose
========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.allclose