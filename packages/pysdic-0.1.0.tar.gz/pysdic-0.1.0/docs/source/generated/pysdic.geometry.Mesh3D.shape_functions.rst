shape\_functions
================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.shape_functions