n\_elements
===========

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.n_elements