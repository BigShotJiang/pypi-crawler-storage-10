n\_dimensions
=============

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.n_dimensions