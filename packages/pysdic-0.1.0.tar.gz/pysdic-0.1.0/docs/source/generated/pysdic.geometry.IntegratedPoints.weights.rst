weights
=======

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.weights