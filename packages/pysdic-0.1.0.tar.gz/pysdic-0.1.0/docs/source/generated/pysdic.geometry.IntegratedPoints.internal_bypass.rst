internal\_bypass
================

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.internal_bypass