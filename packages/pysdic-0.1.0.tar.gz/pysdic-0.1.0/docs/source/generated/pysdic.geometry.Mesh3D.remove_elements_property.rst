remove\_elements\_property
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.remove_elements_property