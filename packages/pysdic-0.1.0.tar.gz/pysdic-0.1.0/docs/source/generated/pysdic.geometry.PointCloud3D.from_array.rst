from\_array
===========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.from_array