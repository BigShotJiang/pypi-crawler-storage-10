to\_vtk
=======

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.to_vtk