validate
========

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.validate