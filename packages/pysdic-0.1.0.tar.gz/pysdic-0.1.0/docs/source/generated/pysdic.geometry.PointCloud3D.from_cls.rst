from\_cls
=========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.from_cls