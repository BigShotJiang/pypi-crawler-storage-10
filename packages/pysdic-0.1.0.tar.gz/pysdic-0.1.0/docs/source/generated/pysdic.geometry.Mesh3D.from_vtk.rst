from\_vtk
=========

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.from_vtk