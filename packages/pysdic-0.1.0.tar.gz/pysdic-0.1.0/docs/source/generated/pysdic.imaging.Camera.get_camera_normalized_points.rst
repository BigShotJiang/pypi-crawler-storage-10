get\_camera\_normalized\_points
===============================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.get_camera_normalized_points