validate
========

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.validate