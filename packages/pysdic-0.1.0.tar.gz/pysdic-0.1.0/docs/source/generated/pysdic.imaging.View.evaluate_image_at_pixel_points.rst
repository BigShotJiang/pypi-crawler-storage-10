evaluate\_image\_at\_pixel\_points
==================================

.. currentmodule:: pysdic.imaging

.. automethod:: View.evaluate_image_at_pixel_points