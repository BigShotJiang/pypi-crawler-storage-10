set\_vertices\_property
=======================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.set_vertices_property