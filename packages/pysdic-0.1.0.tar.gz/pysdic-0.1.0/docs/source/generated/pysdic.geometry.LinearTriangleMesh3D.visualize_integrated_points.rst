visualize\_integrated\_points
=============================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.visualize_integrated_points