list\_vertices\_properties
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.list_vertices_properties