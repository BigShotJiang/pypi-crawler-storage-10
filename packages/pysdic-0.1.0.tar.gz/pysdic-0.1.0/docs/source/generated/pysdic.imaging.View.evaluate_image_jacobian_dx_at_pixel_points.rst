evaluate\_image\_jacobian\_dx\_at\_pixel\_points
================================================

.. currentmodule:: pysdic.imaging

.. automethod:: View.evaluate_image_jacobian_dx_at_pixel_points