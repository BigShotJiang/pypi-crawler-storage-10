remove\_points
==============

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.remove_points