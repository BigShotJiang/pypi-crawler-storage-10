from\_meshio
============

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.from_meshio