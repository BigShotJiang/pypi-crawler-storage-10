compute\_vertices\_normals
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.compute_vertices_normals