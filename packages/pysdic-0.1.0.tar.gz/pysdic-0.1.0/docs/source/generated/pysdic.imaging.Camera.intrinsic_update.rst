intrinsic\_update
=================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.intrinsic_update