clear\_elements\_properties
===========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.clear_elements_properties