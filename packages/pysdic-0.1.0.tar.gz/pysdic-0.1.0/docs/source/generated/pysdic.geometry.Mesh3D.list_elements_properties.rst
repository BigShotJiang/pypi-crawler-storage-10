list\_elements\_properties
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.list_elements_properties