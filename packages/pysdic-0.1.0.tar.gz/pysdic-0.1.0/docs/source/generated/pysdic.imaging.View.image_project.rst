image\_project
==============

.. currentmodule:: pysdic.imaging

.. automethod:: View.image_project