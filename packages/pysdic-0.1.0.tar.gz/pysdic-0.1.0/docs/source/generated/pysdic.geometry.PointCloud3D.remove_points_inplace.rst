remove\_points\_inplace
=======================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.remove_points_inplace