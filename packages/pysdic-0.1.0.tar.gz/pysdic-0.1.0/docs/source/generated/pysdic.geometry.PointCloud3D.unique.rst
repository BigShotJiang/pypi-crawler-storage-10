unique
======

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.unique