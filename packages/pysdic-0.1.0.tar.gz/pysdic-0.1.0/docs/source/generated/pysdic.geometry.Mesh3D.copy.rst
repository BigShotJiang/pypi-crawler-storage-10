copy
====

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.copy