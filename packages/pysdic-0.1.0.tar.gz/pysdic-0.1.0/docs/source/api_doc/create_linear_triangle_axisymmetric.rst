.. currentmodule:: pysdic.geometry

pysdic.geometry.create_linear_triangle_axisymmetric
====================================================

.. autofunction:: create_linear_triangle_axisymmetric