.. currentmodule:: pysdic.geometry

pysdic.geometry.create_linear_triangle_heightmap
=================================================

.. autofunction:: create_linear_triangle_heightmap