.. currentmodule:: pysdic.imaging

pysdic.imaging.ProjectionResult
===========================================

.. autoclass:: ProjectionResult
    :members:
    :inherited-members:
    :show-inheritance:

