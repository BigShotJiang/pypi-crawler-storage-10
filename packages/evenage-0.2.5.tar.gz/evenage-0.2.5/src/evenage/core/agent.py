"""
Back-compat shim for legacy import path.

This module now proxies to the canonical AgentBase to avoid duplication.
Prefer importing from `evenage.core.agent_base`.
"""

from evenage.core.agent_base import AgentBase as Agent

__all__ = ["Agent"]
