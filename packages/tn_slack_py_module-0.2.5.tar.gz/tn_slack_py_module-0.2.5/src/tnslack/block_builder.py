"""Modern BlockBuilder with type hints and improved API."""

import uuid
from typing import Any

# Type aliases for better readability
Block = dict[str, Any]
TextBlock = dict[str, str]
Option = dict[str, Any]


class BlockBuilder:
    """Modern BlockBuilder for creating Slack Block Kit components with type safety."""

    @staticmethod
    def simple_context_block(
        value: str, text_type: str = "plain_text", block_id: str | None = None
    ) -> Block:
        """Create a simple single value context block - metadata style.

        Args:
            value: Text value for the context
            text_type: Text type ("plain_text" or "mrkdwn")
            block_id: Block ID, auto-generated if not provided

        Returns:
            Context block dictionary
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        return {
            "type": "context",
            "elements": [{"type": text_type, "text": value}],
            "block_id": block_id,
        }

    @staticmethod
    def many_context_block(
        values: list[str], text_type: str = "plain_text", block_id: str | None = None
    ) -> Block:
        """Create a multi-value context block - metadata style.

        Args:
            values: List of text values
            text_type: Text type applied to all values ("plain_text" or "mrkdwn")
            block_id: Block ID, auto-generated if not provided

        Returns:
            Context block dictionary

        Raises:
            TypeError: If values is not a list
        """
        if not isinstance(values, list):
            raise TypeError(
                f"Values must be a list, got {type(values)}. "
                "Use simple_context_block for single values."
            )

        if not block_id:
            block_id = str(uuid.uuid4())

        elements = [{"type": text_type, "text": val} for val in values]
        return {
            "type": "context",
            "elements": elements,
            "block_id": block_id,
        }

    @staticmethod
    def custom_context_block(elements: list[TextBlock], block_id: str | None = None) -> Block:
        """Create a customizable multi-context block with custom text blocks.

        Args:
            elements: List of text block dictionaries with 'type' and 'text' keys
            block_id: Block ID, auto-generated if not provided

        Returns:
            Context block dictionary

        Raises:
            TypeError: If elements is not a list
        """
        if not isinstance(elements, list):
            raise TypeError("Elements must be a list of text blocks")

        if not block_id:
            block_id = str(uuid.uuid4())

        return {
            "type": "context",
            "elements": elements,
            "block_id": block_id,
        }

    @staticmethod
    def text_block(value: str, text_type: str = "plain_text") -> TextBlock:
        """Create a text block object.

        Args:
            value: Text content
            text_type: Text type ("plain_text" or "mrkdwn")

        Returns:
            Text block dictionary
        """
        return {"type": text_type, "text": value}

    @staticmethod
    def input_block(
        label: str,
        initial_value: str | None = None,
        placeholder: str | None = None,
        multiline: bool = False,
        placeholder_type: str = "plain_text",
        action_id: str = "plain_input",
        block_id: str | None = None,
        label_type: str = "plain_text",
        min_length: int | None = None,
        max_length: int | None = None,
        optional: bool = True,
    ) -> Block:
        """Create a text input block.

        Args:
            label: Label text for the input
            initial_value: Initial value for the input
            placeholder: Placeholder text
            multiline: Whether to use multiline text area
            placeholder_type: Type for placeholder text
            action_id: Action ID for the input
            block_id: Block ID, auto-generated if not provided
            label_type: Type for label text
            min_length: Minimum input length
            max_length: Maximum input length
            optional: Whether the input is optional

        Returns:
            Input block dictionary
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        obj = {
            "type": "input",
            "block_id": block_id,
            "label": {"type": label_type, "text": label},
            "optional": optional,
            "element": {
                "type": "plain_text_input",
                "action_id": action_id,
                "multiline": multiline,
            },
        }

        if placeholder:
            obj["element"]["placeholder"] = BlockBuilder.text_block(placeholder, placeholder_type)

        if max_length is not None:
            obj["element"]["max_length"] = max_length

        if min_length is not None:
            obj["element"]["min_length"] = min_length

        if initial_value is not None:
            obj["element"]["initial_value"] = str(initial_value)

        return obj

    @staticmethod
    def simple_section_block(
        value: str, text_type: str = "plain_text", block_id: str | None = None
    ) -> Block:
        """Create a simple section block with text.

        Args:
            value: Text content
            text_type: Text type ("plain_text" or "mrkdwn")
            block_id: Block ID, auto-generated if not provided

        Returns:
            Section block dictionary
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        return {
            "type": "section",
            "text": {"type": text_type, "text": value},
            "block_id": block_id,
        }

    @staticmethod
    def simple_section_multiple_block(
        text_blocks: list[TextBlock], block_id: str | None = None
    ) -> Block:
        """Create a section block with multiple text fields.

        Args:
            text_blocks: List of text block objects
            block_id: Block ID, auto-generated if not provided

        Returns:
            Section block dictionary
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        return {"type": "section", "fields": text_blocks, "block_id": block_id}

    @staticmethod
    def option(text: str, value: str) -> Option:
        """Create an option object for select menus.

        Args:
            text: Display text for the option
            value: Value for the option

        Returns:
            Option dictionary
        """
        return {
            "text": {"type": "plain_text", "text": text},
            "value": value,
        }

    @staticmethod
    def divider_block() -> Block:
        """Create a divider block.

        Returns:
            Divider block dictionary
        """
        return {"type": "divider"}

    @staticmethod
    def header_block(text: str, block_id: str | None = None) -> Block:
        """Create a header block.

        Args:
            text: Header text
            block_id: Block ID, auto-generated if not provided

        Returns:
            Header block dictionary
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        return {
            "type": "header",
            "text": {"type": "plain_text", "text": text},
            "block_id": block_id,
        }

    @staticmethod
    def static_select_block(
        label: str,
        options: list[Option],
        action_id: str | None = None,
        initial_option: Option | None = None,
        placeholder: str = "Select",
        block_id: str | None = None,
    ) -> Block:
        """Create a static select block.

        Args:
            label: Label text for the select
            options: List of option objects
            action_id: Action ID for the select
            initial_option: Initially selected option
            placeholder: Placeholder text
            block_id: Block ID, auto-generated if not provided

        Returns:
            Section block with static select accessory
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        block = {
            "type": "section",
            "text": {"type": "mrkdwn", "text": label},
            "block_id": block_id,
            "accessory": {
                "type": "static_select",
                "placeholder": {"type": "plain_text", "text": placeholder},
                "options": options,
            },
        }

        if initial_option:
            block["accessory"]["initial_option"] = initial_option
        if action_id:
            block["accessory"]["action_id"] = action_id

        return block

    @staticmethod
    def simple_button_block(
        label: str,
        value: str,
        url: str | None = None,
        style: str | None = None,
        confirm: bool = False,
        action_id: str | None = None,
    ) -> Block:
        """Create a button element.

        Args:
            label: Button text
            value: Button value passed in payload
            url: Optional URL for link button
            style: Button style ("default", "primary", or "danger")
            confirm: Whether to show confirmation dialog
            action_id: Action ID, auto-generated if not provided

        Returns:
            Button element dictionary
        """
        block = {
            "type": "button",
            "text": {"type": "plain_text", "text": label},
            "value": value,
            "action_id": action_id or str(uuid.uuid4()),
        }

        if style:
            block["style"] = style
        if url:
            block["url"] = url

        return block

    @staticmethod
    def actions_block(elements: list[Block], block_id: str | None = None) -> Block | None:
        """Create an actions block with interactive elements.

        Args:
            elements: List of interactive elements (max 5)
            block_id: Block ID, auto-generated if not provided

        Returns:
            Actions block dictionary or None if invalid

        Note:
            Returns None if no elements or more than 5 elements provided
        """
        if not elements or len(elements) > 5:
            return None

        if not block_id:
            block_id = str(uuid.uuid4())

        return {"type": "actions", "block_id": block_id, "elements": elements}

    @staticmethod
    def section_with_accessory_block(
        section_text: str,
        accessory: Block,
        text_type: str = "mrkdwn",
        block_id: str | None = None,
    ) -> Block:
        """Create a section block with an accessory element.

        Args:
            section_text: Text for the section
            accessory: Accessory element (button, select, etc.)
            text_type: Text type for section text
            block_id: Block ID, auto-generated if not provided

        Returns:
            Section block with accessory
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        return {
            "type": "section",
            "text": {"type": text_type, "text": section_text},
            "block_id": block_id,
            "accessory": accessory,
        }

    @staticmethod
    def section_with_button_block(
        button_label: str,
        button_value: str,
        section_text: str,
        text_type: str = "mrkdwn",
        block_id: str | None = None,
        url: str | None = None,
        style: str | None = None,
        confirm: bool = False,
        action_id: str | None = None,
    ) -> Block:
        """Create a section block with a button accessory.

        Args:
            button_label: Button text
            button_value: Button value
            section_text: Section text
            text_type: Text type for section
            block_id: Block ID, auto-generated if not provided
            url: Optional button URL
            style: Button style
            confirm: Show confirmation dialog
            action_id: Button action ID

        Returns:
            Section block with button accessory
        """
        button = BlockBuilder.simple_button_block(
            button_label, button_value, url, style, confirm, action_id
        )
        return BlockBuilder.section_with_accessory_block(section_text, button, text_type, block_id)

    @staticmethod
    def simple_image_block(url: str, alt_text: str) -> Block:
        """Create an image block.

        Args:
            url: Image URL (max 3000 characters)
            alt_text: Alt text for image (max 2000 characters)

        Returns:
            Image block dictionary
        """
        return {
            "type": "image",
            "image_url": url,
            "alt_text": alt_text,
        }

    @staticmethod
    def datepicker_block(
        initial_date: str | None = None,
        action_id: str | None = None,
        block_id: str | None = None,
        label: str = "Select Date",
        placeholder: str = "Select a date",
        confirm: Block | None = None,
    ) -> Block:
        """Create a datepicker block.

        Args:
            initial_date: Initial date in YYYY-MM-DD format
            action_id: Action ID for the datepicker
            block_id: Block ID, auto-generated if not provided
            label: Label text
            placeholder: Placeholder text
            confirm: Optional confirmation dialog object

        Returns:
            Section block with datepicker accessory
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        block = {
            "type": "section",
            "text": {"type": "mrkdwn", "text": label},
            "block_id": block_id,
            "accessory": {
                "type": "datepicker",
                "placeholder": {"type": "plain_text", "text": placeholder},
            },
        }

        if initial_date:
            block["accessory"]["initial_date"] = initial_date
        if action_id:
            block["accessory"]["action_id"] = action_id
        if confirm:
            block["accessory"]["confirm"] = confirm

        return block

    @staticmethod
    def datetimepicker_block(
        label: str,
        action_id: str | None = None,
        block_id: str | None = None,
        initial_date_time: int | None = None,
        hint: str | None = None,
        optional: bool = True,
        confirm: Block | None = None,
    ) -> Block:
        """Create a datetime picker input block.

        Args:
            label: Label text for the datetime picker
            action_id: Action ID for the datetime picker
            block_id: Block ID, auto-generated if not provided
            initial_date_time: Initial datetime as Unix timestamp
            hint: Optional hint text
            optional: Whether the input is optional
            confirm: Optional confirmation dialog object

        Returns:
            Input block with datetime picker element

        Example:
            import time

            # Set initial time to current time
            current_timestamp = int(time.time())

            datetime_block = BlockBuilder.datetimepicker_block(
                label="📅 Start date",
                action_id="meeting_datetime",
                initial_date_time=current_timestamp,
                hint="This is some hint text"
            )
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        if not action_id:
            action_id = "datetimepicker-action"

        block = {
            "type": "input",
            "block_id": block_id,
            "label": {"type": "plain_text", "text": label, "emoji": True},
            "optional": optional,
            "element": {
                "type": "datetimepicker",
                "action_id": action_id,
            },
        }

        if initial_date_time is not None:
            block["element"]["initial_date_time"] = initial_date_time

        if hint:
            block["hint"] = {"type": "plain_text", "text": hint, "emoji": True}

        if confirm:
            block["element"]["confirm"] = confirm

        return block

    @staticmethod
    def timepicker_block(
        initial_time: str | None = None,
        action_id: str | None = None,
        block_id: str | None = None,
        label: str = "Select Time",
        placeholder: str = "Select a time",
        timezone: str | None = None,
        confirm: Block | None = None,
    ) -> Block:
        """Create a time picker block.

        Args:
            initial_time: Initial time in HH:MM format (24-hour)
            action_id: Action ID for the time picker
            block_id: Block ID, auto-generated if not provided
            label: Label text
            placeholder: Placeholder text
            timezone: Timezone identifier (e.g., "America/Los_Angeles")
            confirm: Optional confirmation dialog object

        Returns:
            Section block with time picker accessory

        Example:
            time_block = BlockBuilder.timepicker_block(
                initial_time="14:30",
                action_id="meeting_time",
                label="🕐 Select meeting time",
                timezone="America/New_York"
            )
        """
        if not block_id:
            block_id = str(uuid.uuid4())

        block = {
            "type": "section",
            "text": {"type": "mrkdwn", "text": label},
            "block_id": block_id,
            "accessory": {
                "type": "timepicker",
                "placeholder": {"type": "plain_text", "text": placeholder},
            },
        }

        if initial_time:
            block["accessory"]["initial_time"] = initial_time
        if action_id:
            block["accessory"]["action_id"] = action_id
        if timezone:
            block["accessory"]["timezone"] = timezone
        if confirm:
            block["accessory"]["confirm"] = confirm

        return block

    @staticmethod
    def confirmation_dialog(
        title: str,
        text: str,
        confirm_text: str = "Do it",
        deny_text: str = "Stop, I've changed my mind!",
    ) -> Block:
        """Create a confirmation dialog object for use with interactive elements.

        Args:
            title: Title of the confirmation dialog
            text: Body text of the confirmation dialog
            confirm_text: Text for the confirm button
            deny_text: Text for the deny button

        Returns:
            Confirmation dialog object

        Example:
            confirm_dialog = BlockBuilder.confirmation_dialog(
                title="Are you sure?",
                text="Wouldn't you prefer a good game of chess?",
                confirm_text="Do it",
                deny_text="Stop, I've changed my mind!"
            )

            # Use with datetime picker
            datetime_block = BlockBuilder.datetimepicker_block(
                label="📅 Delete date",
                confirm=confirm_dialog
            )

            # Use with buttons or other interactive elements
            button = BlockBuilder.simple_button_block(
                label="Delete Account",
                value="delete_account",
                style="danger"
            )
            # Note: Add confirm to button after creation
            button["confirm"] = confirm_dialog
        """
        return {
            "title": {"type": "plain_text", "text": title},
            "text": {"type": "plain_text", "text": text},
            "confirm": {"type": "plain_text", "text": confirm_text},
            "deny": {"type": "plain_text", "text": deny_text},
        }

    @staticmethod
    def overflow_menu(
        action_id: str,
        options: list[tuple[str, str]] | list[Option],
    ) -> Block:
        """Create an overflow menu element.

        Note: All actions defined in the overflow menu options are consumed
        by a single block_actions event handler. The action_id of the overflow
        menu itself will be used to route to your handler, and the selected
        option's value will be available in the payload.

        Args:
            action_id: Action ID for the overflow menu (used for routing)
            options: List of (text, value) tuples or Option objects

        Returns:
            Overflow menu element dictionary

        Example:
            # Using tuples
            overflow = BlockBuilder.overflow_menu(
                "entry_actions_123",
                [
                    ("✏️ Edit", "edit:123"),
                    ("🗑️ Delete", "delete:123"),
                    ("📋 Duplicate", "duplicate:123")
                ]
            )

            # Using Option objects
            options = [
                BlockBuilder.option("✏️ Edit", "edit:123"),
                BlockBuilder.option("🗑️ Delete", "delete:123")
            ]
            overflow = BlockBuilder.overflow_menu("entry_actions_123", options)

            # Handler example
            @app.route("block_actions")
            def handle_entry_actions(payload, context):
                action_id = payload["actions"][0]["action_id"]
                selected_value = payload["actions"][0]["selected_option"]["value"]

                if action_id == "entry_actions_123":
                    if selected_value.startswith("edit:"):
                        entry_id = selected_value.split(":")[1]
                        # Handle edit action
                    elif selected_value.startswith("delete:"):
                        entry_id = selected_value.split(":")[1]
                        # Handle delete action
        """
        # Convert tuples to Option objects if needed
        formatted_options = []
        for option in options:
            if isinstance(option, tuple):
                text, value = option
                formatted_options.append(BlockBuilder.option(text, value))
            else:
                formatted_options.append(option)

        return {
            "type": "overflow",
            "action_id": action_id,
            "options": formatted_options,
        }
