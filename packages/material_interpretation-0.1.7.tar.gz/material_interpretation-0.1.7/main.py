# 这是模块的入口点文件，当使用 python -m material_interpretation 时会执行这个文件
# 从同一个包中导入主函数
from material_interpretation import main

# 执行主函数，启动 MCP 计算器服务器
main()