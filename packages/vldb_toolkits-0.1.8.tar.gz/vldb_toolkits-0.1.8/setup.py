"""Setup configuration for vldb-toolkits"""

from setuptools import setup

# For compatibility with older build tools
if __name__ == "__main__":
    setup()
