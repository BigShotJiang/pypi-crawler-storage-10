﻿# Financetools

Financetools Python üçün **maliyyə və vergi ilə bağlı faydalı funksiyalar** kitabxanasıdır.

## Modullar
- discount_utils: endirim və faiz hesablamaları
- tax_utils: vergi və net gəlir hesablamaları
- loan_utils: kredit və faiz hesablamaları
- currency_utils: valyuta çevirmə
