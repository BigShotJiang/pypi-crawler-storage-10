﻿def currency_conversion(amount, rate):
    """Valyuta çevirmə"""
    return amount * rate
