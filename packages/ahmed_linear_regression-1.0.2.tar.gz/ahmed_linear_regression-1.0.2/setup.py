from setuptools import setup

setup(
   name='ahmed_linear_regression',
   version='1.0.2',
   author='ahmed',
   author_email='ay.bouguessa@esi-sba.dz',
   packages=['ahmed_linear_regression'],
   url='http://pypi.python.org/pypi/ahmed_linear_regression/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['ahmed_linear_regression']
)