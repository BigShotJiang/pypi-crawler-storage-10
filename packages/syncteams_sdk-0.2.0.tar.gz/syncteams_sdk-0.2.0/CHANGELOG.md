# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2025-10-28

### Added
- Initial Python SDK release
- `WorkflowClient` with full API support
- `execute_workflow`, `get_task_status`, `continue_task` methods
- `wait_for_completion` with polling and callbacks
- `execute_and_wait` convenience method with approval handling
- Automatic retry with exponential backoff
- Type hints and comprehensive error handling
- Unit tests with pytest

### Features
- Full parity with JavaScript SDK
- Python 3.9+ support
- Async-friendly polling with stop events
- Webhook event type definitions
- Detailed error responses with `WorkflowAPIError`
