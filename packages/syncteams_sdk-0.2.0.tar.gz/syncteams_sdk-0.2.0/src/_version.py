"""Package version, shared between packaging metadata and runtime."""
__all__ = ["__version__"]

__version__ = "0.2.0"
