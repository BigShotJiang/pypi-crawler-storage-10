"""Shared type definitions and constants for the SyncTeams Python SDK."""
from __future__ import annotations

from dataclasses import dataclass
from threading import Event
from typing import Any, Callable, List, Mapping, MutableMapping, Optional, Sequence, TypedDict

from typing_extensions import Literal, NotRequired

from .event_types import ExecutionEvent

WorkflowStatus = Literal[
    "QUEUED",
    "PENDING",
    "RUNNING",
    "WAITING",
    "CANCELED",
    "FAILED",
    "COMPLETED",
]

ApprovalDecision = Literal["APPROVE", "REJECT"]

WorkflowEventType = Literal[
    "UserInputEvent",
    "ConnectorInputEvent",
    "TaskApprovalRequestEvent",
    "TaskApprovalResponseEvent",
    "CrewKickoffStartedEvent",
    "CrewKickoffCompletedEvent",
    "CrewKickoffFailedEvent",
    "CrewTestStartedEvent",
    "CrewTestCompletedEvent",
    "CrewTestFailedEvent",
    "CrewTrainStartedEvent",
    "CrewTrainCompletedEvent",
    "CrewTestResultEvent",
    "CrewTrainFailedEvent",
    "AgentExecutionStartedEvent",
    "AgentExecutionCompletedEvent",
    "AgentExecutionErrorEvent",
    "AgentReasoningStartedEvent",
    "AgentReasoningCompletedEvent",
    "AgentReasoningFailedEvent",
    "TaskStartedEvent",
    "TaskCompletedEvent",
    "TaskFailedEvent",
    "TaskEvaluationEvent",
    "TaskOutput",
    "ToolUsageStartedEvent",
    "ToolUsageFinishedEvent",
    "ToolUsageErrorEvent",
    "ToolValidateInputErrorEvent",
    "ToolExecutionErrorEvent",
    "ToolSelectionErrorEvent",
    "KnowledgeRetrievalStartedEvent",
    "KnowledgeRetrievalCompletedEvent",
    "KnowledgeQueryStartedEvent",
    "KnowledgeQueryCompletedEvent",
    "KnowledgeQueryFailedEvent",
    "KnowledgeSearchQueryFailedEvent",
    "FlowCreatedEvent",
    "FlowStartedEvent",
    "FlowFinishedEvent",
    "FlowPlotEvent",
    "MethodExecutionStartedEvent",
    "MethodExecutionFinishedEvent",
    "MethodExecutionFailedEvent",
    "LLMCallStartedEvent",
    "LLMCallCompletedEvent",
    "LLMCallFailedEvent",
    "LLMStreamChunkEvent",
    str,
]


class TaskEventLog(TypedDict, total=False):
    eventType: WorkflowEventType
    eventData: ExecutionEvent
    createdAt: str
    updatedAt: str


class ExecuteWorkflowInput(TypedDict):
    workflowId: str
    input: Mapping[str, Any]
    uniqueId: NotRequired[str]


class ExecuteWorkflowResponse(TypedDict):
    taskId: str
    status: WorkflowStatus


class TaskStatusResponse(ExecuteWorkflowResponse, total=False):
    eventLogs: List[TaskEventLog]


class WebhookEventPayload(TypedDict, total=False):
    taskId: str
    uniqueId: str
    status: WorkflowStatus
    eventLogs: List[TaskEventLog]


class WorkflowClientRetryConfig(TypedDict, total=False):
    max_attempts: int
    initial_delay_ms: int
    backoff_factor: float
    max_delay_ms: int
    retry_on_statuses: Sequence[int]


class WorkflowClientOptions(TypedDict, total=False):
    base_url: str
    api_key: str
    timeout_ms: int
    default_headers: Mapping[str, str]
    retry: WorkflowClientRetryConfig
    user_agent_suffix: str


WaitForCompletionCallback = Callable[[TaskStatusResponse], None]


class WaitForCompletionOptions(TypedDict, total=False):
    poll_interval_ms: int
    max_wait_time_ms: int
    terminal_statuses: Sequence[WorkflowStatus]
    exit_on_waiting: bool
    stop_event: Event
    on_update: WaitForCompletionCallback


class ExecuteAndWaitOptions(WaitForCompletionOptions, total=False):
    on_waiting: Callable[[TaskStatusResponse], bool]


DEFAULT_REQUEST_TIMEOUT_MS = 30_000
DEFAULT_POLL_INTERVAL_MS = 2_000
DEFAULT_MAX_WAIT_TIME_MS = 10 * 60 * 1000  # 10 minutes
DEFAULT_BASE_URL = "https://develop.api.syncteams.studio"


@dataclass
class RequestDescriptor:
    """Minimal request metadata used when raising :class:`WorkflowAPIError`."""

    method: str
    url: str
    body: Optional[Any] = None


Headers = MutableMapping[str, str]
