from sqlfmt_primer.primer import sqlfmt_primer

sqlfmt_primer()
