def greet():
    print("Hello from AppScriptify!")
