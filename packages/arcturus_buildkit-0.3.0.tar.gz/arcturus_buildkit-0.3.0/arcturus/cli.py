import argparse
from arcturus.arcturus_buildkit import arcturusNLP

def main():
    parser = argparse.ArgumentParser(
        prog="arcturus",
        description="Arcturus BuildKit CLI — simple NLP analysis tool"
    )
    parser.add_argument("text", help="Text to analyze")
    args = parser.parse_args()

    nlp = arcturusNLP()
    tokens = nlp.tokenize(args.text)
    lemmas = [nlp.lemmatizer(t).get(t, (t, t))[1] for t in tokens]

    print("Tokens:", tokens)
    print("Lemmas:", lemmas)

if __name__ == "__main__":
    main()
