from setuptools import setup

setup(
   name='yAchouriPackage',
   version='1.0.0',
   author='yAchouriPackage',
   author_email='yi.achouri@esi-sba.dz',
   packages=['yAchouriPackage'],
   url='http://pypi.python.org/pypi/yAchouriPackage/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['yAchouriPackage']
)