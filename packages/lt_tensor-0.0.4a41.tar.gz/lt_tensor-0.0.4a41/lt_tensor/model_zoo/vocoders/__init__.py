from .hifigan import HifiganConfig, HifiganGenerator
from .istftnet import iSTFTNetConfig, iSTFTNetGenerator
from . import istftnet, hifigan
