"""
Install endpoint - Install apps from package registries (PyPI, npm, GitHub)
Replaces S3 download with public package manager support
"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from pathlib import Path
import sys

# Add the backend source to path
backend_path = Path(__file__).parent.parent.parent.parent.parent / "aurica-base-be" / "src"
sys.path.insert(0, str(backend_path.parent))

try:
    from src.app_package_manager import AppPackageManager
    from src.auth_decorators import require_auth, public_route
except ImportError as e:
    print(f"Warning: Import error: {e}")
    def require_auth(func):
        return func
    def public_route(func):
        return func

router = APIRouter()

# Get apps directory from environment or use default
import os
apps_dir = Path(os.getenv('APPS_DIR', Path(__file__).parent.parent.parent.parent.parent / "apps"))


class InstallRequest(BaseModel):
    """Request model for install endpoint."""
    package_ref: str  # e.g., "npm:@myorg/myapp@1.0.0", "pypi:myorg-myapp@1.0.0", "github:myorg/myapp@v1.0.0"
    force: bool = False  # Force reinstall even if already installed


class InstallResponse(BaseModel):
    """Response model for install endpoint."""
    success: bool
    message: str
    app_name: str
    version: Optional[str] = None
    registry: Optional[str] = None
    files_count: Optional[int] = None


@router.post("/", response_model=InstallResponse, summary="Install app from package registry", tags=['app-sync'])
@require_auth
async def install_app(request: InstallRequest):
    """
    Install an app from a package registry (PyPI, npm, GitHub).
    
    This endpoint downloads apps from public package managers.
    No S3 required - uses standard package infrastructure.
    
    Package reference formats:
    - PyPI: `pypi:namespace-appname@1.0.0`
    - npm: `npm:@namespace/appname@1.0.0`
    - GitHub: `github:owner/repo@v1.0.0` or `github:owner/repo@main`
    
    Args:
        request: InstallRequest with package_ref and optional force flag
        
    Returns:
        InstallResponse with installation details
        
    Examples:
        ```json
        {
            "package_ref": "npm:@acme/weather-app@1.2.3",
            "force": false
        }
        ```
        
        ```json
        {
            "package_ref": "github:acme/auth-app@v2.0.0",
            "force": true
        }
        ```
    """
    try:
        manager = AppPackageManager(apps_dir)
        result = manager.install_app(request.package_ref, force=request.force)
        
        if not result['success']:
            raise HTTPException(status_code=400, detail=result.get('error', 'Installation failed'))
        
        # Handle case where app was already installed
        if result.get('skipped'):
            return InstallResponse(
                success=True,
                message=f"App '{result['app_name']}' version {result['version']} already installed",
                app_name=result['app_name'],
                version=result['version']
            )
        
        return InstallResponse(
            success=True,
            message=f"Successfully installed '{result['app_name']}' version {result['version']}",
            app_name=result['app_name'],
            version=result['version'],
            registry=result.get('registry'),
            files_count=result.get('files_count')
        )
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Installation failed: {str(e)}")


class UninstallRequest(BaseModel):
    """Request model for uninstall endpoint."""
    app_name: str


class UninstallResponse(BaseModel):
    """Response model for uninstall endpoint."""
    success: bool
    message: str
    app_name: str


@router.delete("/", response_model=UninstallResponse, summary="Uninstall an app", tags=['app-sync'])
@require_auth
async def uninstall_app(request: UninstallRequest):
    """
    Uninstall an app from the system.
    
    Args:
        request: UninstallRequest with app_name
        
    Returns:
        UninstallResponse with result
    """
    try:
        manager = AppPackageManager(apps_dir)
        result = manager.uninstall_app(request.app_name)
        
        if not result['success']:
            raise HTTPException(status_code=404, detail=result.get('error', 'Uninstall failed'))
        
        return UninstallResponse(
            success=True,
            message=f"Successfully uninstalled '{request.app_name}'",
            app_name=request.app_name
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Uninstall failed: {str(e)}")


class ListInstalledResponse(BaseModel):
    """Response model for list installed apps."""
    apps: list


class RegistryResponse(BaseModel):
    """Response model for registry apps."""
    apps: dict


@router.get("/registry", response_model=RegistryResponse, summary="Get available apps from registry", tags=['app-sync'])
@public_route
async def get_registry_apps():
    """
    Get list of all available apps from the app registry.
    This endpoint is public - no authentication required.
    
    Returns:
        RegistryResponse with all apps available for installation
    """
    try:
        import json
        registry_path = apps_dir / "app-registry.json"
        
        # Try multiple locations for the registry
        if not registry_path.exists():
            registry_path = Path(__file__).parent.parent.parent / "app-registry.json"
        if not registry_path.exists():
            # Try backend config location
            backend_path = Path(__file__).parent.parent.parent.parent.parent / "aurica-base-be" / "config" / "app-registry.json"
            if backend_path.exists():
                registry_path = backend_path
        
        if not registry_path.exists():
            return RegistryResponse(apps={})
        
        with open(registry_path, 'r') as f:
            registry = json.load(f)
        
        return RegistryResponse(apps=registry.get('apps', {}))
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load registry: {str(e)}")


@router.get("/installed", response_model=ListInstalledResponse, summary="List installed apps", tags=['app-sync'])
@require_auth
async def list_installed_apps():
    """
    List all apps installed from package registries.
    
    Returns:
        ListInstalledResponse with list of installed apps and their details
    """
    try:
        manager = AppPackageManager(apps_dir)
        apps = manager.list_installed_apps()
        
        return ListInstalledResponse(apps=apps)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list apps: {str(e)}")
