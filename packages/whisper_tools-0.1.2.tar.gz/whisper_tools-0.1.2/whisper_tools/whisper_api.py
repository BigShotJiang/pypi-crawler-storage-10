from .logger import logger
from openai import OpenAI
import soundfile as sf
import numpy as np
import requests
import tempfile
import os


class WhisperAPI:
    def __init__(self, api_key: str, base_url: str, model: str = "whisper-1"):
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def transcribe_audio_data(self, audio_data: np.ndarray, sample_rate: int = 16000) -> str:
        """transcribe audio via API"""
        try:
            # saving audio to the temp file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_file:
                tmp_file_path = tmp_file.name
            
            # normalize audio
            audio_data = np.clip(audio_data, -1.0, 1.0)
            sf.write(tmp_file_path, audio_data, sample_rate, subtype='PCM_16')
            
            # sending to the API
            with open(tmp_file_path, 'rb') as audio_file:
                files = {
                    'file': ('audio.wav', audio_file, 'audio/wav'),
                    'model': (None, self.model),
                    'language': (None, 'ru'),
                    'response_format': (None, 'json')
                }
                
                response = self.session.post(
                    f"{self.base_url}/v1/audio/transcriptions",
                    files=files
                )
            
            # removing temp file
            if os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)
            
            if response.status_code == 200:
                result = response.json()
                text = result.get('text', '').strip()
                logger.info(f"API transcription: '{text}'")
                return text
            else:
                logger.error(f"API error {response.status_code}: {response.text}")
                return ""
                
        except Exception as e:
            logger.error(f"Error in API transcription: {e}")
            # removing tmp file
            if 'tmp_file_path' in locals() and os.path.exists(tmp_file_path):
                try:
                    os.unlink(tmp_file_path)
                except:
                    pass
            return ""
    
    def transcribe_file(self, file_path: str) -> str:
        """transcribe file via API"""
        try:
            with open(file_path, 'rb') as audio_file:
                files = {
                    'file': ('audio.wav', audio_file, 'audio/wav'),
                    'model': (None, self.model),
                    'language': (None, 'ru'),
                    'response_format': (None, 'json')
                }
                
                response = self.session.post(
                    f"{self.base_url}/v1/audio/transcriptions",
                    files=files
                )
            
            if response.status_code == 200:
                result = response.json()
                text = result.get('text', '').strip()
                logger.info(f"API file transcription: '{text}'")
                return text
            else:
                logger.error(f"API error {response.status_code}: {response.text}")
                return ""
                
        except Exception as e:
            logger.error(f"Error transcribing file via API: {e}")
            return ""