API reference
=============
This section documents the internal API of ``napari-matplotlib`` classes.
Most users shouldn't need this, and will just directly interact with the
plots though the napari user interface.


.. automodapi:: napari_matplotlib

.. automodapi:: napari_matplotlib.base
