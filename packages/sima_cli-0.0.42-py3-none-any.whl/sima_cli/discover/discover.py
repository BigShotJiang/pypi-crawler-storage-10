#!/usr/bin/env python3
import socket
import struct
import json
import time
import concurrent.futures
import paramiko
import netifaces
from rich.console import Console
from rich.table import Table

# ─────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────
MCAST_GRP = "239.255.42.1"
MCAST_PORT = 50000
SRC_PORT   = 60000
TIMEOUT    = 1.0
DISCOVERY_MSG = b"DISCOVER"
SIMA_OUI = "68:e1:54"
DEFAULT_USER = "sima"
DEFAULT_PASS = "edgeai"

console = Console()

# ─────────────────────────────────────────────────────────────
# SSH probe helper (for backward compatibility)
# ─────────────────────────────────────────────────────────────
def get_build_info_via_ssh(ip, passwd=DEFAULT_PASS):
    """SSH into device and extract build info from /etc/build or /etc/buildinfo."""
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ip, username=DEFAULT_USER, password=passwd, timeout=4)
        _, stdout, _ = ssh.exec_command(
            # Match even if spaces exist around '='
            "grep -E 'SIMA_BUILD_VERSION|MACHINE|DISTRO' /etc/build 2>/dev/null || "
            "grep -E 'SIMA_BUILD_VERSION|MACHINE|DISTRO' /etc/buildinfo 2>/dev/null"
        )
        data = stdout.read().decode().strip()
        ssh.close()
        if not data:
            return {"version": "N/A", "machine": "-", "distro": "-"}

        info = {}
        for line in data.splitlines():
            if "=" in line:
                k, v = [s.strip() for s in line.strip().split("=", 1)]
                info[k.strip().lower()] = v.strip()

        return {
            "version": info.get("sima_build_version", "N/A"),
            "machine": info.get("machine", "-"),
            "distro": info.get("distro", "-"),
        }

    except Exception as e:
        return {"version": "unreachable", "machine": "-", "distro": "-"}


# ─────────────────────────────────────────────────────────────
# Multicast discovery logic
# ─────────────────────────────────────────────────────────────
def discover_multicast():
    """Cross-platform multicast discovery over all physical interfaces."""
    console.print("[cyan]📡 Discovering nearby SiMa.ai DevKits[/cyan]")

    # 1️⃣ Collect candidate interfaces
    iface_candidates = []
    for iface in netifaces.interfaces():
        ifaddrs = netifaces.ifaddresses(iface).get(netifaces.AF_INET)
        if not ifaddrs:
            continue
        for a in ifaddrs:
            ip = a.get("addr")
            if not ip or ip.startswith("127."):
                continue

            name = iface.lower()
            if (
                name.startswith(("en", "eth"))  # macOS/Linux
                or name.startswith("ethernet")  # Windows
                or name.startswith("lan")       # Windows alt
            ):
                iface_candidates.append((iface, ip))

    if not iface_candidates:
        console.print("[yellow]⚠️ No active physical interfaces found.[/yellow]")
        return []

    console.print(f"🔎 Found interfaces on this machine: {[f'{i}:{ip}' for i, ip in iface_candidates]}")

    # 2️⃣ Send DISCOVER from each interface
    responses = []
    seen_ips = set()

    for iface, iface_ip in iface_candidates:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.settimeout(TIMEOUT)
            sock.bind((iface_ip, SRC_PORT))

            # Bind multicast to this interface
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(iface_ip))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)

            console.print(f"📤 Discovering via {iface} ({iface_ip})")
            sock.sendto(DISCOVERY_MSG, (MCAST_GRP, MCAST_PORT))

            start = time.time()
            while time.time() - start < TIMEOUT:
                try:
                    data, addr = sock.recvfrom(2048)
                    msg = json.loads(data.decode(errors="ignore"))
                    ip = addr[0]
                    if ip not in seen_ips:
                        msg["from"] = ip
                        msg["iface"] = iface
                        responses.append(msg)
                        seen_ips.add(ip)
                except socket.timeout:
                    break
                except json.JSONDecodeError:
                    continue
                except Exception:
                    break

            sock.close()

        except Exception as e:
            console.print(f"[red]❌ Error sending from {iface}: {e}[/red]")
            continue

    return responses


# ─────────────────────────────────────────────────────────────
# Main entry
# ─────────────────────────────────────────────────────────────
def discover_and_probe():
    responses = discover_multicast()
    if not responses:
        console.print("[yellow]No responses received.[/yellow]")
        return

    # Filter to SiMa devices
    sima_devices = [r for r in responses if r.get("mac", "").startswith(SIMA_OUI)]
    if not sima_devices:
        console.print(f"[yellow]No SiMa devices (OUI {SIMA_OUI}) found.[/yellow]")
        return

    console.print(f"✅ [green]Found {len(sima_devices)} SiMa device(s)[/green]\n")

    table = Table(title="SiMa Devices")
    table.add_column("IP", justify="center")
    table.add_column("MAC", justify="center")
    table.add_column("Machine", justify="center")
    table.add_column("Distro", justify="center")
    table.add_column("Build Version", justify="center")

    def probe(entry):
        ip = entry.get("ip") or entry.get("from")
        mac = entry.get("mac", "-")
        machine = entry.get("machine")
        distro = entry.get("distro")
        version = entry.get("version")

        # Fallback to SSH probing if fields missing
        if not machine or not distro or not version or version == "N/A":
            info = get_build_info_via_ssh(ip)
            machine = machine or info["machine"]
            distro = distro or info["distro"]
            version = version or info["version"]

        return ip, mac, machine, distro, version

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
        rows = list(ex.map(probe, sima_devices))

    for ip, mac, machine, distro, version in rows:
        table.add_row(ip, mac, machine, distro, version)

    console.print(table)


if __name__ == "__main__":
    discover_and_probe()
