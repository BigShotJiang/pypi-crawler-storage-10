from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8') if (this_directory / "README.md").exists() else ""

setup(
    name="prac-codes-dwm",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A simple package to display codes from codes.txt",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/prac-codes-dwm",
    packages=find_packages(),
    package_data={
        'prac_codes_dwm': ['codes.txt'],
    },
    include_package_data=True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.7",
    entry_points={
        'console_scripts': [
            'show-codes-dwm=prac_codes_dwm.main:show_codes',
        ],
    },
    install_requires=[],
)

