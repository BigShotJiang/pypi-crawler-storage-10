# prac-codes-dwm

A simple Python package that displays codes from a `codes.txt` file using a command-line interface.

## Installation

Install the package using pip:

```bash
pip install prac-codes-dwm
```

## Usage

After installation, you can display the codes using the following command:

```bash
show-codes-dwm
```

This will display all the content from the `codes.txt` file in your terminal.

## Package Structure

```
prac-codes-dwm/
├── prac_codes_dwm/
│   ├── __init__.py
│   ├── main.py
│   └── codes.txt
├── setup.py
├── pyproject.toml
├── MANIFEST.in
└── README.md
```

## Development

### Building the Package

To build the package locally:

```bash
python setup.py sdist bdist_wheel
```

Or using build:

```bash
pip install build
python -m build
```

This will create distribution files in the `dist/` directory.

### Testing Locally

To test the package locally before publishing:

```bash
pip install -e .
```

Then test the command:

```bash
show-codes-dwm
```

## Publishing to PyPI

### Prerequisites

1. Create accounts on:
   - [PyPI](https://pypi.org/account/register/) (for production)
   - [TestPyPI](https://test.pypi.org/account/register/) (for testing)

2. Install required tools:

```bash
pip install twine build
```

### Steps to Publish

1. **Update version number** in `setup.py` and `pyproject.toml` if needed

2. **Build the distribution files**:

```bash
python -m build
```

3. **Test on TestPyPI first** (recommended):

```bash
python -m twine upload --repository testpypi dist/*
```

You'll be prompted for credentials.

4. **Test installation from TestPyPI**:

```bash
pip install --index-url https://test.pypi.org/simple/ prac-codes-dwm
```

5. **Publish to PyPI** (production):

```bash
python -m twine upload dist/*
```

You'll be prompted for credentials.

### Using API Tokens (Recommended)

**IMPORTANT: Never put your API key in any package files!** API keys are only used during upload, not in your code.

To use an API token:

1. Go to your PyPI account settings: https://pypi.org/manage/account/token/
2. Generate an API token (for the entire account or a specific project)
3. When prompted by `twine upload`, use:
   - Username: `__token__`
   - Password: `pypi-<your-token-here>` (include the `pypi-` prefix)

**Alternative: Use environment variables** (more secure):

```bash
# For PyPI
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-your-token-here

# Then upload without prompts
python -m twine upload dist/*
```

**Or use a .pypirc file** (in your home directory, NOT in the package):

Create `~/.pypirc`:
```
[pypi]
username = __token__
password = pypi-your-token-here

[testpypi]
username = __token__
password = pypi-your-test-token-here
```

⚠️ **Security Note**: Never commit `.pypirc` or API keys to version control. Add it to `.gitignore` if storing locally.

## Updating the Package

When you need to publish an update:

1. Update the version number in `setup.py` and `pyproject.toml`
2. Build the package: `python -m build`
3. Upload: `python -m twine upload dist/*`

## License

MIT License

## Author

Your Name (your.email@example.com)

