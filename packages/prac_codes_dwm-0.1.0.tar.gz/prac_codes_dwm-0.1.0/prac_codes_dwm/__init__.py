"""
Prac Codes DWM Package
A simple package to display codes from codes.txt
"""

__version__ = "0.1.0"

