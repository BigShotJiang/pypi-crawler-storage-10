#!/usr/bin/env python3
"""
Main module to display codes from codes.txt
"""
import sys
import os
from pathlib import Path


def get_codes_file_path():
    """Get the path to codes.txt in the package directory."""
    # Get the directory where this package is installed
    package_dir = Path(__file__).parent
    codes_file = package_dir / "codes.txt"
    return codes_file


def show_codes():
    """Read and display the contents of codes.txt."""
    codes_file = get_codes_file_path()
    
    try:
        if not codes_file.exists():
            print(f"Error: codes.txt not found at {codes_file}", file=sys.stderr)
            sys.exit(1)
        
        with open(codes_file, 'r', encoding='utf-8') as f:
            content = f.read()
            print(content)
    
    except Exception as e:
        print(f"Error reading codes.txt: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    show_codes()

