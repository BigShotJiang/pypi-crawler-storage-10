# Maxwell

**Semantic workflow automation for codebases and documents** - A CLI-first tool for content analysis, search, and code quality.

Maxwell provides a plugin-like workflow system where each workflow is a self-contained analyzer, generator, or searcher. All workflows use the same CLI pattern: `maxwell [--debug] <workflow-id> [options]`.

## Why Maxwell?

**The Problem:** Modern development teams face three persistent challenges:

1. **Code quality decay** - Lint errors, type issues, and tech debt accumulate faster than you can fix them manually
2. **Knowledge fragmentation** - Important decisions, bugs, and discussions are scattered across chat logs, PDFs, and documentation
3. **Context loss** - Understanding codebases requires reading thousands of files, manually tracing dependencies, and reconstructing architectural decisions

**Maxwell's Solution:**

**🔧 Automated Quality Enforcement**
```bash
maxwell validate --fix  # Auto-fix 100+ code quality issues in seconds
```
- Runs pyright, ruff, eslint, tsc across your entire codebase
- Auto-fixes common issues (imports, formatting, type hints)
- Prevents dependency drift with `maxwell validate --fix` in CI/CD
- **Real use case**: Cleaned up 200+ type errors in a 50k-line codebase in under 2 minutes

**🧠 Semantic Code Understanding**
```bash
maxwell agentic-refactoring  # AI finds duplicate code you missed
```
- Graph-based DRY optimization finds duplicate logic across files
- LLM recommends refactoring strategies with safety analysis
- Multi-language support (Python, JavaScript, TypeScript)
- **Real use case**: Identified 15 duplicate validation functions spread across 8 files

**🔍 Universal Semantic Search**
```bash
maxwell chat-semantic-search --query "authentication bug fix"
```
- Search your Claude chat logs, PDFs, and documentation by *meaning*, not keywords
- Content-addressable storage means same document = same hash = deduplicated
- Works across formats: Markdown, PDF, Office docs, chat logs
- **Real use case**: Found that bug fix discussion from 3 months ago in 28MB of chat logs instantly

**📸 Instant Codebase Context**
```bash
maxwell snapshot --output SNAPSHOT.md  # Share your entire codebase in one file
```
- Generate markdown snapshot of entire codebase (filesystem tree + file contents)
- Perfect for sharing context with AI assistants or new team members
- **Real use case**: Onboarded new developer by sharing single 50-page snapshot instead of hour-long walkthrough

**Why not just use existing tools?**
- **vs linters alone**: Maxwell runs *all* of them (pyright + ruff + eslint + tsc) with auto-fix in one command
- **vs grep/ripgrep**: Maxwell understands *meaning*, not just text patterns (semantic search with embeddings)
- **vs manual refactoring**: Maxwell uses graph analysis + LLM to find patterns humans miss
- **vs reading docs**: Maxwell generates living documentation from your actual codebase

## Features

- **Workflow-based architecture** - Extensible plugin system for analysis tasks
- **Semantic search** - Find documents and conversations by meaning using embeddings
- **Multi-format extraction** - PDFs (marker-pdf), Office docs (markitdown), Claude chat logs (.jsonl)
- **Code quality** - Multi-language validation (Python, JavaScript, TypeScript), auto-fixing, dependency checking
- **Agentic refactoring** - DRY optimization using graph analysis and LLM reasoning
- **Codebase analysis** - Architecture linting, docstring enrichment, duplicate detection
- **Codebase snapshots** - Generate markdown documentation of entire codebases
- **Content-addressable storage** - Files identified by SHA256 hash, global deduplication
- **Distributed architecture** - Each directory has `.maxwell/` (like `.git/`)
- **Comprehensive logging** - Dual logging to console (stderr) and `.maxwell/logs/maxwell.log` with `--debug` flag

## Installation

```bash
pip install -e .
```

## Quick Start

### List Available Workflows

```bash
maxwell list-workflows
```

### Validate Code Quality

Run multi-language validators (Python, JavaScript, TypeScript) to check code quality:

```bash
# Run validation with auto-fix
maxwell validate --fix

# Show results in different formats
maxwell validate --format json > results.json
maxwell validate --format human
```

Built-in validators:
- **Python**: pyright, ruff, custom Maxwell validators
- **JavaScript/TypeScript**: eslint, tsc
- **Project-wide**: dependency sync, logging practices

### Agentic Refactoring

DRY optimization using graph analysis and LLM reasoning:

```bash
# Analyze duplicate code and generate refactoring plan
maxwell agentic-refactoring
```

Creates:
- `.maxwell/quality_worksheet.json` - Multi-language quality issues (pyright, ruff, eslint, tsc)
- `.maxwell/refactoring_report.md` - Duplicate code analysis with LLM recommendations

### Generate a Codebase Snapshot

Create a markdown file with filesystem tree and file contents:

```bash
maxwell snapshot --output SNAPSHOT.md
```

### Search Chat Conversations

Find discussions using semantic search:

```bash
maxwell chat-semantic-search --query "PDF parsing marker-pdf" --top-k 5
```

Or use BM25 keyword search:

```bash
maxwell chat-bm25-search --query "marker-pdf import error" --limit 10
```

### Enrich Docstrings

Generate rich docstrings for Python and JavaScript code:

```bash
maxwell docstring-enrichment
```

### Utilities

Get timestamps and session IDs for scripting:

```bash
maxwell get-time --format iso
maxwell get-session
```

### Debug Mode

Enable verbose console output for any workflow:

```bash
maxwell --debug validate
maxwell --debug agentic-refactoring
```

## Available Workflows

Run `maxwell list-workflows` for the full list. Key workflows:

### Code Quality & Refactoring
- **validate** - Multi-language code validation (Python, JS, TS) with auto-fix
- **agentic-refactoring** - DRY optimization using graph analysis and LLM reasoning
- **architecture-lint** - Validates Maxwell's plugin architecture rules
- **docstring-enrichment** - Generate rich docstrings for Python and JavaScript

### Search & Analysis
- **chat-semantic-search** - Semantic search over indexed chat logs
- **chat-bm25-search** - Keyword search over chat conversations
- **chat-upsert** - Index chat files into MongoDB with deduplication
- **temporal-concept-evolution** - Iterative concept discovery with ontology construction
- **deep-research** - Comprehensive research across chat and filesystem data

### Documentation & Utilities
- **snapshot** - Generate codebase documentation (markdown with tree + contents)
- **tag-refactor** - Format semantic HTML tags in markdown files
- **web-scrape** - Scrape web pages using crawl4ai with Playwright
- **get-time** / **get-session** - Utility workflows for timestamps and session IDs

## Configuration

Add to `pyproject.toml`:

```toml
[tool.maxwell]
include_globs = [
    "*.md", "**/*.md",
    "*.pdf", "**/*.pdf",
    "**/.claude/projects/*.jsonl"    # Include chat logs
]
exclude_globs = [
    ".maxwell/**",
    ".git/**",
    "__pycache__/**",
    "*.pyc"
]

# Validation rules (optional)
[tool.maxwell.validation]
rules = {
    EMOJI-IN-STRING = "WARN",
    DICT-GET-FALLBACK = "WARN",
    TYPING-POOR-PRACTICE = "WARN",
    DEPENDENCY-NOT-DECLARED = "WARN",
    LOGGING-POOR-PRACTICE = "WARN"
}
```

## Architecture

```
project/
├── .maxwell/                      # Like .git/, per-directory
│   ├── data/                      # Workflow-specific data (committed to git)
│   ├── logs/                      # Execution logs
│   │   ├── maxwell.log            # Full debug log (all workflows)
│   │   └── <session>.jsonl        # LLM conversation logs
│   ├── indexes/                   # SQLite indexes (gitignored, rebuildable)
│   ├── extracted/                 # Cached extractions (gitignored)
│   ├── quality_worksheet.json     # Multi-language quality issues (agentic-refactoring)
│   ├── refactoring_report.md      # Duplicate code analysis (agentic-refactoring)
│   └── .gitignore                 # Auto-created
└── your-files/

~/.maxwell/                        # Global cache
└── cache.db                       # Shared embedding cache (deduplication)
```

### Logging

Maxwell uses dual logging:
- **Console (stderr)**: INFO level by default, use `--debug` for DEBUG level
- **File (`.maxwell/logs/maxwell.log`)**: Always DEBUG level with timestamps
- **stdout**: Kept clean for actual output (JSON, reports)

```bash
# Normal: INFO to console, DEBUG to file
maxwell validate

# Verbose: DEBUG to console and file
maxwell --debug validate

# Redirect output: logs to stderr, JSON to stdout
maxwell validate --format json > output.json
```

## What Gets Indexed

Maxwell can work with:
- **Markdown files** (`.md`)
- **PDFs** (`.pdf`) - reuses existing parsed versions when available
- **Claude chat logs** (`.jsonl` in `.claude/projects/`)
- **Office documents** (`.docx`, `.pptx`, `.xlsx`)
- **Python code** (`.py`) - semantic code analysis

## Extending Maxwell

### Plugin System

Maxwell supports external plugins without modifying core code. Plugins are loaded from:
- `~/.maxwell/plugins/` (global plugins)
- `<project>/.maxwell/plugins/` (project-specific plugins)

**Two plugin types:**

1. **Python plugins**: `.py` files with `BaseWorkflow` subclasses
2. **Script plugins**: Executable scripts with `.json` metadata

Example script plugin:

```bash
#!/usr/bin/env bash
# ~/.maxwell/plugins/hello
echo "Hello from Maxwell plugin!"
```

```json
{
  "workflow_id": "hello",
  "name": "Hello Plugin",
  "description": "Simple hello world plugin",
  "category": "utility"
}
```

See [plugins/README.md](./plugins/README.md) for detailed plugin development guide.

### Core Workflow Development

To add workflows to Maxwell core:

1. Create a Python file in `src/maxwell/workflows/`
2. Define a `BaseWorkflow` subclass with `@register_workflow` decorator
3. Implement `execute()`, `get_cli_parameters()`, and schema classes
4. Import your workflow in `src/maxwell/workflows/__init__.py`

Example:

```python
from maxwell.workflows.base import BaseWorkflow
from maxwell.registry import register_workflow

@register_workflow
class MyWorkflow(BaseWorkflow):
    workflow_id = "my-workflow"
    name = "My Custom Workflow"
    description = "Does something cool"

    def execute(self, project_root: Path, context: Dict[str, Any]) -> WorkflowResult:
        # Your logic here
        pass
```

## Development

See [AGENTS.instructions.md](./AGENTS.instructions.md) for development guidelines.

### Testing

```bash
# Run formatters and linters
isort src/
black src/
ruff check --fix src/
pyright src/
```

## Documentation

- [Development Instructions](./AGENTS.instructions.md)
- [Claude Code Config](./.claude/settings.json)
- [MCP Documentation](./docs/README_MCP.md)
- [Schema Migration Guide](./docs/SCHEMA_MIGRATION.md)

## License

See LICENSE file.
