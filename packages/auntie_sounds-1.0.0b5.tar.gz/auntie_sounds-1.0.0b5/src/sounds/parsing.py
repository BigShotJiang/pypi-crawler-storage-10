from abc import ABC, abstractmethod
from typing import Dict, List, Type, Optional
from dataclasses import fields

from .constants import ItemType, ItemURN
from .models import BaseObject, PlayableItem, PodcastEpisode, RadioShow


class ModelParser(ABC):
    @abstractmethod
    def can_parse(self, data: dict) -> bool:
        """Check if this parser can handle the given data"""
        pass

    @abstractmethod
    def parse(self, data: dict) -> BaseObject:
        """Parse the data into a model object"""
        pass

    @abstractmethod
    def get_priority(self) -> int:
        """Return priority (lower = higher priority)"""
        pass

    def _create_object(self, data, object_type):
        required_fields = [f.name for f in fields(object_type)]
        return RadioShow(**{k: v for k, v in data.items() if k in required_fields})


class EpisodeParser(ModelParser):
    def can_parse(self, data: dict) -> bool:
        urn = data.get("urn", "")
        return data.get("type") == ItemType.PLAYABLE_ITEM.value and urn.startswith(
            ItemURN.EPISODE.value
        )

    def parse(self, data: dict) -> PlayableItem:
        container = data.get("container", {})
        network_id = container.get("network", {}).get("id")

        if network_id == "bbc_sounds_podcasts":
            return self._create_object(data, PodcastEpisode)
        else:
            return self._create_object(data, RadioShow)

    def get_priority(self) -> int:
        return 10

    def _create_podcast_episode(self, data: dict) -> PodcastEpisode:
        # Specific creation logic
        pass

    def _create_radio_show(self, data: dict) -> RadioShow:
        required_fields = [f.name for f in fields(RadioShow)]
        return RadioShow(**{k: v for k, v in data.items() if k in required_fields})


class ModelParserRegistry:
    def __init__(self):
        self._parsers: List[ModelParser] = []

    def register(self, parser: ModelParser):
        self._parsers.append(parser)
        # Sort by priority
        self._parsers.sort(key=lambda p: p.get_priority())

    def parse(self, data: dict) -> Optional[BaseObject]:
        for parser in self._parsers:
            if parser.can_parse(data):
                return parser.parse(data)
        return None


# Usage
registry = ModelParserRegistry()
registry.register(EpisodeParser())
# registry.register(StationParser())
# registry.register(ContainerParser())


def model_factory(data: dict) -> Optional[BaseObject]:
    return registry.parse(data)
