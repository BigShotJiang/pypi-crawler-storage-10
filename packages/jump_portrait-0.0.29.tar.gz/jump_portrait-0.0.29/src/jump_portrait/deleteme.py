from jump_portrait.fetch import get_item_location_info

cmpd_info_byinchi = get_item_location_info("CLETVKMYAXARPO-UHFFFAOYSA-N")
