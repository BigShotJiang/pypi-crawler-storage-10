from setuptools import setup, find_packages

setup(
    name='classictea',                # Must be unique on PyPI
    version='1.0.1',                 # Update each time you upload
    packages=find_packages(),
    include_package_data=True,
    description='WCNL HTML and JS codes for practice',
    author='Your Name',
    author_email='your.email@example.com',
    license='MIT',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://pypi.org/project/classictea/',
)