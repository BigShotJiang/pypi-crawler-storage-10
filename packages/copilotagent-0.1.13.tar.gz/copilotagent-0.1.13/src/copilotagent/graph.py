"""Deepagents come with planning, filesystem, and subagents."""

from collections.abc import Callable, Sequence
from typing import Any, Literal

from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware, InterruptOnConfig
from langchain.agents.middleware.summarization import SummarizationMiddleware
from langchain.agents.middleware.types import AgentMiddleware
from langchain.agents.structured_output import ResponseFormat
from langchain_anthropic import ChatAnthropic
from langchain_anthropic.middleware import AnthropicPromptCachingMiddleware
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import BaseTool
from langgraph.cache.base import BaseCache
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.types import Checkpointer

from copilotagent.middleware.filesystem import FilesystemMiddleware
from copilotagent.middleware.initial_message import InitialMessageMiddleware
from copilotagent.middleware.patch_tool_calls import PatchToolCallsMiddleware
from copilotagent.middleware.planning import PlanningMiddleware
from copilotagent.middleware.subagents import CompiledSubAgent, SubAgent, SubAgentMiddleware

# Global default agent type for planning middleware
DEFAULT_AGENT_TYPE: Literal["ITP-Princeton", "DrawDoc-AWM", "research"] = "ITP-Princeton"

BASE_AGENT_PROMPT = "In order to complete the objective that the user asks of you, you have access to a number of standard tools."

# Default starting messages for different agent types
DEFAULT_STARTING_MESSAGES = {
    "ITP-Princeton": "Let's review and approve Intent to Proceed for Princeton mortgage",
    "DrawDoc-AWM": "Run Encompass API test now. Test loan 65ec32a1-99df-4685-92ce-41a08fd3b64e with fields [\"4000\", \"4002\", \"4004\", \"353\"]. Test loan 387596ee-7090-47ca-8385-206e22c9c9da for documents list, entity data, and download attachment d78186cc-a8a2-454f-beaf-19f0e6c3aa8c.",
    "research": None,  # Research agents still get human input
}


def get_default_model() -> ChatAnthropic:
    """Get the default model for deep agents.

    Returns:
        ChatAnthropic instance configured with Claude Sonnet 4.
    """
    return ChatAnthropic(
        model_name="claude-sonnet-4-5-20250929",
        max_tokens=20000,
    )


def get_default_starting_message(
    agent_type: Literal["ITP-Princeton", "DrawDoc-AWM", "research"]
) -> str | None:
    """Get the default starting message for an agent type.

    Args:
        agent_type: The type of agent.

    Returns:
        Default starting message for the agent type, or None if no default.
    """
    return DEFAULT_STARTING_MESSAGES.get(agent_type)


def create_deep_agent(
    model: str | BaseChatModel | None = None,
    tools: Sequence[BaseTool | Callable | dict[str, Any]] | None = None,
    *,
    system_prompt: str | None = None,
    middleware: Sequence[AgentMiddleware] = (),
    subagents: list[SubAgent | CompiledSubAgent] | None = None,
    response_format: ResponseFormat | None = None,
    context_schema: type[Any] | None = None,
    checkpointer: Checkpointer | None = None,
    store: BaseStore | None = None,
    use_longterm_memory: bool = False,
    interrupt_on: dict[str, bool | InterruptOnConfig] | None = None,
    agent_type: Literal["ITP-Princeton", "DrawDoc-AWM", "research"] | None = None,
    planning_prompt: str | None = None,
    debug: bool = False,
    name: str | None = None,
    cache: BaseCache | None = None,
) -> CompiledStateGraph:
    """Create a deep agent.

    This agent will by default have access to a tool to write todos (write_todos),
    four file editing tools: write_file, ls, read_file, edit_file, and a tool to call
    subagents.

    Args:
        tools: The tools the agent should have access to.
        system_prompt: The additional instructions the agent should have. Will go in
            the system prompt.
        middleware: Additional middleware to apply after standard middleware.
        model: The model to use.
        subagents: The subagents to use. Each subagent should be a dictionary with the
            following keys:
                - `name`
                - `description` (used by the main agent to decide whether to call the
                  sub agent)
                - `prompt` (used as the system prompt in the subagent)
                - (optional) `tools`
                - (optional) `model` (either a LanguageModelLike instance or dict
                  settings)
                - (optional) `middleware` (list of AgentMiddleware)
        response_format: A structured output response format to use for the agent.
        context_schema: The schema of the deep agent.
        checkpointer: Optional checkpointer for persisting agent state between runs.
        store: Optional store for persisting longterm memories.
        use_longterm_memory: Whether to use longterm memory - you must provide a store
            in order to use longterm memory.
        interrupt_on: Optional Dict[str, bool | InterruptOnConfig] mapping tool names to
            interrupt configs.
        agent_type: Type of agent for planning prompts. Options: "ITP-Princeton",
            "DrawDoc-AWM", "research". Defaults to the global DEFAULT_AGENT_TYPE.
        planning_prompt: Custom planning prompt to use instead of the built-in prompt
            for the agent_type. This allows agents to provide their own planning
            prompts without modifying the PyPI package.
        debug: Whether to enable debug mode. Passed through to create_agent.
        name: The name of the agent. Passed through to create_agent.
        cache: The cache to use for the agent. Passed through to create_agent.

    Returns:
        A configured deep agent.
    """
    if model is None:
        model = get_default_model()

    # Use the provided agent_type or fall back to the global default
    if agent_type is None:
        agent_type = DEFAULT_AGENT_TYPE

    # Get the default starting message for this agent type
    default_starting_message = get_default_starting_message(agent_type)

    deepagent_middleware = [
        # Add initial message middleware first, so it can present default message
        # before any other processing happens
        InitialMessageMiddleware(
            agent_type=agent_type,
            default_message=default_starting_message,
        ),
        PlanningMiddleware(
            agent_type=agent_type,
            system_prompt=planning_prompt,
        ),
        FilesystemMiddleware(
            long_term_memory=use_longterm_memory,
        ),
        SubAgentMiddleware(
            default_model=model,
            default_tools=tools,
            subagents=subagents if subagents is not None else [],
            default_middleware=[
                PlanningMiddleware(
                    agent_type=agent_type,
                    system_prompt=planning_prompt,
                ),
                FilesystemMiddleware(
                    long_term_memory=use_longterm_memory,
                ),
                SummarizationMiddleware(
                    model=model,
                    max_tokens_before_summary=170000,
                    messages_to_keep=6,
                ),
                AnthropicPromptCachingMiddleware(unsupported_model_behavior="ignore"),
                PatchToolCallsMiddleware(),
            ],
            default_interrupt_on=interrupt_on,
            general_purpose_agent=True,
        ),
        SummarizationMiddleware(
            model=model,
            max_tokens_before_summary=170000,
            messages_to_keep=6,
        ),
        AnthropicPromptCachingMiddleware(unsupported_model_behavior="ignore"),
        PatchToolCallsMiddleware(),
    ]
    if interrupt_on is not None:
        deepagent_middleware.append(HumanInTheLoopMiddleware(interrupt_on=interrupt_on))
    if middleware is not None:
        deepagent_middleware.extend(middleware)

    return create_agent(
        model,
        system_prompt=system_prompt + "\n\n" + BASE_AGENT_PROMPT if system_prompt else BASE_AGENT_PROMPT,
        tools=tools,
        middleware=deepagent_middleware,
        response_format=response_format,
        context_schema=context_schema,
        checkpointer=checkpointer,
        store=store,
        debug=debug,
        name=name,
        cache=cache,
    ).with_config({"recursion_limit": 1000})
