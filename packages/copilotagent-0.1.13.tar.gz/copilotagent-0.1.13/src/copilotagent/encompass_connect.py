"""EncompassConnect - Interface to Encompass API and LandingAI document extraction.

This module provides a Python interface to the ICE Mortgage Technology (Encompass)
API for field operations and document management, with integrated LandingAI
document extraction capabilities.
"""

from __future__ import annotations

import base64
from functools import wraps
from typing import Any

import requests


class EncompassConnectError(Exception):
    """Base exception for EncompassConnect errors."""


class TokenRefreshError(EncompassConnectError):
    """Raised when token refresh fails."""


class APIError(EncompassConnectError):
    """Raised when an API request fails."""


class LandingAIError(EncompassConnectError):
    """Raised when LandingAI extraction fails."""


class EncompassConnect:
    """Client for interacting with Encompass API and LandingAI document extraction.

    This class provides methods to:
    - Read and write loan fields
    - Retrieve document metadata
    - Download document attachments
    - Extract data from documents using LandingAI

    Args:
        access_token: Encompass API access token (impersonation token)
        landingai_api_key: LandingAI API key for document extraction (optional)
        api_base_url: Base URL for Encompass API (default: https://api.elliemae.com)
        credentials: Dictionary containing credentials for token refresh:
            - username: Encompass username
            - password: Encompass password
            - client_id: OAuth client ID
            - client_secret: OAuth client secret
            - instance_id: Encompass instance ID
            - subject_user_id: User ID to impersonate
    """

    def __init__(
        self,
        access_token: str,
        landingai_api_key: str | None = None,
        api_base_url: str = "https://api.elliemae.com",
        credentials: dict[str, str] | None = None,
    ) -> None:
        """Initialize EncompassConnect client."""
        self.access_token = access_token
        self.landingai_api_key = landingai_api_key
        self.api_base_url = api_base_url.rstrip("/")
        self.credentials = credentials or {}

        # Validate credentials if provided
        if self.credentials:
            required_fields = ["username", "password", "client_id", "client_secret", "instance_id", "subject_user_id"]
            missing = [f for f in required_fields if f not in self.credentials]
            if missing:
                raise ValueError(f"Missing required credential fields: {', '.join(missing)}")

    def _check_token_validity(self) -> bool:
        """Check if the current access token is valid.

        Returns:
            True if the token is valid, False otherwise.
        """
        try:
            response = requests.get(
                f"{self.api_base_url}/encompass/v1/company/users/me",
                headers={"Authorization": f"Bearer {self.access_token}", "Accept": "application/json"},
                timeout=10,
            )
            return response.status_code == 200
        except Exception:
            return False

    def refresh_token(self) -> str:
        """Refresh the access token using stored credentials.

        This implements a 2-step OAuth flow:
        1. Get Super Admin token using password grant
        2. Get Impersonation token using token exchange

        Returns:
            New access token

        Raises:
            TokenRefreshError: If token refresh fails or credentials are not set
        """
        if not self.credentials:
            raise TokenRefreshError("Cannot refresh token: credentials not provided during initialization")

        try:
            # Step 1: Get Super Admin token
            response = requests.post(
                f"{self.api_base_url}/oauth2/v1/token",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={
                    "grant_type": "password",
                    "username": f"{self.credentials['username']}@encompass:{self.credentials['instance_id']}",
                    "password": self.credentials["password"],
                    "client_id": self.credentials["client_id"],
                    "client_secret": self.credentials["client_secret"],
                    "scope": "lp",
                },
                timeout=10,
            )

            if response.status_code != 200:
                raise TokenRefreshError(f"Failed to get Super Admin token: {response.text}")

            actor_token = response.json().get("access_token")
            if not actor_token:
                raise TokenRefreshError("No access_token in Super Admin token response")

            # Step 2: Get Impersonation token
            response = requests.post(
                f"{self.api_base_url}/oauth2/v1/token",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:token-exchange",
                    "actor_token_type": "urn:ietf:params:oauth:token-type:access_token",
                    "subject_user_id": self.credentials["subject_user_id"],
                    "actor_token": actor_token,
                    "scope": "lp",
                    "client_id": self.credentials["client_id"],
                    "client_secret": self.credentials["client_secret"],
                },
                timeout=10,
            )

            if response.status_code != 200:
                raise TokenRefreshError(f"Failed to get Impersonation token: {response.text}")

            impersonation_token = response.json().get("access_token")
            if not impersonation_token:
                raise TokenRefreshError("No access_token in Impersonation token response")

            # Update the stored token
            self.access_token = impersonation_token
            return impersonation_token

        except requests.exceptions.RequestException as e:
            raise TokenRefreshError(f"Network error during token refresh: {e}") from e
        except KeyError as e:
            raise TokenRefreshError(f"Missing credential field: {e}") from e

    def _auto_refresh_on_401(func):  # noqa: N805
        """Decorator to automatically refresh token on 401 Unauthorized responses."""

        @wraps(func)
        def wrapper(self, *args, **kwargs):  # noqa: ANN001, ANN002, ANN003, ANN202
            try:
                return func(self, *args, **kwargs)
            except APIError as e:
                # Check if it's a 401 error
                if "401" in str(e) or "Unauthorized" in str(e):
                    # Try to refresh the token
                    try:
                        self.refresh_token()
                        # Retry the original function with the new token
                        return func(self, *args, **kwargs)
                    except TokenRefreshError:
                        # If refresh fails, re-raise the original error
                        raise e from None
                # If not a 401 error, re-raise
                raise

        return wrapper

    @_auto_refresh_on_401
    def get_field(self, loan_id: str, field_ids: str | list[str]) -> dict[str, Any]:
        """Retrieve one or multiple loan fields.

        Args:
            loan_id: The loan GUID
            field_ids: Single field ID string or list of field IDs

        Returns:
            Dictionary mapping field IDs to their values

        Raises:
            APIError: If the API request fails

        Example:
            >>> client = EncompassConnect(token)
            >>> # Get single field
            >>> result = client.get_field("loan-guid", "4000")
            >>> # Get multiple fields
            >>> result = client.get_field("loan-guid", ["4000", "4002", "4004"])
        """
        # Normalize input to list
        if isinstance(field_ids, str):
            field_ids = [field_ids]

        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}/fieldReader"
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
            "content-type": "application/json",
        }

        try:
            response = requests.post(url, json=field_ids, headers=headers, timeout=30)

            if response.status_code != 200:
                raise APIError(f"Field read failed (status {response.status_code}): {response.text}")

            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during field read: {e}") from e

    @_auto_refresh_on_401
    def write_field(self, loan_id: str, field_id: str, value: Any) -> bool:
        """Write a single loan field value.

        Args:
            loan_id: The loan GUID
            field_id: The field ID to write
            value: The value to set

        Returns:
            True if successful

        Raises:
            APIError: If the API request fails

        Example:
            >>> client = EncompassConnect(token)
            >>> client.write_field("loan-guid", "4000", 350000)
        """
        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}"
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
            "content-type": "application/json",
        }

        # Construct the payload with the field to update
        payload = {field_id: value}

        try:
            response = requests.patch(url, json=payload, headers=headers, timeout=30)

            if response.status_code not in (200, 204):
                raise APIError(f"Field write failed (status {response.status_code}): {response.text}")

            return True

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during field write: {e}") from e

    @_auto_refresh_on_401
    def get_loan_documents(self, loan_id: str) -> list[dict[str, Any]]:
        """List all documents in a loan with their attachment metadata.

        Args:
            loan_id: The loan GUID

        Returns:
            List of document dictionaries, each containing document metadata including
            attachments with their IDs

        Raises:
            APIError: If the API request fails

        Example:
            >>> client = EncompassConnect(token)
            >>> docs = client.get_loan_documents("loan-guid")
            >>> for doc in docs:
            ...     print(f"{doc['title']}: {len(doc.get('attachments', []))} attachments")
            ...     for att in doc.get('attachments', []):
            ...         print(f"  - {att.get('attachmentId')}")
        """
        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}/documents"
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }

        try:
            response = requests.get(url, headers=headers, timeout=30)

            if response.status_code != 200:
                raise APIError(f"Document list retrieval failed (status {response.status_code}): {response.text}")

            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during document list retrieval: {e}") from e

    @_auto_refresh_on_401
    def get_loan_entity(self, loan_id: str) -> dict[str, Any]:
        """Get full loan data including all fields and custom fields.

        This retrieves the complete loan entity with view=entity parameter which
        includes standard fields, custom fields, and other loan data.

        Args:
            loan_id: The loan GUID

        Returns:
            Dictionary containing complete loan data

        Raises:
            APIError: If the API request fails

        Example:
            >>> client = EncompassConnect(token)
            >>> loan = client.get_loan_entity("loan-guid")
            >>> print(f"Loan Number: {loan.get('loanNumber')}")
            >>> print(f"Borrower: {loan.get('borrowerFirstName')} {loan.get('borrowerLastName')}")
        """
        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}"
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }
        params = {"view": "entity"}

        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)

            if response.status_code != 200:
                raise APIError(f"Loan entity retrieval failed (status {response.status_code}): {response.text}")

            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during loan entity retrieval: {e}") from e

    @_auto_refresh_on_401
    def get_document(self, loan_id: str, document_id: str) -> dict[str, Any]:
        """Retrieve document metadata including attachments list.

        Args:
            loan_id: The loan GUID
            document_id: The document GUID

        Returns:
            Dictionary containing document metadata and attachments

        Raises:
            APIError: If the API request fails

        Example:
            >>> client = EncompassConnect(token)
            >>> doc = client.get_document("loan-guid", "doc-guid")
            >>> print(doc['title'])
            >>> print(doc['attachments'])
        """
        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}/documents/{document_id}"
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }

        try:
            response = requests.get(url, headers=headers, timeout=30)

            if response.status_code == 404:
                raise APIError(f"Document not found: {document_id}")
            if response.status_code != 200:
                raise APIError(f"Document retrieval failed (status {response.status_code}): {response.text}")

            return response.json()

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during document retrieval: {e}") from e

    @_auto_refresh_on_401
    def download_attachment(self, loan_id: str, attachment_id: str) -> bytes:
        """Download a document attachment as bytes.

        This method handles both Cloud Storage (with authorization header) and
        Legacy (with signed URL) storage types.

        Args:
            loan_id: The loan GUID
            attachment_id: The attachment entity ID

        Returns:
            Document content as bytes

        Raises:
            APIError: If the download fails

        Example:
            >>> client = EncompassConnect(token)
            >>> pdf_bytes = client.download_attachment("loan-guid", "attachment-guid")
            >>> # Save to file
            >>> with open("document.pdf", "wb") as f:
            ...     f.write(pdf_bytes)
        """
        # Step 1: Get download URL
        url = f"{self.api_base_url}/encompass/v3/loans/{loan_id}/attachmentDownloadUrl"
        payload = {"attachments": [attachment_id]}
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {self.access_token}",
            "content-type": "application/json",
        }

        try:
            response = requests.post(url, json=payload, headers=headers, timeout=30)

            if response.status_code != 200:
                raise APIError(f"Failed to get download URL (status {response.status_code}): {response.text}")

            data = response.json()

            # Extract download information
            attachments = data.get("attachments", [])
            if not attachments:
                raise APIError("No download information returned")

            attachment_info = attachments[0]

            # Determine download URL and auth method based on storage type
            download_url = None
            authorization_header = attachment_info.get("authorizationHeader")

            # Cloud Storage (newer documents) - has 'url' field
            if attachment_info.get("url"):
                download_url = attachment_info.get("url")
            # Legacy - multi-page documents with originalUrls
            elif attachment_info.get("originalUrls"):
                download_url = attachment_info.get("originalUrls")[0]
            # Page-based (converted documents)
            elif attachment_info.get("pages"):
                download_url = attachment_info.get("pages")[0].get("url")

            if not download_url:
                raise APIError(f"No download URL found in response. Available fields: {list(attachment_info.keys())}")

            # Step 2: Download the actual file
            download_headers = {}
            if authorization_header:
                # Cloud Storage requires the authorization header
                download_headers["Authorization"] = authorization_header

            download_response = requests.get(download_url, headers=download_headers, stream=True, timeout=60)

            if download_response.status_code != 200:
                raise APIError(f"Failed to download file (status {download_response.status_code}): {download_response.text}")

            # Collect the file content
            content = b""
            for chunk in download_response.iter_content(chunk_size=8192):
                if chunk:
                    content += chunk

            return content

        except requests.exceptions.RequestException as e:
            raise APIError(f"Network error during download: {e}") from e

    def extract_document_data(self, document_bytes: bytes, schema: dict[str, Any], doc_type: str | None = None, filename: str = "document.pdf") -> dict[str, Any]:
        """Extract structured data from a document using LandingAI.

        Uses the LandingAI Agentic Document Extraction API to parse and extract
        structured data from documents in a single request.

        Args:
            document_bytes: Document content as bytes
            schema: JSON schema defining what data to extract. Format:
                {
                    "type": "object",
                    "properties": {
                        "field_name": {"type": "string", "title": "Field Name", "description": "..."},
                        "amount": {"type": "number", "title": "Amount", "description": "..."},
                        ...
                    }
                }
            doc_type: Optional document type label for logging/metadata
            filename: Name of the file being processed (default: "document.pdf")

        Returns:
            Dictionary containing extracted data and metadata

        Raises:
            LandingAIError: If extraction fails or API key not set

        Example:
            >>> client = EncompassConnect(token, landingai_api_key="key")
            >>> pdf_bytes = client.download_attachment("loan-id", "attach-id")
            >>> schema = {
            ...     "type": "object",
            ...     "properties": {
            ...         "loan_amount": {"type": "number", "title": "Loan Amount"},
            ...         "borrower_name": {"type": "string", "title": "Borrower Name"}
            ...     }
            ... }
            >>> result = client.extract_document_data(pdf_bytes, schema, "1003")
            >>> print(result['extracted_schema'])
        """
        if not self.landingai_api_key:
            raise LandingAIError("LandingAI API key not set. Provide landingai_api_key during initialization.")

        try:
            import json
            import io

            # Prepare the API request using the new LandingAI API format
            url = "https://api.va.landing.ai/v1/tools/agentic-document-analysis"
            headers = {"Authorization": f"Basic {self.landingai_api_key}"}

            # Create file-like object from bytes
            file_obj = io.BytesIO(document_bytes)

            files = [("pdf", (filename, file_obj, "application/pdf"))]
            payload = {"fields_schema": json.dumps(schema)}

            # Make the extraction request
            response = requests.post(url, headers=headers, files=files, data=payload, timeout=60)

            if not response.ok:
                raise LandingAIError(f"Document extraction failed (status {response.status_code}): {response.text}")

            result = response.json()

            # Extract the data from the response
            output_data = result.get("data", {})
            extracted_schema = output_data.get("extracted_schema", {})

            # Return structured result
            return {
                "extracted_schema": extracted_schema,
                "doc_type": doc_type,
                "extraction_method": "landingai-agentic",
                "raw_response": output_data,
            }

        except requests.exceptions.RequestException as e:
            raise LandingAIError(f"Network error during extraction: {e}") from e
        except Exception as e:
            if isinstance(e, LandingAIError):
                raise
            raise LandingAIError(f"Unexpected error during extraction: {e}") from e


