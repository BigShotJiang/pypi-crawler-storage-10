"""Middleware for the CopilotAgent."""

from copilotagent.middleware.filesystem import FilesystemMiddleware
from copilotagent.middleware.initial_message import InitialMessageMiddleware
from copilotagent.middleware.planning import PlanningMiddleware
from copilotagent.middleware.subagents import CompiledSubAgent, SubAgent, SubAgentMiddleware

__all__ = [
    "CompiledSubAgent",
    "FilesystemMiddleware",
    "InitialMessageMiddleware",
    "PlanningMiddleware",
    "SubAgent",
    "SubAgentMiddleware",
]
