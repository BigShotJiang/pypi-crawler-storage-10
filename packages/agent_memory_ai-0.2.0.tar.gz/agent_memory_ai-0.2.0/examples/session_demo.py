"""
会话管理演示

展示跨会话管理功能
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType
from storage.sqlite_store import SQLiteStore
from modules.formation import MemoryFormer
from modules.session import SessionManager


def demo_session_lifecycle():
    """演示完整的会话生命周期"""
    print("=" * 70)
    print("演示：完整的会话生命周期")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        session_mgr = SessionManager(store)
        former = MemoryFormer()
        
        user_id = "demo_user"
        
        # 场景：第一次会话
        print("\n📅 第一次会话")
        print("-" * 70)
        
        session1_id = "session_001"
        
        # 开始会话
        print("\n1️⃣  开始会话")
        context = session_mgr.start_session(user_id, session1_id)
        print(f"  会话ID: {context['session_id']}")
        print(f"  一致性问题: {len(context['consistency_issues'])}")
        
        # 模拟对话
        print("\n2️⃣  进行对话")
        messages1 = [
            {"role": "user", "content": "我想学习Python编程"},
            {"role": "assistant", "content": "很好，Python是一门强大的语言"},
            {"role": "user", "content": "我决定从基础开始"},
            {"role": "assistant", "content": "明智的选择"},
            {"role": "user", "content": "需要完成三个练习"},
        ]
        
        for msg in messages1:
            print(f"  {msg['role']}: {msg['content'][:30]}...")
        
        # 形成记忆
        print("\n3️⃣  形成记忆")
        memory1 = former.form_memory_from_text("学习Python编程基础", user_id)
        if memory1:
            store.create_memory(memory1)
            print(f"  ✓ 创建记忆: {memory1.content}")
        
        # 结束会话
        print("\n4️⃣  结束会话并生成摘要")
        start_time1 = datetime.now() - timedelta(hours=1)
        summary1 = session_mgr.end_session(
            user_id,
            session1_id,
            messages1,
            start_time1
        )
        
        print(f"  会话摘要: {summary1.summary}")
        print(f"  关键主题: {summary1.key_topics[:3]}")
        print(f"  决策: {summary1.decisions[:2]}")
        print(f"  待办任务: {summary1.pending_tasks}")
        
        # 场景：第二次会话（2天后）
        print("\n\n📅 第二次会话（2天后）")
        print("-" * 70)
        
        session2_id = "session_002"
        
        # 开始会话
        print("\n1️⃣  开始会话")
        context2 = session_mgr.start_session(user_id, session2_id)
        print(f"  会话ID: {context2['session_id']}")
        
        # 检查提醒
        if context2.get('reminder'):
            print(f"  💡 提醒: {context2['reminder']}")
        
        # 显示上下文
        print(f"\n2️⃣  会话上下文")
        ctx = context2['context']
        print(f"  核心记忆: {ctx['user_profile']['core_memories'][:2]}")
        print(f"  最近话题: {ctx['recent_topics'][:3]}")
        print(f"  待办任务: {ctx['pending_tasks']}")
        
        # 继续对话
        print("\n3️⃣  继续对话")
        messages2 = [
            {"role": "assistant", "content": "欢迎回来！上次您提到要学习Python"},
            {"role": "user", "content": "是的，我已经完成了一个练习"},
            {"role": "assistant", "content": "太好了！"},
            {"role": "user", "content": "现在想学习面向对象"},
        ]
        
        for msg in messages2:
            print(f"  {msg['role']}: {msg['content'][:40]}...")
        
        # 新记忆
        print("\n4️⃣  形成新记忆")
        memory2 = former.form_memory_from_text("学习Python面向对象编程", user_id)
        if memory2:
            store.create_memory(memory2)
            print(f"  ✓ 创建记忆: {memory2.content}")
        
        # 结束会话
        print("\n5️⃣  结束会话")
        start_time2 = datetime.now() - timedelta(minutes=45)
        summary2 = session_mgr.end_session(
            user_id,
            session2_id,
            messages2,
            start_time2
        )
        
        print(f"  会话摘要: {summary2.summary}")
        print(f"  关键主题: {summary2.key_topics[:3]}")
        
        # 查看进展
        print("\n\n📊 用户进展总结")
        print("-" * 70)
        progress = session_mgr.get_user_progress(user_id)
        
        print(f"  总记忆数: {progress['total_memories']}")
        print(f"  核心记忆数: {progress['core_memories']}")
        print(f"  总会话数: {progress['total_sessions']}")
        print(f"  最近话题: {progress['recent_topics'][:5]}")
        print(f"  平均重要性: {progress['avg_importance']:.3f}")


def demo_consistency_check():
    """演示一致性检查"""
    print("\n\n" + "=" * 70)
    print("演示：一致性检查")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        session_mgr = SessionManager(store)
        former = MemoryFormer()
        
        user_id = "demo_user"
        
        # 创建可能冲突的记忆
        print("\n1️⃣  创建记忆")
        
        mem1 = former.form_memory_from_text("我喜欢使用Python", user_id)
        if mem1:
            mem1.created_at = datetime.now() - timedelta(days=10)
            store.create_memory(mem1)
            print(f"  10天前: {mem1.content}")
        
        mem2 = former.form_memory_from_text("我不太喜欢Python的语法", user_id)
        if mem2:
            store.create_memory(mem2)
            print(f"  今天: {mem2.content}")
        
        # 检查一致性
        print("\n2️⃣  检查一致性")
        issues = session_mgr.check_consistency(user_id)
        
        if issues:
            print(f"  发现 {len(issues)} 个问题:")
            for i, issue in enumerate(issues, 1):
                print(f"\n  问题{i}:")
                print(f"    类型: {issue.issue_type.value}")
                print(f"    严重程度: {issue.severity.value}")
                print(f"    描述: {issue.description}")
                print(f"    建议: {issue.suggested_action}")
        else:
            print("  ✓ 未发现一致性问题")
        
        # 解决问题
        if issues:
            print("\n3️⃣  解决一致性问题")
            result = session_mgr.resolve_consistency_issues(user_id, auto_resolve=True)
            print(f"  总问题数: {result['total_issues']}")
            print(f"  已解决: {result['resolved']}")
            print(f"  跳过: {result['skipped']}")


def demo_session_report():
    """演示会话报告"""
    print("\n\n" + "=" * 70)
    print("演示：会话报告")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        session_mgr = SessionManager(store)
        former = MemoryFormer()
        
        user_id = "demo_user"
        
        # 创建一些记忆
        print("\n1️⃣  模拟一周的活动")
        
        topics = ["Python基础", "数据结构", "算法学习", "项目开发"]
        
        for i, topic in enumerate(topics):
            memory = former.form_memory_from_text(topic, user_id)
            if memory:
                memory.created_at = datetime.now() - timedelta(days=7-i*2)
                store.create_memory(memory)
                print(f"  {7-i*2}天前: {topic}")
        
        # 生成报告
        print("\n2️⃣  生成7天报告")
        report = session_mgr.generate_session_report(user_id, days=7)
        
        print(f"\n  📋 报告内容:")
        print(f"  统计期间: {report['period']}")
        print(f"  会话数: {report['session_count']}")
        print(f"  总记忆数: {report['total_memories']}")
        print(f"  记忆增长: {report['memory_growth']} 条")
        print(f"  最近话题: {report['recent_topics'][:5]}")
        print(f"  平均重要性: {report['avg_importance']:.3f}")


def main():
    """运行所有演示"""
    print("\n" + "🎯" * 35)
    print("会话管理功能演示")
    print("🎯" * 35 + "\n")
    
    demo_session_lifecycle()
    demo_consistency_check()
    demo_session_report()
    
    print("\n\n" + "=" * 70)
    print("🎉 演示完成！")
    print("=" * 70)
    print("\n展示了以下功能:")
    print("  ✓ 完整的会话生命周期（开始→对话→结束）")
    print("  ✓ 会话摘要自动生成")
    print("  ✓ 跨会话上下文恢复")
    print("  ✓ 智能提醒机制")
    print("  ✓ 一致性检查与解决")
    print("  ✓ 用户进展追踪")
    print("  ✓ 会话报告生成")
    print("\n")


if __name__ == "__main__":
    main()

