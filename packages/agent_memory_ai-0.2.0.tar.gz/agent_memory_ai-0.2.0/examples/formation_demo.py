"""
记忆形成模块演示

展示如何使用记忆形成功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.memory import MemoryType, MemoryCategory
from storage.sqlite_store import SQLiteStore
from modules.formation.classifier import MemoryClassifier


def demo_classifier():
    """演示记忆分类器"""
    print("\n" + "=" * 70)
    print(" " * 20 + "记忆分类演示")
    print("=" * 70)
    
    classifier = MemoryClassifier()
    
    # 演示不同的文本分类
    test_texts = [
        ("我喜欢使用Python进行数据分析", "偏好记忆"),
        ("上次项目中遇到了内存泄漏问题", "经验记忆"),
        ("机器学习是AI的重要分支", "知识记忆"),
        ("今天讨论了系统架构设计", "情境记忆"),
        ("我认为代码质量是最重要的", "反思记忆"),
        ("记住这个配置很重要", "元记忆")
    ]
    
    print("\n📝 文本 → 记忆维度分类:")
    print("-" * 70)
    
    for text, expected in test_texts:
        category = classifier.classify_category(text)
        print(f"\n文本: {text}")
        print(f"分类: {category.value} ({expected})")
        
        # 生成标签
        tags = classifier.generate_tags(text)
        if tags:
            print(f"标签: {', '.join(tags[:5])}")


def demo_importance_levels():
    """演示不同重要性级别的分类"""
    print("\n" + "=" * 70)
    print(" " * 20 + "重要性分类演示")
    print("=" * 70)
    
    classifier = MemoryClassifier()
    
    importance_examples = [
        (0.95, "用户核心价值观：重视代码质量和可维护性"),
        (0.75, "用户擅长Python和数据分析"),
        (0.55, "最近在学习机器学习"),
        (0.35, "今天讨论了API设计"),
        (0.15, "临时笔记：测试环境配置")
    ]
    
    print("\n⭐ 重要性 → 记忆类型:")
    print("-" * 70)
    
    for importance, description in importance_examples:
        memory_type = classifier.classify_memory_type(importance, description)
        
        print(f"\n重要性: {importance:.2f}")
        print(f"类型: {memory_type.value}")
        print(f"描述: {description}")


def demo_privacy_detection():
    """演示隐私级别检测"""
    print("\n" + "=" * 70)
    print(" " * 20 + "隐私检测演示")
    print("=" * 70)
    
    classifier = MemoryClassifier()
    
    privacy_examples = [
        "我的密码是123456",
        "公司的机密文档在这里",
        "我的收入情况如下",
        "今天学习了Python编程",
    ]
    
    print("\n🔒 文本 → 隐私级别:")
    print("-" * 70)
    
    for text in privacy_examples:
        privacy = classifier.determine_privacy_level(text)
        
        emoji = "🚨" if privacy == "private" else ("⚠️" if privacy == "sensitive" else "✅")
        print(f"\n{emoji} [{privacy.upper():9s}] {text}")


def demo_tag_generation():
    """演示标签生成"""
    print("\n" + "=" * 70)
    print(" " * 20 + "标签生成演示")
    print("=" * 70)
    
    classifier = MemoryClassifier()
    
    texts = [
        "使用Python和PyTorch进行深度学习模型训练",
        "FastAPI框架用于构建高性能API服务",
        "数据库设计中的索引优化策略",
        "React前端组件的状态管理方案"
    ]
    
    print("\n🏷️  文本 → 自动标签:")
    print("-" * 70)
    
    for text in texts:
        tags = classifier.generate_tags(text)
        print(f"\n文本: {text}")
        print(f"标签: {', '.join(tags) if tags else '无'}")


def demo_complete_classification():
    """演示完整的分类流程"""
    print("\n" + "=" * 70)
    print(" " * 20 + "完整分类流程演示")
    print("=" * 70)
    
    classifier = MemoryClassifier()
    
    text = "我非常喜欢使用Python进行数据分析，特别是Pandas和NumPy库，" \
           "之前项目中积累了很多经验，我认为数据质量是最核心的"
    
    print(f"\n📄 输入文本:")
    print(f"{text}")
    
    # 1. 分类维度
    category = classifier.classify_category(text)
    print(f"\n✓ 记忆维度: {category.value}")
    
    # 2. 假设重要性为0.75
    importance = 0.75
    memory_type = classifier.classify_memory_type(importance, text)
    print(f"✓ 记忆类型: {memory_type.value} (重要性: {importance})")
    
    # 3. 生成标签
    tags = classifier.generate_tags(text)
    print(f"✓ 生成标签: {', '.join(tags)}")
    
    # 4. 隐私检测
    privacy = classifier.determine_privacy_level(text)
    print(f"✓ 隐私级别: {privacy}")
    
    # 5. 来源类型
    source = classifier.classify_source_type(None)
    print(f"✓ 来源类型: {source}")
    
    print(f"\n✅ 分类完成！")
    print(f"最终结果: [{memory_type.value}] [{category.value}]")


def demo_with_database():
    """演示与数据库集成"""
    print("\n" + "=" * 70)
    print(" " * 20 + "数据库集成演示")
    print("=" * 70)
    
    from core.memory import Memory, UserProfile
    
    store = SQLiteStore(db_path=":memory:")
    classifier = MemoryClassifier()
    
    # 创建用户
    profile = UserProfile(
        user_id="demo_user",
        domain="软件开发",
        preferences={"language": "Python"}
    )
    store.create_or_update_profile(profile)
    print("\n✓ 创建用户画像")
    
    # 创建几条记忆
    texts_with_importance = [
        ("我喜欢Python", 0.7),
        ("上次项目很成功", 0.8),
        ("今天学习了新知识", 0.5),
        ("代码质量最重要", 0.9)
    ]
    
    print("\n创建记忆:")
    for text, importance in texts_with_importance:
        memory_type = classifier.classify_memory_type(importance, text)
        category = classifier.classify_category(text)
        tags = classifier.generate_tags(text)
        
        memory = Memory(
            user_id="demo_user",
            content=text,
            memory_type=memory_type,
            category=category,
            importance=importance,
            tags=tags
        )
        
        store.create_memory(memory)
        print(f"  [{memory_type.value:5s}] [{category.value:11s}] {text}")
    
    # 统计
    all_memories = store.get_memories_by_user("demo_user")
    print(f"\n✓ 共创建 {len(all_memories)} 条记忆")
    
    # 按类型统计
    type_counts = {}
    for mem in all_memories:
        type_counts[mem.memory_type.value] = type_counts.get(mem.memory_type.value, 0) + 1
    
    print(f"✓ 类型分布: {type_counts}")


def main():
    """运行所有演示"""
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + " " * 18 + "记忆形成模块演示" + " " * 32 + "║")
    print("╚" + "═" * 68 + "╝")
    
    demos = [
        ("1. 记忆维度分类", demo_classifier),
        ("2. 重要性级别分类", demo_importance_levels),
        ("3. 隐私级别检测", demo_privacy_detection),
        ("4. 标签自动生成", demo_tag_generation),
        ("5. 完整分类流程", demo_complete_classification),
        ("6. 数据库集成", demo_with_database)
    ]
    
    for name, func in demos:
        try:
            func()
        except Exception as e:
            print(f"\n⚠️  演示 {name} 出错: {e}")
    
    print("\n" + "=" * 70)
    print("✓ 演示完成！")
    print("=" * 70)
    
    print("\n💡 提示:")
    print("  • 这些功能已集成到 MemoryFormer 中")
    print("  • 配置LLM API后可获得更好的提取效果")
    print("  • 查看 examples/quick_start.py 了解完整用法")
    print()


if __name__ == "__main__":
    main()

