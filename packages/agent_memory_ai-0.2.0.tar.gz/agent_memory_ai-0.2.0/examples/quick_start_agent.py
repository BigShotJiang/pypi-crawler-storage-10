"""
快速开始示例 - 使用AgentMemory主类

展示如何使用统一的AgentMemory接口
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent_memory import AgentMemory


def basic_usage():
    """基础使用示例"""
    print("=" * 70)
    print("示例1: 基础使用")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        # 创建Agent记忆系统
        print("\n1️⃣  初始化Agent记忆系统")
        agent = AgentMemory(
            user_id="alice",
            db_path=db_path,
            use_vector_store=False  # 简化演示
        )
        print(f"  {agent}")
        
        # 记忆一些内容
        print("\n2️⃣  记忆一些内容")
        mem1 = agent.memorize("我喜欢使用Python编程")
        print(f"  ✓ 记忆1: {mem1.content if mem1 else 'None'}")
        
        mem2 = agent.memorize("我正在学习机器学习")
        print(f"  ✓ 记忆2: {mem2.content if mem2 else 'None'}")
        
        mem3 = agent.memorize("我计划下周完成一个NLP项目")
        print(f"  ✓ 记忆3: {mem3.content if mem3 else 'None'}")
        
        # 检索记忆
        print("\n3️⃣  检索记忆")
        results = agent.recall("Python", top_k=3)
        print(f"  检索到 {len(results)} 条记忆:")
        for r in results:
            print(f"    - {r.content}")
        
        # 获取统计
        print("\n4️⃣  查看统计")
        stats = agent.get_statistics()
        print(f"  总记忆数: {stats['progress']['total_memories']}")
        print(f"  平均重要性: {stats['progress']['avg_importance']:.3f}")
        
        print("\n✅ 基础使用完成")


def session_usage():
    """会话管理示例"""
    print("\n\n" + "=" * 70)
    print("示例2: 会话管理")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        agent = AgentMemory(user_id="bob", db_path=db_path, use_vector_store=False)
        
        # 方式1: 手动管理会话
        print("\n1️⃣  手动管理会话")
        context = agent.start_session()
        print(f"  会话ID: {context['session_id']}")
        
        agent.add_message("user", "你好")
        agent.add_message("assistant", "你好！有什么可以帮你的吗？")
        
        agent.memorize("学习深度学习")
        
        summary = agent.end_session()
        print(f"  会话摘要: {summary['summary']}")
        
        # 方式2: 使用上下文管理器
        print("\n2️⃣  使用上下文管理器")
        with agent as session:
            session.chat("我想学习强化学习", "好的，我可以帮你")
            session.memorize("学习强化学习")
        print("  会话自动结束")
        
        print("\n✅ 会话管理完成")


def chat_usage():
    """对话示例"""
    print("\n\n" + "=" * 70)
    print("示例3: 对话处理")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        agent = AgentMemory(user_id="charlie", db_path=db_path, use_vector_store=False)
        
        print("\n模拟多轮对话")
        
        # 第一轮
        print("\n1️⃣  第一轮对话")
        result1 = agent.chat(
            "我想学习数据科学",
            "很好的选择！数据科学是一个很有前景的领域",
            memorize_user=True
        )
        if result1['user_memory']:
            print(f"  ✓ 记住: {result1['user_memory'].content}")
        
        # 第二轮
        print("\n2️⃣  第二轮对话")
        result2 = agent.chat(
            "我应该从哪里开始？",
            "建议先学习Python基础和统计学",
            memorize_user=True
        )
        
        # 第三轮 - 检索相关记忆
        print("\n3️⃣  第三轮对话（检索上下文）")
        related = agent.recall("学习", top_k=3)
        print(f"  找到 {len(related)} 条相关记忆:")
        for mem in related:
            print(f"    - {mem.content}")
        
        result3 = agent.chat(
            "好的，我会认真学习的",
            "加油！",
            memorize_user=True
        )
        
        # 结束会话
        if agent.current_session_id:
            summary = agent.end_session()
            print(f"\n  会话摘要: {summary['summary']}")
            print(f"  关键主题: {summary['key_topics'][:3]}")
        
        print("\n✅ 对话处理完成")


def search_and_filter():
    """搜索和过滤示例"""
    print("\n\n" + "=" * 70)
    print("示例4: 搜索和过滤")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        agent = AgentMemory(user_id="david", db_path=db_path, use_vector_store=False)
        
        # 创建不同类型的记忆
        print("\n1️⃣  创建不同类型的记忆")
        
        from core.memory import MemoryType, MemoryCategory
        
        agent.create_memory(
            "Python是一门编程语言",
            memory_type=MemoryType.CORE,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.9,
            tags=["Python", "编程"]
        )
        print("  ✓ 核心记忆: Python知识")
        
        agent.create_memory(
            "今天学习了列表推导式",
            memory_type=MemoryType.SHORT,
            category=MemoryCategory.EXPERIENCE,
            importance=0.5,
            tags=["Python", "学习"]
        )
        print("  ✓ 短期记忆: 学习经验")
        
        agent.create_memory(
            "我喜欢Python的简洁语法",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.7,
            tags=["Python", "偏好"]
        )
        print("  ✓ 长期记忆: 个人偏好")
        
        # 搜索和过滤
        print("\n2️⃣  搜索和过滤")
        
        # 按重要性过滤
        high_importance = agent.search("Python", filters={"min_importance": 0.7})
        print(f"  高重要性记忆: {len(high_importance)} 条")
        
        # 按类型过滤
        core_memories = agent.get_all_memories(memory_type=MemoryType.CORE)
        print(f"  核心记忆: {len(core_memories)} 条")
        
        # 按标签过滤
        python_memories = agent.search("编程", filters={"tags": ["Python"]})
        print(f"  Python相关: {len(python_memories)} 条")
        
        print("\n✅ 搜索和过滤完成")


def maintenance_usage():
    """维护和清理示例"""
    print("\n\n" + "=" * 70)
    print("示例5: 记忆维护")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        agent = AgentMemory(user_id="eve", db_path=db_path, use_vector_store=False)
        
        # 创建一些记忆
        print("\n1️⃣  创建记忆")
        agent.memorize("学习Python基础")
        agent.memorize("学习Python函数")
        agent.memorize("学习Python类")
        print("  ✓ 创建了3条记忆")
        
        # 执行维护
        print("\n2️⃣  执行维护")
        result = agent.maintain()
        print(f"  生命周期处理: {result['lifecycle']['processed']} 条")
        print(f"  自动遗忘: {result['forget']['deleted']} 条")
        print(f"  一致性问题: {result['consistency_issues']} 个")
        
        # 更新记忆
        print("\n3️⃣  更新记忆")
        memories = agent.get_all_memories()
        if memories:
            first_id = memories[0].id
            agent.update_memory(
                first_id,
                tags=["Python", "基础", "已复习"]
            )
            print("  ✓ 更新了记忆标签")
        
        # 获取统计
        print("\n4️⃣  获取统计")
        stats = agent.get_statistics()
        print(f"  总记忆数: {stats['progress']['total_memories']}")
        print(f"  核心记忆数: {stats['progress']['core_memories']}")
        
        print("\n✅ 记忆维护完成")


def report_usage():
    """报告生成示例"""
    print("\n\n" + "=" * 70)
    print("示例6: 报告生成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        
        agent = AgentMemory(user_id="frank", db_path=db_path, use_vector_store=False)
        
        # 模拟一周的活动
        print("\n1️⃣  模拟一周的活动")
        activities = [
            "学习Python基础",
            "练习Python函数",
            "理解Python类",
            "实践面向对象",
            "完成小项目"
        ]
        
        for activity in activities:
            agent.memorize(activity)
            print(f"  ✓ {activity}")
        
        # 生成报告
        print("\n2️⃣  生成7天报告")
        report = agent.generate_report(days=7)
        print(f"  会话数: {report['session_count']}")
        print(f"  总记忆数: {report['total_memories']}")
        print(f"  记忆增长: {report['memory_growth']} 条")
        print(f"  最近话题: {report['recent_topics'][:5]}")
        print(f"  平均重要性: {report['avg_importance']:.3f}")
        
        # 获取上下文
        print("\n3️⃣  获取当前上下文")
        context = agent.get_context()
        print(f"  最近话题: {context['recent_topics'][:3]}")
        print(f"  待办任务: {context['pending_tasks']}")
        
        print("\n✅ 报告生成完成")


def main():
    """运行所有示例"""
    print("\n" + "🚀" * 35)
    print("AgentMemory 快速开始")
    print("🚀" * 35 + "\n")
    
    basic_usage()
    session_usage()
    chat_usage()
    search_and_filter()
    maintenance_usage()
    report_usage()
    
    print("\n\n" + "=" * 70)
    print("🎉 所有示例运行完成！")
    print("=" * 70)
    print("\n展示了以下功能:")
    print("  ✓ 基础使用（记忆、检索、统计）")
    print("  ✓ 会话管理（手动和自动）")
    print("  ✓ 对话处理（多轮对话）")
    print("  ✓ 搜索和过滤（多条件）")
    print("  ✓ 记忆维护（更新、清理）")
    print("  ✓ 报告生成（统计分析）")
    print("\n")


if __name__ == "__main__":
    main()

