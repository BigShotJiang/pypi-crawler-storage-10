"""
基础使用示例

演示如何使用Agent记忆系统的基本功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.memory import Memory, UserProfile, MemoryType, MemoryCategory
from core.config import get_config
from storage.sqlite_store import SQLiteStore
from storage.vector_store import VectorStore
from utils.embeddings import get_embedding_generator


def example_basic_memory():
    """示例1：创建和检索记忆"""
    print("\n" + "=" * 60)
    print("示例1：创建和检索记忆")
    print("=" * 60)
    
    # 初始化配置
    config = get_config()
    config.ensure_directories()
    
    # 初始化存储
    sqlite_store = SQLiteStore()
    
    # 创建记忆
    memory = Memory(
        user_id="user_001",
        content="用户喜欢使用Python进行数据分析",
        memory_type=MemoryType.SHORT,
        category=MemoryCategory.PREFERENCE,
        importance=0.8,
        tags=["Python", "数据分析", "偏好"]
    )
    
    print(f"\n创建记忆: {memory.content}")
    print(f"  - ID: {memory.id}")
    print(f"  - 类型: {memory.memory_type.value}")
    print(f"  - 分类: {memory.category.value}")
    print(f"  - 重要性: {memory.importance}")
    
    # 保存到数据库
    sqlite_store.create_memory(memory)
    print("✓ 记忆已保存到数据库")
    
    # 检索记忆
    retrieved = sqlite_store.get_memory(memory.id)
    if retrieved:
        print(f"\n✓ 成功检索记忆: {retrieved.content}")
    
    # 获取用户所有记忆
    user_memories = sqlite_store.get_memories_by_user("user_001")
    print(f"\n用户共有 {len(user_memories)} 条记忆")


def example_user_profile():
    """示例2：用户画像"""
    print("\n" + "=" * 60)
    print("示例2：用户画像管理")
    print("=" * 60)
    
    sqlite_store = SQLiteStore()
    
    # 创建用户画像
    profile = UserProfile(
        user_id="user_001",
        domain="数据科学",
        role="数据分析师",
        technical_level="中级",
        preferences={
            "language": "Python",
            "tools": ["Pandas", "NumPy", "Matplotlib"],
            "response_style": "详细"
        },
        conversation_style="专业",
        is_cold_start=False,
        confidence=0.75,
        conversation_count=15
    )
    
    print(f"\n创建用户画像:")
    print(f"  - 用户ID: {profile.user_id}")
    print(f"  - 领域: {profile.domain}")
    print(f"  - 角色: {profile.role}")
    print(f"  - 技术水平: {profile.technical_level}")
    print(f"  - 偏好工具: {profile.preferences.get('tools')}")
    print(f"  - 画像置信度: {profile.confidence}")
    
    # 保存画像
    sqlite_store.create_or_update_profile(profile)
    print("\n✓ 用户画像已保存")
    
    # 检索画像
    retrieved_profile = sqlite_store.get_profile("user_001")
    if retrieved_profile:
        print(f"✓ 成功检索用户画像，对话次数: {retrieved_profile.conversation_count}")


def example_memory_types():
    """示例3：不同类型的记忆"""
    print("\n" + "=" * 60)
    print("示例3：不同类型和维度的记忆")
    print("=" * 60)
    
    sqlite_store = SQLiteStore()
    
    memories = [
        # 短期记忆 - 知识
        Memory(
            user_id="user_002",
            content="今天学习了机器学习的决策树算法",
            memory_type=MemoryType.SHORT,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.6
        ),
        # 中期记忆 - 经验
        Memory(
            user_id="user_002",
            content="上次项目中数据清洗花费了大量时间，需要提前规划",
            memory_type=MemoryType.MID,
            category=MemoryCategory.EXPERIENCE,
            importance=0.75
        ),
        # 长期记忆 - 偏好
        Memory(
            user_id="user_002",
            content="用户倾向于使用Scikit-learn而不是TensorFlow",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.8
        ),
        # 核心记忆 - 价值观
        Memory(
            user_id="user_002",
            content="用户非常重视代码可读性和文档完整性",
            memory_type=MemoryType.CORE,
            category=MemoryCategory.REFLECTION,
            importance=0.95
        )
    ]
    
    print("\n创建不同层次的记忆:")
    for mem in memories:
        sqlite_store.create_memory(mem)
        print(f"  [{mem.memory_type.value:5s}] [{mem.category.value:11s}] {mem.content[:40]}...")
    
    print("\n✓ 所有记忆已创建")
    
    # 按类型检索
    short_memories = sqlite_store.get_memories_by_user("user_002", memory_type="short")
    print(f"\n短期记忆数量: {len(short_memories)}")


def example_vector_search():
    """示例4：向量检索（需要先安装依赖）"""
    print("\n" + "=" * 60)
    print("示例4：向量相似度检索")
    print("=" * 60)
    
    try:
        # 初始化向量存储
        vector_store = VectorStore()
        embedding_gen = get_embedding_generator()
        
        # 创建一些记忆
        texts = [
            "Python是一门强大的编程语言",
            "机器学习需要大量的数据",
            "深度学习是AI的重要分支",
            "数据清洗是数据分析的第一步"
        ]
        
        print("\n添加记忆到向量数据库:")
        for i, text in enumerate(texts):
            memory = Memory(
                user_id="user_003",
                content=text,
                memory_type=MemoryType.SHORT,
                category=MemoryCategory.KNOWLEDGE
            )
            
            # 生成向量
            embedding = embedding_gen.encode(text)
            vector_store.add_memory(memory, embedding)
            print(f"  {i+1}. {text}")
        
        print("\n✓ 向量已添加")
        
        # 搜索相似记忆
        query = "编程语言相关的内容"
        print(f"\n搜索查询: {query}")
        query_embedding = embedding_gen.encode(query)
        
        results = vector_store.search_similar(
            query_embedding=query_embedding,
            user_id="user_003",
            top_k=3
        )
        
        print(f"\n找到 {len(results)} 条相似记忆:")
        for memory_id, distance in results:
            print(f"  - ID: {memory_id[:8]}... (距离: {distance:.4f})")
    
    except Exception as e:
        print(f"\n⚠ 向量检索示例需要先安装依赖: {e}")
        print("请运行: pip install sentence-transformers")


def main():
    """运行所有示例"""
    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " " * 15 + "Agent 记忆系统示例" + " " * 23 + "║")
    print("╚" + "═" * 58 + "╝")
    
    # 确保目录存在
    config = get_config()
    config.ensure_directories()
    
    # 运行示例
    example_basic_memory()
    example_user_profile()
    example_memory_types()
    
    print("\n" + "=" * 60)
    print("✓ 基础示例运行完成！")
    print("=" * 60)
    print("\n提示：")
    print("  1. 数据保存在 ./data/ 目录下")
    print("  2. 可以运行 tests/test_basic.py 进行完整测试")
    print("  3. 向量检索需要先安装: pip install sentence-transformers")
    print()


if __name__ == "__main__":
    main()

