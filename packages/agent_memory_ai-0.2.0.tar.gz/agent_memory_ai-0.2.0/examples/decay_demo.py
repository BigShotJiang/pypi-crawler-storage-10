"""
记忆衰减与遗忘演示

展示记忆的生命周期管理功能
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from storage.sqlite_store import SQLiteStore
from modules.formation import MemoryFormer
from modules.decay import DecayManager, ForgetManager


def demo_memory_lifecycle():
    """演示完整的记忆生命周期"""
    print("=" * 70)
    print("演示：完整的记忆生命周期")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        former = MemoryFormer()
        decay_manager = DecayManager(store)
        
        user_id = "demo_user"
        
        # 1. 创建记忆
        print("\n📝 步骤1: 创建记忆")
        memory = former.form_memory_from_text(
            "学习Python编程",
            user_id
        )
        store.create_memory(memory)
        print(f"  内容: {memory.content}")
        print(f"  类型: {memory.memory_type.value}")
        print(f"  重要性: {memory.importance:.3f}")
        
        # 2. 模拟时间流逝和访问
        print("\n⏰ 步骤2: 时间流逝（模拟2天后）")
        memory.created_at = datetime.now() - timedelta(days=2)
        memory.updated_at = memory.created_at
        store.update_memory(memory)
        
        # 多次访问强化记忆
        print("\n🔄 步骤3: 频繁访问强化记忆")
        for i in range(5):
            memory = decay_manager.reinforce_memory(memory, boost=0.05)
            store.update_memory(memory)
        
        print(f"  访问次数: {memory.access_count}")
        print(f"  重要性: {memory.importance:.3f}")
        
        # 3. 检查是否应该晋升
        print("\n⬆️  步骤4: 检查晋升")
        should_promote = decay_manager.should_promote(memory)
        print(f"  应该晋升: {should_promote}")
        
        if should_promote:
            memory = decay_manager.promote_memory(memory)
            store.update_memory(memory)
            print(f"  新类型: {memory.memory_type.value}")
        
        # 4. 查看衰减统计
        print("\n📊 步骤5: 衰减统计")
        stats = decay_manager.get_decay_statistics(user_id)
        print(f"  总记忆数: {stats['total']}")
        print(f"  类型分布: {stats['by_type']}")
        print(f"  应晋升: {stats['should_promote']}")
        print(f"  应归档: {stats['should_archive']}")


def demo_auto_forget():
    """演示自动遗忘策略"""
    print("\n\n" + "=" * 70)
    print("演示：自动遗忘策略")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        former = MemoryFormer()
        forget_manager = ForgetManager(store)
        
        user_id = "demo_user"
        
        # 创建不同类型的记忆
        print("\n📝 创建不同类型的记忆:")
        
        # 1. 正常记忆
        normal = former.form_memory_from_text("学习机器学习算法", user_id)
        store.create_memory(normal)
        print(f"  1. 正常记忆: {normal.content}")
        
        # 2. 低重要性旧记忆
        old_low = former.form_memory_from_text("临时笔记", user_id)
        if old_low:
            old_low.importance = 0.1
            old_low.created_at = datetime.now() - timedelta(days=70)
            old_low.updated_at = old_low.created_at
            store.create_memory(old_low)
            print(f"  2. 低重要性旧记忆: {old_low.content}")
        
        # 3. 敏感信息
        sensitive = former.form_memory_from_text("用户密码相关", user_id)
        if sensitive:
            sensitive.privacy_level = PrivacyLevel.SENSITIVE
            sensitive.created_at = datetime.now() - timedelta(days=40)
            sensitive.updated_at = sensitive.created_at
            store.create_memory(sensitive)
            print(f"  3. 过期敏感信息: {sensitive.content}")
        
        # 4. 一次性信息
        ephemeral = former.form_memory_from_text("临时验证码", user_id)
        if ephemeral:
            ephemeral.metadata['is_ephemeral'] = True
            ephemeral.metadata['is_used'] = True
            store.create_memory(ephemeral)
            print(f"  4. 一次性已使用: {ephemeral.content}")
        
        print(f"\n总计: {len(store.get_memories_by_user(user_id))} 条记忆")
        
        # 执行自动遗忘
        print("\n🗑️  执行自动遗忘策略...")
        result = forget_manager.auto_forget(user_id)
        
        print(f"\n📊 遗忘结果:")
        print(f"  删除数量: {result.deleted_count}")
        print(f"  删除原因: {result.reason}")
        
        remaining = store.get_memories_by_user(user_id)
        print(f"\n剩余记忆: {len(remaining)} 条")
        for m in remaining:
            print(f"  - {m.content} (重要性: {m.importance:.3f})")


def demo_user_forget():
    """演示用户主动遗忘"""
    print("\n\n" + "=" * 70)
    print("演示：用户主动遗忘")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        former = MemoryFormer()
        forget_manager = ForgetManager(store)
        
        user_id = "demo_user"
        
        # 创建多条记忆
        print("\n📝 创建记忆:")
        texts = [
            "Python基础学习",
            "Python高级特性",
            "Java开发经验",
            "数据库设计",
            "算法优化"
        ]
        
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            if memory:
                store.create_memory(memory)
                print(f"  - {text}")
        
        print(f"\n总计: {len(texts)} 条记忆")
        
        # 场景1: 按查询遗忘（确认模式）
        print("\n🔍 场景1: 查找要删除的记忆")
        result, to_confirm = forget_manager.forget_by_query(
            "Python",
            user_id,
            confirm=True
        )
        
        print(f"找到 {len(to_confirm)} 条匹配的记忆:")
        for m in to_confirm:
            print(f"  - {m.content}")
        
        # 用户确认后删除
        print("\n✅ 用户确认删除")
        result, _ = forget_manager.forget_by_query(
            "Python",
            user_id,
            confirm=False
        )
        print(f"已删除 {result.deleted_count} 条记忆")
        
        # 场景2: 按标签遗忘
        print("\n🏷️  场景2: 按标签删除")
        
        # 添加标签
        remaining = store.get_memories_by_user(user_id)
        for m in remaining:
            if "Java" in m.content:
                m.tags.append("Java")
                store.update_memory(m)
        
        result = forget_manager.forget_by_tags(
            user_id,
            ["Java"],
            match_all=False
        )
        print(f"删除带'Java'标签的记忆: {result.deleted_count} 条")
        
        # 最终统计
        print("\n📊 最终统计:")
        final = store.get_memories_by_user(user_id)
        print(f"剩余记忆: {len(final)} 条")
        for m in final:
            print(f"  - {m.content}")


def demo_cascade_delete():
    """演示级联删除"""
    print("\n\n" + "=" * 70)
    print("演示：级联删除关联记忆")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        former = MemoryFormer()
        forget_manager = ForgetManager(store)
        
        user_id = "demo_user"
        
        # 创建记忆网络
        print("\n📝 创建记忆网络:")
        
        main = former.form_memory_from_text("Python项目开发", user_id)
        if not main:
            print("  无法创建记忆（LLM不可用）")
            return
        
        store.create_memory(main)
        print(f"  主记忆: {main.content}")
        
        related1 = former.form_memory_from_text("使用Flask框架", user_id)
        if related1:
            store.create_memory(related1)
            print(f"  关联1 (强): {related1.content}")
        
        related2 = former.form_memory_from_text("项目部署经验", user_id)
        if related2:
            store.create_memory(related2)
            print(f"  关联2 (强): {related2.content}")
        
        related3 = former.form_memory_from_text("Python语法笔记", user_id)
        if related3:
            store.create_memory(related3)
            print(f"  关联3 (弱): {related3.content}")
        
        # 建立关联
        related_ids = []
        associations = {}
        
        if related1:
            related_ids.append(related1.id)
            associations[related1.id] = {'strength': 0.9}
        if related2:
            related_ids.append(related2.id)
            associations[related2.id] = {'strength': 0.8}
        if related3:
            related_ids.append(related3.id)
            associations[related3.id] = {'strength': 0.3}
        
        if related_ids:
            main.related_memory_ids = related_ids
            main.metadata['associations'] = associations
            store.update_memory(main)
            print(f"\n建立了 {len(main.related_memory_ids)} 个关联")
        else:
            print("\n未能建立关联（无关联记忆创建）")
        
        # 级联删除
        print("\n🗑️  删除主记忆（级联模式）...")
        result = forget_manager.forget_by_id(
            main.id,
            user_id,
            cascade=True
        )
        
        print(f"\n📊 删除结果:")
        print(f"  主记忆删除: {result.deleted_count} 条")
        print(f"  级联删除: {len(result.cascade_deleted)} 条")
        print(f"  (强依赖的关联记忆被级联删除)")
        
        # 检查剩余
        remaining = store.get_memories_by_user(user_id)
        print(f"\n剩余记忆: {len(remaining)} 条")
        for m in remaining:
            print(f"  - {m.content} (弱关联被保留)")


def main():
    """运行所有演示"""
    print("\n" + "🎯" * 35)
    print("记忆衰减与遗忘功能演示")
    print("🎯" * 35 + "\n")
    
    demo_memory_lifecycle()
    demo_auto_forget()
    demo_user_forget()
    demo_cascade_delete()
    
    print("\n\n" + "=" * 70)
    print("🎉 演示完成！")
    print("=" * 70)
    print("\n展示了以下功能:")
    print("  ✓ 记忆生命周期管理（创建→强化→晋升）")
    print("  ✓ 自动遗忘策略（低重要性、敏感信息、一次性）")
    print("  ✓ 用户主动遗忘（按查询、按标签）")
    print("  ✓ 级联删除（强依赖级联、弱依赖保留）")
    print("\n")


if __name__ == "__main__":
    main()

