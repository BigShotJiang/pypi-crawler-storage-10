"""
快速开始示例

演示基本功能，不需要安装外部依赖
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.memory import Memory, UserProfile, Session, MemoryType, MemoryCategory
from core.config import get_config
from storage.sqlite_store import SQLiteStore


def main():
    print("\n" + "=" * 70)
    print(" " * 20 + "Agent 记忆系统 - 快速开始")
    print("=" * 70)
    
    # 1. 初始化
    print("\n[步骤1] 初始化系统...")
    config = get_config()
    config.ensure_directories()
    store = SQLiteStore()
    print("✓ 系统初始化完成")
    print(f"  - 数据库路径: {config.db_path}")
    print(f"  - LLM模型: {config.llm_model}")
    
    # 2. 创建用户画像
    print("\n[步骤2] 创建用户画像...")
    profile = UserProfile(
        user_id="demo_user",
        domain="软件开发",
        role="Python开发者",
        technical_level="高级",
        preferences={
            "language": "Python",
            "framework": "FastAPI",
            "coding_style": "简洁清晰"
        }
    )
    store.create_or_update_profile(profile)
    print("✓ 用户画像创建成功")
    print(f"  - 用户ID: {profile.user_id}")
    print(f"  - 领域: {profile.domain}")
    print(f"  - 偏好: {profile.preferences}")
    
    # 3. 创建不同类型的记忆
    print("\n[步骤3] 创建记忆...")
    memories = [
        Memory(
            user_id="demo_user",
            content="用户擅长使用Python进行后端开发",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.8,
            tags=["Python", "后端开发"]
        ),
        Memory(
            user_id="demo_user",
            content="用户喜欢详细的代码注释",
            memory_type=MemoryType.MID,
            category=MemoryCategory.PREFERENCE,
            importance=0.7,
            tags=["编码习惯", "注释"]
        ),
        Memory(
            user_id="demo_user",
            content="今天讨论了Agent记忆系统的实现方案",
            memory_type=MemoryType.SHORT,
            category=MemoryCategory.CONTEXT,
            importance=0.6,
            tags=["Agent", "记忆系统"]
        ),
        Memory(
            user_id="demo_user",
            content="用户非常重视代码质量和可维护性",
            memory_type=MemoryType.CORE,
            category=MemoryCategory.REFLECTION,
            importance=0.95,
            tags=["价值观", "代码质量"]
        )
    ]
    
    for mem in memories:
        store.create_memory(mem)
        print(f"  ✓ [{mem.memory_type.value:5s}] {mem.content[:40]}...")
    
    # 4. 检索记忆
    print("\n[步骤4] 检索记忆...")
    all_memories = store.get_memories_by_user("demo_user")
    print(f"✓ 共检索到 {len(all_memories)} 条记忆")
    
    # 按重要性排序
    print("\n最重要的3条记忆:")
    for i, mem in enumerate(all_memories[:3], 1):
        print(f"  {i}. [{mem.importance:.2f}] {mem.content}")
    
    # 按标签检索
    print("\n标签'Python'相关的记忆:")
    python_memories = store.search_memories_by_tags("demo_user", ["Python"])
    for mem in python_memories:
        print(f"  - {mem.content[:50]}...")
    
    # 5. 创建会话
    print("\n[步骤5] 创建会话...")
    session = Session(user_id="demo_user")
    session.add_message("user", "你能帮我设计一个Agent记忆系统吗？")
    session.add_message("assistant", "当然可以！我可以帮你设计一个多层次的记忆系统...")
    session.add_message("user", "太好了，那我们开始吧")
    session.summary = "讨论Agent记忆系统的设计方案"
    session.key_topics = ["Agent", "记忆系统", "架构设计"]
    
    store.create_session(session)
    print("✓ 会话创建成功")
    print(f"  - 会话ID: {session.session_id}")
    print(f"  - 消息数: {len(session.messages)}")
    print(f"  - 主题: {session.key_topics}")
    
    # 6. 更新记忆
    print("\n[步骤6] 更新记忆...")
    memory_to_update = all_memories[0]
    memory_to_update.access_count += 1
    memory_to_update.importance = 0.9
    store.update_memory(memory_to_update)
    print(f"✓ 记忆更新成功")
    print(f"  - 访问次数: {memory_to_update.access_count}")
    print(f"  - 新重要性: {memory_to_update.importance}")
    
    # 7. 统计信息
    print("\n[步骤7] 统计信息...")
    print(f"  - 总记忆数: {len(all_memories)}")
    print(f"  - 短期记忆: {len([m for m in all_memories if m.memory_type == MemoryType.SHORT])}")
    print(f"  - 中期记忆: {len([m for m in all_memories if m.memory_type == MemoryType.MID])}")
    print(f"  - 长期记忆: {len([m for m in all_memories if m.memory_type == MemoryType.LONG])}")
    print(f"  - 核心记忆: {len([m for m in all_memories if m.memory_type == MemoryType.CORE])}")
    
    print("\n" + "=" * 70)
    print("✓ 快速开始示例运行完成！")
    print("=" * 70)
    
    print("\n💡 接下来你可以:")
    print("  1. 查看数据库: ./data/memory.db")
    print("  2. 运行完整测试: python tests/test_simple.py")
    print("  3. 安装完整依赖: pip install -r requirements.txt")
    print("  4. 查看实现规划: ../实现规划.md")
    print()


if __name__ == "__main__":
    main()

