"""
记忆检索模块演示

展示多种检索策略的使用
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType
from storage.sqlite_store import SQLiteStore
from modules.retrieval import (
    MemoryRetriever,
    KeywordSearcher,
    TemporalSearcher,
    ContextSearcher,
    AssociativeSearcher
)


def demo_basic_retrieval():
    """演示基础检索功能"""
    print("=" * 60)
    print("演示1: 基础检索功能")
    print("=" * 60)
    
    # 创建临时数据库
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        
        user_id = "demo_user"
        now = datetime.now()
        
        # 创建一些示例记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="我最喜欢的编程语言是Python，因为它简洁优雅",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.PREFERENCE,
                importance=0.9,
                tags=["Python", "编程", "偏好"],
                created_at=now - timedelta(days=30),
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="最近在学习机器学习，发现PyTorch很好用",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.8,
                tags=["机器学习", "PyTorch", "学习"],
                created_at=now - timedelta(days=5),
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="今天完成了数据分析项目，使用了pandas和matplotlib",
                memory_type=MemoryType.SHORT,
                category=MemoryCategory.EXPERIENCE,
                importance=0.7,
                tags=["数据分析", "pandas", "matplotlib"],
                created_at=now,
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem4",
                user_id=user_id,
                content="记得要在项目中使用类型提示，提高代码可维护性",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.8,
                tags=["编程", "最佳实践"],
                created_at=now - timedelta(days=15),
                related_memory_ids=["mem1"],
                source_type=SourceType.INFERRED
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        print(f"\n已创建 {len(memories)} 条示例记忆\n")
        
        # 1. 关键词检索
        print("1️⃣  关键词检索: 'Python'")
        keyword_searcher = KeywordSearcher(store)
        results = keyword_searcher.search("Python", user_id, top_k=3)
        for r in results:
            print(f"   📝 {r.memory.content}")
            print(f"      分数: {r.score:.2f} | 标签: {r.memory.tags}\n")
        
        # 2. 时间检索
        print("2️⃣  时间检索: 最近7天")
        temporal_searcher = TemporalSearcher(store)
        recent_results = temporal_searcher.search_recent(user_id, days=7, top_k=3)
        for r in recent_results:
            age = (now - r.memory.created_at).days
            print(f"   📝 {r.memory.content}")
            print(f"      {age}天前 | 重要性: {r.memory.importance}\n")
        
        # 3. 按维度检索
        print("3️⃣  维度检索: 经验类记忆")
        context_searcher = ContextSearcher(store)
        exp_results = context_searcher.search_by_category(
            user_id, MemoryCategory.EXPERIENCE, top_k=3
        )
        for r in exp_results:
            print(f"   📝 {r.memory.content}")
            print(f"      类型: {r.memory.memory_type.value}\n")
        
        # 4. 关联检索
        print("4️⃣  关联检索: mem1的关联记忆")
        assoc_searcher = AssociativeSearcher(store)
        related_results = assoc_searcher.search_related("mem1", user_id, max_depth=2)
        for r in related_results:
            print(f"   📝 {r.memory.content}")
            print(f"      关联分数: {r.score:.2f}\n")


def demo_hybrid_retrieval():
    """演示混合检索策略"""
    print("\n" + "=" * 60)
    print("演示2: 混合检索策略")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        
        # 注意：不传vector_store，仅使用关键词和时间检索
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        user_id = "demo_user"
        now = datetime.now()
        
        # 创建记忆
        memories = [
            Memory(
                id=f"mem{i}",
                user_id=user_id,
                content=content,
                memory_type=mem_type,
                category=category,
                importance=importance,
                tags=tags,
                created_at=now - timedelta(days=age),
                source_type=SourceType.EXPLICIT
            )
            for i, (content, mem_type, category, importance, tags, age) in enumerate([
                ("Python是我最常用的编程语言", MemoryType.LONG, MemoryCategory.PREFERENCE, 0.9, ["Python"], 60),
                ("学习了Python的装饰器用法", MemoryType.MID, MemoryCategory.KNOWLEDGE, 0.7, ["Python", "装饰器"], 10),
                ("今天用Python写了一个爬虫", MemoryType.SHORT, MemoryCategory.EXPERIENCE, 0.6, ["Python", "爬虫"], 1),
                ("Python的异步编程很强大", MemoryType.LONG, MemoryCategory.KNOWLEDGE, 0.8, ["Python", "异步"], 30),
            ])
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        print(f"\n已创建 {len(memories)} 条Python相关记忆\n")
        
        # 混合检索（不使用向量）
        print("🔍 混合检索: 'Python装饰器'")
        results = retriever.retrieve(
            query="Python装饰器",
            user_id=user_id,
            top_k=3,
            strategy="hybrid"
        )
        
        for i, r in enumerate(results, 1):
            print(f"\n{i}. {r.memory.content}")
            print(f"   分数: {r.score:.2f}")
            print(f"   重要性: {r.memory.importance}")
            print(f"   标签: {r.memory.tags}")
            print(f"   来源: {r.source}")


def demo_context_aware_retrieval():
    """演示上下文感知检索"""
    print("\n" + "=" * 60)
    print("演示3: 上下文感知检索")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        user_id = "demo_user"
        
        # 创建记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="在做机器学习项目时，数据预处理很重要",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.8,
                tags=["机器学习", "数据预处理"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="最近在研究深度学习，需要大量GPU计算资源",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.7,
                tags=["深度学习", "GPU"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="对于数据科学项目，特征工程是关键",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.9,
                tags=["数据科学", "特征工程"],
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        print("\n📋 带上下文检索\n")
        
        # 带上下文的检索
        context = {
            "current_topic": "机器学习",
            "domain": "数据科学"
        }
        
        results = retriever.retrieve(
            query="特征",
            user_id=user_id,
            top_k=3,
            strategy="hybrid",
            context=context
        )
        
        print(f"上下文: {context}\n")
        
        for i, r in enumerate(results, 1):
            print(f"{i}. {r.memory.content}")
            print(f"   综合分数: {r.score:.2f}\n")


def demo_trending_and_important():
    """演示热门和重要记忆检索"""
    print("\n" + "=" * 60)
    print("演示4: 热门和重要记忆")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "demo.db")
        store = SQLiteStore(db_path)
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        user_id = "demo_user"
        now = datetime.now()
        
        # 创建不同访问频率的记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="核心技能：Python编程",
                memory_type=MemoryType.CORE,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.95,
                tags=["Python", "核心技能"],
                created_at=now - timedelta(days=180),
                access_count=50,
                last_access=now - timedelta(days=1),
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="最近在学Vue.js",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.6,
                tags=["Vue", "前端"],
                created_at=now - timedelta(days=7),
                access_count=3,
                last_access=now,
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 检索重要记忆
        print("\n⭐ 重要记忆 (importance >= 0.8):")
        important = retriever.retrieve_important(user_id, min_importance=0.8)
        for r in important:
            print(f"   📌 {r.memory.content}")
            print(f"      重要性: {r.memory.importance} | 访问: {r.memory.access_count}次\n")
        
        # 检索热门记忆
        print("🔥 热门记忆 (最近7天内):")
        trending = retriever.retrieve_trending(user_id, window_days=7)
        for r in trending:
            print(f"   🔥 {r.memory.content}")
            print(f"      热度分数: {r.score:.2f}\n")


def main():
    """运行所有演示"""
    print("\n" + "🎯" * 30)
    print("记忆检索模块完整演示")
    print("🎯" * 30 + "\n")
    
    try:
        demo_basic_retrieval()
        demo_hybrid_retrieval()
        demo_context_aware_retrieval()
        demo_trending_and_important()
        
        print("\n" + "=" * 60)
        print("✅ 所有演示完成！")
        print("=" * 60 + "\n")
        
    except Exception as e:
        print(f"\n❌ 演示过程中出错: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())

