#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""测试LLM JSON提取"""
import sys
import json
sys.path.insert(0, '.')

from utils.llm_client import LLMClient

def main():
    print('=' * 60)
    print('测试LLM JSON提取')
    print('=' * 60)
    
    llm = LLMClient()
    
    # 测试文本
    text = "我叫张三，今年25岁，是一名Python工程师，喜欢AI"
    
    # 测试提取实体
    print(f'\n测试文本: {text}')
    print('\n1. 测试提取实体...')
    
    prompt = f"""从以下文本中提取实体信息，以JSON格式返回。

文本：{text}

请只返回JSON格式，格式如下：
{{"entities": [{{"name": "实体名", "type": "人名/年龄/职业等"}}]}}

JSON:"""
    
    try:
        response = llm.chat([{'role': 'user', 'content': prompt}], temperature=0)
        print(f'\nLLM原始响应:')
        print(response)
        print(f'\n尝试解析JSON...')
        
        # 清理response
        response_clean = response.strip()
        if response_clean.startswith('```json'):
            response_clean = response_clean[7:]
        elif response_clean.startswith('```'):
            response_clean = response_clean[3:]
        
        if response_clean.endswith('```'):
            response_clean = response_clean[:-3]
        
        response_clean = response_clean.strip()
        
        print(f'清理后: {response_clean[:200]}')
        
        data = json.loads(response_clean)
        print(f'✓ JSON解析成功！')
        print(f'实体: {data}')
        
    except json.JSONDecodeError as e:
        print(f'✗ JSON解析失败: {e}')
        print(f'可能原因: LLM返回的格式不是标准JSON')
    except Exception as e:
        print(f'✗ 错误: {e}')
    
    print('\n' + '=' * 60)

if __name__ == '__main__':
    main()

