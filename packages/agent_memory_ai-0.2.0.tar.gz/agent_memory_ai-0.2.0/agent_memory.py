"""
Agent记忆系统主类

统一的记忆管理接口
"""
from typing import List, Dict, Optional, Union
from datetime import datetime

from .core.memory import Memory, MemoryType, MemoryCategory
from .core.config import get_config
from .storage.sqlite_store import SQLiteStore
from .storage.vector_store import VectorStore
from .modules.formation import MemoryFormer
from .modules.retrieval import MemoryRetriever
from .modules.update import UpdateManager
from .modules.decay import DecayManager, ForgetManager
from .modules.session import SessionManager


class AgentMemory:
    """
    Agent记忆系统主类
    
    提供统一的记忆管理接口，整合所有功能模块
    """
    
    def __init__(
        self,
        user_id: str,
        db_path: Optional[str] = None,
        vector_db_path: Optional[str] = None,
        use_vector_store: bool = True
    ):
        """
        初始化Agent记忆系统
        
        Args:
            user_id: 用户ID
            db_path: 数据库路径（可选，默认使用配置）
            vector_db_path: 向量数据库路径（可选）
            use_vector_store: 是否使用向量存储
        """
        self.user_id = user_id
        self.config = get_config()
        
        # 初始化存储
        self.sqlite_store = SQLiteStore(db_path or self.config.db_path)
        
        self.vector_store = None
        if use_vector_store:
            try:
                self.vector_store = VectorStore(
                    vector_db_path or self.config.vector_db_path
                )
            except Exception as e:
                print(f"向量存储初始化失败，将使用降级模式: {e}")
        
        # 初始化功能模块
        self.former = MemoryFormer(sqlite_store=self.sqlite_store)
        self.retriever = MemoryRetriever(
            sqlite_store=self.sqlite_store,
            vector_store=self.vector_store
        )
        self.update_manager = UpdateManager(self.sqlite_store)
        self.decay_manager = DecayManager(self.sqlite_store)
        self.forget_manager = ForgetManager(self.sqlite_store)
        self.session_manager = SessionManager(self.sqlite_store)
        
        # 当前会话
        self.current_session_id: Optional[str] = None
        self.current_session_messages: List[Dict] = []
        self.current_session_start_time: Optional[datetime] = None
    
    # ==================== 会话管理 ====================
    
    def start_session(self, session_id: Optional[str] = None) -> Dict:
        """
        开始新会话
        
        Args:
            session_id: 会话ID（可选，自动生成）
        
        Returns:
            会话上下文
        """
        if session_id is None:
            session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.current_session_id = session_id
        self.current_session_messages = []
        self.current_session_start_time = datetime.now()
        
        context = self.session_manager.start_session(self.user_id, session_id)
        
        return context
    
    def end_session(self) -> Dict:
        """
        结束当前会话
        
        Returns:
            会话摘要
        """
        if self.current_session_id is None:
            raise ValueError("没有活跃的会话")
        
        summary = self.session_manager.end_session(
            self.user_id,
            self.current_session_id,
            self.current_session_messages,
            self.current_session_start_time
        )
        
        # 重置会话状态
        self.current_session_id = None
        self.current_session_messages = []
        self.current_session_start_time = None
        
        return summary.to_dict()
    
    def add_message(self, role: str, content: str):
        """
        添加对话消息
        
        Args:
            role: 角色 (user/assistant)
            content: 消息内容
        """
        if self.current_session_id is None:
            # 自动开始会话
            self.start_session()
        
        self.current_session_messages.append({
            "role": role,
            "content": content
        })
    
    # ==================== 记忆形成 ====================
    
    def memorize(
        self,
        text: str,
        auto_add_to_session: bool = True
    ) -> Optional[Memory]:
        """
        从文本形成记忆
        
        Args:
            text: 文本内容
            auto_add_to_session: 是否自动添加到会话
        
        Returns:
            形成的记忆
        """
        # 形成记忆
        memory = self.former.form_memory_from_text(text, self.user_id)
        
        if memory:
            # 保存到数据库
            self.sqlite_store.create_memory(memory)
            
            # 保存到向量数据库
            if self.vector_store:
                try:
                    self.vector_store.add_memory(memory)
                except Exception as e:
                    print(f"向量存储失败: {e}")
            
            # 添加到会话消息
            if auto_add_to_session and self.current_session_id:
                self.add_message("user", text)
        
        return memory
    
    def create_memory(
        self,
        content: str,
        memory_type: MemoryType = MemoryType.MID,
        category: MemoryCategory = MemoryCategory.KNOWLEDGE,
        importance: Optional[float] = None,
        tags: Optional[List[str]] = None
    ) -> Memory:
        """
        直接创建记忆（不通过形成器）
        
        Args:
            content: 记忆内容
            memory_type: 记忆类型
            category: 记忆类别
            importance: 重要性（可选，自动计算）
            tags: 标签
        
        Returns:
            创建的记忆
        """
        from core.memory import SourceType, PrivacyLevel
        
        # 如果没有指定重要性，使用简单计算
        if importance is None:
            importance = self.former.scorer.calculate_importance(content, self.user_id)
        
        # 直接创建Memory对象
        memory = Memory(
            user_id=self.user_id,
            content=content,
            memory_type=memory_type,
            category=category,
            source_type=SourceType.EXPLICIT,
            importance=importance,
            tags=tags or [],
            privacy_level=PrivacyLevel.NORMAL
        )
        
        # 保存
        self.sqlite_store.create_memory(memory)
        
        if self.vector_store:
            try:
                self.vector_store.add_memory(memory)
            except Exception as e:
                print(f"向量存储失败: {e}")
        
        return memory
    
    # ==================== 记忆检索 ====================
    
    def recall(
        self,
        query: str,
        top_k: int = 5,
        strategy: str = "hybrid"
    ) -> List[Memory]:
        """
        检索记忆
        
        Args:
            query: 查询内容
            top_k: 返回数量
            strategy: 检索策略 (hybrid/vector/keyword/temporal/context)
        
        Returns:
            记忆列表
        """
        results = self.retriever.retrieve(
            query=query,
            user_id=self.user_id,
            top_k=top_k,
            strategy=strategy
        )
        
        # 更新访问次数
        for result in results:
            result.memory.access_count += 1
            result.memory.last_accessed_at = datetime.now()
            self.sqlite_store.update_memory(result.memory)
        
        return [r.memory for r in results]
    
    def search(
        self,
        query: str,
        filters: Optional[Dict] = None,
        top_k: int = 10
    ) -> List[Memory]:
        """
        搜索记忆（支持过滤）
        
        Args:
            query: 查询内容
            filters: 过滤条件
            top_k: 返回数量
        
        Returns:
            记忆列表
        """
        # 基础检索
        results = self.recall(query, top_k=top_k * 2)  # 多检索一些，然后过滤
        
        # 应用过滤器
        if filters:
            filtered = []
            for memory in results:
                if self._match_filters(memory, filters):
                    filtered.append(memory)
            results = filtered
        
        return results[:top_k]
    
    def _match_filters(self, memory: Memory, filters: Dict) -> bool:
        """检查记忆是否匹配过滤条件"""
        for key, value in filters.items():
            if key == "type" and memory.memory_type.value != value:
                return False
            elif key == "category" and memory.category.value != value:
                return False
            elif key == "min_importance" and memory.importance < value:
                return False
            elif key == "max_importance" and memory.importance > value:
                return False
            elif key == "tags" and not any(tag in memory.tags for tag in value):
                return False
        return True
    
    def get_all_memories(
        self,
        memory_type: Optional[MemoryType] = None
    ) -> List[Memory]:
        """
        获取所有记忆
        
        Args:
            memory_type: 记忆类型过滤
        
        Returns:
            记忆列表
        """
        memories = self.sqlite_store.get_memories_by_user(self.user_id)
        
        if memory_type:
            memories = [m for m in memories if m.memory_type == memory_type]
        
        return memories
    
    # ==================== 记忆更新 ====================
    
    def update_memory(
        self,
        memory_id: str,
        content: Optional[str] = None,
        tags: Optional[List[str]] = None,
        importance: Optional[float] = None
    ) -> Dict:
        """
        更新记忆
        
        Args:
            memory_id: 记忆ID
            content: 新内容
            tags: 新标签
            importance: 新重要性
        
        Returns:
            更新结果
        """
        result = {"success": False, "updated": False}
        
        if content:
            result = self.update_manager.update_memory_content(
                memory_id, content, check_conflicts=True
            )
        
        # 更新标签和重要性需要直接操作
        if tags is not None or importance is not None:
            memory = self.sqlite_store.get_memory(memory_id)
            if memory:
                if tags is not None:
                    memory.tags = tags
                if importance is not None:
                    memory.importance = importance
                memory.updated_at = datetime.now()
                self.sqlite_store.update_memory(memory)
                result["updated"] = True
        
        result["success"] = True
        return result
    
    def merge_memories(self, memory_ids: List[str]) -> Optional[Memory]:
        """
        合并记忆
        
        Args:
            memory_ids: 要合并的记忆ID列表
        
        Returns:
            合并后的记忆
        """
        if len(memory_ids) < 2:
            raise ValueError("至少需要2条记忆来合并")
        
        # 获取记忆
        memories = [self.sqlite_store.get_memory(mid) for mid in memory_ids]
        memories = [m for m in memories if m is not None]
        
        if len(memories) < 2:
            return None
        
        # 合并
        merged = self.update_manager.memory_merger.merge_memories(memories)
        
        # 删除原记忆
        for memory in memories:
            self.forget_manager.forget_by_id(memory.id, self.user_id)
        
        # 保存合并后的记忆
        self.sqlite_store.create_memory(merged)
        
        return merged
    
    # ==================== 记忆维护 ====================
    
    def maintain(self) -> Dict:
        """
        执行记忆维护（衰减、清理）
        
        Returns:
            维护结果统计
        """
        result = {}
        
        # 生命周期处理
        lifecycle_result = self.decay_manager.process_memory_lifecycle(self.user_id)
        result["lifecycle"] = lifecycle_result
        
        # 自动遗忘
        forget_result = self.forget_manager.auto_forget(self.user_id)
        result["forget"] = {
            "deleted": forget_result.deleted_count,
            "reason": forget_result.reason
        }
        
        # 一致性检查
        issues = self.session_manager.check_consistency(self.user_id)
        result["consistency_issues"] = len(issues)
        
        return result
    
    def forget(
        self,
        memory_id: Optional[str] = None,
        query: Optional[str] = None,
        days_old: Optional[int] = None
    ) -> int:
        """
        遗忘记忆
        
        Args:
            memory_id: 记忆ID
            query: 查询（匹配的记忆）
            days_old: 天数（超过指定天数的记忆）
        
        Returns:
            删除的记忆数量
        """
        if memory_id:
            return self.forget_manager.forget_by_id(memory_id, self.user_id)
        elif query:
            return self.forget_manager.forget_by_query(query, self.user_id)
        elif days_old:
            cutoff = datetime.now() - timedelta(days=days_old)
            return self.forget_manager.forget_by_time(cutoff, self.user_id)
        else:
            raise ValueError("必须提供 memory_id、query 或 days_old")
    
    # ==================== 统计和报告 ====================
    
    def get_statistics(self) -> Dict:
        """
        获取记忆统计
        
        Returns:
            统计信息
        """
        # 基础统计
        decay_stats = self.decay_manager.get_decay_statistics(self.user_id)
        forget_stats = self.forget_manager.get_forget_statistics(self.user_id)
        
        # 用户进展
        progress = self.session_manager.get_user_progress(self.user_id)
        
        return {
            "decay": decay_stats,
            "forget": forget_stats,
            "progress": progress
        }
    
    def generate_report(self, days: int = 7) -> Dict:
        """
        生成记忆报告
        
        Args:
            days: 统计天数
        
        Returns:
            报告
        """
        return self.session_manager.generate_session_report(self.user_id, days)
    
    def get_context(self) -> Dict:
        """
        获取当前上下文
        
        Returns:
            上下文信息
        """
        return self.session_manager.get_session_context(self.user_id)
    
    # ==================== 用户管理 ====================
    
    def get_profile(self) -> Optional[Dict]:
        """
        获取用户资料
        
        Returns:
            用户资料
        """
        profile = self.sqlite_store.get_profile(self.user_id)
        if profile:
            return {
                "user_id": profile.user_id,
                "name": profile.name,
                "preferences": profile.preferences,
                "created_at": profile.created_at.isoformat(),
                "updated_at": profile.updated_at.isoformat()
            }
        return None
    
    def update_profile(
        self,
        name: Optional[str] = None,
        preferences: Optional[Dict] = None
    ):
        """
        更新用户资料
        
        Args:
            name: 用户名
            preferences: 偏好设置
        """
        profile = self.sqlite_store.get_profile(self.user_id)
        
        if profile:
            if name:
                profile.name = name
            if preferences:
                profile.preferences.update(preferences)
            profile.updated_at = datetime.now()
            self.sqlite_store.update_profile(profile)
    
    # ==================== 便捷方法 ====================
    
    def chat(
        self,
        user_message: str,
        assistant_response: Optional[str] = None,
        memorize_user: bool = True,
        memorize_assistant: bool = False
    ) -> Dict:
        """
        处理一轮对话
        
        Args:
            user_message: 用户消息
            assistant_response: 助手回复（可选）
            memorize_user: 是否记忆用户消息
            memorize_assistant: 是否记忆助手回复
        
        Returns:
            处理结果
        """
        result = {
            "user_memory": None,
            "assistant_memory": None,
            "context": None
        }
        
        # 添加用户消息
        self.add_message("user", user_message)
        
        # 记忆用户消息
        if memorize_user:
            user_memory = self.memorize(user_message, auto_add_to_session=False)
            result["user_memory"] = user_memory
        
        # 添加助手回复
        if assistant_response:
            self.add_message("assistant", assistant_response)
            
            # 记忆助手回复
            if memorize_assistant:
                assistant_memory = self.memorize(
                    assistant_response,
                    auto_add_to_session=False
                )
                result["assistant_memory"] = assistant_memory
        
        # 获取上下文
        result["context"] = self.get_context()
        
        return result
    
    def __enter__(self):
        """支持上下文管理器"""
        self.start_session()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出时自动结束会话"""
        if self.current_session_id:
            self.end_session()
    
    def __repr__(self):
        """字符串表示"""
        mem_count = len(self.get_all_memories())
        return f"<AgentMemory(user_id='{self.user_id}', memories={mem_count})>"


# 时间导入
from datetime import timedelta

