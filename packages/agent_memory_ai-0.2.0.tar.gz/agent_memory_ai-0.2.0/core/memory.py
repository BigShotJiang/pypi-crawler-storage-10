"""
核心记忆数据模型定义
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid


class MemoryType(Enum):
    """记忆类型 - 基于时间层次"""
    WORK = "work"              # 工作记忆（即时）
    SHORT = "short"            # 短期记忆（1周内）
    MID = "mid"                # 中期记忆（1周-3个月）
    LONG = "long"              # 长期记忆（3个月+）
    CORE = "core"              # 核心记忆（永久）


class MemoryCategory(Enum):
    """记忆维度 - 基于内容类型"""
    KNOWLEDGE = "knowledge"    # 知识性记忆
    EXPERIENCE = "experience"  # 经验性记忆
    PREFERENCE = "preference"  # 偏好记忆
    CONTEXT = "context"        # 情境记忆
    REFLECTION = "reflection"  # 反思记忆
    META = "meta"              # 元记忆


class PrivacyLevel(Enum):
    """隐私级别"""
    NORMAL = "normal"          # 普通信息
    SENSITIVE = "sensitive"    # 敏感信息（90天自动删除）
    PRIVATE = "private"        # 私密信息（30天自动删除）


class SourceType(Enum):
    """记忆来源类型"""
    EXPLICIT = "explicit"      # 用户明确表述
    INFERRED = "inferred"      # 系统推断
    DERIVED = "derived"        # 从其他记忆衍生


@dataclass
class Memory:
    """
    记忆基础类
    
    表示系统中的一条记忆，包含内容、分类、时间、重要性等信息
    """
    # 基础标识
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str = ""
    content: str = ""
    
    # 分类
    memory_type: MemoryType = MemoryType.SHORT
    category: MemoryCategory = MemoryCategory.KNOWLEDGE
    
    # 时间信息
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    last_access: datetime = field(default_factory=datetime.now)
    
    # 重要性指标
    importance: float = 0.5        # 重要性分数 (0-1)
    confidence: float = 0.7        # 置信度 (0-1)
    access_count: int = 0          # 访问次数
    
    # 来源信息
    source_type: SourceType = SourceType.EXPLICIT
    source_conversation_id: Optional[str] = None
    source_session_id: Optional[str] = None
    
    # 关联关系
    related_memory_ids: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    
    # 向量表示（用于相似度检索）
    embedding: Optional[List[float]] = None
    
    # 隐私和生命周期
    privacy_level: PrivacyLevel = PrivacyLevel.NORMAL
    auto_delete_date: Optional[datetime] = None
    is_deleted: bool = False
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "content": self.content,
            "memory_type": self.memory_type.value,
            "category": self.category.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_access": self.last_access.isoformat(),
            "importance": self.importance,
            "confidence": self.confidence,
            "access_count": self.access_count,
            "source_type": self.source_type.value,
            "source_conversation_id": self.source_conversation_id,
            "source_session_id": self.source_session_id,
            "related_memory_ids": self.related_memory_ids,
            "tags": self.tags,
            "privacy_level": self.privacy_level.value,
            "auto_delete_date": self.auto_delete_date.isoformat() if self.auto_delete_date else None,
            "is_deleted": self.is_deleted,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Memory':
        """从字典创建"""
        return cls(
            id=data.get("id", str(uuid.uuid4())),
            user_id=data.get("user_id", ""),
            content=data.get("content", ""),
            memory_type=MemoryType(data.get("memory_type", "short")),
            category=MemoryCategory(data.get("category", "knowledge")),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.now(),
            last_access=datetime.fromisoformat(data["last_access"]) if "last_access" in data else datetime.now(),
            importance=data.get("importance", 0.5),
            confidence=data.get("confidence", 0.7),
            access_count=data.get("access_count", 0),
            source_type=SourceType(data.get("source_type", "explicit")),
            source_conversation_id=data.get("source_conversation_id"),
            source_session_id=data.get("source_session_id"),
            related_memory_ids=data.get("related_memory_ids", []),
            tags=data.get("tags", []),
            embedding=data.get("embedding"),
            privacy_level=PrivacyLevel(data.get("privacy_level", "normal")),
            auto_delete_date=datetime.fromisoformat(data["auto_delete_date"]) if data.get("auto_delete_date") else None,
            is_deleted=data.get("is_deleted", False),
            metadata=data.get("metadata", {})
        )
    
    def update_access(self):
        """更新访问信息"""
        self.last_access = datetime.now()
        self.access_count += 1


@dataclass
class UserProfile:
    """
    用户画像
    
    存储用户的基本信息、偏好、画像置信度等
    """
    user_id: str
    
    # 基础信息
    domain: Optional[str] = None           # 专业领域
    role: Optional[str] = None             # 角色
    technical_level: Optional[str] = None  # 技术水平
    
    # 偏好配置
    preferences: Dict[str, Any] = field(default_factory=dict)
    conversation_style: str = "adaptive"   # 对话风格
    
    # 状态
    is_cold_start: bool = True            # 是否冷启动状态
    confidence: float = 0.3               # 画像置信度
    conversation_count: int = 0           # 对话次数
    
    # 时间
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    
    # 核心记忆引用
    core_memory_ids: List[str] = field(default_factory=list)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "user_id": self.user_id,
            "domain": self.domain,
            "role": self.role,
            "technical_level": self.technical_level,
            "preferences": self.preferences,
            "conversation_style": self.conversation_style,
            "is_cold_start": self.is_cold_start,
            "confidence": self.confidence,
            "conversation_count": self.conversation_count,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "core_memory_ids": self.core_memory_ids,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UserProfile':
        """从字典创建"""
        return cls(
            user_id=data["user_id"],
            domain=data.get("domain"),
            role=data.get("role"),
            technical_level=data.get("technical_level"),
            preferences=data.get("preferences", {}),
            conversation_style=data.get("conversation_style", "adaptive"),
            is_cold_start=data.get("is_cold_start", True),
            confidence=data.get("confidence", 0.3),
            conversation_count=data.get("conversation_count", 0),
            created_at=datetime.fromisoformat(data["created_at"]) if "created_at" in data else datetime.now(),
            updated_at=datetime.fromisoformat(data["updated_at"]) if "updated_at" in data else datetime.now(),
            last_active=datetime.fromisoformat(data["last_active"]) if "last_active" in data else datetime.now(),
            core_memory_ids=data.get("core_memory_ids", []),
            metadata=data.get("metadata", {})
        )


@dataclass
class Session:
    """
    会话
    
    表示一次完整的对话会话，包含消息历史、摘要、任务等
    """
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str = ""
    
    # 时间
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    
    # 对话历史
    messages: List[Dict[str, Any]] = field(default_factory=list)
    
    # 摘要信息
    summary: Optional[str] = None
    key_topics: List[str] = field(default_factory=list)
    decisions_made: List[str] = field(default_factory=list)
    pending_tasks: List[str] = field(default_factory=list)
    
    # 记忆管理
    memories_created: List[str] = field(default_factory=list)
    memories_accessed: List[str] = field(default_factory=list)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_message(self, role: str, content: str):
        """添加消息"""
        self.messages.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "messages": self.messages,
            "summary": self.summary,
            "key_topics": self.key_topics,
            "decisions_made": self.decisions_made,
            "pending_tasks": self.pending_tasks,
            "memories_created": self.memories_created,
            "memories_accessed": self.memories_accessed,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Session':
        """从字典创建"""
        return cls(
            session_id=data.get("session_id", str(uuid.uuid4())),
            user_id=data.get("user_id", ""),
            start_time=datetime.fromisoformat(data["start_time"]) if "start_time" in data else datetime.now(),
            end_time=datetime.fromisoformat(data["end_time"]) if data.get("end_time") else None,
            messages=data.get("messages", []),
            summary=data.get("summary"),
            key_topics=data.get("key_topics", []),
            decisions_made=data.get("decisions_made", []),
            pending_tasks=data.get("pending_tasks", []),
            memories_created=data.get("memories_created", []),
            memories_accessed=data.get("memories_accessed", []),
            metadata=data.get("metadata", {})
        )


@dataclass
class MemorySnapshot:
    """
    记忆快照
    
    用于快速加载和跨会话一致性保证
    """
    user_id: str
    snapshot_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = field(default_factory=datetime.now)
    
    # 核心记忆
    core_memory: Dict[str, Any] = field(default_factory=dict)
    
    # 最近会话摘要
    recent_sessions: List[Dict[str, Any]] = field(default_factory=list)
    
    # 活跃主题
    active_topics: List[str] = field(default_factory=list)
    
    # 待办事项
    pending_tasks: List[str] = field(default_factory=list)
    
    # 用户画像
    user_profile: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "user_id": self.user_id,
            "snapshot_id": self.snapshot_id,
            "timestamp": self.timestamp.isoformat(),
            "core_memory": self.core_memory,
            "recent_sessions": self.recent_sessions,
            "active_topics": self.active_topics,
            "pending_tasks": self.pending_tasks,
            "user_profile": self.user_profile
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemorySnapshot':
        """从字典创建"""
        return cls(
            user_id=data["user_id"],
            snapshot_id=data.get("snapshot_id", str(uuid.uuid4())),
            timestamp=datetime.fromisoformat(data["timestamp"]) if "timestamp" in data else datetime.now(),
            core_memory=data.get("core_memory", {}),
            recent_sessions=data.get("recent_sessions", []),
            active_topics=data.get("active_topics", []),
            pending_tasks=data.get("pending_tasks", []),
            user_profile=data.get("user_profile", {})
        )

