"""
配置管理模块

从config.json加载配置，提供全局配置访问
"""
import json
import os
from typing import Dict, Any, Optional
from pathlib import Path


class Config:
    """
    配置管理类
    
    单例模式，从config.json加载所有配置
    """
    _instance: Optional['Config'] = None
    _config: Dict[str, Any] = {}
    
    def __new__(cls, config_path: Optional[str] = None):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, config_path: Optional[str] = None):
        if self._initialized:
            return
        
        if config_path is None:
            # 默认配置文件路径
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(__file__)),
                "config.json"
            )
        
        self.config_path = config_path
        self._load_config()
        self._initialized = True
    
    def _load_config(self):
        """加载配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self._config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件不存在: {self.config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"配置文件格式错误: {e}")
    
    def reload(self):
        """重新加载配置"""
        self._load_config()
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        获取配置项
        
        支持点号分隔的嵌套键，例如: "llm.model"
        """
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """
        设置配置项
        
        支持点号分隔的嵌套键
        """
        keys = key.split('.')
        config = self._config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def save(self):
        """保存配置到文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self._config, f, indent=2, ensure_ascii=False)
    
    # LLM 配置
    @property
    def llm_provider(self) -> str:
        return self.get("llm.provider", "openai")
    
    @property
    def llm_api_key(self) -> str:
        return self.get("llm.api_key", "")
    
    @property
    def llm_base_url(self) -> str:
        return self.get("llm.base_url", "https://api.openai.com/v1")
    
    @property
    def llm_model(self) -> str:
        return self.get("llm.model", "gpt-4")
    
    @property
    def llm_temperature(self) -> float:
        return self.get("llm.temperature", 0.7)
    
    @property
    def llm_max_tokens(self) -> int:
        return self.get("llm.max_tokens", 2000)
    
    # Embedding 配置
    @property
    def embedding_model(self) -> str:
        return self.get("embedding.model_name", "paraphrase-multilingual-MiniLM-L12-v2")
    
    @property
    def embedding_device(self) -> str:
        return self.get("embedding.device", "cpu")
    
    @property
    def embedding_batch_size(self) -> int:
        return self.get("embedding.batch_size", 32)
    
    @property
    def embedding_cache_folder(self) -> str:
        return self.get("embedding.cache_folder", "./data/models")
    
    # Storage 配置
    @property
    def db_type(self) -> str:
        return self.get("storage.database.type", "sqlite")
    
    @property
    def db_path(self) -> str:
        return self.get("storage.database.path", "./data/memory.db")
    
    @property
    def vector_db_type(self) -> str:
        return self.get("storage.vector_db.type", "chromadb")
    
    @property
    def vector_db_path(self) -> str:
        return self.get("storage.vector_db.path", "./data/chroma")
    
    @property
    def vector_collection_name(self) -> str:
        return self.get("storage.vector_db.collection_name", "memories")
    
    # Memory 配置
    @property
    def memory_thresholds(self) -> Dict[str, float]:
        return self.get("memory.thresholds", {
            "core": 0.9,
            "long_term": 0.7,
            "mid_term": 0.5,
            "short_term": 0.3
        })
    
    @property
    def decay_config(self) -> Dict[str, int]:
        return self.get("memory.decay", {
            "short_term_days": 7,
            "mid_term_days": 90,
            "sensitive_days": 30
        })
    
    @property
    def compression_config(self) -> Dict[str, Any]:
        return self.get("memory.compression", {
            "min_cluster_size": 3,
            "similarity_threshold": 0.85
        })
    
    @property
    def retrieval_config(self) -> Dict[str, int]:
        return self.get("memory.retrieval", {
            "default_top_k": 10,
            "max_results": 50
        })
    
    # Scheduler 配置
    @property
    def scheduler_enabled(self) -> bool:
        return self.get("scheduler.enabled", True)
    
    @property
    def scheduler_timezone(self) -> str:
        return self.get("scheduler.timezone", "Asia/Shanghai")
    
    @property
    def scheduler_tasks(self) -> Dict[str, Any]:
        return self.get("scheduler.tasks", {})
    
    # Logging 配置
    @property
    def log_level(self) -> str:
        return self.get("logging.level", "INFO")
    
    @property
    def log_format(self) -> str:
        return self.get("logging.format", 
                       "{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function}:{line} - {message}")
    
    @property
    def log_rotation(self) -> str:
        return self.get("logging.rotation", "100 MB")
    
    @property
    def log_retention(self) -> str:
        return self.get("logging.retention", "30 days")
    
    @property
    def log_path(self) -> str:
        return self.get("logging.log_path", "./logs/memory_system.log")
    
    def ensure_directories(self):
        """确保所有必要的目录存在"""
        directories = [
            os.path.dirname(self.db_path),
            self.vector_db_path,
            self.embedding_cache_folder,
            os.path.dirname(self.log_path)
        ]
        
        for directory in directories:
            if directory:
                Path(directory).mkdir(parents=True, exist_ok=True)


# 全局配置实例
_global_config: Optional[Config] = None


def get_config(config_path: Optional[str] = None) -> Config:
    """获取全局配置实例"""
    global _global_config
    if _global_config is None:
        _global_config = Config(config_path)
    return _global_config


def reload_config():
    """重新加载配置"""
    global _global_config
    if _global_config is not None:
        _global_config.reload()

