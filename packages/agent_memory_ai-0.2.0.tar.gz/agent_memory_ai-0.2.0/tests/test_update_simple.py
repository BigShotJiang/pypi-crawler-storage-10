"""
更新模块简单测试

测试记忆更新、冲突检测、合并等功能
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType
from storage.sqlite_store import SQLiteStore
from modules.update import (
    ConflictDetector,
    ConflictType,
    ConflictResolver,
    MemoryUpdater,
    MemoryMerger,
    MemoryCompressor,
    AssociationManager,
    UpdateManager
)


def test_conflict_detection():
    """测试冲突检测"""
    print("=" * 60)
    print("测试1: 冲突检测")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        detector = ConflictDetector(store)
        
        user_id = "test_user"
        
        # 创建测试记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="我喜欢Python编程",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.PREFERENCE,
                importance=0.8,
                tags=["Python", "编程"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="我不喜欢Python编程",  # 矛盾
                memory_type=MemoryType.LONG,
                category=MemoryCategory.PREFERENCE,
                importance=0.7,
                tags=["Python", "编程"],
                source_type=SourceType.EXPLICIT,
                created_at=datetime.now() - timedelta(days=1)
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="我喜欢用Python写代码",  # 重复
                memory_type=MemoryType.LONG,
                category=MemoryCategory.PREFERENCE,
                importance=0.75,
                tags=["Python"],
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories[:-1]:  # 先存前两个
            store.create_memory(memory)
        
        # 1. 检测矛盾
        print("\n1️⃣  检测矛盾")
        new_memory = memories[0]
        old_memory = memories[1]
        
        contradiction_score = detector._check_contradiction(new_memory, old_memory)
        print(f"  矛盾度: {contradiction_score:.2f}")
        assert contradiction_score > 0.5, "应该检测到矛盾"
        
        # 2. 检测重复
        print("\n2️⃣  检测重复")
        dup_memory = memories[2]
        duplicate_score = detector._check_duplicate(new_memory, dup_memory)
        print(f"  重复度: {duplicate_score:.2f}")
        assert duplicate_score > 0.3, "应该检测到相似"
        
        # 3. 检测新记忆的冲突
        print("\n3️⃣  检测新记忆冲突")
        conflicts = detector.detect_conflicts(dup_memory, user_id)
        print(f"  发现 {len(conflicts)} 个冲突:")
        for mem, conflict_type, confidence in conflicts:
            print(f"    - {mem.content[:30]}... ({conflict_type.value}: {confidence:.2f})")
        
        assert len(conflicts) > 0, "应该检测到冲突"
        
        print("\n✅ 冲突检测测试通过")


def test_conflict_resolution():
    """测试冲突解决"""
    print("\n" + "=" * 60)
    print("测试2: 冲突解决")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        resolver = ConflictResolver(store)
        
        user_id = "test_user"
        
        # 创建冲突记忆
        mem1 = Memory(
            id="mem1",
            user_id=user_id,
            content="Python是最好的语言",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.8,
            tags=["Python"],
            source_type=SourceType.EXPLICIT,
            created_at=datetime.now() - timedelta(days=10)
        )
        
        mem2 = Memory(
            id="mem2",
            user_id=user_id,
            content="Python不是最好的语言",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.7,
            tags=["Python"],
            source_type=SourceType.EXPLICIT
        )
        
        # 1. 解决矛盾冲突
        print("\n1️⃣  解决矛盾冲突")
        resolution = resolver.resolve_conflict(
            mem2, mem1,
            ConflictType.CONTRADICTION,
            strategy="auto"
        )
        print(f"  解决方案: {resolution['action']}")
        print(f"  原因: {resolution.get('reason', 'N/A')}")
        assert resolution["action"] in ["mark_contradicted", "keep_new"], "应该有解决方案"
        
        # 2. 解决重复冲突
        print("\n2️⃣  解决重复冲突")
        dup_mem = Memory(
            id="mem3",
            user_id=user_id,
            content="Python是最好的语言",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.9,  # 更高重要性
            tags=["Python"],
            source_type=SourceType.EXPLICIT
        )
        
        resolution = resolver.resolve_conflict(
            dup_mem, mem1,
            ConflictType.DUPLICATE,
            strategy="auto"
        )
        print(f"  解决方案: {resolution['action']}")
        print(f"  保留: {resolution.get('kept', 'N/A')}")
        print(f"  删除: {resolution.get('deleted', 'N/A')}")
        
        # 3. 合并策略
        print("\n3️⃣  合并策略")
        merge_resolution = resolver._merge_memories(mem1, dup_mem)
        print(f"  合并内容: {merge_resolution['merged']['content']}")
        print(f"  合并标签: {merge_resolution['merged']['tags']}")
        
        print("\n✅ 冲突解决测试通过")


def test_memory_update():
    """测试记忆更新"""
    print("\n" + "=" * 60)
    print("测试3: 记忆更新")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        updater = MemoryUpdater(store)
        
        user_id = "test_user"
        
        # 创建记忆
        memory = Memory(
            id="mem1",
            user_id=user_id,
            content="原始内容",
            memory_type=MemoryType.MID,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.6,
            tags=["tag1"],
            source_type=SourceType.EXPLICIT
        )
        store.create_memory(memory)
        
        # 1. 更新内容
        print("\n1️⃣  更新内容")
        updated = updater.update_content("mem1", "新的内容", recompute_importance=False)
        assert updated is not None, "应该更新成功"
        assert updated.content == "新的内容", "内容应该更新"
        print(f"  旧内容: 原始内容")
        print(f"  新内容: {updated.content}")
        
        # 2. 更新标签
        print("\n2️⃣  更新标签")
        updated = updater.update_tags("mem1", ["tag2", "tag3"], mode="add")
        assert "tag1" in updated.tags, "原标签应该保留"
        assert "tag2" in updated.tags, "新标签应该添加"
        print(f"  标签: {updated.tags}")
        
        # 3. 添加关联
        print("\n3️⃣  添加关联")
        mem2 = Memory(
            id="mem2",
            user_id=user_id,
            content="关联记忆",
            memory_type=MemoryType.MID,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.5,
            tags=[],
            source_type=SourceType.EXPLICIT
        )
        store.create_memory(mem2)
        
        success = updater.add_related_memory("mem1", "mem2", bidirectional=True)
        assert success, "应该添加关联成功"
        
        updated = store.get_memory("mem1")
        assert "mem2" in updated.related_memory_ids, "应该有关联"
        print(f"  关联记忆: {updated.related_memory_ids}")
        
        # 4. 更新访问计数
        print("\n4️⃣  更新访问计数")
        old_count = updated.access_count
        updated = updater.increment_access_count("mem1")
        assert updated.access_count == old_count + 1, "访问计数应该增加"
        print(f"  访问次数: {old_count} → {updated.access_count}")
        
        print("\n✅ 记忆更新测试通过")


def test_memory_merger():
    """测试记忆合并"""
    print("\n" + "=" * 60)
    print("测试4: 记忆合并")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        merger = MemoryMerger(store)
        
        user_id = "test_user"
        
        # 创建相似记忆
        mem1 = Memory(
            id="mem1",
            user_id=user_id,
            content="我学习了Python基础",
            memory_type=MemoryType.MID,
            category=MemoryCategory.EXPERIENCE,
            importance=0.7,
            tags=["Python", "学习"],
            source_type=SourceType.EXPLICIT
        )
        
        mem2 = Memory(
            id="mem2",
            user_id=user_id,
            content="掌握了Python语法",
            memory_type=MemoryType.MID,
            category=MemoryCategory.EXPERIENCE,
            importance=0.6,
            tags=["Python", "语法"],
            source_type=SourceType.EXPLICIT
        )
        
        # 1. 合并两个记忆
        print("\n1️⃣  合并两个记忆")
        merged = merger.merge_two_memories(mem1, mem2)
        print(f"  原记忆1: {mem1.content}")
        print(f"  原记忆2: {mem2.content}")
        print(f"  合并后: {merged.content}")
        print(f"  合并标签: {merged.tags}")
        print(f"  重要性: {merged.importance}")
        
        assert "Python" in merged.tags, "应该包含Python标签"
        assert merged.importance == max(mem1.importance, mem2.importance), "应该保留最高重要性"
        
        print("\n✅ 记忆合并测试通过")


def test_association_manager():
    """测试关联管理"""
    print("\n" + "=" * 60)
    print("测试5: 关联管理")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        manager = AssociationManager(store)
        
        user_id = "test_user"
        
        # 创建记忆
        memories = [
            Memory(
                id=f"mem{i}",
                user_id=user_id,
                content=f"Python相关内容{i}",
                memory_type=MemoryType.MID,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.6,
                tags=["Python"] if i < 3 else ["Java"],
                source_type=SourceType.EXPLICIT
            )
            for i in range(5)
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 1. 添加关联
        print("\n1️⃣  添加关联")
        success = manager.add_association("mem0", "mem1", bidirectional=True)
        assert success, "应该添加成功"
        
        mem0 = store.get_memory("mem0")
        assert "mem1" in mem0.related_memory_ids, "应该有关联"
        print(f"  mem0 → mem1: 成功")
        
        # 2. 自动创建关联
        print("\n2️⃣  自动创建关联")
        count = manager.auto_create_associations(memories[2], user_id, max_associations=3)
        print(f"  为mem2创建了 {count} 个关联")
        
        mem2 = store.get_memory("mem2")
        print(f"  关联记忆: {mem2.related_memory_ids}")
        
        # 3. 清理无效关联
        print("\n3️⃣  清理无效关联")
        # 添加一个无效关联
        mem0.related_memory_ids.append("invalid_id")
        store.update_memory(mem0)
        
        cleaned = manager.clean_broken_associations(user_id)
        print(f"  清理了 {cleaned} 个无效关联")
        assert cleaned > 0, "应该清理了无效关联"
        
        print("\n✅ 关联管理测试通过")


def test_update_manager():
    """测试更新管理器"""
    print("\n" + "=" * 60)
    print("测试6: 更新管理器")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        manager = UpdateManager(store)
        
        user_id = "test_user"
        
        # 创建已有记忆
        existing = Memory(
            id="existing",
            user_id=user_id,
            content="我喜欢Python",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.8,
            tags=["Python"],
            source_type=SourceType.EXPLICIT
        )
        store.create_memory(existing)
        
        # 1. 添加新记忆并检查冲突
        print("\n1️⃣  添加新记忆并检查冲突")
        new_memory = Memory(
            id="new1",
            user_id=user_id,
            content="我不喜欢Python",  # 矛盾
            memory_type=MemoryType.LONG,
            category=MemoryCategory.PREFERENCE,
            importance=0.7,
            tags=["Python"],
            source_type=SourceType.EXPLICIT
        )
        
        result = manager.add_new_memory_with_conflict_check(
            new_memory,
            auto_resolve=True
        )
        
        print(f"  冲突数量: {result['conflicts_found']}")
        print(f"  解决方案数: {len(result['resolutions'])}")
        print(f"  存储成功: {result['stored']}")
        
        # 2. 更新记忆内容
        print("\n2️⃣  更新记忆内容")
        update_result = manager.update_memory_content(
            "existing",
            "我非常喜欢Python编程",
            check_conflicts=True
        )
        
        assert update_result['success'], "应该更新成功"
        print(f"  更新成功: {update_result['success']}")
        print(f"  新内容: {update_result['memory'].content}")
        
        # 3. 维护关联
        print("\n3️⃣  维护关联")
        assoc_result = manager.maintain_associations(
            user_id,
            auto_create=True,
            clean_broken=True
        )
        print(f"  创建关联: {assoc_result['associations_created']}")
        print(f"  清理关联: {assoc_result['associations_cleaned']}")
        
        print("\n✅ 更新管理器测试通过")


def main():
    """运行所有测试"""
    print("\n" + "🎯" * 30)
    print("更新模块简单测试")
    print("🎯" * 30)
    
    try:
        test_conflict_detection()
        test_conflict_resolution()
        test_memory_update()
        test_memory_merger()
        test_association_manager()
        test_update_manager()
        
        print("\n" + "=" * 60)
        print("🎉 所有更新模块测试通过！")
        print("=" * 60)
        print("\n✅ 验证项目:")
        print("  ✓ 冲突检测功能正常")
        print("  ✓ 冲突解决策略有效")
        print("  ✓ 记忆更新功能完整")
        print("  ✓ 记忆合并功能正常")
        print("  ✓ 关联管理功能有效")
        print("  ✓ 更新管理器集成成功")
        print("\n阶段4完成！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

