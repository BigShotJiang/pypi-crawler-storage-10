"""
基础功能测试

测试核心数据模型、配置加载、存储层等基础功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from datetime import datetime
from core.memory import Memory, UserProfile, Session, MemoryType, MemoryCategory
from core.config import get_config
from storage.sqlite_store import SQLiteStore
from storage.vector_store import VectorStore


class TestMemoryModel:
    """测试Memory数据模型"""
    
    def test_create_memory(self):
        """测试创建记忆"""
        memory = Memory(
            user_id="test_user",
            content="这是一条测试记忆",
            memory_type=MemoryType.SHORT,
            category=MemoryCategory.KNOWLEDGE
        )
        
        assert memory.id is not None
        assert memory.user_id == "test_user"
        assert memory.content == "这是一条测试记忆"
        assert memory.importance == 0.5
        assert memory.confidence == 0.7
    
    def test_memory_to_dict(self):
        """测试Memory转字典"""
        memory = Memory(user_id="test_user", content="测试")
        data = memory.to_dict()
        
        assert isinstance(data, dict)
        assert data["user_id"] == "test_user"
        assert data["content"] == "测试"
        assert "created_at" in data
    
    def test_memory_from_dict(self):
        """测试从字典创建Memory"""
        data = {
            "id": "test_id",
            "user_id": "test_user",
            "content": "测试内容",
            "memory_type": "short",
            "category": "knowledge"
        }
        
        memory = Memory.from_dict(data)
        assert memory.id == "test_id"
        assert memory.user_id == "test_user"
        assert memory.content == "测试内容"


class TestConfig:
    """测试配置管理"""
    
    def test_load_config(self):
        """测试加载配置"""
        config = get_config()
        
        assert config is not None
        assert config.llm_model is not None
        assert config.embedding_model is not None
    
    def test_config_singleton(self):
        """测试配置单例"""
        config1 = get_config()
        config2 = get_config()
        
        assert config1 is config2
    
    def test_config_get(self):
        """测试获取配置项"""
        config = get_config()
        
        model = config.get("llm.model")
        assert model is not None
        
        # 测试默认值
        non_exist = config.get("non.exist.key", "default")
        assert non_exist == "default"


class TestSQLiteStore:
    """测试SQLite存储"""
    
    @pytest.fixture
    def store(self):
        """创建测试用的存储实例"""
        # 使用内存数据库
        return SQLiteStore(db_path=":memory:")
    
    def test_create_and_get_memory(self, store):
        """测试创建和获取记忆"""
        memory = Memory(
            user_id="test_user",
            content="测试记忆内容",
            importance=0.8
        )
        
        # 创建
        created = store.create_memory(memory)
        assert created.id == memory.id
        
        # 获取
        retrieved = store.get_memory(memory.id)
        assert retrieved is not None
        assert retrieved.content == "测试记忆内容"
        assert retrieved.importance == 0.8
    
    def test_update_memory(self, store):
        """测试更新记忆"""
        memory = Memory(user_id="test_user", content="原内容")
        store.create_memory(memory)
        
        # 更新
        memory.content = "新内容"
        memory.importance = 0.9
        store.update_memory(memory)
        
        # 验证
        retrieved = store.get_memory(memory.id)
        assert retrieved.content == "新内容"
        assert retrieved.importance == 0.9
    
    def test_delete_memory(self, store):
        """测试删除记忆"""
        memory = Memory(user_id="test_user", content="待删除")
        store.create_memory(memory)
        
        # 删除
        store.delete_memory(memory.id, "test_user", "test")
        
        # 验证（软删除，仍能获取但is_deleted=True）
        retrieved = store.get_memory(memory.id)
        assert retrieved is None  # 因为查询时过滤了is_deleted
    
    def test_get_memories_by_user(self, store):
        """测试获取用户记忆列表"""
        # 使用独立的user_id避免与其他测试冲突
        test_user_id = "test_user_for_list"
        
        # 创建多条记忆
        for i in range(5):
            memory = Memory(
                user_id=test_user_id,
                content=f"记忆{i}",
                importance=0.5 + i * 0.1
            )
            store.create_memory(memory)
        
        # 获取列表
        memories = store.get_memories_by_user(test_user_id)
        assert len(memories) == 5, f"Expected 5 memories, got {len(memories)}"
        
        # 验证排序（按importance降序）
        assert memories[0].importance >= memories[-1].importance
    
    def test_user_profile(self, store):
        """测试用户画像"""
        profile = UserProfile(
            user_id="test_user",
            domain="软件开发",
            role="开发者",
            preferences={"language": "Python"}
        )
        
        # 创建
        store.create_or_update_profile(profile)
        
        # 获取
        retrieved = store.get_profile("test_user")
        assert retrieved is not None
        assert retrieved.domain == "软件开发"
        assert retrieved.preferences["language"] == "Python"
        
        # 更新
        profile.confidence = 0.8
        store.create_or_update_profile(profile)
        
        retrieved = store.get_profile("test_user")
        assert retrieved.confidence == 0.8
    
    def test_session(self, store):
        """测试会话"""
        session = Session(
            user_id="test_user",
            summary="测试会话"
        )
        session.add_message("user", "你好")
        session.add_message("assistant", "你好！")
        
        # 创建
        store.create_session(session)
        
        # 获取
        retrieved = store.get_session(session.session_id)
        assert retrieved is not None
        assert len(retrieved.messages) == 2
        assert retrieved.summary == "测试会话"


class TestVectorStore:
    """测试向量存储"""
    
    @pytest.fixture
    def vector_store(self, tmp_path):
        """创建测试用的向量存储"""
        store = VectorStore(
            db_path=str(tmp_path / "test_chroma"),
            collection_name="test_memories"
        )
        # 清空
        store.reset_collection()
        return store
    
    def test_add_and_search(self, vector_store):
        """测试添加和检索"""
        memory = Memory(
            user_id="test_user",
            content="Python是一门编程语言"
        )
        
        # 模拟embedding（实际使用时需要真实的向量）
        fake_embedding = [0.1] * 384
        
        # 添加
        vector_store.add_memory(memory, fake_embedding)
        
        # 搜索
        results = vector_store.search_similar(
            query_embedding=fake_embedding,
            user_id="test_user",
            top_k=5
        )
        
        assert len(results) > 0
        assert results[0][0] == memory.id
    
    def test_delete_vector(self, vector_store):
        """测试删除向量"""
        memory = Memory(user_id="test_user", content="测试")
        fake_embedding = [0.1] * 384
        
        vector_store.add_memory(memory, fake_embedding)
        vector_store.delete_memory(memory.id)
        
        # 验证
        count = vector_store.count_memories("test_user")
        assert count == 0


def run_tests():
    """运行所有测试"""
    print("=" * 60)
    print("运行基础功能测试")
    print("=" * 60)
    
    # 测试Memory模型
    print("\n[1/4] 测试Memory数据模型...")
    test_memory = TestMemoryModel()
    test_memory.test_create_memory()
    test_memory.test_memory_to_dict()
    test_memory.test_memory_from_dict()
    print("✓ Memory模型测试通过")
    
    # 测试配置
    print("\n[2/4] 测试配置管理...")
    test_config = TestConfig()
    test_config.test_load_config()
    test_config.test_config_singleton()
    test_config.test_config_get()
    print("✓ 配置管理测试通过")
    
    # 测试SQLite存储
    print("\n[3/4] 测试SQLite存储...")
    test_store = TestSQLiteStore()
    store = SQLiteStore(db_path=":memory:")
    test_store.test_create_and_get_memory(store)
    test_store.test_update_memory(store)
    test_store.test_delete_memory(store)
    test_store.test_get_memories_by_user(store)
    test_store.test_user_profile(store)
    test_store.test_session(store)
    print("✓ SQLite存储测试通过")
    
    # 测试向量存储
    print("\n[4/4] 测试向量存储...")
    try:
        import tempfile
        from pathlib import Path
        
        test_vector = TestVectorStore()
        with tempfile.TemporaryDirectory() as tmpdir:
            # 测试1: 添加和搜索
            vector_store1 = VectorStore(
                db_path=str(Path(tmpdir) / "test_chroma1"),
                collection_name="test_memories1"
            )
            vector_store1.reset_collection()
            test_vector.test_add_and_search(vector_store1)
            
            # 测试2: 删除向量
            vector_store2 = VectorStore(
                db_path=str(Path(tmpdir) / "test_chroma2"),
                collection_name="test_memories2"
            )
            vector_store2.reset_collection()
            test_vector.test_delete_vector(vector_store2)
        print("✓ 向量存储测试通过")
    except ImportError as e:
        print(f"⚠ 向量存储测试跳过（缺少依赖: {e}）")
    except RuntimeError as e:
        print(f"⚠ 向量存储测试跳过（运行时错误: {e}）")
    except Exception as e:
        print(f"⚠ 向量存储测试跳过（错误: {type(e).__name__}: {e}）")
    
    print("\n" + "=" * 60)
    print("✓ 所有基础测试通过！")
    print("=" * 60)


if __name__ == "__main__":
    run_tests()

