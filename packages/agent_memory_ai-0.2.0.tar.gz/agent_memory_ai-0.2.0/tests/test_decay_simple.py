"""
记忆衰减与遗忘模块简单测试
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from storage.sqlite_store import SQLiteStore
from modules.decay import DecayManager, ForgetManager


def create_test_memory(
    user_id: str = "test_user",
    content: str = "测试记忆",
    memory_type: MemoryType = MemoryType.WORK,
    importance: float = 0.5,
    age_days: int = 0,
    access_count: int = 0
) -> Memory:
    """创建测试记忆"""
    created_at = datetime.now() - timedelta(days=age_days)
    
    memory = Memory(
        user_id=user_id,
        content=content,
        memory_type=memory_type,
        category=MemoryCategory.KNOWLEDGE,
        source_type=SourceType.EXPLICIT,
        importance=importance,
        created_at=created_at,
        updated_at=created_at,
        access_count=access_count
    )
    
    return memory


def test_decay_calculation():
    """测试衰减计算"""
    print("=" * 70)
    print("测试1: 衰减计算")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store)
        
        # 创建一个7天前的记忆
        memory = create_test_memory(
            content="7天前的记忆",
            importance=0.8,
            age_days=7,
            access_count=0
        )
        
        # 计算衰减
        decayed_importance = decay_manager.calculate_decay(memory)
        
        print(f"原始重要性: {memory.importance:.3f}")
        print(f"衰减后重要性: {decayed_importance:.3f}")
        print(f"衰减量: {memory.importance - decayed_importance:.3f}")
        
        # 验证衰减
        assert decayed_importance < memory.importance, "应该发生衰减"
        assert decayed_importance > 0, "衰减后重要性应该大于0"
        
        print("✅ 衰减计算正常")


def test_promotion():
    """测试晋升机制"""
    print("\n" + "=" * 70)
    print("测试2: 晋升机制")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store)
        
        # 测试1: 工作记忆 → 短期记忆
        print("\n1️⃣  工作记忆晋升")
        work_memory = create_test_memory(
            content="重要的工作记忆",
            memory_type=MemoryType.WORK,
            importance=0.7,
            age_days=2,
            access_count=5
        )
        
        should_promote = decay_manager.should_promote(work_memory)
        print(f"  应该晋升: {should_promote}")
        
        if should_promote:
            promoted = decay_manager.promote_memory(work_memory)
            print(f"  晋升后类型: {promoted.memory_type.value}")
            assert promoted.memory_type == MemoryType.SHORT, "应该晋升到短期"
        
        # 测试2: 低重要性不晋升
        print("\n2️⃣  低重要性记忆不晋升")
        low_memory = create_test_memory(
            content="低重要性记忆",
            memory_type=MemoryType.WORK,
            importance=0.3,
            age_days=2,
            access_count=1
        )
        
        should_promote = decay_manager.should_promote(low_memory)
        print(f"  应该晋升: {should_promote}")
        assert not should_promote, "低重要性不应晋升"
        
        print("\n✅ 晋升机制正常")


def test_archival():
    """测试归档机制"""
    print("\n" + "=" * 70)
    print("测试3: 归档机制")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store, decay_rate=0.5)
        
        # 测试1: 旧的低重要性记忆应该归档
        print("\n1️⃣  旧的低重要性记忆")
        old_memory = create_test_memory(
            content="10天前的低重要性记忆",
            memory_type=MemoryType.SHORT,
            importance=0.2,
            age_days=10,
            access_count=0
        )
        
        should_archive = decay_manager.should_archive(old_memory)
        print(f"  应该归档: {should_archive}")
        assert should_archive, "旧的低重要性记忆应该归档"
        
        # 测试2: 新的记忆不归档
        print("\n2️⃣  新的记忆")
        new_memory = create_test_memory(
            content="1天前的记忆",
            memory_type=MemoryType.WORK,
            importance=0.5,
            age_days=1,
            access_count=2
        )
        
        should_archive = decay_manager.should_archive(new_memory)
        print(f"  应该归档: {should_archive}")
        assert not should_archive, "新的记忆不应归档"
        
        print("\n✅ 归档机制正常")


def test_lifecycle_processing():
    """测试生命周期处理"""
    print("\n" + "=" * 70)
    print("测试4: 生命周期处理")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store)
        
        user_id = "test_user"
        
        # 创建多个不同状态的记忆
        memories = [
            create_test_memory(user_id, "应该晋升的工作记忆", MemoryType.WORK, 0.7, 2, 5),
            create_test_memory(user_id, "应该归档的短期记忆", MemoryType.SHORT, 0.2, 10, 0),
            create_test_memory(user_id, "正常的中期记忆", MemoryType.MID, 0.5, 15, 3),
            create_test_memory(user_id, "核心记忆", MemoryType.CORE, 0.9, 100, 50),
        ]
        
        # 存储记忆
        for memory in memories:
            store.create_memory(memory)
        
        print(f"创建了 {len(memories)} 条记忆")
        
        # 处理生命周期
        result = decay_manager.process_memory_lifecycle(user_id)
        
        print(f"\n处理结果:")
        print(f"  处理数量: {result['processed']}")
        print(f"  晋升数量: {result['promoted']}")
        print(f"  归档数量: {result['archived']}")
        print(f"  衰减数量: {result['decayed']}")
        print(f"  错误数量: {len(result['errors'])}")
        
        assert result['processed'] == len(memories), "应该处理所有记忆"
        assert result['promoted'] >= 0, "晋升数量应该非负"
        assert result['archived'] >= 0, "归档数量应该非负"
        
        print("\n✅ 生命周期处理正常")


def test_reinforcement():
    """测试记忆强化"""
    print("\n" + "=" * 70)
    print("测试5: 记忆强化")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store)
        
        # 创建记忆
        memory = create_test_memory(
            content="要强化的记忆",
            importance=0.5,
            access_count=0
        )
        
        print(f"原始状态:")
        print(f"  重要性: {memory.importance:.3f}")
        print(f"  访问次数: {memory.access_count}")
        
        # 强化记忆
        reinforced = decay_manager.reinforce_memory(memory, boost=0.1)
        
        print(f"\n强化后:")
        print(f"  重要性: {reinforced.importance:.3f}")
        print(f"  访问次数: {reinforced.access_count}")
        
        assert reinforced.access_count == 1, "访问次数应该增加"
        assert reinforced.importance >= memory.importance, "重要性应该增加或不变"
        
        print("\n✅ 记忆强化正常")


def test_forget_by_id():
    """测试按ID遗忘"""
    print("\n" + "=" * 70)
    print("测试6: 按ID遗忘")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        forget_manager = ForgetManager(store)
        
        user_id = "test_user"
        
        # 创建记忆
        memory = create_test_memory(user_id, "要删除的记忆")
        store.create_memory(memory)
        
        print(f"创建记忆: {memory.id}")
        
        # 遗忘记忆
        result = forget_manager.forget_by_id(memory.id, user_id, cascade=False)
        
        print(f"\n遗忘结果:")
        print(f"  删除数量: {result.deleted_count}")
        print(f"  删除ID: {result.deleted_ids}")
        print(f"  原因: {result.reason}")
        
        assert result.deleted_count == 1, "应该删除1条记忆"
        assert memory.id in result.deleted_ids, "应该包含删除的ID"
        
        # 验证已删除
        deleted_memory = store.get_memory(memory.id)
        assert deleted_memory is None, "记忆应该已被删除"
        
        print("\n✅ 按ID遗忘正常")


def test_forget_by_query():
    """测试按查询遗忘"""
    print("\n" + "=" * 70)
    print("测试7: 按查询遗忘")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        forget_manager = ForgetManager(store)
        
        user_id = "test_user"
        
        # 创建多个记忆
        memories = [
            create_test_memory(user_id, "Python编程学习"),
            create_test_memory(user_id, "Java开发经验"),
            create_test_memory(user_id, "Python数据分析"),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        print(f"创建了 {len(memories)} 条记忆")
        
        # 测试1: 确认模式
        print("\n1️⃣  确认模式")
        result, to_confirm = forget_manager.forget_by_query(
            "Python",
            user_id,
            confirm=True
        )
        
        print(f"  找到匹配记忆: {len(to_confirm) if to_confirm else 0} 条")
        if to_confirm:
            for m in to_confirm:
                print(f"    - {m.content}")
        
        assert to_confirm is not None, "应该返回待确认列表"
        assert len(to_confirm) == 2, "应该匹配2条Python相关记忆"
        
        # 测试2: 直接删除模式
        print("\n2️⃣  直接删除模式")
        result, _ = forget_manager.forget_by_query(
            "Python",
            user_id,
            confirm=False
        )
        
        print(f"  删除数量: {result.deleted_count}")
        assert result.deleted_count == 2, "应该删除2条记忆"
        
        # 验证删除
        remaining = store.get_memories_by_user(user_id)
        print(f"  剩余记忆: {len(remaining)} 条")
        assert len(remaining) == 1, "应该剩余1条记忆"
        
        print("\n✅ 按查询遗忘正常")


def test_forget_by_tags():
    """测试按标签遗忘"""
    print("\n" + "=" * 70)
    print("测试8: 按标签遗忘")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        forget_manager = ForgetManager(store)
        
        user_id = "test_user"
        
        # 创建带标签的记忆
        memory1 = create_test_memory(user_id, "Python学习")
        memory1.tags = ["Python", "编程", "学习"]
        store.create_memory(memory1)
        
        memory2 = create_test_memory(user_id, "Java学习")
        memory2.tags = ["Java", "编程"]
        store.create_memory(memory2)
        
        memory3 = create_test_memory(user_id, "数据分析")
        memory3.tags = ["Python", "数据科学"]
        store.create_memory(memory3)
        
        print("创建了3条带标签的记忆")
        
        # 按标签删除（OR模式）
        result = forget_manager.forget_by_tags(
            user_id,
            ["Python"],
            match_all=False
        )
        
        print(f"\n删除带'Python'标签的记忆:")
        print(f"  删除数量: {result.deleted_count}")
        
        assert result.deleted_count == 2, "应该删除2条Python标签的记忆"
        
        # 验证剩余
        remaining = store.get_memories_by_user(user_id)
        print(f"  剩余记忆: {len(remaining)} 条")
        assert len(remaining) == 1, "应该剩余1条记忆"
        
        print("\n✅ 按标签遗忘正常")


def test_auto_forget():
    """测试自动遗忘"""
    print("\n" + "=" * 70)
    print("测试9: 自动遗忘")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        forget_manager = ForgetManager(
            store,
            auto_delete_threshold=0.3,
            sensitive_ttl_days=30
        )
        
        user_id = "test_user"
        
        # 创建不同类型的记忆
        # 1. 低重要性旧记忆（应该删除）
        old_low = create_test_memory(
            user_id,
            "低重要性旧记忆",
            importance=0.2,
            age_days=70
        )
        store.create_memory(old_low)
        
        # 2. 过期敏感信息（应该删除）
        old_sensitive = create_test_memory(
            user_id,
            "过期敏感信息",
            importance=0.5,
            age_days=40
        )
        old_sensitive.privacy_level = PrivacyLevel.SENSITIVE
        store.create_memory(old_sensitive)
        
        # 3. 正常记忆（不删除）
        normal = create_test_memory(
            user_id,
            "正常记忆",
            importance=0.6,
            age_days=10
        )
        store.create_memory(normal)
        
        # 4. 一次性已使用记忆（应该删除）
        ephemeral = create_test_memory(user_id, "一次性记忆")
        ephemeral.metadata['is_ephemeral'] = True
        ephemeral.metadata['is_used'] = True
        store.create_memory(ephemeral)
        
        print("创建了4条不同类型的记忆")
        
        # 执行自动遗忘
        result = forget_manager.auto_forget(user_id)
        
        print(f"\n自动遗忘结果:")
        print(f"  删除数量: {result.deleted_count}")
        print(f"  原因: {result.reason}")
        
        # 至少应该删除一些记忆
        assert result.deleted_count > 0, "应该删除一些记忆"
        
        # 验证剩余
        remaining = store.get_memories_by_user(user_id)
        print(f"  剩余记忆: {len(remaining)} 条")
        
        print("\n✅ 自动遗忘正常")


def test_cascade_delete():
    """测试级联删除"""
    print("\n" + "=" * 70)
    print("测试10: 级联删除")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        forget_manager = ForgetManager(store)
        
        user_id = "test_user"
        
        # 创建主记忆
        main_memory = create_test_memory(user_id, "主记忆")
        store.create_memory(main_memory)
        
        # 创建关联记忆
        related1 = create_test_memory(user_id, "强关联记忆")
        store.create_memory(related1)
        
        related2 = create_test_memory(user_id, "弱关联记忆")
        store.create_memory(related2)
        
        # 建立关联
        main_memory.related_memory_ids = [related1.id, related2.id]
        main_memory.metadata['associations'] = {
            related1.id: {'strength': 0.8},  # 强依赖
            related2.id: {'strength': 0.3},  # 弱依赖
        }
        store.update_memory(main_memory)
        
        print("创建了1条主记忆和2条关联记忆")
        print(f"  主记忆: {main_memory.id}")
        print(f"  强关联: {related1.id}")
        print(f"  弱关联: {related2.id}")
        
        # 级联删除
        result = forget_manager.forget_by_id(
            main_memory.id,
            user_id,
            cascade=True
        )
        
        print(f"\n级联删除结果:")
        print(f"  删除数量: {result.deleted_count}")
        print(f"  级联删除: {len(result.cascade_deleted)} 条")
        
        assert result.deleted_count == 1, "应该删除主记忆"
        assert len(result.cascade_deleted) > 0, "应该级联删除强关联记忆"
        
        print("\n✅ 级联删除正常")


def test_statistics():
    """测试统计功能"""
    print("\n" + "=" * 70)
    print("测试11: 统计功能")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        decay_manager = DecayManager(store)
        forget_manager = ForgetManager(store)
        
        user_id = "test_user"
        
        # 创建多条记忆
        for i in range(5):
            memory = create_test_memory(
                user_id,
                f"记忆{i}",
                importance=0.3 + i * 0.1,
                age_days=i * 5
            )
            store.create_memory(memory)
        
        print("创建了5条记忆")
        
        # 衰减统计
        print("\n1️⃣  衰减统计")
        decay_stats = decay_manager.get_decay_statistics(user_id)
        print(f"  总记忆数: {decay_stats['total']}")
        print(f"  应晋升数: {decay_stats['should_promote']}")
        print(f"  应归档数: {decay_stats['should_archive']}")
        print(f"  平均重要性: {decay_stats['avg_importance']:.3f}")
        
        # 删除一些记忆
        memories = store.get_memories_by_user(user_id)
        for memory in memories[:2]:
            forget_manager.forget_by_id(memory.id, user_id, cascade=False)
        
        # 遗忘统计
        print("\n2️⃣  遗忘统计")
        forget_stats = forget_manager.get_forget_statistics(user_id)
        print(f"  总遗忘数: {forget_stats['total_forgotten']}")
        print(f"  按原因: {forget_stats['by_reason']}")
        
        assert decay_stats['total'] == 5, "应该有5条记忆"
        assert forget_stats['total_forgotten'] == 2, "应该遗忘了2条"
        
        print("\n✅ 统计功能正常")


def main():
    """运行所有测试"""
    print("\n" + "🧪" * 35)
    print("记忆衰减与遗忘模块测试")
    print("🧪" * 35 + "\n")
    
    try:
        test_decay_calculation()
        test_promotion()
        test_archival()
        test_lifecycle_processing()
        test_reinforcement()
        test_forget_by_id()
        test_forget_by_query()
        test_forget_by_tags()
        test_auto_forget()
        test_cascade_delete()
        test_statistics()
        
        print("\n" + "=" * 70)
        print("🎉 所有测试通过！")
        print("=" * 70)
        print("\n✅ 测试项目:")
        print("  ✓ 衰减计算")
        print("  ✓ 晋升机制")
        print("  ✓ 归档机制")
        print("  ✓ 生命周期处理")
        print("  ✓ 记忆强化")
        print("  ✓ 按ID遗忘")
        print("  ✓ 按查询遗忘")
        print("  ✓ 按标签遗忘")
        print("  ✓ 自动遗忘")
        print("  ✓ 级联删除")
        print("  ✓ 统计功能")
        print("\n阶段5开发完成！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

