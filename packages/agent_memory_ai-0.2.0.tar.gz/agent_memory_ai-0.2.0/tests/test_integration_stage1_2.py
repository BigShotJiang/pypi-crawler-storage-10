"""
阶段1+阶段2集成测试

测试记忆形成模块与存储层的完整联通性
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime
from core.memory import Memory, UserProfile, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from core.config import get_config
from storage.sqlite_store import SQLiteStore
from modules.formation.scorer import ImportanceScorer
from modules.formation.classifier import MemoryClassifier


def test_config_integration():
    """测试配置系统集成"""
    print("\n[测试1/6] 配置系统集成...")
    
    config = get_config()
    
    # 验证阶段1的配置
    assert config.db_path is not None
    print(f"  ✓ 数据库配置: {config.db_path}")
    
    # 验证阶段2的配置
    thresholds = config.memory_thresholds
    assert 'core' in thresholds
    assert 'long_term' in thresholds
    print(f"  ✓ 记忆阈值配置: {thresholds}")
    
    assert config.llm_model is not None
    print(f"  ✓ LLM模型配置: {config.llm_model}")


def test_storage_with_classification():
    """测试存储层与分类器的集成"""
    print("\n[测试2/6] 存储层 + 分类器集成...")
    
    # 初始化组件
    store = SQLiteStore(db_path=":memory:")
    classifier = MemoryClassifier()
    
    # 创建用户画像（阶段1功能）
    profile = UserProfile(
        user_id="test_user",
        domain="数据科学",
        preferences={"language": "Python"}
    )
    store.create_or_update_profile(profile)
    print("  ✓ 创建用户画像（阶段1）")
    
    # 使用分类器分类（阶段2功能）
    text = "我喜欢使用Python进行数据分析"
    category = classifier.classify_category(text)
    memory_type = classifier.classify_memory_type(0.7, text)
    tags = classifier.generate_tags(text)
    
    print(f"  ✓ 分类记忆（阶段2）: {memory_type.value} / {category.value}")
    
    # 创建记忆并存储（综合）
    memory = Memory(
        user_id="test_user",
        content=text,
        memory_type=memory_type,
        category=category,
        importance=0.7,
        tags=tags
    )
    
    store.create_memory(memory)
    print("  ✓ 保存到数据库（阶段1）")
    
    # 验证存储
    retrieved = store.get_memory(memory.id)
    assert retrieved is not None
    assert retrieved.memory_type == memory_type
    assert retrieved.category == category
    print("  ✓ 数据库读取验证成功")


def test_scorer_with_storage():
    """测试评分器与存储层的集成"""
    print("\n[测试3/6] 评分器 + 存储层集成...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    
    # 创建用户和初始记忆
    profile = UserProfile(
        user_id="test_user",
        domain="软件开发",
        preferences={"language": "Python"}
    )
    store.create_or_update_profile(profile)
    
    # 添加一些历史记忆
    existing_texts = [
        "Python是一门编程语言",
        "数据分析很重要",
        "机器学习需要大量数据"
    ]
    
    for text in existing_texts:
        mem = Memory(
            user_id="test_user",
            content=text,
            memory_type=MemoryType.MID,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.5
        )
        store.create_memory(mem)
    
    print(f"  ✓ 创建{len(existing_texts)}条历史记忆")
    
    # 测试新颖性计算（会查询数据库）
    new_text = "Python是一门编程语言"  # 重复内容
    novelty = scorer.calculate_novelty(new_text, "test_user")
    assert novelty < 1.0, "重复内容新颖性应该降低"
    print(f"  ✓ 新颖性计算（重复内容）: {novelty:.3f}")
    
    unique_text = "区块链技术很有前景"  # 新内容
    novelty2 = scorer.calculate_novelty(unique_text, "test_user")
    assert novelty2 > novelty, "新内容应该更有新颖性"
    print(f"  ✓ 新颖性计算（新内容）: {novelty2:.3f}")
    
    # 测试相关性计算（会读取用户画像）
    relevance = scorer.calculate_relevance("Python开发很有趣", "test_user")
    assert relevance > 0.5, "与用户领域相关的内容相关性应该较高"
    print(f"  ✓ 相关性计算: {relevance:.3f}")
    
    # 测试频率评分（会统计历史记忆）
    frequency = scorer.calculate_frequency_score("Python相关的内容", "test_user")
    print(f"  ✓ 频率评分: {frequency:.3f}")


def test_complete_memory_formation_flow():
    """测试完整的记忆形成流程"""
    print("\n[测试4/6] 完整记忆形成流程...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    classifier = MemoryClassifier()
    
    # 1. 创建用户（阶段1）
    profile = UserProfile(
        user_id="integration_user",
        domain="数据科学",
        role="数据分析师",
        preferences={
            "language": "Python",
            "tools": ["Pandas", "NumPy"]
        }
    )
    store.create_or_update_profile(profile)
    print("  ✓ 步骤1: 创建用户画像")
    
    # 2. 模拟对话输入
    conversation_texts = [
        "我主要使用Python做数据分析",
        "我最常用的库是Pandas",
        "上次项目中数据清洗很重要",
        "我认为数据质量是核心",
        "今天学习了新的可视化方法"
    ]
    
    print("  ✓ 步骤2: 输入对话文本")
    
    # 3. 逐条处理
    memories_created = []
    for i, text in enumerate(conversation_texts, 1):
        # 3.1 计算重要性（阶段2 - 评分器）
        importance = scorer.calculate_importance(text, "integration_user")
        
        # 3.2 分类（阶段2 - 分类器）
        memory_type = classifier.classify_memory_type(importance, text)
        category = classifier.classify_category(text)
        tags = classifier.generate_tags(text)
        privacy_str = classifier.determine_privacy_level(text)
        privacy = PrivacyLevel[privacy_str.upper()]
        
        # 3.3 计算置信度（阶段2 - 评分器）
        confidence = scorer.calculate_confidence(text, "explicit")
        
        # 3.4 创建记忆对象（阶段1 - 数据模型）
        memory = Memory(
            user_id="integration_user",
            content=text,
            memory_type=memory_type,
            category=category,
            importance=importance,
            confidence=confidence,
            source_type=SourceType.EXPLICIT,
            tags=tags,
            privacy_level=privacy
        )
        
        # 3.5 保存到数据库（阶段1 - 存储层）
        store.create_memory(memory)
        memories_created.append(memory)
        
        print(f"    记忆{i}: [{memory_type.value:5s}] [{category.value:11s}] "
              f"重要性:{importance:.2f} - {text[:25]}...")
    
    print(f"  ✓ 步骤3: 创建{len(memories_created)}条记忆")
    
    # 4. 验证存储
    all_memories = store.get_memories_by_user("integration_user")
    assert len(all_memories) == len(conversation_texts)
    print(f"  ✓ 步骤4: 验证数据库（{len(all_memories)}条记忆）")
    
    # 5. 验证分类分布
    type_dist = {}
    category_dist = {}
    for mem in all_memories:
        type_dist[mem.memory_type.value] = type_dist.get(mem.memory_type.value, 0) + 1
        category_dist[mem.category.value] = category_dist.get(mem.category.value, 0) + 1
    
    print(f"  ✓ 步骤5: 类型分布 {type_dist}")
    print(f"           维度分布 {category_dist}")
    
    # 6. 测试检索功能
    sorted_memories = sorted(all_memories, key=lambda m: m.importance, reverse=True)
    most_important = sorted_memories[0]
    print(f"  ✓ 步骤6: 最重要的记忆: {most_important.content[:30]}... ({most_important.importance:.2f})")
    
    # 7. 测试标签检索
    all_tags = set()
    for mem in all_memories:
        all_tags.update(mem.tags)
    print(f"  ✓ 步骤7: 共生成{len(all_tags)}个不同标签")


def test_multi_user_isolation():
    """测试多用户隔离"""
    print("\n[测试5/6] 多用户数据隔离...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    classifier = MemoryClassifier()
    
    # 创建两个用户
    users = [
        ("user_1", "Python开发", {"language": "Python"}),
        ("user_2", "Java开发", {"language": "Java"})
    ]
    
    for user_id, domain, prefs in users:
        profile = UserProfile(
            user_id=user_id,
            domain=domain,
            preferences=prefs
        )
        store.create_or_update_profile(profile)
    
    print("  ✓ 创建2个用户")
    
    # 为每个用户创建记忆
    user1_memories = [
        "我喜欢Python的简洁语法",
        "Pandas是很好的数据分析工具"
    ]
    
    user2_memories = [
        "Java的性能很不错",
        "Spring Boot很适合企业开发"
    ]
    
    for text in user1_memories:
        importance = scorer.calculate_importance(text, "user_1")
        mem = Memory(
            user_id="user_1",
            content=text,
            memory_type=classifier.classify_memory_type(importance, text),
            category=classifier.classify_category(text),
            importance=importance
        )
        store.create_memory(mem)
    
    for text in user2_memories:
        importance = scorer.calculate_importance(text, "user_2")
        mem = Memory(
            user_id="user_2",
            content=text,
            memory_type=classifier.classify_memory_type(importance, text),
            category=classifier.classify_category(text),
            importance=importance
        )
        store.create_memory(mem)
    
    print("  ✓ 为每个用户创建记忆")
    
    # 验证隔离
    user1_mems = store.get_memories_by_user("user_1")
    user2_mems = store.get_memories_by_user("user_2")
    
    assert len(user1_mems) == len(user1_memories)
    assert len(user2_mems) == len(user2_memories)
    
    # 验证内容不交叉
    user1_contents = {m.content for m in user1_mems}
    user2_contents = {m.content for m in user2_mems}
    assert len(user1_contents & user2_contents) == 0, "用户记忆应该完全隔离"
    
    print(f"  ✓ 用户1: {len(user1_mems)}条记忆")
    print(f"  ✓ 用户2: {len(user2_mems)}条记忆")
    print("  ✓ 数据隔离验证成功")


def test_memory_update_and_access():
    """测试记忆更新和访问统计"""
    print("\n[测试6/6] 记忆更新和访问统计...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    classifier = MemoryClassifier()
    
    # 创建记忆
    text = "Python是一门很好的编程语言"
    importance = scorer.calculate_importance(text, "test_user")
    
    memory = Memory(
        user_id="test_user",
        content=text,
        memory_type=classifier.classify_memory_type(importance, text),
        category=classifier.classify_category(text),
        importance=importance,
        access_count=0
    )
    
    store.create_memory(memory)
    print("  ✓ 创建初始记忆")
    
    # 模拟访问
    for i in range(3):
        retrieved = store.get_memory(memory.id)
        retrieved.update_access()  # 更新访问统计
        store.update_memory(retrieved)
    
    print("  ✓ 模拟3次访问")
    
    # 验证访问统计
    final_memory = store.get_memory(memory.id)
    assert final_memory.access_count == 3
    print(f"  ✓ 访问次数: {final_memory.access_count}")
    
    # 测试重要性更新（基于访问频率）
    old_importance = final_memory.importance
    
    # 重新计算重要性（会考虑访问频率）
    new_importance = scorer.calculate_importance(text, "test_user")
    final_memory.importance = new_importance
    store.update_memory(final_memory)
    
    print(f"  ✓ 重要性更新: {old_importance:.3f} → {new_importance:.3f}")
    
    # 测试记忆类型调整
    old_type = final_memory.memory_type
    new_type = classifier.classify_memory_type(new_importance, text)
    
    if new_type != old_type:
        final_memory.memory_type = new_type
        store.update_memory(final_memory)
        print(f"  ✓ 类型调整: {old_type.value} → {new_type.value}")
    else:
        print(f"  ✓ 类型保持: {old_type.value}")


def main():
    """运行所有集成测试"""
    print("\n" + "=" * 70)
    print(" " * 15 + "阶段1 + 阶段2 集成测试")
    print("=" * 70)
    print("\n测试目标: 验证记忆形成模块与存储层的完整联通性")
    
    try:
        test_config_integration()
        test_storage_with_classification()
        test_scorer_with_storage()
        test_complete_memory_formation_flow()
        test_multi_user_isolation()
        test_memory_update_and_access()
        
        print("\n" + "=" * 70)
        print("✓ 所有集成测试通过！")
        print("=" * 70)
        
        print("\n🎉 验证结果:")
        print("  ✓ 配置系统集成正常")
        print("  ✓ 存储层与分类器联通")
        print("  ✓ 评分器与数据库集成")
        print("  ✓ 完整记忆形成流程畅通")
        print("  ✓ 多用户数据隔离有效")
        print("  ✓ 记忆更新和统计正常")
        
        print("\n📊 联通性测试覆盖:")
        print("  • 阶段1（存储层）:")
        print("    - SQLiteStore 数据CRUD")
        print("    - UserProfile 画像管理")
        print("    - Memory 记忆存储")
        print("    - Config 配置加载")
        
        print("\n  • 阶段2（记忆形成）:")
        print("    - ImportanceScorer 重要性评分")
        print("    - MemoryClassifier 记忆分类")
        print("    - 标签生成")
        print("    - 隐私判断")
        
        print("\n  • 集成点:")
        print("    - 评分器 ← 读取 → 数据库（新颖性、频率计算）")
        print("    - 评分器 ← 读取 → 用户画像（相关性计算）")
        print("    - 分类器 → 创建 → Memory对象")
        print("    - Memory对象 → 保存 → 数据库")
        print("    - 数据库 → 检索 → Memory对象")
        
        print("\n✅ 阶段1和阶段2完全联通！")
        print("\n🎯 系统已具备完整的记忆形成能力:")
        print("  对话文本 → 分析评分 → 智能分类 → 持久化存储 → 灵活检索")
        
        print("\n📈 当前系统能力:")
        print("  • 支持5种记忆类型的自动分类")
        print("  • 支持6个记忆维度的智能识别")
        print("  • 支持6维度综合重要性评分")
        print("  • 支持多用户完全隔离")
        print("  • 支持记忆的动态更新")
        print("  • 支持访问统计和频率分析")
        
        print("\n🚀 准备进入阶段3 - 记忆检索！")
        print()
        
        return 0
    
    except AssertionError as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n✗ 运行错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

