"""
阶段1+2+3+4完整集成测试

测试完整的记忆生命周期：形成 → 存储 → 检索 → 更新
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType
from storage.sqlite_store import SQLiteStore
from modules.formation import MemoryFormer
from modules.retrieval import MemoryRetriever, KeywordSearcher
from modules.update import (
    UpdateManager,
    ConflictDetector,
    ConflictResolver,
    MemoryUpdater,
    AssociationManager
)


def test_complete_lifecycle():
    """测试完整的记忆生命周期"""
    print("=" * 70)
    print("测试1: 完整记忆生命周期 - 形成→存储→检索→更新")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        
        # 阶段2: 记忆形成
        print("\n📝 阶段2: 记忆形成")
        former = MemoryFormer()
        
        texts = [
            "我喜欢使用Python进行数据分析",
            "今天学习了机器学习算法",
            "明天要完成项目报告"
        ]
        
        memories = []
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            memories.append(memory)
            print(f"  ✓ 形成: {memory.content[:30]}... (重要性: {memory.importance:.2f})")
        
        # 阶段1: 存储
        print("\n💾 阶段1: 存储记忆")
        for memory in memories:
            store.create_memory(memory)
            print(f"  ✓ 存储: {memory.id}")
        
        stored_count = len(store.get_memories_by_user(user_id))
        print(f"\n  📊 数据库中共 {stored_count} 条记忆")
        assert stored_count == len(texts), "存储数量应该匹配"
        
        # 阶段3: 检索
        print("\n🔍 阶段3: 检索记忆")
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        # 关键词检索
        results = retriever.retrieve(
            query="Python",
            user_id=user_id,
            top_k=5,
            strategy="keyword"
        )
        print(f"  关键词'Python': 找到 {len(results)} 条")
        for r in results:
            print(f"    - {r.memory.content[:40]}... (score: {r.score:.2f})")
        assert len(results) > 0, "应该找到Python相关记忆"
        
        # 阶段4: 更新
        print("\n🔄 阶段4: 更新记忆")
        updater = MemoryUpdater(store)
        
        # 更新第一条记忆的内容
        first_memory = memories[0]
        updated = updater.update_content(
            first_memory.id,
            "我非常喜欢使用Python进行数据分析和机器学习",
            recompute_importance=True
        )
        print(f"  ✓ 更新内容: {updated.content[:50]}...")
        print(f"  ✓ 新重要性: {updated.importance:.2f}")
        
        # 添加标签
        updated = updater.update_tags(first_memory.id, ["数据科学"], mode="add")
        print(f"  ✓ 新标签: {updated.tags}")
        
        print("\n✅ 完整生命周期测试通过")


def test_conflict_detection_in_flow():
    """测试流程中的冲突检测"""
    print("\n" + "=" * 70)
    print("测试2: 流程中的冲突检测与解决")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        update_manager = UpdateManager(store)
        
        # 1. 形成并存储第一条记忆
        print("\n1️⃣  添加原始记忆")
        memory1 = former.form_memory_from_text("我喜欢Python编程", user_id)
        store.create_memory(memory1)
        print(f"  ✓ 存储: {memory1.content}")
        
        # 2. 添加矛盾记忆（自动检测和解决）
        print("\n2️⃣  添加矛盾记忆")
        memory2 = former.form_memory_from_text("我不喜欢Python编程", user_id)
        
        result = update_manager.add_new_memory_with_conflict_check(
            memory2,
            auto_resolve=True
        )
        
        print(f"  冲突数量: {result['conflicts_found']}")
        assert result['conflicts_found'] > 0, "应该检测到冲突"
        
        if result['resolutions']:
            for resolution in result['resolutions']:
                print(f"  解决方案: {resolution['action']}")
                print(f"  原因: {resolution.get('reason', 'N/A')}")
        
        # 3. 添加相似记忆（重复检测）
        print("\n3️⃣  添加相似记忆")
        memory3 = former.form_memory_from_text("我喜欢用Python写代码", user_id)
        
        result = update_manager.add_new_memory_with_conflict_check(
            memory3,
            auto_resolve=True
        )
        
        print(f"  冲突数量: {result['conflicts_found']}")
        print(f"  存储成功: {result['stored']}")
        
        print("\n✅ 冲突检测流程测试通过")


def test_retrieval_after_update():
    """测试更新后的检索效果"""
    print("\n" + "=" * 70)
    print("测试3: 更新后的检索验证")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        updater = MemoryUpdater(store)
        searcher = KeywordSearcher(store)
        
        # 1. 创建记忆
        print("\n1️⃣  创建原始记忆")
        memory = former.form_memory_from_text("学习Java编程", user_id)
        store.create_memory(memory)
        print(f"  ✓ 内容: {memory.content}")
        print(f"  ✓ 标签: {memory.tags}")
        
        # 2. 更新记忆
        print("\n2️⃣  更新记忆内容和标签")
        updated = updater.update_content(
            memory.id,
            "学习Python和Java编程",
            recompute_importance=False
        )
        updater.update_tags(memory.id, ["Python", "编程语言"], mode="add")
        
        updated = store.get_memory(memory.id)
        print(f"  ✓ 新内容: {updated.content}")
        print(f"  ✓ 新标签: {updated.tags}")
        
        # 3. 检索验证
        print("\n3️⃣  检索验证")
        
        # 搜索Python
        results = searcher.search("Python", user_id, top_k=5)
        print(f"  搜索'Python': {len(results)} 条")
        assert len(results) > 0, "应该能搜索到更新后的内容"
        
        # 标签检索
        tag_results = searcher.search_by_tags(["Python"], user_id)
        print(f"  标签'Python': {len(tag_results)} 条")
        assert len(tag_results) > 0, "应该能通过标签找到"
        
        for r in results:
            print(f"    - {r.memory.content}")
        
        print("\n✅ 更新后检索测试通过")


def test_association_management():
    """测试关联管理的完整流程"""
    print("\n" + "=" * 70)
    print("测试4: 关联管理完整流程")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        assoc_manager = AssociationManager(store)
        update_manager = UpdateManager(store)
        
        # 1. 创建相关记忆
        print("\n1️⃣  创建相关记忆")
        texts = [
            "Python是一种编程语言",
            "Python用于数据科学",
            "NumPy是Python的数值库",
            "Pandas用于数据处理"
        ]
        
        memories = []
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            store.create_memory(memory)
            memories.append(memory)
            print(f"  ✓ {text}")
        
        # 2. 自动创建关联
        print("\n2️⃣  自动创建关联")
        for memory in memories:
            count = assoc_manager.auto_create_associations(
                memory, user_id, max_associations=3
            )
            if count > 0:
                print(f"  为 '{memory.content[:20]}...' 创建了 {count} 个关联")
        
        # 3. 检查关联
        print("\n3️⃣  检查关联关系")
        for memory in memories[:2]:
            updated = store.get_memory(memory.id)
            if updated.related_memory_ids:
                print(f"  '{updated.content[:30]}...'")
                print(f"    关联: {len(updated.related_memory_ids)} 个")
        
        # 4. 维护关联
        print("\n4️⃣  维护关联")
        result = update_manager.maintain_associations(
            user_id,
            auto_create=True,
            clean_broken=True
        )
        print(f"  创建关联: {result['associations_created']}")
        print(f"  清理关联: {result['associations_cleaned']}")
        
        print("\n✅ 关联管理测试通过")


def test_batch_operations():
    """测试批量操作"""
    print("\n" + "=" * 70)
    print("测试5: 批量操作")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        update_manager = UpdateManager(store)
        
        # 1. 批量创建记忆
        print("\n1️⃣  批量创建记忆")
        texts = [
            "Python基础知识",
            "Python进阶内容",
            "学习了机器学习",
            "完成了数据分析项目",
            "掌握了深度学习"
        ]
        
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            store.create_memory(memory)
        
        print(f"  ✓ 创建了 {len(texts)} 条记忆")
        
        # 2. 批量更新重要性
        print("\n2️⃣  批量更新重要性")
        result = update_manager.batch_update_importance(user_id)
        print(f"  ✓ 更新了 {result['updated_count']} 条记忆")
        
        # 3. 查找矛盾
        print("\n3️⃣  查找并解决矛盾")
        
        # 添加一条矛盾记忆
        conflict_memory = former.form_memory_from_text("我不喜欢Python", user_id)
        store.create_memory(conflict_memory)
        
        result = update_manager.find_and_resolve_contradictions(
            user_id,
            auto_resolve=False  # 只查找不解决
        )
        print(f"  发现矛盾: {result['contradictions_found']} 个")
        
        print("\n✅ 批量操作测试通过")


def test_memory_evolution():
    """测试记忆演化过程"""
    print("\n" + "=" * 70)
    print("测试6: 记忆演化过程")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        updater = MemoryUpdater(store)
        
        # 1. 初始记忆
        print("\n1️⃣  初始记忆")
        memory = former.form_memory_from_text("我在学Python", user_id)
        store.create_memory(memory)
        print(f"  版本1: {memory.content}")
        print(f"  重要性: {memory.importance:.2f}")
        print(f"  标签: {memory.tags}")
        
        # 2. 第一次演化（内容更新）
        print("\n2️⃣  第一次演化 - 更新内容")
        updater.update_content(
            memory.id,
            "我学会了Python基础",
            recompute_importance=True
        )
        v2 = store.get_memory(memory.id)
        print(f"  版本2: {v2.content}")
        print(f"  重要性: {v2.importance:.2f}")
        
        # 3. 第二次演化（添加标签）
        print("\n3️⃣  第二次演化 - 添加标签")
        updater.update_tags(memory.id, ["编程", "学习"], mode="add")
        v3 = store.get_memory(memory.id)
        print(f"  版本3标签: {v3.tags}")
        
        # 4. 第三次演化（提升重要性）
        print("\n4️⃣  第三次演化 - 提升重要性")
        for _ in range(3):
            updater.increment_access_count(memory.id)
        
        v4 = store.get_memory(memory.id)
        print(f"  访问次数: {v4.access_count}")
        
        # 5. 检查历史
        print("\n5️⃣  查看演化历史")
        if 'content_history' in v4.metadata:
            history = v4.metadata['content_history']
            print(f"  内容变更历史: {len(history)} 次")
            for i, h in enumerate(history, 1):
                print(f"    {i}. {h.get('content', 'N/A')[:30]}...")
        
        print("\n✅ 记忆演化测试通过")


def test_end_to_end_scenario():
    """测试端到端场景"""
    print("\n" + "=" * 70)
    print("测试7: 端到端真实场景")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "alice"
        
        # 初始化所有模块
        former = MemoryFormer()
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        update_manager = UpdateManager(store)
        
        print("\n场景：用户学习编程的过程")
        print("-" * 70)
        
        # Day 1: 开始学Python
        print("\n📅 第1天：开始学习")
        memory1 = former.form_memory_from_text("开始学习Python编程", user_id)
        store.create_memory(memory1)
        print(f"  ✓ 记录: {memory1.content}")
        
        # Day 2: 学习基础
        print("\n📅 第2天：学习基础知识")
        memory2 = former.form_memory_from_text("学习了Python的变量和函数", user_id)
        result = update_manager.add_new_memory_with_conflict_check(memory2, auto_resolve=True)
        print(f"  ✓ 记录: {memory2.content}")
        print(f"  ✓ 自动创建关联: {result['associations_created']} 个")
        
        # Day 5: 深入学习
        print("\n📅 第5天：深入学习")
        memory3 = former.form_memory_from_text("深入学习Python面向对象编程", user_id)
        update_manager.add_new_memory_with_conflict_check(memory3, auto_resolve=True)
        print(f"  ✓ 记录: {memory3.content}")
        
        # Day 10: 项目实践
        print("\n📅 第10天：项目实践")
        memory4 = former.form_memory_from_text("用Python完成了第一个数据分析项目", user_id)
        update_manager.add_new_memory_with_conflict_check(memory4, auto_resolve=True)
        print(f"  ✓ 记录: {memory4.content}")
        
        # Day 15: 回顾总结
        print("\n📅 第15天：回顾总结")
        
        # 检索所有Python相关记忆
        results = retriever.retrieve(
            query="Python",
            user_id=user_id,
            top_k=10,
            strategy="hybrid"
        )
        
        print(f"\n  📚 Python学习记录 ({len(results)} 条):")
        for i, r in enumerate(results, 1):
            print(f"    {i}. {r.memory.content}")
            print(f"       重要性: {r.memory.importance:.2f} | 分数: {r.score:.2f}")
        
        # 检查记忆网络
        print("\n  🔗 记忆关联网络:")
        for memory in [memory1, memory2, memory3, memory4]:
            updated = store.get_memory(memory.id)
            if updated and updated.related_memory_ids:
                print(f"    '{updated.content[:25]}...' → {len(updated.related_memory_ids)} 个关联")
        
        # 统计
        total_memories = len(store.get_memories_by_user(user_id))
        print(f"\n  📊 总计: {total_memories} 条记忆")
        
        assert total_memories >= 4, "应该有至少4条记忆"
        assert len(results) > 0, "应该能检索到Python相关记忆"
        
        print("\n✅ 端到端场景测试通过")


def main():
    """运行所有集成测试"""
    print("\n" + "🎯" * 35)
    print("阶段1+2+3+4 完整集成测试")
    print("🎯" * 35)
    
    try:
        test_complete_lifecycle()
        test_conflict_detection_in_flow()
        test_retrieval_after_update()
        test_association_management()
        test_batch_operations()
        test_memory_evolution()
        test_end_to_end_scenario()
        
        print("\n" + "=" * 70)
        print("🎉 所有集成测试通过！")
        print("=" * 70)
        print("\n✅ 验证项目:")
        print("  ✓ 阶段1 (存储) - 正常工作")
        print("  ✓ 阶段2 (形成) - 正常工作")
        print("  ✓ 阶段3 (检索) - 正常工作")
        print("  ✓ 阶段4 (更新) - 正常工作")
        print("  ✓ 四个阶段完美联通")
        print("  ✓ 完整生命周期流畅运行")
        print("  ✓ 冲突检测与解决有效")
        print("  ✓ 关联管理智能化")
        print("  ✓ 端到端场景验证成功")
        print("\n准备进入阶段5！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

