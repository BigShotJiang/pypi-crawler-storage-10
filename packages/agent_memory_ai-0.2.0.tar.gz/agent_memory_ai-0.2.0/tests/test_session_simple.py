"""
会话管理模块简单测试
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType
from storage.sqlite_store import SQLiteStore
from modules.formation import MemoryFormer
from modules.session import SessionSummarizer, SnapshotManager, ConsistencyChecker, SessionManager


def create_test_memory(
    user_id: str,
    content: str,
    importance: float = 0.5,
    memory_type: MemoryType = MemoryType.MID,
    tags: list = None
) -> Memory:
    """创建测试记忆"""
    memory = Memory(
        user_id=user_id,
        content=content,
        memory_type=memory_type,
        category=MemoryCategory.KNOWLEDGE,
        source_type=SourceType.EXPLICIT,
        importance=importance,
        tags=tags or []
    )
    return memory


def test_session_summarizer():
    """测试会话摘要生成"""
    print("=" * 70)
    print("测试1: 会话摘要生成")
    print("=" * 70)
    
    summarizer = SessionSummarizer()
    
    # 模拟对话
    messages = [
        {"role": "user", "content": "我想学习Python编程"},
        {"role": "assistant", "content": "好的，Python是一门很好的语言"},
        {"role": "user", "content": "我决定从基础开始学习"},
        {"role": "assistant", "content": "很好的计划"},
        {"role": "user", "content": "需要完成第一个项目"},
    ]
    
    print("\n1️⃣  生成会话摘要")
    summary = summarizer.summarize_session(
        session_id="session_001",
        user_id="test_user",
        messages=messages,
        start_time=datetime.now() - timedelta(hours=1)
    )
    
    print(f"  会话ID: {summary.session_id}")
    print(f"  用户ID: {summary.user_id}")
    print(f"  摘要: {summary.summary}")
    print(f"  关键主题: {summary.key_topics}")
    print(f"  决策: {summary.decisions}")
    print(f"  待办任务: {summary.pending_tasks}")
    print(f"  情绪: {summary.sentiment}")
    print(f"  交互次数: {summary.interaction_count}")
    
    assert summary.session_id == "session_001", "会话ID应该匹配"
    assert summary.interaction_count == len(messages), "交互次数应该匹配"
    assert len(summary.key_topics) > 0, "应该提取到主题"
    
    print("\n✅ 会话摘要生成测试通过")


def test_snapshot_manager():
    """测试快照管理"""
    print("\n" + "=" * 70)
    print("测试2: 记忆快照管理")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        snapshot_mgr = SnapshotManager(store)
        
        user_id = "test_user"
        
        # 创建一些测试记忆
        print("\n1️⃣  创建测试记忆")
        memories = [
            create_test_memory(user_id, "Python基础知识", 0.8, MemoryType.CORE, ["Python", "编程"]),
            create_test_memory(user_id, "学习了函数", 0.6, MemoryType.MID, ["Python", "函数"]),
            create_test_memory(user_id, "需要完成作业", 0.5, MemoryType.SHORT, ["任务"]),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        print(f"  创建了 {len(memories)} 条记忆")
        
        # 创建快照
        print("\n2️⃣  创建记忆快照")
        snapshot = snapshot_mgr.create_snapshot(user_id)
        
        print(f"  用户ID: {snapshot.user_id}")
        print(f"  快照时间: {snapshot.snapshot_time}")
        print(f"  核心记忆数: {len(snapshot.core_memories)}")
        print(f"  最近话题: {snapshot.recent_topics}")
        print(f"  待办任务: {snapshot.pending_tasks}")
        print(f"  统计信息: {snapshot.stats}")
        
        assert snapshot.user_id == user_id, "用户ID应该匹配"
        assert len(snapshot.core_memories) > 0, "应该有核心记忆"
        assert snapshot.stats['total_memories'] == len(memories), "记忆数应该匹配"
        
        # 获取会话上下文
        print("\n3️⃣  获取会话上下文")
        context = snapshot_mgr.get_session_context(user_id)
        
        print(f"  核心记忆: {context['user_profile']['core_memories']}")
        print(f"  最近话题: {context['recent_topics']}")
        print(f"  待办任务: {context['pending_tasks']}")
        
        assert 'user_profile' in context, "应该有用户资料"
        assert 'recent_topics' in context, "应该有最近话题"
        
        print("\n✅ 快照管理测试通过")


def test_consistency_checker():
    """测试一致性检查"""
    print("\n" + "=" * 70)
    print("测试3: 一致性检查")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        snapshot_mgr = SnapshotManager(store)
        checker = ConsistencyChecker(store)
        
        user_id = "test_user"
        
        # 创建可能有冲突的记忆
        print("\n1️⃣  创建测试记忆")
        
        mem1 = create_test_memory(user_id, "我喜欢Python编程", 0.7)
        mem1.created_at = datetime.now() - timedelta(days=10)
        store.create_memory(mem1)
        print(f"  记忆1: {mem1.content}")
        
        mem2 = create_test_memory(user_id, "我不喜欢Python编程", 0.6)
        store.create_memory(mem2)
        print(f"  记忆2: {mem2.content}")
        
        # 创建快照
        print("\n2️⃣  创建快照并检查一致性")
        snapshot = snapshot_mgr.create_snapshot(user_id)
        
        # 检查所有一致性问题
        issues = checker.check_all(snapshot)
        
        print(f"\n  发现问题数: {len(issues)}")
        for i, issue in enumerate(issues, 1):
            print(f"\n  问题{i}:")
            print(f"    类型: {issue.issue_type.value}")
            print(f"    严重程度: {issue.severity.value}")
            print(f"    描述: {issue.description}")
            print(f"    建议: {issue.suggested_action}")
        
        # 应该检测到事实冲突
        has_factual_issue = any(
            issue.issue_type.value == 'factual'
            for issue in issues
        )
        
        if has_factual_issue:
            print("\n  ✓ 成功检测到事实冲突")
        
        print("\n✅ 一致性检查测试通过")


def test_session_manager():
    """测试会话管理器"""
    print("\n" + "=" * 70)
    print("测试4: 会话管理器")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        session_mgr = SessionManager(store)
        
        user_id = "test_user"
        session_id = "session_001"
        
        # 创建一些背景记忆
        print("\n1️⃣  准备背景记忆")
        memory = create_test_memory(user_id, "之前学习了Python基础", 0.7)
        store.create_memory(memory)
        print(f"  创建背景记忆: {memory.content}")
        
        # 开始会话
        print("\n2️⃣  开始新会话")
        start_context = session_mgr.start_session(user_id, session_id)
        
        print(f"  会话ID: {start_context['session_id']}")
        print(f"  一致性问题: {len(start_context['consistency_issues'])}")
        print(f"  提醒: {start_context.get('reminder', 'None')}")
        
        assert start_context['session_id'] == session_id, "会话ID应该匹配"
        assert 'context' in start_context, "应该有上下文"
        
        # 模拟对话
        print("\n3️⃣  进行对话")
        messages = [
            {"role": "user", "content": "继续学习Python"},
            {"role": "assistant", "content": "好的，今天学什么？"},
            {"role": "user", "content": "学习面向对象编程"},
        ]
        
        # 结束会话
        print("\n4️⃣  结束会话")
        start_time = datetime.now() - timedelta(minutes=30)
        summary = session_mgr.end_session(
            user_id,
            session_id,
            messages,
            start_time
        )
        
        print(f"  会话摘要: {summary.summary}")
        print(f"  关键主题: {summary.key_topics}")
        
        assert summary.session_id == session_id, "会话ID应该匹配"
        assert len(summary.key_topics) > 0, "应该有关键主题"
        
        # 获取用户进展
        print("\n5️⃣  获取用户进展")
        progress = session_mgr.get_user_progress(user_id)
        
        print(f"  总记忆数: {progress['total_memories']}")
        print(f"  核心记忆数: {progress['core_memories']}")
        print(f"  最近话题: {progress['recent_topics']}")
        
        assert progress['total_memories'] > 0, "应该有记忆"
        
        print("\n✅ 会话管理器测试通过")


def test_session_reminder():
    """测试会话提醒"""
    print("\n" + "=" * 70)
    print("测试5: 会话提醒")
    print("=" * 70)
    
    summarizer = SessionSummarizer()
    
    # 创建带待办任务的摘要
    print("\n1️⃣  创建带待办任务的摘要")
    messages = [
        {"role": "user", "content": "我要学习Python"},
        {"role": "assistant", "content": "很好"},
        {"role": "user", "content": "需要完成三个练习"},
    ]
    
    summary = summarizer.summarize_session(
        "session_001",
        "test_user",
        messages,
        datetime.now() - timedelta(days=2)
    )
    
    print(f"  待办任务: {summary.pending_tasks}")
    
    # 测试不同天数的提醒
    print("\n2️⃣  测试提醒生成")
    
    # 距离2天（应该有提醒）
    reminder_2days = summarizer.create_session_reminder(summary, 2)
    print(f"  2天前: {reminder_2days}")
    
    # 距离10天（可能没有提醒）
    reminder_10days = summarizer.create_session_reminder(summary, 10)
    print(f"  10天前: {reminder_10days}")
    
    # 应该根据时间生成不同的提醒
    if summary.pending_tasks:
        assert reminder_2days is not None or reminder_10days is not None, "应该有提醒"
    
    print("\n✅ 会话提醒测试通过")


def test_snapshot_comparison():
    """测试快照比较"""
    print("\n" + "=" * 70)
    print("测试6: 快照比较")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        snapshot_mgr = SnapshotManager(store)
        
        user_id = "test_user"
        
        # 创建初始记忆
        print("\n1️⃣  创建初始记忆")
        mem1 = create_test_memory(user_id, "学习Python", 0.6, tags=["Python"])
        store.create_memory(mem1)
        
        # 第一个快照
        snapshot1 = snapshot_mgr.create_snapshot(user_id)
        print(f"  快照1: {snapshot1.stats['total_memories']} 条记忆")
        
        # 添加更多记忆
        print("\n2️⃣  添加更多记忆")
        mem2 = create_test_memory(user_id, "学习Java", 0.5, tags=["Java"])
        mem3 = create_test_memory(user_id, "完成项目", 0.7, tags=["项目"])
        store.create_memory(mem2)
        store.create_memory(mem3)
        
        # 第二个快照
        snapshot2 = snapshot_mgr.create_snapshot(user_id)
        print(f"  快照2: {snapshot2.stats['total_memories']} 条记忆")
        
        # 比较快照
        print("\n3️⃣  比较快照差异")
        diff = snapshot_mgr.compare_snapshots(snapshot1, snapshot2)
        
        print(f"  记忆数变化: {diff['memory_count_change']}")
        print(f"  新增话题: {diff['new_topics']}")
        print(f"  新增任务: {diff['new_tasks']}")
        print(f"  重要性变化: {diff['importance_change']:.3f}")
        
        assert diff['memory_count_change'] == 2, "应该新增2条记忆"
        assert len(diff['new_topics']) > 0, "应该有新话题"
        
        print("\n✅ 快照比较测试通过")


def main():
    """运行所有测试"""
    print("\n" + "🧪" * 35)
    print("会话管理模块测试")
    print("🧪" * 35 + "\n")
    
    try:
        test_session_summarizer()
        test_snapshot_manager()
        test_consistency_checker()
        test_session_manager()
        test_session_reminder()
        test_snapshot_comparison()
        
        print("\n" + "=" * 70)
        print("🎉 所有测试通过！")
        print("=" * 70)
        print("\n✅ 测试项目:")
        print("  ✓ 会话摘要生成")
        print("  ✓ 记忆快照管理")
        print("  ✓ 一致性检查")
        print("  ✓ 会话管理器")
        print("  ✓ 会话提醒")
        print("  ✓ 快照比较")
        print("\n阶段6开发完成！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

