"""
阶段1-7完整集成测试

验证AgentMemory主类与所有底层模块的集成
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent_memory import AgentMemory, MemoryType, MemoryCategory


def test_agent_with_storage():
    """测试AgentMemory与阶段1（存储）的集成"""
    print("=" * 70)
    print("测试1: AgentMemory与阶段1（存储）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("alice", db_path=db_path, use_vector_store=False)
        
        # 创建记忆
        print("\n1️⃣  通过AgentMemory创建记忆")
        mem1 = agent.memorize("Python编程基础")
        if mem1:
            print(f"  ✓ 创建记忆: {mem1.content}")
            
            # 验证存储
            print("\n2️⃣  验证底层存储")
            stored = agent.sqlite_store.get_memory(mem1.id)
            assert stored is not None, "记忆应该被存储"
            assert stored.content == mem1.content, "内容应该匹配"
            print(f"  ✓ 底层存储正常")
            
            # 查询所有记忆
            print("\n3️⃣  查询所有记忆")
            all_memories = agent.get_all_memories()
            assert len(all_memories) > 0, "应该有记忆"
            print(f"  ✓ 查询到 {len(all_memories)} 条记忆")
        
        print("\n✅ AgentMemory与存储集成测试通过")


def test_agent_with_formation():
    """测试AgentMemory与阶段2（形成）的集成"""
    print("\n" + "=" * 70)
    print("测试2: AgentMemory与阶段2（形成）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("bob", db_path=db_path, use_vector_store=False)
        
        # 使用memorize方法（调用形成器）
        print("\n1️⃣  使用memorize方法")
        mem1 = agent.memorize("我喜欢Python编程")
        if mem1:
            print(f"  ✓ 形成记忆: {mem1.content}")
            print(f"  ✓ 重要性: {mem1.importance:.3f}")
            print(f"  ✓ 类型: {mem1.memory_type.value}")
            assert mem1.importance > 0, "应该有重要性分数"
        
        # 使用create_memory方法（不经过形成器）
        print("\n2️⃣  使用create_memory方法")
        mem2 = agent.create_memory(
            "Python是一门编程语言",
            memory_type=MemoryType.CORE,
            importance=0.9,
            tags=["Python", "知识"]
        )
        print(f"  ✓ 创建记忆: {mem2.content}")
        print(f"  ✓ 指定重要性: {mem2.importance}")
        assert mem2.importance == 0.9, "重要性应该匹配"
        
        # 验证形成器功能
        print("\n3️⃣  验证形成器集成")
        assert agent.former is not None, "应该有形成器"
        print(f"  ✓ 形成器已集成")
        
        print("\n✅ AgentMemory与形成集成测试通过")


def test_agent_with_retrieval():
    """测试AgentMemory与阶段3（检索）的集成"""
    print("\n" + "=" * 70)
    print("测试3: AgentMemory与阶段3（检索）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("charlie", db_path=db_path, use_vector_store=False)
        
        # 创建多条记忆
        print("\n1️⃣  创建测试记忆")
        agent.memorize("Python编程基础")
        agent.memorize("Java开发经验")
        agent.memorize("Python Web开发")
        print(f"  ✓ 创建了3条记忆")
        
        # 使用recall方法（混合检索）
        print("\n2️⃣  使用recall方法（混合检索）")
        results = agent.recall("Python", top_k=5, strategy="hybrid")
        print(f"  ✓ 检索到 {len(results)} 条记忆")
        for r in results:
            print(f"    - {r.content}")
        assert len(results) >= 2, "应该检索到至少2条Python相关"
        
        # 使用search方法（带过滤）
        print("\n3️⃣  使用search方法（带过滤）")
        filtered = agent.search("Python", filters={"min_importance": 0.5})
        print(f"  ✓ 过滤后 {len(filtered)} 条记忆")
        
        # 验证检索器集成
        print("\n4️⃣  验证检索器集成")
        assert agent.retriever is not None, "应该有检索器"
        print(f"  ✓ 检索器已集成")
        
        print("\n✅ AgentMemory与检索集成测试通过")


def test_agent_with_update():
    """测试AgentMemory与阶段4（更新）的集成"""
    print("\n" + "=" * 70)
    print("测试4: AgentMemory与阶段4（更新）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("david", db_path=db_path, use_vector_store=False)
        
        # 创建记忆
        print("\n1️⃣  创建记忆")
        mem = agent.memorize("学习Python基础")
        if mem:
            print(f"  ✓ 创建: {mem.content}")
            
            # 更新记忆
            print("\n2️⃣  更新记忆")
            result = agent.update_memory(
                mem.id,
                tags=["Python", "基础", "已学习"]
            )
            assert result['success'], "更新应该成功"
            print(f"  ✓ 更新成功")
            
            # 验证更新
            print("\n3️⃣  验证更新结果")
            updated = agent.sqlite_store.get_memory(mem.id)
            assert "已学习" in updated.tags, "应该包含新标签"
            print(f"  ✓ 标签已更新: {updated.tags}")
            
            # 验证更新管理器集成
            print("\n4️⃣  验证更新管理器集成")
            assert agent.update_manager is not None, "应该有更新管理器"
            print(f"  ✓ 更新管理器已集成")
        
        print("\n✅ AgentMemory与更新集成测试通过")


def test_agent_with_decay():
    """测试AgentMemory与阶段5（衰减遗忘）的集成"""
    print("\n" + "=" * 70)
    print("测试5: AgentMemory与阶段5（衰减遗忘）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("eve", db_path=db_path, use_vector_store=False)
        
        # 创建记忆
        print("\n1️⃣  创建记忆")
        mem = agent.memorize("旧的Python知识")
        if mem:
            # 模拟时间流逝
            mem.created_at = datetime.now() - timedelta(days=30)
            mem.updated_at = mem.created_at
            agent.sqlite_store.update_memory(mem)
            print(f"  ✓ 创建30天前的记忆")
            
            # 执行维护
            print("\n2️⃣  执行维护")
            result = agent.maintain()
            print(f"  ✓ 生命周期处理: {result['lifecycle']['processed']} 条")
            print(f"  ✓ 自动遗忘: {result['forget']['deleted']} 条")
            print(f"  ✓ 一致性问题: {result['consistency_issues']} 个")
            
            # 验证管理器集成
            print("\n3️⃣  验证管理器集成")
            assert agent.decay_manager is not None, "应该有衰减管理器"
            assert agent.forget_manager is not None, "应该有遗忘管理器"
            print(f"  ✓ 衰减管理器已集成")
            print(f"  ✓ 遗忘管理器已集成")
        
        print("\n✅ AgentMemory与衰减遗忘集成测试通过")


def test_agent_with_session():
    """测试AgentMemory与阶段6（会话管理）的集成"""
    print("\n" + "=" * 70)
    print("测试6: AgentMemory与阶段6（会话管理）集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("frank", db_path=db_path, use_vector_store=False)
        
        # 开始会话
        print("\n1️⃣  开始会话")
        context = agent.start_session("test_session")
        assert agent.current_session_id == "test_session", "会话ID应该设置"
        print(f"  ✓ 会话ID: {agent.current_session_id}")
        print(f"  ✓ 一致性问题: {len(context['consistency_issues'])}")
        
        # 对话
        print("\n2️⃣  进行对话")
        result = agent.chat("你好", "你好！有什么可以帮你的？")
        assert len(agent.current_session_messages) == 2, "应该有2条消息"
        print(f"  ✓ 消息数: {len(agent.current_session_messages)}")
        
        # 记忆对话内容
        print("\n3️⃣  记忆对话内容")
        agent.memorize("学习Python")
        print(f"  ✓ 记忆已保存")
        
        # 结束会话
        print("\n4️⃣  结束会话")
        summary = agent.end_session()
        assert agent.current_session_id is None, "会话应该结束"
        print(f"  ✓ 会话摘要: {summary['summary'][:50]}...")
        print(f"  ✓ 会话已结束")
        
        # 验证会话管理器集成
        print("\n5️⃣  验证会话管理器集成")
        assert agent.session_manager is not None, "应该有会话管理器"
        print(f"  ✓ 会话管理器已集成")
        
        print("\n✅ AgentMemory与会话管理集成测试通过")


def test_complete_workflow():
    """测试完整工作流"""
    print("\n" + "=" * 70)
    print("测试7: 完整工作流（所有阶段集成）")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        print("\n场景：一个用户的完整学习旅程")
        print("-" * 70)
        
        # 第1天
        print("\n📅 第1天：初次学习")
        agent = AgentMemory("learner", db_path=db_path, use_vector_store=False)
        
        with agent as session:
            # 记忆（阶段2）
            session.memorize("开始学习Python编程")
            print(f"  ✓ 记忆已形成")
            
            # 对话（阶段6）
            session.chat("Python难学吗？", "Python很适合初学者")
            print(f"  ✓ 对话已记录")
        
        print(f"  ✓ 会话已结束")
        
        # 第3天
        print("\n📅 第3天：继续学习")
        
        with agent as session:
            # 检索历史（阶段3）
            history = session.recall("Python", top_k=5)
            print(f"  ✓ 检索到 {len(history)} 条历史")
            
            # 新记忆
            session.memorize("学习Python函数和类")
            print(f"  ✓ 新记忆已形成")
        
        # 第7天
        print("\n📅 第7天：复习和维护")
        
        with agent as session:
            # 搜索学习内容
            learned = session.search("学习", filters={"min_importance": 0.5})
            print(f"  ✓ 找到 {len(learned)} 条学习记录")
            
            # 更新记忆（阶段4）
            if learned:
                session.update_memory(
                    learned[0].id,
                    tags=["Python", "已掌握"]
                )
                print(f"  ✓ 记忆已更新")
            
            # 执行维护（阶段5）
            result = session.maintain()
            print(f"  ✓ 维护完成: 处理 {result['lifecycle']['processed']} 条")
        
        # 生成报告
        print("\n📊 生成学习报告")
        report = agent.generate_report(days=7)
        print(f"  总记忆数: {report['total_memories']}")
        print(f"  记忆增长: {report['memory_growth']} 条")
        print(f"  最近话题: {report['recent_topics'][:3]}")
        
        # 统计
        print("\n📈 学习统计")
        stats = agent.get_statistics()
        print(f"  总记忆: {stats['progress']['total_memories']}")
        print(f"  平均重要性: {stats['progress']['avg_importance']:.3f}")
        
        print("\n✅ 完整工作流测试通过")


def test_context_manager_integration():
    """测试上下文管理器与所有模块的集成"""
    print("\n" + "=" * 70)
    print("测试8: 上下文管理器集成")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        print("\n1️⃣  使用with语句管理会话")
        with agent:
            # 会话自动开始
            assert agent.current_session_id is not None, "会话应该自动开始"
            print(f"  ✓ 会话已自动开始: {agent.current_session_id}")
            
            # 形成记忆
            agent.memorize("测试记忆1")
            agent.memorize("测试记忆2")
            print(f"  ✓ 记忆已形成")
            
            # 检索
            results = agent.recall("测试")
            print(f"  ✓ 检索到 {len(results)} 条")
            
            # 对话
            agent.chat("测试消息", "测试回复")
            print(f"  ✓ 对话已记录")
        
        # 会话自动结束
        assert agent.current_session_id is None, "会话应该自动结束"
        print(f"\n  ✓ 会话已自动结束")
        
        print("\n✅ 上下文管理器集成测试通过")


def test_all_features_together():
    """测试所有功能的协同工作"""
    print("\n" + "=" * 70)
    print("测试9: 所有功能协同工作")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("power_user", db_path=db_path, use_vector_store=False)
        
        print("\n场景：复杂的实际应用")
        print("-" * 70)
        
        # 1. 创建各种类型的记忆
        print("\n1️⃣  创建多种类型记忆")
        agent.create_memory(
            "Python是一门编程语言",
            memory_type=MemoryType.CORE,
            importance=0.9,
            tags=["Python", "知识"]
        )
        agent.memorize("今天学习了Python基础")
        agent.memorize("我喜欢Python的简洁语法")
        print(f"  ✓ 创建了3种类型的记忆")
        
        # 2. 开始会话并对话
        print("\n2️⃣  开始会话并对话")
        with agent:
            agent.chat("继续学习Python", "很好！")
            agent.chat("有什么建议吗？", "建议多实践")
        print(f"  ✓ 会话完成")
        
        # 3. 检索和搜索
        print("\n3️⃣  检索和搜索")
        all_python = agent.recall("Python", top_k=10)
        high_importance = agent.search(
            "Python",
            filters={"min_importance": 0.7}
        )
        print(f"  ✓ 所有Python记忆: {len(all_python)} 条")
        print(f"  ✓ 高重要性: {len(high_importance)} 条")
        
        # 4. 更新记忆
        print("\n4️⃣  更新记忆")
        if all_python:
            agent.update_memory(
                all_python[0].id,
                tags=["Python", "重要", "已复习"]
            )
        print(f"  ✓ 记忆已更新")
        
        # 5. 执行维护
        print("\n5️⃣  执行维护")
        maintain_result = agent.maintain()
        print(f"  ✓ 生命周期: {maintain_result['lifecycle']['processed']}")
        print(f"  ✓ 遗忘: {maintain_result['forget']['deleted']}")
        
        # 6. 生成报告和统计
        print("\n6️⃣  生成报告")
        report = agent.generate_report(days=7)
        stats = agent.get_statistics()
        print(f"  ✓ 总记忆: {report['total_memories']}")
        print(f"  ✓ 平均重要性: {stats['progress']['avg_importance']:.3f}")
        
        # 7. 获取上下文
        print("\n7️⃣  获取上下文")
        context = agent.get_context()
        print(f"  ✓ 最近话题: {len(context['recent_topics'])}")
        
        print("\n✅ 所有功能协同工作测试通过")


def main():
    """运行所有集成测试"""
    print("\n" + "🎯" * 35)
    print("阶段1-7 完整集成测试")
    print("🎯" * 35 + "\n")
    
    try:
        test_agent_with_storage()
        test_agent_with_formation()
        test_agent_with_retrieval()
        test_agent_with_update()
        test_agent_with_decay()
        test_agent_with_session()
        test_complete_workflow()
        test_context_manager_integration()
        test_all_features_together()
        
        print("\n" + "=" * 70)
        print("🎉 所有集成测试通过！")
        print("=" * 70)
        print("\n✅ 验证项目:")
        print("  ✓ AgentMemory与阶段1（存储）集成")
        print("  ✓ AgentMemory与阶段2（形成）集成")
        print("  ✓ AgentMemory与阶段3（检索）集成")
        print("  ✓ AgentMemory与阶段4（更新）集成")
        print("  ✓ AgentMemory与阶段5（衰减遗忘）集成")
        print("  ✓ AgentMemory与阶段6（会话管理）集成")
        print("  ✓ 完整工作流验证")
        print("  ✓ 上下文管理器集成")
        print("  ✓ 所有功能协同工作")
        print("\n🚀 阶段7与前6个阶段完美集成！")
        print("准备进入阶段8！\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

