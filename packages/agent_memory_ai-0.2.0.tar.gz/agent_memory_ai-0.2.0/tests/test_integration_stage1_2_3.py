"""
阶段1+2+3集成测试

测试完整的记忆生命周期：存储 → 形成 → 检索
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from core.config import get_config
from storage.sqlite_store import SQLiteStore
from modules.formation import MemoryExtractor, ImportanceScorer, MemoryClassifier, MemoryFormer
from modules.retrieval import (
    MemoryRetriever,
    KeywordSearcher,
    TemporalSearcher,
    ContextSearcher,
    AssociativeSearcher,
    Reranker
)


def test_complete_flow():
    """测试完整流程：记忆形成 + 存储 + 检索"""
    print("=" * 60)
    print("测试1: 完整流程 - 形成→存储→检索")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        
        # 阶段2：记忆形成
        print("\n📝 阶段2: 记忆形成")
        extractor = MemoryExtractor()
        scorer = ImportanceScorer()
        classifier = MemoryClassifier()
        former = MemoryFormer()
        
        # 创建一些文本内容
        texts = [
            "我最喜欢使用Python进行数据分析和机器学习",
            "今天学习了深度学习的基础知识，特别是神经网络",
            "明天需要完成项目报告，记得使用matplotlib画图",
            "Python的异步编程非常强大，async/await很好用",
        ]
        
        memories = []
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            memories.append(memory)
            print(f"  ✓ 形成记忆: {memory.content[:30]}...")
            print(f"    重要性: {memory.importance:.2f} | 类型: {memory.memory_type.value}")
        
        # 阶段1：存储
        print(f"\n💾 阶段1: 存储到数据库")
        for memory in memories:
            store.create_memory(memory)
            print(f"  ✓ 存储: {memory.content[:30]}...")
        
        # 验证存储
        stored_count = len(store.get_memories_by_user(user_id))
        print(f"\n  📊 已存储 {stored_count} 条记忆")
        assert stored_count == len(texts), "存储的记忆数量不匹配"
        
        # 阶段3：检索
        print(f"\n🔍 阶段3: 检索测试")
        
        # 1. 关键词检索
        print("\n1️⃣  关键词检索: 'Python'")
        keyword_searcher = KeywordSearcher(store)
        keyword_results = keyword_searcher.search("Python", user_id, top_k=5)
        print(f"  找到 {len(keyword_results)} 条结果:")
        for r in keyword_results:
            print(f"    - {r.memory.content[:40]}... (score: {r.score:.2f})")
        assert len(keyword_results) >= 2, "应该找到包含Python的记忆"
        
        # 2. 按重要性检索
        print("\n2️⃣  重要性检索: >= 0.5")
        important_results = keyword_searcher.search_by_importance(0.5, user_id)
        print(f"  找到 {len(important_results)} 条重要记忆:")
        for r in important_results:
            print(f"    - 重要性 {r.memory.importance:.2f}: {r.memory.content[:40]}...")
        
        # 3. 时间检索
        print("\n3️⃣  时间检索: 最近记忆")
        temporal_searcher = TemporalSearcher(store)
        recent_results = temporal_searcher.search_recent(user_id, days=7, top_k=5)
        print(f"  找到 {len(recent_results)} 条最近记忆")
        assert len(recent_results) == stored_count, "应该找到所有最近的记忆"
        
        # 4. 按维度检索
        print("\n4️⃣  维度检索: 知识类记忆")
        context_searcher = ContextSearcher(store)
        knowledge_results = context_searcher.search_by_category(
            user_id, MemoryCategory.KNOWLEDGE, top_k=5
        )
        print(f"  找到 {len(knowledge_results)} 条知识类记忆:")
        for r in knowledge_results:
            print(f"    - {r.memory.content[:40]}...")
        
        print("\n✅ 完整流程测试通过")


def test_retrieval_with_formed_memories():
    """测试使用形成的记忆进行各种检索"""
    print("\n" + "=" * 60)
    print("测试2: 高级检索功能")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        
        # 创建不同主题的记忆
        texts = [
            "我在用Python开发机器学习项目",
            "学习了TensorFlow和PyTorch框架",
            "数据预处理是机器学习的关键步骤",
            "深度学习需要大量的GPU计算资源",
            "今天完成了神经网络的训练",
        ]
        
        print("\n📝 创建测试记忆...")
        memories = []
        for i, text in enumerate(texts):
            memory = former.form_memory_from_text(text, user_id)
            # 设置不同的创建时间
            memory.created_at = datetime.now() - timedelta(days=i)
            memories.append(memory)
            store.create_memory(memory)
            print(f"  ✓ {i+1}. {text}")
        
        # 初始化检索器
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        # 1. 混合检索
        print("\n1️⃣  混合检索: '机器学习'")
        hybrid_results = retriever.retrieve(
            query="机器学习",
            user_id=user_id,
            top_k=3,
            strategy="hybrid"
        )
        print(f"  找到 {len(hybrid_results)} 条结果:")
        for i, r in enumerate(hybrid_results, 1):
            print(f"    {i}. {r.memory.content}")
            print(f"       score: {r.score:.3f} | importance: {r.memory.importance:.2f}")
        assert len(hybrid_results) > 0, "混合检索应该有结果"
        
        # 2. 标签检索
        print("\n2️⃣  标签检索")
        all_tags = set()
        for mem in memories:
            all_tags.update(mem.tags)
        print(f"  所有标签: {sorted(all_tags)}")
        
        if all_tags:
            sample_tag = list(all_tags)[0]
            keyword_searcher = KeywordSearcher(store)
            tag_results = keyword_searcher.search_by_tags([sample_tag], user_id)
            print(f"  标签 '{sample_tag}' 的记忆: {len(tag_results)} 条")
        
        # 3. 按时间段检索
        print("\n3️⃣  按时间段检索")
        temporal_searcher = TemporalSearcher(store)
        
        # 今天
        today_results = temporal_searcher.search_by_period(user_id, "today", top_k=5)
        print(f"  今天: {len(today_results)} 条")
        
        # 本周
        week_results = temporal_searcher.search_by_period(user_id, "this_week", top_k=5)
        print(f"  本周: {len(week_results)} 条")
        
        # 4. 上下文检索
        print("\n4️⃣  上下文检索")
        context = {
            "current_topic": "机器学习",
            "domain": "AI"
        }
        context_results = retriever.retrieve(
            query="神经网络",
            user_id=user_id,
            top_k=3,
            strategy="hybrid",
            context=context
        )
        print(f"  上下文: {context}")
        print(f"  找到 {len(context_results)} 条相关记忆")
        for r in context_results:
            print(f"    - {r.memory.content}")
        
        print("\n✅ 高级检索测试通过")


def test_memory_network():
    """测试记忆关联网络"""
    print("\n" + "=" * 60)
    print("测试3: 记忆关联网络")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        
        # 创建有主题关联的记忆
        texts = [
            "Python是一种高级编程语言",
            "Python有丰富的数据科学库",
            "NumPy是Python的数值计算库",
            "Pandas用于数据处理和分析",
            "Matplotlib是Python的可视化库",
        ]
        
        print("\n📝 创建关联记忆...")
        memories = []
        for text in texts:
            memory = former.form_memory_from_text(text, user_id)
            memories.append(memory)
            store.create_memory(memory)
            print(f"  ✓ {text}")
        
        # 手动添加一些关联关系
        print("\n🔗 添加关联关系...")
        memories[0].related_memory_ids = [memories[1].id, memories[2].id]
        store.update_memory(memories[0])
        memories[1].related_memory_ids = [memories[0].id, memories[3].id]
        store.update_memory(memories[1])
        print("  ✓ 建立了记忆间的关联")
        
        # 测试关联检索
        print("\n🔍 关联检索测试")
        assoc_searcher = AssociativeSearcher(store)
        
        # 1. 查找关联记忆
        print(f"\n1️⃣  查找 '{memories[0].content[:20]}...' 的关联:")
        related_results = assoc_searcher.search_related(
            memories[0].id, user_id, max_depth=2, top_k=5
        )
        for r in related_results:
            print(f"    → {r.memory.content}")
            print(f"      score: {r.score:.2f} | source: {r.source}")
        assert len(related_results) > 0, "应该找到关联记忆"
        
        # 2. 构建关联图
        print(f"\n2️⃣  构建记忆关联图")
        graph = assoc_searcher.build_memory_graph(user_id, min_connections=1)
        print(f"  图中节点数: {len(graph)}")
        for mem_id, related_ids in list(graph.items())[:3]:
            mem = store.get_memory(mem_id)
            print(f"    - {mem.content[:30]}... → {len(related_ids)} 个关联")
        
        # 3. 中心记忆
        print(f"\n3️⃣  查找中心记忆")
        central_results = assoc_searcher.find_central_memories(user_id, top_k=3)
        if central_results:
            print(f"  最中心的记忆:")
            for r in central_results:
                print(f"    ⭐ {r.memory.content}")
                print(f"       中心度: {r.score:.2f}")
        
        print("\n✅ 记忆网络测试通过")


def test_reranking():
    """测试重排序功能"""
    print("\n" + "=" * 60)
    print("测试4: 重排序功能")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        now = datetime.now()
        
        # 创建不同特征的记忆
        test_cases = [
            ("核心技能：Python编程", 180, 0.95, 50),  # 老但重要且常访问
            ("最近学习了Vue.js框架", 3, 0.6, 2),      # 新但不太重要
            ("掌握了机器学习算法", 60, 0.85, 10),     # 中等
        ]
        
        print("\n📝 创建不同特征的记忆...")
        memories = []
        for content, age_days, importance, access_count in test_cases:
            memory = former.form_memory_from_text(content, user_id)
            memory.importance = importance
            memory.created_at = now - timedelta(days=age_days)
            memory.access_count = access_count
            memory.last_access = now - timedelta(days=age_days // 10)
            
            memories.append(memory)
            store.create_memory(memory)
            print(f"  ✓ {content}")
            print(f"    年龄:{age_days}天 | 重要性:{importance} | 访问:{access_count}次")
        
        # 测试不同的重排序策略
        print("\n🔄 重排序测试")
        keyword_searcher = KeywordSearcher(store)
        reranker = Reranker()
        
        # 获取所有记忆
        all_results = keyword_searcher.search("", user_id, top_k=10)
        if not all_results:
            # 如果空查询没结果，用重要性检索
            all_results = keyword_searcher.search_by_importance(0, user_id, top_k=10)
        
        print(f"\n  原始结果 ({len(all_results)} 条):")
        for i, r in enumerate(all_results, 1):
            print(f"    {i}. {r.memory.content[:30]}...")
        
        # 1. 按重要性重排序
        print(f"\n1️⃣  按重要性排序:")
        importance_ranked = reranker.rerank(all_results, strategy="重要性")
        for i, r in enumerate(importance_ranked, 1):
            print(f"    {i}. {r.memory.content[:30]}... (importance: {r.memory.importance})")
        
        # 验证排序
        importances = [r.memory.importance for r in importance_ranked]
        assert importances == sorted(importances, reverse=True), "重要性排序不正确"
        
        # 2. 按新鲜度重排序
        print(f"\n2️⃣  按新鲜度排序:")
        freshness_ranked = reranker.rerank(all_results, strategy="新鲜度")
        for i, r in enumerate(freshness_ranked, 1):
            age = (now - r.memory.created_at).days
            print(f"    {i}. {r.memory.content[:30]}... ({age}天前)")
        
        # 3. 综合重排序
        print(f"\n3️⃣  综合排序:")
        comprehensive_ranked = reranker.rerank(all_results, strategy="综合")
        for i, r in enumerate(comprehensive_ranked, 1):
            print(f"    {i}. {r.memory.content[:30]}... (score: {r.score:.3f})")
        
        print("\n✅ 重排序测试通过")


def test_filters_and_constraints():
    """测试过滤和约束条件"""
    print("\n" + "=" * 60)
    print("测试5: 过滤和约束")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        now = datetime.now()
        
        # 创建多样化的记忆
        texts = [
            "Python编程技能",
            "今天的会议记录",
            "重要的项目里程碑",
        ]
        
        print("\n📝 创建测试记忆...")
        memories = []
        for i, text in enumerate(texts):
            memory = former.form_memory_from_text(text, user_id)
            memory.created_at = now - timedelta(days=i * 10)
            memories.append(memory)
            store.create_memory(memory)
            print(f"  ✓ {text} (importance: {memory.importance:.2f})")
        
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        # 1. 重要性过滤
        print("\n1️⃣  重要性过滤: >= 0.6")
        important_results = retriever.retrieve(
            query="",
            user_id=user_id,
            top_k=10,
            strategy="keyword",
            filters={"min_importance": 0.6}
        )
        print(f"  找到 {len(important_results)} 条记忆")
        for r in important_results:
            assert r.memory.importance >= 0.6, "过滤条件未生效"
            print(f"    - {r.memory.content} (importance: {r.memory.importance:.2f})")
        
        # 2. 时间范围过滤
        print("\n2️⃣  时间范围过滤: 最近15天")
        start_time = now - timedelta(days=15)
        end_time = now
        time_filtered = retriever.retrieve(
            query="",
            user_id=user_id,
            top_k=10,
            strategy="keyword",
            filters={"time_range": (start_time, end_time)}
        )
        print(f"  找到 {len(time_filtered)} 条记忆")
        for r in time_filtered:
            assert start_time <= r.memory.created_at <= end_time, "时间过滤未生效"
            age = (now - r.memory.created_at).days
            print(f"    - {r.memory.content} ({age}天前)")
        
        # 3. 类型过滤
        print("\n3️⃣  类型过滤")
        # 统计各类型数量
        type_counts = {}
        for mem in store.get_memories_by_user(user_id):
            mem_type = mem.memory_type.value
            type_counts[mem_type] = type_counts.get(mem_type, 0) + 1
        
        print(f"  类型分布: {type_counts}")
        
        print("\n✅ 过滤和约束测试通过")


def test_performance():
    """测试性能和可扩展性"""
    print("\n" + "=" * 60)
    print("测试6: 性能测试")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        
        user_id = "test_user"
        former = MemoryFormer()
        
        # 创建较多记忆
        num_memories = 50
        print(f"\n📝 创建 {num_memories} 条记忆...")
        
        import time
        start_time = time.time()
        
        for i in range(num_memories):
            text = f"这是第{i+1}条测试记忆，内容关于Python、机器学习和数据科学"
            memory = former.form_memory_from_text(text, user_id)
            store.create_memory(memory)
            
            if (i + 1) % 10 == 0:
                print(f"  ✓ 已创建 {i+1} 条")
        
        creation_time = time.time() - start_time
        print(f"\n  创建耗时: {creation_time:.2f}秒 (平均 {creation_time/num_memories*1000:.1f}ms/条)")
        
        # 测试检索性能
        print(f"\n🔍 检索性能测试")
        retriever = MemoryRetriever(sqlite_store=store, vector_store=None)
        
        # 1. 关键词检索
        start_time = time.time()
        keyword_results = retriever.retrieve(
            query="Python机器学习",
            user_id=user_id,
            top_k=10,
            strategy="keyword"
        )
        keyword_time = time.time() - start_time
        print(f"  关键词检索: {len(keyword_results)} 条结果, 耗时 {keyword_time*1000:.1f}ms")
        
        # 2. 混合检索
        start_time = time.time()
        hybrid_results = retriever.retrieve(
            query="Python",
            user_id=user_id,
            top_k=10,
            strategy="hybrid"
        )
        hybrid_time = time.time() - start_time
        print(f"  混合检索: {len(hybrid_results)} 条结果, 耗时 {hybrid_time*1000:.1f}ms")
        
        # 3. 时间检索
        temporal_searcher = TemporalSearcher(store)
        start_time = time.time()
        recent_results = temporal_searcher.search_recent(user_id, days=7, top_k=10)
        temporal_time = time.time() - start_time
        print(f"  时间检索: {len(recent_results)} 条结果, 耗时 {temporal_time*1000:.1f}ms")
        
        print("\n✅ 性能测试通过")


def main():
    """运行所有集成测试"""
    print("\n" + "🎯" * 30)
    print("阶段1+2+3 完整集成测试")
    print("🎯" * 30)
    
    try:
        test_complete_flow()
        test_retrieval_with_formed_memories()
        test_memory_network()
        test_reranking()
        test_filters_and_constraints()
        test_performance()
        
        print("\n" + "=" * 60)
        print("🎉 所有集成测试通过！")
        print("=" * 60)
        print("\n✅ 验证项目:")
        print("  ✓ 阶段1 (存储) 正常工作")
        print("  ✓ 阶段2 (形成) 正常工作")
        print("  ✓ 阶段3 (检索) 正常工作")
        print("  ✓ 三个阶段完美联通")
        print("  ✓ 性能表现良好")
        print("\n准备进入阶段4！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

