"""
检索模块简单测试

不依赖LLM和向量数据库的基础测试
"""
import os
import sys
import tempfile
from datetime import datetime, timedelta

# 添加项目根目录到路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.memory import Memory, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from storage.sqlite_store import SQLiteStore
from modules.retrieval.keyword_search import KeywordSearcher
from modules.retrieval.temporal_search import TemporalSearcher
from modules.retrieval.context_search import ContextSearcher
from modules.retrieval.associative_search import AssociativeSearcher
from modules.retrieval.reranker import Reranker


def test_keyword_search():
    """测试关键词检索"""
    print("=" * 50)
    print("测试1: 关键词检索")
    print("=" * 50)
    
    # 创建临时数据库
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        searcher = KeywordSearcher(store)
        
        user_id = "test_user"
        
        # 创建测试记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="我喜欢使用Python进行数据分析",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.8,
                tags=["Python", "数据分析"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="今天学习了机器学习的基础知识",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.EXPERIENCE,
                importance=0.7,
                tags=["机器学习", "学习"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="Python是一种非常流行的编程语言",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.6,
                tags=["Python", "编程"],
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 1. 关键词检索
        print("\n1.1 搜索 'Python':")
        results = searcher.search("Python", user_id, top_k=5)
        assert len(results) > 0, "应该找到包含Python的记忆"
        for r in results:
            print(f"  - {r.memory.content[:30]}... (score: {r.score:.3f})")
        
        # 2. 标签检索
        print("\n1.2 按标签搜索 ['Python']:")
        tag_results = searcher.search_by_tags(["Python"], user_id)
        assert len(tag_results) >= 2, "应该找到至少2条带Python标签的记忆"
        for r in tag_results:
            print(f"  - {r.memory.content[:30]}... (tags: {r.memory.tags})")
        
        # 3. 精确匹配
        print("\n1.3 精确匹配 '数据分析':")
        exact_results = searcher.search_exact("数据分析", user_id)
        assert len(exact_results) > 0, "应该找到精确匹配"
        for r in exact_results:
            print(f"  - {r.memory.content[:30]}...")
        
        # 4. 重要性筛选
        print("\n1.4 重要性 >= 0.7:")
        important_results = searcher.search_by_importance(0.7, user_id)
        assert len(important_results) >= 2, "应该找到重要记忆"
        for r in important_results:
            print(f"  - {r.memory.content[:30]}... (importance: {r.memory.importance})")
        
        print("\n✅ 关键词检索测试通过")


def test_temporal_search():
    """测试时间检索"""
    print("\n" + "=" * 50)
    print("测试2: 时间检索")
    print("=" * 50)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        searcher = TemporalSearcher(store)
        
        user_id = "test_user"
        now = datetime.now()
        
        # 创建不同时间的记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="今天的记忆",
                memory_type=MemoryType.SHORT,
                category=MemoryCategory.CONTEXT,
                importance=0.8,
                created_at=now,
                last_access=now,
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="3天前的记忆",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.7,
                created_at=now - timedelta(days=3),
                last_access=now - timedelta(days=2),
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="一个月前的记忆",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.9,
                created_at=now - timedelta(days=30),
                last_access=now - timedelta(days=30),
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 1. 最近7天
        print("\n2.1 最近7天的记忆:")
        recent_results = searcher.search_recent(user_id, days=7)
        assert len(recent_results) >= 2, "应该找到最近的记忆"
        for r in recent_results:
            age = (now - r.memory.created_at).days
            print(f"  - {r.memory.content} ({age}天前)")
        
        # 2. 时间范围
        print("\n2.2 指定时间范围:")
        start = now - timedelta(days=5)
        end = now
        range_results = searcher.search_by_time_range(user_id, start, end)
        assert len(range_results) > 0, "应该找到时间范围内的记忆"
        for r in range_results:
            print(f"  - {r.memory.content}")
        
        # 3. 按周期
        print("\n2.3 本周的记忆:")
        period_results = searcher.search_by_period(user_id, "this_week")
        for r in period_results:
            print(f"  - {r.memory.content}")
        
        print("\n✅ 时间检索测试通过")


def test_context_search():
    """测试情境检索"""
    print("\n" + "=" * 50)
    print("测试3: 情境检索")
    print("=" * 50)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        searcher = ContextSearcher(store)
        
        user_id = "test_user"
        
        # 创建不同维度和类型的记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="关于Python的知识",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.8,
                tags=["Python"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="学习Python的经验",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.7,
                tags=["Python", "学习"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="今天讨论了数据库设计",
                memory_type=MemoryType.SHORT,
                category=MemoryCategory.CONTEXT,
                importance=0.6,
                source_type=SourceType.EXPLICIT,
                source_session_id="session1"
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 1. 按维度检索
        print("\n3.1 检索知识维度:")
        category_results = searcher.search_by_category(user_id, MemoryCategory.KNOWLEDGE)
        assert len(category_results) > 0, "应该找到知识维度的记忆"
        for r in category_results:
            print(f"  - {r.memory.content} (category: {r.memory.category.value})")
        
        # 2. 按类型检索
        print("\n3.2 检索长期记忆:")
        type_results = searcher.search_by_type(user_id, MemoryType.LONG)
        assert len(type_results) > 0, "应该找到长期记忆"
        for r in type_results:
            print(f"  - {r.memory.content} (type: {r.memory.memory_type.value})")
        
        # 3. 按会话检索
        print("\n3.3 检索同一会话:")
        session_results = searcher.search_by_session(user_id, "session1")
        for r in session_results:
            print(f"  - {r.memory.content}")
        
        # 4. 上下文检索
        print("\n3.4 基于上下文检索:")
        context = {
            "current_topic": "Python",
            "domain": "编程"
        }
        context_results = searcher.search_by_context(user_id, context)
        for r in context_results:
            print(f"  - {r.memory.content} (score: {r.score:.3f})")
        
        print("\n✅ 情境检索测试通过")


def test_associative_search():
    """测试关联检索"""
    print("\n" + "=" * 50)
    print("测试4: 关联检索")
    print("=" * 50)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        store = SQLiteStore(db_path)
        searcher = AssociativeSearcher(store)
        
        user_id = "test_user"
        
        # 创建有关联的记忆
        memories = [
            Memory(
                id="mem1",
                user_id=user_id,
                content="Python基础知识",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.8,
                tags=["Python", "基础"],
                related_memory_ids=["mem2", "mem3"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem2",
                user_id=user_id,
                content="Python高级特性",
                memory_type=MemoryType.LONG,
                category=MemoryCategory.KNOWLEDGE,
                importance=0.7,
                tags=["Python", "高级"],
                related_memory_ids=["mem1"],
                source_type=SourceType.EXPLICIT
            ),
            Memory(
                id="mem3",
                user_id=user_id,
                content="Python应用实践",
                memory_type=MemoryType.MID,
                category=MemoryCategory.EXPERIENCE,
                importance=0.6,
                tags=["Python", "实践"],
                related_memory_ids=["mem1"],
                source_type=SourceType.EXPLICIT
            ),
        ]
        
        for memory in memories:
            store.create_memory(memory)
        
        # 1. 关联检索
        print("\n4.1 查找mem1的关联记忆:")
        related_results = searcher.search_related("mem1", user_id, max_depth=2)
        assert len(related_results) > 0, "应该找到关联记忆"
        for r in related_results:
            print(f"  - {r.memory.content} (score: {r.score:.3f}, source: {r.source})")
        
        # 2. 构建关联图
        print("\n4.2 构建记忆关联图:")
        graph = searcher.build_memory_graph(user_id, min_connections=1)
        for mem_id, related_ids in graph.items():
            memory = store.get_memory(mem_id)
            print(f"  - {memory.content[:20]}... -> {len(related_ids)} 个关联")
        
        # 3. 中心记忆
        print("\n4.3 查找中心记忆:")
        central_results = searcher.find_central_memories(user_id, top_k=3)
        for r in central_results:
            print(f"  - {r.memory.content} (score: {r.score:.3f})")
        
        print("\n✅ 关联检索测试通过")


def test_reranker():
    """测试重排序器"""
    print("\n" + "=" * 50)
    print("测试5: 重排序器")
    print("=" * 50)
    
    from modules.retrieval.vector_search import SearchResult
    
    # 创建模拟检索结果
    now = datetime.now()
    
    memories = [
        Memory(
            id="mem1",
            user_id="test",
            content="高重要性但较旧",
            memory_type=MemoryType.LONG,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.9,
            created_at=now - timedelta(days=60),
            access_count=2,
            source_type=SourceType.EXPLICIT
        ),
        Memory(
            id="mem2",
            user_id="test",
            content="中等重要性且新鲜",
            memory_type=MemoryType.MID,
            category=MemoryCategory.EXPERIENCE,
            importance=0.6,
            created_at=now - timedelta(days=1),
            access_count=5,
            source_type=SourceType.EXPLICIT
        ),
        Memory(
            id="mem3",
            user_id="test",
            content="低重要性很新",
            memory_type=MemoryType.SHORT,
            category=MemoryCategory.CONTEXT,
            importance=0.4,
            created_at=now,
            access_count=1,
            source_type=SourceType.EXPLICIT
        ),
    ]
    
    results = [
        SearchResult(memories[0], 0.8, 0.2, "test"),
        SearchResult(memories[1], 0.7, 0.3, "test"),
        SearchResult(memories[2], 0.6, 0.4, "test"),
    ]
    
    reranker = Reranker()
    
    # 1. 按重要性重排序
    print("\n5.1 按重要性重排序:")
    importance_ranked = reranker.rerank(results, strategy="重要性")
    for r in importance_ranked:
        print(f"  - {r.memory.content} (importance: {r.memory.importance})")
    
    # 2. 按新鲜度重排序
    print("\n5.2 按新鲜度重排序:")
    freshness_ranked = reranker.rerank(results, strategy="新鲜度")
    for r in freshness_ranked:
        age = (now - r.memory.created_at).days
        print(f"  - {r.memory.content} ({age}天前)")
    
    # 3. 综合重排序
    print("\n5.3 综合重排序:")
    comprehensive_ranked = reranker.rerank(results, strategy="综合")
    for r in comprehensive_ranked:
        print(f"  - {r.memory.content} (score: {r.score:.3f})")
    
    # 4. 多路召回合并
    print("\n5.4 多路召回合并:")
    results1 = results[:2]
    results2 = results[1:]
    merged = reranker.merge_results([results1, results2], weights=[1.0, 0.5])
    for r in merged:
        print(f"  - {r.memory.content} (merged score: {r.score:.3f})")
    
    print("\n✅ 重排序器测试通过")


def main():
    """运行所有测试"""
    print("开始检索模块简单测试...")
    print()
    
    try:
        test_keyword_search()
        test_temporal_search()
        test_context_search()
        test_associative_search()
        test_reranker()
        
        print("\n" + "=" * 50)
        print("🎉 所有检索模块测试通过！")
        print("=" * 50)
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())

