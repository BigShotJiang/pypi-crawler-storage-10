"""
记忆形成模块简化测试

不依赖LLM API的测试版本
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.memory import MemoryType, MemoryCategory
from storage.sqlite_store import SQLiteStore
from modules.formation.scorer import ImportanceScorer
from modules.formation.classifier import MemoryClassifier


def test_scorer_basic():
    """测试重要性评分器基础功能"""
    print("\n[测试1/3] 重要性评分器（基础功能）...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    
    # 创建测试用户
    from core.memory import UserProfile
    profile = UserProfile(
        user_id="test_user",
        domain="软件开发",
        preferences={"language": "Python"}
    )
    store.create_or_update_profile(profile)
    
    # 测试新颖性计算（第一条记忆）
    content1 = "Python是一门很好的编程语言"
    novelty = scorer.calculate_novelty(content1, "test_user")
    assert novelty == 1.0, "第一条记忆新颖性应该是1.0"
    print(f"  ✓ 新颖性计算: {novelty}")
    
    # 测试相关性计算
    relevance = scorer.calculate_relevance(content1, "test_user")
    assert 0 <= relevance <= 1, "相关性应该在0-1之间"
    print(f"  ✓ 相关性计算: {relevance:.3f}")
    
    # 测试置信度计算
    confidence = scorer.calculate_confidence(content1, "explicit")
    assert 0 <= confidence <= 1, "置信度应该在0-1之间"
    assert confidence > 0.7, "明确表述的置信度应该较高"
    print(f"  ✓ 置信度计算: {confidence:.3f}")
    
    # 测试明确性评分
    clarity = scorer.calculate_clarity_score(content1, None)
    assert 0 <= clarity <= 1
    print(f"  ✓ 明确性评分: {clarity:.3f}")


def test_classifier_comprehensive():
    """测试记忆分类器全面功能"""
    print("\n[测试2/3] 记忆分类器（全面功能）...")
    
    classifier = MemoryClassifier()
    
    # 测试1：记忆类型分类（全部5种类型）
    test_cases = [
        (0.95, MemoryType.CORE, "核心记忆"),
        (0.75, MemoryType.LONG, "长期记忆"),
        (0.55, MemoryType.MID, "中期记忆"),
        (0.35, MemoryType.SHORT, "短期记忆"),
        (0.15, MemoryType.WORK, "工作记忆")
    ]
    
    print("  记忆类型分类:")
    for importance, expected_type, name in test_cases:
        result_type = classifier.classify_memory_type(importance, "测试内容")
        assert result_type == expected_type, f"{name}分类错误"
        print(f"    {importance:.2f} → {result_type.value} ✓")
    
    # 测试2：记忆维度分类（全部6个维度）
    dimension_tests = [
        ("Python是一门编程语言", MemoryCategory.KNOWLEDGE, "知识"),
        ("上次项目中遇到了问题", MemoryCategory.EXPERIENCE, "经验"),
        ("我喜欢用FastAPI", MemoryCategory.PREFERENCE, "偏好"),
        ("今天讨论了架构设计", MemoryCategory.CONTEXT, "情境"),
        ("我认为代码质量很重要", MemoryCategory.REFLECTION, "反思"),
        ("记住这个很重要", MemoryCategory.META, "元记忆")
    ]
    
    print("\n  记忆维度分类:")
    for text, expected_cat, name in dimension_tests:
        result_cat = classifier.classify_category(text)
        assert result_cat == expected_cat, f"{name}分类错误: 期望{expected_cat.value}, 得到{result_cat.value}"
        print(f"    {name}: {text[:20]}... → {result_cat.value} ✓")
    
    # 测试3：标签生成
    tags = classifier.generate_tags("Python机器学习数据分析项目")
    assert len(tags) > 0, "应该生成标签"
    print(f"\n  ✓ 标签生成: {tags}")
    
    # 测试4：隐私级别判断
    privacy_tests = [
        ("我的密码是123456", "private"),
        ("这是我的收入情况", "sensitive"),
        ("今天学习了Python", "normal")
    ]
    
    print("\n  隐私级别判断:")
    for text, expected in privacy_tests:
        result = classifier.determine_privacy_level(text)
        assert result == expected, f"隐私级别判断错误"
        print(f"    {expected}: {text[:20]}... ✓")
    
    # 测试5：核心记忆晋升判断
    should_promote = classifier.should_promote_to_core(
        content="用户的核心价值观是代码质量",
        importance=0.9,
        access_count=10,
        age_days=60
    )
    assert should_promote, "符合条件应该晋升为核心记忆"
    print(f"\n  ✓ 核心记忆晋升判断正确")


def test_integration_without_llm():
    """不依赖LLM的集成测试"""
    print("\n[测试3/3] 集成测试（不依赖LLM）...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    classifier = MemoryClassifier()
    
    # 创建用户画像
    from core.memory import UserProfile, Memory
    profile = UserProfile(
        user_id="test_user",
        domain="数据科学",
        preferences={"language": "Python", "framework": "PyTorch"}
    )
    store.create_or_update_profile(profile)
    print("  ✓ 创建用户画像")
    
    # 手动创建记忆（模拟完整流程）
    test_contents = [
        "我主要使用Python做数据分析",
        "我最常用的库是Pandas",
        "上次项目中数据清洗很重要",
        "我认为数据质量是核心",
        "今天天气不错"
    ]
    
    memories_created = []
    for content in test_contents:
        # 1. 计算重要性
        importance = scorer.calculate_importance(content, "test_user")
        
        # 2. 分类类型
        memory_type = classifier.classify_memory_type(importance, content)
        
        # 3. 分类维度
        category = classifier.classify_category(content)
        
        # 4. 生成标签
        tags = classifier.generate_tags(content)
        
        # 5. 计算置信度
        confidence = scorer.calculate_confidence(content, "explicit")
        
        # 6. 创建记忆
        memory = Memory(
            user_id="test_user",
            content=content,
            memory_type=memory_type,
            category=category,
            importance=importance,
            confidence=confidence,
            tags=tags
        )
        
        store.create_memory(memory)
        memories_created.append(memory)
        
        print(f"    创建: [{memory_type.value:5s}] [{category.value:11s}] "
              f"重要性:{importance:.2f} - {content[:25]}...")
    
    print(f"\n  ✓ 成功创建{len(memories_created)}条记忆")
    
    # 验证记忆存储
    all_memories = store.get_memories_by_user("test_user")
    assert len(all_memories) == len(test_contents), "记忆数量应该匹配"
    print(f"  ✓ 数据库中有{len(all_memories)}条记忆")
    
    # 验证重要性排序
    sorted_memories = sorted(all_memories, key=lambda m: m.importance, reverse=True)
    most_important = sorted_memories[0]
    least_important = sorted_memories[-1]
    
    print(f"\n  最重要: {most_important.content[:30]}... (重要性: {most_important.importance:.3f})")
    print(f"  最不重要: {least_important.content[:30]}... (重要性: {least_important.importance:.3f})")
    
    # 统计分布
    type_dist = {}
    cat_dist = {}
    for mem in all_memories:
        type_dist[mem.memory_type.value] = type_dist.get(mem.memory_type.value, 0) + 1
        cat_dist[mem.category.value] = cat_dist.get(mem.category.value, 0) + 1
    
    print(f"\n  ✓ 类型分布: {type_dist}")
    print(f"  ✓ 维度分布: {cat_dist}")


def main():
    """运行所有测试"""
    print("\n" + "=" * 70)
    print(" " * 15 + "记忆形成模块测试（简化版）")
    print("=" * 70)
    
    try:
        test_scorer_basic()
        test_classifier_comprehensive()
        test_integration_without_llm()
        
        print("\n" + "=" * 70)
        print("✓ 所有测试通过！")
        print("=" * 70)
        
        print("\n阶段2完成情况:")
        print("  ✓ 重要性评分器 - 多维度评分（新颖性、相关性、情绪等）")
        print("  ✓ 记忆分类器 - 5种类型 × 6个维度自动分类")
        print("  ✓ 标签生成 - 自动提取关键词和主题标签")
        print("  ✓ 隐私判断 - 3级隐私保护（normal/sensitive/private）")
        print("  ✓ 记忆晋升 - 智能判断是否晋升为核心记忆")
        print("  ✓ 完整流程 - 从文本到结构化记忆")
        
        print("\n核心功能:")
        print("  • 6个维度评分系统")
        print("  • 30种类型 × 维度组合")
        print("  • 智能标签生成")
        print("  • 隐私级别自动判断")
        print("  • 记忆重要性动态调整")
        
        print("\n注意:")
        print("  - 完整功能需要配置LLM API（用于实体、事实、观点提取）")
        print("  - 当前测试版本使用关键词匹配作为降级策略")
        print("  - 配置config.json中的llm.api_key后可使用完整功能")
        
        print("\n下一步:")
        print("  1. 阶段3：实现记忆检索模块")
        print("  2. 向量检索 + 关键词检索 + 时间检索")
        print("  3. 多路召回 + 重排序算法")
        print()
        
        return 0
    
    except AssertionError as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n✗ 运行错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

