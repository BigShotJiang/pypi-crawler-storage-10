"""
简单测试 - 不依赖外部库

测试核心功能，不需要安装chromadb等依赖
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime
from core.memory import Memory, UserProfile, Session, MemoryType, MemoryCategory
from core.config import get_config
from storage.sqlite_store import SQLiteStore


def test_memory_model():
    """测试Memory数据模型"""
    print("\n[测试1/5] Memory数据模型...")
    
    memory = Memory(
        user_id="test_user",
        content="这是一条测试记忆",
        memory_type=MemoryType.SHORT,
        category=MemoryCategory.KNOWLEDGE
    )
    
    assert memory.id is not None
    assert memory.user_id == "test_user"
    assert memory.content == "这是一条测试记忆"
    assert memory.importance == 0.5
    
    # 测试转换
    data = memory.to_dict()
    assert isinstance(data, dict)
    
    # 测试从字典创建
    memory2 = Memory.from_dict(data)
    assert memory2.id == memory.id
    assert memory2.content == memory.content
    
    print("  ✓ Memory创建成功")
    print("  ✓ Memory序列化成功")
    print("  ✓ Memory反序列化成功")


def test_config():
    """测试配置管理"""
    print("\n[测试2/5] 配置管理...")
    
    config = get_config()
    assert config is not None
    
    # 测试获取配置
    model = config.get("llm.model")
    assert model is not None
    
    # 测试默认值
    non_exist = config.get("non.exist.key", "default")
    assert non_exist == "default"
    
    # 测试单例
    config2 = get_config()
    assert config is config2
    
    print("  ✓ 配置加载成功")
    print(f"  ✓ LLM模型: {config.llm_model}")
    print(f"  ✓ 向量模型: {config.embedding_model}")


def test_sqlite_store():
    """测试SQLite存储"""
    print("\n[测试3/5] SQLite存储...")
    
    # 使用内存数据库
    store = SQLiteStore(db_path=":memory:")
    
    # 测试创建记忆
    memory = Memory(
        user_id="test_user",
        content="测试记忆内容",
        importance=0.8
    )
    
    created = store.create_memory(memory)
    assert created.id == memory.id
    print("  ✓ 创建记忆成功")
    
    # 测试获取记忆
    retrieved = store.get_memory(memory.id)
    assert retrieved is not None
    assert retrieved.content == "测试记忆内容"
    print("  ✓ 获取记忆成功")
    
    # 测试更新记忆
    memory.content = "新内容"
    memory.importance = 0.9
    store.update_memory(memory)
    
    retrieved = store.get_memory(memory.id)
    assert retrieved.content == "新内容"
    assert retrieved.importance == 0.9
    print("  ✓ 更新记忆成功")
    
    # 测试获取用户记忆列表
    for i in range(3):
        mem = Memory(
            user_id="test_user",
            content=f"记忆{i}",
            importance=0.5 + i * 0.1
        )
        store.create_memory(mem)
    
    memories = store.get_memories_by_user("test_user")
    assert len(memories) >= 3
    print(f"  ✓ 获取记忆列表成功 (共{len(memories)}条)")


def test_user_profile():
    """测试用户画像"""
    print("\n[测试4/5] 用户画像...")
    
    store = SQLiteStore(db_path=":memory:")
    
    profile = UserProfile(
        user_id="test_user",
        domain="软件开发",
        role="开发者",
        preferences={"language": "Python"}
    )
    
    # 创建画像
    store.create_or_update_profile(profile)
    print("  ✓ 创建画像成功")
    
    # 获取画像
    retrieved = store.get_profile("test_user")
    assert retrieved is not None
    assert retrieved.domain == "软件开发"
    assert retrieved.preferences["language"] == "Python"
    print("  ✓ 获取画像成功")
    
    # 更新画像
    profile.confidence = 0.8
    store.create_or_update_profile(profile)
    
    retrieved = store.get_profile("test_user")
    assert retrieved.confidence == 0.8
    print("  ✓ 更新画像成功")


def test_session():
    """测试会话"""
    print("\n[测试5/5] 会话管理...")
    
    store = SQLiteStore(db_path=":memory:")
    
    session = Session(
        user_id="test_user",
        summary="测试会话"
    )
    session.add_message("user", "你好")
    session.add_message("assistant", "你好！")
    
    # 创建会话
    store.create_session(session)
    print("  ✓ 创建会话成功")
    
    # 获取会话
    retrieved = store.get_session(session.session_id)
    assert retrieved is not None
    assert len(retrieved.messages) == 2
    assert retrieved.summary == "测试会话"
    print("  ✓ 获取会话成功")
    
    # 获取最近会话
    recent = store.get_recent_sessions("test_user")
    assert len(recent) > 0
    print(f"  ✓ 获取最近会话成功 (共{len(recent)}条)")


def main():
    """运行所有测试"""
    print("\n" + "=" * 60)
    print(" " * 18 + "基础功能测试")
    print("=" * 60)
    
    try:
        test_memory_model()
        test_config()
        test_sqlite_store()
        test_user_profile()
        test_session()
        
        print("\n" + "=" * 60)
        print("✓ 所有测试通过！")
        print("=" * 60)
        print("\n阶段1完成情况:")
        print("  ✓ 项目结构创建完成")
        print("  ✓ 核心数据模型实现完成")
        print("  ✓ 配置管理实现完成")
        print("  ✓ SQLite存储实现完成")
        print("  ✓ 基础测试通过")
        print("\n下一步:")
        print("  1. 安装依赖: pip install -r requirements.txt")
        print("  2. 实现记忆形成模块 (阶段2)")
        print("  3. 实现记忆检索模块 (阶段3)")
        print()
        
    except AssertionError as e:
        print(f"\n✗ 测试失败: {e}")
        return 1
    except Exception as e:
        print(f"\n✗ 运行错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())

