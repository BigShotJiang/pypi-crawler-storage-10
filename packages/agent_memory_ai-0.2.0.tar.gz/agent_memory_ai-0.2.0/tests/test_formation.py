"""
记忆形成模块测试

测试信息提取、重要性评分、记忆分类等功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.memory import MemoryType, MemoryCategory
from storage.sqlite_store import SQLiteStore
from modules.formation.extractor import MemoryExtractor
from modules.formation.scorer import ImportanceScorer
from modules.formation.classifier import MemoryClassifier
from modules.formation.memory_former import MemoryFormer


def test_extractor():
    """测试信息提取器"""
    print("\n[测试1/5] 信息提取器...")
    
    extractor = MemoryExtractor()
    
    # 测试1：提取实体
    text1 = "我喜欢使用Python进行数据分析"
    result1 = extractor.extract_all(text1)
    
    print(f"  文本: {text1}")
    print(f"  ✓ 关键词: {result1.get('keywords', [])}")
    
    # 测试2：判断是否值得记忆
    worthy1 = extractor.is_memory_worthy("你好")
    worthy2 = extractor.is_memory_worthy("我昨天完成了一个重要的机器学习项目")
    
    assert worthy1 == False, "简单问候不应该被记忆"
    assert worthy2 == True, "有意义的内容应该被记忆"
    print("  ✓ 过滤简单内容成功")
    
    # 测试3：提取偏好
    text3 = "我更喜欢用FastAPI而不是Flask来开发API"
    prefs = extractor.extract_preferences(text3)
    print(f"  ✓ 提取偏好: {prefs}")


def test_scorer():
    """测试重要性评分器"""
    print("\n[测试2/5] 重要性评分器...")
    
    store = SQLiteStore(db_path=":memory:")
    scorer = ImportanceScorer(store)
    
    # 创建测试用户
    from core.memory import UserProfile
    profile = UserProfile(
        user_id="test_user",
        domain="软件开发",
        preferences={"language": "Python"}
    )
    store.create_or_update_profile(profile)
    
    # 测试1：计算重要性
    content1 = "Python是一门很好的编程语言"
    importance1 = scorer.calculate_importance(content1, "test_user")
    print(f"  文本1重要性: {importance1:.3f}")
    assert 0 <= importance1 <= 1, "重要性应该在0-1之间"
    
    # 测试2：不同内容的重要性对比
    content2 = "今天天气不错"
    importance2 = scorer.calculate_importance(content2, "test_user")
    print(f"  文本2重要性: {importance2:.3f}")
    
    # 技术相关的内容应该比天气更重要
    assert importance1 > importance2, "技术内容应该更重要"
    print("  ✓ 重要性评分合理")
    
    # 测试3：计算置信度
    confidence = scorer.calculate_confidence(content1, "explicit")
    print(f"  ✓ 置信度: {confidence:.3f}")
    assert 0 <= confidence <= 1, "置信度应该在0-1之间"


def test_classifier():
    """测试记忆分类器"""
    print("\n[测试3/5] 记忆分类器...")
    
    classifier = MemoryClassifier()
    
    # 测试1：分类记忆类型
    type1 = classifier.classify_memory_type(0.95, "这是核心价值观")
    assert type1 == MemoryType.CORE, "高重要性应该是核心记忆"
    print(f"  ✓ 重要性0.95 → {type1.value}")
    
    type2 = classifier.classify_memory_type(0.6, "这是中等重要的信息")
    assert type2 == MemoryType.MID, "中等重要性应该是中期记忆"
    print(f"  ✓ 重要性0.6 → {type2.value}")
    
    type3 = classifier.classify_memory_type(0.2, "这是临时信息")
    assert type3 == MemoryType.WORK, "低重要性应该是工作记忆"
    print(f"  ✓ 重要性0.2 → {type3.value}")
    
    # 测试2：分类记忆维度
    category1 = classifier.classify_category("我喜欢Python")
    assert category1 == MemoryCategory.PREFERENCE, "应该识别为偏好"
    print(f"  ✓ '我喜欢Python' → {category1.value}")
    
    category2 = classifier.classify_category("上次项目中遇到了内存泄漏问题")
    assert category2 == MemoryCategory.EXPERIENCE, "应该识别为经验"
    print(f"  ✓ '上次项目...' → {category2.value}")
    
    category3 = classifier.classify_category("机器学习是AI的重要分支")
    assert category3 == MemoryCategory.KNOWLEDGE, "应该识别为知识"
    print(f"  ✓ '机器学习...' → {category3.value}")
    
    # 测试3：生成标签
    tags = classifier.generate_tags("Python机器学习项目开发")
    print(f"  ✓ 生成标签: {tags}")
    assert len(tags) > 0, "应该生成标签"
    
    # 测试4：判断隐私级别
    privacy1 = classifier.determine_privacy_level("我的密码是123456")
    assert privacy1 == "private", "包含密码应该是私密"
    print(f"  ✓ 隐私级别判断正确")


def test_memory_former():
    """测试记忆形成管理器"""
    print("\n[测试4/5] 记忆形成管理器...")
    
    store = SQLiteStore(db_path=":memory:")
    former = MemoryFormer(sqlite_store=store)
    
    # 测试1：从文本创建记忆
    text = "我非常喜欢使用Python进行后端开发，尤其是FastAPI框架"
    memory = former.form_memory_from_text(
        text=text,
        user_id="test_user",
        session_id="test_session"
    )
    
    assert memory is not None, "应该创建记忆"
    assert memory.user_id == "test_user"
    assert memory.content == text
    assert memory.importance > 0
    print(f"  ✓ 创建记忆成功")
    print(f"    - 类型: {memory.memory_type.value}")
    print(f"    - 维度: {memory.category.value}")
    print(f"    - 重要性: {memory.importance:.3f}")
    print(f"    - 标签: {memory.tags}")
    
    # 测试2：批量创建
    texts = [
        "今天学习了机器学习的决策树算法",
        "我更倾向于使用Scikit-learn",
        "代码质量很重要"
    ]
    
    memories = former.batch_form_memories(texts, "test_user")
    assert len(memories) == 3, "应该创建3条记忆"
    print(f"  ✓ 批量创建{len(memories)}条记忆")
    
    # 测试3：从对话创建
    messages = [
        {"role": "user", "content": "我想学习深度学习"},
        {"role": "assistant", "content": "好的，我可以帮你"},
        {"role": "user", "content": "推荐使用PyTorch还是TensorFlow"}
    ]
    
    conv_memories = former.form_memories_from_conversation(
        messages,
        user_id="test_user",
        session_id="test_session"
    )
    assert len(conv_memories) == 2, "应该创建2条记忆（只处理用户消息）"
    print(f"  ✓ 从对话创建{len(conv_memories)}条记忆")
    
    # 测试4：分析记忆质量
    quality = former.analyze_memory_quality(memory)
    print(f"  ✓ 记忆质量分析:")
    print(f"    - 内容长度: {quality['content_length']}")
    print(f"    - 标签数: {quality['tags_count']}")


def test_integration():
    """集成测试：完整流程"""
    print("\n[测试5/5] 集成测试...")
    
    store = SQLiteStore(db_path=":memory:")
    former = MemoryFormer(sqlite_store=store)
    
    # 模拟一个完整的用户交互场景
    user_id = "integration_test_user"
    
    # 1. 创建用户画像
    from core.memory import UserProfile
    profile = UserProfile(
        user_id=user_id,
        domain="数据科学",
        role="数据分析师"
    )
    store.create_or_update_profile(profile)
    print("  ✓ 创建用户画像")
    
    # 2. 用户进行多轮对话
    conversation_texts = [
        "我主要使用Python做数据分析",
        "我最常用的库是Pandas和NumPy",
        "上次项目中数据清洗花了很长时间",
        "我认为数据质量是最重要的",
        "今天天气不错"  # 这条应该被过滤或重要性很低
    ]
    
    memories_created = 0
    for text in conversation_texts:
        memory = former.form_memory_from_text(
            text=text,
            user_id=user_id,
            session_id="integration_session"
        )
        if memory:
            memories_created += 1
    
    print(f"  ✓ 从{len(conversation_texts)}条文本创建了{memories_created}条记忆")
    
    # 3. 检索创建的记忆
    all_memories = store.get_memories_by_user(user_id)
    print(f"  ✓ 用户共有{len(all_memories)}条记忆")
    
    # 4. 验证记忆分类
    type_counts = {}
    category_counts = {}
    
    for memory in all_memories:
        type_counts[memory.memory_type.value] = type_counts.get(memory.memory_type.value, 0) + 1
        category_counts[memory.category.value] = category_counts.get(memory.category.value, 0) + 1
    
    print(f"  ✓ 记忆类型分布: {type_counts}")
    print(f"  ✓ 记忆维度分布: {category_counts}")
    
    # 5. 验证重要性排序
    sorted_memories = sorted(all_memories, key=lambda m: m.importance, reverse=True)
    print(f"  ✓ 最重要的记忆: {sorted_memories[0].content[:30]}... (重要性: {sorted_memories[0].importance:.3f})")


def main():
    """运行所有测试"""
    print("\n" + "=" * 70)
    print(" " * 20 + "记忆形成模块测试")
    print("=" * 70)
    
    try:
        test_extractor()
        test_scorer()
        test_classifier()
        test_memory_former()
        test_integration()
        
        print("\n" + "=" * 70)
        print("✓ 所有测试通过！")
        print("=" * 70)
        
        print("\n阶段2完成情况:")
        print("  ✓ 信息提取器实现完成")
        print("  ✓ 重要性评分器实现完成")
        print("  ✓ 记忆分类器实现完成")
        print("  ✓ 记忆形成管理器实现完成")
        print("  ✓ 所有测试通过")
        
        print("\n功能特性:")
        print("  • 自动提取实体、事实、观点")
        print("  • 多维度重要性评分（新颖性、相关性、情绪等）")
        print("  • 智能分类（5种类型 × 6个维度）")
        print("  • 自动生成标签和元数据")
        print("  • 隐私级别判断")
        print("  • 完整的记忆形成流程")
        
        print("\n下一步:")
        print("  1. 阶段3：实现记忆检索模块")
        print("  2. 集成向量检索功能")
        print("  3. 实现多路召回和重排序")
        print()
        
        return 0
    
    except AssertionError as e:
        print(f"\n✗ 测试失败: {e}")
        return 1
    except Exception as e:
        print(f"\n✗ 运行错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

