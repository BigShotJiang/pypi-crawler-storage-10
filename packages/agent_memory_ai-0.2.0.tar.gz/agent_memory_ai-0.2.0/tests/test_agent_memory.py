"""
AgentMemory主类测试

测试统一的Agent记忆接口
"""
import os
import sys
import tempfile
from datetime import datetime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from agent_memory import AgentMemory, MemoryType, MemoryCategory


def test_basic_usage():
    """测试基础使用"""
    print("=" * 70)
    print("测试1: 基础使用")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        # 记忆
        print("\n1️⃣  记忆功能")
        mem1 = agent.memorize("Python编程")
        assert mem1 is not None, "应该能创建记忆"
        print(f"  ✓ 创建记忆: {mem1.content}")
        
        # 检索
        print("\n2️⃣  检索功能")
        results = agent.recall("Python", top_k=5)
        assert len(results) > 0, "应该能检索到记忆"
        print(f"  ✓ 检索到 {len(results)} 条")
        
        # 统计
        print("\n3️⃣  统计功能")
        stats = agent.get_statistics()
        assert stats['progress']['total_memories'] > 0, "应该有记忆统计"
        print(f"  ✓ 总记忆数: {stats['progress']['total_memories']}")
        
        print("\n✅ 基础使用测试通过")


def test_session_management():
    """测试会话管理"""
    print("\n" + "=" * 70)
    print("测试2: 会话管理")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        # 开始会话
        print("\n1️⃣  开始会话")
        context = agent.start_session("test_session")
        assert context['session_id'] == "test_session", "会话ID应该匹配"
        print(f"  ✓ 会话ID: {context['session_id']}")
        
        # 添加消息
        print("\n2️⃣  添加消息")
        agent.add_message("user", "Hello")
        agent.add_message("assistant", "Hi")
        assert len(agent.current_session_messages) == 2, "应该有2条消息"
        print(f"  ✓ 消息数: {len(agent.current_session_messages)}")
        
        # 结束会话
        print("\n3️⃣  结束会话")
        summary = agent.end_session()
        assert summary is not None, "应该有会话摘要"
        print(f"  ✓ 摘要: {summary['summary'][:50]}...")
        
        print("\n✅ 会话管理测试通过")


def test_chat_function():
    """测试对话功能"""
    print("\n" + "=" * 70)
    print("测试3: 对话功能")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        # 对话
        print("\n1️⃣  进行对话")
        result = agent.chat(
            "我想学习Python",
            "很好的选择",
            memorize_user=True
        )
        
        assert result['user_memory'] is not None, "应该记住用户消息"
        print(f"  ✓ 记住用户消息: {result['user_memory'].content}")
        
        # 检索上下文
        print("\n2️⃣  检索上下文")
        memories = agent.recall("Python", top_k=3)
        assert len(memories) > 0, "应该能检索到"
        print(f"  ✓ 找到 {len(memories)} 条相关记忆")
        
        print("\n✅ 对话功能测试通过")


def test_memory_operations():
    """测试记忆操作"""
    print("\n" + "=" * 70)
    print("测试4: 记忆操作")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        # 创建记忆
        print("\n1️⃣  创建记忆")
        mem = agent.create_memory(
            "Python基础知识",
            memory_type=MemoryType.CORE,
            category=MemoryCategory.KNOWLEDGE,
            importance=0.9,
            tags=["Python", "基础"]
        )
        assert mem.importance == 0.9, "重要性应该匹配"
        print(f"  ✓ 创建核心记忆: {mem.content}")
        
        # 更新记忆
        print("\n2️⃣  更新记忆")
        result = agent.update_memory(
            mem.id,
            tags=["Python", "基础", "已学习"]
        )
        assert result['success'], "更新应该成功"
        print(f"  ✓ 更新成功")
        
        # 搜索
        print("\n3️⃣  搜索记忆")
        results = agent.search("Python", filters={"min_importance": 0.8})
        assert len(results) > 0, "应该能搜索到高重要性记忆"
        print(f"  ✓ 找到 {len(results)} 条高重要性记忆")
        
        print("\n✅ 记忆操作测试通过")


def test_maintenance():
    """测试维护功能"""
    print("\n" + "=" * 70)
    print("测试5: 维护功能")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        # 创建一些记忆
        print("\n1️⃣  创建记忆")
        agent.memorize("学习Python")
        agent.memorize("学习Java")
        print(f"  ✓ 创建了2条记忆")
        
        # 执行维护
        print("\n2️⃣  执行维护")
        result = agent.maintain()
        assert 'lifecycle' in result, "应该有生命周期结果"
        assert 'forget' in result, "应该有遗忘结果"
        print(f"  ✓ 生命周期处理: {result['lifecycle']['processed']} 条")
        print(f"  ✓ 自动遗忘: {result['forget']['deleted']} 条")
        
        # 获取报告
        print("\n3️⃣  生成报告")
        report = agent.generate_report(days=7)
        assert 'total_memories' in report, "应该有记忆总数"
        print(f"  ✓ 总记忆数: {report['total_memories']}")
        
        print("\n✅ 维护功能测试通过")


def test_context_manager():
    """测试上下文管理器"""
    print("\n" + "=" * 70)
    print("测试6: 上下文管理器")
    print("=" * 70)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        
        print("\n1️⃣  使用with语句")
        with agent as session:
            session.memorize("测试记忆")
            assert session.current_session_id is not None, "应该有活跃会话"
            print(f"  ✓ 会话ID: {session.current_session_id}")
        
        # 退出后会话应该结束
        assert agent.current_session_id is None, "会话应该已结束"
        print(f"  ✓ 会话已自动结束")
        
        print("\n✅ 上下文管理器测试通过")


def main():
    """运行所有测试"""
    print("\n" + "🧪" * 35)
    print("AgentMemory 主类测试")
    print("🧪" * 35 + "\n")
    
    try:
        test_basic_usage()
        test_session_management()
        test_chat_function()
        test_memory_operations()
        test_maintenance()
        test_context_manager()
        
        print("\n" + "=" * 70)
        print("🎉 所有测试通过！")
        print("=" * 70)
        print("\n✅ 测试项目:")
        print("  ✓ 基础使用")
        print("  ✓ 会话管理")
        print("  ✓ 对话功能")
        print("  ✓ 记忆操作")
        print("  ✓ 维护功能")
        print("  ✓ 上下文管理器")
        print("\nAgentMemory主类功能完整！🚀\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

