"""
阶段8集成测试

验证阶段8（优化与发布）与前7个阶段的集成
主要测试：
1. 打包配置的正确性
2. 文档的完整性
3. 项目结构的合理性
4. 与核心功能的兼容性
"""
import os
import sys
import tempfile
import importlib.util

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


def test_setup_py_exists():
    """测试setup.py是否存在且格式正确"""
    print("=" * 70)
    print("测试1: setup.py配置文件")
    print("=" * 70)
    
    setup_path = os.path.join(os.path.dirname(__file__), '..', 'setup.py')
    assert os.path.exists(setup_path), "setup.py应该存在"
    print("  ✓ setup.py文件存在")
    
    # 读取setup.py内容
    with open(setup_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 验证关键配置
    assert 'name="agent-memory"' in content, "应该包含包名"
    assert 'version=' in content, "应该包含版本号"
    assert 'author=' in content, "应该包含作者信息"
    assert 'install_requires=' in content, "应该包含依赖列表"
    assert 'packages=find_packages' in content, "应该包含包发现"
    print("  ✓ setup.py配置完整")
    
    print("\n✅ setup.py配置文件测试通过\n")


def test_readme_exists():
    """测试README.md是否存在且内容完整"""
    print("=" * 70)
    print("测试2: README.md文档")
    print("=" * 70)
    
    readme_path = os.path.join(os.path.dirname(__file__), '..', 'README.md')
    assert os.path.exists(readme_path), "README.md应该存在"
    print("  ✓ README.md文件存在")
    
    with open(readme_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 验证关键章节
    required_sections = [
        '功能特性',
        '安装',
        '快速开始',
        '文档',
        '示例',
        '架构',
    ]
    
    for section in required_sections:
        assert section in content, f"README应该包含{section}章节"
        print(f"  ✓ 包含'{section}'章节")
    
    # 验证代码示例
    assert '```python' in content, "应该包含Python代码示例"
    assert 'AgentMemory' in content, "应该提到AgentMemory类"
    print("  ✓ 包含代码示例")
    
    print("\n✅ README.md文档测试通过\n")


def test_changelog_exists():
    """测试CHANGELOG.md是否存在"""
    print("=" * 70)
    print("测试3: CHANGELOG.md变更日志")
    print("=" * 70)
    
    changelog_path = os.path.join(os.path.dirname(__file__), '..', 'CHANGELOG.md')
    assert os.path.exists(changelog_path), "CHANGELOG.md应该存在"
    print("  ✓ CHANGELOG.md文件存在")
    
    with open(changelog_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    assert '[0.1.0]' in content, "应该包含0.1.0版本"
    assert '2025-10-29' in content, "应该包含发布日期"
    print("  ✓ 包含版本信息")
    
    print("\n✅ CHANGELOG.md变更日志测试通过\n")


def test_license_exists():
    """测试LICENSE文件是否存在"""
    print("=" * 70)
    print("测试4: LICENSE许可证")
    print("=" * 70)
    
    license_path = os.path.join(os.path.dirname(__file__), '..', 'LICENSE')
    assert os.path.exists(license_path), "LICENSE应该存在"
    print("  ✓ LICENSE文件存在")
    
    with open(license_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    assert 'MIT License' in content, "应该是MIT许可证"
    assert '2025' in content, "应该包含版权年份"
    print("  ✓ MIT许可证正确")
    
    print("\n✅ LICENSE许可证测试通过\n")


def test_gitignore_exists():
    """测试.gitignore是否存在"""
    print("=" * 70)
    print("测试5: .gitignore配置")
    print("=" * 70)
    
    gitignore_path = os.path.join(os.path.dirname(__file__), '..', '.gitignore')
    assert os.path.exists(gitignore_path), ".gitignore应该存在"
    print("  ✓ .gitignore文件存在")
    
    with open(gitignore_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 验证关键忽略项
    required_ignores = [
        '__pycache__',
        '*.py[cod]',  # 匹配.pyc, .pyo, .pyd
        'venv/',
        '.env',
        '*.db',
    ]
    
    for ignore in required_ignores:
        assert ignore in content, f"应该忽略{ignore}"
        print(f"  ✓ 忽略'{ignore}'")
    
    print("\n✅ .gitignore配置测试通过\n")


def test_requirements_exists():
    """测试requirements.txt是否存在"""
    print("=" * 70)
    print("测试6: requirements.txt依赖")
    print("=" * 70)
    
    req_path = os.path.join(os.path.dirname(__file__), '..', 'requirements.txt')
    assert os.path.exists(req_path), "requirements.txt应该存在"
    print("  ✓ requirements.txt文件存在")
    
    with open(req_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 验证核心依赖
    core_deps = [
        'sqlalchemy',
        'openai',
    ]
    
    for dep in core_deps:
        assert dep.lower() in content.lower(), f"应该包含{dep}依赖"
        print(f"  ✓ 包含'{dep}'依赖")
    
    print("\n✅ requirements.txt依赖测试通过\n")


def test_best_practices_exists():
    """测试最佳实践文档是否存在"""
    print("=" * 70)
    print("测试7: 最佳实践文档")
    print("=" * 70)
    
    bp_path = os.path.join(os.path.dirname(__file__), '..', 'docs', 'BEST_PRACTICES.md')
    assert os.path.exists(bp_path), "BEST_PRACTICES.md应该存在"
    print("  ✓ BEST_PRACTICES.md文件存在")
    
    with open(bp_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 验证关键章节
    required_sections = [
        '初始化和配置',
        '记忆管理',
        '会话管理',
        '性能优化',
        '错误处理',
    ]
    
    for section in required_sections:
        assert section in content, f"应该包含{section}章节"
        print(f"  ✓ 包含'{section}'章节")
    
    print("\n✅ 最佳实践文档测试通过\n")


def test_project_structure():
    """测试项目结构是否合理"""
    print("=" * 70)
    print("测试8: 项目结构")
    print("=" * 70)
    
    base_path = os.path.join(os.path.dirname(__file__), '..')
    
    # 验证核心目录
    required_dirs = [
        'core',
        'storage',
        'modules',
        'utils',
        'tests',
        'examples',
        'docs',
    ]
    
    for dir_name in required_dirs:
        dir_path = os.path.join(base_path, dir_name)
        assert os.path.exists(dir_path), f"{dir_name}目录应该存在"
        print(f"  ✓ {dir_name}/ 目录存在")
    
    # 验证核心文件
    required_files = [
        'agent_memory.py',
        '__init__.py',
        'config.json',
    ]
    
    for file_name in required_files:
        file_path = os.path.join(base_path, file_name)
        assert os.path.exists(file_path), f"{file_name}应该存在"
        print(f"  ✓ {file_name} 文件存在")
    
    print("\n✅ 项目结构测试通过\n")


def test_package_importable():
    """测试包是否可以正常导入"""
    print("=" * 70)
    print("测试9: 包导入测试")
    print("=" * 70)
    
    try:
        from agent_memory import AgentMemory
        print("  ✓ 成功导入AgentMemory")
        
        # 尝试导入数据类型
        try:
            from agent_memory import MemoryType, MemoryCategory
            print("  ✓ 成功导入数据类型")
        except ImportError:
            print("  ⚠ 数据类型导入跳过（可能是路径问题）")
        
        # 验证AgentMemory有核心方法
        assert hasattr(AgentMemory, 'memorize'), "应该有memorize方法"
        assert hasattr(AgentMemory, 'recall'), "应该有recall方法"
        assert hasattr(AgentMemory, 'update_memory'), "应该有update_memory方法"
        assert hasattr(AgentMemory, 'maintain'), "应该有maintain方法"
        print("  ✓ AgentMemory包含核心方法")
        
    except ImportError as e:
        raise AssertionError(f"导入失败: {e}")
    
    print("\n✅ 包导入测试通过\n")


def test_core_functionality_with_stage8():
    """测试核心功能与阶段8的集成"""
    print("=" * 70)
    print("测试10: 核心功能集成测试")
    print("=" * 70)
    
    from agent_memory import AgentMemory
    
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "test.db")
        
        # 创建Agent（验证阶段7）
        print("\n  1️⃣  创建AgentMemory实例")
        agent = AgentMemory("test_user", db_path=db_path, use_vector_store=False)
        print("    ✓ AgentMemory实例创建成功")
        
        # 记忆形成（验证阶段2）
        print("\n  2️⃣  测试记忆形成")
        mem = agent.memorize("测试阶段8集成")
        if mem:
            print(f"    ✓ 记忆形成成功: {mem.content}")
        
        # 检索（验证阶段3）
        print("\n  3️⃣  测试记忆检索")
        results = agent.recall("测试", top_k=5)
        print(f"    ✓ 检索成功: {len(results)} 条结果")
        
        # 更新（验证阶段4）
        print("\n  4️⃣  测试记忆更新")
        if mem:
            result = agent.update_memory(mem.id, tags=["阶段8", "集成"])
            print(f"    ✓ 更新成功")
        
        # 维护（验证阶段5）
        print("\n  5️⃣  测试记忆维护")
        maintain_result = agent.maintain()
        print(f"    ✓ 维护完成")
        
        # 会话管理（验证阶段6）
        print("\n  6️⃣  测试会话管理")
        with agent:
            agent.chat("测试消息", "测试回复")
        print(f"    ✓ 会话管理正常")
        
        # 统计（验证阶段7）
        print("\n  7️⃣  测试统计功能")
        stats = agent.get_statistics()
        print(f"    ✓ 统计功能正常: {stats['progress']['total_memories']} 条记忆")
    
    print("\n✅ 核心功能集成测试通过\n")


def test_documentation_completeness():
    """测试文档完整性"""
    print("=" * 70)
    print("测试11: 文档完整性检查")
    print("=" * 70)
    
    base_path = os.path.join(os.path.dirname(__file__), '..', '..')
    
    # 检查阶段总结文档
    stage_summaries = [
        '阶段1完成总结.md',
        '阶段2完成总结.md',
        '阶段3完成总结.md',
        '阶段4完成总结.md',
        '阶段5完成总结.md',
        '阶段6完成总结.md',
        '阶段7完成总结.md',
        '阶段8完成总结.md',
    ]
    
    for summary in stage_summaries:
        summary_path = os.path.join(base_path, summary)
        if os.path.exists(summary_path):
            print(f"  ✓ {summary} 存在")
    
    # 检查集成测试报告
    integration_reports = [
        '阶段1+2集成测试报告.md',
        '阶段1+2+3集成测试报告.md',
        '阶段1-7集成测试报告.md',
    ]
    
    for report in integration_reports:
        report_path = os.path.join(base_path, report)
        if os.path.exists(report_path):
            print(f"  ✓ {report} 存在")
    
    # 检查项目完成报告
    final_report_path = os.path.join(base_path, '项目完成报告.md')
    if os.path.exists(final_report_path):
        print(f"  ✓ 项目完成报告.md 存在")
    
    print("\n✅ 文档完整性检查通过\n")


def test_examples_executable():
    """测试示例代码是否可以找到"""
    print("=" * 70)
    print("测试12: 示例代码检查")
    print("=" * 70)
    
    examples_path = os.path.join(os.path.dirname(__file__), '..', 'examples')
    assert os.path.exists(examples_path), "examples目录应该存在"
    
    # 检查示例文件
    example_files = [
        'basic_usage.py',
        'quick_start.py',
        'formation_demo.py',
        'retrieval_demo.py',
        'decay_demo.py',
        'session_demo.py',
        'quick_start_agent.py',
    ]
    
    found_examples = []
    for example in example_files:
        example_path = os.path.join(examples_path, example)
        if os.path.exists(example_path):
            found_examples.append(example)
            print(f"  ✓ {example} 存在")
    
    assert len(found_examples) > 0, "应该至少有一个示例文件"
    
    print(f"\n  总共找到 {len(found_examples)} 个示例文件")
    print("\n✅ 示例代码检查通过\n")


def main():
    """运行所有阶段8集成测试"""
    print("\n" + "🎯" * 35)
    print("阶段8集成测试 - 优化与发布")
    print("🎯" * 35 + "\n")
    
    try:
        # 配置文件测试
        test_setup_py_exists()
        test_requirements_exists()
        test_gitignore_exists()
        
        # 文档测试
        test_readme_exists()
        test_changelog_exists()
        test_license_exists()
        test_best_practices_exists()
        test_documentation_completeness()
        
        # 结构测试
        test_project_structure()
        test_examples_executable()
        
        # 功能集成测试
        test_package_importable()
        test_core_functionality_with_stage8()
        
        print("=" * 70)
        print("🎉 所有阶段8集成测试通过！")
        print("=" * 70)
        
        print("\n✅ 验证项目:")
        print("  ✓ 打包配置完整 (setup.py, requirements.txt)")
        print("  ✓ 文档系统完善 (README, CHANGELOG, LICENSE)")
        print("  ✓ 最佳实践文档齐全")
        print("  ✓ 项目结构合理")
        print("  ✓ 包可以正常导入")
        print("  ✓ 核心功能与阶段8完美集成")
        print("  ✓ 示例代码完整")
        print("  ✓ 文档体系完整")
        
        print("\n📦 发布准备检查:")
        print("  ✅ setup.py - 打包配置")
        print("  ✅ requirements.txt - 依赖管理")
        print("  ✅ README.md - 项目说明")
        print("  ✅ CHANGELOG.md - 版本历史")
        print("  ✅ LICENSE - MIT许可证")
        print("  ✅ .gitignore - 版本控制")
        print("  ✅ BEST_PRACTICES.md - 使用指南")
        print("  ✅ 示例代码 - 快速上手")
        
        print("\n🚀 阶段8与前7个阶段完美集成！")
        print("项目已经完全准备好发布到PyPI！\n")
        
        return 0
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return 1
    except Exception as e:
        print(f"\n❌ 测试错误: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit(main())

