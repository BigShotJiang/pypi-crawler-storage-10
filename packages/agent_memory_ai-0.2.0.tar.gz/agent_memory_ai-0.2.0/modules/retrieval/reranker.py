"""
重排序器

对检索结果进行多维度重排序
"""
from typing import List, Dict, Any, Optional
from datetime import datetime
import math

from agent_memory.core.memory import Memory
from agent_memory.modules.retrieval.vector_search import SearchResult


class Reranker:
    """
    重排序器
    
    基于多个维度对检索结果进行重新排序
    """
    
    def __init__(self):
        """初始化重排序器"""
        pass
    
    def rerank(
        self,
        results: List[SearchResult],
        strategy: str = "综合",
        context: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        重排序
        
        Args:
            results: 原始检索结果
            strategy: 排序策略
                - 综合: 多维度综合排序
                - 重要性: 按重要性排序
                - 新鲜度: 按时间新鲜度排序
                - 相关性: 按原始分数排序
                - 多样性: 多样性排序
            context: 上下文信息（可选）
        
        Returns:
            重排序后的结果
        """
        if not results:
            return results
        
        if strategy == "重要性":
            return self._rerank_by_importance(results)
        
        elif strategy == "新鲜度":
            return self._rerank_by_freshness(results)
        
        elif strategy == "相关性":
            return self._rerank_by_relevance(results)
        
        elif strategy == "多样性":
            return self._rerank_by_diversity(results)
        
        else:  # 综合
            return self._rerank_comprehensive(results, context)
    
    def _rerank_comprehensive(
        self,
        results: List[SearchResult],
        context: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        综合重排序
        
        考虑相关性、重要性、新鲜度、访问频率等多个维度
        """
        scored_results = []
        
        for result in results:
            memory = result.memory
            
            # 1. 原始相关性分数 (40%)
            relevance_score = result.score * 0.4
            
            # 2. 重要性分数 (25%)
            importance_score = memory.importance * 0.25
            
            # 3. 新鲜度分数 (20%)
            age_days = (datetime.now() - memory.created_at).days
            freshness = self._calculate_freshness(age_days)
            freshness_score = freshness * 0.2
            
            # 4. 访问热度分数 (10%)
            access_score = min(1.0, memory.access_count / 10) * 0.1
            
            # 5. 上下文匹配分数 (5%)
            context_score = 0.0
            if context:
                context_score = self._calculate_context_match(memory, context) * 0.05
            
            # 综合分数
            total_score = (
                relevance_score +
                importance_score +
                freshness_score +
                access_score +
                context_score
            )
            
            scored_results.append((result, total_score))
        
        # 排序
        scored_results.sort(key=lambda x: x[1], reverse=True)
        
        # 更新分数
        reranked = []
        for result, new_score in scored_results:
            new_result = SearchResult(
                memory=result.memory,
                score=new_score,
                distance=1.0 - new_score,
                source=result.source + "_reranked"
            )
            reranked.append(new_result)
        
        return reranked
    
    def _rerank_by_importance(self, results: List[SearchResult]) -> List[SearchResult]:
        """按重要性重排序"""
        results_copy = results.copy()
        results_copy.sort(key=lambda x: x.memory.importance, reverse=True)
        return results_copy
    
    def _rerank_by_freshness(self, results: List[SearchResult]) -> List[SearchResult]:
        """按新鲜度重排序"""
        scored_results = []
        
        for result in results:
            age_days = (datetime.now() - result.memory.created_at).days
            freshness = self._calculate_freshness(age_days)
            scored_results.append((result, freshness))
        
        scored_results.sort(key=lambda x: x[1], reverse=True)
        return [r for r, _ in scored_results]
    
    def _rerank_by_relevance(self, results: List[SearchResult]) -> List[SearchResult]:
        """按原始相关性重排序"""
        results_copy = results.copy()
        results_copy.sort(key=lambda x: x.score, reverse=True)
        return results_copy
    
    def _rerank_by_diversity(
        self,
        results: List[SearchResult],
        alpha: float = 0.7
    ) -> List[SearchResult]:
        """
        多样性重排序（MMR算法）
        
        平衡相关性和多样性
        
        Args:
            results: 原始结果
            alpha: 相关性权重（1-alpha为多样性权重）
        
        Returns:
            多样性排序结果
        """
        if len(results) <= 1:
            return results
        
        selected = []
        remaining = results.copy()
        
        # 选择第一个（最相关）
        first = remaining.pop(0)
        selected.append(first)
        
        # 迭代选择
        while remaining:
            max_score = -1
            max_idx = -1
            
            for idx, candidate in enumerate(remaining):
                # 相关性分数
                relevance = candidate.score
                
                # 多样性分数（与已选择的最小相似度）
                min_similarity = min(
                    self._calculate_similarity(candidate.memory, sel.memory)
                    for sel in selected
                )
                diversity = 1.0 - min_similarity
                
                # MMR分数
                mmr_score = alpha * relevance + (1 - alpha) * diversity
                
                if mmr_score > max_score:
                    max_score = mmr_score
                    max_idx = idx
            
            # 添加最佳候选
            if max_idx >= 0:
                selected.append(remaining.pop(max_idx))
            else:
                break
        
        return selected
    
    def deduplicate(
        self,
        results: List[SearchResult],
        similarity_threshold: float = 0.9
    ) -> List[SearchResult]:
        """
        去重
        
        移除高度相似的重复结果
        
        Args:
            results: 原始结果
            similarity_threshold: 相似度阈值
        
        Returns:
            去重后的结果
        """
        if len(results) <= 1:
            return results
        
        deduplicated = []
        
        for result in results:
            is_duplicate = False
            
            for existing in deduplicated:
                similarity = self._calculate_similarity(
                    result.memory,
                    existing.memory
                )
                
                if similarity >= similarity_threshold:
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduplicated.append(result)
        
        return deduplicated
    
    def merge_results(
        self,
        result_lists: List[List[SearchResult]],
        weights: Optional[List[float]] = None
    ) -> List[SearchResult]:
        """
        合并多路召回结果
        
        Args:
            result_lists: 多个结果列表
            weights: 各路召回的权重（可选）
        
        Returns:
            合并后的结果
        """
        if not result_lists:
            return []
        
        if weights is None:
            weights = [1.0] * len(result_lists)
        
        # 收集所有记忆及其加权分数
        memory_scores = {}
        memory_to_result = {}
        
        for result_list, weight in zip(result_lists, weights):
            for result in result_list:
                mem_id = result.memory.id
                weighted_score = result.score * weight
                
                if mem_id in memory_scores:
                    # 累加分数
                    memory_scores[mem_id] += weighted_score
                else:
                    memory_scores[mem_id] = weighted_score
                    memory_to_result[mem_id] = result
        
        # 构建合并结果
        merged = []
        for mem_id, total_score in sorted(memory_scores.items(), key=lambda x: x[1], reverse=True):
            result = memory_to_result[mem_id]
            merged.append(SearchResult(
                memory=result.memory,
                score=min(1.0, total_score),
                distance=1.0 - min(1.0, total_score),
                source="merged"
            ))
        
        return merged
    
    def _calculate_freshness(self, age_days: int) -> float:
        """
        计算新鲜度
        
        指数衰减，半衰期30天
        """
        if age_days <= 0:
            return 1.0
        
        half_life = 30
        return math.exp(-0.693 * age_days / half_life)
    
    def _calculate_similarity(self, memory1: Memory, memory2: Memory) -> float:
        """
        计算两个记忆的相似度
        
        基于内容、标签等
        """
        # 简化版：基于标签重叠
        if not memory1.tags or not memory2.tags:
            return 0.0
        
        tags1 = set(memory1.tags)
        tags2 = set(memory2.tags)
        
        intersection = tags1 & tags2
        union = tags1 | tags2
        
        if not union:
            return 0.0
        
        return len(intersection) / len(union)
    
    def _calculate_context_match(
        self,
        memory: Memory,
        context: Dict[str, Any]
    ) -> float:
        """
        计算上下文匹配度
        """
        score = 0.0
        count = 0
        
        # 检查各种上下文特征
        if 'current_topic' in context:
            topic = context['current_topic'].lower()
            if topic in memory.content.lower():
                score += 1.0
            count += 1
        
        if 'user_mood' in context and 'mood' in memory.extra_metadata:
            if context['user_mood'] == memory.extra_metadata.get('mood'):
                score += 1.0
            count += 1
        
        return score / count if count > 0 else 0.0


# 全局实例
_reranker = None


def get_reranker() -> Reranker:
    """获取全局重排序器实例"""
    global _reranker
    if _reranker is None:
        _reranker = Reranker()
    return _reranker

