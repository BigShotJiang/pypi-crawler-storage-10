"""
关联检索器

激活和检索关联记忆，构建记忆网络
"""
from typing import List, Set, Optional, Dict
from collections import defaultdict

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.retrieval.vector_search import SearchResult


class AssociativeSearcher:
    """
    关联检索器
    
    基于记忆间的关联关系进行检索
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化关联检索器"""
        self.sqlite_store = sqlite_store
    
    def search_related(
        self,
        memory_id: str,
        user_id: str,
        max_depth: int = 2,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索关联记忆
        
        Args:
            memory_id: 起始记忆ID
            user_id: 用户ID
            max_depth: 最大关联深度
            top_k: 返回数量
        
        Returns:
            关联记忆列表
        """
        # 获取起始记忆
        start_memory = self.sqlite_store.get_memory(memory_id)
        if not start_memory:
            return []
        
        # BFS遍历关联网络
        visited = {memory_id}
        queue = [(memory_id, 0, 1.0)]  # (id, depth, score)
        related_memories = []
        
        while queue and len(related_memories) < top_k * 2:
            current_id, depth, parent_score = queue.pop(0)
            
            if depth >= max_depth:
                continue
            
            # 获取当前记忆
            current_memory = self.sqlite_store.get_memory(current_id)
            if not current_memory:
                continue
            
            # 1. 通过related_memory_ids关联
            for related_id in current_memory.related_memory_ids:
                if related_id not in visited:
                    visited.add(related_id)
                    score = parent_score * 0.8  # 每层衰减
                    queue.append((related_id, depth + 1, score))
                    
                    related_mem = self.sqlite_store.get_memory(related_id)
                    if related_mem:
                        related_memories.append((related_mem, score, depth + 1))
            
            # 2. 通过标签关联
            if current_memory.tags:
                tag_related = self.sqlite_store.search_memories_by_tags(
                    user_id, current_memory.tags
                )
                for mem in tag_related:
                    if mem.id not in visited and mem.id != memory_id:
                        visited.add(mem.id)
                        score = parent_score * 0.6  # 标签关联权重较低
                        related_memories.append((mem, score, depth + 1))
        
        # 构建结果
        results = []
        seen_ids = set()
        
        for memory, score, depth in sorted(related_memories, key=lambda x: x[1], reverse=True):
            if memory.id not in seen_ids:
                seen_ids.add(memory.id)
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source=f"related_depth{depth}"
                ))
        
        return results[:top_k]
    
    def find_memory_chain(
        self,
        start_id: str,
        end_id: str,
        user_id: str,
        max_depth: int = 5
    ) -> List[List[Memory]]:
        """
        查找两个记忆之间的关联链
        
        Args:
            start_id: 起始记忆ID
            end_id: 目标记忆ID
            user_id: 用户ID
            max_depth: 最大搜索深度
        
        Returns:
            关联链列表（可能有多条）
        """
        # BFS查找所有路径
        queue = [([start_id], {start_id})]
        chains = []
        
        while queue and len(chains) < 3:  # 最多返回3条路径
            path, visited = queue.pop(0)
            
            if len(path) > max_depth:
                continue
            
            current_id = path[-1]
            
            # 找到目标
            if current_id == end_id:
                # 构建记忆链
                chain = []
                for mem_id in path:
                    mem = self.sqlite_store.get_memory(mem_id)
                    if mem:
                        chain.append(mem)
                chains.append(chain)
                continue
            
            # 扩展路径
            current_memory = self.sqlite_store.get_memory(current_id)
            if not current_memory:
                continue
            
            for related_id in current_memory.related_memory_ids:
                if related_id not in visited:
                    new_visited = visited.copy()
                    new_visited.add(related_id)
                    queue.append((path + [related_id], new_visited))
        
        return chains
    
    def build_memory_graph(
        self,
        user_id: str,
        min_connections: int = 2
    ) -> Dict[str, List[str]]:
        """
        构建记忆关联图
        
        Args:
            user_id: 用户ID
            min_connections: 最小连接数（过滤孤立节点）
        
        Returns:
            邻接表 {memory_id: [related_ids]}
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        graph = defaultdict(set)
        
        # 1. 显式关联
        for memory in all_memories:
            for related_id in memory.related_memory_ids:
                graph[memory.id].add(related_id)
                graph[related_id].add(memory.id)  # 双向
        
        # 2. 标签关联
        tag_to_memories = defaultdict(set)
        for memory in all_memories:
            for tag in memory.tags:
                tag_to_memories[tag].add(memory.id)
        
        # 同标签的记忆相互关联
        for tag, memory_ids in tag_to_memories.items():
            if len(memory_ids) >= 2:
                for mid1 in memory_ids:
                    for mid2 in memory_ids:
                        if mid1 != mid2:
                            graph[mid1].add(mid2)
        
        # 过滤孤立节点
        filtered_graph = {
            k: list(v)
            for k, v in graph.items()
            if len(v) >= min_connections
        }
        
        return filtered_graph
    
    def find_central_memories(
        self,
        user_id: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        查找中心记忆
        
        连接数最多的记忆（类似PageRank）
        
        Args:
            user_id: 用户ID
            top_k: 返回数量
        
        Returns:
            中心记忆列表
        """
        graph = self.build_memory_graph(user_id, min_connections=1)
        
        # 计算连接度
        centrality = []
        for memory_id, related_ids in graph.items():
            memory = self.sqlite_store.get_memory(memory_id)
            if memory:
                # 连接度分数
                degree = len(related_ids)
                score = min(1.0, degree / 10) * memory.importance
                centrality.append((memory, score, degree))
        
        # 排序
        centrality.sort(key=lambda x: x[1], reverse=True)
        
        results = []
        for memory, score, degree in centrality[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=score,
                distance=1.0 - score,
                source=f"central_{degree}"
            ))
        
        return results
    
    def activate_associative_memories(
        self,
        seed_memories: List[Memory],
        user_id: str,
        activation_threshold: float = 0.5,
        max_activated: int = 20
    ) -> List[SearchResult]:
        """
        激活关联记忆网络
        
        从种子记忆开始，激活相关记忆
        
        Args:
            seed_memories: 种子记忆列表
            user_id: 用户ID
            activation_threshold: 激活阈值
            max_activated: 最大激活数量
        
        Returns:
            激活的记忆列表
        """
        # 激活度字典
        activation = {}
        
        # 初始化种子记忆
        for memory in seed_memories:
            activation[memory.id] = 1.0
        
        # 扩散激活
        queue = [(m.id, 1.0) for m in seed_memories]
        visited = set(m.id for m in seed_memories)
        
        while queue and len(activation) < max_activated:
            current_id, current_activation = queue.pop(0)
            
            if current_activation < activation_threshold:
                continue
            
            current_memory = self.sqlite_store.get_memory(current_id)
            if not current_memory:
                continue
            
            # 激活相关记忆
            for related_id in current_memory.related_memory_ids:
                new_activation = current_activation * 0.8
                
                if related_id in activation:
                    # 累积激活
                    activation[related_id] = min(1.0, activation[related_id] + new_activation * 0.3)
                else:
                    activation[related_id] = new_activation
                
                if related_id not in visited and new_activation >= activation_threshold:
                    visited.add(related_id)
                    queue.append((related_id, new_activation))
        
        # 构建结果（排除种子记忆）
        results = []
        seed_ids = {m.id for m in seed_memories}
        
        for memory_id, act_score in sorted(activation.items(), key=lambda x: x[1], reverse=True):
            if memory_id not in seed_ids:
                memory = self.sqlite_store.get_memory(memory_id)
                if memory:
                    results.append(SearchResult(
                        memory=memory,
                        score=act_score,
                        distance=1.0 - act_score,
                        source="activated"
                    ))
        
        return results


# 全局实例
_associative_searcher = None


def get_associative_searcher(sqlite_store: Optional[SQLiteStore] = None) -> AssociativeSearcher:
    """获取全局关联检索器实例"""
    global _associative_searcher
    if _associative_searcher is None:
        _associative_searcher = AssociativeSearcher(sqlite_store or SQLiteStore())
    return _associative_searcher

