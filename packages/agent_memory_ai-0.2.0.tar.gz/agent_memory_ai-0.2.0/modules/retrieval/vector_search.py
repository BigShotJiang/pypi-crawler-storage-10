"""
向量检索器

基于向量相似度的语义检索
"""
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.storage.vector_store import VectorStore


@dataclass
class SearchResult:
    """检索结果"""
    memory: Memory          # 记忆对象
    score: float           # 相似度分数
    distance: float        # 向量距离
    source: str            # 来源（vector/keyword/time等）
    

class VectorSearcher:
    """
    向量检索器
    
    使用向量相似度进行语义检索
    """
    
    def __init__(
        self,
        sqlite_store: SQLiteStore,
        vector_store: Optional[VectorStore] = None
    ):
        """
        初始化向量检索器
        
        Args:
            sqlite_store: SQLite存储
            vector_store: 向量存储（可选）
        """
        self.sqlite_store = sqlite_store
        self.vector_store = vector_store
        self._embedding_gen = None
    
    @property
    def embedding_gen(self):
        """延迟加载向量生成器"""
        if self._embedding_gen is None:
            try:
                from utils.embeddings import get_embedding_generator
                self._embedding_gen = get_embedding_generator()
            except:
                self._embedding_gen = None
        return self._embedding_gen
    
    def search(
        self,
        query: str,
        user_id: str,
        top_k: int = 10,
        memory_type: Optional[str] = None,
        min_similarity: float = 0.0
    ) -> List[SearchResult]:
        """
        向量相似度检索
        
        Args:
            query: 查询文本
            user_id: 用户ID
            top_k: 返回Top K个结果
            memory_type: 记忆类型过滤（可选）
            min_similarity: 最小相似度阈值
        
        Returns:
            检索结果列表
        """
        if not self.vector_store:
            return []
        
        if not self.embedding_gen:
            return []
        
        try:
            # 1. 生成查询向量
            query_embedding = self.embedding_gen.encode(query)
            
            # 2. 向量检索
            vector_results = self.vector_store.search_similar(
                query_embedding=query_embedding,
                user_id=user_id,
                top_k=top_k * 2,  # 多召回一些，后续过滤
                memory_type=memory_type
            )
            
            # 3. 获取完整记忆对象并构建结果
            results = []
            for memory_id, distance in vector_results:
                memory = self.sqlite_store.get_memory(memory_id)
                if not memory:
                    continue
                
                # 计算相似度分数（余弦距离转相似度）
                similarity = 1.0 - distance
                
                # 过滤低相似度结果
                if similarity < min_similarity:
                    continue
                
                results.append(SearchResult(
                    memory=memory,
                    score=similarity,
                    distance=distance,
                    source="vector"
                ))
            
            # 4. 按相似度排序并截取Top K
            results.sort(key=lambda x: x.score, reverse=True)
            return results[:top_k]
        
        except Exception as e:
            print(f"向量检索失败: {e}")
            return []
    
    def search_by_memory(
        self,
        memory: Memory,
        user_id: str,
        top_k: int = 10,
        exclude_self: bool = True
    ) -> List[SearchResult]:
        """
        基于记忆对象检索相似记忆
        
        Args:
            memory: 参考记忆
            user_id: 用户ID
            top_k: 返回Top K个结果
            exclude_self: 是否排除自身
        
        Returns:
            相似记忆列表
        """
        if not memory.embedding and not self.embedding_gen:
            return []
        
        try:
            # 使用记忆的向量或重新生成
            if memory.embedding:
                query_embedding = memory.embedding
            else:
                query_embedding = self.embedding_gen.encode(memory.content)
            
            # 向量检索
            vector_results = self.vector_store.search_similar(
                query_embedding=query_embedding,
                user_id=user_id,
                top_k=top_k + 1 if exclude_self else top_k
            )
            
            # 构建结果
            results = []
            for memory_id, distance in vector_results:
                # 排除自身
                if exclude_self and memory_id == memory.id:
                    continue
                
                mem = self.sqlite_store.get_memory(memory_id)
                if not mem:
                    continue
                
                results.append(SearchResult(
                    memory=mem,
                    score=1.0 - distance,
                    distance=distance,
                    source="vector"
                ))
            
            return results[:top_k]
        
        except Exception as e:
            print(f"相似记忆检索失败: {e}")
            return []
    
    def batch_search(
        self,
        queries: List[str],
        user_id: str,
        top_k: int = 10
    ) -> List[List[SearchResult]]:
        """
        批量检索
        
        Args:
            queries: 查询列表
            user_id: 用户ID
            top_k: 每个查询返回Top K
        
        Returns:
            每个查询的结果列表
        """
        if not self.embedding_gen:
            return [[] for _ in queries]
        
        try:
            # 批量生成向量
            query_embeddings = self.embedding_gen.encode_batch(queries)
            
            # 批量检索
            all_results = []
            for embedding in query_embeddings:
                vector_results = self.vector_store.search_similar(
                    query_embedding=embedding,
                    user_id=user_id,
                    top_k=top_k
                )
                
                results = []
                for memory_id, distance in vector_results:
                    memory = self.sqlite_store.get_memory(memory_id)
                    if memory:
                        results.append(SearchResult(
                            memory=memory,
                            score=1.0 - distance,
                            distance=distance,
                            source="vector"
                        ))
                
                all_results.append(results)
            
            return all_results
        
        except Exception as e:
            print(f"批量检索失败: {e}")
            return [[] for _ in queries]
    
    def find_similar_cluster(
        self,
        query: str,
        user_id: str,
        similarity_threshold: float = 0.8,
        max_results: int = 50
    ) -> List[SearchResult]:
        """
        查找相似记忆簇
        
        找到所有相似度高于阈值的记忆
        
        Args:
            query: 查询文本
            user_id: 用户ID
            similarity_threshold: 相似度阈值
            max_results: 最大结果数
        
        Returns:
            相似记忆簇
        """
        results = self.search(
            query=query,
            user_id=user_id,
            top_k=max_results,
            min_similarity=similarity_threshold
        )
        
        return results
    
    def search_by_category(
        self,
        query: str,
        user_id: str,
        category: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        在特定维度下检索
        
        Args:
            query: 查询文本
            user_id: 用户ID
            category: 记忆维度
            top_k: 返回数量
        
        Returns:
            检索结果
        """
        # 先进行向量检索
        all_results = self.search(
            query=query,
            user_id=user_id,
            top_k=top_k * 3  # 多召回一些
        )
        
        # 过滤指定维度
        filtered = [r for r in all_results if r.memory.category.value == category]
        
        return filtered[:top_k]


# 全局实例
_vector_searcher = None


def get_vector_searcher(
    sqlite_store: Optional[SQLiteStore] = None,
    vector_store: Optional[VectorStore] = None
) -> VectorSearcher:
    """获取全局向量检索器实例"""
    global _vector_searcher
    if _vector_searcher is None:
        _vector_searcher = VectorSearcher(
            sqlite_store or SQLiteStore(),
            vector_store
        )
    return _vector_searcher

