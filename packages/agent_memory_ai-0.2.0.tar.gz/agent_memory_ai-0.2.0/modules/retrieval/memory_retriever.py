"""
记忆检索管理器

整合多路召回，提供统一的检索接口
"""
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from agent_memory.core.memory import Memory, MemoryType, MemoryCategory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.storage.vector_store import VectorStore
from agent_memory.modules.retrieval.vector_search import VectorSearcher, SearchResult
from agent_memory.modules.retrieval.keyword_search import KeywordSearcher
from agent_memory.modules.retrieval.temporal_search import TemporalSearcher
from agent_memory.modules.retrieval.context_search import ContextSearcher
from agent_memory.modules.retrieval.associative_search import AssociativeSearcher
from agent_memory.modules.retrieval.reranker import Reranker


class MemoryRetriever:
    """
    记忆检索管理器
    
    整合多路召回策略，提供统一的检索接口
    """
    
    def __init__(
        self,
        sqlite_store: Optional[SQLiteStore] = None,
        vector_store: Optional[VectorStore] = None
    ):
        """
        初始化检索管理器
        
        Args:
            sqlite_store: SQLite存储
            vector_store: 向量存储
        """
        self.sqlite_store = sqlite_store or SQLiteStore()
        self.vector_store = vector_store
        
        # 初始化各个检索器
        self.vector_searcher = VectorSearcher(self.sqlite_store, vector_store)
        self.keyword_searcher = KeywordSearcher(self.sqlite_store)
        self.temporal_searcher = TemporalSearcher(self.sqlite_store)
        self.context_searcher = ContextSearcher(self.sqlite_store)
        self.associative_searcher = AssociativeSearcher(self.sqlite_store)
        self.reranker = Reranker()
    
    def retrieve(
        self,
        query: str,
        user_id: str,
        top_k: int = 10,
        strategy: str = "hybrid",
        context: Optional[Dict[str, Any]] = None,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        统一检索接口
        
        Args:
            query: 查询文本
            user_id: 用户ID
            top_k: 返回数量
            strategy: 检索策略
                - hybrid: 混合检索（默认）
                - vector: 仅向量检索
                - keyword: 仅关键词检索
                - temporal: 仅时间检索
                - context: 仅情境检索
            context: 上下文信息（可选）
            filters: 过滤条件（可选）
                - memory_type: 记忆类型
                - category: 记忆维度
                - min_importance: 最小重要性
                - time_range: 时间范围
        
        Returns:
            检索结果列表
        """
        if strategy == "hybrid":
            return self._hybrid_retrieve(query, user_id, top_k, context, filters)
        
        elif strategy == "vector":
            results = self.vector_searcher.search(query, user_id, top_k)
            return self._apply_filters(results, filters)
        
        elif strategy == "keyword":
            results = self.keyword_searcher.search(query, user_id, top_k)
            return self._apply_filters(results, filters)
        
        elif strategy == "temporal":
            results = self.temporal_searcher.search_recent(user_id, days=7, top_k=top_k)
            return self._apply_filters(results, filters)
        
        elif strategy == "context":
            if context:
                results = self.context_searcher.search_by_context(user_id, context, top_k)
                return self._apply_filters(results, filters)
            return []
        
        else:
            return self._hybrid_retrieve(query, user_id, top_k, context, filters)
    
    def _hybrid_retrieve(
        self,
        query: str,
        user_id: str,
        top_k: int,
        context: Optional[Dict[str, Any]],
        filters: Optional[Dict[str, Any]]
    ) -> List[SearchResult]:
        """
        混合检索策略
        
        多路召回 + 重排序 + 去重
        """
        all_results = []
        
        # 1. 向量检索（主要）
        vector_results = self.vector_searcher.search(
            query=query,
            user_id=user_id,
            top_k=top_k * 2
        )
        all_results.append((vector_results, 1.0))  # 权重1.0
        
        # 2. 关键词检索（辅助）
        keyword_results = self.keyword_searcher.search(
            query=query,
            user_id=user_id,
            top_k=top_k
        )
        all_results.append((keyword_results, 0.6))  # 权重0.6
        
        # 3. 时间检索（最近记忆）
        recent_results = self.temporal_searcher.search_recent(
            user_id=user_id,
            days=7,
            top_k=top_k // 2
        )
        all_results.append((recent_results, 0.4))  # 权重0.4
        
        # 4. 上下文检索（如果有上下文）
        if context:
            context_results = self.context_searcher.search_by_context(
                user_id=user_id,
                context=context,
                top_k=top_k // 2
            )
            all_results.append((context_results, 0.5))  # 权重0.5
        
        # 合并多路召回
        result_lists = [r for r, w in all_results]
        weights = [w for r, w in all_results]
        merged_results = self.reranker.merge_results(result_lists, weights)
        
        # 应用过滤
        filtered_results = self._apply_filters(merged_results, filters)
        
        # 重排序
        reranked_results = self.reranker.rerank(
            filtered_results,
            strategy="综合",
            context=context
        )
        
        # 去重
        deduplicated_results = self.reranker.deduplicate(reranked_results)
        
        return deduplicated_results[:top_k]
    
    def retrieve_related(
        self,
        memory_id: str,
        user_id: str,
        top_k: int = 10,
        include_associative: bool = True
    ) -> List[SearchResult]:
        """
        检索相关记忆
        
        Args:
            memory_id: 记忆ID
            user_id: 用户ID
            top_k: 返回数量
            include_associative: 是否包含关联激活
        
        Returns:
            相关记忆列表
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return []
        
        all_results = []
        
        # 1. 向量相似检索
        vector_results = self.vector_searcher.search_by_memory(
            memory=memory,
            user_id=user_id,
            top_k=top_k
        )
        all_results.extend(vector_results)
        
        # 2. 关联记忆检索
        if include_associative:
            associative_results = self.associative_searcher.search_related(
                memory_id=memory_id,
                user_id=user_id,
                max_depth=2,
                top_k=top_k // 2
            )
            all_results.extend(associative_results)
        
        # 去重并排序
        deduplicated = self.reranker.deduplicate(all_results)
        deduplicated.sort(key=lambda x: x.score, reverse=True)
        
        return deduplicated[:top_k]
    
    def retrieve_by_time_range(
        self,
        user_id: str,
        start_time: datetime,
        end_time: datetime,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按时间范围检索
        
        Args:
            user_id: 用户ID
            start_time: 开始时间
            end_time: 结束时间
            top_k: 返回数量
        
        Returns:
            指定时间范围的记忆
        """
        return self.temporal_searcher.search_by_time_range(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            top_k=top_k
        )
    
    def retrieve_by_category(
        self,
        user_id: str,
        category: MemoryCategory,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按记忆维度检索
        
        Args:
            user_id: 用户ID
            category: 记忆维度
            top_k: 返回数量
        
        Returns:
            指定维度的记忆
        """
        return self.context_searcher.search_by_category(
            user_id=user_id,
            category=category,
            top_k=top_k
        )
    
    def retrieve_by_type(
        self,
        user_id: str,
        memory_type: MemoryType,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按记忆类型检索
        
        Args:
            user_id: 用户ID
            memory_type: 记忆类型
            top_k: 返回数量
        
        Returns:
            指定类型的记忆
        """
        return self.context_searcher.search_by_type(
            user_id=user_id,
            memory_type=memory_type,
            top_k=top_k
        )
    
    def retrieve_important(
        self,
        user_id: str,
        min_importance: float = 0.7,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索重要记忆
        
        Args:
            user_id: 用户ID
            min_importance: 最小重要性
            top_k: 返回数量
        
        Returns:
            重要记忆列表
        """
        return self.keyword_searcher.search_by_importance(
            min_importance=min_importance,
            user_id=user_id,
            top_k=top_k
        )
    
    def retrieve_trending(
        self,
        user_id: str,
        window_days: int = 7,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索热门记忆
        
        Args:
            user_id: 用户ID
            window_days: 时间窗口（天）
            top_k: 返回数量
        
        Returns:
            热门记忆列表
        """
        return self.temporal_searcher.search_trending(
            user_id=user_id,
            window_days=window_days,
            top_k=top_k
        )
    
    def retrieve_central(
        self,
        user_id: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索中心记忆
        
        Args:
            user_id: 用户ID
            top_k: 返回数量
        
        Returns:
            中心记忆列表
        """
        return self.associative_searcher.find_central_memories(
            user_id=user_id,
            top_k=top_k
        )
    
    def retrieve_for_context_building(
        self,
        user_id: str,
        session_id: Optional[str] = None,
        max_memories: int = 20
    ) -> List[Memory]:
        """
        为上下文构建检索记忆
        
        用于会话开始时加载相关记忆
        
        Args:
            user_id: 用户ID
            session_id: 会话ID（可选）
            max_memories: 最大记忆数
        
        Returns:
            记忆列表
        """
        memories = []
        
        # 1. 核心记忆（最重要的）
        core_results = self.retrieve_important(
            user_id=user_id,
            min_importance=0.8,
            top_k=5
        )
        memories.extend([r.memory for r in core_results])
        
        # 2. 最近记忆
        recent_results = self.temporal_searcher.search_recent(
            user_id=user_id,
            days=3,
            top_k=10
        )
        memories.extend([r.memory for r in recent_results])
        
        # 3. 同会话记忆（如果有会话ID）
        if session_id:
            session_results = self.context_searcher.search_by_session(
                user_id=user_id,
                session_id=session_id,
                top_k=5
            )
            memories.extend([r.memory for r in session_results])
        
        # 去重
        seen_ids = set()
        unique_memories = []
        for memory in memories:
            if memory.id not in seen_ids:
                seen_ids.add(memory.id)
                unique_memories.append(memory)
        
        return unique_memories[:max_memories]
    
    def _apply_filters(
        self,
        results: List[SearchResult],
        filters: Optional[Dict[str, Any]]
    ) -> List[SearchResult]:
        """
        应用过滤条件
        
        Args:
            results: 原始结果
            filters: 过滤条件
        
        Returns:
            过滤后的结果
        """
        if not filters:
            return results
        
        filtered = results
        
        # 记忆类型过滤
        if 'memory_type' in filters:
            memory_type = filters['memory_type']
            filtered = [
                r for r in filtered
                if r.memory.memory_type.value == memory_type
            ]
        
        # 记忆维度过滤
        if 'category' in filters:
            category = filters['category']
            filtered = [
                r for r in filtered
                if r.memory.category.value == category
            ]
        
        # 重要性过滤
        if 'min_importance' in filters:
            min_importance = filters['min_importance']
            filtered = [
                r for r in filtered
                if r.memory.importance >= min_importance
            ]
        
        # 时间范围过滤
        if 'time_range' in filters:
            start_time, end_time = filters['time_range']
            filtered = [
                r for r in filtered
                if start_time <= r.memory.created_at <= end_time
            ]
        
        return filtered


# 全局实例
_memory_retriever = None


def get_memory_retriever(
    sqlite_store: Optional[SQLiteStore] = None,
    vector_store: Optional[VectorStore] = None
) -> MemoryRetriever:
    """获取全局记忆检索管理器实例"""
    global _memory_retriever
    if _memory_retriever is None:
        _memory_retriever = MemoryRetriever(sqlite_store, vector_store)
    return _memory_retriever

