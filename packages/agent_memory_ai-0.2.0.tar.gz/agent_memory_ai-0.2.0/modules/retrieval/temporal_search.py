"""
时间检索器

基于时间维度的检索
"""
from typing import List, Optional
from datetime import datetime, timedelta

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.retrieval.vector_search import SearchResult


class TemporalSearcher:
    """
    时间检索器
    
    基于时间范围和时间特征进行检索
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化时间检索器"""
        self.sqlite_store = sqlite_store
    
    def search_by_time_range(
        self,
        user_id: str,
        start_time: datetime,
        end_time: datetime,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按时间范围检索
        
        Args:
            user_id: 用户ID
            start_time: 开始时间
            end_time: 结束时间
            top_k: 返回数量
        
        Returns:
            时间范围内的记忆
        """
        memories = self.sqlite_store.get_memories_by_timerange(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time
        )
        
        # 按时间排序（最新的在前）
        memories.sort(key=lambda m: m.created_at, reverse=True)
        
        results = []
        for memory in memories[:top_k]:
            # 计算时间新鲜度分数
            age = datetime.now() - memory.created_at
            freshness = self._calculate_freshness(age.days)
            
            results.append(SearchResult(
                memory=memory,
                score=freshness,
                distance=1.0 - freshness,
                source="temporal"
            ))
        
        return results
    
    def search_recent(
        self,
        user_id: str,
        days: int = 7,
        top_k: int = 10,
        min_importance: float = 0.0
    ) -> List[SearchResult]:
        """
        检索最近N天的记忆
        
        Args:
            user_id: 用户ID
            days: 天数
            top_k: 返回数量
            min_importance: 最小重要性过滤
        
        Returns:
            最近的记忆
        """
        end_time = datetime.now()
        start_time = end_time - timedelta(days=days)
        
        memories = self.sqlite_store.get_memories_by_timerange(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time
        )
        
        # 过滤重要性
        if min_importance > 0:
            memories = [m for m in memories if m.importance >= min_importance]
        
        # 排序：重要性和新鲜度综合
        memories.sort(
            key=lambda m: (m.importance * 0.6 + self._calculate_freshness((datetime.now() - m.created_at).days) * 0.4),
            reverse=True
        )
        
        results = []
        for memory in memories[:top_k]:
            age_days = (datetime.now() - memory.created_at).days
            freshness = self._calculate_freshness(age_days)
            
            # 综合分数
            score = memory.importance * 0.6 + freshness * 0.4
            
            results.append(SearchResult(
                memory=memory,
                score=score,
                distance=1.0 - score,
                source="recent"
            ))
        
        return results
    
    def search_by_access_time(
        self,
        user_id: str,
        recent_accessed: bool = True,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按访问时间检索
        
        Args:
            user_id: 用户ID
            recent_accessed: True=最近访问, False=很久未访问
            top_k: 返回数量
        
        Returns:
            按访问时间排序的记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 排序
        all_memories.sort(
            key=lambda m: m.last_access,
            reverse=recent_accessed
        )
        
        results = []
        for memory in all_memories[:top_k]:
            age = datetime.now() - memory.last_access
            freshness = self._calculate_freshness(age.days)
            
            score = freshness if recent_accessed else (1.0 - freshness)
            
            results.append(SearchResult(
                memory=memory,
                score=score,
                distance=1.0 - score,
                source="access_time"
            ))
        
        return results
    
    def search_by_period(
        self,
        user_id: str,
        period: str,  # today/yesterday/this_week/last_week/this_month/last_month
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按时间段检索
        
        Args:
            user_id: 用户ID
            period: 时间段
            top_k: 返回数量
        
        Returns:
            指定时间段的记忆
        """
        now = datetime.now()
        
        # 计算时间范围
        if period == "today":
            start_time = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end_time = now
        
        elif period == "yesterday":
            today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            start_time = today_start - timedelta(days=1)
            end_time = today_start
        
        elif period == "this_week":
            days_since_monday = now.weekday()
            start_time = now - timedelta(days=days_since_monday)
            start_time = start_time.replace(hour=0, minute=0, second=0, microsecond=0)
            end_time = now
        
        elif period == "last_week":
            days_since_monday = now.weekday()
            this_week_start = now - timedelta(days=days_since_monday)
            this_week_start = this_week_start.replace(hour=0, minute=0, second=0, microsecond=0)
            start_time = this_week_start - timedelta(days=7)
            end_time = this_week_start
        
        elif period == "this_month":
            start_time = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            end_time = now
        
        elif period == "last_month":
            this_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            if this_month_start.month == 1:
                start_time = this_month_start.replace(year=this_month_start.year - 1, month=12)
            else:
                start_time = this_month_start.replace(month=this_month_start.month - 1)
            end_time = this_month_start
        
        else:
            return []
        
        return self.search_by_time_range(user_id, start_time, end_time, top_k)
    
    def search_trending(
        self,
        user_id: str,
        window_days: int = 7,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索热门记忆
        
        在指定时间窗口内访问频繁的记忆
        
        Args:
            user_id: 用户ID
            window_days: 时间窗口（天）
            top_k: 返回数量
        
        Returns:
            热门记忆
        """
        cutoff_time = datetime.now() - timedelta(days=window_days)
        
        # 获取所有记忆
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 计算热度分数
        scored_memories = []
        for memory in all_memories:
            # 热度 = 访问次数 + 重要性 + 新鲜度
            age_days = (datetime.now() - memory.created_at).days
            freshness = self._calculate_freshness(age_days)
            
            # 最近访问加权
            if memory.last_access > cutoff_time:
                access_weight = 2.0
            else:
                access_weight = 1.0
            
            heat_score = (
                memory.access_count * 0.4 * access_weight +
                memory.importance * 0.4 +
                freshness * 0.2
            )
            
            scored_memories.append((memory, heat_score))
        
        # 排序
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        
        results = []
        for memory, score in scored_memories[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=min(1.0, score),
                distance=1.0 - min(1.0, score),
                source="trending"
            ))
        
        return results
    
    def search_aging(
        self,
        user_id: str,
        min_age_days: int = 30,
        max_access_count: int = 2,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索老化记忆
        
        长时间未访问且访问次数少的记忆
        
        Args:
            user_id: 用户ID
            min_age_days: 最小年龄（天）
            max_access_count: 最大访问次数
            top_k: 返回数量
        
        Returns:
            老化的记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        aging_memories = []
        for memory in all_memories:
            age_days = (datetime.now() - memory.created_at).days
            access_age_days = (datetime.now() - memory.last_access).days
            
            # 老化条件
            if (age_days >= min_age_days and
                memory.access_count <= max_access_count and
                access_age_days >= min_age_days):
                
                # 老化程度分数
                aging_score = min(1.0, access_age_days / 90)  # 90天完全老化
                
                aging_memories.append((memory, aging_score))
        
        # 按老化程度排序
        aging_memories.sort(key=lambda x: x[1], reverse=True)
        
        results = []
        for memory, score in aging_memories[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=score,
                distance=1.0 - score,
                source="aging"
            ))
        
        return results
    
    def _calculate_freshness(self, age_days: int) -> float:
        """
        计算新鲜度分数
        
        基于记忆年龄的衰减函数
        
        Args:
            age_days: 年龄（天）
        
        Returns:
            新鲜度分数 (0-1)
        """
        if age_days <= 0:
            return 1.0
        
        # 指数衰减：半衰期30天
        import math
        half_life = 30
        freshness = math.exp(-0.693 * age_days / half_life)
        
        return freshness


# 全局实例
_temporal_searcher = None


def get_temporal_searcher(sqlite_store: Optional[SQLiteStore] = None) -> TemporalSearcher:
    """获取全局时间检索器实例"""
    global _temporal_searcher
    if _temporal_searcher is None:
        _temporal_searcher = TemporalSearcher(sqlite_store or SQLiteStore())
    return _temporal_searcher

