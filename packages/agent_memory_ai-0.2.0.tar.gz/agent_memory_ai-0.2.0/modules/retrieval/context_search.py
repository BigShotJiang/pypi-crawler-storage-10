"""
情境检索器

基于上下文和场景的检索
"""
from typing import List, Optional, Dict, Any

from agent_memory.core.memory import Memory, MemoryCategory, MemoryType
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.retrieval.vector_search import SearchResult


class ContextSearcher:
    """
    情境检索器
    
    基于当前上下文和场景特征进行检索
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化情境检索器"""
        self.sqlite_store = sqlite_store
    
    def search_by_context(
        self,
        user_id: str,
        context: Dict[str, Any],
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        基于上下文检索
        
        Args:
            user_id: 用户ID
            context: 上下文信息
                - current_topic: 当前话题
                - session_topics: 会话主题列表
                - user_state: 用户状态
                - domain: 领域
        
        Returns:
            相关记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        results = []
        for memory in all_memories:
            score = self._calculate_context_score(memory, context)
            
            if score > 0:
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="context"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def search_by_category(
        self,
        user_id: str,
        category: MemoryCategory,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按记忆维度检索
        
        Args:
            user_id: 用户ID
            category: 记忆维度
            top_k: 返回数量
        
        Returns:
            指定维度的记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 过滤维度
        filtered = [m for m in all_memories if m.category == category]
        
        # 按重要性排序
        filtered.sort(key=lambda m: m.importance, reverse=True)
        
        results = []
        for memory in filtered[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=memory.importance,
                distance=1.0 - memory.importance,
                source="category"
            ))
        
        return results
    
    def search_by_type(
        self,
        user_id: str,
        memory_type: MemoryType,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按记忆类型检索
        
        Args:
            user_id: 用户ID
            memory_type: 记忆类型
            top_k: 返回数量
        
        Returns:
            指定类型的记忆
        """
        memories = self.sqlite_store.get_memories_by_user(
            user_id=user_id,
            memory_type=memory_type.value,
            limit=top_k * 2
        )
        
        # 按重要性和新鲜度综合排序
        from datetime import datetime
        memories.sort(
            key=lambda m: (m.importance * 0.7 + (1.0 - min(1.0, (datetime.now() - m.created_at).days / 30)) * 0.3),
            reverse=True
        )
        
        results = []
        for memory in memories[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=memory.importance,
                distance=1.0 - memory.importance,
                source="type"
            ))
        
        return results
    
    def search_by_session(
        self,
        user_id: str,
        session_id: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索同一会话的记忆
        
        Args:
            user_id: 用户ID
            session_id: 会话ID
            top_k: 返回数量
        
        Returns:
            同会话的记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 过滤会话
        session_memories = [
            m for m in all_memories
            if m.source_session_id == session_id
        ]
        
        # 按创建时间排序
        session_memories.sort(key=lambda m: m.created_at)
        
        results = []
        for memory in session_memories[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=1.0,
                distance=0.0,
                source="session"
            ))
        
        return results
    
    def search_related_topics(
        self,
        user_id: str,
        topic: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        检索相关主题的记忆
        
        Args:
            user_id: 用户ID
            topic: 主题
            top_k: 返回数量
        
        Returns:
            相关主题的记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        topic_lower = topic.lower()
        results = []
        
        for memory in all_memories:
            # 检查内容、标签中是否包含主题
            content_match = topic_lower in memory.content.lower()
            tag_match = any(topic_lower in tag.lower() for tag in memory.tags)
            
            if content_match or tag_match:
                score = 0.8 if content_match else 0.6
                score *= memory.importance
                
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="topic"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def _calculate_context_score(
        self,
        memory: Memory,
        context: Dict[str, Any]
    ) -> float:
        """
        计算上下文匹配分数
        
        Args:
            memory: 记忆对象
            context: 上下文信息
        
        Returns:
            匹配分数 (0-1)
        """
        score = 0.0
        weights = 0.0
        
        # 1. 当前话题匹配
        if 'current_topic' in context:
            topic = context['current_topic'].lower()
            if topic in memory.content.lower():
                score += 0.4
            weights += 0.4
        
        # 2. 会话主题匹配
        if 'session_topics' in context:
            topics = [t.lower() for t in context['session_topics']]
            for topic in topics:
                if topic in memory.content.lower():
                    score += 0.2
                    break
            weights += 0.2
        
        # 3. 领域匹配
        if 'domain' in context:
            domain = context['domain'].lower()
            if domain in memory.content.lower():
                score += 0.2
            weights += 0.2
        
        # 4. 记忆类型匹配（优先情境记忆）
        if memory.category == MemoryCategory.CONTEXT:
            score += 0.2
            weights += 0.2
        
        # 归一化
        if weights > 0:
            return score / weights * memory.importance
        
        return 0.0


# 全局实例
_context_searcher = None


def get_context_searcher(sqlite_store: Optional[SQLiteStore] = None) -> ContextSearcher:
    """获取全局情境检索器实例"""
    global _context_searcher
    if _context_searcher is None:
        _context_searcher = ContextSearcher(sqlite_store or SQLiteStore())
    return _context_searcher

