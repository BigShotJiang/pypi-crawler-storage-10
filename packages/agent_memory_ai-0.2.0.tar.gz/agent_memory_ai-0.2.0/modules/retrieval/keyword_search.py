"""
关键词检索器

基于关键词匹配的精确检索
"""
from typing import List, Optional, Set
import re

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.retrieval.vector_search import SearchResult


class KeywordSearcher:
    """
    关键词检索器
    
    基于关键词进行精确匹配检索
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化关键词检索器"""
        self.sqlite_store = sqlite_store
    
    def search(
        self,
        query: str,
        user_id: str,
        top_k: int = 10,
        match_mode: str = "any"  # any/all/phrase
    ) -> List[SearchResult]:
        """
        关键词检索
        
        Args:
            query: 查询文本
            user_id: 用户ID
            top_k: 返回Top K
            match_mode: 匹配模式
                - any: 任意关键词匹配
                - all: 所有关键词匹配
                - phrase: 短语精确匹配
        
        Returns:
            检索结果列表
        """
        # 提取关键词
        keywords = self._extract_keywords(query)
        
        if not keywords:
            return []
        
        # 获取用户所有记忆
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 匹配和评分
        results = []
        for memory in all_memories:
            score = self._calculate_match_score(
                memory.content,
                keywords,
                match_mode,
                query
            )
            
            if score > 0:
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="keyword"
                ))
        
        # 排序并返回Top K
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def search_by_tags(
        self,
        tags: List[str],
        user_id: str,
        match_all: bool = False,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        根据标签检索
        
        Args:
            tags: 标签列表
            user_id: 用户ID
            match_all: 是否匹配所有标签
            top_k: 返回数量
        
        Returns:
            检索结果
        """
        memories = self.sqlite_store.search_memories_by_tags(user_id, tags)
        
        results = []
        for memory in memories:
            # 计算标签匹配度
            memory_tags = set(memory.tags)
            query_tags = set(tags)
            
            if match_all:
                # 必须包含所有标签
                if not query_tags.issubset(memory_tags):
                    continue
                score = 1.0
            else:
                # 计算重叠率
                intersection = memory_tags & query_tags
                union = memory_tags | query_tags
                score = len(intersection) / len(union) if union else 0
            
            if score > 0:
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="tag"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def search_exact(
        self,
        phrase: str,
        user_id: str,
        case_sensitive: bool = False
    ) -> List[SearchResult]:
        """
        精确短语匹配
        
        Args:
            phrase: 精确短语
            user_id: 用户ID
            case_sensitive: 是否区分大小写
        
        Returns:
            匹配结果
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        results = []
        for memory in all_memories:
            content = memory.content if case_sensitive else memory.content.lower()
            search_phrase = phrase if case_sensitive else phrase.lower()
            
            if search_phrase in content:
                # 计算匹配度（基于短语长度占比）
                score = len(search_phrase) / len(content)
                score = min(1.0, score * 2)  # 放大并限制在1.0
                
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="exact"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results
    
    def search_regex(
        self,
        pattern: str,
        user_id: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        正则表达式检索
        
        Args:
            pattern: 正则表达式
            user_id: 用户ID
            top_k: 返回数量
        
        Returns:
            匹配结果
        """
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            return []
        
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        results = []
        for memory in all_memories:
            matches = regex.findall(memory.content)
            if matches:
                # 根据匹配次数计算分数
                score = min(1.0, len(matches) * 0.2)
                
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="regex"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def _extract_keywords(self, text: str) -> List[str]:
        """
        提取关键词
        
        简单的分词和停用词过滤
        """
        # 简单分词（按空格和标点）
        words = re.findall(r'\w+', text.lower())
        
        # 停用词
        stopwords = {
            '的', '了', '在', '是', '我', '有', '和', '就', '不', '人',
            '都', '一', '上', '也', '很', '到', '说', '要', '去', '你',
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to',
            'for', 'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are'
        }
        
        # 过滤停用词和短词
        keywords = [w for w in words if w not in stopwords and len(w) > 1]
        
        return keywords
    
    def _calculate_match_score(
        self,
        content: str,
        keywords: List[str],
        match_mode: str,
        original_query: str = ""
    ) -> float:
        """
        计算匹配分数
        
        Args:
            content: 记忆内容
            keywords: 关键词列表
            match_mode: 匹配模式
            original_query: 原始查询
        
        Returns:
            匹配分数 (0-1)
        """
        content_lower = content.lower()
        
        if match_mode == "phrase":
            # 短语匹配
            if original_query.lower() in content_lower:
                return len(original_query) / len(content)
            return 0.0
        
        # 统计关键词匹配
        matched = 0
        total_weight = 0
        
        for keyword in keywords:
            if keyword in content_lower:
                matched += 1
                # 关键词出现次数作为权重
                count = content_lower.count(keyword)
                total_weight += min(count, 3)  # 最多计3次
        
        if match_mode == "all":
            # 必须全部匹配
            if matched < len(keywords):
                return 0.0
            return total_weight / (len(keywords) * 2)  # 归一化
        
        else:  # any
            # 任意匹配
            if matched == 0:
                return 0.0
            
            # 匹配率 + 权重
            match_ratio = matched / len(keywords)
            weight_score = total_weight / (len(keywords) * 3)
            
            return (match_ratio * 0.6 + weight_score * 0.4)
    
    def search_by_importance(
        self,
        min_importance: float,
        user_id: str,
        top_k: int = 10
    ) -> List[SearchResult]:
        """
        按重要性筛选
        
        Args:
            min_importance: 最小重要性
            user_id: 用户ID
            top_k: 返回数量
        
        Returns:
            高重要性记忆
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 过滤和排序
        high_importance = [
            m for m in all_memories
            if m.importance >= min_importance
        ]
        
        high_importance.sort(key=lambda m: m.importance, reverse=True)
        
        results = []
        for memory in high_importance[:top_k]:
            results.append(SearchResult(
                memory=memory,
                score=memory.importance,
                distance=1.0 - memory.importance,
                source="importance"
            ))
        
        return results
    
    def fuzzy_search(
        self,
        query: str,
        user_id: str,
        top_k: int = 10,
        tolerance: int = 1
    ) -> List[SearchResult]:
        """
        模糊检索
        
        允许一定的拼写错误
        
        Args:
            query: 查询文本
            user_id: 用户ID
            top_k: 返回数量
            tolerance: 容错度（编辑距离）
        
        Returns:
            模糊匹配结果
        """
        # 简化版：基于子串匹配
        keywords = self._extract_keywords(query)
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        results = []
        for memory in all_memories:
            score = 0
            content_lower = memory.content.lower()
            
            for keyword in keywords:
                # 检查是否有相似的词
                for word in content_lower.split():
                    if self._is_similar(keyword, word, tolerance):
                        score += 0.5
            
            if score > 0:
                score = min(1.0, score / len(keywords))
                results.append(SearchResult(
                    memory=memory,
                    score=score,
                    distance=1.0 - score,
                    source="fuzzy"
                ))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:top_k]
    
    def _is_similar(self, word1: str, word2: str, tolerance: int) -> bool:
        """
        判断两个词是否相似（简化版）
        
        基于长度和公共字符
        """
        if word1 == word2:
            return True
        
        if abs(len(word1) - len(word2)) > tolerance:
            return False
        
        # 计算公共字符
        common = set(word1) & set(word2)
        min_len = min(len(word1), len(word2))
        
        return len(common) >= min_len - tolerance


# 全局实例
_keyword_searcher = None


def get_keyword_searcher(sqlite_store: Optional[SQLiteStore] = None) -> KeywordSearcher:
    """获取全局关键词检索器实例"""
    global _keyword_searcher
    if _keyword_searcher is None:
        _keyword_searcher = KeywordSearcher(sqlite_store or SQLiteStore())
    return _keyword_searcher

