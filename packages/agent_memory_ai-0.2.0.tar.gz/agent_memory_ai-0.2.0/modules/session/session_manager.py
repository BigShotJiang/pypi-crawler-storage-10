"""
会话管理器

整合所有会话管理功能
"""
from typing import List, Dict, Optional
from datetime import datetime, timedelta

from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.session.session_summarizer import SessionSummarizer, SessionSummary
from agent_memory.modules.session.snapshot_manager import SnapshotManager, MemorySnapshot
from agent_memory.modules.session.consistency_checker import ConsistencyChecker, ConsistencyIssue


class SessionManager:
    """会话管理器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """
        初始化会话管理器
        
        Args:
            sqlite_store: SQLite存储
        """
        self.store = sqlite_store
        self.summarizer = SessionSummarizer()
        self.snapshot_manager = SnapshotManager(sqlite_store)
        self.consistency_checker = ConsistencyChecker(sqlite_store)
        
        # 会话摘要缓存
        self.session_summaries: Dict[str, SessionSummary] = {}
    
    def start_session(
        self,
        user_id: str,
        session_id: str
    ) -> Dict:
        """
        开始新会话
        
        Args:
            user_id: 用户ID
            session_id: 会话ID
        
        Returns:
            会话上下文
        """
        # 1. 加载记忆快照
        snapshot = self.snapshot_manager.create_snapshot(user_id)
        
        # 2. 检查一致性
        issues = self.consistency_checker.check_all(snapshot)
        
        # 3. 获取上次会话信息
        last_session_info = self._get_last_session_info(user_id)
        
        # 4. 生成提醒（如果需要）
        reminder = None
        if last_session_info:
            days_since_last = (
                datetime.now() - last_session_info['end_time']
            ).days
            
            # 如果有上次会话摘要，生成提醒
            if 'summary' in last_session_info:
                reminder = self.summarizer.create_session_reminder(
                    last_session_info['summary'],
                    days_since_last
                )
        
        # 5. 构建会话上下文
        context = {
            'session_id': session_id,
            'user_id': user_id,
            'snapshot': snapshot.to_dict(),
            'consistency_issues': [issue.to_dict() for issue in issues],
            'reminder': reminder,
            'last_session': last_session_info,
            'context': self.snapshot_manager.get_session_context(user_id)
        }
        
        return context
    
    def end_session(
        self,
        user_id: str,
        session_id: str,
        messages: List[Dict],
        start_time: datetime
    ) -> SessionSummary:
        """
        结束会话
        
        Args:
            user_id: 用户ID
            session_id: 会话ID
            messages: 消息列表
            start_time: 开始时间
        
        Returns:
            会话摘要
        """
        end_time = datetime.now()
        
        # 1. 生成会话摘要
        summary = self.summarizer.summarize_session(
            session_id=session_id,
            user_id=user_id,
            messages=messages,
            start_time=start_time,
            end_time=end_time
        )
        
        # 2. 缓存摘要
        self.session_summaries[session_id] = summary
        
        # 3. 更新记忆快照
        self.snapshot_manager.update_snapshot_with_session(
            user_id=user_id,
            session_summary=summary.summary,
            new_topics=summary.key_topics,
            new_tasks=summary.pending_tasks
        )
        
        # 4. 保存会话记录到数据库
        self._save_session_record(summary)
        
        return summary
    
    def get_session_summary(self, session_id: str) -> Optional[SessionSummary]:
        """
        获取会话摘要
        
        Args:
            session_id: 会话ID
        
        Returns:
            会话摘要
        """
        return self.session_summaries.get(session_id)
    
    def get_session_context(self, user_id: str) -> Dict:
        """
        获取会话上下文（简化版）
        
        Args:
            user_id: 用户ID
        
        Returns:
            上下文字典
        """
        return self.snapshot_manager.get_session_context(user_id)
    
    def check_consistency(self, user_id: str) -> List[ConsistencyIssue]:
        """
        检查用户记忆一致性
        
        Args:
            user_id: 用户ID
        
        Returns:
            问题列表
        """
        snapshot = self.snapshot_manager.create_snapshot(user_id)
        return self.consistency_checker.check_all(snapshot)
    
    def resolve_consistency_issues(
        self,
        user_id: str,
        auto_resolve: bool = False
    ) -> Dict:
        """
        解决一致性问题
        
        Args:
            user_id: 用户ID
            auto_resolve: 是否自动解决
        
        Returns:
            解决结果
        """
        issues = self.check_consistency(user_id)
        return self.consistency_checker.resolve_issues(issues, auto_resolve)
    
    def get_user_progress(self, user_id: str) -> Dict:
        """
        获取用户进展概况
        
        Args:
            user_id: 用户ID
        
        Returns:
            进展信息
        """
        # 获取当前快照
        current_snapshot = self.snapshot_manager.create_snapshot(user_id)
        
        # 获取用户会话历史
        sessions = self._get_user_sessions(user_id)
        
        # 计算进展
        return {
            'total_memories': current_snapshot.stats['total_memories'],
            'core_memories': len(current_snapshot.core_memories),
            'total_sessions': len(sessions),
            'recent_topics': current_snapshot.recent_topics,
            'pending_tasks': current_snapshot.pending_tasks,
            'avg_importance': current_snapshot.stats['avg_importance'],
            'last_active': sessions[-1]['end_time'] if sessions else None
        }
    
    def _get_last_session_info(self, user_id: str) -> Optional[Dict]:
        """
        获取上次会话信息
        
        Args:
            user_id: 用户ID
        
        Returns:
            会话信息
        """
        # 从数据库获取最近的会话记录
        session = self.store.get_session(user_id)
        
        if session:
            # 尝试获取摘要
            summary = self.session_summaries.get(session.id)
            
            return {
                'session_id': session.id,
                'start_time': session.start_time,
                'end_time': session.end_time,
                'summary': summary
            }
        
        return None
    
    def _save_session_record(self, summary: SessionSummary):
        """
        保存会话记录到数据库
        
        Args:
            summary: 会话摘要
        """
        # 使用已有的session存储
        # 注意：这需要在MemorySession中添加更多字段
        # 这里简化处理，实际可能需要扩展数据模型
        
        # 构建session数据
        session_data = {
            'id': summary.session_id,
            'user_id': summary.user_id,
            'start_time': summary.start_time,
            'end_time': summary.end_time,
            'summary': summary.summary,
            'metadata': summary.to_dict()
        }
        
        # 这里可以调用store的方法保存
        # 由于当前session model可能不包含所有字段
        # 所以这里做简化处理
        pass
    
    def _get_user_sessions(self, user_id: str) -> List[Dict]:
        """
        获取用户所有会话
        
        Args:
            user_id: 用户ID
        
        Returns:
            会话列表
        """
        # 获取最近的会话
        sessions = self.store.get_recent_sessions(user_id, limit=10)
        
        return [
            {
                'session_id': s.id,
                'start_time': s.start_time,
                'end_time': s.end_time
            }
            for s in sessions
        ]
    
    def generate_session_report(
        self,
        user_id: str,
        days: int = 7
    ) -> Dict:
        """
        生成会话报告
        
        Args:
            user_id: 用户ID
            days: 统计天数
        
        Returns:
            报告
        """
        # 获取时间范围内的会话
        cutoff_date = datetime.now() - timedelta(days=days)
        sessions = self._get_user_sessions(user_id)
        
        recent_sessions = [
            s for s in sessions
            if s['end_time'] >= cutoff_date
        ]
        
        # 获取快照
        snapshot = self.snapshot_manager.create_snapshot(user_id)
        
        # 生成报告
        return {
            'period': f'{days}天',
            'session_count': len(recent_sessions),
            'total_memories': snapshot.stats['total_memories'],
            'recent_topics': snapshot.recent_topics,
            'pending_tasks': snapshot.pending_tasks,
            'avg_importance': snapshot.stats['avg_importance'],
            'memory_growth': self._calculate_memory_growth(user_id, days)
        }
    
    def _calculate_memory_growth(self, user_id: str, days: int) -> int:
        """
        计算记忆增长数
        
        Args:
            user_id: 用户ID
            days: 天数
        
        Returns:
            增长数量
        """
        cutoff_date = datetime.now() - timedelta(days=days)
        all_memories = self.store.get_memories_by_user(user_id)
        
        recent_memories = [
            m for m in all_memories
            if m.created_at >= cutoff_date
        ]
        
        return len(recent_memories)

