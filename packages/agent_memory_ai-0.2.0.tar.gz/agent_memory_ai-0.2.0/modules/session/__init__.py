"""
会话管理模块

提供跨会话的一致性管理：
- 会话摘要
- 记忆快照
- 上下文恢复
- 一致性检查
"""

from .session_summarizer import SessionSummarizer
from .snapshot_manager import SnapshotManager
from .consistency_checker import ConsistencyChecker
from .session_manager import SessionManager

__all__ = [
    'SessionSummarizer',
    'SnapshotManager',
    'ConsistencyChecker',
    'SessionManager',
]

