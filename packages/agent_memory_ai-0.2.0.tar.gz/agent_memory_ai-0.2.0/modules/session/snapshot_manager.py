"""
记忆快照管理器

负责创建和管理用户记忆快照
"""
from typing import List, Dict, Optional
from datetime import datetime
from dataclasses import dataclass, field
import json

from agent_memory.core.memory import Memory, MemoryType
from agent_memory.storage.sqlite_store import SQLiteStore


@dataclass
class MemorySnapshot:
    """记忆快照"""
    user_id: str
    snapshot_time: datetime
    
    # 核心记忆
    core_memories: List[Memory] = field(default_factory=list)
    
    # 最近话题
    recent_topics: List[str] = field(default_factory=list)
    
    # 待办任务
    pending_tasks: List[str] = field(default_factory=list)
    
    # 上次会话摘要
    last_session_summary: Optional[str] = None
    
    # 用户偏好
    preferences: Dict = field(default_factory=dict)
    
    # 对话风格
    conversation_style: Dict = field(default_factory=dict)
    
    # 统计信息
    stats: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'user_id': self.user_id,
            'snapshot_time': self.snapshot_time.isoformat(),
            'core_memories': [
                {
                    'id': m.id,
                    'content': m.content,
                    'importance': m.importance,
                    'type': m.memory_type.value
                }
                for m in self.core_memories
            ],
            'recent_topics': self.recent_topics,
            'pending_tasks': self.pending_tasks,
            'last_session_summary': self.last_session_summary,
            'preferences': self.preferences,
            'conversation_style': self.conversation_style,
            'stats': self.stats
        }
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class SnapshotManager:
    """记忆快照管理器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """
        初始化快照管理器
        
        Args:
            sqlite_store: SQLite存储
        """
        self.store = sqlite_store
    
    def create_snapshot(self, user_id: str) -> MemorySnapshot:
        """
        创建记忆快照
        
        Args:
            user_id: 用户ID
        
        Returns:
            记忆快照
        """
        # 获取所有记忆
        all_memories = self.store.get_memories_by_user(user_id)
        
        # 提取核心记忆（重要性高或核心类型）
        core_memories = [
            m for m in all_memories
            if m.memory_type == MemoryType.CORE or m.importance >= 0.7
        ]
        
        # 提取最近话题（从最近的记忆中）
        recent_topics = self._extract_recent_topics(all_memories)
        
        # 提取待办任务
        pending_tasks = self._extract_pending_tasks(all_memories)
        
        # 获取用户资料
        user_profile = self.store.get_profile(user_id)
        preferences = user_profile.preferences if user_profile else {}
        
        # 统计信息
        stats = self._calculate_stats(all_memories)
        
        return MemorySnapshot(
            user_id=user_id,
            snapshot_time=datetime.now(),
            core_memories=core_memories[:10],  # 最多10个核心记忆
            recent_topics=recent_topics[:5],   # 最多5个最近话题
            pending_tasks=pending_tasks[:5],   # 最多5个待办
            preferences=preferences,
            stats=stats
        )
    
    def load_snapshot(
        self,
        user_id: str,
        snapshot_time: Optional[datetime] = None
    ) -> Optional[MemorySnapshot]:
        """
        加载记忆快照
        
        Args:
            user_id: 用户ID
            snapshot_time: 快照时间（None表示最新）
        
        Returns:
            记忆快照
        """
        # 默认创建最新快照
        return self.create_snapshot(user_id)
    
    def get_session_context(self, user_id: str) -> Dict:
        """
        获取会话上下文
        
        Args:
            user_id: 用户ID
        
        Returns:
            会话上下文字典
        """
        snapshot = self.create_snapshot(user_id)
        
        return {
            'user_profile': {
                'core_memories': [m.content for m in snapshot.core_memories[:3]],
                'preferences': snapshot.preferences
            },
            'recent_topics': snapshot.recent_topics,
            'pending_tasks': snapshot.pending_tasks,
            'last_session_summary': snapshot.last_session_summary,
            'conversation_style': snapshot.conversation_style
        }
    
    def update_snapshot_with_session(
        self,
        user_id: str,
        session_summary: str,
        new_topics: List[str],
        new_tasks: List[str]
    ) -> MemorySnapshot:
        """
        用会话信息更新快照
        
        Args:
            user_id: 用户ID
            session_summary: 会话摘要
            new_topics: 新话题
            new_tasks: 新任务
        
        Returns:
            更新后的快照
        """
        snapshot = self.create_snapshot(user_id)
        
        # 更新最后会话摘要
        snapshot.last_session_summary = session_summary
        
        # 合并新话题（保持最近的）
        all_topics = new_topics + snapshot.recent_topics
        snapshot.recent_topics = list(dict.fromkeys(all_topics))[:5]  # 去重并保留5个
        
        # 合并新任务
        all_tasks = new_tasks + snapshot.pending_tasks
        snapshot.pending_tasks = list(dict.fromkeys(all_tasks))[:5]
        
        return snapshot
    
    def _extract_recent_topics(self, memories: List[Memory]) -> List[str]:
        """
        从记忆中提取最近话题
        
        Args:
            memories: 记忆列表
        
        Returns:
            话题列表
        """
        # 按时间排序
        sorted_memories = sorted(
            memories,
            key=lambda m: m.created_at,
            reverse=True
        )
        
        # 从最近的记忆标签中提取话题
        topics = []
        for memory in sorted_memories[:20]:  # 查看最近20条记忆
            topics.extend(memory.tags)
        
        # 去重并返回最常见的
        from collections import Counter
        topic_counts = Counter(topics)
        return [topic for topic, _ in topic_counts.most_common(5)]
    
    def _extract_pending_tasks(self, memories: List[Memory]) -> List[str]:
        """
        从记忆中提取待办任务
        
        Args:
            memories: 记忆列表
        
        Returns:
            任务列表
        """
        tasks = []
        
        # 任务关键词
        task_keywords = ['待办', '需要', '要做', '未完成', '计划']
        
        for memory in memories:
            # 检查内容是否包含任务关键词
            for keyword in task_keywords:
                if keyword in memory.content:
                    # 检查是否有标记为未完成
                    if not memory.metadata.get('completed', False):
                        tasks.append(memory.content)
                        break
        
        return tasks[:5]
    
    def _calculate_stats(self, memories: List[Memory]) -> Dict:
        """
        计算统计信息
        
        Args:
            memories: 记忆列表
        
        Returns:
            统计字典
        """
        if not memories:
            return {
                'total_memories': 0,
                'by_type': {},
                'avg_importance': 0.0,
                'total_access': 0
            }
        
        # 按类型统计
        type_counts = {}
        for memory in memories:
            type_key = memory.memory_type.value
            type_counts[type_key] = type_counts.get(type_key, 0) + 1
        
        # 计算平均重要性
        avg_importance = sum(m.importance for m in memories) / len(memories)
        
        # 总访问次数
        total_access = sum(m.access_count for m in memories)
        
        return {
            'total_memories': len(memories),
            'by_type': type_counts,
            'avg_importance': round(avg_importance, 3),
            'total_access': total_access
        }
    
    def compare_snapshots(
        self,
        snapshot1: MemorySnapshot,
        snapshot2: MemorySnapshot
    ) -> Dict:
        """
        比较两个快照的差异
        
        Args:
            snapshot1: 快照1（旧）
            snapshot2: 快照2（新）
        
        Returns:
            差异字典
        """
        # 记忆数量变化
        memory_count_change = (
            snapshot2.stats['total_memories'] -
            snapshot1.stats['total_memories']
        )
        
        # 新增话题
        new_topics = [
            t for t in snapshot2.recent_topics
            if t not in snapshot1.recent_topics
        ]
        
        # 新增任务
        new_tasks = [
            t for t in snapshot2.pending_tasks
            if t not in snapshot1.pending_tasks
        ]
        
        # 完成的任务（在旧快照中但不在新快照中）
        completed_tasks = [
            t for t in snapshot1.pending_tasks
            if t not in snapshot2.pending_tasks
        ]
        
        return {
            'memory_count_change': memory_count_change,
            'new_topics': new_topics,
            'new_tasks': new_tasks,
            'completed_tasks': completed_tasks,
            'importance_change': (
                snapshot2.stats['avg_importance'] -
                snapshot1.stats['avg_importance']
            )
        }

