"""
会话摘要生成器

负责生成会话摘要和提取关键信息
"""
from typing import List, Dict, Optional
from datetime import datetime
from dataclasses import dataclass

from agent_memory.utils.llm_client import LLMClient
from agent_memory.utils.text_utils import TextProcessor


@dataclass
class SessionSummary:
    """会话摘要"""
    session_id: str
    user_id: str
    start_time: datetime
    end_time: datetime
    summary: str
    key_topics: List[str]
    decisions: List[str]
    pending_tasks: List[str]
    sentiment: str  # positive, neutral, negative
    interaction_count: int
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'session_id': self.session_id,
            'user_id': self.user_id,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'summary': self.summary,
            'key_topics': self.key_topics,
            'decisions': self.decisions,
            'pending_tasks': self.pending_tasks,
            'sentiment': self.sentiment,
            'interaction_count': self.interaction_count
        }


class SessionSummarizer:
    """会话摘要生成器"""
    
    def __init__(self, llm_client: Optional[LLMClient] = None):
        """
        初始化摘要生成器
        
        Args:
            llm_client: LLM客户端（可选）
        """
        self.llm_client = llm_client or LLMClient()
        self.text_processor = TextProcessor()
    
    def summarize_session(
        self,
        session_id: str,
        user_id: str,
        messages: List[Dict],
        start_time: datetime,
        end_time: Optional[datetime] = None
    ) -> SessionSummary:
        """
        生成会话摘要
        
        Args:
            session_id: 会话ID
            user_id: 用户ID
            messages: 消息列表 [{"role": "user/assistant", "content": "..."}]
            start_time: 开始时间
            end_time: 结束时间
        
        Returns:
            会话摘要
        """
        if end_time is None:
            end_time = datetime.now()
        
        # 提取关键主题
        key_topics = self.extract_topics(messages)
        
        # 提取决策
        decisions = self.extract_decisions(messages)
        
        # 提取待办任务
        pending_tasks = self.extract_pending_tasks(messages)
        
        # 生成摘要文本
        summary = self._generate_summary_text(messages, key_topics, decisions)
        
        # 分析情绪
        sentiment = self._analyze_sentiment(messages)
        
        return SessionSummary(
            session_id=session_id,
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            summary=summary,
            key_topics=key_topics,
            decisions=decisions,
            pending_tasks=pending_tasks,
            sentiment=sentiment,
            interaction_count=len(messages)
        )
    
    def extract_topics(self, messages: List[Dict]) -> List[str]:
        """
        提取会话关键主题
        
        Args:
            messages: 消息列表
        
        Returns:
            主题列表
        """
        # 合并所有消息内容
        all_text = " ".join([msg.get('content', '') for msg in messages])
        
        # 尝试使用LLM提取主题
        if self.llm_client:
            try:
                prompt = f"""从以下对话中提取3-5个关键主题（用逗号分隔）：

对话内容：
{all_text[:1000]}  # 限制长度

主题："""
                
                response = self.llm_client.chat_with_system("你是一个话题提取助手", prompt, max_tokens=100)
                if response:
                    topics = [t.strip() for t in response.split(',')]
                    return topics[:5]  # 最多5个
            except Exception as e:
                print(f"LLM提取主题失败: {e}")
        
        # 降级策略：使用关键词提取
        keywords = self.text_processor.extract_keywords(all_text, top_k=5)
        return keywords
    
    def extract_decisions(self, messages: List[Dict]) -> List[str]:
        """
        提取会话中的决策
        
        Args:
            messages: 消息列表
        
        Returns:
            决策列表
        """
        decisions = []
        
        # 决策关键词
        decision_keywords = [
            '决定', '计划', '打算', '准备', '要做', '会做',
            'decide', 'plan', 'will', 'going to'
        ]
        
        for msg in messages:
            if msg.get('role') == 'user':
                content = msg.get('content', '').lower()
                
                # 检查是否包含决策关键词
                for keyword in decision_keywords:
                    if keyword in content:
                        # 提取包含关键词的句子
                        sentences = content.split('。')
                        for sent in sentences:
                            if keyword in sent:
                                decisions.append(sent.strip())
                                break
                        break
        
        return decisions[:5]  # 最多5个
    
    def extract_pending_tasks(self, messages: List[Dict]) -> List[str]:
        """
        提取待办任务
        
        Args:
            messages: 消息列表
        
        Returns:
            待办任务列表
        """
        tasks = []
        
        # 任务关键词
        task_keywords = [
            '待办', '需要', '要完成', '未完成', '下次',
            'todo', 'need to', 'have to', 'should', 'next time'
        ]
        
        for msg in messages:
            content = msg.get('content', '').lower()
            
            # 检查是否包含任务关键词
            for keyword in task_keywords:
                if keyword in content:
                    # 提取任务描述
                    sentences = content.split('。')
                    for sent in sentences:
                        if keyword in sent:
                            tasks.append(sent.strip())
                            break
                    break
        
        return tasks[:5]  # 最多5个
    
    def _generate_summary_text(
        self,
        messages: List[Dict],
        key_topics: List[str],
        decisions: List[str]
    ) -> str:
        """
        生成摘要文本
        
        Args:
            messages: 消息列表
            key_topics: 关键主题
            decisions: 决策列表
        
        Returns:
            摘要文本
        """
        # 尝试使用LLM生成摘要
        if self.llm_client and len(messages) > 0:
            try:
                # 构建对话文本
                conversation = "\n".join([
                    f"{msg['role']}: {msg['content']}"
                    for msg in messages[:10]  # 限制消息数量
                ])
                
                prompt = f"""请用一两句话总结以下对话：

{conversation}

总结："""
                
                response = self.llm_client.chat_with_system("你是一个对话摘要助手", prompt, max_tokens=150)
                if response:
                    return response.strip()
            except Exception as e:
                print(f"LLM生成摘要失败: {e}")
        
        # 降级策略：基于规则生成摘要
        topics_str = "、".join(key_topics[:3]) if key_topics else "多个话题"
        decisions_str = f"，做出了{len(decisions)}个决策" if decisions else ""
        
        return f"用户讨论了{topics_str}{decisions_str}。"
    
    def _analyze_sentiment(self, messages: List[Dict]) -> str:
        """
        分析会话情绪
        
        Args:
            messages: 消息列表
        
        Returns:
            情绪 (positive, neutral, negative)
        """
        # 简单的情绪关键词检测
        positive_keywords = ['谢谢', '太好了', '很好', '满意', '开心', 'thank', 'great', 'good', 'happy']
        negative_keywords = ['不好', '失望', '糟糕', '问题', '错误', 'bad', 'disappointed', 'problem', 'error']
        
        positive_count = 0
        negative_count = 0
        
        for msg in messages:
            content = msg.get('content', '').lower()
            
            for keyword in positive_keywords:
                if keyword in content:
                    positive_count += 1
            
            for keyword in negative_keywords:
                if keyword in content:
                    negative_count += 1
        
        # 判断情绪
        if positive_count > negative_count:
            return 'positive'
        elif negative_count > positive_count:
            return 'negative'
        else:
            return 'neutral'
    
    def create_session_reminder(
        self,
        summary: SessionSummary,
        days_since_last: int
    ) -> Optional[str]:
        """
        创建会话提醒文本
        
        Args:
            summary: 会话摘要
            days_since_last: 距离上次会话的天数
        
        Returns:
            提醒文本（如果需要）
        """
        # 如果有待办任务且距离上次会话不久，生成提醒
        if summary.pending_tasks and days_since_last <= 3:
            tasks_str = "、".join(summary.pending_tasks[:2])
            return f"上次我们讨论了{summary.key_topics[0] if summary.key_topics else '一些话题'}，还有一些待办事项：{tasks_str}"
        
        # 如果有重要决策，也提醒
        if summary.decisions and days_since_last <= 7:
            return f"上次您提到{summary.decisions[0]}"
        
        return None

