"""
一致性检查器

检查和解决记忆的一致性问题
"""
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.session.snapshot_manager import MemorySnapshot


class IssueType(Enum):
    """问题类型"""
    TIMELINE = "timeline"          # 时间线不一致
    FACTUAL = "factual"           # 事实矛盾
    PREFERENCE = "preference"     # 偏好变化
    DUPLICATE = "duplicate"       # 重复内容


class IssueSeverity(Enum):
    """问题严重程度"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class ConsistencyIssue:
    """一致性问题"""
    issue_type: IssueType
    severity: IssueSeverity
    description: str
    affected_memories: List[str]  # 受影响的记忆ID
    suggested_action: str
    details: Dict = None
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'issue_type': self.issue_type.value,
            'severity': self.severity.value,
            'description': self.description,
            'affected_memories': self.affected_memories,
            'suggested_action': self.suggested_action,
            'details': self.details or {}
        }


class ConsistencyChecker:
    """一致性检查器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """
        初始化一致性检查器
        
        Args:
            sqlite_store: SQLite存储
        """
        self.store = sqlite_store
    
    def check_all(self, snapshot: MemorySnapshot) -> List[ConsistencyIssue]:
        """
        执行所有一致性检查
        
        Args:
            snapshot: 记忆快照
        
        Returns:
            问题列表
        """
        issues = []
        
        # 1. 检查时间线一致性
        timeline_issues = self.check_timeline(snapshot)
        issues.extend(timeline_issues)
        
        # 2. 检查事实一致性
        fact_issues = self.check_facts(snapshot)
        issues.extend(fact_issues)
        
        # 3. 检查偏好一致性
        preference_issues = self.check_preferences(snapshot)
        issues.extend(preference_issues)
        
        return issues
    
    def check_timeline(self, snapshot: MemorySnapshot) -> List[ConsistencyIssue]:
        """
        检查时间线一致性
        
        检测：
        - 时间顺序矛盾
        - 不可能的时间间隔
        
        Args:
            snapshot: 记忆快照
        
        Returns:
            问题列表
        """
        issues = []
        
        # 获取用户所有记忆
        all_memories = self.store.get_memories_by_user(snapshot.user_id)
        
        # 按时间排序
        sorted_memories = sorted(all_memories, key=lambda m: m.created_at)
        
        # 检查时间顺序
        for i in range(len(sorted_memories) - 1):
            current = sorted_memories[i]
            next_mem = sorted_memories[i + 1]
            
            # 检查是否有时间逻辑矛盾
            if self._has_temporal_conflict(current, next_mem):
                issues.append(ConsistencyIssue(
                    issue_type=IssueType.TIMELINE,
                    severity=IssueSeverity.MEDIUM,
                    description=f"记忆时间顺序可能存在矛盾",
                    affected_memories=[current.id, next_mem.id],
                    suggested_action="检查记忆的时间标记是否准确",
                    details={
                        'memory1': current.content[:50],
                        'memory2': next_mem.content[:50],
                        'time1': current.created_at.isoformat(),
                        'time2': next_mem.created_at.isoformat()
                    }
                ))
        
        return issues
    
    def check_facts(self, snapshot: MemorySnapshot) -> List[ConsistencyIssue]:
        """
        检查事实一致性
        
        检测：
        - 矛盾的陈述
        - 冲突的信息
        
        Args:
            snapshot: 记忆快照
        
        Returns:
            问题列表
        """
        issues = []
        
        # 获取核心记忆
        core_memories = snapshot.core_memories
        
        # 检查两两之间是否有矛盾
        for i in range(len(core_memories)):
            for j in range(i + 1, len(core_memories)):
                mem1 = core_memories[i]
                mem2 = core_memories[j]
                
                # 检查是否矛盾
                if self._has_factual_conflict(mem1, mem2):
                    issues.append(ConsistencyIssue(
                        issue_type=IssueType.FACTUAL,
                        severity=IssueSeverity.HIGH,
                        description=f"发现矛盾的事实陈述",
                        affected_memories=[mem1.id, mem2.id],
                        suggested_action="验证并保留更可靠的记忆",
                        details={
                            'memory1': mem1.content,
                            'memory2': mem2.content
                        }
                    ))
        
        return issues
    
    def check_preferences(self, snapshot: MemorySnapshot) -> List[ConsistencyIssue]:
        """
        检查偏好一致性
        
        检测：
        - 偏好变化
        - 不一致的选择
        
        Args:
            snapshot: 记忆快照
        
        Returns:
            问题列表
        """
        issues = []
        
        # 获取用户所有记忆
        all_memories = self.store.get_memories_by_user(snapshot.user_id)
        
        # 查找包含偏好信息的记忆
        preference_memories = [
            m for m in all_memories
            if self._contains_preference(m)
        ]
        
        # 检查偏好变化
        if len(preference_memories) >= 2:
            # 按时间排序
            sorted_prefs = sorted(preference_memories, key=lambda m: m.created_at)
            
            for i in range(len(sorted_prefs) - 1):
                current = sorted_prefs[i]
                next_pref = sorted_prefs[i + 1]
                
                # 检查是否是偏好变化而非矛盾
                if self._is_preference_change(current, next_pref):
                    issues.append(ConsistencyIssue(
                        issue_type=IssueType.PREFERENCE,
                        severity=IssueSeverity.LOW,
                        description=f"检测到偏好变化",
                        affected_memories=[current.id, next_pref.id],
                        suggested_action="记录偏好演变，保留两者",
                        details={
                            'old_preference': current.content,
                            'new_preference': next_pref.content,
                            'change_time': next_pref.created_at.isoformat()
                        }
                    ))
        
        return issues
    
    def resolve_issues(
        self,
        issues: List[ConsistencyIssue],
        auto_resolve: bool = False
    ) -> Dict:
        """
        解决一致性问题
        
        Args:
            issues: 问题列表
            auto_resolve: 是否自动解决
        
        Returns:
            解决结果
        """
        result = {
            'total_issues': len(issues),
            'resolved': 0,
            'skipped': 0,
            'actions': []
        }
        
        for issue in issues:
            if auto_resolve:
                # 根据问题类型和严重程度自动处理
                action = self._auto_resolve_issue(issue)
                if action:
                    result['resolved'] += 1
                    result['actions'].append(action)
                else:
                    result['skipped'] += 1
            else:
                # 只记录建议，不自动解决
                result['actions'].append({
                    'issue': issue.to_dict(),
                    'status': 'pending',
                    'suggestion': issue.suggested_action
                })
        
        return result
    
    def _has_temporal_conflict(self, mem1: Memory, mem2: Memory) -> bool:
        """
        检查两个记忆是否有时间冲突
        
        Args:
            mem1: 记忆1
            mem2: 记忆2
        
        Returns:
            是否有冲突
        """
        # 简单检查：如果内容提到"之前"、"之后"等时间关系
        # 但创建时间相反，则可能有冲突
        
        # 检查mem2是否提到"之前"但时间更晚
        if '之前' in mem2.content and mem2.created_at > mem1.created_at:
            # 检查是否真的在说mem1
            if any(word in mem2.content for word in mem1.content.split()[:3]):
                return True
        
        return False
    
    def _has_factual_conflict(self, mem1: Memory, mem2: Memory) -> bool:
        """
        检查两个记忆是否有事实冲突
        
        Args:
            mem1: 记忆1
            mem2: 记忆2
        
        Returns:
            是否有冲突
        """
        # 简单的矛盾检测：查找否定词对
        content1_lower = mem1.content.lower()
        content2_lower = mem2.content.lower()
        
        # 提取关键词
        words1 = set(content1_lower.split())
        words2 = set(content2_lower.split())
        
        # 共同关键词
        common_words = words1 & words2
        
        # 如果有共同关键词，检查是否有否定关系
        if len(common_words) >= 2:
            # 检查"喜欢" vs "不喜欢"
            if ('喜欢' in content1_lower and '不喜欢' in content2_lower) or \
               ('不喜欢' in content1_lower and '喜欢' in content2_lower):
                return True
            
            # 检查其他否定模式
            negation_pairs = [
                ('是', '不是'),
                ('能', '不能'),
                ('会', '不会'),
                ('要', '不要')
            ]
            
            for pos, neg in negation_pairs:
                if (pos in content1_lower and neg in content2_lower) or \
                   (neg in content1_lower and pos in content2_lower):
                    # 确保有共同主题
                    if len(common_words) >= 3:
                        return True
        
        return False
    
    def _contains_preference(self, memory: Memory) -> bool:
        """
        检查记忆是否包含偏好信息
        
        Args:
            memory: 记忆
        
        Returns:
            是否包含偏好
        """
        # 偏好关键词
        preference_keywords = [
            '喜欢', '不喜欢', '偏好', '喜好', '倾向',
            '更喜欢', '讨厌', '爱', '不喜',
            'like', 'dislike', 'prefer', 'love', 'hate'
        ]
        
        content_lower = memory.content.lower()
        return any(keyword in content_lower for keyword in preference_keywords)
    
    def _is_preference_change(self, old_mem: Memory, new_mem: Memory) -> bool:
        """
        判断是否是偏好变化（而非矛盾）
        
        Args:
            old_mem: 旧记忆
            new_mem: 新记忆
        
        Returns:
            是否是偏好变化
        """
        # 如果有明显的时间间隔（如>30天），更可能是偏好变化
        time_diff = (new_mem.created_at - old_mem.created_at).days
        
        if time_diff > 30:
            # 检查是否有"现在"、"最近"等词暗示变化
            change_indicators = ['现在', '最近', '后来', '改变', '变成']
            if any(word in new_mem.content for word in change_indicators):
                return True
        
        return False
    
    def _auto_resolve_issue(self, issue: ConsistencyIssue) -> Optional[Dict]:
        """
        自动解决问题
        
        Args:
            issue: 问题
        
        Returns:
            解决动作
        """
        # 根据问题类型决定处理方式
        if issue.issue_type == IssueType.PREFERENCE:
            # 偏好变化：标记为演变，保留两者
            return {
                'action': 'mark_as_evolution',
                'issue_type': issue.issue_type.value,
                'affected': issue.affected_memories,
                'note': '标记为偏好演变'
            }
        
        elif issue.severity == IssueSeverity.LOW:
            # 低严重性：仅记录
            return {
                'action': 'log_only',
                'issue_type': issue.issue_type.value,
                'affected': issue.affected_memories,
                'note': '已记录，不需要立即处理'
            }
        
        # 高严重性问题需要人工介入
        return None

