"""
重要性评分器

计算记忆的重要性分数，用于决定记忆的层次和优先级
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import math

from agent_memory.core.memory import Memory, MemoryType, MemoryCategory
from agent_memory.storage.sqlite_store import SQLiteStore
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from modules.formation.extractor import Entity, Fact, Opinion


class ImportanceScorer:
    """
    重要性评分器
    
    基于多个维度计算记忆的重要性分数
    """
    
    def __init__(self, store: Optional[SQLiteStore] = None):
        self.store = store or SQLiteStore()
        self.embedding_gen = None  # 延迟加载
    
    def calculate_importance(
        self,
        content: str,
        user_id: str,
        extracted_info: Dict[str, Any] = None,
        context: Dict[str, Any] = None
    ) -> float:
        """
        计算综合重要性分数
        
        考虑因素：
        1. 新颖性 - 是否为新信息
        2. 相关性 - 与用户目标的相关程度
        3. 情绪强度 - 情感表达的强烈程度
        4. 频率 - 提及次数
        5. 明确性 - 信息的明确程度
        
        Args:
            content: 记忆内容
            user_id: 用户ID
            extracted_info: 提取的信息（实体、事实、观点）
            context: 上下文信息
        
        Returns:
            重要性分数 (0-1)
        """
        scores = {}
        
        # 1. 新颖性评分
        scores['novelty'] = self.calculate_novelty(content, user_id)
        
        # 2. 相关性评分
        scores['relevance'] = self.calculate_relevance(content, user_id, context)
        
        # 3. 情绪评分
        scores['emotion'] = self.calculate_emotion_score(extracted_info)
        
        # 4. 频率评分
        scores['frequency'] = self.calculate_frequency_score(content, user_id)
        
        # 5. 明确性评分
        scores['clarity'] = self.calculate_clarity_score(content, extracted_info)
        
        # 6. 信息密度评分
        scores['density'] = self.calculate_density_score(content, extracted_info)
        
        # 加权平均
        weights = {
            'novelty': 0.25,      # 新颖性权重
            'relevance': 0.20,    # 相关性权重
            'emotion': 0.15,      # 情绪权重
            'frequency': 0.15,    # 频率权重
            'clarity': 0.15,      # 明确性权重
            'density': 0.10       # 信息密度权重
        }
        
        importance = sum(scores[k] * weights[k] for k in weights.keys())
        
        # 限制在0-1范围内
        importance = max(0.0, min(1.0, importance))
        
        return importance
    
    def calculate_novelty(self, content: str, user_id: str) -> float:
        """
        计算新颖性分数
        
        通过与现有记忆对比，判断是否为新信息
        """
        try:
            # 获取用户的最近记忆
            existing_memories = self.store.get_memories_by_user(user_id, limit=50)
            
            if len(existing_memories) == 0:
                return 1.0  # 第一条记忆，完全新颖
            
            # 简单的文本相似度检查
            max_similarity = 0.0
            for memory in existing_memories:
                similarity = self._text_similarity(content, memory.content)
                max_similarity = max(max_similarity, similarity)
            
            # 相似度越高，新颖性越低
            novelty = 1.0 - max_similarity
            
            return novelty
        
        except Exception as e:
            print(f"新颖性计算失败: {e}")
            return 0.5  # 默认中等新颖性
    
    def calculate_relevance(
        self,
        content: str,
        user_id: str,
        context: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        计算相关性分数
        
        基于用户画像和当前上下文
        """
        try:
            profile = self.store.get_profile(user_id)
            
            if not profile:
                return 0.5  # 没有画像，默认中等相关性
            
            relevance_score = 0.5  # 基础分数
            
            # 1. 与用户领域的相关性
            if profile.domain and profile.domain in content:
                relevance_score += 0.2
            
            # 2. 与用户偏好的相关性
            if profile.preferences:
                for key, value in profile.preferences.items():
                    if isinstance(value, str) and value.lower() in content.lower():
                        relevance_score += 0.1
                    elif isinstance(value, list):
                        for item in value:
                            if str(item).lower() in content.lower():
                                relevance_score += 0.05
            
            # 3. 与当前上下文的相关性
            if context and context.get('current_topic'):
                if context['current_topic'] in content:
                    relevance_score += 0.2
            
            return min(1.0, relevance_score)
        
        except Exception as e:
            print(f"相关性计算失败: {e}")
            return 0.5
    
    def calculate_emotion_score(self, extracted_info: Optional[Dict[str, Any]] = None) -> float:
        """
        计算情绪分数
        
        基于观点的情感强度
        """
        if not extracted_info or 'opinions' not in extracted_info:
            return 0.3  # 没有明显情绪
        
        opinions: List[Opinion] = extracted_info['opinions']
        
        if len(opinions) == 0:
            return 0.3
        
        # 计算平均情感强度
        avg_intensity = sum(op.intensity for op in opinions) / len(opinions)
        
        # 强烈的情绪（正面或负面）都表示重要
        emotion_score = avg_intensity
        
        return emotion_score
    
    def calculate_frequency_score(self, content: str, user_id: str) -> float:
        """
        计算频率分数
        
        某个主题被频繁提及，说明重要
        """
        try:
            # 尝试提取关键词
            try:
                from utils.text_utils import extract_keywords
                keywords = extract_keywords(content, top_k=3)
            except:
                # 降级策略：简单提取长词
                words = content.split()
                keywords = [w for w in words if len(w) > 2][:3]
            
            if len(keywords) == 0:
                return 0.3
            
            # 统计这些关键词在历史记忆中的出现次数
            existing_memories = self.store.get_memories_by_user(user_id, limit=100)
            
            total_mentions = 0
            for keyword in keywords:
                for memory in existing_memories:
                    if keyword in memory.content:
                        total_mentions += 1
            
            # 归一化频率分数
            if len(existing_memories) == 0:
                return 0.3
            
            frequency_ratio = total_mentions / (len(existing_memories) * len(keywords))
            frequency_score = min(1.0, frequency_ratio * 2)  # 放大倍数
            
            return frequency_score
        
        except Exception as e:
            print(f"频率计算失败: {e}")
            return 0.3
    
    def calculate_clarity_score(
        self,
        content: str,
        extracted_info: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        计算明确性分数
        
        信息越明确、结构化程度越高，越重要
        """
        clarity_score = 0.3  # 基础分数
        
        # 1. 内容长度（适中的长度表示明确）
        length = len(content)
        if 20 <= length <= 200:
            clarity_score += 0.2
        elif 10 <= length < 20 or 200 < length <= 500:
            clarity_score += 0.1
        
        # 2. 提取到的结构化信息
        if extracted_info:
            entities = extracted_info.get('entities', [])
            facts = extracted_info.get('facts', [])
            opinions = extracted_info.get('opinions', [])
            
            # 有明确的实体
            if len(entities) > 0:
                clarity_score += 0.2
            
            # 有事实陈述
            if len(facts) > 0:
                clarity_score += 0.2
            
            # 有观点表达
            if len(opinions) > 0:
                clarity_score += 0.1
        
        return min(1.0, clarity_score)
    
    def calculate_density_score(
        self,
        content: str,
        extracted_info: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        计算信息密度分数
        
        单位文本中包含的信息量
        """
        if not extracted_info:
            return 0.3
        
        entities = extracted_info.get('entities', [])
        facts = extracted_info.get('facts', [])
        opinions = extracted_info.get('opinions', [])
        keywords = extracted_info.get('keywords', [])
        
        # 信息元素总数
        total_elements = len(entities) + len(facts) + len(opinions) + len(keywords)
        
        # 文本长度（字符数）
        text_length = len(content)
        
        if text_length == 0:
            return 0.0
        
        # 信息密度 = 信息元素数 / 文本长度 * 100
        density = (total_elements / text_length) * 100
        
        # 归一化到0-1
        # 假设密度在0.05-0.3之间为最佳
        if density >= 0.3:
            density_score = 1.0
        elif density >= 0.05:
            density_score = density / 0.3
        else:
            density_score = density / 0.05 * 0.3
        
        return min(1.0, density_score)
    
    def _text_similarity(self, text1: str, text2: str) -> float:
        """
        计算两个文本的相似度（简化版）
        
        实际应用中应使用向量相似度
        """
        try:
            # 尝试使用分词
            from utils.text_utils import segment
            words1 = set(segment(text1))
            words2 = set(segment(text2))
        except:
            # 降级策略：简单的字符级相似度
            words1 = set(text1)
            words2 = set(text2)
        
        if len(words1) == 0 or len(words2) == 0:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.0
    
    def adjust_importance_by_type(self, base_importance: float, memory_type: MemoryType) -> float:
        """
        根据记忆类型调整重要性
        
        某些类型的记忆天然具有更高或更低的重要性
        """
        adjustments = {
            MemoryType.CORE: 1.2,    # 核心记忆加成
            MemoryType.LONG: 1.1,    # 长期记忆加成
            MemoryType.MID: 1.0,     # 中期记忆不变
            MemoryType.SHORT: 0.9,   # 短期记忆略降
            MemoryType.WORK: 0.8     # 工作记忆降低
        }
        
        adjusted = base_importance * adjustments.get(memory_type, 1.0)
        return min(1.0, adjusted)
    
    def calculate_confidence(
        self,
        content: str,
        source_type: str,
        extracted_info: Optional[Dict[str, Any]] = None
    ) -> float:
        """
        计算置信度
        
        表示记忆内容的可靠程度
        """
        confidence = 0.5  # 基础置信度
        
        # 1. 来源类型影响置信度
        source_confidence = {
            'explicit': 0.9,   # 用户明确表述
            'inferred': 0.6,   # 系统推断
            'derived': 0.5     # 从其他记忆衍生
        }
        confidence = source_confidence.get(source_type, 0.5)
        
        # 2. 提取的信息质量
        if extracted_info:
            entities = extracted_info.get('entities', [])
            facts = extracted_info.get('facts', [])
            
            # 有高置信度的实体
            if entities:
                avg_entity_conf = sum(e.confidence for e in entities) / len(entities)
                confidence = (confidence + avg_entity_conf) / 2
            
            # 有高置信度的事实
            if facts:
                avg_fact_conf = sum(f.confidence for f in facts) / len(facts)
                confidence = (confidence + avg_fact_conf) / 2
        
        return min(1.0, confidence)


# 全局实例
_scorer = None


def get_scorer(store: Optional[SQLiteStore] = None) -> ImportanceScorer:
    """获取全局评分器实例"""
    global _scorer
    if _scorer is None:
        _scorer = ImportanceScorer(store)
    return _scorer

