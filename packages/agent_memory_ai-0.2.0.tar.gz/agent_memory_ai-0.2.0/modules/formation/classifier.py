"""
记忆分类器

自动判断记忆的类型（短期/中期/长期/核心）和维度（知识/经验/偏好等）
"""
from typing import Dict, Any, Optional, List
from datetime import datetime

from agent_memory.core.memory import MemoryType, MemoryCategory
from agent_memory.core.config import get_config
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from modules.formation.extractor import Entity, Fact, Opinion


class MemoryClassifier:
    """
    记忆分类器
    
    根据内容、重要性、上下文等自动分类记忆
    """
    
    def __init__(self):
        self.config = get_config()
        self.thresholds = self.config.memory_thresholds
    
    def classify_memory_type(
        self,
        importance: float,
        content: str,
        extracted_info: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> MemoryType:
        """
        分类记忆类型（时间层次）
        
        基于重要性分数和内容特征
        
        Args:
            importance: 重要性分数
            content: 记忆内容
            extracted_info: 提取的信息
            context: 上下文
        
        Returns:
            记忆类型
        """
        # 1. 基于重要性阈值
        if importance >= self.thresholds.get('core', 0.9):
            return MemoryType.CORE
        elif importance >= self.thresholds.get('long_term', 0.7):
            return MemoryType.LONG
        elif importance >= self.thresholds.get('mid_term', 0.5):
            return MemoryType.MID
        elif importance >= self.thresholds.get('short_term', 0.3):
            return MemoryType.SHORT
        else:
            return MemoryType.WORK
    
    def classify_category(
        self,
        content: str,
        extracted_info: Optional[Dict[str, Any]] = None
    ) -> MemoryCategory:
        """
        分类记忆维度（内容类型）
        
        基于内容特征和提取的信息
        
        Returns:
            记忆维度
        """
        if not extracted_info:
            return self._classify_by_keywords(content)
        
        entities = extracted_info.get('entities', [])
        facts = extracted_info.get('facts', [])
        opinions = extracted_info.get('opinions', [])
        
        # 评分系统
        scores = {
            MemoryCategory.KNOWLEDGE: 0,
            MemoryCategory.EXPERIENCE: 0,
            MemoryCategory.PREFERENCE: 0,
            MemoryCategory.CONTEXT: 0,
            MemoryCategory.REFLECTION: 0,
            MemoryCategory.META: 0
        }
        
        # 1. 基于观点判断偏好
        if len(opinions) > 0:
            scores[MemoryCategory.PREFERENCE] += 3 * len(opinions)
            
            # 强烈的观点可能是反思
            for opinion in opinions:
                if opinion.intensity > 0.7:
                    scores[MemoryCategory.REFLECTION] += 2
        
        # 2. 基于事实判断知识
        if len(facts) > 0:
            scores[MemoryCategory.KNOWLEDGE] += 3 * len(facts)
        
        # 3. 基于实体类型判断
        for entity in entities:
            if entity.type in ['concept', 'tool']:
                scores[MemoryCategory.KNOWLEDGE] += 2
            elif entity.type == 'project':
                scores[MemoryCategory.EXPERIENCE] += 2
            elif entity.type == 'person':
                scores[MemoryCategory.CONTEXT] += 1
        
        # 4. 基于关键词判断
        keyword_scores = self._score_by_keywords(content)
        for category, score in keyword_scores.items():
            scores[category] += score
        
        # 5. 返回得分最高的分类
        max_category = max(scores.items(), key=lambda x: x[1])
        
        # 如果所有得分都很低，使用关键词分类
        if max_category[1] < 2:
            return self._classify_by_keywords(content)
        
        return max_category[0]
    
    def _classify_by_keywords(self, content: str) -> MemoryCategory:
        """
        基于关键词的简单分类（降级策略）
        """
        content_lower = content.lower()
        
        # 偏好关键词
        preference_keywords = [
            '喜欢', '偏好', '倾向', '习惯', '风格', '想要', '希望',
            '不喜欢', '讨厌', '避免', '更愿意', '通常', '一般'
        ]
        if any(kw in content_lower for kw in preference_keywords):
            return MemoryCategory.PREFERENCE
        
        # 经验关键词
        experience_keywords = [
            '之前', '上次', '曾经', '遇到过', '经历', '做过', 
            '项目中', '工作中', '实践', '总结', '教训'
        ]
        if any(kw in content_lower for kw in experience_keywords):
            return MemoryCategory.EXPERIENCE
        
        # 反思关键词
        reflection_keywords = [
            '认为', '觉得', '价值观', '原则', '重视', '关注',
            '思考', '理解', '意识到', '发现', '成长'
        ]
        if any(kw in content_lower for kw in reflection_keywords):
            return MemoryCategory.REFLECTION
        
        # 情境关键词
        context_keywords = [
            '今天', '现在', '当前', '正在', '讨论', '聊天',
            '话题', '场景', '情况'
        ]
        if any(kw in content_lower for kw in context_keywords):
            return MemoryCategory.CONTEXT
        
        # 元记忆关键词
        meta_keywords = [
            '记住', '记录', '记忆', '忘记', '重要', '优先',
            '关联', '索引'
        ]
        if any(kw in content_lower for kw in meta_keywords):
            return MemoryCategory.META
        
        # 默认为知识
        return MemoryCategory.KNOWLEDGE
    
    def _score_by_keywords(self, content: str) -> Dict[MemoryCategory, int]:
        """
        基于关键词计算各维度的得分
        """
        content_lower = content.lower()
        scores = {cat: 0 for cat in MemoryCategory}
        
        # 定义关键词权重
        keyword_rules = {
            MemoryCategory.KNOWLEDGE: [
                ('学习', 2), ('知识', 2), ('了解', 1), ('掌握', 2),
                ('技术', 1), ('方法', 1), ('原理', 2), ('概念', 2)
            ],
            MemoryCategory.EXPERIENCE: [
                ('经验', 3), ('实践', 2), ('项目', 2), ('工作', 1),
                ('遇到', 1), ('处理', 1), ('解决', 1), ('完成', 1)
            ],
            MemoryCategory.PREFERENCE: [
                ('喜欢', 3), ('偏好', 3), ('倾向', 2), ('习惯', 2),
                ('风格', 2), ('不喜欢', 3), ('更愿意', 2)
            ],
            MemoryCategory.CONTEXT: [
                ('当前', 2), ('现在', 1), ('今天', 1), ('正在', 1),
                ('讨论', 1), ('话题', 1), ('情况', 1)
            ],
            MemoryCategory.REFLECTION: [
                ('认为', 2), ('思考', 2), ('理解', 2), ('意识到', 2),
                ('价值观', 3), ('原则', 3), ('重视', 2), ('关注', 2)
            ],
            MemoryCategory.META: [
                ('记住', 3), ('记录', 2), ('重要', 2), ('优先', 2),
                ('关联', 2), ('索引', 2)
            ]
        }
        
        for category, keywords in keyword_rules.items():
            for keyword, weight in keywords:
                if keyword in content_lower:
                    scores[category] += weight
        
        return scores
    
    def should_promote_to_core(
        self,
        content: str,
        importance: float,
        access_count: int,
        age_days: int
    ) -> bool:
        """
        判断是否应该晋升为核心记忆
        
        核心记忆的特征：
        1. 持续高重要性
        2. 被频繁访问
        3. 长期稳定
        4. 关于价值观、原则等
        """
        # 重要性必须很高
        if importance < 0.85:
            return False
        
        # 需要一定的时间验证（至少30天）
        if age_days < 30:
            return False
        
        # 需要被多次访问（至少5次）
        if access_count < 5:
            return False
        
        # 内容必须是价值观、原则相关
        core_keywords = ['价值观', '原则', '重视', '底线', '核心', '关键', '根本']
        if not any(kw in content for kw in core_keywords):
            return False
        
        return True
    
    def determine_privacy_level(self, content: str) -> str:
        """
        判断隐私级别
        
        Returns:
            'normal' / 'sensitive' / 'private'
        """
        content_lower = content.lower()
        
        # 私密信息关键词
        private_keywords = [
            '密码', 'password', 'token', 'key', 'secret',
            '身份证', '银行卡', '地址', '电话', '邮箱'
        ]
        if any(kw in content_lower for kw in private_keywords):
            return 'private'
        
        # 敏感信息关键词
        sensitive_keywords = [
            '收入', '工资', '薪水', '财务', '隐私',
            '个人', '私密', '机密', '保密'
        ]
        if any(kw in content_lower for kw in sensitive_keywords):
            return 'sensitive'
        
        return 'normal'
    
    def generate_tags(
        self,
        content: str,
        extracted_info: Optional[Dict[str, Any]] = None
    ) -> List[str]:
        """
        生成标签
        
        基于内容和提取的信息
        """
        tags = []
        
        # 1. 从提取的实体生成标签
        if extracted_info:
            entities = extracted_info.get('entities', [])
            for entity in entities:
                if entity.name and len(entity.name) > 1:
                    tags.append(entity.name)
            
            # 从关键词生成标签
            keywords = extracted_info.get('keywords', [])
            tags.extend(keywords[:5])  # 最多5个关键词标签
        
        # 2. 基于内容生成主题标签
        topic_keywords = {
            'Python': ['python', 'py'],
            '机器学习': ['机器学习', 'ml', 'machine learning'],
            '深度学习': ['深度学习', 'dl', 'deep learning', '神经网络'],
            '数据分析': ['数据分析', '数据处理', 'pandas', 'numpy'],
            'Web开发': ['web', 'http', 'api', 'fastapi', 'flask', 'django'],
            '数据库': ['数据库', 'database', 'sql', 'mysql', 'postgresql'],
            '前端': ['前端', 'frontend', 'react', 'vue', 'javascript'],
            '后端': ['后端', 'backend', 'server'],
            '架构': ['架构', 'architecture', '设计模式'],
            '测试': ['测试', 'test', 'pytest', '单元测试'],
        }
        
        content_lower = content.lower()
        for topic, keywords in topic_keywords.items():
            if any(kw in content_lower for kw in keywords):
                tags.append(topic)
        
        # 去重并限制数量
        tags = list(set(tags))[:10]
        
        return tags
    
    def classify_source_type(self, context: Optional[Dict[str, Any]] = None) -> str:
        """
        判断记忆来源类型
        
        Returns:
            'explicit' / 'inferred' / 'derived'
        """
        if not context:
            return 'explicit'
        
        if context.get('is_inferred'):
            return 'inferred'
        
        if context.get('derived_from'):
            return 'derived'
        
        return 'explicit'


# 全局实例
_classifier = None


def get_classifier() -> MemoryClassifier:
    """获取全局分类器实例"""
    global _classifier
    if _classifier is None:
        _classifier = MemoryClassifier()
    return _classifier

