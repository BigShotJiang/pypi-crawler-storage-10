"""
信息提取器

从对话中提取实体、事实、观点等结构化信息
"""
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import json
import re

from agent_memory.utils.llm_client import get_llm_client
from agent_memory.utils.text_utils import extract_keywords, segment, clean_text


@dataclass
class Entity:
    """实体"""
    name: str           # 实体名称
    type: str           # 实体类型（人物/项目/概念/工具等）
    context: str        # 上下文
    confidence: float   # 置信度


@dataclass
class Fact:
    """事实"""
    content: str        # 事实内容
    subject: str        # 主体
    predicate: str      # 谓语
    object: str         # 客体
    confidence: float   # 置信度


@dataclass
class Opinion:
    """观点"""
    content: str        # 观点内容
    holder: str         # 持有者
    target: str         # 目标对象
    sentiment: str      # 情感倾向（positive/negative/neutral）
    intensity: float    # 强度（0-1）


class MemoryExtractor:
    """
    记忆提取器
    
    从对话中提取结构化信息
    """
    
    def __init__(self):
        self.llm_client = get_llm_client()
    
    def extract_all(self, text: str, user_id: str = None) -> Dict[str, Any]:
        """
        提取所有信息
        
        Args:
            text: 对话文本
            user_id: 用户ID（可选）
        
        Returns:
            包含实体、事实、观点的字典
        """
        # 清洗文本
        cleaned_text = clean_text(text)
        
        # 提取各类信息
        entities = self.extract_entities(cleaned_text)
        facts = self.extract_facts(cleaned_text)
        opinions = self.extract_opinions(cleaned_text)
        keywords = extract_keywords(cleaned_text, top_k=5)
        
        return {
            "entities": entities,
            "facts": facts,
            "opinions": opinions,
            "keywords": keywords,
            "original_text": text
        }
    
    def extract_entities(self, text: str) -> List[Entity]:
        """
        提取实体（人物、项目、概念、工具等）
        
        使用LLM进行智能提取
        """
        if len(text) < 5:
            return []
        
        prompt = f"""请从以下文本中提取关键实体，返回JSON格式。

实体类型包括：person（人物）、project（项目）、concept（概念）、tool（工具）、organization（组织）、other（其他）

文本：{text}

返回格式：
{{
    "entities": [
        {{
            "name": "实体名称",
            "type": "实体类型",
            "context": "出现的上下文",
            "confidence": 0.9
        }}
    ]
}}"""
        
        try:
            response = self.llm_client.extract_json(prompt)
            data = json.loads(response)
            
            entities = []
            for item in data.get("entities", []):
                entities.append(Entity(
                    name=item.get("name", ""),
                    type=item.get("type", "other"),
                    context=item.get("context", ""),
                    confidence=item.get("confidence", 0.7)
                ))
            
            return entities
        
        except Exception as e:
            print(f"实体提取失败: {e}")
            # 降级策略：使用关键词作为实体
            keywords = extract_keywords(text, top_k=3)
            return [Entity(
                name=kw,
                type="concept",
                context=text[:50],
                confidence=0.5
            ) for kw in keywords]
    
    def extract_facts(self, text: str) -> List[Fact]:
        """
        提取事实性信息
        
        使用LLM识别客观事实
        """
        if len(text) < 10:
            return []
        
        prompt = f"""请从以下文本中提取事实性信息（客观、可验证的陈述），返回JSON格式。

文本：{text}

返回格式：
{{
    "facts": [
        {{
            "content": "完整的事实陈述",
            "subject": "主体",
            "predicate": "谓语/动作",
            "object": "客体",
            "confidence": 0.9
        }}
    ]
}}

如果没有明确的事实，返回空列表。"""
        
        try:
            response = self.llm_client.extract_json(prompt)
            data = json.loads(response)
            
            facts = []
            for item in data.get("facts", []):
                facts.append(Fact(
                    content=item.get("content", ""),
                    subject=item.get("subject", ""),
                    predicate=item.get("predicate", ""),
                    object=item.get("object", ""),
                    confidence=item.get("confidence", 0.7)
                ))
            
            return facts
        
        except Exception as e:
            print(f"事实提取失败: {e}")
            # 降级策略：如果包含明显的陈述句，作为事实
            if any(keyword in text for keyword in ["是", "会", "能", "有", "做", "完成"]):
                return [Fact(
                    content=text,
                    subject="",
                    predicate="",
                    object="",
                    confidence=0.4
                )]
            return []
    
    def extract_opinions(self, text: str) -> List[Opinion]:
        """
        提取观点和价值判断
        
        使用LLM识别主观观点
        """
        if len(text) < 10:
            return []
        
        prompt = f"""请从以下文本中提取观点和偏好（主观判断、喜好、评价），返回JSON格式。

文本：{text}

返回格式：
{{
    "opinions": [
        {{
            "content": "完整的观点陈述",
            "holder": "观点持有者（用户/其他人）",
            "target": "评价对象",
            "sentiment": "positive/negative/neutral",
            "intensity": 0.8
        }}
    ]
}}

如果没有明确的观点，返回空列表。"""
        
        try:
            response = self.llm_client.extract_json(prompt)
            data = json.loads(response)
            
            opinions = []
            for item in data.get("opinions", []):
                opinions.append(Opinion(
                    content=item.get("content", ""),
                    holder=item.get("holder", "用户"),
                    target=item.get("target", ""),
                    sentiment=item.get("sentiment", "neutral"),
                    intensity=item.get("intensity", 0.5)
                ))
            
            return opinions
        
        except Exception as e:
            print(f"观点提取失败: {e}")
            # 降级策略：如果包含明显的主观词汇，作为观点
            subjective_keywords = ["喜欢", "讨厌", "希望", "想要", "觉得", "认为", "偏好", "倾向"]
            if any(keyword in text for keyword in subjective_keywords):
                # 简单判断情感
                positive_words = ["喜欢", "希望", "想要", "好", "优秀", "棒"]
                negative_words = ["讨厌", "不喜欢", "糟糕", "差"]
                
                sentiment = "neutral"
                if any(word in text for word in positive_words):
                    sentiment = "positive"
                elif any(word in text for word in negative_words):
                    sentiment = "negative"
                
                return [Opinion(
                    content=text,
                    holder="用户",
                    target="",
                    sentiment=sentiment,
                    intensity=0.6
                )]
            return []
    
    def extract_preferences(self, text: str) -> Dict[str, Any]:
        """
        提取用户偏好
        
        专门用于识别用户的习惯和偏好
        """
        preferences = {
            "tools": [],
            "methods": [],
            "styles": [],
            "dislikes": []
        }
        
        # 使用规则和LLM结合
        opinions = self.extract_opinions(text)
        
        for opinion in opinions:
            if opinion.sentiment == "positive":
                if any(word in opinion.content for word in ["工具", "使用", "框架", "库"]):
                    preferences["tools"].append(opinion.target)
                elif any(word in opinion.content for word in ["方法", "方式", "流程"]):
                    preferences["methods"].append(opinion.target)
                elif any(word in opinion.content for word in ["风格", "习惯", "偏好"]):
                    preferences["styles"].append(opinion.target)
            
            elif opinion.sentiment == "negative":
                preferences["dislikes"].append(opinion.target)
        
        return preferences
    
    def extract_from_conversation(self, messages: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        从完整对话中提取信息
        
        Args:
            messages: 消息列表 [{"role": "user", "content": "..."}]
        
        Returns:
            提取的所有信息
        """
        # 合并所有用户消息
        user_messages = [msg["content"] for msg in messages if msg.get("role") == "user"]
        combined_text = "\n".join(user_messages)
        
        return self.extract_all(combined_text)
    
    def is_memory_worthy(self, text: str) -> bool:
        """
        判断是否值得记忆
        
        过滤掉过于简单或无意义的内容
        """
        # 基本过滤
        if len(text) < 5:
            return False
        
        # 过滤纯问候语
        greetings = ["你好", "谢谢", "再见", "嗯", "哦", "好的", "ok", "嗯嗯"]
        if text.strip() in greetings:
            return False
        
        # 如果有实体、事实或观点，则值得记忆
        entities = self.extract_entities(text)
        facts = self.extract_facts(text)
        opinions = self.extract_opinions(text)
        
        return len(entities) > 0 or len(facts) > 0 or len(opinions) > 0


# 全局实例
_extractor = None


def get_extractor() -> MemoryExtractor:
    """获取全局提取器实例"""
    global _extractor
    if _extractor is None:
        _extractor = MemoryExtractor()
    return _extractor

