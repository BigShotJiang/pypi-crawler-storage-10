"""
记忆形成管理器

整合提取器、评分器、分类器，完成从对话到记忆的完整流程
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid

from agent_memory.core.memory import Memory, MemoryType, MemoryCategory, SourceType, PrivacyLevel
from agent_memory.core.config import get_config
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.storage.vector_store import VectorStore
from agent_memory.utils.embeddings import get_embedding_generator

from agent_memory.modules.formation.extractor import MemoryExtractor, get_extractor
from agent_memory.modules.formation.scorer import ImportanceScorer, get_scorer
from agent_memory.modules.formation.classifier import MemoryClassifier, get_classifier


class MemoryFormer:
    """
    记忆形成管理器
    
    负责将对话转换为结构化记忆的完整流程
    """
    
    def __init__(
        self,
        sqlite_store: Optional[SQLiteStore] = None,
        vector_store: Optional[VectorStore] = None
    ):
        """
        初始化记忆形成管理器
        
        Args:
            sqlite_store: SQLite存储（可选）
            vector_store: 向量存储（可选）
        """
        self.config = get_config()
        self.sqlite_store = sqlite_store or SQLiteStore()
        self.vector_store = vector_store
        
        # 初始化各个组件
        self.extractor = get_extractor()
        self.scorer = get_scorer(self.sqlite_store)
        self.classifier = get_classifier()
        
        # 延迟初始化（避免启动时加载大模型）
        self._embedding_gen = None
    
    @property
    def embedding_gen(self):
        """延迟加载向量化生成器"""
        if self._embedding_gen is None:
            self._embedding_gen = get_embedding_generator()
        return self._embedding_gen
    
    def form_memory_from_text(
        self,
        text: str,
        user_id: str,
        session_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> Memory:
        """
        从文本创建记忆
        
        完整流程：
        1. 提取信息（实体、事实、观点）
        2. 计算重要性和置信度
        3. 分类记忆类型和维度
        4. 生成标签和元数据
        5. 创建Memory对象
        6. 保存到数据库
        
        Args:
            text: 对话文本
            user_id: 用户ID
            session_id: 会话ID（可选）
            conversation_id: 对话ID（可选）
            context: 上下文信息（可选）
        
        Returns:
            创建的Memory对象
        """
        # 1. 检查是否值得记忆
        if not self.extractor.is_memory_worthy(text):
            return None
        
        # 2. 提取信息
        extracted_info = self.extractor.extract_all(text, user_id)
        
        # 3. 计算重要性
        importance = self.scorer.calculate_importance(
            content=text,
            user_id=user_id,
            extracted_info=extracted_info,
            context=context
        )
        
        # 4. 分类记忆类型
        memory_type = self.classifier.classify_memory_type(
            importance=importance,
            content=text,
            extracted_info=extracted_info,
            context=context
        )
        
        # 5. 分类记忆维度
        category = self.classifier.classify_category(
            content=text,
            extracted_info=extracted_info
        )
        
        # 6. 计算置信度
        source_type = self.classifier.classify_source_type(context)
        confidence = self.scorer.calculate_confidence(
            content=text,
            source_type=source_type,
            extracted_info=extracted_info
        )
        
        # 7. 生成标签
        tags = self.classifier.generate_tags(text, extracted_info)
        
        # 8. 判断隐私级别
        privacy_level_str = self.classifier.determine_privacy_level(text)
        privacy_level = PrivacyLevel[privacy_level_str.upper()]
        
        # 9. 创建Memory对象
        memory = Memory(
            id=str(uuid.uuid4()),
            user_id=user_id,
            content=text,
            memory_type=memory_type,
            category=category,
            importance=importance,
            confidence=confidence,
            source_type=SourceType[source_type.upper()],
            source_conversation_id=conversation_id,
            source_session_id=session_id,
            tags=tags,
            privacy_level=privacy_level,
            metadata={
                "extracted_entities": [e.name for e in extracted_info.get('entities', [])],
                "has_facts": len(extracted_info.get('facts', [])) > 0,
                "has_opinions": len(extracted_info.get('opinions', [])) > 0,
                "keywords": extracted_info.get('keywords', [])
            }
        )
        
        # 10. 保存到数据库
        self.sqlite_store.create_memory(memory)
        
        # 11. 生成向量并保存（如果有向量存储）
        if self.vector_store:
            try:
                embedding = self.embedding_gen.encode(text)
                self.vector_store.add_memory(memory, embedding)
                memory.embedding = embedding
            except Exception as e:
                print(f"向量存储失败: {e}")
        
        return memory
    
    def form_memories_from_conversation(
        self,
        messages: List[Dict[str, str]],
        user_id: str,
        session_id: Optional[str] = None
    ) -> List[Memory]:
        """
        从完整对话创建多条记忆
        
        Args:
            messages: 消息列表 [{"role": "user", "content": "..."}]
            user_id: 用户ID
            session_id: 会话ID
        
        Returns:
            创建的记忆列表
        """
        memories = []
        
        # 过滤出用户消息
        user_messages = [msg for msg in messages if msg.get("role") == "user"]
        
        for i, msg in enumerate(user_messages):
            content = msg.get("content", "")
            
            # 为每条消息创建记忆
            memory = self.form_memory_from_text(
                text=content,
                user_id=user_id,
                session_id=session_id,
                conversation_id=f"{session_id}_{i}",
                context={
                    "message_index": i,
                    "total_messages": len(user_messages)
                }
            )
            
            if memory:
                memories.append(memory)
        
        return memories
    
    def batch_form_memories(
        self,
        texts: List[str],
        user_id: str,
        session_id: Optional[str] = None
    ) -> List[Memory]:
        """
        批量创建记忆
        
        Args:
            texts: 文本列表
            user_id: 用户ID
            session_id: 会话ID
        
        Returns:
            创建的记忆列表
        """
        memories = []
        
        for i, text in enumerate(texts):
            memory = self.form_memory_from_text(
                text=text,
                user_id=user_id,
                session_id=session_id,
                conversation_id=f"batch_{i}"
            )
            
            if memory:
                memories.append(memory)
        
        return memories
    
    def update_memory_importance(self, memory_id: str, user_id: str) -> Optional[Memory]:
        """
        重新计算并更新记忆的重要性
        
        用于定期更新或基于新信息调整
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        # 重新计算重要性
        new_importance = self.scorer.calculate_importance(
            content=memory.content,
            user_id=user_id,
            context={"existing_memory": True}
        )
        
        # 更新
        memory.importance = new_importance
        memory.updated_at = datetime.now()
        
        # 检查是否需要调整类型
        new_type = self.classifier.classify_memory_type(
            importance=new_importance,
            content=memory.content
        )
        
        if new_type != memory.memory_type:
            memory.memory_type = new_type
        
        # 保存
        self.sqlite_store.update_memory(memory)
        
        return memory
    
    def promote_to_core_if_worthy(self, memory: Memory) -> bool:
        """
        检查记忆是否应该晋升为核心记忆
        
        Returns:
            是否晋升成功
        """
        # 计算记忆存在天数
        age = datetime.now() - memory.created_at
        age_days = age.days
        
        # 判断是否应该晋升
        should_promote = self.classifier.should_promote_to_core(
            content=memory.content,
            importance=memory.importance,
            access_count=memory.access_count,
            age_days=age_days
        )
        
        if should_promote and memory.memory_type != MemoryType.CORE:
            memory.memory_type = MemoryType.CORE
            memory.importance = min(1.0, memory.importance * 1.1)  # 略微提升重要性
            memory.updated_at = datetime.now()
            
            self.sqlite_store.update_memory(memory)
            return True
        
        return False
    
    def extract_and_form_preferences(
        self,
        text: str,
        user_id: str
    ) -> Dict[str, Any]:
        """
        提取并形成用户偏好记忆
        
        专门处理偏好相关的内容
        """
        # 提取偏好
        preferences = self.extractor.extract_preferences(text)
        
        # 为每个偏好类别创建记忆
        memories_created = []
        
        for pref_type, items in preferences.items():
            if not items:
                continue
            
            content = f"用户{pref_type}: {', '.join(items)}"
            
            memory = self.form_memory_from_text(
                text=content,
                user_id=user_id,
                context={"is_preference": True}
            )
            
            if memory:
                # 强制设置为偏好类别
                memory.category = MemoryCategory.PREFERENCE
                self.sqlite_store.update_memory(memory)
                memories_created.append(memory)
        
        return {
            "preferences": preferences,
            "memories_created": len(memories_created),
            "memories": memories_created
        }
    
    def analyze_memory_quality(self, memory: Memory) -> Dict[str, Any]:
        """
        分析记忆质量
        
        用于调试和优化
        """
        return {
            "memory_id": memory.id,
            "content_length": len(memory.content),
            "importance": memory.importance,
            "confidence": memory.confidence,
            "memory_type": memory.memory_type.value,
            "category": memory.category.value,
            "tags_count": len(memory.tags),
            "has_embedding": memory.embedding is not None,
            "access_count": memory.access_count,
            "age_days": (datetime.now() - memory.created_at).days
        }


# 全局实例
_memory_former = None


def get_memory_former(
    sqlite_store: Optional[SQLiteStore] = None,
    vector_store: Optional[VectorStore] = None
) -> MemoryFormer:
    """获取全局记忆形成管理器实例"""
    global _memory_former
    if _memory_former is None:
        _memory_former = MemoryFormer(sqlite_store, vector_store)
    return _memory_former

