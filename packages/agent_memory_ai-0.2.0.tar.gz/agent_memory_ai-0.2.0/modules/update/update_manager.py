"""
更新管理器

统一管理所有记忆更新相关功能
"""
from typing import List, Optional, Dict, Any
from datetime import datetime

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.update.conflict_detector import ConflictDetector, ConflictType
from agent_memory.modules.update.conflict_resolver import ConflictResolver
from agent_memory.modules.update.memory_updater import MemoryUpdater
from agent_memory.modules.update.memory_merger import MemoryMerger
from agent_memory.modules.update.memory_compressor import MemoryCompressor
from agent_memory.modules.update.association_manager import AssociationManager


class UpdateManager:
    """
    更新管理器
    
    统一接口管理所有更新功能
    """
    
    def __init__(self, sqlite_store: Optional[SQLiteStore] = None):
        """初始化更新管理器"""
        self.sqlite_store = sqlite_store or SQLiteStore()
        
        # 初始化各个子模块
        self.conflict_detector = ConflictDetector(self.sqlite_store)
        self.conflict_resolver = ConflictResolver(self.sqlite_store)
        self.memory_updater = MemoryUpdater(self.sqlite_store)
        self.memory_merger = MemoryMerger(self.sqlite_store)
        self.memory_compressor = MemoryCompressor(self.sqlite_store)
        self.association_manager = AssociationManager(self.sqlite_store)
    
    def add_new_memory_with_conflict_check(
        self,
        memory: Memory,
        auto_resolve: bool = True
    ) -> Dict[str, Any]:
        """
        添加新记忆并检查冲突
        
        Args:
            memory: 新记忆
            auto_resolve: 是否自动解决冲突
        
        Returns:
            处理结果字典
        """
        # 1. 检测冲突
        conflicts = self.conflict_detector.detect_conflicts(
            memory,
            memory.user_id,
            check_range_days=90
        )
        
        result = {
            "memory": memory,
            "conflicts_found": len(conflicts),
            "conflicts": [],
            "resolutions": [],
            "stored": False
        }
        
        # 2. 如果有冲突
        if conflicts:
            result["conflicts"] = [
                {
                    "memory_id": conflict_mem.id,
                    "type": conflict_type.value,
                    "confidence": confidence
                }
                for conflict_mem, conflict_type, confidence in conflicts
            ]
            
            # 3. 自动解决冲突
            if auto_resolve:
                for conflict_mem, conflict_type, confidence in conflicts:
                    resolution = self.conflict_resolver.resolve_conflict(
                        memory,
                        conflict_mem,
                        conflict_type,
                        strategy="auto"
                    )
                    result["resolutions"].append(resolution)
                    
                    # 执行解决方案
                    self._execute_resolution(resolution, memory, conflict_mem)
        
        # 4. 存储记忆
        self.sqlite_store.create_memory(memory)
        result["stored"] = True
        
        # 5. 自动创建关联
        associations_count = self.association_manager.auto_create_associations(
            memory,
            memory.user_id,
            max_associations=5
        )
        result["associations_created"] = associations_count
        
        return result
    
    def _execute_resolution(
        self,
        resolution: Dict[str, Any],
        new_memory: Memory,
        old_memory: Memory
    ):
        """执行冲突解决方案"""
        action = resolution.get("action")
        
        if action == "delete_duplicate":
            # 删除重复记忆
            deleted_id = resolution.get("deleted")
            if deleted_id:
                mem = self.sqlite_store.get_memory(deleted_id)
                if mem:
                    self.sqlite_store.delete_memory(deleted_id, mem.user_id)
        
        elif action == "mark_contradicted":
            # 标记为矛盾
            updated_id = resolution.get("updated")
            if updated_id:
                self.sqlite_store.update_memory(old_memory)
        
        elif action == "link_inconsistent":
            # 建立关联
            self.sqlite_store.update_memory(new_memory)
            self.sqlite_store.update_memory(old_memory)
        
        elif action == "mark_superseded":
            # 标记为被取代
            self.sqlite_store.update_memory(old_memory)
            self.sqlite_store.update_memory(new_memory)
    
    def update_memory_content(
        self,
        memory_id: str,
        new_content: str,
        check_conflicts: bool = True
    ) -> Dict[str, Any]:
        """
        更新记忆内容并检查冲突
        
        Args:
            memory_id: 记忆ID
            new_content: 新内容
            check_conflicts: 是否检查冲突
        
        Returns:
            更新结果
        """
        # 1. 更新内容
        updated_memory = self.memory_updater.update_content(
            memory_id,
            new_content,
            recompute_importance=True
        )
        
        if not updated_memory:
            return {"success": False, "error": "记忆不存在"}
        
        result = {
            "success": True,
            "memory": updated_memory,
            "conflicts": []
        }
        
        # 2. 检查新内容是否与其他记忆冲突
        if check_conflicts:
            conflicts = self.conflict_detector.detect_conflicts(
                updated_memory,
                updated_memory.user_id
            )
            
            if conflicts:
                result["conflicts"] = [
                    {
                        "memory_id": cm.id,
                        "type": ct.value,
                        "confidence": conf
                    }
                    for cm, ct, conf in conflicts
                ]
        
        return result
    
    def merge_duplicate_memories(
        self,
        user_id: str,
        similarity_threshold: float = 0.8,
        auto_execute: bool = False
    ) -> Dict[str, Any]:
        """
        合并重复记忆
        
        Args:
            user_id: 用户ID
            similarity_threshold: 相似度阈值
            auto_execute: 是否自动执行合并
        
        Returns:
            合并结果
        """
        # 1. 检测重复
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        duplicates = self.conflict_detector.check_duplicate_in_batch(
            all_memories,
            threshold=similarity_threshold
        )
        
        result = {
            "duplicates_found": len(duplicates),
            "merged_count": 0,
            "merged_memories": []
        }
        
        # 2. 自动合并
        if auto_execute and duplicates:
            for m1, m2, similarity in duplicates:
                merged = self.memory_merger.merge_two_memories(m1, m2)
                
                # 删除旧记忆
                self.sqlite_store.delete_memory(m1.id, m1.user_id)
                self.sqlite_store.delete_memory(m2.id, m2.user_id)
                
                # 存储合并后的记忆
                self.sqlite_store.create_memory(merged)
                
                result["merged_memories"].append(merged)
                result["merged_count"] += 1
        
        return result
    
    def compress_user_memories(
        self,
        user_id: str,
        window_days: int = 30,
        target_per_window: int = 20
    ) -> Dict[str, Any]:
        """
        压缩用户记忆
        
        Args:
            user_id: 用户ID
            window_days: 时间窗口
            target_per_window: 每窗口目标数量
        
        Returns:
            压缩结果
        """
        compressed = self.memory_compressor.compress_by_time_window(
            user_id,
            window_days,
            target_per_window
        )
        
        return {
            "original_count": len(self.sqlite_store.get_memories_by_user(user_id, limit=10000)),
            "compressed_count": len(compressed),
            "compression_ratio": len(compressed) / max(1, len(compressed))
        }
    
    def maintain_associations(
        self,
        user_id: str,
        auto_create: bool = True,
        clean_broken: bool = True
    ) -> Dict[str, Any]:
        """
        维护记忆关联
        
        Args:
            user_id: 用户ID
            auto_create: 是否自动创建关联
            clean_broken: 是否清理无效关联
        
        Returns:
            维护结果
        """
        result = {
            "associations_created": 0,
            "associations_cleaned": 0
        }
        
        # 1. 清理无效关联
        if clean_broken:
            cleaned = self.association_manager.clean_broken_associations(user_id)
            result["associations_cleaned"] = cleaned
        
        # 2. 自动创建关联
        if auto_create:
            memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
            for memory in memories:
                if len(memory.related_memory_ids) < 5:  # 关联数少的
                    count = self.association_manager.auto_create_associations(
                        memory,
                        user_id,
                        max_associations=5 - len(memory.related_memory_ids)
                    )
                    result["associations_created"] += count
        
        return result
    
    def batch_update_importance(
        self,
        user_id: str
    ) -> Dict[str, Any]:
        """
        批量更新记忆重要性
        
        Args:
            user_id: 用户ID
        
        Returns:
            更新结果
        """
        updated_count = self.memory_updater.batch_update_importance(
            user_id,
            recompute=True
        )
        
        return {
            "updated_count": updated_count
        }
    
    def find_and_resolve_contradictions(
        self,
        user_id: str,
        auto_resolve: bool = True
    ) -> Dict[str, Any]:
        """
        查找并解决矛盾
        
        Args:
            user_id: 用户ID
            auto_resolve: 是否自动解决
        
        Returns:
            处理结果
        """
        # 查找矛盾
        contradictions = self.conflict_detector.find_contradictions(user_id)
        
        result = {
            "contradictions_found": len(contradictions),
            "resolutions": []
        }
        
        # 自动解决
        if auto_resolve:
            for m1, m2, confidence in contradictions:
                resolution = self.conflict_resolver.resolve_conflict(
                    m1, m2,
                    ConflictType.CONTRADICTION,
                    strategy="auto"
                )
                result["resolutions"].append(resolution)
                
                # 执行解决方案
                self._execute_resolution(resolution, m1, m2)
        
        return result


# 全局实例
_update_manager = None


def get_update_manager(sqlite_store: Optional[SQLiteStore] = None) -> UpdateManager:
    """获取全局更新管理器实例"""
    global _update_manager
    if _update_manager is None:
        _update_manager = UpdateManager(sqlite_store)
    return _update_manager

