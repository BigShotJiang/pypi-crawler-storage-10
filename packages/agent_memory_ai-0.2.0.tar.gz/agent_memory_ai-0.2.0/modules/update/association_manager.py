"""
关联管理器

管理记忆间的关联关系
"""
from typing import List, Optional, Set, Dict
from collections import defaultdict

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore


class AssociationManager:
    """关联管理器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化关联管理器"""
        self.sqlite_store = sqlite_store
    
    def add_association(
        self,
        memory_id1: str,
        memory_id2: str,
        bidirectional: bool = True
    ) -> bool:
        """
        添加关联
        
        Args:
            memory_id1: 记忆ID1
            memory_id2: 记忆ID2
            bidirectional: 是否双向关联
        
        Returns:
            是否成功
        """
        memory1 = self.sqlite_store.get_memory(memory_id1)
        if not memory1:
            return False
        
        if memory_id2 not in memory1.related_memory_ids:
            memory1.related_memory_ids.append(memory_id2)
            self.sqlite_store.update_memory(memory1)
        
        if bidirectional:
            memory2 = self.sqlite_store.get_memory(memory_id2)
            if memory2 and memory_id1 not in memory2.related_memory_ids:
                memory2.related_memory_ids.append(memory_id1)
                self.sqlite_store.update_memory(memory2)
        
        return True
    
    def remove_association(
        self,
        memory_id1: str,
        memory_id2: str,
        bidirectional: bool = True
    ) -> bool:
        """移除关联"""
        memory1 = self.sqlite_store.get_memory(memory_id1)
        if not memory1:
            return False
        
        if memory_id2 in memory1.related_memory_ids:
            memory1.related_memory_ids.remove(memory_id2)
            self.sqlite_store.update_memory(memory1)
        
        if bidirectional:
            memory2 = self.sqlite_store.get_memory(memory_id2)
            if memory2 and memory_id1 in memory2.related_memory_ids:
                memory2.related_memory_ids.remove(memory_id1)
                self.sqlite_store.update_memory(memory2)
        
        return True
    
    def auto_create_associations(
        self,
        memory: Memory,
        user_id: str,
        max_associations: int = 5
    ) -> int:
        """
        自动创建关联
        
        基于标签、内容相似度等
        
        Args:
            memory: 记忆
            user_id: 用户ID
            max_associations: 最大关联数
        
        Returns:
            创建的关联数
        """
        # 获取候选记忆
        candidates = self._find_candidate_associations(memory, user_id)
        
        # 限制数量
        candidates = candidates[:max_associations]
        
        # 创建关联
        count = 0
        for candidate_id, score in candidates:
            if self.add_association(memory.id, candidate_id, bidirectional=True):
                count += 1
        
        return count
    
    def _find_candidate_associations(
        self,
        memory: Memory,
        user_id: str
    ) -> List[tuple]:
        """
        查找候选关联记忆
        
        Returns:
            [(记忆ID, 相关度分数)]
        """
        all_memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        candidates = []
        
        for other in all_memories:
            if other.id == memory.id:
                continue
            
            # 计算相关度
            score = self._calculate_relevance(memory, other)
            
            if score > 0.5:
                candidates.append((other.id, score))
        
        # 按分数排序
        candidates.sort(key=lambda x: x[1], reverse=True)
        
        return candidates
    
    def _calculate_relevance(self, m1: Memory, m2: Memory) -> float:
        """
        计算两个记忆的相关度
        
        Returns:
            相关度分数 (0-1)
        """
        score = 0.0
        
        # 1. 标签重叠
        if m1.tags and m2.tags:
            tag_overlap = len(set(m1.tags) & set(m2.tags))
            tag_union = len(set(m1.tags) | set(m2.tags))
            if tag_union > 0:
                score += (tag_overlap / tag_union) * 0.5
        
        # 2. 同类别
        if m1.category == m2.category:
            score += 0.2
        
        # 3. 内容相似度（简单版）
        words1 = set(m1.content.lower().split())
        words2 = set(m2.content.lower().split())
        
        if words1 and words2:
            word_overlap = len(words1 & words2)
            word_union = len(words1 | words2)
            if word_union > 0:
                score += (word_overlap / word_union) * 0.3
        
        return min(1.0, score)
    
    def clean_broken_associations(self, user_id: str) -> int:
        """
        清理无效关联（指向不存在的记忆）
        
        Args:
            user_id: 用户ID
        
        Returns:
            清理数量
        """
        memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 获取所有有效ID
        valid_ids = {m.id for m in memories}
        
        cleaned_count = 0
        
        for memory in memories:
            original_count = len(memory.related_memory_ids)
            
            # 过滤无效关联
            memory.related_memory_ids = [
                rid for rid in memory.related_memory_ids
                if rid in valid_ids
            ]
            
            if len(memory.related_memory_ids) < original_count:
                self.sqlite_store.update_memory(memory)
                cleaned_count += (original_count - len(memory.related_memory_ids))
        
        return cleaned_count
    
    def get_association_strength(
        self,
        memory_id1: str,
        memory_id2: str
    ) -> float:
        """
        获取两个记忆的关联强度
        
        Returns:
            关联强度 (0-1)
        """
        memory1 = self.sqlite_store.get_memory(memory_id1)
        memory2 = self.sqlite_store.get_memory(memory_id2)
        
        if not memory1 or not memory2:
            return 0.0
        
        # 检查是否有直接关联
        has_direct = memory_id2 in memory1.related_memory_ids or \
                     memory_id1 in memory2.related_memory_ids
        
        if has_direct:
            base_strength = 0.8
        else:
            base_strength = 0.0
        
        # 计算内容相关度
        relevance = self._calculate_relevance(memory1, memory2)
        
        return max(base_strength, relevance)


# 全局实例
_association_manager = None


def get_association_manager(sqlite_store: Optional[SQLiteStore] = None) -> AssociationManager:
    """获取全局关联管理器实例"""
    global _association_manager
    if _association_manager is None:
        _association_manager = AssociationManager(sqlite_store or SQLiteStore())
    return _association_manager

