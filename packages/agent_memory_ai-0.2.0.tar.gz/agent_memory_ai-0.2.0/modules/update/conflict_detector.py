"""
冲突检测器

检测记忆间的冲突（矛盾、重复、不一致）
"""
from typing import List, Tuple, Optional, Dict, Any
from enum import Enum
from datetime import datetime

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore


class ConflictType(Enum):
    """冲突类型"""
    CONTRADICTION = "contradiction"  # 矛盾冲突（内容相反）
    DUPLICATE = "duplicate"          # 重复冲突（内容相同）
    INCONSISTENCY = "inconsistency"  # 不一致（相关但有差异）
    TEMPORAL = "temporal"            # 时间变化（新旧信息）


class ConflictDetector:
    """
    冲突检测器
    
    检测记忆间的各种冲突
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化冲突检测器"""
        self.sqlite_store = sqlite_store
    
    def detect_conflicts(
        self,
        new_memory: Memory,
        user_id: str,
        check_range_days: int = 90
    ) -> List[Tuple[Memory, ConflictType, float]]:
        """
        检测新记忆与已有记忆的冲突
        
        Args:
            new_memory: 新记忆
            user_id: 用户ID
            check_range_days: 检查范围（天）
        
        Returns:
            冲突列表 [(记忆, 冲突类型, 冲突度)]
        """
        # 获取候选记忆（最近的、相关的）
        candidates = self._get_candidate_memories(
            new_memory, user_id, check_range_days
        )
        
        conflicts = []
        
        for candidate in candidates:
            # 检测各种类型的冲突
            conflict_type, confidence = self._detect_conflict_type(
                new_memory, candidate
            )
            
            if conflict_type and confidence > 0.5:
                conflicts.append((candidate, conflict_type, confidence))
        
        # 按冲突度排序
        conflicts.sort(key=lambda x: x[2], reverse=True)
        
        return conflicts
    
    def _get_candidate_memories(
        self,
        new_memory: Memory,
        user_id: str,
        days: int
    ) -> List[Memory]:
        """
        获取候选记忆
        
        选择可能冲突的记忆（相同维度、相似主题）
        """
        # 1. 获取同维度的记忆
        all_memories = self.sqlite_store.get_memories_by_user(
            user_id=user_id,
            limit=1000
        )
        
        # 2. 过滤同类别
        candidates = [
            m for m in all_memories
            if m.category == new_memory.category
            and m.id != new_memory.id
        ]
        
        # 3. 过滤时间范围（检查最近N天）
        cutoff = datetime.now()
        candidates = [
            m for m in candidates
            if (cutoff - m.created_at).days <= days
        ]
        
        # 4. 过滤有相同标签的
        new_tags = set(new_memory.tags)
        if new_tags:
            candidates = [
                m for m in candidates
                if new_tags & set(m.tags)  # 有交集
            ]
        
        return candidates[:50]  # 最多检查50个
    
    def _detect_conflict_type(
        self,
        memory1: Memory,
        memory2: Memory
    ) -> Tuple[Optional[ConflictType], float]:
        """
        检测两个记忆的冲突类型和置信度
        
        Returns:
            (冲突类型, 置信度) 或 (None, 0.0)
        """
        # 1. 检测重复
        duplicate_score = self._check_duplicate(memory1, memory2)
        if duplicate_score > 0.8:
            return ConflictType.DUPLICATE, duplicate_score
        
        # 2. 检测矛盾
        contradiction_score = self._check_contradiction(memory1, memory2)
        if contradiction_score > 0.7:
            return ConflictType.CONTRADICTION, contradiction_score
        
        # 3. 检测不一致
        inconsistency_score = self._check_inconsistency(memory1, memory2)
        if inconsistency_score > 0.6:
            return ConflictType.INCONSISTENCY, inconsistency_score
        
        # 4. 检测时间变化
        temporal_score = self._check_temporal_change(memory1, memory2)
        if temporal_score > 0.7:
            return ConflictType.TEMPORAL, temporal_score
        
        return None, 0.0
    
    def _check_duplicate(self, m1: Memory, m2: Memory) -> float:
        """
        检测重复（内容高度相似）
        
        Returns:
            相似度分数 (0-1)
        """
        # 简单的文本相似度（可以用更复杂的方法）
        content1 = m1.content.lower().strip()
        content2 = m2.content.lower().strip()
        
        # 完全相同
        if content1 == content2:
            return 1.0
        
        # 计算字符级相似度
        if len(content1) == 0 or len(content2) == 0:
            return 0.0
        
        # 简单的包含关系
        if content1 in content2 or content2 in content1:
            shorter = min(len(content1), len(content2))
            longer = max(len(content1), len(content2))
            return shorter / longer
        
        # 计算公共子串
        common_chars = set(content1) & set(content2)
        all_chars = set(content1) | set(content2)
        
        if not all_chars:
            return 0.0
        
        char_similarity = len(common_chars) / len(all_chars)
        
        # 检查标签相似度
        if m1.tags and m2.tags:
            tag_overlap = len(set(m1.tags) & set(m2.tags)) / len(set(m1.tags) | set(m2.tags))
            return (char_similarity * 0.7 + tag_overlap * 0.3)
        
        return char_similarity * 0.7
    
    def _check_contradiction(self, m1: Memory, m2: Memory) -> float:
        """
        检测矛盾（内容相反）
        
        Returns:
            矛盾度 (0-1)
        """
        # 检测否定词
        negation_words = {
            '不', '没', '非', '无', '未', '否',
            'not', 'no', 'never', 'none', 'neither'
        }
        
        content1_lower = m1.content.lower()
        content2_lower = m2.content.lower()
        
        # 检测一个有否定词，一个没有
        has_neg1 = any(neg in content1_lower for neg in negation_words)
        has_neg2 = any(neg in content2_lower for neg in negation_words)
        
        if has_neg1 != has_neg2:  # 一个有否定一个没有
            # 检查是否讨论同一主题
            words1 = set(content1_lower.split())
            words2 = set(content2_lower.split())
            
            common = words1 & words2
            if len(common) > 3:  # 有足够多公共词
                return 0.8
        
        # 检测对立词对
        opposite_pairs = [
            ('喜欢', '不喜欢'), ('喜欢', '讨厌'),
            ('好', '坏'), ('对', '错'),
            ('是', '不是'), ('能', '不能'),
            ('like', 'dislike'), ('love', 'hate'),
            ('good', 'bad'), ('yes', 'no')
        ]
        
        for word1, word2 in opposite_pairs:
            if (word1 in content1_lower and word2 in content2_lower) or \
               (word2 in content1_lower and word1 in content2_lower):
                # 检查上下文相似度
                if self._check_duplicate(m1, m2) > 0.4:
                    return 0.75
        
        return 0.0
    
    def _check_inconsistency(self, m1: Memory, m2: Memory) -> float:
        """
        检测不一致（相关但有差异）
        
        Returns:
            不一致度 (0-1)
        """
        # 相似但不完全相同
        similarity = self._check_duplicate(m1, m2)
        
        if 0.4 < similarity < 0.8:
            # 检查是否有数字差异（可能是数据不一致）
            import re
            numbers1 = set(re.findall(r'\d+', m1.content))
            numbers2 = set(re.findall(r'\d+', m2.content))
            
            if numbers1 and numbers2 and numbers1 != numbers2:
                return 0.7  # 数字不同，可能是数据不一致
            
            return 0.6  # 一般不一致
        
        return 0.0
    
    def _check_temporal_change(self, m1: Memory, m2: Memory) -> float:
        """
        检测时间变化（新旧信息更替）
        
        Returns:
            时间变化置信度 (0-1)
        """
        # 检测时间相关词
        temporal_words = {
            '以前', '之前', '曾经', '过去', '原来',
            '现在', '目前', '最近', '新', '改',
            'before', 'previously', 'used to', 'was',
            'now', 'currently', 'recently', 'new', 'changed'
        }
        
        content1_lower = m1.content.lower()
        content2_lower = m2.content.lower()
        
        has_temporal1 = any(word in content1_lower for word in temporal_words)
        has_temporal2 = any(word in content2_lower for word in temporal_words)
        
        if has_temporal1 or has_temporal2:
            # 检查内容相似但有差异
            similarity = self._check_duplicate(m1, m2)
            if 0.3 < similarity < 0.7:
                # 检查时间差异
                time_diff = abs((m1.created_at - m2.created_at).days)
                if time_diff > 7:  # 时间差超过7天
                    return 0.75
        
        return 0.0
    
    def check_duplicate_in_batch(
        self,
        memories: List[Memory],
        threshold: float = 0.8
    ) -> List[Tuple[Memory, Memory, float]]:
        """
        批量检查重复记忆
        
        Args:
            memories: 记忆列表
            threshold: 重复阈值
        
        Returns:
            重复对列表 [(记忆1, 记忆2, 相似度)]
        """
        duplicates = []
        
        for i in range(len(memories)):
            for j in range(i + 1, len(memories)):
                similarity = self._check_duplicate(memories[i], memories[j])
                if similarity >= threshold:
                    duplicates.append((memories[i], memories[j], similarity))
        
        return duplicates
    
    def find_contradictions(
        self,
        user_id: str,
        category: Optional[str] = None
    ) -> List[Tuple[Memory, Memory, float]]:
        """
        查找所有矛盾记忆
        
        Args:
            user_id: 用户ID
            category: 记忆维度（可选）
        
        Returns:
            矛盾对列表
        """
        # 获取记忆
        memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        if category:
            memories = [m for m in memories if m.category.value == category]
        
        contradictions = []
        
        # 两两比较
        for i in range(len(memories)):
            for j in range(i + 1, len(memories)):
                contradiction_score = self._check_contradiction(
                    memories[i], memories[j]
                )
                if contradiction_score > 0.7:
                    contradictions.append((
                        memories[i], memories[j], contradiction_score
                    ))
        
        # 按矛盾度排序
        contradictions.sort(key=lambda x: x[2], reverse=True)
        
        return contradictions


# 全局实例
_conflict_detector = None


def get_conflict_detector(sqlite_store: Optional[SQLiteStore] = None) -> ConflictDetector:
    """获取全局冲突检测器实例"""
    global _conflict_detector
    if _conflict_detector is None:
        _conflict_detector = ConflictDetector(sqlite_store or SQLiteStore())
    return _conflict_detector

