"""
冲突解决器

解决检测到的记忆冲突
"""
from typing import Optional, Dict, Any, List
from datetime import datetime

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.update.conflict_detector import ConflictType


class ConflictResolver:
    """
    冲突解决器
    
    根据冲突类型采取不同的解决策略
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化冲突解决器"""
        self.sqlite_store = sqlite_store
    
    def resolve_conflict(
        self,
        memory1: Memory,
        memory2: Memory,
        conflict_type: ConflictType,
        strategy: str = "auto"
    ) -> Dict[str, Any]:
        """
        解决冲突
        
        Args:
            memory1: 记忆1（通常是新记忆）
            memory2: 记忆2（通常是旧记忆）
            conflict_type: 冲突类型
            strategy: 解决策略
                - auto: 自动策略
                - keep_new: 保留新的
                - keep_old: 保留旧的
                - merge: 合并
                - keep_important: 保留重要的
        
        Returns:
            解决结果字典
        """
        if strategy == "auto":
            # 根据冲突类型自动选择策略
            if conflict_type == ConflictType.DUPLICATE:
                return self._resolve_duplicate(memory1, memory2)
            elif conflict_type == ConflictType.CONTRADICTION:
                return self._resolve_contradiction(memory1, memory2)
            elif conflict_type == ConflictType.INCONSISTENCY:
                return self._resolve_inconsistency(memory1, memory2)
            elif conflict_type == ConflictType.TEMPORAL:
                return self._resolve_temporal(memory1, memory2)
        
        elif strategy == "keep_new":
            return self._keep_newer(memory1, memory2)
        
        elif strategy == "keep_old":
            return self._keep_older(memory1, memory2)
        
        elif strategy == "merge":
            return self._merge_memories(memory1, memory2)
        
        elif strategy == "keep_important":
            return self._keep_more_important(memory1, memory2)
        
        return {
            "action": "none",
            "kept": None,
            "deleted": None,
            "merged": None
        }
    
    def _resolve_duplicate(
        self,
        m1: Memory,
        m2: Memory
    ) -> Dict[str, Any]:
        """
        解决重复冲突
        
        策略：保留更重要或更新的，删除另一个
        """
        # 比较重要性
        if abs(m1.importance - m2.importance) > 0.1:
            # 重要性差异明显，保留重要的
            if m1.importance > m2.importance:
                return {
                    "action": "delete_duplicate",
                    "kept": m1.id,
                    "deleted": m2.id,
                    "reason": f"保留更重要的记忆 (importance: {m1.importance:.2f} vs {m2.importance:.2f})"
                }
            else:
                return {
                    "action": "delete_duplicate",
                    "kept": m2.id,
                    "deleted": m1.id,
                    "reason": f"保留更重要的记忆 (importance: {m2.importance:.2f} vs {m1.importance:.2f})"
                }
        
        # 重要性相似，保留访问次数多的
        if m1.access_count != m2.access_count:
            if m1.access_count > m2.access_count:
                return {
                    "action": "delete_duplicate",
                    "kept": m1.id,
                    "deleted": m2.id,
                    "reason": f"保留访问更多的记忆 (access: {m1.access_count} vs {m2.access_count})"
                }
            else:
                return {
                    "action": "delete_duplicate",
                    "kept": m2.id,
                    "deleted": m1.id,
                    "reason": f"保留访问更多的记忆 (access: {m2.access_count} vs {m1.access_count})"
                }
        
        # 都差不多，保留新的
        return self._keep_newer(m1, m2)
    
    def _resolve_contradiction(
        self,
        m1: Memory,
        m2: Memory
    ) -> Dict[str, Any]:
        """
        解决矛盾冲突
        
        策略：保留新的，标记旧的为过时
        """
        # 通常新信息更准确
        if m1.created_at > m2.created_at:
            newer, older = m1, m2
        else:
            newer, older = m2, m1
        
        # 更新旧记忆的元数据，标记为被矛盾
        older.metadata = older.metadata or {}
        older.metadata['contradicted_by'] = newer.id
        older.metadata['contradicted_at'] = datetime.now().isoformat()
        
        # 降低旧记忆的重要性
        older.importance *= 0.5
        
        return {
            "action": "mark_contradicted",
            "kept": newer.id,
            "updated": older.id,
            "reason": f"新记忆矛盾旧记忆，标记旧记忆为过时"
        }
    
    def _resolve_inconsistency(
        self,
        m1: Memory,
        m2: Memory
    ) -> Dict[str, Any]:
        """
        解决不一致冲突
        
        策略：保留两个，建立关联
        """
        # 建立关联关系
        if m2.id not in m1.related_memory_ids:
            m1.related_memory_ids.append(m2.id)
        if m1.id not in m2.related_memory_ids:
            m2.related_memory_ids.append(m1.id)
        
        # 添加不一致标记
        m1.metadata = m1.metadata or {}
        m1.metadata['inconsistent_with'] = m2.id
        
        m2.metadata = m2.metadata or {}
        m2.metadata['inconsistent_with'] = m1.id
        
        return {
            "action": "link_inconsistent",
            "kept": [m1.id, m2.id],
            "reason": "保留两个不一致的记忆，建立关联"
        }
    
    def _resolve_temporal(
        self,
        m1: Memory,
        m2: Memory
    ) -> Dict[str, Any]:
        """
        解决时间变化冲突
        
        策略：保留新的，标记旧的为历史版本
        """
        if m1.created_at > m2.created_at:
            newer, older = m1, m2
        else:
            newer, older = m2, m1
        
        # 标记为历史版本
        older.metadata = older.metadata or {}
        older.metadata['superseded_by'] = newer.id
        older.metadata['superseded_at'] = datetime.now().isoformat()
        
        # 建立关联
        if older.id not in newer.related_memory_ids:
            newer.related_memory_ids.append(older.id)
        
        # 适当降低旧记忆重要性
        older.importance *= 0.7
        
        return {
            "action": "mark_superseded",
            "kept": newer.id,
            "updated": older.id,
            "reason": "新记忆取代旧记忆，标记为历史版本"
        }
    
    def _keep_newer(self, m1: Memory, m2: Memory) -> Dict[str, Any]:
        """保留更新的记忆"""
        if m1.created_at > m2.created_at:
            return {
                "action": "keep_new",
                "kept": m1.id,
                "deleted": m2.id,
                "reason": "保留更新的记忆"
            }
        else:
            return {
                "action": "keep_new",
                "kept": m2.id,
                "deleted": m1.id,
                "reason": "保留更新的记忆"
            }
    
    def _keep_older(self, m1: Memory, m2: Memory) -> Dict[str, Any]:
        """保留更旧的记忆"""
        if m1.created_at < m2.created_at:
            return {
                "action": "keep_old",
                "kept": m1.id,
                "deleted": m2.id,
                "reason": "保留更旧的记忆"
            }
        else:
            return {
                "action": "keep_old",
                "kept": m2.id,
                "deleted": m1.id,
                "reason": "保留更旧的记忆"
            }
    
    def _keep_more_important(self, m1: Memory, m2: Memory) -> Dict[str, Any]:
        """保留更重要的记忆"""
        if m1.importance > m2.importance:
            return {
                "action": "keep_important",
                "kept": m1.id,
                "deleted": m2.id,
                "reason": f"保留更重要的记忆 ({m1.importance:.2f} vs {m2.importance:.2f})"
            }
        else:
            return {
                "action": "keep_important",
                "kept": m2.id,
                "deleted": m1.id,
                "reason": f"保留更重要的记忆 ({m2.importance:.2f} vs {m1.importance:.2f})"
            }
    
    def _merge_memories(self, m1: Memory, m2: Memory) -> Dict[str, Any]:
        """
        合并两个记忆
        
        创建新记忆包含两者信息
        """
        # 合并内容
        merged_content = self._merge_content(m1.content, m2.content)
        
        # 合并标签
        merged_tags = list(set(m1.tags + m2.tags))
        
        # 选择更高的重要性
        merged_importance = max(m1.importance, m2.importance)
        
        # 使用更新的时间
        merged_created_at = max(m1.created_at, m2.created_at)
        
        return {
            "action": "merge",
            "deleted": [m1.id, m2.id],
            "merged": {
                "content": merged_content,
                "tags": merged_tags,
                "importance": merged_importance,
                "created_at": merged_created_at,
                "related_memory_ids": list(set(m1.related_memory_ids + m2.related_memory_ids))
            },
            "reason": "合并两个相似记忆"
        }
    
    def _merge_content(self, content1: str, content2: str) -> str:
        """
        合并两个记忆的内容
        
        简单策略：选择更长的或组合
        """
        if len(content1) > len(content2) * 1.5:
            return content1
        elif len(content2) > len(content1) * 1.5:
            return content2
        else:
            # 内容差不多长，组合
            return f"{content1}；{content2}"
    
    def batch_resolve_conflicts(
        self,
        conflicts: List[tuple],
        strategy: str = "auto"
    ) -> List[Dict[str, Any]]:
        """
        批量解决冲突
        
        Args:
            conflicts: 冲突列表 [(记忆1, 记忆2, 冲突类型, 置信度)]
            strategy: 解决策略
        
        Returns:
            解决结果列表
        """
        results = []
        
        for conflict in conflicts:
            if len(conflict) >= 3:
                m1, m2, conflict_type = conflict[:3]
                result = self.resolve_conflict(m1, m2, conflict_type, strategy)
                results.append(result)
        
        return results


# 全局实例
_conflict_resolver = None


def get_conflict_resolver(sqlite_store: Optional[SQLiteStore] = None) -> ConflictResolver:
    """获取全局冲突解决器实例"""
    global _conflict_resolver
    if _conflict_resolver is None:
        _conflict_resolver = ConflictResolver(sqlite_store or SQLiteStore())
    return _conflict_resolver

