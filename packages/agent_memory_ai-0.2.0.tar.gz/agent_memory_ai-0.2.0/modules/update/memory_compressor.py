"""
记忆压缩器

压缩和精简记忆
"""
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore


class MemoryCompressor:
    """记忆压缩器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化记忆压缩器"""
        self.sqlite_store = sqlite_store
    
    def compress_memories(
        self,
        memories: List[Memory],
        target_count: int
    ) -> List[Memory]:
        """
        压缩记忆列表
        
        Args:
            memories: 记忆列表
            target_count: 目标数量
        
        Returns:
            压缩后的记忆列表
        """
        if len(memories) <= target_count:
            return memories
        
        # 按重要性排序
        sorted_memories = sorted(memories, key=lambda m: m.importance, reverse=True)
        
        # 保留最重要的
        return sorted_memories[:target_count]
    
    def compress_by_time_window(
        self,
        user_id: str,
        window_days: int = 30,
        target_per_window: int = 10
    ) -> List[Memory]:
        """
        按时间窗口压缩记忆
        
        Args:
            user_id: 用户ID
            window_days: 时间窗口（天）
            target_per_window: 每个窗口保留数量
        
        Returns:
            压缩后的记忆列表
        """
        memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        # 按时间窗口分组
        now = datetime.now()
        windows = {}
        
        for memory in memories:
            window_id = (now - memory.created_at).days // window_days
            if window_id not in windows:
                windows[window_id] = []
            windows[window_id].append(memory)
        
        # 每个窗口压缩
        compressed = []
        for window_memories in windows.values():
            compressed.extend(
                self.compress_memories(window_memories, target_per_window)
            )
        
        return compressed
    
    def summarize_memories(
        self,
        memories: List[Memory],
        summary_length: int = 100
    ) -> str:
        """
        生成记忆摘要
        
        Args:
            memories: 记忆列表
            summary_length: 摘要长度
        
        Returns:
            摘要文本
        """
        if not memories:
            return ""
        
        # 简单实现：提取最重要的几条
        top_memories = sorted(memories, key=lambda m: m.importance, reverse=True)[:5]
        
        summary_parts = []
        for memory in top_memories:
            if len(memory.content) > 50:
                summary_parts.append(memory.content[:50] + "...")
            else:
                summary_parts.append(memory.content)
        
        summary = "；".join(summary_parts)
        
        if len(summary) > summary_length:
            return summary[:summary_length] + "..."
        
        return summary


# 全局实例
_memory_compressor = None


def get_memory_compressor(sqlite_store: Optional[SQLiteStore] = None) -> MemoryCompressor:
    """获取全局记忆压缩器实例"""
    global _memory_compressor
    if _memory_compressor is None:
        _memory_compressor = MemoryCompressor(sqlite_store or SQLiteStore())
    return _memory_compressor

