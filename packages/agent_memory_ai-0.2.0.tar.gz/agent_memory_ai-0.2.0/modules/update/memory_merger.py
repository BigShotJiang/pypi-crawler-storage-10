"""
记忆合并器

合并相似或重复的记忆
"""
from typing import List, Optional, Dict, Any
from datetime import datetime

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore


class MemoryMerger:
    """记忆合并器"""
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化记忆合并器"""
        self.sqlite_store = sqlite_store
    
    def merge_two_memories(
        self,
        memory1: Memory,
        memory2: Memory,
        keep_both_contents: bool = True
    ) -> Memory:
        """
        合并两个记忆
        
        Args:
            memory1: 记忆1
            memory2: 记忆2
            keep_both_contents: 是否保留两者内容
        
        Returns:
            合并后的新记忆
        """
        # 创建新记忆
        merged = Memory(
            id=f"merged_{memory1.id}_{memory2.id}",
            user_id=memory1.user_id,
            content=self._merge_content(memory1.content, memory2.content, keep_both_contents),
            memory_type=memory1.memory_type if memory1.importance > memory2.importance else memory2.memory_type,
            category=memory1.category,
            importance=max(memory1.importance, memory2.importance),
            tags=list(set(memory1.tags + memory2.tags)),
            related_memory_ids=list(set(memory1.related_memory_ids + memory2.related_memory_ids)),
            source_type=memory1.source_type,
            created_at=min(memory1.created_at, memory2.created_at),
            updated_at=datetime.now(),
            access_count=memory1.access_count + memory2.access_count,
            last_access=max(memory1.last_access, memory2.last_access)
        )
        
        # 记录合并来源
        merged.metadata = {
            "merged_from": [memory1.id, memory2.id],
            "merged_at": datetime.now().isoformat()
        }
        
        return merged
    
    def _merge_content(self, content1: str, content2: str, keep_both: bool) -> str:
        """合并内容"""
        if not keep_both:
            return content1 if len(content1) > len(content2) else content2
        
        if content1 == content2:
            return content1
        
        return f"{content1}；{content2}"
    
    def merge_similar_memories(
        self,
        user_id: str,
        similarity_threshold: float = 0.8,
        max_merges: int = 10
    ) -> List[Memory]:
        """
        批量合并相似记忆
        
        Args:
            user_id: 用户ID
            similarity_threshold: 相似度阈值
            max_merges: 最大合并数
        
        Returns:
            合并后的记忆列表
        """
        # 简单实现：找到最相似的对并合并
        memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        merged_memories = []
        merged_ids = set()
        merge_count = 0
        
        for i in range(len(memories)):
            if memories[i].id in merged_ids or merge_count >= max_merges:
                continue
            
            for j in range(i + 1, len(memories)):
                if memories[j].id in merged_ids:
                    continue
                
                # 计算相似度（简化版）
                similarity = self._calculate_similarity(memories[i], memories[j])
                
                if similarity >= similarity_threshold:
                    # 合并
                    merged = self.merge_two_memories(memories[i], memories[j])
                    merged_memories.append(merged)
                    merged_ids.add(memories[i].id)
                    merged_ids.add(memories[j].id)
                    merge_count += 1
                    break
        
        return merged_memories
    
    def _calculate_similarity(self, m1: Memory, m2: Memory) -> float:
        """计算记忆相似度"""
        # 简单的相似度计算
        content1 = set(m1.content.lower().split())
        content2 = set(m2.content.lower().split())
        
        if not content1 or not content2:
            return 0.0
        
        intersection = content1 & content2
        union = content1 | content2
        
        jaccard = len(intersection) / len(union) if union else 0.0
        
        # 考虑标签相似度
        if m1.tags and m2.tags:
            tag_similarity = len(set(m1.tags) & set(m2.tags)) / len(set(m1.tags) | set(m2.tags))
            return jaccard * 0.7 + tag_similarity * 0.3
        
        return jaccard


# 全局实例
_memory_merger = None


def get_memory_merger(sqlite_store: Optional[SQLiteStore] = None) -> MemoryMerger:
    """获取全局记忆合并器实例"""
    global _memory_merger
    if _memory_merger is None:
        _memory_merger = MemoryMerger(sqlite_store or SQLiteStore())
    return _memory_merger

