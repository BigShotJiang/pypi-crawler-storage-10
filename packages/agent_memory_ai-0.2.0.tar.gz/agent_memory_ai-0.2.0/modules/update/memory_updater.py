"""
记忆更新器

更新记忆的内容、重要性等属性
"""
from typing import Optional, Dict, Any
from datetime import datetime

from agent_memory.core.memory import Memory
from agent_memory.storage.sqlite_store import SQLiteStore
from agent_memory.modules.formation import ImportanceScorer


class MemoryUpdater:
    """
    记忆更新器
    
    负责更新记忆的各种属性
    """
    
    def __init__(self, sqlite_store: SQLiteStore):
        """初始化记忆更新器"""
        self.sqlite_store = sqlite_store
        self.scorer = ImportanceScorer()
    
    def update_content(
        self,
        memory_id: str,
        new_content: str,
        recompute_importance: bool = True
    ) -> Optional[Memory]:
        """
        更新记忆内容
        
        Args:
            memory_id: 记忆ID
            new_content: 新内容
            recompute_importance: 是否重新计算重要性
        
        Returns:
            更新后的记忆
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        # 保存旧内容到历史
        old_content = memory.content
        memory.metadata = memory.metadata or {}
        memory.metadata['content_history'] = memory.metadata.get('content_history', [])
        memory.metadata['content_history'].append({
            "content": old_content,
            "updated_at": datetime.now().isoformat()
        })
        
        # 更新内容
        memory.content = new_content
        memory.updated_at = datetime.now()
        
        # 重新计算重要性
        if recompute_importance:
            try:
                new_importance = self.scorer.calculate_importance(
                    new_content,
                    memory.user_id
                )
                memory.importance = new_importance
            except:
                pass  # 如果计算失败，保持原importance
        
        # 保存更新
        self.sqlite_store.update_memory(memory)
        
        return memory
    
    def update_importance(
        self,
        memory_id: str,
        new_importance: Optional[float] = None,
        recompute: bool = False
    ) -> Optional[Memory]:
        """
        更新记忆重要性
        
        Args:
            memory_id: 记忆ID
            new_importance: 新重要性（如果提供）
            recompute: 是否重新计算
        
        Returns:
            更新后的记忆
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        old_importance = memory.importance
        
        if recompute:
            # 重新计算
            try:
                new_importance = self.scorer.calculate_importance(
                    memory.content,
                    memory.user_id
                )
            except:
                return memory
        
        if new_importance is not None:
            memory.importance = max(0.0, min(1.0, new_importance))
            memory.updated_at = datetime.now()
            
            # 记录变化
            memory.metadata = memory.metadata or {}
            memory.metadata['importance_history'] = memory.metadata.get('importance_history', [])
            memory.metadata['importance_history'].append({
                "old": old_importance,
                "new": memory.importance,
                "updated_at": datetime.now().isoformat()
            })
            
            self.sqlite_store.update_memory(memory)
        
        return memory
    
    def update_tags(
        self,
        memory_id: str,
        new_tags: list,
        mode: str = "replace"  # replace/add/remove
    ) -> Optional[Memory]:
        """
        更新记忆标签
        
        Args:
            memory_id: 记忆ID
            new_tags: 新标签列表
            mode: 更新模式
                - replace: 替换所有标签
                - add: 添加标签
                - remove: 移除标签
        
        Returns:
            更新后的记忆
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        if mode == "replace":
            memory.tags = new_tags
        elif mode == "add":
            memory.tags = list(set(memory.tags + new_tags))
        elif mode == "remove":
            memory.tags = [t for t in memory.tags if t not in new_tags]
        
        memory.updated_at = datetime.now()
        self.sqlite_store.update_memory(memory)
        
        return memory
    
    def add_related_memory(
        self,
        memory_id: str,
        related_id: str,
        bidirectional: bool = True
    ) -> bool:
        """
        添加关联记忆
        
        Args:
            memory_id: 记忆ID
            related_id: 关联记忆ID
            bidirectional: 是否双向关联
        
        Returns:
            是否成功
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return False
        
        if related_id not in memory.related_memory_ids:
            memory.related_memory_ids.append(related_id)
            memory.updated_at = datetime.now()
            self.sqlite_store.update_memory(memory)
        
        # 双向关联
        if bidirectional:
            related_memory = self.sqlite_store.get_memory(related_id)
            if related_memory and memory_id not in related_memory.related_memory_ids:
                related_memory.related_memory_ids.append(memory_id)
                related_memory.updated_at = datetime.now()
                self.sqlite_store.update_memory(related_memory)
        
        return True
    
    def remove_related_memory(
        self,
        memory_id: str,
        related_id: str,
        bidirectional: bool = True
    ) -> bool:
        """
        移除关联记忆
        
        Args:
            memory_id: 记忆ID
            related_id: 关联记忆ID
            bidirectional: 是否双向移除
        
        Returns:
            是否成功
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return False
        
        if related_id in memory.related_memory_ids:
            memory.related_memory_ids.remove(related_id)
            memory.updated_at = datetime.now()
            self.sqlite_store.update_memory(memory)
        
        # 双向移除
        if bidirectional:
            related_memory = self.sqlite_store.get_memory(related_id)
            if related_memory and memory_id in related_memory.related_memory_ids:
                related_memory.related_memory_ids.remove(memory_id)
                related_memory.updated_at = datetime.now()
                self.sqlite_store.update_memory(related_memory)
        
        return True
    
    def update_metadata(
        self,
        memory_id: str,
        metadata: Dict[str, Any],
        merge: bool = True
    ) -> Optional[Memory]:
        """
        更新记忆元数据
        
        Args:
            memory_id: 记忆ID
            metadata: 新元数据
            merge: 是否合并（否则替换）
        
        Returns:
            更新后的记忆
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        if merge:
            memory.metadata = memory.metadata or {}
            memory.metadata.update(metadata)
        else:
            memory.metadata = metadata
        
        memory.updated_at = datetime.now()
        self.sqlite_store.update_memory(memory)
        
        return memory
    
    def increment_access_count(self, memory_id: str) -> Optional[Memory]:
        """
        增加访问计数
        
        Args:
            memory_id: 记忆ID
        
        Returns:
            更新后的记忆
        """
        memory = self.sqlite_store.get_memory(memory_id)
        if not memory:
            return None
        
        memory.access_count += 1
        memory.last_access = datetime.now()
        
        self.sqlite_store.update_memory(memory)
        
        return memory
    
    def batch_update_importance(
        self,
        user_id: str,
        recompute: bool = True
    ) -> int:
        """
        批量更新重要性
        
        Args:
            user_id: 用户ID
            recompute: 是否重新计算
        
        Returns:
            更新数量
        """
        memories = self.sqlite_store.get_memories_by_user(user_id, limit=1000)
        
        updated_count = 0
        
        for memory in memories:
            if recompute:
                try:
                    new_importance = self.scorer.calculate_importance(
                        memory.content,
                        user_id
                    )
                    memory.importance = new_importance
                    memory.updated_at = datetime.now()
                    self.sqlite_store.update_memory(memory)
                    updated_count += 1
                except:
                    pass
        
        return updated_count


# 全局实例
_memory_updater = None


def get_memory_updater(sqlite_store: Optional[SQLiteStore] = None) -> MemoryUpdater:
    """获取全局记忆更新器实例"""
    global _memory_updater
    if _memory_updater is None:
        _memory_updater = MemoryUpdater(sqlite_store or SQLiteStore())
    return _memory_updater

