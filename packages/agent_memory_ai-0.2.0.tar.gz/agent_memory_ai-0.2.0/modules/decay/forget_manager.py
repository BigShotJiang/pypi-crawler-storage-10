"""
遗忘管理器

实现记忆的自动和手动遗忘机制
"""
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

from agent_memory.core.memory import Memory, PrivacyLevel
from agent_memory.storage.sqlite_store import SQLiteStore


@dataclass
class ForgetResult:
    """遗忘结果"""
    deleted_count: int
    deleted_ids: List[str]
    cascade_deleted: List[str]  # 级联删除的ID
    reason: str
    timestamp: datetime


class ForgetManager:
    """遗忘管理器"""
    
    def __init__(
        self,
        sqlite_store: SQLiteStore,
        auto_delete_threshold: float = 0.2,  # 自动删除阈值
        sensitive_ttl_days: int = 30,  # 敏感信息TTL
        private_ttl_days: int = 90,    # 私密信息TTL
    ):
        """
        初始化遗忘管理器
        
        Args:
            sqlite_store: SQLite存储
            auto_delete_threshold: 自动删除的重要性阈值
            sensitive_ttl_days: 敏感信息未访问多久后删除
            private_ttl_days: 私密信息未访问多久后删除
        """
        self.store = sqlite_store
        self.auto_delete_threshold = auto_delete_threshold
        self.sensitive_ttl_days = sensitive_ttl_days
        self.private_ttl_days = private_ttl_days
        
        # 遗忘日志（不包含具体内容）
        self.forget_log: List[Dict] = []
    
    def forget_by_id(
        self,
        memory_id: str,
        user_id: str,
        cascade: bool = True,
        reason: str = "user_request"
    ) -> ForgetResult:
        """
        按ID遗忘记忆
        
        Args:
            memory_id: 记忆ID
            user_id: 用户ID
            cascade: 是否级联删除关联记忆
            reason: 遗忘原因
        
        Returns:
            遗忘结果
        """
        memory = self.store.get_memory(memory_id)
        if not memory or memory.user_id != user_id:
            return ForgetResult(
                deleted_count=0,
                deleted_ids=[],
                cascade_deleted=[],
                reason=reason,
                timestamp=datetime.now()
            )
        
        cascade_deleted = []
        
        # 级联删除关联记忆
        if cascade and memory.related_memory_ids:
            cascade_deleted = self._cascade_delete(
                memory,
                user_id,
                reason=f"cascade_from_{memory_id}"
            )
        
        # 删除主记忆
        self.store.delete_memory(memory_id, user_id)
        
        # 记录遗忘日志
        self._log_forget(memory, reason)
        
        return ForgetResult(
            deleted_count=1,
            deleted_ids=[memory_id],
            cascade_deleted=cascade_deleted,
            reason=reason,
            timestamp=datetime.now()
        )
    
    def forget_by_query(
        self,
        query: str,
        user_id: str,
        cascade: bool = True,
        confirm: bool = True
    ) -> Tuple[ForgetResult, Optional[List[Memory]]]:
        """
        按查询条件遗忘记忆
        
        Args:
            query: 查询条件
            user_id: 用户ID
            cascade: 是否级联删除
            confirm: 是否需要确认（True返回待删除列表，False直接删除）
        
        Returns:
            (遗忘结果, 待确认的记忆列表)
        """
        # 搜索匹配的记忆
        matching_memories = self._search_memories_for_forget(query, user_id)
        
        if confirm:
            # 返回待确认列表
            return (
                ForgetResult(
                    deleted_count=0,
                    deleted_ids=[],
                    cascade_deleted=[],
                    reason="pending_confirmation",
                    timestamp=datetime.now()
                ),
                matching_memories
            )
        
        # 直接删除
        deleted_ids = []
        cascade_deleted = []
        
        for memory in matching_memories:
            result = self.forget_by_id(
                memory.id,
                user_id,
                cascade=cascade,
                reason=f"query:{query}"
            )
            deleted_ids.extend(result.deleted_ids)
            cascade_deleted.extend(result.cascade_deleted)
        
        return (
            ForgetResult(
                deleted_count=len(deleted_ids),
                deleted_ids=deleted_ids,
                cascade_deleted=cascade_deleted,
                reason=f"query:{query}",
                timestamp=datetime.now()
            ),
            None
        )
    
    def forget_by_time_range(
        self,
        user_id: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        cascade: bool = False
    ) -> ForgetResult:
        """
        按时间范围遗忘记忆
        
        Args:
            user_id: 用户ID
            start_time: 开始时间
            end_time: 结束时间
            cascade: 是否级联删除
        
        Returns:
            遗忘结果
        """
        memories = self.store.get_memories_by_user(user_id)
        
        deleted_ids = []
        cascade_deleted = []
        
        for memory in memories:
            # 检查时间范围
            if start_time and memory.created_at < start_time:
                continue
            if end_time and memory.created_at > end_time:
                continue
            
            result = self.forget_by_id(
                memory.id,
                user_id,
                cascade=cascade,
                reason="time_range_delete"
            )
            deleted_ids.extend(result.deleted_ids)
            cascade_deleted.extend(result.cascade_deleted)
        
        return ForgetResult(
            deleted_count=len(deleted_ids),
            deleted_ids=deleted_ids,
            cascade_deleted=cascade_deleted,
            reason="time_range_delete",
            timestamp=datetime.now()
        )
    
    def forget_by_tags(
        self,
        user_id: str,
        tags: List[str],
        match_all: bool = False,
        cascade: bool = False
    ) -> ForgetResult:
        """
        按标签遗忘记忆
        
        Args:
            user_id: 用户ID
            tags: 标签列表
            match_all: 是否匹配所有标签（True=AND, False=OR）
            cascade: 是否级联删除
        
        Returns:
            遗忘结果
        """
        memories = self.store.get_memories_by_user(user_id)
        
        deleted_ids = []
        cascade_deleted = []
        
        for memory in memories:
            # 检查标签匹配
            if match_all:
                # AND：必须包含所有标签
                if not all(tag in memory.tags for tag in tags):
                    continue
            else:
                # OR：包含任意标签
                if not any(tag in memory.tags for tag in tags):
                    continue
            
            result = self.forget_by_id(
                memory.id,
                user_id,
                cascade=cascade,
                reason=f"tags:{','.join(tags)}"
            )
            deleted_ids.extend(result.deleted_ids)
            cascade_deleted.extend(result.cascade_deleted)
        
        return ForgetResult(
            deleted_count=len(deleted_ids),
            deleted_ids=deleted_ids,
            cascade_deleted=cascade_deleted,
            reason=f"tags:{','.join(tags)}",
            timestamp=datetime.now()
        )
    
    def auto_forget(self, user_id: str) -> ForgetResult:
        """
        自动遗忘策略
        
        删除：
        1. 低重要性且长期未访问的记忆
        2. 过期的敏感信息
        3. 标记为一次性的已使用记忆
        
        Args:
            user_id: 用户ID
        
        Returns:
            遗忘结果
        """
        memories = self.store.get_memories_by_user(user_id)
        current_time = datetime.now()
        
        deleted_ids = []
        cascade_deleted = []
        
        for memory in memories:
            should_delete = False
            delete_reason = ""
            
            # 1. 低重要性且长期未访问
            days_since_access = (current_time - memory.updated_at).total_seconds() / 86400
            if memory.importance < self.auto_delete_threshold and days_since_access > 60:
                should_delete = True
                delete_reason = "low_importance_old"
            
            # 2. 过期的敏感信息
            if memory.privacy_level == PrivacyLevel.SENSITIVE:
                if days_since_access > self.sensitive_ttl_days:
                    should_delete = True
                    delete_reason = "sensitive_expired"
            
            if memory.privacy_level == PrivacyLevel.PRIVATE:
                if days_since_access > self.private_ttl_days:
                    should_delete = True
                    delete_reason = "private_expired"
            
            # 3. 一次性信息已使用
            if memory.metadata.get('is_ephemeral') and memory.metadata.get('is_used'):
                should_delete = True
                delete_reason = "ephemeral_used"
            
            # 4. 标记了自动删除日期
            if 'auto_delete_date' in memory.metadata:
                delete_date_str = memory.metadata['auto_delete_date']
                try:
                    delete_date = datetime.fromisoformat(delete_date_str)
                    if current_time > delete_date:
                        should_delete = True
                        delete_reason = "auto_delete_date_reached"
                except (ValueError, TypeError):
                    pass
            
            # 执行删除
            if should_delete:
                result = self.forget_by_id(
                    memory.id,
                    user_id,
                    cascade=False,  # 自动删除不级联
                    reason=delete_reason
                )
                deleted_ids.extend(result.deleted_ids)
        
        return ForgetResult(
            deleted_count=len(deleted_ids),
            deleted_ids=deleted_ids,
            cascade_deleted=[],
            reason="auto_forget_policy",
            timestamp=current_time
        )
    
    def _cascade_delete(
        self,
        memory: Memory,
        user_id: str,
        reason: str
    ) -> List[str]:
        """
        级联删除关联记忆
        
        Args:
            memory: 主记忆
            user_id: 用户ID
            reason: 删除原因
        
        Returns:
            级联删除的记忆ID列表
        """
        cascade_deleted = []
        
        if not memory.related_memory_ids:
            return cascade_deleted
        
        for related_id in memory.related_memory_ids:
            related = self.store.get_memory(related_id)
            if not related or related.user_id != user_id:
                continue
            
            # 检查依赖强度
            dependency = memory.metadata.get('associations', {}).get(related_id, {}).get('strength', 0.5)
            
            # 强依赖：一起删除
            if dependency > 0.7:
                self.store.delete_memory(related_id, user_id)
                cascade_deleted.append(related_id)
                self._log_forget(related, reason)
            
            # 弱依赖：只移除关联
            else:
                if related_id in related.related_memory_ids:
                    related.related_memory_ids.remove(memory.id)
                    self.store.update_memory(related)
        
        return cascade_deleted
    
    def _search_memories_for_forget(
        self,
        query: str,
        user_id: str
    ) -> List[Memory]:
        """
        搜索要遗忘的记忆
        
        Args:
            query: 查询条件
            user_id: 用户ID
        
        Returns:
            匹配的记忆列表
        """
        memories = self.store.get_memories_by_user(user_id)
        matching = []
        
        query_lower = query.lower()
        
        for memory in memories:
            # 内容匹配
            if query_lower in memory.content.lower():
                matching.append(memory)
                continue
            
            # 标签匹配
            if any(query_lower in tag.lower() for tag in memory.tags):
                matching.append(memory)
                continue
        
        return matching
    
    def _log_forget(self, memory: Memory, reason: str):
        """
        记录遗忘日志（不包含具体内容）
        
        Args:
            memory: 记忆对象
            reason: 遗忘原因
        """
        log_entry = {
            'memory_id': memory.id,
            'user_id': memory.user_id,
            'memory_type': memory.memory_type.value,
            'category': memory.category.value,
            'importance': memory.importance,
            'created_at': memory.created_at.isoformat(),
            'deleted_at': datetime.now().isoformat(),
            'reason': reason
        }
        
        self.forget_log.append(log_entry)
        
        # 只保留最近1000条日志
        if len(self.forget_log) > 1000:
            self.forget_log = self.forget_log[-1000:]
    
    def get_forget_statistics(self, user_id: Optional[str] = None) -> Dict:
        """
        获取遗忘统计信息
        
        Args:
            user_id: 用户ID（可选）
        
        Returns:
            统计信息
        """
        logs = self.forget_log
        
        if user_id:
            logs = [log for log in logs if log['user_id'] == user_id]
        
        stats = {
            'total_forgotten': len(logs),
            'by_reason': {},
            'by_type': {},
            'by_category': {},
            'recent_30_days': 0
        }
        
        cutoff_date = datetime.now() - timedelta(days=30)
        
        for log in logs:
            # 按原因统计
            reason = log['reason']
            stats['by_reason'][reason] = stats['by_reason'].get(reason, 0) + 1
            
            # 按类型统计
            memory_type = log['memory_type']
            stats['by_type'][memory_type] = stats['by_type'].get(memory_type, 0) + 1
            
            # 按类别统计
            category = log['category']
            stats['by_category'][category] = stats['by_category'].get(category, 0) + 1
            
            # 最近30天
            deleted_at = datetime.fromisoformat(log['deleted_at'])
            if deleted_at >= cutoff_date:
                stats['recent_30_days'] += 1
        
        return stats
    
    def clear_all_memories(
        self,
        user_id: str,
        confirm_code: str
    ) -> ForgetResult:
        """
        清除用户所有记忆（危险操作，需要确认码）
        
        Args:
            user_id: 用户ID
            confirm_code: 确认码（应为用户ID的hash）
        
        Returns:
            遗忘结果
        """
        # 简单的确认机制
        import hashlib
        expected_code = hashlib.md5(user_id.encode()).hexdigest()[:8]
        
        if confirm_code != expected_code:
            return ForgetResult(
                deleted_count=0,
                deleted_ids=[],
                cascade_deleted=[],
                reason="invalid_confirmation",
                timestamp=datetime.now()
            )
        
        memories = self.store.get_memories_by_user(user_id)
        deleted_ids = []
        
        for memory in memories:
            self.store.delete_memory(memory.id, user_id)
            deleted_ids.append(memory.id)
            self._log_forget(memory, "user_clear_all")
        
        return ForgetResult(
            deleted_count=len(deleted_ids),
            deleted_ids=deleted_ids,
            cascade_deleted=[],
            reason="user_clear_all",
            timestamp=datetime.now()
        )

