"""
记忆衰减管理器

实现记忆的自动衰减和晋升机制
"""
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import math

from agent_memory.core.memory import Memory, MemoryType
from agent_memory.storage.sqlite_store import SQLiteStore


class DecayManager:
    """记忆衰减管理器"""
    
    def __init__(
        self,
        sqlite_store: SQLiteStore,
        work_memory_ttl: int = 1,  # 工作记忆存活天数
        short_term_ttl: int = 7,   # 短期记忆存活天数
        mid_term_ttl: int = 30,    # 中期记忆存活天数
        promotion_threshold: float = 0.6,  # 晋升阈值
        decay_rate: float = 0.1,  # 衰减率
    ):
        """
        初始化衰减管理器
        
        Args:
            sqlite_store: SQLite存储
            work_memory_ttl: 工作记忆存活天数
            short_term_ttl: 短期记忆存活天数
            mid_term_ttl: 中期记忆存活天数
            promotion_threshold: 晋升阈值
            decay_rate: 衰减率（每天）
        """
        self.store = sqlite_store
        self.work_memory_ttl = work_memory_ttl
        self.short_term_ttl = short_term_ttl
        self.mid_term_ttl = mid_term_ttl
        self.promotion_threshold = promotion_threshold
        self.decay_rate = decay_rate
    
    def calculate_decay(
        self,
        memory: Memory,
        current_time: Optional[datetime] = None
    ) -> float:
        """
        计算记忆的衰减后重要性
        
        基于艾宾浩斯遗忘曲线：R = e^(-t/S)
        其中：
        - R: 保留率
        - t: 时间
        - S: 记忆强度（基于重要性和访问次数）
        
        Args:
            memory: 记忆对象
            current_time: 当前时间（用于测试）
        
        Returns:
            衰减后的重要性
        """
        if current_time is None:
            current_time = datetime.now()
        
        # 计算时间差（天）
        time_delta = (current_time - memory.updated_at).total_seconds() / 86400
        
        # 计算记忆强度（基于重要性和访问次数）
        # 访问次数越多，衰减越慢
        access_factor = 1 + math.log(1 + memory.access_count)
        memory_strength = memory.importance * access_factor
        
        # 应用遗忘曲线
        retention_rate = math.exp(-time_delta / (memory_strength * 10))
        
        # 计算衰减后的重要性
        decayed_importance = memory.importance * retention_rate
        
        return max(0.0, min(1.0, decayed_importance))
    
    def should_promote(self, memory: Memory) -> bool:
        """
        判断记忆是否应该晋升
        
        Args:
            memory: 记忆对象
        
        Returns:
            是否应该晋升
        """
        current_time = datetime.now()
        age_days = (current_time - memory.created_at).total_seconds() / 86400
        
        # 工作记忆 → 短期记忆
        if memory.memory_type == MemoryType.WORK:
            if age_days >= self.work_memory_ttl:
                # 重要性高或访问频繁则晋升
                if memory.importance >= self.promotion_threshold or memory.access_count >= 3:
                    return True
        
        # 短期记忆 → 中期记忆
        elif memory.memory_type == MemoryType.SHORT:
            if age_days >= self.short_term_ttl:
                if memory.importance >= self.promotion_threshold or memory.access_count >= 5:
                    return True
        
        # 中期记忆 → 长期记忆
        elif memory.memory_type == MemoryType.MID:
            if age_days >= self.mid_term_ttl:
                if memory.importance >= self.promotion_threshold or memory.access_count >= 10:
                    return True
        
        return False
    
    def should_archive(self, memory: Memory) -> bool:
        """
        判断记忆是否应该归档（降级）
        
        Args:
            memory: 记忆对象
        
        Returns:
            是否应该归档
        """
        current_time = datetime.now()
        age_days = (current_time - memory.created_at).total_seconds() / 86400
        days_since_access = (current_time - memory.updated_at).total_seconds() / 86400
        
        # 计算衰减后的重要性
        decayed_importance = self.calculate_decay(memory)
        
        # 工作记忆：超过TTL且重要性低
        if memory.memory_type == MemoryType.WORK:
            if age_days > self.work_memory_ttl and decayed_importance < 0.3:
                return True
        
        # 短期记忆：超过TTL且重要性低
        elif memory.memory_type == MemoryType.SHORT:
            if age_days > self.short_term_ttl and decayed_importance < 0.3:
                return True
        
        # 中期记忆：超过TTL且长期未访问
        elif memory.memory_type == MemoryType.MID:
            if age_days > self.mid_term_ttl and days_since_access > 60 and decayed_importance < 0.4:
                return True
        
        # 长期记忆：长期未访问且重要性低
        elif memory.memory_type == MemoryType.LONG:
            if days_since_access > 180 and decayed_importance < 0.3:
                return True
        
        return False
    
    def promote_memory(self, memory: Memory) -> Memory:
        """
        晋升记忆到更高级别
        
        Args:
            memory: 记忆对象
        
        Returns:
            晋升后的记忆
        """
        if memory.memory_type == MemoryType.WORK:
            memory.memory_type = MemoryType.SHORT
        elif memory.memory_type == MemoryType.SHORT:
            memory.memory_type = MemoryType.MID
        elif memory.memory_type == MemoryType.MID:
            memory.memory_type = MemoryType.LONG
        # LONG和CORE不再晋升
        
        # 更新时间
        memory.updated_at = datetime.now()
        
        # 记录晋升历史
        if 'promotion_history' not in memory.metadata:
            memory.metadata['promotion_history'] = []
        
        memory.metadata['promotion_history'].append({
            'from': memory.memory_type.value,
            'to': memory.memory_type.value,
            'timestamp': datetime.now().isoformat(),
            'importance': memory.importance,
            'access_count': memory.access_count
        })
        
        return memory
    
    def apply_decay(self, memory: Memory) -> Memory:
        """
        应用衰减到记忆
        
        Args:
            memory: 记忆对象
        
        Returns:
            衰减后的记忆
        """
        # 核心记忆不衰减
        if memory.memory_type == MemoryType.CORE:
            return memory
        
        # 计算衰减后的重要性
        decayed_importance = self.calculate_decay(memory)
        
        # 记录衰减历史
        if 'decay_history' not in memory.metadata:
            memory.metadata['decay_history'] = []
        
        if len(memory.metadata['decay_history']) < 10:  # 只保留最近10次
            memory.metadata['decay_history'].append({
                'timestamp': datetime.now().isoformat(),
                'before': memory.importance,
                'after': decayed_importance
            })
        
        # 更新重要性
        memory.importance = decayed_importance
        memory.updated_at = datetime.now()
        
        return memory
    
    def process_memory_lifecycle(
        self,
        user_id: str,
        auto_promote: bool = True,
        auto_archive: bool = True,
        auto_decay: bool = True
    ) -> Dict:
        """
        处理用户所有记忆的生命周期
        
        Args:
            user_id: 用户ID
            auto_promote: 是否自动晋升
            auto_archive: 是否自动归档
            auto_decay: 是否自动衰减
        
        Returns:
            处理结果统计
        """
        result = {
            'processed': 0,
            'promoted': 0,
            'archived': 0,
            'decayed': 0,
            'errors': []
        }
        
        # 获取所有记忆
        memories = self.store.get_memories_by_user(user_id)
        
        for memory in memories:
            try:
                result['processed'] += 1
                updated = False
                
                # 1. 检查是否应该晋升
                if auto_promote and self.should_promote(memory):
                    memory = self.promote_memory(memory)
                    result['promoted'] += 1
                    updated = True
                
                # 2. 检查是否应该归档
                elif auto_archive and self.should_archive(memory):
                    # 归档标记（可以选择删除或标记为归档）
                    memory.metadata['archived'] = True
                    memory.metadata['archived_at'] = datetime.now().isoformat()
                    result['archived'] += 1
                    updated = True
                
                # 3. 应用衰减
                if auto_decay:
                    old_importance = memory.importance
                    memory = self.apply_decay(memory)
                    if memory.importance != old_importance:
                        result['decayed'] += 1
                        updated = True
                
                # 保存更新
                if updated:
                    self.store.update_memory(memory)
                    
            except Exception as e:
                result['errors'].append({
                    'memory_id': memory.id,
                    'error': str(e)
                })
        
        return result
    
    def reinforce_memory(self, memory: Memory, boost: float = 0.1) -> Memory:
        """
        强化记忆（因为被访问）
        
        Args:
            memory: 记忆对象
            boost: 强化幅度
        
        Returns:
            强化后的记忆
        """
        # 增加访问次数
        memory.access_count += 1
        
        # 轻微提升重要性（但不超过原始重要性的1.2倍）
        original_importance = memory.metadata.get('original_importance', memory.importance)
        max_importance = min(1.0, original_importance * 1.2)
        
        memory.importance = min(max_importance, memory.importance + boost)
        memory.updated_at = datetime.now()
        
        # 记录强化历史
        if 'reinforcement_history' not in memory.metadata:
            memory.metadata['reinforcement_history'] = []
        
        if len(memory.metadata['reinforcement_history']) < 10:
            memory.metadata['reinforcement_history'].append({
                'timestamp': datetime.now().isoformat(),
                'boost': boost,
                'new_importance': memory.importance
            })
        
        return memory
    
    def get_decay_statistics(self, user_id: str) -> Dict:
        """
        获取衰减统计信息
        
        Args:
            user_id: 用户ID
        
        Returns:
            统计信息
        """
        memories = self.store.get_memories_by_user(user_id)
        
        stats = {
            'total': len(memories),
            'by_type': {
                'work': 0,
                'short': 0,
                'mid': 0,
                'long': 0,
                'core': 0
            },
            'should_promote': 0,
            'should_archive': 0,
            'avg_decay': 0.0,
            'avg_importance': 0.0
        }
        
        total_decay = 0.0
        total_importance = 0.0
        
        for memory in memories:
            # 统计类型分布
            stats['by_type'][memory.memory_type.value] += 1
            
            # 统计应该晋升的数量
            if self.should_promote(memory):
                stats['should_promote'] += 1
            
            # 统计应该归档的数量
            if self.should_archive(memory):
                stats['should_archive'] += 1
            
            # 计算平均衰减
            decayed = self.calculate_decay(memory)
            total_decay += (memory.importance - decayed)
            total_importance += memory.importance
        
        if len(memories) > 0:
            stats['avg_decay'] = total_decay / len(memories)
            stats['avg_importance'] = total_importance / len(memories)
        
        return stats

