"""
Agent Memory - 智能Agent记忆管理系统
"""
from setuptools import setup, find_packages
import os

# 读取README
def read_file(filename):
    with open(os.path.join(os.path.dirname(__file__), filename), encoding='utf-8') as f:
        return f.read()

# 读取requirements
def read_requirements(filename):
    with open(os.path.join(os.path.dirname(__file__), filename), encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name="agent-memory-ai",
    version="0.2.0",
    author="yixiaobai",
    author_email="yixiaobai1102@gmail.com",
    description="一个完整的、智能的、多层次的Agent记忆管理系统",
    long_description=read_file("README.md"),
    long_description_content_type="text/markdown",
    license="MIT",
    url="https://pypi.org/project/agent-memory-ai/",
    packages=[
        'agent_memory',
        'agent_memory.core',
        'agent_memory.storage',
        'agent_memory.utils',
        'agent_memory.modules',
        'agent_memory.modules.formation',
        'agent_memory.modules.retrieval',
        'agent_memory.modules.update',
        'agent_memory.modules.decay',
        'agent_memory.modules.session',
    ],
    package_dir={'agent_memory': '.'},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "sqlalchemy>=2.0.0",
        "openai>=1.0.0",
    ],
    extras_require={
        "full": [
            "chromadb>=0.4.0",
            "sentence-transformers>=2.2.0",
            "jieba>=0.42.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "agent-memory=agent_memory.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "agent_memory": ["config.json"],
    },
    keywords=[
        "agent",
        "memory",
        "llm",
        "ai",
        "chatbot",
        "knowledge-management",
        "vector-database",
        "memory-management",
    ],
    project_urls={
        "PyPI": "https://test.pypi.org/project/agent-memory-ai/",
    },
)

