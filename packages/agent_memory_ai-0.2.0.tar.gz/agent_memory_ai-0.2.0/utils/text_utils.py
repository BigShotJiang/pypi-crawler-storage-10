"""
文本处理工具

提供文本清洗、分词、关键词提取等功能
"""
import re
from typing import List, Set, TYPE_CHECKING

if TYPE_CHECKING:
    import jieba
    import jieba.analyse
else:
    try:
        import jieba
        import jieba.analyse
        JIEBA_AVAILABLE = True
    except ImportError:
        jieba = None
        JIEBA_AVAILABLE = False


class TextProcessor:
    """文本处理器"""
    
    def __init__(self):
        # 初始化jieba（如果可用）
        if JIEBA_AVAILABLE:
            jieba.setLogLevel(jieba.logging.INFO)
    
    def clean_text(self, text: str) -> str:
        """
        清洗文本
        
        - 去除多余空白
        - 统一标点符号
        """
        # 去除多余空白
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        return text
    
    def segment(self, text: str) -> List[str]:
        """
        中文分词
        
        Args:
            text: 原文
        
        Returns:
            分词结果
        """
        if JIEBA_AVAILABLE:
            return list(jieba.cut(text))
        else:
            # 简单的按空格和标点分割
            return re.findall(r'\w+', text)
    
    def extract_keywords(self, text: str, top_k: int = 10) -> List[str]:
        """
        提取关键词
        
        使用TF-IDF算法
        
        Args:
            text: 原文
            top_k: 提取关键词数量
        
        Returns:
            关键词列表
        """
        if JIEBA_AVAILABLE:
            keywords = jieba.analyse.extract_tags(text, topK=top_k, withWeight=False)
            return keywords
        else:
            # 简单的词频统计
            words = re.findall(r'\w+', text.lower())
            stopwords = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人',
                        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at'}
            words = [w for w in words if w not in stopwords and len(w) > 1]
            
            # 简单词频统计
            word_freq = {}
            for w in words:
                word_freq[w] = word_freq.get(w, 0) + 1
            
            # 返回频率最高的top_k个词
            sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
            return [w for w, f in sorted_words[:top_k]]
    
    def extract_keywords_with_weight(self, text: str, top_k: int = 10) -> List[tuple]:
        """
        提取关键词（带权重）
        
        Args:
            text: 原文
            top_k: 提取关键词数量
        
        Returns:
            [(keyword, weight), ...]
        """
        keywords = jieba.analyse.extract_tags(text, topK=top_k, withWeight=True)
        return keywords
    
    def remove_stopwords(self, words: List[str], custom_stopwords: Set[str] = None) -> List[str]:
        """
        去除停用词
        
        Args:
            words: 词列表
            custom_stopwords: 自定义停用词集合
        
        Returns:
            过滤后的词列表
        """
        # 默认停用词
        default_stopwords = {
            '的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一',
            '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有',
            '看', '好', '自己', '这'
        }
        
        if custom_stopwords:
            stopwords = default_stopwords | custom_stopwords
        else:
            stopwords = default_stopwords
        
        return [w for w in words if w not in stopwords and len(w) > 1]
    
    def calculate_similarity(self, text1: str, text2: str) -> float:
        """
        计算两个文本的相似度（简单版本）
        
        基于词重叠率
        
        Returns:
            相似度分数 (0-1)
        """
        words1 = set(self.segment(text1))
        words2 = set(self.segment(text2))
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.0
    
    def truncate(self, text: str, max_length: int = 100, suffix: str = "...") -> str:
        """
        截断文本
        
        Args:
            text: 原文
            max_length: 最大长度
            suffix: 后缀
        
        Returns:
            截断后的文本
        """
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix


# 全局实例
_text_processor = TextProcessor()


def clean_text(text: str) -> str:
    """快捷函数：清洗文本"""
    return _text_processor.clean_text(text)


def extract_keywords(text: str, top_k: int = 10) -> List[str]:
    """快捷函数：提取关键词"""
    return _text_processor.extract_keywords(text, top_k)


def segment(text: str) -> List[str]:
    """快捷函数：分词"""
    return _text_processor.segment(text)

