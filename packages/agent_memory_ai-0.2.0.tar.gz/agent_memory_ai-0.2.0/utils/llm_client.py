"""
大模型调用客户端

封装LLM API调用，从config.json读取配置
"""
from typing import List, Dict, Any, Optional
from openai import OpenAI

from agent_memory.core.config import get_config


class LLMClient:
    """
    大模型客户端
    
    封装OpenAI兼容的API调用
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        config = get_config()
        
        # 初始化OpenAI客户端
        # 处理不同版本的兼容性问题
        try:
            import httpx
            # 创建一个自定义的httpx客户端，避免代理参数问题
            http_client = httpx.Client(
                timeout=60.0,
                follow_redirects=True
            )
            self.client = OpenAI(
                api_key=config.llm_api_key,
                base_url=config.llm_base_url,
                http_client=http_client
            )
        except (TypeError, ImportError):
            # 如果失败，使用简单初始化
            self.client = OpenAI(
                api_key=config.llm_api_key,
                base_url=config.llm_base_url
            )
        
        self.model = config.llm_model
        self.temperature = config.llm_temperature
        self.max_tokens = config.llm_max_tokens
        
        self._initialized = True
    
    def chat(
        self, 
        messages: List[Dict[str, str]], 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        聊天接口
        
        Args:
            messages: 消息列表，格式: [{"role": "user", "content": "..."}]
            temperature: 温度参数（可选）
            max_tokens: 最大token数（可选）
        
        Returns:
            模型的回复文本
        """
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature if temperature is not None else self.temperature,
            max_tokens=max_tokens if max_tokens is not None else self.max_tokens,
            **kwargs
        )
        
        return response.choices[0].message.content
    
    def chat_with_system(
        self, 
        system_prompt: str, 
        user_message: str,
        temperature: Optional[float] = None,
        **kwargs
    ) -> str:
        """
        带系统提示的聊天
        
        Args:
            system_prompt: 系统提示
            user_message: 用户消息
            temperature: 温度参数
        
        Returns:
            模型回复
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ]
        return self.chat(messages, temperature=temperature, **kwargs)
    
    def extract_json(
        self,
        prompt: str,
        schema_description: Optional[str] = None
    ) -> str:
        """
        提取JSON格式的回复
        
        Args:
            prompt: 提示词
            schema_description: JSON格式说明
        
        Returns:
            清理后的JSON字符串
        """
        system_prompt = "你是一个专业的信息提取助手，请严格按照要求以JSON格式回复，不要包含```json标记。"
        if schema_description:
            system_prompt += f"\n\n期望的JSON格式：\n{schema_description}"
        
        response = self.chat_with_system(
            system_prompt=system_prompt,
            user_message=prompt,
            temperature=0.3  # 降低温度提高稳定性
        )
        
        # 清理response，移除markdown代码块标记
        response = response.strip()
        
        # 移除```json或```标记
        if response.startswith('```json'):
            response = response[7:]
        elif response.startswith('```'):
            response = response[3:]
        
        if response.endswith('```'):
            response = response[:-3]
        
        return response.strip()
    
    def summarize(self, text: str, max_length: int = 200) -> str:
        """
        文本摘要
        
        Args:
            text: 原文
            max_length: 摘要最大长度（字符）
        
        Returns:
            摘要文本
        """
        prompt = f"请将以下文本总结为{max_length}字以内的摘要：\n\n{text}"
        return self.chat_with_system(
            system_prompt="你是一个专业的文本摘要助手。",
            user_message=prompt,
            temperature=0.5
        )
    
    def analyze_emotion(self, text: str) -> Dict[str, Any]:
        """
        情感分析
        
        Args:
            text: 待分析文本
        
        Returns:
            情感分析结果
        """
        prompt = f"""请分析以下文本的情感倾向，以JSON格式返回：
{{
    "emotion": "positive/negative/neutral",
    "intensity": 0.0-1.0,
    "keywords": ["关键词1", "关键词2"]
}}

文本：{text}"""
        
        result = self.extract_json(prompt)
        
        # 解析JSON
        try:
            import json
            return json.loads(result)
        except:
            return {"emotion": "neutral", "intensity": 0.5, "keywords": []}


# 全局单例
_llm_client = None


def get_llm_client() -> LLMClient:
    """获取全局LLM客户端"""
    global _llm_client
    if _llm_client is None:
        _llm_client = LLMClient()
    return _llm_client


def chat(messages: List[Dict[str, str]], **kwargs) -> str:
    """快捷函数：聊天"""
    client = get_llm_client()
    return client.chat(messages, **kwargs)


def summarize(text: str, max_length: int = 200) -> str:
    """快捷函数：摘要"""
    client = get_llm_client()
    return client.summarize(text, max_length)

