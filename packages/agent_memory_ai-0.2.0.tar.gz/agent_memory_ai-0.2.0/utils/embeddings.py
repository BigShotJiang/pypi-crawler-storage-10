"""
向量化工具

使用sentence-transformers生成文本的向量表示
"""
from typing import List, Union, Optional, TYPE_CHECKING
from functools import lru_cache

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer
else:
    try:
        from sentence_transformers import SentenceTransformer
        SENTENCE_TRANSFORMERS_AVAILABLE = True
    except ImportError:
        SentenceTransformer = None
        SENTENCE_TRANSFORMERS_AVAILABLE = False

from agent_memory.core.config import get_config


class EmbeddingGenerator:
    """
    文本向量化生成器
    
    使用sentence-transformers将文本转换为向量
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            self.model = None
            self._initialized = True
            return
        
        config = get_config()
        
        # 加载模型
        self.model_name = config.embedding_model
        self.device = config.embedding_device
        self.batch_size = config.embedding_batch_size
        
        print(f"正在加载向量化模型: {self.model_name}...")
        self.model = SentenceTransformer(
            self.model_name,
            device=self.device,
            cache_folder=config.embedding_cache_folder
        )
        print("向量化模型加载完成")
        
        self._initialized = True
    
    def encode(self, text: Union[str, List[str]], show_progress: bool = False) -> Union[List[float], List[List[float]]]:
        """
        将文本编码为向量
        
        Args:
            text: 单个文本或文本列表
            show_progress: 是否显示进度条
        
        Returns:
            向量或向量列表
        """
        if isinstance(text, str):
            # 单个文本
            embedding = self.model.encode(
                text,
                convert_to_numpy=True,
                show_progress_bar=show_progress
            )
            return embedding.tolist()
        else:
            # 批量文本
            embeddings = self.model.encode(
                text,
                batch_size=self.batch_size,
                convert_to_numpy=True,
                show_progress_bar=show_progress
            )
            return [emb.tolist() for emb in embeddings]
    
    def encode_batch(self, texts: List[str], show_progress: bool = True) -> List[List[float]]:
        """
        批量编码文本
        
        Args:
            texts: 文本列表
            show_progress: 是否显示进度条
        
        Returns:
            向量列表
        """
        return self.encode(texts, show_progress=show_progress)
    
    @lru_cache(maxsize=1000)
    def encode_cached(self, text: str) -> List[float]:
        """
        编码文本（带缓存）
        
        注意：只能用于字符串，不能用于列表
        """
        return self.encode(text)
    
    def get_dimension(self) -> int:
        """获取向量维度"""
        return self.model.get_sentence_embedding_dimension()


# 全局单例
_embedding_generator = None


def get_embedding_generator() -> EmbeddingGenerator:
    """获取全局向量化生成器"""
    global _embedding_generator
    if _embedding_generator is None:
        _embedding_generator = EmbeddingGenerator()
    return _embedding_generator


def encode_text(text: Union[str, List[str]]) -> Union[List[float], List[List[float]]]:
    """快捷函数：编码文本"""
    generator = get_embedding_generator()
    return generator.encode(text)

