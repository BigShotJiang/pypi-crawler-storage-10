"""
Agent记忆系统

一个完整的、智能的、多层次的Agent记忆管理系统
"""

__version__ = "0.2.0"
__author__ = "yixiaobai"

# 主类
from .agent_memory import AgentMemory

# 核心类型
from .core.memory import (
    Memory,
    MemoryType,
    MemoryCategory,
    SourceType,
    PrivacyLevel,
    UserProfile,
    Session,
    MemorySnapshot
)

# 配置
from .core.config import get_config

__all__ = [
    # 主类
    "AgentMemory",
    
    # 核心类型
    "Memory",
    "MemoryType",
    "MemoryCategory",
    "SourceType",
    "PrivacyLevel",
    "UserProfile",
    "Session",
    "MemorySnapshot",
    
    # 配置
    "get_config",
    
    # 版本
    "__version__",
    "__author__",
]

