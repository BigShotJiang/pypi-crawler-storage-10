"""
向量数据库存储实现

使用ChromaDB进行向量存储和相似度检索
"""
from typing import List, Optional, Dict, Any, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    import chromadb
    from chromadb.config import Settings
    from chromadb.utils import embedding_functions
else:
    try:
        import chromadb
        from chromadb.config import Settings
        from chromadb.utils import embedding_functions
        CHROMADB_AVAILABLE = True
    except ImportError:
        chromadb = None
        Settings = None
        embedding_functions = None
        CHROMADB_AVAILABLE = False

from agent_memory.core.memory import Memory
from agent_memory.core.config import get_config


class VectorStore:
    """
    向量数据库管理器
    
    负责记忆的向量存储和相似度检索
    """
    
    def __init__(self, db_path: Optional[str] = None, collection_name: Optional[str] = None):
        """初始化向量数据库"""
        if not CHROMADB_AVAILABLE:
            raise RuntimeError("chromadb未安装，无法使用向量存储功能。请运行: pip install chromadb")
        
        config = get_config()
        
        if db_path is None:
            db_path = config.vector_db_path
        
        if collection_name is None:
            collection_name = config.vector_collection_name
        
        # 初始化ChromaDB客户端
        self.client = chromadb.PersistentClient(
            path=db_path,
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        self.collection_name = collection_name
        
        # 获取或创建集合
        # 注意：这里不使用内置的embedding函数，我们会自己生成embedding
        try:
            self.collection = self.client.get_collection(name=collection_name)
        except:
            self.collection = self.client.create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"}  # 使用余弦相似度
            )
    
    def add_memory(self, memory: Memory, embedding: List[float]):
        """
        添加记忆到向量数据库
        
        Args:
            memory: 记忆对象
            embedding: 文本的向量表示
        """
        self.collection.add(
            ids=[memory.id],
            embeddings=[embedding],
            metadatas=[{
                "user_id": memory.user_id,
                "memory_type": memory.memory_type.value,
                "category": memory.category.value,
                "importance": memory.importance,
                "created_at": memory.created_at.isoformat(),
                "tags": ",".join(memory.tags) if memory.tags else ""
            }],
            documents=[memory.content]
        )
    
    def update_memory(self, memory_id: str, embedding: List[float], content: str, metadata: Dict[str, Any]):
        """
        更新记忆向量
        
        Args:
            memory_id: 记忆ID
            embedding: 新的向量表示
            content: 新的内容
            metadata: 新的元数据
        """
        self.collection.update(
            ids=[memory_id],
            embeddings=[embedding],
            metadatas=[metadata],
            documents=[content]
        )
    
    def delete_memory(self, memory_id: str):
        """删除记忆向量"""
        try:
            self.collection.delete(ids=[memory_id])
        except:
            pass  # 如果不存在则忽略
    
    def search_similar(
        self, 
        query_embedding: List[float], 
        user_id: Optional[str] = None,
        top_k: int = 10,
        memory_type: Optional[str] = None
    ) -> List[Tuple[str, float]]:
        """
        向量相似度检索
        
        Args:
            query_embedding: 查询向量
            user_id: 用户ID（可选，用于过滤）
            top_k: 返回Top K个结果
            memory_type: 记忆类型（可选，用于过滤）
        
        Returns:
            List[(memory_id, distance)]
        """
        # 构建过滤条件
        where = {}
        if user_id:
            where["user_id"] = user_id
        if memory_type:
            where["memory_type"] = memory_type
        
        # 执行查询
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=where if where else None
        )
        
        # 返回结果
        if results and results['ids'] and len(results['ids']) > 0:
            memory_ids = results['ids'][0]
            distances = results['distances'][0] if results['distances'] else [0] * len(memory_ids)
            return list(zip(memory_ids, distances))
        
        return []
    
    def search_by_text(
        self,
        query_text: str,
        query_embedding: List[float],
        user_id: Optional[str] = None,
        top_k: int = 10
    ) -> List[Tuple[str, float, str]]:
        """
        基于文本的相似度检索（返回完整信息）
        
        Returns:
            List[(memory_id, distance, content)]
        """
        where = {}
        if user_id:
            where["user_id"] = user_id
        
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            where=where if where else None
        )
        
        if results and results['ids'] and len(results['ids']) > 0:
            memory_ids = results['ids'][0]
            distances = results['distances'][0] if results['distances'] else [0] * len(memory_ids)
            documents = results['documents'][0] if results['documents'] else [""] * len(memory_ids)
            
            return list(zip(memory_ids, distances, documents))
        
        return []
    
    def get_all_memories_by_user(self, user_id: str, limit: int = 1000) -> List[str]:
        """获取用户的所有记忆ID"""
        results = self.collection.get(
            where={"user_id": user_id},
            limit=limit
        )
        
        if results and results['ids']:
            return results['ids']
        
        return []
    
    def count_memories(self, user_id: Optional[str] = None) -> int:
        """统计记忆数量"""
        if user_id:
            results = self.collection.get(
                where={"user_id": user_id}
            )
            return len(results['ids']) if results and results['ids'] else 0
        else:
            return self.collection.count()
    
    def reset_collection(self):
        """重置集合（危险操作，用于测试）"""
        self.client.delete_collection(name=self.collection_name)
        self.collection = self.client.create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"}
        )

