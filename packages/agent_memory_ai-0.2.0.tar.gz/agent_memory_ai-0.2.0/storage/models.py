"""
数据库模型定义

使用SQLAlchemy ORM定义数据库表结构
"""
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, Text, 
    DateTime, JSON, ForeignKey, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()


class MemoryModel(Base):
    """记忆表"""
    __tablename__ = "memories"
    
    # 主键
    id = Column(String(36), primary_key=True)
    user_id = Column(String(36), nullable=False, index=True)
    
    # 内容
    content = Column(Text, nullable=False)
    
    # 分类
    memory_type = Column(String(20), nullable=False, index=True)  # work/short/mid/long/core
    category = Column(String(20), nullable=False, index=True)     # knowledge/experience/preference...
    
    # 时间
    created_at = Column(DateTime, default=datetime.now, nullable=False)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, nullable=False)
    last_access = Column(DateTime, default=datetime.now, nullable=False)
    
    # 重要性指标
    importance = Column(Float, default=0.5, nullable=False)
    confidence = Column(Float, default=0.7, nullable=False)
    access_count = Column(Integer, default=0, nullable=False)
    
    # 来源
    source_type = Column(String(20), default="explicit", nullable=False)
    source_conversation_id = Column(String(36), nullable=True)
    source_session_id = Column(String(36), nullable=True)
    
    # 关联（存储为JSON）
    related_memory_ids = Column(JSON, default=list)
    tags = Column(JSON, default=list)
    
    # 隐私
    privacy_level = Column(String(20), default="normal", nullable=False)
    auto_delete_date = Column(DateTime, nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)
    
    # 元数据（避免与SQLAlchemy的metadata冲突）
    extra_metadata = Column(JSON, default=dict)
    
    # 索引
    __table_args__ = (
        Index('idx_user_type', 'user_id', 'memory_type'),
        Index('idx_user_importance', 'user_id', 'importance'),
        Index('idx_created_at', 'created_at'),
        Index('idx_last_access', 'last_access'),
    )


class UserProfileModel(Base):
    """用户画像表"""
    __tablename__ = "user_profiles"
    
    # 主键
    user_id = Column(String(36), primary_key=True)
    
    # 基础信息
    domain = Column(String(100), nullable=True)
    role = Column(String(100), nullable=True)
    technical_level = Column(String(50), nullable=True)
    
    # 偏好
    preferences = Column(JSON, default=dict)
    conversation_style = Column(String(50), default="adaptive")
    
    # 状态
    is_cold_start = Column(Boolean, default=True)
    confidence = Column(Float, default=0.3)
    conversation_count = Column(Integer, default=0)
    
    # 时间
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    last_active = Column(DateTime, default=datetime.now)
    
    # 核心记忆
    core_memory_ids = Column(JSON, default=list)
    
    # 元数据（避免与SQLAlchemy的metadata冲突）
    extra_metadata = Column(JSON, default=dict)


class SessionModel(Base):
    """会话表"""
    __tablename__ = "sessions"
    
    # 主键
    session_id = Column(String(36), primary_key=True)
    user_id = Column(String(36), nullable=False, index=True)
    
    # 时间
    start_time = Column(DateTime, default=datetime.now)
    end_time = Column(DateTime, nullable=True)
    
    # 对话历史（存储为JSON）
    messages = Column(JSON, default=list)
    
    # 摘要
    summary = Column(Text, nullable=True)
    key_topics = Column(JSON, default=list)
    decisions_made = Column(JSON, default=list)
    pending_tasks = Column(JSON, default=list)
    
    # 记忆管理
    memories_created = Column(JSON, default=list)
    memories_accessed = Column(JSON, default=list)
    
    # 元数据（避免与SQLAlchemy的metadata冲突）
    extra_metadata = Column(JSON, default=dict)
    
    # 索引
    __table_args__ = (
        Index('idx_user_start_time', 'user_id', 'start_time'),
    )


class MemorySnapshotModel(Base):
    """记忆快照表"""
    __tablename__ = "memory_snapshots"
    
    # 主键
    snapshot_id = Column(String(36), primary_key=True)
    user_id = Column(String(36), nullable=False, index=True)
    timestamp = Column(DateTime, default=datetime.now)
    
    # 快照内容（JSON格式）
    core_memory = Column(JSON, default=dict)
    recent_sessions = Column(JSON, default=list)
    active_topics = Column(JSON, default=list)
    pending_tasks = Column(JSON, default=list)
    user_profile = Column(JSON, default=dict)
    
    # 索引
    __table_args__ = (
        Index('idx_user_timestamp', 'user_id', 'timestamp'),
    )


class MemoryRelationModel(Base):
    """记忆关联关系表（用于构建记忆图谱）"""
    __tablename__ = "memory_relations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    from_memory_id = Column(String(36), nullable=False, index=True)
    to_memory_id = Column(String(36), nullable=False, index=True)
    
    # 关联类型和权重
    relation_type = Column(String(50), default="related")  # related/caused_by/derived_from
    weight = Column(Float, default=1.0)
    
    # 时间
    created_at = Column(DateTime, default=datetime.now)
    
    # 索引
    __table_args__ = (
        Index('idx_from_to', 'from_memory_id', 'to_memory_id'),
    )


class DeletionLogModel(Base):
    """删除日志表（用于审计）"""
    __tablename__ = "deletion_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(36), nullable=False, index=True)
    memory_id = Column(String(36), nullable=False)
    
    # 删除信息
    deleted_at = Column(DateTime, default=datetime.now)
    reason = Column(String(100), nullable=False)  # user_request/auto_decay/privacy
    
    # 不存储具体内容，只存储元数据
    memory_metadata = Column(JSON, default=dict)

