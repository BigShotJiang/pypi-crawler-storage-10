"""
SQLite 存储实现

提供基于SQLite的数据持久化功能
"""
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from sqlalchemy import create_engine, and_, or_
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool

from agent_memory.core.memory import Memory, UserProfile, Session as MemorySession, MemorySnapshot
from agent_memory.core.config import get_config
from agent_memory.storage.models import (
    Base, MemoryModel, UserProfileModel, SessionModel, 
    MemorySnapshotModel, MemoryRelationModel, DeletionLogModel
)


class SQLiteStore:
    """
    SQLite存储管理器
    
    负责所有关系型数据的CRUD操作
    """
    
    def __init__(self, db_path: Optional[str] = None):
        """初始化数据库连接"""
        config = get_config()
        if db_path is None:
            db_path = config.db_path
        
        # 创建引擎
        self.engine = create_engine(
            f"sqlite:///{db_path}",
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
            echo=False
        )
        
        # 创建所有表
        Base.metadata.create_all(self.engine)
        
        # 创建会话工厂
        self.SessionLocal = sessionmaker(bind=self.engine)
    
    def _get_db_session(self) -> Session:
        """获取数据库会话（内部方法）"""
        return self.SessionLocal()
    
    # ==================== Memory CRUD ====================
    
    def create_memory(self, memory: Memory) -> Memory:
        """创建记忆"""
        session = self._get_db_session()
        try:
            model = MemoryModel(
                id=memory.id,
                user_id=memory.user_id,
                content=memory.content,
                memory_type=memory.memory_type.value,
                category=memory.category.value,
                created_at=memory.created_at,
                updated_at=memory.updated_at,
                last_access=memory.last_access,
                importance=memory.importance,
                confidence=memory.confidence,
                access_count=memory.access_count,
                source_type=memory.source_type.value,
                source_conversation_id=memory.source_conversation_id,
                source_session_id=memory.source_session_id,
                related_memory_ids=memory.related_memory_ids,
                tags=memory.tags,
                privacy_level=memory.privacy_level.value,
                auto_delete_date=memory.auto_delete_date,
                is_deleted=memory.is_deleted,
                extra_metadata=memory.metadata
            )
            session.add(model)
            session.commit()
            return memory
        finally:
            session.close()
    
    def get_memory(self, memory_id: str) -> Optional[Memory]:
        """获取单条记忆"""
        session = self._get_db_session()
        try:
            model = session.query(MemoryModel).filter(
                MemoryModel.id == memory_id,
                MemoryModel.is_deleted == False
            ).first()
            
            if model:
                return self._model_to_memory(model)
            return None
        finally:
            session.close()
    
    def update_memory(self, memory: Memory) -> Memory:
        """更新记忆"""
        session = self._get_db_session()
        try:
            model = session.query(MemoryModel).filter(MemoryModel.id == memory.id).first()
            if model:
                model.content = memory.content
                model.memory_type = memory.memory_type.value
                model.category = memory.category.value
                model.updated_at = datetime.now()
                model.last_access = memory.last_access
                model.importance = memory.importance
                model.confidence = memory.confidence
                model.access_count = memory.access_count
                model.related_memory_ids = memory.related_memory_ids
                model.tags = memory.tags
                model.privacy_level = memory.privacy_level.value
                model.auto_delete_date = memory.auto_delete_date
                model.extra_metadata = memory.metadata
                
                session.commit()
            return memory
        finally:
            session.close()
    
    def delete_memory(self, memory_id: str, user_id: str, reason: str = "user_request"):
        """删除记忆（软删除）"""
        session = self._get_db_session()
        try:
            # 标记为已删除
            model = session.query(MemoryModel).filter(MemoryModel.id == memory_id).first()
            if model:
                model.is_deleted = True
                
                # 记录删除日志
                log = DeletionLogModel(
                    user_id=user_id,
                    memory_id=memory_id,
                    reason=reason,
                    memory_metadata={
                        "type": model.memory_type,
                        "category": model.category,
                        "importance": model.importance
                    }
                )
                session.add(log)
                session.commit()
        finally:
            session.close()
    
    def get_memories_by_user(
        self, 
        user_id: str, 
        memory_type: Optional[str] = None,
        limit: int = 100
    ) -> List[Memory]:
        """获取用户的记忆列表"""
        session = self._get_db_session()
        try:
            query = session.query(MemoryModel).filter(
                MemoryModel.user_id == user_id,
                MemoryModel.is_deleted == False
            )
            
            if memory_type:
                query = query.filter(MemoryModel.memory_type == memory_type)
            
            models = query.order_by(MemoryModel.importance.desc()).limit(limit).all()
            return [self._model_to_memory(m) for m in models]
        finally:
            session.close()
    
    def search_memories_by_tags(self, user_id: str, tags: List[str]) -> List[Memory]:
        """根据标签搜索记忆"""
        session = self._get_db_session()
        try:
            # SQLite的JSON查询比较简单，这里使用Python过滤
            models = session.query(MemoryModel).filter(
                MemoryModel.user_id == user_id,
                MemoryModel.is_deleted == False
            ).all()
            
            results = []
            for model in models:
                if any(tag in (model.tags or []) for tag in tags):
                    results.append(self._model_to_memory(model))
            
            return results
        finally:
            session.close()
    
    def get_memories_by_timerange(
        self, 
        user_id: str, 
        start_time: datetime, 
        end_time: datetime
    ) -> List[Memory]:
        """根据时间范围获取记忆"""
        session = self._get_db_session()
        try:
            models = session.query(MemoryModel).filter(
                MemoryModel.user_id == user_id,
                MemoryModel.created_at >= start_time,
                MemoryModel.created_at <= end_time,
                MemoryModel.is_deleted == False
            ).all()
            
            return [self._model_to_memory(m) for m in models]
        finally:
            session.close()
    
    def get_memories_for_decay(self, memory_type: str, days: int) -> List[Memory]:
        """获取需要衰减的记忆"""
        session = self._get_db_session()
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            models = session.query(MemoryModel).filter(
                MemoryModel.memory_type == memory_type,
                MemoryModel.last_access < cutoff_date,
                MemoryModel.is_deleted == False
            ).all()
            
            return [self._model_to_memory(m) for m in models]
        finally:
            session.close()
    
    def _model_to_memory(self, model: MemoryModel) -> Memory:
        """将数据库模型转换为Memory对象"""
        return Memory.from_dict({
            "id": model.id,
            "user_id": model.user_id,
            "content": model.content,
            "memory_type": model.memory_type,
            "category": model.category,
            "created_at": model.created_at.isoformat(),
            "updated_at": model.updated_at.isoformat(),
            "last_access": model.last_access.isoformat(),
            "importance": model.importance,
            "confidence": model.confidence,
            "access_count": model.access_count,
            "source_type": model.source_type,
            "source_conversation_id": model.source_conversation_id,
            "source_session_id": model.source_session_id,
            "related_memory_ids": model.related_memory_ids or [],
            "tags": model.tags or [],
            "privacy_level": model.privacy_level,
            "auto_delete_date": model.auto_delete_date.isoformat() if model.auto_delete_date else None,
            "is_deleted": model.is_deleted,
            "metadata": model.extra_metadata or {}
        })
    
    # ==================== UserProfile CRUD ====================
    
    def create_or_update_profile(self, profile: UserProfile) -> UserProfile:
        """创建或更新用户画像"""
        session = self._get_db_session()
        try:
            model = session.query(UserProfileModel).filter(
                UserProfileModel.user_id == profile.user_id
            ).first()
            
            if model:
                # 更新
                model.domain = profile.domain
                model.role = profile.role
                model.technical_level = profile.technical_level
                model.preferences = profile.preferences
                model.conversation_style = profile.conversation_style
                model.is_cold_start = profile.is_cold_start
                model.confidence = profile.confidence
                model.conversation_count = profile.conversation_count
                model.updated_at = datetime.now()
                model.last_active = profile.last_active
                model.core_memory_ids = profile.core_memory_ids
                model.metadata = profile.metadata
            else:
                # 创建
                model = UserProfileModel(
                    user_id=profile.user_id,
                    domain=profile.domain,
                    role=profile.role,
                    technical_level=profile.technical_level,
                    preferences=profile.preferences,
                    conversation_style=profile.conversation_style,
                    is_cold_start=profile.is_cold_start,
                    confidence=profile.confidence,
                    conversation_count=profile.conversation_count,
                    created_at=profile.created_at,
                    updated_at=profile.updated_at,
                    last_active=profile.last_active,
                    core_memory_ids=profile.core_memory_ids,
                    metadata=profile.metadata
                )
                session.add(model)
            
            session.commit()
            return profile
        finally:
            session.close()
    
    def get_profile(self, user_id: str) -> Optional[UserProfile]:
        """获取用户画像"""
        session = self._get_db_session()
        try:
            model = session.query(UserProfileModel).filter(
                UserProfileModel.user_id == user_id
            ).first()
            
            if model:
                return UserProfile.from_dict({
                    "user_id": model.user_id,
                    "domain": model.domain,
                    "role": model.role,
                    "technical_level": model.technical_level,
                    "preferences": model.preferences or {},
                    "conversation_style": model.conversation_style,
                    "is_cold_start": model.is_cold_start,
                    "confidence": model.confidence,
                    "conversation_count": model.conversation_count,
                    "created_at": model.created_at.isoformat(),
                    "updated_at": model.updated_at.isoformat(),
                    "last_active": model.last_active.isoformat(),
                    "core_memory_ids": model.core_memory_ids or [],
                    "metadata": model.extra_metadata or {}
                })
            return None
        finally:
            session.close()
    
    # ==================== Session CRUD ====================
    
    def create_session(self, mem_session: MemorySession) -> MemorySession:
        """创建会话"""
        session = self._get_db_session()
        try:
            model = SessionModel(
                session_id=mem_session.session_id,
                user_id=mem_session.user_id,
                start_time=mem_session.start_time,
                end_time=mem_session.end_time,
                messages=mem_session.messages,
                summary=mem_session.summary,
                key_topics=mem_session.key_topics,
                decisions_made=mem_session.decisions_made,
                pending_tasks=mem_session.pending_tasks,
                memories_created=mem_session.memories_created,
                memories_accessed=mem_session.memories_accessed,
                metadata=mem_session.metadata
            )
            session.add(model)
            session.commit()
            return mem_session
        finally:
            session.close()
    
    def update_session(self, mem_session: MemorySession) -> MemorySession:
        """更新会话"""
        session = self._get_db_session()
        try:
            model = session.query(SessionModel).filter(
                SessionModel.session_id == mem_session.session_id
            ).first()
            
            if model:
                model.end_time = mem_session.end_time
                model.messages = mem_session.messages
                model.summary = mem_session.summary
                model.key_topics = mem_session.key_topics
                model.decisions_made = mem_session.decisions_made
                model.pending_tasks = mem_session.pending_tasks
                model.memories_created = mem_session.memories_created
                model.memories_accessed = mem_session.memories_accessed
                model.metadata = mem_session.metadata
                session.commit()
            
            return mem_session
        finally:
            session.close()
    
    def get_session(self, session_id: str) -> Optional[MemorySession]:
        """获取会话"""
        db_session = self._get_db_session()
        try:
            model = db_session.query(SessionModel).filter(
                SessionModel.session_id == session_id
            ).first()
            
            if model:
                return MemorySession.from_dict({
                    "session_id": model.session_id,
                    "user_id": model.user_id,
                    "start_time": model.start_time.isoformat(),
                    "end_time": model.end_time.isoformat() if model.end_time else None,
                    "messages": model.messages or [],
                    "summary": model.summary,
                    "key_topics": model.key_topics or [],
                    "decisions_made": model.decisions_made or [],
                    "pending_tasks": model.pending_tasks or [],
                    "memories_created": model.memories_created or [],
                    "memories_accessed": model.memories_accessed or [],
                    "metadata": model.extra_metadata or {}
                })
            return None
        finally:
            db_session.close()
    
    def get_recent_sessions(self, user_id: str, limit: int = 10) -> List[MemorySession]:
        """获取最近的会话"""
        db_session = self._get_db_session()
        try:
            models = db_session.query(SessionModel).filter(
                SessionModel.user_id == user_id
            ).order_by(SessionModel.start_time.desc()).limit(limit).all()
            
            sessions = []
            for model in models:
                sessions.append(MemorySession.from_dict({
                    "session_id": model.session_id,
                    "user_id": model.user_id,
                    "start_time": model.start_time.isoformat(),
                    "end_time": model.end_time.isoformat() if model.end_time else None,
                    "messages": model.messages or [],
                    "summary": model.summary,
                    "key_topics": model.key_topics or [],
                    "decisions_made": model.decisions_made or [],
                    "pending_tasks": model.pending_tasks or [],
                    "memories_created": model.memories_created or [],
                    "memories_accessed": model.memories_accessed or [],
                    "metadata": model.extra_metadata or {}
                }))
            
            return sessions
        finally:
            db_session.close()

