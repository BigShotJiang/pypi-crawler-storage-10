"""
Implementations Module
Concrete implementations of Google API Client
"""

from google_api_client.implementations.http import GoogleAPIClientHTTP

__all__ = ['GoogleAPIClientHTTP']

