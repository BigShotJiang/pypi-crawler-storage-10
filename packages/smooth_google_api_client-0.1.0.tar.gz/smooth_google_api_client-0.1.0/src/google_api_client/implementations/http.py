"""
Google API Client Implementation
HTTP client implementation for Google API Server
"""

import json
import logging
from typing import Dict, List, Optional, Any, Type, Tuple, AsyncIterator
from urllib.parse import urljoin

import httpx

from google_api_client.interfaces.client import IGoogleAPIClient
from google_api_client.core.models import (
    TranslationResponse,
    BatchTranslationResponse,
    LanguageDetectionResponse,
)
from google_api_client.core.types import (
    TranslationResultDict,
    BatchTranslationResultDict,
    LanguageDetectionResultDict,
    SSEDataDict,
)

logger = logging.getLogger(__name__)


class GoogleAPIClientHTTP(IGoogleAPIClient):
    """
    Google API Server HTTP client implementation
    Implements IGoogleAPIClient protocol using HTTP
    Supports translation operations with custom domain configuration
    """
    
    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        timeout: float = 30.0,
        max_retries: int = 3
    ):
        """
        Initialize the client
        
        Args:
            base_url: Base URL of the API server (e.g., "http://localhost:8000")
                     Can include protocol, domain and port
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        
        # Initialize HTTP client
        self._client = httpx.AsyncClient(
            timeout=timeout,
            limits=httpx.Limits(max_keepalive_connections=10, max_connections=20)
        )
        
        logger.info(f"✅ GoogleAPIClient initialized with base_url: {self.base_url}")
    
    def _build_url(self, path: str) -> str:
        """
        Build full URL from path
        
        Args:
            path: URL path
            
        Returns:
            Full URL string
        """
        return urljoin(f"{self.base_url}/", path.lstrip('/'))
    
    async def close(self) -> None:
        """Close the HTTP client"""
        await self._client.aclose()
    
    async def __aenter__(self) -> 'GoogleAPIClient':
        """
        Async context manager entry
        
        Returns:
            Self instance
        """
        return self
    
    async def __aexit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[Any]
    ) -> None:
        """
        Async context manager exit
        
        Args:
            exc_type: Exception type
            exc_val: Exception value
            exc_tb: Exception traceback
        """
        await self.close()
    
    async def translate(
        self,
        text: str,
        source_language: str,
        target_language: str
    ) -> TranslationResponse:
        """
        Translate text from source language to target language
        
        Args:
            text: Text to translate
            source_language: Source language code (e.g., 'en')
            target_language: Target language code (e.g., 'zh-CN')
            
        Returns:
            TranslationResponse object
            
        Raises:
            httpx.HTTPError: If request fails
        """
        url: str = self._build_url('/translation/translate')
        
        data: Dict[str, str] = {
            'text': text,
            'source_language': source_language,
            'target_language': target_language
        }
        
        try:
            logger.info(f"🔄 [Client] Translating: {source_language} -> {target_language}")
            response: httpx.Response = await self._client.post(url, data=data)
            response.raise_for_status()
            
            result: TranslationResultDict = response.json()  # type: ignore
            return TranslationResponse(
                original_text=result.get('original_text', text),
                translated_text=result.get('translated_text', ''),
                source_language=result.get('source_language', source_language),
                target_language=result.get('target_language', target_language)
            )
            
        except httpx.HTTPError as e:
            logger.error(f"❌ [Client] Translation failed: {e}")
            raise
    
    async def translate_to_multiple(
        self,
        text: str,
        source_language: str,
        target_languages: List[str]
    ) -> BatchTranslationResponse:
        """
        Translate text to multiple target languages concurrently
        
        Args:
            text: Text to translate
            source_language: Source language code (e.g., 'en')
            target_languages: List of target language codes (e.g., ['zh-CN', 'ja', 'es'])
            
        Returns:
            BatchTranslationResponse object
            
        Raises:
            httpx.HTTPError: If request fails
        """
        url: str = self._build_url('/translation/translate-multiple')
        
        target_langs_str: str = ','.join(target_languages)
        
        data: Dict[str, str] = {
            'text': text,
            'source_language': source_language,
            'target_languages': target_langs_str
        }
        
        try:
            logger.info(f"🔄 [Client] Batch translating to {len(target_languages)} languages")
            response: httpx.Response = await self._client.post(url, data=data)
            response.raise_for_status()
            
            result: BatchTranslationResultDict = response.json()  # type: ignore
            return BatchTranslationResponse(
                original_text=result.get('original_text', text),
                source_language=result.get('source_language', source_language),
                translations=result.get('translations', {})
            )
            
        except httpx.HTTPError as e:
            logger.error(f"❌ [Client] Batch translation failed: {e}")
            raise
    
    async def detect_language(self, text: str) -> LanguageDetectionResponse:
        """
        Detect the language of the given text
        
        Args:
            text: Text to detect language for
            
        Returns:
            LanguageDetectionResponse object
            
        Raises:
            httpx.HTTPError: If request fails
        """
        url: str = self._build_url('/translation/detect-language')
        
        data: Dict[str, str] = {'text': text}
        
        try:
            logger.info("🔄 [Client] Detecting language")
            response: httpx.Response = await self._client.post(url, data=data)
            response.raise_for_status()
            
            result: LanguageDetectionResultDict = response.json()  # type: ignore
            return LanguageDetectionResponse(
                text=result.get('text', text),
                detected_language=result.get('detected_language', '')
            )
            
        except httpx.HTTPError as e:
            logger.error(f"❌ [Client] Language detection failed: {e}")
            raise
    
    async def translate_stream(
        self,
        text: str,
        source_language: str,
        target_languages: List[str]
    ) -> AsyncIterator[SSEDataDict]:
        """
        Stream translations using Server-Sent Events (SSE)
        
        Args:
            text: Text to translate
            source_language: Source language code
            target_languages: List of target language codes
            
        Yields:
            Dictionary containing translation data
            
        Raises:
            httpx.HTTPError: If request fails
        """
        url: str = self._build_url('/translation/translate-stream')
        
        target_langs_str: str = ','.join(target_languages)
        
        # Use POST method with data in query params (based on server requirements)
        params: Dict[str, str] = {
            'text': text,
            'source_language': source_language,
            'target_languages': target_langs_str
        }
        
        try:
            logger.info(f"🔄 [Client] Starting translation stream to {len(target_languages)} languages")
            
            async with self._client.stream('POST', url, params=params) as response:
                response.raise_for_status()
                
                buffer: str = ""
                
                async for chunk in response.aiter_bytes():
                    buffer += chunk.decode('utf-8')
                    
                    # Process complete SSE messages
                    while '\n\n' in buffer:
                        parts: Tuple[str, str] = buffer.split('\n\n', 1)
                        message: str = parts[0].strip()
                        buffer = parts[1]
                        
                        if not message or not message.startswith('data: '):
                            continue
                        
                        data_str: str = message[6:]  # Remove 'data: ' prefix
                        
                        try:
                            data: SSEDataDict = json.loads(data_str)  # type: ignore
                            yield data
                            
                            # Log progress
                            if data.get('type') == 'translation':
                                logger.info(
                                    f"📤 [Client] Received translation for {data.get('language')} "
                                    f"({data.get('progress', 0)}/{data.get('total', 0)})"
                                )
                            elif data.get('type') == 'complete':
                                logger.info(f"✅ [Client] Stream completed: {data.get('total', 0)} translations")
                                
                        except json.JSONDecodeError as e:
                            logger.error(f"❌ [Client] Failed to parse SSE data: {e}")
            
        except httpx.HTTPError as e:
            logger.error(f"❌ [Client] Translation stream failed: {e}")
            raise

