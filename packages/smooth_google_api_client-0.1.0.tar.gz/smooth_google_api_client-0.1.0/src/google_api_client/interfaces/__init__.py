"""
Interfaces Module
Protocol definitions for type checking and interface contracts
"""

from google_api_client.interfaces.client import IGoogleAPIClient

__all__ = ['IGoogleAPIClient']

