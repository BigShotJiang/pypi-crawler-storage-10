"""
Google API Client Interface
Protocol definitions for type checking and interface contracts
"""

from typing import Protocol, runtime_checkable, AsyncIterator, List

from google_api_client.core.models import (
    TranslationResponse,
    BatchTranslationResponse,
    LanguageDetectionResponse,
)
from google_api_client.core.types import SSEDataDict


@runtime_checkable
class IGoogleAPIClient(Protocol):
    """
    Interface for Google API Client
    Defines the contract that all implementations must follow
    """
    
    async def translate(
        self,
        text: str,
        source_language: str,
        target_language: str
    ) -> TranslationResponse:
        """
        Translate text from source language to target language
        
        Args:
            text: Text to translate
            source_language: Source language code (e.g., 'en')
            target_language: Target language code (e.g., 'zh-CN')
            
        Returns:
            TranslationResponse object
        """
        ...
    
    async def translate_to_multiple(
        self,
        text: str,
        source_language: str,
        target_languages: List[str]
    ) -> BatchTranslationResponse:
        """
        Translate text to multiple target languages concurrently
        
        Args:
            text: Text to translate
            source_language: Source language code (e.g., 'en')
            target_languages: List of target language codes (e.g., ['zh-CN', 'ja', 'es'])
            
        Returns:
            BatchTranslationResponse object
        """
        ...
    
    async def detect_language(self, text: str) -> LanguageDetectionResponse:
        """
        Detect the language of the given text
        
        Args:
            text: Text to detect language for
            
        Returns:
            LanguageDetectionResponse object
        """
        ...
    
    async def translate_stream(
        self,
        text: str,
        source_language: str,
        target_languages: List[str]
    ) -> AsyncIterator[SSEDataDict]:
        """
        Stream translations using Server-Sent Events (SSE)
        
        Args:
            text: Text to translate
            source_language: Source language code
            target_languages: List of target language codes
            
        Yields:
            Dictionary containing translation data
        """
        ...
    
    async def close(self) -> None:
        """Close the client and release resources"""
        ...


__all__ = ['IGoogleAPIClient']

