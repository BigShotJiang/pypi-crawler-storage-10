"""
Google API Client Library

A Python client library for Google Cloud APIs.
Following Interface Segregation Principle for better code architecture.
"""

__version__ = "0.1.0"

# Import from submodules
from google_api_client.core import (
    # Response Models
    TranslationResponse,
    BatchTranslationResponse,
    LanguageDetectionResponse,
    # Type Definitions
    TranslationResultDict,
    BatchTranslationResultDict,
    LanguageDetectionResultDict,
    SSEDataDict,
)

from google_api_client.interfaces import IGoogleAPIClient

from google_api_client.implementations import GoogleAPIClientHTTP

# Backward compatibility: alias GoogleAPIClientHTTP as GoogleAPIClient
GoogleAPIClient = GoogleAPIClientHTTP

__all__ = [
    # Version
    "__version__",
    # Interface
    "IGoogleAPIClient",
    # Response Models
    "TranslationResponse",
    "BatchTranslationResponse",
    "LanguageDetectionResponse",
    # Type Definitions
    "TranslationResultDict",
    "BatchTranslationResultDict",
    "LanguageDetectionResultDict",
    "SSEDataDict",
    # Implementations
    "GoogleAPIClient",  # Backward compatibility alias
    "GoogleAPIClientHTTP",
]
