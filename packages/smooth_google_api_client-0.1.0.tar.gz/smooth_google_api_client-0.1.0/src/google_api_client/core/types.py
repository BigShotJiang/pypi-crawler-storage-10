"""
Type Definitions
Strong types for Google API Client
"""

from typing import Dict, Optional, TypedDict


class TranslationResultDict(TypedDict):
    """Translation result dictionary structure"""
    original_text: str
    translated_text: str
    source_language: str
    target_language: str


class BatchTranslationResultDict(TypedDict):
    """Batch translation result dictionary structure"""
    original_text: str
    source_language: str
    translations: Dict[str, str]


class LanguageDetectionResultDict(TypedDict):
    """Language detection result dictionary structure"""
    text: str
    detected_language: str


class SSEDataDict(TypedDict, total=False):
    """Server-Sent Event data dictionary structure"""
    type: str
    original_text: Optional[str]
    source_language: Optional[str]
    target_language: Optional[str]
    translated_text: Optional[str]
    language: Optional[str]
    error: Optional[str]
    progress: Optional[int]
    total: Optional[int]
    success: Optional[bool]


__all__ = [
    'TranslationResultDict',
    'BatchTranslationResultDict',
    'LanguageDetectionResultDict',
    'SSEDataDict',
]

