"""
Response Models
Data classes for API responses
"""

from typing import Dict
from dataclasses import dataclass


@dataclass
class TranslationResponse:
    """Translation response data class"""
    original_text: str
    translated_text: str
    source_language: str
    target_language: str


@dataclass
class BatchTranslationResponse:
    """Batch translation response data class"""
    original_text: str
    source_language: str
    translations: Dict[str, str]


@dataclass
class LanguageDetectionResponse:
    """Language detection response data class"""
    text: str
    detected_language: str


__all__ = [
    'TranslationResponse',
    'BatchTranslationResponse',
    'LanguageDetectionResponse',
]

