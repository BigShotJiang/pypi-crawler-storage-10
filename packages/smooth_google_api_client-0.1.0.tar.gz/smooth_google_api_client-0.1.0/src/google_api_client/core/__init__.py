"""
Core Module
Core types and models for Google API Client
"""

from typing import List, AsyncIterator

from google_api_client.core.models import (
    TranslationResponse,
    BatchTranslationResponse,
    LanguageDetectionResponse,
)

from google_api_client.core.types import (
    TranslationResultDict,
    BatchTranslationResultDict,
    LanguageDetectionResultDict,
    SSEDataDict,
)

__all__ = [
    # Models
    "TranslationResponse",
    "BatchTranslationResponse",
    "LanguageDetectionResponse",
    # Types
    "TranslationResultDict",
    "BatchTranslationResultDict",
    "LanguageDetectionResultDict",
    "SSEDataDict",
]

