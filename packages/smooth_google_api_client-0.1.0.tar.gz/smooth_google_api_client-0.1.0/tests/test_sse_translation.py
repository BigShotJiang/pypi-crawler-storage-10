"""
Tests for SSE translation streaming functionality using REAL API endpoints
These tests require a running API server.

To run these tests:
1. Start the API server (e.g., on http://localhost:8000)
2. Set TEST_API_BASE_URL environment variable (optional, defaults to http://localhost:8000)
3. Run: pytest tests/test_sse_translation.py -v
"""

import os
import pytest
from typing import List

from google_api_client.implementations.http import GoogleAPIClientHTTP


# Get test API base URL from environment or use default
TEST_API_BASE_URL = os.getenv("TEST_API_BASE_URL", "http://localhost:8000")


class TestSSETranslation:
    """Test suite for Server-Sent Events translation streaming using real API endpoints"""
    
    @pytest.fixture
    def client(self):
        """Create a GoogleAPIClientHTTP instance with test API URL"""
        return GoogleAPIClientHTTP(base_url=TEST_API_BASE_URL)
    
    @pytest.mark.asyncio
    async def test_translate_stream_success(self, client):
        """Test successful SSE translation stream with multiple languages"""
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="Hello, World!",
                source_language="en",
                target_languages=["zh-CN", "ja"]
            ):
                results.append(data)
        
        # Verify we got results
        assert len(results) > 0
        
        # Should have translation data
        translation_data = [r for r in results if r.get('type') == 'translation']
        assert len(translation_data) >= 1
        
        # Should have completion message
        completion_data = [r for r in results if r.get('type') == 'complete']
        assert len(completion_data) >= 1
    
    @pytest.mark.asyncio
    async def test_translate_stream_single_language(self, client):
        """Test SSE translation with single target language"""
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="Good morning",
                source_language="en",
                target_languages=["zh-CN"]
            ):
                results.append(data)
        
        assert len(results) > 0
        
        # Should have translation data
        translation_data = [r for r in results if r.get('type') == 'translation']
        if len(translation_data) > 0:
            assert 'translated_text' in translation_data[0]
            assert 'language' in translation_data[0]
        
        # Should have completion
        completion_data = [r for r in results if r.get('type') == 'complete']
        assert len(completion_data) >= 1
    
    @pytest.mark.asyncio
    async def test_translate_stream_multiple_languages(self, client):
        """Test SSE translation stream with multiple target languages"""
        target_languages = ["zh-CN", "ja", "es", "fr", "de"]
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="Good morning!",
                source_language="en",
                target_languages=target_languages
            ):
                results.append(data)
        
        # Verify we got results
        assert len(results) > 0
        
        # Collect translation data
        translation_data = [r for r in results if r.get('type') == 'translation']
        
        # Should have at least some translations
        assert len(translation_data) >= 1
        
        # Check progress tracking
        progress_values = [r.get('progress', 0) for r in translation_data if 'progress' in r]
        total_values = [r.get('total', 0) for r in translation_data if 'total' in r]
        
        # Progress should be tracked
        if len(progress_values) > 0:
            assert max(progress_values) <= total_values[0] if total_values else True
        
        # Completion message should exist
        completion_data = [r for r in results if r.get('type') == 'complete']
        assert len(completion_data) >= 1
    
    @pytest.mark.asyncio
    async def test_translate_stream_chinese_text(self, client):
        """Test SSE translation of Chinese text to English"""
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="你好，世界！",
                source_language="zh-CN",
                target_languages=["en"]
            ):
                results.append(data)
        
        assert len(results) > 0
        
        # Check for translation
        translation_data = [r for r in results if r.get('type') == 'translation']
        if len(translation_data) > 0:
            assert translation_data[0]['language'] == 'en'
    
    @pytest.mark.asyncio
    async def test_translate_stream_long_text(self, client):
        """Test SSE translation with longer text"""
        long_text = "The quick brown fox jumps over the lazy dog. " * 3
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text=long_text,
                source_language="en",
                target_languages=["zh-CN", "ja"]
            ):
                results.append(data)
        
        assert len(results) > 0
        assert len([r for r in results if r.get('type') == 'translation']) >= 1
    
    @pytest.mark.asyncio
    async def test_translate_stream_progress_tracking(self, client):
        """Test that progress is correctly tracked"""
        target_languages = ["zh-CN", "ja", "es"]
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="Progress test",
                source_language="en",
                target_languages=target_languages
            ):
                results.append(data)
        
        # Check progress values
        progress_values = []
        total_value = None
        
        for data in results:
            if 'progress' in data:
                progress_values.append(data['progress'])
            if 'total' in data:
                if total_value is None:
                    total_value = data['total']
        
        # Progress should be sequential if available
        if len(progress_values) > 1:
            assert progress_values == sorted(progress_values)
    
    @pytest.mark.asyncio
    async def test_translate_stream_empty_text(self, client):
        """Test SSE translation with empty text (should still work)"""
        results = []
        
        async with client:
            async for data in client.translate_stream(
                text="",
                source_language="en",
                target_languages=["zh-CN"]
            ):
                results.append(data)
        
        # Should still get a response
        assert len(results) >= 0
    
    @pytest.mark.asyncio
    async def test_translate_stream_context_manager(self, client):
        """Test that context manager properly handles resource cleanup"""
        async with client:
            count = 0
            async for data in client.translate_stream(
                text="Test",
                source_language="en",
                target_languages=["zh-CN"]
            ):
                count += 1
                if count >= 5:  # Don't exhaust the stream
                    break
        
        # After exiting context manager, client should be closed
        assert count > 0
    
    @pytest.mark.asyncio
    async def test_translate_stream_async_iterator(self, client):
        """Test that the stream works as an async iterator"""
        results = []
        
        async with client:
            stream = client.translate_stream(
                text="Iterator test",
                source_language="en",
                target_languages=["zh-CN"]
            )
            
            # Verify it's an async iterator
            assert hasattr(stream, '__aiter__')
            
            async for data in stream:
                results.append(data)
        
        assert len(results) > 0


class TestSSETranslationWithRealServer:
    """Additional tests that check server connectivity"""
    
    @pytest.fixture
    def client(self):
        """Create a GoogleAPIClientHTTP instance"""
        return GoogleAPIClientHTTP(base_url=TEST_API_BASE_URL)
    
    @pytest.mark.asyncio
    async def test_server_connection(self, client):
        """Test that we can connect to the server"""
        try:
            async with client:
                results = []
                async for data in client.translate_stream(
                    text="Connection test",
                    source_language="en",
                    target_languages=["zh-CN"]
                ):
                    results.append(data)
                    break  # Just check connection
                
                assert len(results) >= 0
        except Exception as e:
            pytest.fail(f"Failed to connect to server at {TEST_API_BASE_URL}: {e}")
