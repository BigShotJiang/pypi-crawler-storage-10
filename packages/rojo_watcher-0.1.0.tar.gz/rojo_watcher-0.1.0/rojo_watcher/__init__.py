__version__ = "0.1.0"
__description__ = "automatically updates Rojo project JSON when new folders are created"