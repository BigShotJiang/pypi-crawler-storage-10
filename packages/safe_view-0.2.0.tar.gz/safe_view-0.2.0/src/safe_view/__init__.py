"""Safe View - A terminal application to view safetensors files."""
from .main import main

__version__ = "0.1.0"
__author__ = "Elinx"
__license__ = "MIT"
__description__ = "A terminal application to view safetensors files"