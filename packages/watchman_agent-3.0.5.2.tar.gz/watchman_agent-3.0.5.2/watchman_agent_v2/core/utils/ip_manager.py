def parse_ip_range(start_ip: str, end_ip: str):
    """
    Génère une liste d'adresses IP entre start_ip et end_ip.
    """
    # Implémenter la génération de plage IP
    return []

def is_exempt(ip: str, exemptions: list):
    """
    Vérifie si une adresse IP est dans la liste des exemptions.
    """
    return ip in exemptions
