# Fireworks AI Livekit Plugin

Fireworks AI Livekit Plugin for speech-to-text and realtime voice agent with [Fireworks AI](https://fireworks.ai/).

## Installation

```bash
pip install fireworks-livekit
```

## Pre-requisites

You'll need an API key from Fireworks AI. It can be set as an environment variable: `FIREWORKS_API_KEY`


## Changelog

### 1.1.16 – 2025-10-31
- Added initial changelog documentation for tracking project changes.

### 1.1.15 – 2025-09-29
- Added server-side VAD configuration (`skip_vad`, `vad_kwargs`).
- Fixed parameter bug introduced in 1.1.14.

For full history, see CHANGELOG.md (included in the package).
