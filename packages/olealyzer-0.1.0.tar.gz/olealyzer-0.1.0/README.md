
# OLEalyzer

**OLEalyzer** is a Python package for static analysis of Microsoft Office OLE documents,  
offering deep VBA deobfuscation and feature extraction for threat intelligence and malware triage.

---

## Installation

```bash
pip install olealyzer
