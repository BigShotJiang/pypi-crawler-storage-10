class RenderError(Exception):
    pass