import numpy as np
import networkx as nx
import pandas as pd
import geopandas as gpd

from .system import System

# Trivially, this library is used for analyzing at least one system.
# So, providing default system is intuitive.

