from .system import System


# Trivially, this library is used for analyzing at least one system.
# So, providing default system is intuitive.


gcs = System() # global current system

def get_gcs():
    global gcs
    return gcs

def set_gcs(system):
    global gcs
    gcs = system
