

class System:
    """System is environment of whole analysis. 
    
    When we start study, we set the boundary of the study and what we study. 
    These all metaresearch process need to be recorded on system.
    System is our target of the study and everything.
    """
    def __init__(self):
        pass

    