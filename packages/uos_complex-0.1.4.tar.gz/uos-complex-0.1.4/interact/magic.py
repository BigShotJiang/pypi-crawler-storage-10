# This code can be put in any Python module, it does not require IPython
# itself to be running already.  It only creates the magics subclass but
# doesn't instantiate it yet.
from __future__ import print_function
from IPython.core.magic import (Magics, magics_class, line_magic,
                                cell_magic, line_cell_magic)
from interact.workspace import variable

# The class MUST call this class decorator at creation time
@magics_class
class MyMagics(Magics):

    @cell_magic
    def namespace(self, line, cell):
        "my cell magic"
        global_ = self.shell.user_ns
        if not line in global_:
            global_[line] = variable()
        local_ = global_[line]
        local_["__namespace__"] = line
        #if isinstance(local_, ):
        #    raise TypeError(f"`{line}` must be a mapping object, like `dict` or `variable`. But its type is `{type(local_)}`.")
        return exec(cell, global_, local_)



# In order to actually use these magics, you must register them with a
# running IPython.

def load_ipython_extension(ipython):
    """
    Any module file that define a function named `load_ipython_extension`
    can be loaded via `%load_ext module.path` or be configured to be
    autoloaded by IPython at startup time.
    """
    # You can register the class itself without instantiating it.  IPython will
    # call the default constructor on it.
    ipython.register_magics(MyMagics)