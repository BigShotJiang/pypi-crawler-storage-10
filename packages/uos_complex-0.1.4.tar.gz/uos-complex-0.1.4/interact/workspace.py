import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import sys, os, inspect
from tqdm import tqdm


class variable(dict):
    def __repr__(self):
        base = "<a set of variable>\n" + self.ls(print_=False)
        return base

    def ls(self, detail=False, print_=True):
        res = ""
        for i in vars(self):
            if i[0] == "_":
                continue
            res += i
            if detail:
                res += f" : \n{vars(self)[i]}"
            res += "\n"
        if self:
            res += "In dict :\n"
            for i in self:
                if isinstance(i, str):
                    res += f"\t'{i}'"
                else:
                    res += f"\t{i}"
                if detail:
                    res += f" : \n{self[i]}"
                res += "\n"
        if print_:
            print(res)
            return
        else:
            return res

    def set(self, **kwargs):
        return self.update(kwargs)

    def __getattr__(self, key):
        if hasattr(super(), key):
            return getattr(super(), key)
        else:
            return self[key]

    def __setattr__(self, key, value):
        if hasattr(super(), key):
            return setattr(super(), key)
        else:
            self[key] = value


class ListedDict(dict):
    def __init__(self, dictionary):
        super().__init__(dictionary)

    @property
    def at(self):
        return list(self.values())

    def __getitem__(self, values):
        if isinstance(values, slice):
            return list(self.values())[values]
        elif isinstance(values, list):
            return [self.get(key) for key in values]
        else:
            return super().__getitem__(values)

## need to move to figure

_style = {
    "large" : {
        "figure.figsize" : (5,3.5),
        "figure.dpi" : 200,
        'savefig.dpi' : 300,
        "font.size" : 10
    },
    "scientific" : {
        'font.family' : "serif",
        'mathtext.fontset' : "cm",
    }
}


class custom_default:
    def __init__(self, func):
        self.func = func
        self.__doc__ = "Customized function of \n" + func.__doc__ if  func.__doc__ else  "Customized function of \n" + repr(func)
        self.__call__ = func.__call__
        self.kwargs = {}
    
    def __repr__(self):
        return f"customized {repr(self.func)}"

    def set(self, **kwarg):
        self.kwargs = kwarg

    def update(self, _option_dict = None, **kwarg):
        if _option_dict is not None:
            self.kwargs.update(_option_dict)
        self.kwargs.update(kwarg)
        
    def __call__(self, *arg, **kwarg):
        kw = self.kwargs.copy()
        kw.update(kwarg)
        return self.func(*arg, **kw)


def plt_setter(**kwarg):
    if "ax" not in kwarg:
        ax = plt.gca()
    else:
        ax = kwarg.pop("ax")

    for arg in kwarg:
        getattr(ax, f"set_{arg}")(kwarg[arg])
        
        

def plt_style(style):
    if isinstance(style, list):
        for s in style:
            plt.rcParams.update(_style[s])
    else:
        plt.rcParams.update(_style[style])