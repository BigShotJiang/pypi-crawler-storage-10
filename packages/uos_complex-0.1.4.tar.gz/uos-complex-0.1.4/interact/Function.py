import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import inspect

__all__ = ["Function", "Gaussian", "relevant_gaussian"]

def _Functionize(func):
    def wrapper(self, other):
        if callable(other) and not isinstance(other, self.__class__):
            return func(self, self.__class__(other))
        else:
            return func(self, other)
    return wrapper

class Param(dict):
    _pinned = False
    def __init__(self, *arg, **kwarg):
        super().__init__(self, *arg, **kwarg)
        self._pinned = False
        
    def __str__(self):
        key = list(self.keys())
        rep = ""
        for para in sorted(key):
            value = self.get(para)
            if isinstance(value , float):
                rep += f"{para} = {value:5.3f}, "
            else:
                rep += f"{para} = {value}, "
        return rep[:-2]

    def __getattr__(self, key):
        if hasattr(super(), key):
            return getattr(super(), key)
        else:
            return self[key]

    def __setattr__(self, key, value):
        if self._pinned: return
            
        if hasattr(super(), key):
            return setattr(super(), key)
        else:
            self[key] = value
            
    
class Function:
    xrange_init = np.linspace(-5, 5, 101)
    
    def __init__(self, py_func, *arg, **kwarg):
        if isinstance(py_func, np.ufunc):
            self.py_func = py_func
            self.signature = {}
        else:
            self.py_func = np.vectorize(py_func, *arg, **kwarg)
            self.signature = inspect.signature(py_func).parameters
        self._py_func = py_func
        self.xrange = None
        self.independent = False # 매개변수 독립
        self.params = Param()
        # check the function contain variable for other keyword argument (i.e. **kwargs)
        self._strict = True
        for param, value in self.signature.items():  
            if value.kind == value.VAR_KEYWORD:
                self._strict = False
            if not value.default == inspect._empty:
                self.params[param] = value.default
                
        if 'doc' in kwarg:
            self.__doc__ = kwarg['doc']
        else:
            self.__doc__ = py_func.__doc__

    def __repr__(self):
        return str(self.__class__) + " of " + repr(self._py_func)

    def copy(self, pinning = False):
        temp = self.__class__(self._py_func)
        temp.params = self.params.copy()
        temp.xrange = self.xrange
        temp.params._pinned = pinning
        return temp
            
    def set_xrange(self, xmin, xmax, points=100, log = False):
        """Setup range of x for the function. 
        It is equivalent to self.xrange = np.linspace(xmin, xmax, points) when `log=False`, 
        or self.xrange = np.logspace(xmin, xmax, points) when `log=True`.
        """
        self.xrange = np.linspace(xmin, xmax, points) if not log else np.logspace(xmin, xmax, points)
        return self
    
    
    def set_params(self, **kwarg):
        """Setting parameters of function. 
        keyword argument and value of this function will be the default values of each keyword of original function.
        """
        self.params.update(kwarg)
        return self

    def fitting(self, xdata, ydata, *arg, **kwarg):
        """Parameter setting from given data. Working with `scipy.optimize.curve_fit`. So, see more detail on scipy.org."""
        if not self._strict:
            curve_fit(self, xdata, ydata) # It will raise ValueError cannot find args for curve fit
        
        result = curve_fit(self._py_func, xdata, ydata, *arg, **kwarg)
        args = list(self.signature.keys())[1:]
        self.params = Param({key : value for key, value in zip(args, result[0])})
        self.set_xrange(min(xdata), max(xdata))
        if len(result) == 2:
            return result[1] # cov
        else:
            return result[1:]
    
    def on_axis(self, ax = None, points = 100):
        if ax is None:
            ax = plt.gca()
        lims = ax.get_xlim()
        self.xrange = np.linspace(* lims, points)
        if ax.get_xscale == 'log':
            self.xrange = np.logspace(*np.log10(lims, points))
        return self

    def plot(self, fmt = "-", ax= None, points = 100, **kwargs):
        """it is equalvalent to ax.plot(self.xrange, func(self.xrange), fmt, **kwargs), 
        if self.xrange is None, then the xrange will be set from `ax.get_xlim()`. """
        if ax is None:
            ax = plt.gca()
            if not len(ax.get_children())>10 and self.xrange is None:
                self.on_axis(ax=ax, points= points)
        else:
            if self.xrange is None:
                self.on_axis(ax=ax, points= points)
            
        return ax.plot(self.xrange, self(self.xrange), fmt, **kwargs)
        

    # Method overriding
    
    def __array__(self): # for plotting object, or array style return
        xrange = self.xrange if self.xrange is not None else Function.xrange_init
        return self(xrange)

    def __call__(self, *arg, **kwarg):
        kwargs = {}
        kwargs.update(self.params)
        kwargs.update(kwarg)
        if self.independent:
            kwargs.update(self.params)
        if self._strict:
            inputs = {}
            for key in kwargs:
                if key in self.signature:
                    inputs[key] = kwargs[key]
            kwargs = inputs
        return self.py_func(*arg, **kwargs)
            
    def __iter__(self):
        yield self.xrange if self.xrange is not None else Function.xrange_init
        yield self.__array__()


    # methods for Fucntion Arithmatics 
    
    def merge_into(self, other, func):
        temp = self.__class__(func)
        if not self.xrange is None:
            temp.xrange = self.xrange
            
        if isinstance(other, self.__class__):
            temp.params.update(other.params)
        temp.params.update(self.params)
        return temp

    
    @_Functionize
    def __add__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) + other(*arg, **kwarg)
        else:
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) + other
        return self.merge_into(other, new_func)

    @_Functionize
    def __radd__(self, other): return self.__add__(other)

    @_Functionize
    def __sub__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) - other(*arg, **kwarg)
        else:
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) - other
        return self.merge_into(other, new_func)

    @_Functionize
    def __rsub__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: other(*arg, **kwarg) - self(*arg, **kwarg)
        else:
            new_func = lambda *arg, **kwarg: other - self(*arg, **kwarg)
        return self.merge_into(other, new_func)

    @_Functionize
    def __mul__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) * other(*arg, **kwarg)
        else:
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) * other
        return self.merge_into(other, new_func)

    @_Functionize
    def __rmul__(self, other): return self.__mul__(other)

    @_Functionize
    def __truediv__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) / other(*arg, **kwarg)
        else:
            new_func = lambda *arg, **kwarg: self(*arg, **kwarg) / other
        return self.merge_into(other, new_func)

    @_Functionize
    def __rtruediv__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg:  other(*arg, **kwarg) / self(*arg, **kwarg) 
        else:
            new_func = lambda *arg, **kwarg: other / self(*arg, **kwarg)
        return self.merge_into(other, new_func)

    @_Functionize
    def __matmul__(self, other):
        return self.merge_into(other, lambda x, *arg, **kwarg: self(other(x, *arg, **kwarg), *arg, **kwarg))

    @_Functionize
    def __rmatmul__(self, other):
        return self.merge_into(other, lambda x, *arg, **kwarg: other(self(x, *arg, **kwarg), *arg, **kwarg))
    
    @_Functionize
    def __pow__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: np.power(self(*arg, **kwarg) , other(*arg, **kwarg))
        else:
            new_func = lambda *arg, **kwarg: np.power(self(*arg, **kwarg) , other)
        return self.merge_into(other, new_func)

    @_Functionize
    def __rpow__(self, other):
        if callable(other):
            new_func = lambda *arg, **kwarg: np.power(other(*arg, **kwarg), self(*arg, **kwarg))
        else:
            new_func = lambda *arg, **kwarg: np.power(other, self(*arg, **kwarg))
        return self.merge_into(other, new_func)
        
    def __neg__(self):
        return self.merge_into(self, lambda *arg, **kwarg: -self(*arg, **kwarg))
    
@Function
def Gaussian (x, loc = 0, scale = 1):
    variance_d = 2* scale ** 2
    return 1/np.sqrt(np.pi*variance_d) * np.exp(-(x-loc)**2/variance_d)

@Function
def Line(x, a, b):
    return a*x + b


def relevant_gaussian(data, xmin = None, xmax = None):
    global Gaussian
    data = np.array(data)
    if xmin is not None:
        data = data[xmin<data]
    if xmax is not None:
        data = data[data<xmax]
    res = Gaussian.copy().set_params(loc = data.mean(), scale = data.std()).set_xrange(data.min(), data.max())
    return res