import matplotlib.gridspec as gridspec
import matplotlib.pyplot as plt

class PlotContainer:
    def __init__(self, plots):
        self.plots = plots # must be list
        self.last = None
        self.adjust_kwarg = {}
        self.fig_arg = []
        self.fig_kwarg = {}

    def adjust(self, **kwargs):
        self.adjust_kwarg = kwargs
        return self
    
    def figure(self, *arg, **kwarg):
        self.fig_arg = arg
        self.fig_kwarg = kwarg
        return self
    
    def __getitem__(self, value):
        return self.plots[value]

    def __call__(self, *arg, **kwarg):
        self.fig_arg = arg
        self.fig_kwarg = kwarg

    def __add__(self, other):
        if isinstance(other, Ploter):
            other = self.__class__([other])

        if isinstance(other, self.__class__):
            if self.last == "horizontal":
                for plot in other.plots:
                    self.plots.append(plot)
                self.adjust_kwarg.update(other.adjust_kwarg)
                self.last = "horizontal"
                return self
            else:
                new = self.__class__([self, other])
                new.last = "horizontal"
                return new
            
        else:
            return NotImplemented

    def __mul__(self, other):
        if isinstance(other, Ploter):
            other = self.__class__([other])

        if isinstance(other, self.__class__):
            if self.last == "vertical":
                for plot in other.plots:
                    self.plots.append(plot)
                self.adjust_kwarg.update(other.adjust_kwarg)
                self.last = "vertical"
                return self
            else:
                new = self.__class__([self, other])
                new.last = "vertical"
                return new            
        else:
            return NotImplemented

    def __matmul__(self, other):
        if isinstance(other, Ploter):
            if self.last == "stack":
                self.plots.append(other)
                return self
            else:
                raise TypeError("stacking is only working for Ploter instance.")
        else:
            return NotImplemented

    def __repr__(self):
        self.draw()
        return repr(self.fig)

    def draw(self, gs = None, fig = None):
        if fig is None:
            self.fig = plt.figure(*self.fig_arg, **self.fig_kwarg)
            fig = self.fig
            gs = gridspec.GridSpec(1,1, figure = self.fig)[0]

        if self.last == "stack":
            ax = fig.add_subplot(gs)
            self.ax = ax
            for pl in self.plots:
                pl._plot(ax = ax)
        else:
            shape = (len(self.plots), 1) if self.last == "vertical" else (1, len(self.plots))
            ngs = gridspec.GridSpecFromSubplotSpec(*shape, subplot_spec=gs, **self.adjust_kwarg)
            for i, pl in enumerate(self.plots):
                if isinstance(pl, self.__class__):
                    pl.draw(ngs[i],fig)
                else:
                    ax = fig.add_subplot(ngs[i])
                    pl._plot(ax= ax)
                
        return fig
    



class Ploter:
    def __init__(self, *arg, method = None, **kwarg):
        self.arg = arg
        self.kwarg = kwarg
        self.plot_kwarg = {}
        self.method = method
        self.axis = None
        self.grid = False
    
    def plot_settings(self, **kwargs):
        self.grid = kwargs.pop("grid", False)
        self.axis = kwargs.pop("axis", None)
        self.plot_kwarg.update(kwargs)
        return self

    
    def _plot(self, ax = None):
        if ax is None:
            ax = plt.gca()
        self.ax =ax 

        if self.method is None:
            return

        ret = getattr(ax, self.method)(*self.arg, **self.kwarg) 
        for prop in self.plot_kwarg:
            getattr(ax, f"set_{prop}")(self.plot_kwarg[prop])

        ax.grid(self.grid)
        ax.axis(self.axis)
        
        return ret
        

    def __add__(self, other):
        if isinstance(other, self.__class__):
            new= PlotContainer([self, other])
            new.last = "horizontal"
            return new
        else:
            return NotImplemented

    def __mul__(self, other):
        if isinstance(other, self.__class__):
            new= PlotContainer([self, other])
            new.last = "vertical"
            return new
        else:
            return NotImplemented
    
    def __matmul__(self, other):
        if isinstance(other, self.__class__):
            new= PlotContainer([self, other])
            new.last = "stack"
            return new
        else:
            return NotImplemented

    def copy(self):
        new = self.__class__(*self.arg, **self.kwarg)
        new.plot_kwarg.update(self.plot_kwarg)
        new.axis = self.axis
        new.grid = self.grid
        new.method = self.method
        return new

    def clear(self):
        self.plot_kwarg = {}
        self.axis = None
        self.grid = False

    
    @classmethod
    def plot(cls, *arg, **kwarg):
        new = cls(*arg, method = "plot", **kwarg)
        return new

    @classmethod
    def hist(cls, *arg, **kwarg):
        new = cls(*arg, method = "hist", **kwarg)
        return new

    @classmethod
    def empty(cls, *arg, **kwarg):
        new = cls(*arg, method = None, **kwarg)
        return new

    
    def __repr__(self):
        rep = self._plot()
        return str(rep)


plot = Ploter.plot
hist = Ploter.hist
empty = Ploter.empty
scatter = lambda *arg, **kwarg: Ploter(*arg, method="scatter", **kwarg)
