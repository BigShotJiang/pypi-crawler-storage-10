
# Trivially, this library is used for analyzing at least one system.
# So, providing default system is intuitive.

