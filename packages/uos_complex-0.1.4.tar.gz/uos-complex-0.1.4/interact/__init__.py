__version__ = "0.1.4"

from .Function import *
from .slurm import SlurmBatch