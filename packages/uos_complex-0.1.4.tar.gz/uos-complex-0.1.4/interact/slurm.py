import os, sys, inspect

class SlurmBatch:
    #`None` for skipping option, `True` for non-value option
    _default_options= {
        "job_name"          : None,
        "output"            : None,
        "error"             : None,
        "mail_type"         : None,                          # Mail events (NONE, BEGIN, END, FAIL, ALL) ex)"END,FAIL"
        "mail_user"         : None,                          # Where to send mail	                     ex)email@uos.ac.kr
        "partition"         : None,                          # target partition of slurm    ex) "hgx" or "gpu"
        "ntasks"            : 1,                             # Number of MPI ranks
        "nodes"             : 1,                             # Number of nodes
        "ntasks_per_node"   : 1,                             # How many tasks on each node
        "ntasks_per_node"   : None,                          # How many tasks on each node
        "cpus_per_task"     : None,                          # Number of OpenMP threads for each MPI process/rank
        "mems"              : None,                          # total memory
        "mem_per_cpu"       : None,                          # Memory per core
        "gres"              : None,                          # Graphic resource
        "get_user_env"      : True,                          # get user default shell environment
        "time"              : None,                          # Time limit hrs:min:sec
    }
    _slurm_path = "/TGM/SLURM/bin/sbatch" if os.path.exists("/TGM/SLURM/bin/sbatch") else "/usr/bin/sbatch"
    
    def __init__(self, jobname, outputpath = "", **kwarg):
        """Python simple slurm executer for multiple execution."""
        self._modules = {}
        self.functions = []
        self.data = []
        self.main = None
        self.options = self._default_options.copy()
        self.options["job_name"] = jobname                      # Job name
        self.options["output"]   = os.path.join(outputpath, f"{jobname}.%N.%j.out") # Standard output and error log
        self.options["error"]    = os.path.join(outputpath, f"{jobname}.%N.%j.err") # The --error option is provided to allow stdout and stderr to be redirected to different locations.
        self.options.update(kwarg)
        self._packing_code = ""
        self._ready = False
        self.pre_code = ""
        self.post_code = ""

    def set_modules(self, **kwargs):
        self._modules.update(kwargs)

        
    def write_options(self):
        """Convert options to text for source file."""
        

        nonvalueoption = lambda opt:f"""#SBATCH --{opt.replace("_","-")}"""
        valueoption = lambda opt, value:f"""#SBATCH --{opt.replace("_","-")}={value}"""
    
        sbatch_source = f"#!{sys.executable}\n"
        
    
        for key in self.options:
            if self.options[key] is None:
                continue
            elif self.options[key] is True:
                sbatch_source += nonvalueoption(key)+"\n"
            else:
                sbatch_source += valueoption(key, self.options[key])+"\n"
                
        return sbatch_source+"\n\n"

    def packing(self):
        """pickling given functions and modules into pickle file. 
        and return code to load packed pickle."""
        jobname = self.options["job_name"]
        source_code = ""
        for var in self._modules:
            source_code += f"import {self._modules[var].__name__} as {var}\n"

        source_code += "\n\n"
        if self.functions:
            for var in self.functions:
                source_code += inspect.getsource(var) 
                
        self._packing_code = source_code
        return source_code
    
    def write_python_code(self, *args, **kwargs):
        jobname = self.options["job_name"]
        if self.main is None:
            raise ValueError("No code to execute!")

        python_code = """"""
        python_code += self.write_options()
        python_code += self.packing()
        python_code += "\n\n"

        python_code += self.pre_code
        python_code += "\n\n"
        
        command = f"{self.main}("
        for arg in args:
            command += f"{arg}," if type(arg) != str else f"'{arg}',"
        for kwarg in kwargs:
            command += f"{kwarg} = {kwargs[kwarg]}," if type(kwargs[kwarg]) != str else f"'{kwargs[kwarg]}',"
        if command[-1] == ",":
            command = command[:-1]
        command += ")\n"

        python_code += command
        python_code += "\n\n"

        python_code += self.post_code
        
        return python_code

   
    def run(self, *args, **kwargs):
        jobname = self.options["job_name"]
        with open(f"{jobname}.py", "w") as f:
            f.write(self.write_python_code(*args, **kwargs))
        os.system(f"{self._slurm_path} {jobname}.py")
    
    
