# Interact

A Powerful Python Package packs for analyzing complex system.

> NetworkX + (Geo)Pandas + Visualization = interact

Systematic Analysis tool for interacting system.

## We need to make
- Data processor 
    - Massive data management (search, indexing, slicing)
    - aggregation 
    - time selection 
    - interpolation 
    - extrapolation 
    - data annealing(missing data, etc.)
    - etc.
    
- System
    - including (define interaction)
    - defining state
    - time evolving or predicting
    - make toy data (random data)

- Object : target unit of the system

- Space : the definition of place of each units.
    - lattice
    - real space (especially 2D)
    - momentum space
    - time correlated
    - abstract space (network?)
    - metric space (only distance defined)
    - space tessellation (grid, voronoi cell, triangle tessellation)

- heterogeneity analysis
    - Lorentz curve
    - power-law fitting

- Interaction
    - known interaction extract from data
    - define new interaction type

- Statistics
    - measuring metric
    
- Algorithms
    - clustering
    - geometric analysis
    - fourier transform
    - percolation

- read/write
- plotting
    - basic statistics (Pandas and networkx plot method mapping)
    - 3D visualization 
    - map visualization



## Workflow

- Core library
  - systematic problem definition and selection of data
  - defining the arbitrary calculation(observable)
  - Data I/O 
  - Code management and cache save/load (MetaProgramming)
  - scalability (connect with slurm)

- Data analaysis

- Data visualization

