export type TrainingProtocol = {
    planId: string;
    name: string;
    description: string;
}