import {createContext, useContext} from "react";

import type {TrainingProtocol} from "../models/trainingProtocol.ts";

export const TrainingProtocolContext = createContext<TrainingProtocol | null>(null);

export const useTrainingProtocol = () => useContext(TrainingProtocolContext);