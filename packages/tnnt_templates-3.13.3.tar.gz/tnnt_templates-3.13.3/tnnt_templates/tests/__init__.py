"""
Initialize the tests
"""
