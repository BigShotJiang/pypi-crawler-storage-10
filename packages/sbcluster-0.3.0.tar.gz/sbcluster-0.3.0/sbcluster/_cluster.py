from numbers import Integral, Real
from typing import Final, Self, cast

import faiss  # type: ignore
import numpy as np
import numpy.typing as npt
from sklearn.base import BaseEstimator, ClusterMixin  # type: ignore
from sklearn.utils._param_validation import Interval, validate_params  # type: ignore
from sklearn.utils.validation import check_is_fitted  # type: ignore

from ._common import compute_affinity, compute_projections, eigh_laplacian
from ._defs import AffinityTransform, ExpQuantileTransform
from ._kmeans import KMeans

# Constants
DEFAULT_AFFINITY_TRANSFORM: Final[AffinityTransform] = ExpQuantileTransform(
    0.1, 0.9, 1e4
)


class SpectralBridgesClusterer(BaseEstimator, ClusterMixin):
    """Spectral Bridges clustering algorithm.

    Attributes:
        n_clusters (int): The number of clusters to form.
        n_nodes (int): Number of nodes or initial clusters.
        p (int | float): Power of the alpha_i.
        n_iter (int): Number of iterations to run the k-means algorithm.
        n_local_trials (int | None): Number of seeding trials for centroids
            initialization.
        random_state (int | None): Determines random number generation for centroid
            initialization.
        tol (float): Tolerance for the normalized eigengap.
        affinity_transform (AffinityTransform): Affinity transform to apply to the
            affinity matrix.
        cluster_centers_ (np.ndarray | None): Coordinates of cluster centers.
        cluster_labels_ (np.ndarray | None): Labels of each cluster.
        labels_ (np.ndarray | None): Labels of each data point.
        affinity_ (np.ndarray | None): Affinity matrix.
        ngap_ (float | None): The normalized eigengap.
    """

    n_clusters: int
    n_nodes: int
    p: int | float
    n_iter: int
    n_local_trials: int | None
    random_state: int | None
    tol: float
    affinity_transform: AffinityTransform
    cluster_centers_: np.ndarray | None
    cluster_labels_: np.ndarray | None
    labels_: np.ndarray | None
    affinity_: np.ndarray | None
    ngap_: float | None

    @validate_params(
        {
            "n_clusters": [Interval(Integral, 2, None, closed="left")],
            "n_nodes": [Interval(Integral, 2, None, closed="left")],
            "p": [Interval(Real, 0, None, closed="right")],
            "n_iter": [Interval(Integral, 1, None, closed="left")],
            "n_local_trials": [Interval(Integral, 1, None, closed="left"), None],
            "random_state": ["random_state"],
            "tol": [Interval(Real, 0, None, closed="left")],
            "affinity_transform": [AffinityTransform],
        },
        prefer_skip_nested_validation=True,
    )
    def __init__(
        self,
        n_clusters: int,
        n_nodes: int,
        *,
        p: int | float = 2,
        n_iter: int = 20,
        n_local_trials: int | None = None,
        random_state: int | None = None,
        tol: float = 1e-8,
        affinity_transform: AffinityTransform = DEFAULT_AFFINITY_TRANSFORM,
    ):
        """Initialize the Spectral Bridges model.

        Args:
            n_clusters (int): The number of clusters to form.
            n_nodes  (int | None): Number of nodes or initial clusters.
            p (int | float, optional): Power of the alpha_i. Defaults to 2.
            n_iter (int, optional): Number of iterations to run the k-means
                algorithm. Defaults to 20.
            n_local_trials (int | None, optional): Number of seeding trials for
                centroids initialization. Defaults to None.
            random_state (int | None, optional): Determines random number
                generation for centroid initialization. Defaults to None.
            tol (float, optional): Tolerance for the normalized eigengap.
                Defaults to 1e-8.
            affinity_transform (AffinityTransform, optional): Affinity transform
                to apply to the affinity matrix. Defaults to DEFAULT_AFFINITY_TRANSFORM.
        """
        self.n_clusters = n_clusters
        self.n_nodes = n_nodes
        self.p = p
        self.n_iter = n_iter
        self.n_local_trials = n_local_trials
        self.random_state = random_state
        self.tol = tol
        self.affinity_transform = affinity_transform
        self.cluster_centers_ = None
        self.ngap_ = None
        self.affinity_ = None
        self.eigvals_ = None
        self.eigvecs_ = None

        if self.n_nodes <= self.n_clusters:
            raise ValueError(
                f"n_nodes must be greater than n_clusters, got {self.n_nodes} <= "
                f"{self.n_clusters}"
            )

    @validate_params(
        {
            "X": ["array-like"],
            "y": [None],
        },
        prefer_skip_nested_validation=True,
    )
    def fit(self, X: npt.ArrayLike, y: None = None) -> Self:  # noqa: ARG002
        """Fit the Spectral Bridges model on the input data X.

        Args:
            X (npt.ArrayLike): Input data to cluster.
            y (None, optional): Placeholder for y.

        Raises:
            ValueError: If the number of samples is less than the number of clusters.
            ValueError: If n_nodes is not provided.

        Returns:
            Self: The fitted model.
        """
        X = np.asarray(X)  # type: ignore

        if X.shape[0] < self.n_nodes:
            raise ValueError(
                f"n_samples={X.shape[0]} must be >= n_nodes={self.n_nodes}."
            )

        kmeans = KMeans(
            self.n_nodes,
            self.n_iter,
            self.n_local_trials,
            self.random_state,
        ).fit(X)
        self.cluster_centers_ = cast(np.ndarray, kmeans.cluster_centers_)

        projections = compute_projections(
            X, self.cluster_centers_, cast(np.ndarray, kmeans.labels_)
        )
        self.affinity_ = self.affinity_transform(compute_affinity(projections, self.p))

        eigvals, eigvecs = eigh_laplacian(self.affinity_, self.n_clusters + 1, self.tol)

        eigvecs = eigvecs[:, :-1]
        eigvecs /= np.linalg.norm(eigvecs, axis=1)[:, None]
        self.ngap_ = (eigvals[-1] - eigvals[-2]) / eigvals[-2]

        self.cluster_labels_ = cast(
            np.ndarray,
            KMeans(self.n_clusters, self.n_iter, self.n_local_trials, self.random_state)
            .fit(eigvecs)  # type: ignore
            .labels_,
        )
        self.labels_ = self.cluster_labels_[kmeans.labels_]

        return self

    @validate_params(
        {
            "X": ["array-like"],
        },
        prefer_skip_nested_validation=True,
    )
    def predict(self, X: npt.ArrayLike) -> np.ndarray:
        """Predict the nearest cluster index for each input data point x.

        Args:
            X (npt.ArrayLike): The input data.

        Raises:
            ValueError: If `X` contains inf or NaN values.
            ValueError: If `X` contains inf or NaN values.
            ValueError: If `self.cluster_centers_` is not set.

        Returns:
            np.ndarray The predicted cluster indices.
        """
        check_is_fitted(self, ("cluster_centers_", "cluster_labels_"))

        X_f32 = np.asarray(X).astype(np.float32)

        if np.isinf(X_f32).any():
            raise ValueError("X must not contain inf values")
        if np.isnan(X_f32).any():
            raise ValueError("X must not contain NaN values")

        index = faiss.IndexFlatL2(X_f32.shape[1])
        index.add(self.cluster_centers_)  # type: ignore

        return cast(np.ndarray, self.cluster_labels_)[
            cast(np.ndarray, index.search(X_f32, 1)[1]).ravel()  # type: ignore
        ]
