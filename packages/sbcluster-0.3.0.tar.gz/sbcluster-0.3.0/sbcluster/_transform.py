from collections.abc import Callable
from numbers import Integral, Real
from typing import Any, Final, Self, cast

import faiss  # type: ignore
import numpy as np
import numpy.typing as npt
from sklearn.base import BaseEstimator, TransformerMixin  # type: ignore
from sklearn.manifold import TSNE  # type: ignore
from sklearn.utils._param_validation import Interval, validate_params  # type: ignore
from sklearn.utils.validation import check_is_fitted  # type: ignore

from ._common import (
    compute_affinity,
    compute_embedding,
    compute_projections,
    eigh_laplacian,
)
from ._defs import AffinityTransform, ExpQuantileTransform, Transformer
from ._kmeans import KMeans

# Constants
DEFAULT_AFFINITY_TRANSFORM: Final[AffinityTransform] = ExpQuantileTransform(
    0.1, 0.9, 1e4
)


class SpectralBridgesTransformer(BaseEstimator, TransformerMixin):
    """Spectral Bridges clustering algorithm.

    Attributes:
        n_components (int): The number of components to form.
        n_embedding_components (int): The number of embedding components.
        n_nodes (int): Number of nodes or initial clusters.
        p (int | float): Power of the alpha_i.
        n_iter (int): Number of iterations to run the k-means algorithm.
        n_local_trials (int | None): Number of seeding trials for centroids
            initialization.
        random_state (int | None): Determines random number generation for centroid
            initialization.
        affinity_transform (AffinityTransform): Affinity transform to apply to the
            affinity matrix.
        reducer_factory (Callable[[int], Transformer]): The reducer factory to use. This
            is used to reduce the embedding space to the desired number of components.
        cluster_centers_ (np.ndarray | None): Coordinates of cluster centers.
        affinity_ (np.ndarray | None): Affinity matrix.
        embedding_ (np.ndarray | None): Embedding of the data.
    """

    n_components: int
    n_embedding_components: int
    n_nodes: int
    p: int | float
    n_iter: int
    n_local_trials: int | None
    random_state: int | None
    affinity_transform: AffinityTransform
    reducer_factory: Callable[..., Transformer]
    reducer_params: dict[str, Any]
    cluster_centers_: np.ndarray | None
    cluster_embedding_: np.ndarray | None
    affinity_: np.ndarray | None
    embedding_: np.ndarray | None

    @validate_params(
        {
            "n_components": [Interval(Integral, 2, None, closed="left")],
            "n_embedding_components": [Interval(Integral, 2, None, closed="left")],
            "n_nodes": [Interval(Integral, 2, None, closed="left")],
            "p": [Interval(Real, 0, None, closed="right")],
            "n_iter": [Interval(Integral, 1, None, closed="left")],
            "n_local_trials": [Interval(Integral, 1, None, closed="left"), None],
            "random_state": ["random_state"],
            "affinity_transform": [AffinityTransform],
        },
        prefer_skip_nested_validation=True,
    )
    def __init__(
        self,
        n_components: int = 2,
        n_embedding_components: int = 16,
        n_nodes: int = 256,
        *,
        p: int | float = 2,
        n_iter: int = 20,
        n_local_trials: int | None = None,
        random_state: int | None = None,
        affinity_transform: AffinityTransform = DEFAULT_AFFINITY_TRANSFORM,
        reducer_factory: Callable[..., Transformer] = TSNE,
        reducer_params: dict[str, Any] | None = None,
    ):
        """Initialize the Spectral Bridges model.

        Args:
            n_components (int, optional): The number of components to form. Defaults to
                2.
            n_embedding_components (int, optional): The number of embedding components.
                Defaults to 16.
            n_nodes  (int | None): Number of nodes or initial clusters. Defaults to
                256.
            p (int | float, optional): Power of the alpha_i. Defaults to 2.
            n_iter (int, optional): Number of iterations to run the k-means
                algorithm. Defaults to 20.
            n_local_trials (int | None, optional): Number of seeding trials for
                centroids initialization. Defaults to None.
            random_state (int | None, optional): Determines random number
                generation for centroid initialization. Defaults to None.
            affinity_transform (AffinityTransform, optional): Affinity transform
                to apply to the affinity matrix. Defaults to DEFAULT_AFFINITY_TRANSFORM.
            reducer_factory (Callable[..., Transformer], optional): The reducer
                factory to use. Defaults to TSNE.
            reducer_params (dict[str, Any], optional): The parameters to pass to the
                reducer factory. Defaults to None.
        """
        self.n_components = n_components
        self.n_embedding_components = n_embedding_components
        self.n_nodes = n_nodes
        self.p = p
        self.n_iter = n_iter
        self.n_local_trials = n_local_trials
        self.random_state = random_state
        self.affinity_transform = affinity_transform
        self.cluster_centers_ = None
        self.cluster_embedding_ = None
        self.affinity_ = None
        self.embedding_ = None
        self.reducer_factory = reducer_factory
        self.reducer_params = reducer_params or {}

        if self.n_nodes <= self.n_components:
            raise ValueError(
                f"n_nodes must be greater than n_components, got {self.n_nodes} <= "
                f"{self.n_components}"
            )
        if self.n_embedding_components < self.n_components:
            raise ValueError(
                f"n_embedding_components must be greater or equal to n_components, got "
                f"{self.n_embedding_components} < {self.n_components}"
            )

    @validate_params(
        {
            "X": ["array-like"],
            "y": [None],
        },
        prefer_skip_nested_validation=True,
    )
    def fit(self, X: npt.ArrayLike, y: None = None) -> Self:  # noqa: ARG002
        """Fit the Spectral Bridges model on the input data X.

        Args:
            X (npt.ArrayLike): Input data to cluster.
            y (None, optional): Placeholder for y.

        Raises:
            ValueError: If the number of samples is less than the number of clusters.
            ValueError: If n_nodes is not provided.

        Returns:
            Self: The fitted model.
        """
        X = np.asarray(X)  # type: ignore

        if X.shape[0] < self.n_nodes:
            raise ValueError(
                f"n_samples={X.shape[0]} must be >= n_nodes={self.n_nodes}."
            )

        kmeans = KMeans(
            self.n_nodes,
            self.n_iter,
            self.n_local_trials,
            self.random_state,
        ).fit(X)
        self.cluster_centers_ = cast(np.ndarray, kmeans.cluster_centers_)

        projections = compute_projections(
            X, self.cluster_centers_, cast(np.ndarray, kmeans.labels_)
        )
        self.affinity_ = self.affinity_transform(compute_affinity(projections, self.p))

        _, eigvecs = eigh_laplacian(self.affinity_, self.n_embedding_components, 0)
        eigvecs = eigvecs[:, :-1]
        eigvecs /= np.linalg.norm(eigvecs, axis=1)[:, None]

        # Compute the reduced embedding of the clusters
        self.cluster_embedding_ = self.reducer_factory(
            n_components=self.n_components, **self.reducer_params
        ).fit_transform(eigvecs)

        # Compute the embedding of the data
        self.embedding_ = compute_embedding(
            X.shape[0],
            self.cluster_embedding_,
            self.affinity_,
            projections,
            cast(np.ndarray, kmeans.labels_),
        )

        return self

    @validate_params(
        {
            "X": ["array-like"],
        },
        prefer_skip_nested_validation=True,
    )
    def transform(self, X: npt.ArrayLike) -> np.ndarray:
        """Transform the input data X.

        Args:
            X (npt.ArrayLike): The input data.

        Raises:
            ValueError: If `X` contains inf or NaN values.
            ValueError: If `X` contains inf or NaN values.
            ValueError: If `self.cluster_centers_` is not set.

        Returns:
            np.ndarray The predicted cluster indices.
        """
        check_is_fitted(self, ("cluster_centers_", "cluster_embedding_", "affinity_"))

        X_f32 = np.asarray(X).astype(np.float32)

        if np.isinf(X_f32).any():
            raise ValueError("X must not contain inf values")
        if np.isnan(X_f32).any():
            raise ValueError("X must not contain NaN values")

        index = faiss.IndexFlatL2(X_f32.shape[1])
        index.add(self.cluster_centers_)  # type: ignore
        labels = cast(np.ndarray, index.search(X_f32, 1)[1]).ravel()  # type: ignore
        projections = compute_projections(
            X_f32, cast(np.ndarray, self.cluster_centers_), labels
        )

        return compute_embedding(
            X_f32.shape[0],
            cast(np.ndarray, self.cluster_embedding_),
            cast(np.ndarray, self.affinity_),
            projections,
            labels,
        )
