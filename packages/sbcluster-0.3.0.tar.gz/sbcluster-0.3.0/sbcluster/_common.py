from typing import cast

import numpy as np
from scipy.linalg import eigh  # type: ignore
from scipy.linalg.blas import dgemm  # type: ignore
from scipy.special import logsumexp  # type: ignore


def compute_projections(
    X: np.ndarray, cluster_centers: np.ndarray, labels: np.ndarray
) -> list[np.ndarray]:
    """Compute the projections of the data points onto the segments.

    Args:
        X (np.ndarray): The data points.
        cluster_centers (np.ndarray): The cluster centers.
        labels (np.ndarray): The labels of the data points.

    Returns:
        list[np.ndarray]: The projections of the data points onto the segments.
    """
    X_centered = [
        np.array(
            X[labels == i] - cluster_centers[i],
            dtype=np.float64,
            order="F",
        )
        for i in range(cluster_centers.shape[0])
    ]

    out: list[np.ndarray] = []
    for i in range(cluster_centers.shape[0]):
        segments = np.asfortranarray(
            cluster_centers - cluster_centers[i],
            dtype=np.float64,
        )
        dists = np.einsum("ij,ij->i", segments, segments)
        dists[i] = 1

        projs = cast(np.ndarray, dgemm(1.0, X_centered[i], segments, trans_b=True))
        out.append(np.clip(projs / dists, 0, None))

    return out


def compute_affinity(projections: list[np.ndarray], p: int | float) -> np.ndarray:
    """Compute the affinity matrix.

    Args:
        projections (list[np.ndarray]): The projections of the data points onto the
            segments.
        p (int | float): The power of the affinity matrix.

    Returns:
        np.ndarray: The affinity matrix.
    """
    affinity = np.empty((len(projections), len(projections)), dtype=np.float64)
    for i, proj in enumerate(projections):
        # Numerically stable computation of the affinity matrix
        if p < np.inf:
            log_proj = np.log(np.clip(proj, np.finfo(np.float64).tiny, None))
            m = log_proj.max(axis=0)
            affinity[i] = p * m + logsumexp(p * (log_proj - m), axis=0)
        else:
            affinity[i] = np.clip(proj.max(axis=0), 0, None)

    if p < np.inf:
        counts = np.array([proj.shape[0] for proj in projections])
        log_counts = np.log(counts[None, :] + counts[:, None])
        affinity = np.exp((np.logaddexp(affinity, affinity.T) - log_counts) / p)
    else:
        affinity = np.maximum(affinity, affinity.T)

    return affinity


def eigh_laplacian(
    affinity: np.ndarray,
    n_components: int,
    tol: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute the eigenvectors and eigenvalues of the Laplacian matrix.

    Args:
        affinity (np.ndarray): The affinity matrix.
        n_components (int): The number of components to compute.
        tol (float): The tolerance for the normalized eigengap.

    Returns:
        tuple[np.ndarray, np.ndarray]: The eigenvectors and eigenvalues of the Laplacian
            matrix.
    """
    d = np.power(affinity.mean(axis=1), -0.5)
    L = -(d[:, None] * affinity * d[None, :])
    np.fill_diagonal(L, L.shape[0] + tol)

    return cast(
        tuple[np.ndarray, np.ndarray],
        eigh(
            L,
            subset_by_index=[0, n_components - 1],
        ),
    )


def compute_embedding(
    n: int,
    cluster_embedding: np.ndarray,
    affinity: np.ndarray,
    projections: list[np.ndarray],
    labels: np.ndarray,
) -> np.ndarray:
    """Compute the embedding of the data points.

    Args:
        n (int): The number of data points.
        cluster_embedding (np.ndarray): The cluster embedding.
        affinity (np.ndarray): The affinity matrix.
        projections (list[np.ndarray]): The projections of the data points onto the
            segments.
        labels (np.ndarray): The labels of the data points.

    Returns:
        np.ndarray: The embedding of the data points.
    """
    embedding = np.empty((n, cluster_embedding.shape[1]), dtype=np.float64)
    for i, proj in enumerate(projections):
        weights = affinity[i] / affinity[i].sum()
        embedding[labels == i] = cluster_embedding[i] + proj * weights @ (
            cluster_embedding - cluster_embedding[i]
        )

    return embedding
