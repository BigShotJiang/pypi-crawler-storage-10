# Hybrid Optimization Framework (starter)

Minimal starter with SearchSpace, ModelRegistry, SklearnWrapper, Genetic optimizer, ParallelExecutor, and OptimizationEngine.
