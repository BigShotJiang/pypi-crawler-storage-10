import os
import sys
import time
import zipfile
import subprocess
import shutil
import requests
import psutil
import socket
import yaml
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Optional, Set, Any, Callable, Tuple
from dataclasses import dataclass
from datetime import datetime
import threading
from importlib.metadata import version as _version, PackageNotFoundError

from zhkj_plugins.remote_config import RemoteSettings


# 单例端口管理器（服务类插件端口记录）
class PortManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.port_map = {}  # {插件名: 端口号}
        return cls._instance

    def get_port(self, plugin_name: str) -> Optional[int]:
        return self.port_map.get(plugin_name)

    def set_port(self, plugin_name: str, port: int) -> None:
        self.port_map[plugin_name] = port

    def clear_port(self, plugin_name: str) -> None:
        if plugin_name in self.port_map:
            del self.port_map[plugin_name]

    def clear_all(self) -> None:
        self.port_map.clear()


# 版本信息数据类
@dataclass
class VersionInfo:
    version: str
    download_url: str
    release_notes: str
    release_date: str
    file_size: int
    md5_hash: str = ""


# 插件配置数据类
@dataclass
class PluginConfig:
    name: str
    extract_folder: str
    app_relative_path: str
    is_service: bool = False  # 是否为服务类型插件
    current_version: str = "1.0.0"  # 当前版本


class PluginManager:
    def __init__(self, config: Dict[str, Any] = None, config_path: str = "config.yaml"):
        """通过 YAML 配置文件初始化插件管理器"""
        self.config_path = Path(config_path)
        self.config = config if config is not None else self._load_yaml_config()  # 加载 YAML 配置
        self.plugin_install_dir = Path(self.config.get('plugin_install_dir', 'plugins'))
        self.auto_check_updates = self.config.get('auto_check_updates', True)
        self.version_checks_url = self.config.get('version_checks_url', '')  # 版本检查配置URL
        self.settings_url = self.config.get('settings_url', '')  # 自定义配置URL
        self.settings_update_interval = self.config.get('settings_update_interval', 600)  # 同步间隔
        self.settings_update_timeout = self.config.get('settings_update_timeout', 10)  # 超时时间
        self.settings_plugins_version_key = self.config.get('settings_plugins_version_key', 'plugins_version')  # key

        self.port_manager = PortManager()
        self.version_cache_file = self.plugin_install_dir / "version_cache.json"
        self.version_cache = self._load_version_cache()
        self._version_checks_cache = None  # 缓存远程版本检查配置
        self._version_checks_last_fetch = 0  # 上次获取时间

        # 确保目录存在
        self._ensure_dir(self.plugin_install_dir)

        # 加载插件配置
        self.plugins = self._load_plugin_configs()

        # 启动自动更新检查（后台线程）
        if self.auto_check_updates:
            self._start_auto_update_check()

    def _load_yaml_config(self) -> Dict:
        """加载并解析 YAML 配置文件"""
        if not self.config_path.exists():
            # 创建默认配置
            default_config = {
                'plugin_install_dir': 'plugins',
                'auto_check_updates': True,
                'version_checks_url': ''
            }
            self._save_config_to_file(default_config)
            return default_config

        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ValueError(f"YAML 配置解析错误: {str(e)}")

    def _load_plugin_configs(self) -> List[PluginConfig]:
        """从插件目录加载所有插件的配置"""
        plugins = []

        # 扫描插件目录中的所有子目录
        for plugin_dir in self.plugin_install_dir.iterdir():
            if plugin_dir.is_dir() and not plugin_dir.name.startswith("_"):
                config_file = plugin_dir / "plugin.yaml"
                if config_file.exists():
                    try:
                        with open(config_file, 'r', encoding='utf-8') as f:
                            plugin_data = yaml.safe_load(f)

                        if plugin_data and 'name' in plugin_data:
                            plugin_config = PluginConfig(
                                name=plugin_data['name'],
                                extract_folder=plugin_data['extract_folder'],
                                app_relative_path=plugin_data['app_relative_path'],
                                is_service=plugin_data.get('is_service', False),
                                current_version=plugin_data.get('current_version', '1.0.0')
                            )
                            plugins.append(plugin_config)
                            print(f"加载插件配置: {plugin_config.name}")

                    except Exception as e:
                        print(f"加载插件配置文件 {config_file} 失败: {str(e)}")

        print(f"共加载 {len(plugins)} 个插件配置")
        return plugins

    def _save_plugin_config(self, plugin_config: PluginConfig) -> None:
        """保存单个插件的配置到其目录下的 plugin.yaml 文件"""
        plugin_dir = self.plugin_install_dir / plugin_config.extract_folder
        config_file = plugin_dir / "plugin.yaml"

        # 确保插件目录存在
        self._ensure_dir(plugin_dir)

        config_data = {
            'name': plugin_config.name,
            'extract_folder': plugin_config.extract_folder,
            'app_relative_path': plugin_config.app_relative_path,
            'is_service': plugin_config.is_service,
            'current_version': plugin_config.current_version
        }

        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config_data, f, allow_unicode=True, indent=2)
            print(f"保存插件配置: {plugin_config.name} -> {config_file}")
        except Exception as e:
            print(f"保存插件配置失败 {plugin_config.name}: {str(e)}")

    def _fetch_version_checks(self) -> Dict[str, Any]:
        """从远程获取版本检查配置"""
        if not self.version_checks_url:
            if self.settings_url:
                try:
                    return RemoteSettings(self.settings_url, self.settings_update_interval,
                                          self.settings_update_timeout).get_dict(self.settings_plugins_version_key)
                except Exception as e:
                    print(f"获取远程版本检查配置失败: {str(e)}")
                    return {}
            return {}

        # 检查缓存是否有效（5分钟缓存）
        current_time = time.time()
        if (self._version_checks_cache is not None and
                current_time - self._version_checks_last_fetch < 300):
            return self._version_checks_cache

        try:
            print("正在获取远程版本检查配置...")
            response = requests.get(self.version_checks_url, timeout=10)
            response.raise_for_status()
            version_checks = response.json()

            # 更新缓存
            self._version_checks_cache = version_checks
            self._version_checks_last_fetch = current_time
            print("远程版本检查配置获取成功")
            return version_checks
        except Exception as e:
            print(f"获取远程版本检查配置失败: {str(e)}")
            return {}

    def _get_version_check_info(self, plugin_name: str) -> Dict[str, Any]:
        """获取指定插件的版本检查信息"""
        version_checks = self._fetch_version_checks()
        return version_checks.get(plugin_name, {})

    def _load_version_cache(self) -> Dict[str, Any]:
        """加载版本缓存"""
        if self.version_cache_file.exists():
            try:
                with open(self.version_cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return {}
        return {}

    def _save_version_cache(self) -> None:
        """保存版本缓存"""
        try:
            with open(self.version_cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.version_cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存版本缓存失败: {str(e)}")

    def _ensure_dir(self, dir_path: Path) -> None:
        if not dir_path.exists():
            dir_path.mkdir(parents=True, exist_ok=True)
            print(f"创建目录: {dir_path}")

    def _get_free_port(self) -> int:
        """获取随机可用端口"""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('', 0))
            return s.getsockname()[1]

    def _start_auto_update_check(self) -> None:
        """启动自动更新检查后台线程"""

        def check_updates_background():
            while True:
                try:
                    # 每6小时检查一次更新
                    time.sleep(6 * 3600)
                    self.check_all_updates(background=True)
                except Exception as e:
                    print(f"后台更新检查失败: {str(e)}")

        thread = threading.Thread(target=check_updates_background, daemon=True)
        thread.start()

    def _save_config_to_file(self, config: Dict[str, Any] = None) -> None:
        """保存配置到文件"""
        if config is None:
            config = self.config

        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, allow_unicode=True, indent=2)
            print(f"配置文件已保存: {self.config_path}")
        except Exception as e:
            print(f"保存配置文件失败: {str(e)}")

    def download_with_progress(
            self,
            url: str,
            save_path: str,
            progress_callback: Optional[Callable[[int, int, float], None]] = None,
            chunk_size: int = 8192,
            timeout: int = 30
    ) -> bool:
        """
        带进度回调的文件下载函数
        """
        try:
            # 发送 HEAD 请求获取文件总大小
            head_response = requests.head(url, timeout=timeout)
            total_size = int(head_response.headers.get('Content-Length', 0))

            # 发送 GET 请求开始下载（流式传输）
            with requests.get(url, stream=True, timeout=timeout) as response:
                response.raise_for_status()

                if total_size == 0:
                    total_size = int(response.headers.get('Content-Length', 0))

                downloaded_size = 0
                start_time = time.time()
                last_time = start_time
                last_downloaded = 0

                with open(save_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            downloaded_size += len(chunk)

                            current_time = time.time()
                            time_diff = current_time - last_time
                            if time_diff > 0.1:
                                speed = (downloaded_size - last_downloaded) / (time_diff * 1024)
                                last_time = current_time
                                last_downloaded = downloaded_size

                                if progress_callback:
                                    progress_callback(downloaded_size, total_size, speed)

                if progress_callback:
                    total_time = time.time() - start_time
                    avg_speed = (downloaded_size / (total_time * 1024)) if total_time > 0 else 0
                    progress_callback(downloaded_size, total_size, avg_speed)

            print(f"\n下载完成：{save_path}")
            return True

        except Exception as e:
            print(f"\n下载失败：{str(e)}")
            return False

    def _extract_archive(self, archive_path: Path, extract_dir: Path) -> bool:
        try:
            if archive_path.suffix.lower() == '.zip':
                with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
                print(f"ZIP解压完成: {extract_dir}")
                return True
            else:
                print(f"不支持的压缩格式: {archive_path.suffix}")
                return False
        except Exception as e:
            print(f"解压失败: {str(e)}")
            return False

    def _calculate_file_md5(self, file_path: Path) -> str:
        """计算文件的MD5哈希值"""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

    def _compare_versions(self, version1: str, version2: str) -> int:
        """比较两个版本号，返回1表示version1>version2，-1表示version1<version2，0表示相等"""
        v1_parts = list(map(int, version1.split('.')))
        v2_parts = list(map(int, version2.split('.')))

        # 补齐版本号长度
        max_len = max(len(v1_parts), len(v2_parts))
        v1_parts.extend([0] * (max_len - len(v1_parts)))
        v2_parts.extend([0] * (max_len - len(v2_parts)))

        for i in range(max_len):
            if v1_parts[i] > v2_parts[i]:
                return 1
            elif v1_parts[i] < v2_parts[i]:
                return -1
        return 0

    def is_plugin_installed(self, plugin_name: str) -> bool:
        """检查插件是否已安装"""
        plugin = self.plugin_info(plugin_name)
        if not plugin:
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        return plugin_dir.exists()

    def check_plugin_update(self, plugin_name: str) -> Tuple[bool, Optional[VersionInfo]]:
        """检查插件是否有更新"""
        plugin = self.plugin_info(plugin_name)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False, None



        # 从远程获取版本检查信息
        remote_info = self._get_version_check_info(plugin_name)

        if not remote_info:
            print(f"插件 {plugin_name} 未配置版本检查URL")
            return False, None

        try:
            remote_version = remote_info.get('version', '')
            remote_url = remote_info.get('download_url', '')
            release_notes = remote_info.get('release_notes', '')
            release_date = remote_info.get('release_date', '')
            file_size = remote_info.get('file_size', 0)
            md5_hash = remote_info.get('md5_hash', '')

            if not remote_version or not remote_url:
                print(f"远程版本信息不完整: {plugin_name}")
                return False, None

            # 比较版本
            current_version = plugin.current_version
            version_comparison = self._compare_versions(remote_version, current_version)

            if version_comparison > 0:
                # 有新版本
                version_info = VersionInfo(
                    version=remote_version,
                    download_url=remote_url,
                    release_notes=release_notes,
                    release_date=release_date,
                    file_size=file_size,
                    md5_hash=md5_hash
                )
                return True, version_info
            else:
                return False, None

        except Exception as e:
            print(f"检查插件 {plugin_name} 更新失败: {str(e)}")
            return False, None

    def check_all_updates(self, background: bool = False) -> Dict[str, VersionInfo]:
        """检查所有插件的更新"""
        updates = {}

        if not background:
            print("开始检查所有插件更新...")

        for plugin in self.plugins:
            has_update, version_info = self.check_plugin_update(plugin.name)
            if has_update and version_info:
                updates[plugin.name] = version_info
                if not background:
                    print(f"🔔 插件 {plugin.name} 有新版本: {plugin.current_version} -> {version_info.version}")

        # 更新缓存
        self.version_cache['last_update_check'] = datetime.now().isoformat()
        self.version_cache['available_updates'] = {
            plugin_name: {
                'version': info.version,
                'release_date': info.release_date
            } for plugin_name, info in updates.items()
        }
        self._save_version_cache()

        if not background:
            if updates:
                print(f"\n发现 {len(updates)} 个插件有更新")
            else:
                print("\n所有插件都是最新版本")

        return updates

    def update_plugin(
            self,
            plugin_name: str,
            version_info: VersionInfo,
            progress_callback: Optional[Callable[[int, int, float], None]] = None
    ) -> bool:
        """更新指定插件到新版本"""
        plugin = self.plugin_info(plugin_name)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        print(f"开始更新插件 {plugin_name}: {plugin.current_version} -> {version_info.version}")

        # 停止运行中的插件
        if self.is_plugin_running(plugin_name):
            print(f"停止运行中的插件: {plugin_name}")
            if not self.stop_plugin(plugin_name):
                print("停止插件失败，无法更新")
                return False

        # 备份旧版本
        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        backup_dir = self.plugin_install_dir / f"{plugin.extract_folder}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        if plugin_dir.exists():
            try:
                shutil.copytree(plugin_dir, backup_dir)
                print(f"已创建备份: {backup_dir}")
            except Exception as e:
                print(f"备份失败: {str(e)}")

        # 下载新版本
        temp_archive = self.plugin_install_dir / f"{plugin.name}_update_temp.zip"

        if not self.download_with_progress(version_info.download_url, str(temp_archive), progress_callback):
            # 下载失败，恢复备份
            if backup_dir.exists():
                print("下载失败，恢复备份...")
                if plugin_dir.exists():
                    shutil.rmtree(plugin_dir)
                shutil.move(backup_dir, plugin_dir)
            return False

        # 验证文件完整性（如果提供了MD5）
        if version_info.md5_hash:
            downloaded_md5 = self._calculate_file_md5(temp_archive)
            if downloaded_md5 != version_info.md5_hash.lower():
                print(f"文件校验失败: MD5不匹配")
                temp_archive.unlink(missing_ok=True)
                # 恢复备份
                if backup_dir.exists():
                    if plugin_dir.exists():
                        shutil.rmtree(plugin_dir)
                    shutil.move(backup_dir, plugin_dir)
                return False

        # 解压新版本
        if plugin_dir.exists():
            shutil.rmtree(plugin_dir)

        self._ensure_dir(plugin_dir)
        if not self._extract_archive(temp_archive, plugin_dir):
            # 解压失败，恢复备份
            if backup_dir.exists():
                print("解压失败，恢复备份...")
                if plugin_dir.exists():
                    shutil.rmtree(plugin_dir)
                shutil.move(backup_dir, plugin_dir)
            temp_archive.unlink(missing_ok=True)
            return False

        # 更新插件配置中的版本号
        plugin.current_version = version_info.version
        self._save_plugin_config(plugin)

        # 清理临时文件
        temp_archive.unlink(missing_ok=True)

        # 删除备份
        if backup_dir.exists():
            shutil.rmtree(backup_dir)

        print(f"插件 {plugin_name} 更新完成: {version_info.version}")
        return True

    def auto_update_plugins(self) -> Dict[str, bool]:
        """自动更新所有有更新的插件"""
        updates = self.check_all_updates(background=True)
        results = {}

        for plugin_name, version_info in updates.items():
            plugin = self.plugin_info(plugin_name)
            version_check_info = self._get_version_check_info(plugin_name)
            auto_update = version_check_info.get('auto_update', False)

            if plugin and auto_update:
                print(f"自动更新插件: {plugin_name}")
                success = self.update_plugin(plugin_name, version_info)
                results[plugin_name] = success
            else:
                print(f"插件 {plugin_name} 有更新但未启用自动更新")
                results[plugin_name] = False

        return results

    def install_plugin(self, plugin_name: str, url: str = None,
                       progress_callback: Optional[Callable[[int, int, float], None]] = None) -> bool:
        """安装指定插件"""
        # 首先检查插件是否已安装
        if self.is_plugin_installed(plugin_name):
            print(f"插件已安装: {plugin_name}")
            return True

        # 如果没有提供URL，尝试从远程版本检查配置中获取
        if not url:
            version_check_info = self._get_version_check_info(plugin_name)
            url = version_check_info.get('download_url')
            if not url:
                print(f"无法获取插件 {plugin_name} 的下载地址")
                return False

        print(f"开始安装插件: {plugin_name}")

        # 创建临时下载目录
        temp_dir = self.plugin_install_dir / "_temp" / plugin_name
        self._ensure_dir(temp_dir)
        temp_archive = temp_dir / f"{plugin_name}.zip"

        # 下载插件
        if not self.download_with_progress(url, str(temp_archive), progress_callback=progress_callback):
            # 清理临时文件
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 解压到临时目录
        extract_temp_dir = temp_dir / "extracted"
        if not self._extract_archive(temp_archive, extract_temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 在解压目录中查找 plugin.yaml
        plugin_config_path = self._find_plugin_config(extract_temp_dir)
        if not plugin_config_path:
            print(f"在压缩包中未找到 plugin.yaml 文件: {plugin_name}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 读取插件配置
        plugin_config = self._load_plugin_config_from_file(plugin_config_path)
        if not plugin_config:
            print(f"无法读取插件配置文件: {plugin_name}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 验证插件名称是否匹配
        if plugin_config.name != plugin_name:
            print(f"插件名称不匹配: 配置中为 {plugin_config.name}, 期望为 {plugin_name}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 移动文件到最终目录
        plugin_dir = self.plugin_install_dir / plugin_config.extract_folder
        if plugin_dir.exists():
            print(f"目标目录已存在，先删除: {plugin_dir}")
            shutil.rmtree(plugin_dir, ignore_errors=True)

        # 移动整个解压内容到插件目录
        try:
            shutil.move(str(extract_temp_dir), str(plugin_dir))
            print(f"插件文件已移动到: {plugin_dir}")
        except Exception as e:
            print(f"移动插件文件失败: {str(e)}")
            shutil.rmtree(temp_dir, ignore_errors=True)
            return False

        # 将插件配置添加到管理器
        if not any(p.name == plugin_config.name for p in self.plugins):
            self.plugins.append(plugin_config)
            print(f"添加插件配置到管理器: {plugin_config.name}")

        # 确保插件配置已保存到插件目录（覆盖压缩包中的配置，确保最新）
        self._save_plugin_config(plugin_config)

        # 清理临时文件
        shutil.rmtree(temp_dir, ignore_errors=True)

        print(f"插件安装完成: {plugin_name}")
        return True

    def _find_plugin_config(self, directory: Path) -> Optional[Path]:
        """在目录中递归查找 plugin.yaml 文件"""
        for file_path in directory.rglob("plugin.yaml"):
            if file_path.is_file():
                return file_path
        return None

    def _load_plugin_config_from_file(self, config_path: Path) -> Optional[PluginConfig]:
        """从文件加载插件配置"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                plugin_data = yaml.safe_load(f)

            if plugin_data and 'name' in plugin_data:
                plugin_config = PluginConfig(
                    name=plugin_data['name'],
                    extract_folder=plugin_data['extract_folder'],
                    app_relative_path=plugin_data['app_relative_path'],
                    is_service=plugin_data.get('is_service', False),
                    current_version=plugin_data.get('current_version', '1.0.0')
                )
                return plugin_config
        except Exception as e:
            print(f"加载插件配置文件失败 {config_path}: {str(e)}")

        return None

    def install_all_plugins(self,
                            progress_callback: Optional[Callable[[int, int, float], None]] = None) -> None:
        """安装所有插件 - 从远程版本检查配置中获取下载地址"""
        print("开始安装所有插件...")
        for plugin in self.plugins:
            # 从远程版本检查配置中获取下载地址
            version_check_info = self._get_version_check_info(plugin.name)
            url = version_check_info.get('download_url')
            if url:
                self.install_plugin(plugin.name, url, progress_callback=progress_callback)
            else:
                print(f"插件 {plugin.name} 未配置下载地址，跳过安装")
        print("所有插件安装操作完成")

    def start_plugin(self, plugin_name: str, wait_for_ready: bool = True, timeout: int = 30) -> bool:
        """
        启动插件

        Args:
            plugin_name: 插件名称
            wait_for_ready: 是否等待插件就绪，默认等待
            timeout: 等待超时时间（秒），默认30秒

        Returns:
            启动是否成功
        """
        if self.is_plugin_running(plugin_name):
            print(f"插件已在运行: {plugin_name}")
            return True

        plugin = self.plugin_info(plugin_name)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        app_path = plugin_dir / plugin.app_relative_path

        if not plugin_dir.exists():
            print(f"插件未安装: {plugin_name}，无法启动")
            return False

        if not app_path.exists():
            print(f"插件程序不存在: {app_path}")
            return False

        try:
            cmd = [str(app_path)]
            port = None
            if plugin.is_service:
                port = self._get_free_port()
                cmd.extend([f"--port={port}"])  # 传递端口参数
                print(f"为服务插件 [{plugin_name}] 分配端口: {port}")

            print(f"启动插件: {plugin_name} ({app_path})")

            # 启动进程
            if os.name == 'nt':
                process = subprocess.Popen(cmd, shell=True)
            elif os.name == 'posix':
                process = subprocess.Popen(cmd)

            if plugin.is_service and port:
                self.port_manager.set_port(plugin_name, port)

            # 如果需要等待就绪
            if wait_for_ready:
                if plugin.is_service:
                    # 服务插件：等待端口就绪
                    success = self._wait_for_port_ready(plugin_name, port, process, timeout)
                else:
                    # 非服务插件：区分一次性任务和常驻进程
                    success = self._wait_for_non_service_ready(plugin_name, process, timeout)

                if success:
                    print(f"插件 {plugin_name} 启动成功")
                    return True
                else:
                    print(f"插件 {plugin_name} 启动超时或失败")
                    # 启动失败，清理资源
                    self.stop_plugin(plugin_name)
                    return False
            else:
                # 不等待就绪，直接返回
                print(f"插件 {plugin_name} 已启动（未等待就绪）")
                return True

        except Exception as e:
            print(f"启动插件失败: {str(e)}")
            if plugin.is_service:
                self.port_manager.clear_port(plugin_name)
            return False

    def _wait_for_non_service_ready(self, plugin_name: str, process: subprocess.Popen, timeout: int) -> bool:
        """
        等待非服务插件就绪

        对于非服务插件，有两种情况：
        1. 一次性任务：执行完成即退出，这种情况我们检查退出码
        2. 常驻进程：持续运行，这种情况我们检查进程是否在运行
        """
        print(f"等待插件 {plugin_name} 就绪...")

        start_time = time.time()

        while time.time() - start_time < timeout:
            # 检查进程状态
            return_code = process.poll()

            # 如果进程已经退出
            if return_code is not None:
                if return_code == 0:
                    # 正常退出，视为成功
                    print(f"插件 {plugin_name} 已执行完成（退出码: {return_code}）")
                    return True
                else:
                    # 异常退出，视为失败
                    print(f"插件 {plugin_name} 执行失败（退出码: {return_code}）")
                    return False
            else:
                # 进程仍在运行
                print(f"插件 {plugin_name} 正在运行...")
                return True

            time.sleep(0.5)  # 每隔0.5秒检查一次

        # 超时处理
        return_code = process.poll()
        if return_code is not None:
            # 进程在超时前已退出
            if return_code == 0:
                print(f"插件 {plugin_name} 已执行完成（超时前退出码: {return_code}）")
                return True
            else:
                print(f"插件 {plugin_name} 执行失败（超时前退出码: {return_code}）")
                return False
        else:
            # 进程仍在运行，但等待超时
            print(f"等待插件 {plugin_name} 就绪超时，但进程仍在运行")
            return True

    def _wait_for_port_ready(self, plugin_name: str, port: int, process: subprocess.Popen, timeout: int) -> bool:
        """等待服务插件的端口就绪"""
        print(f"等待服务插件 {plugin_name} 端口 {port} 就绪...")

        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                # 尝试连接端口
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(1)
                    result = sock.connect_ex(('localhost', port))
                    if result == 0:
                        print(f"服务插件 {plugin_name} 端口 {port} 已就绪")
                        return True
            except Exception:
                pass

            # 检查进程是否还在运行
            return_code = process.poll()
            if return_code is not None:
                # 进程已退出
                print(f"服务插件进程已退出: {plugin_name} (退出码: {return_code})")
                return return_code == 0  # 如果正常退出，视为成功

            time.sleep(0.5)  # 每隔0.5秒检查一次

        # 超时处理
        return_code = process.poll()
        if return_code is not None:
            # 进程在超时前已退出
            print(f"服务插件 {plugin_name} 在超时前退出 (退出码: {return_code})")
            return return_code == 0
        else:
            print(f"等待端口就绪超时: {plugin_name} (端口: {port})")
            return False

    def _get_running_processes(self) -> Set[str]:
        processes = set()
        for proc in psutil.process_iter(['exe', 'cmdline']):
            try:
                if proc.info['exe']:
                    processes.add(str(Path(proc.info['exe']).resolve()))
                elif proc.info['cmdline']:
                    cmd_path = Path(proc.info['cmdline'][0]).resolve()
                    if cmd_path.exists():
                        processes.add(str(cmd_path))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return processes

    def is_plugin_running(self, plugin_name: str) -> bool:
        plugin = self.plugin_info(plugin_name)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        app_path = plugin_dir / plugin.app_relative_path
        if not app_path.exists():
            return False

        app_abs_path = str(app_path.resolve())
        return app_abs_path in self._get_running_processes()

    def get_service_port(self, plugin_name: str) -> Optional[int]:
        plugin = self.plugin_info(plugin_name)
        if not plugin or not plugin.is_service:
            print(f"不是服务类型插件: {plugin_name}")
            return None
        return self.port_manager.get_port(plugin_name)

    def stop_plugin(self, plugin_name: str) -> bool:
        if not self.is_plugin_running(plugin_name):
            print(f"插件未在运行: {plugin_name}")
            self.port_manager.clear_port(plugin_name)
            return True

        plugin = self.plugin_info(plugin_name)
        if not plugin:
            return False

        app_abs_path = str((self.plugin_install_dir / plugin.extract_folder / plugin.app_relative_path).resolve())

        try:
            for proc in psutil.process_iter(['exe']):
                try:
                    if proc.info['exe'] and str(Path(proc.info['exe']).resolve()) == app_abs_path:
                        proc.terminate()
                        proc.wait(timeout=5)
                        print(f"已终止插件进程: {plugin_name} (PID: {proc.pid})")
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired):
                    continue

            if plugin.is_service:
                self.port_manager.clear_port(plugin_name)
            return True
        except Exception as e:
            print(f"停止插件失败: {str(e)}")
            return False

    def uninstall_plugin(self, plugin_name: str) -> bool:
        if self.is_plugin_running(plugin_name):
            print(f"插件正在运行，先停止插件: {plugin_name}")
            if not self.stop_plugin(plugin_name):
                print("停止插件失败，无法卸载")
                return False

        plugin = self.plugin_info(plugin_name)
        if not plugin:
            print(f"插件不存在: {plugin_name}")
            return False

        plugin_dir = self.plugin_install_dir / plugin.extract_folder
        if not plugin_dir.exists():
            print(f"插件未安装: {plugin_name}")
            return True

        try:
            shutil.rmtree(plugin_dir)
            print(f"插件卸载完成: {plugin_name}")
            return True
        except Exception as e:
            print(f"卸载插件失败: {str(e)}")
            return False

    def plugin_info(self, plugin_name: str) -> Optional[PluginConfig]:
        plugin = next((p for p in self.plugins if p.name == plugin_name), None)
        return plugin

    def list_plugins(self) -> None:
        print("\n插件列表:")
        print("-" * 120)
        print(
            f"{'名称':<15} {'版本':<10} {'类型':<8} {'安装状态':<10} {'运行状态':<10} {'自动更新':<8} {'端口':<6} {'安装路径':<40}")
        print("-" * 120)
        for plugin in self.plugins:
            plugin_dir = self.plugin_install_dir / plugin.extract_folder
            install_status = "已安装" if self.is_plugin_installed(plugin.name) else "未安装"
            run_status = "运行中" if self.is_plugin_running(plugin.name) else "未运行"
            port = self.port_manager.get_port(plugin.name) or "-"
            plugin_type = "服务" if plugin.is_service else "应用"

            # 从远程获取自动更新设置
            version_check_info = self._get_version_check_info(plugin.name)
            auto_update = "是" if version_check_info.get('auto_update', False) else "否"

            print(
                f"{plugin.name:<15} {plugin.current_version:<10} {plugin_type:<8} {install_status:<10} "
                f"{run_status:<10} {auto_update:<8} {str(port):<6} {str(plugin_dir):<40}"
            )
        print("-" * 120 + "\n")

    def package_plugin(self, plugin_name: str, plugin_dir: str, version: str = None):
        """
        打包插件为zip文件

        Args:
            plugin_name: 插件名
            plugin_dir: 插件目录路径
            version: 版本号，如果为None则从pyproject.toml读取
        """
        plugin_path = Path(plugin_dir)

        # 1. 检测插件实际路径是否存在
        if not plugin_path.exists():
            print(f"错误: 插件目录不存在: {plugin_dir}")
            return None

        package_output_dir = Path(
            self.config.get('package_output_dir', 'packages/' + plugin_name if plugin_name else "packages"))
        package_output_dir.mkdir(exist_ok=True)

        # 3. 读取plugin.yaml
        plugin_config_path = package_output_dir / "plugin.yaml"
        if not plugin_config_path.exists():
            print(f"错误: plugin.yaml 不存在于 {package_output_dir}")
            return None

        try:
            with open(plugin_config_path, 'r', encoding='utf-8') as f:
                plugin_config = yaml.safe_load(f)
        except Exception as e:
            print(f"读取plugin.yaml失败: {str(e)}")
            return None

        if not plugin_name:
            plugin_name = plugin_config.get('name')
            if not plugin_name:
                print("错误: plugin.yaml 中未找到插件名称")
                return None

        # 4. 如果没有version就读取pyproject.toml的版本
        if version is None:
            pyproject_path = plugin_path / "pyproject.toml"
            if pyproject_path.exists():
                try:
                    # 读取 pyproject.toml 中定义的版本号（与项目名称对应）
                    version = _version(plugin_name)  # 注意：此处名称必须与 pyproject.toml 中的 project.name 一致
                except Exception as e:
                    print(f"读取pyproject.toml失败: {str(e)}")

            if not version:
                print("错误: 未提供版本号且无法从pyproject.toml读取")
                return None

        # 更新plugin.yaml中的版本号
        plugin_config['current_version'] = version
        try:
            with open(plugin_path / "plugin.yaml", 'w', encoding='utf-8') as f:
                yaml.dump(plugin_config, f, allow_unicode=True, indent=2)
            print(f"更新plugin.yaml版本号为: {version}")
        except Exception as e:
            print(f"更新plugin.yaml失败: {str(e)}")
            return None

        zip_filename = f"{plugin_name}-{version}.zip"
        zip_path = package_output_dir / zip_filename

        # 检查zip文件是否已存在，如果存在则创建备份
        if zip_path.exists():
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_filename = f"{plugin_name}-{version}-backup-{timestamp}.zip"
            backup_path = package_output_dir / backup_filename

            try:
                shutil.copy2(zip_path, backup_path)
                print(f"已存在的zip文件已备份为: {backup_filename}")
            except Exception as e:
                print(f"备份已存在的zip文件失败: {str(e)}")
                return None

        try:
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # 遍历插件目录中的所有文件和子目录
                for file_path in plugin_path.rglob('*'):
                    if file_path.is_file():
                        # 计算在zip文件中的相对路径
                        arcname = file_path.relative_to(plugin_path)
                        zipf.write(file_path, arcname)
                        print(f"添加文件: {arcname}")

            print(f"插件打包成功: {zip_path}")
        except Exception as e:
            print(f"打包插件失败: {str(e)}")
            return None

        # 6. 计算文件哈希值
        try:
            file_hash = hashlib.md5()
            with open(zip_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    file_hash.update(chunk)
            md5_hash = file_hash.hexdigest()
        except Exception as e:
            print(f"计算文件哈希失败: {str(e)}")
            md5_hash = ""

        # 获取文件大小
        file_size = zip_path.stat().st_size

        # 7. 构建version_check内容
        download_base_url = self.config.get('download_base_url', '')
        if not download_base_url:
            print(f"打包插件异常: download_base_url未配置")

        download_url = f"{download_base_url}/{zip_filename}" if download_base_url else f"./packages/{zip_filename}"

        version_check_info = {
            "version": version,
            "download_url": download_url,
            "release_notes": f"Release {version}",
            "release_date": datetime.now().strftime("%Y-%m-%d"),
            "file_size": file_size,
            "md5_hash": md5_hash
        }

        nfo = json.dumps(version_check_info, indent=2, ensure_ascii=False)

        # 8. 保存版本检查配置到 <插件名>-<版本号>.json 文件
        version_check_filename = f"{plugin_name}-{version}.json"
        version_check_path = package_output_dir / version_check_filename

        try:
            with open(version_check_path, 'w', encoding='utf-8') as f:
                f.write(nfo)
            print(f"版本检查配置已保存到: {version_check_path}")
        except Exception as e:
            print(f"保存版本检查配置文件失败: {str(e)}")

        # 8. 打印version_check内容
        print("\n" + "=" * 50)
        print("版本检查配置内容 (可添加到远程版本检查配置中):")
        print("=" * 50)
        print(nfo)
        print("=" * 50)

        return {
            "plugin_name": plugin_name,
            "version": version,
            "zip_path": str(zip_path),
            "download_url": download_url,
            "file_size": file_size,
            "md5_hash": md5_hash
        }


def main():
    if len(sys.argv) < 2:
        print("插件管理器使用方法:")
        print("  python manager.py install <插件名> [下载地址] - 安装指定插件")
        print("  python manager.py install-all                - 安装所有插件")
        print("  python manager.py start <插件名>             - 启动指定插件")
        print("  python manager.py stop <插件名>              - 停止指定插件")
        print("  python manager.py uninstall <插件名>         - 卸载指定插件")
        print("  python manager.py list                       - 列出所有插件状态")
        print("  python manager.py status <插件名>            - 查看单个插件状态")
        print("  python manager.py get-port <插件名>          - 获取服务插件端口")
        print("  python manager.py check-updates              - 检查所有插件更新")
        print("  python manager.py update <插件名>            - 更新指定插件")
        print("  python manager.py auto-update                - 自动更新所有插件")
        print("  python manager.py is-installed <插件名>      - 检查插件是否已安装")
        print("  python manager.py refresh-version-checks     - 刷新版本检查配置")
        return

    try:
        # 初始化管理器（默认加载当前目录的 config.yaml）
        manager = PluginManager()

        command = sys.argv[1].lower()
        plugin_name = sys.argv[2] if len(sys.argv) > 2 else None
        url = sys.argv[3] if len(sys.argv) > 3 else None

        if command == "install" and plugin_name:
            manager.install_plugin(plugin_name, url)
        elif command == "install-all":
            manager.install_all_plugins()
        elif command == "start" and plugin_name:
            manager.start_plugin(plugin_name)
        elif command == "stop" and plugin_name:
            manager.stop_plugin(plugin_name)
        elif command == "uninstall" and plugin_name:
            manager.uninstall_plugin(plugin_name)
        elif command == "list":
            manager.list_plugins()
        elif command == "status" and plugin_name:
            status = "运行中" if manager.is_plugin_running(plugin_name) else "未运行"
            port = manager.get_service_port(plugin_name)
            port_info = f", 端口: {port}" if port else ""
            print(f"{plugin_name} 状态: {status}{port_info}")
        elif command == "get-port" and plugin_name:
            port = manager.get_service_port(plugin_name)
            if port:
                print(f"{plugin_name} 端口: {port}")
        elif command == "check-updates":
            updates = manager.check_all_updates()
            if updates:
                print("\n可用的更新:")
                for plugin_name, version_info in updates.items():
                    print(f"  {plugin_name}: {version_info.version} - {version_info.release_notes}")
        elif command == "update" and plugin_name:
            # 检查更新
            has_update, version_info = manager.check_plugin_update(plugin_name)
            if has_update and version_info:
                print(f"发现新版本: {version_info.version}")
                print(f"更新说明: {version_info.release_notes}")
                confirm = input("是否更新? (y/N): ")
                if confirm.lower() == 'y':
                    manager.update_plugin(plugin_name, version_info)
                else:
                    print("取消更新")
            else:
                print(f"插件 {plugin_name} 已是最新版本")
        elif command == "auto-update":
            print("开始自动更新...")
            results = manager.auto_update_plugins()
            if results:
                print("\n自动更新结果:")
                for plugin_name, success in results.items():
                    status = "成功" if success else "失败"
                    print(f"  {plugin_name}: {status}")
            else:
                print("没有需要更新的插件")
        elif command == "refresh-version-checks":
            # 强制刷新版本检查配置
            manager._version_checks_cache = None
            manager._version_checks_last_fetch = 0
            print("版本检查配置已刷新")
        elif command == "is-installed" and plugin_name:
            installed = manager.is_plugin_installed(plugin_name)
            status = "已安装" if installed else "未安装"
            print(f"插件 {plugin_name} {status}")
        else:
            print("未知命令")
    except Exception as e:
        print(f"执行失败: {str(e)}")


if __name__ == "__main__":
    # 需安装依赖：pip install psutil pyyaml requests
    main()
