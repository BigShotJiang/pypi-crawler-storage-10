######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.0                                                                                 #
# Generated on 2025-10-26T02:29:29.760750                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

