######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.0                                                                                 #
# Generated on 2025-10-26T02:29:29.787308                                                            #
######################################################################################################

from __future__ import annotations


from .card_datastore import CardDatastore as CardDatastore

def resumed_info(task):
    ...

def resolve_paths_from_task(flow_datastore, pathspec = None, type = None, hash = None, card_id = None):
    ...

