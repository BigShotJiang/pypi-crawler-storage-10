######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.0                                                                                 #
# Generated on 2025-10-26T02:29:29.781893                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

