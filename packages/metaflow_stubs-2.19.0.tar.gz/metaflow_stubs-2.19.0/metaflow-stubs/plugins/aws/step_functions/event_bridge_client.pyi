######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.0                                                                                 #
# Generated on 2025-10-26T02:29:29.816702                                                            #
######################################################################################################

from __future__ import annotations



class EventBridgeClient(object, metaclass=type):
    def __init__(self, name):
        ...
    def cron(self, cron):
        ...
    def role_arn(self, role_arn):
        ...
    def state_machine_arn(self, state_machine_arn):
        ...
    def schedule(self):
        ...
    def delete(self):
        ...
    ...

def format(name):
    ...

