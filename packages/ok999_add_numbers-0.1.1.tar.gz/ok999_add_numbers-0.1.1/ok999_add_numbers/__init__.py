def add(a: int | float, b: int | float) -> int | float:
    """
    两数相加的简单函数
    
    参数:
        a: 第一个数字（int或float）
        b: 第二个数字（int或float）
    
    返回:
        a与b的和
    """
    return a + b