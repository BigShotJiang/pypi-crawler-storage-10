# nilla net

dependencies
- CuPy must be pre-installed on your system.

installation

`
pip3 install nillanet
`

read documentation at
- [github.io](https://j-s-135.github.io/nillanet)

disclaimer
- Nilla net has been archived. The documentation is no longer available. If the project gets revived in the future, it will be reflected here. For now, while the project is not maintained, we do not recommend using it. We are not responsible for problems resulting from the use of nilla net. By using nilla net, you implicitly agree to these terms.
