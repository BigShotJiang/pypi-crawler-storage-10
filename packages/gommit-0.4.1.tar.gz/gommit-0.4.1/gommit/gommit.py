import subprocess
import os
import sys
import time
import threading
import configparser
from pathlib import Path
from openai import OpenAI
from colorama import init, Fore, Style

# --------------------------------------------------------------------------- #
# Helper: simple spinner
# --------------------------------------------------------------------------- #
def spinner(message="Processing"):
    spinner_chars = ['|', '/', '-', '\\']
    i = 0
    while getattr(threading.current_thread(), "running", True):
        sys.stdout.write(f'\r{message} {spinner_chars[i % len(spinner_chars)]}')
        sys.stdout.flush()
        time.sleep(0.1)
        i += 1
    sys.stdout.write('\r' + ' ' * (len(message) + 2) + '\r')
    sys.stdout.flush()

# --------------------------------------------------------------------------- #
# Git diff (staged only)
# --------------------------------------------------------------------------- #
def get_git_diff():
    try:
        result = subprocess.run(
            ['git', 'diff', '--cached'],
            capture_output=True, text=True, check=True
        )
        diff = result.stdout
        if not diff:
            raise ValueError("No staged changes found. Stage your changes with 'git add' first.")
        return diff
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Error running git diff: {e.stderr}")
    except FileNotFoundError:
        raise RuntimeError("Git is not installed or not found in PATH.")

# --------------------------------------------------------------------------- #
# Load configuration (project gommit.ini → env vars)
# --------------------------------------------------------------------------- #
def load_config():
    config = configparser.ConfigParser()
    ini_path = Path.cwd() / "gommit.ini"
    if ini_path.is_file():
        config.read(ini_path)

    cfg = {
        "message_style": config.get("gommit", "message_style", fallback="short").strip().lower(),
        "use_emojis":   config.getboolean("gommit", "use_emojis", fallback=False),
        "api_key":      config.get("gommit", "api_key", fallback=None),
        "base_url":     config.get("gommit", "base_url", fallback=None),
        "model":        config.get("gommit", "model", fallback=None),
    }

    # Validate message_style
    if cfg["message_style"] not in {"short", "descriptive"}:
        cfg["message_style"] = "short"

    return cfg

# --------------------------------------------------------------------------- #
# Build prompt according to config
# --------------------------------------------------------------------------- #
def build_prompt(diff: str, cfg: dict) -> str:
    base = (
        "You are a helpful assistant that generates concise, informative Git commit messages. "
        "Follow these guidelines:\n"
        "- Start with a short summary (50 characters or less) in imperative mood.\n"
        "- Use present tense (e.g., 'Add feature' not 'Added feature').\n"
    )

    if cfg["message_style"] == "descriptive":
        base += (
            "- After the summary, add a blank line and a detailed body explaining *why* the change was made.\n"
            "- Keep the body clear and professional.\n"
        )
    else:
        base += "- Keep it to a single line.\n"

    if cfg["use_emojis"]:
        base += "- Prefix the summary with a relevant emoji (e.g., feat:, fix:, refactor:, docs:, style:, test:, chore:).\n"

    base += "\nGenerate a commit message for the following git diff:\n\n" + diff
    return base

# --------------------------------------------------------------------------- #
# Call the LLM
# --------------------------------------------------------------------------- #
def generate_commit_message(diff: str, cfg: dict, max_tokens: int = 150):
    # Resolve API credentials (project > env > error)
    api_key = cfg["api_key"] or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set in environment or gommit.ini")

    base_url = cfg["base_url"] or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    model    = cfg["model"]    or os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    client = OpenAI(api_key=api_key, base_url=base_url)

    prompt = build_prompt(diff, cfg)

    # Spinner thread
    spin_thread = threading.Thread(target=spinner, args=("Generating commit message",))
    spin_thread.running = True
    spin_thread.start()

    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=0.7,
        )
        return resp.choices[0].message.content.strip()
    finally:
        spin_thread.running = False
        spin_thread.join()

# --------------------------------------------------------------------------- #
# Main entry point
# --------------------------------------------------------------------------- #
def main():
    init()  # colorama
    cfg = load_config()

    try:
        diff = get_git_diff()
        commit_msg = generate_commit_message(diff, cfg)
        print(f"\nGenerated Commit Message:\n{commit_msg}")

        confirm = input(f"\nDo you want to commit with this message? (y/n): ").strip().lower()
        if confirm == 'y':
            subprocess.run(['git', 'commit', '-m', commit_msg], check=True)
            print(f"{Fore.GREEN}Committed successfully.{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}Commit aborted.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Error: {str(e)}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
