#!/usr/bin/env python3

__version__ = '1.2'
from .read import (
    read_image, read_images, read_document_pdf, create_table_from_dict,
    read_directory_pdf, read_directory_image, read_file_pdf,
)

from .find import SearchableText, DocumentFinder
from .document import (
    OrganizeInnerData, DocumentTextExtract, OrganizeInnerText,
    FilterData, Filter
)


