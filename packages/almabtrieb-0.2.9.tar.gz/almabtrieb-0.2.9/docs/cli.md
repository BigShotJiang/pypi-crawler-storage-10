# CLI tool

::: mkdocs-click
    :module: almabtrieb.__main__
    :command: main
    :prog_name: almabtrieb
    :depth: 1