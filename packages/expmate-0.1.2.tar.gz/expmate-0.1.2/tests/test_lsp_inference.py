#!/usr/bin/env python3
"""
Test that LSP type inference works correctly with override_config().

This file demonstrates that after calling override_config(), the LSP still
knows the specific type of the config object and can provide autocomplete.
"""

import argparse
from dataclasses import dataclass, field

from expmate import Config, override_config


@dataclass
class ModelConfig(Config):
    """Model configuration."""

    dim: int = 128
    layers: int = 4
    dropout: float = 0.1


@dataclass
class TrainingConfig(Config):
    """Training configuration."""

    seed: int = 42
    epochs: int = 100
    lr: float = 0.001
    batch_size: int = 32
    model: ModelConfig = field(default_factory=ModelConfig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config-file", type=str, default=None)
    args, unknown = parser.parse_known_args()

    # Load config - LSP knows it's TrainingConfig
    if args.config_file:
        config = TrainingConfig.from_file(args.config_file)
    else:
        config = TrainingConfig.from_dict({})

    # Before override_config - LSP should autocomplete these:
    print(f"Before override: lr={config.lr}, batch_size={config.batch_size}")
    print(f"Before override: model.dim={config.model.dim}")

    # Apply overrides - THIS SHOULD PRESERVE THE TYPE
    config = override_config(config, unknown)

    # After override_config - LSP should STILL autocomplete these:
    # Try typing "config." here in your editor - you should see:
    # - config.seed
    # - config.epochs
    # - config.lr
    # - config.batch_size
    # - config.model
    #
    # Try typing "config.model." - you should see:
    # - config.model.dim
    # - config.model.layers
    # - config.model.dropout
    print(f"After override: lr={config.lr}, batch_size={config.batch_size}")
    print(f"After override: model.dim={config.model.dim}")

    # Type checking should still work
    assert isinstance(config, TrainingConfig)
    assert isinstance(config.model, ModelConfig)

    print()
    print("✅ Type inference preserved after override_config()!")
    print("✨ LSP autocomplete should work for all config fields!")


if __name__ == "__main__":
    print("=" * 70)
    print("LSP Type Inference Test")
    print("=" * 70)
    print()
    print("Testing that override_config() preserves type information...")
    print()

    main()

    print()
    print("=" * 70)
    print("To verify LSP autocomplete:")
    print("1. Open this file in VS Code with Pylance")
    print("2. Go to line with 'config = override_config(config, unknown)'")
    print("3. Type 'config.' on the next line")
    print("4. You should see autocomplete for: seed, epochs, lr, batch_size, model")
    print("5. Type 'config.model.' - you should see: dim, layers, dropout")
    print("=" * 70)
