"""Debug script to check LSP behavior."""

from dataclasses import dataclass
from expmate.config import Config


@dataclass
class TestConfig(Config):
    """Test config."""

    run_id: str
    seed: int


# Create instance
config = TestConfig.from_dict({"run_id": "test123", "seed": 42})

print(f"Type: {type(config)}")
print(f"Is dataclass: {hasattr(config.__class__, '__dataclass_fields__')}")
print(f"Dataclass fields: {list(config.__class__.__dataclass_fields__.keys())}")
print()

# Check if attributes exist
print("Checking attributes:")
print(f"  hasattr(config, 'run_id'): {hasattr(config, 'run_id')}")
print(f"  hasattr(config, 'seed'): {hasattr(config, 'seed')}")
print(f"  hasattr(config, '_data'): {hasattr(config, '_data')}")
print()

# Try to access
print("Accessing attributes:")
try:
    print(f"  config.run_id = {config.run_id}")
    print(f"  type(config.run_id) = {type(config.run_id)}")
except Exception as e:
    print(f"  ERROR accessing run_id: {e}")

try:
    print(f"  config.seed = {config.seed}")
    print(f"  type(config.seed) = {type(config.seed)}")
except Exception as e:
    print(f"  ERROR accessing seed: {e}")

print()

# Check __dict__
print(f"Instance __dict__: {config.__dict__}")
print()

# Check what object.__getattribute__ returns
try:
    run_id_direct = object.__getattribute__(config, "run_id")
    print(f"Direct access to run_id: {run_id_direct}")
except AttributeError as e:
    print(f"Direct access to run_id FAILED: {e}")
