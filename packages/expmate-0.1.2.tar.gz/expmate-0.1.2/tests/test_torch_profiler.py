#!/usr/bin/env python3
"""
Test timer() method for simple timing.

Note: For PyTorch profiling, users should use torch.profiler directly.
The timer() method provides simple wall-clock timing only.
"""

import tempfile
import time

import expmate
from expmate import ExperimentLogger


def test_simple_timer():
    """Test basic time-based profiling with timer()."""
    with tempfile.TemporaryDirectory() as tmpdir:
        logger = ExperimentLogger(run_dir=tmpdir, console_output=False)

        # Profile with simple timing
        with logger.timer("simple_ops") as result:
            time.sleep(0.01)
            _ = sum(range(1000000))

        assert result["elapsed"] > 0.009
        assert "elapsed" in result

        logger.close()


def test_timer_no_logging():
    """Test timer with log_result=False."""
    with tempfile.TemporaryDirectory() as tmpdir:
        logger = ExperimentLogger(run_dir=tmpdir, console_output=False)

        # Silent timing
        with logger.timer("silent_ops", log_result=False) as result:
            time.sleep(0.01)

        assert result["elapsed"] > 0.009

        logger.close()


def test_profiling_disabled():
    """Test that profiling can be disabled globally."""
    # Save original value
    original = expmate.profile

    try:
        # Disable profiling globally
        expmate.profile = False

        with tempfile.TemporaryDirectory() as tmpdir:
            logger = ExperimentLogger(run_dir=tmpdir, console_output=False)

            # This should be a no-op
            with logger.timer("disabled_timer") as result:
                time.sleep(0.01)

            # Elapsed should be 0 when profiling disabled
            assert result["elapsed"] == 0.0

            logger.close()
    finally:
        # Restore original value
        expmate.profile = original


def test_backward_compat_profile():
    """Test that profile() still works as alias to timer()."""
    with tempfile.TemporaryDirectory() as tmpdir:
        logger = ExperimentLogger(run_dir=tmpdir, console_output=False)

        # profile() should work as timer()
        with logger.profile("compat_test") as result:
            time.sleep(0.01)

        assert result["elapsed"] > 0.009
        assert "elapsed" in result

        logger.close()
