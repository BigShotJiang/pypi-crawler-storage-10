from setuptools import setup, find_packages

setup(
    name="minimatrix",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["numpy", "scipy", "pandas"],
    author="Suchibrata Patra",
    description="Numerical optimization toolkit — BFGS, CG, Newton, Steepest Descent, and more.",
    python_requires=">=3.7",
)
