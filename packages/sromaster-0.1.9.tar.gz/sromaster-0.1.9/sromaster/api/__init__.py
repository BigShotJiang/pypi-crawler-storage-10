# flake8: noqa

# import apis into api package
from sromaster.api.customers_api import CustomersApi
from sromaster.api.im_insurers_api import ImInsurersApi
from sromaster.api.im_mailing_api import ImMailingApi
from sromaster.api.im_sros_api import ImSrosApi
from sromaster.api.organizations_api import OrganizationsApi
from sromaster.api.parser_api import ParserApi
from sromaster.api.parser_write_api import ParserWriteApi
from sromaster.api.users_api import UsersApi

