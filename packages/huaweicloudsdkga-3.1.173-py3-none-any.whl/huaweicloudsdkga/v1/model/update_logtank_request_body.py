# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateLogtankRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'logtank': 'UpdateLogtankOption'
    }

    attribute_map = {
        'logtank': 'logtank'
    }

    def __init__(self, logtank=None):
        r"""UpdateLogtankRequestBody

        The model defined in huaweicloud sdk

        :param logtank: 
        :type logtank: :class:`huaweicloudsdkga.v1.UpdateLogtankOption`
        """
        
        

        self._logtank = None
        self.discriminator = None

        self.logtank = logtank

    @property
    def logtank(self):
        r"""Gets the logtank of this UpdateLogtankRequestBody.

        :return: The logtank of this UpdateLogtankRequestBody.
        :rtype: :class:`huaweicloudsdkga.v1.UpdateLogtankOption`
        """
        return self._logtank

    @logtank.setter
    def logtank(self, logtank):
        r"""Sets the logtank of this UpdateLogtankRequestBody.

        :param logtank: The logtank of this UpdateLogtankRequestBody.
        :type logtank: :class:`huaweicloudsdkga.v1.UpdateLogtankOption`
        """
        self._logtank = logtank

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateLogtankRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
