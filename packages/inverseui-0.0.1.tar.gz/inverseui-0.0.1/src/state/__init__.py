"""State management for UI analysis"""

from .analysis_state import UIState, AnalysisStage

__all__ = ["UIState", "AnalysisStage"]