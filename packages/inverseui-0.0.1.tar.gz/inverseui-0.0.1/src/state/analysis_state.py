from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List, Optional
import time


class AnalysisStage(Enum):
    INITIALIZED = "initialized"
    LAYOUT_ANALYSIS = "layout_analysis"
    ELEMENT_ANALYSIS = "element_analysis"
    HIERARCHY_ASSEMBLY = "hierarchy_assembly"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class UIState:
    stage: AnalysisStage = AnalysisStage.INITIALIZED
    
    screenshot_path: Optional[str] = None
    bounding_boxes: List[Dict[str, Any]] = field(default_factory=list)
    
    layout_analysis: Optional[Dict[str, Any]] = None
    element_analyses: List[Dict[str, Any]] = field(default_factory=list)
    final_hierarchy: Optional[Dict[str, Any]] = None
    
    errors: List[Dict[str, Any]] = field(default_factory=list)
    
    iteration: int = 0
    max_iterations: int = 10
    
    start_time: float = field(default_factory=time.time)
    stage_start_times: Dict[str, float] = field(default_factory=dict)
    stage_durations: Dict[str, float] = field(default_factory=dict)
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def set_stage(self, stage: AnalysisStage):
        if self.stage != AnalysisStage.INITIALIZED:
            prev_stage = self.stage.value
            if prev_stage in self.stage_start_times:
                duration = time.time() - self.stage_start_times[prev_stage]
                self.stage_durations[prev_stage] = duration
                
        self.stage = stage
        self.stage_start_times[stage.value] = time.time()
        
    def add_error(self, error: str, source: str = "unknown", details: Any = None):
        self.errors.append({
            "error": error,
            "source": source,
            "details": details,
            "timestamp": time.time()
        })
        
        if len(self.errors) > 3:
            self.stage = AnalysisStage.ERROR
            
    def is_complete(self) -> bool:
        return (self.stage == AnalysisStage.COMPLETED or 
                self.stage == AnalysisStage.ERROR or
                self.iteration >= self.max_iterations)
                
    def is_error(self) -> bool:
        return self.stage == AnalysisStage.ERROR or len(self.errors) > 0
        
    def increment_iteration(self):
        self.iteration += 1
        
    def get_result(self) -> Dict[str, Any]:
        if self.final_hierarchy:
            return {
                "success": True,
                "ui_tree": self.final_hierarchy,
                "metadata": {
                    "iterations": self.iteration,
                    "duration": time.time() - self.start_time,
                    "stage_durations": self.stage_durations,
                    **self.metadata
                }
            }
        else:
            return {
                "success": False,
                "errors": self.errors,
                "partial_results": {
                    "layout_analysis": self.layout_analysis,
                    "element_count": len(self.element_analyses)
                },
                "metadata": {
                    "iterations": self.iteration,
                    "duration": time.time() - self.start_time,
                    "failed_at_stage": self.stage.value
                }
            }
            
    def to_dict(self) -> Dict[str, Any]:
        return {
            "stage": self.stage.value,
            "screenshot_path": self.screenshot_path,
            "bounding_boxes": self.bounding_boxes,
            "layout_analysis": self.layout_analysis,
            "element_analyses": self.element_analyses,
            "final_hierarchy": self.final_hierarchy,
            "errors": self.errors,
            "iteration": self.iteration,
            "metadata": self.metadata,
            "timing": {
                "start_time": self.start_time,
                "current_duration": time.time() - self.start_time,
                "stage_durations": self.stage_durations
            }
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UIState":
        state = cls()
        
        state.stage = AnalysisStage(data.get("stage", "initialized"))
        state.screenshot_path = data.get("screenshot_path")
        state.bounding_boxes = data.get("bounding_boxes", [])
        state.layout_analysis = data.get("layout_analysis")
        state.element_analyses = data.get("element_analyses", [])
        state.final_hierarchy = data.get("final_hierarchy")
        state.errors = data.get("errors", [])
        state.iteration = data.get("iteration", 0)
        state.metadata = data.get("metadata", {})
        
        return state
        
    def get_progress(self) -> Dict[str, Any]:
        stages_completed = []
        
        if self.layout_analysis:
            stages_completed.append("layout_analysis")
        if self.element_analyses:
            stages_completed.append("element_analysis")
        if self.final_hierarchy:
            stages_completed.append("hierarchy_assembly")
            
        total_stages = 3
        completed_stages = len(stages_completed)
        
        return {
            "current_stage": self.stage.value,
            "stages_completed": stages_completed,
            "progress_percentage": (completed_stages / total_stages) * 100,
            "iteration": self.iteration,
            "has_errors": len(self.errors) > 0,
            "elapsed_time": time.time() - self.start_time
        }