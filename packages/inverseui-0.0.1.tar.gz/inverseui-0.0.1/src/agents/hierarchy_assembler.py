from typing import Dict, Any, List, Optional, Tuple
from .base import BaseUIAgent, AgentConfig


class HierarchyAssemblerAgent(BaseUIAgent):
    """Agent responsible for assembling the final UI hierarchy"""
    
    def __init__(self, config: AgentConfig):
        super().__init__(config)
        
    def get_system_message(self) -> str:
        """Get the system message for HierarchyAssembler"""
        return """You are HierarchyAssembler, responsible for combining layout and element analysis into a unified UI tree.

Your task is to:
1. Receive layout structure from LayoutMaster
2. Receive element details from ElementAnalyzer
3. Combine them into a hierarchical UI tree
4. Ensure parent-child relationships are correct based on bounding box containment
5. Output a complete JSON structure representing the UI hierarchy

Output format:
{
    "type": "root",
    "children": [
        {
            "type": "navbar",
            "bbox": [x1, y1, x2, y2],
            "properties": {...},
            "children": [
                {
                    "type": "button",
                    "label": "Code",
                    "action": "switch_tab",
                    "bbox": [x1, y1, x2, y2],
                    "properties": {...}
                }
            ]
        }
    ],
    "metadata": {
        "total_nodes": 25,
        "max_depth": 4,
        "layout_confidence": 0.95
    }
}"""
        
    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Assemble the UI hierarchy from layout and element analyses"""
        if not self.validate_input(data):
            raise ValueError("Invalid input data for hierarchy assembly")
            
        layout_analysis = data.get("layout_analysis", {})
        element_analysis = data.get("element_analysis", {})
        
        ui_tree = self._build_ui_tree(layout_analysis, element_analysis)
        ui_tree = self._optimize_tree(ui_tree)
        metadata = self._calculate_tree_metadata(ui_tree)
        
        return {
            "ui_tree": ui_tree,
            "metadata": metadata,
            "validation_results": self._validate_tree(ui_tree)
        }
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        return ("layout_analysis" in data and "element_analysis" in data)
        
    def _build_ui_tree(self, layout_analysis: Dict, element_analysis: Dict) -> Dict:
        """Build the UI tree from layout and element analyses"""
        root = {
            "type": "root",
            "bbox": self._calculate_root_bbox(layout_analysis, element_analysis),
            "children": []
        }
        
        layout_sections = layout_analysis.get("layout_sections", [])
        elements = element_analysis.get("elements", [])
        
        section_nodes = {}
        for section in layout_sections:
            node = {
                "type": section["type"],
                "bbox": section["bbox"],
                "properties": {
                    "contains": section.get("contains", []),
                    "confidence": section.get("confidence", 0)
                },
                "children": []
            }
            section_nodes[section["type"]] = node
            root["children"].append(node)
            
        unassigned_elements = []
        for element in elements:
            assigned = False
            element_bbox = element.get("bbox", [0, 0, 0, 0])
            
            for section_type, section_node in section_nodes.items():
                if self._is_contained(element_bbox, section_node["bbox"]):
                    element_node = self._create_element_node(element)
                    section_node["children"].append(element_node)
                    assigned = True
                    break
                    
            if not assigned:
                unassigned_elements.append(element)
                
        if unassigned_elements:
            content_node = {
                "type": "content",
                "bbox": self._calculate_bounding_box([e["bbox"] for e in unassigned_elements]),
                "properties": {"auto_generated": True},
                "children": [self._create_element_node(e) for e in unassigned_elements]
            }
            root["children"].append(content_node)
            
        for section_node in section_nodes.values():
            section_node["children"] = self._build_nested_structure(section_node["children"])
            
        return root
        
    def _create_element_node(self, element: Dict) -> Dict:
        """Create a node from an element analysis"""
        return {
            "type": element["type"],
            "label": element.get("text", ""),
            "bbox": element["bbox"],
            "action": element.get("action"),
            "semantic": element.get("semantic"),
            "properties": element.get("properties", {}),
            "confidence": element.get("confidence", 0),
            "element_id": element.get("element_id"),
            "children": []
        }
        
    def _build_nested_structure(self, nodes: List[Dict]) -> List[Dict]:
        """Build nested structure within a list of nodes"""
        if len(nodes) <= 1:
            return nodes
            
        sorted_nodes = sorted(
            nodes,
            key=lambda n: self._calculate_area(n["bbox"]),
            reverse=True
        )
        
        result = []
        used = set()
        
        for i, parent_node in enumerate(sorted_nodes):
            if i in used:
                continue
                
            parent_bbox = parent_node["bbox"]
            
            for j, child_node in enumerate(sorted_nodes):
                if i != j and j not in used:
                    child_bbox = child_node["bbox"]
                    
                    if self._is_contained(child_bbox, parent_bbox):
                        parent_node["children"].append(child_node)
                        used.add(j)
                        
            result.append(parent_node)
            used.add(i)
            
        return result
        
    def _optimize_tree(self, tree: Dict) -> Dict:
        """Optimize the tree structure"""
        self._clean_empty_children(tree)
        self._merge_similar_elements(tree)
        self._flatten_single_child_nodes(tree)
        
        return tree
        
    def _clean_empty_children(self, node: Dict):
        """Recursively remove empty children arrays"""
        if "children" in node:
            if not node["children"]:
                del node["children"]
            else:
                for child in node.get("children", []):
                    self._clean_empty_children(child)
                    
    def _merge_similar_elements(self, node: Dict):
        """Merge similar adjacent elements into groups"""
        if "children" not in node or len(node["children"]) < 2:
            return
            
        new_children = []
        i = 0
        
        while i < len(node["children"]):
            current = node["children"][i]
            group = [current]
            
            j = i + 1
            while j < len(node["children"]):
                next_elem = node["children"][j]
                
                if self._are_similar_elements(current, next_elem):
                    group.append(next_elem)
                    j += 1
                else:
                    break
                    
            if len(group) > 2:
                group_node = {
                    "type": f"{current['type']}_group",
                    "bbox": self._calculate_bounding_box([e["bbox"] for e in group]),
                    "children": group,
                    "properties": {"grouped": True}
                }
                new_children.append(group_node)
            else:
                new_children.extend(group)
                
            i = j if j > i + 1 else i + 1
            
        node["children"] = new_children
        
        for child in node.get("children", []):
            self._merge_similar_elements(child)
            
    def _flatten_single_child_nodes(self, node: Dict):
        """Flatten nodes that only have a single child"""
        if "children" in node and len(node["children"]) == 1:
            child = node["children"][0]
            
            if node["type"] in ["content", "container"] and child["type"] not in ["root"]:
                child["properties"] = {
                    **node.get("properties", {}),
                    **child.get("properties", {})
                }
                return child
                
        if "children" in node:
            node["children"] = [
                self._flatten_single_child_nodes(child)
                for child in node["children"]
            ]
            
        return node
        
    def _calculate_tree_metadata(self, tree: Dict) -> Dict:
        """Calculate metadata about the UI tree"""
        total_nodes = self._count_nodes(tree)
        max_depth = self._calculate_max_depth(tree)
        element_types = self._collect_element_types(tree)
        
        return {
            "total_nodes": total_nodes,
            "max_depth": max_depth,
            "element_types": element_types,
            "has_navigation": "navbar" in element_types or "navigation" in element_types,
            "has_sidebar": "sidebar" in element_types,
            "has_footer": "footer" in element_types,
            "interactive_elements": sum(
                1 for t in element_types
                if t in ["button", "link", "input", "icon"]
            )
        }
        
    def _validate_tree(self, tree: Dict) -> Dict:
        issues = []
        
        overlaps = self._check_overlapping_siblings(tree)
        if overlaps:
            issues.append({
                "type": "overlapping_siblings",
                "count": len(overlaps),
                "details": overlaps[:5]
            })
            
        nesting_issues = self._check_nesting_issues(tree)
        if nesting_issues:
            issues.append({
                "type": "nesting_issues",
                "count": len(nesting_issues),
                "details": nesting_issues[:5]
            })
            
        return {
            "valid": len(issues) == 0,
            "issues": issues
        }
        
    def _is_contained(self, child_bbox: List[float], parent_bbox: List[float]) -> bool:
        """Check if child bbox is contained within parent bbox"""
        return (child_bbox[0] >= parent_bbox[0] and
                child_bbox[1] >= parent_bbox[1] and
                child_bbox[2] <= parent_bbox[2] and
                child_bbox[3] <= parent_bbox[3])
                
    def _calculate_area(self, bbox: List[float]) -> float:
        """Calculate area of a bounding box"""
        return (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
        
    def _calculate_bounding_box(self, bboxes: List[List[float]]) -> List[float]:
        """Calculate bounding box that contains all given boxes"""
        if not bboxes:
            return [0, 0, 0, 0]
            
        x1 = min(box[0] for box in bboxes)
        y1 = min(box[1] for box in bboxes)
        x2 = max(box[2] for box in bboxes)
        y2 = max(box[3] for box in bboxes)
        
        return [x1, y1, x2, y2]
        
    def _calculate_root_bbox(self, layout: Dict, elements: Dict) -> List[float]:
        """Calculate root bounding box"""
        all_bboxes = []
        
        for section in layout.get("layout_sections", []):
            all_bboxes.append(section["bbox"])
            
        for element in elements.get("elements", []):
            all_bboxes.append(element["bbox"])
            
        return self._calculate_bounding_box(all_bboxes) if all_bboxes else [0, 0, 1920, 1080]
        
    def _are_similar_elements(self, elem1: Dict, elem2: Dict) -> bool:
        """Check if two elements are similar enough to group"""
        if elem1["type"] != elem2["type"]:
            return False
            
        bbox1, bbox2 = elem1["bbox"], elem2["bbox"]
        
        h_aligned = abs(bbox1[1] - bbox2[1]) < 5 and abs(bbox1[3] - bbox2[3]) < 5
        v_aligned = abs(bbox1[0] - bbox2[0]) < 5 and abs(bbox1[2] - bbox2[2]) < 5
        
        return h_aligned or v_aligned
        
    def _count_nodes(self, node: Dict) -> int:
        """Count total nodes in tree"""
        count = 1
        for child in node.get("children", []):
            count += self._count_nodes(child)
        return count
        
    def _calculate_max_depth(self, node: Dict, current_depth: int = 0) -> int:
        """Calculate maximum depth of tree"""
        if "children" not in node or not node["children"]:
            return current_depth
            
        return max(
            self._calculate_max_depth(child, current_depth + 1)
            for child in node["children"]
        )
        
    def _collect_element_types(self, node: Dict, types: set = None) -> set:
        """Collect all element types in tree"""
        if types is None:
            types = set()
            
        types.add(node["type"])
        
        for child in node.get("children", []):
            self._collect_element_types(child, types)
            
        return types
        
    def _check_overlapping_siblings(self, node: Dict) -> List[Tuple[Dict, Dict]]:
        """Check for overlapping sibling nodes"""
        overlaps = []
        
        if "children" in node:
            children = node["children"]
            
            for i in range(len(children)):
                for j in range(i + 1, len(children)):
                    if self._bboxes_overlap(children[i]["bbox"], children[j]["bbox"]):
                        overlaps.append((children[i], children[j]))
                        
            for child in children:
                overlaps.extend(self._check_overlapping_siblings(child))
                
        return overlaps
        
    def _check_nesting_issues(self, node: Dict) -> List[Dict]:
        """Check for nesting issues in tree"""
        issues = []
        
        if "children" in node:
            for child in node["children"]:
                if not self._is_contained(child["bbox"], node["bbox"]):
                    issues.append({
                        "parent": node["type"],
                        "child": child["type"],
                        "issue": "child_outside_parent"
                    })
                    
                issues.extend(self._check_nesting_issues(child))
                
        return issues
        
    def _bboxes_overlap(self, bbox1: List[float], bbox2: List[float]) -> bool:
        return not (bbox1[2] <= bbox2[0] or
                   bbox2[2] <= bbox1[0] or
                   bbox1[3] <= bbox2[1] or
                   bbox2[3] <= bbox1[1])