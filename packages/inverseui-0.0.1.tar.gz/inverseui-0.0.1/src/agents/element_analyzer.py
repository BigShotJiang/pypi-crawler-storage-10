from typing import Dict, Any, List, Optional
import re
import json
import asyncio
from .base import BaseUIAgent, AgentConfig, AgentResult
try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


class ElementAnalyzerAgent(BaseUIAgent):
    """Agent specialized in analyzing individual UI elements"""
    
    def __init__(self, config: AgentConfig, use_vision: bool = False):
        super().__init__(config)
        self.element_patterns = self._load_element_patterns()
        self.use_vision = use_vision and config.api_type == "anthropic" and ANTHROPIC_AVAILABLE
        
        if self.use_vision:
            try:
                from ..utils.vision_processing import VisionProcessor
                self.vision_processor = VisionProcessor()
                self.claude_client = anthropic.Anthropic(api_key=config.api_key)
            except Exception as e:
                print(f"Vision mode disabled: {e}")
                self.use_vision = False
        
    def get_system_message(self) -> str:
        """Get the system message for ElementAnalyzer"""
        if self.use_vision:
            return """You are a Vision-Enhanced ElementAnalyzer, specialized in analyzing UI elements using visual perception.

Your task is to:
1. Analyze individual UI elements using both visual appearance and text
2. Accurately classify element types based on visual cues (buttons, inputs, links, etc.)
3. Identify visual states (hover, disabled, selected) and styling
4. Extract visual properties (colors, borders, shadows, icons)
5. Understand element purpose from visual context

Focus on:
- Visual appearance and styling patterns
- Icons and visual indicators
- Text styling and hierarchy
- Interactive affordances
- Component patterns (primary button, ghost button, etc.)

Provide detailed element analysis with high confidence based on visual understanding."""
        else:
            return """You are ElementAnalyzer, specialized in analyzing individual UI elements.

Your task is to:
1. Analyze individual UI elements (buttons, labels, icons, inputs, etc.)
2. Understand their semantic meaning and potential actions
3. Classify element types accurately based on visual and textual cues
4. Predict possible interactions or actions

For each element, output:
{
    "element_id": "unique_id",
    "type": "button/label/icon/input/link/image/text/etc",
    "text": "visible text content",
    "semantic": "what this element represents or does",
    "action": "click/navigate/submit/input/toggle/etc",
    "properties": {
        "interactive": true/false,
        "state": "enabled/disabled/active/hover",
        "variant": "primary/secondary/danger/success",
        "size": "small/medium/large"
    },
    "confidence": 0.95
}"""
        
    async def analyze(self, data: Dict[str, Any]) -> AgentResult:
        """Analyze individual UI elements"""
        try:
            if not self.validate_input(data):
                return AgentResult(
                    success=False,
                    error="Invalid input data for element analysis"
                )
                
            bounding_boxes = data.get("bounding_boxes", [])
            layout_context = data.get("layout_context", {})
            screenshot_path = data.get("screenshot")
            
            if self.use_vision and screenshot_path:
                # Use vision-enhanced analysis
                analyzed_elements = await self._analyze_elements_with_vision(
                    screenshot_path, bounding_boxes, layout_context
                )
            else:
                # Use traditional analysis
                analyzed_elements = []
                for idx, box in enumerate(bounding_boxes):
                    element_analysis = self._analyze_single_element(
                        box, idx, layout_context
                    )
                    analyzed_elements.append(element_analysis)
                
            element_summary = self._summarize_elements(analyzed_elements)
            
            return AgentResult(
                success=True,
                data={
                    "elements": analyzed_elements,
                    "summary": element_summary,
                    "total_elements": len(analyzed_elements),
                    "vision_enhanced": self.use_vision and screenshot_path is not None
                },
                metadata={
                    "analysis_mode": "vision" if self.use_vision and screenshot_path else "text-only"
                }
            )
        except Exception as e:
            return AgentResult(
                success=False,
                error=f"Element analysis failed: {str(e)}"
            )
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        return "bounding_boxes" in data and isinstance(data["bounding_boxes"], list)
        
    def _load_element_patterns(self) -> Dict[str, Any]:
        """Load patterns for element classification"""
        return {
            "button": {
                "text_patterns": [
                    r"(?i)(submit|save|cancel|ok|apply|delete|add|create|update|edit|login|signup|register|download|upload)",
                    r"(?i)(yes|no|confirm|close|back|next|previous|continue)"
                ],
                "action_keywords": ["click", "submit", "navigate"],
                "properties": {
                    "interactive": True,
                    "variants": ["primary", "secondary", "danger", "success", "warning"]
                }
            },
            "input": {
                "text_patterns": [
                    r"(?i)(email|password|username|name|search|phone|address|date|time)",
                    r"(?i)(enter|type|input)"
                ],
                "action_keywords": ["input", "type", "fill"],
                "properties": {
                    "interactive": True,
                    "types": ["text", "email", "password", "number", "date", "search"]
                }
            },
            "link": {
                "text_patterns": [
                    r"(?i)(home|about|contact|help|terms|privacy|blog|news)",
                    r"(?i)(read more|learn more|view|see)"
                ],
                "action_keywords": ["navigate", "open"],
                "properties": {
                    "interactive": True,
                    "underlined": True
                }
            },
            "label": {
                "text_patterns": [
                    r"(?i)(name:|email:|password:|username:|date:|time:)",
                    r"(?i)(label|title|heading)"
                ],
                "action_keywords": [],
                "properties": {
                    "interactive": False
                }
            },
            "icon": {
                "text_patterns": [
                    r"^[\u2000-\u3300]$",  # Unicode range for common icons
                    r"(?i)(icon|glyph|symbol)"
                ],
                "action_keywords": ["click", "toggle"],
                "properties": {
                    "interactive": True,
                    "types": ["navigation", "action", "status", "social"]
                }
            }
        }
        
    def _analyze_single_element(self, box: Dict, idx: int, layout_context: Dict) -> Dict:
        """Analyze a single UI element"""
        element_id = box.get("element_id", f"element_{idx}")
        text = box.get("text", "").strip()
        bbox = box.get("bbox", [0, 0, 0, 0])
        
        element_type = self._classify_element_type(box, text)
        semantic = self._determine_semantic_meaning(element_type, text, layout_context)
        action = self._determine_action(element_type, text)
        properties = self._extract_properties(element_type, box, text)
        confidence = self._calculate_element_confidence(element_type, text, properties)
        
        return {
            "element_id": element_id,
            "type": element_type,
            "text": text,
            "bbox": bbox,
            "semantic": semantic,
            "action": action,
            "properties": properties,
            "confidence": confidence
        }
        
    def _classify_element_type(self, box: Dict, text: str) -> str:
        """Classify the type of UI element"""
        if "type" in box:
            return box["type"]
            
        for element_type, patterns in self.element_patterns.items():
            for pattern in patterns.get("text_patterns", []):
                if re.search(pattern, text):
                    return element_type
                    
        bbox = box.get("bbox", [0, 0, 0, 0])
        width = bbox[2] - bbox[0]
        height = bbox[3] - bbox[1]
        aspect_ratio = width / max(height, 1)
        
        if aspect_ratio > 3 and height < 50:
            return "button"
        elif aspect_ratio > 5:
            return "input"
        elif width < 50 and height < 50:
            return "icon"
        elif not text:
            return "image"
        else:
            return "text"
            
    def _determine_semantic_meaning(self, element_type: str, text: str, context: Dict) -> str:
        """Determine the semantic meaning of an element"""
        semantic_mappings = {
            "button": {
                "submit": "form submission",
                "save": "save changes",
                "cancel": "cancel operation",
                "login": "user authentication",
                "search": "search functionality",
                "add": "add new item",
                "delete": "remove item"
            },
            "input": {
                "email": "email address input",
                "password": "password input",
                "search": "search query input",
                "name": "name input field"
            },
            "link": {
                "home": "navigate to homepage",
                "about": "view about information",
                "contact": "contact information"
            }
        }
        
        element_mappings = semantic_mappings.get(element_type, {})
        text_lower = text.lower()
        
        for keyword, meaning in element_mappings.items():
            if keyword in text_lower:
                return meaning
                
        default_semantics = {
            "button": f"interactive button with text '{text}'",
            "input": f"input field for '{text}'",
            "link": f"navigation link to '{text}'",
            "label": f"label displaying '{text}'",
            "icon": "interactive icon element",
            "image": "image or graphic element",
            "text": f"text content: '{text}'"
        }
        
        return default_semantics.get(element_type, f"UI element: '{text}'")
        
    def _determine_action(self, element_type: str, text: str) -> str:
        """Determine the primary action for an element"""
        action_mappings = {
            "button": {
                "submit": "submit_form",
                "save": "save_data",
                "cancel": "cancel_action",
                "delete": "delete_item",
                "add": "add_item",
                "login": "authenticate",
                "search": "perform_search"
            },
            "input": "input_text",
            "link": "navigate",
            "icon": "click_action",
            "label": None,
            "text": None,
            "image": "view_image"
        }
        
        if element_type in ["button", "link"]:
            text_lower = text.lower()
            type_mappings = action_mappings.get(element_type, {})
            
            if isinstance(type_mappings, dict):
                for keyword, action in type_mappings.items():
                    if keyword in text_lower:
                        return action
                        
            return "click"
            
        return action_mappings.get(element_type, "interact")
        
    def _extract_properties(self, element_type: str, box: Dict, text: str) -> Dict:
        """Extract element properties"""
        properties = {
            "interactive": element_type in ["button", "input", "link", "icon"]
        }
        
        if element_type in ["button", "input"]:
            properties["state"] = "enabled"
            
        if element_type == "button":
            text_lower = text.lower()
            if any(word in text_lower for word in ["delete", "remove", "cancel"]):
                properties["variant"] = "danger"
            elif any(word in text_lower for word in ["save", "submit", "confirm"]):
                properties["variant"] = "primary"
            else:
                properties["variant"] = "secondary"
                
        bbox = box.get("bbox", [0, 0, 0, 0])
        height = bbox[3] - bbox[1]
        
        if height < 30:
            properties["size"] = "small"
        elif height < 50:
            properties["size"] = "medium"
        else:
            properties["size"] = "large"
            
        return properties
        
    def _calculate_element_confidence(self, element_type: str, text: str, properties: Dict) -> float:
        """Calculate confidence score for element analysis"""
        confidence = 0.5
        
        for patterns in self.element_patterns.get(element_type, {}).get("text_patterns", []):
            if re.search(patterns, text):
                confidence += 0.3
                break
                
        if text:
            confidence += 0.1
            
        if properties.get("interactive") and element_type in ["button", "link"]:
            confidence += 0.1
            
        return min(confidence, 0.99)
        
    def _summarize_elements(self, elements: List[Dict]) -> Dict:
        """Create a summary of analyzed elements"""
        summary = {
            "by_type": {},
            "interactive_count": 0,
            "total_confidence": 0
        }
        
        for element in elements:
            el_type = element["type"]
            if el_type not in summary["by_type"]:
                summary["by_type"][el_type] = []
                
            summary["by_type"][el_type].append(element["element_id"])
            
            if element["properties"].get("interactive"):
                summary["interactive_count"] += 1
                
            summary["total_confidence"] += element["confidence"]
            
        summary["average_confidence"] = summary["total_confidence"] / max(len(elements), 1)
        
        return summary
    
    async def _analyze_elements_with_vision(self, screenshot_path: str, bounding_boxes: List[Dict], layout_context: Dict) -> List[Dict]:
        """Analyze elements using vision capabilities"""
        batch_size = 10
        all_analyzed_elements = []
        
        for i in range(0, len(bounding_boxes), batch_size):
            batch = bounding_boxes[i:i + batch_size]
            
            # Prepare cropped images for this batch
            encoded_images = self.vision_processor.prepare_images_for_analysis(
                screenshot_path=screenshot_path,
                bounding_boxes=batch,
                include_full_screenshot=False,
                max_crops=None
            )
            
            # Analyze batch with vision
            batch_results = await self._analyze_batch_with_vision(
                encoded_images, batch, layout_context, i
            )
            all_analyzed_elements.extend(batch_results)
            
        return all_analyzed_elements
    
    async def _analyze_batch_with_vision(self, encoded_images: Dict, batch: List[Dict], layout_context: Dict, start_idx: int) -> List[Dict]:
        """Analyze a batch of elements using Claude Vision"""
        prompt = self._create_vision_batch_prompt(batch, layout_context)
        
        # Create message content with cropped images
        message_content = self.vision_processor.create_vision_prompt_with_images(
            base_prompt=prompt,
            encoded_images=encoded_images,
            include_bbox_context=True
        )
        
        try:
            # Call Claude Vision API
            response = self.claude_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=4096,
                messages=[{
                    "role": "user",
                    "content": message_content
                }]
            )
            
            # Parse response
            response_text = response.content[0].text
            json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
            if json_match:
                analysis_data = json.loads(json_match.group(1))
            else:
                analysis_data = json.loads(response_text)
            
            # Map analysis to elements
            analyzed_elements = []
            elements_analysis = analysis_data.get("elements", [])
            
            for idx, element_data in enumerate(batch):
                if idx < len(elements_analysis):
                    vision_analysis = elements_analysis[idx]
                    analyzed_elements.append(self._merge_vision_analysis(
                        element_data, vision_analysis, start_idx + idx
                    ))
                else:
                    # Fallback analysis
                    analyzed_elements.append(self._analyze_single_element(
                        element_data, start_idx + idx, layout_context
                    ))
            
            return analyzed_elements
            
        except Exception as e:
            print(f"Vision analysis error: {e}")
            # Fall back to traditional analysis
            return [self._analyze_single_element(elem, start_idx + i, layout_context) 
                    for i, elem in enumerate(batch)]
    
    def _create_vision_batch_prompt(self, batch: List[Dict], layout_context: Dict) -> str:
        """Create prompt for vision batch analysis"""
        context_info = ""
        if layout_context:
            context_info = f"\nLayout context: {json.dumps(layout_context, indent=2)}"
        
        return f"""Analyze these UI element crops and provide detailed classification for each.

For each element image shown above, determine:

1. **Element Type**: button, link, input, text, image, icon, container, etc.
2. **Visual Properties**:
   - Colors (background, text, border)
   - Typography (size, weight, style)
   - Styling (borders, shadows, rounded corners)
   - Icons or visual indicators
3. **Interactive State**: clickable, editable, static, hover/active states
4. **Semantic Meaning**: What the element does based on visual context
5. **Confidence**: Your confidence level (0-1) in this classification

{context_info}

Return a JSON array with analysis for each element:
```json
{{
  "elements": [
    {{
      "type": "button",
      "semantic": "submit form",
      "action": "submit",
      "visual_properties": {{
        "background_color": "#007bff",
        "text_color": "#ffffff",
        "border_radius": "4px",
        "has_icon": false
      }},
      "properties": {{
        "interactive": true,
        "state": "enabled",
        "variant": "primary",
        "size": "medium"
      }},
      "confidence": 0.95
    }}
  ]
}}
```"""
    
    def _merge_vision_analysis(self, element_data: Dict, vision_analysis: Dict, idx: int) -> Dict:
        """Merge vision analysis with element data"""
        element_id = element_data.get("element_id", f"element_{idx}")
        text = element_data.get("text", "").strip()
        bbox = element_data.get("bbox", [0, 0, 0, 0])
        
        # Use vision-determined type with high confidence
        element_type = vision_analysis.get("type", "unknown")
        confidence = vision_analysis.get("confidence", 0.9)
        
        # Merge properties from vision analysis
        properties = vision_analysis.get("properties", {})
        if "visual_properties" in vision_analysis:
            properties["visual_properties"] = vision_analysis["visual_properties"]
        
        return {
            "element_id": element_id,
            "type": element_type,
            "text": text,
            "bbox": bbox,
            "semantic": vision_analysis.get("semantic", f"UI element: {element_type}"),
            "action": vision_analysis.get("action", self._determine_action(element_type, text)),
            "properties": properties,
            "confidence": confidence,
            "vision_analyzed": True
        }