from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import logging
from autogen import AssistantAgent


@dataclass
class AgentConfig:
    name: str
    model: str
    api_key: str
    temperature: float = 0.1
    max_retries: int = 3
    api_type: str = "openai"
    role: Optional[str] = None


@dataclass
class AgentResult:
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class BaseUIAgent(ABC):
    """Base class for all UI analysis agents"""
    
    def __init__(self, config: AgentConfig):
        self.config = config
        self.logger = logging.getLogger(f"UIAgent.{config.name}")
        self._state = "initialized"
        self._autogen_agent = None
        
    @abstractmethod
    def get_system_message(self) -> str:
        pass
        
    @abstractmethod
    def analyze(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pass
    
    @abstractmethod
    def validate_input(self, data: Dict[str, Any]) -> bool:
        pass
    
    def get_autogen_agent(self) -> AssistantAgent:
        """Get or create the Autogen AssistantAgent"""
        if self._autogen_agent is None:
            self._autogen_agent = AssistantAgent(
                name=self.config.name,
                system_message=self.get_system_message(),
                llm_config={
                    "config_list": [{
                        "model": self.config.model,
                        "api_key": self.config.api_key,
                        "api_type": self.config.api_type,
                    }],
                    "temperature": self.config.temperature,
                }
            )
        return self._autogen_agent
    
    def reset(self):
        self._state = "initialized"
        self.logger.info(f"Agent {self.config.name} reset")
        
    def get_state(self) -> str:
        return self._state
        
    def set_state(self, state: str):
        self._state = state
        self.logger.info(f"Agent {self.config.name} state changed to: {state}")


class DelegatingAgent(BaseUIAgent):
    """Agent that can delegate tasks to sub-agents"""
    
    def __init__(self, config: AgentConfig, sub_agents: Dict[str, BaseUIAgent]):
        super().__init__(config)
        self.sub_agents = sub_agents
        
    def delegate_task(self, task_type: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Delegate a task to a sub-agent"""
        if task_type not in self.sub_agents:
            raise ValueError(f"No sub-agent available for task type: {task_type}")
            
        sub_agent = self.sub_agents[task_type]
        self.logger.info(f"Delegating {task_type} to {sub_agent.config.name}")
        
        try:
            return sub_agent.analyze(data)
        except Exception as e:
            self.logger.error(f"Sub-agent {sub_agent.config.name} failed: {str(e)}")
            raise
            
    def get_available_sub_agents(self) -> List[str]:
        return list(self.sub_agents.keys())