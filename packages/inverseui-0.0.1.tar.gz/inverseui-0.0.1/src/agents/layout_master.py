from typing import Dict, Any, List, Tuple
import numpy as np
import json
import re
from .base import BaseUIAgent, AgentConfig, AgentResult
try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False


class LayoutMasterAgent(BaseUIAgent):
    """Agent specialized in analyzing UI layouts"""
    
    def __init__(self, config: AgentConfig, use_vision: bool = False):
        super().__init__(config)
        self.layout_patterns = self._load_layout_patterns()
        self.use_vision = use_vision and config.api_type == "anthropic" and ANTHROPIC_AVAILABLE
        
        if self.use_vision:
            try:
                from ..utils.vision_processing import VisionProcessor
                self.vision_processor = VisionProcessor()
                self.claude_client = anthropic.Anthropic(api_key=config.api_key)
            except Exception as e:
                print(f"Vision mode disabled: {e}")
                self.use_vision = False
        
    def get_system_message(self) -> str:
        """Get the system message for LayoutMaster"""
        if self.use_vision:
            return """You are a Vision-Enhanced LayoutMaster, analyzing UI layouts with visual perception.

Your task is to:
1. Analyze the UI screenshot using visual understanding
2. Identify visual layout patterns and design systems
3. Detect major sections based on visual hierarchy and grouping
4. Understand visual boundaries, spacing, and alignment
5. Recognize navigation patterns and content organization

Focus on:
- Visual grouping and proximity
- Color schemes and visual themes
- Typography hierarchy
- Spacing patterns and visual rhythm
- Visual boundaries and containers
- Design patterns (cards, grids, etc.)

Provide comprehensive layout analysis based on visual understanding."""
        else:
            return """You are LayoutMaster, an expert in analyzing UI layouts.

Your task is to:
1. Analyze the overall UI screenshot with bounding boxes
2. Identify major layout structures (navbar, sidebar, content area, footer, etc.)
3. Determine the hierarchical relationship between these major sections
4. Output a structured layout hierarchy

Format your response as JSON with the following structure:
{
    "layout_sections": [
        {
            "type": "navbar",
            "bbox": [x1, y1, x2, y2],
            "contains": ["navigation items", "logo", "search"],
            "confidence": 0.95
        }
    ],
    "spatial_relationships": [
        {
            "parent": "root",
            "child": "navbar",
            "relationship": "top"
        }
    ]
}"""
        
    async def analyze(self, data: Dict[str, Any]) -> AgentResult:
        try:
            if not self.validate_input(data):
                return AgentResult(
                    success=False,
                    error="Invalid input data for layout analysis"
                )
                
            screenshot_path = data.get("screenshot")
            bounding_boxes = data.get("bounding_boxes", [])
            
            if self.use_vision and screenshot_path:
                # Use vision-enhanced analysis
                result = await self._analyze_with_vision(screenshot_path, bounding_boxes)
                layout_sections = result.get("layout_sections", [])
                spatial_relationships = result.get("spatial_relationships", [])
                visual_insights = result.get("visual_insights", {})
            else:
                # Use traditional analysis
                layout_sections = self._identify_layout_sections(bounding_boxes)
                spatial_relationships = self._build_spatial_relationships(layout_sections)
                visual_insights = {}
            
            for section in layout_sections:
                section["confidence"] = self._calculate_confidence(section, bounding_boxes)
            
            return AgentResult(
                success=True,
                data={
                    "layout_sections": layout_sections,
                    "spatial_relationships": spatial_relationships,
                    "visual_insights": visual_insights,
                    "analysis_metadata": {
                        "total_elements": len(bounding_boxes),
                        "identified_sections": len(layout_sections),
                        "confidence_average": np.mean([s["confidence"] for s in layout_sections]) if layout_sections else 0,
                        "vision_enhanced": self.use_vision and screenshot_path is not None
                    }
                },
                metadata={
                    "analysis_mode": "vision" if self.use_vision and screenshot_path else "coordinate-based"
                }
            )
        except Exception as e:
            return AgentResult(
                success=False,
                error=f"Layout analysis failed: {str(e)}"
            )
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        return "bounding_boxes" in data and isinstance(data["bounding_boxes"], list)
        
    def _load_layout_patterns(self) -> Dict[str, Any]:
        """Load common UI layout patterns"""
        return {
            "navbar": {
                "position": "top",
                "height_ratio": (0, 0.15),
                "common_elements": ["logo", "navigation", "search", "user menu"]
            },
            "sidebar": {
                "position": ["left", "right"],
                "width_ratio": (0.15, 0.3),
                "common_elements": ["navigation", "filters", "menu items"]
            },
            "content": {
                "position": "center",
                "common_elements": ["main content", "articles", "data"]
            },
            "footer": {
                "position": "bottom",
                "height_ratio": (0, 0.2),
                "common_elements": ["links", "copyright", "contact"]
            }
        }
        
    def _identify_layout_sections(self, bounding_boxes: List[Dict]) -> List[Dict]:
        """Identify major layout sections from bounding boxes"""
        if not bounding_boxes:
            return []
            
        viewport = self._get_viewport_dimensions(bounding_boxes)
        sections = []
        
        for pattern_name, pattern in self.layout_patterns.items():
            section_boxes = self._find_section_boxes(
                bounding_boxes, pattern, viewport
            )
            
            if section_boxes:
                sections.append({
                    "type": pattern_name,
                    "bbox": self._merge_bounding_boxes([b["bbox"] for b in section_boxes]),
                    "contains": [b.get("text", "") for b in section_boxes if b.get("text")],
                    "element_count": len(section_boxes)
                })
                
        return sections
        
    def _build_spatial_relationships(self, layout_sections: List[Dict]) -> List[Dict]:
        """Build spatial relationships between layout sections"""
        relationships = []
        
        for i, section in enumerate(layout_sections):
            for j, other_section in enumerate(layout_sections):
                if i != j:
                    relation = self._determine_spatial_relation(
                        section["bbox"], other_section["bbox"]
                    )
                    if relation:
                        relationships.append({
                            "parent": section["type"],
                            "child": other_section["type"],
                            "relationship": relation
                        })
                        
        return relationships
        
    def _get_viewport_dimensions(self, bounding_boxes: List[Dict]) -> Tuple[int, int]:
        """Calculate viewport dimensions from all bounding boxes"""
        if not bounding_boxes:
            return (1920, 1080)  # Default viewport
            
        max_x = max(box["bbox"][2] for box in bounding_boxes)
        max_y = max(box["bbox"][3] for box in bounding_boxes)
        
        return (max_x, max_y)
        
    def _find_section_boxes(self, boxes: List[Dict], pattern: Dict, viewport: Tuple) -> List[Dict]:
        """Find boxes that match a layout pattern"""
        matching_boxes = []
        width, height = viewport
        
        for box in boxes:
            bbox = box["bbox"]
            box_width = bbox[2] - bbox[0]
            box_height = bbox[3] - bbox[1]
            
            # Check position
            if pattern.get("position") == "top" and bbox[1] < height * 0.2:
                matching_boxes.append(box)
            elif pattern.get("position") == "bottom" and bbox[3] > height * 0.8:
                matching_boxes.append(box)
            elif "left" in pattern.get("position", []) and bbox[0] < width * 0.3:
                matching_boxes.append(box)
            elif "right" in pattern.get("position", []) and bbox[2] > width * 0.7:
                matching_boxes.append(box)
                
        return matching_boxes
        
    def _merge_bounding_boxes(self, boxes: List[List[float]]) -> List[float]:
        """Merge multiple bounding boxes into one"""
        if not boxes:
            return [0, 0, 0, 0]
            
        x1 = min(box[0] for box in boxes)
        y1 = min(box[1] for box in boxes)
        x2 = max(box[2] for box in boxes)
        y2 = max(box[3] for box in boxes)
        
        return [x1, y1, x2, y2]
        
    def _determine_spatial_relation(self, bbox1: List[float], bbox2: List[float]) -> str:
        """Determine spatial relationship between two bounding boxes"""
        # Check if bbox1 contains bbox2
        if (bbox2[0] >= bbox1[0] and bbox2[1] >= bbox1[1] and
            bbox2[2] <= bbox1[2] and bbox2[3] <= bbox1[3]):
            return "contains"
            
        # Check relative positions
        if bbox1[3] < bbox2[1]:
            return "above"
        elif bbox1[1] > bbox2[3]:
            return "below"
        elif bbox1[2] < bbox2[0]:
            return "left_of"
        elif bbox1[0] > bbox2[2]:
            return "right_of"
            
        return None
        
    def _calculate_confidence(self, section: Dict, all_boxes: List[Dict]) -> float:
        """Calculate confidence score for a layout section"""
        # Simple confidence based on element count and pattern matching
        element_count = section.get("element_count", 0)
        
        if element_count == 0:
            return 0.0
        elif element_count < 3:
            return 0.6
        elif element_count < 10:
            return 0.8
        else:
            return 0.95
    
    async def _analyze_with_vision(self, screenshot_path: str, bounding_boxes: List[Dict]) -> Dict[str, Any]:
        """Analyze layout using vision capabilities"""
        # Prepare full screenshot for layout analysis
        encoded_images = self.vision_processor.prepare_images_for_analysis(
            screenshot_path=screenshot_path,
            bounding_boxes=bounding_boxes[:20],  # Include top elements for context
            include_full_screenshot=True,
            max_crops=20
        )
        
        prompt = self._create_vision_layout_prompt(bounding_boxes)
        
        # Create message with images
        message_content = self.vision_processor.create_vision_prompt_with_images(
            base_prompt=prompt,
            encoded_images=encoded_images,
            include_bbox_context=True
        )
        
        try:
            # Call Claude Vision API
            response = self.claude_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=4096,
                messages=[{
                    "role": "user",
                    "content": message_content
                }]
            )
            
            # Parse response
            response_text = response.content[0].text
            json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
            if json_match:
                analysis_data = json.loads(json_match.group(1))
            else:
                analysis_data = json.loads(response_text)
            
            return {
                "layout_sections": analysis_data.get("layout_sections", []),
                "spatial_relationships": analysis_data.get("spatial_relationships", []),
                "visual_insights": analysis_data.get("visual_insights", {})
            }
            
        except Exception as e:
            print(f"Vision layout analysis error: {e}")
            # Fall back to coordinate-based analysis
            return {
                "layout_sections": self._identify_layout_sections(bounding_boxes),
                "spatial_relationships": [],
                "visual_insights": {}
            }
    
    def _create_vision_layout_prompt(self, bounding_boxes: List[Dict]) -> str:
        """Create prompt for vision layout analysis"""
        bbox_summary = f"The UI contains {len(bounding_boxes)} detected elements."
        
        return f"""Analyze this UI screenshot to understand the overall layout structure.

{bbox_summary}

Please identify:

1. **Major Layout Sections**:
   - Navigation areas (navbar, sidebar)
   - Content regions (main, article, sections)
   - Functional areas (forms, toolbars, modals)
   - Footer/header regions

2. **Visual Design Analysis**:
   - Color scheme and visual hierarchy
   - Typography patterns
   - Spacing and alignment grid
   - Visual grouping and containers

3. **Layout Patterns**:
   - Grid system or layout framework
   - Responsive design patterns
   - Component organization

Return a JSON response with:
```json
{{
  "layout_sections": [
    {{
      "type": "navbar",
      "bbox": [x1, y1, x2, y2],
      "contains": ["logo", "navigation", "search"],
      "visual_properties": {{
        "background": "dark",
        "position": "fixed-top"
      }},
      "confidence": 0.95
    }}
  ],
  "spatial_relationships": [
    {{
      "parent": "root",
      "child": "navbar",
      "relationship": "top"
    }}
  ],
  "visual_insights": {{
    "design_system": "material/bootstrap/custom",
    "color_scheme": "light/dark",
    "layout_type": "fixed/fluid/responsive"
  }}
}}
```"""