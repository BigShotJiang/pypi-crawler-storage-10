"""
Screenshot capture utilities for InverseUI.
Provides cross-platform screenshot functionality.
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Tuple, Union
import logging

try:
    from PIL import Image, ImageGrab
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import pyautogui
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False


class ScreenshotCapture:
    """Cross-platform screenshot capture utility."""
    
    def __init__(self):
        self.logger = logging.getLogger("ScreenshotCapture")
        self.platform = sys.platform
        
    def capture_screen(
        self,
        save_path: Optional[str] = None,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> str:
        """
        Capture a screenshot of the entire screen or a specific region.
        
        Args:
            save_path: Optional path to save the screenshot. If None, saves to temp file.
            region: Optional tuple (x, y, width, height) to capture specific region
            
        Returns:
            Path to the saved screenshot file
        """
        # Generate save path if not provided
        if save_path is None:
            temp_dir = tempfile.gettempdir()
            save_path = os.path.join(temp_dir, f"inverseui_screenshot_{os.getpid()}.png")
        
        # Ensure directory exists
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Try different capture methods in order of preference
        if self._capture_with_pil(save_path, region):
            return save_path
        elif self._capture_with_pyautogui(save_path, region):
            return save_path
        elif self._capture_with_system(save_path, region):
            return save_path
        else:
            raise RuntimeError("No screenshot capture method available")
    
    def _capture_with_pil(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot using PIL/Pillow."""
        if not PIL_AVAILABLE:
            return False
        
        try:
            if region:
                # Capture specific region
                x, y, width, height = region
                screenshot = ImageGrab.grab(bbox=(x, y, x + width, y + height))
            else:
                # Capture entire screen
                screenshot = ImageGrab.grab()
            
            screenshot.save(save_path)
            self.logger.info(f"Screenshot captured with PIL: {save_path}")
            return True
            
        except Exception as e:
            self.logger.debug(f"PIL capture failed: {e}")
            return False
    
    def _capture_with_pyautogui(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot using pyautogui."""
        if not PYAUTOGUI_AVAILABLE:
            return False
        
        try:
            if region:
                # Capture specific region
                screenshot = pyautogui.screenshot(region=region)
            else:
                # Capture entire screen
                screenshot = pyautogui.screenshot()
            
            screenshot.save(save_path)
            self.logger.info(f"Screenshot captured with pyautogui: {save_path}")
            return True
            
        except Exception as e:
            self.logger.debug(f"Pyautogui capture failed: {e}")
            return False
    
    def _capture_with_system(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot using system-specific commands."""
        try:
            if self.platform == "darwin":  # macOS
                return self._capture_macos(save_path, region)
            elif self.platform == "win32":  # Windows
                return self._capture_windows(save_path, region)
            elif self.platform.startswith("linux"):  # Linux
                return self._capture_linux(save_path, region)
            else:
                return False
                
        except Exception as e:
            self.logger.debug(f"System capture failed: {e}")
            return False
    
    def _capture_macos(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot on macOS using screencapture."""
        try:
            cmd = ["screencapture", "-x"]  # -x disables sound
            
            if region:
                # screencapture uses different format: -R x,y,width,height
                x, y, width, height = region
                cmd.extend(["-R", f"{x},{y},{width},{height}"])
            
            cmd.append(save_path)
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info(f"Screenshot captured with screencapture: {save_path}")
                return True
            else:
                self.logger.debug(f"screencapture failed: {result.stderr}")
                return False
                
        except Exception as e:
            self.logger.debug(f"macOS capture failed: {e}")
            return False
    
    def _capture_windows(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot on Windows."""
        # Windows-specific implementation would go here
        # For now, rely on PIL/pyautogui on Windows
        return False
    
    def _capture_linux(
        self,
        save_path: str,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> bool:
        """Capture screenshot on Linux using gnome-screenshot or scrot."""
        # Try gnome-screenshot first
        try:
            cmd = ["gnome-screenshot", "-f", save_path]
            
            if region:
                # gnome-screenshot doesn't support region directly
                # Would need to capture full screen and crop
                pass
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info(f"Screenshot captured with gnome-screenshot: {save_path}")
                return True
                
        except FileNotFoundError:
            pass
        
        # Try scrot as fallback
        try:
            cmd = ["scrot", save_path]
            
            if region:
                # scrot doesn't support region directly either
                pass
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info(f"Screenshot captured with scrot: {save_path}")
                return True
                
        except FileNotFoundError:
            pass
        
        return False
    
    def capture_element(
        self,
        element_bbox: Tuple[int, int, int, int],
        save_path: Optional[str] = None
    ) -> str:
        """
        Capture a screenshot of a specific UI element.
        
        Args:
            element_bbox: Bounding box of element (x1, y1, x2, y2)
            save_path: Optional save path
            
        Returns:
            Path to the saved element screenshot
        """
        # Convert bbox format to region format
        x1, y1, x2, y2 = element_bbox
        region = (x1, y1, x2 - x1, y2 - y1)
        
        return self.capture_screen(save_path, region)
    
    def capture_and_get_size(
        self,
        save_path: Optional[str] = None
    ) -> Tuple[str, Tuple[int, int]]:
        """
        Capture screenshot and return path with dimensions.
        
        Returns:
            Tuple of (screenshot_path, (width, height))
        """
        screenshot_path = self.capture_screen(save_path)
        
        # Get dimensions
        if PIL_AVAILABLE:
            with Image.open(screenshot_path) as img:
                dimensions = img.size
        else:
            # Fallback: try to get dimensions another way
            dimensions = (0, 0)
        
        return screenshot_path, dimensions


# Convenience functions
def capture_screenshot(
    save_path: Optional[str] = None,
    region: Optional[Tuple[int, int, int, int]] = None
) -> str:
    """
    Capture a screenshot.
    
    Args:
        save_path: Optional path to save screenshot
        region: Optional region to capture (x, y, width, height)
        
    Returns:
        Path to screenshot file
    """
    capture = ScreenshotCapture()
    return capture.capture_screen(save_path, region)


def capture_current_page() -> str:
    """
    Capture the current page/screen and return the screenshot path.
    
    Returns:
        Path to screenshot file
    """
    return capture_screenshot()


def capture_element_screenshot(
    bbox: Union[Tuple[int, int, int, int], list],
    save_path: Optional[str] = None
) -> str:
    """
    Capture a screenshot of a specific element by its bounding box.
    
    Args:
        bbox: Element bounding box (x1, y1, x2, y2)
        save_path: Optional save path
        
    Returns:
        Path to element screenshot
    """
    capture = ScreenshotCapture()
    return capture.capture_element(tuple(bbox), save_path)