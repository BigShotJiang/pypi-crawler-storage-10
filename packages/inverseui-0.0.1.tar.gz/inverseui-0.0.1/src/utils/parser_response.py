"""
Utilities for working with InverseUI Parser API responses.
Handles the specific response format with labeled images and parsed elements.
"""

import base64
import json
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import logging

try:
    from PIL import Image
    import io
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


class ParserResponse:
    """Handle and process InverseUI Parser API responses."""
    
    def __init__(self, response_data: Dict[str, Any]):
        """
        Initialize with API response data.
        
        Args:
            response_data: Response from api.inverseui.com/parser/bbox
        """
        self.raw_response = response_data
        self.success = response_data.get("success", False)
        self.labeled_image_base64 = response_data.get("labeled_image", "")
        self.parsed_elements = response_data.get("parsed", {})
        self.logger = logging.getLogger("ParserResponse")
    
    @property
    def element_count(self) -> int:
        """Get the number of parsed elements."""
        return len(self.parsed_elements)
    
    def get_elements(self) -> List[Dict[str, Any]]:
        """
        Get all parsed elements as a list.
        
        Returns:
            List of elements with standardized structure
        """
        elements = []
        
        for key, element_data in self.parsed_elements.items():
            # Extract icon number
            icon_num = None
            if key.startswith("icon "):
                try:
                    icon_num = int(key.split(" ")[1])
                except:
                    pass
            
            element = {
                "id": key,
                "index": icon_num,
                "type": element_data.get("type", "unknown"),
                "bbox": element_data.get("bbox", []),
                "interactivity": element_data.get("interactivity", False),
                "content": element_data.get("content", "").strip(),
                "source": element_data.get("source", "")
            }
            elements.append(element)
        
        # Sort by index
        elements.sort(key=lambda x: x["index"] if x["index"] is not None else float('inf'))
        return elements
    
    def get_interactive_elements(self) -> List[Dict[str, Any]]:
        """Get only interactive elements."""
        return [elem for elem in self.get_elements() if elem["interactivity"]]
    
    def get_elements_by_type(self, element_type: str) -> List[Dict[str, Any]]:
        """Get elements of a specific type."""
        return [elem for elem in self.get_elements() if elem["type"] == element_type]
    
    def save_labeled_image(self, save_path: str = "labeled_output.png") -> Optional[str]:
        """
        Save the labeled image to a file.
        
        Args:
            save_path: Path to save the image
            
        Returns:
            Path to saved file or None if failed
        """
        if not self.labeled_image_base64:
            self.logger.warning("No labeled image in response")
            return None
        
        try:
            # Decode base64
            image_bytes = base64.b64decode(self.labeled_image_base64)
            
            # Save to file
            with open(save_path, "wb") as f:
                f.write(image_bytes)
            
            self.logger.info(f"Saved labeled image: {save_path}")
            return save_path
            
        except Exception as e:
            self.logger.error(f"Failed to save labeled image: {e}")
            return None
    
    def get_labeled_image_pil(self) -> Optional['Image.Image']:
        """
        Get labeled image as PIL Image object.
        
        Returns:
            PIL Image or None if not available
        """
        if not PIL_AVAILABLE or not self.labeled_image_base64:
            return None
        
        try:
            image_bytes = base64.b64decode(self.labeled_image_base64)
            return Image.open(io.BytesIO(image_bytes))
        except Exception as e:
            self.logger.error(f"Failed to decode image: {e}")
            return None
    
    def convert_bbox_to_pixels(self, bbox: List[float], image_size: Tuple[int, int]) -> List[int]:
        """
        Convert normalized bbox to pixel coordinates.
        
        Args:
            bbox: Normalized bbox [x1, y1, x2, y2]
            image_size: (width, height) in pixels
            
        Returns:
            Pixel coordinates [x1, y1, x2, y2]
        """
        if len(bbox) != 4:
            return bbox
        
        width, height = image_size
        x1, y1, x2, y2 = bbox
        
        return [
            int(x1 * width),
            int(y1 * height),
            int(x2 * width),
            int(y2 * height)
        ]
    
    def get_element_at_position(self, x: float, y: float, normalized: bool = True) -> Optional[Dict[str, Any]]:
        """
        Find element at given position.
        
        Args:
            x, y: Coordinates (normalized 0-1 or pixels)
            normalized: Whether coordinates are normalized
            
        Returns:
            Element dict or None
        """
        for element in self.get_elements():
            bbox = element["bbox"]
            if len(bbox) == 4:
                x1, y1, x2, y2 = bbox
                
                # Check if point is inside bbox
                if x1 <= x <= x2 and y1 <= y <= y2:
                    return element
        
        return None
    
    def to_inverseui_format(self) -> List[Dict[str, Any]]:
        """
        Convert parsed elements to InverseUI bounding box format.
        
        Returns:
            List of bounding boxes for InverseUI analysis
        """
        bounding_boxes = []
        
        for element in self.get_elements():
            # Convert to InverseUI format
            bbox_data = {
                "bbox": element["bbox"],
                "text": element["content"],
                "type": element["type"],
                "properties": {
                    "interactive": element["interactivity"],
                    "source": element["source"],
                    "parser_id": element["id"]
                }
            }
            bounding_boxes.append(bbox_data)
        
        return bounding_boxes
    
    def summary(self) -> Dict[str, Any]:
        """
        Get a summary of the parsed response.
        
        Returns:
            Summary statistics
        """
        elements = self.get_elements()
        
        # Count by type
        type_counts = {}
        for elem in elements:
            elem_type = elem["type"]
            type_counts[elem_type] = type_counts.get(elem_type, 0) + 1
        
        # Count interactive
        interactive_count = sum(1 for elem in elements if elem["interactivity"])
        
        return {
            "total_elements": len(elements),
            "interactive_elements": interactive_count,
            "non_interactive_elements": len(elements) - interactive_count,
            "elements_by_type": type_counts,
            "has_labeled_image": bool(self.labeled_image_base64)
        }
    
    def print_summary(self):
        """Print a formatted summary of the response."""
        summary = self.summary()
        
        print("=== Parser Response Summary ===")
        print(f"Total elements: {summary['total_elements']}")
        print(f"Interactive: {summary['interactive_elements']}")
        print(f"Non-interactive: {summary['non_interactive_elements']}")
        
        if summary['elements_by_type']:
            print("\nElements by type:")
            for elem_type, count in summary['elements_by_type'].items():
                print(f"  - {elem_type}: {count}")
        
        print(f"\nLabeled image: {'Yes' if summary['has_labeled_image'] else 'No'}")
        
        # Show sample elements
        elements = self.get_elements()
        if elements:
            print("\nSample elements:")
            for elem in elements[:3]:
                print(f"  {elem['id']}: {elem['type']} - \"{elem['content']}\"")
            if len(elements) > 3:
                print(f"  ... and {len(elements) - 3} more")


def process_parser_response(api_response: Dict[str, Any]) -> ParserResponse:
    """
    Process an API response into a ParserResponse object.
    
    Args:
        api_response: Response from InverseUI parser API
        
    Returns:
        ParserResponse object
    """
    return ParserResponse(api_response)


def load_parser_response_from_file(file_path: str) -> ParserResponse:
    """
    Load a parser response from a JSON file.
    
    Args:
        file_path: Path to JSON file containing API response
        
    Returns:
        ParserResponse object
    """
    with open(file_path, 'r') as f:
        data = json.load(f)
    return ParserResponse(data)


# Example usage functions
def analyze_response(response_data: Dict[str, Any]) -> None:
    """
    Analyze and display parser response.
    
    Args:
        response_data: API response data
    """
    parser_resp = ParserResponse(response_data)
    
    # Print summary
    parser_resp.print_summary()
    
    # Save labeled image if available
    if parser_resp.labeled_image_base64:
        saved_path = parser_resp.save_labeled_image("parsed_ui_labeled.png")
        if saved_path:
            print(f"\nLabeled image saved to: {saved_path}")
    
    # Get interactive elements
    interactive = parser_resp.get_interactive_elements()
    if interactive:
        print(f"\nFound {len(interactive)} interactive elements:")
        for elem in interactive:
            print(f"  - {elem['content']} ({elem['type']})")


def convert_for_inverseui(response_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Convert parser response to InverseUI format.
    
    Args:
        response_data: API response data
        
    Returns:
        Bounding boxes for InverseUI
    """
    parser_resp = ParserResponse(response_data)
    return parser_resp.to_inverseui_format()