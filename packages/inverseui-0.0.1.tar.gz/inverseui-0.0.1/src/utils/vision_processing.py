"""
Vision processing utilities for UI analysis using Claude Vision API.
Handles image encoding, bbox cropping, and vision model interactions.
"""

import base64
import io
from typing import List, Dict, Any, Tuple, Optional
from PIL import Image
import numpy as np


class VisionProcessor:
    """Handles image processing and vision model interactions for UI analysis."""
    
    def __init__(self):
        """Initialize the vision processor."""
        pass
    
    @staticmethod
    def encode_image_to_base64(image_path: str) -> str:
        """
        Encode an image file to base64 string for API consumption.
        
        Args:
            image_path: Path to the image file
            
        Returns:
            Base64 encoded string of the image
        """
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    
    @staticmethod
    def crop_bbox_from_image(image_path: str, bbox: List[int]) -> Image.Image:
        """
        Crop a bounding box region from an image.
        
        Args:
            image_path: Path to the source image
            bbox: Bounding box coordinates [x1, y1, x2, y2]
            
        Returns:
            PIL Image object of the cropped region
        """
        image = Image.open(image_path)
        x1, y1, x2, y2 = bbox
        
        # Ensure coordinates are within image bounds
        img_width, img_height = image.size
        x1 = max(0, min(x1, img_width))
        y1 = max(0, min(y1, img_height))
        x2 = max(0, min(x2, img_width))
        y2 = max(0, min(y2, img_height))
        
        # Crop the image
        cropped = image.crop((x1, y1, x2, y2))
        return cropped
    
    @staticmethod
    def crop_and_encode_bbox(image_path: str, bbox: List[int]) -> str:
        """
        Crop a bounding box from an image and encode it to base64.
        
        Args:
            image_path: Path to the source image
            bbox: Bounding box coordinates [x1, y1, x2, y2]
            
        Returns:
            Base64 encoded string of the cropped region
        """
        cropped_image = VisionProcessor.crop_bbox_from_image(image_path, bbox)
        
        # Convert to base64
        buffer = io.BytesIO()
        cropped_image.save(buffer, format="PNG")
        buffer.seek(0)
        return base64.b64encode(buffer.read()).decode('utf-8')
    
    @staticmethod
    def prepare_images_for_analysis(
        screenshot_path: str,
        bounding_boxes: List[Dict[str, Any]],
        include_full_screenshot: bool = True,
        max_crops: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Prepare images for vision model analysis.
        
        Args:
            screenshot_path: Path to the full screenshot
            bounding_boxes: List of bounding box dictionaries
            include_full_screenshot: Whether to include the full screenshot
            max_crops: Maximum number of bbox crops to include (None for all)
            
        Returns:
            Dictionary containing encoded images and metadata
        """
        result = {
            "full_screenshot": None,
            "bbox_crops": [],
            "metadata": {
                "total_bboxes": len(bounding_boxes),
                "crops_included": 0
            }
        }
        
        # Encode full screenshot if requested
        if include_full_screenshot:
            result["full_screenshot"] = VisionProcessor.encode_image_to_base64(screenshot_path)
        
        # Process bounding box crops
        bboxes_to_process = bounding_boxes[:max_crops] if max_crops else bounding_boxes
        
        for i, bbox_data in enumerate(bboxes_to_process):
            try:
                bbox = bbox_data.get("bbox", [])
                if len(bbox) == 4:
                    encoded_crop = VisionProcessor.crop_and_encode_bbox(screenshot_path, bbox)
                    result["bbox_crops"].append({
                        "index": i,
                        "bbox": bbox,
                        "text": bbox_data.get("text", ""),
                        "encoded_image": encoded_crop
                    })
                    result["metadata"]["crops_included"] += 1
            except Exception as e:
                print(f"Error processing bbox {i}: {e}")
                continue
        
        return result
    
    @staticmethod
    def create_vision_prompt_with_images(
        base_prompt: str,
        encoded_images: Dict[str, Any],
        include_bbox_context: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Create a structured prompt for vision models with images.
        
        Args:
            base_prompt: The base text prompt
            encoded_images: Dictionary containing encoded images from prepare_images_for_analysis
            include_bbox_context: Whether to include bbox context in prompts
            
        Returns:
            List of message dictionaries for the vision model
        """
        messages = []
        
        # Add the full screenshot if available
        if encoded_images.get("full_screenshot"):
            messages.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": encoded_images["full_screenshot"]
                }
            })
            messages.append({
                "type": "text",
                "text": "Above is the full UI screenshot."
            })
        
        # Add bbox crops if available
        if encoded_images.get("bbox_crops"):
            for crop_data in encoded_images["bbox_crops"]:
                messages.append({
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": "image/png",
                        "data": crop_data["encoded_image"]
                    }
                })
                
                if include_bbox_context:
                    context_text = f"Above is element at bbox {crop_data['bbox']}"
                    if crop_data.get("text"):
                        context_text += f" with text: '{crop_data['text']}'"
                    messages.append({
                        "type": "text",
                        "text": context_text
                    })
        
        # Add the main prompt
        messages.append({
            "type": "text",
            "text": base_prompt
        })
        
        return messages
    
    @staticmethod
    def merge_visual_analysis_with_bbox_data(
        bounding_boxes: List[Dict[str, Any]],
        visual_analysis: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Merge visual analysis results with existing bounding box data.
        
        Args:
            bounding_boxes: Original bounding box data
            visual_analysis: Results from vision model analysis
            
        Returns:
            Enhanced bounding box data with visual insights
        """
        enhanced_bboxes = []
        
        for i, bbox_data in enumerate(bounding_boxes):
            enhanced = bbox_data.copy()
            
            # Add visual analysis if available for this bbox
            if visual_analysis and f"element_{i}" in visual_analysis:
                element_analysis = visual_analysis[f"element_{i}"]
                enhanced["visual_analysis"] = {
                    "element_type": element_analysis.get("type", "unknown"),
                    "visual_properties": element_analysis.get("properties", {}),
                    "styling": element_analysis.get("styling", {}),
                    "confidence": element_analysis.get("confidence", 0.0)
                }
            
            enhanced_bboxes.append(enhanced)
        
        return enhanced_bboxes