from dataclasses import dataclass, field
import time
from typing import Dict, Any, List, Optional
import json


@dataclass
class AnalysisMetrics:
    start_time: float = field(default_factory=time.time)
    end_time: Optional[float] = None
    events_processed: int = 0
    errors_encountered: int = 0
    agent_metrics: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    def start_agent_timing(self, agent_name: str):
        if agent_name not in self.agent_metrics:
            self.agent_metrics[agent_name] = {
                "start_time": time.time(),
                "invocations": 0,
                "errors": 0
            }
        self.agent_metrics[agent_name]["start_time"] = time.time()
        
    def end_agent_timing(self, agent_name: str, success: bool = True):
        if agent_name in self.agent_metrics:
            metrics = self.agent_metrics[agent_name]
            duration = time.time() - metrics["start_time"]
            
            if "durations" not in metrics:
                metrics["durations"] = []
            metrics["durations"].append(duration)
            metrics["invocations"] += 1
            
            if not success:
                metrics["errors"] += 1
                
    def increment_events(self):
        self.events_processed += 1
        
    def increment_errors(self):
        self.errors_encountered += 1
        
    def finish(self):
        self.end_time = time.time()
        
    def duration(self) -> float:
        if self.end_time:
            return self.end_time - self.start_time
        return time.time() - self.start_time
        
    def get_agent_stats(self, agent_name: str) -> Dict[str, Any]:
        if agent_name not in self.agent_metrics:
            return {}
            
        metrics = self.agent_metrics[agent_name]
        durations = metrics.get("durations", [])
        
        if not durations:
            return metrics
            
        return {
            "invocations": metrics["invocations"],
            "errors": metrics["errors"],
            "success_rate": (metrics["invocations"] - metrics["errors"]) / max(1, metrics["invocations"]),
            "avg_duration": sum(durations) / len(durations),
            "min_duration": min(durations),
            "max_duration": max(durations),
            "total_duration": sum(durations)
        }
        
    def to_dict(self) -> Dict[str, Any]:
        agent_stats = {
            agent: self.get_agent_stats(agent)
            for agent in self.agent_metrics
        }
        
        return {
            "duration": self.duration(),
            "events_processed": self.events_processed,
            "errors_encountered": self.errors_encountered,
            "success_rate": (self.events_processed - self.errors_encountered) / max(1, self.events_processed),
            "agent_stats": agent_stats
        }
        
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)
        
    def print_summary(self):
        print(f"\n{'='*50}")
        print("Analysis Metrics Summary")
        print(f"{'='*50}")
        print(f"Total Duration: {self.duration():.2f}s")
        print(f"Events Processed: {self.events_processed}")
        print(f"Errors Encountered: {self.errors_encountered}")
        print(f"Success Rate: {(self.events_processed - self.errors_encountered) / max(1, self.events_processed):.2%}")
        
        print(f"\n{'Agent Performance':^50}")
        print(f"{'-'*50}")
        
        agent_stats = {
            agent: self.get_agent_stats(agent)
            for agent in self.agent_metrics
        }
        
        for agent, stats in agent_stats.items():
            if stats:
                print(f"\n{agent}:")
                print(f"  Invocations: {stats['invocations']}")
                print(f"  Success Rate: {stats['success_rate']:.2%}")
                print(f"  Avg Duration: {stats['avg_duration']:.2f}s")
                
        print(f"{'='*50}\n")