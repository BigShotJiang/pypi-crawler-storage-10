"""
API client for InverseUI parser service.
Handles sending bounding box data and labeled pages to the parser API.
"""

import aiohttp
import asyncio
import json
from typing import Dict, Any, List, Optional, Union, Tuple
from pathlib import Path
import base64
import logging
from .screenshot import capture_screenshot, capture_current_page
from .pyautogui_executor import PyAutoGUIExecutor, execute_backend_pyautogui


class InverseUIAPIClient:
    """API client for InverseUI parser service."""
    
    def __init__(self):
        """
        Initialize the InverseUI API client.
        """
        self.base_url = "https://api.inverseui.com"
        self.endpoint = "parser/bbox"
        self.default_headers = {"Content-Type": "application/json"}
        self.logger = logging.getLogger("InverseUIAPIClient")
        
    def get_endpoint_url(self) -> str:
        """
        Get full URL for the parser endpoint.
        
        Returns:
            Full endpoint URL
        """
        return f"{self.base_url}/{self.endpoint}"
    
    async def send_request(
        self,
        data: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Send POST request to InverseUI parser API.
        
        Args:
            data: Request data/payload
            headers: Additional headers
            
        Returns:
            API response as dictionary
        """
        # TEMPORARY: Return mock data instead of calling API
        self.logger.info("Using mock data instead of API call")
        
        # Mock response with sample bounding boxes
        mock_response = {
            "success": True,
            "status_code": 200,
            "data": {
                "parsed": {
                    "icon 1": {
                        "type": "button",
                        "bbox": [0.1, 0.1, 0.3, 0.15],
                        "interactivity": True,
                        "content": "Submit",
                        "source": "mock"
                    },
                    "icon 2": {
                        "type": "input",
                        "bbox": [0.1, 0.2, 0.5, 0.25],
                        "interactivity": True,
                        "content": "Email",
                        "source": "mock"
                    },
                    "icon 3": {
                        "type": "text",
                        "bbox": [0.1, 0.3, 0.4, 0.35],
                        "interactivity": False,
                        "content": "Welcome to our application",
                        "source": "mock"
                    },
                    "icon 4": {
                        "type": "link",
                        "bbox": [0.6, 0.1, 0.8, 0.15],
                        "interactivity": True,
                        "content": "Learn More",
                        "source": "mock"
                    },
                    "icon 5": {
                        "type": "button",
                        "bbox": [0.4, 0.5, 0.6, 0.55],
                        "interactivity": True,
                        "content": "Cancel",
                        "source": "mock"
                    }
                },
                "labeled_image": "",  # Empty base64 string for now
                "pyautogui_code": """import pyautogui
# Example automation code from backend
pyautogui.moveTo(200, 200, duration=0.5)
pyautogui.click()
pyautogui.typewrite("Hello from InverseUI!")
"""
            },
            "headers": {}
        }
        
        # Add a small delay to simulate network request
        await asyncio.sleep(0.5)
        
        return mock_response
        
        # ORIGINAL CODE (commented out for now):
        # url = self.get_endpoint_url()
        # 
        # # Merge headers
        # request_headers = self.default_headers.copy()
        # if headers:
        #     request_headers.update(headers)
        # 
        # async with aiohttp.ClientSession() as session:
        #     try:
        #         async with session.post(
        #             url=url,
        #             json=data,
        #             headers=request_headers
        #         ) as response:
        #             response_data = await response.json()
        #             
        #             return {
        #                 "success": response.status < 400,
        #                 "status_code": response.status,
        #                 "data": response_data,
        #                 "headers": dict(response.headers)
        #             }
        #             
        #     except aiohttp.ClientError as e:
        #         self.logger.error(f"Network error: {str(e)}")
        #         return {
        #             "success": False,
        #             "error": f"Network error: {str(e)}",
        #             "status_code": None
        #         }
        #     except Exception as e:
        #         self.logger.error(f"Unexpected error: {str(e)}")
        #         return {
        #             "success": False,
        #             "error": f"Unexpected error: {str(e)}",
        #             "status_code": None
        #         }
    
    async def send_bbox_data(
        self,
        bounding_boxes: List[Dict[str, Any]],
        screenshot_path: Optional[str] = None,
        page_url: Optional[str] = None,
        page_title: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        capture_screenshot_if_missing: bool = True
    ) -> Dict[str, Any]:
        """
        Send bounding box data to the API.
        
        Args:
            bounding_boxes: List of bounding box dictionaries
            screenshot_path: Optional path to screenshot file
            page_url: Optional URL of the page
            page_title: Optional title of the page
            metadata: Optional additional metadata
            capture_screenshot_if_missing: Capture screen if no screenshot
            
        Returns:
            API response as dictionary
        """
        # Prepare request payload
        payload = {
            "bounding_boxes": bounding_boxes,
            "page_info": {
                "url": page_url,
                "title": page_title
            }
        }
        
        # Handle screenshot
        if screenshot_path and Path(screenshot_path).exists():
            # Use provided screenshot
            screenshot_base64 = self._encode_image(screenshot_path)
            payload["screenshot"] = {
                "data": screenshot_base64,
                "filename": Path(screenshot_path).name
            }
        elif capture_screenshot_if_missing:
            # Capture current screen if no screenshot provided
            try:
                self.logger.info("No screenshot provided, capturing current screen...")
                captured_path = capture_current_page()
                screenshot_base64 = self._encode_image(captured_path)
                payload["screenshot"] = {
                    "data": screenshot_base64,
                    "filename": "captured_screen.png"
                }
                payload["metadata"] = payload.get("metadata", {})
                payload["metadata"]["screenshot_captured"] = True
            except Exception as e:
                self.logger.warning(f"Failed to capture screenshot: {e}")
        
        # Add metadata if provided
        if metadata:
            payload["metadata"] = metadata
        
        # Send request
        response = await self.send_request(data=payload)
        
        # Process response for parser format
        if response.get("success") and response.get("data"):
            data = response["data"]
            # Add parsed fields to top level for convenience
            if "labeled_image" in data:
                response["labeled_image"] = data["labeled_image"]
            if "parsed" in data:
                response["parsed"] = data["parsed"]
            
            # Check for PyAutoGUI code and optionally execute
            if "pyautogui_code" in data:
                self.logger.info("Found PyAutoGUI code in response")
                # Store the code in response for reference
                response["pyautogui_code"] = data["pyautogui_code"]
        
        return response
    
    async def send_labeled_page(
        self,
        screenshot_path: str,
        bounding_boxes: List[Dict[str, Any]],
        labels: Dict[str, Any],
        page_url: Optional[str] = None,
        page_type: Optional[str] = None,
        ui_analysis: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Send a labeled page with bounding boxes and analysis results.
        
        Args:
            screenshot_path: Path to screenshot file
            bounding_boxes: List of bounding box dictionaries
            labels: Dictionary of labels for the page/elements
            page_url: Optional URL of the page
            page_type: Optional type of page (e.g., "login", "dashboard")
            ui_analysis: Optional UI analysis results from InverseUI
            
        Returns:
            API response as dictionary
        """
        # Handle screenshot
        if screenshot_path and Path(screenshot_path).exists():
            screenshot_data = self._encode_image(screenshot_path)
            screenshot_filename = Path(screenshot_path).name
        else:
            # Capture current screen
            try:
                self.logger.info("Capturing current screen for labeled page...")
                captured_path = capture_current_page()
                screenshot_data = self._encode_image(captured_path)
                screenshot_filename = "captured_screen.png"
            except Exception as e:
                return {
                    "success": False,
                    "error": f"Failed to capture screenshot: {str(e)}",
                    "status_code": None
                }
        
        # Prepare labeled data
        labeled_data = {
            "screenshot": {
                "data": screenshot_data,
                "filename": screenshot_filename
            },
            "bounding_boxes": bounding_boxes,
            "labels": labels,
            "page_info": {
                "url": page_url,
                "type": page_type
            }
        }
        
        # Add UI analysis if provided
        if ui_analysis:
            labeled_data["ui_analysis"] = ui_analysis
        
        # Send to API
        return await self.send_bbox_data(
            bounding_boxes=bounding_boxes,
            screenshot_path=screenshot_path,
            page_url=page_url,
            metadata={
                "labels": labels,
                "page_type": page_type,
                "ui_analysis": ui_analysis
            }
        )
    
    def _encode_image(self, image_path: str) -> str:
        """Encode image file to base64 string."""
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    
    def save_labeled_image(self, response: Dict[str, Any], save_path: str = "labeled_image.png") -> Optional[str]:
        """
        Save the labeled image from API response to a file.
        
        Args:
            response: API response containing labeled_image
            save_path: Path to save the labeled image
            
        Returns:
            Path to saved file or None if no labeled image
        """
        labeled_image_base64 = response.get("labeled_image")
        if not labeled_image_base64:
            return None
        
        try:
            # Decode base64 to bytes
            image_bytes = base64.b64decode(labeled_image_base64)
            
            # Save to file
            with open(save_path, "wb") as f:
                f.write(image_bytes)
            
            self.logger.info(f"Saved labeled image to: {save_path}")
            return save_path
            
        except Exception as e:
            self.logger.error(f"Failed to save labeled image: {e}")
            return None
    
    @staticmethod
    def parse_response_elements(response: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Parse the API response to extract elements in a standardized format.
        
        Args:
            response: API response with 'parsed' field
            
        Returns:
            List of parsed elements with normalized structure
        """
        parsed_data = response.get("parsed", {})
        elements = []
        
        for key, element_data in parsed_data.items():
            # Extract icon number if present
            icon_num = None
            if key.startswith("icon "):
                try:
                    icon_num = int(key.split(" ")[1])
                except:
                    pass
            
            element = {
                "id": key,
                "icon_number": icon_num,
                "type": element_data.get("type", "unknown"),
                "bbox": element_data.get("bbox", []),
                "bbox_normalized": element_data.get("bbox", []),  # Already normalized
                "interactivity": element_data.get("interactivity", False),
                "content": element_data.get("content", ""),
                "source": element_data.get("source", "")
            }
            elements.append(element)
        
        # Sort by icon number if available
        elements.sort(key=lambda x: x["icon_number"] if x["icon_number"] is not None else float('inf'))
        
        return elements
    
    @staticmethod
    def convert_normalized_bbox(bbox: List[float], image_width: int, image_height: int) -> List[int]:
        """
        Convert normalized bbox coordinates to pixel coordinates.
        
        Args:
            bbox: Normalized bbox [x1, y1, x2, y2] with values 0-1
            image_width: Width of the image in pixels
            image_height: Height of the image in pixels
            
        Returns:
            Pixel coordinates [x1, y1, x2, y2]
        """
        if len(bbox) != 4:
            return bbox
        
        x1, y1, x2, y2 = bbox
        return [
            int(x1 * image_width),
            int(y1 * image_height),
            int(x2 * image_width),
            int(y2 * image_height)
        ]
    
    async def send_batch(
        self,
        pages: List[Dict[str, Any]],
        batch_size: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Send multiple pages in batches.
        
        Args:
            pages: List of page data dictionaries
            batch_size: Number of pages to send concurrently
            
        Returns:
            List of API responses
        """
        results = []
        
        for i in range(0, len(pages), batch_size):
            batch = pages[i:i + batch_size]
            
            # Send batch concurrently
            tasks = []
            for page_data in batch:
                task = self.send_bbox_data(**page_data)
                tasks.append(task)
            
            batch_results = await asyncio.gather(*tasks)
            results.extend(batch_results)
            
            # Brief delay between batches to avoid rate limiting
            if i + batch_size < len(pages):
                await asyncio.sleep(0.5)
        
        return results
    
    async def execute_backend_automation(self, response: Dict[str, Any], execute_immediately: bool = True) -> Dict[str, Any]:
        """
        Execute PyAutoGUI automation code from backend response.
        
        Args:
            response: API response containing PyAutoGUI code
            execute_immediately: Whether to execute the code immediately
            
        Returns:
            Execution result dictionary
        """
        # Initialize executor
        executor = PyAutoGUIExecutor(
            max_execution_time=30.0,
            enable_screenshots=True,
            enable_prompts=False
        )
        
        # Extract PyAutoGUI code from response
        code = executor.parse_backend_response(response)
        
        if not code:
            # Check if it's in the data field
            if response.get("data"):
                code = executor.parse_backend_response(response["data"])
        
        if not code:
            return {
                "success": False,
                "error": "No PyAutoGUI code found in response"
            }
        
        self.logger.info(f"Found PyAutoGUI code in response: {len(code)} characters")
        
        if execute_immediately:
            # Execute the code
            result = executor.execute_code(code)
            self.logger.info(f"Execution result: {result.get('success', False)}")
            return result
        else:
            # Just validate and return the code
            is_valid, error_msg = executor.validate_code(code)
            return {
                "success": is_valid,
                "code": code if is_valid else None,
                "error": error_msg,
                "executed": False
            }


class InverseUIParser:
    """
    High-level parser that combines InverseUI analysis with API submission.
    """
    
    def __init__(self, api_client: Optional[InverseUIAPIClient] = None):
        """
        Initialize the parser.
        
        Args:
            api_client: Optional API client instance
        """
        self.api_client = api_client or InverseUIAPIClient()
        self.logger = logging.getLogger("InverseUIParser")
    
    async def parse_and_send(
        self,
        screenshot_path: str,
        bounding_boxes: List[Dict[str, Any]],
        use_vision: bool = True,
        send_to_api: bool = True,
        page_url: Optional[str] = None,
        page_type: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Parse UI with InverseUI and optionally send to API.
        
        Args:
            screenshot_path: Path to screenshot
            bounding_boxes: List of bounding boxes
            use_vision: Whether to use vision analysis
            send_to_api: Whether to send results to API
            page_url: Optional page URL
            page_type: Optional page type
            
        Returns:
            Combined results from analysis and API
        """
        from ..core.inverter import UIInverter
        
        # Analyze with InverseUI
        inverter = UIInverter(use_vision=use_vision)
        ui_analysis = await inverter.analyze_ui(screenshot_path, bounding_boxes)
        
        result = {
            "ui_analysis": ui_analysis,
            "api_response": None
        }
        
        # Send to API if requested
        if send_to_api:
            # Extract key information from analysis
            labels = self._extract_labels_from_analysis(ui_analysis)
            
            api_response = await self.api_client.send_labeled_page(
                screenshot_path=screenshot_path,
                bounding_boxes=bounding_boxes,
                labels=labels,
                page_url=page_url,
                page_type=page_type,
                ui_analysis=ui_analysis
            )
            
            result["api_response"] = api_response
        
        return result
    
    def _extract_labels_from_analysis(self, ui_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Extract meaningful labels from UI analysis results."""
        labels = {
            "layout_sections": [],
            "interactive_elements": [],
            "element_types": {}
        }
        
        # Extract layout sections
        if ui_analysis.get("layout_analysis"):
            sections = ui_analysis["layout_analysis"].get("layout_sections", [])
            labels["layout_sections"] = [
                {
                    "type": section.get("type"),
                    "bbox": section.get("bbox"),
                    "confidence": section.get("confidence")
                }
                for section in sections
            ]
        
        # Extract element information
        if ui_analysis.get("element_analysis"):
            elements = ui_analysis["element_analysis"].get("elements", [])
            
            for element in elements:
                elem_type = element.get("type", "unknown")
                
                # Count element types
                if elem_type not in labels["element_types"]:
                    labels["element_types"][elem_type] = 0
                labels["element_types"][elem_type] += 1
                
                # Track interactive elements
                if element.get("properties", {}).get("interactive"):
                    labels["interactive_elements"].append({
                        "type": elem_type,
                        "action": element.get("action"),
                        "text": element.get("text"),
                        "bbox": element.get("bbox")
                    })
        
        # Add metadata
        labels["metadata"] = {
            "total_elements": len(ui_analysis.get("element_analysis", {}).get("elements", [])),
            "vision_enhanced": ui_analysis.get("element_analysis", {}).get("vision_enhanced", False),
            "confidence_average": ui_analysis.get("analysis_metadata", {}).get("confidence_average", 0)
        }
        
        return labels


# Convenience functions
async def send_to_parser_api(
    screenshot_path: Optional[str] = None,
    bounding_boxes: List[Dict[str, Any]] = None,
    capture_screen: bool = True,
    **kwargs
) -> Dict[str, Any]:
    """
    Convenience function to send data to InverseUI parser API.
    
    Args:
        screenshot_path: Path to screenshot (optional, will capture if not provided)
        bounding_boxes: List of bounding boxes (optional)
        capture_screen: Whether to capture screen if no screenshot provided
        **kwargs: Additional arguments for API client
        
    Returns:
        API response
    """
    client = InverseUIAPIClient()
    
    # If no bounding boxes provided, use empty list
    if bounding_boxes is None:
        bounding_boxes = []
    
    return await client.send_bbox_data(
        bounding_boxes=bounding_boxes,
        screenshot_path=screenshot_path,
        capture_screenshot_if_missing=capture_screen,
        **kwargs
    )


async def capture_and_send_current_page(
    page_url: Optional[str] = None,
    page_title: Optional[str] = None,
    detect_elements: bool = False,
    **kwargs
) -> Dict[str, Any]:
    """
    Capture current screen and send to parser API.
    
    Args:
        page_url: Optional URL of the current page
        page_title: Optional title of the page
        detect_elements: Whether to detect elements (requires additional setup)
        **kwargs: Additional arguments
        
    Returns:
        API response
    """
    # Capture current screen
    screenshot_path = capture_current_page()
    
    # TODO: If detect_elements is True, would need element detection
    # For now, send with empty bounding boxes
    bounding_boxes = []
    
    return await send_to_parser_api(
        screenshot_path=screenshot_path,
        bounding_boxes=bounding_boxes,
        page_url=page_url,
        page_title=page_title,
        capture_screen=False,  # Already captured
        **kwargs
    )


async def parse_and_send_to_api(
    screenshot_path: str,
    bounding_boxes: List[Dict[str, Any]],
    use_vision: bool = True,
    **kwargs
) -> Dict[str, Any]:
    """
    Parse with InverseUI and send to API.
    
    Args:
        screenshot_path: Path to screenshot
        bounding_boxes: List of bounding boxes
        use_vision: Whether to use vision analysis
        **kwargs: Additional arguments
        
    Returns:
        Combined results
    """
    parser = InverseUIParser()
    return await parser.parse_and_send(
        screenshot_path=screenshot_path,
        bounding_boxes=bounding_boxes,
        use_vision=use_vision,
        send_to_api=True,
        **kwargs
    )