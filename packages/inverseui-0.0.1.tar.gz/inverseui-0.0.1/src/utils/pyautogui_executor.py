"""
PyAutoGUI code executor for running backend-returned automation scripts.
Handles safe execution of PyAutoGUI commands with proper error handling and validation.
"""

import ast
import sys
import json
import logging
import traceback
from typing import Dict, Any, List, Optional, Union
from io import StringIO
import contextlib
import pyautogui

# Configure PyAutoGUI safety features
pyautogui.FAILSAFE = True  # Move mouse to corner to abort
pyautogui.PAUSE = 0.5  # Pause between commands


class PyAutoGUIExecutor:
    """Safely execute PyAutoGUI code returned from backend."""
    
    # Allowed PyAutoGUI functions for security
    ALLOWED_FUNCTIONS = {
        'moveTo', 'move', 'dragTo', 'drag', 'click', 'doubleClick', 
        'rightClick', 'middleClick', 'scroll', 'hscroll', 'vscroll',
        'typewrite', 'write', 'press', 'keyDown', 'keyUp', 'hotkey',
        'screenshot', 'locateOnScreen', 'locateCenterOnScreen',
        'position', 'size', 'onScreen', 'pixelMatchesColor',
        'sleep', 'PAUSE', 'FAILSAFE', 'getWindowsWithTitle',
        'getActiveWindow', 'confirm', 'alert', 'prompt'
    }
    
    # Restricted modules - only allow pyautogui
    ALLOWED_MODULES = {'pyautogui', 'time'}
    
    def __init__(self, 
                 max_execution_time: float = 30.0,
                 enable_screenshots: bool = True,
                 enable_prompts: bool = False):
        """
        Initialize PyAutoGUI executor.
        
        Args:
            max_execution_time: Maximum execution time in seconds
            enable_screenshots: Allow screenshot functions
            enable_prompts: Allow UI prompts (alert, confirm, prompt)
        """
        self.max_execution_time = max_execution_time
        self.enable_screenshots = enable_screenshots
        self.enable_prompts = enable_prompts
        self.logger = logging.getLogger("PyAutoGUIExecutor")
        
        # Configure safety
        pyautogui.FAILSAFE = True
        
    def validate_code(self, code: str) -> tuple[bool, Optional[str]]:
        """
        Validate PyAutoGUI code for safety.
        
        Args:
            code: Python code string to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            # Parse the code into AST
            tree = ast.parse(code)
            
            # Check for dangerous operations
            for node in ast.walk(tree):
                # Check imports
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name not in self.ALLOWED_MODULES:
                            return False, f"Import of '{alias.name}' not allowed"
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module not in self.ALLOWED_MODULES:
                        return False, f"Import from '{node.module}' not allowed"
                
                # Check function calls
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Attribute):
                        # Check for pyautogui.function calls
                        if isinstance(node.func.value, ast.Name) and node.func.value.id == 'pyautogui':
                            if node.func.attr not in self.ALLOWED_FUNCTIONS:
                                return False, f"Function 'pyautogui.{node.func.attr}' not allowed"
                            
                            # Additional checks for specific functions
                            if not self.enable_screenshots and node.func.attr in ['screenshot', 'locateOnScreen', 'locateCenterOnScreen']:
                                return False, "Screenshot functions are disabled"
                            
                            if not self.enable_prompts and node.func.attr in ['alert', 'confirm', 'prompt']:
                                return False, "UI prompt functions are disabled"
                
                # Prevent exec, eval, compile
                elif isinstance(node, ast.Name) and node.id in ['exec', 'eval', 'compile', '__import__']:
                    return False, f"Use of '{node.id}' not allowed"
                
                # Prevent file operations
                elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in ['open', 'file']:
                    return False, "File operations not allowed"
            
            return True, None
            
        except SyntaxError as e:
            return False, f"Syntax error: {str(e)}"
        except Exception as e:
            return False, f"Validation error: {str(e)}"
    
    def execute_code(self, code: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Execute PyAutoGUI code safely.
        
        Args:
            code: Python code string to execute
            context: Optional context variables to inject
            
        Returns:
            Execution result dictionary
        """
        # Validate code first
        is_valid, error_msg = self.validate_code(code)
        if not is_valid:
            return {
                "success": False,
                "error": error_msg,
                "error_type": "ValidationError"
            }
        
        # Prepare execution environment
        exec_globals = {
            'pyautogui': pyautogui,
            '__builtins__': {
                'print': print,
                'len': len,
                'range': range,
                'str': str,
                'int': int,
                'float': float,
                'bool': bool,
                'list': list,
                'dict': dict,
                'tuple': tuple,
                'True': True,
                'False': False,
                'None': None
            }
        }
        
        # Add context variables if provided
        if context:
            exec_globals.update(context)
        
        # Capture output
        output_buffer = StringIO()
        error_buffer = StringIO()
        
        try:
            # Execute with output capture
            with contextlib.redirect_stdout(output_buffer), contextlib.redirect_stderr(error_buffer):
                exec(code, exec_globals, {})
            
            output = output_buffer.getvalue()
            errors = error_buffer.getvalue()
            
            return {
                "success": True,
                "output": output,
                "errors": errors if errors else None,
                "executed_code": code
            }
            
        except Exception as e:
            error_trace = traceback.format_exc()
            self.logger.error(f"Execution error: {error_trace}")
            
            return {
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__,
                "traceback": error_trace
            }
        finally:
            output_buffer.close()
            error_buffer.close()
    
    def execute_action_sequence(self, actions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Execute a sequence of PyAutoGUI actions.
        
        Args:
            actions: List of action dictionaries with 'action' and 'params' keys
            
        Returns:
            Execution result dictionary
        """
        results = []
        
        for i, action in enumerate(actions):
            action_type = action.get('action')
            params = action.get('params', {})
            
            if action_type not in self.ALLOWED_FUNCTIONS:
                results.append({
                    "index": i,
                    "action": action_type,
                    "success": False,
                    "error": f"Action '{action_type}' not allowed"
                })
                continue
            
            try:
                # Get the function from pyautogui
                func = getattr(pyautogui, action_type)
                
                # Execute the action
                result = func(**params)
                
                results.append({
                    "index": i,
                    "action": action_type,
                    "success": True,
                    "result": str(result) if result is not None else None
                })
                
            except Exception as e:
                results.append({
                    "index": i,
                    "action": action_type,
                    "success": False,
                    "error": str(e)
                })
        
        # Check overall success
        all_success = all(r['success'] for r in results)
        
        return {
            "success": all_success,
            "actions_executed": len(results),
            "results": results
        }
    
    def parse_backend_response(self, response: Dict[str, Any]) -> Optional[str]:
        """
        Extract PyAutoGUI code from backend response.
        
        Args:
            response: Backend response dictionary
            
        Returns:
            PyAutoGUI code string or None
        """
        # Check for code in various possible locations
        code_locations = [
            'pyautogui_code',
            'automation_code',
            'code',
            'data.pyautogui_code',
            'data.automation_code',
            'parsed.automation_code'
        ]
        
        for location in code_locations:
            # Handle nested paths
            keys = location.split('.')
            value = response
            
            for key in keys:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    value = None
                    break
            
            if value and isinstance(value, str):
                return value
        
        # Check for action sequence format
        if 'actions' in response or 'action_sequence' in response:
            actions = response.get('actions') or response.get('action_sequence')
            if isinstance(actions, list):
                # Convert action sequence to code
                return self._actions_to_code(actions)
        
        return None
    
    def _actions_to_code(self, actions: List[Dict[str, Any]]) -> str:
        """Convert action sequence to PyAutoGUI code."""
        code_lines = ["import pyautogui"]
        
        for action in actions:
            action_type = action.get('action')
            params = action.get('params', {})
            
            # Build parameter string
            param_strs = []
            for key, value in params.items():
                if isinstance(value, str):
                    param_strs.append(f'{key}="{value}"')
                else:
                    param_strs.append(f'{key}={value}')
            
            param_str = ', '.join(param_strs)
            code_lines.append(f"pyautogui.{action_type}({param_str})")
        
        return '\n'.join(code_lines)
    
    def safe_execute_from_response(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """
        Safely execute PyAutoGUI code from backend response.
        
        Args:
            response: Backend response containing PyAutoGUI code
            
        Returns:
            Execution result
        """
        # Extract code from response
        code = self.parse_backend_response(response)
        
        if not code:
            return {
                "success": False,
                "error": "No PyAutoGUI code found in response"
            }
        
        self.logger.info(f"Executing PyAutoGUI code:\n{code}")
        
        # Execute the code
        result = self.execute_code(code)
        
        # Log result
        if result['success']:
            self.logger.info("PyAutoGUI code executed successfully")
        else:
            self.logger.error(f"PyAutoGUI execution failed: {result['error']}")
        
        return result


# Convenience functions
def execute_pyautogui_code(code: str, **kwargs) -> Dict[str, Any]:
    """
    Execute PyAutoGUI code with default settings.
    
    Args:
        code: PyAutoGUI code string
        **kwargs: Additional arguments for PyAutoGUIExecutor
        
    Returns:
        Execution result
    """
    executor = PyAutoGUIExecutor(**kwargs)
    return executor.execute_code(code)


def execute_backend_pyautogui(response: Dict[str, Any], **kwargs) -> Dict[str, Any]:
    """
    Execute PyAutoGUI code from backend response.
    
    Args:
        response: Backend response dictionary
        **kwargs: Additional arguments for PyAutoGUIExecutor
        
    Returns:
        Execution result
    """
    executor = PyAutoGUIExecutor(**kwargs)
    return executor.safe_execute_from_response(response)


# Example usage
if __name__ == "__main__":
    # Example 1: Execute simple PyAutoGUI code
    code = """
import pyautogui
pyautogui.moveTo(100, 100, duration=1)
pyautogui.click()
print("Clicked at (100, 100)")
"""
    
    result = execute_pyautogui_code(code)
    print("Result:", result)
    
    # Example 2: Execute from backend response
    backend_response = {
        "success": True,
        "data": {
            "pyautogui_code": """
import pyautogui
pyautogui.moveTo(500, 500)
pyautogui.typewrite("Hello from backend!")
"""
        }
    }
    
    result = execute_backend_pyautogui(backend_response)
    print("Backend execution result:", result)
    
    # Example 3: Execute action sequence
    executor = PyAutoGUIExecutor()
    actions = [
        {"action": "moveTo", "params": {"x": 300, "y": 300}},
        {"action": "click", "params": {}},
        {"action": "typewrite", "params": {"message": "Action sequence"}}
    ]
    
    result = executor.execute_action_sequence(actions)
    print("Action sequence result:", result)