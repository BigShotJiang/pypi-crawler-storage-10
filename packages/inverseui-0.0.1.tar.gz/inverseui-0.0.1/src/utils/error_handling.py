from functools import wraps
import asyncio
import logging
from typing import Callable, Any


def with_error_handling(retry_count: int = 3, backoff_factor: float = 2.0):
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs) -> Any:
            last_error = None
            logger = logging.getLogger(func.__module__)
            
            for attempt in range(retry_count):
                try:
                    return await func(*args, **kwargs)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    last_error = e
                    logger.warning(
                        f"Attempt {attempt + 1}/{retry_count} failed for {func.__name__}: {str(e)}"
                    )
                    
                    if attempt < retry_count - 1:
                        wait_time = backoff_factor ** attempt
                        logger.info(f"Retrying in {wait_time} seconds...")
                        await asyncio.sleep(wait_time)
                    else:
                        logger.error(
                            f"All {retry_count} attempts failed for {func.__name__}"
                        )
                        
            if last_error:
                raise last_error
            else:
                raise RuntimeError(f"{func.__name__} failed without exception")
                
        return wrapper
    return decorator


class ErrorContext:
    def __init__(self, operation_name: str, cleanup_func: Callable = None):
        self.operation_name = operation_name
        self.cleanup_func = cleanup_func
        self.logger = logging.getLogger(__name__)
        
    async def __aenter__(self):
        self.logger.debug(f"Starting operation: {self.operation_name}")
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.logger.error(
                f"Error in operation '{self.operation_name}': {exc_val}"
            )
            
            if self.cleanup_func:
                try:
                    self.logger.info(f"Running cleanup for {self.operation_name}")
                    if asyncio.iscoroutinefunction(self.cleanup_func):
                        await self.cleanup_func()
                    else:
                        self.cleanup_func()
                except Exception as cleanup_error:
                    self.logger.error(
                        f"Cleanup failed for {self.operation_name}: {cleanup_error}"
                    )
                    
        return False