from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional
import time
import uuid


class EventType(Enum):
    ANALYSIS_START = "analysis_start"
    ANALYSIS_COMPLETE = "analysis_complete"
    ANALYSIS_ERROR = "analysis_error"
    
    AGENT_START = "agent_start"
    AGENT_COMPLETE = "agent_complete"
    AGENT_ERROR = "agent_error"
    
    LAYOUT_ANALYSIS_REQUEST = "layout_analysis_request"
    LAYOUT_ANALYZED = "layout_analyzed"
    ELEMENT_ANALYSIS_REQUEST = "element_analysis_request"
    ELEMENTS_ANALYZED = "elements_analyzed"
    HIERARCHY_ASSEMBLY_REQUEST = "hierarchy_assembly_request"
    HIERARCHY_ASSEMBLED = "hierarchy_assembled"
    
    VISION_LAYOUT_ANALYSIS_REQUEST = "vision_layout_analysis_request"
    VISION_LAYOUT_ANALYZED = "vision_layout_analyzed"
    VISION_ELEMENT_ANALYSIS_REQUEST = "vision_element_analysis_request"
    VISION_ELEMENTS_ANALYZED = "vision_elements_analyzed"
    
    AGENT_MESSAGE = "agent_message"
    DELEGATION_REQUEST = "delegation_request"
    DELEGATION_RESPONSE = "delegation_response"


@dataclass
class UIEvent:
    """Base event for UI analysis workflow"""
    type: EventType
    source: str
    data: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    metadata: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "type": self.type.value,
            "source": self.source,
            "data": self.data,
            "timestamp": self.timestamp,
            "metadata": self.metadata or {}
        }
        
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UIEvent":
        return cls(
            type=EventType(data["type"]),
            source=data["source"],
            data=data["data"],
            timestamp=data.get("timestamp", time.time()),
            event_id=data.get("event_id", str(uuid.uuid4())),
            metadata=data.get("metadata")
        )
        
    def is_error(self) -> bool:
        return "ERROR" in self.type.name
        
    def get_error_message(self) -> Optional[str]:
        if self.is_error():
            return self.data.get("error", "Unknown error")
        return None