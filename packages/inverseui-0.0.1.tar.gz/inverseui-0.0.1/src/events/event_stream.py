import asyncio
from typing import List, Dict, Any, Callable, Optional
import logging
from .event import UIEvent, EventType


class EventStream:
    """Manages event flow between agents"""
    
    def __init__(self, max_queue_size: int = 1000):
        self.queue = asyncio.Queue(maxsize=max_queue_size)
        self.handlers: Dict[EventType, List[Callable]] = {}
        self.event_history: List[UIEvent] = []
        self.logger = logging.getLogger("EventStream")
        self._running = False
        
    async def emit(self, event: UIEvent):
        try:
            await self.queue.put(event)
            self.event_history.append(event)
            self.logger.debug(f"Event emitted: {event.type.value} from {event.source}")
        except asyncio.QueueFull:
            self.logger.error(f"Event queue full, dropping event: {event.type.value}")
            
    def register_handler(self, event_type: EventType, handler: Callable):
        if event_type not in self.handlers:
            self.handlers[event_type] = []
        self.handlers[event_type].append(handler)
        self.logger.info(f"Handler registered for {event_type.value}")
        
    def unregister_handler(self, event_type: EventType, handler: Callable):
        if event_type in self.handlers and handler in self.handlers[event_type]:
            self.handlers[event_type].remove(handler)
            self.logger.info(f"Handler unregistered for {event_type.value}")
            
    async def process_events(self):
        self._running = True
        self.logger.info("Event processing started")
        
        while self._running:
            try:
                event = await asyncio.wait_for(self.queue.get(), timeout=1.0)
                await self._handle_event(event)
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                self.logger.error(f"Error processing event: {str(e)}")
                
    async def _handle_event(self, event: UIEvent):
        """Handle a single event"""
        handlers = self.handlers.get(event.type, [])
        
        if not handlers:
            self.logger.warning(f"No handlers for event type: {event.type.value}")
            return
            
        tasks = []
        for handler in handlers:
            if asyncio.iscoroutinefunction(handler):
                tasks.append(handler(event))
            else:
                tasks.append(asyncio.create_task(self._run_sync_handler(handler, event)))
                
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(f"Handler {handlers[i].__name__} failed: {result}")
                
    async def _run_sync_handler(self, handler: Callable, event: UIEvent):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, handler, event)
        
    def stop(self):
        self._running = False
        self.logger.info("Event processing stopped")
        
    def get_event_history(self, event_type: Optional[EventType] = None) -> List[UIEvent]:
        if event_type:
            return [e for e in self.event_history if e.type == event_type]
        return self.event_history.copy()
        
    def clear_history(self):
        self.event_history.clear()
        
    async def wait_for_event(self, event_type: EventType, timeout: float = 30.0) -> Optional[UIEvent]:
        start_time = asyncio.get_event_loop().time()
        
        while asyncio.get_event_loop().time() - start_time < timeout:
            for event in reversed(self.event_history):
                if event.type == event_type:
                    return event
                    
            await asyncio.sleep(0.1)
            
        return None
        
    def get_stats(self) -> Dict[str, Any]:
        event_counts = {}
        for event in self.event_history:
            event_counts[event.type.value] = event_counts.get(event.type.value, 0) + 1
            
        return {
            "total_events": len(self.event_history),
            "queue_size": self.queue.qsize(),
            "event_counts": event_counts,
            "registered_handlers": {
                event_type.value: len(handlers)
                for event_type, handlers in self.handlers.items()
            }
        }