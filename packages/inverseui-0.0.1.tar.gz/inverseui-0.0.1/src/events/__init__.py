"""Event system for UI analysis"""

from .event import UIEvent, EventType
from .event_stream import EventStream

__all__ = ["UIEvent", "EventType", "EventStream"]