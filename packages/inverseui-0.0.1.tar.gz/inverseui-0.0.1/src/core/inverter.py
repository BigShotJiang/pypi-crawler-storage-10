import asyncio
import os
from typing import List, Dict, Any, Optional
import logging
from dotenv import load_dotenv

from ..agents import (
    AgentConfig,
    LayoutMasterAgent,
    ElementAnalyzerAgent,
    HierarchyAssemblerAgent
)
from ..controllers import UIController
from ..utils import AnalysisMetrics


load_dotenv()


class UIInverter:
    """Main class for UI analysis using multi-agent system"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, use_vision: bool = None):
        """
        Initialize UI Inverter system
        
        Args:
            config: Configuration dictionary with optional settings
            use_vision: Whether to use vision capabilities (None = auto-detect based on API)
        """
        self.config = config or {}
        self.logger = logging.getLogger("UIInverter")
        
        # Auto-detect vision mode if not specified
        if use_vision is None:
            anthropic_key = os.getenv("ANTHROPIC_API_KEY") or self.config.get("anthropic_api_key")
            self.use_vision = bool(anthropic_key)  # Use vision if Anthropic key is available
        else:
            self.use_vision = use_vision
        
        self._setup_logging()
        
        # Pass API config to controller
        controller_config = self._get_controller_config()
        self.controller = UIController(agents=None, config=controller_config, use_vision=self.use_vision)
        self.metrics = AnalysisMetrics()
        
    def _setup_logging(self):
        log_level = self.config.get("log_level", "INFO")
        logging.basicConfig(
            level=getattr(logging, log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
    def _initialize_agents(self) -> Dict[str, Any]:
        anthropic_key = os.getenv("ANTHROPIC_API_KEY") or self.config.get("anthropic_api_key")
        openai_key = os.getenv("OPENAI_API_KEY") or self.config.get("openai_api_key")
        
        if anthropic_key:
            vision_model = "claude-3-5-sonnet-20241022"  # Updated to latest vision model
            text_model = "claude-3-sonnet-20240229"
            api_key = anthropic_key
            api_type = "anthropic"
        elif openai_key:
            vision_model = "gpt-4-vision-preview"
            text_model = "gpt-3.5-turbo"
            api_key = openai_key
            api_type = "openai"
        else:
            raise ValueError("No API key found. Please set ANTHROPIC_API_KEY or OPENAI_API_KEY")
            
        layout_config = AgentConfig(
            name="LayoutMaster",
            model=vision_model,
            api_key=api_key,
            api_type=api_type,
            temperature=0.2
        )
        
        element_config = AgentConfig(
            name="ElementAnalyzer",
            model=text_model,
            api_key=api_key,
            api_type=api_type,
            temperature=0.1
        )
        
        hierarchy_config = AgentConfig(
            name="HierarchyAssembler",
            model=text_model,
            api_key=api_key,
            api_type=api_type,
            temperature=0.1
        )
        
        agents = {
            "layout_master": LayoutMasterAgent(layout_config),
            "element_analyzer": ElementAnalyzerAgent(element_config),
            "hierarchy_assembler": HierarchyAssemblerAgent(hierarchy_config)
        }
        
        self.logger.info(f"Initialized {len(agents)} agents")
        return agents
    
    def _get_controller_config(self) -> Dict[str, Any]:
        """Get configuration for the controller"""
        anthropic_key = os.getenv("ANTHROPIC_API_KEY") or self.config.get("anthropic_api_key")
        openai_key = os.getenv("OPENAI_API_KEY") or self.config.get("openai_api_key")
        
        controller_config = self.config.copy()
        
        if anthropic_key:
            controller_config.update({
                "api_key": anthropic_key,
                "api_type": "anthropic",
                "model": "claude-3-5-sonnet-20241022" if self.use_vision else "claude-3-opus-20240229"
            })
        elif openai_key:
            controller_config.update({
                "api_key": openai_key,
                "api_type": "openai",
                "model": "gpt-4-vision-preview" if self.use_vision else "gpt-3.5-turbo"
            })
        else:
            raise ValueError("No API key found. Please set ANTHROPIC_API_KEY or OPENAI_API_KEY")
        
        return controller_config
        
    def analyze_ui(self, screenshot_path: str, bounding_boxes: List[Dict[str, Any]], send_to_api: bool = False, api_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze UI screenshot and return structured component tree
        
        Args:
            screenshot_path: Path to UI screenshot
            bounding_boxes: List of bounding boxes with format:
                [{"bbox": [x1, y1, x2, y2], "text": "...", ...}, ...]
            send_to_api: Whether to send results to InverseUI parser API
            api_metadata: Optional metadata for API submission
        
        Returns:
            Structured UI component tree with metadata
        """
        return asyncio.run(self._analyze_ui_async(screenshot_path, bounding_boxes, send_to_api, api_metadata))
        
    async def _analyze_ui_async(self, screenshot_path: str, bounding_boxes: List[Dict[str, Any]], send_to_api: bool = False, api_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.logger.info(f"Starting UI analysis for {screenshot_path}")
        self.metrics = AnalysisMetrics()
        
        try:
            if not os.path.exists(screenshot_path):
                raise FileNotFoundError(f"Screenshot not found: {screenshot_path}")
                
            if not bounding_boxes:
                raise ValueError("No bounding boxes provided")
                
            result = await self.controller.analyze_ui(screenshot_path, bounding_boxes)
            
            # Optionally send to API
            if send_to_api:
                from ..utils.api_client import InverseUIAPIClient
                
                self.logger.info("Sending results to InverseUI parser API")
                api_client = InverseUIAPIClient()
                
                # Prepare metadata
                metadata = api_metadata or {}
                metadata.update({
                    "vision_mode": self.use_vision,
                    "analysis_duration": self.metrics.duration(),
                    "confidence_average": result.get("analysis_metadata", {}).get("confidence_average", 0),
                    "total_elements": len(bounding_boxes)
                })
                
                api_response = await api_client.send_bbox_data(
                    bounding_boxes=bounding_boxes,
                    screenshot_path=screenshot_path,
                    metadata=metadata
                )
                
                result["api_response"] = api_response
                
                if api_response.get("success"):
                    self.logger.info("Successfully sent data to parser API")
                else:
                    self.logger.error(f"Failed to send to API: {api_response.get('error')}")
            
            self.metrics.finish()
            result["metrics"] = self.metrics.to_dict()
            self.logger.info(f"Analysis completed in {self.metrics.duration():.2f}s")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Analysis failed: {str(e)}")
            self.metrics.increment_errors()
            self.metrics.finish()
            
            return {
                "success": False,
                "error": str(e),
                "metrics": self.metrics.to_dict()
            }
            
    def analyze_ui_from_json(self, screenshot_path: str, json_path: str) -> Dict[str, Any]:
        """
        Analyze UI using bounding boxes from JSON file
        
        Args:
            screenshot_path: Path to UI screenshot
            json_path: Path to JSON file containing bounding boxes
        
        Returns:
            Structured UI component tree
        """
        import json
        
        with open(json_path, 'r') as f:
            data = json.load(f)
            
        if isinstance(data, list):
            bounding_boxes = data
        elif isinstance(data, dict) and "boxes" in data:
            bounding_boxes = data["boxes"]
        elif isinstance(data, dict) and "bounding_boxes" in data:
            bounding_boxes = data["bounding_boxes"]
        else:
            raise ValueError("Invalid JSON format. Expected list or dict with 'boxes' key")
            
        return self.analyze_ui(screenshot_path, bounding_boxes)
        
    def get_progress(self) -> Dict[str, Any]:
        return self.controller.get_progress()
        
    def get_metrics(self) -> AnalysisMetrics:
        return self.metrics
        
    def print_metrics(self):
        self.metrics.print_summary()
        
    @classmethod
    def from_config_file(cls, config_path: str) -> "UIInverter":
        import json
        
        with open(config_path, 'r') as f:
            config = json.load(f)
            
        return cls(config)