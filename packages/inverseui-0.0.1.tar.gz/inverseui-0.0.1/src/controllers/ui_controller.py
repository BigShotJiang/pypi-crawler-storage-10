import asyncio
from typing import List, Dict, Any, Optional
import logging
from autogen import GroupChat, GroupChatManager

from ..agents.base import BaseUIAgent
from ..events.event import UIEvent, EventType
from ..events.event_stream import EventStream
from ..state.analysis_state import UIState, AnalysisStage
from ..utils.error_handling import with_error_handling


class UIController:
    """Controller for managing UI analysis workflow"""
    
    def __init__(self, agents: Dict[str, BaseUIAgent], config: Optional[Dict[str, Any]] = None):
        self.agents = agents
        self.config = config or {}
        self.event_stream = EventStream()
        self.state = UIState()
        self.logger = logging.getLogger("UIController")
        
        self._setup_event_handlers()
        self._setup_autogen_components()
        
    def _setup_event_handlers(self):
        """Set up event handlers for different event types"""
        self.event_stream.register_handler(
            EventType.LAYOUT_ANALYZED,
            self._handle_layout_analyzed
        )
        self.event_stream.register_handler(
            EventType.ELEMENTS_ANALYZED,
            self._handle_elements_analyzed
        )
        self.event_stream.register_handler(
            EventType.HIERARCHY_ASSEMBLED,
            self._handle_hierarchy_assembled
        )
        self.event_stream.register_handler(
            EventType.ANALYSIS_ERROR,
            self._handle_error
        )
        
    def _setup_autogen_components(self):
        autogen_agents = []
        for agent_name, agent in self.agents.items():
            autogen_agents.append(agent.get_autogen_agent())
            
        self.group_chat = GroupChat(
            agents=autogen_agents,
            messages=[],
            max_round=self.config.get("max_rounds", 10)
        )
        
        manager_config = self.config.get("manager_config", {
            "config_list": [{
                "model": "gpt-3.5-turbo",
                "api_key": "dummy"
            }],
            "temperature": 0
        })
        
        self.chat_manager = GroupChatManager(
            groupchat=self.group_chat,
            llm_config=manager_config
        )
        
    async def analyze_ui(self, screenshot_path: str, bounding_boxes: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Main entry point for UI analysis"""
        try:
            self.state = UIState(
                screenshot_path=screenshot_path,
                bounding_boxes=bounding_boxes
            )
            
            event_task = asyncio.create_task(self.event_stream.process_events())
            
            await self.event_stream.emit(UIEvent(
                type=EventType.ANALYSIS_START,
                source="controller",
                data={
                    "screenshot": screenshot_path,
                    "bounding_boxes": bounding_boxes
                }
            ))
            
            result = await self._run_analysis_workflow()
            
            self.event_stream.stop()
            await event_task
            
            return result
            
        except Exception as e:
            self.logger.error(f"Analysis failed: {str(e)}")
            self.state.add_error(str(e), "controller")
            return self.state.get_result()
            
    @with_error_handling(retry_count=3)
    async def _run_analysis_workflow(self) -> Dict[str, Any]:
        self.state.set_stage(AnalysisStage.LAYOUT_ANALYSIS)
        await self._analyze_layout()
        
        layout_event = await self.event_stream.wait_for_event(
            EventType.LAYOUT_ANALYZED,
            timeout=30.0
        )
        
        if not layout_event:
            raise TimeoutError("Layout analysis timed out")
            
        self.state.set_stage(AnalysisStage.ELEMENT_ANALYSIS)
        await self._analyze_elements()
        
        elements_event = await self.event_stream.wait_for_event(
            EventType.ELEMENTS_ANALYZED,
            timeout=30.0
        )
        
        if not elements_event:
            raise TimeoutError("Element analysis timed out")
            
        self.state.set_stage(AnalysisStage.HIERARCHY_ASSEMBLY)
        await self._assemble_hierarchy()
        
        hierarchy_event = await self.event_stream.wait_for_event(
            EventType.HIERARCHY_ASSEMBLED,
            timeout=30.0
        )
        
        if not hierarchy_event:
            raise TimeoutError("Hierarchy assembly timed out")
            
        self.state.set_stage(AnalysisStage.COMPLETED)
        
        await self.event_stream.emit(UIEvent(
            type=EventType.ANALYSIS_COMPLETE,
            source="controller",
            data=self.state.get_result()
        ))
        
        return self.state.get_result()
        
    async def _analyze_layout(self):
        layout_agent = self.agents.get("layout_master")
        if not layout_agent:
            raise ValueError("LayoutMaster agent not found")
            
        await self.event_stream.emit(UIEvent(
            type=EventType.LAYOUT_ANALYSIS_REQUEST,
            source="controller",
            data={
                "screenshot": self.state.screenshot_path,
                "bounding_boxes": self.state.bounding_boxes
            }
        ))
        
        try:
            result = await asyncio.create_task(
                self._run_agent_analysis(layout_agent, {
                    "screenshot": self.state.screenshot_path,
                    "bounding_boxes": self.state.bounding_boxes
                })
            )
            
            self.state.layout_analysis = result
            
            await self.event_stream.emit(UIEvent(
                type=EventType.LAYOUT_ANALYZED,
                source="layout_master",
                data=result
            ))
            
        except Exception as e:
            await self._emit_error("layout_master", str(e))
            raise
            
    async def _analyze_elements(self):
        element_agent = self.agents.get("element_analyzer")
        if not element_agent:
            raise ValueError("ElementAnalyzer agent not found")
            
        await self.event_stream.emit(UIEvent(
            type=EventType.ELEMENT_ANALYSIS_REQUEST,
            source="controller",
            data={
                "bounding_boxes": self.state.bounding_boxes,
                "layout_context": self.state.layout_analysis
            }
        ))
        
        try:
            result = await asyncio.create_task(
                self._run_agent_analysis(element_agent, {
                    "bounding_boxes": self.state.bounding_boxes,
                    "layout_context": self.state.layout_analysis
                })
            )
            
            self.state.element_analyses = result.get("elements", [])
            
            await self.event_stream.emit(UIEvent(
                type=EventType.ELEMENTS_ANALYZED,
                source="element_analyzer",
                data=result
            ))
            
        except Exception as e:
            await self._emit_error("element_analyzer", str(e))
            raise
            
    async def _assemble_hierarchy(self):
        hierarchy_agent = self.agents.get("hierarchy_assembler")
        if not hierarchy_agent:
            raise ValueError("HierarchyAssembler agent not found")
            
        await self.event_stream.emit(UIEvent(
            type=EventType.HIERARCHY_ASSEMBLY_REQUEST,
            source="controller",
            data={
                "layout_analysis": self.state.layout_analysis,
                "element_analysis": {"elements": self.state.element_analyses}
            }
        ))
        
        try:
            result = await asyncio.create_task(
                self._run_agent_analysis(hierarchy_agent, {
                    "layout_analysis": self.state.layout_analysis,
                    "element_analysis": {"elements": self.state.element_analyses}
                })
            )
            
            self.state.final_hierarchy = result.get("ui_tree")
            
            await self.event_stream.emit(UIEvent(
                type=EventType.HIERARCHY_ASSEMBLED,
                source="hierarchy_assembler",
                data=result
            ))
            
        except Exception as e:
            await self._emit_error("hierarchy_assembler", str(e))
            raise
            
    async def _run_agent_analysis(self, agent: BaseUIAgent, data: Dict[str, Any]) -> Dict[str, Any]:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, agent.analyze, data)
        
    async def _emit_error(self, source: str, error: str):
        await self.event_stream.emit(UIEvent(
            type=EventType.ANALYSIS_ERROR,
            source=source,
            data={"error": error}
        ))
        
    async def _handle_layout_analyzed(self, event: UIEvent):
        self.logger.info("Layout analysis completed")
        
    async def _handle_elements_analyzed(self, event: UIEvent):
        self.logger.info("Element analysis completed")
        
    async def _handle_hierarchy_assembled(self, event: UIEvent):
        self.logger.info("Hierarchy assembly completed")
        
    async def _handle_error(self, event: UIEvent):
        error_msg = event.get_error_message()
        self.logger.error(f"Error from {event.source}: {error_msg}")
        self.state.add_error(error_msg, event.source)
        
    def get_progress(self) -> Dict[str, Any]:
        return self.state.get_progress()
        
    def get_event_stats(self) -> Dict[str, Any]:
        return self.event_stream.get_stats()
    
    def _create_agents(self, use_vision: bool) -> Dict[str, BaseUIAgent]:
        """Create default agents with or without vision capabilities"""
        from ..agents.layout_master import LayoutMasterAgent
        from ..agents.element_analyzer import ElementAnalyzerAgent
        from ..agents.hierarchy_assembler import HierarchyAssemblerAgent
        from ..agents.base import AgentConfig
        
        api_key = self.config.get("api_key")
        api_type = self.config.get("api_type", "openai")
        model = self.config.get("model", "gpt-3.5-turbo")
        
        # Use vision models if requested and available
        if use_vision and api_type == "anthropic":
            model = "claude-3-5-sonnet-20241022"
        elif use_vision and api_type == "openai":
            model = "gpt-4-vision-preview"
        
        return {
            "layout_master": LayoutMasterAgent(
                config=AgentConfig(
                    name="LayoutMaster",
                    model=model,
                    api_key=api_key,
                    api_type=api_type,
                    temperature=0.3,
                    role="layout_master"
                ),
                use_vision=use_vision
            ),
            "element_analyzer": ElementAnalyzerAgent(
                config=AgentConfig(
                    name="ElementAnalyzer",
                    model=model,
                    api_key=api_key,
                    api_type=api_type,
                    temperature=0.3,
                    role="element_analyzer"
                ),
                use_vision=use_vision
            ),
            "hierarchy_assembler": HierarchyAssemblerAgent(
                config=AgentConfig(
                    name="HierarchyAssembler",
                    model=self.config.get("model", "gpt-3.5-turbo"),  # Can use non-vision model
                    api_key=api_key,
                    api_type=api_type,
                    temperature=0.3,
                    role="hierarchy_assembler"
                )
            )
        }