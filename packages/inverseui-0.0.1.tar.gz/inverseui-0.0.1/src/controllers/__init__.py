"""Controllers for UI analysis system"""

from .ui_controller import UIController

__all__ = ["UIController"]