"""Entry point for the CLI."""

from gixy.cli.main import main

main()
