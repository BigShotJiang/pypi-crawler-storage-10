# flake8: noqa

from gixy.core import severity

version = "0.2.12"
