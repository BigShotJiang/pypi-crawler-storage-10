from calculator.basic.addition import add
from calculator.basic.multiplication import multiply
from calculator.basic.subtraction import subtract