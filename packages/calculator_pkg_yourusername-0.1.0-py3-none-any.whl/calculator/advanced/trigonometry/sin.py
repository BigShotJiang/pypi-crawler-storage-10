from math import sin
def sine(x):
    return sin(x)