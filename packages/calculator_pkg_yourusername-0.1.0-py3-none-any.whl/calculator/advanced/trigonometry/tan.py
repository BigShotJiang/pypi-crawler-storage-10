from math import tan
def tangent(x):
    return tan(x)