from math import cos
def cosine(x):
    return cos(x)