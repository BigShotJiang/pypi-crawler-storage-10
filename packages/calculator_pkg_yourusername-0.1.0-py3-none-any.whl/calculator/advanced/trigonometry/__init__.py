from .cos import cosine
from .sin import sine
from .tan import tangent