import sys
import time

sys.path.append("../..")
from src.service.clientsvc.client_service import MeterClientService

# 日志设置
from src.transport.client.log import log as client_log
from src.service.clientsvc.log import log as client_svc_log
from src.protocol.log import log as protocol_log
client_log.set_config(filename="log/client.log", when='10 MB', cmdlevel='DEBUG',
          filelevel='DEBUG', limit="10 MB", backup_count=1, colorful=True)
client_svc_log.set_config(filename="log/client_svc.log", when='10 MB', cmdlevel='DEBUG',
          filelevel='DEBUG', limit="10 MB", backup_count=1, colorful=True)
protocol_log.set_config(filename="log/protocol.log", when='10 MB', cmdlevel='DEBUG',
          filelevel='DEBUG', limit="10 MB", backup_count=1, colorful=True)


if __name__ == "__main__":
    # 创建TCP客户端
    client_svc = MeterClientService.new_tcp_client("127.0.0.1", 10521, 3000)
    if not client_svc:
        print("创建客户端失败")
        sys.exit(1)
    
    # 读取通讯地址
    print("读取通讯地址...")
    address_data = client_svc.read_address()
    if address_data and hasattr(address_data, 'value'):
        print(f"通讯地址: {address_data.value}")
    else:
        print("读取通讯地址失败")
    
    # 设置设备地址
    client_svc.set_address(address_data.value)
    
    # 读取多次数据
    for i in range(3):
        print(f"\n第 {i+1} 次读取数据:")
        start_time = time.time()
        
        # 读取电能数据
        print("读取电能数据...")
        data_item = client_svc.read_01(0x00000000)
        print(f"电能数据: {data_item}")
        
        # 读取变量数据
        print("读取变量数据...")
        data_item2 = client_svc.read_02(0x02010100)
        print(f"变量数据: {data_item2}")
        
        end_time = time.time()
        print(f"第 {i+1} 次读取耗时: {end_time - start_time:.4f} 秒")
        
        if i < 2:  # 最后一次不需要等待
            print("等待1秒后进行下一次读取...")
            time.sleep(1)
