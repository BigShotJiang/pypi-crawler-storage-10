{{ name | escape | underline }}

.. currentmodule:: ~{{ module }}

.. autoexception:: {{ fullname }}
