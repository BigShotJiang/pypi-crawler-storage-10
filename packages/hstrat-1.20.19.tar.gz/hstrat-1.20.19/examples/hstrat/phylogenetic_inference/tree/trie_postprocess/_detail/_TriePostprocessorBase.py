class TriePostprocessorBase:
    """Base class to facilitate detection of postprocessor types."""
