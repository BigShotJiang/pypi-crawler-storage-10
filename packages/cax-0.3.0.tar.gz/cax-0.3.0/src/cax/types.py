"""Type definitions."""

from typing import Any, TypeAlias

PyTree: TypeAlias = Any

State: TypeAlias = PyTree
Input: TypeAlias = PyTree
