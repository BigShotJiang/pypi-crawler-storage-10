"""CAX: Cellular Automata Accelerated in JAX."""
