"""Complex systems implemented in CAX."""
