"""Prismor CLI - Security scanning tool for GitHub repositories."""

__version__ = "0.1.2"
__author__ = "Prismor"
__description__ = "A CLI tool for scanning GitHub repositories for vulnerabilities, secrets, and generating SBOMs"

