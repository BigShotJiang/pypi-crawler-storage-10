# @point72/csp-gateway

Frontend assets for `csp-gateway`.

## Installation

```bash
npm install @point72/csp-gateway
```

## Usage

See [our wiki](https://github.com/Point72/csp-gateway/wiki/Develop#Extending-the-UI).
