
from speclike.speclike import Spec, Case

__all__ = [
    "Spec", "Case"
]

