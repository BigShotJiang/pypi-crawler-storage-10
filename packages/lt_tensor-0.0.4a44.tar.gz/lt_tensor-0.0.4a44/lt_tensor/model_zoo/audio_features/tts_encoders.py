__all__ = ["StyleEncoder", "DurationPredictor", "TextEncoder", "DiffusionTimeEmbedding"]

from lt_utils.common import *
from lt_tensor.common import *
import torch.nn.functional as F
from lt_tensor.model_zoo.convs import ConvBase, is_conv


class Conv1dNorm(ConvBase):
    def __init__(
        self,
        channels: int,
        kernel_size: int = 1,
        dilation: int = 1,
        eps: float = 1e-5,
        dropout: float = 0.05,
        stride: int = 1,
        activation=nn.LeakyReLU(0.1),
        groups: int = 1,
        mask_value: float = 0.0,
        bias: bool = True,
        norm: Optional[Literal["weight_norm", "spectral_norm"]] = "weight_norm",
    ):
        super().__init__()
        self.channels = channels
        self.mask_value = mask_value
        self.activation = activation
        self.eps = eps

        self.cnn = self.get_1d_conv(
            channels,
            kernel_size=kernel_size,
            dilation=dilation,
            groups=groups,
            stride=stride,
            padding=(kernel_size - dilation) // 2,
            bias=bias,
            norm=norm,
        )
        self.norm = nn.LayerNorm(channels, eps, elementwise_affine=True, bias=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: Tensor, mask: Optional[Tensor] = None):
        if mask is not None:
            x.masked_fill_(mask, self.mask_value)
        x = self.cnn(x).transpose(-2, -1)
        x = self.norm(x).transpose(-2, -1)
        x = self.activation(x)
        x = self.dropout(x)
        return x


class DiffusionTimeEmbedding(Model):
    def __init__(
        self,
        max_steps: int,
        hidden_dim: int = 512,
        activation: nn.Module = nn.SiLU(),
    ):
        super().__init__()
        self.register_buffer(
            "embedding", self._build_embedding(max_steps), persistent=False
        )

        self.net = nn.Sequential(
            nn.Linear(128, hidden_dim),
            activation,
            nn.Linear(hidden_dim, 128),
            activation,
        )

    def forward(self, diffusion_step: Tensor):
        x = self.embedding[diffusion_step]
        return self.net(x)

    def _build_embedding(self, max_steps):
        steps = torch.arange(max_steps).unsqueeze(1)  # [T,1]
        dims = torch.arange(64).unsqueeze(0)  # [1,64]
        table = steps * 10.0 ** (dims * 4.0 / 63.0)  # [T,64]
        table = torch.cat([torch.sin(table), torch.cos(table)], dim=1)
        return table


class DurationPredictor(ConvBase):
    def __init__(
        self,
        d_model: int = 128,
        mask_value: Number = 0.0,
        exponential: bool = False,
        kernel_size: int = 3,
        dilation: int = 1,
        flatten_outputs: bool = True,
        bias_at_final_layer: bool = False,
        n_layers: int = 2,
        dropout: float = 0.0,
        proj_activation: nn.Module = nn.LeakyReLU(0.1),
        layers_activations: nn.Module = nn.LeakyReLU(0.1),
        norm: Optional[Literal["weight_norm", "spectral_norm"]] = None,
    ):
        super().__init__()
        self.flatten_outputs = flatten_outputs
        pad = self.get_padding(kernel_size, dilation)
        n_layers = max(int(n_layers), 1)
        self.layers = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Linear(d_model, d_model),
                    layers_activations,
                )
                for _ in range(n_layers)
            ]
        )
        self.conv_post = nn.Sequential(
            self.get_1d_conv(d_model, d_model, 3, padding=1, norm=norm),
            proj_activation,
            nn.BatchNorm1d(d_model),
            self.get_1d_conv(d_model, 1, 1, bias=bias_at_final_layer, norm=norm),
        )
        self.exponential = exponential
        self.n_layers = n_layers
        self.dropout = (
            nn.Identity() if dropout <= 0 or self.n_layers < 2 else nn.Dropout(dropout)
        )
        self.res_sp = 1.0 / ((self.n_layers + 1) * 2)
        self.mask_value = mask_value
        for m in self.conv_post:
            if is_conv(m):
                nn.init.orthogonal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.weight)
        for m in self.layers:
            nn.init.xavier_normal_(m[0].weight)

    def forward(self, x: Tensor, mask: Optional[Tensor] = None):
        # x=[B, C, d_model]
        if mask is not None:
            x = x.transpose(-1, -2)
            x.masked_fill_(mask, self.mask_value)
            x = x.transpose(-1, -2)

        for layer in self.layers:
            x = self.dropout(x)
            x = layer(x)

        x = x.transpose(-1, -2).contiguous()
        if mask is not None:
            x.masked_fill_(mask, self.mask_value)

        x = self.conv_post(x)

        if self.exponential:
            x = x.exp()
        if self.flatten_outputs:
            x = x.flatten(1, -1)
        return x

    @staticmethod
    def expand_embeddings(x: torch.Tensor, durations: torch.Tensor) -> torch.Tensor:
        """
        Expand per-token embeddings according to predicted or target durations.

        Args:
            x: Tensor of shape [B, seq_len, D] — token embeddings.
            durations: Tensor of shape [B, seq_len] — durations (in frames).

        Returns:
            expanded: Tensor of shape [B, total_frames, D]
                where total_frames = sum(durations[b]) for each batch.
        """
        expanded = []
        durations = torch.clamp(durations, min=1).long()

        for b in range(x.size(0)):
            expanded_seq = torch.repeat_interleave(x[b], durations[b], dim=0)
            expanded.append(expanded_seq)

        # pad to the max total length across the batch for tensor stacking
        max_len = max(seq.size(0) for seq in expanded)
        expanded = [F.pad(seq, (0, 0, 0, max_len - seq.size(0))) for seq in expanded]
        return torch.stack(expanded, dim=0)


class TextEncoder(Model):
    def __init__(
        self,
        vocab_size: int,
        d_model: int = 256,
        kernel_sizes: List[int] = [3, 3, 3, 3],
        n_layers: int = 2,
        dropout: float = 0.1,
        padding_id: int = 0,
        mask_value: Number = 0.0,
        activation: nn.Module = nn.LeakyReLU(0.1),
        norm: Optional[Literal["weight_norm", "spectral_norm"]] = None,
    ):
        super().__init__()

        self.embedding = nn.Embedding(vocab_size, d_model, padding_idx=padding_id)
        self.mask_value = mask_value
        self.cnn = nn.ModuleList()
        for k in kernel_sizes:
            self.cnn.append(
                Conv1dNorm(
                    d_model,
                    k,
                    activation=activation,
                    norm=norm,
                    mask_value=mask_value,
                    dropout=dropout,
                )
            )

        self.rnn = nn.LSTM(
            d_model,
            d_model,
            num_layers=n_layers,
            dropout=0 if n_layers < 2 else dropout,
            batch_first=True,
            bidirectional=True,
        )
        self.proj_out = nn.Sequential(
            nn.LeakyReLU(0.1),
            nn.Linear(d_model * 2, d_model),
        )
        self.duration_pred = None

    def forward(
        self,
        input_ids: Tensor,
        lengths: List[int] = None,
        mask: Optional[Tensor] = None,
    ):
        B, T = input_ids.size(0), input_ids.size(-1)
        emb: Tensor = self.embedding(input_ids.view(B, T))  # [B, T, emb]

        x = emb.transpose(-1, -2)  # [B, emb, T]

        for c in self.cnn:
            x = c(x, mask)

        if mask is not None:
            x.masked_fill_(mask, self.mask_value)

        x = x.transpose(-1, -2)

        if lengths is None:
            lengths = [T for _ in range(B)]
        elif isinstance(lengths, Tensor):
            lengths = lengths.clone().detach().cpu().long().tolist()

        packed = nn.utils.rnn.pack_padded_sequence(
            x,
            lengths,
            batch_first=True,
            enforce_sorted=False,
        )
        self.rnn.flatten_parameters()
        out_packed = self.rnn(packed)[0]
        x = nn.utils.rnn.pad_packed_sequence(out_packed, batch_first=True)[0]
        x = self.proj_out(x)
        x = x.transpose(-1, -2)
        if mask is not None:
            x.masked_fill_(mask, self.mask_value)

        return dict(text=x, emb=emb)


class StyleEncoder(ConvBase):
    def __init__(
        self,
        n_mels: int = 80,
        d_model: int = 128,
        out_dim: int = 256,
        fc_bias: bool = True,
        norm: Optional[Literal["weight_norm", "spectral_norm"]] = None,
        activation: nn.Module = nn.LeakyReLU(0.1),
    ):
        super().__init__()
        self.n_mels = n_mels
        self.hidden = d_model
        pad = lambda k, d: ((k - 1) * d) // 2
        self.net = nn.Sequential(
            self.get_1d_conv(
                n_mels, d_model, kernel_size=3, stride=2, padding=1, norm=norm
            ),
            activation,
            self.get_1d_conv(
                d_model,
                d_model,
                kernel_size=5,
                dilation=2,
                padding=pad(5, 2),
                norm=norm,
            ),
            activation,
            self.get_1d_conv(
                d_model, d_model, kernel_size=3, stride=2, padding=1, norm=norm
            ),
            activation,
            nn.AdaptiveAvgPool1d(1),
        )
        self.fc = nn.Linear(d_model, out_dim, bias=fc_bias)

    def forward(self, mel: Tensor) -> Tensor:
        if mel.ndim == 2:
            mel = mel.unsqueeze(0)
        B = mel.size(0)
        mel = self.net(mel.view(B, self.n_mels, -1)).view(B, self.hidden)  # [B, h]
        return self.fc(mel)  # [B, dim_out]
