class EQ3Exception(Exception):
    pass
