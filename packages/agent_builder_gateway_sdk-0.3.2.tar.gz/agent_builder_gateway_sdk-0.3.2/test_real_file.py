#!/usr/bin/env python3
"""测试真实的 S3 文件"""

from gateway_sdk import GatewayClient

def test_real_s3_file():
    """使用真实的 S3 文件测试白名单模式"""
    
    print("🧪 测试白名单模式 + 真实 S3 文件")
    
    # 无需 token，白名单模式
    client = GatewayClient()
    
    s3_url = "s3://cubeflow-dev/prefab-gateway/prefab-inputs/f94d31c2-154d-4363-8450-cc907117cbcb/2025/10/29/1761708431516-____.pdf"
    
    print(f"📄 S3 文件: {s3_url}")
    print("📤 调用 file-processing-prefab...")
    
    try:
        result = client.run(
            prefab_id="file-processing-prefab",
            version="0.1.5",
            function_name="parse_file",
            parameters={},
            files={"input": [s3_url]}
        )
        
        print(f"\n📊 SDK 层状态: {result.status}")
        print(f"📋 Job ID: {result.job_id}")
        
        if result.is_success():
            print("\n✅ 调用成功！")
            
            # 获取函数返回值
            function_result = result.get_function_result()
            if function_result:
                print(f"\n📦 函数返回值:")
                print(f"   success: {function_result.get('success')}")
                print(f"   message: {function_result.get('message')}")
                if function_result.get('content'):
                    content = function_result.get('content')
                    print(f"   content: {content[:200]}..." if len(content) > 200 else f"   content: {content}")
                print(f"   input_file: {function_result.get('input_file')}")
                print(f"   output_file: {function_result.get('output_file')}")
                
                if not function_result.get('success'):
                    print(f"   error: {function_result.get('error')}")
                    print(f"   error_code: {function_result.get('error_code')}")
            
            # 获取输出文件
            output_files = result.get_files()
            if output_files:
                print(f"\n📁 输出文件: {output_files}")
        else:
            print(f"\n❌ 调用失败")
            print(f"错误: {result.error}")
            
    except Exception as e:
        print(f"\n❌ 异常: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_real_s3_file()
