let algebra-ineq-nto1onlt2m1on = `!n:num. exp ((&1 / &n) * ln(&n)) < &2 - &1 / &n`;;
