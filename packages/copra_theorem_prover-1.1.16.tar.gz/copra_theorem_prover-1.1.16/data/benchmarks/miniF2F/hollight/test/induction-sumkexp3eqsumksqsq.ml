let induction-sumkexp3eqsumksqsq = `!n. nsum(0..(n-1)) (\k. k EXP 3) = (nsum(0..(n-1)) (\k. k EXP 2)) EXP 2`;;
