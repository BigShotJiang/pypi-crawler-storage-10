let algebra-others-exirrpowirrrat = `?a:real b:real. ~rational a /\ ~rational b /\ rational (exp (b * ln a))`;;
