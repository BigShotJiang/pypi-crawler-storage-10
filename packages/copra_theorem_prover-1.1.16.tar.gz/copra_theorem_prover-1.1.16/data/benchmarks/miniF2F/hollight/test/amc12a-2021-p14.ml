let amc12a-2021-p14 = `sum (1..(21-1)) (\k. ln (&(3 EXP (k EXP 2))) / ln (&(5 EXP k))) * sum (1..(101-1)) (\k. ln (&(25 EXP k)) / ln (&(9 EXP k))) = &21000`;;
