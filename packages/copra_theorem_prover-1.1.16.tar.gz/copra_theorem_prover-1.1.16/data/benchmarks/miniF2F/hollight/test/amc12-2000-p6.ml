let amc12-2000-p6 = let amc12-2000-p6 = `!p q. (prime p /\ prime q) /\ (4 <= p /\ p <= 18) /\ (4 <= q /\ q <= 18) ==> ~(p * q - (p + q) = 194)`;;
