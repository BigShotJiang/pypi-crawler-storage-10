let amc12a-2002-p6 = `!n. ~(n = 0) ==> (?m. m > n /\ ?p. m * p <= m + p )`;;

