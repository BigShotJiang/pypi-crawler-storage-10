let amc12b-2021-p18 = `!z:complex.
    (&12 * (norm z) pow 2 = &2 * (norm (z + Cx (&2))) pow 2 + (norm (z pow 2 + Cx (&1))) pow 2 + &31)
==>
    z + Cx (&6) / z = -- Cx(&2)`;;
