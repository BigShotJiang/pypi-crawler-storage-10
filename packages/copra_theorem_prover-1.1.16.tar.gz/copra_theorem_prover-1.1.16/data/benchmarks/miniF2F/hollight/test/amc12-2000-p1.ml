let amc12-2000-p1 = let amc12-2000-p1 = `!i m n. ~(i = m) /\ ~(m = n) /\ ~(n = i) /\ (i * m * n = 2001) ==> i + m + n <= 671`;;
