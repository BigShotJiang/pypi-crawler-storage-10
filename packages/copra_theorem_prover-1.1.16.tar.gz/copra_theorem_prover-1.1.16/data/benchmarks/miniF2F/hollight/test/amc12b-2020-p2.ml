let amc12b-2020-p2 = `real_of_int (int_of_num (100 EXP 2) - &(7 EXP 2)) / real_of_int (int_of_num (70 EXP 2) - &(11 EXP 2)) * (&(70 - 11) * &(70 + 11) / &((100 - 7) * (100 + 7))) = &1`;;
