let induction-1pxpownlt1pnx = `!x n. n > 0 /\ -- &1 < x ==> (&1 + x) pow n <= &1 + &n * x`;;
