let amc12b-2002-p19 = `!a:real b:real c:real.
    (&0 < a /\ &0 < b /\ &0 < c) /\
    (a * (b + c) = &152) /\
    (b * (c + a) = &162) /\
    (c * (a + b) = &170)
    ==> a * b * c = &720`;;
