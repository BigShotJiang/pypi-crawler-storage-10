let algebra-sqineq-unitcircatbpamblt1 = `!a:real b:real. (a pow 2 + b pow 2 = &1) ==> a * b + (a - b) <= &1`;;
