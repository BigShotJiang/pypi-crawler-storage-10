let amc12b-2020-p13 = `sqrt (ln (&6) / ln (&2) + ln (&6) / ln (&3)) = sqrt (ln (&3) / ln (&2)) + sqrt (ln (&2) / ln (&3))`;;
