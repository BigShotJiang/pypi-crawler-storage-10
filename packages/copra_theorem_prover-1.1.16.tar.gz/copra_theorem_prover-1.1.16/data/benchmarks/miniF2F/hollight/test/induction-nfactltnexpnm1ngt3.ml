let induction-nfactltnexpnm1ngt3 = `!n. 3 <= n ==> FACT n < n EXP (n - 1)`;;
