let amc12-2000-p12 = `!a m c. (a + m + c = 12) ==> a * m * c + a * m + m * c + a * c <= 112`;;
