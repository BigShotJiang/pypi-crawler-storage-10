let amc12b-2020-p22 = `!t:real. ((exp (t * ln (&2)) - &3 * t) * t) / (exp(t * ln (&4))) <= &1 / &12`;;
