let induction-12dvd4expnp1p20 = `!n. 12 divides 4 EXP (n+1) + 20`;;
