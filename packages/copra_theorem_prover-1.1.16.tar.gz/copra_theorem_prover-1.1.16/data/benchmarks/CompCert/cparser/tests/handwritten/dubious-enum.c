int f (void)
{
  int x = sizeof(enum e;
  /* Maybe a closing parenthesis is missing,
     maybe also "enum e" could be continued with an opening brace.
     Our message ignores the latter possibility. */
}
