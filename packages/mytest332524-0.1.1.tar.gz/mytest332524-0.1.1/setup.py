from setuptools import setup, find_packages

setup(
    name="mytest332524",
    version="0.1.1",
    author="mysathish",
    author_email="sathishdhuda25@gmail.com",
    description="test module",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
