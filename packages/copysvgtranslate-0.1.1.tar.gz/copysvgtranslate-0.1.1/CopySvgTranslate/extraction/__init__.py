"""Extraction phase helpers for CopySvgTranslate."""

from .extractor import extract

__all__ = ["extract"]
