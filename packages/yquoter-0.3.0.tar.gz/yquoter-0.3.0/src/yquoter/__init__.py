# yquoter/__init__.py
# Copyright 2025 Yodeesy
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0

"""Yquoter: A unified financial data interface and analysis toolkit for CN/HK/US markets."""

__version__ = "0.3.0"
__author__ = "Yquoter Team"
__email__ = "yodeeshi@gmail.com"

import logging

# ----------------------------------------------------------------------
# Logging setup
# ----------------------------------------------------------------------
from yquoter.logger import setup_logging, get_logger
setup_logging(level=logging.WARNING)
logger = get_logger(__name__)

# ----------------------------------------------------------------------
# Core imports
# ----------------------------------------------------------------------
from yquoter.config import get_newest_df_path
from yquoter.datasource import register_source, set_default_source
from yquoter.models import Stock
from yquoter.exceptions import TuShareNotImportableError
from yquoter.compat import (
    get_stock_history,
    get_stock_realtime,
    get_stock_financials,
    get_stock_profile,
    get_stock_factors,
    get_rsi_n,
    get_max_drawdown,
    get_boll_n,
    get_rv_n,
    get_vol_ratio,
    get_ma_n,
    generate_stock_report
)

# ----------------------------------------------------------------------
# Cache initialization
# ----------------------------------------------------------------------
def init_cache_manager(max_entries: int = 50):
    """
    Initialize the cache manager.

    Args:
        max_entries (int): Max number of cached files. Default is 50.
    """
    from .cache import init_cache, set_max_cache_entries
    set_max_cache_entries(max_entries)
    init_cache()
    logging.getLogger(__name__).info(
        f"Cache manager initialized, max cache entries: {max_entries}"
    )


# Auto-initialize cache (safe-guarded)
try:
    init_cache_manager()
except Exception as e:
    logging.getLogger(__name__).warning(f"Cache manager init failed: {e}")


# ----------------------------------------------------------------------
# TuShare initialization
# ----------------------------------------------------------------------
def init_tushare(token: str = None):
    """
    Initialize TuShare data source.

    Args:
        token (str, optional): TuShare API token.
    """
    try:
        from .tushare_source import init_tushare as _ts_init
        _ts_init(token)
    except TuShareNotImportableError as e:
        logger.error(
            "Tushare library not found. Please install it to use the Tushare data source: "
            "pip install yquoter[tushare] or pip install tushare"
        )
        raise e
    except ImportError:
        logger.error("Failed to load tushare_source module. Check package integrity.")
        raise

# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------
__all__ = [
    "register_source",
    "set_default_source",
    "init_tushare",
    "Stock",
    "get_stock_history",
    "get_stock_realtime",
    "get_stock_factors",
    "get_stock_profile",
    "get_stock_financials",
    "get_ma_n",
    "get_boll_n",
    "get_max_drawdown",
    "get_vol_ratio",
    "get_newest_df_path",
    "get_rsi_n",
    "get_rv_n",
    "init_cache_manager",
    "generate_stock_report"
]

