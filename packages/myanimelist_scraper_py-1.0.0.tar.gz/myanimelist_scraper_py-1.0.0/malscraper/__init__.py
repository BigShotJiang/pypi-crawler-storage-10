from .malscraper import (
    Anime,
    Manga,
    animesearch,
    animeinfo,
    animeinfoID,
    mangasearch,
    mangainfo,
    mangainfoID,
    topanime,
    topmanga,
)
