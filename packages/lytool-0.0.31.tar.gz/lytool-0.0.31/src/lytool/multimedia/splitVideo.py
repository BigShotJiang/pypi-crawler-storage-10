from lytool.audioAndVideo.splitVideo import splitDirVideo
from lytool.audioAndVideo.splitVideo import splitOneVideo

if __name__ == '__main__':
    # 切割指定目录中所有的mp4，用mp4的文件名作为输出名——文件夹名、m3u8名
    splitDirVideo(r'E:\project\program\ly_dictation\lyd_db\video\videoLibrary\re_primarySchool')

    # 切割一个指定的mp4
    # input_file = '../video/primarySchool/mp4+srt/level1_upper_unit2/level1_upper_unit2.mp4'
    # output_dir = '../video/primarySchool/m3u8/level1_upper_unit2'
    # output_file_name = 'level1_upper_unit2'
    # splitOneVideo(input_file, output_dir, output_file_name)

