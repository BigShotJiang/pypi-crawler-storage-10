DEFINE_XML_FILE_NAME: str = "define.xml"
ODM_NAMESPACE: str = "http://www.cdisc.org/ns/odm/v1.3"
