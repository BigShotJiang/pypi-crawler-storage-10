from cdisc_rules_engine.operations.operations_factory import OperationsFactory

operations_factory = OperationsFactory()
