"""Plugins for SpectraFit."""
