"""Services module."""

from mcpbundles_proxy.services.browser import BrowserService

__all__ = ['BrowserService']

