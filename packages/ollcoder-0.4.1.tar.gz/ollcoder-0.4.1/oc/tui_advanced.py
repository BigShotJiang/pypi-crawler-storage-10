"""
Advanced TUI for Ollcoder with full feature set.

This is a comprehensive TUI implementation including:
- Context Builder
- Memory Viewer  
- Autonomous Agent
- Security Scanner
- Code Diff Preview
- Session Management
- Streaming Responses
- File Editor
- Settings Panel
- Chat Search/Filter
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional
import json
import asyncio

try:
    from textual.app import App, ComposeResult
    from textual.containers import Container, Horizontal, Vertical, ScrollableContainer, VerticalScroll
    from textual.widgets import (
        Header, Footer, DirectoryTree, Input, Static, Label, 
        Button, SelectionList, OptionList, ListView, ListItem, Markdown,
        TabbedContent, TabPane, TextArea, ProgressBar, DataTable, Tree
    )
    from textual.widgets.option_list import Option
    from textual.binding import Binding
    from textual.screen import Screen, ModalScreen
    from textual import events, work
    from textual.message import Message
    from textual.reactive import reactive
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False

import re


# ==================== Modal Screens ====================

class ContextBuilderScreen(ModalScreen):
    """Build and view codebase context."""
    
    def compose(self) -> ComposeResult:
        with Container(id="context-dialog"):
            yield Static("[bold cyan]Context Builder[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Enter query (e.g. 'authentication')", id="query-input")
            
            with Horizontal(id="compression-select"):
                yield Static("Compression: ")
                yield OptionList(
                    Option("NONE", id="NONE"),
                    Option("SEMANTIC", id="SEMANTIC"),
                    Option("HEURISTIC", id="HEURISTIC"),
                    Option("MODERATE", id="MODERATE"),
                    Option("SUMMARY", id="SUMMARY"),
                    id="compression-list"
                )
            
            yield ScrollableContainer(
                Static("Context will appear here...", id="context-output"),
                id="context-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build", variant="primary", id="build-btn")
                yield Button("Copy", variant="default", id="copy-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss(None)
        elif event.button.id == "build-btn":
            self.build_context()
        elif event.button.id == "copy-btn":
            # TODO: Copy to clipboard
            pass
    
    def build_context(self) -> None:
        """Build context from query."""
        query_input = self.query_one("#query-input", Input)
        query = query_input.value.strip()
        
        if not query:
            return
        
        # TODO: Integrate with actual context builder
        output = self.query_one("#context-output", Static)
        output.update(f"[cyan]Building context for:[/cyan] {query}\\n\\n[dim]Loading...[/dim]")


class MemoryViewerScreen(ModalScreen):
    """View agent memory sessions and learned patterns."""
    
    def compose(self) -> ComposeResult:
        with Container(id="memory-dialog"):
            yield Static("[bold cyan]Memory Viewer[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="sessions"):
                with TabPane("Sessions", id="sessions"):
                    yield ScrollableContainer(
                        Static("Loading sessions...", id="sessions-list"),
                        id="sessions-scroll"
                    )
                
                with TabPane("Patterns", id="patterns"):
                    yield ScrollableContainer(
                        Static("Loading patterns...", id="patterns-list"),
                        id="patterns-scroll"
                    )
                
                with TabPane("Errors", id="errors"):
                    yield ScrollableContainer(
                        Static("Loading errors...", id="errors-list"),
                        id="errors-scroll"
                    )
            
            yield Button("Close", variant="primary", id="close-btn")
    
    def on_mount(self) -> None:
        """Load memory data on mount."""
        self.load_memory()
    
    def load_memory(self) -> None:
        """Load memory from store."""
        # TODO: Integrate with actual memory store
        pass
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class AgentRunnerScreen(ModalScreen):
    """Run autonomous agent tasks with progress tracking."""
    
    def compose(self) -> ComposeResult:
        with Container(id="agent-dialog"):
            yield Static("[bold cyan]Autonomous Agent[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Enter task (e.g. 'Add error handling to API')", id="task-input")
            
            with Horizontal():
                yield Static("Max Steps: ")
                yield Input(value="6", id="steps-input")
            
            with Horizontal():
                yield Static("Apply Changes: ")
                yield Button("Yes", variant="primary", id="apply-yes")
                yield Button("No", variant="default", id="apply-no")
            
            yield ProgressBar(total=100, show_eta=False, id="progress-bar")
            
            yield ScrollableContainer(
                Static("Agent output will appear here...", id="agent-output"),
                id="agent-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Run", variant="primary", id="run-btn")
                yield Button("Stop", variant="error", id="stop-btn", disabled=True)
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "run-btn":
            self.run_agent()
        elif event.button.id == "stop-btn":
            self.stop_agent()
    
    def run_agent(self) -> None:
        """Start agent execution."""
        # TODO: Integrate with actual agent
        pass
    
    def stop_agent(self) -> None:
        """Stop agent execution."""
        # TODO: Implement stop
        pass


class SecurityScannerScreen(ModalScreen):
    """Display security scan results."""
    
    def compose(self) -> ComposeResult:
        with Container(id="security-dialog"):
            yield Static("[bold cyan]Security Scanner[/bold cyan]", id="dialog-title")
            
            yield DataTable(id="security-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Scan", variant="primary", id="scan-btn")
                yield Button("Export SARIF", variant="default", id="export-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table on mount."""
        table = self.query_one(DataTable)
        table.add_columns("Severity", "File", "Line", "Rule", "Message")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "scan-btn":
            self.run_scan()
        elif event.button.id == "export-btn":
            self.export_sarif()
    
    def run_scan(self) -> None:
        """Run security scan."""
        # TODO: Integrate with security.scan()
        pass
    
    def export_sarif(self) -> None:
        """Export scan results to SARIF."""
        # TODO: Implement export
        pass


class DiffViewerScreen(ModalScreen):
    """Preview code diffs before applying."""
    
    def compose(self) -> ComposeResult:
        with Container(id="diff-dialog"):
            yield Static("[bold cyan]Code Diff Preview[/bold cyan]", id="dialog-title")
            
            yield ScrollableContainer(
                TextArea("", language="diff", id="diff-content"),
                id="diff-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Apply", variant="primary", id="apply-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(False)
        elif event.button.id == "apply-btn":
            self.dismiss(True)


class FileEditorScreen(ModalScreen):
    """Simple file editor."""
    
    def __init__(self, filepath: str, content: str):
        super().__init__()
        self.filepath = filepath
        self.content = content
    
    def compose(self) -> ComposeResult:
        with Container(id="editor-dialog"):
            yield Static(f"[bold cyan]Editing: {self.filepath}[/bold cyan]", id="dialog-title")
            
            yield TextArea(self.content, language="python", id="editor-content")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Save", variant="primary", id="save-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "save-btn":
            editor = self.query_one("#editor-content", TextArea)
            self.dismiss(editor.text)


class SettingsScreen(ModalScreen):
    """Configure TUI settings."""
    
    def compose(self) -> ComposeResult:
        with Container(id="settings-dialog"):
            yield Static("[bold cyan]Settings[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="general"):
                with TabPane("General", id="general"):
                    yield Label("Compression Level:")
                    yield OptionList(
                        Option("NONE", id="NONE"),
                        Option("SEMANTIC", id="SEMANTIC"),
                        Option("MODERATE", id="MODERATE", selected=True),
                        Option("SUMMARY", id="SUMMARY"),
                        id="compression-setting"
                    )
                
                with TabPane("Trust", id="trust"):
                    yield Label("Default Trust Level:")
                    yield OptionList(
                        Option("OWNER", id="OWNER"),
                        Option("HIGH", id="HIGH"),
                        Option("MEDIUM", id="MEDIUM", selected=True),
                        Option("LOW", id="LOW"),
                        id="trust-setting"
                    )
                
                with TabPane("Memory", id="memory"):
                    yield Label("Enable Memory:")
                    yield Button("On", variant="primary", id="memory-on")
                    yield Button("Off", variant="default", id="memory-off")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Save", variant="primary", id="save-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "save-btn":
            # TODO: Save settings
            self.dismiss(True)


class SearchScreen(ModalScreen):
    """Search and filter chat messages."""
    
    def compose(self) -> ComposeResult:
        with Container(id="search-dialog"):
            yield Static("[bold cyan]Search Chat[/bold cyan]", id="dialog-title")
            yield Input(placeholder="Search messages...", id="search-input")
            
            yield Label("Filter by:")
            yield OptionList(
                Option("All", id="all", selected=True),
                Option("User", id="user"),
                Option("Assistant", id="assistant"),
                id="filter-list"
            )
            
            yield ScrollableContainer(
                Static("Search results will appear here...", id="search-results"),
                id="results-scroll"
            )
            
            yield Button("Close", variant="primary", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss()


class TrustManagerScreen(ModalScreen):
    """Manage trusted folders and their access levels."""
    
    def compose(self) -> ComposeResult:
        with Container(id="trust-dialog"):
            yield Static("[bold cyan]Trust Manager[/bold cyan]", id="dialog-title")
            
            yield DataTable(id="trust-table")
            
            with Horizontal():
                yield Input(placeholder="Path to add...", id="path-input")
                yield OptionList(
                    Option("OWNER", id="OWNER"),
                    Option("HIGH", id="HIGH"),
                    Option("MEDIUM", id="MEDIUM"),
                    Option("LOW", id="LOW"),
                    id="trust-level"
                )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Add", variant="primary", id="add-btn")
                yield Button("Remove", variant="error", id="remove-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table on mount."""
        table = self.query_one(DataTable)
        table.add_columns("Path", "Trust Level", "Allowed Actions")
        self.load_trust_data()
    
    def load_trust_data(self) -> None:
        """Load current trust configuration."""
        # TODO: Integrate with trusted_folders.py
        pass
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "add-btn":
            self.add_trust_entry()
        elif event.button.id == "remove-btn":
            self.remove_trust_entry()
    
    def add_trust_entry(self) -> None:
        """Add new trust entry."""
        # TODO: Implement
        pass
    
    def remove_trust_entry(self) -> None:
        """Remove selected trust entry."""
        # TODO: Implement
        pass


class ChecksRunnerScreen(ModalScreen):
    """Run linters and tests, display results."""
    
    def compose(self) -> ComposeResult:
        with Container(id="checks-dialog"):
            yield Static("[bold cyan]Checks Runner[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="ruff"):
                with TabPane("Ruff", id="ruff"):
                    yield ScrollableContainer(
                        Static("Ruff results will appear here...", id="ruff-output"),
                        id="ruff-scroll"
                    )
                
                with TabPane("Mypy", id="mypy"):
                    yield ScrollableContainer(
                        Static("Mypy results will appear here...", id="mypy-output"),
                        id="mypy-scroll"
                    )
                
                with TabPane("Tests", id="tests"):
                    yield ScrollableContainer(
                        Static("Test results will appear here...", id="test-output"),
                        id="test-scroll"
                    )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Run All", variant="primary", id="run-all-btn")
                yield Button("Run Ruff", variant="default", id="run-ruff-btn")
                yield Button("Run Mypy", variant="default", id="run-mypy-btn")
                yield Button("Run Tests", variant="default", id="run-tests-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "run-all-btn":
            self.run_all_checks()
        elif event.button.id == "run-ruff-btn":
            self.run_ruff()
        elif event.button.id == "run-mypy-btn":
            self.run_mypy()
        elif event.button.id == "run-tests-btn":
            self.run_tests()
    
    def run_all_checks(self) -> None:
        """Run all checks."""
        # TODO: Integrate with checks.py
        pass
    
    def run_ruff(self) -> None:
        """Run ruff linter."""
        # TODO: Implement
        pass
    
    def run_mypy(self) -> None:
        """Run mypy type checker."""
        # TODO: Implement
        pass
    
    def run_tests(self) -> None:
        """Run pytest."""
        # TODO: Implement
        pass


class MultiRepoScreen(ModalScreen):
    """Manage multiple repository roots."""
    
    def compose(self) -> ComposeResult:
        with Container(id="multi-dialog"):
            yield Static("[bold cyan]Multi-Repo Manager[/bold cyan]", id="dialog-title")
            
            yield Label("Active Repositories:")
            yield SelectionList(id="repo-list")
            
            with Horizontal():
                yield Input(placeholder="Path to add...", id="repo-path-input")
                yield Button("Add", variant="primary", id="add-repo-btn")
            
            yield ScrollableContainer(
                Static("Combined context will appear here...", id="multi-context"),
                id="context-scroll"
            )
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build Context", variant="primary", id="build-btn")
                yield Button("Remove Selected", variant="error", id="remove-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "add-repo-btn":
            self.add_repository()
        elif event.button.id == "remove-btn":
            self.remove_repository()
        elif event.button.id == "build-btn":
            self.build_multi_context()
    
    def add_repository(self) -> None:
        """Add repository to list."""
        # TODO: Implement
        pass
    
    def remove_repository(self) -> None:
        """Remove selected repository."""
        # TODO: Implement
        pass
    
    def build_multi_context(self) -> None:
        """Build context across all repos."""
        # TODO: Integrate with multi.py
        pass


class EcoDashboardScreen(ModalScreen):
    """Carbon tracking and complexity metrics."""
    
    def compose(self) -> ComposeResult:
        with Container(id="eco-dialog"):
            yield Static("[bold cyan]Eco Dashboard[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="carbon"):
                with TabPane("Carbon", id="carbon"):
                    yield Static("Estimated CO2: Loading...", id="carbon-stats")
                    yield ProgressBar(id="carbon-bar")
                    yield ScrollableContainer(
                        Static("Carbon details...", id="carbon-details"),
                        id="carbon-scroll"
                    )
                
                with TabPane("Complexity", id="complexity"):
                    yield DataTable(id="complexity-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Analyze", variant="primary", id="analyze-btn")
                yield Button("Export", variant="default", id="export-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup complexity table."""
        table = self.query_one("#complexity-table", DataTable)
        table.add_columns("File", "Complexity", "Maintainability", "Issues")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "analyze-btn":
            self.run_analysis()
        elif event.button.id == "export-btn":
            self.export_results()
    
    def run_analysis(self) -> None:
        """Run eco analysis."""
        # TODO: Integrate with eco.py
        pass
    
    def export_results(self) -> None:
        """Export analysis results."""
        pass


class EthicsScannerScreen(ModalScreen):
    """Bias and ethics detection."""
    
    def compose(self) -> ComposeResult:
        with Container(id="ethics-dialog"):
            yield Static("[bold cyan]Ethics Scanner[/bold cyan]", id="dialog-title")
            
            yield DataTable(id="ethics-table")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Scan", variant="primary", id="scan-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_mount(self) -> None:
        """Setup table."""
        table = self.query_one(DataTable)
        table.add_columns("File", "Line", "Category", "Term", "Suggestion")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "scan-btn":
            self.run_scan()
    
    def run_scan(self) -> None:
        """Run ethics scan."""
        # TODO: Integrate with ethics.py
        pass


class BlockchainViewerScreen(ModalScreen):
    """View and verify code signatures."""
    
    def compose(self) -> ComposeResult:
        with Container(id="blockchain-dialog"):
            yield Static("[bold cyan]Blockchain Viewer[/bold cyan]", id="dialog-title")
            
            with TabbedContent(initial="manifest"):
                with TabPane("Manifest", id="manifest"):
                    yield ScrollableContainer(
                        Static("Manifest will appear here...", id="manifest-content"),
                        id="manifest-scroll"
                    )
                
                with TabPane("Signature", id="signature"):
                    yield ScrollableContainer(
                        Static("Signature details...", id="signature-content"),
                        id="signature-scroll"
                    )
                
                with TabPane("Verify", id="verify"):
                    yield Input(placeholder="Public key path...", id="pubkey-input")
                    yield Input(placeholder="Signature path...", id="sig-input")
                    yield Static("Verification result will appear here...", id="verify-result")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Build Manifest", variant="primary", id="manifest-btn")
                yield Button("Sign", variant="default", id="sign-btn")
                yield Button("Verify", variant="default", id="verify-btn")
                yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "manifest-btn":
            self.build_manifest()
        elif event.button.id == "sign-btn":
            self.sign_manifest()
        elif event.button.id == "verify-btn":
            self.verify_signature()
    
    def build_manifest(self) -> None:
        """Build code manifest."""
        # TODO: Integrate with blockchain.py
        pass
    
    def sign_manifest(self) -> None:
        """Sign manifest."""
        pass
    
    def verify_signature(self) -> None:
        """Verify signature."""
        pass


class WebFetchScreen(ModalScreen):
    """Fetch and display web content."""
    
    def compose(self) -> ComposeResult:
        with Container(id="web-dialog"):
            yield Static("[bold cyan]Web Fetch[/bold cyan]", id="dialog-title")
            
            with Horizontal():
                yield Input(placeholder="Enter URL...", id="url-input")
                yield Button("Fetch", variant="primary", id="fetch-btn")
            
            yield ScrollableContainer(
                Markdown("", id="web-content"),
                id="web-scroll"
            )
            
            yield Button("Close", variant="default", id="close-btn")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "close-btn":
            self.dismiss()
        elif event.button.id == "fetch-btn":
            self.fetch_url()
    
    def fetch_url(self) -> None:
        """Fetch URL content."""
        # TODO: Integrate with web_fetch.py
        pass


# ==================== Session Management ====================

class SessionManager:
    """Manage chat sessions."""
    
    def __init__(self, root: str):
        self.root = Path(root)
        self.sessions_dir = Path.home() / ".ollcoder" / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.current_session: Optional[str] = None
    
    def list_sessions(self) -> list[tuple[str, float]]:
        """List all sessions with timestamps."""
        sessions = []
        for f in self.sessions_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                sessions.append((f.stem, data.get("timestamp", 0)))
            except Exception:
                pass
        return sorted(sessions, key=lambda x: x[1], reverse=True)
    
    def save_session(self, session_id: str, messages: list[dict], metadata: dict) -> None:
        """Save session to disk."""
        filepath = self.sessions_dir / f"{session_id}.json"
        data = {
            "session_id": session_id,
            "timestamp": metadata.get("timestamp", 0),
            "root": str(self.root),
            "messages": messages,
            "metadata": metadata
        }
        filepath.write_text(json.dumps(data, indent=2))
    
    def load_session(self, session_id: str) -> Optional[dict]:
        """Load session from disk."""
        filepath = self.sessions_dir / f"{session_id}.json"
        if not filepath.exists():
            return None
        try:
            return json.loads(filepath.read_text())
        except Exception:
            return None


# ==================== Enhanced Chat Panel ====================

class EnhancedChatPanel(ScrollableContainer):
    """Enhanced chat panel with search and filtering."""
    
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.messages: list[tuple[str, str]] = []
        self.filter_role: Optional[str] = None
        self.search_query: str = ""
    
    def add_message(self, role: str, content: str, stream: bool = False) -> None:
        """Add a message to chat."""
        self.messages.append((role, content))
        
        # Apply filters
        if self.filter_role and role != self.filter_role:
            return
        if self.search_query and self.search_query.lower() not in content.lower():
            return
        
        role_style = "bold cyan" if role == "assistant" else "bold green"
        role_label = "🤖 Assistant" if role == "assistant" else "👤 You"
        
        msg_text = f"[{role_style}]{role_label}[/{role_style}]\n{content}\n"
        msg = Static(msg_text)
        self.mount(msg)
        msg.scroll_visible()
    
    def filter_messages(self, role: Optional[str] = None, query: str = "") -> None:
        """Filter displayed messages."""
        self.filter_role = role
        self.search_query = query
        self.remove_children()
        
        for msg_role, content in self.messages:
            if role and msg_role != role:
                continue
            if query and query.lower() not in content.lower():
                continue
            self.add_message(msg_role, content)


class SessionSelectorScreen(ModalScreen):
    """Select or create sessions."""
    
    def __init__(self, session_manager: SessionManager):
        super().__init__()
        self.session_manager = session_manager
    
    def compose(self) -> ComposeResult:
        with Container(id="session-dialog"):
            yield Static("[bold cyan]Session Manager[/bold cyan]", id="dialog-title")
            
            sessions = self.session_manager.list_sessions()
            options = [Option(f"{sid} ({self._format_time(ts)})", id=sid) 
                      for sid, ts in sessions]
            
            if not options:
                options = [Option("No saved sessions", id="", disabled=True)]
            
            yield OptionList(*options, id="session-list")
            
            with Horizontal(id="dialog-buttons"):
                yield Button("Load", variant="primary", id="load-btn")
                yield Button("New", variant="default", id="new-btn")
                yield Button("Delete", variant="error", id="delete-btn")
                yield Button("Cancel", variant="default", id="cancel-btn")
    
    def _format_time(self, timestamp: float) -> str:
        """Format timestamp."""
        import datetime
        dt = datetime.datetime.fromtimestamp(timestamp)
        return dt.strftime("%Y-%m-%d %H:%M")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "load-btn":
            option_list = self.query_one("#session-list", OptionList)
            if option_list.highlighted is not None:
                selected = option_list.get_option_at_index(option_list.highlighted)
                if selected.id:
                    self.dismiss({"action": "load", "session_id": selected.id})
        elif event.button.id == "new-btn":
            self.dismiss({"action": "new"})
        elif event.button.id == "delete-btn":
            # TODO: Implement delete
            pass


# ==================== Main Advanced TUI ====================

class OllcoderAdvancedTUI(App):
    """Advanced Ollcoder TUI with all features."""
    
    CSS = """
    /* Inherit base styles and add advanced features */
    Screen {
        background: #000000;
    }
    
    Header {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    Footer {
        background: #0a0a0a;
        color: #00ff88;
    }
    
    #sidebar {
        width: 30;
        background: #0a0a0a;
        border-right: solid #00ff88;
    }
    
    #chat-container {
        width: 1fr;
        background: #000000;
    }
    
    TabbedContent {
        height: 1fr;
    }
    
    EnhancedChatPanel {
        background: #000000;
        padding: 1;
    }
    
    #input-container {
        height: 3;
        background: #0a0a0a;
        padding: 0 1;
    }
    
    Input {
        background: #0a0a0a;
        color: #00ff88;
        border: solid #00ff88;
    }
    
    DirectoryTree {
        padding: 1;
        background: #0a0a0a;
        color: #888888;
    }
    
    Static {
        color: #cccccc;
    }
    
    /* Advanced feature dialogs */
    ModalScreen {
        align: center middle;
    }
    
    #context-dialog, #memory-dialog, #agent-dialog, 
    #security-dialog, #diff-dialog, #editor-dialog,
    #settings-dialog, #search-dialog, #session-dialog {
        width: 80;
        height: 40;
        background: #0a0a0a;
        border: solid #00ff88;
        padding: 2;
    }
    
    DataTable {
        height: 1fr;
        background: #000000;
    }
    
    TextArea {
        height: 1fr;
        background: #000000;
        border: solid #00ff88;
    }
    
    ProgressBar {
        background: #0a0a0a;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", priority=True),
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+l", "clear_chat", "Clear"),
        Binding("ctrl+m", "change_model", "Model"),
        Binding("ctrl+n", "new_file", "New File"),
        Binding("ctrl+p", "command_palette", "Commands"),
        Binding("ctrl+e", "export_chat", "Export"),
        # Advanced features - Core
        Binding("ctrl+b", "context_builder", "Context"),
        Binding("ctrl+r", "run_agent", "Agent"),
        Binding("ctrl+k", "security_scan", "Security"),
        Binding("ctrl+t", "trust_manager", "Trust"),
        Binding("ctrl+w", "web_fetch", "Web"),
        # Advanced features - Shift variants
        Binding("ctrl+shift+m", "view_memory", "Memory"),
        Binding("ctrl+shift+s", "manage_sessions", "Sessions"),
        Binding("ctrl+shift+f", "search_chat", "Search"),
        Binding("ctrl+shift+e", "edit_file", "Edit"),
        Binding("ctrl+shift+c", "checks_runner", "Checks"),
        Binding("ctrl+shift+r", "multi_repo", "Multi-Repo"),
        Binding("ctrl+shift+o", "eco_dashboard", "Eco"),
        Binding("ctrl+shift+t", "ethics_scan", "Ethics"),
        Binding("ctrl+shift+b", "blockchain_view", "Blockchain"),
        # Settings
        Binding("ctrl+comma", "settings", "Settings"),
    ]
    
    def __init__(self, root: str, provider: Any, model: str):
        super().__init__()
        self.root = root
        self.provider = provider
        self.model = model
        self.session_manager = SessionManager(root)
        self.messages: list[dict[str, str]] = [
            {"role": "system", "content": (
                "You are a helpful coding assistant with access to the codebase.\n"
                "Be conversational and concise. Provide context when helpful."
            )},
        ]
        self.streaming_enabled = True
    
    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()
        
        with Horizontal():
            with Vertical(id="sidebar"):
                yield Static(
                    f"[bold cyan]🤖 Ollcoder Advanced[/bold cyan]\n"
                    f"Model: {self.model}\n"
                    f"Project: {Path(self.root).name}",
                    id="info-panel"
                )
                yield DirectoryTree(self.root)
            
            with Vertical(id="chat-container"):
                with TabbedContent(initial="chat-1"):
                    with TabPane("Chat 1", id="chat-1"):
                        yield EnhancedChatPanel(id="chat-panel-1")
                    with TabPane("Chat 2", id="chat-2"):
                        yield EnhancedChatPanel(id="chat-panel-2")
                with Container(id="input-container"):
                    yield Input(placeholder="Type your message... (Ctrl+B: Context, Ctrl+R: Agent)", id="chat-input")
        
        yield Footer()
    
    def on_mount(self) -> None:
        """Handle app mount."""
        chat_panel = self.query_one("#chat-panel-1", EnhancedChatPanel)
        chat_panel.add_message(
            "assistant",
            "👋 Welcome to Ollcoder Advanced!\n\n"
            "**Quick Actions:**\n"
            "• Ctrl+B - Build Context\n"
            "• Ctrl+R - Run Agent\n"
            "• Ctrl+K - Security Scan\n"
            "• Ctrl+Shift+M - View Memory\n"
            "• Ctrl+Comma - Settings"
        )
        self.query_one("#chat-input", Input).focus()
    
    def _get_active_chat_panel(self) -> EnhancedChatPanel:
        """Get currently active chat panel."""
        tabbed = self.query_one(TabbedContent)
        active_tab = tabbed.active
        if active_tab == "chat-1":
            return self.query_one("#chat-panel-1", EnhancedChatPanel)
        else:
            return self.query_one("#chat-panel-2", EnhancedChatPanel)
    
    # ==================== Actions ====================
    
    def action_context_builder(self) -> None:
        """Open context builder."""
        async def show_builder():
            await self.push_screen_wait(ContextBuilderScreen())
        self.run_worker(show_builder())
    
    def action_view_memory(self) -> None:
        """Open memory viewer."""
        async def show_memory():
            await self.push_screen_wait(MemoryViewerScreen())
        self.run_worker(show_memory())
    
    def action_run_agent(self) -> None:
        """Open agent runner."""
        async def show_agent():
            await self.push_screen_wait(AgentRunnerScreen())
        self.run_worker(show_agent())
    
    def action_security_scan(self) -> None:
        """Open security scanner."""
        async def show_scanner():
            await self.push_screen_wait(SecurityScannerScreen())
        self.run_worker(show_scanner())
    
    def action_manage_sessions(self) -> None:
        """Open session manager."""
        async def show_sessions():
            result = await self.push_screen_wait(SessionSelectorScreen(self.session_manager))
            if result:
                if result["action"] == "load":
                    self.load_session(result["session_id"])
                elif result["action"] == "new":
                    self.new_session()
        self.run_worker(show_sessions())
    
    def action_search_chat(self) -> None:
        """Open chat search."""
        async def show_search():
            await self.push_screen_wait(SearchScreen())
        self.run_worker(show_search())
    
    def action_edit_file(self) -> None:
        """Open file editor."""
        # TODO: Get selected file from tree
        pass
    
    def action_settings(self) -> None:
        """Open settings."""
        async def show_settings():
            await self.push_screen_wait(SettingsScreen())
        self.run_worker(show_settings())
    
    def action_trust_manager(self) -> None:
        """Open trust manager."""
        async def show_trust():
            await self.push_screen_wait(TrustManagerScreen())
        self.run_worker(show_trust())
    
    def action_checks_runner(self) -> None:
        """Open checks runner."""
        async def show_checks():
            await self.push_screen_wait(ChecksRunnerScreen())
        self.run_worker(show_checks())
    
    def action_multi_repo(self) -> None:
        """Open multi-repo manager."""
        async def show_multi():
            await self.push_screen_wait(MultiRepoScreen())
        self.run_worker(show_multi())
    
    def action_eco_dashboard(self) -> None:
        """Open eco dashboard."""
        async def show_eco():
            await self.push_screen_wait(EcoDashboardScreen())
        self.run_worker(show_eco())
    
    def action_ethics_scan(self) -> None:
        """Open ethics scanner."""
        async def show_ethics():
            await self.push_screen_wait(EthicsScannerScreen())
        self.run_worker(show_ethics())
    
    def action_blockchain_view(self) -> None:
        """Open blockchain viewer."""
        async def show_blockchain():
            await self.push_screen_wait(BlockchainViewerScreen())
        self.run_worker(show_blockchain())
    
    def action_web_fetch(self) -> None:
        """Open web fetch panel."""
        async def show_web():
            await self.push_screen_wait(WebFetchScreen())
        self.run_worker(show_web())
    
    def action_clear_chat(self) -> None:
        """Clear current chat."""
        chat_panel = self._get_active_chat_panel()
        chat_panel.remove_children()
        chat_panel.messages.clear()
        self.messages = self.messages[:1]
        chat_panel.add_message("assistant", "Chat cleared!")
    
    def action_change_model(self) -> None:
        """Change AI model."""
        # Reuse from original TUI
        pass
    
    def action_new_file(self) -> None:
        """Create new file."""
        # Reuse from original TUI
        pass
    
    def action_export_chat(self) -> None:
        """Export chat to markdown."""
        # Reuse from original TUI
        pass
    
    def action_command_palette(self) -> None:
        """Show command palette."""
        # Reuse from original TUI
        pass
    
    # ==================== Session Management ====================
    
    def load_session(self, session_id: str) -> None:
        """Load a saved session."""
        data = self.session_manager.load_session(session_id)
        if data:
            self.messages = data.get("messages", [])
            chat_panel = self._get_active_chat_panel()
            chat_panel.remove_children()
            chat_panel.messages.clear()
            for msg in self.messages[1:]:  # Skip system message
                chat_panel.add_message(msg["role"], msg["content"])
    
    def new_session(self) -> None:
        """Start a new session."""
        import time
        session_id = f"session_{int(time.time())}"
        self.session_manager.current_session = session_id
        self.action_clear_chat()
    
    def save_current_session(self) -> None:
        """Save current session."""
        import time
        if not self.session_manager.current_session:
            self.session_manager.current_session = f"session_{int(time.time())}"
        
        metadata = {
            "timestamp": time.time(),
            "model": self.model,
            "message_count": len(self.messages)
        }
        self.session_manager.save_session(
            self.session_manager.current_session,
            self.messages,
            metadata
        )


def run_advanced_tui(root: str, provider: Any, model: str) -> int:
    """Run the advanced TUI."""
    if not TEXTUAL_AVAILABLE:
        print("Error: Textual not installed. Run: pip install 'ollcoder[ui]'")
        return 1
    
    app = OllcoderAdvancedTUI(root, provider, model)
    app.run()
    return 0
