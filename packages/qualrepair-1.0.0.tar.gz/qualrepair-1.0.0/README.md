# qualrepair

[![PyPI Release](https://badge.fury.io/py/qualrepair.svg)](https://badge.fury.io/py/qualrepair)
[![CI](https://github.com/clintval/qualrepair/actions/workflows/python_package.yml/badge.svg?branch=main)](https://github.com/clintval/qualrepair/actions/workflows/python_package.yml?query=branch%3Amain)
[![Python Versions](https://img.shields.io/badge/python-3.11_|_3.12_|_3.13-blue)](https://github.com/clintval/qualrepair)
[![MyPy Checked](http://www.mypy-lang.org/static/mypy_badge.svg)](http://mypy-lang.org/)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://docs.astral.sh/ruff/)

Update the FASTQ quality scores from a subsequence FASTQ.

```console
pip install qualrepair
```

## Example

Repair the qualities in a sub-sequence FASTQ file from its original FASTQ file.

```bash
❯ qualrepair --in-source "r1.fastq.gz" --in-subseq "r1.subseq.fastq.gz"
```

This tool is primarily used to mitigate an unsolved issue in the [`splitcode`](https://github.com/pachterlab/splitcode/issues/18) tool.

## Development and Testing

See the [contributing guide](./CONTRIBUTING.md) for more information.
