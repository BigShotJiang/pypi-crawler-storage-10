"""
Differential Geometry Module for Coordinate System Package
===========================================================

This module provides tools for discrete differential geometry computations on surfaces,
using the CORRECT Intrinsic Gradient Operator framework based on the proven algorithm.

Key Formula:
    G_μ = (c(u+h) - c(u-h)) / (2h)  then extract normal derivative using .VZ()

Author: PanGuoJun
Version: 3.3.0 (Corrected Intrinsic Gradient)
Date: 2025-10-31
"""

import math
import numpy as np
from typing import Tuple, Optional, Callable, Union
from .coordinate_system import coord3, vec3
from .coord3_wrapper import Coord3Wrapper


# ========== Surface Base Class ==========

class Surface:
    """
    Base class for parametric surfaces r(u, v)
    """

    def __init__(self, h: float = 1e-6):
        """
        Initialize surface

        Args:
            h: Step size for numerical differentiation
        """
        self.h = h

    def position(self, u: float, v: float) -> vec3:
        """Compute position on surface at parameters (u, v)"""
        raise NotImplementedError("Subclass must implement position(u, v)")

    def tangent_u(self, u: float, v: float) -> vec3:
        """Compute tangent vector in u direction"""
        r_plus = self.position(u + self.h, v)
        r_minus = self.position(u - self.h, v)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def tangent_v(self, u: float, v: float) -> vec3:
        """Compute tangent vector in v direction"""
        r_plus = self.position(u, v + self.h)
        r_minus = self.position(u, v - self.h)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def normal(self, u: float, v: float) -> vec3:
        """Compute unit normal vector"""
        r_u = self.tangent_u(u, v)
        r_v = self.tangent_v(u, v)
        n = r_u.cross(r_v)
        length = (n.x**2 + n.y**2 + n.z**2) ** 0.5
        if length > 1e-10:
            return n * (1.0 / length)
        else:
            return vec3(0.0, 0.0, 1.0)


# ========== Common Surface Types ==========

class Sphere(Surface):
    """
    Sphere surface
    Parametrization: r(θ, φ) = R(sin θ cos φ, sin θ sin φ, cos θ)
    where θ ∈ [0, π] is polar angle, φ ∈ [0, 2π] is azimuthal angle
    """

    def __init__(self, radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = radius

    def position(self, theta: float, phi: float) -> vec3:
        """Position on sphere"""
        x = self.R * math.sin(theta) * math.cos(phi)
        y = self.R * math.sin(theta) * math.sin(phi)
        z = self.R * math.cos(theta)
        return vec3(x, y, z)


class Torus(Surface):
    """
    Torus surface
    Parametrization: r(u, v) = ((R + r cos u) cos v, (R + r cos u) sin v, r sin u)
    """

    def __init__(self, major_radius: float = 3.0, minor_radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = major_radius  # Major radius
        self.r = minor_radius  # Minor radius

    def position(self, u: float, v: float) -> vec3:
        """Position on torus"""
        x = (self.R + self.r * math.cos(u)) * math.cos(v)
        y = (self.R + self.r * math.cos(u)) * math.sin(v)
        z = self.r * math.sin(u)
        return vec3(x, y, z)


# ========== Metric Tensor ==========

class MetricTensor:
    """
    First fundamental form (metric tensor) of a surface
    g_ij = <∂r/∂u^i, ∂r/∂u^j>
    """

    def __init__(self, E: float, F: float, G: float):
        """
        Initialize metric tensor

        Args:
            E: g_11 = <r_u, r_u>
            F: g_12 = <r_u, r_v>
            G: g_22 = <r_v, r_v>
        """
        self.E = E
        self.F = F
        self.G = G
        self.det = E * G - F * F

    @classmethod
    def from_surface(cls, surface: Surface, u: float, v: float) -> 'MetricTensor':
        """Create metric tensor from surface at point (u, v)"""
        r_u = surface.tangent_u(u, v)
        r_v = surface.tangent_v(u, v)
        E = r_u.dot(r_u)
        F = r_u.dot(r_v)
        G = r_v.dot(r_v)
        return cls(E, F, G)

    def determinant(self) -> float:
        """Get determinant of metric tensor"""
        return self.det

    def __repr__(self) -> str:
        return f"MetricTensor(E={self.E:.6f}, F={self.F:.6f}, G={self.G:.6f}, det={self.det:.6f})"


# ========== CORRECT Intrinsic Gradient Operator ==========

class IntrinsicGradientOperator:
    """
    CORRECT Implementation of Intrinsic Gradient Operator
    Based on proven formula: G_μ = (c(u+h) - c(u-h)) / (2h) then extract .VZ()

    This matches the validated algorithm from the working test code.
    """

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        """
        Initialize intrinsic gradient operator

        Args:
            surface: Surface object
            step_size: Finite difference step size (default 0.001 rad ≈ 0.057 degrees)
        """
        self.surface = surface
        self.h = step_size

    def calc_intrinsic_frame(self, u: float, v: float) -> coord3:
        """
        Calculate intrinsic frame at point (u, v)
        
        This matches the algorithm from the working test code:
        - Compute position and tangent vectors
        - Create orthonormal frame with unit vectors
        - Return coord3 object for vector operations
        """
        # Position vector
        pos = self.surface.position(u, v)
        
        # Tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)
        
        # Unit normal vector
        n = r_u.cross(r_v).normalized()
        
        # Unit tangent vectors
        e1 = r_u.normalized()
        e2 = r_v.normalized()
        
        # Ensure orthonormality
        e2_corrected = (e2 - e1 * e2.dot(e1)).normalized()
        n_corrected = e1.cross(e2_corrected).normalized()
        
        # Create intrinsic frame
        frame = coord3()
        frame.o = pos
        frame.ux = e1
        frame.uy = e2_corrected
        frame.uz = n_corrected
        
        return frame

    def compute_both(self, u: float, v: float) -> Tuple['GradientResult', 'GradientResult', coord3]:
        """
        Compute intrinsic gradient operators in both directions using CENTRAL DIFFERENCES
        
        This implements the proven algorithm:
        dn_du = ((c(u+h) - c(u-h)) / (2h)).VZ()
        """
        # Compute frames using central differences (like the working test code)
        c_center = self.calc_intrinsic_frame(u, v)
        
        # u-direction: central difference
        c_u_plus = self.calc_intrinsic_frame(u + self.h, v)
        c_u_minus = self.calc_intrinsic_frame(u - self.h, v)
        dn_du = ((c_u_plus - c_u_minus) / (2 * self.h)).VZ()
        
        # v-direction: central difference  
        c_v_plus = self.calc_intrinsic_frame(u, v + self.h)
        c_v_minus = self.calc_intrinsic_frame(u, v - self.h)
        dn_dv = ((c_v_plus - c_v_minus) / (2 * self.h)).VZ()
        
        # Create gradient results
        G_u = GradientResult(dn_du, "u")
        G_v = GradientResult(dn_dv, "v")
        
        return G_u, G_v, c_center


class GradientResult:
    """
    Gradient result containing normal vector derivative
    
    Simplified version that directly stores the computed derivative
    """

    def __init__(self, dn: vec3, direction: str):
        """
        Initialize gradient result

        Args:
            dn: Normal vector derivative (computed using proven algorithm)
            direction: Parameter direction ('u' or 'v')
        """
        self.dn = dn
        self.direction = direction

    def __repr__(self) -> str:
        return f"GradientResult({self.direction}: [{self.dn.x:.6f}, {self.dn.y:.6f}, {self.dn.z:.6f}])"


# ========== Curvature Calculator ==========

class IntrinsicGradientCurvatureCalculator:
    """
    Curvature calculator using CORRECT intrinsic gradient operator method
    """

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        """
        Initialize curvature calculator

        Args:
            surface: Surface object
            step_size: Step size for gradient computation (default 0.001)
        """
        self.surface = surface
        self.h = step_size
        self.grad_op = IntrinsicGradientOperator(surface, step_size)

    def compute_gaussian_curvature(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature using intrinsic gradient method

        Formula: K = (LN - M²) / det(g)
        """
        # Compute gradient operators using the proven algorithm
        G_u, G_v, _ = self.grad_op.compute_both(u, v)

        # Compute tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)

        # Extract normal derivatives (already computed using correct algorithm)
        dn_du = G_u.dn
        dn_dv = G_v.dn

        # Compute metric tensor
        E = r_u.dot(r_u)
        F = r_u.dot(r_v)
        G = r_v.dot(r_v)
        metric_det = E * G - F * F

        # Compute second fundamental form
        L = -dn_du.dot(r_u)  # -<dn/du, r_u>
        M1 = -dn_du.dot(r_v)  # -<dn/du, r_v>
        M2 = -dn_dv.dot(r_u)  # -<dn/dv, r_u>
        N = -dn_dv.dot(r_v)   # -<dn/dv, r_v>
        M = (M1 + M2) / 2.0  # Symmetrize

        # Gaussian curvature
        if abs(metric_det) > 1e-14:
            K = (L * N - M * M) / metric_det
        else:
            K = 0.0

        return K

    def compute_mean_curvature(self, u: float, v: float) -> float:
        """
        Compute mean curvature

        Formula: H = (EN - 2FM + GL) / (2·det(g))
        """
        # Compute gradient operators
        G_u, G_v, _ = self.grad_op.compute_both(u, v)

        # Compute tangent vectors and metric
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)
        E = r_u.dot(r_u)
        F = r_u.dot(r_v)
        G = r_v.dot(r_v)
        metric_det = E * G - F * F

        # Extract normal derivatives
        dn_du = G_u.dn
        dn_dv = G_v.dn

        # Second fundamental form
        L = -dn_du.dot(r_u)
        M1 = -dn_du.dot(r_v)
        M2 = -dn_dv.dot(r_u)
        N = -dn_dv.dot(r_v)
        M = (M1 + M2) / 2.0

        # Mean curvature
        if abs(metric_det) > 1e-14:
            H = (G * L - 2 * F * M + E * N) / (2 * metric_det)
        else:
            H = 0.0

        return H

    def compute_second_fundamental_form(self, u: float, v: float) -> Tuple[float, float, float]:
        """
        Compute second fundamental form coefficients

        Returns:
            (L, M, N) tuple
        """
        # Compute gradient operators
        G_u, G_v, _ = self.grad_op.compute_both(u, v)

        # Compute tangent vectors
        r_u = self.surface.tangent_u(u, v)
        r_v = self.surface.tangent_v(u, v)

        # Extract normal derivatives
        dn_du = G_u.dn
        dn_dv = G_v.dn

        # Second fundamental form
        L = -dn_du.dot(r_u)
        M1 = -dn_du.dot(r_v)
        M2 = -dn_dv.dot(r_u)
        N = -dn_dv.dot(r_v)
        M = (M1 + M2) / 2.0

        return L, M, N

    def compute_all_curvatures(self, u: float, v: float) -> dict:
        """
        Compute all curvature quantities

        Returns:
            Dictionary with all curvature information
        """
        K = self.compute_gaussian_curvature(u, v)
        H = self.compute_mean_curvature(u, v)
        L, M, N = self.compute_second_fundamental_form(u, v)

        # Principal curvatures
        discriminant = max(0, H * H - K)
        sqrt_disc = discriminant ** 0.5
        k1 = H + sqrt_disc
        k2 = H - sqrt_disc

        # Metric tensor
        metric = MetricTensor.from_surface(self.surface, u, v)

        return {
            'gaussian_curvature': K,
            'mean_curvature': H,
            'principal_curvatures': (k1, k2),
            'second_fundamental_form': (L, M, N),
            'metric_tensor': metric
        }


# ========== Convenience Functions ==========

def compute_gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    method: str = 'intrinsic',
    step_size: float = 1e-3
) -> float:
    """
    Compute Gaussian curvature

    Args:
        surface: Surface object
        u, v: Parameter values
        method: Calculation method (currently only 'intrinsic' is correct)
        step_size: Step size for numerical differentiation

    Returns:
        Gaussian curvature value
    """
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_gaussian_curvature(u, v)


def compute_mean_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute mean curvature
    """
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_mean_curvature(u, v)


def compute_all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> dict:
    """
    Compute all curvature quantities
    """
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_all_curvatures(u, v)


def compute_intrinsic_gradient(
    surface: Surface,
    u: float,
    v: float,
    direction: str = 'u',
    step_size: float = 1e-3
) -> GradientResult:
    """
    Compute intrinsic gradient in specified direction

    Args:
        surface: Surface object
        u, v: Parameter values
        direction: 'u' or 'v'
        step_size: Step size

    Returns:
        GradientResult object
    """
    grad_op = IntrinsicGradientOperator(surface, step_size)
    
    if direction == 'u':
        # Compute central difference for u direction
        c_plus = grad_op.calc_intrinsic_frame(u + step_size, v)
        c_minus = grad_op.calc_intrinsic_frame(u - step_size, v)
        dn = ((c_plus - c_minus) / (2 * step_size)).VZ()
    elif direction == 'v':
        # Compute central difference for v direction
        c_plus = grad_op.calc_intrinsic_frame(u, v + step_size)
        c_minus = grad_op.calc_intrinsic_frame(u, v - step_size)
        dn = ((c_plus - c_minus) / (2 * step_size)).VZ()
    else:
        raise ValueError(f"direction must be 'u' or 'v', got: {direction}")

    return GradientResult(dn, direction)


# ========== Backward Compatibility (DEPRECATED) ==========

def compute_curvature_tensor(*args, **kwargs):
    """DEPRECATED: Use compute_all_curvatures instead"""
    raise NotImplementedError("compute_curvature_tensor is deprecated. Use compute_all_curvatures instead.")


# ========== Export ==========

__all__ = [
    # Surface classes
    'Surface',
    'Sphere',
    'Torus',

    # Core classes
    'MetricTensor',
    'IntrinsicGradientOperator',
    'IntrinsicGradientCurvatureCalculator',

    # Functions
    'compute_gaussian_curvature',
    'compute_mean_curvature',
    'compute_all_curvatures',
    'compute_intrinsic_gradient',
]