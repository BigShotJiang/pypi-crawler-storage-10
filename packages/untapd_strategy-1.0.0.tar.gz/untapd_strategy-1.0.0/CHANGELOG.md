# Changelog

## 1.0.0 (2025-10-26)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/untapd-labs/strategy-sdk/compare/v0.0.1...v1.0.0)

### Features

* **api:** manual updates ([5e34bfa](https://github.com/untapd-labs/strategy-sdk/commit/5e34bfa73e74288a634f8ba2a64981d3776a425a))
* **api:** manual updates ([de0791e](https://github.com/untapd-labs/strategy-sdk/commit/de0791e7fba5aaa8e2f76c48241f36676e7eee25))


### Chores

* update SDK settings ([2be7926](https://github.com/untapd-labs/strategy-sdk/commit/2be7926096bb87371ac3d0b034716d98cf0fe297))
* update SDK settings ([b51ff39](https://github.com/untapd-labs/strategy-sdk/commit/b51ff39bdd201cadf5dd5319cbb63fbf6fb300fc))
