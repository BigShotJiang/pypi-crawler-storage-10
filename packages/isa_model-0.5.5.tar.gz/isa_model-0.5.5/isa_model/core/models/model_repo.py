"""
Model Registry with PostgreSQL Backend

Uses PostgresClient (gRPC) following the ISA service architecture pattern.
"""

import os
import json
import logging
from typing import Dict, List, Optional, Any
from enum import Enum
from datetime import datetime
from dataclasses import dataclass

# Import PostgresClient from isa_common
try:
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from isa_common.postgres_client import PostgresClient
    POSTGRES_AVAILABLE = True
except ImportError as e:
    logging.warning(f"PostgresClient not available: {e}")
    POSTGRES_AVAILABLE = False
    PostgresClient = None

logger = logging.getLogger(__name__)

def _parse_metadata(metadata: Any) -> Dict[str, Any]:
    """
    Parse metadata field that might be a dict, JSON string, or None.

    Args:
        metadata: The metadata value from database (dict, str, or None)

    Returns:
        Dict with metadata, or empty dict if None
    """
    if not metadata:
        return {}

    # If already a dict (from JSONB column), return as-is
    if isinstance(metadata, dict):
        return metadata

    # If string, parse as JSON
    if isinstance(metadata, str):
        try:
            return json.loads(metadata)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse metadata as JSON: {metadata[:100]}")
            return {}

    # Unknown type
    logger.warning(f"Unexpected metadata type: {type(metadata)}")
    return {}

@dataclass
class RegisteredModel:
    """Simple model representation for registration results"""
    model_id: str
    model_type: str
    provider: str
    capabilities: List[str]
    metadata: Dict[str, Any]
    created_at: str
    updated_at: str

class ModelCapability(str, Enum):
    """Model capabilities"""
    TEXT_GENERATION = "text_generation"
    CHAT = "chat"
    EMBEDDING = "embedding"
    RERANKING = "reranking"
    REASONING = "reasoning"
    IMAGE_GENERATION = "image_generation"
    IMAGE_ANALYSIS = "image_analysis"
    AUDIO_TRANSCRIPTION = "audio_transcription"
    AUDIO_REALTIME = "audio_realtime"
    SPEECH_TO_TEXT = "speech_to_text"
    TEXT_TO_SPEECH = "text_to_speech"
    CONVERSATION = "conversation"
    IMAGE_UNDERSTANDING = "image_understanding"
    UI_DETECTION = "ui_detection"
    OCR = "ocr"
    TABLE_DETECTION = "table_detection"
    TABLE_STRUCTURE_RECOGNITION = "table_structure_recognition"

class ModelType(str, Enum):
    """Model types"""
    LLM = "llm"
    EMBEDDING = "embedding"
    RERANK = "rerank"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    VISION = "vision"

class ModelRegistry:
    """Model Registry using PostgreSQL via gRPC"""

    def __init__(self, host: str = None, port: int = None, user_id: str = 'model-service'):
        """
        Initialize model registry with PostgreSQL

        Args:
            host: PostgreSQL gRPC server host (default: from env or isa-postgres-grpc)
            port: PostgreSQL gRPC server port (default: from env or 50061)
            user_id: Service user ID for tracking
        """
        if not POSTGRES_AVAILABLE:
            raise ImportError("PostgresClient is required. Install isa_common package")

        # Get connection info from environment
        if host is None:
            host = os.getenv('POSTGRES_GRPC_HOST', 'isa-postgres-grpc')
        if port is None:
            port = int(os.getenv('POSTGRES_GRPC_PORT', '50061'))

        self.db = PostgresClient(host=host, port=port, user_id=user_id)
        self.schema = "model"
        self.environment = os.getenv('ENVIRONMENT', 'development')

        logger.info(f"Model registry initialized with PostgreSQL backend (env: {self.environment}, schema: {self.schema})")
    
    def register_model(self,
                      model_id: str,
                      model_type: ModelType,
                      capabilities: List[ModelCapability],
                      metadata: Dict[str, Any],
                      provider: Optional[str] = None) -> Optional[RegisteredModel]:
        """Register a model with its capabilities and metadata"""
        try:
            with self.db:
                current_time = datetime.now().isoformat()

                # Extract provider from metadata or use parameter
                provider_value = provider or metadata.get('provider')
                if not provider_value:
                    raise ValueError("Provider must be specified either as parameter or in metadata")

                # Insert or update model
                self.db.execute(f"""
                    INSERT INTO {self.schema}.models (model_id, model_type, provider, metadata, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, NOW(), NOW())
                    ON CONFLICT (model_id)
                    DO UPDATE SET
                        model_type = EXCLUDED.model_type,
                        provider = EXCLUDED.provider,
                        metadata = EXCLUDED.metadata,
                        updated_at = NOW()
                """, [model_id, model_type.value, provider_value, json.dumps(metadata)])

                # Delete existing capabilities
                self.db.execute(f"""
                    DELETE FROM {self.schema}.model_capabilities WHERE model_id = $1
                """, [model_id])

                # Insert new capabilities
                if capabilities:
                    for capability in capabilities:
                        self.db.execute(f"""
                            INSERT INTO {self.schema}.model_capabilities (model_id, capability, created_at)
                            VALUES ($1, $2, NOW())
                        """, [model_id, capability.value])

                logger.info(f"Successfully registered model {model_id} with {len(capabilities)} capabilities")

                # Return the registered model object
                return RegisteredModel(
                    model_id=model_id,
                    model_type=model_type.value,
                    provider=provider_value,
                    capabilities=[cap.value for cap in capabilities],
                    metadata=metadata,
                    created_at=current_time,
                    updated_at=current_time
                )

        except Exception as e:
            logger.error(f"Failed to register model {model_id}: {e}")
            return None
    
    def unregister_model(self, model_id: str) -> bool:
        """Unregister a model"""
        try:
            with self.db:
                self.db.execute(f"""
                    DELETE FROM {self.schema}.models WHERE model_id = $1
                """, [model_id])
                logger.info(f"Unregistered model {model_id}")
                return True

        except Exception as e:
            logger.error(f"Failed to unregister model {model_id}: {e}")
            return False
    
    def get_model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Get model information"""
        try:
            with self.db:
                # Get model info
                model_rows = self.db.query(f"""
                    SELECT model_id, model_type, provider, metadata, created_at, updated_at
                    FROM {self.schema}.models
                    WHERE model_id = $1
                """, [model_id])

                if not model_rows:
                    return None

                model_row = model_rows[0]

                # Get capabilities
                cap_rows = self.db.query(f"""
                    SELECT capability FROM {self.schema}.model_capabilities
                    WHERE model_id = $1
                """, [model_id])
                capabilities = [row['capability'] for row in cap_rows]

                metadata = model_row['metadata']
                if isinstance(metadata, str):
                    metadata = json.loads(metadata)

                return {
                    "model_id": model_row["model_id"],
                    "type": model_row["model_type"],
                    "capabilities": capabilities,
                    "metadata": metadata,
                    "created_at": str(model_row["created_at"]),
                    "updated_at": str(model_row["updated_at"])
                }

        except Exception as e:
            logger.error(f"Failed to get model info for {model_id}: {e}")
            return None
    
    def get_models_by_type(self, model_type: ModelType) -> Dict[str, Dict[str, Any]]:
        """Get all models of a specific type"""
        try:
            models_result = self._table('models').select('*').eq('model_type', model_type.value).execute()
            
            result = {}
            for model in models_result.data:
                model_id = model["model_id"]
                
                # Get capabilities for this model
                cap_result = self._table('model_capabilities').select('capability').eq('model_id', model_id).execute()
                capabilities = [cap['capability'] for cap in cap_result.data]
                
                result[model_id] = {
                    "type": model["model_type"],
                    "capabilities": capabilities,
                    "metadata": _parse_metadata(model["metadata"]),
                    "created_at": model["created_at"],
                    "updated_at": model["updated_at"]
                }

            return result

        except Exception as e:
            logger.error(f"Failed to get models by type {model_type}: {e}")
            return {}
    
    def get_models_by_capability(self, capability: ModelCapability) -> Dict[str, Dict[str, Any]]:
        """Get all models with a specific capability"""
        try:
            # Get model IDs with specific capability
            cap_result = self._table('model_capabilities').select('model_id').eq('capability', capability.value).execute()
            model_ids = [row['model_id'] for row in cap_result.data]
            
            if not model_ids:
                return {}
            
            # Get model details
            models_result = self._table('models').select('*').in_('model_id', model_ids).execute()
            
            result = {}
            for model in models_result.data:
                model_id = model["model_id"]
                
                # Get all capabilities for this model
                all_caps_result = self._table('model_capabilities').select('capability').eq('model_id', model_id).execute()
                capabilities = [cap['capability'] for cap in all_caps_result.data]
                
                result[model_id] = {
                    "type": model["model_type"],
                    "capabilities": capabilities,
                    "metadata": _parse_metadata(model["metadata"]),
                    "created_at": model["created_at"],
                    "updated_at": model["updated_at"]
                }

            return result

        except Exception as e:
            logger.error(f"Failed to get models by capability {capability}: {e}")
            return {}
    
    def has_capability(self, model_id: str, capability: ModelCapability) -> bool:
        """Check if a model has a specific capability"""
        try:
            result = self._table('model_capabilities').select('model_id').eq('model_id', model_id).eq('capability', capability.value).execute()
            
            return len(result.data) > 0
            
        except Exception as e:
            logger.error(f"Failed to check capability for {model_id}: {e}")
            return False
    
    def list_models(self) -> Dict[str, Dict[str, Any]]:
        """List all registered models"""
        try:
            with self.db:
                models_rows = self.db.query(f"""
                    SELECT model_id, model_type, provider, metadata, created_at, updated_at
                    FROM {self.schema}.models
                    ORDER BY created_at DESC
                """)

                result = {}
                for model in models_rows:
                    model_id = model["model_id"]

                    # Get capabilities
                    cap_rows = self.db.query(f"""
                        SELECT capability FROM {self.schema}.model_capabilities
                        WHERE model_id = $1
                    """, [model_id])
                    capabilities = [row['capability'] for row in cap_rows]

                    metadata = model['metadata']
                    if isinstance(metadata, str):
                        metadata = json.loads(metadata)

                    result[model_id] = {
                        "type": model["model_type"],
                        "capabilities": capabilities,
                        "metadata": metadata,
                        "created_at": str(model["created_at"]),
                        "updated_at": str(model["updated_at"])
                    }

                return result

        except Exception as e:
            logger.error(f"Failed to list models: {e}")
            return {}
    
    def get_stats(self) -> Dict[str, Any]:
        """Get registry statistics"""
        try:
            with self.db:
                # Count total models
                total_result = self.db.query_row(f"""
                    SELECT COUNT(*) as count FROM {self.schema}.models
                """)
                total_models = total_result['count'] if total_result else 0

                # Count by type
                type_rows = self.db.query(f"""
                    SELECT model_type, COUNT(*) as count
                    FROM {self.schema}.models
                    GROUP BY model_type
                """)
                type_counts = {row['model_type']: row['count'] for row in type_rows}

                # Count by capability
                cap_rows = self.db.query(f"""
                    SELECT capability, COUNT(*) as count
                    FROM {self.schema}.model_capabilities
                    GROUP BY capability
                """)
                capability_counts = {row['capability']: row['count'] for row in cap_rows}

                return {
                    "total_models": total_models,
                    "models_by_type": type_counts,
                    "models_by_capability": capability_counts
                }

        except Exception as e:
            logger.error(f"Failed to get stats: {e}")
            return {"total_models": 0, "models_by_type": {}, "models_by_capability": {}}
    
    def search_models(self, query: str) -> Dict[str, Dict[str, Any]]:
        """Search models by name or metadata"""
        try:
            # Search in model_id and metadata
            models_result = self._table('models').select('*').or_(
                f'model_id.ilike.%{query}%,metadata.ilike.%{query}%'
            ).order('created_at', desc=True).execute()
            
            result = {}
            for model in models_result.data:
                model_id = model["model_id"]
                
                # Get capabilities for this model
                cap_result = self._table('model_capabilities').select('capability').eq('model_id', model_id).execute()
                capabilities = [cap['capability'] for cap in cap_result.data]
                
                result[model_id] = {
                    "type": model["model_type"],
                    "capabilities": capabilities,
                    "metadata": _parse_metadata(model["metadata"]),
                    "created_at": model["created_at"],
                    "updated_at": model["updated_at"]
                }

            return result

        except Exception as e:
            logger.error(f"Failed to search models with query '{query}': {e}")
            return {}


class ModelRepo:
    """Compatibility wrapper for unified API"""
    
    def __init__(self):
        self.registry = ModelRegistry()
    
    def get_model_by_id(self, model_id: str):
        """Get model by ID - returns a simple object with basic properties"""
        info = self.registry.get_model_info(model_id)
        if not info:
            return None
        
        # Return a simple object that has the expected properties
        class ModelObject:
            def __init__(self, data):
                self.model_id = data["model_id"]
                self.model_type = data["type"]
                self.provider = data["metadata"].get("provider", "unknown")
                self.metadata = data["metadata"]
                self.capabilities = data["capabilities"]
                self.created_at = datetime.fromisoformat(data["created_at"]) if data["created_at"] else None
                self.updated_at = datetime.fromisoformat(data["updated_at"]) if data["updated_at"] else None
        
        return ModelObject(info)
    
    def update_model_metadata(self, model_id: str, metadata_updates: Dict[str, Any], updated_by: str = None):
        """Update model metadata - simplified implementation"""
        # Get existing model
        info = self.registry.get_model_info(model_id)
        if not info:
            return False
        
        # Merge metadata
        new_metadata = info["metadata"].copy()
        new_metadata.update(metadata_updates)
        
        # Update via re-registration (simplified)
        capabilities = [ModelCapability(cap) for cap in info["capabilities"] if cap in [c.value for c in ModelCapability]]
        model_type = ModelType(info["type"])
        
        return self.registry.register_model(
            model_id=model_id,
            model_type=model_type, 
            capabilities=capabilities,
            metadata=new_metadata,
            provider=info["metadata"].get("provider")
        )
    
    def search_models(self, query: str, model_type: str = None, provider: str = None, capabilities: List[str] = None, limit: int = 50):
        """Search models with filters"""
        results = self.registry.search_models(query)
        
        # Apply filters
        if model_type:
            results = {k: v for k, v in results.items() if v["type"] == model_type}
        
        if provider:
            results = {k: v for k, v in results.items() if v["metadata"].get("provider") == provider}
        
        if capabilities:
            results = {k: v for k, v in results.items() if any(cap in v["capabilities"] for cap in capabilities)}
        
        # Convert to expected format
        final_results = []
        for model_id, data in list(results.items())[:limit]:
            class ModelObject:
                def __init__(self, model_id, data):
                    self.model_id = model_id
                    self.model_type = data["type"]
                    self.provider = data["metadata"].get("provider", "unknown")
                    self.capabilities = data["capabilities"]
                    self.metadata = data["metadata"]
                    self.updated_at = datetime.fromisoformat(data["updated_at"]) if data["updated_at"] else None
            
            final_results.append(ModelObject(model_id, data))
        
        return final_results
    
    def get_providers_summary(self):
        """Get summary of available providers"""
        models = self.registry.list_models()
        providers = {}
        
        for model_id, data in models.items():
            provider = data["metadata"].get("provider", "unknown")
            if provider not in providers:
                providers[provider] = {
                    "provider": provider,
                    "model_count": 0,
                    "model_types": set(),
                    "capabilities": set()
                }
            
            providers[provider]["model_count"] += 1
            providers[provider]["model_types"].add(data["type"])
            providers[provider]["capabilities"].update(data["capabilities"])
        
        # Convert sets to lists for JSON serialization
        for provider_data in providers.values():
            provider_data["model_types"] = list(provider_data["model_types"])
            provider_data["capabilities"] = list(provider_data["capabilities"])
        
        return list(providers.values())