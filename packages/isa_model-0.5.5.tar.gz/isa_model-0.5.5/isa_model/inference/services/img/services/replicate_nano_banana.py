#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Replicate Google Nano-Banana Service
Specialized service for multi-image to image generation
"""

import os
import logging
from typing import Dict, Any, Union, Optional, List
import replicate

from ..base_image_gen_service import BaseImageGenService

logger = logging.getLogger(__name__)

class ReplicateNanoBananaService(BaseImageGenService):
    """
    Replicate Google Nano-Banana Service
    Advanced multi-image to image generation with style transfer capabilities
    """

    def __init__(self, provider_name: str, model_name: str, **kwargs):
        super().__init__(provider_name, model_name, **kwargs)

        # Get configuration from centralized config manager
        provider_config = self.get_provider_config()

        try:
            self.api_token = provider_config.get("api_key") or provider_config.get("replicate_api_token")

            if not self.api_token:
                raise ValueError("Replicate API token not found in provider configuration")

            # Set API token
            os.environ["REPLICATE_API_TOKEN"] = self.api_token

            # Model path
            self.model_path = "google/nano-banana"

            # Statistics
            self.total_generation_count = 0

            logger.info(f"Initialized ReplicateNanoBananaService with model '{self.model_name}'")

        except Exception as e:
            logger.error(f"Failed to initialize Replicate Nano-Banana client: {e}")
            raise ValueError(f"Failed to initialize Replicate Nano-Banana client: {e}") from e

    async def image_to_image(
        self,
        prompt: str,
        init_image: Union[str, List[str], Any],
        strength: float = 0.8,
        negative_prompt=None,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5,
        seed=None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate image from input image(s) and prompt using Nano-Banana

        Args:
            prompt: Text description for the generation
            init_image: Single image URL or list of image URLs
            strength: Not used by Nano-Banana (kept for compatibility)
            negative_prompt: Not used by Nano-Banana (kept for compatibility)
            num_inference_steps: Not used by Nano-Banana (kept for compatibility)
            guidance_scale: Not used by Nano-Banana (kept for compatibility)
            seed: Not used by Nano-Banana (kept for compatibility)
            **kwargs: Additional parameters including:
                - aspect_ratio: Output aspect ratio ("match_input_image", "1:1", "16:9", etc.)
                - output_format: Output format ("jpg", "png", "webp")
        """

        # Extract user_id from kwargs for billing
        self._current_user_id = kwargs.get('user_id')

        # Ensure init_image is a list
        if isinstance(init_image, str):
            image_input = [init_image]
        elif isinstance(init_image, list):
            image_input = init_image
        else:
            image_input = [str(init_image)]

        input_data = {
            "prompt": prompt,
            "image_input": image_input,
            "aspect_ratio": kwargs.get("aspect_ratio", "match_input_image"),
            "output_format": kwargs.get("output_format", "jpg")
        }

        return await self._generate_internal(input_data)

    async def multi_image_to_image(
        self,
        prompt: str,
        images: List[str],
        aspect_ratio: str = "match_input_image",
        output_format: str = "jpg",
        **kwargs
    ) -> Dict[str, Any]:
        """Generate image from multiple input images and prompt

        Args:
            prompt: Text description for the generation
            images: List of image URLs (typically 2 images for style transfer)
            aspect_ratio: Output aspect ratio ("match_input_image", "1:1", "16:9", etc.)
            output_format: Output format ("jpg", "png", "webp")
        """

        # Extract user_id from kwargs for billing
        self._current_user_id = kwargs.get('user_id')

        input_data = {
            "prompt": prompt,
            "image_input": images,
            "aspect_ratio": aspect_ratio,
            "output_format": output_format
        }

        return await self._generate_internal(input_data)

    async def _generate_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Internal generation method"""
        try:
            logger.info(f"Starting Nano-Banana multi-i2i with prompt: {input_data.get('prompt', '')[:50]}...")
            logger.info(f"Input images count: {len(input_data.get('image_input', []))}")

            # Call Replicate API
            output = await replicate.async_run(self.model_path, input=input_data)

            # Process output - handle FileOutput object
            if hasattr(output, 'url'):
                url = str(output.url)
            else:
                url = str(output)

            # Update statistics
            self.total_generation_count += 1

            # Calculate cost (estimate - adjust based on actual pricing)
            cost = self._calculate_cost(1)

            # Track billing information
            if self._current_user_id:
                await self._publish_billing_event(
                    user_id=self._current_user_id,
                    service_type="image_generation",
                    operation="multi_image_to_image",
                    input_tokens=0,
                    output_tokens=0,
                    input_units=len(input_data.get('image_input', [])),  # Number of input images
                    output_units=1,  # Generated image count
                    metadata={
                        "model": self.model_name,
                        "prompt": input_data.get("prompt", "")[:100],
                        "generation_type": "multi_i2i",
                        "input_image_count": len(input_data.get('image_input', [])),
                        "cost_usd": cost
                    }
                )

            # Return result
            result = {
                "url": url,
                "urls": [url],
                "format": input_data.get("output_format", "jpg"),
                "aspect_ratio": input_data.get("aspect_ratio", "match_input_image"),
                "count": 1,
                "cost_usd": cost,
                "metadata": {
                    "model": self.model_name,
                    "input": input_data,
                    "input_image_count": len(input_data.get('image_input', []))
                }
            }

            logger.info(f"Nano-Banana multi-i2i completed: cost: ${cost:.6f}")
            return result

        except Exception as e:
            logger.error(f"Nano-Banana multi-i2i failed: {e}")
            raise

    def _calculate_cost(self, image_count: int) -> float:
        """Calculate generation cost - estimate $0.03 per image (adjust based on actual pricing)"""
        return image_count * 0.03

    def get_generation_stats(self) -> Dict[str, Any]:
        """Get generation statistics"""
        total_cost = self.total_generation_count * 0.03

        return {
            "total_generation_count": self.total_generation_count,
            "total_cost_usd": total_cost,
            "cost_per_image": 0.03,
            "model": self.model_name
        }

    def get_supported_aspect_ratios(self) -> list[str]:
        """Get supported aspect ratios"""
        return ["match_input_image", "1:1", "16:9", "9:16", "4:3", "3:4", "21:9", "9:21"]

    def get_model_info(self) -> Dict[str, Any]:
        """Get model information"""
        return {
            "name": self.model_name,
            "type": "multi_image_to_image",
            "cost_per_image": 0.03,
            "supports_negative_prompt": False,
            "supports_img2img": True,
            "supports_multi_img2img": True,
            "supported_formats": ["jpg", "png", "webp"],
            "supported_aspect_ratios": self.get_supported_aspect_ratios(),
            "description": "Multi-image to image generation with style transfer capabilities"
        }

    async def load(self) -> None:
        """Load service"""
        if not self.api_token:
            raise ValueError("Missing Replicate API token")
        logger.info(f"Replicate Nano-Banana service ready with model: {self.model_name}")

    async def unload(self) -> None:
        """Unload service"""
        logger.info(f"Unloading Replicate Nano-Banana service: {self.model_name}")

    async def close(self):
        """Close service"""
        await self.unload()

    async def generate_image(
        self,
        prompt: str,
        negative_prompt: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5,
        seed: Optional[int] = None
    ) -> Dict[str, Any]:
        """Not supported - use image_to_image or multi_image_to_image instead"""
        raise NotImplementedError("Nano-Banana requires input image(s) - use image_to_image or multi_image_to_image method")

    async def generate_images(
        self,
        prompt: str,
        num_images: int = 1,
        negative_prompt: Optional[str] = None,
        width: int = 512,
        height: int = 512,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5,
        seed: Optional[int] = None
    ) -> list[Dict[str, Any]]:
        """Not supported - use image_to_image or multi_image_to_image instead"""
        raise NotImplementedError("Nano-Banana requires input image(s) - use image_to_image or multi_image_to_image method")

    def get_supported_sizes(self) -> list[Dict[str, int]]:
        """Get supported image sizes"""
        return [
            {"width": 512, "height": 512},
            {"width": 768, "height": 768},
            {"width": 1024, "height": 1024},
        ]
