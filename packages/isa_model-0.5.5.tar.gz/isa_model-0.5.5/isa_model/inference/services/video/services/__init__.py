#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Specialized video generation services"""

from .replicate_seedance import ReplicateSeedanceService

__all__ = [
    'ReplicateSeedanceService',
]
