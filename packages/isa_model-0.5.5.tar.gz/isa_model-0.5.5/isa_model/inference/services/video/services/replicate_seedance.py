#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Replicate ByteDance Seedance-1-Pro Service
Specialized service for text-to-video generation
"""

import os
import logging
from typing import Dict, Any, Optional
import replicate

from ..base_video_gen_service import BaseVideoGenService

logger = logging.getLogger(__name__)

class ReplicateSeedanceService(BaseVideoGenService):
    """
    Replicate ByteDance Seedance-1-Pro Service
    Advanced text-to-video generation with camera motion control
    """

    def __init__(self, provider_name: str, model_name: str, **kwargs):
        super().__init__(provider_name, model_name, **kwargs)

        # Get configuration from centralized config manager
        provider_config = self.get_provider_config()

        try:
            self.api_token = provider_config.get("api_key") or provider_config.get("replicate_api_token")

            if not self.api_token:
                raise ValueError("Replicate API token not found in provider configuration")

            # Set API token
            os.environ["REPLICATE_API_TOKEN"] = self.api_token

            # Model path
            self.model_path = "bytedance/seedance-1-pro"

            # Statistics
            self.total_generation_count = 0
            self.total_duration_seconds = 0.0

            logger.info(f"Initialized ReplicateSeedanceService with model '{self.model_name}'")

        except Exception as e:
            logger.error(f"Failed to initialize Replicate Seedance client: {e}")
            raise ValueError(f"Failed to initialize Replicate Seedance client: {e}") from e

    async def generate_video(
        self,
        prompt: str,
        duration: float = 5.0,
        fps: int = 24,
        resolution: str = "1080p",
        aspect_ratio: str = "16:9",
        camera_fixed: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate video from text prompt using Seedance-1-Pro

        Args:
            prompt: Text description of the desired video
            duration: Video duration in seconds (default: 5.0)
            fps: Frames per second (8-60, default: 24)
            resolution: Video resolution ("360p", "480p", "720p", "1080p", "2k", "4k")
            aspect_ratio: Video aspect ratio ("16:9", "9:16", "1:1", "21:9", "9:21")
            camera_fixed: Whether to disable camera motion (default: False)
            **kwargs: Additional parameters including user_id for billing
        """

        # Extract user_id from kwargs for billing
        self._current_user_id = kwargs.get('user_id')

        # Validate parameters
        if fps < 8 or fps > 60:
            raise ValueError("FPS must be between 8 and 60")

        if resolution not in self.get_supported_resolutions():
            raise ValueError(f"Resolution must be one of {self.get_supported_resolutions()}")

        if aspect_ratio not in self.get_supported_aspect_ratios():
            raise ValueError(f"Aspect ratio must be one of {self.get_supported_aspect_ratios()}")

        input_data = {
            "fps": fps,
            "prompt": prompt,
            "duration": duration,
            "resolution": resolution,
            "aspect_ratio": aspect_ratio,
            "camera_fixed": camera_fixed
        }

        return await self._generate_internal(input_data)

    async def _generate_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Internal generation method"""
        try:
            logger.info(f"Starting Seedance video generation with prompt: {input_data.get('prompt', '')[:50]}...")
            logger.info(f"Duration: {input_data['duration']}s, FPS: {input_data['fps']}, Resolution: {input_data['resolution']}")

            # Call Replicate API
            output = await replicate.async_run(self.model_path, input=input_data)

            # Process output - handle FileOutput object
            if hasattr(output, 'url'):
                url = str(output.url)
            else:
                url = str(output)

            # Update statistics
            self.total_generation_count += 1
            self.total_duration_seconds += input_data['duration']

            # Calculate cost (estimate - adjust based on actual pricing)
            # Seedance-1-Pro pricing is typically per second of video
            cost = self._calculate_cost(input_data['duration'], input_data['resolution'])

            # Track billing information
            if self._current_user_id:
                await self._publish_billing_event(
                    user_id=self._current_user_id,
                    service_type="video_generation",
                    operation="text_to_video",
                    input_tokens=0,
                    output_tokens=0,
                    input_units=1,  # One generation request
                    output_units=input_data['duration'],  # Duration in seconds
                    metadata={
                        "model": self.model_name,
                        "prompt": input_data.get("prompt", "")[:100],
                        "generation_type": "t2v",
                        "duration": input_data['duration'],
                        "fps": input_data['fps'],
                        "resolution": input_data['resolution'],
                        "aspect_ratio": input_data['aspect_ratio'],
                        "cost_usd": cost
                    }
                )

            # Return result
            result = {
                "url": url,
                "urls": [url],
                "duration": input_data['duration'],
                "fps": input_data['fps'],
                "resolution": input_data['resolution'],
                "aspect_ratio": input_data['aspect_ratio'],
                "format": "mp4",
                "camera_fixed": input_data['camera_fixed'],
                "cost_usd": cost,
                "metadata": {
                    "model": self.model_name,
                    "input": input_data
                }
            }

            logger.info(f"Seedance video generation completed: {input_data['duration']}s video, cost: ${cost:.6f}")
            return result

        except Exception as e:
            logger.error(f"Seedance video generation failed: {e}")
            raise

    def _calculate_cost(self, duration: float, resolution: str) -> float:
        """Calculate generation cost based on duration and resolution

        Pricing estimates (adjust based on actual Replicate pricing):
        - 360p-720p: $0.05 per second
        - 1080p: $0.08 per second
        - 2k-4k: $0.12 per second
        """
        base_cost_per_second = {
            "360p": 0.05,
            "480p": 0.05,
            "720p": 0.05,
            "1080p": 0.08,
            "2k": 0.12,
            "4k": 0.12
        }

        cost_per_second = base_cost_per_second.get(resolution, 0.08)
        return duration * cost_per_second

    def get_generation_stats(self) -> Dict[str, Any]:
        """Get generation statistics"""
        total_cost = sum(
            self._calculate_cost(5.0, "1080p")  # Approximate average
            for _ in range(self.total_generation_count)
        )

        return {
            "total_generation_count": self.total_generation_count,
            "total_duration_seconds": self.total_duration_seconds,
            "total_cost_usd": total_cost,
            "model": self.model_name
        }

    def get_supported_resolutions(self) -> list[str]:
        """Get supported video resolutions"""
        return ["360p", "480p", "720p", "1080p", "2k", "4k"]

    def get_supported_aspect_ratios(self) -> list[str]:
        """Get supported aspect ratios"""
        return ["16:9", "9:16", "1:1", "21:9", "9:21"]

    def get_model_info(self) -> Dict[str, Any]:
        """Get model information"""
        return {
            "name": self.model_name,
            "type": "text_to_video",
            "max_duration": 10.0,  # Adjust based on model limits
            "max_fps": 60,
            "min_fps": 8,
            "supports_img2vid": False,
            "supports_camera_control": True,
            "supported_resolutions": self.get_supported_resolutions(),
            "supported_aspect_ratios": self.get_supported_aspect_ratios(),
            "description": "Text-to-video generation with advanced camera motion control"
        }

    async def load(self) -> None:
        """Load service"""
        if not self.api_token:
            raise ValueError("Missing Replicate API token")
        logger.info(f"Replicate Seedance service ready with model: {self.model_name}")

    async def unload(self) -> None:
        """Unload service"""
        logger.info(f"Unloading Replicate Seedance service: {self.model_name}")

    async def close(self):
        """Close service"""
        await self.unload()
