from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Union
from isa_model.inference.services.base_service import BaseService

class BaseVideoGenService(BaseService):
    """Base class for video generation services with unified task dispatch"""

    async def invoke(
        self,
        prompt: str,
        task: Optional[str] = None,
        **kwargs
    ) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """
        Unified task dispatch method for video generation

        Args:
            prompt: Text description of the desired video
            task: Task type (generate, img2vid, vid2vid, etc.)
            **kwargs: Task-specific additional parameters

        Returns:
            Dict or List[Dict] containing generation results
        """
        task = task or "generate"

        if task == "generate":
            return await self.generate_video(prompt, **kwargs)
        elif task == "img2vid":
            init_image = kwargs.get("init_image")
            if not init_image:
                raise ValueError("img2vid task requires init_image parameter")
            return await self.image_to_video(prompt, init_image, **kwargs)
        else:
            raise NotImplementedError(f"{self.__class__.__name__} does not support task: {task}")

    def get_supported_tasks(self) -> List[str]:
        """
        Get list of supported tasks

        Returns:
            List of supported task names
        """
        return ["generate"]

    @abstractmethod
    async def generate_video(
        self,
        prompt: str,
        duration: float = 5.0,
        fps: int = 24,
        resolution: str = "720p",
        aspect_ratio: str = "16:9",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generate a video from text prompt

        Args:
            prompt: Text description of the desired video
            duration: Video duration in seconds
            fps: Frames per second
            resolution: Video resolution (e.g., "720p", "1080p", "4k")
            aspect_ratio: Video aspect ratio (e.g., "16:9", "9:16", "1:1")
            **kwargs: Additional model-specific parameters

        Returns:
            Dict containing generation results with keys:
            - url: Video URL or path
            - duration: Actual video duration
            - fps: Actual frames per second
            - resolution: Actual resolution
            - format: Video format (e.g., 'mp4', 'webm')
        """
        pass

    async def image_to_video(
        self,
        prompt: str,
        init_image: Union[str, Any],
        duration: float = 5.0,
        fps: int = 24,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generate video from image and prompt (optional, not all models support this)

        Args:
            prompt: Text description of desired video
            init_image: Initial image URL or path
            duration: Video duration in seconds
            fps: Frames per second
            **kwargs: Additional parameters

        Returns:
            Dict containing generation results
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support image_to_video")

    @abstractmethod
    def get_supported_resolutions(self) -> List[str]:
        """
        Get list of supported video resolutions

        Returns:
            List of resolution strings (e.g., ["720p", "1080p", "4k"])
        """
        pass

    @abstractmethod
    def get_supported_aspect_ratios(self) -> List[str]:
        """
        Get list of supported aspect ratios

        Returns:
            List of aspect ratio strings (e.g., ["16:9", "9:16", "1:1"])
        """
        pass

    @abstractmethod
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about the video generation model

        Returns:
            Dict containing model information:
            - name: Model name
            - max_duration: Maximum supported duration
            - max_fps: Maximum supported FPS
            - supports_img2vid: Whether image-to-video is supported
        """
        pass

    @abstractmethod
    async def close(self):
        """Cleanup resources"""
        pass
