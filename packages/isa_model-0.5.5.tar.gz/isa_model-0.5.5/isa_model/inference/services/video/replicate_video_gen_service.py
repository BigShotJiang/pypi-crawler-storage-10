#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Replicate Video Generation Service (Orchestrator)
Delegates to specialized video generation services
"""

import logging
from typing import Dict, Any, Optional, Union

from .base_video_gen_service import BaseVideoGenService
from .services.replicate_seedance import ReplicateSeedanceService

logger = logging.getLogger(__name__)

class ReplicateVideoGenService(BaseVideoGenService):
    """
    Replicate Video Generation Service (Orchestrator)
    Delegates to specialized services based on model type:
    - seedance-1-pro: Text-to-video generation with camera control
    """

    def __init__(self, provider_name: str, model_name: str, **kwargs):
        super().__init__(provider_name, model_name, **kwargs)

        # Initialize the appropriate specialized service
        self._delegate_service = self._create_delegate_service()

        logger.info(f"Initialized ReplicateVideoGenService orchestrator with model '{self.model_name}'")

    def _create_delegate_service(self) -> BaseVideoGenService:
        """Create the appropriate specialized service based on model name"""
        if "seedance" in self.model_name.lower():
            return ReplicateSeedanceService(self.provider_name, self.model_name)
        else:
            # Default to Seedance for unknown models
            return ReplicateSeedanceService(self.provider_name, self.model_name)

    async def generate_video(
        self,
        prompt: str,
        duration: float = 5.0,
        fps: int = 24,
        resolution: str = "1080p",
        aspect_ratio: str = "16:9",
        **kwargs
    ) -> Dict[str, Any]:
        """Generate video - delegates to appropriate service"""
        if hasattr(self._delegate_service, 'generate_video'):
            return await self._delegate_service.generate_video(
                prompt, duration, fps, resolution, aspect_ratio, **kwargs
            )
        else:
            raise NotImplementedError(f"generate_video not supported by {type(self._delegate_service).__name__}")

    async def image_to_video(
        self,
        prompt: str,
        init_image: Union[str, Any],
        duration: float = 5.0,
        fps: int = 24,
        **kwargs
    ) -> Dict[str, Any]:
        """Image-to-video generation - delegates to appropriate service"""
        if hasattr(self._delegate_service, 'image_to_video'):
            return await self._delegate_service.image_to_video(
                prompt, init_image, duration, fps, **kwargs
            )
        else:
            raise NotImplementedError(f"image_to_video not supported by {type(self._delegate_service).__name__}")

    # Delegation methods for common functionality
    def get_generation_stats(self) -> Dict[str, Any]:
        """Get generation statistics - delegates to service"""
        return self._delegate_service.get_generation_stats()

    def get_model_info(self) -> Dict[str, Any]:
        """Get model information - delegates to service"""
        return self._delegate_service.get_model_info()

    def get_supported_resolutions(self) -> list[str]:
        """Get supported resolutions - delegates to service"""
        return self._delegate_service.get_supported_resolutions()

    def get_supported_aspect_ratios(self) -> list[str]:
        """Get supported aspect ratios - delegates to service"""
        return self._delegate_service.get_supported_aspect_ratios()

    async def load(self) -> None:
        """Load service - delegates to service"""
        await self._delegate_service.load()

    async def unload(self) -> None:
        """Unload service - delegates to service"""
        await self._delegate_service.unload()

    async def close(self):
        """Close service - delegates to service"""
        await self._delegate_service.close()
