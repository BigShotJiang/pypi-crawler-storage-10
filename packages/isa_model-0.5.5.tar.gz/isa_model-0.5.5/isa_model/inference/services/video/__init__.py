#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Video generation services"""

from .base_video_gen_service import BaseVideoGenService
from .replicate_video_gen_service import ReplicateVideoGenService

__all__ = [
    'BaseVideoGenService',
    'ReplicateVideoGenService',
]
