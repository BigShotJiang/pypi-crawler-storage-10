"""Core reinforcement-learning utilities for the rl_soumya package."""

from __future__ import annotations

import random
from typing import Iterable, List, Sequence


def train_epsilon_greedy(
    reward_generators: Sequence[Iterable[float]],
    epsilon: float = 0.1,
    steps: int = 1000,
    seed: int | None = None,
) -> List[float]:
    """Run a simple epsilon-greedy bandit loop and return cumulative rewards.

    Args:
        reward_generators: Sequence of iterables that yield rewards for each arm.
        epsilon: Probability of exploring a random arm instead of the best known one.
        steps: Total number of steps to simulate.
        seed: Optional random seed for reproducibility.

    Returns:
        A list of cumulative rewards collected at each step.
    """
    if not reward_generators:
        raise ValueError("You must provide at least one reward generator.")

    if not 0.0 <= epsilon <= 1.0:
        raise ValueError("epsilon must be in the [0, 1] range.")

    if steps <= 0:
        raise ValueError("steps must be a positive integer.")

    rng = random.Random(seed)
    arm_count = len(reward_generators)
    values = [0.0] * arm_count
    counts = [0] * arm_count
    cumulative_rewards: List[float] = []
    total_reward = 0.0

    for _ in range(steps):
        if rng.random() < epsilon:
            arm = rng.randrange(arm_count)
        else:
            arm = max(range(arm_count), key=lambda idx: values[idx])

        try:
            reward = next(reward_generators[arm])
        except StopIteration:
            raise RuntimeError(f"Reward generator for arm {arm} ran out of samples.") from None

        counts[arm] += 1
        values[arm] += (reward - values[arm]) / counts[arm]
        total_reward += reward
        cumulative_rewards.append(total_reward)

    return cumulative_rewards


__all__ = ["train_epsilon_greedy"]
