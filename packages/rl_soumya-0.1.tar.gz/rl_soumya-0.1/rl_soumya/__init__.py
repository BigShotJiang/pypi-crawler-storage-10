"""Public API for the rl_soumya package."""

from .main import train_epsilon_greedy

__all__ = ["train_epsilon_greedy"]
