# rl-soumya

`rl-soumya` provides tiny building blocks for experimenting with reinforcement-learning ideas.  
The current release ships a reference implementation of a simple epsilon-greedy multi-armed
bandit loop and a CLI demo that shows it in action.

## Installation

```bash
pip install rl-soumya
```

## Usage

```python
from rl_soumya import train_epsilon_greedy

# Create reward generators for each arm
def make_generator(mean):
    while True:
        yield mean

arms = [make_generator(0.4), make_generator(0.6), make_generator(0.9)]
rewards = train_epsilon_greedy(arms, epsilon=0.05, steps=500)
print(f"Total reward collected: {rewards[-1]:.2f}")
```

Run the included demo from a shell:

```bash
python -m rl_soumya.main
```

## Development

```bash
python3.11 setup.py sdist bdist_wheel
pip install dist/rl_soumya-0.1-py3-none-any.whl
```

## License

MIT
