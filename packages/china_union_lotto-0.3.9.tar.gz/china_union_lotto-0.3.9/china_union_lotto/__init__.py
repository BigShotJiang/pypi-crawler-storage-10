import sys
from .server import serve
from loguru import logger

def init_logger():
    log_format = "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<8} | {name}::{function} [{line}] - {message}"
    logger.remove()  # 移除默认的logger
    logger.add(sink=sys.stderr,
               format=log_format,
               level="DEBUG")  # 输出到错误控制台
    
    logger.add(sink="log.log", 
               format=log_format,
               level="DEBUG",
               rotation="10 MB")  # 每10MB创建一个新日志文件
    logger.info("Logger initialized")

def main():
    """MCP Server for China Union Lotto - Help you select china union lotto numbers."""

    init_logger()

    logger.info("Starting china union lotto mcp-server")

    import asyncio

    # parser = argparse.ArgumentParser(
    #     description="help you select china union lotto numbers"
    # )
    # parser.add_argument("--numbers", type=str, help="how many numbers to select")

    # args = parser.parse_args()
    asyncio.run(serve())

if __name__ == "__main__":
    main()
