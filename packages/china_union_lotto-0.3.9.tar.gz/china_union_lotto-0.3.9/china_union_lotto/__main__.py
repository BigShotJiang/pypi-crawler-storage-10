from china_union_lotto import main

main()
