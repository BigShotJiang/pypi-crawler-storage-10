"""
Utility modules for the Garbage Classifier project.

This package contains configuration settings and custom classes
for data loading, model definition, and training callbacks.
"""
