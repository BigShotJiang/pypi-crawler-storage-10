# MIT License
#
# Copyright (c) 2025 David256
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from typing import cast, Union, Optional
import os
import configparser
import pathlib
import filetype

from tsdtool.log import logger
from tsdtool.utils import parse_channel_id

from telethon import TelegramClient
import telethon.functions as functions
import telethon.types as tg_types


class TSD:
    def __init__(self, config_filename: str) -> None:
        self.config_filename = config_filename
        self.config = self.get_config(self.config_filename)
        self.client = self.create_client()

    def get_config(self, config_filename: str):
        """Create a config object from config file.

        Args:
            config_filename (str): The config filename.

        Returns:
            ConfigParser: a new ConfigParser object.
        """
        if not os.path.exists(config_filename):
            raise FileNotFoundError(f'Not found: {config_filename}')
        config = configparser.ConfigParser()
        config.read(config_filename)
        return config

    def create_client(self):
        """Create a Telegram client object from given config.

        Args:
            config (configparser.ConfigParser): Parsed config object.

        Returns:
            TelegramClient: The Telegram client object.
        """
        client = TelegramClient(
            session=self.config['Access']['session'],
            api_id=int(self.config['Access']['id']),
            api_hash=self.config['Access']['hash'],
            timeout=int(self.config['Client']['timeout']),
            device_model=self.config['Client']['device_model'],
            lang_code=self.config['Client']['lang_code'],
        )
        client.start()
        return client

    async def download_stories(self,
                               channel_id: Union[int, str],
                               story_ids: Optional[list[int]],
                               output_dir: Optional[str],
                               pinned_stories: Optional[bool],
                               ):
        output_directory = (
            pathlib.Path(output_dir)
            if output_dir
            else pathlib.Path.cwd()
        )
        output_directory.mkdir(parents=True, exist_ok=True)
        logger.debug('output directory: %s', output_directory)

        try:
            _channel_id = parse_channel_id(channel_id)
            entity = await self.client.get_entity(_channel_id)
            input_peer: tg_types.InputPeerChannel | tg_types.InputPeerUser
            if isinstance(entity, tg_types.User) and entity.access_hash:
                input_peer = tg_types.InputPeerUser(entity.id, entity.access_hash)
            elif isinstance(entity, tg_types.Channel) and entity.access_hash:
                input_peer = tg_types.InputPeerChannel(entity.id, entity.access_hash)
            else:
                logger.error('Cannot get the input peer data')
                return

            if not isinstance(entity, (tg_types.Channel, tg_types.User)):
                logger.warning('Cannot get a Channel object from that channel id')
                return
            if entity.access_hash is None:
                logger.warning('Cannot get the access hash for that channel')
                return
            
            story_items: list[tg_types.StoryItem] = []

            if story_ids is None:
                if pinned_stories:
                    logger.info('downloading all pinned stories')
                    offset_id = 0
                    while True:
                        logger.debug('offset_id = %d', offset_id)
                        _stories = await self.client(
                            functions.stories.GetPinnedStoriesRequest(
                                peer=input_peer,
                                offset_id=offset_id,
                                limit=100,
                            )
                        )
                        _stories = cast(tg_types.stories.Stories, _stories)
                        if len(_stories.stories) == 0:
                            break
                        story_items.extend([
                            story_item
                            for story_item
                            in _stories.stories
                            if isinstance(story_item, tg_types.StoryItem)
                        ])
                        offset_id = _stories.stories[-1].id
                else:
                    _peer_stories = await self.client(functions.stories.GetPeerStoriesRequest(
                        input_peer,
                    ))
                    _peer_stories = cast(tg_types.stories.PeerStories, _peer_stories)
                    story_items.extend([
                        story_item
                        for story_item
                        in _peer_stories.stories.stories
                        if isinstance(story_item, tg_types.StoryItem)
                    ])
            else:
                logger.info('downloading stories from provided ids list')
                _stories = await self.client(
                    functions.stories.GetStoriesByIDRequest(
                        peer=input_peer,
                        id=story_ids,
                    )
                )
                stories = cast(tg_types.stories.Stories, _stories)
                story_items.extend([
                    story_item
                    for story_item
                    in stories.stories
                    if isinstance(story_item, tg_types.StoryItem)
                ])

            logger.debug('found %d stories', len(story_items))

            # download the media
            filenames: list[pathlib.Path] = []
            for story_item in story_items:
                filename_path = output_directory.joinpath(f'story.{channel_id}.{story_item.id}')
                logger.debug('downloading %s ...', filename_path)

                with filename_path.open('wb+') as file:
                    await self.client.download_file(
                        story_item.media,
                        file,
                    )
                    logger.debug('downloaded %s', filename_path)
                
                extension_result = filetype.guess(filename_path)
                if extension_result:
                    extension = extension_result.extension
                    new_output_filename = f'{filename_path.absolute()}.{extension}'
                    filename_path.rename(new_output_filename)
                    filenames.append(filename_path)
                    logger.debug('rename to %s', new_output_filename)
            
            return filenames

        except Exception as err:
            logger.error('Error: channel_id=%s, story_ids=%s, output_dir=%s',
                         channel_id,
                         story_ids,
                         output_dir)
            logger.error(err)