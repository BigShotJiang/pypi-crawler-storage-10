from typing import Union


def parse_channel_id(channel_id: Union[str, int]):
    """Parse the channel id.
    
    This can be string (@public_link) or int (for private channel).
    Also, the private channel id should be negative number.

    Args:
        channel_id (Union[str, int]): The channel id.

    Returns:
        Union[str, int]: The channel id.
    """
    if isinstance(channel_id, str):
        stripped = channel_id.lstrip('-')
        if stripped.isdigit():
            channel_id = int(channel_id)
        else:
            channel_id = channel_id.replace('@', '')

    # for channel, the ID are negatives
    if isinstance(channel_id, int) and channel_id > 0:
        channel_id = int(f'-100{channel_id}')
    # return that
    return channel_id