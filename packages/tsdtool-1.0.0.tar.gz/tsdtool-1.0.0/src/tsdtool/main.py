# MIT License
#
# Copyright (c) 2025 David256
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from typing import Optional
from dataclasses import dataclass
import argparse
import asyncio
import re

from tsdtool.tsdtool import TSD
from tsdtool.log import logger


def parse_story_ids(value: str):
    try:
        strings = value.split(',')
        ids = [
            int(string)
            for string
            in strings
        ]
        return ids
    except Exception as err:
        logger.error(err)


@dataclass
class Argument:
    config_filename: str
    channel_id: str
    story_ids: Optional[list[int]]
    output_dir: Optional[str]
    pinned_stories: Optional[bool]


def get_args():
    parser = argparse.ArgumentParser(
        prog='tsdtool',
        description='Script to download Telegram stories',
    )

    parser.add_argument('-c',
                        '--config',
                        nargs='?',
                        dest='config_filename',
                        default='config.ini',
                        help='The config filename')

    parser.add_argument('-C',
                        '--channel-id',
                        nargs='?',
                        dest='channel_id',
                        help='The channel ID.')
    
    parser.add_argument('--story-ids',
                        nargs='?',
                        dest='story_ids',
                        type=parse_story_ids,
                        help='The story ID list separated by comma.')
    
    parser.add_argument('--link',
                        nargs='?',
                        dest='link',
                        help='The story link.')
    
    parser.add_argument('-O',
                        '--output-dir',
                        nargs='?',
                        dest='output_dir',
                        help='The output directory path.')
    
    parser.add_argument('-P',
                        '--pinned-stories',
                        default=False,
                        dest='pinned_stories',
                        action='store_true',
                        help='Find between the pinned stories.')
    
    args = parser.parse_args()

    config_filename: str = args.config_filename
    channel_id: str = args.channel_id
    story_ids: Optional[list[int]] = args.story_ids
    output_dir: Optional[str] = args.output_dir
    pinned_stories: bool = args.pinned_stories

    if args.link:
        regex = re.compile(r't\.me/(\w+)/s/(\d+)')
        _match = regex.search(args.link)
        if _match is None:
            parser.error('Cannot parse the link: ' + args.link)
            parser.print_help()
            exit(-1)
        channel_id = _match.group(1)
        story_ids = [int(_match.group(2))]
    elif not channel_id:
        parser.error('Missing the channel id or the story link')
        parser.print_help()
        exit(-1)

    return Argument(
        config_filename=config_filename,
        channel_id=channel_id,
        story_ids=story_ids,
        output_dir=output_dir,
        pinned_stories=pinned_stories,
    )


def main():
    args = get_args()
    
    tsd_tool = TSD(args.config_filename)

    coro= tsd_tool.download_stories(
        args.channel_id,
        args.story_ids,
        args.output_dir,
        args.pinned_stories,
    )

    task = asyncio.ensure_future(coro)

    tsd_tool.client.loop.run_until_complete(task)
