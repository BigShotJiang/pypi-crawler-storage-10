# tsdtool

> _From the creators of [rcdtool](https://github.com/David256/rcdtool)..._

Script that downloads telegram stories.

## Usage

For help:

```bash
./tsdtool --help
```

This script needs the story link to download it.

```bash
tsdtool -c /path/to/config.ini --link "https://t.me/<username>/s/<id>" -O /tmp/path/to/directory
```

Then the script starts the downloading.

### Download all the current stories

You can pass the channel and download all the public stories:

```bash
tsdtool -c /path/to/config.ini -C "<username or channel ID>" -O /tmp/path/to/directory
```

### Download the pinned stories

These stories are saved as "posts":

```bash
tsdtool --pinned-stories -C "<username or channel ID>" -O /tmp/path/to/directory
```

### Download an specific story

You can pass the channel and the story ids separated by comma:

```bash
tsdtool -C "<username or channel ID>" --story-ids 23
```

or...

```bash
tsdtool -C "<username or channel ID>" --story-ids 23,24,40
```

## Dist

In this repository we release the source code (Python) and a binary option for GNU/Linux. You can build a binary for any other operating system using tool as [PyInstaller](https://pyinstaller.org/en/).

## Telegram session

You MUST have an API ID provided by Telegram at https://my.telegram.org/ (I think). This is as follows:

```
api_id: 32767
api_hash: ed855a59bbe4a3360dbf7a0538842142
```

Then rename `config.ini.sample` to `config.ini`, edit it and save wherever you want. If the file is in the same directory as `tsdtool` and its name is exactly "config.ini", then `tsdtool` will load it automatically.

The first time, **tsdtool** will ask you for your phone number, and will start a login process. When this is done, a `.session` file will be created. With this `.session` file, the tool could access to your Telegram account to read messages and download medias. The name of the .session file is set in `config.ini`.
