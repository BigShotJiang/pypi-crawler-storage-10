"""
===========================================================
 DarkNeuronAI Library
 Unified loader for ML & LLM models
 Author: Gaurav Pandey (Mr. Def@ult)
===========================================================
"""

# ---------------- IMPORTS ----------------
import torch
from darkneuronai.core.ml_loader import DarkNeuronML
from darkneuronai.core.llm_loader import DarkNeuronLLM

# ---------------- META INFO ----------------
__version__ = "1.0.2"
__author__ = "Gaurav Pandey"
__company__ = "DarkNeuronAI"
__license__ = "MIT"

# ---------------- DEVICE DETECTION ----------------
if torch.cuda.is_available():
    DEVICE = "cuda"
elif torch.backends.mps.is_available():
    DEVICE = "mps"
else:
    DEVICE = "cpu"

# ---------------- MAIN LOADER FUNCTION ----------------
def load_darkneuron_model(model_type, model_identifier):
    """
    Loads a DarkNeuronAI model.
    model_type: "ml" or "llm"
    model_identifier:
        • For ML → file name or dict with {"model_path", "vectorizer_path"}
        • For LLM → model name (Hugging Face)
    """
    if model_type == "ml":
        if isinstance(model_identifier, dict):
            model = DarkNeuronML(
                model_identifier.get("model_path"),
                model_identifier.get("vectorizer_path")
            )
        else:
            model = DarkNeuronML(model_identifier)
    elif model_type == "llm":
        model = DarkNeuronLLM(model_identifier, device=DEVICE)
    else:
        raise ValueError("Invalid model_type. Use 'ml' or 'llm'.")

    model.load_model()
    return model

# ---------------- ALIASES ----------------
load_model = load_darkneuron_model
get_model = load_darkneuron_model

# ---------------- PUBLIC EXPORTS ----------------
__all__ = [
    "load_darkneuron_model",
    "load_model",
    "get_model",
    "DarkNeuronMLModel",
    "DarkNeuronLLM",
    "DEVICE",
    "__version__",
    "__author__",
    "__company__",
    "__license__"
]