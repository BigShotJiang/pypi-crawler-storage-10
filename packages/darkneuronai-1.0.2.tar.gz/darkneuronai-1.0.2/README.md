# 🧠 DarkNeuronAI  
> Unified ML & LLM Loader — simple, smart, and powerful.

[DarkNeuronAI HuggingFace](https://huggingface.co/DarkNeuronAI)

---

## 🚀 Overview
**DarkNeuronAI** is a professional Python library built for seamlessly loading and using both **Machine Learning (ML)** and **Large Language Models (LLMs)**.  
It automatically handles `.pkl` extensions for ML models, integrates with Hugging Face for LLMs, and detects hardware (CPU/GPU/MPS) automatically.  

Developed by **Gaurav Pandey (Mr. Def@ult)** under the **DarkNeuronAI** organization.

---

## ✨ Features

✅ Unified interface for ML and LLM models  
✅ Auto `.pkl` detection — no need to type full filenames  
✅ Works with both local and Hugging Face models  
✅ Auto device selection (CPU / GPU / MPS)  
✅ Vectorizer auto-loading for ML text models  
✅ Simple and clean API — no complex configs  
✅ Ready for PyPI packaging and production use  

---

## 🧩 Installation
Install via **pip**:
```bash
pip install darkneuronai
```

Install directly via **GitHub**: 
```bash
pip install git+https://github.com/DarkNeuronAI/darkneuronai-python-library.git
```

---

## 🌟 Usage of ML Model
```python
from darkneuron import load_model

# Load spam detection model (auto adds .pkl)
spam_model = load_model("ml", {
    "model_path": "darkneuron-spamdex-v1",
    "vectorizer_path": "spamdex_vectorizer"
})

# Predict
print(spam_model.predict("Win a free iPhone now!"))
```

---

## 🌟 Usage of LLM Model
```python
from darkneuron import load_model

llm = load_model("llm", "DarkNeuronAI/darkneuron-chat-v1.1")
response = llm.generate("Explain quantum mechanics in simple terms.")
print(response)
```

---

## 🧠 API Reference
> load_model(model_type, model_identifier)

| Parameter          | Type            | Description                                                                                                               |
| ------------------ | --------------- | ------------------------------------------------------------------------------------------------------------------------- |
| `model_type`       | `str`           | `"ml"` or `"llm"`                                                                                                         |
| `model_identifier` | `dict` or `str` | For ML: `{"model_path": "spam_model", "vectorizer_path": "vectorizer"}`<br>For LLM: `"DarkNeuronAI/darkneuron-chat-v1.1"` |

---

## 📁 Folder Structure
darkneuron/  
├── __init__.py  
├── core/  
│   ├── base_model.py  
│   ├── ml_loader.py  
│   └── llm_loader.py    
├── tests/  
│   ├── test_ml_loader.py  
│   └── test_llm_loader.py  
├── utils/  
│   ├── device.py  
│   └── logger.py  
├── models/  
│   ├── darkneuron-spamdex-v1.pkl  
│   ├── spamdex_vectorizer.pkl  
│   └── water_model.pkl  
├── README.md  
├── pyproject.toml  
└── requirements.txt  

---

## 🧰 Dependencies
- torch
- transformers
- joblib
- numpy

Install **manually if needed**:
```bash
pip install torch transformers joblib numpy
```

---

## 🧑‍💻 Developer Info
**Author:** Gaurav Pandey (Mr. Def@ult)  
**Company:** DarkNeuronAI  
**License:** MIT  
**Version:** 1.0.2 
**Email:** darkneuronai.official@gmail.com  
**GitHub:** github.com/DarkNeuron-AI  
**HuggingFace:** huggingface.co/DarkNeuronAI

---

## 🧬 Future Updates
- Auto model/vectorizer detection from folder name
- Async model loading
- Built-in performance benchmarks
- CLI for quick inference (darkneuron run model input.txt)

--- 

## 🖤 Credits
Created by **Gaurav Pandey (Mr. Def@ult)**
> Turning Data → Intelligence → Power

---

© 2025 DarkNeuronAI — Advancing Emotionally Intelligent AI!