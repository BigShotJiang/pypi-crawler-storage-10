#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK

"""Converts dnscrypt-proxy query_log TSV values to Prometheus-compatible metrics."""

import logging
import re
import sys
import time
from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser, Namespace
from collections.abc import Iterable
from contextlib import suppress
from pathlib import Path
from typing import TypedDict

from prometheus_client import write_to_textfile
from prometheus_client.core import CounterMetricFamily, GaugeMetricFamily, HistogramMetricFamily, Metric
from prometheus_client.parser import text_string_to_metric_families  # pyright: ignore[reportUnknownVariableType]
from prometheus_client.registry import Collector, CollectorRegistry

argcomplete_imported = False
with suppress(ModuleNotFoundError):
    from argcomplete import autocomplete  # pyright: ignore[reportMissingTypeStubs]
    from argcomplete.completers import FilesCompleter  # pyright: ignore[reportMissingTypeStubs]

    argcomplete_imported = True


__prog__ = "dnscrypt-proxy-logs-analyzer"
__version__ = "1.0.0"
__status__ = "Development"
__author__ = "Alexander Pozlevich"
__email__ = "apozlevich@gmail.com"

logger = logging.getLogger()
logging.basicConfig(
    format="%(levelname)s [%(asctime)s.%(msecs)03d]: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.WARNING,
    stream=sys.stderr,
)

LINE_RE = re.compile(r"^\[[^\]]+\]\s+\S+\s+\S+\s+(\S+)\s+(\S+)\s+(\d+)ms\s+(\S+)$")
BUCKETS = [0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0]

QTYPES = {
    "A",
    "AAAA",
    "CNAME",
    "HTTPS",
    "SVCB",
    "DS",
    "DNSKEY",
    "NSEC",
    "RRSIG",
    "PTR",
    "MX",
    "TXT",
}

RTYPES = {
    "PASS",
    "NXDOMAIN",
    "NODATA",
    "REFUSED",
    "SERVFAIL",
    "NOERROR",
    "NETWORK_ERROR",
    "TIMEOUT",
    "DNSCRYPT_ERROR",
    "TLS_ERROR",
    "SECURITY_ERROR",
    "BOGUS",
    "INSECURE",
    "CACHED",
    "BLOCKED",
    "REWRITE",
    "FORCED",
}

# Use own registry so no default metrics will be exposed.
REGISTRY = CollectorRegistry(auto_describe=True)

INF = float("inf")

QUERIES_METRIC_NAME = "dnscrypt_proxy_queries"
LATENCY_METRIC_NAME = "dnscrypt_proxy_latency_seconds"

Key = tuple[str, str, str]  # (qtype, result, upstream)


class HistNorm(TypedDict):
    """One histogram entry."""

    buckets: dict[float, float]
    inf: float
    sum: float


class HistCum(TypedDict):
    """Temporary cumulative histogram before normalization."""

    cumulative: dict[float, float]
    sum: float
    count: float


class DnsCryptProxyLogCollector(Collector):
    """Parses query log of dnscrypt-proxy."""

    def __init__(self, log_path: Path, prom_path: Path) -> None:
        """Parse query log of dnscrypt-proxy."""

        self.log_path = log_path
        self.prom_path = prom_path
        self.had_parse_error = False

    @staticmethod
    def _cumulative_to_bucket_list(cumulative: dict[float, float], count: float) -> list[tuple[str, float]]:
        """
        Convert cumulative histogram buckets into per-bucket counts.

        Args:
            cumulative: {bucket: cumulative_count}
            count: total observations (from +Inf bucket)

        Returns:
            Per-bucket values for prometheus_client.
        """

        prev = 0.0
        result: list[tuple[str, float]] = []

        for bucket in BUCKETS:
            val = cumulative.get(bucket, prev)
            result.append((str(bucket), val))
            prev = val

        result.append(("+Inf", count))
        return result

    def _iter_queries(self) -> Iterable[tuple[str, str, int, str]]:
        """
        Parse lines.

        Yields:
            Query type, query result, latency in ms and upstream name.
        """

        try:
            with self.log_path.open(mode="r", encoding="utf-8") as file:
                for i, line in enumerate(file):
                    match = LINE_RE.match(line)
                    if match is None:
                        logger.warning("Badly formatted line %d: %s", i, line)
                        self.had_parse_error = True
                        continue

                    qtype, result, latency_str, upstream = match.groups()

                    if qtype not in QTYPES:
                        logger.warning("Unknown query type on line %d: %s", i, qtype)
                        self.had_parse_error = True
                        continue

                    if result not in RTYPES:
                        logger.warning("Unknown query result on line %d: %s", i, result)
                        self.had_parse_error = True
                        continue

                    try:
                        latency_int = int(latency_str)

                    except ValueError:
                        logger.warning("Badly formatted latency on line %d: %s", i, latency_str)
                        self.had_parse_error = True
                        continue

                    yield qtype, result, latency_int, upstream

        except FileNotFoundError:
            self.had_parse_error = True
            logger.error("Source file %s does not exists", self.log_path.name)  # noqa: TRY400

    def _load_previous_metrics(self) -> tuple[dict[Key, float], dict[Key, HistNorm]]:  # noqa: C901
        """
        Read .prom file.

        Returns:
            Tuple of parsed metrics.
        """

        previous_query_counts: dict[Key, float] = {}
        previous_histograms: dict[Key, HistNorm] = {}
        histogram_cumulative_tmp: dict[Key, HistCum] = {}

        text = self.prom_path.read_text(encoding="utf-8")

        for metric_family in text_string_to_metric_families(text):
            if metric_family.name == QUERIES_METRIC_NAME:
                for sample in metric_family.samples:
                    key = (sample.labels["qtype"], sample.labels["result"], sample.labels["upstream"])
                    previous_query_counts[key] = float(sample.value)

            elif metric_family.name == LATENCY_METRIC_NAME:
                for sample in metric_family.samples:
                    key = (sample.labels["qtype"], sample.labels["result"], sample.labels["upstream"])
                    record = histogram_cumulative_tmp.setdefault(key, {"cumulative": {}, "sum": 0.0, "count": 0.0})

                    if sample.name.endswith("_bucket"):
                        le = sample.labels["le"]
                        if le == "+Inf":
                            record["count"] = float(sample.value)
                        else:
                            record["cumulative"][float(le)] = float(sample.value)

                    elif sample.name.endswith("_sum"):
                        record["sum"] = float(sample.value)

                    elif sample.name.endswith("_count"):
                        record["count"] = float(sample.value)

        # Normalize cumulative to per-bucket.
        for key, record in histogram_cumulative_tmp.items():
            previous = 0.0
            per_bucket_counts = dict.fromkeys(BUCKETS, 0.0)

            for bucket in BUCKETS:
                current = record["cumulative"].get(bucket, previous)
                per_bucket_counts[bucket] = current - previous
                previous = current

            overflow = max(0.0, record["count"] - previous)
            previous_histograms[key] = {"buckets": per_bucket_counts, "inf": overflow, "sum": record["sum"]}

        return previous_query_counts, previous_histograms

    def _parse_log(self) -> tuple[dict[Key, int], dict[Key, HistNorm]]:
        """
        Read query log file and produce new metrics.

        Returns:
            Tuple of parsed metrics.
        """

        new_counters: dict[Key, int] = {}
        new_histograms: dict[Key, HistNorm] = {}

        for qtype, result, latency_ms, upstream in self._iter_queries():
            key = (qtype, result, upstream)
            new_counters[key] = new_counters.get(key, 0) + 1

            latency_s = latency_ms / 1000.0
            histogram = new_histograms.setdefault(key, {"buckets": dict.fromkeys(BUCKETS, 0.0), "inf": 0.0, "sum": 0.0})
            histogram["sum"] += latency_s

            placed = False
            for bucket in BUCKETS:
                if latency_s <= bucket:
                    histogram["buckets"][bucket] += 1
                    placed = True
                    break

            if not placed:
                histogram["inf"] += 1

        return new_counters, new_histograms

    @staticmethod
    def _merge_counters(old: dict[Key, float], new: dict[Key, int]) -> dict[Key, float]:
        """
        Merge counter metrics.

        Args:
            old: parsed counter from .prom file.
            new: parsed counter from query log file.

        Returns:
            Merged counter dictionary.
        """

        return {key: old.get(key, 0) + new.get(key, 0) for key in (old.keys() | new.keys())}

    @staticmethod
    def _merge_histogram(old: dict[Key, HistNorm], new: dict[Key, HistNorm]) -> dict[Key, HistNorm]:
        """
        Merge histogram metrics.

        Args:
            old: parsed histogram from .prom file.
            new: parsed histogram from query log bile.

        Returns:
            Merged histogram dictionary.
        """

        merged: dict[Key, HistNorm] = {}
        for key in old.keys() | new.keys():
            old_value = old.get(key, {"buckets": dict.fromkeys(BUCKETS, 0.0), "inf": 0.0, "sum": 0.0})
            new_value = new.get(key, {"buckets": dict.fromkeys(BUCKETS, 0.0), "inf": 0.0, "sum": 0.0})
            merged[key] = {
                "buckets": {b: old_value["buckets"][b] + new_value["buckets"][b] for b in BUCKETS},
                "inf": old_value["inf"] + new_value["inf"],
                "sum": old_value["sum"] + new_value["sum"],
            }

        return merged

    @staticmethod
    def _export_counter(counts: dict[Key, float]) -> Metric:
        """
        Export counter metric.

        Args:
            counts: dictionary of parsed counters.

        Returns:
            `prometheus_client` metric.
        """

        counter = CounterMetricFamily(QUERIES_METRIC_NAME, "Total DNS queries", labels=("qtype", "result", "upstream"))

        for (qtype, result, upstream), value in counts.items():
            counter.add_metric((qtype, result, upstream), value)

        return counter

    @staticmethod
    def _export_histogram(histograms: dict[Key, HistNorm]) -> Metric:
        """
        Export histogram metric.

        Args:
            histograms: dictionary of parsed counters.

        Returns:
            `prometheus_client` metric.
        """

        histogram = HistogramMetricFamily(LATENCY_METRIC_NAME, "DNS query latency", labels=("qtype", "result", "upstream"))

        for (qtype, result, upstream), data in histograms.items():
            cumulative = 0.0
            buckets: list[tuple[str, float]] = []

            for bucket in BUCKETS:
                cumulative += data["buckets"][bucket]
                buckets.append((str(bucket), cumulative))

            buckets.append(("+Inf", cumulative + data["inf"]))
            histogram.add_metric((qtype, result, upstream), buckets=buckets, sum_value=data["sum"])

        return histogram

    def collect(self) -> Iterable[Metric]:
        """
        Produce metrics.

        Yields:
            Metics.
        """

        if self.prom_path.exists():
            prev_counts, prev_hist = self._load_previous_metrics()

        else:
            prev_counts, prev_hist = {}, {}

        new_counts, new_hist = self._parse_log()
        merged_counts = self._merge_counters(prev_counts, new_counts)
        merged_hist = self._merge_histogram(prev_hist, new_hist)

        last_run_ts = GaugeMetricFamily(
            name="dnscrypt_proxy_logs_analyzer_last_run_timestamp",
            documentation="Unix time of last successful processing",
        )
        last_run_ts.add_metric([], time.time())

        last_run_ok = GaugeMetricFamily(
            name="dnscrypt_proxy_logs_analyzer_last_run_success",
            documentation="1 if last run processed logs successfully, 0 if errors occurred",
        )
        last_run_ok.add_metric([], 0.0 if self.had_parse_error else 1.0)

        yield self._export_counter(merged_counts)
        yield self._export_histogram(merged_hist)
        yield last_run_ts
        yield last_run_ok


def _parse_args() -> Namespace:
    """
    Prepare argparse and parse CLI args.

    Returns:
        Namespace with parsed args.
    """

    parser = ArgumentParser(
        prog=__prog__,
        description=__doc__,
        epilog=f"Written by {__author__} <{__email__}>.",
        formatter_class=lambda prog: ArgumentDefaultsHelpFormatter(prog=prog, max_help_position=120),
    )
    parser.add_argument("--version", action="version", version=f"{__prog__} v{__version__} ({__status__})")

    query_arg = parser.add_argument(
        "-i",
        "--query-log",
        metavar="file",
        default="/var/log/dnscrypt-proxy/query.log",
        help="specify path to query.log in TSV format",
    )

    output_arg = parser.add_argument(
        "-o",
        "--output",
        metavar="file",
        default="/var/lib/node_exporter/textfile_collector/dnscrypt-proxy.prom",
        help="specify path to output metrics file",
    )

    parser.add_argument(
        "--no-trunc",
        action="store_true",
        help="do not truncate log file if used in conjuction with another utility such as logrotate."
        " Caution: if log will not be truncated, metrics will be incremented each run.",
    )

    if argcomplete_imported:
        query_arg.completer = FilesCompleter(directories=False)  # pyright: ignore[reportAttributeAccessIssue, reportPossiblyUnboundVariable]
        output_arg.completer = FilesCompleter(directories=False)  # pyright: ignore[reportAttributeAccessIssue, reportPossiblyUnboundVariable]
        autocomplete(parser)  # pyright: ignore[reportPossiblyUnboundVariable]

    return parser.parse_args()


def main() -> None:
    """Convert dnscrypt-proxy query_log and nx_log to Prometheus-compatible metrics."""

    args = _parse_args()
    query_log = Path(args.query_log)
    output_file = Path(args.output)

    REGISTRY.register(collector=DnsCryptProxyLogCollector(log_path=query_log, prom_path=output_file))
    write_to_textfile(path=str(output_file), registry=REGISTRY)
    query_log.write_text(data="", encoding="utf-8")


if __name__ == "__main__":
    with suppress(KeyboardInterrupt):
        main()
