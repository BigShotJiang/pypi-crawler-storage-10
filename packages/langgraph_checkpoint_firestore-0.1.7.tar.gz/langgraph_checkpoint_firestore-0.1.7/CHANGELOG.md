# Changelog

## [0.1.7]
### Changed
- Subgraph support
- Performance fix

## [0.1.4]
### Changed
- Async support

## [0.1.3]

- **Added**: Configurable checkpoint and writes collection feature.
- **Fixed**: List function bug.

This version introduces a new configurable checkpoint and writes collection feature