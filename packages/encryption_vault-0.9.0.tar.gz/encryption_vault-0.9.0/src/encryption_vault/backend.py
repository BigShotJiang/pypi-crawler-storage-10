"""Backend helpers implementing Firebase-backed storage."""
from __future__ import annotations

import base64
import functools
import hashlib
import hmac
import json
import logging
import os
import re
import time
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import gnupg
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

try:
    from . import firebase_sync
except ImportError:  # pragma: no cover - direct execution support
    import firebase_sync  # type: ignore

try:
    from gnupg import _parsers as _gnupg_parsers
except ImportError:
    _gnupg_parsers = None
else:
    def _wrap_unknown_status(cls):
        original = cls._handle_status

        def _patched(self, key, value, _orig=original):
            if key == 'PINENTRY_LAUNCHED':
                return
            try:
                return _orig(self, key, value)
            except ValueError as exc:
                if 'Unknown status message' in str(exc):
                    return
                raise

        cls._handle_status = _patched

    for _name in dir(_gnupg_parsers):
        _obj = getattr(_gnupg_parsers, _name)
        if isinstance(_obj, type) and hasattr(_obj, '_handle_status'):
            _wrap_unknown_status(_obj)

# Local persistence support for offline mode.
_CONFIG_DIR_OVERRIDE = os.getenv('ENCRYPTION_VAULT_CONFIG_DIR')
if _CONFIG_DIR_OVERRIDE:
    CONFIG_DIR = Path(os.path.expanduser(_CONFIG_DIR_OVERRIDE))
else:
    CONFIG_DIR = Path(os.path.expanduser('~/.encryption_vault'))
try:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
except OSError:
    CONFIG_DIR = Path.cwd()
LOCAL_STORE_PATH = CONFIG_DIR / 'offline_store.json'
LOCAL_ACCOUNTS_PATH = CONFIG_DIR / 'local_accounts.json'

OFFLINE_MODE = False

REMOTE_PROVIDER = 'firebase'
LOCAL_PROVIDER = 'local'
OFFLINE_PROVIDER = 'offline'

# Public objects intentionally exposed for UI modules.
gpg = gnupg.GPG()
logger = logging.getLogger(__name__)

salt = b'my_app_master_salt'
ACCOUNT_ID: Optional[str] = None
ACCOUNT_KEY: Optional[str] = None
master_password: Optional[str] = None
fernet: Optional[Fernet] = None
aes_secret_key: Optional[str] = None
session: Optional[firebase_sync.FirebaseSession] = None

_remote_store: Dict[str, str] = firebase_sync.DEFAULT_REMOTE_STORE.copy()

_EXP_RE = re.compile(r'^\s*(\d{1,2})\D*(\d{2})\s*$')

_TABLE0: list[Tuple[int, int]] = []
_TABLE1: list[Tuple[int, int]] = []
for v in range(10000):
    digs = [v // 1000, (v // 100) % 10, (v // 10) % 10, v % 10]
    for s, tbl in ((0, _TABLE0), (1, _TABLE1)):
        sm2 = sm5 = 0
        dbl = bool(s)
        for d in reversed(digs):
            n = d * 2 - 9 if dbl and d >= 5 else d * 2 if dbl else d
            dbl = not dbl
            sm2 ^= n & 1
            sm5 = (sm5 + n) % 5
        tbl.append((sm2, sm5))

SECURE_KEYS = ('private_key', 'sign_private_key', 'credentials', 'pgp_keyvault', 'cards')

class AuthError(RuntimeError):
    """Raised when local authentication fails or is misconfigured."""


def _normalise_email(value: str) -> str:
    return (value or '').strip().lower()


def _store_key(provider: str, identifier: Optional[str]) -> str:
    ident = (identifier or '').strip().lower() or 'default'
    return f'{provider}:{ident}'


def _current_store_key() -> str:
    if ACCOUNT_KEY:
        return ACCOUNT_KEY
    return _store_key(OFFLINE_PROVIDER, 'default')


def _canonicalise_store(candidate: object) -> Dict[str, str]:
    store = firebase_sync.DEFAULT_REMOTE_STORE.copy()
    if isinstance(candidate, dict):
        for key, value in candidate.items():
            if isinstance(key, str) and isinstance(value, str):
                store[key] = value
    return store


def _load_offline_index() -> Dict[str, Dict[str, str]]:
    if not LOCAL_STORE_PATH.exists():
        return {}
    try:
        data = json.loads(LOCAL_STORE_PATH.read_text(encoding='utf-8'))
    except Exception as exc:  # pragma: no cover - filesystem issues
        logger.warning('Failed to load offline cache from %s: %s', LOCAL_STORE_PATH, exc)
        return {}
    stores: Dict[str, Dict[str, str]] = {}
    raw_stores: Dict[str, object]
    if isinstance(data, dict) and 'stores' in data and isinstance(data['stores'], dict):
        raw_stores = data['stores']  # type: ignore[assignment]
    elif isinstance(data, dict):
        raw_stores = {_store_key(OFFLINE_PROVIDER, 'default'): data}
    else:
        return {}
    for key, payload in raw_stores.items():
        if isinstance(key, str):
            stores[key] = _canonicalise_store(payload)
    return stores


def _save_offline_index(stores: Dict[str, Dict[str, str]]) -> None:
    payload = {
        '__meta__': {'version': 2, 'updated': int(time.time())},
        'stores': {key: _canonicalise_store(value) for key, value in stores.items()},
    }
    try:
        LOCAL_STORE_PATH.write_text(json.dumps(payload), encoding='utf-8')
    except Exception as exc:  # pragma: no cover - filesystem issues
        logger.warning('Failed to persist offline cache to %s: %s', LOCAL_STORE_PATH, exc)


def _persist_offline_store(account_key: Optional[str] = None) -> None:
    key = account_key or _current_store_key()
    stores = _load_offline_index()
    stores[key] = _canonicalise_store(_remote_store)
    if not OFFLINE_MODE and key != _store_key(OFFLINE_PROVIDER, 'default'):
        stores[_store_key(OFFLINE_PROVIDER, 'default')] = _canonicalise_store(_remote_store)
    _save_offline_index(stores)


def _load_offline_store(account_key: Optional[str] = None) -> Dict[str, str]:
    key = account_key or _current_store_key()
    stores = _load_offline_index()
    if key in stores:
        return stores[key].copy()
    fallback_key = _store_key(OFFLINE_PROVIDER, 'default')
    if fallback_key in stores:
        return stores[fallback_key].copy()
    return firebase_sync.DEFAULT_REMOTE_STORE.copy()


def _local_account_key(email: str) -> str:
    return _store_key(LOCAL_PROVIDER, _normalise_email(email))


def _read_local_accounts() -> Dict[str, Dict[str, str]]:
    if not LOCAL_ACCOUNTS_PATH.exists():
        return {}
    try:
        data = json.loads(LOCAL_ACCOUNTS_PATH.read_text(encoding='utf-8'))
    except Exception as exc:  # pragma: no cover - filesystem issues
        logger.warning('Failed to load local account registry from %s: %s', LOCAL_ACCOUNTS_PATH, exc)
        return {}
    if not isinstance(data, dict):
        return {}
    accounts: Dict[str, Dict[str, str]] = {}
    for key, value in data.items():
        if not isinstance(key, str) or not isinstance(value, dict):
            continue
        email = _normalise_email(value.get('email', key))
        salt = value.get('salt')
        pwd_hash = value.get('hash')
        if email and isinstance(salt, str) and isinstance(pwd_hash, str):
            accounts[email] = {
                'email': value.get('email', key),
                'salt': salt,
                'hash': pwd_hash,
                'created': str(value.get('created', '')),
            }
    return accounts


def _write_local_accounts(accounts: Dict[str, Dict[str, str]]) -> None:
    payload = {
        key: {
            'email': entry.get('email', key),
            'salt': entry['salt'],
            'hash': entry['hash'],
            'created': entry.get('created', ''),
        }
        for key, entry in accounts.items()
        if 'salt' in entry and 'hash' in entry
    }
    try:
        LOCAL_ACCOUNTS_PATH.write_text(json.dumps(payload), encoding='utf-8')
    except Exception as exc:  # pragma: no cover - filesystem issues
        logger.warning('Failed to persist local account registry to %s: %s', LOCAL_ACCOUNTS_PATH, exc)


def _derive_local_password_hash(password: str, salt: bytes) -> str:
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 200000)
    return base64.urlsafe_b64encode(digest).decode('ascii')


def _activate_local_account(email: str) -> None:
    global session, ACCOUNT_ID, ACCOUNT_KEY, master_password, fernet, OFFLINE_MODE
    OFFLINE_MODE = True
    session = None
    ACCOUNT_KEY = _local_account_key(email)
    ACCOUNT_ID = f'{email} (Local)'
    master_password = None
    fernet = None
    store = _load_offline_store(ACCOUNT_KEY)
    _remote_store.clear()
    _remote_store.update(firebase_sync.DEFAULT_REMOTE_STORE)
    _remote_store.update(store)
    _persist_offline_store(ACCOUNT_KEY)


def register_local_account(email: str, password: str) -> None:
    """Create a new local-only account stored on disk."""
    email_normalised = _normalise_email(email)
    if not email_normalised or '@' not in email_normalised:
        raise AuthError('Enter a valid email address to create a local account.')
    if len(password) < 6:
        raise AuthError('Password must be at least 6 characters long.')
    accounts = _read_local_accounts()
    if email_normalised in accounts:
        raise AuthError('A local account with this email already exists.')
    salt = os.urandom(16)
    pwd_hash = _derive_local_password_hash(password, salt)
    entry = {
        'email': email.strip(),
        'salt': base64.urlsafe_b64encode(salt).decode('ascii'),
        'hash': pwd_hash,
        'created': str(int(time.time())),
    }
    accounts[email_normalised] = entry
    _write_local_accounts(accounts)
    _activate_local_account(entry['email'])


def authenticate_local_account(email: str, password: str) -> None:
    """Authenticate against the locally stored account registry."""
    email_normalised = _normalise_email(email)
    if not email_normalised:
        raise AuthError('Email is required for local sign-in.')
    accounts = _read_local_accounts()
    entry = accounts.get(email_normalised)
    if not entry:
        raise AuthError('No local account found for this email.')
    try:
        salt = base64.urlsafe_b64decode(entry['salt'].encode('ascii'))
    except Exception as exc:
        logger.warning('Corrupt local account salt for %s: %s', email_normalised, exc)
        raise AuthError('Local account data is corrupted. Remove and recreate this account.') from exc
    expected = entry['hash']
    computed = _derive_local_password_hash(password, salt)
    if not hmac.compare_digest(expected, computed):
        raise AuthError('Incorrect password for local account.')
    _activate_local_account(entry.get('email', email))


def _sync_remote_store() -> None:
    _remote_store['remote_updated_at'] = str(int(time.time()))
    if not session:
        if OFFLINE_MODE:
            _persist_offline_store()
            return
        raise RuntimeError('Firebase session not initialised')
    if OFFLINE_MODE:
        _persist_offline_store()
        return
    try:
        firebase_sync.replace_user_store(session, _remote_store)
    except firebase_sync.FirebaseAuthError as exc:
        logger.warning('Failed to sync remote store for %s: %s', session.user_id, exc)
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.exception('Unexpected error syncing remote store for %s', session.user_id)
    finally:
        _persist_offline_store()


def _initialise_session(sess: firebase_sync.FirebaseSession) -> None:
    """Hydrate local caches from Firestore for the authenticated session."""
    global session, ACCOUNT_ID, ACCOUNT_KEY, master_password, fernet, OFFLINE_MODE
    try:
        store = firebase_sync.fetch_user_store(sess)
    except firebase_sync.FirebaseAuthError as exc:
        logger.warning('Could not fetch remote store for %s: %s', sess.user_id, exc)
        store = firebase_sync.DEFAULT_REMOTE_STORE.copy()
    except Exception as exc:  # pragma: no cover - defensive logging
        logger.exception('Unexpected error while fetching remote store for %s', sess.user_id)
        store = firebase_sync.DEFAULT_REMOTE_STORE.copy()
    OFFLINE_MODE = False
    session = sess
    identifier = sess.email or sess.user_id
    ACCOUNT_KEY = _store_key(REMOTE_PROVIDER, identifier or sess.user_id or '')
    ACCOUNT_ID = f'{identifier} (Firebase)' if identifier else 'Firebase account'
    master_password = None
    fernet = None
    _remote_store.clear()
    _remote_store.update(firebase_sync.DEFAULT_REMOTE_STORE)
    _remote_store.update(store)
    _persist_offline_store(ACCOUNT_KEY)

def authenticate_with_email(email: str, password: str) -> None:
    """Authenticate against Firebase using email/password."""
    sess = firebase_sync.sign_in_with_email(email, password)
    _initialise_session(sess)


def register_account(email: str, password: str) -> None:
    """Register a new Firebase account and hydrate the session immediately."""
    sess = firebase_sync.sign_up_with_email(email, password)
    try:
        firebase_sync.create_user_store(sess, firebase_sync.DEFAULT_REMOTE_STORE.copy())
    except Exception:
        pass
    try:
        firebase_sync.send_verification_email(sess)
    except Exception:
        pass
    _initialise_session(sess)

def enable_offline_mode() -> None:
    """Enable offline mode and load cached data."""
    global session, ACCOUNT_ID, ACCOUNT_KEY, master_password, fernet, OFFLINE_MODE
    OFFLINE_MODE = True
    session = None
    ACCOUNT_KEY = _store_key(OFFLINE_PROVIDER, 'default')
    ACCOUNT_ID = 'Offline mode'
    master_password = None
    fernet = None
    store = _load_offline_store(ACCOUNT_KEY)
    _remote_store.clear()
    _remote_store.update(firebase_sync.DEFAULT_REMOTE_STORE)
    _remote_store.update(store)
    logger.info('Offline mode enabled; data persisted at %s', LOCAL_STORE_PATH)
    _persist_offline_store(ACCOUNT_KEY)


def is_offline_mode() -> bool:
    return OFFLINE_MODE




def has_master_password() -> bool:
    return bool(_remote_store.get('master_pw_hash'))


def store_master_hash(password: str) -> None:
    _remote_store['master_pw_hash'] = hashlib.sha256(password.encode()).hexdigest()


@functools.lru_cache(maxsize=128)
def derive_master_key(password: str) -> bytes:
    return base64.urlsafe_b64encode(
        PBKDF2HMAC(hashes.SHA256(), 32, salt, 100000).derive(password.encode())
    )


@functools.lru_cache(maxsize=128)
def derive_aes_key(password: str) -> bytes:
    return PBKDF2HMAC(hashes.SHA256(), 32, salt, 100000).derive(password.encode())


def initialise_master_password(password: str) -> None:
    """Set the initial master password for a newly authenticated user."""
    global master_password, fernet
    fernet = Fernet(derive_master_key(password))
    master_password = password
    store_master_hash(password)
    _sync_remote_store()


def verify_master_password(password: str) -> bool:
    """Validate the provided password against the stored hash and initialise Fernet."""
    global fernet, master_password
    stored = _remote_store.get('master_pw_hash')
    if not stored or hashlib.sha256(password.encode()).hexdigest() != stored:
        return False
    fernet = Fernet(derive_master_key(password))
    master_password = password
    return True


def rotate_master_password(new_password: str) -> None:
    """Re-encrypt secure payloads using a new master password."""
    global master_password, fernet
    if not fernet:
        raise RuntimeError('Master password not initialised')
    old = fernet
    new_fernet = Fernet(derive_master_key(new_password))
    for key in SECURE_KEYS:
        encrypted = _remote_store.get(key)
        if not encrypted:
            continue
        try:
            plaintext = old.decrypt(encrypted.encode()).decode()
        except Exception:
            continue
        _remote_store[key] = new_fernet.encrypt(plaintext.encode()).decode()
    fernet = new_fernet
    master_password = new_password
    store_master_hash(new_password)
    _sync_remote_store()


def _encrypt_if_needed(key: str, text: str) -> str:
    enc = key in SECURE_KEYS
    if enc:
        if not fernet:
            raise RuntimeError('Master password context is not initialised')
        return fernet.encrypt(text.encode()).decode()
    return text


def store_key(key: str, text: str) -> None:
    _remote_store[key] = _encrypt_if_needed(key, text)
    _sync_remote_store()


def get_stored_key(key: str) -> Optional[str]:
    data = _remote_store.get(key)
    if not data:
        return None
    if key in SECURE_KEYS:
        if not fernet:
            return None
        try:
            return fernet.decrypt(data.encode()).decode()
        except Exception:
            return None
    return data


def _load_json_field(field: str) -> Dict[str, Dict[str, str]]:
    payload = get_stored_key(field)
    if not payload:
        return {}
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return {}


def _store_json_field(field: str, data: Dict[str, Dict[str, str]]) -> None:
    store_key(field, json.dumps(data))


def load_credentials() -> Dict[str, Dict[str, str]]:
    return _load_json_field('credentials')


def save_credentials(creds: Dict[str, Dict[str, str]]) -> None:
    _store_json_field('credentials', creds)


def load_keyvault() -> Dict[str, Dict[str, str]]:
    return _load_json_field('pgp_keyvault')


def _store_default_vault_fingerprint(value: str, *, sync: bool = True) -> None:
    normalised = value.strip()
    if _remote_store.get('default_vault_fingerprint', '') == normalised:
        return
    _remote_store['default_vault_fingerprint'] = normalised
    if sync:
        _sync_remote_store()


def get_default_vault_fingerprint() -> str:
    return (_remote_store.get('default_vault_fingerprint') or '').strip()


def set_default_vault_fingerprint(fingerprint: Optional[str]) -> None:
    value = (fingerprint or '').strip()
    if value and value not in load_keyvault():
        logger.info('Ignoring default fingerprint %s because it is not present in the vault.', value)
        value = ''
    _store_default_vault_fingerprint(value)


def save_keyvault(vault: Dict[str, Dict[str, str]]) -> None:
    default_fp = get_default_vault_fingerprint()
    if default_fp and default_fp not in vault:
        _store_default_vault_fingerprint('', sync=False)
    _store_json_field('pgp_keyvault', vault)


def persist_public_key(fingerprint: str, key_text: str) -> bool:
    key_text = (key_text or '').strip()
    if not key_text:
        return False
    vault = load_keyvault()
    entry = vault.get(fingerprint, {})
    if entry.get('public') == key_text:
        return False
    entry['public'] = key_text
    vault[fingerprint] = entry
    save_keyvault(vault)
    return True


def persist_private_key(fingerprint: str, key_text: str, passphrase: Optional[str] = None) -> bool:
    key_text = (key_text or '').strip()
    if not key_text:
        return False
    vault = load_keyvault()
    entry = vault.get(fingerprint, {})
    updated = False
    if entry.get('private') != key_text:
        entry['private'] = key_text
        updated = True
    if passphrase is not None:
        if passphrase:
            if entry.get('passphrase') != passphrase:
                entry['passphrase'] = passphrase
                updated = True
        elif 'passphrase' in entry:
            entry.pop('passphrase')
            updated = True
    if 'public' not in entry:
        try:
            exported = gpg.export_keys(fingerprint)
        except Exception:
            exported = None
        if exported:
            entry['public'] = exported
            updated = True
    if updated:
        vault[fingerprint] = entry
        save_keyvault(vault)
    return updated


def store_passphrase(fingerprint: str, passphrase: Optional[str]) -> bool:
    vault = load_keyvault()
    entry = vault.get(fingerprint)
    if not entry:
        return False
    changed = False
    if passphrase:
        if entry.get('passphrase') != passphrase:
            entry['passphrase'] = passphrase
            changed = True
    elif 'passphrase' in entry:
        entry.pop('passphrase')
        changed = True
    if changed:
        vault[fingerprint] = entry
        save_keyvault(vault)
    return changed


def load_passphrase_from_vault(fingerprint: str) -> Optional[str]:
    return load_keyvault().get(fingerprint, {}).get('passphrase')


def load_key_from_vault(fingerprint: str, kind: str) -> Optional[str]:
    return load_keyvault().get(fingerprint, {}).get(kind, '')


def list_vault_keys(kind: Optional[str] = None) -> list[str]:
    vault = load_keyvault()
    if kind is None:
        return sorted(vault.keys())
    return sorted(fp for fp, data in vault.items() if kind in data)


def load_cards() -> Dict[str, Dict[str, str]]:
    return _load_json_field('cards')


def save_cards(cards: Dict[str, Dict[str, str]]) -> None:
    _store_json_field('cards', cards)


def delete_account_data() -> None:
    if not session:
        raise RuntimeError('Firebase session not initialised')
    firebase_sync.delete_user_store(session)
    _remote_store.clear()
    _remote_store.update(firebase_sync.DEFAULT_REMOTE_STORE)
    _sync_remote_store()


def aes_encrypt(password: str, data: str) -> str:
    key, iv = derive_aes_key(password), os.urandom(16)
    padder = padding.PKCS7(128).padder()
    cipher = Cipher(
        algorithms.AES(key),
        modes.CBC(iv),
        backend=default_backend()
    ).encryptor()
    ct = cipher.update(padder.update(data.encode()) + padder.finalize()) + cipher.finalize()
    return base64.b64encode(iv + ct).decode()


def aes_decrypt(password: str, token: str) -> bytes:
    raw = base64.b64decode(token)
    iv, ct = raw[:16], raw[16:]
    cipher = Cipher(
        algorithms.AES(derive_aes_key(password)),
        modes.CBC(iv),
        backend=default_backend()
    ).decryptor()
    padded = cipher.update(ct) + cipher.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


def load_public_key_from_text(text: str, persist: bool = True) -> str:
    key_text = (text or '').strip()
    if not key_text:
        raise ValueError('Empty public key')
    result = gpg.import_keys(key_text)
    if not _import_result_ok(result):
        raise ValueError('Failed to import public key')
    fingerprint = _latest_fingerprint(result)
    if not fingerprint:
        raise ValueError('No fingerprint returned for public key')
    if persist:
        persist_public_key(fingerprint, key_text)
    return fingerprint


def load_private_key_from_text(
    text: str,
    persist: bool = True,
    passphrase: Optional[str] = None,
    persist_bucket: Optional[str] = None,
) -> str:
    key_text = (text or '').strip()
    if not key_text:
        raise ValueError('Empty private key')
    result = gpg.import_keys(key_text)
    if not _import_result_ok(result):
        raise ValueError('Failed to import private key')
    fingerprint = _latest_fingerprint(result)
    if not fingerprint:
        raise ValueError('No fingerprint returned for private key')
    if persist:
        persist_private_key(fingerprint, key_text, passphrase)
    if persist_bucket:
        try:
            store_key(persist_bucket, key_text)
        except Exception:
            pass
    return fingerprint


def encrypt_message(pub_fpr: str, message: str) -> str:
    encrypted = gpg.encrypt(message, recipients=[pub_fpr], always_trust=True)
    if not encrypted.ok:
        raise ValueError('Encryption failed: ' + encrypted.status)
    return str(encrypted)


def decrypt_message(priv_fpr: str, ciphertext: str, passphrase: Optional[str]) -> str:
    decrypted = gpg.decrypt(ciphertext, passphrase=passphrase)
    if not decrypted.ok:
        raise ValueError('Decryption failed: ' + decrypted.status)
    return str(decrypted)


def sign_message_detached(priv_fpr: str, message: str, passphrase: Optional[str]) -> str:
    signature = gpg.sign(message, detach=True, passphrase=passphrase, default_key=priv_fpr)
    if not signature:
        raise ValueError('Signing failed')
    return str(signature)


def verify_signature(pub_fpr: str, signed_message: str) -> Tuple[bool, str]:
    verification = gpg.verify(signed_message)
    return bool(verification.valid), (verification.data.decode('utf-8', errors='ignore') if verification.data else '')


def generate_keypair(name: str, email: str, passphrase: Optional[str]) -> Tuple[str, str, str]:
    params = gpg.gen_key_input(
        name_real=name,
        name_email=email,
        passphrase=passphrase,
        key_type='RSA',
        key_length=2048
    )
    key = gpg.gen_key(params)
    if not key:
        raise ValueError('Key generation failed')
    fingerprint = str(key)
    public = gpg.export_keys(fingerprint)
    private = gpg.export_keys(fingerprint, True, passphrase=passphrase)
    return private, public, fingerprint


def valid_card(number: str) -> bool:
    digits = ''.join(filter(str.isdigit, number))
    sm2 = sm5 = 0
    rv = digits[::-1]
    for i in range(0, len(rv), 4):
        chunk = rv[i:i + 4]
        if len(chunk) == 4:
            tbl = _TABLE0 if (i & 1) == 0 else _TABLE1
            t = tbl[int(chunk[::-1])]
            sm2 ^= t[0]
            sm5 = (sm5 + t[1]) % 5
        else:
            dbl = bool(i & 1)
            for c in chunk:
                d = int(c)
                n = d * 2 - 9 if dbl and d >= 5 else d * 2 if dbl else d
                dbl = not dbl
                sm2 ^= n & 1
                sm5 = (sm5 + n) % 5
    return sm2 == 0 and sm5 == 0


def parse_expiration(text: Optional[str]) -> Optional[str]:
    match = _EXP_RE.match(text or '')
    if not match:
        return None
    month, year = int(match.group(1)), int(match.group(2))
    return f'{month:02d}/{year:02d}' if 1 <= month <= 12 else None


def _import_result_ok(result: object) -> bool:
    ok_attr = getattr(result, 'import_ok', None)
    if ok_attr is not None:
        return bool(ok_attr)
    counts = getattr(result, 'counts', None) or {}
    for key in ('imported', 'imported_rsa', 'sec_imported', 'imported_secret'):
        if counts.get(key):
            return True
    return bool(getattr(result, 'fingerprints', ()))


def _latest_fingerprint(result: object) -> Optional[str]:
    fingerprints = getattr(result, 'fingerprints', None)
    return fingerprints[-1] if fingerprints else None


__all__ = [
    'ACCOUNT_ID',
    'AuthError',
    'aes_decrypt',
    'aes_encrypt',
    'aes_secret_key',
    'authenticate_with_email',
    'authenticate_local_account',
    'delete_account_data',
    'derive_aes_key',
    'derive_master_key',
    'encrypt_message',
    'decrypt_message',
    'fernet',
    'generate_keypair',
    'get_stored_key',
    'gpg',
    'has_master_password',
    'initialise_master_password',
    'list_vault_keys',
    'load_cards',
    'load_credentials',
    'load_key_from_vault',
    'load_keyvault',
    'load_passphrase_from_vault',
    'load_private_key_from_text',
    'load_public_key_from_text',
    'master_password',
    'parse_expiration',
    'persist_private_key',
    'persist_public_key',
    'enable_offline_mode',
    'is_offline_mode',
    'register_account',
    'register_local_account',
    'save_cards',
    'save_credentials',
    'save_keyvault',
    'session',
    'sign_message_detached',
    'store_key',
    'store_master_hash',
    'store_passphrase',
    'valid_card',
    'verify_master_password',
    'verify_signature',
    'rotate_master_password',
]
