"""Firebase authentication and Firestore synchronization helpers."""
from __future__ import annotations

import json
import logging
import time
import urllib.parse
from dataclasses import dataclass
from typing import Dict, Optional

import requests

FIREBASE_CONFIG = {
    "apiKey": "AIzaSyAkxOXZdtpA3M-Y7w_4r3-p_mwU0WAV1T0",
    "authDomain": "erosolar-encryption-b2c60.firebaseapp.com",
    "projectId": "erosolar-encryption-b2c60",
    "storageBucket": "erosolar-encryption-b2c60.firebasestorage.app",
    "messagingSenderId": "679177387857",
    "appId": "1:679177387857:web:379cccb9134b513f3a9d70",
    "measurementId": "G-56W2SR5ETF",
}

API_KEY = FIREBASE_CONFIG["apiKey"]
PROJECT_ID = FIREBASE_CONFIG["projectId"]

IDENTITY_BASE = "https://identitytoolkit.googleapis.com/v1"
FIRESTORE_BASE = f"https://firestore.googleapis.com/v1/projects/{PROJECT_ID}/databases/(default)/documents"
SECURE_TOKEN_URL = f"https://securetoken.googleapis.com/v1/token?key={API_KEY}"

MAX_ATTEMPTS = 3
RETRYABLE_STATUS = {429, 500, 502, 503, 504}

logger = logging.getLogger(__name__)

STORAGE_BUCKET = FIREBASE_CONFIG.get("storageBucket", "").strip()
STORAGE_API_BASE = f"https://firebasestorage.googleapis.com/v0/b/{STORAGE_BUCKET}" if STORAGE_BUCKET else ""
_STORAGE_OBJECT_NAME = "store.json"


class FirebaseAuthError(RuntimeError):
    """Raised when Firebase authentication fails."""


@dataclass
class FirebaseSession:
    id_token: str
    refresh_token: str
    user_id: str
    email: str
    expiration: float

    def ensure_valid(self) -> None:
        if time.time() < self.expiration - 30:
            return
        self.refresh()

    def refresh(self) -> None:
        tokens = _refresh_tokens(self.refresh_token)
        self.id_token = tokens["id_token"]
        self.refresh_token = tokens["refresh_token"]
        self.expiration = time.time() + tokens["expires_in"]


def _post(url: str, payload: Dict[str, object]) -> Dict[str, object]:
    last_error: Optional[Exception] = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = requests.post(url, json=payload, timeout=15)
        except requests.RequestException as exc:
            last_error = exc
            if attempt == MAX_ATTEMPTS:
                raise FirebaseAuthError(str(exc)) from exc
            time.sleep(0.5 * attempt)
            continue
        if response.status_code == 200:
            return response.json()
        if response.status_code in RETRYABLE_STATUS and attempt < MAX_ATTEMPTS:
            time.sleep(0.5 * attempt)
            continue
        message = f'{response.status_code} {response.reason}: {response.text}'
        raise FirebaseAuthError(message)
    if last_error:
        raise FirebaseAuthError(str(last_error)) from last_error
    raise FirebaseAuthError('Unknown Firebase request failure.')


def _request(method: str, url: str, session: FirebaseSession, payload: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    session.ensure_valid()
    headers = {
        "Authorization": f"Bearer {session.id_token}",
        "Content-Type": "application/json",
    }
    last_error: Optional[Exception] = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = requests.request(method, url, headers=headers, json=payload, timeout=15)
        except requests.RequestException as exc:
            last_error = exc
            if attempt == MAX_ATTEMPTS:
                raise FirebaseAuthError(str(exc)) from exc
            time.sleep(0.5 * attempt)
            continue
        if response.status_code == 404:
            raise FileNotFoundError(url)
        if response.status_code >= 400:
            if response.status_code in RETRYABLE_STATUS and attempt < MAX_ATTEMPTS:
                time.sleep(0.5 * attempt)
                continue
            message = f'{response.status_code} {response.reason}: {response.text}'
            raise FirebaseAuthError(message)
        if response.content:
            return response.json()
        return {}
    if last_error:
        raise FirebaseAuthError(str(last_error)) from last_error
    raise FirebaseAuthError('Unknown Firebase request failure.')


def _storage_request(
    method: str,
    url: str,
    session: FirebaseSession,
    *,
    headers: Optional[Dict[str, str]] = None,
    data: Optional[bytes] = None,
    expect_json: bool = True,
) -> object:
    if not STORAGE_API_BASE:
        raise FirebaseAuthError('Firebase Storage is not configured for this project.')
    session.ensure_valid()
    merged_headers = {"Authorization": f"Bearer {session.id_token}"}
    if headers:
        merged_headers.update(headers)
    last_error: Optional[Exception] = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            response = requests.request(method, url, headers=merged_headers, data=data, timeout=15)
        except requests.RequestException as exc:
            last_error = exc
            if attempt == MAX_ATTEMPTS:
                raise FirebaseAuthError(str(exc)) from exc
            time.sleep(0.5 * attempt)
            continue
        if response.status_code == 404:
            raise FileNotFoundError(url)
        if response.status_code >= 400:
            if response.status_code in RETRYABLE_STATUS and attempt < MAX_ATTEMPTS:
                time.sleep(0.5 * attempt)
                continue
            message = f'{response.status_code} {response.reason}: {response.text}'
            raise FirebaseAuthError(message)
        if expect_json:
            if response.content:
                return response.json()
            return {}
        return response
    if last_error:
        raise FirebaseAuthError(str(last_error)) from last_error
    raise FirebaseAuthError('Unknown Firebase Storage request failure.')


def _serialise_store(store: Dict[str, str]) -> bytes:
    payload: Dict[str, str] = {key: store.get(key, "") or "" for key in DEFAULT_REMOTE_STORE}
    for key, value in store.items():
        if isinstance(key, str) and key not in payload:
            payload[key] = str(value or "")
    return json.dumps(payload, separators=(',', ':')).encode('utf-8')


def _parse_timestamp(value: Optional[str]) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def upload_user_store_blob(session: FirebaseSession, store: Dict[str, str]) -> None:
    if not STORAGE_API_BASE:
        return
    object_name = urllib.parse.quote(_storage_object_path(session.user_id), safe='')
    url = f"{STORAGE_API_BASE}/o?uploadType=media&name={object_name}"
    headers = {"Content-Type": "application/json; charset=utf-8"}
    _storage_request("POST", url, session, headers=headers, data=_serialise_store(store))


def download_user_store_blob(session: FirebaseSession) -> Optional[Dict[str, str]]:
    if not STORAGE_API_BASE:
        return None
    object_name = urllib.parse.quote(_storage_object_path(session.user_id), safe='')
    url = f"{STORAGE_API_BASE}/o/{object_name}?alt=media"
    try:
        response = _storage_request("GET", url, session, expect_json=False)
    except FileNotFoundError:
        return None
    except FirebaseAuthError as exc:
        logger.warning('Failed to download Firebase Storage backup for %s: %s', session.user_id, exc)
        return None
    text = getattr(response, 'text', None)
    if not text:
        return None
    try:
        data = json.loads(text)
    except ValueError:
        logger.warning('Firebase Storage payload for %s is not valid JSON.', session.user_id)
        return None
    store = DEFAULT_REMOTE_STORE.copy()
    for key, value in data.items():
        if isinstance(key, str) and isinstance(value, str):
            store[key] = value
    return store


def delete_user_store_blob(session: FirebaseSession) -> None:
    if not STORAGE_API_BASE:
        return
    object_name = urllib.parse.quote(_storage_object_path(session.user_id), safe='')
    url = f"{STORAGE_API_BASE}/o/{object_name}"
    try:
        _storage_request("DELETE", url, session, expect_json=False)
    except FileNotFoundError:
        return
    except FirebaseAuthError as exc:
        logger.warning('Failed to delete Firebase Storage backup for %s: %s', session.user_id, exc)
        raise


def _build_session(data: Dict[str, object]) -> FirebaseSession:
    tokens = _extract_tokens(data)
    return FirebaseSession(
        id_token=tokens["id_token"],
        refresh_token=tokens["refresh_token"],
        user_id=str(data.get("localId") or data.get("user_id") or ""),
        email=str(data.get("email") or ""),
        expiration=time.time() + tokens["expires_in"],
    )


def _extract_tokens(data: Dict[str, object]) -> Dict[str, object]:
    id_token = data.get("idToken") or data.get("id_token")
    refresh_token = data.get("refreshToken") or data.get("refresh_token")
    if not id_token:
        raise FirebaseAuthError("Firebase response missing idToken.")
    if not refresh_token:
        raise FirebaseAuthError("Firebase response missing refresh token.")
    expires_raw = data.get("expiresIn") or data.get("expires_in") or 3600
    try:
        expires_in = int(expires_raw)
    except (TypeError, ValueError):
        expires_in = 3600
    expires_in = max(expires_in, 60)
    return {
        "id_token": str(id_token),
        "refresh_token": str(refresh_token),
        "expires_in": expires_in,
    }


def _refresh_tokens(refresh_token: str) -> Dict[str, object]:
    payload = {"grant_type": "refresh_token", "refresh_token": refresh_token}
    data = _post(SECURE_TOKEN_URL, payload)
    return _extract_tokens(data)


def _lookup_user(session: FirebaseSession) -> Dict[str, object]:
    session.ensure_valid()
    return _post(f"{IDENTITY_BASE}/accounts:lookup?key={API_KEY}", {"idToken": session.id_token})


def send_verification_email(session: FirebaseSession) -> None:
    """Trigger a Firebase verification email for the provided session."""
    session.ensure_valid()
    _post(
        f"{IDENTITY_BASE}/accounts:sendOobCode?key={API_KEY}",
        {"requestType": "VERIFY_EMAIL", "idToken": session.id_token},
    )


def sign_in_with_email(email: str, password: str) -> FirebaseSession:
    url = f"{IDENTITY_BASE}/accounts:signInWithPassword?key={API_KEY}"
    data = _post(url, {"email": email, "password": password, "returnSecureToken": True})
    return _build_session(data)


def sign_up_with_email(email: str, password: str) -> FirebaseSession:
    """Create a new Firebase account using email/password credentials."""
    url = f"{IDENTITY_BASE}/accounts:signUp?key={API_KEY}"
    data = _post(url, {"email": email, "password": password, "returnSecureToken": True})
    return _build_session(data)


DEFAULT_REMOTE_STORE = {
    "master_pw_hash": "",
    "private_key": "",
    "sign_private_key": "",
    "credentials": "",
    "pgp_keyvault": "",
    "default_vault_fingerprint": "",
    "public_key": "",
    "verify_public_key": "",
    "cards": "",
    "remote_updated_at": "",
}


def _firestore_doc_path(user_id: str) -> str:
    return f"{FIRESTORE_BASE}/users/{user_id}"


def _storage_object_path(user_id: str) -> str:
    return f"users/{user_id}/{_STORAGE_OBJECT_NAME}"


def fetch_user_store(session: FirebaseSession) -> Dict[str, str]:
    url = _firestore_doc_path(session.user_id)
    try:
        doc = _request("GET", url, session)
    except FileNotFoundError:
        backup = download_user_store_blob(session)
        if backup is not None:
            create_user_store(session, backup)
            return backup
        store = DEFAULT_REMOTE_STORE.copy()
        create_user_store(session, store)
        try:
            upload_user_store_blob(session, store)
        except FirebaseAuthError as exc:
            logger.warning('Unable to seed Firebase Storage backup for %s: %s', session.user_id, exc)
        return store
    except FirebaseAuthError:
        backup = download_user_store_blob(session)
        if backup is not None:
            return backup
        raise
    fields = doc.get("fields", {})
    store: Dict[str, str] = {}
    for key, value in DEFAULT_REMOTE_STORE.items():
        store[key] = fields.get(key, {}).get("stringValue", value)
    backup = download_user_store_blob(session)
    if backup is not None and _parse_timestamp(backup.get("remote_updated_at")) > _parse_timestamp(store.get("remote_updated_at")):
        return backup
    return store


def create_user_store(session: FirebaseSession, store: Dict[str, str]) -> None:
    url = f"{FIRESTORE_BASE}/users?documentId={session.user_id}"
    payload = {"fields": {k: {"stringValue": v or ""} for k, v in store.items()}}
    _request("POST", url, session, payload)
    try:
        upload_user_store_blob(session, store)
    except FirebaseAuthError as exc:
        logger.warning('Failed to upload initial Firebase Storage backup for %s: %s', session.user_id, exc)


def replace_user_store(session: FirebaseSession, store: Dict[str, str]) -> None:
    url = _firestore_doc_path(session.user_id)
    payload = {"fields": {k: {"stringValue": v or ""} for k, v in store.items()}}
    firestore_error: Optional[Exception] = None
    try:
        _request("PATCH", url, session, payload)
    except FileNotFoundError:
        try:
            create_user_store(session, store)
        except Exception as exc:
            firestore_error = exc
    except Exception as exc:
        firestore_error = exc
    storage_error: Optional[Exception] = None
    try:
        upload_user_store_blob(session, store)
    except FirebaseAuthError as exc:
        storage_error = exc
    if firestore_error and storage_error:
        raise FirebaseAuthError(
            f'Failed to persist remote store via Firestore ({firestore_error}) and Firebase Storage ({storage_error}).'
        ) from firestore_error
    if firestore_error:
        if STORAGE_API_BASE and storage_error is None:
            logger.warning('Firestore sync failed for %s; relying on Firebase Storage backup.', session.user_id)
            return
        if isinstance(firestore_error, FirebaseAuthError):
            raise firestore_error
        raise FirebaseAuthError(str(firestore_error)) from firestore_error
    if storage_error:
        logger.warning('Failed to upload Firebase Storage backup for %s: %s', session.user_id, storage_error)


def delete_user_store(session: FirebaseSession) -> None:
    url = _firestore_doc_path(session.user_id)
    firestore_error: Optional[Exception] = None
    try:
        _request("DELETE", url, session)
    except FileNotFoundError:
        firestore_error = None
    except Exception as exc:
        firestore_error = exc
    storage_error: Optional[Exception] = None
    try:
        delete_user_store_blob(session)
    except FirebaseAuthError as exc:
        storage_error = exc
    if firestore_error and storage_error:
        raise FirebaseAuthError(
            f'Failed to delete user store from Firestore ({firestore_error}) and Firebase Storage ({storage_error}).'
        ) from firestore_error
    if firestore_error:
        if isinstance(firestore_error, FirebaseAuthError):
            raise firestore_error
        raise FirebaseAuthError(str(firestore_error)) from firestore_error
    if storage_error:
        logger.warning('Failed to delete Firebase Storage backup for %s: %s', session.user_id, storage_error)
