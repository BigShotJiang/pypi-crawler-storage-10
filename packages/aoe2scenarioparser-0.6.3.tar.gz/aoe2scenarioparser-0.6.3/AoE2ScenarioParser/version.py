""" Expose version """

__version__ = "0.6.3"
VERSION = __version__.split(".")
