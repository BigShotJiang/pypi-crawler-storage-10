## cdf 

### Added

- [alpha] Added new command `cdf migrate events`. 

## templates

No changes.