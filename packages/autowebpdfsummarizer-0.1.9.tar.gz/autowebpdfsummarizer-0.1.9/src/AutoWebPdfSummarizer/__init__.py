"""Tools for summarizing web pages and PDFs with Gemini."""

from .summarizer import ChunkSummary, SummarizationResult, summarize_url, summarize_url_stream

__all__ = ["ChunkSummary", "SummarizationResult", "summarize_url", "summarize_url_stream"]
