from dataclasses import dataclass, asdict
from typing import Dict, Any

@dataclass
class VersionInfo:
    version: str
    download_url: str
    release_notes: str
    release_date: str
    file_size: int
    md5_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'VersionInfo':
        return cls(**data)

@dataclass
class PluginConfig:
    name: str
    extract_folder: str
    app_relative_path: str
    is_service: bool = False
    current_version: str = "1.0.0"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PluginConfig':
        return cls(**data)