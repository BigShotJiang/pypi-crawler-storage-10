# read version from installed package
from importlib.metadata import version
__version__ = version("factorlab")

# add imports for easier access