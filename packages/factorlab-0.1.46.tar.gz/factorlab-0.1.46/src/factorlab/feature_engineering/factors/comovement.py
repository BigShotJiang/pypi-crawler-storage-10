from __future__ import annotations
import pandas as pd
import numpy as np
from typing import Union


from factorlab.transform import Transform


class Comovement:
    """
    Comovement factor.
    """