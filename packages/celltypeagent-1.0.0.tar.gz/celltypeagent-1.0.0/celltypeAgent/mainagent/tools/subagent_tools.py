#!/usr/bin/env python3
"""
celltypeAgent - Subagent Tools模块
Author: cuilei
Version: 1.0
"""

from __future__ import annotations

import asyncio
import sys
import os
import json
from pathlib import Path
from typing import Any, Dict, Optional, Union, List

# 导入MainAgent的配置管理器以支持配置传递
from celltypeAgent.mainagent.config.settings import ConfigManager as MainConfigManager


def load_config_from_json(config_path: Optional[str] = None) -> Optional[Dict]:
    """从JSON文件加载配置

    Args:
        config_path: 配置文件路径，如果为None则使用默认路径

    Returns:
        配置字典，如果文件不存在或解析失败则返回None
    """
    if config_path is None:
        # 首先检查环境变量中的配置文件路径（主要用于子Agent）
        env_config_path = os.getenv("CELLTYPE_CONFIG_PATH")
        if env_config_path:
            env_config_file = Path(env_config_path)
            if env_config_file.exists():
                print(f"🔍 调试输出: 使用环境变量配置文件: {env_config_path}")
                config_path = env_config_file
            else:
                print(f"⚠️ 环境变量指定的配置文件不存在: {env_config_path}")

        # 如果环境变量没有找到有效配置，进行动态搜索
        if config_path is None:
            # 动态搜索配置文件，优先使用当前工作目录
            possible_paths = [
                Path.cwd() / "celltypeAgent_config.json",  # 当前工作目录（最高优先级）
                Path.cwd().parent / "celltypeAgent_config.json",  # 上级目录
                Path.cwd().parent.parent / "celltypeAgent_config.json",  # 上两级目录
                Path.cwd().parent.parent.parent / "celltypeAgent_config.json",  # 上三级目录
                Path.cwd().parent.parent.parent.parent / "celltypeAgent_config.json",  # 上四级目录
                # 包内配置文件作为最后选择（但需要验证API配置不为空）
            ]

            print(f"🔍 调试输出: 当前工作目录: {Path.cwd()}")
            config_path = None

            for potential_path in possible_paths:
                print(f"🔍 调试输出: 检查配置文件路径: {potential_path}")
                if potential_path.exists():
                    # 尝试读取并验证配置文件内容
                    try:
                        with open(potential_path, 'r', encoding='utf-8') as f:
                            test_config = json.load(f)
                            llm_config = test_config.get('llm', {})
                            api_base = llm_config.get('api_base')
                            api_key = llm_config.get('api_key')

                            # 检查是否包含有效的API配置
                            has_valid_api_config = (api_base is not None and api_base != "") or (api_key is not None and api_key != "")
                            print(f"🔍 调试输出: 配置文件API状态 - api_base: {api_base is not None and api_base != ''}, api_key: {api_key is not None and api_key != ''}")

                            if has_valid_api_config:
                                config_path = potential_path
                                print(f"✅ 找到有效配置文件: {config_path}")
                                break
                            else:
                                print(f"⚠️ 配置文件存在但API配置为空，继续搜索: {potential_path}")
                    except (json.JSONDecodeError, IOError) as e:
                        print(f"⚠️ 无法读取配置文件，继续搜索: {potential_path} - {e}")
                        continue

            if config_path is None:
                print(f"❌ 在所有可能的路径中都未找到配置文件")
                print(f"🔍 调试输出: 搜索的路径列表:")
                for path in possible_paths:
                    print(f"   - {path}")
                return None
    else:
        config_path = Path(config_path)

    try:
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
                print(f"✅ 成功加载配置文件: {config_path}")
                return config_data
        else:
            print(f"❌ 配置文件不存在: {config_path}", file=sys.stderr)
    except (json.JSONDecodeError, IOError) as e:
        print(f"❌ 无法加载配置文件 {config_path}: {e}", file=sys.stderr)

    return None


def get_subagent_config(agent_name: str, fallback_config: Optional[MainConfigManager] = None) -> Dict[str, Any]:
    """为指定的子Agent获取配置

    Args:
        agent_name: 子Agent名称 ('celltypeSubagent', 'celltypeDataAgent', 'celltypeAppAgent')
        fallback_config: 备用配置（原有的传入配置）

    Returns:
        配置字典，包含该子Agent需要的所有配置参数
    """
    print(f"🔍 调试输出: 为{agent_name}获取配置...")

    config_dict: Dict[str, Any] = {}

    # 1. 优先使用传入的配置对象，并允许后续补全缺失字段
    if fallback_config:
        print(f"🔍 调试输出: 从fallback_config获取配置...")
        config_dict.update({
            'openai_api_base': getattr(fallback_config, 'openai_api_base', None),
            'openai_api_key': getattr(fallback_config, 'openai_api_key', None),
            'openai_model': getattr(fallback_config, 'openai_model', None),
            'proxy': getattr(fallback_config, 'proxy', None),
            'language': getattr(fallback_config, 'language', None),
            'enable_streaming': getattr(fallback_config, 'enable_streaming', None)
        })
        print(f"🔍 调试输出: fallback配置状态: api_base={config_dict.get('openai_api_base') is not None}, api_key={config_dict.get('openai_api_key') is not None}")
    else:
        print(f"🔍 调试输出: 没有提供fallback_config")

    # 2. 使用JSON配置补全缺失字段
    print(f"🔍 调试输出: 尝试从JSON配置文件加载配置...")
    json_config = load_config_from_json()
    if json_config:
        llm_config = json_config.get('llm', {})
        project_config = json_config.get('project', {})

        print(f"🔍 调试输出: JSON配置结构:")
        print(f"   - llm: {list(llm_config.keys()) if llm_config else 'None'}")
        print(f"   - project: {list(project_config.keys()) if project_config else 'None'}")

        # 显示关键配置值的详细信息（脱敏处理）
        print(f"🔍 调试输出: LLM配置详情:")
        if llm_config:
            api_base_raw = llm_config.get('api_base')
            api_key_raw = llm_config.get('api_key')
            model_raw = llm_config.get('model')
            print(f"   - api_base (原始): {repr(api_base_raw)} (类型: {type(api_base_raw).__name__})")
            print(f"   - api_key (原始): {repr(api_key_raw) if api_key_raw is None else '***已设置***'} (类型: {type(api_key_raw).__name__})")
            print(f"   - model (原始): {repr(model_raw)} (类型: {type(model_raw).__name__})")

        resolved_model = (
            llm_config.get('model')
            or llm_config.get('openai_model')
            or config_dict.get('openai_model')
            or 'gpt-4o'
        )

        # 获取API配置，确保不使用null值
        base_from_json = None
        key_from_json = None

        # 检查 api_base
        api_base_val = llm_config.get('api_base') or llm_config.get('openai_api_base')
        if api_base_val is not None and api_base_val.strip() != "":
            base_from_json = api_base_val

        # 检查 api_key
        api_key_val = llm_config.get('api_key') or llm_config.get('openai_api_key')
        if api_key_val is not None and api_key_val.strip() != "":
            key_from_json = api_key_val

            # 显示处理后的配置值
        print(f"🔍 调试输出: 处理后的API配置:")
        print(f"   - base_from_json: {repr(base_from_json) if base_from_json else 'None'}")
        print(f"   - key_from_json: {'***已设置***' if key_from_json else 'None'}")
        print(f"   - resolved_model: {repr(resolved_model) if resolved_model else 'None'}")

        proxy_from_json = llm_config.get('proxy')
        language_from_json = project_config.get('language')
        streaming_from_json = project_config.get('enable_streaming')

        # 更新配置，优先使用已有值
        if not config_dict.get('openai_api_base') and base_from_json:
            config_dict['openai_api_base'] = base_from_json
            print(f"✅ 从JSON获取api_base: {base_from_json}")
        if not config_dict.get('openai_api_key') and key_from_json:
            config_dict['openai_api_key'] = key_from_json
            print(f"✅ 从JSON获取api_key: ***已设置***")
        if not config_dict.get('openai_model') and resolved_model:
            config_dict['openai_model'] = resolved_model
            print(f"✅ 从JSON获取model: {resolved_model}")
        if not config_dict.get('proxy') and proxy_from_json:
            config_dict['proxy'] = proxy_from_json
        if not config_dict.get('language') and language_from_json:
            config_dict['language'] = language_from_json
        if config_dict.get('enable_streaming') is None and streaming_from_json is not None:
            config_dict['enable_streaming'] = streaming_from_json
    else:
        print(f"❌ 无法从JSON文件加载配置")

    # 3. 环境变量作为最终兜底
    print(f"🔍 调试输出: 检查环境变量...")
    env_base = os.getenv('OPENAI_API_BASE')
    env_key = os.getenv('OPENAI_API_KEY')
    env_model = os.getenv('OPENAI_MODEL')
    env_proxy = os.getenv('OPENAI_PROXY')

    if not config_dict.get('openai_api_base') and env_base:
        config_dict['openai_api_base'] = env_base
        print(f"✅ 从环境变量获取api_base: {env_base}")
    if not config_dict.get('openai_api_key') and env_key:
        config_dict['openai_api_key'] = env_key
        print(f"✅ 从环境变量获取api_key: ***已设置***")
    if not config_dict.get('openai_model') and env_model:
        config_dict['openai_model'] = env_model
        print(f"✅ 从环境变量获取model: {env_model}")
    elif not config_dict.get('openai_model'):
        config_dict['openai_model'] = 'gpt-4o'
        print(f"🔍 调试输出: 使用默认模型: gpt-4o")
    if not config_dict.get('proxy') and env_proxy:
        config_dict['proxy'] = env_proxy

    # 4. 设置默认值
    if not config_dict.get('language'):
        config_dict['language'] = 'zh'
    if config_dict.get('enable_streaming') is None:
        config_dict['enable_streaming'] = True

    print(f"🔍 调试输出: 最终配置状态:")
    print(f"   - api_base: {config_dict.get('openai_api_base') is not None}")
    print(f"   - api_key: {config_dict.get('openai_api_key') is not None}")
    print(f"   - model: {repr(config_dict.get('openai_model'))}")
    print(f"   - language: {config_dict.get('language')}")
    print(f"   - streaming: {config_dict.get('enable_streaming')}")

    return config_dict


def _run_async(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    # If there is already a running loop, execute in a new loop on a thread
    import concurrent.futures

    def runner():
        new_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(new_loop)
        try:
            return new_loop.run_until_complete(coro)
        finally:
            new_loop.close()

    with concurrent.futures.ThreadPoolExecutor() as ex:
        fut = ex.submit(runner)
        return fut.result()


def process_data_via_subagent(input_data: Union[str, List[str], Any], species: Optional[str] = None, config: Optional[MainConfigManager] = None) -> Dict:
    # 测试用，直接返回
    # return({'success': True,
    # 'output_file_paths': {'rds_file': '/root/code/gitpackage/celltypeAgent/utils/sce.rds',
    # 'h5ad_file': None,
    # 'h5_file': '/root/code/gitpackage/celltypeAgent/utils/.celltype_cache/sce_20250917_024836.h5',
    # 'json_file': '/root/code/gitpackage/celltypeAgent/utils/.celltype_cache/cluster_marker_genes_20250917_024836.json'}})
    from celltypeAgent.dataagent.config.settings import ConfigManager
    from celltypeAgent.dataagent.agent.data_processor_agent import DataProcessorReactAgent

    async def _run():
        agent = None
        try:
            # 使用新的配置加载逻辑
            print(f"🔍 调试输出: 开始获取DataAgent配置...")
            config_dict = get_subagent_config('celltypeDataAgent', config)

            # 验证关键配置项
            api_base = config_dict.get('openai_api_base')
            api_key = config_dict.get('openai_api_key')
            model = config_dict.get('openai_model', 'gpt-4o')

            print(f"🔍 调试输出: API Base: {api_base if api_base else 'None'}")
            print(f"🔍 调试输出: API Key: {'***已设置***' if api_key else 'None'}")
            print(f"🔍 调试输出: Model: {model}")

            # 配置完整性检查
            if not api_base or not api_key:
                error_msg = f"DataAgent配置不完整: api_base={api_base is not None}, api_key={api_key is not None}"
                print(f"❌ {error_msg}")
                return {"success": False, "error": error_msg}

            sub_config = ConfigManager(
                openai_api_base=api_base,
                openai_api_key=api_key,
                openai_model=model,
                proxy=config_dict.get('proxy')
            )

            # 从配置中获取语言、流式设置和日志控制
            language = config_dict.get('language', 'zh')
            enable_streaming = config_dict.get('enable_streaming', True)

            # 精细化日志控制 - 优先从配置读取，默认关闭控制台输出但保留文件输出
            console_output = config_dict.get('console_output', False)
            file_output = config_dict.get('file_output', True)

            # 🌟 获取 MainAgent 的 session_id 准备传递
            from celltypeAgent.mainagent.config.session_config import get_session_id
            main_session_id = get_session_id()

            print(f"🔍 调试输出: 创建DataAgent实例，传递session_id: {main_session_id}")
            agent = DataProcessorReactAgent(
                config=sub_config,
                language=language,
                enable_streaming=enable_streaming,
                console_output=console_output,
                file_output=file_output,
                session_id=main_session_id
            )

            print(f"🔍 调试输出: 初始化DataAgent...")
            if not await agent.initialize():
                error_msg = "DataAgent MCP服务器启动失败"
                print(f"❌ {error_msg}")
                return {"success": False, "error": error_msg}

            print(f"🔍 调试输出: DataAgent初始化成功，开始处理数据...")
            print(f"🔍 调试输出: 传递物种参数: {species}")
            result = await agent.process_data(input_data, species=species)
            print(f"🔍 调试输出: 数据处理完成，结果: {result.get('success', False)}")

            # 🌟 提取 DataAgent 返回的物种信息
            detected_species = result.get("detected_species")
            if detected_species:
                print(f"✅ DataAgent检测到物种: {detected_species}")

            # 提取核心路径信息，用于防止LLM遗忘
            output_paths = result.get("output_file_paths", {})
            remember_paths = {
                "json_file": output_paths.get("json_file"),
                "h5_file": output_paths.get("h5_file"),
                "rds_file": output_paths.get("rds_file"),
                "h5ad_file": output_paths.get("h5ad_file"),
            }
            # 过滤掉None值
            remember_paths = {k: v for k, v in remember_paths.items() if v is not None}

            # DataAgent 的 LLM 会在内部自己调用 save_file_paths_bundle 保存路径
            # 不再需要在这里自动保存

            return {
                "success": result.get("success", True),
                "final_result": result.get("final_result"),
                "output_file_paths": output_paths,
                "remember_paths": remember_paths,  # 新增：核心路径信息，防止LLM遗忘
                "detected_species": detected_species,  # 🌟 新增：DataAgent检测到的物种
                "species_detection_info": result.get("species_detection_info"),  # 物种检测详情
            }
        except Exception as e:
            import traceback
            error_msg = f"DataAgent调用异常: {str(e)}"
            print(f"❌ {error_msg}")
            print(f"🔍 调试输出: 异常详情:\n{traceback.format_exc()}")
            return {"success": False, "error": error_msg}
        finally:
            if agent:
                try:
                    print(f"🔍 调试输出: 清理DataAgent资源...")
                    await agent.cleanup()
                except Exception as cleanup_e:
                    print(f"⚠️ DataAgent资源清理失败: {cleanup_e}")

    return _run_async(_run())


def run_annotation_via_subagent(
    rds_path: Optional[str],
    h5ad_path: Optional[str],
    tissue_description: Optional[str] = None,
    marker_json_path: Optional[str] = None,
    species: Optional[str] = None,
    h5_path: Optional[str] = None,
    cluster_column: Optional[str] = None,
    detected_species_from_data: Optional[str] = None,  # 🌟 新增：从DataAgent传递的物种
    config: Optional[MainConfigManager] = None,
) -> Dict:
    from celltypeAgent.appagent.config.settings import ConfigManager
    from celltypeAgent.appagent.agent.celltype_annotation_agent import CelltypeAnnotationAgent

    async def _run():
        agent = None
        try:
            # 使用新的配置加载逻辑
            config_dict = get_subagent_config('celltypeAppAgent', config)
            sub_config = ConfigManager(
                openai_api_base=config_dict.get('openai_api_base'),
                openai_api_key=config_dict.get('openai_api_key'),
                openai_model=config_dict.get('openai_model', 'gpt-4o'),
                proxy=config_dict.get('proxy')
            )

            # 从配置中获取语言、流式设置和日志控制
            language = config_dict.get('language', 'zh')
            enable_streaming = config_dict.get('enable_streaming', True)

            # 精细化日志控制 - 优先从配置读取，默认关闭控制台输出但保留文件输出
            console_output = config_dict.get('console_output', False)
            file_output = config_dict.get('file_output', True)

            # 🌟 获取 MainAgent 的 session_id 准备传递
            from celltypeAgent.mainagent.config.session_config import get_session_id
            main_session_id = get_session_id()

            # 🌟 物种优先级逻辑: 用户指定 > DataAgent检测
            final_species = species or detected_species_from_data
            if final_species:
                print(f"✅ 使用物种参数: {final_species} (来源: {'用户指定' if species else 'DataAgent检测'})")
            else:
                print(f"⚠️ 未提供物种参数，AppAgent将自行检测")

            print(f"🔍 调试输出: 创建AppAgent实例，传递session_id: {main_session_id}")
            agent = CelltypeAnnotationAgent(
                config=sub_config,
                language=language,
                enable_streaming=enable_streaming,
                console_output=console_output,
                file_output=file_output,
                session_id=main_session_id
            )
            if not await agent.initialize():
                return {"success": False, "error": "Failed to start MCP server (AppAgent)"}

            result = await agent.annotate(
                rds_path=rds_path,
                h5ad_path=h5ad_path,
                tissue_description=tissue_description,
                marker_json_path=marker_json_path,
                species=final_species,  # 🌟 传递合并后的物种
                h5_path=h5_path,
                cluster_column=cluster_column,
            )

            # 提取核心路径信息，用于防止LLM遗忘
            output_paths = result.get("output_file_paths", {})
            remember_paths = {
                "singler_result": output_paths.get("singler_result"),
                "sctype_result": output_paths.get("sctype_result"),
                "celltypist_result": output_paths.get("celltypist_result"),
                "rds_file": rds_path,
                "h5ad_file": h5ad_path,
                "h5_file": h5_path,
                "json_file": marker_json_path,
            }
            # 过滤掉None值
            remember_paths = {k: v for k, v in remember_paths.items() if v is not None}

            # AppAgent 的 LLM 会在内部自己调用 save_file_paths_bundle 保存所有7个路径
            # 不再需要在这里自动保存

            return {
                "success": result.get("success", True),
                "final_answer": result.get("final_answer"),
                "output_file_paths": output_paths,
                "remember_paths": remember_paths,  # 新增：核心路径信息，防止LLM遗忘
            }
        except Exception as e:
            return {"success": False, "error": f"细胞类型注释失败: {str(e)}"}
        finally:
            if agent:
                try:
                    await agent.cleanup()
                except Exception:
                    pass

    return _run_async(_run())


def analyze_gene_list_via_subagent(
    gene_list: str,
    tissue_type: Optional[str] = None,
    species: Optional[str] = None,  # 🌟 新增：物种参数
    config: Optional[MainConfigManager] = None
) -> Dict:
    from celltypeAgent.subagent.config.settings import ConfigManager
    from celltypeAgent.subagent.agent.celltype_react_agent import CellTypeReactAgent

    async def _run():
        agent = None
        try:
            # 使用新的配置加载逻辑
            config_dict = get_subagent_config('celltypeSubagent', config)
            sub_config = ConfigManager(
                openai_api_base=config_dict.get('openai_api_base'),
                openai_api_key=config_dict.get('openai_api_key'),
                openai_model=config_dict.get('openai_model', 'gpt-4o'),
                proxy=config_dict.get('proxy')
            )

            # 从配置中获取语言、流式设置和日志控制
            language = config_dict.get('language', 'zh')
            enable_streaming = config_dict.get('enable_streaming', True)

            # 精细化日志控制 - 优先从配置读取，默认关闭控制台输出但保留文件输出
            console_output = config_dict.get('console_output', False)
            file_output = config_dict.get('file_output', True)

            # 🌟 获取 MainAgent 的 session_id 准备传递
            from celltypeAgent.mainagent.config.session_config import get_session_id
            main_session_id = get_session_id()

            # 🌟 记录物种信息
            if species:
                print(f"✅ 使用物种参数: {species} (传递给SubAgent)")
            else:
                print(f"⚠️ 未提供物种参数，SubAgent将自行检测")

            print(f"🔍 调试输出: 创建SubAgent实例，传递session_id: {main_session_id}")
            agent = CellTypeReactAgent(
                config=sub_config,
                language=language,
                enable_streaming=enable_streaming,
                console_output=console_output,
                file_output=file_output,
                session_id=main_session_id
            )
            if not await agent.initialize():
                return {"success": False, "error": "Failed to start MCP server (Subagent)"}

            result = await agent.analyze_celltype(gene_list=gene_list, tissue_type=tissue_type, species=species)

            # 如果result已经是dict，在其中添加remember_paths
            if isinstance(result, dict):
                # 🆕 自动从当前会话路径包读取路径，防止长循环中路径丢失（第四阶段 - Subagent循环）
                remember_paths = {}
                try:
                    from celltypeAgent.mainagent.tools.file_paths_tools import load_file_paths_bundle

                    print(f"🔍 调试输出: 尝试从当前会话路径包读取路径...")

                    # 加载当前会话的路径包
                    loaded_paths = load_file_paths_bundle()
                    if loaded_paths.get("success"):
                        # 提取需要echo的路径
                        if loaded_paths.get("json_file"):
                            remember_paths["json_file"] = loaded_paths["json_file"]
                        if loaded_paths.get("singler_result"):
                            remember_paths["singler_result"] = loaded_paths["singler_result"]
                        if loaded_paths.get("sctype_result"):
                            remember_paths["sctype_result"] = loaded_paths["sctype_result"]
                        if loaded_paths.get("celltypist_result"):
                            remember_paths["celltypist_result"] = loaded_paths["celltypist_result"]

                        if remember_paths:
                            result["remember_paths"] = remember_paths
                            print(f"✅ 已从路径包读取并echo路径: {list(remember_paths.keys())}")
                    else:
                        print(f"⚠️ 加载路径包失败: {loaded_paths.get('error')}")

                except Exception as e:
                    print(f"⚠️ 读取路径包时出错: {e}")
                    import traceback
                    print(f"   详细信息: {traceback.format_exc()}")

                # 添加基因列表信息到返回值中，虽然不是文件路径，但有助于LLM记住上下文
                result["remember_context"] = {
                    "gene_list": gene_list[:200] if len(gene_list) > 200 else gene_list,  # 截断过长的基因列表
                    "tissue_type": tissue_type,
                }

            return result
        except Exception as e:
            return {"success": False, "error": f"基因列表分析失败: {str(e)}"}
        finally:
            if agent:
                try:
                    await agent.cleanup()
                except Exception:
                    pass

    return _run_async(_run())



# ========== 简化的函数名，与main_agent.py保持一致 ==========

def process_data(input_data: Union[str, List[str], Any], species: Optional[str] = None, config: Optional[MainConfigManager] = None) -> Dict:
    """调用 celltypeDataAgent 的数据处理 Agent - 简化版本"""
    return process_data_via_subagent(input_data, species=species, config=config)


def run_annotation_pipeline(
    rds_path: Optional[str],
    h5ad_path: Optional[str],
    tissue_description: Optional[str] = None,
    marker_json_path: Optional[str] = None,
    species: Optional[str] = None,
    h5_path: Optional[str] = None,
    cluster_column: Optional[str] = None,
    config: Optional[MainConfigManager] = None,
) -> Dict:
    """调用 celltypeAppAgent 的应用级注释 Agent - 简化版本"""
    return run_annotation_via_subagent(
        rds_path,
        h5ad_path,
        tissue_description,
        marker_json_path,
        species,
        h5_path,
        cluster_column,
        config,
    )


def analyze_gene_list(gene_list: str, tissue_type: Optional[str] = None, config: Optional[MainConfigManager] = None) -> Dict:
    """调用 celltypeSubagent 的基因列表分析 Agent - 简化版本"""
    return analyze_gene_list_via_subagent(gene_list, tissue_type, config)
