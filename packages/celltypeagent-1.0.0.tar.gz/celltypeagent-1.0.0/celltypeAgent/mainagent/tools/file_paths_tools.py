#!/usr/bin/env python3
"""
celltypeAgent - 文件路径保存工具模块
Author: cuilei
Version: 1.0
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, asdict
import sys

# 导入项目模块

# 导入统一配置系统
from celltypeAgent.config import get_temp_dir, get_cache_dir as global_get_cache_dir


@dataclass
class FilePathsInfo:
    """文件路径信息数据结构 - 专注于7个核心文件"""
    session_id: str                          # 会话唯一标识
    timestamp: str                           # 创建时间戳
    # 核心数据文件（4个）
    rds_file: Optional[str] = None          # RDS文件路径
    h5ad_file: Optional[str] = None         # H5AD文件路径
    h5_file: Optional[str] = None           # H5文件路径
    json_file: Optional[str] = None         # JSON文件路径
    # AppAgent输出文件（3个）
    singler_result: Optional[str] = None    # SingleR结果文件路径
    sctype_result: Optional[str] = None     # scType结果文件路径
    celltypist_result: Optional[str] = None # CellTypist结果文件路径
    # 可选元数据
    metadata: Optional[Dict[str, Any]] = None # 额外元数据（非必须）

    def __post_init__(self):
        """初始化默认值"""
        if self.metadata is None:
            self.metadata = {}

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'FilePathsInfo':
        """从字典创建实例"""
        return cls(**data)


class FilePathsManager:
    """文件路径管理器"""

    def __init__(self):
        # 直接使用 cache 目录作为唯一存储位置
        self.bundle_dir = self._get_bundle_directory()
        self.bundle_prefix = "celltype_file_paths_"
        self.bundle_suffix = ".json"
        self.default_expiry_hours = 24  # 默认过期时间24小时

    def _get_bundle_directory(self) -> Path:
        """获取路径包存储目录（cache目录）

        优点：
        1. 每个项目独立目录，避免多项目冲突
        2. 持久化存储，不会被系统清理
        3. 便于调试和查看
        """
        try:
            # 使用统一配置系统
            bundle_dir = global_get_cache_dir("celltypeMainagent/path_bundles")
            bundle_dir.mkdir(exist_ok=True, parents=True)
            return bundle_dir
        except Exception as e:
            # 如果创建失败，抛出异常
            raise RuntimeError(f"无法创建路径包目录: {e}")

    def _generate_bundle_filename(self, session_id: str) -> str:
        """生成文件包文件名"""
        return f"{self.bundle_prefix}{session_id}{self.bundle_suffix}"

    def _validate_file_path(self, file_path: Optional[str]) -> bool:
        """验证文件路径的安全性和有效性"""
        # None 或空字符串都视为"未提供"，允许通过
        if file_path is None or file_path.strip() == "":
            return True

        try:
            path = Path(file_path)
            # 检查路径是否存在
            if not path.exists():
                return False
            # 检查是否为文件
            if not path.is_file():
                return False
            # 基本安全检查（避免路径遍历攻击）
            resolved_path = path.resolve()
            return True
        except Exception:
            return False

    def save_file_paths_bundle(
        self,
        rds_file: Optional[str] = None,
        h5ad_file: Optional[str] = None,
        h5_file: Optional[str] = None,
        json_file: Optional[str] = None,
        singler_result: Optional[str] = None,
        sctype_result: Optional[str] = None,
        celltypist_result: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None,
        expiry_hours: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        保存文件路径信息包到临时目录

        Args:
            rds_file: RDS文件路径
            h5ad_file: H5AD文件路径
            h5_file: H5文件路径
            json_file: JSON文件路径
            singler_result: SingleR结果文件路径
            sctype_result: scType结果文件路径
            celltypist_result: CellTypist结果文件路径
            metadata: 额外元数据（非必须）
            session_id: 会话ID（如果不提供则自动生成）
            expiry_hours: 过期时间（小时）

        Returns:
            包含保存结果的字典
        """
        try:
            # 生成会话ID
            if session_id is None:
                from celltypeAgent.mainagent.config.session_config import get_session_id
                session_id = get_session_id()

            # 验证文件路径
            file_paths = {
                'rds_file': rds_file,
                'h5ad_file': h5ad_file,
                'h5_file': h5_file,
                'json_file': json_file,
                'singler_result': singler_result,
                'sctype_result': sctype_result,
                'celltypist_result': celltypist_result
            }

            invalid_paths = []
            for name, path in file_paths.items():
                if path is not None and not self._validate_file_path(path):
                    invalid_paths.append(f"{name}: {path}")

            if invalid_paths:
                return {
                    "success": False,
                    "error": f"无效的文件路径: {', '.join(invalid_paths)}"
                }

            # 创建文件路径信息对象
            timestamp = datetime.now().isoformat()
            if expiry_hours is None:
                expiry_hours = self.default_expiry_hours

            # 添加过期时间到元数据
            if metadata is None:
                metadata = {}
            metadata['expiry_time'] = (datetime.now() + timedelta(hours=expiry_hours)).isoformat()

            file_paths_info = FilePathsInfo(
                session_id=session_id,
                timestamp=timestamp,
                rds_file=rds_file,
                h5ad_file=h5ad_file,
                h5_file=h5_file,
                json_file=json_file,
                singler_result=singler_result,
                sctype_result=sctype_result,
                celltypist_result=celltypist_result,
                metadata=metadata
            )

            # 保存到文件
            bundle_filename = self._generate_bundle_filename(session_id)
            bundle_path = self.bundle_dir / bundle_filename

            with open(bundle_path, 'w', encoding='utf-8') as f:
                json.dump(file_paths_info.to_dict(), f, ensure_ascii=False, indent=2)

            # 保存后立即验证：确保文件正确写入且可读回
            verification_passed = False
            verification_error = None
            try:
                # 1. 验证文件存在
                if not bundle_path.exists():
                    verification_error = "保存的bundle文件不存在"
                else:
                    # 2. 验证文件可读且内容完整
                    with open(bundle_path, 'r', encoding='utf-8') as f:
                        saved_data = json.load(f)

                    # 3. 验证关键字段
                    if saved_data.get('session_id') != session_id:
                        verification_error = f"session_id不匹配: 期望{session_id}, 实际{saved_data.get('session_id')}"
                    elif saved_data.get('json_file') != json_file:
                        verification_error = f"json_file不匹配: 期望{json_file}, 实际{saved_data.get('json_file')}"
                    else:
                        verification_passed = True
            except Exception as e:
                verification_error = f"验证失败: {str(e)}"

            result = {
                "success": True,
                "session_id": session_id,
                "bundle_path": str(bundle_path),
                "timestamp": timestamp,
                "expiry_hours": expiry_hours,
                "file_count": sum(1 for path in [rds_file, h5ad_file, h5_file, json_file, singler_result, sctype_result, celltypist_result] if path),
                # 验证信息
                "verified": verification_passed,
                "verification_error": verification_error
            }

            # 如果验证失败，在返回中添加警告（但不标记success=False，因为文件已保存）
            if not verification_passed:
                result["warning"] = f"文件已保存但验证失败: {verification_error}"

            return result

        except Exception as e:
            return {
                "success": False,
                "error": f"保存文件路径包失败: {str(e)}"
            }

    def load_file_paths_bundle(self) -> Dict[str, Any]:
        """
        从cache目录加载当前会话的文件路径信息包

        自动使用当前会话ID定位文件路径包。

        Returns:
            包含文件路径信息的字典
        """
        try:
            # 自动获取当前会话ID
            from celltypeAgent.mainagent.config.session_config import get_session_id
            session_id = get_session_id()

            bundle_filename = self._generate_bundle_filename(session_id)
            bundle_path = self.bundle_dir / bundle_filename

            if not bundle_path.exists():
                return {
                    "success": False,
                    "error": f"未找到会话ID为 {session_id} 的文件路径包"
                }

            # 读取文件
            with open(bundle_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            file_paths_info = FilePathsInfo.from_dict(data)

            # 检查是否过期
            if 'expiry_time' in file_paths_info.metadata:
                expiry_time = datetime.fromisoformat(file_paths_info.metadata['expiry_time'])
                if datetime.now() > expiry_time:
                    # 自动清理过期文件
                    bundle_path.unlink(missing_ok=True)
                    return {
                        "success": False,
                        "error": f"文件路径包已过期 (过期时间: {expiry_time.isoformat()})"
                    }

            result = {
                "success": True,
                "session_id": file_paths_info.session_id,
                "timestamp": file_paths_info.timestamp,
                "rds_file": file_paths_info.rds_file,
                "h5ad_file": file_paths_info.h5ad_file,
                "h5_file": file_paths_info.h5_file,
                "json_file": file_paths_info.json_file,
                "singler_result": file_paths_info.singler_result,
                "sctype_result": file_paths_info.sctype_result,
                "celltypist_result": file_paths_info.celltypist_result,
                "metadata": file_paths_info.metadata
            }

            return result

        except Exception as e:
            return {
                "success": False,
                "error": f"加载文件路径包失败: {str(e)}"
            }

    def load_and_validate_bundle(self) -> Dict[str, Any]:
        """
        加载当前会话的文件路径包并验证关键文件是否存在

        这是一个安全的加载方法，会在加载后立即验证json_file等关键文件的存在性。
        推荐使用此方法代替load_file_paths_bundle，以避免使用过期的路径包。

        Returns:
            包含文件路径信息和验证结果的字典
        """
        # 先调用标准加载
        result = self.load_file_paths_bundle()

        if not result.get("success"):
            return result

        # 验证关键文件存在性
        json_file = result.get("json_file")
        missing_files = []
        existing_files = []

        # 检查所有文件路径
        files_to_check = {
            "json_file": json_file,
            "h5_file": result.get("h5_file"),
            "rds_file": result.get("rds_file"),
            "h5ad_file": result.get("h5ad_file"),
            "singler_result": result.get("singler_result"),
            "sctype_result": result.get("sctype_result"),
            "celltypist_result": result.get("celltypist_result"),
        }

        for file_type, file_path in files_to_check.items():
            if file_path:
                if Path(file_path).exists():
                    existing_files.append(file_type)
                else:
                    missing_files.append(file_type)

        # 如果json_file不存在，标记为验证失败
        if json_file and not Path(json_file).exists():
            result["success"] = False
            result["error"] = f"路径包中的关键文件已不存在: {json_file}"
            result["validation_failed"] = True
            result["missing_files"] = missing_files
            result["existing_files"] = existing_files
            return result

        # 添加验证信息
        result["validated"] = True
        result["missing_files"] = missing_files
        result["existing_files"] = existing_files
        result["all_files_exist"] = len(missing_files) == 0

        return result

    def list_saved_bundles(self, include_expired: bool = False, validate_files: bool = True) -> Dict[str, Any]:
        """
        列出所有已保存的文件路径包

        Args:
            include_expired: 是否包含已过期的包
            validate_files: 是否验证文件存在性（默认True，推荐开启以过滤过期路径包）

        Returns:
            包含所有文件路径包信息的字典
        """
        try:
            bundles = []
            bundle_files = list(self.bundle_dir.glob(f"{self.bundle_prefix}*{self.bundle_suffix}"))

            for bundle_file in bundle_files:
                try:
                    with open(bundle_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)

                    file_paths_info = FilePathsInfo.from_dict(data)

                    # 检查是否过期
                    is_expired = False
                    if 'expiry_time' in file_paths_info.metadata:
                        expiry_time = datetime.fromisoformat(file_paths_info.metadata['expiry_time'])
                        is_expired = datetime.now() > expiry_time

                    if not include_expired and is_expired:
                        continue

                    # 新增：验证关键文件是否存在
                    files_exist = True
                    json_file_exists = False
                    if validate_files:
                        # 检查json_file（最关键的文件）
                        json_file = file_paths_info.json_file
                        if json_file:
                            json_file_exists = Path(json_file).exists()
                            files_exist = json_file_exists
                        else:
                            files_exist = False

                        # 如果关键文件不存在，跳过这个路径包
                        if not files_exist:
                            continue

                    bundle_info = {
                        "session_id": file_paths_info.session_id,
                        "timestamp": file_paths_info.timestamp,
                        "file_count": sum(1 for path in [
                            file_paths_info.rds_file,
                            file_paths_info.h5ad_file,
                            file_paths_info.h5_file,
                            file_paths_info.json_file,
                            file_paths_info.singler_result,
                            file_paths_info.sctype_result,
                            file_paths_info.celltypist_result
                        ] if path),
                        "is_expired": is_expired,
                        "bundle_path": str(bundle_file),
                        # 新增：显示关键文件路径，方便LLM识别
                        "json_file": file_paths_info.json_file,
                        "files_exist": files_exist,  # 新增：文件存在性标记
                    }

                    if 'expiry_time' in file_paths_info.metadata:
                        bundle_info['expiry_time'] = file_paths_info.metadata['expiry_time']

                    bundles.append(bundle_info)

                except Exception as e:
                    # 跳过损坏的文件
                    continue

            # 按时间戳排序（最新的在前）
            bundles.sort(key=lambda x: x['timestamp'], reverse=True)

            return {
                "success": True,
                "total_count": len(bundles),
                "bundles": bundles,
                "validated": validate_files,  # 新增：标记是否进行了验证
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"列出文件路径包失败: {str(e)}"
            }

    def clear_expired_bundles(self) -> Dict[str, Any]:
        """
        清理过期的文件路径包

        Returns:
            清理结果字典
        """
        try:
            cleaned_count = 0
            error_count = 0
            bundle_files = list(self.bundle_dir.glob(f"{self.bundle_prefix}*{self.bundle_suffix}"))

            for bundle_file in bundle_files:
                try:
                    with open(bundle_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)

                    file_paths_info = FilePathsInfo.from_dict(data)

                    # 检查是否过期
                    if 'expiry_time' in file_paths_info.metadata:
                        expiry_time = datetime.fromisoformat(file_paths_info.metadata['expiry_time'])
                        if datetime.now() > expiry_time:
                            bundle_file.unlink()
                            cleaned_count += 1

                except Exception:
                    error_count += 1
                    # 尝试删除损坏的文件
                    try:
                        bundle_file.unlink()
                        cleaned_count += 1
                    except Exception:
                        pass

            return {
                "success": True,
                "cleaned_count": cleaned_count,
                "error_count": error_count
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"清理过期文件包失败: {str(e)}"
            }

    def delete_bundle(self, session_id: str) -> Dict[str, Any]:
        """
        删除指定的文件路径包

        Args:
            session_id: 会话ID

        Returns:
            删除结果字典
        """
        try:
            bundle_filename = self._generate_bundle_filename(session_id)
            bundle_path = self.bundle_dir / bundle_filename

            if not bundle_path.exists():
                return {
                    "success": False,
                    "error": f"未找到会话ID为 {session_id} 的文件路径包"
                }

            bundle_path.unlink()

            return {
                "success": True,
                "session_id": session_id,
                "message": "文件路径包删除成功"
            }

        except Exception as e:
            return {
                "success": False,
                "error": f"删除文件路径包失败: {str(e)}"
            }


# 创建全局管理器实例
_file_paths_manager = FilePathsManager()


# 导出的便捷函数
def save_file_paths_bundle(
    rds_file: Optional[str] = None,
    h5ad_file: Optional[str] = None,
    h5_file: Optional[str] = None,
    json_file: Optional[str] = None,
    singler_result: Optional[str] = None,
    sctype_result: Optional[str] = None,
    celltypist_result: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    session_id: Optional[str] = None,
    expiry_hours: Optional[int] = None
) -> Dict[str, Any]:
    """保存文件路径信息包到系统临时目录"""
    return _file_paths_manager.save_file_paths_bundle(
        rds_file=rds_file,
        h5ad_file=h5ad_file,
        h5_file=h5_file,
        json_file=json_file,
        singler_result=singler_result,
        sctype_result=sctype_result,
        celltypist_result=celltypist_result,
        metadata=metadata,
        session_id=session_id,
        expiry_hours=expiry_hours
    )


def load_file_paths_bundle() -> Dict[str, Any]:
    """从临时目录加载当前会话的文件路径信息包"""
    return _file_paths_manager.load_file_paths_bundle()


def load_and_validate_bundle() -> Dict[str, Any]:
    """加载当前会话的文件路径包并验证关键文件是否存在

    这是一个安全的加载方法，推荐使用此方法代替load_file_paths_bundle。
    会在加载后立即验证json_file等关键文件的存在性，避免使用过期的路径包。

    Returns:
        包含文件路径信息和验证结果的字典，包括:
        - validated: 是否进行了验证
        - missing_files: 缺失的文件列表
        - existing_files: 存在的文件列表
        - all_files_exist: 是否所有文件都存在
    """
    return _file_paths_manager.load_and_validate_bundle()


def list_saved_bundles(include_expired: bool = False, validate_files: bool = True) -> Dict[str, Any]:
    """列出所有已保存的文件路径包

    Args:
        include_expired: 是否包含已过期的包
        validate_files: 是否验证文件存在性（默认True，过滤过期路径包）
    """
    return _file_paths_manager.list_saved_bundles(include_expired, validate_files)


def clear_expired_bundles() -> Dict[str, Any]:
    """清理过期的文件路径包"""
    return _file_paths_manager.clear_expired_bundles()


def delete_bundle(session_id: str) -> Dict[str, Any]:
    """删除指定的文件路径包"""
    return _file_paths_manager.delete_bundle(session_id)