#!/usr/bin/env python3
"""
celltypeAgent - Data Processor MCP Server
Author: cuilei
Version: 1.0
"""

import sys
import asyncio
import json
import os
from typing import Optional, Dict, Any
from pathlib import Path

# 导入项目模块

# 导入国际化支持
try:
    from celltypeAgent.dataagent.utils.i18n import _
except ImportError:
    # 如果国际化模块不存在，提供简单的占位符
    def _(key, **kwargs):
        return key.format(**kwargs) if kwargs else key

try:
    from mcp.server.fastmcp import FastMCP
    # 直接导入核心处理函数
    from celltypeAgent.dataagent.tools.data_converters import (
        run_r_findallmarkers,
        run_r_sce_to_h5,
        convert_r_markers_csv_to_json,
        easyscfpy_h5_to_json,
        scanpy_path_to_json,
        convert_scanpy_file_to_h5
    )
    # 导入配置函数用于构建实际输出路径
    from celltypeAgent.config import get_results_dir, get_session_id_for_filename
    # 导入路径管理工具
    from celltypeAgent.mainagent.tools.file_paths_tools import (
        save_file_paths_bundle as _save_file_paths_bundle,
        load_file_paths_bundle as _load_file_paths_bundle,
        load_and_validate_bundle as _load_and_validate_bundle
    )
except ImportError as e:
    # 获取项目根目录
    current_file = Path(__file__).resolve()
    # project_root 不再需要

    print(f"导入依赖失败: {e}")
    print("请检查MCP包安装：pip install mcp")
    print(f"当前工作目录: {Path.cwd()}")
    #
    print(f"Python路径: {sys.path[:3]}")
    sys.exit(1)

# 初始化缓存系统
try:
    from celltypeAgent.dataagent.config.cache_config import init_cache
    cache_dir = init_cache()
except ImportError:
    try:
        from config import get_cache_dir
        cache_dir = get_cache_dir("celltypeDataAgent")
    except ImportError:
        # 如果缓存配置不存在，使用默认目录
        cache_dir = Path.cwd() / ".celltype_cache"
        cache_dir.mkdir(exist_ok=True)

# 导入路径管理器
try:
    from celltypeAgent.dataagent.utils.path_manager import normalize_path, get_absolute_paths
except ImportError:
    # 简单的备用实现
    def normalize_path(file_path):
        return str(Path(file_path).resolve()) if file_path else ""
    def get_absolute_paths(**kwargs):
        return {k: normalize_path(v) for k, v in kwargs.items()}

# 初始化FastMCP服务器
mcp = FastMCP("celltype-data-processor", log_level="INFO")

# 缓存目录配置
CACHE_DIR = str(cache_dir)

def ensure_cache_dir() -> str:
    """确保缓存目录存在"""
    os.makedirs(CACHE_DIR, exist_ok=True)
    return CACHE_DIR

@mcp.tool()
async def run_r_findallmarkers(
    seurat_file: str,
    output_file: Optional[str] = None,
    pval_threshold: float = 0.05
) -> str:
    """运行R FindAllMarkers分析，获取各聚类的标记基因
    
    Args:
        seurat_file: Seurat RDS文件路径
        output_file: 输出JSON文件路径（可选）
        pval_threshold: p值阈值，默认0.05
        
    Returns:
        JSON格式的分析结果
    """
    try:
        ensure_cache_dir()
        
        if output_file is None:
            output_file = os.path.join(CACHE_DIR, 'cluster_marker_genes.json')
        
        print(f"🔬 运行FindAllMarkers分析: {seurat_file}")

        # 使用异步执行器调用处理函数（不再传递 output_file）
        from celltypeAgent.dataagent.tools.data_converters import run_r_findallmarkers as original_func
        marker_genes = await asyncio.get_event_loop().run_in_executor(
            None, original_func, seurat_file, pval_threshold
        )

        if marker_genes is None:
            return json.dumps({
                "success": False,
                "error": "FindAllMarkers分析失败"
            }, ensure_ascii=False, indent=2)

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'cluster_markers_{session_id}.json')

        # 为MCP传输创建精简版本（每个分簇只返回前10个基因）
        preview_marker_genes = {}
        for cluster, genes in marker_genes.items():
            preview_marker_genes[cluster] = genes[:10] if len(genes) > 10 else genes

        result = {
            "success": True,
            "input_file": seurat_file,
            "output_file": actual_output_file,
            "pval_threshold": pval_threshold,
            "marker_genes_preview": preview_marker_genes,
            "cluster_count": len(marker_genes),
            "total_genes": sum(len(genes) for genes in marker_genes.values()),
            "note": "完整的marker基因数据已保存到文件，这里只显示每个分簇的前10个基因预览"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"运行FindAllMarkers分析时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def run_r_sce_to_h5(
    seurat_file: str,
    output_file: Optional[str] = None
) -> str:
    """将R SCE对象转换为H5格式
    
    Args:
        seurat_file: Seurat RDS文件路径
        output_file: 输出H5文件路径（可选）
        
    Returns:
        JSON格式的转换结果
    """
    try:
        ensure_cache_dir()
        
        if output_file is None:
            output_file = os.path.join(CACHE_DIR, 'data.h5')
        
        print(f"📁 转换SCE为H5格式: {seurat_file}")

        # 使用异步执行器调用处理函数（不再传递 output_file）
        from celltypeAgent.dataagent.tools.data_converters import run_r_sce_to_h5 as original_func
        h5_result = await asyncio.get_event_loop().run_in_executor(
            None, original_func, seurat_file
        )

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'sce_{session_id}.h5')

        # 修复了返回值检查 - 现在函数返回错误消息而不是None
        if h5_result and "成功" in str(h5_result):
            result = {
                "success": True,
                "input_file": seurat_file,
                "output_file": actual_output_file,
                "file_size": os.path.getsize(actual_output_file) if os.path.exists(actual_output_file) else 0,
                "message": h5_result
            }
        else:
            return json.dumps({
                "success": False,
                "error": h5_result if h5_result else "SCE转H5格式失败"
            }, ensure_ascii=False, indent=2)
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"转换SCE为H5格式时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def convert_r_markers_csv_to_json(
    csv_file: str,
    output_file: Optional[str] = None,
    pval_threshold: float = 0.05
) -> str:
    """转换R FindAllMarkers CSV结果为JSON格式
    
    Args:
        csv_file: CSV文件路径
        output_file: 输出JSON文件路径（可选）
        pval_threshold: p值阈值，默认0.05
        
    Returns:
        JSON格式的转换结果
    """
    try:
        ensure_cache_dir()
        
        if output_file is None:
            output_file = os.path.join(CACHE_DIR, 'cluster_marker_genes.json')
        
        print(f"🔄 转换CSV为JSON格式: {csv_file}")

        # 使用异步执行器调用处理函数（不再传递 output_file）
        from celltypeAgent.dataagent.tools.data_converters import convert_r_markers_csv_to_json as original_func
        marker_genes = await asyncio.get_event_loop().run_in_executor(
            None, original_func, csv_file, pval_threshold
        )

        if marker_genes is None:
            return json.dumps({
                "success": False,
                "error": "CSV转JSON失败"
            }, ensure_ascii=False, indent=2)

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'cluster_marker_genes_{session_id}.json')

        # 为MCP传输创建精简版本（每个分簇只返回前10个基因）
        preview_marker_genes = {}
        for cluster, genes in marker_genes.items():
            preview_marker_genes[cluster] = genes[:10] if len(genes) > 10 else genes

        result = {
            "success": True,
            "input_file": csv_file,
            "output_file": actual_output_file,
            "pval_threshold": pval_threshold,
            "marker_genes_preview": preview_marker_genes,
            "cluster_count": len(marker_genes),
            "total_genes": sum(len(genes) for genes in marker_genes.values()),
            "note": "完整的marker基因数据已保存到文件，这里只显示每个分簇的前10个基因预览"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"转换CSV为JSON时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def easyscfpy_h5_to_json(
    h5_file: str,
    output_file: Optional[str] = None,
    pval_threshold: float = 0.05
) -> str:
    """将easySCF H5文件转换为JSON格式
    
    Args:
        h5_file: H5文件路径
        output_file: 输出JSON文件路径（可选）
        pval_threshold: p值阈值，默认0.05
        
    Returns:
        JSON格式的转换结果
    """
    try:
        ensure_cache_dir()
        
        if output_file is None:
            output_file = os.path.join(CACHE_DIR, 'cluster_marker_genes.json')
        
        print(f"🔄 转换easySCF H5为JSON格式: {h5_file}")

        # 使用异步执行器调用处理函数（不再传递 output_file）
        from celltypeAgent.dataagent.tools.data_converters import easyscfpy_h5_to_json as original_func
        marker_genes = await asyncio.get_event_loop().run_in_executor(
            None, original_func, h5_file, pval_threshold
        )

        if marker_genes is None:
            return json.dumps({
                "success": False,
                "error": "easySCF H5转JSON失败"
            }, ensure_ascii=False, indent=2)

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'cluster_marker_genes_{session_id}.json')

        # 为MCP传输创建精简版本（每个分簇只返回前10个基因）
        preview_marker_genes = {}
        for cluster, genes in marker_genes.items():
            preview_marker_genes[cluster] = genes[:10] if len(genes) > 10 else genes

        result = {
            "success": True,
            "input_file": h5_file,
            "output_file": actual_output_file,
            "pval_threshold": pval_threshold,
            "marker_genes_preview": preview_marker_genes,
            "cluster_count": len(marker_genes),
            "total_genes": sum(len(genes) for genes in marker_genes.values()),
            "note": "完整的marker基因数据已保存到文件，这里只显示每个分簇的前10个基因预览"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"转换easySCF H5为JSON时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def scanpy_path_to_json(
    scanpy_path: str,
    output_file: Optional[str] = None,
    pval_threshold: float = 0.05
) -> str:
    """将scanpy文件路径转换为JSON格式
    
    Args:
        scanpy_path: scanpy文件路径（.h5ad格式）
        output_file: 输出JSON文件路径（可选）
        pval_threshold: p值阈值，默认0.05
        
    Returns:
        JSON格式的转换结果
    """
    try:
        ensure_cache_dir()
        
        if output_file is None:
            output_file = os.path.join(CACHE_DIR, 'cluster_marker_genes.json')
        
        print(f"🔬 转换scanpy文件为JSON格式: {scanpy_path}")

        # 使用异步执行器调用处理函数（不再传递 output_file）
        from celltypeAgent.dataagent.tools.data_converters import scanpy_path_to_json as original_func
        marker_genes = await asyncio.get_event_loop().run_in_executor(
            None, original_func, scanpy_path, pval_threshold
        )

        if marker_genes is None:
            return json.dumps({
                "success": False,
                "error": "scanpy文件转JSON失败"
            }, ensure_ascii=False, indent=2)

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'cluster_marker_genes_{session_id}.json')

        # 为MCP传输创建精简版本（每个分簇只返回前10个基因）
        preview_marker_genes = {}
        for cluster, genes in marker_genes.items():
            preview_marker_genes[cluster] = genes[:10] if len(genes) > 10 else genes

        result = {
            "success": True,
            "input_file": scanpy_path,
            "output_file": actual_output_file,
            "pval_threshold": pval_threshold,
            "marker_genes_preview": preview_marker_genes,
            "cluster_count": len(marker_genes),
            "total_genes": sum(len(genes) for genes in marker_genes.values()),
            "note": "完整的marker基因数据已保存到文件，这里只显示每个分簇的前10个基因预览"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"转换scanpy文件为JSON时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def convert_scanpy_file_to_h5(
    input_file: str,
    h5_file: Optional[str] = None
) -> str:
    """将scanpy数据文件转换为easySCF H5格式
    
    Args:
        input_file: 输入数据文件路径（支持.h5ad等格式）
        h5_file: 输出H5文件路径（可选）
        
    Returns:
        JSON格式的转换结果
    """
    try:
        ensure_cache_dir()
        
        if h5_file is None:
            h5_file = os.path.join(CACHE_DIR, 'data.h5')
        
        print(f"🔄 转换scanpy文件为H5格式: {input_file}")

        # 使用异步执行器调用处理函数（不再传递 h5_file）
        from celltypeAgent.dataagent.tools.data_converters import convert_scanpy_file_to_h5 as original_func
        result_msg = await asyncio.get_event_loop().run_in_executor(
            None, original_func, input_file
        )

        if result_msg is None or "✗" in result_msg:
            return json.dumps({
                "success": False,
                "error": result_msg or "scanpy文件转H5失败"
            }, ensure_ascii=False, indent=2)

        # 构建实际的输出文件路径
        session_id = get_session_id_for_filename()
        results_dir = get_results_dir("celltypeDataAgent")
        actual_output_file = str(results_dir / f'data_{session_id}.h5')

        file_size = os.path.getsize(actual_output_file) if os.path.exists(actual_output_file) else 0

        result = {
            "success": True,
            "message": result_msg,
            "input_file": input_file,
            "output_file": actual_output_file,
            "file_size": f"{file_size / 1024 / 1024:.1f} MB" if file_size > 1024*1024 else f"{file_size / 1024:.1f} KB" if file_size > 1024 else f"{file_size} bytes"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"转换scanpy文件为H5时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def validate_json_only(json_file: str) -> str:
    """专门验证JSON文件格式和内容
    
    Args:
        json_file: JSON文件路径
        
    Returns:
        JSON格式的验证结果
    """
    try:
        if not os.path.exists(json_file):
            return json.dumps({
                "success": False,
                "error": f"JSON文件不存在: {json_file}",
                "valid": False
            }, ensure_ascii=False, indent=2)
        
        file_path_obj = Path(json_file)
        
        # 检查文件扩展名
        if file_path_obj.suffix.lower() != '.json':
            return json.dumps({
                "success": False,
                "error": f"文件不是JSON格式: {json_file}",
                "valid": False,
                "file_extension": file_path_obj.suffix
            }, ensure_ascii=False, indent=2)
        
        # 读取并验证JSON内容
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
        except json.JSONDecodeError as e:
            return json.dumps({
                "success": False,
                "error": f"JSON格式错误: {str(e)}",
                "valid": False,
                "json_decode_error": str(e)
            }, ensure_ascii=False, indent=2)
        
        file_size = file_path_obj.stat().st_size
        
        # 分析JSON内容结构
        content_info = {
            "data_type": type(json_data).__name__,
            "size_bytes": file_size,
            "size_readable": f"{file_size / 1024:.1f} KB" if file_size > 1024 else f"{file_size} bytes"
        }
        
        # 如果是字典，分析键值
        if isinstance(json_data, dict):
            content_info.update({
                "keys": list(json_data.keys()),
                "key_count": len(json_data.keys()),
                "is_marker_genes": "cluster" in str(json_data).lower() or "gene" in str(json_data).lower()
            })
        # 如果是列表，分析元素
        elif isinstance(json_data, list):
            content_info.update({
                "list_length": len(json_data),
                "first_element_type": type(json_data[0]).__name__ if json_data else "empty",
                "is_marker_genes": len(json_data) > 0 and any("gene" in str(item).lower() for item in json_data[:3])
            })
        
        # 特殊检查：是否是marker基因文件
        marker_gene_indicators = [
            "cluster", "gene", "marker", "p_val", "avg_log", "pct"
        ]
        content_str = str(json_data).lower()
        marker_score = sum(1 for indicator in marker_gene_indicators if indicator in content_str)
        
        # 额外检查：如果有cluster键，很可能是marker基因
        cluster_pattern = any("cluster" in str(k).lower() for k in (json_data.keys() if isinstance(json_data, dict) else []))
        content_info["likely_marker_genes"] = marker_score >= 2 or cluster_pattern
        
        result = {
            "success": True,
            "valid": True,
            "file_path": str(file_path_obj),
            "file_name": file_path_obj.name,
            "json_validation": "passed",
            "content_analysis": content_info,
            "processing_recommendation": "ready_for_use" if content_info.get("likely_marker_genes", False) else "general_json"
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"JSON验证过程中发生异常: {str(e)}",
            "valid": False
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def validate_file_type(file_path: str) -> str:
    """识别和验证文件类型
    
    Args:
        file_path: 文件路径
        
    Returns:
        JSON格式的文件类型信息
    """
    try:
        # 使用当前会话的session_id保持一致性
        current_timestamp = get_session_id_for_filename()
        print(f"🕒 使用当前会话session_id: {current_timestamp}")
        
        if not os.path.exists(file_path):
            return json.dumps({
                "success": False,
                "error": f"文件不存在: {file_path}",
                "file_type": "unknown",
                "timestamp": current_timestamp
            }, ensure_ascii=False, indent=2)
        
        file_path_obj = Path(file_path)
        file_size = file_path_obj.stat().st_size
        file_extension = file_path_obj.suffix.lower()
        
        # 基于扩展名判断文件类型
        file_type_map = {
            '.rds': 'rds',
            '.h5': 'h5',
            '.h5ad': 'h5ad',
            '.csv': 'csv',
            '.json': 'json'
        }
        
        file_type = file_type_map.get(file_extension, 'unknown')
        
        result = {
            "success": True,
            "file_path": str(file_path_obj),
            "file_name": file_path_obj.name,
            "file_size": file_size,
            "file_extension": file_extension,
            "file_type": file_type,
            "valid": file_type != 'unknown',
            "timestamp": current_timestamp
        }
        
        # 对JSON文件进行额外验证
        if file_type == 'json':
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                result["json_valid"] = True
                result["json_keys"] = list(json_data.keys()) if isinstance(json_data, dict) else None
            except json.JSONDecodeError as e:
                result["json_valid"] = False
                result["json_error"] = str(e)
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"文件类型验证失败: {str(e)}",
            "file_type": "unknown",
            "timestamp": get_session_id_for_filename()
        }, ensure_ascii=False, indent=2)

@mcp.tool()
async def get_token_stats() -> str:
    """获取DataAgent的token消耗统计信息

    Returns:
        str: JSON格式的token统计信息
    """
    try:
        # 由于MCP服务器是独立进程，这里返回默认的空统计
        # 实际的token统计需要通过agent实例获取
        from celltypeAgent.common.token_statistics import TokenStatistics

        # 创建一个空的统计对象作为占位符
        # 实际应该通过某种IPC机制或共享存储获取真实数据
        stats = TokenStatistics(agent_name="DataAgent")

        return json.dumps({
            "success": True,
            "data": stats.to_dict(),
            "message": "DataAgent token统计 (MCP服务器独立进程)"
        }, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"获取token统计时发生异常: {str(e)}"
        }, ensure_ascii=False, indent=2)


# ========== 路径管理工具 ==========

@mcp.tool()
async def save_file_paths_bundle(
    rds_file: Optional[str] = None,
    h5ad_file: Optional[str] = None,
    h5_file: Optional[str] = None,
    json_file: Optional[str] = None,
    metadata: Optional[str] = None,
    session_id: Optional[str] = None,
    expiry_hours: Optional[int] = None
) -> str:
    """保存数据文件路径到cache目录

    此工具用于在数据处理完成后保存所有关键文件路径，以便后续步骤使用。

    Args:
        rds_file: RDS文件路径
        h5ad_file: H5AD文件路径
        h5_file: H5文件路径（easySCF格式）
        json_file: Marker基因JSON文件路径
        metadata: 额外元数据（JSON字符串格式，可选）
        session_id: 会话ID（可选，默认使用当前会话ID）
        expiry_hours: 过期时间（小时，默认24小时）

    Returns:
        JSON格式的保存结果，包含成功状态、session_id、保存路径等信息

    使用场景：
        - 在完成数据处理后立即调用，保存生成的文件路径
        - 确保路径格式正确（特别注意中文路径的分隔符）
        - 如果保存失败，检查错误信息并修正路径后重试
    """
    try:
        # json_file 是 DataAgent 的必需输出
        if not json_file or json_file.strip() == "":
            return json.dumps({
                "success": False,
                "error": "❌ json_file 是必需的！DataAgent 必须生成 marker 基因 JSON 文件。",
                "action_required": "请使用以下方法之一生成 JSON 文件：",
                "available_methods": [
                    "1. run_r_findallmarkers - 对 RDS/Seurat 对象进行标记基因分析",
                    "2. easyscfpy_h5_to_json - 从 easySCF H5 文件提取",
                    "3. scanpy_path_to_json - 从 scanpy/AnnData 文件转换",
                    "4. convert_r_markers_csv_to_json - 从 FindAllMarkers CSV 结果转换"
                ]
            }, ensure_ascii=False, indent=2)

        # 解析 metadata（如果提供）
        metadata_dict = None
        if metadata:
            try:
                metadata_dict = json.loads(metadata)
            except json.JSONDecodeError:
                return json.dumps({
                    "success": False,
                    "error": "metadata 不是有效的JSON格式"
                }, ensure_ascii=False, indent=2)

        # 添加 DataAgent 标记到 metadata
        if metadata_dict is None:
            metadata_dict = {}
        metadata_dict["agent"] = "DataAgent"
        metadata_dict["stage"] = "data_processing"

        # 调用核心函数
        result = _save_file_paths_bundle(
            rds_file=rds_file,
            h5ad_file=h5ad_file,
            h5_file=h5_file,
            json_file=json_file,
            metadata=metadata_dict,
            session_id=session_id,
            expiry_hours=expiry_hours
        )

        return json.dumps(result, ensure_ascii=False, indent=2)

    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"保存文件路径包异常: {e}"
        }, ensure_ascii=False, indent=2)


@mcp.tool()
async def load_file_paths_bundle() -> str:
    """从cache目录加载当前会话的文件路径

    此工具用于加载之前保存的文件路径信息。

    Returns:
        JSON格式的路径信息，包含 rds_file, h5ad_file, h5_file, json_file 等

    使用场景：
        - 当需要获取之前保存的文件路径时
        - 跨步骤传递文件路径信息
    """
    try:
        result = _load_and_validate_bundle()  # 使用验证版本更安全
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "success": False,
            "error": f"加载文件路径包异常: {e}"
        }, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    # 解析命令行参数
    import argparse
    from celltypeAgent.mainagent.config.session_config import set_session_id

    parser = argparse.ArgumentParser(description='CellType DataProcessor MCP Server')
    parser.add_argument('--session-id', type=str, help='Session ID for file naming')
    args = parser.parse_args()

    # 如果提供了session_id，设置到全局配置
    if args.session_id:
        set_session_id(args.session_id)
        print(f"✅ MCP Server 使用传入的 session_id: {args.session_id}")

    # 初始化全局缓存目录
    ensure_cache_dir()
    print(f"缓存目录已设置为: {CACHE_DIR}")

    # 启动MCP服务器 (标准stdio传输)
    print("🚀 启动CellType DataProcessor MCP服务器...")
    print("📋 协议: Model Context Protocol (MCP)")
    print("🔧 可用工具: 12个")
    print("📊 核心工具:")
    print("  1️⃣  run_r_findallmarkers - R FindAllMarkers分析")
    print("  2️⃣  run_r_sce_to_h5 - SCE转H5格式")
    print("  3️⃣  convert_r_markers_csv_to_json - CSV转JSON")
    print("  4️⃣  easyscfpy_h5_to_json - easySCF H5转JSON")
    print("  5️⃣  scanpy_to_json - scanpy对象转JSON")
    print("  6️⃣  scanpy_path_to_json - scanpy文件转JSON")
    print("  7️⃣  convert_scanpy_file_to_h5 - scanpy文件转H5格式")
    print("  8️⃣  validate_file_type - 文件类型验证")
    print("  9️⃣  validate_json_only - JSON文件专门验证")
    print("  🔟  get_token_stats - 获取token统计信息")
    print("  1️⃣1️⃣ save_file_paths_bundle - 保存文件路径到cache")
    print("  1️⃣2️⃣ load_file_paths_bundle - 从cache加载文件路径")
    print("=" * 60)
    mcp.run(transport='stdio')