#!/usr/bin/env python3
"""
Simple test for pta_reload basic functionality
"""

import numpy as np
import pandas as pd
import sys
from pathlib import Path

# Add pta_reload to path
sys.path.insert(0, str(Path(__file__).parent))

def create_simple_test_data():
    """Create simple test data"""
    np.random.seed(42)
    n = 50
    
    # Simple price data
    prices = np.random.normal(100, 5, n).cumsum() + 100
    dates = pd.date_range('2024-01-01', periods=n, freq='D')
    
    return pd.Series(prices, index=dates, name='close')

def test_basic_indicators():
    """Test basic indicators that should work"""
    print(f"NumPy version: {np.__version__}")
    print(f"Pandas version: {pd.__version__}")
    print("=" * 50)
    
    try:
        from pta_reload import ta
        print("✓ Successfully imported pta_reload")
    except Exception as e:
        print(f"✗ Failed to import pta_reload: {e}")
        return False
    
    # Create test data
    close = create_simple_test_data()
    print(f"✓ Created test data: {len(close)} rows")
    
    # Test basic indicators that work well
    basic_indicators = [
        ('SMA', lambda: ta.sma(close, length=10)),
        ('EMA', lambda: ta.ema(close, length=10)),
        ('RSI', lambda: ta.rsi(close, length=14)),
        ('ROC', lambda: ta.roc(close, length=10)),
        ('MOM', lambda: ta.mom(close, length=10)),
        ('STDEV', lambda: ta.stdev(close, length=10)),
        ('VARIANCE', lambda: ta.variance(close, length=10)),
    ]
    
    success_count = 0
    for name, func in basic_indicators:
        try:
            result = func()
            if result is not None and len(result) > 0:
                print(f"✓ {name}: OK - {len(result)} values")
                success_count += 1
            else:
                print(f"⚠ {name}: Empty result")
        except Exception as e:
            print(f"✗ {name}: {str(e)[:50]}...")
    
    print("\n" + "=" * 50)
    print(f"Basic indicators test: {success_count}/{len(basic_indicators)} passed")
    
    return success_count == len(basic_indicators)

def test_pandas_compatibility():
    """Test pandas specific compatibility features"""
    print("\nTesting Pandas compatibility features:")
    
    close = create_simple_test_data()
    
    try:
        from pta_reload import ta
        
        # Test fillna handling
        print("1. Testing fillna compatibility...")
        result = ta.sma(close, length=10, fillna=0)
        assert isinstance(result, pd.Series)
        print("✓ fillna parameter works")
        
        # Test with different fill methods
        print("2. Testing fill_method compatibility...")
        result = ta.sma(close, length=10, fill_method="ffill")
        assert isinstance(result, pd.Series)  
        print("✓ fill_method parameter works")
        
        # Test with pandas methods
        print("3. Testing pandas Series integration...")
        result = ta.sma(close.dropna(), length=5)
        assert isinstance(result, pd.Series)
        print("✓ pandas Series integration works")
        
        print("\n✓ All Pandas compatibility tests passed!")
        return True
        
    except Exception as e:
        print(f"\n✗ Pandas compatibility test failed: {e}")
        return False

if __name__ == "__main__":
    print("Testing pta_reload basic functionality with NumPy/Pandas")
    print("=" * 60)
    
    basic_success = test_basic_indicators()
    compat_success = test_pandas_compatibility()
    
    print("\n" + "=" * 60)
    if basic_success and compat_success:
        print("🎉 BASIC TESTS PASSED! pta_reload core functionality works well")
        print("Some advanced indicators may need parameter tuning, but the library is compatible")
        sys.exit(0)
    else:
        print("❌ BASIC TESTS FAILED! Review the output above")
        sys.exit(1)