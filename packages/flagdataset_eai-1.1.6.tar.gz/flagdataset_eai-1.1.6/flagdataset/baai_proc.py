from pathlib import Path


def proc_data(cmd_args):
    from .process.handle import handle_single_data


    save_path_arg = cmd_args.save_path # noqa
    data_path = Path(save_path_arg) / "data"
    logw_path = Path(save_path_arg) / "log"
    proc_path = Path(save_path_arg) / "proc"
    proc_path.mkdir(parents=True, exist_ok=True)


    single_path = Path("~/Downloads/")
    # 也可以选择传递具体数据文件夹名
    single_folder_name = ["刷透明试管_试用角色测试新建模版_346"]

    try:
        print(single_path.absolute(), single_folder_name)
        handle_single_data(single_path, single_folder_name, proc_path, True, logw_path)
    except Exception as e:
        print(e)
