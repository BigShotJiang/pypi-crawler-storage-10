from typing import Any

class ColorError(Exception):
    pass

class InvalidColorError(ColorError):
    __slots__: tuple[str, str] = ('color_value', 'message')

    def __init__(self, color_value: Any, message: str | None = None) -> None:
        self.color_value: Any = color_value
        self.message: str = message if message else "Invalid color value: " + str(color_value)

        super().__init__(self.message)

class ColorConversionError(ColorError):
    __slots__: tuple[str, str, str, str] = ('from_format', 'to_format', 'value', 'message')

    def __init__(self, from_format: str, to_format: str, value: Any, message: str | None = None) -> None:
        self.from_format: str = from_format
        self.to_format: str = to_format
        self.value: Any = value
        self.message: str = message if message else "Failed to convert " + str(value) + " from " + from_format + " to " + to_format

        super().__init__(self.message)
