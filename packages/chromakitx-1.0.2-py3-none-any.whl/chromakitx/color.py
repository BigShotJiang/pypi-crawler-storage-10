from types import UnionType

from chromakitx.colors.ansi import AnsiColor
from chromakitx.colors.css import CssColor
from chromakitx.colors.xterm import XtermColor
from chromakitx.colors.style import TextStyle
from chromakitx.colors.custom import CustomColor
from chromakitx.protocols import ColorFormattable
from chromakitx.exceptions import InvalidColorError

ColorType: UnionType = AnsiColor | CssColor | XtermColor | TextStyle | CustomColor

class Color:
    __slots__: tuple[str] = ('_formatted',)

    def __init__(self, color: ColorType) -> None:
        if not isinstance(color, ColorFormattable):
            raise InvalidColorError(color_value=color, message="Color must implement ColorFormattable protocol, got " + type(color).__name__)

        self._formatted: str = color.format()

    @property
    def formatted(self) -> str:
        return self._formatted

    def __str__(self) -> str:
        return self._formatted

    def __repr__(self) -> str:
        return "Color('" + self._formatted + "')"

    def __add__(self, other: object) -> str:
        match other:
            case str():
                return self._formatted + other

            case Color():
                return self._formatted + other._formatted

            case _:
                return NotImplemented

    def __radd__(self, other: object) -> str:
        match other:
            case str():
                return other + self._formatted

            case Color():
                return other._formatted + self._formatted

            case _:
                return NotImplemented

    def __eq__(self, other: object) -> bool:
        return NotImplemented if not isinstance(other, Color) else self._formatted == other._formatted

    def __hash__(self) -> int:
        return hash(self._formatted)
