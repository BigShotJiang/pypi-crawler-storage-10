from chromakitx.typing_ext import EnumColor
from chromakitx.constants import ANSI_ESCAPE

class AnsiColor(EnumColor):
    Black = 30
    Red = 31
    Green = 32
    Yellow = 33
    Blue = 34
    Magenta = 35
    Cyan = 36
    White = 37
    Default = 39

    BrightBlack = 90
    BrightRed = 91
    BrightGreen = 92
    BrightYellow = 93
    BrightBlue = 94
    BrightMagenta = 95
    BrightCyan = 96
    BrightWhite = 97

    def format(self) -> str:
        return ANSI_ESCAPE % self.value
