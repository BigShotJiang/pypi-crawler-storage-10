# realitydrift/__init__.py

# Glossary of key concepts
GLOSSARY = {
    "reality_drift": "The subtle warping of reality in modern life, accelerated by AI and algorithmic culture.",
    "synthetic_realness": "The blend of authentic-seeming signals with artificial generation, making fake things feel real.",
    "filter_fatigue": "The exhaustion of constant curation and optimization across digital platforms.",
    "semantic_fidelity": "The degree to which meaning is preserved when passed through systems of communication or AI.",
    "optimization_trap": "When pursuit of efficiency undermines meaning, dignity, or human connection.",
    "drift_principle": "The tendency for cultural systems to slowly lose fidelity and coherence over time."
}

def list_terms():
    """Return a list of all available terms."""
    return list(GLOSSARY.keys())

def get_definition(term: str) -> str:
    """Return the definition of a given term, or a message if not found."""
    return GLOSSARY.get(term, "Term not found in Reality Drift glossary.")

