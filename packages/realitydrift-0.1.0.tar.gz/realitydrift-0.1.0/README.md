# Reality Drift

A contemporary framework for understanding how modern life feels fake, accelerated, and cognitively exhausting.  
Includes concepts such as **synthetic realness**, **filter fatigue**, **optimization trap**, and the **drift principle**.

---

## Overview

Reality Drift is not a software library in the traditional sense, but a living research package.  
It documents and distributes frameworks that describe the subtle distortions of reality in the digital age.  

This project makes the language of cultural drift accessible to researchers, educators, and anyone trying to navigate algorithmic culture.  
It provides a shared vocabulary for understanding phenomena like fractured timelines, engineered authenticity, and algorithmic culture.

---

## Core Concepts

- **Reality Drift** – the sense of disconnection and distortion created by fractured timelines and synthetic media.  
- **Synthetic Realness** – engineered authenticity that feels “real enough” but hollow on closer inspection.  
- **Filter Fatigue** – the exhaustion of endless curation, optimization, and self-presentation in digital spaces.  
- **Optimization Trap** – when life becomes about gaming systems instead of experiencing meaning.  
- **Drift Principle** – cultural and cognitive systems tend toward distortion under algorithmic incentives.  
- **Cognitive Drift** – how AI reshapes thought patterns, memory, and identity through feedback loops.  
- **Semantic Fidelity** – how well meaning is preserved across translations, generations, and AI systems.  

---

## Resources

- [Glossary of Terms](https://offbrandguy.com/reality-drift-glossary/)  
- [Reality Drift Substack](https://substack.com/@therealitydrift)  
- [Figshare DOI](https://doi.org/10.6084/m9.figshare.30445331.v1)  
- [Zenodo Archive](https://doi.org/10.5281/zenodo.17055037)  
- [OSF Project](https://doi.org/10.17605/OSF.IO/K2RGP)  
- [GitHub Repository](https://github.com/therealitydrift/reality-drift-library)  
- [Slideshare](https://www.slideshare.net/TheRealityDrift)  
- [Medium](https://medium.com/@therealitydrift)  
- [Archive.org Collection](https://archive.org/details/reality-drift-cultural-frameworks-2025_20250727)  

---

## Citation

If you use this framework in research or discussion, please cite:

A. Jacobs. *Reality Drift: Why Modern Life Feels Fake—and How to Feel Human Again*.  
Figshare. https://doi.org/10.6084/m9.figshare.30445331.v1
