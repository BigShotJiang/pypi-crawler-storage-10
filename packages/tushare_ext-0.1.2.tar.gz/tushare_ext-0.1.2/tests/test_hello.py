from tushare_utils import config
from tushare_utils.time_utils import TimeUtils

def test_token():
    config.token='abc'
    assert config.token=="abc"

def test_conn():
    config.conn={"name":'mysql',"port":3306}
    print(config.conn)
    assert config.conn['name']=='mysql'
    TimeUtils.show()
