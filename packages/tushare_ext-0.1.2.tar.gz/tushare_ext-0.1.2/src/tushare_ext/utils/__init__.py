from utils.settings import  Settings


config =Settings()


