from typing import Dict

class Settings():


    @property
    def token(self)->str:
        return self._token   
    
    @token.setter
    def token(self,value:str)->None:
        self._token=value

    @property
    def conn(self)->Dict[str,int]:
        return self._conn
    
    @conn.setter
    def conn(self,value:Dict[str,int])->None:
        self._conn=value

