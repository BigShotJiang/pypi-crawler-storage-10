from utils import config

class TimeUtils():

    @staticmethod
    def show():
        print(config.token)