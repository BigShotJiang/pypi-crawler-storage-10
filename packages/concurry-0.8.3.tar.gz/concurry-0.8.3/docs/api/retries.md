# Retry API Reference

::: concurry.core.retry.RetryConfig
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.retry.RetryValidationError
    options:
      show_root_heading: true
      show_source: true

::: concurry.core.retry.calculate_retry_wait
    options:
      show_root_heading: true
      show_source: true

