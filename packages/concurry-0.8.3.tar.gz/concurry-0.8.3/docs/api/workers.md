# Workers API Reference

## Base Worker Class

::: concurry.core.worker.base_worker.Worker
    options:
      show_root_heading: true
      show_source: true

## TaskWorker

::: concurry.core.worker.task_worker.TaskWorker
    options:
      show_root_heading: true
      show_source: true

## Task Decorator

::: concurry.core.worker.task_decorator.task
    options:
      show_root_heading: true
      show_source: true

