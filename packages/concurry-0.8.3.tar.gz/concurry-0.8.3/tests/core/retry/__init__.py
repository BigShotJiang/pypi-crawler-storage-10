"""Tests for retry module."""
