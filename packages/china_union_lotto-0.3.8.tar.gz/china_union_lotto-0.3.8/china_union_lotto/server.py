from datetime import datetime, timedelta
from enum import Enum
import json
import requests
from typing import Sequence

from zoneinfo import ZoneInfo
from tzlocal import get_localzone_name  # ← returns "Europe/Paris", etc.

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource,Prompt
from mcp.shared.exceptions import McpError
from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

from pydantic import BaseModel

from loguru import logger
from dotenv import load_dotenv
import os
import io
import csv

'''
'''
class LottoTools(str, Enum):
    SELECT_NUMBERS = "select_numbers"

'''
'''
class LottoResult(BaseModel):
    numbers: list[str]
'''
'''
class Utils:
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"    
        }
    def fetch_url(self,url):
        try:
            logger.debug(f"fetching {url}")
            res= requests.get(url,headers=self.headers)
            return res.content.decode(res.apparent_encoding,'ignore')
        except Exception as e:
            logger.error(f"Failed to fetch[{e.__traceback__.tb_lineno}]: {e}")
            pass
        return None

    def fetch_url_with_retry(self,url, retry_count=3):
        logger.info(f"fetch_url_with_retry {url}, retry_count={retry_count}")
        n = retry_count
        html = None 
        while True:
            n -=1 
            if n < 0:
                break 
            try:
                res=requests.get(url,headers=self.headers)
                html = res.content.decode(res.apparent_encoding,'ignore')
                break 
            except Exception as e:        
                logger.error(f"Failed to fetch[{e.__traceback__.tb_lineno}]: {e}")
                continue 
        return html

'''
'''
class ChinaUnionLottoDataList:
    def __init__(self):
        self.utils=Utils()
        self.data_list=list()
    
    def load_data(self):
        try:
            load_dotenv()
            url = os.getenv("CSV_URL")
            logger.info(f"CSV_URL={url}")
            html = self.utils.fetch_url_with_retry(url,10)
            if html is None or len(html) == 0:
                logger.error(f"Failed to fetch {url}")
            csv_io = io.StringIO(html)
            reader = csv.reader(csv_io)
            self.data_list = list(reader)
            logger.info(f"loaded {len(self.data_list)} data")
        except Exception as e:
            logger.error(f"Failed to load data[{e.__traceback__.tb_lineno}]: {e}")
            pass

'''
'''            
class LottoServer:
    def __init__(self):
        self.utils=Utils()
        self.old_lotto = ChinaUnionLottoDataList()

    def select_numbers(self,count:int) -> LottoResult:
        # 
        self.old_lotto.load_data()
        ret = list()
        for d in self.old_lotto.data_list:
            ret.append(f"{d[2]} {d[3]} {d[4]} {d[5]} {d[6]} {d[7]} {d[8]}")
            if len(ret) >= count:
                break
        logger.info(f"selected numbers: {ret}")
        
        return LottoResult(numbers=ret)

async def serve() -> None:
    server = Server("mcp-china-union-lotto")
    lotto_server=LottoServer()

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available lotto tools."""
        return [
            Tool(
                name=LottoTools.SELECT_NUMBERS.value,
                description="select numbers for china union lotto",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "count": {
                            "type": "integer",
                            "description": f"how many numbers to select",
                        }
                    },
                    "required": ["count"],
                },
            ),
        ]

    # @server.list_prompts()
    # async def list_prompts() -> list[Prompt]:
    #     return [
    #         Prompt(
    #             name="select_numbers",
    #             description="select numbers for china union lotto[0.3.7]",
    #         ),
    #     ]
    
    @server.call_tool()
    async def call_tool(
        name: str, arguments: dict
    ) -> Sequence[TextContent]:
        """Handle tool calls for lotto."""
        try:
            match name:
                case LottoTools.SELECT_NUMBERS.value:
                    count = arguments.get("count")
                    if not count:
                        count = 5
                    result = lotto_server.select_numbers(count)
                case _:
                    raise ValueError(f"Unknown tool: {name}")

            return [
                TextContent(type="text", text=json.dumps(result.model_dump(), indent=2))
            ]

        except Exception as e:
            raise ValueError(f"Error processing lotto tool: {str(e)}")

    # todo: streamablehttp
    #session_manager = StreamableHTTPSessionManager()

    options = server.create_initialization_options()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, options)
