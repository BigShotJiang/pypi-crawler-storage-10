# SnakeScan
![PyPI version](https://badge.fury.io/py/SnakeScan.svg)
![Requires-python](https://img.shields.io/badge/requires--python-3.6+-red)
![License](https://img.shields.io/badge/License-MIT-blue.svg)
 ```
import SnakeScan
SnakeScan.run()
```
## Help
- --l  need internet to view public ip you device
- --t threading port search
- --s single port search
- --i information about host
- --h in host /--h port in host
- --check [host] scan subnet in ip
- exit in host or port off script
## Added class Watcher:
 ```
 for SnakeScan import Watcher
 Watcher(host:str,port:int)
 ```
 ## Added multiple use Watcher:
     ```
     from SnakeScan import Watcher
ports=[53,80,100,160]
for i in range(len(ports)):
    Watcher("127.0.0.1",ports[i])
    ```