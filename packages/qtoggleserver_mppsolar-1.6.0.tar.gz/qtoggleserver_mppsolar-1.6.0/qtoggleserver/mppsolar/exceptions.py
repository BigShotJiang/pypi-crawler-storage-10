class MPPSolarException(Exception):
    pass


class MPPSolarTimeout(MPPSolarException):
    pass
