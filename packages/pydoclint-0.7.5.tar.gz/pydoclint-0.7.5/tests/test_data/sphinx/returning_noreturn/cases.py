from typing import NoReturn


def func(arg1: int) -> NoReturn:
    """
    Do something

    :param arg1: Arg 1
    :type arg1: int
    """
    exit(1)
