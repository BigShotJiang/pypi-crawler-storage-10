class MyClass:
    def __init__(self):
        pass

    def func1(self, arg1, arg2) -> int:
        """
        Do something

        :param arg1: Arg 1
        :param arg2: Arg 2
        :return: The return value
        :rtype: int
        """
        return 1

    def func2(self, arg1: int, arg2: float) -> int:
        """
        Do something

        :param arg1: Arg 1
        :param arg2: Arg 2
        :return: The return value
        :rtype: int
        """
        return 1

    def func3(self, arg1, arg2) -> int:
        """
        Do something

        :param arg1: Arg 1
        :type arg1: int
        :param arg2: Arg 2
        :type arg2: float
        :return: The return value
        :rtype: int
        """
        return 1

    def func4(self, arg1: int, arg2: float) -> int:
        """
        Do something

        :param arg1: Arg 1
        :type arg1: int
        :param arg2: Arg 2
        :type arg2: float
        :return: The return value
        :rtype: int
        """
        return 1

    def func5(self, arg1, arg2: float) -> int:
        """
        Do something

        :param arg1: Arg 1
        :type arg1: int
        :param arg2: Arg 2
        :return: The return value
        :rtype: int
        """
        return 1

    def func6(self, arg1: bool, arg2: float) -> int:
        """
        Do something

        :param arg1: Arg 1
        :type arg1: int
        :param arg2: Arg 2
        :type arg2: float
        :return: The return value
        :rtype: int
        """
        return 1

    def func7(self, arg1, arg2: float) -> int:
        """
        Do something

        :param arg1: Arg 1
        :param arg2: Arg 2
        :type arg2: float
        :return: The return value
        :rtype: int
        """
        return 1
