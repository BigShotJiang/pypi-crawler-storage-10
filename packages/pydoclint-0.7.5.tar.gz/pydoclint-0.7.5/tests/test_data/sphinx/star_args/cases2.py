from typing import Dict, Tuple


class A:
    def __init__(self, *args: Tuple, **kwargs: Dict) -> None:
        """
        Do something.

        :param *args: Args
        :param **kwargs: Keyword args
        """
        pass
