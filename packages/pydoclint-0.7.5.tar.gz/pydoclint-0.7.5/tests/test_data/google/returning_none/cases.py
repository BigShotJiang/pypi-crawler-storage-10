def func(arg1: int) -> None:
    """
    Do something

    Args:
        arg1 (int): Arg 1
    """
    print(1)
