from typing import NoReturn


def func(arg1: int) -> NoReturn:
    """
    Do something

    Args:
        arg1 (int): Arg 1
    """
    exit(1)
