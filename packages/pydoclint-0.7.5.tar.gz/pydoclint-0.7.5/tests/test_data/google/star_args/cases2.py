from typing import Dict, Tuple


class A:
    def __init__(self, *args: Tuple, **kwargs: Dict) -> None:
        """
        Do something.

        Args:
            *args: Args
            **kwargs: Keyword args
        """
        pass
