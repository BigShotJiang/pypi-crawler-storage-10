def someFunc(arg1: int, arg2: bool) -> str:
    """
    Do something.

    :param arg1: Arg 1
    :type arg1: `int`
    :param arg2: Arg 2
    :type arg2: ``bool``
    :return: Return value
    :rtype: `str`
    """
    pass
