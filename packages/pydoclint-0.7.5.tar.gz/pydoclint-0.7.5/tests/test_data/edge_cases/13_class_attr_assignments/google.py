class MyClass:
    """
    My Class

    Attributes:
        a1: attr 1
        a2: attr 2
        a3: attr 3
        a4: attr 4
        a5: attr 5
        a6: attr 6
        a7: attr 7
        a8: attr 8
        a9: attr 9
        a10: attr 10
        a11: attr 11
        a12: attr 12
        a13: attr 13
        a14: attr 14
        a15: attr 15
    """

    a1, a2, a3 = 1, 2, 3
    a4 = a5 = a6 = 3
    a7 = a8 = a9 = a6 == 2
    a10, a11 = a12, a13 = a14, a15 = 5, 6
