def f(x: int, y: int, z: int) -> None:
    """
    Run f().

    From issue: https://github.com/jsh9/pydoclint/issues/85

    Parameters
    ----------
    y
        y
    z
        z
    """
    pass
