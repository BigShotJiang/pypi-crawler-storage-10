def function1(arg1: str) -> None:
    """
    Do something

    Args:
        arg1 (int): Arg 1
    """
    pass
