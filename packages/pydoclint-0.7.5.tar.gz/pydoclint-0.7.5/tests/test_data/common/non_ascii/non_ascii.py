def func_non_ascii(argλ: float) -> None:
    """Something.

    Parameters
    ----------
    argλ : float
        Non ASCII argument

    Returns
    -------
    None
    """
    return None
