from typing import Callable, Optional

from zhkj_plugins import PluginManager


def progress_bar_callback(downloaded: int, total: int, speed: float) -> None:
    """显示文本进度条和百分比"""
    if total == 0:
        # 无法获取总大小，只显示已下载字节数
        print(f"\r已下载：{downloaded / 1024:.2f} KB | 速度：{speed:.2f} KB/s", end="")
        return

    # 计算百分比
    percent = (downloaded / total) * 100
    # 进度条长度（20个字符）
    bar_length = 20
    filled_length = int(bar_length * percent // 100)
    bar = "=" * filled_length + " " * (bar_length - filled_length)

    # 格式化显示（总大小转为 MB/KB）
    total_size = total / (1024 * 1024) if total >= 1024 * 1024 else total / 1024
    total_unit = "MB" if total >= 1024 * 1024 else "KB"
    downloaded_size = downloaded / (1024 * 1024) if total >= 1024 * 1024 else downloaded / 1024

    # 显示格式：[=====     ] 50%  1.2/2.4 MB  100.5 KB/s
    print(
        f"\r[{bar}] {percent:.1f}%  "
        f"{downloaded_size:.2f}/{total_size:.2f} {total_unit}  "
        f"速度：{speed:.2f} KB/s",
        end=""
    )


class PluginBase:
    def __init__(self, plugin_name: str, plugin_install_dir="plugins", auto_check_updates=True, version_checks_url="",
                 settings_url=""):
        self.name = plugin_name
        self.plugin_manager = PluginManager({
            "plugin_install_dir": plugin_install_dir,  # 自定义插件安装目录
            "auto_check_updates": auto_check_updates,
            "version_checks_url": version_checks_url,
            "settings_url": settings_url
        })

    def install(self, progress_callback: Optional[Callable[[int, int, float], None]] = progress_bar_callback):
        self.plugin_manager.install_plugin(self.name, progress_callback=progress_callback)

    def start(self):
        self.plugin_manager.start_plugin(self.name)

    def stop(self):
        self.plugin_manager.stop_plugin(self.name)

    def is_running(self):
        self.plugin_manager.is_plugin_running(self.name)

    def list(self):
        self.plugin_manager.list_plugins()
