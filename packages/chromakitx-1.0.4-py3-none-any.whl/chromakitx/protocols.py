# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from typing import (Protocol, runtime_checkable)

@runtime_checkable
class ColorFormattable(Protocol):
    def format(self) -> str:
        ...

@runtime_checkable
class NameResolvable(Protocol):
    @classmethod
    def from_name(cls, name: str) -> "NameResolvable":
        ...

@runtime_checkable
class ColorProvider(ColorFormattable, NameResolvable, Protocol):
    pass
