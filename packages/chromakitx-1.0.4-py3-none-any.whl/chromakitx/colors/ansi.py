# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.typing_ext import EnumColor
from chromakitx.constants import ANSI_ESCAPE

class AnsiColor(EnumColor):
    Black = (30, 40)
    Red = (31, 41)
    Green = (32, 42)
    Yellow = (33, 43)
    Blue = (34, 44)
    Magenta = (35, 45)
    Cyan = (36, 46)
    White = (37, 47)
    Default = (39, 49)

    BrightBlack = (90, 100)
    BrightRed = (91, 101)
    BrightGreen = (92, 102)
    BrightYellow = (93, 103)
    BrightBlue = (94, 104)
    BrightMagenta = (95, 105)
    BrightCyan = (96, 106)
    BrightWhite = (97, 107)

    def format(self, is_background: bool = False) -> str:
        return ANSI_ESCAPE % (self.value[0] if not is_background else self.value[1])
