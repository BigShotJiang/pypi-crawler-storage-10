# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from chromakitx.typing_ext import EnumColor
from chromakitx.constants import ANSI_ESCAPE

class TextStyle(EnumColor):
    RESET = 0
    BOLD = 1
    DIM = 2
    ITALIC = 3
    UNDERLINE = 4
    BLINK = 5
    BLINK_RAPID = 6
    REVERSE = 7
    HIDDEN = 8
    STRIKETHROUGH = 9

    def format(self, _: bool = False) -> str:
        return ANSI_ESCAPE % self.value
