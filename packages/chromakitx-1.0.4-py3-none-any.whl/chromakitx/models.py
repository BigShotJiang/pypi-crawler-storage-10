# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from dataclasses import dataclass
from typing import Iterator

from chromakitx.constants import (MIN_RGB_VALUE, MAX_RGB_VALUE, MIN_HSL_VALUE, MAX_HSL_VALUE, MIN_HSV_VALUE, MAX_HSV_VALUE, VALID_HEX_LENGTHS, VALID_HEX_CHARS)

@dataclass(frozen=True, slots=True)
class RGB:
    r: int
    g: int
    b: int

    def __post_init__(self) -> None:
        self._validate_component(self.r, name="Red")
        self._validate_component(self.g, name="Green")
        self._validate_component(self.b, name="Blue")

    @staticmethod
    def _validate_component(value: int, name: str) -> None:
        if not isinstance(value, int):
            raise TypeError(name + " must be an integer, got " + type(value).__name__)

        if not (MIN_RGB_VALUE <= value <= MAX_RGB_VALUE):
            raise ValueError(name + " must be " + str(MIN_RGB_VALUE) + "-" + str(MAX_RGB_VALUE) + ", got " + str(value))

    def __iter__(self) -> Iterator[int]:
        yield self.r
        yield self.g
        yield self.b

@dataclass(frozen=True, slots=True)
class HSL:
    h: float
    s: float
    l: float

    def __post_init__(self) -> None:
        self._validate_component(self.h, name="Hue")
        self._validate_component(self.s, name="Saturation")
        self._validate_component(self.l, name="Lightness")

    @staticmethod
    def _validate_component(value: float, name: str) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError(name + " must be a number, got " + type(value).__name__)

        if not (MIN_HSL_VALUE <= value <= MAX_HSL_VALUE):
            raise ValueError(name + " must be " + str(MIN_HSL_VALUE) + "-" + str(MAX_HSL_VALUE) + ", got " + str(value))

    def __iter__(self) -> Iterator[float]:
        yield self.h
        yield self.s
        yield self.l

@dataclass(frozen=True, slots=True)
class HSV:
    h: float
    s: float
    v: float

    def __post_init__(self) -> None:
        self._validate_component(self.h, name="Hue", max_value=360.0)
        self._validate_component(self.s, name="Saturation", max_value=MAX_HSV_VALUE)
        self._validate_component(self.v, name="Value", max_value=MAX_HSV_VALUE)

    @staticmethod
    def _validate_component(value: float, name: str, max_value: float) -> None:
        if not isinstance(value, (int, float)):
            raise TypeError(name + " must be a number, got " + type(value).__name__)

        if not (MIN_HSV_VALUE <= value <= max_value):
            raise ValueError(name + " must be " + str(MIN_HSV_VALUE) + "-" + str(max_value) + ", got " + str(value))

    def __iter__(self) -> Iterator[float]:
        yield self.h
        yield self.s
        yield self.v

@dataclass(frozen=True, slots=True)
class HEX:
    value: str

    def __post_init__(self) -> None:
        normalized: str = self.value.lstrip('#').upper()

        if len(normalized) not in VALID_HEX_LENGTHS:
            raise ValueError("Hex color must be 3 or 6 characters, got " + str(len(normalized)) + ": " + self.value)

        if not all(c in VALID_HEX_CHARS for c in normalized):
            raise ValueError("Hex color contains invalid characters: " + self.value)

    @property
    def normalized(self) -> str:
        return self.value.lstrip('#').upper()
