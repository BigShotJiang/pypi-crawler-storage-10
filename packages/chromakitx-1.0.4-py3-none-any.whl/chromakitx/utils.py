# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

import colorsys

from chromakitx.constants import (HEX_PATTERN, RGB_MAX_VALUE)
from chromakitx.exceptions import (InvalidColorError, ColorConversionError)
from chromakitx.models import (RGB, HSL, HEX, HSV)

def hex_to_rgb(hex_color: HEX) -> RGB:
    hex_color:  str = hex_color.value
    normalized: str = hex_color.normalized if isinstance(hex_color, HEX) else hex_color.lstrip('#').upper()

    if len(normalized) == 3:
        normalized = ''.join((char * 2) for char in normalized)

    if not HEX_PATTERN.fullmatch(normalized):
        raise InvalidColorError(hex_color, "Invalid hex color format: " + hex_color)

    try:
        r: int = int(normalized[0:2], 16)
        g: int = int(normalized[2:4], 16)
        b: int = int(normalized[4:6], 16)

        return RGB(r, g, b)
    except ValueError as e:
        raise ColorConversionError("hex", "rgb", hex_color) from e

def hsl_to_rgb(hsl: HSL) -> RGB:
    try:
        (r_float, g_float, b_float) = colorsys.hls_to_rgb(hsl.h, hsl.s, hsl.l)

        r: int = round(r_float * RGB_MAX_VALUE)
        g: int = round(g_float * RGB_MAX_VALUE)
        b: int = round(b_float * RGB_MAX_VALUE)

        return RGB(r, g, b)
    except (ValueError, TypeError) as e:
        raise ColorConversionError("hsl", "rgb", str(hsl)) from e

def hsv_to_rgb(hsv: HSV) -> RGB:
    try:
        (r_float, g_float, b_float) = colorsys.hsv_to_rgb(hsv.h, hsv.s, hsv.v)

        r: int = round(r_float * RGB_MAX_VALUE)
        g: int = round(g_float * RGB_MAX_VALUE)
        b: int = round(b_float * RGB_MAX_VALUE)

        return RGB(r, g, b)
    except (ValueError, TypeError) as e:
        raise ColorConversionError("hsv", "rgb", str(hsv)) from e
