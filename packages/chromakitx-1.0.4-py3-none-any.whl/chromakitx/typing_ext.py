# SPDX-FileCopyrightText: 2023 CELESTIFYX Team
# SPDX-License-Identifier: GPL-3.0-or-later

from enum import Enum
from typing import (TypeVar, Type)

from chromakitx.exceptions import InvalidColorError

T: TypeVar = TypeVar("T", bound="EnumColor")

class EnumColor(Enum):
    @classmethod
    def from_name(cls: Type[T], name: str) -> T:
        normalized: str = name.replace('_', '').replace('-', '').replace(' ', '').lower()

        for member in cls:
            if member.name.lower().replace('_', '') == normalized:
                return member

        raise InvalidColorError(color_value=name, message="Unknown color name '" + name + "' in {cls.__name__}")

    def format(self, is_background: bool = False) -> str:
        raise NotImplementedError("Subclasses must implement format() method")
