"""
XandAI Utils - Utilitários e helpers
"""
