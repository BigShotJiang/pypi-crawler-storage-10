#!/usr/bin/env python3
"""
Entry point para execução como módulo Python
python -m xandai
"""

from xandai.cli import main

if __name__ == "__main__":
    main()
