# sweng25_objectpatternrecognizer_grpa/main.py
def add(x, y):
    return x + y


def main_func():
    print("Hello from ObjectPatternRecognizer!")
