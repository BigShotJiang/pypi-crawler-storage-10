- Guewen Baconnier \<guewen.baconnier@camptocamp.com\>
- Matthieu Méquignon \<matthieu.mequignon@camptocamp.com\>
- Sébastien Alix \<sebastien.alix@camptocamp.com\>
- Jacques-Etienne Baudoux \<je@bcim.be\>
- Laurent Mignon \<laurent.mignon@acsone.eu\>
- Michael Tietz (MT Software) \<mtietz@mt-software.de\>

## Design

- Joël Grand-Guillaume \<joel.grandguillaume@camptocamp.com\>
- Jacques-Etienne Baudoux \<je@bcim.be\>
