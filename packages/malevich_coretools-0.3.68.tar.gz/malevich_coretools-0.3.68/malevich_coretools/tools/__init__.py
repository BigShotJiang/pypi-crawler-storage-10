from .vast import vast_settings  # noqa: F401
