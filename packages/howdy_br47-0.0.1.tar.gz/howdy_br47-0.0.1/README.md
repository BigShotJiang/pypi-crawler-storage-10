# howdy-br47
A tiny example package.

## Usage
```python
from howdy-br47 import say_hello
print(say_hello("World"))
