from .stack import Stack

__all__ = ["Stack"]
