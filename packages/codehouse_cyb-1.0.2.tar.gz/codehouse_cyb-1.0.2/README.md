# codehouse_cyb 🛡️

**Codehouse Cloud Cybersecurity Training Cli Package**

---

## Overview
`codehouse_cyb` is a Python package designed to connect students to cybersecurity training questions, simulations, and AI-powered learning tools.

It is part of the **CodeHouse Cloud Learning Suite**, developed by **Applinet Technology** — an African-centered technology company that merges traditional cultures and values with modern technology to solve Africa's unique challenges and **CodeHouse Cloud** - an African Tech empowerment  initiative.

This package allows learners to practice cybersecurity skills interactively through the command line.

---

## Features

- Interactive cybersecurity learning and quizzes  
- Auto-retrieval of training questions  
- Local fallback (offline question database)  
- Intelligent feedback and scoring system  
- Fast and lightweight (no heavy dependencies)

---

## Example Usage

### 1️⃣ Installation
You can install the package directly from PyPI:

```bash
pip install codehouse_cyb
```

---

### Usage
To start the training session, run:

```bash
python -m cyber.start
```

or simply:

```bash
python cyber.start
```

---

### Example Output

```bash
Welcome to CodeHouse Cloud Cybersecurity Training!

Loading your questions...
Question 1: What does CIA Triad stand for?
A) Confidentiality, Integrity, Availability
B) Control, Internet, Access
C) Cybersecurity, Information, Authentication

Your Answer: A
✅ Correct! Great job.
```

---

## Requirements

- Python 3.8 or higher  
- Internet connection (for live mode)  
- Works offline (fallback question database included)

---

## Developer Notes

If you want to build from source:

```bash
git clone https://github.com/applinet-technology/codehouse_cyber_quiz.git
cd codehouse_cyber_quiz
pip install -e .
```

---

## License

This project is licensed under the **MIT License**.  
See [LICENSE](LICENSE) for details.

---

## Training and Community

- **CodeHouse Cloud Cybersecurity Course** — African Coding Initiative  
🌍 [View Cybersecurity Quiz Top Scorers](https://cli.codehouse.cloud)  
🌍 [Go To CodeHouse.Cloud Classroom](https://classroom.codehouse.cloud/course/view.php?id=4)  
🌍 [Enrol for Cybersecurity Course (Nigeria)](https://codehouse.cloud/technology/courses/cyber-security/cyber-security)  

---
## Author

- **CodeHouse Cloud** — African Coding Initiative  
🌍 [https://codehouse.cloud](https://codehouse.cloud)  
🌍 [Donate](https://codehouse.cloud/technology/applinet/support/donate)  
🌍 [Join Genius Community](https://genius.codehouse.cloud/)  
🌍 [Join WhatsApp Group](https://chat.whatsapp.com/BYfgMwPZBpCEwr3piT77iE)  
📧 genius@codehouse.cloud

- **Applinet Technology**  
🌍 [https://applinet.com.ng](https://applinet.com.ng)  
📧 developers@applinet.com.ng
🌍 [Join Applinet Technology WhatsApp Community](https://whatsapp.com/channel/0029VaBkX0Q96H4ZCYhgXF0a)  
🌍 [Follow us on LinkedIn](https://www.linkedin.com/company/applinet-technology)  

---

## 💡 Credits

- **Godswill Moses Ikpotokin** — CEO, Applinet Technology & CodeHouse Cloud
📧 godswill@ikpotokin.ng
🌍 [https://ikpotokin.ng](https://ikpotokin.ng)  

