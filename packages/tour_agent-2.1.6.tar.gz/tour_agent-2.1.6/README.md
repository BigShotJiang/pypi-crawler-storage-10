## 🧳 **`tour-agent` — Python uchun sayohatlarni boshqarish kutubxonasi**

**`tour-agent`** — bu Python dasturlash tili uchun yaratilgan qulay kutubxona bo‘lib, sayohat turlarini boshqarish, mijozlar bilan ishlash va tur paketlarini ko‘rish imkoniyatini beradi.

U orqali siz **admin panel** va **foydalanuvchi paneli** yordamida sayohat jarayonlarini to‘liq boshqarishingiz mumkin.
Kutubxona terminalda rangli interfeys bilan ishlaydi:

* 🟦 **Ko‘k rang** — tizimdan yuborilgan xabarlar
* 🟥 **Qizil rang** — xatoliklar va ogohlantirishlar
* 🟩 **Yashil rang** — foydalanuvchi tomonidan kiritilishi kerak bo‘lgan ma’lumotlar

---

### 👑 **Admin panel imkoniyatlari:**

Administrator uchun maxsus menyu mavjud:

```
ADMIN MENU
1. Tour qo‘shish
2. Tour o‘chirish
3. Barcha tourlarni ko‘rish
4. Statistika
5. Chiqish
```

Bu qismda siz yangi turlarni qo‘shishingiz, mavjudlarini o‘chirishingiz yoki tahliliy ma’lumotlarni ko‘rishingiz mumkin.
Masalan, umumiy foydalanuvchilar soni, tushgan daromad yoki mavjud buyurtmalar haqida statistikani olish mumkin.

---

### 👤 **Foydalanuvchi panel imkoniyatlari:**

Oddiy foydalanuvchi uchun menyu quyidagicha:

```
1. Tourlarni ko‘rish
2. Tourlarni qidirish
3. Shaxsiy kabinet
4. Savatcha
5. Chiqish
```

Bu bo‘limda foydalanuvchilar o‘zlariga yoqqan turlarni ko‘rishlari, izlashlari va savatchaga qo‘shishlari mumkin.
Shuningdek, ular **shaxsiy kabinet** orqali o‘z ma’lumotlarini boshqarishlari mumkin.

---

### 💼 **Shaxsiy kabinet imkoniyatlari:**

```
1. Ma’lumotlarim
2. Balansni ko‘rish
3. Balansga pul qo‘shish
4. Ortga
```

Bu bo‘limda foydalanuvchi o‘z balansini boshqaradi, hisobini to‘ldiradi va shaxsiy ma’lumotlarini yangilaydi.

---

### 💡 **Xususiyatlar:**

* Qulay terminal interfeysi
* Rangli chiqishlar orqali oson tushuniladigan navigatsiya
* Admin va foydalanuvchi uchun alohida menyular
* Statistika va moliyaviy ma’lumotlarni kuzatish
* Tourlarni tezda qo‘shish, qidirish va sotib olish imkoniyati

---

### 🚀 **Foydalanish:**

Kutubxonani o‘rnatish juda oson:

```bash
pip install tour-agent
```

So‘ng quyidagicha chaqirishingiz mumkin:

```python
from tour_agent.main import tour_main

tour_main()

```

---

### ✨ **Xulosa:**

`tour-agent` — bu oson, qulay va interaktiv terminal dasturi ko‘rinishidagi kutubxona bo‘lib, sayohat turlarini boshqarish va foydalanuvchilarga xizmat ko‘rsatishni avtomatlashtirishga yordam beradi.

