"""
Module to include all the functionality
related to RGBA frames (as numpy arrays).
"""