# new-django-project

This package name is reserved for an upcoming Django starter/CLI generator.
