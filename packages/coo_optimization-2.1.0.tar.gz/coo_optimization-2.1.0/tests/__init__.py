"""
Tests for COO Optimization package
"""

__version__ = "1.1.0"
