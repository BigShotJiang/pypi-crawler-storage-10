# from pydantic import BaseModel, Field

# class ContinuousConversationConfig(BaseModel):
#     template_name: str
#     has_content_param: bool
#     content_param_name : str
