from .linear import FPQuantLinear
