#!/usr/bin/env python3
"""Append backlog entries to backlog/backlog.md if missing."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
  sys.path.insert(0, str(ROOT))

from supekku.scripts.lib.backlog import append_backlog_summary


def main() -> None:
  additions = append_backlog_summary()
  if additions:
    pass


if __name__ == "__main__":
  main()
