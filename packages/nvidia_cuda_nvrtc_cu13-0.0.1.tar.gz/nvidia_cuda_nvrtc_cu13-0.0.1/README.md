⚠️ THIS PROJECT 'nvidia-cuda-nvrtc-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-nvrtc' instead.

To install the correct package, use:

    pip install nvidia-cuda-nvrtc

For more information, visit: https://pypi.org/project/nvidia-cuda-nvrtc/
