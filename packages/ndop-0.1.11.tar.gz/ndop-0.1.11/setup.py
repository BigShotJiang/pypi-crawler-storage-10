#!/usr/bin/env python3
"""
Copyright (C) 2019 Oto Kaláb
Contact: kalab.oto@gmail.com
"""

from setuptools import setup

from pathlib import Path
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

with open("requirements.txt") as f:
    install_requirements = f.read().splitlines()

setup(name='ndop',
        author='Oto Kaláb',
        author_email='kalab.oto@gmail.com',
        maintainer="Oto Kaláb",
        maintainer_email='kalab.oto@gmail.com',
        url='https://github.com/kalab-oto/ndop',
        description='Python library for accessing and downloading data from The Species Occurrence Database of NCA CR',
        version="0.1.11",
        packages=["ndop"],
        long_description=long_description,
        long_description_content_type='text/markdown',
        scripts=["bin/ndop"],
        license="MIT",
        license_files='LICENSE',
        classifiers=[
            'Development Status :: 4 - Beta',
            'Environment :: Console',
            'Intended Audience :: Science/Research',
            'License :: OSI Approved :: MIT License',
            'Natural Language :: Czech',
            'Operating System :: POSIX :: Linux',
            'Programming Language :: Python :: 3'
        ],

        install_requires=install_requirements,
        keywords=['GIS', 'AOPK', 'ecology', 'species occurences',
                  'NDOP', 'Czech Republic', 'nálezová databáze']
)
