# 🌀 ZeskaLang

> A Tanglish-based beginner-friendly programming language that **auto-corrects**, **self-heals**, and makes coding feel like chatting with your bro 😎  

---

## ✨ What is ZeskaLang?
ZeskaLang is a mini programming language built for **beginners in India** who think in **Tanglish (Tamil + English)**.

You can write code like this 👇  

```zeska
printu "Vanakkam da world!"
ifu 5 > 3:
    printu "Big number da!"
elseu:
    printu "Small number bro!"
