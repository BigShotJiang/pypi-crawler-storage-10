# Caffeine

https://launchpad.net/caffeine/

Caffeine is a background program that prevents the desktop from becoming
idle (and hence the screen saver or screen lock from activating) when the
active window is full-screen.

Note that Caffeine currently only works on X11; this is a limitation of
xdg-utils, which Caffeine uses to inhibit desktop idleness.

Also provided are an indicator, caffeine-indicator, that gives a manual
toggle, and caffeinate, which allows desktop idleness to be inhibited for
the duration of any command. See their man pages for more information.

Caffeine is distributed under the GNU General Public License, either version
3, or (at your option) any later version. See COPYING.

The Caffeine SVG icons are Copyright (C) 2009 Tommy Brunn
(http://www.blastfromthepast.se/blabbermouth), and distributed under the
terms of the GNU Lesser General Public License, either version 3, or (at
your option) any later version. See COPYING.LESSER.

Caffeine requires the Python packages ewmh, python-xlib, and PyGObject, the
C libraries Gtk3, AyatanaAppIndicator and Keybinder, and the xdg-utils
command-line utilities.


## Configuration

Caffeine Indicator’s global keyboard shortcut can be configured in `dconf-editor` at the path `/org/sc3d/caffeine-indicator/binding`. The default is Super+Ctrl+C (the “Super” key is typically the Windows key or equivalent).


## Installation

Caffeine is distributed in Debian and its derivatives, where you can use
your distribution’s software centre to install it, or in a terminal:

```
apt install caffeine
```

Caffeine is also available in the Python Package Index, under the name
“cups- of-caffeine”, but installing the Python package does not currently
take care of non-Python dependencies.


## If you think you’ve found a bug

Try running, in a terminal:

```
window_id=`xwininfo | grep "Window id" | cut -d " " -f 4`
```

Now click on the terminal window, and then run:

```
xdg-screensaver suspend $window_id
xdg-screensaver resume $window_id
```

This performs the same steps at a lower level as turning Caffeine on then
off again manually. If this gives the same problem as using Caffeine, then
the bug is definitely not in Caffeine.


## Testing translations

If you want to test out a translation without changing the language for the
whole session, run caffeine as e.g.: `LANGUAGE=ru ./caffeine`

To compile the translations: `./update_translations.py` (this is done
automatically when building the package, so no need to do it normally).

You will need a language pack for the given language. Be aware that some
stock items will not be translated unless you log in with a given language.
