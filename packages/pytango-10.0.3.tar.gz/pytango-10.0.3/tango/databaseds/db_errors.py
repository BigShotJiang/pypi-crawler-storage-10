# SPDX-FileCopyrightText: All Contributors to the PyTango project
# SPDX-License-Identifier: LGPL-3.0-or-later
DB_SQLError = "DB_SQLError"
DB_IncorrectArguments = "DB_IncorrectArguments"
DB_IncorrectDeviceName = "DB_IncorrectDeviceName"
DB_IncorrectServerName = "DB_IncorrectServerName"
DB_DeviceNotDefined = "DB_DeviceNotDefined"
DB_AliasNotDefined = "DB_AliasNotDefined"
DB_NoFreeMySQLConnection = "DB_NoFreeMySQLConnection"
DB_MySQLLibNotThreadSafe = "DB_MySQLLibNotThreadSafe"
