### PyTango logo

The blue polygonal snake.

Announced at the 39th Tango Community meeting, Giulianova, Italy. 2025-05-21.

Notes:
- Font: Inter Variable Bold (https://github.com/rsms/inter/releases/tag/v4.1)
- Original files: logo.xcf and logomark.xcf created with GIMP 2.10.
- The logo is designed to be shown on either a black or a white background.
