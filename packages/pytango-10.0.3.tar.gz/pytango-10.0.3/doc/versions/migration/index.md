(pytango-migration-guide)=

# Migration guide

This chapter describes how to migrate between the
different PyTango API versions.

```{toctree}
:maxdepth: 2

to-9.4/index
to-9.5/index
to-10.0/index
```
