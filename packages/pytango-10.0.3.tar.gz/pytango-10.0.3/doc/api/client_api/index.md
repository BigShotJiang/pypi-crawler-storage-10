# Client API

```{toctree}
:maxdepth: 2

device_proxy
attribute_proxy
group
green
miscellaneous
other
```
