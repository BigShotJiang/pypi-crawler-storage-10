import os, shutil, hashlib, random, numpy as np, pandas as pd
from tqdm.notebook import tqdm
from PIL import Image
import imagehash, torch, torch.nn as nn
from torchvision import models, transforms
from transformers import AutoImageProcessor, AutoModel
from timm import create_model
import open_clip
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.cluster import KMeans, DBSCAN
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from IPython import get_ipython

# Optional dependency
try:
    import hdbscan
except ImportError:
    hdbscan = None


class CleanFrame:
    """
    =============================================================
    CleanFrame: Professional Image Deduplication & Clustering Tool
    =============================================================
    Performs:
      1. MD5 exact-duplicate removal
      2. Perceptual-hash near-duplicate removal
      3. Deep-embedding semantic cleaning
      4. Optional embedding clustering + visualization
    """

    def __init__(self, device: str = "cpu"):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self._ipython_env = get_ipython()

    # ==========================================================
    # 1. Embedding Extractors
    # ==========================================================

    def ResNetEmbedding(self, folder):
        model = models.resnet50(pretrained=True)
        model = nn.Sequential(*list(model.children())[:-1]).to(self.device).eval()
        tf = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225])
        ])
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[ResNet50] Embeddings"):
                if f.lower().endswith(('.jpg','.jpeg','.png')):
                    p = os.path.join(folder, f)
                    x = tf(Image.open(p).convert('RGB')).unsqueeze(0).to(self.device)
                    feat = model(x).squeeze().cpu().numpy()
                    embs.append(feat / np.linalg.norm(feat))
                    paths.append(p)
        return np.array(embs), paths

    def SwinEmbedding(self, folder):
        model = create_model('swin_tiny_patch4_window7_224', pretrained=True, num_classes=0)
        model.to(self.device).eval()
        tf = transforms.Compose([
            transforms.Resize((224,224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485,0.456,0.406],
                                 std=[0.229,0.224,0.225])
        ])
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[Swin] Embeddings"):
                if f.lower().endswith(('.jpg','.jpeg','.png')):
                    p = os.path.join(folder,f)
                    x = tf(Image.open(p).convert('RGB')).unsqueeze(0).to(self.device)
                    feat = model(x).squeeze().cpu().numpy()
                    embs.append(feat / np.linalg.norm(feat))
                    paths.append(p)
        return np.array(embs), paths

    def CLIPEmbedding(self, folder):
        model, _, preprocess = open_clip.create_model_and_transforms(
            model_name="ViT-B-32", pretrained="openai")
        model.to(self.device).eval()
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[CLIP] Embeddings"):
                if f.lower().endswith(('.jpg','.jpeg','.png')):
                    p = os.path.join(folder,f)
                    x = preprocess(Image.open(p).convert('RGB')).unsqueeze(0).to(self.device)
                    feat = model.encode_image(x)
                    feat /= feat.norm(dim=-1, keepdim=True)
                    embs.append(feat.cpu().numpy().flatten())
                    paths.append(p)
        return np.array(embs), paths

    def DINOEmbedding(self, folder):
        model_id = "facebook/dinov2-base"
        processor = AutoImageProcessor.from_pretrained(model_id)
        model = AutoModel.from_pretrained(model_id).to(self.device).eval()
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[DINOv2] Embeddings"):
                if f.lower().endswith(('.jpg','.jpeg','.png')):
                    p = os.path.join(folder,f)
                    img = Image.open(p).convert('RGB')
                    x = processor(images=img, return_tensors="pt").to(self.device)
                    feat = model(**x).last_hidden_state.mean(dim=1)
                    feat = feat / feat.norm(dim=-1, keepdim=True)
                    embs.append(feat.cpu().numpy().flatten())
                    paths.append(p)
        return np.array(embs), paths

    # ==========================================================
    # 2. Clustering Interface
    # ==========================================================

    def cluster_embeddings(self, path, embeddings="clip", method="kmeans",
                           n_clusters=5, eps=0.5, min_samples=5):
        """Extract embeddings then cluster them."""
        print("================================")
        print(f"       {embeddings.upper()} + {method.upper()}")
        print("================================")

        # select embedding extractor
        if embeddings=="clip": emb, paths = self.CLIPEmbedding(path)
        elif embeddings=="swin": emb, paths = self.SwinEmbedding(path)
        elif embeddings=="resnet": emb, paths = self.ResNetEmbedding(path)
        elif embeddings=="dino": emb, paths = self.DINOEmbedding(path)
        else: raise ValueError("Embedding must be one of ['clip','swin','resnet','dino'].")

        if method=="kmeans":
            print(f"[1/1] KMeans clustering ({n_clusters} clusters)...")
            labels = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto').fit_predict(emb)
        elif method=="dbscan":
            print(f"[1/1] DBSCAN clustering (eps={eps}, min_samples={min_samples})...")
            labels = DBSCAN(eps=eps, min_samples=min_samples).fit_predict(emb)
        elif method=="hdbscan":
            if hdbscan is None: raise ImportError("Install hdbscan first: pip install hdbscan")
            print("[1/1] HDBSCAN clustering...")
            labels = hdbscan.HDBSCAN(min_cluster_size=min_samples).fit_predict(emb)
        else:
            raise ValueError("Method must be one of ['kmeans','dbscan','hdbscan'].")

        print(f"Clusters found: {len(np.unique(labels))}")
        return labels, emb, paths

    # ==========================================================
    # 3. Visualization
    # ==========================================================

    def visualize_clusters(self, embeddings, labels, paths,
                           title="Embedding Clusters", method="tsne", save=False):
        """Visualize 2D cluster projection."""
        print(f"Visualizing {title} using {method.upper()}...")
        reducer = TSNE(n_components=2, perplexity=30, random_state=42) \
                  if method=="tsne" else PCA(n_components=2)
        emb2d = reducer.fit_transform(embeddings)
        plt.figure(figsize=(7,6))
        plt.scatter(emb2d[:,0], emb2d[:,1], c=labels, cmap='tab10', s=10)
        plt.title(title)
        plt.axis('off')
        if save:
            os.makedirs("cluster_results", exist_ok=True)
            out = os.path.join("cluster_results", f"{title.replace(' ','_')}.png")
            plt.savefig(out, bbox_inches='tight')
            print(f"Saved visualization → {out}")
        if self._ipython_env: plt.show()
        else: plt.close()

    def show_cluster_images(self, paths, labels, title="Cluster Samples", max_per_cluster=3):
        """Show sample images from each cluster."""
        unique_labels = [l for l in np.unique(labels) if l != -1]
        print(f"Showing up to {max_per_cluster} images per {len(unique_labels)} clusters.")
        for cid in unique_labels:
            cluster_paths = [p for p,l in zip(paths,labels) if l==cid]
            print(f"\n[Cluster {cid}] {len(cluster_paths)} images")
            for img_path in random.sample(cluster_paths, min(max_per_cluster,len(cluster_paths))):
                print(" -", os.path.basename(img_path))
                if self._ipython_env:
                    display(Image.open(img_path))
                else:
                    Image.open(img_path).show()

    # ==========================================================
    # 4. Cluster-based Cleaning (High-level)
    # ==========================================================

    def cleanframe(self, path, embeddings='clip', cluster=None,
                   threshold=0.95, output_root="frames_cleaned"):
        """Clean duplicate/near-duplicate images per cluster."""
        paths = sorted([os.path.join(path,f) for f in os.listdir(path)
                        if f.lower().endswith(('.jpg','.jpeg','.png'))])
        print(f"Found {len(paths)} images in {path}")

        # choose embeddings
        if embeddings=="clip": embs,_=self.CLIPEmbedding(path)
        elif embeddings=="swin": embs,_=self.SwinEmbedding(path)
        elif embeddings=="resnet": embs,_=self.ResNetEmbedding(path)
        elif embeddings=="dino": embs,_=self.DINOEmbedding(path)
        else: raise ValueError("Embedding type invalid.")

        labels = np.zeros(len(paths)) if cluster is None else np.array(cluster)
        print(f"Clusters: {len(np.unique(labels))}")

        os.makedirs(output_root, exist_ok=True)
        total_kept, total_removed, kept_global = 0,0,set()

        for cid in [c for c in np.unique(labels) if c!=-1]:
            idx = np.where(labels==cid)[0]
            cluster_paths=[paths[i] for i in idx]
            if len(cluster_paths)==0: continue

            # Step1 MD5
            md5_set, md5_unique=set(),[]
            for p in cluster_paths:
                h=hashlib.md5(open(p,'rb').read()).hexdigest()
                if h not in md5_set:
                    md5_set.add(h); md5_unique.append(p)

            # Step2 pHash
            phash_dict, phash_unique={},[]
            for p in md5_unique:
                try: h=imagehash.phash(Image.open(p))
                except Exception: continue
                if not any(h-hh<5 for hh in phash_dict.values()):
                    phash_dict[p]=h; phash_unique.append(p)

            # Step3 Embedding similarity
            kept=[phash_unique[0]]; kept_idx=[paths.index(phash_unique[0])]
            for p in phash_unique[1:]:
                idxg=paths.index(p)
                sims=cosine_similarity(
                    embs[idxg].reshape(1,-1), embs[kept_idx])[0]
                if np.max(sims)<threshold:
                    kept.append(p); kept_idx.append(idxg)

            for p in kept:
                if p not in kept_global:
                    shutil.copy(p, os.path.join(output_root, os.path.basename(p)))
                    kept_global.add(p)

            total_kept+=len(kept)
            total_removed+=len(cluster_paths)-len(kept)
            print(f"[Cluster {cid}] {len(cluster_paths)} → {len(kept)}")

        print("======================================")
        print(f"Clusters processed: {len(np.unique(labels))}")
        print(f"Kept: {len(kept_global)} | Removed: {total_removed}")
        print(f"Saved in: {output_root}")
        print("======================================")
        return {"kept":list(kept_global),"removed":total_removed,"clusters":len(np.unique(labels))}