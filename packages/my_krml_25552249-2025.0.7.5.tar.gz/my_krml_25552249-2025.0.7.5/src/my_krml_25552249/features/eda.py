import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd

def convert_numeric_columns(df, numeric_cols):
    """
    Converts specified columns in a DataFrame to numeric (float) with coercion for invalid values.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame whose columns you want to convert.
    numeric_cols : list
        List of column names to convert to numeric.

    Returns
    -------
    pd.DataFrame
        The same DataFrame with converted numeric columns.
    """
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        else:
            print(f"Warning: '{col}' not found in DataFrame columns.")
    return df


def add_lag_and_rolling_features(df, lags=[1, 2], rolling_windows=[3, 7], cols=['high', 'close', 'volume', 'open']):
    """
    Adds lag features and rolling averages for specified columns,
    and drops rows with NaN values created by these features.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame sorted by time (chronologically).
    lags : list
        List of lag days to create (default [1, 2]).
    rolling_windows : list
        List of rolling window sizes for moving averages (default [3, 7]).
    cols : list
        List of columns to create lag/rolling features for (default ['high', 'close', 'volume', 'open']).

    Returns
    -------
    pd.DataFrame
        DataFrame with new lag and rolling average features, NaN rows dropped.
    """
    
    df = df.copy()  # avoid modifying original DataFrame
    
    # Lag features
    for col in cols:
        for lag in lags:
            df[f'{col}_lag{lag}'] = df[col].shift(lag)
    
    # Rolling averages
    for col in cols:
        for window in rolling_windows:
            df[f'{col}_ma{window}'] = df[col].rolling(window).mean()
    
    # Drop all rows with NaN values created by lag/rolling
    df = df.dropna().reset_index(drop=True)
    
    return df


def numeric_feature_eda(df, col, target_col=None, log_transform=False, bins=50):
    """
    Perform basic EDA on a numeric column:
    - Histogram (optionally log-transformed)
    - Boxplot
    - Scatter plot against target variable (if provided)
    
    Parameters
    ----------
    df : pd.DataFrame
        DataFrame containing the column to analyze.
    col : str
        Column name to analyze.
    target_col : str, optional
        Target variable column name. If provided, scatter plot is generated.
    log_transform : bool
        Whether to apply log(1 + x) transform to visualize distribution better.
    bins : int
        Number of bins for histogram (default 50).
    """
    
    data = df[col]
    
    # Histogram
    plt.figure(figsize=(10, 4))
    if log_transform:
        sns.histplot(np.log1p(data), bins=bins, kde=True, color='skyblue')
        plt.xlabel(f"log(1 + {col})")
    else:
        sns.histplot(data, bins=bins, kde=True, color='skyblue')
        plt.xlabel(col)
    plt.title(f"Histogram of {col}")
    plt.ylabel("Frequency")
    plt.show()
    
    # Boxplot
    plt.figure(figsize=(10, 4))
    sns.boxplot(x=data, color='steelblue')
    plt.title(f"Boxplot of {col}")
    plt.xlabel(col)
    plt.show()
    
    # Scatter plot against target variable
    if target_col is not None:
        plt.figure(figsize=(10, 4))
        if log_transform:
            plt.scatter(np.log1p(data), df[target_col], alpha=0.5, color='orange')
            plt.xlabel(f"log(1 + {col})")
        else:
            plt.scatter(data, df[target_col], alpha=0.5, color='orange')
            plt.xlabel(col)
        plt.ylabel(target_col)
        plt.title(f"{col} vs {target_col}")
        plt.show()
