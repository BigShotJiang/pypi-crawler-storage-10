import time
import math
import sys

class LuckyTools:
    def __init__(self, prefix_name="⌊ LuckyTools ⌉ »", prefix_hex="00FF5A", prefix_short="⌊ LT ⌉ »", show_warns=True, show_init=True):
        try:
            self.prefix = prefix_name
            self.prefix_hex = prefix_hex
            self.prefix_short = prefix_short
            self.frame = time.time()

            self.fade_print("Успешная инициализация", color=self.prefix_hex, time_show=0.1, white_tag=True)
        except Exception as ex:
            print(self.fore_fromhex("⌊ LuckyTools ⌉ »", "ff1414"),
                  self.fore_fromhex(" Ошибка инициализации", "ff8080"),
                  self.fore_fromhex("LuckyTools: ", "ff1414"),
                  self.fore_fromhex(f"{ex}", "ff8080"))

    def print(self, text):
        if type(text) == list:
            print(self.fore_fromhex(self.prefix_short, self.prefix_hex),
                  self.fore_fromhex(f"Показано", "adwadad"),
                  self.fore_fromhex(f"{len(text)} элементов:", self.prefix_hex))
            for i in text:
                print(self.fore_fromhex("»", self.prefix_hex),
                      self.fore_fromhex(i, "ffffff"))
        elif type(text) == str or type(text) == int or type(text) == float:
            print(self.fore_fromhex(self.prefix_short, self.prefix_hex),
                  self.fore_fromhex(text, "ffffff"))
        elif type(text) == dict:
            print(self.fore_fromhex(self.prefix_short, self.prefix_hex),
                  self.fore_fromhex("Показано", "adwadad"),
                  self.fore_fromhex(f"{len(text)} пар ключ-значение:", self.prefix_hex))
            for key, value in text.items():
                print(self.fore_fromhex(f"{key}:", self.prefix_hex),
                      self.fore_fromhex(value, "ffffff"))


    def fade(self, text, text_hex="00FF5A", seconds=1, speed=3, white_tag=False):
        try:
            time_fade = 0
            while time_fade <seconds:
                if white_tag:
                    colored_text = f"{self.fore_fromhex(self.prefix_short, 'ffffff')} "
                else:
                    colored_text = f"{self.fore_fromhex(self.prefix_short, self.prefix_hex)} "
                self.frame = time.time()
                amplitude = 45
                Red, Green, Blue = self.hex_to_rgb(text_hex)

                for i, char in enumerate(text):
                    phase = self.frame * speed + i * 0.4
                    wave_value = math.sin(phase)
                    brightness_offset = int(wave_value * amplitude)

                    r = max(0, min(255, Red + brightness_offset))
                    g = max(0, min(255, Green + brightness_offset))
                    b = max(0, min(255, Blue + brightness_offset))

                    hex_code = f"{r:02x}{g:02x}{b:02x}"
                    colored_text += self.fore_fromhex(char, hex_code)

                sys.stdout.write(f"\r{colored_text}")
                sys.stdout.flush()
                time_fade += 0.02
                time.sleep(0.02)
        except:
            print("STOP")

    def fade_print(self, text, time_show=10, speed=3, color="00FF5A", white_tag=False):
        self.fade(text, color, speed=speed, seconds=time_show, white_tag=white_tag)
        print()

    def cleanhex(self, data):
        valid_hex = '0123456789ABCDEF'.__contains__
        return ''.join(filter(valid_hex, data.upper()))
    def fore_fromhex(self, text, hexcode, tag=False):
        hexcode = self.cleanhex(hexcode)
        red = int(hexcode[0:2], 16)
        green = int(hexcode[2:4], 16)
        blue = int(hexcode[4:6], 16)
        if tag:
            tag_text = self.fore_fromhex(self.prefix_short, self.prefix_hex)
            return tag_text, "\x1B[38;2;{};{};{}m{}\x1B[0m".format(red, green, blue, text)
        return "\x1B[38;2;{};{};{}m{}\x1B[0m".format(red, green, blue, text)
    def hex_to_rgb(self, hexcode):
        hexcode = self.cleanhex(hexcode)
        if len(hexcode) < 6:
            return 255, 206, 107
        try:
            r = int(hexcode[0:2], 16)
            g = int(hexcode[2:4], 16)
            b = int(hexcode[4:6], 16)
            return r, g, b
        except ValueError:
            return 255, 206, 107

