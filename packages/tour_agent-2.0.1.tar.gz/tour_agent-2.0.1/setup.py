from setuptools import setup, find_packages

# README.md fayldan uzun descriptionni o‘qib olish
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="tour_agent",
    version="2.0.1",
    author="Asilbek Sadullayev",
    description="Python uchun sayohat turlarini boshqaruvchi kutubxona",
    long_description=long_description,
    long_description_content_type="text/markdown",  # Markdown format ekanini bildiradi
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)
