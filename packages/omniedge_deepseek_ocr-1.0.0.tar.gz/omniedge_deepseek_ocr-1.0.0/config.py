#!/usr/bin/env python3
"""
DeepSeek-OCR 配置模块

提供API配置和默认参数设置
"""

import os
from typing import Dict, Any, Optional

# API基础配置
API_BASE_URL = "https://api.siliconflow.cn/v1/chat/completions"
MODEL_NAME = "deepseek-ai/DeepSeek-OCR"

# 默认请求参数
DEFAULT_REQUEST_CONFIG = {
    "model": MODEL_NAME,
    "messages": [],
    "stream": False,
    "max_tokens": 4000,
    "temperature": 0.0,
    "top_p": 0.9,
    "frequency_penalty": 0.1,
    "presence_penalty": 0.1
}

# 支持的图片格式
SUPPORTED_IMAGE_FORMATS = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.bmp': 'image/bmp',
    '.webp': 'image/webp'
}

# 默认设置
DEFAULT_SETTINGS = {
    "timeout": 60,
    "max_retries": 3,
    "retry_delay": 1.0,
    "default_prompt": "OCR"
}


class Config:
    """
    配置管理类
    """

    def __init__(self, api_key: Optional[str] = None, base_dir: Optional[str] = None):
        """
        初始化配置

        Args:
            api_key: API密钥
            base_dir: 基础目录
        """
        self.api_key = api_key
        self.base_dir = base_dir or os.getcwd()
        self.settings = DEFAULT_SETTINGS.copy()

    def get_api_key(self) -> str:
        """
        获取API密钥

        Returns:
            API密钥字符串

        Raises:
            ValueError: 无法获取API密钥时抛出
        """
        if self.api_key:
            return self.api_key

        # 尝试从环境变量获取
        env_key = os.getenv("DEEPSEEK_API_KEY")
        if env_key:
            return env_key

        # 尝试从key.txt文件获取
        key_file = os.path.join(self.base_dir, "key.txt")
        if os.path.exists(key_file):
            try:
                with open(key_file, 'r', encoding='utf-8') as f:
                    return f.read().strip()
            except Exception as e:
                raise ValueError(f"读取API密钥文件失败: {e}")

        raise ValueError(
            "无法获取API密钥。请通过以下方式之一提供：\n"
            "1. 设置环境变量DEEPSEEK_API_KEY\n"
            "2. 在项目目录创建key.txt文件"
        )

    def update_setting(self, key: str, value: Any) -> None:
        """
        更新设置

        Args:
            key: 设置键名
            value: 设置值
        """
        self.settings[key] = value

    def get_setting(self, key: str, default: Any = None) -> Any:
        """
        获取设置值

        Args:
            key: 设置键名
            default: 默认值

        Returns:
            设置值
        """
        return self.settings.get(key, default)


# 全局配置实例
_global_config = None


def get_config(api_key: Optional[str] = None, base_dir: Optional[str] = None) -> Config:
    """
    获取全局配置实例

    Args:
        api_key: API密钥
        base_dir: 基础目录

    Returns:
        配置实例
    """
    global _global_config
    if _global_config is None:
        _global_config = Config(api_key, base_dir)
    return _global_config


def reset_config() -> None:
    """重置全局配置"""
    global _global_config
    _global_config = None