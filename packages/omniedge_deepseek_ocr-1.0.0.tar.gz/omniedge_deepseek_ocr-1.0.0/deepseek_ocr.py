#!/usr/bin/env python3
"""
OmniEdge DeepSeek-OCR 简单易用的OCR识别模块

作者: 智子边界(OmniEdge)
提供简单的API接口，支持图片文字识别功能。

基础使用:
    from omniedge_deepseek_ocr import DeepSeekOCR

    ocr = DeepSeekOCR()
    result = ocr.recognize("image.png")
    print(result)

高级使用:
    ocr = DeepSeekOCR(api_key="your_api_key")
    results = ocr.recognize_batch(["img1.png", "img2.png"])
"""

import os
import json
import requests
from datetime import datetime
from typing import Dict, Any, Optional, List, Union
from pathlib import Path

# API配置
API_BASE_URL = "https://api.siliconflow.cn/v1/chat/completions"
MODEL_NAME = "deepseek-ai/DeepSeek-OCR"
DEFAULT_REQUEST_CONFIG = {
    "model": MODEL_NAME,
    "messages": [],
    "stream": False,
    "max_tokens": 4000,
    "temperature": 0.0,
    "top_p": 0.9,
    "frequency_penalty": 0.1,
    "presence_penalty": 0.1
}

# 支持的图片格式
SUPPORTED_IMAGE_FORMATS = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.bmp': 'image/bmp',
    '.webp': 'image/webp'
}


class DeepSeekOCR:
    """
    DeepSeek-OCR 简易客户端

    提供简单易用的OCR文字识别功能
    作者: 智子边界(OmniEdge)
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        初始化OCR客户端

        Args:
            api_key: API密钥，如果不提供则从环境变量或配置文件读取

        Raises:
            ValueError: 无法获取API密钥时抛出
        """
        self.api_url = API_BASE_URL
        self.api_key = self._get_api_key(api_key)
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        })

    def _get_api_key(self, api_key: Optional[str]) -> str:
        """
        获取API密钥

        Args:
            api_key: 直接提供的API密钥

        Returns:
            API密钥字符串

        Raises:
            ValueError: 无法获取API密钥时抛出
        """
        # 优先使用直接提供的API密钥
        if api_key:
            return api_key

        # 尝试从环境变量获取
        env_key = os.getenv("OMNIEDGE_OCR_API_KEY")
        if env_key:
            return env_key

              # 尝试从配置文件获取
        config_files = [
            "deepseek_ocr_key.txt",
            "key.txt"
        ]

        for config_file in config_files:
            if os.path.exists(config_file):
                try:
                    with open(config_file, 'r', encoding='utf-8') as f:
                        return f.read().strip()
                except Exception as e:
                    continue

        raise ValueError(
            "无法获取API密钥。请通过以下方式之一提供：\n"
            "1. 设置环境变量OMNIEDGE_OCR_API_KEY\n"
            "2. 在项目目录创建deepseek_ocr_key.txt文件\n"
            "3. 在代码中直接传递api_key参数\n\n"
            "获取API密钥: https://cloud.siliconflow.cn/account/ak"
        )

    def _encode_image_to_base64(self, image_path: str) -> str:
        """
        将图片文件编码为base64格式

        Args:
            image_path: 图片文件路径

        Returns:
            base64编码的图片URL字符串
        """
        import base64

        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图片文件不存在: {image_path}")

        # 获取MIME类型
        ext = os.path.splitext(image_path)[1].lower()
        mime_types = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.bmp': 'image/bmp',
            '.webp': 'image/webp'
        }
        mime_type = mime_types.get(ext, 'image/jpeg')

        # 编码图片
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
            base64_data = base64.b64encode(image_data).decode('utf-8')
            return f"data:{mime_type};base64,{base64_data}"

    def _prepare_request_data(self, image_path: str, prompt: str) -> Dict[str, Any]:
        """
        准备API请求数据

        Args:
            image_path: 图片路径
            prompt: OCR提示词

        Returns:
            请求数据字典
        """
        image_content = self._encode_image_to_base64(image_path)

        request_data = DEFAULT_REQUEST_CONFIG.copy()
        request_data["messages"] = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": image_content
                        }
                    }
                ]
            }
        ]

        return request_data

    def _call_api(self, image_path: str, prompt: str = "OCR") -> Dict[str, Any]:
        """
        调用DeepSeek-OCR API

        Args:
            image_path: 图片路径
            prompt: OCR提示词，默认为"OCR"

        Returns:
            API响应数据

        Raises:
            requests.RequestException: 网络请求异常
            ValueError: API响应异常
        """
        request_data = self._prepare_request_data(image_path, prompt)

        try:
            response = self.session.post(
                self.api_url,
                json=request_data,
                timeout=60
            )

            if response.status_code == 200:
                return response.json()
            else:
                error_msg = f"API调用失败: {response.status_code} - {response.text}"
                raise ValueError(error_msg)

        except requests.exceptions.Timeout:
            raise requests.RequestException("API请求超时")
        except requests.exceptions.ConnectionError:
            raise requests.RequestException("网络连接失败")
        except requests.exceptions.RequestException as e:
            raise requests.RequestException(f"网络请求异常: {e}")

    def _extract_text_from_response(self, response_data: Dict[str, Any]) -> Optional[str]:
        """
        从API响应中提取识别出的文本

        Args:
            response_data: API响应数据

        Returns:
            识别出的文本，如果提取失败返回None
        """
        try:
            if "choices" in response_data and len(response_data["choices"]) > 0:
                choice = response_data["choices"][0]
                if "message" in choice and "content" in choice["message"]:
                    return choice["message"]["content"].strip()
            return None
        except Exception:
            return None

    def recognize(self, image_path: str, prompt: str = "OCR") -> Optional[str]:
        """
        识别单张图片中的文字

        Args:
            image_path: 图片文件路径
            prompt: OCR提示词，默认为"OCR"

        Returns:
            识别出的文字内容，如果失败返回None

        Example:
            >>> ocr = DeepSeekOCR()
            >>> text = ocr.recognize("image.png")
            >>> print(text)
        """
        try:
            response_data = self._call_api(image_path, prompt)
            text = self._extract_text_from_response(response_data)
            return text
        except Exception as e:
            print(f"OCR识别失败: {e}")
            return None

    def recognize_batch(self, image_paths: List[str], prompt: str = "OCR") -> List[Dict[str, Any]]:
        """
        批量识别多张图片

        Args:
            image_paths: 图片文件路径列表
            prompt: OCR提示词，默认为"OCR"

        Returns:
            识别结果列表，每个元素包含路径和结果

        Example:
            >>> ocr = DeepSeekOCR()
            >>> results = ocr.recognize_batch(["img1.png", "img2.png"])
            >>> for result in results:
            ...     print(f"{result['path']}: {result['text']}")
        """
        results = []

        for image_path in image_paths:
            result = {
                "path": image_path,
                "text": None,
                "success": False,
                "error": None
            }

            try:
                text = self.recognize(image_path, prompt)
                if text:
                    result["text"] = text
                    result["success"] = True
                else:
                    result["error"] = "识别结果为空"
            except Exception as e:
                result["error"] = str(e)

            results.append(result)

        return results

    def save_result(self, text: str, output_path: str, format: str = "txt") -> bool:
        """
        保存识别结果到文件

        Args:
            text: 要保存的文本内容
            output_path: 输出文件路径
            format: 文件格式，支持 "txt" 或 "json"

        Returns:
            保存是否成功

        Example:
            >>> ocr = DeepSeekOCR()
            >>> text = ocr.recognize("image.png")
            >>> ocr.save_result(text, "result.txt")
        """
        try:
            # 确保目录存在
            output_dir = os.path.dirname(output_path)
            if output_dir:  # 只有当目录路径不为空时才创建
                os.makedirs(output_dir, exist_ok=True)

            if format.lower() == "json":
                data = {
                    "text": text,
                    "timestamp": datetime.now().isoformat(),
                    "model": MODEL_NAME,
                    "author": "智子边界(OmniEdge)"
                }
                with open(output_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
            else:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(text)

            return True
        except Exception as e:
            print(f"保存文件失败: {e}")
            return False


# 便捷函数
def recognize_image(image_path: str, api_key: Optional[str] = None, prompt: str = "OCR") -> Optional[str]:
    """
    便捷的图片识别函数

    Args:
        image_path: 图片文件路径
        api_key: API密钥
        prompt: OCR提示词

    Returns:
        识别出的文字内容

    Example:
        >>> text = recognize_image("image.png")
        >>> print(text)
    """
    ocr = DeepSeekOCR(api_key=api_key)
    return ocr.recognize(image_path, prompt)


if __name__ == "__main__":
    # 简单的命令行测试
    import sys

    if len(sys.argv) < 2:
        print("使用方法: python deepseek_ocr.py <图片路径> [prompt]")
        sys.exit(1)

    image_path = sys.argv[1]
    prompt = sys.argv[2] if len(sys.argv) > 2 else "OCR"

    print(f"正在识别图片: {image_path}")
    print(f"使用prompt: {prompt}")

    ocr = DeepSeekOCR()
    result = ocr.recognize(image_path, prompt)

    if result:
        print("\n识别结果:")
        print("=" * 50)
        print(result)
        print("=" * 50)

        # 保存结果
        output_file = "ocr_result.txt"
        if ocr.save_result(result, output_file):
            print(f"\n结果已保存到: {output_file}")
    else:
        print("识别失败")