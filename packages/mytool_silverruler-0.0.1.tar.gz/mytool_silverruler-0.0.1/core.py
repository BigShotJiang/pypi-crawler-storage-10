# mytool/core.py
def say_hello():
    print("Hello from MyTool!")

