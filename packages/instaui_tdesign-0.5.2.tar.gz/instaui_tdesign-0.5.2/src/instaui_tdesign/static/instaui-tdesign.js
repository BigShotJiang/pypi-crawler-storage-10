import { defineComponent as V, useAttrs as Q, useSlots as k, createBlock as X, openBlock as Z, mergeProps as tt, unref as d, createSlots as et, renderList as H, withCtx as E, renderSlot as rt, normalizeProps as nt, guardReactiveProps as it, computed as T, ref as Jt, createElementVNode as St, createVNode as be, toDisplayString as ft, createTextVNode as Ct, resolveDynamicComponent as ve } from "vue";
import * as I from "tdesign-vue-next";
import { DateRangePickerPanel as me, useConfig as Ae, MessagePlugin as Te, NotifyPlugin as we } from "tdesign-vue-next";
function Oe(t) {
  const { container: e = ".insta-main" } = t;
  return e;
}
const $e = /* @__PURE__ */ V({
  inheritAttrs: !1,
  __name: "Affix",
  setup(t) {
    const e = Q(), r = k(), n = Oe(e);
    return (a, i) => (Z(), X(I.Affix, tt(d(e), { container: d(n) }), et({ _: 2 }, [
      H(d(r), (o, u) => ({
        name: u,
        fn: E((s) => [
          rt(a.$slots, u, nt(it(s)))
        ])
      }))
    ]), 1040, ["container"]));
  }
});
function Pe(t) {
  const e = [], r = T(() => t.data ?? []);
  return {
    tableData: T(() => {
      const i = r.value;
      return e.reduce((o, u) => u(o), i);
    }),
    orgData: r,
    registerRowsHandler: (i) => {
      e.push(i);
    }
  };
}
function Se(t) {
  const { tableData: e, attrs: r } = t, n = [], a = T(() => {
    let u = !r.columns && e.value.length > 0 ? Ce(e.value) : r.columns ?? [];
    u = u.map(xe);
    for (const s of n)
      u = s(u);
    return u;
  });
  function i(o) {
    n.push(o);
  }
  return [a, i];
}
function Ce(t) {
  const e = t[0];
  return Object.keys(e).map((n) => ({
    colKey: n,
    title: n,
    sorter: !0
  }));
}
function xe(t) {
  const e = t.name ?? t.colKey, r = `header-cell-${e}`, n = `body-cell-${e}`, a = t.label ?? t.colKey;
  return {
    ...t,
    name: e,
    label: a,
    title: r,
    cell: n
  };
}
function Ee(t) {
  const { tableData: e, attrs: r } = t;
  return T(() => {
    const { pagination: n } = r;
    let a;
    if (typeof n == "boolean") {
      if (!n)
        return;
      a = {
        defaultPageSize: 10
      };
    }
    return typeof n == "number" && n > 0 && (a = {
      defaultPageSize: n
    }), typeof n == "object" && n !== null && (a = n), {
      defaultCurrent: 1,
      total: e.value.length,
      ...a
    };
  });
}
var Qt = typeof global == "object" && global && global.Object === Object && global, Re = typeof self == "object" && self && self.Object === Object && self, O = Qt || Re || Function("return this")(), C = O.Symbol, kt = Object.prototype, De = kt.hasOwnProperty, je = kt.toString, B = C ? C.toStringTag : void 0;
function Fe(t) {
  var e = De.call(t, B), r = t[B];
  try {
    t[B] = void 0;
    var n = !0;
  } catch {
  }
  var a = je.call(t);
  return n && (e ? t[B] = r : delete t[B]), a;
}
var Ie = Object.prototype, Me = Ie.toString;
function Le(t) {
  return Me.call(t);
}
var Ne = "[object Null]", ze = "[object Undefined]", xt = C ? C.toStringTag : void 0;
function L(t) {
  return t == null ? t === void 0 ? ze : Ne : xt && xt in Object(t) ? Fe(t) : Le(t);
}
function M(t) {
  return t != null && typeof t == "object";
}
var Be = "[object Symbol]";
function U(t) {
  return typeof t == "symbol" || M(t) && L(t) == Be;
}
function J(t, e) {
  for (var r = -1, n = t == null ? 0 : t.length, a = Array(n); ++r < n; )
    a[r] = e(t[r], r, t);
  return a;
}
var A = Array.isArray, Et = C ? C.prototype : void 0, Rt = Et ? Et.toString : void 0;
function te(t) {
  if (typeof t == "string")
    return t;
  if (A(t))
    return J(t, te) + "";
  if (U(t))
    return Rt ? Rt.call(t) : "";
  var e = t + "";
  return e == "0" && 1 / t == -1 / 0 ? "-0" : e;
}
function yt(t) {
  var e = typeof t;
  return t != null && (e == "object" || e == "function");
}
function ee(t) {
  return t;
}
var Ge = "[object AsyncFunction]", He = "[object Function]", Ue = "[object GeneratorFunction]", Ke = "[object Proxy]";
function re(t) {
  if (!yt(t))
    return !1;
  var e = L(t);
  return e == He || e == Ue || e == Ge || e == Ke;
}
var lt = O["__core-js_shared__"], Dt = function() {
  var t = /[^.]+$/.exec(lt && lt.keys && lt.keys.IE_PROTO || "");
  return t ? "Symbol(src)_1." + t : "";
}();
function We(t) {
  return !!Dt && Dt in t;
}
var qe = Function.prototype, Ve = qe.toString;
function D(t) {
  if (t != null) {
    try {
      return Ve.call(t);
    } catch {
    }
    try {
      return t + "";
    } catch {
    }
  }
  return "";
}
var Xe = /[\\^$.*+?()[\]{}|]/g, Ze = /^\[object .+?Constructor\]$/, Ye = Function.prototype, Je = Object.prototype, Qe = Ye.toString, ke = Je.hasOwnProperty, tr = RegExp(
  "^" + Qe.call(ke).replace(Xe, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function er(t) {
  if (!yt(t) || We(t))
    return !1;
  var e = re(t) ? tr : Ze;
  return e.test(D(t));
}
function rr(t, e) {
  return t?.[e];
}
function N(t, e) {
  var r = rr(t, e);
  return er(r) ? r : void 0;
}
var gt = N(O, "WeakMap");
function nr() {
}
function ir(t, e, r, n) {
  for (var a = t.length, i = r + -1; ++i < a; )
    if (e(t[i], i, t))
      return i;
  return -1;
}
function ar(t) {
  return t !== t;
}
function or(t, e, r) {
  for (var n = r - 1, a = t.length; ++n < a; )
    if (t[n] === e)
      return n;
  return -1;
}
function sr(t, e, r) {
  return e === e ? or(t, e, r) : ir(t, ar, r);
}
function ur(t, e) {
  var r = t == null ? 0 : t.length;
  return !!r && sr(t, e, 0) > -1;
}
var fr = 9007199254740991, lr = /^(?:0|[1-9]\d*)$/;
function ne(t, e) {
  var r = typeof t;
  return e = e ?? fr, !!e && (r == "number" || r != "symbol" && lr.test(t)) && t > -1 && t % 1 == 0 && t < e;
}
function ie(t, e) {
  return t === e || t !== t && e !== e;
}
var cr = 9007199254740991;
function bt(t) {
  return typeof t == "number" && t > -1 && t % 1 == 0 && t <= cr;
}
function vt(t) {
  return t != null && bt(t.length) && !re(t);
}
var pr = Object.prototype;
function gr(t) {
  var e = t && t.constructor, r = typeof e == "function" && e.prototype || pr;
  return t === r;
}
function dr(t, e) {
  for (var r = -1, n = Array(t); ++r < t; )
    n[r] = e(r);
  return n;
}
var hr = "[object Arguments]";
function jt(t) {
  return M(t) && L(t) == hr;
}
var ae = Object.prototype, _r = ae.hasOwnProperty, yr = ae.propertyIsEnumerable, oe = jt(/* @__PURE__ */ function() {
  return arguments;
}()) ? jt : function(t) {
  return M(t) && _r.call(t, "callee") && !yr.call(t, "callee");
};
function br() {
  return !1;
}
var se = typeof exports == "object" && exports && !exports.nodeType && exports, Ft = se && typeof module == "object" && module && !module.nodeType && module, vr = Ft && Ft.exports === se, It = vr ? O.Buffer : void 0, mr = It ? It.isBuffer : void 0, dt = mr || br, Ar = "[object Arguments]", Tr = "[object Array]", wr = "[object Boolean]", Or = "[object Date]", $r = "[object Error]", Pr = "[object Function]", Sr = "[object Map]", Cr = "[object Number]", xr = "[object Object]", Er = "[object RegExp]", Rr = "[object Set]", Dr = "[object String]", jr = "[object WeakMap]", Fr = "[object ArrayBuffer]", Ir = "[object DataView]", Mr = "[object Float32Array]", Lr = "[object Float64Array]", Nr = "[object Int8Array]", zr = "[object Int16Array]", Br = "[object Int32Array]", Gr = "[object Uint8Array]", Hr = "[object Uint8ClampedArray]", Ur = "[object Uint16Array]", Kr = "[object Uint32Array]", _ = {};
_[Mr] = _[Lr] = _[Nr] = _[zr] = _[Br] = _[Gr] = _[Hr] = _[Ur] = _[Kr] = !0;
_[Ar] = _[Tr] = _[Fr] = _[wr] = _[Ir] = _[Or] = _[$r] = _[Pr] = _[Sr] = _[Cr] = _[xr] = _[Er] = _[Rr] = _[Dr] = _[jr] = !1;
function Wr(t) {
  return M(t) && bt(t.length) && !!_[L(t)];
}
function ue(t) {
  return function(e) {
    return t(e);
  };
}
var fe = typeof exports == "object" && exports && !exports.nodeType && exports, G = fe && typeof module == "object" && module && !module.nodeType && module, qr = G && G.exports === fe, ct = qr && Qt.process, Mt = function() {
  try {
    var t = G && G.require && G.require("util").types;
    return t || ct && ct.binding && ct.binding("util");
  } catch {
  }
}(), Lt = Mt && Mt.isTypedArray, le = Lt ? ue(Lt) : Wr, Vr = Object.prototype, Xr = Vr.hasOwnProperty;
function Zr(t, e) {
  var r = A(t), n = !r && oe(t), a = !r && !n && dt(t), i = !r && !n && !a && le(t), o = r || n || a || i, u = o ? dr(t.length, String) : [], s = u.length;
  for (var f in t)
    Xr.call(t, f) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (f == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    a && (f == "offset" || f == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    i && (f == "buffer" || f == "byteLength" || f == "byteOffset") || // Skip index properties.
    ne(f, s))) && u.push(f);
  return u;
}
function Yr(t, e) {
  return function(r) {
    return t(e(r));
  };
}
var Jr = Yr(Object.keys, Object), Qr = Object.prototype, kr = Qr.hasOwnProperty;
function tn(t) {
  if (!gr(t))
    return Jr(t);
  var e = [];
  for (var r in Object(t))
    kr.call(t, r) && r != "constructor" && e.push(r);
  return e;
}
function mt(t) {
  return vt(t) ? Zr(t) : tn(t);
}
var en = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, rn = /^\w*$/;
function At(t, e) {
  if (A(t))
    return !1;
  var r = typeof t;
  return r == "number" || r == "symbol" || r == "boolean" || t == null || U(t) ? !0 : rn.test(t) || !en.test(t) || e != null && t in Object(e);
}
var K = N(Object, "create");
function nn() {
  this.__data__ = K ? K(null) : {}, this.size = 0;
}
function an(t) {
  var e = this.has(t) && delete this.__data__[t];
  return this.size -= e ? 1 : 0, e;
}
var on = "__lodash_hash_undefined__", sn = Object.prototype, un = sn.hasOwnProperty;
function fn(t) {
  var e = this.__data__;
  if (K) {
    var r = e[t];
    return r === on ? void 0 : r;
  }
  return un.call(e, t) ? e[t] : void 0;
}
var ln = Object.prototype, cn = ln.hasOwnProperty;
function pn(t) {
  var e = this.__data__;
  return K ? e[t] !== void 0 : cn.call(e, t);
}
var gn = "__lodash_hash_undefined__";
function dn(t, e) {
  var r = this.__data__;
  return this.size += this.has(t) ? 0 : 1, r[t] = K && e === void 0 ? gn : e, this;
}
function R(t) {
  var e = -1, r = t == null ? 0 : t.length;
  for (this.clear(); ++e < r; ) {
    var n = t[e];
    this.set(n[0], n[1]);
  }
}
R.prototype.clear = nn;
R.prototype.delete = an;
R.prototype.get = fn;
R.prototype.has = pn;
R.prototype.set = dn;
function hn() {
  this.__data__ = [], this.size = 0;
}
function at(t, e) {
  for (var r = t.length; r--; )
    if (ie(t[r][0], e))
      return r;
  return -1;
}
var _n = Array.prototype, yn = _n.splice;
function bn(t) {
  var e = this.__data__, r = at(e, t);
  if (r < 0)
    return !1;
  var n = e.length - 1;
  return r == n ? e.pop() : yn.call(e, r, 1), --this.size, !0;
}
function vn(t) {
  var e = this.__data__, r = at(e, t);
  return r < 0 ? void 0 : e[r][1];
}
function mn(t) {
  return at(this.__data__, t) > -1;
}
function An(t, e) {
  var r = this.__data__, n = at(r, t);
  return n < 0 ? (++this.size, r.push([t, e])) : r[n][1] = e, this;
}
function $(t) {
  var e = -1, r = t == null ? 0 : t.length;
  for (this.clear(); ++e < r; ) {
    var n = t[e];
    this.set(n[0], n[1]);
  }
}
$.prototype.clear = hn;
$.prototype.delete = bn;
$.prototype.get = vn;
$.prototype.has = mn;
$.prototype.set = An;
var W = N(O, "Map");
function Tn() {
  this.size = 0, this.__data__ = {
    hash: new R(),
    map: new (W || $)(),
    string: new R()
  };
}
function wn(t) {
  var e = typeof t;
  return e == "string" || e == "number" || e == "symbol" || e == "boolean" ? t !== "__proto__" : t === null;
}
function ot(t, e) {
  var r = t.__data__;
  return wn(e) ? r[typeof e == "string" ? "string" : "hash"] : r.map;
}
function On(t) {
  var e = ot(this, t).delete(t);
  return this.size -= e ? 1 : 0, e;
}
function $n(t) {
  return ot(this, t).get(t);
}
function Pn(t) {
  return ot(this, t).has(t);
}
function Sn(t, e) {
  var r = ot(this, t), n = r.size;
  return r.set(t, e), this.size += r.size == n ? 0 : 1, this;
}
function P(t) {
  var e = -1, r = t == null ? 0 : t.length;
  for (this.clear(); ++e < r; ) {
    var n = t[e];
    this.set(n[0], n[1]);
  }
}
P.prototype.clear = Tn;
P.prototype.delete = On;
P.prototype.get = $n;
P.prototype.has = Pn;
P.prototype.set = Sn;
var Cn = "Expected a function";
function Tt(t, e) {
  if (typeof t != "function" || e != null && typeof e != "function")
    throw new TypeError(Cn);
  var r = function() {
    var n = arguments, a = e ? e.apply(this, n) : n[0], i = r.cache;
    if (i.has(a))
      return i.get(a);
    var o = t.apply(this, n);
    return r.cache = i.set(a, o) || i, o;
  };
  return r.cache = new (Tt.Cache || P)(), r;
}
Tt.Cache = P;
var xn = 500;
function En(t) {
  var e = Tt(t, function(n) {
    return r.size === xn && r.clear(), n;
  }), r = e.cache;
  return e;
}
var Rn = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, Dn = /\\(\\)?/g, jn = En(function(t) {
  var e = [];
  return t.charCodeAt(0) === 46 && e.push(""), t.replace(Rn, function(r, n, a, i) {
    e.push(a ? i.replace(Dn, "$1") : n || r);
  }), e;
});
function Fn(t) {
  return t == null ? "" : te(t);
}
function ce(t, e) {
  return A(t) ? t : At(t, e) ? [t] : jn(Fn(t));
}
function st(t) {
  if (typeof t == "string" || U(t))
    return t;
  var e = t + "";
  return e == "0" && 1 / t == -1 / 0 ? "-0" : e;
}
function wt(t, e) {
  e = ce(e, t);
  for (var r = 0, n = e.length; t != null && r < n; )
    t = t[st(e[r++])];
  return r && r == n ? t : void 0;
}
function In(t, e, r) {
  var n = t == null ? void 0 : wt(t, e);
  return n === void 0 ? r : n;
}
function Mn(t, e) {
  for (var r = -1, n = e.length, a = t.length; ++r < n; )
    t[a + r] = e[r];
  return t;
}
function Ln() {
  this.__data__ = new $(), this.size = 0;
}
function Nn(t) {
  var e = this.__data__, r = e.delete(t);
  return this.size = e.size, r;
}
function zn(t) {
  return this.__data__.get(t);
}
function Bn(t) {
  return this.__data__.has(t);
}
var Gn = 200;
function Hn(t, e) {
  var r = this.__data__;
  if (r instanceof $) {
    var n = r.__data__;
    if (!W || n.length < Gn - 1)
      return n.push([t, e]), this.size = ++r.size, this;
    r = this.__data__ = new P(n);
  }
  return r.set(t, e), this.size = r.size, this;
}
function w(t) {
  var e = this.__data__ = new $(t);
  this.size = e.size;
}
w.prototype.clear = Ln;
w.prototype.delete = Nn;
w.prototype.get = zn;
w.prototype.has = Bn;
w.prototype.set = Hn;
function Un(t, e) {
  for (var r = -1, n = t == null ? 0 : t.length, a = 0, i = []; ++r < n; ) {
    var o = t[r];
    e(o, r, t) && (i[a++] = o);
  }
  return i;
}
function Kn() {
  return [];
}
var Wn = Object.prototype, qn = Wn.propertyIsEnumerable, Nt = Object.getOwnPropertySymbols, Vn = Nt ? function(t) {
  return t == null ? [] : (t = Object(t), Un(Nt(t), function(e) {
    return qn.call(t, e);
  }));
} : Kn;
function Xn(t, e, r) {
  var n = e(t);
  return A(t) ? n : Mn(n, r(t));
}
function zt(t) {
  return Xn(t, mt, Vn);
}
var ht = N(O, "DataView"), _t = N(O, "Promise"), F = N(O, "Set"), Bt = "[object Map]", Zn = "[object Object]", Gt = "[object Promise]", Ht = "[object Set]", Ut = "[object WeakMap]", Kt = "[object DataView]", Yn = D(ht), Jn = D(W), Qn = D(_t), kn = D(F), ti = D(gt), S = L;
(ht && S(new ht(new ArrayBuffer(1))) != Kt || W && S(new W()) != Bt || _t && S(_t.resolve()) != Gt || F && S(new F()) != Ht || gt && S(new gt()) != Ut) && (S = function(t) {
  var e = L(t), r = e == Zn ? t.constructor : void 0, n = r ? D(r) : "";
  if (n)
    switch (n) {
      case Yn:
        return Kt;
      case Jn:
        return Bt;
      case Qn:
        return Gt;
      case kn:
        return Ht;
      case ti:
        return Ut;
    }
  return e;
});
var Wt = O.Uint8Array, ei = "__lodash_hash_undefined__";
function ri(t) {
  return this.__data__.set(t, ei), this;
}
function ni(t) {
  return this.__data__.has(t);
}
function q(t) {
  var e = -1, r = t == null ? 0 : t.length;
  for (this.__data__ = new P(); ++e < r; )
    this.add(t[e]);
}
q.prototype.add = q.prototype.push = ri;
q.prototype.has = ni;
function ii(t, e) {
  for (var r = -1, n = t == null ? 0 : t.length; ++r < n; )
    if (e(t[r], r, t))
      return !0;
  return !1;
}
function pe(t, e) {
  return t.has(e);
}
var ai = 1, oi = 2;
function ge(t, e, r, n, a, i) {
  var o = r & ai, u = t.length, s = e.length;
  if (u != s && !(o && s > u))
    return !1;
  var f = i.get(t), c = i.get(e);
  if (f && c)
    return f == e && c == t;
  var p = -1, l = !0, y = r & oi ? new q() : void 0;
  for (i.set(t, e), i.set(e, t); ++p < u; ) {
    var h = t[p], b = e[p];
    if (n)
      var g = o ? n(b, h, p, e, t, i) : n(h, b, p, t, e, i);
    if (g !== void 0) {
      if (g)
        continue;
      l = !1;
      break;
    }
    if (y) {
      if (!ii(e, function(v, m) {
        if (!pe(y, m) && (h === v || a(h, v, r, n, i)))
          return y.push(m);
      })) {
        l = !1;
        break;
      }
    } else if (!(h === b || a(h, b, r, n, i))) {
      l = !1;
      break;
    }
  }
  return i.delete(t), i.delete(e), l;
}
function si(t) {
  var e = -1, r = Array(t.size);
  return t.forEach(function(n, a) {
    r[++e] = [a, n];
  }), r;
}
function Ot(t) {
  var e = -1, r = Array(t.size);
  return t.forEach(function(n) {
    r[++e] = n;
  }), r;
}
var ui = 1, fi = 2, li = "[object Boolean]", ci = "[object Date]", pi = "[object Error]", gi = "[object Map]", di = "[object Number]", hi = "[object RegExp]", _i = "[object Set]", yi = "[object String]", bi = "[object Symbol]", vi = "[object ArrayBuffer]", mi = "[object DataView]", qt = C ? C.prototype : void 0, pt = qt ? qt.valueOf : void 0;
function Ai(t, e, r, n, a, i, o) {
  switch (r) {
    case mi:
      if (t.byteLength != e.byteLength || t.byteOffset != e.byteOffset)
        return !1;
      t = t.buffer, e = e.buffer;
    case vi:
      return !(t.byteLength != e.byteLength || !i(new Wt(t), new Wt(e)));
    case li:
    case ci:
    case di:
      return ie(+t, +e);
    case pi:
      return t.name == e.name && t.message == e.message;
    case hi:
    case yi:
      return t == e + "";
    case gi:
      var u = si;
    case _i:
      var s = n & ui;
      if (u || (u = Ot), t.size != e.size && !s)
        return !1;
      var f = o.get(t);
      if (f)
        return f == e;
      n |= fi, o.set(t, e);
      var c = ge(u(t), u(e), n, a, i, o);
      return o.delete(t), c;
    case bi:
      if (pt)
        return pt.call(t) == pt.call(e);
  }
  return !1;
}
var Ti = 1, wi = Object.prototype, Oi = wi.hasOwnProperty;
function $i(t, e, r, n, a, i) {
  var o = r & Ti, u = zt(t), s = u.length, f = zt(e), c = f.length;
  if (s != c && !o)
    return !1;
  for (var p = s; p--; ) {
    var l = u[p];
    if (!(o ? l in e : Oi.call(e, l)))
      return !1;
  }
  var y = i.get(t), h = i.get(e);
  if (y && h)
    return y == e && h == t;
  var b = !0;
  i.set(t, e), i.set(e, t);
  for (var g = o; ++p < s; ) {
    l = u[p];
    var v = t[l], m = e[l];
    if (n)
      var x = o ? n(m, v, l, e, t, i) : n(v, m, l, t, e, i);
    if (!(x === void 0 ? v === m || a(v, m, r, n, i) : x)) {
      b = !1;
      break;
    }
    g || (g = l == "constructor");
  }
  if (b && !g) {
    var j = t.constructor, z = e.constructor;
    j != z && "constructor" in t && "constructor" in e && !(typeof j == "function" && j instanceof j && typeof z == "function" && z instanceof z) && (b = !1);
  }
  return i.delete(t), i.delete(e), b;
}
var Pi = 1, Vt = "[object Arguments]", Xt = "[object Array]", Y = "[object Object]", Si = Object.prototype, Zt = Si.hasOwnProperty;
function Ci(t, e, r, n, a, i) {
  var o = A(t), u = A(e), s = o ? Xt : S(t), f = u ? Xt : S(e);
  s = s == Vt ? Y : s, f = f == Vt ? Y : f;
  var c = s == Y, p = f == Y, l = s == f;
  if (l && dt(t)) {
    if (!dt(e))
      return !1;
    o = !0, c = !1;
  }
  if (l && !c)
    return i || (i = new w()), o || le(t) ? ge(t, e, r, n, a, i) : Ai(t, e, s, r, n, a, i);
  if (!(r & Pi)) {
    var y = c && Zt.call(t, "__wrapped__"), h = p && Zt.call(e, "__wrapped__");
    if (y || h) {
      var b = y ? t.value() : t, g = h ? e.value() : e;
      return i || (i = new w()), a(b, g, r, n, i);
    }
  }
  return l ? (i || (i = new w()), $i(t, e, r, n, a, i)) : !1;
}
function $t(t, e, r, n, a) {
  return t === e ? !0 : t == null || e == null || !M(t) && !M(e) ? t !== t && e !== e : Ci(t, e, r, n, $t, a);
}
var xi = 1, Ei = 2;
function Ri(t, e, r, n) {
  var a = r.length, i = a;
  if (t == null)
    return !i;
  for (t = Object(t); a--; ) {
    var o = r[a];
    if (o[2] ? o[1] !== t[o[0]] : !(o[0] in t))
      return !1;
  }
  for (; ++a < i; ) {
    o = r[a];
    var u = o[0], s = t[u], f = o[1];
    if (o[2]) {
      if (s === void 0 && !(u in t))
        return !1;
    } else {
      var c = new w(), p;
      if (!(p === void 0 ? $t(f, s, xi | Ei, n, c) : p))
        return !1;
    }
  }
  return !0;
}
function de(t) {
  return t === t && !yt(t);
}
function Di(t) {
  for (var e = mt(t), r = e.length; r--; ) {
    var n = e[r], a = t[n];
    e[r] = [n, a, de(a)];
  }
  return e;
}
function he(t, e) {
  return function(r) {
    return r == null ? !1 : r[t] === e && (e !== void 0 || t in Object(r));
  };
}
function ji(t) {
  var e = Di(t);
  return e.length == 1 && e[0][2] ? he(e[0][0], e[0][1]) : function(r) {
    return r === t || Ri(r, t, e);
  };
}
function Fi(t, e) {
  return t != null && e in Object(t);
}
function Ii(t, e, r) {
  e = ce(e, t);
  for (var n = -1, a = e.length, i = !1; ++n < a; ) {
    var o = st(e[n]);
    if (!(i = t != null && r(t, o)))
      break;
    t = t[o];
  }
  return i || ++n != a ? i : (a = t == null ? 0 : t.length, !!a && bt(a) && ne(o, a) && (A(t) || oe(t)));
}
function Mi(t, e) {
  return t != null && Ii(t, e, Fi);
}
var Li = 1, Ni = 2;
function zi(t, e) {
  return At(t) && de(e) ? he(st(t), e) : function(r) {
    var n = In(r, t);
    return n === void 0 && n === e ? Mi(r, t) : $t(e, n, Li | Ni);
  };
}
function Bi(t) {
  return function(e) {
    return e?.[t];
  };
}
function Gi(t) {
  return function(e) {
    return wt(e, t);
  };
}
function Hi(t) {
  return At(t) ? Bi(st(t)) : Gi(t);
}
function _e(t) {
  return typeof t == "function" ? t : t == null ? ee : typeof t == "object" ? A(t) ? zi(t[0], t[1]) : ji(t) : Hi(t);
}
function Ui(t) {
  return function(e, r, n) {
    for (var a = -1, i = Object(e), o = n(e), u = o.length; u--; ) {
      var s = o[++a];
      if (r(i[s], s, i) === !1)
        break;
    }
    return e;
  };
}
var Ki = Ui();
function Wi(t, e) {
  return t && Ki(t, e, mt);
}
function qi(t, e) {
  return function(r, n) {
    if (r == null)
      return r;
    if (!vt(r))
      return t(r, n);
    for (var a = r.length, i = -1, o = Object(r); ++i < a && n(o[i], i, o) !== !1; )
      ;
    return r;
  };
}
var Vi = qi(Wi);
function Xi(t, e) {
  var r = -1, n = vt(t) ? Array(t.length) : [];
  return Vi(t, function(a, i, o) {
    n[++r] = e(a, i, o);
  }), n;
}
function Zi(t, e) {
  var r = t.length;
  for (t.sort(e); r--; )
    t[r] = t[r].value;
  return t;
}
function Yi(t, e) {
  if (t !== e) {
    var r = t !== void 0, n = t === null, a = t === t, i = U(t), o = e !== void 0, u = e === null, s = e === e, f = U(e);
    if (!u && !f && !i && t > e || i && o && s && !u && !f || n && o && s || !r && s || !a)
      return 1;
    if (!n && !i && !f && t < e || f && r && a && !n && !i || u && r && a || !o && a || !s)
      return -1;
  }
  return 0;
}
function Ji(t, e, r) {
  for (var n = -1, a = t.criteria, i = e.criteria, o = a.length, u = r.length; ++n < o; ) {
    var s = Yi(a[n], i[n]);
    if (s) {
      if (n >= u)
        return s;
      var f = r[n];
      return s * (f == "desc" ? -1 : 1);
    }
  }
  return t.index - e.index;
}
function Qi(t, e, r) {
  e.length ? e = J(e, function(i) {
    return A(i) ? function(o) {
      return wt(o, i.length === 1 ? i[0] : i);
    } : i;
  }) : e = [ee];
  var n = -1;
  e = J(e, ue(_e));
  var a = Xi(t, function(i, o, u) {
    var s = J(e, function(f) {
      return f(i);
    });
    return { criteria: s, index: ++n, value: i };
  });
  return Zi(a, function(i, o) {
    return Ji(i, o, r);
  });
}
function ki(t, e, r, n) {
  return t == null ? [] : (A(e) || (e = e == null ? [] : [e]), r = r, A(r) || (r = r == null ? [] : [r]), Qi(t, e, r));
}
var ta = 1 / 0, ea = F && 1 / Ot(new F([, -0]))[1] == ta ? function(t) {
  return new F(t);
} : nr, ra = 200;
function na(t, e, r) {
  var n = -1, a = ur, i = t.length, o = !0, u = [], s = u;
  if (i >= ra) {
    var f = e ? null : ea(t);
    if (f)
      return Ot(f);
    o = !1, a = pe, s = new q();
  } else
    s = e ? [] : u;
  t:
    for (; ++n < i; ) {
      var c = t[n], p = e ? e(c) : c;
      if (c = c !== 0 ? c : 0, o && p === p) {
        for (var l = s.length; l--; )
          if (s[l] === p)
            continue t;
        e && s.push(p), u.push(c);
      } else a(s, p, r) || (s !== u && s.push(p), u.push(c));
    }
  return u;
}
function Yt(t, e) {
  return t && t.length ? na(t, _e(e)) : [];
}
function ia(t) {
  const { attrs: e, columns: r, registerRowsHandler: n } = t;
  let a = Jt(e.sort);
  const i = T(() => r.value?.some((s) => s.sorter)), o = T(
    () => r.value.filter((s) => s.sorter).length > 1
  );
  return n((s) => {
    if (!a.value)
      return s;
    const f = Array.isArray(a.value) ? a.value : [a.value], c = f.map((l) => l.sortBy), p = f.map(
      (l) => l.descending ? "desc" : "asc"
    );
    return ki(s, c, p);
  }), {
    onSortChange: (s) => {
      i.value && (a.value = s);
    },
    multipleSort: o,
    sort: a
  };
}
function aa(t) {
  return new Function("return " + t)();
}
function oa(t) {
  const { tableData: e, registerColumnsHandler: r, registerRowsHandler: n, columns: a } = t;
  r(
    (c) => c.map(
      (p) => sa(
        p,
        e,
        t.tdesignGlobalConfig
      )
    )
  );
  const i = Jt(), o = new Map(a.value.map((c) => [c.colKey, c]));
  n((c) => {
    if (!i.value)
      return c;
    const p = Object.keys(i.value).map((l) => {
      const y = i.value[l], h = o.get(l).filter, b = h.type, g = h.predicate ? aa(h.predicate) : void 0, v = b ?? h._type;
      return {
        key: l,
        value: y,
        type: v,
        predicate: g
      };
    });
    return c.filter((l) => p.every((y) => {
      const h = y.type, b = y.predicate;
      if (h === "multiple") {
        const g = y.value;
        return g.length === 0 ? !0 : b ? b(i, l) : g.includes(l[y.key]);
      }
      if (h === "single") {
        const g = y.value;
        return g ? b ? b(g, l) : l[y.key] === g : !0;
      }
      if (h === "input") {
        const g = y.value;
        return g ? b ? b(g, l) : l[y.key].toString().includes(g) : !0;
      }
      if (h === "date") {
        const g = y.value;
        if (!g || g === "") return !0;
        const [v, m] = g, x = new Date(l[y.key]);
        return b ? b(g, l) : new Date(v) <= x && x <= new Date(m);
      }
      throw new Error(`not support filter type ${h}`);
    }));
  });
  const u = (c, p) => {
    if (!p.col) {
      i.value = void 0;
      return;
    }
    i.value = {
      ...c
    };
  };
  function s() {
    i.value = void 0;
  }
  function f() {
    return i.value ? Object.keys(i.value).map((c) => {
      const p = o.get(c).label, l = i.value[c];
      return l.length === 0 ? "" : `${p}: ${JSON.stringify(l)}`;
    }).join("; ") : null;
  }
  return {
    onFilterChange: u,
    filterValue: i,
    resetFilters: s,
    filterResultText: f
  };
}
function sa(t, e, r) {
  if (!("filter" in t))
    return t;
  if (!("type" in t.filter)) throw new Error("filter type is required");
  const { colKey: a } = t, i = t.filter.type;
  if (i === "multiple") {
    const o = Yt(e.value, a).map((s) => ({
      label: s[a],
      value: s[a]
    })), u = {
      resetValue: [],
      list: [
        { label: r.selectAllText, checkAll: !0 },
        ...o
      ],
      ...t.filter
    };
    return {
      ...t,
      filter: u
    };
  }
  if (i === "single") {
    const u = {
      resetValue: null,
      list: Yt(e.value, a).map((s) => ({
        label: s[a],
        value: s[a]
      })),
      showConfirmAndReset: !0,
      ...t.filter
    };
    return {
      ...t,
      filter: u
    };
  }
  if (i === "input") {
    const o = {
      resetValue: "",
      confirmEvents: ["onEnter"],
      showConfirmAndReset: !0,
      ...t.filter,
      props: {
        ...t.filter?.props
      }
    };
    return {
      ...t,
      filter: o
    };
  }
  if (i === "date") {
    const o = {
      resetValue: "",
      showConfirmAndReset: !0,
      props: {
        firstDayOfWeek: 7,
        ...t.filter?.props
      },
      style: {
        fontSize: "14px"
      },
      classNames: "custom-class-name",
      attrs: {
        "data-type": "date-range-picker"
      },
      ...t.filter,
      component: me,
      _type: "date"
    };
    return delete o.type, {
      ...t,
      filter: o
    };
  }
  throw new Error(`not support filter type ${i}`);
}
const ua = {
  hover: !0,
  bordered: !0,
  tableLayout: "auto",
  showSortColumnBgColor: !0
};
function fa(t) {
  const { attrs: e } = t;
  return T(() => ({
    ...ua,
    ...e
  }));
}
function la(t, e) {
  return T(() => {
    const r = Object.keys(t).filter(
      (n) => n.startsWith("header-cell-")
    );
    return e.value.filter((n) => !r.includes(n.title)).map((n) => ({
      slotName: `header-cell-${n.name}`,
      content: n.label ?? n.colKey
    }));
  });
}
const ca = /* @__PURE__ */ V({
  inheritAttrs: !1,
  __name: "Table",
  setup(t) {
    const e = Q(), { t: r, globalConfig: n } = Ae("table"), { tableData: a, orgData: i, registerRowsHandler: o } = Pe(e), [u, s] = Se({
      tableData: a,
      attrs: e
    }), f = Ee({ tableData: a, attrs: e }), { sort: c, onSortChange: p, multipleSort: l } = ia({
      registerRowsHandler: o,
      attrs: e,
      columns: u
    }), { onFilterChange: y, filterValue: h, resetFilters: b, filterResultText: g } = oa({
      tableData: i,
      registerRowsHandler: o,
      registerColumnsHandler: s,
      columns: u,
      tdesignGlobalConfig: n.value
    }), v = fa({ attrs: e }), m = k(), x = la(m, u);
    return (j, z) => (Z(), X(I.Table, tt(d(v), {
      pagination: d(f),
      sort: d(c),
      data: d(a),
      columns: d(u),
      "filter-value": d(h),
      onSortChange: d(p),
      onFilterChange: d(y),
      "multiple-sort": d(l)
    }), et({
      "filter-row": E(() => [
        St("div", null, [
          St("span", null, ft(d(r)(d(n).searchResultText, {
            result: d(g)(),
            count: d(a).length
          })), 1),
          be(I.Button, {
            theme: "primary",
            variant: "text",
            onClick: d(b)
          }, {
            default: E(() => [
              Ct(ft(d(n).clearFilterResultButtonText), 1)
            ]),
            _: 1
          }, 8, ["onClick"])
        ])
      ]),
      _: 2
    }, [
      H(d(x), (ut) => ({
        name: ut.slotName,
        fn: E(() => [
          Ct(ft(ut.content), 1)
        ])
      })),
      H(d(m), (ut, Pt) => ({
        name: Pt,
        fn: E((ye) => [
          rt(j.$slots, Pt, nt(it(ye)))
        ])
      }))
    ]), 1040, ["pagination", "sort", "data", "columns", "filter-value", "onSortChange", "onFilterChange", "multiple-sort"]));
  }
});
function pa(t) {
  const { affixProps: e = {} } = t;
  return {
    container: ".insta-main",
    ...e
  };
}
function ga(t) {
  const { container: e = ".insta-main" } = t;
  return e;
}
const da = /* @__PURE__ */ V({
  inheritAttrs: !1,
  __name: "Anchor",
  setup(t) {
    const e = Q(), r = k(), n = pa(e), a = ga(e);
    return (i, o) => (Z(), X(I.Anchor, tt(d(e), {
      container: d(a),
      "affix-props": d(n)
    }), et({ _: 2 }, [
      H(d(r), (u, s) => ({
        name: s,
        fn: E((f) => [
          rt(i.$slots, s, nt(it(f)))
        ])
      }))
    ]), 1040, ["container", "affix-props"]));
  }
}), ha = /* @__PURE__ */ V({
  __name: "Icon",
  props: {
    name: {},
    size: {},
    color: {},
    prefix: {}
  },
  setup(t) {
    const e = t, r = T(() => {
      const [n, a] = e.name.split(":");
      return a ? e.name : `${e.prefix || "tdesign"}:${e.name}`;
    });
    return (n, a) => (Z(), X(ve("icon"), {
      class: "t-icon",
      icon: r.value,
      size: n.size,
      color: n.color
    }, null, 8, ["icon", "size", "color"]));
  }
}), _a = /* @__PURE__ */ V({
  inheritAttrs: !1,
  __name: "Select",
  props: {
    options: {}
  },
  setup(t) {
    const e = t, r = Q(), n = k(), a = T(() => {
      const i = e.options;
      if (i) {
        if (Array.isArray(i))
          return i.length === 0 ? void 0 : i.map(
            (o) => typeof o == "string" || typeof o == "number" ? { label: o, value: o } : o
          );
        throw new Error("options must be an array");
      }
    });
    return (i, o) => (Z(), X(I.Select, tt(d(r), { options: a.value }), et({ _: 2 }, [
      H(d(n), (u, s) => ({
        name: s,
        fn: E((f) => [
          rt(i.$slots, s, nt(it(f)))
        ])
      }))
    ]), 1040, ["options"]));
  }
});
function va(t) {
  t.use(I), t.component("t-table", ca), t.component("t-affix", $e), t.component("t-anchor", da), t.component("t-icon", ha), t.component("t-select", _a), window.$tdesign = {
    NotifyPlugin: we,
    MessagePlugin: Te
  };
}
export {
  va as install
};
