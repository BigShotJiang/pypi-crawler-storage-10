from typing import Any, Dict, List, Optional, Union
import aiohttp
from pydantic import BaseModel, ValidationError, Field
from typing_extensions import Literal

# 导入异常类
from ...exceptions import ShoplineAPIError


class ItemsItem(BaseModel):
    """Item model for items"""
    id: Optional[str] = None
    quantity: Optional[float] = None
    variation_id: Optional[str] = None

class Body(BaseModel):
    """请求体模型"""
    items: Optional[List[ItemsItem]] = None

class Response(BaseModel):
    """响应体模型"""
    code: Optional[str] = None
    message: Optional[str] = None
    data: Optional[Dict[str, Any]] = None
    trace_id: Optional[str] = None

async def call(
    session: aiohttp.ClientSession, id: str, body: Body
) -> Response:
    """
    Bulk Patch Cart Items
    
    Bulk patch cart items.
     更新購物車商品數量
    
    Path: PATCH /carts/{id}/items
    """
    # 构建请求 URL
    url = f"carts/{id}/items"

    # 构建请求头
    headers = {"Content-Type": "application/json"}

    # 构建请求体
    json_data = body.model_dump(exclude_none=True) if body else None

    # 发起 HTTP 请求
    async with session.patch(
        url, json=json_data, headers=headers
    ) as response:
        if response.status >= 400:
            error_data = await response.json()
            # 默认错误处理
            raise ShoplineAPIError(
                status_code=response.status,
                **error_data
            )
        response_data = await response.json()

        # 验证并返回响应数据
        return Response(**response_data)