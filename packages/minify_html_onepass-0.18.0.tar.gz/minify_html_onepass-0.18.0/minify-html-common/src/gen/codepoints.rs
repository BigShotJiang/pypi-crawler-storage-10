include!(concat!(env!("OUT_DIR"), "/codepoints.rs"));
