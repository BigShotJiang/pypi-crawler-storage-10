"""Django Timestamp Manager – lightweight timestamp and soft delete mixins."""

__version__ = "0.1.0"
