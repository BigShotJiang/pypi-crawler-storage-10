from __future__ import annotations
from django.db import models
from django.utils import timezone
from typing import Optional
from .managers import SoftDeleteManager, SoftDeleteQuerySet


class TimeStampedModel(models.Model):
    """
    Abstract base model that adds created_at and updated_at fields.
    """

    created_at: timezone.datetime = models.DateTimeField(
        auto_now_add=True,
        help_text="Time when the record was created.",
    )
    updated_at: timezone.datetime = models.DateTimeField(
        auto_now=True,
        help_text="Time when the record was last updated.",
    )

    class Meta:
        abstract = True


class SoftDeleteModel(TimeStampedModel):
    """
    Abstract base model that supports soft deletion and timestamps.
    """

    deleted_at: Optional[timezone.datetime] = models.DateTimeField(
        null=True, blank=True, help_text="Time when the record was soft deleted."
    )

    objects = SoftDeleteManager()
    all_objects = SoftDeleteManager.from_queryset(SoftDeleteQuerySet)()

    def delete(self, using=None, keep_parents=False) -> None:
        """Soft delete this instance."""
        self.deleted_at = timezone.now()
        self.save(update_fields=["deleted_at"])

    def restore(self) -> None:
        """Restore a soft-deleted instance."""
        self.deleted_at = None
        self.save(update_fields=["deleted_at"])

    class Meta:
        abstract = True
