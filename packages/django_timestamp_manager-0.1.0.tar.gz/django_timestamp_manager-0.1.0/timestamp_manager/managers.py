from __future__ import annotations
from django.db import models
from django.utils import timezone


class SoftDeleteQuerySet(models.QuerySet):
    """Custom QuerySet for soft-deletable models."""

    def delete(self) -> int:
        """Soft delete objects by setting deleted_at."""
        return super().update(deleted_at=timezone.now())

    def hard_delete(self) -> int:
        """Permanently delete objects from the database."""
        return super().delete()

    def alive(self):
        """Return only non-deleted objects."""
        return self.filter(deleted_at__isnull=True)

    def dead(self):
        """Return only deleted objects."""
        return self.exclude(deleted_at__isnull=True)


class SoftDeleteManager(models.Manager):
    """Manager that filters out deleted records by default."""

    def get_queryset(self) -> SoftDeleteQuerySet:
        return SoftDeleteQuerySet(self.model, using=self._db).alive()
