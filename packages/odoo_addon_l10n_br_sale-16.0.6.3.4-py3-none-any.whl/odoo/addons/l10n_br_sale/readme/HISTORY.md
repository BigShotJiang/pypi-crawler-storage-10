## 14.0.1.0.0 (2022-06-03)

- \[MIG\] Migração para a versão 14.

## 13.0.1.0.0 (2022-01-13)

- \[MIG\] Migração para a versão 13.
