from rsb.models.base_model import BaseModel


class Root(BaseModel):
    uri: str
    name: str
