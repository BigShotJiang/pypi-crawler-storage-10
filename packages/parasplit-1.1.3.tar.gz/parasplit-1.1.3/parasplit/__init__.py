# SPDX-FileCopyrightText: 2025 2024 Samir Bertache
#
# SPDX-License-Identifier: AGPL-3.0-or-later

"""
This script is a the Parasplit project, designed to process paired-end FASTQ files by fragmenting DNA sequences at specified restriction enzyme sites.

Copyright © 2024 Samir Bertache

SPDX-License-Identifier: AGPL-3.0-or-later

===============================================================================

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU Affero General Public License as published by the
Free Software Foundation, either version 3 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.
"""

from .Frag import process_items
from .Pretreatment import partition_threads, search_in_database
from .Read import read_fastq_gzip_simultaneously
from .WriteAndControl import manage_pigz_problems, open_output, write_pairs

__version__ = "1.1.3"
