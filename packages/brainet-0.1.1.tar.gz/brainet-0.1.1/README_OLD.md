# 🧠 Brainet# 🧠 Brainet - Your Cognitive Context Guardian# 🧠 Brainet — Your Cognitive Context Guardian# 🧠 Brainet



> **Because your brain deserves a resume button** ⏸️



Brainet captures your coding context automatically - never lose your train of thought when switching tasks.**AI-powered development context manager that remembers what you were working on.**



## ⚡ Quick Start



```bashBrainet captures your coding sessions, analyzes them with local AI (Ollama), and helps you resume work instantly.> **"Your brain for development. A memory layer that thinks where you left off."****Brainet** — Your AI-powered Cognitive Context Guardian for Developers.

# Install

pip install -e .



# Setup Groq API (FREE & FAST)---

export GROQ_API_KEY="your_key_here"  # Get from https://console.groq.com/keys



# Start tracking

brainet start## ✨ FeaturesBrainet is a local-first AI agent that captures and reconstructs your development context, so you never lose your train of thought when switching tasks, taking breaks, or coming back after days away.Never lose your train of thought again. Brainet automatically captures, summarizes, and restores your development context so you can maintain flow state across interruptions and context switches.



# Capture context with AI summary

brainet capture

- **🤖 Real AI Integration** - Uses Ollama (local LLM) for intelligent summaries

# Resume later

brainet what-was-i-doing- **📸 Context Capture** - Tracks files, TODOs, commands, and git changes

```

- **🔍 Smart Recall** - `brainet what-was-i-doing` explains your last session## 🎯 The Problem Brainet Solves## 🎯 Features

## 🚀 Features

- **🧭 Why Analysis** - `brainet why` explains your coding decisions  

- **⚡ Blazing Fast** - 3.8s captures with Groq API (Llama 3.3 70B)

- **🤖 Real AI** - Natural language summaries using "You" not "The developer"- **⏸️ Pause & Resume** - Save session state and restore later

- **📸 Smart Capture** - Git diffs, TODOs, commands, file changes

- **🧠 Context Awareness** - AI explains WHY you made changes- **🔒 100% Local** - All data stays on your machine (no cloud required)

- **💾 Persistent Storage** - SQLite + JSON capsules

- **🎯 Production Ready** - Clean architecture, fully tested- **💰 Zero Cost** - Free local AI with OllamaWhen you switch between tasks — debugging, researching, writing, testing — **mental context gets nuked**. You lose your train of thought, forget why you wrote something, and waste time retracing your steps.- 📝 **Ambient Context Tracking**: Automatically monitors your development activities



## 📚 Commands



```bash---- 💾 **Context Capsules**: Saves snapshots of your cognitive state

brainet start                  # Start tracking your session

brainet capture                # Capture context with AI summary

brainet pause                  # Pause tracking

brainet what-was-i-doing       # AI explains your work## 🚀 Quick StartYou know that moment when you come back after lunch and go:- 🔄 **Instant Resume**: Quickly restore your mental context after breaks

brainet why [question]         # AI explains your reasoning

brainet status                 # Show session stats

```

### 1. Install Ollama (Free Local AI)- 🤖 **AI-Powered**: Uses Ollama for local AI analysis and insights

## 💡 Examples



### Capture Context

```bash```bash> "Wait… what was I doing again?"- 🔍 **Natural Language Queries**: Ask questions about your development context

$ brainet capture

[Brainet] ✓ AI summaries enabled (Groq/Llama 3.3 70B - FAST & FREE)# macOS



╭────────────────────────────── 📸 Context Captured ──────────────────────────────╮brew install ollama- 🎮 **VS Code Integration**: Visual context tracking and restoration

│ You modified the session summarizer in `session_summarizer.py`, adding imports  │

│ for typing, pathlib, and regular expressions. You also updated several capsules │

│ in the `.brainet/capsules` directory.                                           │

╰──────────────────────────────────────────────────────────────────────────────────╯# LinuxYeah, **that's** the productivity killer Brainet eliminates.- 🌐 **REST API**: HTTP API for integrations and extensions



📝 50 files modified, 4 TODOs foundcurl https://ollama.ai/install.sh | sh

```



### Get Context Back

```bash# Windows - Download from https://ollama.ai

$ brainet what-was-i-doing

```---## ⚙️ Installation

You were integrating Groq API for faster AI summaries. You replaced the Ollama

client with a new GroqClient that uses Llama 3.3 70B. The main changes were in

session_summarizer.py and config.py.

```### 2. Download AI Model



### Ask Why

```bash

$ brainet why "why did I switch to Groq?"```bash## ⚡ What Brainet Does1. Create a virtual environment:



You switched to Groq because it's FREE and blazing fast (500+ tokens/second),# Small & fast (recommended)

compared to running Ollama locally. This reduced capture time from 3+ minutes

to under 4 seconds.ollama pull llama3.2:1b```bash

```



## ⚙️ Configuration

# Or larger, better qualityBrainet is a **cognitive continuity agent** that:python3 -m venv venv

Edit `brainet/core/config.py`:

ollama pull mistral

```python

# AI Provider```source venv/bin/activate  # On Windows: venv\Scripts\activate

AI_PROVIDER = "groq"  # or "ollama"



# Groq Settings

GROQ_CONFIG = {### 3. Install Brainet- 📸 **Captures your development context** — files, TODOs, commits, commands```

    "api_key": "your_key",

    "model": "llama-3.3-70b-versatile",

    "temperature": 0.3

}```bash- 🧠 **Generates AI-powered summaries** — understands what you were working on



# Performancecd /path/to/brainet

MAX_FILES_TO_ANALYZE = 50

MAX_DIFF_SIZE = 10000python3 -m venv venv- 🔄 **Restores your mental workspace** — picks up exactly where you left off2. Install in development mode:

```

source venv/bin/activate

## 🛠️ Development

pip install -e .- 💡 **Provides workflow insights** — helps you understand your coding patterns```bash

```bash

# Install dependencies```

pip install -r requirements.txt

- 🔒 **Works locally first** — your data stays private on your machinepip install -e .

# Run tests

pytest tests/### 4. Start Tracking



# Install in dev mode```

pip install -e .

``````bash



## 📁 Project Structurebrainet start             # Initialize tracking---



See [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) for detailed architecture.brainet capture           # Capture current context



```brainet what-was-i-doing  # See AI summary## 🚀 Quick Start

brainet/

├── ai/                 # Groq + Ollama clients, AI summarizer```

├── core/               # Context capture, extractors, analysis

├── storage/            # Capsule manager, SQLite storage## 🚀 Quick Start

├── monitor/            # File watching, terminal tracking

└── cli.py              # Command-line interface---

```

1. Verify installation:

## 🐛 Troubleshooting

## 📖 Usage Examples

### Command not found

```bash### Installation```bash

# Activate virtual environment

source venv/bin/activate### Capture Your Session



# Reinstallbrainet hello

pip install -e .

``````bash



### Slow captures$ brainet capture```bash```

- Check `MAX_FILES_TO_ANALYZE` in config.py

- Default is 50 files (3-4s capture time)

- Increase for more context, decrease for speed

╭─ 📸 Context Captured ─╮# Clone the repository

### AI not working

```bash│ You were working on   │

# Check Groq API key

echo $GROQ_API_KEY│ auth.py — added       │git clone https://github.com/yourusername/brainet.git2. Start tracking your context:



# Test API directly│ validate_token() and  │

curl https://api.groq.com/openai/v1/models \

  -H "Authorization: Bearer $GROQ_API_KEY"│ check_password().     │cd brainet```bash

```

│ Tests passing.        │

## 📊 Performance

╰───────────────────────╯brainet start

- **Capture Time**: 3.8 seconds (50 files)

- **AI Response**: <1 second (Groq)```

- **Storage**: ~10KB per capsule

- **Models**: Llama 3.3 70B (Groq) or Llama 3.2 1B (Ollama)# Create virtual environment and install```



## 🎯 Roadmap### What Was I Doing?



- [ ] `brainet resume` - Restore session contextpython3 -m venv venv

- [ ] Auto-capture on file save

- [ ] Search capsules by keyword/date```bash

- [ ] Web dashboard for visualization

- [ ] Team collaboration features$ brainet what-was-i-doingsource venv/bin/activate3. When taking a break:



## 📝 License



MIT╭─ 🧠 AI Analysis ─╮pip install -e .```bash



## 🙏 Credits│ You were refactoring│



Built with:│ the authentication  │```brainet pause

- [Groq](https://groq.com) - Lightning-fast AI inference

- [Click](https://click.palletsprojects.com/) - CLI framework│ system, adding JWT  │

- [Rich](https://rich.readthedocs.io/) - Terminal formatting

- [GitPython](https://gitpython.readthedocs.io/) - Git integration│ token validation.   │```


╰─────────────────────╯

```### Basic Workflow



### Why Did I Make These Changes?4. Resume where you left off:



```bash```bash```bash

$ brainet why "why did I change auth.py?"

# 1️⃣ Start tracking your sessionbrainet resume

╭─ 🧠 AI Reasoning ─╮

│ You refactored      │brainet start```

│ auth.py to add JWT  │

│ token validation    │

│ for better security │

╰─────────────────────╯# 2️⃣ Do some coding... edit files, run commands, etc.5. Check current status:

```

```bash

---

# 3️⃣ Capture your current contextbrainet status

## 🛠️ Commands

brainet capture```

| Command | Description |

|---------|-------------|

| `brainet start` | Start context tracking |

| `brainet capture` | Capture current session with AI summary |# 4️⃣ Take a break — pause tracking## 📚 Command Reference

| `brainet pause` | Save session and stop tracking |

| `brainet what-was-i-doing` | AI explanation of last session |brainet pause

| `brainet why [question]` | AI reasoning behind your changes |

| `brainet resume` | Restore last session context |### Core Commands



---# Later... resume from where you left off- `brainet start`: Begin context tracking



## 🔧 Troubleshootingbrainet resume- `brainet pause`: Pause tracking and save state



### Ollama Not Found```- `brainet resume`: Restore previous context



```bash- `brainet status`: Show current tracking status

# Check if running

curl http://localhost:11434/api/tags---



# Start Ollama### Analysis & Insights

ollama serve

```## 📖 Core Commands- `brainet insights`: Show development insights



### No Model Installed- `brainet activity <file>`: Show detailed file activity



```bash### `brainet start`- `brainet ask [query]`: Ask questions about your context

ollama list              # List models

ollama pull llama3.2:1b  # Download modelInitialize context tracking for your current project.

```

### History & Management

### AI Fallback Mode

```bash- `brainet capture`: Manually capture current context

```

[Brainet] ⚠ Ollama unavailable$ brainet start- `brainet list-capsules`: List all saved context capsules

[Brainet] → Using rule-based fallback

```✓ Context tracking initialized for myproject- `brainet history`: Show recent context history



This is normal! Brainet works offline with intelligent fallback.```



---### Server & Integration



## 📜 License### `brainet capture`- `brainet server`: Start the Brainet API server for VS Code integration



MITCapture current development context with AI-powered summary.



---## 🛠️ Development



## 💡 Tagline```bash



> **Brainet — Because your brain deserves a resume button.**$ brainet capture1. Clone the repository:


📸 Capturing development context...```bash

╭─────────────────── 📸 Context Captured ────────────────────╮git clone https://github.com/yourusername/brainet.git

│ ✓ Git state extracted                                      │cd brainet

│ ✓ TODOs found: 6                                           │```

│ ✓ Modified files: 3                                        │

│ ✓ Insights generated: 2                                    │2. Create a virtual environment:

│ ✓ Commands tracked: 10                                     │```bash

│                                                            │python3 -m venv venv

│ Summary: Modified 3 file(s) primarily .py files. Latest    │source venv/bin/activate  # On Windows: venv\Scripts\activate

│ commit: 'Add authentication middleware'. 6 TODO(s) across  │```

│ 2 file(s). Working on: Python development, testing.        │

│                                                            │3. Install dependencies:

│ ✓ Capsule saved: 2025-10-26 18:30:00                       │```bash

╰────────────────────────────────────────────────────────────╯pip install -r requirements.txt

``````



**What gets captured:**4. Install in development mode:

- Modified files and their status```bash

- Recent git commitspip install -e .

- TODO/FIXME/NOTE comments in your code```

- Recent terminal commands (from shell history)

- Active file you were editing## 📄 License

- AI-generated workflow insights

This project is licensed under the MIT License - see the LICENSE file for details.

### `brainet resume`

Resume from your last saved context with full flow restoration.## 🤝 Contributing



```bashContributions are welcome! Please feel free to submit a Pull Request.
$ brainet resume
🔄 Restoring your development flow...

╭─────────────── 📋 Session Summary ───────────────╮
│ Project: myproject                               │
│ Branch: feature/auth-refactor                    │
│ Last Active File: auth.py                        │
│ Modified Files: 3                                │
│ Pending TODOs: 6                                 │
│                                                  │
│ Summary: You were refactoring authentication     │
│ flow, added token caching logic, and prepared    │
│ unit tests for JWT middleware.                   │
╰──────────────────────────────────────────────────╯

📜 Recent Commands You Ran:
┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━┓
┃ Command                 ┃ Shell ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━┩
│ pytest tests/test_auth.py│ zsh   │
│ git commit -m "WIP auth" │ zsh   │
│ python auth.py           │ zsh   │
└─────────────────────────┴───────┘

💡 Tip: You can re-run these commands to continue

✅ Unfinished Tasks (TODOs):
┏━━━━━━━━┳━━━━━━┳━━━━━━━━━━━━━━━━━━━━━┓
┃ File   ┃ Line ┃ Task                ┃
┡━━━━━━━━╇━━━━━━╇━━━━━━━━━━━━━━━━━━━━━┩
│ auth.py│ 42   │ Add token expiry... │
└────────┴──────┴─────────────────────┘

🚀 Next Steps:
  1. Continue working on TODOs in: auth.py
  2. Re-open your last active file: auth.py
  3. Re-run tests: pytest tests/test_auth.py
```

### Other Commands

- `brainet show-context` — Show the last captured context in detail
- `brainet pause` — Pause tracking and save current state
- `brainet insights` — View AI-generated workflow insights
- `brainet status` — Check current project status
- `brainet history` — List recent context capsules
- `brainet ask` — Ask AI questions about your code (requires Ollama)
- `brainet list-capsules` — List all available context capsules
- `brainet activity <file>` — Check file activity timeline

---

## 🧩 Real-World Use Cases

| Use Case | Description | Impact |
|----------|-------------|--------|
| 💤 **Interrupted Flow** | Resume coding after hours/days and instantly remember what you were doing | 10x context recall |
| 🧭 **Multi-project juggling** | Switch between multiple repos easily with per-repo "brains" | Time saver |
| 📜 **Session journaling** | Automatically document what you coded today | Cleaner retrospectives |
| 🔍 **Code archaeology** | Search past session memories ("When did I refactor X?") | Developer memory bank |
| 🧠 **Onboarding** | New devs can see project capsules from previous devs | Knowledge transfer |

---

## 🛠️ How It Works

### Context Capture Engine
Brainet monitors:
- **Git state**: Modified files, recent commits, current branch
- **Code comments**: TODO, FIXME, NOTE markers across your codebase
- **Terminal history**: Recent commands you've run (filtered for dev-related commands)
- **File activity**: Which files you're actively editing

### AI Session Summarizer
Generates natural language summaries like:
> "Modified 3 file(s) primarily .py files. Latest commit: 'Add authentication middleware'. 6 TODO(s) across 2 file(s). Working on: Python development, testing."

Uses rule-based summarization by default, with optional Ollama integration for AI-powered summaries.

### Flow Restoration
When you run `brainet resume`, it shows:
- ✅ Session summary with project and branch info
- 📜 Recent commands you ran (so you can re-run them)
- ✅ Unfinished TODOs (so you know what's pending)
- 💡 AI insights and suggestions
- 🚀 Next steps (suggested actions to continue)

---

## 🔮 Architecture

```
brainet/
├── core/
│   ├── context_capture.py      # Main orchestrator
│   ├── extractors/
│   │   ├── git_extractor.py    # Git state extraction
│   │   ├── todo_extractor.py   # TODO comment parsing
│   │   ├── file_extractor.py   # File activity monitoring
│   │   └── command_extractor.py# Shell history parsing
│   └── analysis/
│       └── context_analyzer.py # Workflow insights generation
├── ai/
│   ├── ollama_client.py        # AI integration
│   └── session_summarizer.py   # Summary generation
├── storage/
│   ├── models/
│   │   └── capsule.py          # Data models (Pydantic)
│   ├── capsule_manager.py      # File-based storage
│   └── storage_manager.py      # SQLite storage
└── cli.py                      # Command-line interface
```

---

## 🎨 Key Features

### ✅ Implemented (MVP)
- ✓ Context capture (files, TODOs, commits, commands)
- ✓ AI-powered session summaries
- ✓ Insight persistence across sessions
- ✓ Flow restoration with next-step suggestions
- ✓ Terminal command history tracking
- ✓ Local-first storage (SQLite + JSON)
- ✓ Beautiful terminal UI with Rich

### 🚧 Future Enhancements
- Cloud sync across devices
- Visual "flow timeline" UI
- Capsule diffing and timeline replay
- GitHub PR auto-generation from capsules
- Team-shared capsules
- CI/CD integration suggestions
- Advanced AI chat with full project context

---

## 🧪 Development

### Run Tests
```bash
pytest tests/ -v
```

### Project Structure
- `brainet/core/` — Context capture and analysis logic
- `brainet/ai/` — AI integration and summarization
- `brainet/storage/` — Data persistence and models
- `brainet/cli.py` — Command-line interface
- `tests/` — Unit and integration tests

---

## 🏢 Multi-Project Workspace Management

Brainet now includes powerful multi-project features for developers working across multiple codebases:

### Workspace Commands

#### `brainet workspaces`
View all active brainet sessions across all your projects in one place:
```bash
$ brainet workspaces

📚 Active Brainet Sessions (2):

┏━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ Project  ┃ Location                  ┃ Capsules ┃ Last Activity ┃
┡━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ brainet  │ /Users/you/Work/brainet   │        3 │ 5 min ago     │
│ Casino   │ /Users/you/Projects/Casino│        5 │ 2 hours ago   │
└──────────┴───────────────────────────┴──────────┴───────────────┘
```

#### `brainet search <query>`
Search for content in your session capsules:
```bash
# Search current project
$ brainet search "authentication"

# Search across all projects
$ brainet search "VIP" --all-projects

🔍 Search Results for 'vip' (2 found):

● Casino (2025-10-31T13:00:06)
    The code was modified to add a VIP tier system...
  /Users/you/Projects/Casino
```

#### `brainet switch`
View all projects with copy-paste friendly navigation:
```bash
$ brainet switch

🔀 Available Projects:

  1. brainet (5 min ago)
     cd /Users/you/Work/brainet

  2. Casino (2 hours ago)
     cd /Users/you/Projects/Casino

💡 Copy a path above and run: cd <path>
💡 Then run: brainet resume to continue your session
```

Just copy the green `cd` command and paste it in your terminal to switch projects!

#### `brainet cleanup`
Clean up old capsules across all projects:
```bash
```

#### `brainet switch`
Interactively switch between projects:
```bash
# Interactive mode - shows menu and prompts for selection
$ brainet switch

🔀 Switch to Project:

  1. brainet (5 min ago)
     /Users/you/Work/brainet

  2. Casino (2 hours ago)
     /Users/you/Projects/Casino

Select project (number or name): 2
# Outputs: /Users/you/Projects/Casino

# Quick switch by number
$ brainet switch 2

# Quick switch by name (partial match)
$ brainet switch Casino
$ brainet switch cas    # Also works!
```

**� Pro Tip:** Use the `bsw` shell function (from shell integration) to actually change directories:
```bash
# This ACTUALLY switches directories and auto-resumes the session!
$ bsw 2
✓ Switching to: /Users/you/Projects/Casino
💡 Resuming brainet session...

$ bsw Casino     # Switch by name
$ bsw            # Interactive mode with prompt
```

#### `brainet cleanup`
Clean up old capsules across all projects:
```bash
# Preview cleanup (dry run)
$ brainet cleanup --days 30 --dry-run

🔍 Dry Run - Would remove 15 capsules from 3 projects:
  ● old-project: 10 capsules
  ● test-repo: 5 capsules

# Actually clean up
$ brainet cleanup --days 60
```

### Multi-Directory Support

Brainet works from any subdirectory (just like git):
```bash
cd /Users/you/Projects/Casino/backend/models
brainet capture  # ✓ Works! Auto-detects project root
brainet workspaces  # ✓ Shows all projects from anywhere
```

---

## 🤝 Contributing

Brainet is open source and welcomes contributions! Some areas to explore:

- Add support for more programming languages
- Improve AI summarization prompts
- Build integrations (VS Code, Notion, etc.)
- Enhance workflow insights detection
- Add cloud sync capabilities

---

## 📜 License

MIT License — see LICENSE file for details.

---

## 💡 Philosophy

Brainet is built on the principle that **developers shouldn't have to waste mental energy remembering where they left off**. Your brain is for solving problems, not for being a context cache.

By offloading cognitive overhead to Brainet, you can:
- **Context switch fearlessly** — jump between tasks without losing momentum
- **Resume instantly** — pick up exactly where you left off
- **Learn from patterns** — understand your own workflow better
- **Share knowledge** — onboard new team members with captured context

---

## 🧠 Why "Brainet"?

**Brain** (your cognitive workspace) + **Net** (network/capture) = **Brainet**

It's your second brain for development — a cognitive prosthetic that remembers everything so you don't have to.

---

**Built with ❤️ for developers who value flow state**
