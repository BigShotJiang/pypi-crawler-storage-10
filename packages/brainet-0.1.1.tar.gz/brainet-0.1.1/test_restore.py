# Testing checkpoint restore
