"""
Response Formatter - Formatação profissional das respostas da Tiramisu
"""

def format_consultation_response(raw_response: str, sources: list) -> str:
    """
    Formata resposta do modo consultoria
    """
    formatted = f"""
# 💬 CONSULTORIA TIRAMISU

---

## 🎯 RESUMO EXECUTIVO

{raw_response.split('\n\n')[0] if raw_response else "Análise em andamento..."}

---

## 📚 ANÁLISE DETALHADA

{raw_response}

---

## 📖 FONTES CONSULTADAS

{', '.join(sources) if sources else 'Nenhuma fonte específica'}

---

## ✅ PRÓXIMOS PASSOS

[ ] Revisar as recomendações acima
[ ] Priorizar ações de maior impacto
[ ] Implementar gradualmente
[ ] Medir resultados

---

*🍰 Análise gerada pela Tiramisu - Fusão de Strategic Foundation × Execution Expert × Digital Transformation Concepts*
"""
    return formatted


def format_planning_response(raw_response: str, sources: list) -> str:
    """
    Formata resposta do modo planejamento
    """
    formatted = f"""
# 📋 PLANEJAMENTO ESTRATÉGICO - TIRAMISU

---

## 🎯 RESUMO EXECUTIVO

**Objetivo:** Planejamento estratégico baseado na Tríade (Strategic Foundation, Execution Expert, Digital Innovation)

---

{raw_response}

---

## 📖 FRAMEWORKS UTILIZADOS

**Fontes:** {', '.join(sources) if sources else 'Base de conhecimento geral'}

---

## ✅ CHECKLIST DE IMPLEMENTAÇÃO

### Curto Prazo (1-30 dias)
- [ ] Ação prioritária 1
- [ ] Ação prioritária 2
- [ ] Quick win identificado

### Médio Prazo (1-3 meses)
- [ ] Estratégia principal
- [ ] Implementação de processos
- [ ] Ajustes baseados em dados

### Longo Prazo (3-12 meses)
- [ ] Consolidação
- [ ] Escala
- [ ] Otimização contínua

---

*🍰 Planejamento criado pela Tiramisu - Fusão de Strategic Foundation × Execution Expert × Digital Transformation Concepts*
"""
    return formatted


def format_analysis_response(analysis_response) -> str:
    """
    Formata resposta do modo análise (mantém estrutura atual mas melhora apresentação)
    """
    formatted = f"""
# 🍰 ANÁLISE TIRAMISU

---

## 🎯 RESUMO EXECUTIVO

{analysis_response.summary}

---

## 🌳 PROCESSO DAS 3 ÁRVORES

### 🌱 RAÍZES (Diagnóstico)
{analysis_response.three_trees.roots}

### 🪵 TRONCO (Avaliação)
{analysis_response.three_trees.trunk}

### 🌿 GALHOS (Oportunidades)
{analysis_response.three_trees.branches}

---

## 👥 VISÃO DA TRÍADE

### 📚 Strategic Foundation (Estratégia)
{analysis_response.triad_insights.kotler}

### 🔥 Execution Expert (Execução)
{analysis_response.triad_insights.gary_vee}

### 💡 Digital Transformation Concepts (Tecnologia)
{analysis_response.triad_insights.martha}

---

## 🚀 PROPOSTA DE SOLUÇÃO

### ✨ Versão Melhorada
{analysis_response.proposal.improved_version or "Ver plano de ação abaixo"}

### 📋 Plano de Ação
{analysis_response.proposal.action_plan}

### 💎 Recomendações-Chave
{analysis_response.proposal.key_recommendations}

### 📊 Resultados Esperados
{analysis_response.proposal.expected_results}

---

## 📖 FONTES CONSULTADAS

{', '.join(analysis_response.rag_sources) if analysis_response.rag_sources else 'Base de conhecimento geral'}

---

## ✅ PRÓXIMOS PASSOS

- [ ] Revisar análise completa
- [ ] Implementar versão melhorada
- [ ] Seguir plano de ação
- [ ] Monitorar métricas

---

*🍰 Análise gerada pela Tiramisu - Fusão de Strategic Foundation × Execution Expert × Digital Transformation Concepts*
"""
    return formatted
