from setuptools import setup, find_packages

setup(
    name="tiramisu-framework",
    version="1.0.0",
    description="AI-powered marketing analysis framework",
    author="Tiramisu Team",
    author_email="frameworktiramisu@gmail.com",
    url="https://github.com/tiramisu-framework/tiramisu-framework",
    packages=find_packages(exclude=['data*', 'tests*', '*.pdf']),
    install_requires=[
        "fastapi>=0.119.0",
        "uvicorn>=0.27.0",
        "pydantic>=2.6.0",
        "openai>=1.12.0",
        "langchain>=0.1.0",
        "python-dotenv>=1.0.0"
    ],
    python_requires=">=3.8",
)
