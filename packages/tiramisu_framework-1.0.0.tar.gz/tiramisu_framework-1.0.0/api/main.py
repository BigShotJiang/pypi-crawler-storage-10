"""
FastAPI Application - Tiramisu API
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from tiramisu.api.routes import router
from tiramisu.api.routers.conversations import router as conversations_router

# Criar app FastAPI
app = FastAPI(
    title="🍰 Tiramisu API",
    description="API da Consultora de Marketing & Vendas - Fusão de Strategic Foundation × Execution Expert × Digital Transformation Concepts",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS para Next.js
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],  # Next.js ports
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(conversations_router, tags=["Conversations"])
# Incluir rotas
app.include_router(router, prefix="/api", tags=["Tiramisu"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "🍰 Tiramisu API - Consultora de Marketing & Vendas",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/api/health"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

