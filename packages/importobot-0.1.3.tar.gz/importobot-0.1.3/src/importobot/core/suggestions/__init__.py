"""Suggestion engine components."""

from .suggestion_engine import GenericSuggestionEngine

__all__ = ["GenericSuggestionEngine"]
