"""
obsidian-base-logger: A CLI tool that wraps shell processes and logs execution
metadata to Obsidian-compatible Markdown files.
"""

__version__ = "0.1.0"
