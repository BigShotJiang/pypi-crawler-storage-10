"""
Allow execution as a module: python -m obsidian_base_logger
"""

from .cli import main

if __name__ == '__main__':
    main()
