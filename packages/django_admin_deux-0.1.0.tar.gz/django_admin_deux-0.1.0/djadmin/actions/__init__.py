"""Action system for django-admin-deux"""

from .base import (
    BaseAction,
    BulkActionMixin,
    ConfirmationActionMixin,
    DownloadActionMixin,
    FormActionMixin,
    ListActionMixin,
    RecordActionMixin,
    RedirectActionMixin,
    ViewActionMixin,
)
from .list_view import ListViewAction
from .view_mixins import (
    CreateViewActionMixin,
    FormFeaturesMixin,
    FormViewActionMixin,
    ListViewActionMixin,
    RedirectViewActionMixin,
    TemplateViewActionMixin,
    UpdateViewActionMixin,
)

__all__ = [
    # Base classes and action type mixins
    'BaseAction',
    'ListActionMixin',
    'BulkActionMixin',
    'RecordActionMixin',
    'FormActionMixin',
    'ViewActionMixin',
    'ConfirmationActionMixin',
    'RedirectActionMixin',
    'DownloadActionMixin',
    # Built-in actions
    'ListViewAction',
    # View type mixins
    'FormFeaturesMixin',
    'FormViewActionMixin',
    'CreateViewActionMixin',
    'UpdateViewActionMixin',
    'ListViewActionMixin',
    'TemplateViewActionMixin',
    'RedirectViewActionMixin',
]
