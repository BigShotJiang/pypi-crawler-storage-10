"""Plugin hooks for permissions system"""

from djadmin.plugins import hookimpl


@hookimpl
def djadmin_provides_features():
    """Advertise that this plugin provides 'permissions' feature."""
    return ['permissions']


@hookimpl
def djadmin_get_action_view_mixins(action):
    """
    Add UserPassesTestMixin and PermissionMixin to ALL action views.

    Uses isinstance() matching with BaseAction to apply to everything.

    Args:
        action: The action instance

    Returns:
        Dict mapping action types to mixin lists
    """
    from django.contrib.auth.mixins import UserPassesTestMixin

    from djadmin.actions import BaseAction
    from djadmin.plugins.permissions.mixins import PermissionMixin

    return {BaseAction: [UserPassesTestMixin, PermissionMixin]}


@hookimpl
def djadmin_get_action_view_attribute_bindings(action):
    """
    Bind test_func method from action to view classes.

    The test_func method on BaseAction provides permission checking for
    UserPassesTestMixin. This hook registers it to be bound from the action
    to the view, similar to how get_template_name is bound.

    Args:
        action: The action instance

    Returns:
        Dict mapping action types to lists of attribute names to bind
    """
    from djadmin.actions import BaseAction

    return {BaseAction: ['test_func']}
