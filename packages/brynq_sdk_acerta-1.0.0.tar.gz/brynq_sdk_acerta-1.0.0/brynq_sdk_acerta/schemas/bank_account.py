"""
Schemas for Bank Accounts resource
"""

import pandas as pd
import pandera as pa
from pandera.typing import Series
from pydantic import BaseModel, Field
from typing import Optional, Literal
from brynq_sdk_functions import BrynQPanderaDataFrameModel


class BankAccountLinkGet(BrynQPanderaDataFrameModel):
    """Schema for GET /v1/employees/{employeeId}/bank-accounts (HAL _links)"""

    # Keep all fields declared in a single contiguous block, matching normalized column order
    employee_id: Series[pd.StringDtype] = pa.Field(coerce=True, description="Employee identifier for which links are returned", alias="employeeId")
    rel: Series[pd.StringDtype] = pa.Field(coerce=True, description="HAL relation key for the link", alias="rel")
    href: Series[pd.StringDtype] = pa.Field(coerce=True, description="Target IRI of the link", alias="href")
    hreflang: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Language of the target resource", alias="hreflang")
    title: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Human-readable identifier for the link", alias="title")
    type: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Media type of the target resource", alias="type")
    deprecation: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="IRI of a deprecation resource", alias="deprecation")
    profile: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="IRI that defines extra semantics", alias="profile")
    name: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Secondary key for link selection", alias="name")
    templated: Series[pd.BooleanDtype] = pa.Field(coerce=True, nullable=True, description="Whether the link is URI template", alias="templated")

    class _Annotation:
        primary_key = "rel"

    class Config:
        metadata = {"class": "BankAccountLink", "dependencies": []}


# POST/PUT Schemas (Pydantic - Request)
class OwnerName(BaseModel):
    """Reusable bank account owner name schema (no prefix)"""
    first_name: str = Field(..., min_length=1, max_length=35, example="John", description="Owner first name of the bank account", alias="firstName")
    last_name: str = Field(..., min_length=1, max_length=35, example="Doe", description="Owner last name of the bank account", alias="lastName")

    class Config:
        populate_by_name = True


class BankOwner(BaseModel):
    """Reusable bank account owner schema (no prefix)"""
    name: OwnerName = Field(..., description="Owner name of the bank account", alias="name", json_schema_extra={"prefix": "name_"})
    street: str = Field(..., min_length=1, max_length=40, example="Main Street", description="Owner street name of the bank account", alias="street")
    house_number: str = Field(..., min_length=1, max_length=9, example="123", description="Owner house number of the bank account", alias="houseNumber")
    box_number: Optional[str] = Field(None, min_length=1, max_length=4, example="A", description="Owner box number of the bank account", alias="boxNumber")
    postal_code: str = Field(..., min_length=1, max_length=14, example="1000", description="Owner zip code of the bank account", alias="postalCode")
    city: str = Field(..., min_length=1, max_length=35, example="Brussels", description="Owner city name of the bank account", alias="city")
    country: str = Field(..., min_length=3, max_length=3, example="BEL", description="Owner country code", alias="country")

    class Config:
        populate_by_name = True


class BankDetails(BaseModel):
    """Reusable bank details schema (no prefix)"""
    bic: str = Field(..., min_length=8, max_length=11, pattern=r"^([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}[A-Z0-9]{3}|[A-Z]{4}[A-Z]{2}[A-Z0-9]{2})$", example="SZNBDLYL", description="BIC Number", alias="bic")
    name: Optional[str] = Field(None, min_length=1, max_length=35, example="Bank Name", description="Name of the bank account", alias="name")
    street: Optional[str] = Field(None, min_length=1, max_length=40, example="Bank Street", description="Street name of the bank account", alias="street")
    house_number: Optional[str] = Field(None, min_length=1, max_length=9, example="456", description="House number of the bank account", alias="houseNumber")
    box_number: Optional[str] = Field(None, min_length=1, max_length=4, example="B", description="Box number of the bank account", alias="boxNumber")
    postal_code: Optional[str] = Field(None, min_length=1, max_length=14, example="2000", description="Zip code of the bank account", alias="postalCode")
    city: Optional[str] = Field(None, min_length=1, max_length=35, example="Antwerp", description="City name of the bank account", alias="city")
    country: Optional[str] = Field(None, min_length=3, max_length=3, example="BEL", description="Country code", alias="country")
    costs: Literal["DEBT", "CRED", "SHAR"] = Field(..., example="DEBT", description="Costs code", alias="costs")

    class Config:
        populate_by_name = True


class BankAccountUpdate(BaseModel):
    """Schema for PUT /v1/employees/{employeeId}/bank-accounts/{bankAccountId} endpoint"""

    iban: str = Field(..., min_length=1, max_length=34, example="BE68539007547034", description="Bank account number", alias="iban")
    text: Optional[str] = Field(None, min_length=1, max_length=40, example="Notice text", description="Notice text", alias="text")
    bank_details: Optional[BankDetails] = Field(None, description="If not a Belgian account, bankDetails must be specified", alias="bankDetails", json_schema_extra={"prefix": "bank_details_"})
    owner: Optional[BankOwner] = Field(None, description="If the owner is not the owner of the bankaccount, some extra data must be provided", alias="owner", json_schema_extra={"prefix": "owner_"})

    class Config:
        populate_by_name = True
