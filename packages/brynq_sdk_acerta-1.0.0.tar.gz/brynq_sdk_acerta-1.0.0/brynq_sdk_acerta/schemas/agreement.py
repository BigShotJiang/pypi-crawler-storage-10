"""
Schemas for Agreements resource
"""

import pandas as pd
import pandera as pa
from pandera.typing import Series
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Literal
from brynq_sdk_functions import BrynQPanderaDataFrameModel

# GET Schema (Pandera - DataFrame)
class AgreementGet(BrynQPanderaDataFrameModel):
    """Schema for GET /v2/employees/{employeeId}/agreements endpoint"""

    agreement_id: Series[pd.StringDtype] = pa.Field(coerce=True, description="Identifies the agreement and is unique for each agreement", alias="agreementId")
    external_reference: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="External reference for the agreement", alias="externalReference")
    employee_id: Series[pd.StringDtype] = pa.Field(coerce=True, description="The employeeId is the unique identifier for an employee", alias="employeeId")
    employer_id: Series[pd.StringDtype] = pa.Field(coerce=True, description="The employerId is the unique identifier for an employer", alias="employerId")
    legal_entity: Series[pd.StringDtype] = pa.Field(coerce=True, description="Legal entity identifier", alias="legalEntity")
    agreement_type_code: Series[pd.StringDtype] = pa.Field(coerce=True, description="Agreement type code", alias="agreementType.code")
    agreement_type_description: Series[pd.StringDtype] = pa.Field(coerce=True, nullable=True, description="Agreement type description", alias="agreementType.description")

    class _Annotation:
        primary_key = "agreement_id"
        foreign_keys = {
            "employee_id": {"parent_schema": "EmployeeGet", "parent_column": "employee_id", "cardinality": "N:1"}
        }

    class Config:
        strict = False
        metadata = {"class": "Agreement", "dependencies": []}

# POST Schema (Pydantic - Request)
class AgreementRemunerationBankAccountCreate(BaseModel):
    """Schema for POST /v1/agreements/{agreementId}/remuneration-bank-account endpoint"""

    iban: str = Field(..., min_length=1, max_length=34, example="BE68539007547034", description="Bank account number", alias="iban")
    bic: Optional[str] = Field(None, min_length=8, max_length=11, example="GEBABEBB", description="Bank identification code", alias="bic")

    class Config:
        populate_by_name = True


# PUT Schema (Pydantic - Request)
class AgreementRemunerationBankAccountUpdate(BaseModel):
    """Schema for PUT /employee-data-management/v3/employees/agreement/{agreementId}/remuneration-bank-account endpoint"""

    iban: str = Field(..., min_length=1, max_length=34, example="BE68539007547034", description="Bank account number", alias="iban")
    bic: Optional[str] = Field(None, min_length=8, max_length=11, example="GEBABEBB", description="Bank identification code", alias="bic")

    class Config:
        populate_by_name = True


class PatchPeriodStartNotNullable(BaseModel):
    start_date: str = Field(..., alias="startDate")
    end_date: Optional[str] = Field(None, alias="endDate")

    class Config:
        populate_by_name = True


class PatchPeriodNullable(BaseModel):
    start_date: Optional[str] = Field(None, alias="startDate")
    end_date: Optional[str] = Field(None, alias="endDate")

    class Config:
        populate_by_name = True


# =========================
# Basic Information section
# =========================

class PatchOfficialEmployerDataRequest(BaseModel):
    official_joint_committee: Optional[str] = Field(None, min_length=1, max_length=7, alias="officialJointCommittee")
    nsso_prefix: Optional[str] = Field(None, min_length=1, max_length=3, alias="nssoPrefix")
    indexation_joint_committee: Optional[str] = Field(None, min_length=1, max_length=7, alias="indexationJointCommittee")
    business_unit: Optional[str] = Field(None, pattern=r"^\d{10}$", alias="businessUnit")
    point_of_operation: Optional[str] = Field(None, min_length=1, max_length=4, alias="pointOfOperation")
    multiple_points_of_operations: Optional[bool] = Field(None, alias="multiplePointsOfOperations")
    replacement_agreement_id: Optional[str] = Field(None, pattern=r"^\d{11}$", alias="replacementAgreementId")

    class Config:
        populate_by_name = True


class PatchOfficialEmployeeDataRequest(BaseModel):
    employee_type: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="employeeType")
    employee_type_detail: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="employeeTypeDetail")
    duration: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="duration")

    class AgreementDetails(BaseModel):
        sort: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="sort")
        nsso_category: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="nssoCategory")
        statute: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="statute")
        nsso_exemption_category: Optional[str] = Field(None, pattern=r"^\d{2}$", alias="nssoExemptionCategory")

        class Config:
            populate_by_name = True

    agreement_details: Optional[AgreementDetails] = Field(None, alias="agreementDetails", json_schema_extra={"prefix": "agreement_details_"})

    class Config:
        populate_by_name = True


class PatchOfficialApprenticeDataRequest(BaseModel):
    type: Optional[str] = Field(None, min_length=1, max_length=1, alias="type")
    community: Optional[str] = Field(None, min_length=1, max_length=1, alias="community")
    contract_term: Optional[str] = Field(None, min_length=1, max_length=2, alias="contractTerm")
    contract_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="contractNumber")
    apprentice_starting_date: Optional[str] = Field(None, alias="apprenticeStartingDate")

    class Config:
        populate_by_name = True


class ContributionToSupplementaryPaymentRequest(BaseModel):
    resumption_of_work: Optional[str] = Field(None, min_length=1, max_length=1, alias="resumptionOfWork")
    first_allocation_date: Optional[str] = Field(None, alias="firstAllocationDate")
    last_allocation_date: Optional[str] = Field(None, alias="lastAllocationDate")
    notion_debtor: Optional[str] = Field(None, min_length=1, max_length=1, alias="notionDebtor")
    work_exemption: Optional[str] = Field(None, min_length=2, max_length=2, alias="workExemption")
    social_security_replacement_number: Optional[str] = Field(None, pattern=r"^\d{11}$", alias="socialSecurityReplacementNumber")

    class Config:
        populate_by_name = True


class PatchOfficialEarlyRetirementDataRequest(BaseModel):
    type: Optional[str] = Field(None, min_length=2, max_length=2, alias="type")
    early_retirement_contribution: Optional[str] = Field(None, min_length=1, max_length=1, alias="earlyRetirementContribution")
    counter_fraction_dmfa: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{3})?$", alias="counterFractionDmfa")
    contribution_to_supplementary_payment: Optional[ContributionToSupplementaryPaymentRequest] = Field(None, alias="contributionToSupplementaryPayment", json_schema_extra={"prefix": "contribution_to_supplementary_payment_"})

    class Config:
        populate_by_name = True


class PatchOfficialRetirementDataRequest(BaseModel):
    nihdi_code: Optional[str] = Field(None, min_length=1, max_length=1, alias="nihdiCode")
    nihdi_frequency: Optional[str] = Field(None, min_length=1, max_length=1, alias="nihdiFrequency")

    class Config:
        populate_by_name = True


class PatchAgreementRequestBasicInformation(BaseModel):
    official_employer_data: Optional[PatchOfficialEmployerDataRequest] = Field(None, alias="officialEmployerData", json_schema_extra={"prefix": "official_employer_data_"})
    official_employee_data: Optional[PatchOfficialEmployeeDataRequest] = Field(None, alias="officialEmployeeData", json_schema_extra={"prefix": "official_employee_data_"})
    apprentice: Optional[PatchOfficialApprenticeDataRequest] = Field(None, alias="apprentice", json_schema_extra={"prefix": "apprentice_"})
    early_retirement: Optional[PatchOfficialEarlyRetirementDataRequest] = Field(None, alias="earlyRetirement", json_schema_extra={"prefix": "early_retirement_"})
    retirement: Optional[PatchOfficialRetirementDataRequest] = Field(None, alias="retirement", json_schema_extra={"prefix": "retirement_"})
    c32_code: Optional[str] = Field(None, min_length=1, max_length=1, alias="c32Code")

    class Construction(BaseModel):
        c32a_current_month_number: Optional[str] = Field(None, min_length=1, max_length=13, alias="c32aCurrentMonthNumber")
        c32a_next_month_number: Optional[str] = Field(None, min_length=1, max_length=13, alias="c32aNextMonthNumber")

        class Config:
            populate_by_name = True

    construction: Optional[Construction] = Field(None, alias="construction", json_schema_extra={"prefix": "construction_"})

    class Config:
        populate_by_name = True


# ===============
# Employment part
# ===============

class PatchEmploymentRequestNotice(BaseModel):
    date_notice_served: Optional[str] = Field(None, alias="dateNoticeServed")
    notice_letter_sent_on: Optional[str] = Field(None, alias="noticeLetterSentOn")
    notice_period: Optional[PatchPeriodNullable] = Field(None, alias="noticePeriod", json_schema_extra={"prefix": "notice_period_"})
    end_disruption_period: Optional[str] = Field(None, alias="endDisruptionPeriod")

    class Config:
        populate_by_name = True


class PatchEmploymentRequestLeavingEmployment(BaseModel):
    date_end_mutual_remuneration: Optional[str] = Field(None, alias="dateEndMutualRemuneration")
    date_end_goodwill_indemnity: Optional[str] = Field(None, alias="dateEndGoodwillIndemnity")
    date_end_integration_compensation: Optional[str] = Field(None, alias="dateEndIntegrationCompensation")
    date_end_non_competition_remuneration: Optional[str] = Field(None, alias="dateEndNonCompetitionRemuneration")
    date_end_medical_force_majeure: Optional[str] = Field(None, alias="dateEndMedicalForceMajeure")

    class Config:
        populate_by_name = True


class PatchEmploymentRequestStudentQuarters(BaseModel):
    days_of_student_work_first_quarter_number: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.00)?$", alias="daysOfStudentWorkFirstQuarterNumber")
    days_of_student_work_second_quarter_number: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.00)?$", alias="daysOfStudentWorkSecondQuarterNumber")
    days_of_student_work_third_quarter_number: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.00)?$", alias="daysOfStudentWorkThirdQuarterNumber")
    days_of_student_work_fourth_quarter_number: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.00)?$", alias="daysOfStudentWorkFourthQuarterNumber")
    days_of_student_work_fifth_quarter_number: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.00)?$", alias="daysOfStudentWorkFifthQuarterNumber")

    class Config:
        populate_by_name = True


class PatchEmploymentRequest(BaseModel):
    employment_period: Optional[PatchPeriodStartNotNullable] = Field(None, alias="employmentPeriod", json_schema_extra={"prefix": "employment_period_"})
    in_organisation_date: Optional[str] = Field(None, alias="inOrganisationDate")
    interim_start_date: Optional[str] = Field(None, alias="interimStartDate")
    trial_period_end_date: Optional[str] = Field(None, alias="trialPeriodEndDate")
    reason_termination: Optional[str] = Field(None, min_length=3, max_length=3, alias="reasonTermination")
    notice: Optional[PatchEmploymentRequestNotice] = Field(None, alias="notice", json_schema_extra={"prefix": "notice_"})
    leaving_employment: Optional[PatchEmploymentRequestLeavingEmployment] = Field(None, alias="leavingEmployment", json_schema_extra={"prefix": "leaving_employment_"})
    ignore_seniority_in_case_of_illness: Optional[bool] = Field(None, alias="ignoreSeniorityInCaseOfIllness")
    students_quarters: Optional[PatchEmploymentRequestStudentQuarters] = Field(None, alias="studentsQuarters", json_schema_extra={"prefix": "students_quarters_"})

    class Config:
        populate_by_name = True


# ==============
# Working Time
# ==============

class PatchWorkingTimeRequestEmploymentFraction(BaseModel):
    numerator: str = Field(..., pattern=r"^\d{1,3}\.\d{3}$", alias="numerator")
    denominator: str = Field(..., pattern=r"^\d{1,3}\.\d{3}$", alias="denominator")

    class Config:
        populate_by_name = True


class PatchFraction(BaseModel):
    numerator: Optional[str] = Field(None, pattern=r"^\d{1,3}\.\d{3}$", alias="numerator")
    denominator: Optional[str] = Field(None, pattern=r"^\d{1,3}\.\d{3}$", alias="denominator")

    class Config:
        populate_by_name = True


class PatchWorkingTimeRequestMeasure(BaseModel):
    code: Optional[str] = Field(None, min_length=3, max_length=3, alias="code")
    percent: Optional[str] = Field(None, pattern=r"^\d{1,3}\.\d{2}$", alias="percent")

    class Config:
        populate_by_name = True


class PatchReducedWorkingHoursRequest(BaseModel):
    regularity: str = Field(..., min_length=1, max_length=1, alias="regularity")
    measure: Optional[str] = Field(None, min_length=3, max_length=3, alias="measure")
    involuntary_part_time: Optional[str] = Field(None, min_length=1, max_length=1, alias="involuntaryPartTime")
    refusal_of_employment_date: Optional[str] = Field(None, alias="refusalOfEmploymentDate")
    has_progressive_work_resumption: Optional[bool] = Field(None, alias="hasProgressiveWorkResumption")
    illness_other_employer_start_date: Optional[str] = Field(None, alias="illnessOtherEmployerStartDate")
    progressive_work_resumption_type: Optional[str] = Field(None, min_length=2, max_length=2, alias="progressiveWorkResumptionType")
    adjusted_work_regime: Optional[str] = Field(None, pattern=r"^\d{1}\.\d{2}$", alias="adjustedWorkRegime")
    adjusted_work_fraction: Optional[PatchFraction] = Field(None, alias="adjustedWorkFraction", json_schema_extra={"prefix": "adjusted_work_fraction_"})
    measure1: Optional[PatchWorkingTimeRequestMeasure] = Field(None, alias="measure1", json_schema_extra={"prefix": "measure1_"})
    measure2: Optional[PatchWorkingTimeRequestMeasure] = Field(None, alias="measure2", json_schema_extra={"prefix": "measure2_"})
    full_time_absence: Optional[bool] = Field(None, alias="fullTimeAbsence")

    class Config:
        populate_by_name = True


class PatchWorkingTimeRequest(BaseModel):
    working_time_type: str = Field(..., min_length=1, max_length=1, alias="workingTimeType")
    work_schedule: Optional[str] = Field(None, min_length=1, max_length=20, alias="workSchedule")
    work_regime: str = Field(..., pattern=r"^\d{1}\.\d{2}$", alias="workRegime")
    hours_week_full_time: str = Field(..., pattern=r"^\d{2}\.\d{2}$", alias="hoursWeekFullTime")
    pay_on_annual_basis: Optional[str] = Field(None, pattern=r"^\d{1}(\.\d{4})?$", alias="payOnAnnualBasis")
    employment_fraction: PatchWorkingTimeRequestEmploymentFraction = Field(..., alias="employmentFraction", json_schema_extra={"prefix": "employment_fraction_"})
    original_employment_fraction: Optional[PatchFraction] = Field(None, alias="originalEmploymentFraction", json_schema_extra={"prefix": "original_employment_fraction_"})
    effective_employment_fraction: Optional[PatchFraction] = Field(None, alias="effectiveEmploymentFraction", json_schema_extra={"prefix": "effective_employment_fraction_"})
    time_credits: Optional[str] = Field(None, min_length=2, max_length=2, alias="timeCredits")
    exemption_type: Optional[str] = Field(None, min_length=1, max_length=2, alias="exemptionType")
    art54bis_or_ter: Optional[str] = Field(None, min_length=1, max_length=2, alias="art54bisOrTer")
    reduced_working_hours: Optional[PatchReducedWorkingHoursRequest] = Field(None, alias="reducedWorkingHours", json_schema_extra={"prefix": "reduced_working_hours_"})

    class Config:
        populate_by_name = True


# ==============
# Remuneration
# ==============

class PatchAgreementRequestGeneralRemuneration(BaseModel):
    steering_group: str = Field(..., min_length=1, max_length=4, alias="steeringGroup")
    accounting_organisation: str = Field(..., min_length=1, max_length=3, alias="accountingOrganisation")
    function: str = Field(..., min_length=1, max_length=8, alias="function")
    function_start_date: Optional[str] = Field(None, alias="functionStartDate")
    organisation: Optional[str] = Field(None, min_length=1, max_length=12, alias="organisation")
    cost_center: Optional[str] = Field(None, min_length=1, max_length=12, alias="costCenter")

    class Config:
        populate_by_name = True


class PatchAgreementRequestRemunerationPayCalculation(BaseModel):
    calculation_method: Optional[str] = Field(None, min_length=1, max_length=1, alias="calculationMethod")
    salary_split: Optional[str] = Field(None, min_length=1, max_length=1, alias="salarySplit")
    salary_qualification: Optional[str] = Field(None, min_length=1, max_length=2, alias="salaryQualification")
    adapted_holiday_pay: Optional[str] = Field(None, min_length=1, max_length=1, alias="adaptedHolidayPay")
    financing_code: Optional[str] = Field(None, min_length=1, max_length=3, alias="financingCode")
    payment_scheme: Optional[str] = Field(None, min_length=1, max_length=8, alias="paymentScheme")

    class Tip(BaseModel):
        type: Optional[str] = Field(None, min_length=1, max_length=1, alias="type")
        professional_role: Optional[str] = Field(None, min_length=2, max_length=2, alias="professionalRole")

        class Config:
            populate_by_name = True

    tip: Optional[Tip] = Field(None, alias="tip", json_schema_extra={"prefix": "tip_"})
    seniority_date: Optional[str] = Field(None, alias="seniorityDate")
    sector_seniority_date: Optional[str] = Field(None, alias="sectorSeniorityDate")
    internal_seniority_date: Optional[str] = Field(None, alias="internalSeniorityDate")
    position_seniority_date: Optional[str] = Field(None, alias="positionSeniorityDate")
    remuneration_fraction: Optional[PatchFraction] = Field(None, alias="remunerationFraction", json_schema_extra={"prefix": "remuneration_fraction_"})
    statutory_retirement_date: Optional[str] = Field(None, alias="statutoryRetirementDate")
    contribution_second_retirement_pillar: Optional[str] = Field(None, min_length=1, max_length=1, alias="contributionSecondRetirementPillar")
    wage_category: Optional[str] = Field(None, min_length=4, max_length=4, alias="wageCategory")

    class Config:
        populate_by_name = True


class PatchAgreementRequestPayScale(BaseModel):
    use_pay_scale: bool = Field(..., alias="usePayScale")
    type: Optional[str] = Field(None, min_length=1, max_length=1, alias="type")
    pay_scale_selection: Optional[str] = Field(None, min_length=1, max_length=9, alias="payScaleSelection")
    experience: Optional[str] = Field(None, alias="experience")
    pay_grade: Optional[str] = Field(None, min_length=1, max_length=1, alias="payGrade")
    level: Optional[str] = Field(None, min_length=1, max_length=1, alias="level")

    class IficNullable(BaseModel):
        useIFIC: Optional[bool] = Field(None, alias="useIFIC")
        useScale: Optional[bool] = Field(None, alias="useScale")

        class Seniority(BaseModel):
            year_number: Optional[str] = Field(None, min_length=1, max_length=2, alias="yearNumber")
            month_number: Optional[str] = Field(None, min_length=1, max_length=2, alias="monthNumber")

            class Config:
                populate_by_name = True

        seniority: Optional[Seniority] = Field(None, alias="seniority", json_schema_extra={"prefix": "seniority_"})
        salary_scale_number: Optional[str] = Field(None, min_length=1, max_length=9, alias="salaryScaleNumber")

        class RemFrac(BaseModel):
            numerator: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{3})?$", alias="numerator")
            denominator: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{3})?$", alias="denominator")

            class Config:
                populate_by_name = True

        remuneration_fraction: Optional[RemFrac] = Field(None, alias="remunerationFraction", json_schema_extra={"prefix": "remuneration_fraction_"})
        function: Optional[str] = Field(None, min_length=4, max_length=4, alias="function")

        class HybridFunction(BaseModel):
            code: Optional[str] = Field(None, min_length=1, max_length=4, alias="code")
            number: Optional[str] = Field(None, min_length=1, max_length=9, alias="number")

            class HybridFraction(BaseModel):
                numerator: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{3})?$", alias="numerator")
                denominator: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{3})?$", alias="denominator")

                class Config:
                    populate_by_name = True

            fraction: Optional[HybridFraction] = Field(None, alias="fraction", json_schema_extra={"prefix": "fraction_"})

            class Config:
                populate_by_name = True

        hybridFunction_1: Optional[HybridFunction] = Field(None, alias="hybridFunction_1", json_schema_extra={"prefix": "hybrid_function_1_"})
        hybridFunction_2: Optional[HybridFunction] = Field(None, alias="hybridFunction_2", json_schema_extra={"prefix": "hybrid_function_2_"})
        hybridFunction_3: Optional[HybridFunction] = Field(None, alias="hybridFunction_3", json_schema_extra={"prefix": "hybrid_function_3_"})

        class Config:
            populate_by_name = True

    ific: Optional[IficNullable] = Field(None, alias="ific", json_schema_extra={"prefix": "ific_"})

    class Config:
        populate_by_name = True


class PatchBankAccounts(BaseModel):
    main_account: Optional[str] = Field(None, min_length=1, max_length=34, alias="mainAccount")
    second_account: Optional[str] = Field(None, min_length=1, max_length=34, alias="secondAccount")

    class Config:
        populate_by_name = True


class PatchAgreementRequestRemunerationMethodOfPayment(BaseModel):
    type: str = Field(..., min_length=1, max_length=1, alias="type")
    employee_bank_accounts: Optional[PatchBankAccounts] = Field(None, alias="employeeBankAccounts", json_schema_extra={"prefix": "employee_bank_accounts_"})
    employer_bank_accounts: Optional[PatchBankAccounts] = Field(None, alias="employerBankAccounts", json_schema_extra={"prefix": "employer_bank_accounts_"})

    class Config:
        populate_by_name = True


class PatchAgreementRequestRemunerationInsuranceDetails(BaseModel):
    work_accident_insurance_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="workAccidentInsuranceNumber")
    work_accident_insurance_policy_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="workAccidentInsurancePolicyNumber")
    has_groups_insurance: Optional[bool] = Field(None, alias="hasGroupsInsurance")
    group_insurance_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="groupInsuranceNumber")
    group_insurance_policy_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="groupInsurancePolicyNumber")
    other_insurance_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="otherInsuranceNumber")
    other_insurance_policy_number: Optional[str] = Field(None, min_length=1, max_length=15, alias="otherInsurancePolicyNumber")
    has_hospital_insurance: Optional[bool] = Field(None, alias="hasHospitalInsurance")
    has_hospital_insurance_for_spouse: Optional[bool] = Field(None, alias="hasHospitalInsuranceForSpouse")

    class Config:
        populate_by_name = True


class PatchAgreementRequestRemuneration(BaseModel):
    general_remuneration: Optional[PatchAgreementRequestGeneralRemuneration] = Field(None, alias="generalRemuneration", json_schema_extra={"prefix": "general_remuneration_"})
    pay_calculation: Optional[PatchAgreementRequestRemunerationPayCalculation] = Field(None, alias="payCalculation", json_schema_extra={"prefix": "pay_calculation_"})
    pay_scale: Optional[PatchAgreementRequestPayScale] = Field(None, alias="payScale", json_schema_extra={"prefix": "pay_scale_"})
    method_of_payment: Optional[PatchAgreementRequestRemunerationMethodOfPayment] = Field(None, alias="methodOfPayment", json_schema_extra={"prefix": "method_of_payment_"})
    insurance_details: Optional[PatchAgreementRequestRemunerationInsuranceDetails] = Field(None, alias="insuranceDetails", json_schema_extra={"prefix": "insurance_details_"})

    class Config:
        populate_by_name = True


# ========================
# Recruitment Incentives
# ========================

class RecruitmentFrameworkNullable(BaseModel):
    code: Optional[str] = Field(None, min_length=3, max_length=3, alias="code")
    start_date: Optional[str] = Field(None, alias="startDate")

    class Config:
        populate_by_name = True


class PatchAgreementRecruitmentIncentives(BaseModel):
    employee_recruitment_framework: Optional[RecruitmentFrameworkNullable] = Field(None, alias="employeeRecruitmentFramework", json_schema_extra={"prefix": "employee_recruitment_framework_"})
    employer_recruitment_framework: Optional[RecruitmentFrameworkNullable] = Field(None, alias="employerRecruitmentFramework", json_schema_extra={"prefix": "employer_recruitment_framework_"})
    regional_recruitment_framework: Optional[RecruitmentFrameworkNullable] = Field(None, alias="regionalRecruitmentFramework", json_schema_extra={"prefix": "regional_recruitment_framework_"})
    number_of_balance_months_work_benefit: Optional[str] = Field(None, pattern=r"^(0|[1-9][0-9]?)$", alias="numberOfBalanceMonthsWorkBenefit")
    gesco_number: Optional[str] = Field(None, min_length=1, max_length=9, alias="gescoNumber")
    career_measure: Optional[str] = Field(None, min_length=2, max_length=2, alias="careerMeasure")
    start_job: Optional[str] = Field(None, min_length=2, max_length=2, alias="startJob")
    restructuring_or_difficulties: Optional[str] = Field(None, min_length=1, max_length=1, alias="restructuringOrDifficulties")
    other_social_services: Optional[str] = Field(None, min_length=2, max_length=2, alias="otherSocialServices")
    research_percent: Optional[str] = Field(None, pattern=r"^\d{1,3}(\.\d{2})?$", alias="researchPercent")
    aid_zone: Optional[str] = Field(None, min_length=1, max_length=1, alias="aidZone")

    class Config:
        populate_by_name = True


# =======
# Sector
# =======

class SocialProfitNumberOfWorkTimeNullable(BaseModel):
    numerator: Optional[str] = Field(None, pattern=r"^(0|[1-9][0-9]?)$", alias="numerator")
    denominator: Optional[str] = Field(None, pattern=r"^(10|11|12)$", alias="denominator")

    class Config:
        populate_by_name = True


class PatchAgreementRequestSectorSocialProfit(BaseModel):
    status_target_group: Optional[str] = Field(None, min_length=1, max_length=1, alias="statusTargetGroup")
    supervision_intensity_code: Optional[str] = Field(None, min_length=1, max_length=1, alias="supervisionIntensityCode")
    wage_bonus_percent: Optional[float] = Field(None, alias="wageBonusPercent")
    is_weak_employee: Optional[bool] = Field(None, alias="isWeakEmployee")
    supervisor_qualification: Optional[str] = Field(None, min_length=2, max_length=2, alias="supervisorQualification")
    occupational_class: Optional[str] = Field(None, min_length=1, max_length=1, alias="occupationalClass")
    employee_qualification: Optional[str] = Field(None, min_length=2, max_length=2, alias="employeeQualification")
    financing: Optional[str] = Field(None, min_length=3, max_length=3, alias="financing")
    rob_particular_competence_code: Optional[str] = Field(None, min_length=1, max_length=1, alias="robParticularCompetenceCode")
    staff_type: Optional[str] = Field(None, min_length=1, max_length=1, alias="staffType")
    nihdi_number: Optional[str] = Field(None, pattern=r"^\d{11}$", alias="nihdiNumber")
    specialism: Optional[str] = Field(None, min_length=1, max_length=3, alias="specialism")
    recognition_year: Optional[str] = Field(None, pattern=r"^\d{4}$", alias="recognitionYear")
    additional_qualification: Optional[str] = Field(None, min_length=1, max_length=2, alias="additionalQualification")
    qualification_year: Optional[str] = Field(None, pattern=r"^\d{4}$", alias="qualificationYear")
    campus: Optional[str] = Field(None, min_length=1, max_length=5, alias="campus")
    hospital_statute: Optional[str] = Field(None, min_length=1, max_length=1, alias="hospitalStatute")
    number_of_work_time: Optional[SocialProfitNumberOfWorkTimeNullable] = Field(None, alias="numberOfWorkTime", json_schema_extra={"prefix": "number_of_work_time_"})
    has_private_practice: Optional[bool] = Field(None, alias="hasPrivatePractice")
    localisation: Optional[str] = Field(None, pattern=r"^\d{4}$", alias="localisation")

    class Policlinic(BaseModel):
        belongs_to_the_own_hospital: Optional[bool] = Field(None, alias="belongsToTheOwnHospital")
        belongs_to_another_hospital: Optional[bool] = Field(None, alias="belongsToAnotherHospital")
        belongs_not_to_hospital: Optional[bool] = Field(None, alias="belongsNotToHospital")

        class Config:
            populate_by_name = True

    policlinic: Optional[Policlinic] = Field(None, alias="policlinic", json_schema_extra={"prefix": "policlinic_"})
    service_activity: Optional[str] = Field(None, min_length=1, max_length=1, alias="serviceActivity")
    distinguishing_letter: Optional[str] = Field(None, min_length=1, max_length=7, alias="distinguishingLetter")
    hospital_particular_competence: Optional[str] = Field(None, min_length=1, max_length=1, alias="hospitalParticularCompetence")
    hospital_organisation_number: Optional[str] = Field(None, min_length=1, max_length=12, alias="hospitalOrganisationNumber")
    physical_department_name: Optional[str] = Field(None, min_length=1, max_length=35, alias="physicalDepartmentName")
    not_medical_registration_zone: Optional[str] = Field(None, min_length=1, max_length=50, alias="notMedicalRegistrationZone")
    nursing_unit_name: Optional[str] = Field(None, min_length=1, max_length=50, alias="nursingUnitName")
    diploma: Optional[str] = Field(None, min_length=1, max_length=4, alias="diploma")

    class Config:
        populate_by_name = True


class PatchAgreementRequestSectorTransport(BaseModel):
    wage_system: Optional[str] = Field(None, min_length=1, max_length=1, alias="wageSystem")

    class Config:
        populate_by_name = True


class PatchAgreementRequestSectorPublicHospital(BaseModel):
    unemployment: Optional[PatchPeriodNullable] = Field(None, alias="unemployment", json_schema_extra={"prefix": "unemployment_"})
    illness: Optional[PatchPeriodNullable] = Field(None, alias="illness", json_schema_extra={"prefix": "illness_"})

    class SickLeaveReserveNullable(BaseModel):
        anniversary_date: Optional[str] = Field(None, alias="anniversaryDate")
        system: Optional[str] = Field(None, min_length=1, max_length=1, alias="system")

        class Config:
            populate_by_name = True

    sick_leave_reserve: Optional[SickLeaveReserveNullable] = Field(None, alias="sickLeaveReserve", json_schema_extra={"prefix": "sick_leave_reserve_"})

    class CapeloNullable(BaseModel):
        has_exception_obligation: Optional[bool] = Field(None, alias="hasExceptionObligation")
        service_type: Optional[str] = Field(None, min_length=1, max_length=1, alias="serviceType")
        institution_type: Optional[str] = Field(None, min_length=1, max_length=2, alias="institutionType")
        function: Optional[str] = Field(None, min_length=1, max_length=1, alias="function")
        staff_category: Optional[str] = Field(None, min_length=1, max_length=4, alias="staffCategory")
        pdos_name: Optional[str] = Field(None, min_length=1, max_length=12, alias="pdosName")
        grade: Optional[str] = Field(None, min_length=1, max_length=8, alias="grade")

        class Config:
            populate_by_name = True

    capelo: Optional[CapeloNullable] = Field(None, alias="capelo", json_schema_extra={"prefix": "capelo_"})

    class Config:
        populate_by_name = True


class PatchAgreementRequestSector(BaseModel):
    social_profit: Optional[PatchAgreementRequestSectorSocialProfit] = Field(None, alias="socialProfit", json_schema_extra={"prefix": "social_profit_"})
    transport: Optional[PatchAgreementRequestSectorTransport] = Field(None, alias="transport", json_schema_extra={"prefix": "transport_"})
    public_hospital: Optional[PatchAgreementRequestSectorPublicHospital] = Field(None, alias="publicHospital", json_schema_extra={"prefix": "public_hospital_"})

    class Config:
        populate_by_name = True


# ============================
# Declarations (OfficialEmployee)
# ============================

class PatchWithHoldingTaxRequest(BaseModel):
    tax_type: str = Field(..., min_length=1, max_length=2, alias="taxType")
    declaration: Optional[str] = Field(None, min_length=1, max_length=1, alias="declaration")
    cross_border_worker: Optional[str] = Field(None, min_length=1, max_length=1, alias="crossBorderWorker")
    gross_net_contraction: str = Field(..., min_length=1, max_length=2, alias="grossNetContraction")

    class Config:
        populate_by_name = True


class PatchOfficialEmployeeDataNSSO(BaseModel):
    work_place_accident_risk_category: Optional[str] = Field(None, min_length=1, max_length=3, alias="workPlaceAccidentRiskCategory")
    nsso_notion: Optional[str] = Field(None, min_length=1, max_length=2, alias="nssoNotion")
    disabled_for_nsso: Optional[bool] = Field(None, alias="disabledForNsso")
    custom_work_type_code: Optional[str] = Field(None, min_length=1, max_length=1, alias="customWorkTypeCode")

    class Config:
        populate_by_name = True


class PatchOfficialEmployeeDataRequestDeclarations(BaseModel):
    with_holding_tax: Optional[PatchWithHoldingTaxRequest] = Field(None, alias="withHoldingTax", json_schema_extra={"prefix": "with_holding_tax_"})
    tax_statute: Optional[str] = Field(None, min_length=1, max_length=2, alias="taxStatute")
    nsso: Optional[PatchOfficialEmployeeDataNSSO] = Field(None, alias="nsso", json_schema_extra={"prefix": "nsso_"})
    transport_costs_fully_taxed: Optional[bool] = Field(None, alias="transportCostsFullyTaxed")
    maribel: Optional[dict] = Field(None, alias="maribel")
    social_balance: Optional[bool] = Field(None, alias="socialBalance")
    via: Optional[str] = Field(None, min_length=1, max_length=5, alias="via")
    nace: Optional[str] = Field(None, min_length=1, max_length=5, alias="nace")
    pension_system: Optional[str] = Field(None, min_length=1, max_length=2, alias="pensionSystem")
    nsso_function: Optional[str] = Field(None, min_length=1, max_length=4, alias="nssoFunction")
    deviating_pension_calculation: Optional[bool] = Field(None, alias="deviatingPensionCalculation")
    measure_non_profit: Optional[str] = Field(None, min_length=1, max_length=2, alias="measureNonProfit")
    illness6_months_date: Optional[str] = Field(None, alias="illness6MonthsDate")

    class Config:
        populate_by_name = True


# =============================
# ROOT: Patch Agreement Request
# =============================

class PatchAgreementRequest(BaseModel):
    """Schema for PATCH /v3/agreements/{agreementId}."""
    from_date: str = Field(..., alias="fromDate")

    basic_information: Optional[PatchAgreementRequestBasicInformation] = Field(None, alias="basicInformation", json_schema_extra={"prefix": "basic_information_"})
    employment: Optional[PatchEmploymentRequest] = Field(None, alias="employment", json_schema_extra={"prefix": "employment_"})
    working_time: Optional[PatchWorkingTimeRequest] = Field(None, alias="workingTime", json_schema_extra={"prefix": "working_time_"})
    remuneration: Optional[PatchAgreementRequestRemuneration] = Field(None, alias="remuneration", json_schema_extra={"prefix": "remuneration_"})
    recruitment_incentives: Optional[PatchAgreementRecruitmentIncentives] = Field(None, alias="recruitmentIncentives", json_schema_extra={"prefix": "recruitment_incentives_"})
    sector: Optional[PatchAgreementRequestSector] = Field(None, alias="sector", json_schema_extra={"prefix": "sector_"})
    declarations: Optional[PatchOfficialEmployeeDataRequestDeclarations] = Field(None, alias="declarations", json_schema_extra={"prefix": "declarations_"})

    class Config:
        populate_by_name = True
