from typing import Dict, Any, Tuple
import pandas as pd
import requests
from brynq_sdk_functions import Functions
from .schemas.bank_account import BankAccountLinkGet, BankAccountUpdate
from .schemas.agreement import AgreementRemunerationBankAccountUpdate
from typing import TYPE_CHECKING
if TYPE_CHECKING:
	from .acerta import Acerta

class BankAccounts:
	"""Resource class for Employee Bank Accounts (HAL links)."""

	def __init__(self, acerta):
		self.acerta: Acerta = acerta
		self.base_uri = "v1"

	def get(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
		"""
		GET /v1/employees/{employeeId}/bank-accounts - Employee Bank Accounts

		Retrieves bank account HAL links for all cached employees. Returns normalized link data
		including href, title, type, and other HAL properties.

		Args:

		Returns:
			Tuple[pd.DataFrame, pd.DataFrame]: (valid_df, invalid_df) after normalizing and validating
		"""
		if not self.acerta._employee_ids:
			self.acerta.agreements.get()

		rows = []
		for employee_id in self.acerta._employee_ids:
			response = self.acerta.session.get(
				url=f"{self.acerta.base_url}/employee-data-management/v1/employees/{employee_id}/bank-accounts",
				timeout=self.acerta.TIMEOUT,
			)
			response.raise_for_status()
			content = response.json()

			links_dict = content.get("_links", {})
			if not isinstance(links_dict, dict):
				links_dict = {}

			for rel, link in links_dict.items():
				if isinstance(link, dict):
					rows.append({"employeeId": employee_id, "rel": rel, **link})

		df = pd.json_normalize(rows)

		valid_data, invalid_data = Functions.validate_data(df, BankAccountLinkGet)

		return valid_data, invalid_data

	def update(self, agreement_id: str, data: Dict[str, Any]) -> requests.Response:
		"""
		PUT /employee-data-management/v3/employees/agreement/{agreementId}/remuneration-bank-account - Agreement Remuneration Bank Account

		Set the bank account for the employee and agreement. This endpoint updates the remuneration
		bank account associated with a specific agreement.

		Args:
			agreement_id: Unique identifier of an agreement
			data: Dictionary with bank account data (iban, bic)

		Returns:
			requests.Response: Raw response object

		Raises:
			Exception: If the update fails
		"""
		# Validate the data (no nesting required for this simple schema)
		validated_data = AgreementRemunerationBankAccountUpdate(**data)

		# Make API request
		response = self.acerta.session.put(
			url=f"{self.acerta.base_url}/employee-data-management/v3/employees/agreement/{agreement_id}/remuneration-bank-account",
			json=validated_data.model_dump(by_alias=True, exclude_none=True),
			timeout=self.acerta.TIMEOUT,
		)
		response.raise_for_status()

		return response
