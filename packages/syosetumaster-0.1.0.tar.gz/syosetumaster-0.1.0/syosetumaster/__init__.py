from syosetumaster import SyosetuMaster
__all__ = "SyosetuMaster"