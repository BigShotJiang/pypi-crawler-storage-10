from .syosetu import Syosetu, PROG_STATUS, BASE_DIR, _set_base_dir
__all__ = "Syosetu, PROG_STATUS, BASE_DIR, _set_base_dir"