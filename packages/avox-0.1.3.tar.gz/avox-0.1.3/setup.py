from setuptools import setup, find_packages

setup(
    name="Avox",  # this is the name people will use with pip install
    version="0.1.3",
    packages=find_packages(),
    install_requires=[
        "speechrecognition",
        "pyaudio",
        "pyttsx3"
    ],
  
    
    
)