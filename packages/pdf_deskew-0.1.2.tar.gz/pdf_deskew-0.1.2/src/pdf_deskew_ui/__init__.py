"""PDF Deskew UI - GUI application for deskewing scanned PDF documents."""

__version__ = "0.1.2"
__author__ = "driezy"
