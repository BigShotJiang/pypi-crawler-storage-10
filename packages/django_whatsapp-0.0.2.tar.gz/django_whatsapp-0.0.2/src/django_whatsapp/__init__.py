"""Django application to handle WhatsApp Webhook incoming requests."""
