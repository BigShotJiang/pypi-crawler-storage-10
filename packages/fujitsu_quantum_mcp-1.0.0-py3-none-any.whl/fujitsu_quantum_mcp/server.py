# (C) Fujitsu Limited, 2025

import os
import ssl
import httpx

from pathlib import Path

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("fujitsu-quantum-mcp")

docs_base_url = "https://www.quantum.global.fujitsu.com/docs/"
topic_to_url = {
    "sdk/installation": f"{docs_base_url}sdk/installation.html.md",
    "sdk/devices": f"{docs_base_url}sdk/devices.html.md",
    "sdk/tasks": f"{docs_base_url}sdk/tasks/index.html.md",
    "sdk/primitive_tasks": f"{docs_base_url}sdk/tasks/primitive-tasks.html.md",
    "sdk/hybrid_tasks": f"{docs_base_url}sdk/tasks/hybrid-tasks.html.md",
    "sdk/managing_tasks": f"{docs_base_url}sdk/tasks/managing-tasks.html.md",
    "sdk/performance_guides": f"{docs_base_url}sdk/performance-guides.html.md",
    "sdk/examples": f"{docs_base_url}sdk/examples.html.md",
    "sdk/troubleshooting": f"{docs_base_url}sdk/troubleshooting.html.md",
    "sdk/migration_guides": f"{docs_base_url}sdk/migration-guides.html.md",
    "sdk/release_notes": f"{docs_base_url}sdk/release-notes.html.md",
    "mcp/installation": f"{docs_base_url}mcp/installation.html.md",
    "mcp/features": f"{docs_base_url}mcp/features.html.md",
    "service_quotas": f"{docs_base_url}service-quotas.html.md",
    "all": f"{docs_base_url}llms-full.txt",
}


def get_basic_auth() -> tuple[str, str]:
    basic_auth = os.getenv("FUJITSU_QUANTUM_BASIC_AUTH")
    if not basic_auth:
        raise ValueError("FUJITSU_QUANTUM_BASIC_AUTH environment variable is required but not set. Please set it in the format 'username:password'.")

    try:
        username, password = basic_auth.split(":", 1)
        return (username, password)
    except ValueError:
        raise ValueError("Invalid FUJITSU_QUANTUM_BASIC_AUTH format. It should be 'username:password'.")


async def fetch(url: str) -> str:
    # Use the ssl certificates specified in the env var FUJITSU_QUANTUM_CA_BUNDLE.
    # If FUJITSU_QUANTUM_CA_BUNDLE is not specified, use the default certificates httpx uses.
    ca_bundle: str | None = os.getenv("FUJITSU_QUANTUM_CA_BUNDLE")
    if ca_bundle:
        ca_path = Path(ca_bundle)
        if not ca_path.is_file():
            raise ValueError(f"The specified CA bundle path does not exist or is not a file: {ca_bundle}")
        ctx = ssl.create_default_context(cafile=ca_bundle)
        verify = ctx
    else:
        verify = True

    auth = get_basic_auth()
    try:
        async with httpx.AsyncClient(verify=verify) as client:
            response = await client.get(url, auth=auth)
            response.raise_for_status()
            return response.text
    except httpx.HTTPError as e:
        raise RuntimeError(f"Failed to fetch the URL: {url}. Error: {str(e)}")


@mcp.tool()
async def get_documentation_by_topic(topic: str = 'all') -> str:
    """Returns the Fujitsu Quantum Cloud documentation, including usage of fujitsu-quantum, for the specified topic in Markdown.

    Args:
        topic (str): A topic to get documentation for. Possible topics are:
            - "sdk/installation": Instructions to install the fujitsu-quantum SDK, log in, log out, and validate installation.
            - "sdk/devices": Usage of fujitsu-quantum APIs to retrieve quantum device information.
            - "sdk/tasks": Overview of quantum task categories: primitive tasks (sampling and estimation tasks) and hybrid tasks.
            - "sdk/primitive_tasks": Usage of fujitsu-quantum APIs regarding primitive tasks.
            - "sdk/hybrid_tasks": Usage of fujitsu-quantum APIs regarding hybrid tasks.
            - "sdk/managing_tasks": Usage of fujitsu-quantum APIs to retrieve quantum task information.
            - "sdk/performance_guides": Key points on how to use SDKs that are important for improving performance.
            - "sdk/examples": Examples using fujitsu-quantum
            - "sdk/troubleshooting": Common issues and solutions.
            - "sdk/migration_guides": Instructions to migrate from older to newer versions of fujitsu-quantum.
            - "sdk/release_notes": Release notes (change logs) of fujitsu-quantum.
            - "mcp/installation": Instructions to install and set up the fujitsu-quantum-mcp MCP server.
            - "mcp/features": Descriptions of MCP server features: tools and resources.
            - "service_quotas": Limits of resources and operations.
            - "all": Complete Fujitsu Quantum Cloud documentation including usage of fujitsu-quantum.
    Returns:
        str: Documentation content in Markdown.
    Raises:
        ValueError: If the specified topic name is not valid.
    """
    # normalization
    topic = topic.lower().replace(" ", "_").replace("-", "_")

    if topic not in topic_to_url:
        raise ValueError(f"Invalid topic name: {topic}. Valid topics are: {', '.join(topic_to_url.keys())}")

    url = topic_to_url[topic]
    return await fetch(url)


@mcp.tool()
async def get_documentation_by_url(url: str) -> str:
    """Returns the Fujitsu Quantum Cloud documentation, including usage of fujitsu-quantum, for the specified URL in Markdown.

    Args:
        url (str): A URL starting with https://www.quantum.global.fujitsu.com/docs/.

    Returns:
        str: Documentation content in Markdown.
    """
    if not url.startswith(docs_base_url):
        raise ValueError(f"The URL must start with '{docs_base_url}'")

    if url.endswith(".html"):
        url = url.replace(".html", ".html.md")

    return await fetch(url)



@mcp.resource("docs:full")
async def full_documentation() -> str:
    """Returns the complete Fujitsu Quantum Cloud documentation, including usage of fujitsu-quantum, in Markdown.
    
    Returns:
        str: Full documentation content in Markdown.
    """
    return await get_documentation_by_topic("all")


def main():
    mcp.run()


if __name__ == "__main__":
    main()
