from setuptools import setup, find_packages

setup(
    name="sockett",
    version="0.3.2",  # <-- Burayı güncel versiyon ile değiştir
    packages=find_packages(),
    install_requires=[],
    description="Sockett - Tek satırda socket programlama",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Özgür",
    author_email="youremail@example.com",
    python_requires=">=3.7",
)
