from blues_lib.namespace.CommandName import CommandName
from blues_lib.command.NodeCommand import NodeCommand
from blues_lib.dao.material.MatQuerier import MatQuerier
from blues_lib.type.output.STDOut import STDOut

class Deduplicator(NodeCommand):

  NAME = CommandName.Material.DEDUPLICATOR
  

  def _invoke(self)->STDOut:
    field:str = self._summary.get('field','mat_url') # table's field
    key:str = self._summary.get('key','url') # entity's key
    entities:list[dict] = self._summary.get('entities',[])

    avail_entities = []
    unavail_entities = []

    querier = MatQuerier()
    for entity in entities:
      if not entity.get(key):
        unavail_entities.append(entity)
        continue

      if querier.exist(entity[key],field):
        unavail_entities.append(entity)
        continue

      avail_entities.append(entity)

    if avail_entities:
      return STDOut(200,'ok',avail_entities,unavail_entities)
    else:
      return STDOut(500,'all brief urls are duplicated',unavail_entities)



     