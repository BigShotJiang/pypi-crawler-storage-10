from blues_lib.command.NodeCommand import NodeCommand
from blues_lib.namespace.CommandName import CommandName
from blues_lib.type.output.STDOut import STDOut
from blues_lib.material.privatizer.Localizer import Localizer as LocalizerHandler

class Localizer(NodeCommand):
  
  NAME = CommandName.Material.LOCALIZER
  

  def _invoke(self)->STDOut:
    entities:list[dict] = self._summary.get('entities',[])
    if not entities:
      return STDOut(400,f'{self.NAME} entities is empty')

    request = {
      'config':{
        'max_image_count':10,
      },
      'entities':entities, # must be a list
    } 
    handler = LocalizerHandler(request)
    return handler.handle()

