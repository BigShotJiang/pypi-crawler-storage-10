# Copyright (c) Acconeer AB, 2022-2024
# All rights reserved

from . import linux, ubuntu_22_04
