# Copyright (c) Acconeer AB, 2022
# All rights reserved

from acconeer.exptool.flash._flasher import main


main()
