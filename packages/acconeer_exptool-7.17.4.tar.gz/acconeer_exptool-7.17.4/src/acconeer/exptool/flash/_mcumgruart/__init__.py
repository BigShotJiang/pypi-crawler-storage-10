# Copyright (c) Acconeer AB, 2023
# All rights reserved

from ._mcumgrflasher import McuMgrUartFlasher
from ._meta import ACCONEER_XB122_MODULE_PID
