# Copyright (c) Acconeer AB, 2023-2025
# All rights reserved

from .widgets import FlashWizard
