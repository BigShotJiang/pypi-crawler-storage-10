# Copyright (c) Acconeer AB, 2022
# All rights reserved


class HandledException(Exception):
    pass
