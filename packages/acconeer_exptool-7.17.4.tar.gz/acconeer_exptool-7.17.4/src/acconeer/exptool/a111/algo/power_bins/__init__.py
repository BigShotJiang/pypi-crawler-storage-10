# Copyright (c) Acconeer AB, 2022
# All rights reserved

from ._processor import get_sensor_config
