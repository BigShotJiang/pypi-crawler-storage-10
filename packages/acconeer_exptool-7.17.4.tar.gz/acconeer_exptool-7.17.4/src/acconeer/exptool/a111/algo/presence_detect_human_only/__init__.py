# Copyright (c) Acconeer AB, 2023
# All rights reserved

from ._processor import ProcessingConfiguration, Processor, get_sensor_config
