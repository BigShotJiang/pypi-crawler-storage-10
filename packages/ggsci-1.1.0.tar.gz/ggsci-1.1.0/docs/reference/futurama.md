# Futurama

::: ggsci.palettes
    options:
      members:
        - pal_futurama
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_futurama
        - scale_colour_futurama
        - scale_fill_futurama
      show_root_heading: true
      show_source: false
