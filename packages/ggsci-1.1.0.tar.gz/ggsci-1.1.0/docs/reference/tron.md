# TRON

::: ggsci.palettes
    options:
      members:
        - pal_tron
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_tron
        - scale_colour_tron
        - scale_fill_tron
      show_root_heading: true
      show_source: false
