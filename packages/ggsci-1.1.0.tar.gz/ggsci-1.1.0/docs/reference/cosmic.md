# COSMIC

::: ggsci.palettes
    options:
      members:
        - pal_cosmic
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_cosmic
        - scale_colour_cosmic
        - scale_fill_cosmic
      show_root_heading: true
      show_source: false
