# Star Trek

::: ggsci.palettes
    options:
      members:
        - pal_startrek
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_startrek
        - scale_colour_startrek
        - scale_fill_startrek
      show_root_heading: true
      show_source: false
