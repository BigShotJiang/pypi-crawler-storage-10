# UCSCGB

::: ggsci.palettes
    options:
      members:
        - pal_ucscgb
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_ucscgb
        - scale_colour_ucscgb
        - scale_fill_ucscgb
      show_root_heading: true
      show_source: false
