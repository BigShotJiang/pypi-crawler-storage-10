# Atlassian

::: ggsci.palettes
    options:
      members:
        - pal_atlassian
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_atlassian
        - scale_colour_atlassian
        - scale_fill_atlassian
      show_root_heading: true
      show_source: false
