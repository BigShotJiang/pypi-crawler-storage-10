# Simpsons

::: ggsci.palettes
    options:
      members:
        - pal_simpsons
      show_root_heading: true
      show_source: false

::: ggsci.scales
    options:
      members:
        - scale_color_simpsons
        - scale_colour_simpsons
        - scale_fill_simpsons
      show_root_heading: true
      show_source: false
