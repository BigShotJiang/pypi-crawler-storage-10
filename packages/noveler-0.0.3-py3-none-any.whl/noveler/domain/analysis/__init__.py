# Analysis Domain - 分析ドメイン
"""小説のアクセス解析と離脱率分析に関するドメインモデルとビジネスルール。"""

from noveler.domain.analysis import services

__all__ = ["services"]
