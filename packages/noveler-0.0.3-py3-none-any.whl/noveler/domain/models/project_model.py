# File: src/noveler/domain/models/project_model.py
# Purpose: Minimal project model stub required by legacy stepwise services.
# Context: Provides lightweight typing/backwards compatibility until the
#          domain model layer is fully restored under the A38 rewrite.

"""Lean project model utilised by legacy progressive execution services."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProjectModel:
    """Lightweight representation of a project configuration."""

    project_name: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)
    default_episode_length: int | None = None

    def get(self, key: str, default: Any = None) -> Any:
        """Dictionary-like accessor retained for compatibility."""
        return self.metadata.get(key, default)
