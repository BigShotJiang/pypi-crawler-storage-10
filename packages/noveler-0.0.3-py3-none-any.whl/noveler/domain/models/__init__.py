# File: src/noveler/domain/models/__init__.py
# Purpose: Package initializer for domain models to ensure compatibility with
#          legacy imports scattered across stepwise services.
# Context: Exports lightweight stubs until the full model layer is reinstated.

from .project_model import ProjectModel

__all__ = ["ProjectModel"]
