# File: src/noveler/application/adapters/mcp_protocol_adapter_factory.py
# Purpose: MCPプロトコルアダプター用ファクトリー（Application層での DDD違反解決）
# Context: Presentation層の Domain/Infrastructure層直接参照を Application層経由に統一

"""MCPプロトコルアダプター用ファクトリー。

Purpose:
    MCPプロトコルアダプター初期化時に、Domain層インターフェースおよび
    Infrastructure層ファクトリーへの参照を Application層経由で提供。
    Presentation層の DDD契約違反を解決し、層の依存方向を正規化。

Responsibility:
    - DI Factory の遅延インポート・提供
    - MCPコマンドサジェスターの生成・提供
    - 型安全性の維持（Protocol定義）
    - Domain/Infrastructure への参照カプセル化

Side Effects:
    None - 純粋な提供者パターン（副作用なし）
"""

from typing import Protocol


class MCPCommandSuggesterProtocol(Protocol):
    """MCPコマンドサジェスター用 Protocol。

    Purpose:
        型チェック時に MCPCommandSuggester の契約を定義。
        遅延インポート後の型安全性を確保。
    """

    def generate_usage_hint(self, command: str, error: str) -> str | None:
        """使用ヒントを生成。

        Args:
            command: MCP コマンド名
            error: エラーメッセージ

        Returns:
            使用ヒント文字列（生成できない場合は None）
        """


class MCPProtocolAdapterFactory:
    """MCPプロトコルアダプター用ファクトリー（Application層）

    Purpose:
        Domain層インターフェースおよび Infrastructure層ファクトリーへの参照を
        Application層経由で提供し、Presentation層の DDD契約違反を解決。

    Responsibility:
        - DI Factory の遅延インポート・提供
        - MCPコマンドサジェスターの生成
        - 型安全性の維持

    Side Effects:
        None - 純粋な提供者パターン
    """

    @staticmethod
    def create_di_factory():
        """DI Factory を取得（Infrastructure層からのラップ）

        Purpose:
            Infrastructure層の具体的な DI Factory実装を、
            型安全性を保ちながら返却する。

        Returns:
            IDIContainerFactory: Noveler プロジェクトの DI コンテナファクトリー

        Raises:
            ImportError: Infrastructure層の依存関係取得失敗時

        Side Effects:
            None - 遅延インポートで提供
        """
        from noveler.domain.interfaces.di_container_factory import (
            IDIContainerFactory,
        )
        from noveler.infrastructure.di.domain_di_container_factory import (
            get_domain_di_factory,
        )

        return get_domain_di_factory()

    @staticmethod
    def create_command_suggester() -> MCPCommandSuggesterProtocol:
        """MCPコマンドサジェスターを生成

        Purpose:
            Domain層の MCPCommandSuggester を、遅延インポートで提供。
            Presentation層が直接 Domain層にアクセスするのを防止。

        Returns:
            MCPCommandSuggesterProtocol: コマンドサジェスター実装

        Raises:
            ImportError: Domain層の依存関係取得失敗時

        Side Effects:
            None - インスタンス生成のみ
        """
        from noveler.domain.services.mcp_command_suggester import (
            MCPCommandSuggester,
        )

        return MCPCommandSuggester()
