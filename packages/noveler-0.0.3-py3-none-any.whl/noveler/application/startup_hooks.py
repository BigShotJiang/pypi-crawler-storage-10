# File: src/noveler/application/startup_hooks.py
# Purpose: Provide application-layer startup hooks that wire domain-level DI entry points.
# Context: Called during application package import to keep domain proxies initialized
#          without introducing hard dependencies on application modules.
"""Application-layer startup hooks for domain DI registration."""

from __future__ import annotations

from noveler.application.services.domain_entity_factory import DomainEntityFactoryService
from noveler.application.use_cases.step_processors.step_processor_factory import StepProcessorFactory
from noveler.domain.interfaces.domain_entity_factory_protocol import register_domain_entity_factory
from noveler.domain.interfaces.step_processor_factory_protocol import register_step_processor_factory

_initialized: bool = False


def initialize_domain_layer_di() -> None:
    """Register application-provided factories with domain-level DI proxies.

    The registration is idempotent so repeated invocations are safe. Domain proxies rely
    on these registrations to avoid legacy import fallbacks, but the fallbacks remain
    available until the migration completes.
    """
    global _initialized
    if _initialized:
        return

    entity_factory = DomainEntityFactoryService()
    register_domain_entity_factory(entity_factory)

    processor_factory = StepProcessorFactory()
    register_step_processor_factory(processor_factory)

    _initialized = True


__all__ = ["initialize_domain_layer_di"]

