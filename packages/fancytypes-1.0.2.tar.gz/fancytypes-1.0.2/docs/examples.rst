.. _examples_sec:

Examples
========

You can find examples of using the ``fancytypes`` library in a series of
notebooks found in the directory ``<root>/examples`` of the ``fancytypes``
repository, where ``<root>`` is the root of the repository. You can find the
repository `here <https://github.com/mrfitzpa/fancytypes>`_.
