License
=======

The source code documented here is published under a GNU General License Version
3.0 license, which we include below.

.. include:: ../LICENSE
    :literal:
