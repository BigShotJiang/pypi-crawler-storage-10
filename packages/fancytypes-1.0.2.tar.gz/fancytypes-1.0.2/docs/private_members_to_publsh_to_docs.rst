select implementation details of fancytypes
===========================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:
