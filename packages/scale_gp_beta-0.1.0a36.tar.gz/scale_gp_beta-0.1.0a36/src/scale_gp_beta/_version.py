# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "scale_gp_beta"
__version__ = "0.1.0-alpha.36"  # x-release-please-version
