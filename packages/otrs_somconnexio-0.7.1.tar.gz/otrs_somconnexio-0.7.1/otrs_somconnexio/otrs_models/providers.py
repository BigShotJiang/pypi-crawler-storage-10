class Providers:
    VALUES = [
        ("scJazztel", "SC-Jazztel (ADSL)"),
        ("scMM", "SC-MM"),
        ("scVdf", "SC-Vdf"),
        ("scOrange", "SC-Orange (Fiber)"),
    ]
