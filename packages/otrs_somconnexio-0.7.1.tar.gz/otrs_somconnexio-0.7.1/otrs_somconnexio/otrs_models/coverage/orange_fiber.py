class OrangeFiberCoverage:
    VALUES = [
        ("fibraFTTH", "Fibra (FTTH)"),
        ("NoRevisat", "No revisat"),
    ]
