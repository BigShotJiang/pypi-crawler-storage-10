class AsociatelFiberCoverage:
    VALUES = [
        ("fibraFTTH", "Fibra (FTTH)"),
        ("NEBAFTTH", "Fibra (NEBA)"),
        ("NoRevisat", "No revisat"),
    ]
