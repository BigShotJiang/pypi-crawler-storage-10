class VdfFiberCoverage:
    VALUES = [
        ("fibraCoaxial", "Fibra (coaxial)"),
        ("fibraFTTH", "Fibra (FTTH)"),
        ("NEBAFTTH", "Fibra (NEBA)"),
        ("NoFibraVdf", "No fibra"),
        ("NoRevisat", "No revisat"),
    ]
