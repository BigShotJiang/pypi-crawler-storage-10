class ResponsibleData:
    def __init__(
        self,
        email,
    ):
        self.email = email
