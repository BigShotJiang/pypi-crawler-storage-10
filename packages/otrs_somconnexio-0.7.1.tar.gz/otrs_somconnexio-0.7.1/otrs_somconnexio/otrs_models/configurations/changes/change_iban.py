class ChangeIbanTicketConfiguration:
    process_id = "Process-76f712cb8936190743ace3a886b3d167"
    activity_id = "Activity-621e28c842e6556964d4a6ce04286235"
    queue_id = 170
    subject = "Sol·licitud canvi de IBAN oficina virtual"
    type = "Petición"
    state = "new"
    priority = "3 normal"
