Party Carddav Client Module
###########################
