#!/bin/bash

# PyPI 发布脚本
# 使用方法: ./publish_to_pypi.sh

set -e  # 遇到错误立即退出

echo "📦 准备发布到 PyPI"
echo ""

# 激活虚拟环境
if [ -f .venv/bin/activate ]; then
    source .venv/bin/activate
    echo "✅ 已激活虚拟环境"
else
    echo "⚠️  未找到虚拟环境，正在创建..."
    python3 -m venv .venv
    source .venv/bin/activate
    echo "✅ 已创建并激活虚拟环境"
fi

# 确保虚拟环境内可使用 pip
if ! command -v pip >/dev/null 2>&1 || ! python -m pip --version >/dev/null 2>&1; then
    echo "⚠️  虚拟环境中未找到 pip，尝试重新安装..."
    python -m ensurepip --upgrade
    python -m pip install --upgrade pip
fi

# 检查是否安装了必要的工具
echo "📥 检查并安装必要的工具..."
python -m pip install --upgrade pip >/dev/null
if ! python -m twine --version &> /dev/null; then
    echo "❌ 未找到 twine，正在安装..."
    python -m pip install twine
fi

# 确认 twine 可用
python -c "import twine" >/dev/null 2>&1 || {
  echo "❌ twine 安装失败，请手动运行: source .venv/bin/activate && python -m pip install twine"
  exit 1
}

# 准备 PyPI 凭证
echo "🔐 准备 PyPI 凭证..."
if [ -z "$TWINE_USERNAME" ]; then
    read -p "PyPI 用户名 (使用 API Token 时请输入 __token__，直接回车默认): " TWINE_USERNAME_INPUT
    if [ -z "$TWINE_USERNAME_INPUT" ]; then
        TWINE_USERNAME="__token__"
        echo "➡️  使用默认用户名 __token__"
    else
        TWINE_USERNAME="$TWINE_USERNAME_INPUT"
    fi
    export TWINE_USERNAME
fi

if [ -z "$TWINE_PASSWORD" ]; then
    echo "ℹ️  如果使用 API Token，请在 PyPI 生成后粘贴完整 token"
    read -s -p "PyPI 密码或 API Token (输入时不会显示): " TWINE_PASSWORD
    echo
    export TWINE_PASSWORD
fi

echo "✅ 凭证已准备"
echo ""

# 清理旧的构建文件
echo "🧹 清理旧的构建文件..."
rm -rf dist/ build/ *.egg-info/
echo ""

# 构建包
echo "🔨 构建包..."
uv build
echo ""

# 检查构建文件
echo "✅ 构建完成，检查文件..."
ls -lh dist/
echo ""

# 上传到 PyPI
echo "🚀 上传到 PyPI..."
echo "⚠️  这是真实上传，请确认！"
read -p "继续? (y/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    python -m twine upload dist/*
    echo ""
    echo "✅ 发布成功！"
    echo ""
    echo "📦 用户可以立即使用以下命令安装："
    echo "   pip install futurmind-mcp"
else
    echo "❌ 已取消上传"
    exit 1
fi

