# Futurmind MCP 发布与分发指南

## 📦 打包文件

打包完成后，在 `dist/` 目录下会生成两个文件：

```
dist/
├── futurmind_mcp-0.1.0-py3-none-any.whl     # Wheel 格式（推荐）
└── futurmind_mcp-0.1.0.tar.gz                # Source distribution
```

## 🚀 分发方式

### 方式 1: 使用 Wheel 文件（推荐）

**优点**: 安装快速，包含所有依赖

```bash
# 用户安装
pip install futurmind_mcp-0.1.0-py3-none-any.whl
```

### 方式 2: 使用 Source Distribution

**优点**: 跨平台兼容性好

```bash
# 用户安装
pip install futurmind_mcp-0.1.0.tar.gz
```

## 📋 用户安装步骤

### 1. 下载安装包

```bash
# 下载 wheel 文件
wget https://your-domain/futurmind_mcp-0.1.0-py3-none-any.whl
```

### 2. 安装

```bash
# 使用虚拟环境（推荐）
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows

# 安装包
pip install futurmind_mcp-0.1.0-py3-none-any.whl
```

### 3. 验证安装

```bash
# 检查命令是否可用
python -m futurmind_mcp --help

# 或直接运行（stdio 模式）
python -m futurmind_mcp
```

## 🔧 Cursor 配置

安装完成后，在 Cursor 的 MCP 配置中添加：

```json
{
  "mcpServers": {
    "futurmind": {
      "command": "python",
      "args": ["-m", "futurmind_mcp"]
    }
  }
}
```

**注意**: Cursor 会自动在 stdio 模式下传递 API key，无需额外配置 headers。

## 🌐 远程 HTTP 部署

如果需要支持 HTTP 模式：

```bash
# 设置环境变量
export MCP_TRANSPORT=http
export MCP_HOST=0.0.0.0
export MCP_PORT=8000

# 运行服务
python -m futurmind_mcp
```

客户端配置：

```json
{
  "mcpServers": {
    "futurmind": {
      "url": "http://your-server:8000/sse",
      "headers": {
        "X-Api-Key": "your-api-key-here"
      }
    }
  }
}
```

## 📦 版本更新

当有新版本时：

```bash
# 卸载旧版本
pip uninstall futurmind-mcp

# 安装新版本
pip install futurmind_mcp-0.2.0-py3-none-any.whl
```

## 🐳 Docker 部署（可选）

如果需要容器化部署，可以使用提供的 Dockerfile：

```bash
# 构建镜像
docker build -t futurmind-mcp:0.1.0 .

# 运行容器
docker run -p 8000:8000 \
  -e MCP_TRANSPORT=http \
  -e MCP_HOST=0.0.0.0 \
  -e MCP_PORT=8000 \
  futurmind-mcp:0.1.0
```

## ⚠️ 注意事项

1. **Python 版本**: 需要 Python >= 3.10
2. **依赖**: 安装时会自动安装以下依赖：
   - `fastmcp>=0.1.0`
   - `mcp[cli]>=1.13.0`
   - `httpx>=0.27.0`

3. **API Key**: 
   - stdio 模式: 无需手动配置，Cursor 会自动传递
   - HTTP 模式: 必须在 headers 中提供 `X-Api-Key`

## 📞 技术支持

如有问题，请提供以下信息：
- Python 版本
- 安装方式
- 错误日志
- 配置内容

