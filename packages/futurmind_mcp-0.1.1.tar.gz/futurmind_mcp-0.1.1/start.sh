#!/bin/bash

# Futurmind MCP Server - Quick Start Script
# Usage: ./start.sh

set -e

echo "🚀 Starting Futurmind MCP Server..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found!"
    echo "📝 Creating .env from env.example..."
    
    if [ -f env.example ]; then
        cp env.example .env
        echo "✅ .env file created"
        echo "⚠️  Please edit .env and set your FUTURMIND_API_KEY"
        echo ""
        echo "Then run: ./start.sh"
        exit 1
    else
        echo "❌ env.example not found!"
        exit 1
    fi
fi

# Check if API key is set
if grep -q "your-api-key-here" .env; then
    echo "⚠️  Please set your FUTURMIND_API_KEY in .env file"
    exit 1
fi

# Check if docker-compose is available
if ! command -v docker-compose &> /dev/null; then
    echo "❌ docker-compose not found!"
    echo "Please install Docker and Docker Compose first"
    exit 1
fi

# Build and start services
echo "🏗️  Building Docker image..."
docker-compose build

echo "🎬 Starting services..."
docker-compose up -d

echo ""
echo "✅ Futurmind MCP Server is starting..."
echo ""
echo "📊 Checking service status..."
sleep 3
docker-compose ps

echo ""
echo "📝 To view logs, run:"
echo "   docker-compose logs -f"
echo ""
echo "🌐 MCP Server is available at:"
echo "   http://localhost:8000/mcp"
echo ""
echo "🛑 To stop the server, run:"
echo "   docker-compose down"
echo ""


