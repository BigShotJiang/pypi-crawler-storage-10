"""
Futurmind MCP Server Entry Point
Allows running as a module with: python -m futurmind_mcp
"""
from .server import serve
from .log import setup_logging


def main() -> None:
    """Futurmind MCP Server"""
    setup_logging()
    serve()


if __name__ == "__main__":
    main()
