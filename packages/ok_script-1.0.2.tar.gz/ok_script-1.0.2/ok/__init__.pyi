# This is a generated .pyi file for type hinting.
# It was generated from a .pyx file and contains documentation in both English and Chinese.

import re
import threading
from typing import Any, Callable, Dict, List, Optional, Pattern, Tuple, Union

import cv2
import numpy


# Forward declarations for classes defined elsewhere or as placeholders
class TaskExecutor: ...


class Handler: ...


class HwndWindow: ...


class Box: ...


class Feature: ...


class ExecutorOperation:
    """
    Provides basic operations for task execution, such as clicking, swiping, and sleeping.
    提供任务执行的基本操作，例如点击、滑动和休眠。
    """
    _executor: TaskExecutor
    logger: Any
    last_click_time: float

    def __init__(self, executor: TaskExecutor) -> None: ...

    def exit_is_set(self) -> bool:
        """
        Checks if the exit event has been set.
        检查退出事件是否已设置。

        Returns:
            bool:
                True if the exit event is set, otherwise False.
                如果退出事件已设置，则返回True，否则返回False。
        """
        ...

    def get_task_by_class(self, cls: type) -> Optional[Any]:
        """
        Finds and returns a task instance of a specific class.
        查找并返回特定类的任务实例。

        Args:
            cls (type):
                The class of the task to find.
                要查找的任务的类。

        Returns:
            Optional[Any]:
                The task instance if found, otherwise None.
                如果找到，则返回任务实例，否则返回None。
        """
        ...

    def box_in_horizontal_center(self, box: Box, off_percent: float = 0.02) -> bool:
        """
        Checks if a box is located in the horizontal center of the screen within a certain tolerance.
        检查一个框是否在屏幕的水平中心，并有一定的容差。

        Args:
            box (Box):
                The box to check.
                要检查的框。
            off_percent (float):
                The allowed offset percentage from the center.
                允许的中心偏移百分比。

        Returns:
            bool:
                True if the box is in the horizontal center, otherwise False.
                如果框在水平中心，则返回True，否则返回False。
        """
        ...

    @property
    def executor(self) -> TaskExecutor:
        """
        The task executor instance.
        任务执行器实例。
        """
        ...

    @property
    def debug(self) -> bool:
        """
        The debug mode flag.
        调试模式标志。
        """
        ...

    def clipboard(self) -> str:
        """
        Gets the content from the system clipboard.
        从系统剪贴板获取内容。

        Returns:
            str:
                The text content of the clipboard.
                剪贴板的文本内容。
        """
        ...

    def is_scene(self, the_scene: Any) -> bool:
        """
        Checks if the current scene is of a specific type.
        检查当前场景是否为特定类型。

        Args:
            the_scene (Any):
                The scene class or type to check against.
                要检查的场景类或类型。

        Returns:
            bool:
                True if the current scene matches the type, otherwise False.
                如果当前场景匹配类型，则返回True，否则返回False。
        """
        ...

    def reset_scene(self) -> None:
        """
        Resets the current scene and frame buffer.
        重置当前场景和帧缓冲区。
        """
        ...

    def click(self, x: Union[int, Box, List[Box]] = -1, y: int = -1, move_back: bool = False,
              name: Optional[str] = None, interval: float = -1, move: bool = True, down_time: float = 0.01,
              after_sleep: float = 0, key: str = 'left') -> bool:
        """
        Performs a click action at the specified coordinates or on a given Box object.
        在指定坐标或给定的Box对象上执行点击操作。

        Args:
            x (Union[int, Box, List[Box]]):
                The x-coordinate, a Box object, or a list of Box objects. If a Box is provided, y is ignored.
                x坐标、Box对象或Box对象列表。如果提供了Box，则忽略y。
            y (int):
                The y-coordinate for the click.
                点击的y坐标。
            move_back (bool):
                Whether to move the mouse back to its original position after the click.
                点击后是否将鼠标移回原始位置。
            name (Optional[str]):
                A name for the click action, used for logging.
                用于日志记录的点击操作名称。
            interval (float):
                The minimum time interval in seconds between consecutive clicks. If the time since the last click is less than this, the click is skipped.
                连续点击之间的最小时间间隔（秒）。如果距离上次点击的时间小于此值，则跳过本次点击。
            move (bool):
                Whether to move the cursor to the coordinates before clicking.
                点击前是否将光标移动到坐标处。
            down_time (float):
                The duration in seconds the mouse button is held down.
                鼠标按下的持续时间（秒）。
            after_sleep (float):
                The time in seconds to sleep after the click action.
                点击操作后休眠的时间（秒）。
            key (str):
                The mouse button to click ('left', 'right', 'middle').
                要点击的鼠标按钮（'left', 'right', 'middle'）。

        Returns:
            bool:
                True if the click was performed, False if it was skipped due to interval.
                如果执行了点击则返回True，如果因间隔而跳过则返回False。
        """
        ...

    def back(self, *args, **kwargs) -> None:
        """
        Simulates a 'back' action, typically by sending an 'ESC' key press.
        模拟一个“返回”操作，通常通过发送'ESC'键来实现。
        """
        ...

    def middle_click(self, *args, **kwargs) -> bool:
        """
        Performs a middle mouse button click. Accepts the same arguments as `click`.
        执行鼠标中键点击。接受与`click`方法相同的参数。
        """
        ...

    def right_click(self, *args, **kwargs) -> bool:
        """
        Performs a right mouse button click. Accepts the same arguments as `click`.
        执行鼠标右键点击。接受与`click`方法相同的参数。
        """
        ...

    def is_adb(self) -> bool:
        """
        Checks if the current device interaction is via ADB.
        检查当前设备交互是否通过ADB。

        Returns:
            bool:
                True if using ADB, otherwise False.
                如果使用ADB，则返回True，否则返回False。
        """
        ...

    def mouse_down(self, x: int = -1, y: int = -1, name: Optional[str] = None, key: str = "left") -> None:
        """
        Simulates pressing a mouse button down.
        模拟按下鼠标按钮。

        Args:
            x (int): The x-coordinate.
            y (int): The y-coordinate.
            name (Optional[str]): A name for the action, for logging.
            key (str): The mouse button to press down ('left', 'right').
        """
        ...

    def mouse_up(self, name: Optional[str] = None, key: str = "left") -> None:
        """
        Simulates releasing a mouse button.
        模拟释放鼠标按钮。

        Args:
            name (Optional[str]): A name for the action, for logging.
            key (str): The mouse button to release ('left', 'right').
        """
        ...

    def swipe_relative(self, from_x: float, from_y: float, to_x: float, to_y: float, duration: float = 0.5,
                       settle_time: float = 0) -> None:
        """
        Performs a swipe gesture using relative screen coordinates.
        使用相对屏幕坐标执行滑动操作。

        Args:
            from_x (float): Starting relative x-coordinate (0.0 to 1.0).
            from_y (float): Starting relative y-coordinate (0.0 to 1.0).
            to_x (float): Ending relative x-coordinate (0.0 to 1.0).
            to_y (float): Ending relative y-coordinate (0.0 to 1.0).
            duration (float): The duration of the swipe in seconds.
            settle_time (float): Time to pause at the end of the swipe before releasing, in seconds.
        """
        ...

    def input_text(self, text: str) -> None:
        """
        Inputs a string of text.
        输入一个文本字符串。

        Args:
            text (str): The text to input.
        """
        ...

    @property
    def hwnd(self) -> HwndWindow:
        """
        The HwndWindow object representing the target window.
        代表目标窗口的HwndWindow对象。
        """
        ...

    def scroll(self, x: int, y: int, count: int) -> None:
        """
        Performs a mouse scroll action at the specified coordinates.
        在指定坐标执行鼠标滚动操作。

        Args:
            x (int): The x-coordinate for the scroll.
            y (int): The y-coordinate for the scroll.
            count (int): The amount to scroll. Positive for up, negative for down.
        """
        ...

    def swipe(self, from_x: int, from_y: int, to_x: int, to_y: int, duration: float = 0.5, after_sleep: float = 0.1,
              settle_time: float = 0) -> None:
        """
        Performs a swipe gesture using absolute screen coordinates.
        使用绝对屏幕坐标执行滑动操作。

        Args:
            from_x (int): Starting x-coordinate.
            from_y (int): Starting y-coordinate.
            to_x (int): Ending x-coordinate.
            to_y (int): Ending y-coordinate.
            duration (float): The duration of the swipe in seconds.
            after_sleep (float): Time to sleep after the swipe completes.
            settle_time (float): Time to pause at the end of the swipe before releasing.
        """
        ...

    def screenshot(self, name: Optional[str] = None, frame: Optional[numpy.ndarray] = None, show_box: bool = False,
                   frame_box: Optional[Box] = None) -> None:
        """
        Takes a screenshot for debugging purposes.
        为调试目的截取屏幕截图。

        Args:
            name (Optional[str]): A name for the screenshot file.
            frame (Optional[numpy.ndarray]): An optional frame to save instead of the current one.
            show_box (bool): Whether to draw a box on the screenshot.
            frame_box (Optional[Box]): The box to draw.
        """
        ...

    def click_box_if_name_match(self, boxes: List[Box], names: Union[str, List[str], Pattern, List[Pattern]],
                                relative_x: float = 0.5, relative_y: float = 0.5) -> Optional[Box]:
        """
        Finds a box by name from a list and clicks it.
        从列表中按名称查找一个框并点击它。

        Args:
            boxes (List[Box]): The list of boxes to search through.
            names (Union[str, List[str]]): The name or names to match. Priority is given to the order in the list.
            relative_x (float): Relative x-position within the box to click (0.0 to 1.0).
            relative_y (float): Relative y-position within the box to click (0.0 to 1.0).

        Returns:
            Optional[Box]: The box that was clicked, or None if no match was found.
        """
        ...

    def box_of_screen(self, x: float, y: float, to_x: float = 1.0, to_y: float = 1.0, width: float = 0.0,
                      height: float = 0.0, name: Optional[str] = None, hcenter: bool = False,
                      confidence: float = 1.0) -> Box:
        """
        Creates a Box object using relative screen coordinates.
        使用相对屏幕坐标创建一个Box对象。

        Args:
            x (float): Top-left relative x-coordinate.
            y (float): Top-left relative y-coordinate.
            to_x (float): Bottom-right relative x-coordinate.
            to_y (float): Bottom-right relative y-coordinate.
            width (float): Relative width.
            height (float): Relative height.
            name (Optional[str]): A name for the box.
            hcenter (bool): If true, adjusts coordinates to be horizontally centered.
            confidence (float): The confidence score for the box.

        Returns:
            Box: The created Box object.
        """
        ...

    def sleep(self, timeout: float) -> bool:
        """
        Pauses execution for a specified duration, while checking for exit events.
        暂停执行指定的持续时间，同时检查退出事件。

        Args:
            timeout (float): The duration to sleep in seconds.

        Returns:
            bool: Always returns True.
        """
        ...

    def send_key(self, key: str, down_time: float = 0.02, interval: float = -1, after_sleep: float = 0) -> bool:
        """
        Sends a key press event.
        发送一个按键事件。

        Args:
            key (str): The key to press (e.g., 'a', 'enter', 'f1').
            down_time (float): The duration the key is held down.
            interval (float): Minimum interval between key presses.
            after_sleep (float): Time to sleep after the key press.

        Returns:
            bool: True if the key was sent, False if skipped due to interval.
        """
        ...

    def send_key_down(self, key: str) -> None:
        """
        Simulates pressing a key down.
        模拟按下键盘按键。

        Args:
            key (str): The key to press down.
        """
        ...

    def send_key_up(self, key: str) -> None:
        """
        Simulates releasing a key.
        模拟释放键盘按键。

        Args:
            key (str): The key to release.
        """
        ...

    def wait_until(self, condition: Callable, time_out: float = 0, pre_action: Optional[Callable] = None,
                   post_action: Optional[Callable] = None, settle_time: float = -1,
                   raise_if_not_found: bool = False) -> Any:
        """
        Waits until a condition is met or a timeout occurs.
        等待直到满足条件或超时。

        Args:
            condition (Callable): A function that returns a truthy value when the condition is met.
            time_out (float): The maximum time to wait in seconds.
            pre_action (Optional[Callable]): An action to perform before checking the condition in each loop.
            post_action (Optional[Callable]): An action to perform if the condition is not met in each loop.
            settle_time (float): Time to wait after the condition is first met to ensure stability.
            raise_if_not_found (bool): If True, raises an exception on timeout.

        Returns:
            Any: The result of the condition function, or None on timeout.
        """
        ...

    def wait_click_box(self, condition: Callable, time_out: float = 0, pre_action: Optional[Callable] = None,
                       post_action: Optional[Callable] = None, raise_if_not_found: bool = False) -> Any:
        """
        Waits for a box (returned by a condition) and then clicks it.
        等待一个框（由条件函数返回），然后点击它。

        Args:
            condition (Callable): A function that returns a Box object.
            time_out (float): The maximum time to wait.
            pre_action (Optional[Callable]): Action to perform before each check.
            post_action (Optional[Callable]): Action to perform after each failed check.
            raise_if_not_found (bool): If True, raises an exception on timeout.

        Returns:
            Any: The Box object that was clicked, or None.
        """
        ...

    def next_frame(self) -> numpy.ndarray:
        """
        Captures and returns the next frame from the device.
        捕获并返回设备的下一帧。

        Returns:
            numpy.ndarray: The captured frame.
        """
        ...

    @property
    def frame(self) -> numpy.ndarray:
        """
        The current captured frame.
        当前捕获的帧。
        """
        ...

    @staticmethod
    def draw_boxes(feature_name: Optional[str] = None, boxes: Optional[List[Box]] = None, color: str = "red",
                   debug: bool = True) -> None:
        """
        Draws boxes on the screen overlay for debugging.
        在屏幕覆盖层上绘制框以进行调试。

        Args:
            feature_name (Optional[str]): A name for the set of boxes.
            boxes (Optional[List[Box]]): A list of Box objects to draw.
            color (str): The color of the boxes.
            debug (bool): Only draw if debug mode is active.
        """
        ...


class FindFeature(ExecutorOperation):
    """
    Provides methods for finding features (template images) within the screen capture.
    提供在屏幕截图中查找特征（模板图像）的方法。
    """

    def find_feature(self, feature_name: Optional[Union[str, List[str]]] = None, horizontal_variance: float = 0,
                     vertical_variance: float = 0, threshold: float = 0, use_gray_scale: bool = False, x: float = -1,
                     y: float = -1, to_x: float = -1, to_y: float = -1, width: float = -1, height: float = -1,
                     box: Optional[Union[Box, str]] = None, canny_lower: int = 0, canny_higher: int = 0,
                     frame_processor: Optional[Callable] = None, template: Optional[numpy.ndarray] = None,
                     match_method: int = cv2.TM_CCOEFF_NORMED, screenshot: bool = False,
                     mask_function: Optional[Callable] = None, frame: Optional[numpy.ndarray] = None) -> List[Box]:
        """
        Finds occurrences of a feature (template image) in the current frame.
        在当前帧中查找特征（模板图像）的出现位置。

        Args:
            feature_name (Optional[Union[str, List[str]]]): The name of the feature or list of feature names to find.
            horizontal_variance (float): Allowed horizontal variance in the search area, as a percentage of screen width.
            vertical_variance (float): Allowed vertical variance in the search area, as a percentage of screen height.
            threshold (float): Confidence threshold for matching (0.0 to 1.0).
            use_gray_scale (bool): Convert images to grayscale for matching.
            x, y, to_x, to_y, width, height (float): Defines a relative search area.
            box (Optional[Union[Box, str]]): A specific Box object or box name to search within.
            canny_lower, canny_higher (int): Parameters for Canny edge detection if used.
            frame_processor (Optional[Callable]): A function to preprocess the frame before matching.
            template (Optional[numpy.ndarray]): An external template image to use instead of a pre-loaded feature.
            match_method (int): The template matching method from OpenCV.
            screenshot (bool): Take a screenshot for debugging this operation.
            mask_function (Optional[Callable]): A function to generate a mask for the template.
            frame (Optional[numpy.ndarray]): An external frame to search in, instead of the current one.

        Returns:
            List[Box]: A list of Box objects for each found match.
        """
        ...

    def get_feature_by_name(self, name: str) -> Optional[Feature]:
        """
        Retrieves a pre-loaded feature by its name.
        按名称检索预加载的特征。

        Args:
            name (str): The name of the feature.

        Returns:
            Optional[Feature]: The Feature object, or None if not found.
        """
        ...

    def get_box_by_name(self, name: str) -> Optional[Box]:
        """
        Retrieves a pre-defined box by its name.
        按名称检索预定义的框。

        Args:
            name (str): The name of the box.

        Returns:
            Optional[Box]: The Box object, or None if not found.
        """
        ...

    def wait_feature(self, feature: str, horizontal_variance: float = 0, vertical_variance: float = 0,
                     threshold: float = 0, time_out: float = 0, pre_action: Optional[Callable] = None,
                     post_action: Optional[Callable] = None, use_gray_scale: bool = False, box: Optional[Box] = None,
                     raise_if_not_found: bool = False, canny_lower: int = 0, canny_higher: int = 0,
                     settle_time: float = -1, frame_processor: Optional[Callable] = None) -> Any:
        """
        Waits for a specific feature to appear on the screen.
        等待特定特征出现在屏幕上。

        Args:
            feature (str): The name of the feature to wait for.
            ... (other args are passed to find_one): See find_one for details.
            time_out (float): Maximum time to wait in seconds.
            raise_if_not_found (bool): If True, raises an exception on timeout.

        Returns:
            Any: The result of the wait condition (the found Box), or None on timeout.
        """
        ...

    def wait_click_feature(self, feature: str, horizontal_variance: float = 0, vertical_variance: float = 0,
                           threshold: float = 0, relative_x: float = 0.5, relative_y: float = 0.5, time_out: float = 0,
                           pre_action: Optional[Callable] = None, post_action: Optional[Callable] = None,
                           box: Optional[Box] = None, raise_if_not_found: bool = True, use_gray_scale: bool = False,
                           canny_lower: int = 0, canny_higher: int = 0, click_after_delay: float = 0,
                           settle_time: float = -1, after_sleep: float = 0) -> bool:
        """
        Waits for a feature to appear and then clicks it.
        等待一个特征出现，然后点击它。

        Args:
            feature (str): The name of the feature to wait for and click.
            ... (other args): See wait_feature and click_box for details.

        Returns:
            bool: True if the feature was found and clicked, otherwise False.
        """
        ...

    def find_one(self, feature_name: Optional[str] = None, horizontal_variance: float = 0, vertical_variance: float = 0,
                 threshold: float = 0, use_gray_scale: bool = False, box: Optional[Box] = None, canny_lower: int = 0,
                 canny_higher: int = 0, frame_processor: Optional[Callable] = None,
                 template: Optional[numpy.ndarray] = None, mask_function: Optional[Callable] = None,
                 frame: Optional[numpy.ndarray] = None, match_method: int = cv2.TM_CCOEFF_NORMED,
                 screenshot: bool = False) -> Optional[Box]:
        """
        Finds the single best match for a feature.
        查找特征的单个最佳匹配。

        Args:
            ... (args): See find_feature for details.

        Returns:
            Optional[Box]: The Box of the best match, or None if no match is found.
        """
        ...


class OCR(FindFeature):
    """
    Provides Optical Character Recognition (OCR) capabilities.
    提供光学字符识别（OCR）功能。
    """
    ocr_default_threshold: float
    log_debug: bool

    def __init__(self, executor: TaskExecutor) -> None: ...

    def ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1,
            match: Optional[Union[str, List[str], Pattern, List[Pattern]]] = None, width: int = 0, height: int = 0,
            box: Optional[Union[Box, str]] = None, name: Optional[str] = None, threshold: float = 0,
            frame: Optional[numpy.ndarray] = None, target_height: int = 0, use_grayscale: bool = False,
            log: bool = False, frame_processor: Optional[Callable] = None, lib: str = 'default') -> List[Box]:
        """
        Performs OCR on a specified region of an image to find text.
        在图像的指定区域上执行OCR以查找文本。

        Args:
            x, y, to_x, to_y (float): Relative coordinates defining the search area.
            match (Optional[...]): A string or regex pattern to filter OCR results.
            width, height (int): Absolute pixel dimensions for the search area.
            box (Optional[Union[Box, str]]): A specific Box or box name to search within.
            name (Optional[str]): A name for the OCR operation for logging.
            threshold (float): The confidence threshold for recognized text.
            frame (Optional[numpy.ndarray]): An external frame to use for OCR.
            target_height (int): Resize the image region to this height before OCR for better accuracy.
            use_grayscale (bool): Convert the image to grayscale before OCR.
            log (bool): Log detailed information about the OCR operation.
            frame_processor (Optional[Callable]): A function to preprocess the image region.
            lib (str): The OCR library instance to use.

        Returns:
            List[Box]: A list of Box objects, each representing a piece of recognized text.
        """
        ...

    def wait_click_ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1, width: int = 0,
                       height: int = 0, box: Optional[Box] = None, name: Optional[str] = None,
                       match: Optional[Union[str, List[str], Pattern, List[Pattern]]] = None, threshold: float = 0,
                       frame: Optional[numpy.ndarray] = None, target_height: int = 0, time_out: float = 0,
                       raise_if_not_found: bool = False, recheck_time: float = 0, after_sleep: float = 0,
                       post_action: Optional[Callable] = None, log: bool = False, settle_time: float = -1,
                       lib: str = "default") -> Optional[List[Box]]:
        """
        Waits for specific text to appear via OCR and then clicks it.
        通过OCR等待特定文本出现，然后点击它。

        Args:
            ... (args): See ocr and wait_until for details.
            recheck_time (float): An additional delay before a final OCR check if the text is found.

        Returns:
            Optional[List[Box]]: The list of Box objects that were clicked, or None.
        """
        ...

    def wait_ocr(self, x: float = 0, y: float = 0, to_x: float = 1, to_y: float = 1, width: int = 0, height: int = 0,
                 name: Optional[str] = None, box: Optional[Box] = None,
                 match: Optional[Union[str, List[str], Pattern, List[Pattern]]] = None, threshold: float = 0,
                 frame: Optional[numpy.ndarray] = None, target_height: int = 0, time_out: float = 0,
                 post_action: Optional[Callable] = None, raise_if_not_found: bool = False, log: bool = False,
                 settle_time: float = -1, lib: str = "default") -> Optional[List[Box]]:
        """
        Waits for specific text to be found by OCR.
        等待通过OCR找到特定文本。

        Args:
            ... (args): See ocr and wait_until for details.

        Returns:
            Optional[List[Box]]: The list of found text boxes, or None on timeout.
        """
        ...


class BaseTask(OCR):
    """
    The base class for all tasks, providing common functionality.
    所有任务的基类，提供通用功能。
    """
    name: str
    description: str
    _enabled: bool
    config: Any
    info: Dict[str, Any]
    default_config: Dict[str, Any]
    config_description: Dict[str, str]
    config_type: Dict[str, Any]
    _paused: bool
    lock: threading.Lock
    _handler: Optional[Handler]
    running: bool
    exit_after_task: bool
    trigger_interval: bool
    last_trigger_time: float
    start_time: float
    icon: Any
    supported_languages: List[str]

    def __init__(self, executor: Optional[TaskExecutor] = None) -> None: ...

    def run_task_by_class(self, cls: type) -> None:
        """
        Executes another task identified by its class.
        执行由其类标识的另一个任务。

        Args:
            cls (type): The class of the task to run.
        """
        ...

    def post_init(self) -> None:
        """
        Called after the task is fully initialized. Can be overridden for custom setup.
        在任务完全初始化后调用。可以被覆盖以进行自定义设置。
        """
        ...

    def tr(self, message: str) -> str:
        """
        Translates a given message string.
        翻译给定的消息字符串。

        Args:
            message (str): The message key to translate.

        Returns:
            str: The translated string.
        """
        ...

    def get_status(self) -> str:
        """
        Gets the current status of the task.
        获取任务的当前状态。

        Returns:
            str: The status string (e.g., "Running", "Paused", "Not Started").
        """
        ...

    def enable(self) -> None:
        """
        Enables the task, making it eligible to run.
        启用任务，使其有资格运行。
        """
        ...

    @property
    def handler(self) -> Handler:
        """
        A dedicated handler for posting delayed or asynchronous actions for this task.
        用于发布此任务的延迟或异步操作的专用处理程序。
        """
        ...

    def pause(self) -> None:
        """
        Pauses the execution of this task.
        暂停此任务的执行。
        """
        ...

    def unpause(self) -> None:
        """
        Resumes a paused task.
        恢复已暂停的任务。
        """
        ...

    @property
    def paused(self) -> bool:
        """
        Checks if the task is currently paused.
        检查任务当前是否已暂停。
        """
        ...

    def log_info(self, message: str, notify: bool = False) -> None:
        """
        Logs an informational message.
        记录一条信息性消息。

        Args:
            message (str): The message to log.
            notify (bool): If True, also sends a desktop notification.
        """
        ...

    def log_debug(self, message: str, notify: bool = False) -> None:
        """
        Logs a debug message.
        记录一条调试消息。

        Args:
            message (str): The message to log.
            notify (bool): If True, also sends a desktop notification.
        """
        ...

    def log_error(self, message: str, exception: Optional[Exception] = None, notify: bool = False) -> None:
        """
        Logs an error message.
        记录一条错误消息。

        Args:
            message (str): The error message.
            exception (Optional[Exception]): An associated exception object.
            notify (bool): If True, also sends an error notification.
        """
        ...

    @property
    def enabled(self) -> bool:
        """
        Checks if the task is currently enabled.
        检查任务当前是否已启用。
        """
        ...

    def info_set(self, key: str, value: Any) -> None:
        """
        Sets a key-value pair in the task's info dictionary for display in the UI.
        在任务的信息字典中设置一个键值对，用于在UI中显示。

        Args:
            key (str): The key.
            value (Any): The value.
        """
        ...

    def disable(self) -> None:
        """
        Disables the task, preventing it from running.
        禁用任务，阻止其运行。
        """
        ...

    @property
    def hwnd_title(self) -> str:
        """
        Gets the title of the target window.
        获取目标窗口的标题。
        """
        ...

    def run(self) -> Any:
        """
        The main execution logic of the task. This method should be overridden by subclasses.
        任务的主要执行逻辑。此方法应由子类覆盖。
        """
        ...

    def trigger(self) -> bool:
        """
        For trigger tasks, this method determines if the task should run.
        对于触发器任务，此方法确定任务是否应该运行。

        Returns:
            bool: True if the task's conditions are met, otherwise False.
        """
        ...

    def on_destroy(self) -> None:
        """
        Cleanup logic to be executed when the task is destroyed.
        任务销毁时要执行的清理逻辑。
        """
        ...

    def on_create(self) -> None:
        """
        Initialization logic to be executed when the task is created.
        任务创建时要执行的初始化逻辑。
        """
        ...

    def find_boxes(self, boxes: List[Box], match: Optional[Union[str, List[str], Pattern, List[Pattern]]] = None,
                   boundary: Optional[Union[Box, str]] = None) -> List[Box]:
        """
        Filters a list of boxes by name and/or boundary.
        按名称和/或边界过滤框列表。

        Args:
            boxes (List[Box]): The initial list of boxes.
            match (Optional[...]): A name or regex to filter boxes.
            boundary (Optional[Union[Box, str]]): A Box or box name to define a boundary.

        Returns:
            List[Box]: The filtered list of boxes.
        """
        ...