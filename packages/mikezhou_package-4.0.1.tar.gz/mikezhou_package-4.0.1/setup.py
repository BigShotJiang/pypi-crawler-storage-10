# !/usr/bin/python3
# -*- coding: utf-8 -*-
# @Author : Mike Zhou
# @Email : 公众号：测试开发技术
# @File : setup.py.py

from setuptools import setup,find_packages

with open("README.rst", "r") as f:
  long_description = f.read()

setup(name='mikezhou_package',  # 包名
      version='4.0.1',  # 版本号
      description='全栈测试开发训练营Python示例',
      long_description=long_description,
      author='mikezhou_talk',
      author_email='76235765@qq.com',
      url='https://kjdaohang.com',
      install_requires=[],
      license='MIT License',
      packages=find_packages(),
      platforms=["all"],
      classifiers=[
          'Intended Audience :: Developers',
          'Operating System :: OS Independent',
          'Natural Language :: Chinese (Simplified)',
          'Programming Language :: Python',
          'Programming Language :: Python :: 2',
          'Programming Language :: Python :: 2.5',
          'Programming Language :: Python :: 2.6',
          'Programming Language :: Python :: 2.7',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.5',
          'Programming Language :: Python :: 3.6',
          'Programming Language :: Python :: 3.7',
          'Programming Language :: Python :: 3.8',
          'Topic :: Software Development :: Libraries'
      ],
      entry_points={
          'console_scripts': [
              'mycli=generate_data:generate_data',
          ]
      },
      )