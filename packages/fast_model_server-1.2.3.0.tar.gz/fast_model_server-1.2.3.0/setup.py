#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""
Setup script.

Authors: fubo
Date:    2022/02/10 08:28:20
"""

import setuptools

setuptools.setup(setup_cfg=True)

