# !/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
服务入口

Authors: fubo
Date: 2022/03/04 00:00:00
"""
import os
import sys
import re
import inspect
import logging
import redis
from logging.handlers import TimedRotatingFileHandler
from fastapi import FastAPI
from fastapi.middleware.wsgi import WSGIMiddleware
from starlette.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from importlib import import_module


class RedisHandler(logging.Handler):
    def __init__(self, host: str, port: int, db: int, password: str, prefix: str='logging', id_filter: str=""):
        super().__init__()
        self.redis_conn = redis.StrictRedis(host=host, port=port, db=db, password=password)
        self.prefix = prefix
        self.id_filter = id_filter

    def emit(self, record):
        message = self.format(record)
        if self.id_filter == "":
            self.redis_conn.lpush(self.prefix, message)
            return None

        session_ids = re.findall(self.id_filter, record.message)
        if len(session_ids) == 0:
            return None
        else:
            self.redis_conn.lpush(f"{self.prefix}:{session_ids[0]}", message)


class Application(object):
    def __init__(
            self,
            server_path: str,
            ui_path: str = "",
            logging_log_file: str = "",
            logging_backup_count=0,
            logging_output_type="console",
            logging_redis_host="",
            logging_redis_port=0,
            logging_redis_db=0,
            logging_redis_password="",
            logging_redis_prefix="",
            logging_redis_session_id_filter=""
    ):
        self.server_path = server_path
        Application.set_log(
            logging_log_file=logging_log_file,
            logging_backup_count=logging_backup_count,
            logging_output_type=logging_output_type,
            logging_redis_host=logging_redis_host,
            logging_redis_port=logging_redis_port,
            logging_redis_db=logging_redis_db,
            logging_redis_password=logging_redis_password,
            logging_redis_prefix=logging_redis_prefix,
            logging_redis_session_id_filter=logging_redis_session_id_filter
        )
        self.app = FastAPI()
        self.register()
        if type(ui_path) is str and ui_path != "" and "/" in ui_path and ui_path.index("/") == 0:
            self.add_ui()
        self.add_dynamic_web()

    @staticmethod
    def set_log(
            logging_log_file: str = "",
            logging_backup_count=0,
            logging_output_type="console",
            logging_redis_host="",
            logging_redis_port=0,
            logging_redis_db=0,
            logging_redis_password="",
            logging_redis_prefix="",
            logging_redis_session_id_filter=""
    ):
        """
        设置日志
        :param logging_log_file: 日志文件名
        :param logging_backup_count: 日志保留数
        :param logging_output_type: 日志输出类型（console、file、redis）
        :param logging_redis_host: redis host
        :param logging_redis_port: redis port
        :param logging_redis_db: redis db
        :param logging_redis_password: redis password
        :param logging_redis_prefix: redis key前缀
        :param logging_redis_session_id_filter: redis session id
        :return: 队列中无数据情况下，返回空字符串
        """
        log_format = "%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s"

        if logging_output_type == "console":
            logging.basicConfig(level=logging.INFO, format=log_format, stream=sys.stderr)
            return

        if logging_output_type == "file":
            log_file_handler = TimedRotatingFileHandler(
                filename=logging_log_file, when="D", interval=1,backupCount=logging_backup_count
            )
            log_file_handler.setFormatter(logging.Formatter(log_format))
            logging.basicConfig(level=logging.INFO, handlers=[log_file_handler, logging.StreamHandler()])
            return

        if logging_output_type == "redis":
            logging.basicConfig(
                level=logging.INFO, format=log_format,
                handlers=[
                    RedisHandler(
                        host=logging_redis_host,
                        port=logging_redis_port,
                        db=logging_redis_db,
                        password=logging_redis_password,
                        prefix=logging_redis_prefix,
                        id_filter=logging_redis_session_id_filter
                    ),
                    logging.StreamHandler()
                ]
            )
            return

        logging.basicConfig(level=logging.INFO, format=log_format, stream=sys.stderr)

    def register(self):
        """
        查找routers下面所有的router包，注册router
        :return:
        """
        routers_path = "%s/routers" % self.server_path
        packages = filter(
            lambda x: (
                    (not x.startswith("__")) and (not x.endswith("__")) and os.path.isdir("%s/%s" % (routers_path, x))
            ), [package_name for package_name in os.listdir(routers_path)]
        )
        for package_name in packages:
            import_module("routers.%s.router" % package_name)
            for name, cls in inspect.getmembers(sys.modules["routers.%s.router" % package_name]):
                if inspect.isclass(cls) and name == "Router":
                    router = cls()
                    self.app.include_router(router.router, prefix="")
                    # self.app.include_router(router.router, prefix="/%s" % router.name)

    def add_ui(self, ui_path: str = "/"):
        """
        添加前端页面
        :param ui_path: 前端UI映射的页面路径
        """
        # 注册跨域
        self.app.add_middleware(
            CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
        )

        # 挂载前端页面
        self.app.mount(ui_path, StaticFiles(directory="static"), name="static")

    def add_dynamic_web(self):
        """
        添加web页基础库
        """
        if not os.path.exists(self.server_path + "/web"):
            return

        web_path = "%s/web" % self.server_path
        packages = filter(
            lambda x: (
                    (not x.startswith("__")) and (not x.endswith("__")) and (not os.path.isdir("%s/%s" % (web_path, x)))
            ), [package_name for package_name in os.listdir(web_path)]
        )
        for package_file_name in packages:
            package_name = ".".join(package_file_name.split(".")[:-1])
            import_module("web.%s" % package_name)
            for name, cls in inspect.getmembers(sys.modules["web.%s" % package_name]):
                if inspect.isclass(cls) and name == "Web":
                    self.app.mount("/%s" % package_name, WSGIMiddleware(cls.application.server))
