"""Physics-related definitions package."""
