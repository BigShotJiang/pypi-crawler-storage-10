"""Exception thrown by the AEAT client"""


class AeatException(RuntimeError):
    """Exception thrown by the AEAT client"""

    pass
