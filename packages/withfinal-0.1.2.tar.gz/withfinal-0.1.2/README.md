# This is just a simple code from try - finally :

## install

```cmd
pip install withFinal
```

## usage

```python
from Final import Final
import sys

def doSomething() :
    print("doSomething")

with Final :
    doSomething()
    print("This is same as 'finally'")

with Final :
    print("Final = FIFO(Queue)")

print(10)

sys.exit()

# output
>>> 10
>>> doSomething
>>> This is same as 'finally'
>>> Final = FIFO(Queue)
```

#### Note
- try use `finally` without `try`!