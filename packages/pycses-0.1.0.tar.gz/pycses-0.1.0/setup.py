from setuptools import setup, find_packages


with open("README.md", "r", encoding="utf-8") as fp:
    long_description = fp.read()

with open("requirements.txt", "r", encoding="utf-8") as fp:
    requirements = [line.strip() for line in fp if line.strip() and not line.startswith("#")]
with open("./docs/requirements.txt", "r", encoding="utf-8") as fp:
    docs_requirements = [line.strip() for line in fp if line.strip() and not line.startswith("#")]

setup(
    name='pycses',
    version='0.1.0',
    author='MacrosMeng',
    author_email='meng-yc@outlook.com',
    description='CSES access framework for Python, refactored by MacrosMeng.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/MacroMeng/cseslib4py',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.9',
    install_requires=requirements,
    extras_require={
        'docs': docs_requirements
    },
    project_urls={
        'Bug Reports': 'https://github.com/MacroMeng/cseslib4py/issues',
        'Source': 'https://github.com/MacroMeng/cseslib4py',
        'Documentation': 'https://cseslib4py.readthedocs.io/',
    },
)