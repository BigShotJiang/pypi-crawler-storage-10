from .android_ui_library import AndroidUiAutomation

# Define escopo global para Robot Framework
AndroidUiAutomation.ROBOT_LIBRARY_SCOPE = "GLOBAL"
