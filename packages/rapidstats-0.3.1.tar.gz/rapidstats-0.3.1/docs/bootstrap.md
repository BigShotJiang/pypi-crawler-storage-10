::: rapidstats._bootstrap
