import uuid
import json
import inspect
import logging
from datetime import datetime
from typing import Dict, Any, Optional, Callable
import requests

from .secret_util import SecretUtil

logger = logging.getLogger("PluginCaller")


def rpc_class(plugin_name: str):
    """
    RPC类注解，指定插件名称
    
    Args:
        plugin_name: 插件名称
    """
    def decorator(cls):
        cls._rpc_class_metadata = {
            "plugin_name": plugin_name
        }
        return cls
    return decorator


def rpc_method(method_name: str = None, endpoint: str = "/api/v1/call", timeout: int = 30):
    """
    RPC方法注解，配置调用参数
    
    Args:
        method_name: 远程方法名，如果为None则使用函数名
        endpoint: API端点
        timeout: 调用超时时间（秒）
    """
    def decorator(func):
        func._rpc_metadata = {
            "method_name": method_name or func.__name__,
            "endpoint": endpoint,
            "timeout": timeout
        }
        return func
    return decorator


class RPCCallerBase:
    """
    RPC调用基类，自动处理注解方法的RPC调用
    """
    
    def __init__(self, plugin_manager, secret_key: str = None):
        """
        初始化RPC调用器
        
        Args:
            plugin_manager: 插件管理器实例
            secret_key: 加密密钥
        """
        self.plugin_manager = plugin_manager
        self.secret_util = SecretUtil(secret_key)
        self._plugin_name = self._get_plugin_name()
        self._base_url = None
        self._session = requests.Session()
        self._initialize_base_url()
    
    def _get_plugin_name(self) -> str:
        """从类注解获取插件名称"""
        return getattr(self.__class__, '_rpc_class_metadata', {}).get('plugin_name')
    
    def _initialize_base_url(self):
        """初始化插件的基础URL"""
        if not self._plugin_name:
            logger.warning("未设置插件名称，请使用@rpc_class注解")
            return
            
        port = self.plugin_manager.get_service_port(self._plugin_name)
        if port:
            self._base_url = f"http://127.0.0.1:{port}"
            logger.info(f"初始化插件 {self._plugin_name} 调用器，地址: {self._base_url}")
        else:
            logger.warning(f"无法获取插件 {self._plugin_name} 的端口，插件可能未运行")
    
    def __getattribute__(self, name: str):
        """拦截方法调用，自动处理RPC调用"""
        try:
            attr = object.__getattribute__(self, name)
            
            # 如果是普通方法或属性，直接返回
            if not callable(attr) or not hasattr(attr, '_rpc_metadata'):
                return attr
                
            # 如果是RPC方法，返回包装函数
            def rpc_wrapper(*args, **kwargs):
                return self._call_rpc_method(attr, *args, **kwargs)
                
            return rpc_wrapper
            
        except AttributeError:
            # 如果属性不存在，返回默认值
            return object.__getattribute__(self, name)
    
    def _call_rpc_method(self, method: Callable, *args, **kwargs) -> Dict[str, Any]:
        """
        执行RPC调用
        
        Args:
            method: 被调用的方法
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            dict: 统一格式的响应结果
        """
        if not self._base_url:
            return self._build_error_response("插件未运行或无法获取服务地址")
        
        metadata = method._rpc_metadata
        method_name = metadata['method_name']
        endpoint = metadata['endpoint']
        timeout = metadata['timeout']
        
        try:
            # 构建参数
            params = self._build_params(method, args, kwargs)
            
            # 执行调用
            return self._execute_call(method_name, params, endpoint, timeout)
            
        except Exception as e:
            logger.error(f"RPC调用异常: {str(e)}")
            return self._build_error_response(f"调用失败: {str(e)}")
    
    def _build_params(self, method: Callable, args: tuple, kwargs: dict) -> Dict[str, Any]:
        """
        根据方法签名构建参数
        
        Args:
            method: 被调用的方法
            args: 位置参数
            kwargs: 关键字参数
            
        Returns:
            dict: 参数字典
        """
        try:
            # 获取方法参数信息
            sig = inspect.signature(method)
            parameters = list(sig.parameters.keys())
            
            # 跳过第一个参数（self）
            if parameters and parameters[0] == 'self':
                parameters = parameters[1:]
            
            params = {}
            
            # 处理位置参数
            for i, param_name in enumerate(parameters):
                if i < len(args):
                    params[param_name] = args[i]
                elif param_name in kwargs:
                    params[param_name] = kwargs[param_name]
                elif sig.parameters[param_name].default != inspect.Parameter.empty:
                    # 使用默认值
                    params[param_name] = sig.parameters[param_name].default
            
            # 处理额外的关键字参数
            params.update(kwargs)
            
            return params
            
        except Exception as e:
            logger.error(f"参数构建失败: {str(e)}")
            return {}
    
    def _execute_call(self, method_name: str, params: Dict[str, Any], 
                     endpoint: str, timeout: int) -> Dict[str, Any]:
        """
        执行实际的RPC调用
        
        Args:
            method_name: 方法名
            params: 参数字典
            endpoint: API端点
            timeout: 超时时间
            
        Returns:
            dict: 统一格式的响应结果
        """
        request_id = str(uuid.uuid4())
        
        try:
            # 构建请求数据
            request_data = {
                "class": self.__class__.__module__ + "." + self.__class__.__name__,
                "method": method_name,
                "params": params,
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id
            }
            
            # 加密请求数据
            encrypted_data = self.secret_util.encrypt_data(request_data)
            if not encrypted_data:
                return self._build_error_response("请求数据加密失败", request_id)
            
            # 发送请求
            url = f"{self._base_url}{endpoint}"
            payload = {
                "data": encrypted_data
            }
            
            logger.debug(f"发送RPC请求到 {url}, 方法: {method_name}")
            response = self._session.post(url, json=payload, timeout=timeout)
            
            if response.status_code != 200:
                return self._build_error_response(
                    f"HTTP错误: {response.status_code}", request_id
                )
            
            # 解析响应
            response_data = response.json()
            if not response_data.get("success"):
                return self._build_error_response(
                    response_data.get("message", "调用失败"), 
                    request_id
                )
            
            # 解密响应数据
            encrypted_response = response_data.get("data")
            if encrypted_response:
                decrypted_response = self.secret_util.decrypt_data(encrypted_response)
                if decrypted_response:
                    try:
                        response_data["data"] = json.loads(decrypted_response)
                    except json.JSONDecodeError:
                        response_data["data"] = decrypted_response
            
            # 确保响应包含必要字段
            if "request_id" not in response_data:
                response_data["request_id"] = request_id
            if "plugin" not in response_data:
                response_data["plugin"] = self._plugin_name
            if "method" not in response_data:
                response_data["method"] = method_name
                
            return response_data
            
        except requests.exceptions.Timeout:
            return self._build_error_response("请求超时", request_id)
        except requests.exceptions.ConnectionError:
            return self._build_error_response("连接失败", request_id)
        except Exception as e:
            return self._build_error_response(f"调用异常: {str(e)}", request_id)
    
    def _build_success_response(self, data: Any, request_id: str = None) -> Dict[str, Any]:
        """
        构建成功响应
        
        Args:
            data: 返回数据
            request_id: 请求ID
            
        Returns:
            dict: 成功响应
        """
        return {
            "success": True,
            "data": data,
            "message": "调用成功",
            "timestamp": datetime.now().isoformat(),
            "request_id": request_id or str(uuid.uuid4()),
            "plugin": self._plugin_name
        }
    
    def _build_error_response(self, message: str, request_id: str = None) -> Dict[str, Any]:
        """
        构建错误响应
        
        Args:
            message: 错误信息
            request_id: 请求ID
            
        Returns:
            dict: 错误响应
        """
        return {
            "success": False,
            "data": None,
            "message": message,
            "timestamp": datetime.now().isoformat(),
            "request_id": request_id or str(uuid.uuid4()),
            "plugin": self._plugin_name
        }
    
    def get_available_methods(self) -> list:
        """
        获取可用的RPC方法列表
        
        Returns:
            list: 方法名列表
        """
        methods = []
        for name in dir(self):
            attr = getattr(self, name)
            if callable(attr) and hasattr(attr, '_rpc_metadata'):
                methods.append(attr._rpc_metadata['method_name'])
        return methods
    
    def validate_connection(self) -> bool:
        """
        验证与插件的连接
        
        Returns:
            bool: 连接是否正常
        """
        if not self._base_url:
            return False
        
        try:
            response = self._session.get(f"{self._base_url}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
