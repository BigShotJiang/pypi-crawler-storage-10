# Import some random modules
from builtins import object
from time import *
from fandango import objects


def dummy_function():
    pass


class DummyClass(object):
    pass
