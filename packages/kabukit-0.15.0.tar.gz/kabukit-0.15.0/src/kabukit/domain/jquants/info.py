from __future__ import annotations

from kabukit.domain.base import Base


class Info(Base):
    pass
