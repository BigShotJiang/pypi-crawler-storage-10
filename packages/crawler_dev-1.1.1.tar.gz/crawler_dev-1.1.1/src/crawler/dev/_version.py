# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "crawler.dev"
__version__ = "1.1.1"  # x-release-please-version
