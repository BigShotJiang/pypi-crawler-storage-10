//! Nearest-neighbor interpolation/extrapolation on a rectilinear grid.
//!
//! ```rust
//! use interpn::nearest::rectilinear;
//!
//! // Define a grid
//! let x = [1.0_f64, 1.2, 2.0];
//! let y = [1.0_f64, 1.3, 1.5];
//!
//! // Grid input for rectilinear method
//! let grids = &[&x[..], &y[..]];
//!
//! // Values at grid points
//! let z = [2.0; 9];
//!
//! // Points to interpolate/extrapolate
//! let xobs = [0.0_f64, 5.0];
//! let yobs = [-1.0, 3.0];
//! let obs = [&xobs[..], &yobs[..]];
//!
//! // Storage for output
//! let mut out = [0.0; 2];
//!
//! // Do interpolation, allocating for the output for convenience
//! rectilinear::interpn_alloc(grids, &z, &obs).unwrap();
//! ```
use crate::index_arr_fixed_dims;
use crunchy::unroll;
use num_traits::Float;

/// Evaluate multicubic interpolation on a regular grid in up to 6 dimensions.
/// Assumes C-style ordering of vals (z(x0, y0), z(x0, y1), ..., z(x0, yn), z(x1, y0), ...).
///
/// This is a convenience function; best performance will be achieved by using the exact right
/// number for the N parameter, as this will slightly reduce compute and compile times.
///
/// While this method initializes the interpolator struct on every call, the overhead of doing this
/// is minimal even when using it to evaluate one observation point at a time.
pub fn interpn<T: Float>(
    grids: &[&[T]],
    vals: &[T],
    obs: &[&[T]],
    out: &mut [T],
) -> Result<(), &'static str> {
    let ndims = grids.len();
    if grids.len() != ndims || obs.len() != ndims {
        return Err("Dimension mismatch");
    }
    match ndims {
        1 => NearestRectilinear::<'_, T, 1>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        2 => NearestRectilinear::<'_, T, 2>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        3 => NearestRectilinear::<'_, T, 3>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        4 => NearestRectilinear::<'_, T, 4>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        5 => NearestRectilinear::<'_, T, 5>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        6 => NearestRectilinear::<'_, T, 6>::new(grids.try_into().unwrap(), vals)?
            .interp(obs.try_into().unwrap(), out),
        _ => Err("Dimension exceeds maximum (6)."),
    }?;

    Ok(())
}

/// Evaluate interpolant, allocating a new Vec for the output.
///
/// For best results, use the `interpn` function with preallocated output;
/// allocation has a significant performance cost, and should be used sparingly.
#[cfg(feature = "std")]
pub fn interpn_alloc<T: Float>(
    grids: &[&[T]],
    vals: &[T],
    obs: &[&[T]],
) -> Result<Vec<T>, &'static str> {
    let mut out = vec![T::zero(); obs[0].len()];
    interpn(grids, vals, obs, &mut out)?;
    Ok(out)
}

pub use crate::multilinear::rectilinear::check_bounds;

/// An arbitrary-dimensional multilinear interpolator / extrapolator on a rectilinear grid.
///
/// Assumes C-style ordering of vals (z(x0, y0), z(x0, y1), ..., z(x0, yn), z(x1, y0), ...).
/// Assumes grids are monotonically _increasing_. Checking this is expensive, and is
/// left to the user.
///
/// Operation Complexity
/// * O(2^ndims) for interpolation and extrapolation in all regions.
///
/// Memory Complexity
/// * Peak stack usage is O(N), which is minimally O(ndims).
/// * While evaluation is recursive, the recursion has constant
///   max depth of N, which provides a guarantee on peak
///   memory usage.
///
/// Timing
/// * Timing determinism is very tight, but not guaranteed due to the use of a bisection search.
pub struct NearestRectilinear<'a, T: Float, const N: usize> {
    /// x, y, ... coordinate grids, each entry of size dims[i]
    grids: &'a [&'a [T]; N],

    /// Size of each dimension
    dims: [usize; N],

    /// Values at each point, size prod(dims)
    vals: &'a [T],
}

impl<'a, T: Float, const N: usize> NearestRectilinear<'a, T, N> {
    /// Build a new interpolator, using O(N) calculations and storage.
    ///
    /// This method does not handle degenerate dimensions; all grids must have at least 2 entries.
    ///
    /// Assumes C-style ordering of vals (z(x0, y0), z(x0, y1), ..., z(x0, yn), z(x1, y0), ...).
    ///
    /// # Errors
    /// * If any input dimensions do not match
    /// * If any dimensions have size < 2
    /// * If any step sizes have zero or negative magnitude
    pub fn new(grids: &'a [&'a [T]; N], vals: &'a [T]) -> Result<Self, &'static str> {
        // Check dimensions
        const {
            assert!(
                N > 0 && N < 7,
                "Flattened method defined for 1-6 dimensions."
            );
        }
        let mut dims = [1_usize; N];
        (0..N).for_each(|i| dims[i] = grids[i].len());
        let nvals: usize = dims[..N].iter().product();
        if vals.len() != nvals {
            return Err("Dimension mismatch");
        };
        // Check if any grids are degenerate
        let degenerate = dims.iter().any(|&x| x < 2);
        if degenerate {
            return Err("All grids must have at least 2 entries");
        };
        // Check that at least the first two entries in each grid are monotonic
        let monotonic_maybe = grids.iter().all(|&g| g[1] > g[0]);
        if !monotonic_maybe {
            return Err("All grids must be monotonically increasing");
        };

        Ok(Self { grids, dims, vals })
    }

    /// Interpolate on a contiguous list of observation points.
    ///
    /// Assumes C-style ordering of vals (z(x0, y0), z(x0, y1), ..., z(x0, yn), z(x1, y0), ...).
    ///
    /// # Errors
    ///   * If the dimensionality of the point does not match the data
    ///   * If the dimensionality of point or data does not match the grid
    pub fn interp(&self, x: &[&[T]; N], out: &mut [T]) -> Result<(), &'static str> {
        let n = out.len();

        // Make sure there are enough coordinate inputs for each dimension
        if x.len() != N {
            return Err("Dimension mismatch");
        }

        // Make sure the size of inputs and output match
        let size_matches = x.iter().all(|&xx| xx.len() == out.len());
        if !size_matches {
            return Err("Dimension mismatch");
        }

        let mut tmp = [T::zero(); N];
        for i in 0..n {
            (0..N).for_each(|j| tmp[j] = x[j][i]);
            out[i] = self.interp_one(tmp)?;
        }

        Ok(())
    }

    /// Interpolate the value at a point,
    /// using fixed-size intermediate storage of O(ndims) and no allocation.
    ///
    /// Assumes C-style ordering of vals (z(x0, y0), z(x0, y1), ..., z(x0, yn), z(x1, y0), ...).
    ///
    /// # Errors
    ///   * If the dimensionality of the point does not match the data
    ///   * If the dimensionality of either one exceeds the fixed maximum
    ///   * If the index along any dimension exceeds the maximum representable
    ///     integer value within the value type `T`
    #[inline]
    pub fn interp_one(&self, x: [T; N]) -> Result<T, &'static str> {
        // Initialize fixed-size intermediate storage.
        // Maybe counterintuitively, initializing this storage here on every usage
        // instead of once with the top level struct is a significant speedup
        // and does not increase peak stack usage.
        //
        // Also notably, storing the index offsets as bool instead of usize
        // reduces memory overhead, but has not effect on throughput rate.
        let mut dimprod = [1_usize; N];
        let mut loc = [0_usize; N];
        let two = T::one() + T::one();
        let half = T::one() / two;

        let mut acc = 1;
        unroll! {
            for i < 7 in 0..N {
                // Populate cumulative product of higher dimensions for indexing.
                //
                // Each entry is the cumulative product of the size of dimensions
                // higher than this one, which is the stride between blocks
                // relating to a given index along each dimension.
                if const { i > 0 } {
                    acc *= self.dims[N - i];
                }
                dimprod[N - i - 1] = acc;

                // Populate lower corner and saturation flag for each dimension
                let origin = self.get_loc(x[i], i)?;

                // Determine normalized delta
                let x0 = self.grids[i][origin];
                let x1 = self.grids[i][origin + 1];
                let step = x1 - x0;
                let dt = (x[i] - x0) / step;

                // Determine nearest index for this dimension based on distance
                let offset = if dt <= half {
                    0
                } else {
                    1
                };

                loc[i] = origin + offset;
            }
        }

        let interped = index_arr_fixed_dims(loc, dimprod, self.vals);
        Ok(interped)
    }

    /// Get the lower-corner index along this dimension where `x` is found,
    /// saturating to the bounds at the edges if necessary.
    ///
    /// At the high bound of a given dimension, saturates to the interior.
    #[inline]
    fn get_loc(&self, v: T, dim: usize) -> Result<usize, &'static str> {
        let grid = self.grids[dim];

        // Bisection search to find location on the grid.
        //
        // The search will return `0` if the point is outside-low,
        // and will return `self.dims[dim]` if outside-high.
        //
        // This process accounts for essentially the entire difference in
        // performance between this method and the regular-grid method.
        let iloc: isize = grid.partition_point(|x| *x < v) as isize - 1;

        let n = self.dims[dim] as isize; // Number of grid points on this dimension
        let dimmax = n.saturating_sub(2).max(0); // maximum index for lower corner
        let loc: usize = iloc.max(0).min(dimmax) as usize; // unsigned integer loc clipped to interior

        Ok(loc)
    }
}

#[cfg(test)]
mod test {
    use super::{NearestRectilinear, interpn};
    use crate::testing::*;
    use crate::utils::*;

    fn nearest_rectilinear_index(value: f64, grid: &[f64]) -> usize {
        let iloc = grid.partition_point(|x| *x < value) as isize - 1;
        let n = grid.len() as isize;
        let dimmax = n.saturating_sub(2).max(0);
        let origin = iloc.max(0).min(dimmax) as usize;
        let x0 = grid[origin];
        let x1 = grid[origin + 1];
        let dt = (value - x0) / (x1 - x0);
        if dt <= 0.5 { origin } else { origin + 1 }
    }

    /// Test with one dimension that is minimum size and one that is not
    #[test]
    fn test_interp_extrap_2d_small() {
        let (nx, ny) = (3, 2);
        let x = linspace(-1.0, 1.0, nx);
        let y = Vec::from([0.5, 0.6]);
        let grids = [&x[..], &y[..]];
        let xy = meshgrid(Vec::from([&x, &y]));

        // z = x + y
        let z: Vec<f64> = (0..nx * ny).map(|i| &xy[i][0] + &xy[i][1]).collect();

        // Observation points all over in 2D space
        let xobs = linspace(-10.0_f64, 10.0, 5);
        let yobs = linspace(-10.0_f64, 10.0, 5);
        let xyobs = meshgrid(Vec::from([&xobs, &yobs]));
        let interpolator: NearestRectilinear<'_, _, 2> =
            NearestRectilinear::new(&grids, &z[..]).unwrap();

        // Check values at every incident vertex
        xyobs.iter().for_each(|xyi| {
            let zii = interpolator.interp_one([xyi[0], xyi[1]]).unwrap();
            let ix = nearest_rectilinear_index(xyi[0], &x);
            let iy = nearest_rectilinear_index(xyi[1], &y);
            let expected = x[ix] + y[iy];
            assert!((expected - zii).abs() < 1e-12)
        });
    }

    /// Iterate from 1 to 8 dimensions, making a minimum-sized grid for each one
    /// to traverse every combination of interpolating or extrapolating high or low on each dimension.
    /// Each test evaluates at 3^ndims locations, largely extrapolated in corner regions, so it
    /// rapidly becomes prohibitively slow after about ndims=9.
    #[test]
    fn test_interp_extrap_1d_to_6d() {
        let mut rng = rng_fixed_seed();

        for ndims in 1..=6 {
            println!("Testing in {ndims} dims");
            // Interp grid
            let dims: Vec<usize> = vec![2; ndims];
            let xs: Vec<Vec<f64>> = (0..ndims)
                .map(|i| {
                    // Make a linear grid and add noise
                    let mut x = linspace(-5.0 * (i as f64), 5.0 * ((i + 1) as f64), dims[i]);
                    let dx = randn::<f64>(&mut rng, x.len());
                    (0..x.len()).for_each(|i| x[i] += (dx[i] - 0.5) / 10.0);
                    (0..x.len() - 1).for_each(|i| assert!(x[i + 1] > x[i]));
                    x
                })
                .collect();

            let grids: Vec<&[f64]> = xs.iter().map(|x| &x[..]).collect();
            let grid = meshgrid((0..ndims).map(|i| &xs[i]).collect());
            let u: Vec<f64> = grid.iter().map(|x| x.iter().sum()).collect(); // sum is linear in every direction, good for testing

            // Observation points
            let xobs: Vec<Vec<f64>> = (0..ndims)
                .map(|i| linspace(-7.0 * (i as f64), 7.0 * ((i + 1) as f64), 3))
                .collect();
            let gridobs = meshgrid((0..ndims).map(|i| &xobs[i]).collect());
            let gridobs_t: Vec<Vec<f64>> = (0..ndims)
                .map(|i| gridobs.iter().map(|x| x[i]).collect())
                .collect(); // transpose
            let xobsslice: Vec<&[f64]> = gridobs_t.iter().map(|x| &x[..]).collect();
            let expected: Vec<f64> = gridobs
                .iter()
                .map(|point| {
                    (0..ndims)
                        .map(|dim| {
                            let idx = nearest_rectilinear_index(point[dim], &xs[dim]);
                            xs[dim][idx]
                        })
                        .sum()
                })
                .collect();
            let mut out = vec![0.0; expected.len()];

            // Evaluate
            interpn(&grids, &u, &xobsslice, &mut out[..]).unwrap();

            // Check that interpolated values match expectation,
            // using an absolute difference because some points are very close to or exactly at zero,
            // and do not do well under a check on relative difference.
            (0..expected.len()).for_each(|i| assert!((out[i] - expected[i]).abs() < 1e-12));
        }
    }

    /// Interpolate on a hat-shaped function to make sure that the grid cell indexing is aligned properly
    #[test]
    fn test_interp_hat_func() {
        fn hat_func(x: f64) -> f64 {
            if x <= 1.0 { x } else { 2.0 - x }
        }

        let x = (0..3).map(|x| x as f64).collect::<Vec<f64>>();
        let grids = [&x[..]];
        let y = (0..3).map(|x| hat_func(x as f64)).collect::<Vec<f64>>();
        let obs = linspace(-2.0, 4.0, 100);

        let interpolator: NearestRectilinear<f64, 1> = NearestRectilinear::new(&grids, &y).unwrap();

        (0..obs.len()).for_each(|i| {
            let idx = nearest_rectilinear_index(obs[i], &x);
            assert_eq!(y[idx], interpolator.interp_one([obs[i]]).unwrap());
        })
    }
}
