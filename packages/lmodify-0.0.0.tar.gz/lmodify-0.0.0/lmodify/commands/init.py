"""Init command - Create configuration file."""

from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Confirm, Prompt

from ..config import (
    ConfigError,
    config_exists,
    create_default_config,
    get_default_config_path,
)

console = Console()


@click.command()
@click.option(
    "-o",
    "--output",
    type=click.Path(path_type=Path),
    help="Output path for config file (default: ~/.config/lmodify.ini)",
)
@click.option(
    "-f",
    "--force",
    is_flag=True,
    help="Overwrite existing config file",
)
def init(output: Path | None, force: bool) -> None:
    """
    Create a configuration file with interactive prompts.

    This will guide you through setting up lmodify with the paths
    for your Singularity images, binaries, and LMOD modules.
    """
    # Determine config path
    if output is None:
        config_path = get_default_config_path()
    else:
        config_path = output

    # Check if config already exists
    if config_exists(config_path) and not force:
        console.print(
            f"[yellow]Configuration file already exists:[/yellow] {config_path}"
        )
        if not Confirm.ask("Do you want to overwrite it?"):
            console.print("[red]Aborted.[/red]")
            raise click.Abort()

    console.print("[bold]lmodify Configuration Setup[/bold]\n")
    console.print(
        "Please provide the following paths for your HPC environment.\n"
        "Press Enter to use the default value shown in brackets.\n"
    )

    # Prompt for values
    values = {}

    values["singularity_default_path"] = Prompt.ask(
        "Path to Singularity images",
        default="/opt/singularity",
    )

    values["bin_path"] = Prompt.ask(
        "Path for binary wrappers",
        default="/opt/bin",
    )

    values["lmod_path"] = Prompt.ask(
        "Path for LMOD Lua files",
        default="/opt/lmod",
    )

    console.print("\n[bold]Metadata (for generated files)[/bold]\n")

    values["author"] = Prompt.ask(
        "Your name",
        default="Your Name",
    )

    values["email"] = Prompt.ask(
        "Your email",
        default="your.email@example.com",
    )

    values["organization"] = Prompt.ask(
        "Your organization",
        default="Your Organization",
    )

    # Create config file
    try:
        create_default_config(config_path, values)
        console.print(f"\n[green]Configuration file created:[/green] {config_path}")
        console.print("\nYou can now use lmodify commands. Try:")
        console.print("  [cyan]lmodify list[/cyan]")
        console.print("  [cyan]lmodify create --help[/cyan]")
    except ConfigError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise click.Abort()
