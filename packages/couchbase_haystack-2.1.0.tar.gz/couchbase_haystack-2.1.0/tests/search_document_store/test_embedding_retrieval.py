# SPDX-FileCopyrightText: 2023-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0
import os
from typing import List

import pytest

from haystack.dataclasses.document import Document
from haystack.utils import Secret
from couchbase_haystack import CouchbaseSearchDocumentStore, CouchbasePasswordAuthenticator, CouchbaseClusterOptions
from couchbase.cluster import Cluster, ClusterOptions
from couchbase.options import ClusterOptions, KnownConfigProfiles
from couchbase.auth import PasswordAuthenticator
from couchbase.management.logic.search_index_logic import SearchIndex
from couchbase.exceptions import SearchIndexNotFoundException
from couchbase import search
from couchbase_haystack.document_stores.search_filters import NumericRangeQuery
from datetime import timedelta
from tests.common.common import IS_GLOBAL_LEVEL_INDEX
from tests.common import common


@pytest.mark.skipif(
    "CONNECTION_STRING" not in os.environ,
    reason="Couchbase cluster connection string not provided",
)
@pytest.mark.skipif(
    "USER_NAME" not in os.environ,
    reason="Couchbase cluster username not provided",
)
@pytest.mark.skipif(
    "PASSWORD" not in os.environ,
    reason="Couchbase cluster password not provided",
)
@pytest.mark.skipif(
    "BUCKET_NAME" not in os.environ,
    reason="Couchbase bucket name not provided",
)
@pytest.mark.skipif(
    "SCOPE_NAME" not in os.environ,
    reason="Couchbase scope name not provided",
)
@pytest.mark.skipif(
    "COLLECTION_NAME" not in os.environ,
    reason="Couchbase collection name not provided",
)
@pytest.mark.integration
class TestEmbeddingRetrieval:
    @pytest.fixture()
    def document_store(self):
        bucket_name = os.environ["BUCKET_NAME"]
        scope_name = os.environ["SCOPE_NAME"]
        collection_name = os.environ["COLLECTION_NAME"]
        cluster_opts = ClusterOptions(
            authenticator=PasswordAuthenticator(username=os.environ["USER_NAME"], password=os.environ["PASSWORD"]),
            enable_tcp_keep_alive=True,
        )
        cluster_opts.apply_profile(KnownConfigProfiles.WanDevelopment)

        cluster = Cluster(os.environ["CONNECTION_STRING"], cluster_opts)
        cluster.wait_until_ready(timeout=timedelta(seconds=30))
        bucket = cluster.bucket(bucket_name=bucket_name)
        collection_manager = bucket.collections()
        common.create_scope_if_not_exists(collection_manager, scope_name)
        common.create_collection_if_not_exists(collection_manager, scope_name, collection_name)
        scope = bucket.scope(scope_name)
        index_definition = common.load_json_file(f"{os.path.dirname(__file__)}/vector_index.json")
        mapping_type = index_definition["params"]["mapping"]["types"]["____scope.collection_____"]
        del index_definition["params"]["mapping"]["types"]["____scope.collection_____"]
        mapping_type["properties"]["embedding"]["fields"][0]["dims"] = 3
        index_definition["params"]["mapping"]["types"][f"{scope_name}.{collection_name}"] = mapping_type

        if IS_GLOBAL_LEVEL_INDEX:
            sim = cluster.search_indexes()
        else:
            sim = scope.search_indexes()

        try:
            sim.get_index(index_name=index_definition["name"])
        except SearchIndexNotFoundException as e:
            search_index = SearchIndex(
                name=index_definition["name"],
                source_name=bucket_name,
                source_type=index_definition["sourceType"],
                params=index_definition["params"],
                plan_params=index_definition["planParams"],
            )
            sim.upsert_index(search_index)

        store = CouchbaseSearchDocumentStore(
            cluster_connection_string=Secret.from_env_var("CONNECTION_STRING"),
            authenticator=CouchbasePasswordAuthenticator(
                username=Secret.from_env_var("USER_NAME"), password=Secret.from_env_var("PASSWORD")
            ),
            cluster_options=CouchbaseClusterOptions(profile=KnownConfigProfiles.WanDevelopment),
            bucket=bucket_name,
            scope=scope_name,
            collection=collection_name,
            vector_search_index=index_definition["name"],
            is_global_level_index=IS_GLOBAL_LEVEL_INDEX,
        )

        store.write_documents(
            [
                Document(content="red color", embedding=[1.0, 0.0, 0.0], meta={"color": "red", "number": 1}),
                Document(content="blue color", embedding=[0.0, 1.0, 0.0], meta={"color": "blue", "number": 2}),
                Document(content="grey color", embedding=[0.0, 0.0, 1.0], meta={"color": "grey", "number": 3}),
                Document(content="light grey color", embedding=[0.0, 0.1, 0.9], meta={"color": "light grey", "number": 4}),
            ]
        )

        yield store
        result = sim.drop_index(index_definition["name"])
        result = cluster.query
        cluster.query(f"drop collection {bucket_name}.{scope_name}.{collection_name}").execute()
        cluster.close()

    def test_embedding_retrieval(self, document_store: CouchbaseSearchDocumentStore):
        query_embedding = [0.9, 0.1, 0.0]
        results = document_store._embedding_retrieval(query_embedding=query_embedding, top_k=3)
        assert len(results) == 3
        assert results[0].content == "red color"
        assert results[1].content == "blue color"
        assert results[0].score > results[1].score

    def test_embedding_retrieval_with_search_query(self, document_store: CouchbaseSearchDocumentStore):
        query_embedding = [0.9, 0.0, 0.0]
        results = document_store._embedding_retrieval(
            query_embedding=query_embedding,
            top_k=1,
            limit=2,
            search_query=NumericRangeQuery(min=3, max=3, inclusive_min=True, inclusive_max=True, field="meta.number"),
        )
        assert len(results) == 2
        assert results[0].content == "red color"
        assert results[1].content == "grey color"
        assert results[0].score > results[1].score

    def test_embedding_retrieval_with_filters(self, document_store: CouchbaseSearchDocumentStore):
        query_embedding = [0.0, 0.9, 0.0]
        results = document_store._embedding_retrieval(
            query_embedding=query_embedding,
            top_k=1,
            filters={"field": "meta.color", "operator": "==", "value": "red"},
        )
        assert len(results) == 1
        assert results[0].content == "red color"
