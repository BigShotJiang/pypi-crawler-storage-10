*pptagent-pptx* is a Python library for creating, reading, and updating PowerPoint (.pptx)
files, forked from `python-pptx`.
