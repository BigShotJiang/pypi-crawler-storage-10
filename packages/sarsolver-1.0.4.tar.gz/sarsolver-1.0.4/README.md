# sarsolver
Python library for SAR forward/adjoint modelling.
