def test_cphd_101(vanuatu_dataset):
    x = vanuatu_dataset
    pass
