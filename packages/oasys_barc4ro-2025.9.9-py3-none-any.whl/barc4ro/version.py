
# THIS FILE IS GENERATED FROM barc4ro SETUP.PY
short_version = '2025.09.09'
version = '2025.09.09'
full_version = '2025.09.09.dev0+'
git_revision = ''
release = False

if not release:
    version = full_version
    short_version += ".dev"
