
from speclike.for_pytest.mod import TestDispatcher, case

__all__ = ["TestDispatcher", "case"]
