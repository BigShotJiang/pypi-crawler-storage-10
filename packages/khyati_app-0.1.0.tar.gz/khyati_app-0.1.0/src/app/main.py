import requests

def run():
    response = requests.get("https://jsonplaceholder.typicode.com/posts/1")
    if response.status_code == 200:
        data = response.json()
        print("Data retrieved successfully:", data)
    else:
        print("Failed to retrieve data. Status code:", response.status_code)

run()