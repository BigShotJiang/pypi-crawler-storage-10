# celery-debug

celery debug tasks.

## 安装

```shell
pip install celery-debug
```

## 输出的celery调试服务

- debug.ping
- debug.echo
- debug.sleep
- debug.raise_error
- debug.retry_n

## 启动

1. 在工作目录下创建`celeryconfig.py`，添加以下内容

    ```python
    # concurrency
    worker_concurrency = 10
    worker_pool = "threads"
    # broker_url and result_backend
    broker_url = "redis://redis/0"
    result_backend = "redis://redis/1"
    # internal configs
    accept_content = ["application/json"]
    task_serializer = "json"
    result_accept_content = ["application/json"]
    result_serializer = "json"
    timezone = "Asia/Shanghai"
    broker_connection_retry_on_startup = True
    task_track_started = True
    task_acks_late = True
    task_acks_on_failure_or_timeout = True
    task_reject_on_worker_lost = True
    # 额外新增的配置项
    # 配置后所有任务都使用不同的队列
    use_different_queue = True
    ```

2. 使用以下命令启动celery worker

    ```shell
    celery -A celery_debug.app:app worker -l DEBUG 
    ```

## 版本记录

### v0.1.0

- 版本首发。

### v0.1.1

- 提供配置项，快速让所有任务都使用不同的队列。

### v0.1.2

- use_different_queue方法做成工具函数。让用户自主控制，避免一引入就强制设置。

### v0.1.4

- `use_different_queue`自动绑定`celery`消息队列。
- 添加`deubg.sleep`任务。
- 添加`debug.raise_error`任务。
- 添加`debug.retry_n`任务。

### v0.1.5

- Doc update.
