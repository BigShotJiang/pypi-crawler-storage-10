# opacus_dpcr Pipup

This directory stores the automation script for publishing the `opacus_dpcr` package. When `pipup.py` runs it will:

1. copy the library source from the repository root;
2. generate a project-specific `setup.py`;
3. build the distribution artifact and upload it to the configured registry;
4. clean up all temporary packaging assets.

Usage:

```bash
python pipups/opacus_dpcr/pipup.py
```

Destination settings and credentials are read from the accounts declared in `pipups/config.py`.
