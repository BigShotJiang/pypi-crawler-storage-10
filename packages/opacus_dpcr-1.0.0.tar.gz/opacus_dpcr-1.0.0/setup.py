#!/usr/bin/env python
# -*- coding:utf-8 -*-


#############################################
# File Name: setup.py
# Author: Jianping Cai
# Mail: jpingcai@163.com
# Created Time:  2025-10-26 16:12:48
#############################################


from setuptools import setup, find_packages

setup(
    name="opacus_dpcr",
    version="1.0.0",
    keywords=["opacus", "differential-privacy", "optimizer"],
    description="Opacus extensions with DP continual release optimizers.",
    long_description="Engine and optimizer implementations enabling DP continual release workflows in Opacus.",
    license="Apache License 2.0",
    author="Jianping Cai",
    author_email="jpingcai@163.com",
    packages=find_packages(),
    include_package_data=True,
    platforms="any",
    install_requires=["numpy", "dpcrpy>=1.0.0", "opacus", "torch"],
    entry_points={}
)
