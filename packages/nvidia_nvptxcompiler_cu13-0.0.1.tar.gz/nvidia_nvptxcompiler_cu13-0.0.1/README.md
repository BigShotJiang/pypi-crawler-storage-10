⚠️ THIS PROJECT 'nvidia-nvptxcompiler-cu13' IS DEPRECATED.
Please use 'nvidia-nvptxcompiler' instead.

To install the correct package, use:

    pip install nvidia-nvptxcompiler

For more information, visit: https://pypi.org/project/nvidia-nvptxcompiler/
