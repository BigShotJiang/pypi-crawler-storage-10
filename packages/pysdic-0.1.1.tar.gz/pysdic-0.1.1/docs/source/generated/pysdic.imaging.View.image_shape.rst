image\_shape
============

.. currentmodule:: pysdic.imaging

.. autoproperty:: View.image_shape