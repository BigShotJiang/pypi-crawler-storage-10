visualize\_projected\_point\_cloud
==================================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.visualize_projected_point_cloud