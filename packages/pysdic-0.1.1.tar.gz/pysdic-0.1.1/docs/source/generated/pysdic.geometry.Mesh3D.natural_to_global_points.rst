natural\_to\_global\_points
===========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.natural_to_global_points