pixel\_points\_to\_image\_points
================================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.pixel_points_to_image_points