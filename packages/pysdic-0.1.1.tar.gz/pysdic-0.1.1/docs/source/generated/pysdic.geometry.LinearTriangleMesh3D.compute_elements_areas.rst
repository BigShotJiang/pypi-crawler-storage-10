compute\_elements\_areas
========================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.compute_elements_areas