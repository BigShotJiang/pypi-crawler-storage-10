bounding\_box
=============

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.bounding_box