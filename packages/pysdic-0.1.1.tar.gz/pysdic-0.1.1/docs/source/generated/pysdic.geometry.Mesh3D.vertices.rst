vertices
========

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.vertices