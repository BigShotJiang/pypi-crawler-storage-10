internal\_bypass
================

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.internal_bypass