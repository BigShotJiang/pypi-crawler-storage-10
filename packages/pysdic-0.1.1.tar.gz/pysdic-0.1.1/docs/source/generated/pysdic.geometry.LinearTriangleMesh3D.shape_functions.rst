shape\_functions
================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.shape_functions