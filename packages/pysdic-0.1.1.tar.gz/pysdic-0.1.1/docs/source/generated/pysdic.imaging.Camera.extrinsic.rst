extrinsic
=========

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.extrinsic