camera
======

.. currentmodule:: pysdic.imaging

.. autoproperty:: View.camera