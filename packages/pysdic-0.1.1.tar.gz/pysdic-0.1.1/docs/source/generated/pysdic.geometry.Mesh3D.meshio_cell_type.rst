meshio\_cell\_type
==================

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.meshio_cell_type