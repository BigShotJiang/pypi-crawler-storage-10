from\_empty
===========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.from_empty