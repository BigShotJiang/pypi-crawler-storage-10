as\_array
=========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.as_array