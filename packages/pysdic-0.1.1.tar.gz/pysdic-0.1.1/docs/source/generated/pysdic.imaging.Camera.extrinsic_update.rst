extrinsic\_update
=================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.extrinsic_update