clear\_properties
=================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.clear_properties