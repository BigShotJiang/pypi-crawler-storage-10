clear\_vertices\_properties
===========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.clear_vertices_properties