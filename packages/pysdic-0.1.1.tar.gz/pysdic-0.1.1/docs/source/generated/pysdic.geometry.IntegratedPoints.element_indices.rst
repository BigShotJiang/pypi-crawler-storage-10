element\_indices
================

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.element_indices