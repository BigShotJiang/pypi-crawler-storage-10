size\_update
============

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.size_update