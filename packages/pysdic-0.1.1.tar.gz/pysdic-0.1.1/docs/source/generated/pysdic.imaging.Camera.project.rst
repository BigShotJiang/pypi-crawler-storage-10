project
=======

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.project