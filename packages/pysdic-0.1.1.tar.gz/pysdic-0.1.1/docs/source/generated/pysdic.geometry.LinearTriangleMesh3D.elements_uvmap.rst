elements\_uvmap
===============

.. currentmodule:: pysdic.geometry

.. autoproperty:: LinearTriangleMesh3D.elements_uvmap