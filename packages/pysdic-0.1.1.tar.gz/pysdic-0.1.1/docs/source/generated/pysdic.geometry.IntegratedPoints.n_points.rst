n\_points
=========

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.n_points