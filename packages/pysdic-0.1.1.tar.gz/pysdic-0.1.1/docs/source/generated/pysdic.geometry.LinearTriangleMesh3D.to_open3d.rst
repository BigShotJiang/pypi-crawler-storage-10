to\_open3d
==========

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.to_open3d