get\_vertices\_coordinates
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.get_vertices_coordinates