image\_project\_points
======================

.. currentmodule:: pysdic.imaging

.. automethod:: View.image_project_points