visualize\_texture
==================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.visualize_texture