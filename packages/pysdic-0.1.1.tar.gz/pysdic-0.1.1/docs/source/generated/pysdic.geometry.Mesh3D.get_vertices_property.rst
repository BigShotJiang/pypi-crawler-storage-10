get\_vertices\_property
=======================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.get_vertices_property