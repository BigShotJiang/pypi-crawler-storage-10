visualize\_projected\_mesh
==========================

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.visualize_projected_mesh