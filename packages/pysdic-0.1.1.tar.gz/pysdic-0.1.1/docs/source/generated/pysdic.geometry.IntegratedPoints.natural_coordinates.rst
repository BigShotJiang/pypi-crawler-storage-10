natural\_coordinates
====================

.. currentmodule:: pysdic.geometry

.. autoproperty:: IntegratedPoints.natural_coordinates