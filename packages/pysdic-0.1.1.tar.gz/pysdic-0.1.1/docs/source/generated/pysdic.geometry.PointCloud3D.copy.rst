copy
====

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.copy