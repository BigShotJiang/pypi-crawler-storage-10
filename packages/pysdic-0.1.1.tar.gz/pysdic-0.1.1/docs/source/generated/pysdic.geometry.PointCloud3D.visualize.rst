visualize
=========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.visualize