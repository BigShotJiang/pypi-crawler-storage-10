evaluate\_vertices\_property\_at
================================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.evaluate_vertices_property_at