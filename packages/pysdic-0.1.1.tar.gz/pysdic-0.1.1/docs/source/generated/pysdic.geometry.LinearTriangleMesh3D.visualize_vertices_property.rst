visualize\_vertices\_property
=============================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.visualize_vertices_property