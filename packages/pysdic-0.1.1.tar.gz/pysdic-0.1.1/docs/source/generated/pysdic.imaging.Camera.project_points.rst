project\_points
===============

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.project_points