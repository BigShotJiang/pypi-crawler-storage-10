compute\_elements\_normals
==========================

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.compute_elements_normals