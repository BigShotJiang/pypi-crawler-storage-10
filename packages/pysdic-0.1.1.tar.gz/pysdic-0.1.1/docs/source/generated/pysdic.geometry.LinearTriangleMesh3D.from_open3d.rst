from\_open3d
============

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.from_open3d