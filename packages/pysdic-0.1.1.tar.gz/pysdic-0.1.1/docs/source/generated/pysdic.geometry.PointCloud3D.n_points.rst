n\_points
=========

.. currentmodule:: pysdic.geometry

.. autoproperty:: PointCloud3D.n_points