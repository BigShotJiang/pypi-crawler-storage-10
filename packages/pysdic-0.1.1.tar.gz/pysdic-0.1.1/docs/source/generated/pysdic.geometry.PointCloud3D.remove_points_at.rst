remove\_points\_at
==================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.remove_points_at