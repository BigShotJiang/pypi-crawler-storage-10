n\_vertices
===========

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.n_vertices