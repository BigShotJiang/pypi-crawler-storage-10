camera\_size\_change
====================

.. currentmodule:: pysdic.imaging

.. automethod:: View.camera_size_change