visualize
=========

.. currentmodule:: pysdic.geometry

.. automethod:: LinearTriangleMesh3D.visualize