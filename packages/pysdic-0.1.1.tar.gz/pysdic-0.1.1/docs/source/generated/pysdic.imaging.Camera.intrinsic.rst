intrinsic
=========

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.intrinsic