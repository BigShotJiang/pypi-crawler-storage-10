keep\_points\_inplace
=====================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.keep_points_inplace