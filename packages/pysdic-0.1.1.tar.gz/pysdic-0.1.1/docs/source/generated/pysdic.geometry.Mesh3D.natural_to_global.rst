natural\_to\_global
===================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.natural_to_global