to\_meshio
==========

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.to_meshio