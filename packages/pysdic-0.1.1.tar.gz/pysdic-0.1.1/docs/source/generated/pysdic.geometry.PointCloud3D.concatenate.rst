concatenate
===========

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.concatenate