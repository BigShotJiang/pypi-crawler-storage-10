unique\_inplace
===============

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.unique_inplace