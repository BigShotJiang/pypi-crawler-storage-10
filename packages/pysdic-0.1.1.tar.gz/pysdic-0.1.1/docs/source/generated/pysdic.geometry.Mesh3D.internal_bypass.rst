internal\_bypass
================

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.internal_bypass