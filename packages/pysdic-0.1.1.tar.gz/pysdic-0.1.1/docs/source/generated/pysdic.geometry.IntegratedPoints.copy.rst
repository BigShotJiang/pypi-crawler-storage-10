copy
====

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.copy