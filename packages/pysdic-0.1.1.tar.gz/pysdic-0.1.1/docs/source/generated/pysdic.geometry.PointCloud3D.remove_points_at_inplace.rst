remove\_points\_at\_inplace
===========================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.remove_points_at_inplace