remove\_points
==============

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.remove_points