shape
=====

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.shape