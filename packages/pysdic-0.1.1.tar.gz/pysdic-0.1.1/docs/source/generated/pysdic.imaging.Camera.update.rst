update
======

.. currentmodule:: pysdic.imaging

.. automethod:: Camera.update