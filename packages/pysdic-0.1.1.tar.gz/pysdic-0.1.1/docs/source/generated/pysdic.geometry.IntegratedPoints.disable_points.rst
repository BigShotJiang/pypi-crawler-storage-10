disable\_points
===============

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.disable_points