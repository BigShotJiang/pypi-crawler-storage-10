image
=====

.. currentmodule:: pysdic.imaging

.. autoproperty:: View.image