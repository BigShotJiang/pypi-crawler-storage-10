connectivity
============

.. currentmodule:: pysdic.geometry

.. autoproperty:: Mesh3D.connectivity