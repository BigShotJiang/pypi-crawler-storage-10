visualize\_projected\_mesh
==========================

.. currentmodule:: pysdic.imaging

.. automethod:: View.visualize_projected_mesh