keep\_points\_at\_inplace
=========================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.keep_points_at_inplace