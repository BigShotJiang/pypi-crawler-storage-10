add\_points
===========

.. currentmodule:: pysdic.geometry

.. automethod:: IntegratedPoints.add_points