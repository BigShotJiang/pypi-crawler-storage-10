distortion
==========

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.distortion