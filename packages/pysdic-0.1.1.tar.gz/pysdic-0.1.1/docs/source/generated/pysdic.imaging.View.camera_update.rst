camera\_update
==============

.. currentmodule:: pysdic.imaging

.. automethod:: View.camera_update