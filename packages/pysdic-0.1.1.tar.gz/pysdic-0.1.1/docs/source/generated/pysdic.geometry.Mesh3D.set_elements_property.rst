set\_elements\_property
=======================

.. currentmodule:: pysdic.geometry

.. automethod:: Mesh3D.set_elements_property