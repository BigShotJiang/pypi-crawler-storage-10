sensor\_width
=============

.. currentmodule:: pysdic.imaging

.. autoproperty:: Camera.sensor_width