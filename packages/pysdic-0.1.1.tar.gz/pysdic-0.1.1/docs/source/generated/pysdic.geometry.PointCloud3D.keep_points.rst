keep\_points
============

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.keep_points