merge
=====

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.merge