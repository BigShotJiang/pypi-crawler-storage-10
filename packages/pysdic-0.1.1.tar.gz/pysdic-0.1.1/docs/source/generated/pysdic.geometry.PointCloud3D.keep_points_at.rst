keep\_points\_at
================

.. currentmodule:: pysdic.geometry

.. automethod:: PointCloud3D.keep_points_at