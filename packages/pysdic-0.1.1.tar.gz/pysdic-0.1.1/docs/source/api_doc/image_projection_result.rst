.. currentmodule:: pysdic.imaging

pysdic.imaging.ImageProjectionResult
===========================================

.. autoclass:: ImageProjectionResult
    :members:
    :inherited-members:
    :show-inheritance:

