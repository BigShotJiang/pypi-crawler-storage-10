from setuptools import setup, find_packages # type: ignore

# Lendo o README.md para o PyPI
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="saraivaPessoaLib",  # ⚡ Nome com hífen para o PyPI
    version="0.1.2",
    description="Biblioteca para gerenciamento de pessoas e endereços usando FastAPI e SQLModel",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Gustavo Saraiva Mariano",
    author_email="gsaraivam10@gmail.com",
    url="https://github.com/saraivagustavo/PersonAdressLib",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "sqlmodel",
        "typing_extensions",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    extras_require={
        "dev": [
            "pytest>=7.0",
        ],
    },
)