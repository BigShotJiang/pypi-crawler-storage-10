import os
import sys
import argparse
from typing import Any, Dict, List, Optional
import requests
from fastmcp import FastMCP


mcp = FastMCP("amap-maps")

@mcp.tool()
def maps_regeocode(location: str) -> Dict[str, Any]:
    """将一个高德经纬度坐标转换为行政区划地址信息
    
    Args:
        location (str): 经纬度坐标，格式为"经度,纬度" (例如："116.481488,39.990464")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/geocode/regeo",
            params={
                "key": AMAP_MAPS_API_KEY,
                "location": location
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"RGeocoding failed: {data.get('info') or data.get('infocode')}"}
            
        return {
            "province": data["regeocode"]["addressComponent"]["province"],
            "city": data["regeocode"]["addressComponent"]["city"],
            "district": data["regeocode"]["addressComponent"]["district"]
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_geo(address: str, city: Optional[str] = None) -> Dict[str, Any]:
    """将详细的结构化地址转换为经纬度坐标。支持对地标性名胜景区、建筑物名称解析为经纬度坐标
    
    Args:
        address (str): 详细地址 (例如："北京市朝阳区阜通东大街6号")
        city (Optional[str]): 城市名称，可选 (例如："北京")
    """
    try:
        params = {
            "key": AMAP_MAPS_API_KEY,
            "address": address
        }
        if city:
            params["city"] = city
            
        response = requests.get(
            "https://restapi.amap.com/v3/geocode/geo",
            params=params
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Geocoding failed: {data.get('info') or data.get('infocode')}"}
            
        geocodes = data.get("geocodes", [])
        results = []
        for geo in geocodes:
            results.append({
                "country": geo.get("country"),
                "province": geo.get("province"),
                "city": geo.get("city"),
                "citycode": geo.get("citycode"),
                "district": geo.get("district"),
                "street": geo.get("street"),
                "number": geo.get("number"),
                "adcode": geo.get("adcode"),
                "location": geo.get("location"),
                "level": geo.get("level")
            })
        return {"return": results}
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_ip_location(ip: str) -> Dict[str, Any]:
    """IP 定位根据用户输入的 IP 地址，定位 IP 的所在位置
    
    Args:
        ip (str): IP地址 (例如："114.247.50.2")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/ip",
            params={
                "key": AMAP_MAPS_API_KEY,
                "ip": ip
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"IP Location failed: {data.get('info') or data.get('infocode')}"}
            
        return {
            "province": data.get("province"),
            "city": data.get("city"),
            "adcode": data.get("adcode"),
            "rectangle": data.get("rectangle")
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_weather(city: str) -> Dict[str, Any]:
    """根据城市名称或者标准adcode查询指定城市的天气
    
    Args:
        city (str): 城市名称或adcode (例如："北京" 或 "110000")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/weather/weatherInfo",
            params={
                "key": AMAP_MAPS_API_KEY,
                "city": city,
                "extensions": "all"
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Get weather failed: {data.get('info') or data.get('infocode')}"}
            
        forecasts = data.get("forecasts", [])
        if not forecasts:
            return {"error": "No forecast data available"}
            
        return {
            "city": forecasts[0]["city"],
            "forecasts": forecasts[0]["casts"]
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_bicycling_by_address(origin_address: str, destination_address: str, origin_city: Optional[str] = None, destination_city: Optional[str] = None) -> Dict[str, Any]:
    """使用地址规划两个地点之间的骑行路线。除非有特定原因需要使用坐标，否则推荐使用此工具。
    
    Args:
        origin_address (str): 起点地址 (例如："北京市朝阳区阜通东大街6号")
        destination_address (str): 终点地址 (例如："北京市海淀区上地十街10号")
        origin_city (Optional[str]): 起点城市名称，可选，用于提高地理编码准确性
        destination_city (Optional[str]): 终点城市名称，可选，用于提高地理编码准确性
        
    Returns:
        Dict[str, Any]: 路线信息，包括距离、时长和详细导航指令。
        考虑桥梁、单行道和道路封闭情况。支持最长500公里的路线。
    """
    try:
        # 将起点地址转换为坐标
        origin_result = maps_geo(origin_address, origin_city)
        if "error" in origin_result:
            return {"error": f"起点地址地理编码失败: {origin_result['error']}"}
        
        if not origin_result.get("return") or not origin_result["return"]:
            return {"error": "未找到起点地址的地理编码结果"}
        
        origin_location = origin_result["return"][0].get("location")
        if not origin_location:
            return {"error": "无法从起点地理编码结果中提取坐标"}
        
        # 将终点地址转换为坐标
        destination_result = maps_geo(destination_address, destination_city)
        if "error" in destination_result:
            return {"error": f"终点地址地理编码失败: {destination_result['error']}"}
        
        if not destination_result.get("return") or not destination_result["return"]:
            return {"error": "未找到终点地址的地理编码结果"}
        
        destination_location = destination_result["return"][0].get("location")
        if not destination_location:
            return {"error": "无法从终点地理编码结果中提取坐标"}
        
        # 使用坐标规划骑行路线
        route_result = maps_bicycling_by_coordinates(origin_location, destination_location)
        
        # 将地址信息添加到结果中
        if "error" not in route_result:
            route_result["addresses"] = {
                "origin": {
                    "address": origin_address,
                    "coordinates": origin_location
                },
                "destination": {
                    "address": destination_address,
                    "coordinates": destination_location
                }
            }
        
        return route_result
    except Exception as e:
        return {"error": f"路线规划失败: {str(e)}"}
    
@mcp.tool()
def maps_bicycling_by_coordinates(origin_coordinates: str, destination_coordinates: str) -> Dict[str, Any]:
    """使用坐标规划两个地点之间的骑行路线。
    
    Args:
        origin_coordinates (str): 起点坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        destination_coordinates (str): 终点坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        
    Returns:
        Dict[str, Any]: 路线信息，包括距离、时长和详细导航指令。
        考虑桥梁、单行道和道路封闭情况。支持最长500公里的路线。
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v4/direction/bicycling",
            params={
                "key": AMAP_MAPS_API_KEY,
                "origin": origin_coordinates,
                "destination": destination_coordinates
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data.get("errcode") != 0:
            return {"error": f"Direction bicycling failed: {data.get('info') or data.get('infocode')}"}
            
        paths = []
        for path in data["data"]["paths"]:
            steps = []
            for step in path["steps"]:
                steps.append({
                    "instruction": step.get("instruction"),
                    "road": step.get("road"),
                    "distance": step.get("distance"),
                    "orientation": step.get("orientation"),
                    "duration": step.get("duration")
                })
            paths.append({
                "distance": path.get("distance"),
                "duration": path.get("duration"),
                "steps": steps
            })
            
        return {
            "data": {
                "origin": data["data"]["origin"],
                "destination": data["data"]["destination"],
                "paths": paths
            }
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_direction_walking_by_address(origin_address: str, destination_address: str, origin_city: Optional[str] = None, destination_city: Optional[str] = None) -> Dict[str, Any]:
    """使用地址规划两个地点之间的步行路线。除非有特定原因需要使用坐标，否则推荐使用此工具。
    
    Args:
        origin_address (str): 起点地址 (例如："北京市朝阳区阜通东大街6号")
        destination_address (str): 终点地址 (例如："北京市海淀区上地十街10号")
        origin_city (Optional[str]): 起点城市名称，可选，用于提高地理编码准确性
        destination_city (Optional[str]): 终点城市名称，可选，用于提高地理编码准确性
        
    Returns:
        Dict[str, Any]: 路线信息，包括距离、时长和详细导航指令。
        支持最长100公里的路线。
    """
    try:
        # 将起点地址转换为坐标
        origin_result = maps_geo(origin_address, origin_city)
        if "error" in origin_result:
            return {"error": f"起点地址地理编码失败: {origin_result['error']}"}
        
        if not origin_result.get("return") or not origin_result["return"]:
            return {"error": "未找到起点地址的地理编码结果"}
        
        origin_location = origin_result["return"][0].get("location")
        if not origin_location:
            return {"error": "无法从起点地理编码结果中提取坐标"}
        
        # 将终点地址转换为坐标
        destination_result = maps_geo(destination_address, destination_city)
        if "error" in destination_result:
            return {"error": f"终点地址地理编码失败: {destination_result['error']}"}
        
        if not destination_result.get("return") or not destination_result["return"]:
            return {"error": "未找到终点地址的地理编码结果"}
        
        destination_location = destination_result["return"][0].get("location")
        if not destination_location:
            return {"error": "无法从终点地理编码结果中提取坐标"}
        
        # 使用坐标规划步行路线
        route_result = maps_direction_walking_by_coordinates(origin_location, destination_location)
        
        # 将地址信息添加到结果中
        if "error" not in route_result:
            route_result["addresses"] = {
                "origin": {
                    "address": origin_address,
                    "coordinates": origin_location
                },
                "destination": {
                    "address": destination_address,
                    "coordinates": destination_location
                }
            }
        
        return route_result
    except Exception as e:
        return {"error": f"路线规划失败: {str(e)}"}

@mcp.tool()
def maps_direction_walking_by_coordinates(origin: str, destination: str) -> Dict[str, Any]:
    """步行路径规划 API 可以根据输入起点终点经纬度坐标规划100km 以内的步行通勤方案，并且返回通勤方案的数据
    
    Args:
        origin (str): 起点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        destination (str): 终点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        
    Returns:
        Dict[str, Any]: 包含距离、时长和详细导航信息的路线数据
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/direction/walking",
            params={
                "key": AMAP_MAPS_API_KEY,
                "origin": origin,
                "destination": destination
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Direction Walking failed: {data.get('info') or data.get('infocode')}"}
            
        paths = []
        for path in data["route"]["paths"]:
            steps = []
            for step in path["steps"]:
                steps.append({
                    "instruction": step.get("instruction"),
                    "road": step.get("road"),
                    "distance": step.get("distance"),
                    "orientation": step.get("orientation"),
                    "duration": step.get("duration")
                })
            paths.append({
                "distance": path.get("distance"),
                "duration": path.get("duration"),
                "steps": steps
            })
            
        return {
            "route": {
                "origin": data["route"]["origin"],
                "destination": data["route"]["destination"],
                "paths": paths
            }
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_direction_driving_by_address(origin_address: str, destination_address: str, origin_city: Optional[str] = None, destination_city: Optional[str] = None) -> Dict[str, Any]:
    """使用地址规划两个地点之间的驾车路线。除非有特定原因需要使用坐标，否则推荐使用此工具。
    
    Args:
        origin_address (str): 起点地址 (例如："北京市朝阳区阜通东大街6号")
        destination_address (str): 终点地址 (例如："北京市海淀区上地十街10号")
        origin_city (Optional[str]): 起点城市名称，可选，用于提高地理编码准确性
        destination_city (Optional[str]): 终点城市名称，可选，用于提高地理编码准确性
        
    Returns:
        Dict[str, Any]: 路线信息，包括距离、时长和详细导航指令。
        考虑交通状况和道路限制。
    """
    try:
        # 将起点地址转换为坐标
        origin_result = maps_geo(origin_address, origin_city)
        if "error" in origin_result:
            return {"error": f"起点地址地理编码失败: {origin_result['error']}"}
        
        if not origin_result.get("return") or not origin_result["return"]:
            return {"error": "未找到起点地址的地理编码结果"}
        
        origin_location = origin_result["return"][0].get("location")
        if not origin_location:
            return {"error": "无法从起点地理编码结果中提取坐标"}
        
        # 将终点地址转换为坐标
        destination_result = maps_geo(destination_address, destination_city)
        if "error" in destination_result:
            return {"error": f"终点地址地理编码失败: {destination_result['error']}"}
        
        if not destination_result.get("return") or not destination_result["return"]:
            return {"error": "未找到终点地址的地理编码结果"}
        
        destination_location = destination_result["return"][0].get("location")
        if not destination_location:
            return {"error": "无法从终点地理编码结果中提取坐标"}
        
        # 使用坐标规划驾车路线
        route_result = maps_direction_driving_by_coordinates(origin_location, destination_location)
        
        # 将地址信息添加到结果中
        if "error" not in route_result:
            route_result["addresses"] = {
                "origin": {
                    "address": origin_address,
                    "coordinates": origin_location
                },
                "destination": {
                    "address": destination_address,
                    "coordinates": destination_location
                }
            }
        
        return route_result
    except Exception as e:
        return {"error": f"路线规划失败: {str(e)}"}

@mcp.tool()
def maps_direction_driving_by_coordinates(origin: str, destination: str) -> Dict[str, Any]:
    """驾车路径规划 API 可以根据用户起终点经纬度坐标规划以小客车、轿车通勤出行的方案，并且返回通勤方案的数据
    
    Args:
        origin (str): 起点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        destination (str): 终点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        
    Returns:
        Dict[str, Any]: 包含距离、时长和详细导航信息的路线数据
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/direction/driving",
            params={
                "key": AMAP_MAPS_API_KEY,
                "origin": origin,
                "destination": destination
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Direction Driving failed: {data.get('info') or data.get('infocode')}"}
            
        paths = []
        for path in data["route"]["paths"]:
            steps = []
            for step in path["steps"]:
                steps.append({
                    "instruction": step.get("instruction"),
                    "road": step.get("road"),
                    "distance": step.get("distance"),
                    "orientation": step.get("orientation"),
                    "duration": step.get("duration")
                })
            paths.append({
                "path": path.get("path"),
                "distance": path.get("distance"),
                "duration": path.get("duration"),
                "steps": steps
            })
            
        return {
            "route": {
                "origin": data["route"]["origin"],
                "destination": data["route"]["destination"],
                "paths": paths
            }
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_direction_transit_integrated_by_address(origin_address: str, destination_address: str, origin_city: str, destination_city: str) -> Dict[str, Any]:
    """使用地址规划两个地点之间的公共交通路线。除非有特定原因需要使用坐标，否则推荐使用此工具。
    
    Args:
        origin_address (str): 起点地址 (例如："北京市朝阳区阜通东大街6号")
        destination_address (str): 终点地址 (例如："北京市海淀区上地十街10号")
        origin_city (str): 起点城市名称（跨城交通必需）
        destination_city (str): 终点城市名称（跨城交通必需）
        
    Returns:
        Dict[str, Any]: 路线信息，包括距离、时长和详细公交指令。
        考虑各种公共交通选项，包括公交、地铁和火车。
    """
    try:
        # 将起点地址转换为坐标
        origin_result = maps_geo(origin_address, origin_city)
        if "error" in origin_result:
            return {"error": f"起点地址地理编码失败: {origin_result['error']}"}
        
        if not origin_result.get("return") or not origin_result["return"]:
            return {"error": "未找到起点地址的地理编码结果"}
        
        origin_location = origin_result["return"][0].get("location")
        if not origin_location:
            return {"error": "无法从起点地理编码结果中提取坐标"}
        
        # 将终点地址转换为坐标
        destination_result = maps_geo(destination_address, destination_city)
        if "error" in destination_result:
            return {"error": f"终点地址地理编码失败: {destination_result['error']}"}
        
        if not destination_result.get("return") or not destination_result["return"]:
            return {"error": "未找到终点地址的地理编码结果"}
        
        destination_location = destination_result["return"][0].get("location")
        if not destination_location:
            return {"error": "无法从终点地理编码结果中提取坐标"}
        
        # 使用坐标规划公共交通路线
        route_result = maps_direction_transit_integrated_by_coordinates(origin_location, destination_location, origin_city, destination_city)
        
        # 将地址信息添加到结果中
        if "error" not in route_result:
            route_result["addresses"] = {
                "origin": {
                    "address": origin_address,
                    "coordinates": origin_location
                },
                "destination": {
                    "address": destination_address,
                    "coordinates": destination_location
                }
            }
        
        return route_result
    except Exception as e:
        return {"error": f"路线规划失败: {str(e)}"}

@mcp.tool()
def maps_direction_transit_integrated_by_coordinates(origin: str, destination: str, city: str, cityd: str) -> Dict[str, Any]:
    """根据用户起终点经纬度坐标规划综合各类公共（火车、公交、地铁）交通方式的通勤方案，并且返回通勤方案的数据，跨城场景下必须传起点城市与终点城市
    
    Args:
        origin (str): 起点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        destination (str): 终点经纬度坐标，格式为"经度,纬度" (例如："116.434307,39.90909")
        city (str): 起点城市名称
        cityd (str): 终点城市名称
        
    Returns:
        Dict[str, Any]: 包含距离、时长和详细公共交通信息的路线数据
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/direction/transit/integrated",
            params={
                "key": AMAP_MAPS_API_KEY,
                "origin": origin,
                "destination": destination,
                "city": city,
                "cityd": cityd
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Direction Transit Integrated failed: {data.get('info') or data.get('infocode')}"}
        
        # 🔧 修复：兼容处理不同的API返回格式
        route_data = data.get("route")
        
        # 安全地获取路线信息
        if isinstance(route_data, list):
            # 如果API返回列表格式
            if not route_data:
                return {"error": "No route data available"}
            
            # 取第一个路线方案
            first_route = route_data[0]
            if not isinstance(first_route, dict):
                return {"error": f"Invalid route data format: expected dict, got {type(first_route)}"}
            
            route_info = first_route
            
        elif isinstance(route_data, dict):
            # 如果API返回字典格式
            route_info = route_data
            
        else:
            return {"error": f"Unexpected route data type: {type(route_data)}"}
        
        # 安全地处理transits数据
        transits = []
        transits_data = route_info.get("transits")
        
        if transits_data and isinstance(transits_data, list):
            for transit in transits_data:
                if not isinstance(transit, dict):
                    continue
                    
                segments = []
                segments_data = transit.get("segments")
                
                if segments_data and isinstance(segments_data, list):
                    for segment in segments_data:
                        if not isinstance(segment, dict):
                            continue
                            
                        # 安全处理walking步骤
                        walking_steps = []
                        walking_data = segment.get("walking", {})
                        if isinstance(walking_data, dict):
                            steps_data = walking_data.get("steps", [])
                            if isinstance(steps_data, list):
                                for step in steps_data:
                                    if isinstance(step, dict):
                                        walking_steps.append({
                                            "instruction": step.get("instruction", ""),
                                            "road": step.get("road", ""),
                                            "distance": step.get("distance", "0"),
                                            "action": step.get("action", ""),
                                            "assistant_action": step.get("assistant_action", "")
                                        })
                        
                        # 安全处理buslines
                        buslines = []
                        bus_data = segment.get("bus", {})
                        if isinstance(bus_data, dict):
                            buslines_data = bus_data.get("buslines", [])
                            if isinstance(buslines_data, list):
                                for busline in buslines_data:
                                    if isinstance(busline, dict):
                                        # 安全处理via_stops
                                        via_stops = []
                                        via_stops_data = busline.get("via_stops", [])
                                        if isinstance(via_stops_data, list):
                                            for stop in via_stops_data:
                                                if isinstance(stop, dict):
                                                    via_stops.append({"name": stop.get("name", "")})
                                        
                                        # 安全获取站点信息
                                        departure_stop = busline.get("departure_stop", {})
                                        arrival_stop = busline.get("arrival_stop", {})
                                        
                                        buslines.append({
                                            "name": busline.get("name", ""),
                                            "departure_stop": {
                                                "name": departure_stop.get("name", "") if isinstance(departure_stop, dict) else ""
                                            },
                                            "arrival_stop": {
                                                "name": arrival_stop.get("name", "") if isinstance(arrival_stop, dict) else ""
                                            },
                                            "distance": busline.get("distance", "0"),
                                            "duration": busline.get("duration", "0"),
                                            "via_stops": via_stops
                                        })
                        
                        # 安全获取其他段信息
                        entrance_data = segment.get("entrance", {})
                        exit_data = segment.get("exit", {})
                        railway_data = segment.get("railway", {})
                        
                        segments.append({
                            "walking": {
                                "origin": walking_data.get("origin", "") if isinstance(walking_data, dict) else "",
                                "destination": walking_data.get("destination", "") if isinstance(walking_data, dict) else "",
                                "distance": walking_data.get("distance", "0") if isinstance(walking_data, dict) else "0",
                                "duration": walking_data.get("duration", "0") if isinstance(walking_data, dict) else "0",
                                "steps": walking_steps
                            },
                            "bus": {"buslines": buslines},
                            "entrance": {
                                "name": entrance_data.get("name", "") if isinstance(entrance_data, dict) else ""
                            },
                            "exit": {
                                "name": exit_data.get("name", "") if isinstance(exit_data, dict) else ""
                            },
                            "railway": {
                                "name": railway_data.get("name", "") if isinstance(railway_data, dict) else "",
                                "trip": railway_data.get("trip", "") if isinstance(railway_data, dict) else ""
                            }
                        })
                
                transits.append({
                    "duration": transit.get("duration", "0"),
                    "walking_distance": transit.get("walking_distance", "0"),
                    "segments": segments
                })
        
        return {
            "route": {
                "origin": route_info.get("origin", origin),
                "destination": route_info.get("destination", destination),
                "distance": route_info.get("distance", "0"),
                "transits": transits
            }
        }
        
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}
    except KeyError as e:
        return {"error": f"Missing required field in API response: {str(e)}"}
    except TypeError as e:
        return {"error": f"Data type error in API response: {str(e)}"}
    except Exception as e:
        return {"error": f"Route planning failed: {str(e)}"}

@mcp.tool()
def maps_distance(origins: str, destination: str, type: str = "1") -> Dict[str, Any]:
    """测量两个经纬度坐标之间的距离,支持驾车、步行以及球面距离测量
    
    Args:
        origins (str): 起点经纬度坐标，格式为"经度,纬度" (例如："116.481488,39.990464")
        destination (str): 终点经纬度坐标，格式为"经度,纬度" (例如："116.465302,39.999357")
        type (str): 距离类型，0-直线距离，1-驾车导航距离 (默认："1")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/distance",
            params={
                "key": AMAP_MAPS_API_KEY,
                "origins": origins,
                "destination": destination,
                "type": type
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Direction Distance failed: {data.get('info') or data.get('infocode')}"}
            
        results = []
        for result in data["results"]:
            results.append({
                "origin_id": result.get("origin_id"),
                "dest_id": result.get("dest_id"),
                "distance": result.get("distance"),
                "duration": result.get("duration")
            })
            
        return {"results": results}
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_text_search(keywords: str, city: str = "", citylimit: str = "false") -> Dict[str, Any]:
    """关键词搜索 API 根据用户输入的关键字进行 POI 搜索，并返回相关的信息
    
    Args:
        keywords (str): 搜索关键词 (例如："肯德基")
        city (str): 城市名称或adcode，可选 (例如："北京")
        citylimit (str): 是否限制在指定城市内搜索，"true"或"false" (默认："false")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/place/text",
            params={
                "key": AMAP_MAPS_API_KEY,
                "keywords": keywords,
                "city": city,
                "citylimit": citylimit
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Text Search failed: {data.get('info') or data.get('infocode')}"}
            
        suggestion_cities = []
        if data.get("suggestion", {}).get("cities"):
            for city in data["suggestion"]["cities"]:
                suggestion_cities.append({"name": city.get("name")})
                
        pois = []
        for poi in data.get("pois", []):
            pois.append({
                "id": poi.get("id"),
                "name": poi.get("name"),
                "address": poi.get("address"),
                "typecode": poi.get("typecode")
            })
            
        return {
            "suggestion": {
                "keywords": data.get("suggestion", {}).get("keywords"),
                "cities": suggestion_cities
            },
            "pois": pois
        }
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_around_search(location: str, radius: str = "1000", keywords: str = "") -> Dict[str, Any]:
    """周边搜，根据用户传入关键词以及坐标location，搜索出radius半径范围的POI
    
    Args:
        location (str): 中心点经纬度坐标，格式为"经度,纬度" (例如："116.473168,39.993015")
        radius (str): 搜索半径，单位米 (例如："1000")
        keywords (str): 搜索关键词，可选 (例如："餐厅")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/place/around",
            params={
                "key": AMAP_MAPS_API_KEY,
                "location": location,
                "radius": radius,
                "keywords": keywords
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Around Search failed: {data.get('info') or data.get('infocode')}"}
            
        pois = []
        for poi in data.get("pois", []):
            pois.append({
                "id": poi.get("id"),
                "name": poi.get("name"),
                "address": poi.get("address"),
                "typecode": poi.get("typecode")
            })
            
        return {"pois": pois}
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}

@mcp.tool()
def maps_search_detail(id: str) -> Dict[str, Any]:
    """查询关键词搜或者周边搜获取到的POI ID的详细信息
    
    Args:
        id (str): POI的ID (例如："B000A7BD6C")
    """
    try:
        response = requests.get(
            "https://restapi.amap.com/v3/place/detail",
            params={
                "key": AMAP_MAPS_API_KEY,
                "id": id
            }
        )
        response.raise_for_status()
        data = response.json()
        
        if data["status"] != "1":
            return {"error": f"Get poi detail failed: {data.get('info') or data.get('infocode')}"}
            
        if not data.get("pois"):
            return {"error": "No POI found"}
            
        poi = data["pois"][0]
        result = {
            "id": poi.get("id"),
            "name": poi.get("name"),
            "location": poi.get("location"),
            "address": poi.get("address"),
            "business_area": poi.get("business_area"),
            "city": poi.get("cityname"),
            "type": poi.get("type"),
            "alias": poi.get("alias")
        }
        
        # 如果有扩展业务数据则添加
        if poi.get("biz_ext"):
            result.update(poi["biz_ext"])
            
        return result
    except requests.exceptions.RequestException as e:
        return {"error": f"Request failed: {str(e)}"}



# 全局变量
AMAP_MAPS_API_KEY = None

def get_api_key() -> str:
    """从环境变量获取高德地图 API 密钥"""
    global AMAP_MAPS_API_KEY
    if AMAP_MAPS_API_KEY is None:
        api_key = os.getenv("AMAP_MAPS_API_KEY")
        if not api_key:
            raise ValueError("AMAP_MAPS_API_KEY environment variable is required")
        AMAP_MAPS_API_KEY = api_key
    return AMAP_MAPS_API_KEY

def main():
    """MCP 服务器入口点"""
    import warnings
    warnings.filterwarnings("ignore")
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(
        description="Amap MCP Server",
        add_help=False  # 禁用自动帮助，避免污染 stdout
    )
    
    # 改为选项参数（带 --）
    parser.add_argument(
        '--transport', 
        default='sse', 
        choices=['stdio', 'sse', 'streamable-http'],
        help='传输类型 (stdio, sse, 或 streamable-http)'
    )
    
    parser.add_argument(
        '--api_key', 
        type=str, 
        help='高德地图 API Key (覆盖 AMAP_MAPS_API_KEY 环境变量)'
    )

    parser.add_argument(
        '--port', 
        type=int, 
        default=8000,
        help='SSE 传输端口 (默认: 8000)'
    )
    
    parser.add_argument(
        '--host', 
        type=str, 
        default="127.0.0.1",
        help='SSE 传输主机 (默认: 127.0.0.1)'
    )
    
    try:
        args = parser.parse_args()
        
        # 设置 API Key
        if args.api_key:
            global AMAP_MAPS_API_KEY
            AMAP_MAPS_API_KEY = args.api_key
        else:
            get_api_key()  # 从环境变量获取
        
        # 使用指定的传输方式运行 MCP 服务器
        mcp.run(transport=args.transport, host="127.0.0.1" if args.transport == 'sse' else None, port=args.port if args.transport == 'sse' else None)
    except Exception as e:
        sys.stderr.write(f"启动失败: {str(e)}\n")
        sys.exit(1)

if __name__ == "__main__":
    main()




