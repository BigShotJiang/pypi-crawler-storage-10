from mcp_server_gaode_thy_sse import main

main()