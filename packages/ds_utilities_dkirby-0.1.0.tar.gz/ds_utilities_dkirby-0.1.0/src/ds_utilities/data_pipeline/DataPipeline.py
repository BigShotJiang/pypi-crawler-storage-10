from typing import Callable
from functools import partial


class DataPipeline:

    def __init__(self):
        self.stages: list[Callable] = []

    def add_stage(self, stage: Callable, **kwargs) -> None:
        if not isinstance(stage, Callable):
            raise TypeError("Stage must be a Callable method")
        else:
            self.stages.append( partial(stage, **kwargs) )

    def run(self):
        data = None
        for stage in self.stages:
            data = stage( data=data )
        return data