from abc import ABC, abstractmethod
from typing import Union
from pandas import DataFrame, read_csv
import snowflake.connector


class DataStrategy(ABC):
    @abstractmethod
    def __init__(self, connection):
        self.connection = connection
        self._source_list: list[str] = None
    @abstractmethod
    def load(self, sources: Union[str, list[str]]) -> DataFrame:
        self._source_list = sources if isinstance(sources, list) else [sources]
        ...


class CsvStrategy(DataStrategy):
    def __init__(self, root_dir: str):
        super().__init__(root_dir)
    def load(self, sources: Union[str, list[str]]) -> list[DataFrame]:
        super().load(sources)
        results = []
        for source in self._source_list:
            results.append( read_csv(self.connection + "//" + source) )
        return results[0] if len(results) == 1 else results


class SnowflakeStrategy(DataStrategy):
    def __init__(self, connector: snowflake.connector):
        super().__init__(connector)
    def load(self, sources: Union[str, list[str]]) -> list[DataFrame]:
        super().load(sources)
        cursor = self.connection.cursor()
        results = []
        for source in self._source_list:
            cursor.execute(source)
            results.append( DataFrame(cursor.fetchall()) )
            results[-1].columns = [col[0] for col in cursor.description]
        return results[0] if len(results) == 1 else results