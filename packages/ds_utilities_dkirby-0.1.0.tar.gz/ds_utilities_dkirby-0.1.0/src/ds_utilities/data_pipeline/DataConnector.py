from typing import Union
import snowflake.connector

from ds_utilities.data_pipeline.DataStrategy import DataStrategy, CsvStrategy, SnowflakeStrategy


class DataConnector:

    STRATEGIES: dict[str, DataStrategy] = {
        "snowflake": SnowflakeStrategy,
        "csv": CsvStrategy,
    }

    def __init__(self, type: str, connection: Union[snowflake.connector, str]):
        """
        @type type: str
        @param type: must be one of 'snowflake', 'csv'

        @type connection: Union[snowflake.connector, str]
        @param connection: data connection for DataStrategy object, supported connectors include Snowflake connection object, str directory
        """
        if type in self.STRATEGIES:
            self.type: str = type
            self.strategy = self.STRATEGIES[type](connection)
        else:
            raise AttributeError("type must be one of {[key for key, val in self.STRATEGIES.items()]}")
        
    def __str__(self):
        return self.type
        
    def load_data(self, sources: Union[str, list[str]]):
        return self.strategy.load(sources)