import pytest
import pandas as pd
from unittest.mock import Mock, MagicMock, patch
import os
from typing import Union
from abc import ABC, abstractmethod
from functools import partial

from ds_utilities.data_pipeline.DataConnector import DataConnector
from ds_utilities.data_pipeline.DataPipeline import DataPipeline
from ds_utilities.data_pipeline.DataStrategy import DataStrategy, CsvStrategy, SnowflakeStrategy


# Fixtures
@pytest.fixture
def sample_csv_data():
    """Create sample CSV data for testing"""
    return pd.DataFrame({
        'WEEK_T': ['2024-07-01', '2024-07-08', '2024-07-15'],
        'STATE': ['Florida', 'Florida', 'Florida'],
        'MEDIA_TYPE': ['radio', 'radio', 'radio'],
        'TRAFFIC_SOURCE': ['radio', 'radio', 'radio'],
        'COST': [2287.32, 2287.32, 2287.32],
        'CLICKS': [0.0, 0.0, 0.0],
        'IMPRESSIONS': [0.0, 0.0, 0.0],
        'INSTALLS': [0.0, 0.0, 0.0]
    })


@pytest.fixture
def mock_snowflake_connection():
    """Create a mock Snowflake connection"""
    mock_conn = Mock()
    mock_cursor = Mock()
    
    # Mock data
    mock_data = [
        ('2022-02-14', 'ARIZONA', 1),
        ('2022-02-21', 'ARIZONA', 45),
        ('2022-02-28', 'ARIZONA', 32)
    ]
    
    mock_cursor.fetchall.return_value = mock_data
    mock_cursor.description = [('WEEK_T',), ('STATE',), ('NRMPS',)]
    mock_conn.cursor.return_value = mock_cursor
    
    return mock_conn


@pytest.fixture
def temp_csv_file(tmp_path, sample_csv_data):
    """Create a temporary CSV file for testing"""
    csv_path = tmp_path / "test_data.csv"
    sample_csv_data.to_csv(csv_path, index=False)
    return str(tmp_path), "test_data.csv"


# Tests for DataStrategy classes
class TestCsvStrategy:
    def test_csv_strategy_single_file(self, temp_csv_file):
        """Test loading a single CSV file"""
        root_dir, filename = temp_csv_file
        strategy = CsvStrategy(root_dir)
        data = strategy.load(filename)
        
        assert isinstance(data, pd.DataFrame)
        assert len(data) == 3
        assert 'WEEK_T' in data.columns
        assert 'STATE' in data.columns
    
    def test_csv_strategy_multiple_files(self, tmp_path, sample_csv_data):
        """Test loading multiple CSV files"""
        # Create two CSV files
        csv1 = tmp_path / "file1.csv"
        csv2 = tmp_path / "file2.csv"
        sample_csv_data.to_csv(csv1, index=False)
        sample_csv_data.to_csv(csv2, index=False)
        
        strategy = CsvStrategy(str(tmp_path))
        data = strategy.load(["file1.csv", "file2.csv"])
        
        assert isinstance(data, list)
        assert len(data) == 2
        assert all(isinstance(df, pd.DataFrame) for df in data)
    
    def test_csv_strategy_sets_source_list(self, temp_csv_file):
        """Test that _source_list is properly set"""
        root_dir, filename = temp_csv_file
        strategy = CsvStrategy(root_dir)
        strategy.load(filename)
        
        assert strategy._source_list == [filename]


class TestSnowflakeStrategy:
    def test_snowflake_strategy_single_query(self, mock_snowflake_connection):
        """Test executing a single query"""
        strategy = SnowflakeStrategy(mock_snowflake_connection)
        query = "SELECT * FROM test_table"
        data = strategy.load(query)
        
        assert isinstance(data, pd.DataFrame)
        assert len(data) == 3
        assert list(data.columns) == ['WEEK_T', 'STATE', 'NRMPS']
        mock_snowflake_connection.cursor().execute.assert_called_once_with(query)
    
    def test_snowflake_strategy_multiple_queries(self, mock_snowflake_connection):
        """Test executing multiple queries"""
        strategy = SnowflakeStrategy(mock_snowflake_connection)
        queries = ["SELECT * FROM table1", "SELECT * FROM table2"]
        data = strategy.load(queries)
        
        assert isinstance(data, list)
        assert len(data) == 2
        assert all(isinstance(df, pd.DataFrame) for df in data)
        assert mock_snowflake_connection.cursor().execute.call_count == 2
    
    def test_snowflake_strategy_sets_columns(self, mock_snowflake_connection):
        """Test that DataFrame columns are properly set from cursor description"""
        strategy = SnowflakeStrategy(mock_snowflake_connection)
        data = strategy.load("SELECT * FROM test_table")
        
        assert list(data.columns) == ['WEEK_T', 'STATE', 'NRMPS']


# Tests for DataConnector
class TestDataConnector:
    def test_snowflake_connector_initialization(self, mock_snowflake_connection):
        """Test initializing a Snowflake connector"""
        connector = DataConnector("snowflake", mock_snowflake_connection)
        
        assert connector.type == "snowflake"
        assert isinstance(connector.strategy, SnowflakeStrategy)
        assert str(connector) == "snowflake"
    
    def test_csv_connector_initialization(self):
        """Test initializing a CSV connector"""
        connector = DataConnector("csv", "/path/to/data")
        
        assert connector.type == "csv"
        assert isinstance(connector.strategy, CsvStrategy)
        assert str(connector) == "csv"
    
    def test_invalid_connector_type(self):
        """Test that invalid connector type raises AttributeError"""
        with pytest.raises(AttributeError):
            DataConnector("invalid_type", None)
    
    def test_load_data_delegates_to_strategy(self, mock_snowflake_connection):
        """Test that load_data properly delegates to the strategy"""
        connector = DataConnector("snowflake", mock_snowflake_connection)
        query = "SELECT * FROM test_table"
        data = connector.load_data(query)
        
        assert isinstance(data, pd.DataFrame)
        assert len(data) == 3
    
    def test_csv_connector_load_data(self, temp_csv_file):
        """Test CSV connector load_data method"""
        root_dir, filename = temp_csv_file
        connector = DataConnector("csv", root_dir)
        data = connector.load_data(filename)
        
        assert isinstance(data, pd.DataFrame)
        assert len(data) == 3


# Tests for DataPipeline
class TestDataPipeline:
    def test_pipeline_initialization(self):
        """Test pipeline initialization"""
        pipeline = DataPipeline()
        
        assert isinstance(pipeline.stages, list)
        assert len(pipeline.stages) == 0
    
    def test_add_stage_with_function(self):
        """Test adding a stage with a function"""
        pipeline = DataPipeline()
        
        def test_func(data=None):
            return "test"
        
        pipeline.add_stage(test_func)
        
        assert len(pipeline.stages) == 1
    
    def test_add_stage_with_kwargs(self):
        """Test adding a stage with keyword arguments"""
        pipeline = DataPipeline()
        
        def test_func(param1, data=None):
            return param1
        
        pipeline.add_stage(test_func, param1="value1")
        
        assert len(pipeline.stages) == 1
    
    def test_add_stage_non_callable_raises_error(self):
        """Test that adding non-callable raises TypeError"""
        pipeline = DataPipeline()
        
        with pytest.raises(TypeError, match="Stage must be a Callable method"):
            pipeline.add_stage("not_a_function")
    
    def test_pipeline_run_single_stage(self):
        """Test running a pipeline with a single stage"""
        pipeline = DataPipeline()
        
        def create_data(data=None):
            return pd.DataFrame({'col1': [1, 2, 3]})
        
        pipeline.add_stage(create_data)
        result = pipeline.run()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3
    
    def test_pipeline_run_multiple_stages(self):
        """Test running a pipeline with multiple stages"""
        pipeline = DataPipeline()
        
        def create_data(data=None):
            return pd.DataFrame({'col1': [1, 2, 3]})
        
        def transform_data(data):
            data['col2'] = data['col1'] * 2
            return data
        
        def convert_to_dict(data):
            return data.to_dict()
        
        pipeline.add_stage(create_data)
        pipeline.add_stage(transform_data)
        pipeline.add_stage(convert_to_dict)
        
        result = pipeline.run()
        
        assert isinstance(result, dict)
        assert 'col1' in result
        assert 'col2' in result
    
    def test_pipeline_with_lambda(self):
        """Test pipeline with lambda function"""
        pipeline = DataPipeline()
        
        def create_data(data=None):
            return pd.DataFrame({'col1': [1, 2, 3]})
        
        pipeline.add_stage(create_data)
        pipeline.add_stage(lambda data: data.to_dict())
        
        result = pipeline.run()
        
        assert isinstance(result, dict)
    
    def test_pipeline_data_flow(self):
        """Test that data flows correctly through pipeline stages"""
        pipeline = DataPipeline()
        
        def stage1(data=None):
            return 10
        
        def stage2(data):
            return data * 2
        
        def stage3(data):
            return data + 5
        
        pipeline.add_stage(stage1)
        pipeline.add_stage(stage2)
        pipeline.add_stage(stage3)
        
        result = pipeline.run()
        
        assert result == 25  # (10 * 2) + 5


# Integration tests
class TestIntegration:
    def test_csv_connector_with_pipeline(self, temp_csv_file):
        """Test integrating CSV connector with pipeline"""
        root_dir, filename = temp_csv_file
        pipeline = DataPipeline()
        
        def load_data(file_path, data=None):
            connector = DataConnector("csv", root_dir)
            return connector.load_data(file_path)
        
        def transform_data(data):
            return data[['WEEK_T', 'STATE', 'COST']]
        
        pipeline.add_stage(load_data, file_path=filename)
        pipeline.add_stage(transform_data)
        
        result = pipeline.run()
        
        assert isinstance(result, pd.DataFrame)
        assert len(result.columns) == 3
        assert list(result.columns) == ['WEEK_T', 'STATE', 'COST']
    
    def test_snowflake_connector_with_pipeline(self, mock_snowflake_connection):
        """Test integrating Snowflake connector with pipeline"""
        pipeline = DataPipeline()
        
        def load_data(query, data=None):
            connector = DataConnector("snowflake", mock_snowflake_connection)
            return connector.load_data(query)
        
        def filter_data(data):
            return data[data['NRMPS'] > 30]
        
        pipeline.add_stage(load_data, query="SELECT * FROM test")
        pipeline.add_stage(filter_data)
        
        result = pipeline.run()
        
        assert isinstance(result, pd.DataFrame)
        assert all(result['NRMPS'] > 30)
