"""
Command-line interface for colab-test.
"""
import sys
import argparse
from pathlib import Path
from .executor import execute_notebook, check_notebook_packages


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Test Jupyter notebooks in Google Colab environment",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  colab-test notebook.ipynb                          # Basic execution
  colab-test notebook.ipynb -v                       # Show progress logs
  colab-test notebook.ipynb --docker-logs            # Show raw Docker output
  colab-test notebook.ipynb -p numpy pandas          # Install specific packages
  colab-test notebook.ipynb -r requirements.txt      # Install from requirements.txt
  colab-test notebook.ipynb -p "scikit-learn>=1.0"   # Install with version
  colab-test notebook.ipynb --env .env               # Use environment file
  colab-test notebook.ipynb --pull                   # Force update image
  colab-test notebook.ipynb --platform linux/amd64   # Specify platform
        """
    )
    
    parser.add_argument(
        'notebook',
        help='Path to the notebook to test'
    )
    
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Show internal colab-test progress logs'
    )
    
    parser.add_argument(
        '--docker-logs',
        action='store_true',
        help='Show raw Docker output instead of structured logs'
    )
    
    parser.add_argument(
        '--env',
        metavar='FILE',
        help='Load environment variables from file'
    )
    
    parser.add_argument(
        '--requirements', '-r',
        metavar='FILE',
        help='Install packages from requirements.txt before execution'
    )
    
    parser.add_argument(
        '--packages', '-p',
        nargs='+',
        metavar='PKG',
        help='Install specific packages (e.g., -p numpy pandas "scikit-learn>=1.0")'
    )
    
    parser.add_argument(
        '--pull',
        action='store_true',
        help='Force pull latest Docker image (default: use cached image if available)'
    )
    
    parser.add_argument(
        '--platform',
        metavar='PLATFORM',
        help='Docker platform (e.g., linux/amd64, linux/arm64). Auto-detects if not specified.'
    )
    
    parser.add_argument(
        '--auto-setup',
        action='store_true',
        help='Automatically insert a Colab Setup cell for fixable errors (e.g., missing packages)'
    )
    
    parser.add_argument(
        '--interactive-setup',
        action='store_true',
        help='Prompt to insert a Colab Setup cell when fixable errors are detected'
    )

    parser.add_argument(
        '--check-packages',
        action='store_true',
        help='Only check notebook imports against Colab runtime; do not execute the notebook'
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version='%(prog)s 0.1.0'
    )
    
    args = parser.parse_args()
    
    # Either run package check or execute the notebook
    if args.check_packages:
        exit_code = check_notebook_packages(
            notebook_path=args.notebook,
            verbose=args.verbose,
            platform=args.platform,
            auto_setup=args.auto_setup,
            interactive_setup=args.interactive_setup,
        )
    else:
        exit_code = execute_notebook(
            notebook_path=args.notebook,
            verbose=args.verbose,
            env_file=args.env,
            force_pull=args.pull,
            platform=args.platform,
            show_docker_output=args.docker_logs,
            requirements_file=args.requirements,
            packages=args.packages,
            auto_setup=args.auto_setup,
            interactive_setup=args.interactive_setup,
        )
    
    sys.exit(exit_code)


if __name__ == '__main__':
    main()

