import ast
import nbformat
from nbformat.v4 import new_code_cell
from pathlib import Path
from typing import List, Set, Dict


SETUP_CELL_METADATA_KEY = "colab_test_setup"
MODULE_TO_PIP: Dict[str, str] = {
    # Common mismatches between import name and pip package name
    "sklearn": "scikit-learn",
    "cv2": "opencv-python",
    "PIL": "pillow",
    "skimage": "scikit-image",
    "yaml": "pyyaml",
    "bs4": "beautifulsoup4",
}


def extract_imported_modules_from_source(source: str) -> Set[str]:
    modules: Set[str] = set()
    try:
        tree = ast.parse(source)
    except Exception:
        return modules

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = (alias.name or "").split(".")[0]
                if name:
                    modules.add(name)
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                # Skip relative imports
                continue
            module_name = (node.module or "").split(".")[0]
            if module_name:
                modules.add(module_name)
    return modules


def extract_imported_modules_from_notebook(notebook_path: str) -> Set[str]:
    path = Path(notebook_path)
    nb = nbformat.read(path.open("r"), as_version=4)
    modules: Set[str] = set()
    for cell in nb.cells:
        if cell.get("cell_type") != "code":
            continue
        src = cell.get("source") or ""
        modules.update(extract_imported_modules_from_source(src))
    return modules


def resolve_modules_to_packages(modules: Set[str]) -> List[str]:
    packages: List[str] = []
    for mod in sorted(modules):
        packages.append(MODULE_TO_PIP.get(mod, mod))
    return packages


def generate_missing_packages_cell(packages: List[str]) -> str:
    """Generate code for a Colab setup cell to install missing packages.

    Args:
        packages: List of missing package specifiers (e.g., ["numpy", "pandas>=2"]).

    Returns:
        A string containing the code that installs the packages using pip in Colab.
    """
    if not packages:
        return "# No missing packages detected"

    # Prefer quiet installs to reduce noise; users can expand output if needed.
    packages_str = " ".join(f"\"{pkg}\"" if " " in pkg else pkg for pkg in packages)
    lines = [
        "# Colab Setup: install missing packages detected by colab-test",
        f"!pip install -q {packages_str}",
    ]
    return "\n".join(lines)


def insert_setup_cell(notebook_path: str, cell_source: str) -> bool:
    """Insert a setup cell at the top of the notebook if not already present.

    Adds a metadata flag on the inserted cell to avoid duplicates.

    Args:
        notebook_path: Path to the .ipynb file to modify (in-place).
        cell_source: Source code of the setup cell to insert.

    Returns:
        True if a new cell was inserted; False if skipped (already present or empty source).
    """
    path = Path(notebook_path)
    if not path.exists():
        raise FileNotFoundError(f"Notebook not found: {notebook_path}")

    if not cell_source.strip():
        return False

    nb = nbformat.read(path.open("r"), as_version=4)

    # Check if we already inserted a setup cell previously
    for cell in nb.cells:
        if isinstance(cell.get("metadata"), dict) and cell.metadata.get(SETUP_CELL_METADATA_KEY):
            return False

    setup_cell = new_code_cell(source=cell_source)
    setup_cell.metadata[SETUP_CELL_METADATA_KEY] = True
    nb.cells.insert(0, setup_cell)

    nbformat.write(nb, path.open("w"))
    return True
