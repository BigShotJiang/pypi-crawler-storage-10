"""
Logging utilities for colab-test.
"""
import sys

class ColabTestLogger:
    """Structured logger for colab-test operations."""
    
    def __init__(self, verbose: bool = False):
        """
        Initialize logger.
        
        Args:
            verbose: Whether to show verbose internal logs
        """
        self.verbose = verbose
    
    def info(self, message: str, force: bool = False):
        """Log informational message.
        
        Args:
            message: Message to log
            force: Show even if not verbose
        """
        if self.verbose or force:
            print(f"[INFO] {message}")
    
    def success(self, message: str):
        """Log success message (always shown)."""
        print(f"[SUCCESS] {message}")
    
    def warning(self, message: str):
        """Log warning message (always shown)."""
        print(f"[WARNING] {message}", file=sys.stderr)
    
    def error(self, message: str):
        """Log error message (always shown)."""
        print(f"[ERROR] {message}", file=sys.stderr)
    
    def step(self, message: str):
        """Log a major step in the process.
        
        Args:
            message: Step description
        """
        if self.verbose:
            print(f"\n[STEP] {message}")
    
    def raw(self, message: str):
        """Output raw message without formatting."""
        print(message)

