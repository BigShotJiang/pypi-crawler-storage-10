import sys
import traceback
import nbformat
from pathlib import Path
from nbconvert.preprocessors import ExecutePreprocessor


def execute_notebook(notebook_path):
    """Execute a notebook and return status."""
    
    # Read the notebook
    with open(notebook_path, 'r') as f:
        nb = nbformat.read(f, as_version=4)
    
    # Create executor
    ep = ExecutePreprocessor(timeout=600, kernel_name='python3')
    
    try:
        # Execute the notebook
        ep.preprocess(nb, {'metadata': {'path': Path(notebook_path).parent}})
        
        print("[SUCCESS] Notebook executed successfully")
        return True
        
    except Exception as e:
        print("\n[ERROR] Notebook execution failed: {}: {}".format(type(e).__name__, str(e)))
        print("\n[ERROR] Full traceback:")
        print(traceback.format_exc())
        return False

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser()
    parser.add_argument('notebook')
    args = parser.parse_args()
    
    success = execute_notebook(args.notebook)
    sys.exit(0 if success else 1)

