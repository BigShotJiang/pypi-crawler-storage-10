"""
colab-test: Test Jupyter notebooks in Google Colab environment using Docker.
"""

__version__ = "0.1.0"

from .executor import execute_notebook
from .cli import main as cli_main
from .docker_utils import cleanup_docker, check_colab_image

__all__ = ["execute_notebook", "cli_main", "cleanup_docker", "check_colab_image"]

