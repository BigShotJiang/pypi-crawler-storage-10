"""
Docker utility functions for colab-test.
"""
import subprocess
from typing import Tuple, List, Dict


def cleanup_docker(verbose: bool = True) -> None:
    """Clean up Docker resources to free disk space."""
    if verbose:
        print("Docker Disk Usage Before Cleanup:")
        subprocess.run(['docker', 'system', 'df'])
        print()
    
    cleanup_commands = [
        ("Removing stopped containers...", ['docker', 'container', 'prune', '-f']),
        ("Removing dangling images...", ['docker', 'image', 'prune', '-f']),
        ("Removing unused volumes...", ['docker', 'volume', 'prune', '-f']),
        ("Removing unused networks...", ['docker', 'network', 'prune', '-f']),
    ]
    
    for description, cmd in cleanup_commands:
        if verbose:
            print(f"→ {description}")
        result = subprocess.run(cmd, capture_output=not verbose)
        if not verbose and result.returncode != 0:
            print(f"Warning: {description} failed")
    
    if verbose:
        print("\nDocker Disk Usage After Cleanup:")
        subprocess.run(['docker', 'system', 'df'])
        print("\nFor more aggressive cleanup (removes ALL unused images):")
        print("  docker image prune -a -f")
        print("\nTo see what's taking space:")
        print("  docker images --format 'table {{.Repository}}:{{.Tag}}\\t{{.Size}}' | sort -k2 -h")


def check_colab_image() -> Tuple[bool, str]:
    """Check if the Google Colab Docker image is available."""
    cmd = ['docker', 'images', '--format', '{{.Repository}}:{{.Tag}}']
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode != 0:
        return False, "Failed to list Docker images"
    
    colab_image = "us-docker.pkg.dev/colab-images/public/runtime:latest"
    if colab_image in result.stdout:
        return True, "Colab image already pulled"
    else:
        return False, "Colab image will be pulled on first run"

