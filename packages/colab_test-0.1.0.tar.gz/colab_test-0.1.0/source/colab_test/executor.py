"""
Notebook execution logic for colab-test.
"""
import os
import tempfile
import subprocess
import platform as platform_module
from pathlib import Path
from typing import Optional, Dict, Tuple, List
import json

from .docker_utils import check_colab_image
from .logger import ColabTestLogger
from .patch_kit import (
    generate_missing_packages_cell,
    insert_setup_cell,
    extract_imported_modules_from_notebook,
    resolve_modules_to_packages,
)

DOCKER_IMAGE = "us-docker.pkg.dev/colab-images/public/runtime:latest"


def detect_platform() -> Optional[str]:
    """Detect the appropriate Docker platform for the current system.
    
    Returns:
        Platform string for Docker (e.g., 'linux/amd64', 'linux/arm64') or None for auto
    """
    machine = platform_module.machine().lower()
    system = platform_module.system().lower()
    
    if system != 'darwin':  # Not macOS, let Docker handle it
        return None
    
    # macOS - determine architecture
    if machine in ('arm64', 'aarch64'):
        # ARM Mac - Colab uses amd64, so we need Rosetta emulation
        return 'linux/amd64'
    else:
        return 'linux/amd64'  # Intel Mac


def create_executor_script() -> str:
    """Create the Python script that runs inside the Docker container."""
    template_path = Path(__file__).parent / 'execute.py'
    return template_path.read_text()


def check_docker() -> Tuple[bool, str]:
    """Check if Docker is installed and running."""
    # Check if Docker is installed
    try:
        subprocess.run(['docker', '--version'], capture_output=True, check=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False, "Docker is not installed"
    
    # Check if Docker daemon is running
    try:
        subprocess.run(['docker', 'info'], capture_output=True, check=True)
    except subprocess.CalledProcessError:
        return False, "Docker daemon is not running"
    
    return True, ""


def parse_docker_error(stderr: str) -> str:
    """Parse Docker error messages and provide helpful context."""
    stderr_lower = stderr.lower()
    
    # Check for common Docker errors
    if 'no space left on device' in stderr_lower:
        return (
            "Docker has run out of storage space.\n"
            "This is a Docker-specific limit, not your system disk.\n\n"
            "Quick fix:\n"
            "  docker system prune -a -f\n\n"
            "Or use the cleanup script:\n"
            "  bash scripts/docker_cleanup.sh\n\n"
            "For macOS users: Consider increasing Docker Desktop's disk image size:\n"
            "  Settings → Resources → Disk image size → Increase limit"
        )
    elif 'cannot connect to the docker daemon' in stderr_lower:
        return (
            "Cannot connect to Docker daemon.\n"
            "Make sure Docker Desktop is running (macOS/Windows)\n"
            "or start the Docker service (Linux: sudo systemctl start docker)"
        )
    elif 'network' in stderr_lower or 'timeout' in stderr_lower:
        return (
            "Network error while pulling Docker image.\n"
            "Check your internet connection and try again."
        )
    elif 'permission denied' in stderr_lower:
        return (
            "Permission denied accessing Docker.\n"
            "You may need to run with sudo or add your user to the docker group:\n"
            "  sudo usermod -aG docker $USER"
        )
    else:
        # Return the raw error if we don't recognize it
        return f"Docker image pull failed:\n{stderr.strip()}"


def pull_docker_image(
    logger: ColabTestLogger,
    force_pull: bool = False,
    show_docker_output: bool = False
) -> Tuple[bool, str]:
    """Pull the Google Colab Docker image if needed.
    
    Args:
        logger: Logger instance
        force_pull: Pull image even if it already exists locally
        show_docker_output: Show raw Docker pull output
    
    Returns:
        Tuple of (success, error_message)
    """
    # Check if image already exists
    image_exists, _ = check_colab_image()
    
    if image_exists and not force_pull:
        logger.info(f"Using cached Docker image: {DOCKER_IMAGE}")
        return True, ""
    
    # Pull the image
    logger.step("Pulling Docker image" if not force_pull else "Updating Docker image")
    cmd = ['docker', 'pull', DOCKER_IMAGE]
    
    if show_docker_output:
        result = subprocess.run(cmd)
        if result.returncode != 0:
            return False, "Failed to pull Docker image (see output above)"
    else:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            error_msg = parse_docker_error(result.stderr)
            return False, error_msg
        logger.info("Docker image ready")
    
    return True, ""


def load_env_file(env_file: str) -> Dict[str, str]:
    """Load environment variables from a file."""
    env_vars = {}
    
    if not os.path.exists(env_file):
        raise FileNotFoundError(f"Environment file not found: {env_file}")
    
    with open(env_file, 'r') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if '=' in line:
                key, value = line.split('=', 1)
                # Remove quotes if present
                value = value.strip('"').strip("'")
                env_vars[key] = value
    
    return env_vars


def execute_notebook(
    notebook_path: str,
    verbose: bool = False,
    env_file: Optional[str] = None,
    force_pull: bool = False,
    platform: Optional[str] = None,
    show_docker_output: bool = False,
    requirements_file: Optional[str] = None,
    packages: Optional[list] = None,
    auto_setup: bool = False,
    interactive_setup: bool = False,
) -> int:
    """
    Execute a notebook in the Google Colab Docker environment.
    
    Args:
        notebook_path: Path to the notebook to execute
        verbose: Show internal colab-test progress logs
        env_file: Optional environment file to load
        force_pull: Force pull Docker image even if cached
        platform: Docker platform (e.g., 'linux/amd64'). If None, auto-detects.
        show_docker_output: Show raw Docker logs instead of structured logs
        requirements_file: Optional path to requirements.txt to install before execution
        packages: Optional list of packages to install (e.g., ['numpy', 'pandas>=1.0'])
        
    Returns:
        Exit code (0 for success, 1 for failure)
    """
    # Initialize logger
    logger = ColabTestLogger(verbose=verbose)

    # Validate setup flags
    if auto_setup and interactive_setup:
        logger.warning("Both --auto-setup and --interactive-setup provided; proceeding with automatic setup.")
        interactive_setup = False
    
    # Auto-detect platform if not specified
    if platform is None:
        platform = detect_platform()
    # Validate notebook path
    notebook_path = Path(notebook_path).resolve()
    if not notebook_path.exists():
        logger.error(f"Notebook not found: {notebook_path}")
        return 1
    
    if not notebook_path.suffix == '.ipynb':
        logger.error(f"File is not a notebook: {notebook_path}")
        return 1
    
    # Validate requirements file if provided
    requirements_path = None
    if requirements_file:
        requirements_path = Path(requirements_file).resolve()
        if not requirements_path.exists():
            logger.error(f"Requirements file not found: {requirements_path}")
            return 1
        logger.info(f"Will install from: {requirements_path.name}")
    
    # Validate packages if provided
    if packages:
        logger.info(f"Will install packages: {', '.join(packages)}")
    
    logger.step("Checking Docker environment")
    
    # Check Docker
    docker_ok, error_msg = check_docker()
    if not docker_ok:
        logger.error(error_msg)
        return 1
    
    # Pull Docker image (or use cached version)
    success, error_msg = pull_docker_image(logger, force_pull, show_docker_output)
    if not success:
        logger.error(error_msg)
        return 1
    
    # Load environment variables
    env_vars = {}
    if env_file:
        logger.info(f"Loading environment from {env_file}")
        try:
            env_vars = load_env_file(env_file)
        except FileNotFoundError as e:
            logger.error(str(e))
            return 1
    
    # Create temporary directory for the executor script
    with tempfile.TemporaryDirectory() as temp_dir:
        logger.step("Preparing execution environment")
        
        # Write executor script
        executor_path = Path(temp_dir) / 'execute_notebook.py'
        executor_path.write_text(create_executor_script())

        # Optional: preflight AST-based check for missing imports inside Colab
        if auto_setup or interactive_setup:
            try:
                modules = extract_imported_modules_from_notebook(str(notebook_path))
            except Exception as e:
                modules = set()
                logger.info(f"AST precheck skipped: {e}", force=True)

            if modules:
                # Prepare precheck script and input
                precheck_script = (
                    "import json, importlib.util, sys\n"
                    "mods = json.load(open('/tmp/test/modules.json'))\n"
                    "missing = []\n"
                    "for m in mods:\n"
                    "    try:\n"
                    "        ok = importlib.util.find_spec(m) is not None\n"
                    "    except Exception:\n"
                    "        ok = False\n"
                    "    if not ok:\n"
                    "        missing.append(m)\n"
                    "print(json.dumps({'missing': missing}))\n"
                )
                (Path(temp_dir) / 'precheck.py').write_text(precheck_script)
                (Path(temp_dir) / 'modules.json').write_text(json.dumps(sorted(modules)))

                pre_container_name = f"colab-test-pre-{os.getpid()}"
                pre_cmd = [
                    'docker', 'run', '--rm',
                    '--name', pre_container_name,
                ]
                if platform:
                    pre_cmd.extend(['--platform', platform])
                pre_cmd.extend([
                    '-v', f'{temp_dir}:/tmp/test:rw',
                    '--entrypoint', 'python',
                    DOCKER_IMAGE,
                    '/tmp/test/precheck.py',
                ])

                pre_res = subprocess.run(pre_cmd, capture_output=True, text=True)
                if pre_res.returncode == 0 and pre_res.stdout:
                    try:
                        data = json.loads(pre_res.stdout.strip().splitlines()[-1])
                        missing_mods = data.get('missing') or []
                    except Exception:
                        missing_mods = []
                else:
                    missing_mods = []

                if missing_mods:
                    pkgs = resolve_modules_to_packages(set(missing_mods))
                    logger.warning("Precheck detected missing packages: " + ", ".join(pkgs))

                    should_apply = auto_setup
                    if not should_apply and interactive_setup:
                        try:
                            resp = input(
                                "Insert a Colab Setup cell to install these before running? [y/N]: "
                            ).strip().lower()
                            should_apply = resp in ("y", "yes")
                        except Exception:
                            should_apply = False

                    if should_apply:
                        cell_code = generate_missing_packages_cell(pkgs)
                        try:
                            created = insert_setup_cell(str(notebook_path), cell_code)
                            if created:
                                logger.success("Inserted Colab Setup cell (preflight).")
                            else:
                                logger.info("Setup cell already present; no changes made.", force=True)
                        except Exception as e:
                            logger.error(f"Failed to insert setup cell: {e}")
        
        # Prepare Docker command
        container_name = f"colab-test-{os.getpid()}"
        
        docker_cmd = [
            'docker', 'run', '--rm',
            '--name', container_name,
        ]
        
        # Add platform if specified
        if platform:
            docker_cmd.extend(['--platform', platform])
            logger.info(f"Using platform: {platform}")
        
        # Add volume mounts
        docker_cmd.extend([
            '-v', f'{notebook_path}:/tmp/notebook.ipynb:ro',
            '-v', f'{temp_dir}:/tmp/test:rw',
        ])
        
        # Mount requirements file if provided
        if requirements_path:
            docker_cmd.extend([
                '-v', f'{requirements_path}:/tmp/requirements.txt:ro'
            ])
        
        # Add environment variables
        for key, value in env_vars.items():
            docker_cmd.extend(['-e', f'{key}={value}'])
        
        # Pass packages list as environment variable if provided
        if packages:
            # Join packages with space for pip install command
            docker_cmd.extend(['-e', f'COLAB_TEST_PACKAGES={" ".join(packages)}'])
        
        # Add environment variables to suppress debugger warnings
        docker_cmd.extend([
            '-e', 'PYDEVD_DISABLE_FILE_VALIDATION=1',
            '-e', 'PYTHONDONTWRITEBYTECODE=1'
        ])
        
        # Override the default entrypoint to run our script instead of Jupyter server
        docker_cmd.extend(['--entrypoint', '/bin/bash'])
        
        # Build installation command
        install_cmds = []
        
        # Install base packages for notebook execution
        install_cmds.append('pip install --progress-bar off -q nbformat nbconvert jupyter >/dev/null 2>&1')
        
        # Install from requirements file if provided
        if requirements_path:
            logger.info("Installing packages from requirements.txt...")
            install_cmds.append('pip install --progress-bar off -r /tmp/requirements.txt')
        
        # Install individual packages if provided
        if packages:
            logger.info(f"Installing {len(packages)} package(s)...")
            packages_str = ' '.join(f'"{pkg}"' for pkg in packages)
            install_cmds.append(f'pip install --progress-bar off {packages_str}')
        
        # Combine all commands
        full_cmd = ' && '.join(install_cmds)
        full_cmd += ' && python -Xfrozen_modules=off /tmp/test/execute_notebook.py /tmp/notebook.ipynb'
        
        # Add the image and command
        docker_cmd.extend([DOCKER_IMAGE, '-c', full_cmd])
        
        # Execute
        logger.step("Executing notebook in Colab environment")
        logger.info(f"Notebook: {notebook_path.name}")
        
        if show_docker_output:
            # Show raw Docker output
            result = subprocess.run(docker_cmd)
        else:
            # Capture output and only show structured logs from execute.py
            result = subprocess.run(docker_cmd, capture_output=True, text=True)
            
            # Show output from the execution script
            if result.stdout:
                logger.raw(result.stdout)
            if result.stderr and result.returncode != 0:
                logger.raw(result.stderr)

        return result.returncode


def check_notebook_packages(
    notebook_path: str,
    verbose: bool = False,
    platform: Optional[str] = None,
    auto_setup: bool = False,
    interactive_setup: bool = False,
) -> int:
    """Standalone package check for a notebook against the Colab runtime.

    - Parses imports via AST
    - Verifies availability inside the Colab image
    - Optionally injects a setup cell
    """
    logger = ColabTestLogger(verbose=verbose)

    if auto_setup and interactive_setup:
        logger.warning("Both --auto-setup and --interactive-setup provided; proceeding with automatic setup.")
        interactive_setup = False

    # Auto-detect platform if not specified
    if platform is None:
        platform = detect_platform()

    # Validate notebook path
    notebook_path = Path(notebook_path).resolve()
    if not notebook_path.exists():
        logger.error(f"Notebook not found: {notebook_path}")
        return 1
    if not notebook_path.suffix == '.ipynb':
        logger.error(f"File is not a notebook: {notebook_path}")
        return 1

    logger.step("Checking Docker environment")
    docker_ok, error_msg = check_docker()
    if not docker_ok:
        logger.error(error_msg)
        return 1
    success, error_msg = pull_docker_image(logger, force_pull=False, show_docker_output=False)
    if not success:
        logger.error(error_msg)
        return 1

    try:
        modules = extract_imported_modules_from_notebook(str(notebook_path))
    except Exception as e:
        modules = set()
        logger.info(f"AST parse failed: {e}", force=True)

    if not modules:
        logger.success("No imports detected or AST parse failed; nothing to check.")
        return 0

    with tempfile.TemporaryDirectory() as temp_dir:
        # Prepare precheck runner
        precheck_script = (
            "import json, importlib.util\n"
            "mods = json.load(open('/tmp/test/modules.json'))\n"
            "missing = []\n"
            "for m in mods:\n"
            "    try:\n"
            "        ok = importlib.util.find_spec(m) is not None\n"
            "    except Exception:\n"
            "        ok = False\n"
            "    if not ok:\n"
            "        missing.append(m)\n"
            "print(json.dumps({'missing': missing}))\n"
        )
        (Path(temp_dir) / 'precheck.py').write_text(precheck_script)
        (Path(temp_dir) / 'modules.json').write_text(json.dumps(sorted(modules)))

        pre_container_name = f"colab-test-pre-{os.getpid()}"
        pre_cmd = [
            'docker', 'run', '--rm',
            '--name', pre_container_name,
        ]
        if platform:
            pre_cmd.extend(['--platform', platform])
        pre_cmd.extend([
            '-v', f'{temp_dir}:/tmp/test:rw',
            '--entrypoint', 'python',
            DOCKER_IMAGE,
            '/tmp/test/precheck.py',
        ])

        pre_res = subprocess.run(pre_cmd, capture_output=True, text=True)
        if pre_res.returncode == 0 and pre_res.stdout:
            try:
                data = json.loads(pre_res.stdout.strip().splitlines()[-1])
                missing_mods = data.get('missing') or []
            except Exception:
                missing_mods = []
        else:
            missing_mods = []

        if not missing_mods:
            logger.success("All imports appear available in the Colab runtime.")
            return 0

        pkgs = resolve_modules_to_packages(set(missing_mods))
        logger.warning("Missing packages: " + ", ".join(pkgs))

        should_apply = auto_setup
        if not should_apply and interactive_setup:
            try:
                resp = input("Insert a Colab Setup cell to install these packages? [y/N]: ").strip().lower()
                should_apply = resp in ("y", "yes")
            except Exception:
                should_apply = False

        if should_apply:
            cell_code = generate_missing_packages_cell(pkgs)
            try:
                created = insert_setup_cell(str(notebook_path), cell_code)
                if created:
                    logger.success("Inserted Colab Setup cell.")
                else:
                    logger.info("Setup cell already present; no changes made.", force=True)
            except Exception as e:
                logger.error(f"Failed to insert setup cell: {e}")

        return 0

