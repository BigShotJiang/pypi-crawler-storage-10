"""Tests for pkgsizer."""

