mod color_map;
mod compare;
mod overlay;
mod utils;

pub(crate) use compare::wplace_template_compare;
pub(crate) use overlay::wplace_template_overlay;
