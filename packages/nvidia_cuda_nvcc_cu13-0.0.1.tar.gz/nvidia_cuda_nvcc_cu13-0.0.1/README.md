⚠️ THIS PROJECT 'nvidia-cuda-nvcc-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-nvcc' instead.

To install the correct package, use:

    pip install nvidia-cuda-nvcc

For more information, visit: https://pypi.org/project/nvidia-cuda-nvcc/
