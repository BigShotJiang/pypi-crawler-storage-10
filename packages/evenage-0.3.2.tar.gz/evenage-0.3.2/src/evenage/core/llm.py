"""
LLM backend implementations.

Provides pluggable LLM backends: NoOp (echo), OpenAI, Anthropic, Gemini.
"""

from __future__ import annotations

from typing import Any


class NoOpLLM:
    """
    No-op LLM backend that echoes prompts.
    
    Useful for testing and local dev without API keys.
    """
    
    async def generate(self, prompt: str, system: str | None = None, **kwargs) -> str:
        """Echo the prompt as response."""
        return f"[NoOpLLM Echo] Prompt: {prompt[:100]}..."


class OpenAILLM:
    """OpenAI LLM backend."""
    
    def __init__(self, api_key: str | None):
        self.api_key = api_key
        self._client = None
    
    async def generate(self, prompt: str, system: str | None = None, **kwargs) -> str:
        """Generate response using OpenAI."""
        if not self.api_key:
            raise ValueError("OpenAI API key not configured")
        
        if self._client is None:
            try:
                import openai
                self._client = openai.AsyncOpenAI(api_key=self.api_key)
            except ImportError:
                raise RuntimeError("openai package not installed. Install with: pip install openai")
        
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        
        response = await self._client.chat.completions.create(
            model=kwargs.get("model", "gpt-4"),
            messages=messages,
            temperature=kwargs.get("temperature", 0.7),
            max_tokens=kwargs.get("max_tokens", 1000)
        )
        
        return response.choices[0].message.content


class AnthropicLLM:
    """Anthropic LLM backend."""
    
    def __init__(self, api_key: str | None):
        self.api_key = api_key
        self._client = None
    
    async def generate(self, prompt: str, system: str | None = None, **kwargs) -> str:
        """Generate response using Anthropic."""
        if not self.api_key:
            raise ValueError("Anthropic API key not configured")
        
        if self._client is None:
            try:
                import anthropic
                self._client = anthropic.AsyncAnthropic(api_key=self.api_key)
            except ImportError:
                raise RuntimeError("anthropic package not installed. Install with: pip install anthropic")
        
        response = await self._client.messages.create(
            model=kwargs.get("model", "claude-3-sonnet-20240229"),
            max_tokens=kwargs.get("max_tokens", 1000),
            system=system or "",
            messages=[{"role": "user", "content": prompt}]
        )
        
        return response.content[0].text


class GeminiLLM:
    """Google Gemini LLM backend."""
    
    def __init__(self, api_key: str | None):
        self.api_key = api_key
        self._model = None
    
    async def generate(self, prompt: str, system: str | None = None, **kwargs) -> str:
        """Generate response using Gemini."""
        if not self.api_key:
            raise ValueError("Gemini API key not configured")
        
        if self._model is None:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self._model = genai.GenerativeModel(kwargs.get("model", "gemini-pro"))
            except ImportError:
                raise RuntimeError("google-generativeai package not installed. Install with: pip install google-generativeai")
        
        full_prompt = prompt
        if system:
            full_prompt = f"{system}\n\n{prompt}"
        
        response = await self._model.generate_content_async(full_prompt)
        return response.text
