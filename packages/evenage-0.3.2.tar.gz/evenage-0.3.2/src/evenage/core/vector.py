"""
Vector store backend implementations.

Provides pluggable vector stores: LocalVectorStore (filesystem).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


class LocalVectorStore:
    """
    Local filesystem-based vector store for dev.
    
    Stores vectors as JSON files. Not suitable for production scale.
    """
    
    def __init__(self, storage_path: str = "./.evenage/vectors"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
    
    def store(self, key: str, vector: list[float], metadata: dict) -> None:
        """Store a vector with metadata."""
        data = {
            "key": key,
            "vector": vector,
            "metadata": metadata
        }
        
        file_path = self.storage_path / f"{self._sanitize_key(key)}.json"
        with open(file_path, "w") as f:
            json.dump(data, f)
    
    def search(self, vector: list[float], k: int = 5) -> list[dict]:
        """
        Search for k nearest vectors.
        
        Uses simple cosine similarity (inefficient for large scale).
        """
        results = []
        
        for file_path in self.storage_path.glob("*.json"):
            try:
                with open(file_path) as f:
                    data = json.load(f)
                
                stored_vector = data["vector"]
                similarity = self._cosine_similarity(vector, stored_vector)
                
                results.append({
                    "key": data["key"],
                    "metadata": data["metadata"],
                    "similarity": similarity
                })
            except Exception:
                continue
        
        # Sort by similarity and return top k
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:k]
    
    def delete(self, key: str) -> None:
        """Delete a vector by key."""
        file_path = self.storage_path / f"{self._sanitize_key(key)}.json"
        if file_path.exists():
            file_path.unlink()
    
    def _sanitize_key(self, key: str) -> str:
        """Sanitize key for use as filename."""
        return key.replace("/", "_").replace("\\", "_").replace(":", "_")
    
    def _cosine_similarity(self, a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if len(a) != len(b):
            return 0.0
        
        dot_product = sum(x * y for x, y in zip(a, b))
        magnitude_a = sum(x * x for x in a) ** 0.5
        magnitude_b = sum(y * y for y in b) ** 0.5
        
        if magnitude_a == 0 or magnitude_b == 0:
            return 0.0
        
        return dot_product / (magnitude_a * magnitude_b)
