# Ruby Manager Web3

A comprehensive Python package for Web3 interactions with Ruby-style address formatting, specifically designed for POA blockchains like Ruby Chain. This package provides a seamless interface for blockchain operations with automatic conversion between Ruby-style addresses (`r...`) and standard hex addresses (`0x...`).

## Features

- 🎯 **Ruby-style Address Formatting**: Automatic conversion between `r...` and `0x...` formats
- ⛓️ **POA Blockchain Support**: Optimized for Ruby Chain (Chain ID: 18359)
- 💰 **Token Management**: Full ERC20 token support with balance checking and transfers
- 🔄 **Batch Operations**: Multicall support for efficient contract interactions
- 📊 **Event Listening**: Real-time blockchain event monitoring
- 💸 **Price Feeds**: Cryptocurrency price data from CoinGecko API
- 🔐 **Wallet Management**: Create, recover, and manage wallets
- ⚡ **Gas Optimization**: Smart gas estimation and transaction management
- 🛡️ **Security**: Comprehensive input validation and error handling

## Installation

### From PyPI
```bash
pip install ruby-manager-web3
```

### From Source
```bash
git clone https://github.com/yourusername/ruby-manager-web3.git
cd ruby-manager-web3
pip install -e .
```

## Quick Start

### Basic Setup
```python
from ruby_manager_web3 import RubyWeb3Manager

# Initialize with Ruby Chain RPC
manager = RubyWeb3Manager(
    provider_url="https://bridge-rpc.rubyscan.io",
    private_key="your_private_key_here",  # Optional
    chain_id=18359
)

# Check connection
if manager.is_connected:
    print("✅ Connected to Ruby Chain!")

# Get current block number
block_number = manager.get_block_number()
print(f"Current block: {block_number}")
```

### Wallet Management
```python
# Create a new wallet
wallet = manager.create_wallet()
print(f"New Ruby Address: {wallet['address']}")  # Starts with 'r'
print(f"Private Key: {wallet['private_key']}")

# Set existing account
manager.set_account("your_private_key")
ruby_address = manager.get_ruby_address()
print(f"Your Ruby Address: {ruby_address}")

# Get balance
balance = manager.get_balance_ruby()
print(f"Balance: {balance} RUBY")
```

### Send Transactions
```python
# Send native coins
tx_hash = manager.send_coin(
    to_address="rRECIPIENT_ADDRESS_HERE",
    amount=1.5,  # 1.5 RUBY
    gas_limit=21000
)
print(f"Transaction sent: {tx_hash}")  # Returns Ruby format hash

# Wait for confirmation
receipt = manager.wait_for_transaction(tx_hash)
print(f"Transaction confirmed in block: {receipt['blockNumber']}")
```

## Core Components

### 1. RubyWeb3Manager
The main manager class for blockchain operations.

```python
from ruby_manager_web3 import RubyWeb3Manager

manager = RubyWeb3Manager("https://bridge-rpc.rubyscan.io")

# Network information
network_info = manager.get_network_info()
print(f"Chain ID: {network_info['chain_id']}")
print(f"Peer Count: {network_info['peer_count']}")

# Block operations
latest_block = manager.get_block_details('latest')
print(f"Block Hash: {latest_block['hash']}")

# Transaction history
tx_history = manager.get_transaction_history("rYOUR_ADDRESS")
for tx in tx_history:
    print(f"TX: {tx['hash']} - Value: {tx['value_eth']} RUBY")
```

### 2. Token Management
```python
from ruby_manager_web3 import TokenManager

token_manager = TokenManager(manager)

# Get token information
token_info = token_manager.get_token_info("rTOKEN_CONTRACT_ADDRESS")
print(f"Token: {token_info.name} ({token_info.symbol})")
print(f"Decimals: {token_info.decimals}")

# Get token balance
balance = token_manager.get_token_balance(
    "rTOKEN_CONTRACT_ADDRESS", 
    "rYOUR_WALLET_ADDRESS"
)
print(f"Balance: {balance.readable_balance} {token_info.symbol}")

# Transfer tokens
tx_hash = token_manager.transfer_token(
    token_address="rTOKEN_CONTRACT_ADDRESS",
    to_address="rRECIPIENT_ADDRESS",
    amount=100.0
)
print(f"Token transfer TX: {tx_hash}")

```
### 4. Event Service
```python
from ruby_manager_web3 import EventService

event_service = EventService(manager)

# Listen for token transfers
def handle_transfer(event):
    print(f"Transfer: {event['args']['from']} -> {event['args']['to']}")
    print(f"Amount: {event['args']['value']}")

# Start listening in background thread
event_service.listen_for_transfers(
    token_address="rTOKEN_CONTRACT_ADDRESS",
    callback=handle_transfer,
    poll_interval=5
)

# Get pending transactions
pending_txs = event_service.get_pending_transactions()
print(f"Pending transactions: {len(pending_txs)}")
```

### 5. Multicall Service
```python
from ruby_manager_web3 import MulticallService

multicall = MulticallService(manager)

# Batch multiple contract calls
calls = [
    ("rTOKEN1_ADDRESS", "balanceOf(address)", ["rYOUR_ADDRESS"]),
    ("rTOKEN2_ADDRESS", "balanceOf(address)", ["rYOUR_ADDRESS"]),
    ("rTOKEN3_ADDRESS", "totalSupply()", [])
]

try:
    block_number, results = multicall.multicall(calls)
    print(f"Block: {block_number}")
    print(f"Results: {results}")
except Exception as e:
    print(f"Multicall not available: {e}")
```

### 6. Price Feed Service
```python
from ruby_manager_web3 import PriceFeedService

price_service = PriceFeedService()

# Get current prices
eth_price = price_service.get_token_price('ethereum')
btc_price = price_service.get_token_price('bitcoin')
print(f"ETH: ${eth_price:.2f}")
print(f"BTC: ${btc_price:.2f}")

# Get multiple prices
prices = price_service.get_multiple_prices(['ethereum', 'bitcoin', 'matic-network'])
for token, price in prices.items():
    print(f"{token}: ${price:.2f}")

# Convert between tokens
converted = price_service.convert_value('ethereum', 'bitcoin', 1.0)
print(f"1 ETH = {converted:.6f} BTC")
```

## Address Format Conversion

The package automatically handles Ruby-style address formatting:

```python
from ruby_manager_web3 import RubyConverter

# Convert to Ruby format
hex_address = "0x742d35Cc6634C0532925a3b8Dc9F5a6f6E8c8f6E"
ruby_address = RubyConverter.to_ruby_format(hex_address)
print(ruby_address)  # "r742d35Cc6634C0532925a3b8Dc9F5a6f6E8c8f6E"

# Convert from Ruby format
original_hex = RubyConverter.from_ruby_format(ruby_address)
print(original_hex)  # "0x742d35Cc6634C0532925a3b8Dc9F5a6f6E8c8f6E"

# Normalize private keys
private_key = "abc123..."  # Without 0x prefix
normalized = RubyConverter.normalize_private_key(private_key)
print(normalized)  # "0xabc123..."
```

## Advanced Usage

### Contract Deployment
```python
# Deploy a new contract
contract_abi = [...]  # Your contract ABI
contract_bytecode = "0x..."  # Your contract bytecode

tx_hash = manager.deploy_contract(
    abi=contract_abi,
    bytecode=contract_bytecode,
    args=[],  # Constructor arguments
    gas_limit=2000000
)

# Get deployed contract address
receipt = manager.wait_for_transaction(tx_hash)
contract_address = manager.get_contract_address_from_tx(tx_hash)
print(f"Contract deployed at: {contract_address}")
```

### Gas Management
```python
# Get gas estimate
gas_estimate = manager.get_gas_estimate(
    to_address="rRECIPIENT_ADDRESS",
    value=1.0
)
print(f"Gas Limit: {gas_estimate.gas_limit}")
print(f"Gas Price: {gas_estimate.gas_price}")
print(f"Total Cost: {gas_estimate.total_cost_eth} RUBY")

# Cancel pending transaction
cancel_tx_hash = manager.cancel_transaction(nonce=5)
print(f"Cancel transaction: {cancel_tx_hash}")

# Speed up pending transaction
speed_tx_hash = manager.speed_up_transaction(nonce=5)
print(f"Speed up transaction: {speed_tx_hash}")
```

### Batch Operations
```python
# Send multiple transactions
transactions = [
    {'to': 'rADDRESS1', 'amount': 0.1},
    {'to': 'rADDRESS2', 'amount': 0.2},
    {'to': 'rADDRESS3', 'amount': 0.3}
]

tx_hashes = manager.send_batch_transactions(transactions)
for i, tx_hash in enumerate(tx_hashes):
    if tx_hash:
        print(f"Transaction {i+1}: {tx_hash}")
```

## Configuration

### Environment Variables
Create a `.env` file:

```env
WEB3_PROVIDER_URL=https://bridge-rpc.rubyscan.io
PRIVATE_KEY=your_private_key_here
CHAIN_ID=18359
```

### Custom Configuration
```python
from ruby_manager_web3 import RubyWeb3Manager
import os
from dotenv import load_dotenv

load_dotenv()

manager = RubyWeb3Manager(
    provider_url=os.getenv('WEB3_PROVIDER_URL'),
    private_key=os.getenv('PRIVATE_KEY'),
    chain_id=int(os.getenv('CHAIN_ID', 18359)),
    timeout=30  # Request timeout in seconds
)
```

## Error Handling

```python
from ruby_manager_web3 import RubyWeb3Error, TransactionError

try:
    tx_hash = manager.send_coin("rINVALID_ADDRESS", 1.0)
except RubyWeb3Error as e:
    print(f"Error: {e}")
    
try:
    receipt = manager.wait_for_transaction("rINVALID_HASH")
except TransactionError as e:
    print(f"Transaction error: {e}")
```

## API Reference

### Core Classes

#### RubyWeb3Manager
- `create_wallet()` - Create new wallet
- `get_balance_ruby()` - Get balance in RUBY
- `send_coin()` - Send native coins
- `send_token()` - Send ERC20 tokens
- `get_transaction_details()` - Get transaction info
- `deploy_contract()` - Deploy new contract
- `get_block_details()` - Get block information

#### TokenManager
- `get_token_info()` - Get token metadata
- `get_token_balance()` - Get token balance
- `transfer_token()` - Transfer tokens
- `approve_token()` - Approve token spending



#### EventService
- `listen_for_events()` - Listen for contract events
- `listen_for_transfers()` - Listen for token transfers
- `get_pending_transactions()` - Get mempool transactions

## Examples

Check the `examples/` directory for complete working examples:

- `basic_usage.py` - Basic wallet and transaction operations
- `wallet_management.py` - Wallet creation and management
- `token_operations.py` - ERC20 token operations
- `defi_operations.py` - DeFi protocol interactions
- `advanced_operations.py` - Advanced blockchain operations

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Development

### Setup Development Environment
```bash
git clone https://github.com/yourusername/ruby-manager-web3.git
cd ruby-manager-web3
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -e ".[dev]"
```

### Running Tests
```bash
pytest tests/
```

### Building Documentation
```bash
pip install pdoc
pdoc --html ruby_manager_web3 --output-dir docs
```

## Security

### Private Key Safety
- Never commit private keys to version control
- Use environment variables for configuration
- Consider using hardware wallets for large amounts

### Input Validation
All user inputs are validated:
- Address format validation
- Amount validation
- Gas parameter validation
- Transaction hash validation

## Support

- 📚 [Documentation](https://github.com/yourusername/ruby-manager-web3/wiki)
- 🐛 [Issue Tracker](https://github.com/yourusername/ruby-manager-web3/issues)
- 💬 [Discussions](https://github.com/yourusername/ruby-manager-web3/discussions)
- 📧 [Email Support](mailto:support@example.com)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [Web3.py](https://github.com/ethereum/web3.py) - Ethereum Python library
- [Ruby Chain](https://rubychain.xyz) - POA blockchain platform
- [CoinGecko](https://www.coingecko.com/) - Cryptocurrency price data

---

**Note**: This package is in active development. Always test with small amounts first and ensure you understand the transactions you're signing.

For the latest updates and breaking changes, please check the [Release Notes](https://github.com/yourusername/ruby-manager-web3/releases).