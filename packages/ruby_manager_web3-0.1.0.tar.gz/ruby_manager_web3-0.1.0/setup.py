from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ruby-manager-web3",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python package for Ruby-style Web3 interactions with POA blockchain",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=[
        "web3>=6.0.0",
        "eth-account>=0.8.0",
        "requests>=2.25.0",
        "python-dotenv>=0.19.0",
        "cryptography>=3.4.0",
        "eth-hash>=0.5.0",
        "eth-typing>=3.0.0",
        "eth-utils>=2.0.0",
        "hexbytes>=0.2.0",
        "protobuf>=3.19.0",
        "pycryptodome>=3.10.0",
        "lru-dict>=1.1.0",
    ],
    keywords="web3, blockchain, ruby, poa, rubyscan, ethereum, smart-contracts",
    url="https://github.com/yourusername/ruby-manager-web3",
    project_urls={
        "Bug Tracker": "https://github.com/yourusername/ruby-manager-web3/issues",
        "Documentation": "https://github.com/yourusername/ruby-manager-web3#readme",
        "Source Code": "https://github.com/yourusername/ruby-manager-web3",
    },
)