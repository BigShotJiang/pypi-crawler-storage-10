# KALKI-6

idk why the fuck i made this, but yeah 
just fucking use it if you want 


##  Install this shit
pip install KALKI-6

# and use like this
pari 69.69.69.69