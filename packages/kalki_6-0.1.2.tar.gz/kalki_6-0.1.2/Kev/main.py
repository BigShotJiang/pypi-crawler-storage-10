import sys
import json
import argparse
import requests

__version__ = "0.1.2"

# Optional token
TOKEN = "d4ee6c4b21280f"

def query_ip(ip_or_empty: str):
 

    base_url = "https://api.ipinfo.io/lite"
    url = f"{base_url}/{ip_or_empty}?token={TOKEN}" if TOKEN else f"{base_url}/{ip_or_empty}"
    if not ip_or_empty:
        url = f"{base_url}?token={TOKEN}" if TOKEN else base_url

    try:
        resp = requests.get(url, timeout=8)
    except requests.RequestException as e:
        raise RuntimeError(f"Network error: {e}")

    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {resp.text}")

    return resp.json()

def pretty_print(data):
    """Print JSON nicely"""
    print(json.dumps(data, indent=2, ensure_ascii=False))

def cli(argv=None):
    parser = argparse.ArgumentParser(
        prog="PARI",
        description="Query ipinfo.io lite for IP info"
    )
    parser.add_argument("ip", nargs="?", default="", help="IP address to lookup (optional).")
    parser.add_argument("--raw", action="store_true", help="Print raw JSON output.")
    parser.add_argument("--version", action="store_true", help="Show version and exit.")
    parser.add_argument("--token", help="Use a custom ipinfo token.")
    
    args = parser.parse_args(argv)

    if args.version:
        print(f"KEV {__version__}")
        return 0

    # Override token if provided via CLI
    global TOKEN
    if args.token:
        TOKEN = args.token

    try:
        data = query_ip(args.ip)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2

    if args.raw:
        print(json.dumps(data, ensure_ascii=False))
    else:
        pretty_print(data)

    return 0

if __name__ == "__main__":
    raise SystemExit(cli())