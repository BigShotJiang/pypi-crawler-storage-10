from __future__ import annotations

import csv
import random
import time
from typing import cast

from aiohttp import ClientSession
import jwt

from pymammotion.const import MAMMOTION_API_DOMAIN, MAMMOTION_CLIENT_ID, MAMMOTION_CLIENT_SECRET, MAMMOTION_DOMAIN
from pymammotion.http.encryption import EncryptionUtils
from pymammotion.http.model.camera_stream import StreamSubscriptionResponse, VideoResourceResponse
from pymammotion.http.model.http import (
    CheckDeviceVersion,
    DeviceInfo,
    DeviceRecords,
    ErrorInfo,
    JWTTokenInfo,
    LoginResponseData,
    MQTTConnection,
    Response,
)
from pymammotion.http.model.response_factory import response_factory
from pymammotion.http.model.rtk import RTK


class MammotionHTTP:
    def __init__(self, account: str | None = None, password: str | None = None) -> None:
        self.device_info: list[DeviceInfo] = []
        self.mqtt_credentials: MQTTConnection | None = None
        self.device_records: DeviceRecords = DeviceRecords(records=[], current=0, total=0, size=0, pages=0)
        self.expires_in = 0.0
        self.code = 0
        self.msg = None
        self.account = account
        self._password = password
        self._response: Response | None = None
        self.login_info: LoginResponseData | None = None
        self.jwt_info: JWTTokenInfo = JWTTokenInfo("", "")
        self._headers = {"User-Agent": "okhttp/4.9.3", "App-Version": "Home Assistant,1.14.2.29"}
        self.encryption_utils = EncryptionUtils()

        # Add this method to generate a 10-digit random number
        def get_10_random() -> str:
            """Generate a 10-digit random number as a string."""
            return "".join([str(random.randint(0, 9)) for _ in range(7)])

        # Replace the line in the __init__ method with:
        self.client_id = f"{int(time.time() * 1000)}_{get_10_random()}_1"

    @property
    def response(self) -> Response | None:
        return self._response

    @response.setter
    def response(self, response: Response) -> None:
        self._response = response
        decoded_token = jwt.decode(response.data.access_token, options={"verify_signature": False})
        if isinstance(decoded_token, dict):
            self.jwt_info = JWTTokenInfo(iot=decoded_token.get("iot", ""), robot=decoded_token.get("robot", ""))

    @staticmethod
    def generate_headers(token: str) -> dict:
        return {"Authorization": f"Bearer {token}"}

    async def handle_expiry(self, resp: Response) -> Response:
        if resp.code == 401 and self.account and self._password:
            return await self.login(self.account, self._password)
        return resp

    async def login_by_email(self, email: str, password: str) -> Response[LoginResponseData]:
        return await self.login(email, password)

    async def get_all_error_codes(self) -> dict[str, ErrorInfo]:
        """Retrieves and parses all error codes from the MAMMOTION API."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/user-server/v1/code/record/export-data",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                reader = csv.DictReader(data.get("data", "").split("\n"), delimiter=",")
                codes = dict()
                for row in reader:
                    error_info = ErrorInfo(**cast(dict, row))
                    codes[error_info.code] = error_info
                return codes

    async def oauth_check(self) -> Response:
        """Check if token is valid.

        Returns 401 if token is invalid. We then need to re-authenticate, can try to refresh token first
        """
        async with ClientSession(MAMMOTION_DOMAIN) as session:
            async with session.post(
                "/user-server/v1/user/oauth/check",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                return Response.from_dict(data)

    async def refresh_token(self) -> Response:
        """Refresh token."""
        async with ClientSession(MAMMOTION_DOMAIN) as session:
            async with session.post(
                "/authorization/code",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
                json={"clientId": MAMMOTION_CLIENT_ID},
            ) as resp:
                data = await resp.json()

                self.login_info.access_token = data["data"].get("accessToken", self.login_info.access_token)
                self.login_info.authorization_code = data["data"].get("code", self.login_info.authorization_code)
                await self.get_mqtt_credentials()
                return Response.from_dict(data)

    async def pair_devices_mqtt(self, mower_name: str, rtk_name: str) -> Response:
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/iot/device/pairing",
                headers=self._headers,
                json={"mowerName": mower_name, "rtkName": rtk_name},
            ) as resp:
                data = await resp.json()
                if data.get("status") == 200:
                    print(data)
                    return Response.from_dict(data)
                else:
                    print(data)
                    return Response.from_dict(data)

    async def unpair_devices_mqtt(self, mower_name: str, rtk_name: str) -> Response:
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/iot/device/unpairing",
                headers=self._headers,
                json={"mowerName": mower_name, "rtkName": rtk_name},
            ) as resp:
                data = await resp.json()
                if data.get("status") == 200:
                    print(data)
                    return Response.from_dict(data)
                else:
                    print(data)
                    return Response.from_dict(data)

    async def net_rtk_enable(self, device_id: str) -> Response:
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/iot/net-rtk/enable", headers=self._headers, json={"deviceId": device_id}
            ) as resp:
                data = await resp.json()
                if data.get("status") == 200:
                    print(data)
                    return Response.from_dict(data)
                else:
                    print(data)
                    return Response.from_dict(data)

    async def get_stream_subscription(self, iot_id: str) -> Response[StreamSubscriptionResponse]:
        """Fetches stream subscription data from agora.io for a given IoT device."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/stream/subscription",
                json={"deviceId": iot_id},
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                # TODO catch errors from mismatch like token expire etc
                # Assuming the data format matches the expected structure
                response = Response[StreamSubscriptionResponse].from_dict(data)
                await self.handle_expiry(response)
                if response.code != 0:
                    return response
                response.data = StreamSubscriptionResponse.from_dict(data.get("data", {}))
                return response

    async def get_stream_subscription_mini_or_x_series(
        self, iot_id: str, is_yuka: bool
    ) -> Response[StreamSubscriptionResponse]:
        # Prepare the payload with cameraStates based on is_yuka flag
        """Fetches stream subscription data for a given IoT device."""

        payload = {"deviceId": iot_id, "mode": 0, "cameraStates": []}

        # Add appropriate cameraStates based on the is_yuka flag
        if is_yuka:
            payload["cameraStates"] = [{"cameraState": 1}, {"cameraState": 0}, {"cameraState": 1}]
        else:
            payload["cameraStates"] = [{"cameraState": 1}, {"cameraState": 0}, {"cameraState": 0}]

        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/stream/token",
                json=payload,
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                # TODO catch errors from mismatch like token expire etc
                # Assuming the data format matches the expected structure
                response = Response[StreamSubscriptionResponse].from_dict(data)
                await self.handle_expiry(response)
                if response.code != 0:
                    return response
                response.data = StreamSubscriptionResponse.from_dict(data.get("data", {}))
                return response

    async def get_video_resource(self, iot_id: str) -> Response[VideoResourceResponse]:
        """Fetch video resource for a given IoT ID."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.get(
                f"/device-server/v1/video-resource/{iot_id}",
                headers={
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                # TODO catch errors from mismatch like token expire etc
                # Assuming the data format matches the expected structure
                response = Response[VideoResourceResponse].from_dict(data)
                if response.code != 0:
                    return response
                response.data = VideoResourceResponse.from_dict(data.get("data", {}))
                return response

    async def get_device_ota_firmware(self, iot_ids: list[str]) -> Response[list[CheckDeviceVersion]]:
        """Checks device firmware versions for a list of IoT IDs."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/devices/version/check",
                json={"deviceIds": iot_ids},
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                # TODO catch errors from mismatch like token expire etc
                # Assuming the data format matches the expected structure
                return response_factory(Response[list[CheckDeviceVersion]], data)

    async def start_ota_upgrade(self, iot_id: str, version: str) -> Response[str]:
        """Initiates an OTA upgrade for a device."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.post(
                "/device-server/v1/ota/device/upgrade",
                json={"deviceId": iot_id, "version": version},
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()
                # TODO catch errors from mismatch like token expire etc
                # Assuming the data format matches the expected structure
                return response_factory(Response[str], data)

    async def get_rtk_devices(self) -> Response[list[RTK]]:
        """Fetches stream subscription data from agora.io for a given IoT device."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.get(
                "/device-server/v1/rtk/devices",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                data = await resp.json()

                return response_factory(Response[list[RTK]], data)

    async def get_user_device_list(self) -> Response[list[DeviceInfo]]:
        """Fetches device list for a user, older devices / aliyun."""
        async with ClientSession(MAMMOTION_API_DOMAIN) as session:
            async with session.get(
                "/device-server/v1/device/list",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                resp_dict = await resp.json()
                response = response_factory(Response[list[DeviceInfo]], resp_dict)
                self.device_info = response.data if response.data else self.device_info
                return response

    async def get_user_device_page(self) -> Response[DeviceRecords]:
        """Fetches device list for a user, is either new API or for newer devices."""
        async with ClientSession(self.jwt_info.iot) as session:
            async with session.post(
                "/v1/user/device/page",
                json={
                    "iotId": "",
                    "pageNumber": 1,
                    "pageSize": 100,
                },
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                    "Client-Id": self.client_id,
                    "Client-Type": "1",
                },
            ) as resp:
                if resp.status != 200:
                    return Response.from_dict({"code": resp.status, "msg": "get device list failed"})
                resp_dict = await resp.json()
                response = response_factory(Response[DeviceRecords], resp_dict)
                self.device_records = response.data if response.data else self.device_records
                return response

    async def get_mqtt_credentials(self) -> Response[MQTTConnection]:
        """Get mammotion mqtt credentials"""
        async with ClientSession(self.jwt_info.iot) as session:
            async with session.post(
                "/v1/mqtt/auth/jwt",
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                },
            ) as resp:
                if resp.status != 200:
                    return Response.from_dict({"code": resp.status, "msg": "get mqtt failed"})
                resp_dict = await resp.json()
                response = response_factory(Response[MQTTConnection], resp_dict)
                self.mqtt_credentials = response.data
                return response

    async def mqtt_invoke(self, content: str, device_name: str, iot_id: str) -> Response[dict]:
        """Send mqtt commands to devices."""
        async with ClientSession(self.jwt_info.iot) as session:
            async with session.post(
                "/v1/mqtt/rpc/thing/service/invoke",
                json={"args": {"content": content, "deviceName": device_name, "iotId": iot_id, "productKey": ""}},
                headers={
                    **self._headers,
                    "Authorization": f"Bearer {self.login_info.access_token}",
                    "Content-Type": "application/json",
                    "User-Agent": "okhttp/4.9.3",
                    "Client-Id": self.client_id,
                    "Client-Type": "1",
                },
            ) as resp:
                if resp.status != 200:
                    return Response.from_dict({"code": resp.status, "msg": "get mqtt failed"})
                resp_dict = await resp.json()
                return response_factory(Response[dict], resp_dict)

    async def refresh_login(self) -> Response[LoginResponseData]:
        if self.expires_in > time.time():
            res = await self.refresh_token()
            if res.code == 0:
                return res
        return await self.login(self.account, self._password)

    async def login(self, account: str, password: str) -> Response[LoginResponseData]:
        """Logs in to the service using provided account and password."""
        self.account = account
        self._password = password
        async with ClientSession(MAMMOTION_DOMAIN) as session:
            async with session.post(
                "/oauth/token",
                headers={
                    **self._headers,
                    "Encrypt-Key": self.encryption_utils.encrypt_by_public_key(),
                    "Decrypt-Type": "3",
                    "Ec-Version": "v1",
                },
                params={
                    "username": self.encryption_utils.encryption_by_aes(account),
                    "password": self.encryption_utils.encryption_by_aes(password),
                    "client_id": self.encryption_utils.encryption_by_aes(MAMMOTION_CLIENT_ID),
                    "client_secret": self.encryption_utils.encryption_by_aes(MAMMOTION_CLIENT_SECRET),
                    "grant_type": self.encryption_utils.encryption_by_aes("password"),
                },
            ) as resp:
                if resp.status != 200:
                    print(resp.json())
                    return Response.from_dict({"code": resp.status, "msg": "Login failed"})
                data = await resp.json()
                login_response = response_factory(Response[LoginResponseData], data)
                if login_response is None or login_response.data is None:
                    print(login_response)
                    return Response.from_dict({"code": resp.status, "msg": "Login failed"})
                self.login_info = login_response.data
                self.expires_in = login_response.data.expires_in + time.time()
                self._headers["Authorization"] = (
                    f"Bearer {self.login_info.access_token}" if login_response.data else None
                )
                self.response = login_response
                self.msg = login_response.msg
                self.code = login_response.code
                # TODO catch errors from mismatch user / password elsewhere
                # Assuming the data format matches the expected structure
                return login_response
