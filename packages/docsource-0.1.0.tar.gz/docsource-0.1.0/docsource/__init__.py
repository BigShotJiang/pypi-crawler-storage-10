"""
docsource: Parse, check and update doc-string documentation

Copyright 2025, Levente Hunyadi

:see: https://github.com/hunyadi/docsource
"""

__version__ = "0.1.0"
__author__ = "Levente Hunyadi"
__copyright__ = "Copyright 2025, Levente Hunyadi"
__license__ = "MIT"
__maintainer__ = "Levente Hunyadi"
__status__ = "Production"
