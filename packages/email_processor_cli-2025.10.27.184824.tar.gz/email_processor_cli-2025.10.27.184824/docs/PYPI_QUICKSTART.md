# 🚀 PyPI Quick Start

## Publicar en 3 Pasos

### 1. Configurar Token

Crear `~/.pypirc` (Linux/Mac) o `%USERPROFILE%\.pypirc` (Windows):

```ini
[pypi]
username = __token__
password = pypi-TU-TOKEN-AQUI
```

### 2. Ejecutar Script

**Windows:**
```cmd
cd scripts
publish_pypi.bat
```

**Linux/Mac:**
```bash
cd scripts
chmod +x publish_pypi.sh
./publish_pypi.sh
```

### 3. Verificar

Visitar: https://pypi.org/project/email-processor-cli/

## Instalación por Usuarios

```bash
pip install email-processor-cli
```

## Uso

```bash
email-processor --input-type list --input "user@old.com" --new-domain new.com --output-type inline
```

## Actualizar Versión

1. Editar `setup.py` y `pyproject.toml`:
   ```python
   version="1.0.1"  # Incrementar
   ```

2. Ejecutar script de publicación nuevamente

---

Ver [PYPI_DEPLOYMENT.md](PYPI_DEPLOYMENT.md) para guía completa.
