# Colibri Code Functions
