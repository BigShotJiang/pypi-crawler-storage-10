"""Prometheus MCP Server.

A Model Context Protocol (MCP) server that enables AI assistants to query
and analyze Prometheus metrics through standardized interfaces.
"""

__version__ = "1.0.0"
