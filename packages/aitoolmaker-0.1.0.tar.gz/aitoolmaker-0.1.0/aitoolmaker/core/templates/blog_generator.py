"""
Blog Generator template for AIToolMaker.
"""

BLOG_GENERATOR_TEMPLATE = """import streamlit as st
import google.generativeai as genai
from api_key import GEMINI_API_KEY

# Configure Gemini API
genai.configure(api_key=GEMINI_API_KEY)

generation_config = {
    'temperature': 0.9,
    'top_p': 1,
    'top_k': 1,
    'max_output_tokens': 2048,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

model = genai.GenerativeModel(
    model_name='{{ model }}',
    generation_config=generation_config,
    safety_settings=safety_settings
)

# Page config
st.set_page_config(layout="wide")

# Main content
st.title('📝 {{ tool_name }}')
st.subheader('Now you can craft perfect blogs with the help of AI')

# Sidebar configuration
with st.sidebar:
    st.title('📋 Blog Configuration')
    st.subheader('Enter details of the blog you want to generate')
    
    blog_title = st.text_input('Blog Title')
    keywords = st.text_input('Keywords (comma-separated)')
    num_words = st.slider('Number of words', min_value=200, max_value=2500, step=250)
    
    submit_button = st.button('Generate Blog')

# Generate blog
if submit_button:
    if not blog_title:
        st.warning("Please enter a blog title.")
    else:
        with st.spinner('Generating blog post...'):
            try:
                prompt_parts = [f\"\"\"
                Generate a well-structured and engaging blog post with the title: "{blog_title}". 
                Incorporate the following keywords naturally throughout the content: "{keywords}". 
                The blog post should aim for a professional yet accessible tone, suitable for a broad audience interested in this topic. 
                Organize the blog post with clear headings and subheadings where appropriate to enhance readability. 
                The approximate word count should be {num_words} words. 
                Please ensure the introduction is captivating, the body paragraphs are informative and well-supported, and the conclusion provides a concise summary or call to action (if relevant to the topic).
                \"\"\"]
                
                response = model.generate_content(prompt_parts)
                generated_text = response.text
                
                st.subheader("Generated Blog Post:")
                st.markdown(generated_text)
                
                if generated_text:
                    st.download_button(
                        label="Download as Markdown",
                        data=generated_text,
                        file_name=f"{blog_title.replace(' ', '_')}.md",
                        mime="text/markdown",
                    )
            except Exception as e:
                st.error(f"An error occurred during blog post generation: {e}")
"""