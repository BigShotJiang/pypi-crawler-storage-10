"""OpenTelemetry FMPy instrumentation."""

from opentelemetry.instrumentation.fmpy.fmpy_instrumentor import FmpyInstrumentor

__all__ = ["FmpyInstrumentor"]