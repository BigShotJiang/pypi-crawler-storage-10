"""Package information for FMPy instrumentation."""

_instruments = ("fmpy >= 0.3.0",)