<h1 align="center">

<b>jetson-stats</b>

[![jetson-stats](https://github.com/rbonghi/jetson_stats/raw/master/docs/images/jtop.png)](https://rnext.it/jetson_stats/)

</h1>

**jetson-stats** is a package for **monitoring** and **control** your [NVIDIA Jetson](https://developer.nvidia.com/buy-jetson) [Orin, Xavier, Nano, TX] series.

jetson-stats is a powerful tool to analyze your board, you can use with a stand alone application with `jtop` or import in your python script, the main features are:

- Decode hardware, architecture, L4T and NVIDIA Jetpack
- Monitoring, CPU, GPU, Memory, Engines, fan
- Control NVP model, fan speed, jetson_clocks
- Importable in a python script
- Dockerizable in a container
- Do not need super user
- Tested on many different hardware configurations
- Works with all NVIDIA Jetpack

## Install

jetson-stats can be installed with [pip](https://pip.pypa.io), but need **superuser**:

```console
sudo pip3 install -U jetson-stats
```

_Don't forget to **logout/login** or **reboot** your board_

<div align="center">

**🚀 That's it! 🚀**

</div>

## Build

To build the package from source: for **Cordatus**

```console
cd jetson_stats
python3 -m build
python -m twine upload dist/*  # add api token from pypi.org | go to -> pypi-token.txt
```


## Library

You can use jtop such a python library to integrate in your software

```python
from jtop import jtop

with jtop() as jetson:
    # jetson.ok() will provide the proper update frequency
    while jetson.ok():
        # Read tegra stats
        print(jetson.stats)
```

You can also use jtop with your _virualenv_!

More information available at [_advanced usage_](https://rnext.it/jetson_stats/advanced-usage.html) page.

## Docker

You can run directly in Docker jtop, you need only to:

1. Install jetson-stats on your **host**
2. Install jetson-stats on your container as well
3. Pass to your container `/run/jtop.sock:/run/jtop.sock`

You can try running this command

```console
docker run --rm -it -v /run/jtop.sock:/run/jtop.sock rbonghi/jetson_stats:latest
```

More information available at [_docker_](https://rnext.it/jetson_stats/docker.html) documentation page.

## Sponsorship

If your company benefits from this library, please consider [💖 sponsoring its development](https://github.com/sponsors/rbonghi).

## Documentation

jetson-stats has usage and reference documentation at <https://rnext.it/jetson_stats>, there is also a [🆘 troubleshooting](https://rnext.it/jetson_stats/troubleshooting.html) page.

## Community

jetson-stats has a [community Discord channel](https://discord.gg/BFbuJNhYzS) for asking questions and collaborating with other contributors. Drop by and say hello 👋
