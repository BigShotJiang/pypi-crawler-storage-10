import logging
import mimetypes
import os
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Type, Optional, Any, List, Tuple

from langchain_core.tools import ToolException
from llm_sandbox import SandboxSession
from llm_sandbox.exceptions import SandboxTimeoutError
from llm_sandbox.security import SecurityPolicy
from pydantic import BaseModel, Field

from codemie_tools.base.codemie_tool import CodeMieTool
from codemie_tools.base.file_object import FileObject
from codemie_tools.data_management.code_executor.llm_sandbox import apply_llm_sandbox_patch
from codemie_tools.data_management.code_executor.models import CodeExecutorConfig
from codemie_tools.data_management.code_executor.security_policies import get_codemie_security_policy, \
    get_restricted_module_names
from codemie_tools.data_management.code_executor.session_manager import SandboxSessionManager
from codemie_tools.data_management.code_executor.tools_vars import (
    CODE_EXECUTOR_TOOL,
    COMMON_SANDBOX_LIBRARIES,
    COMMON_SANDBOX_SYSTEM_TOOLS,
    SAFE_STDLIB_MODULES,
)

logger = logging.getLogger(__name__)

# Apply Kubernetes performance patch on module load
# This fixes the slow file upload issue in llm-sandbox (1s delay per 4KB chunk)
try:
    apply_llm_sandbox_patch()
except ImportError:
    logger.debug("Kubernetes support not available, patch not applied")




def get_code_executor_input_schema(
    blocked_modules: str,
    file_names: Optional[List[str]] = None
) -> Type[BaseModel]:
    """
    Create CodeExecutorInput schema with dynamic blocked modules and optional file info.

    Args:
        blocked_modules: Comma-separated string of blocked modules
        file_names: Optional list of filenames to include in description

    Returns:
        BaseModel class with customized field descriptions
    """
    # Base code description
    code_description = f"""
        Python code to execute in an isolated environment.

        IMPORTANT CONSTRAINTS:
        - Code MUST be Python only
        - ONLY use pre-installed libraries or Python standard library modules
        - External libraries NOT in the pre-installed list are NOT available and will cause import errors
        - Code that attempts to import unavailable libraries will FAIL

        Pre-installed Python libraries: {', '.join(COMMON_SANDBOX_LIBRARIES)}

        Available system tools (can be invoked via subprocess if allowed): {', '.join(COMMON_SANDBOX_SYSTEM_TOOLS)}

        SAFE standard library modules: {SAFE_STDLIB_MODULES}

        BLOCKED modules for security: {blocked_modules}
        """.strip()

    # Add file information if provided
    if file_names:
        file_list = ', '.join([f"'{name}'" for name in file_names])
        files_info = (
            f"AVAILABLE FILES IN WORKING DIRECTORY:\n{file_list}\n"
            f"IMPORTANT: Use these EXACT filenames (including brackets, spaces, parentheses) in your code.\n\n"
        )
        code_description = f"{files_info}{code_description}"

    class CodeExecutorInput(BaseModel):
        code: str = Field(description=code_description)
        export_files: Optional[List[str]] = Field(
            default=None,
            description="List of file paths to export after code execution. Files will be stored using file_repository."
        )

    return CodeExecutorInput


class CodeExecutorTool(CodeMieTool):
    """
    Tool for executing Python code in a secure, isolated environment.
    Provides safe code execution with resource limits and complete isolation.

    Features:
    - Infinite Loop Protection: Automatic timeout after execution_timeout seconds
    - Resource-Intensive Operation Control: CPU and memory limits via pod manifest
    - Session Lifetime Management: Sessions expire after session_timeout seconds
    - Security Policy: Code validation before execution using production-grade policy

    Security:
    - Production-grade security policy optimized for shared multi-tenant environments
    - Blocks dangerous system operations, file access, network calls, and code evaluation
    - Pre-execution code validation with detailed violation reporting
    """

    name: str = CODE_EXECUTOR_TOOL.name
    description: str = CODE_EXECUTOR_TOOL.description
    args_schema: Optional[Type[BaseModel]]= None  # Will be set dynamically in __init__
    config: Optional[CodeExecutorConfig] = None
    file_repository: Optional[Any] = None
    user_id: Optional[str] = ""
    input_files: Optional[List[FileObject]] = Field(default=None, exclude=True)
    security_policy: SecurityPolicy = None
    _custom_pod_manifest: Optional[dict] = None

    def __init__(
            self,
            file_repository: Optional[Any] = None,
            user_id: Optional[str] = "",
            input_files: Optional[List[FileObject]] = None,
    ):
        """
        Initialize the CodeExecutorTool.

        Configuration can be provided directly or loaded from environment variables.
        Environment variables:
        - CODE_EXECUTOR_* for various configuration options (see CodeExecutorConfig)
        - CODE_EXECUTOR_KUBECONFIG_PATH: Path to kubeconfig file (takes priority over in-cluster config)

        Args:
            file_repository: Repository for storing files generated by code execution
            user_id: User ID for file ownership attribution
            input_files: Optional list of FileObject instances to upload to sandbox before execution
        """
        super().__init__()
        self.config = CodeExecutorConfig.from_env()
        self.file_repository = file_repository
        self.user_id = user_id
        self.input_files = input_files or []

        if self.input_files:
            logger.debug(f"  Input files: {len(self.input_files)}")

        yaml_path = Path(self.config.yaml_policy_path) if self.config.yaml_policy_path else None

        # Simple logic:
        # - If security_threshold is None → No restrictions (empty policy)
        # - If security_threshold set AND yaml_path is None → Load default policy
        # - If security_threshold set AND yaml_path provided → Load from yaml_path (error if not found)
        self.security_policy = get_codemie_security_policy(
            severity_threshold=self.config.security_threshold,
            yaml_config_path=yaml_path
        )

        # Generate blocked modules list based on security threshold from config
        blocked_modules_list = get_restricted_module_names(
            severity_threshold=self.config.security_threshold,
            yaml_config_path=yaml_path
        )

        # Convert list to comma-separated string, or "None" if empty
        blocked_modules_str = ', '.join(blocked_modules_list) if blocked_modules_list else "None (unrestricted mode)"

        # Create args_schema dynamically with actual security threshold and files
        file_names = [f.name for f in self.input_files] if self.input_files else None
        self.args_schema = get_code_executor_input_schema(
            blocked_modules=blocked_modules_str,
            file_names=file_names
        )

    def _get_user_workdir(self) -> str:
        """
        Get user-specific working directory to ensure isolation between users.

        Uses sanitized user ID to create isolated workdir paths, preventing
        directory traversal attacks.

        Returns:
            str: User-specific workdir path
        """
        if self.user_id:
            safe_user_id = self.user_id.replace('/', '_').replace('\\', '_')
            return f"{self.config.workdir_base}/{safe_user_id}"
        return self.config.workdir_base

    def _get_available_pod_name(self) -> Optional[str]:
        """
        Get an available pod name using intelligent pod discovery.

        Delegates to SandboxSessionManager which:
        1. Checks for existing running pods
        2. Reuses them if available
        3. Creates new pods only if needed and under max capacity

        Returns:
            str: Available pod name, or None if at max capacity

        Raises:
            ToolException: If no pods available
        """
        session_manager = SandboxSessionManager(config=self.config)
        pod_name = session_manager._get_available_pod_name()

        if pod_name is None:
            raise ToolException(
                f"No pods available. Maximum pool size ({self.config.max_pod_pool_size}) reached. "
                "Please wait for existing code executions to complete or increase max_pod_pool_size."
            )

        return pod_name

    def _create_default_pod_manifest(self, pod_name: str) -> dict:
        """
        Create a default pod manifest with appropriate resource limits and security settings.

        Resource-Intensive Operation Control:
        - Memory and CPU limits configured via CodeExecutorConfig
        - Prevents resource exhaustion in multi-tenant environment

        Security Features:
        - Strict security policies to prevent system command execution
        - No privilege escalation allowed
        - All capabilities dropped
        - Seccomp profile to restrict system calls
        - No host namespace access

        Pod is shared between users with isolation at the workdir level.
        Each pod has a single container. The pool manages multiple pods for load distribution.

        Args:
            pod_name: Fixed pod name from the pool for reuse

        Returns:
            dict: Pod manifest configuration with resource limits and security settings
        """
        return {
            "apiVersion": "v1",
            "kind": "Pod",
            "metadata": {
                "name": pod_name,
                "namespace": self.config.namespace,
                "labels": {
                    "app": "codemie-executor",
                    "component": "code-executor"
                }
            },
            "spec": {
                "containers": [
                    {
                        "name": "python-executor",
                        "image": self.config.docker_image,
                        "tty": True,
                        "stdin": True,
                        "securityContext": {
                            "runAsUser": self.config.run_as_user,
                            "runAsGroup": self.config.run_as_group,
                            "runAsNonRoot": True,
                            "allowPrivilegeEscalation": False,
                            "capabilities": {"drop": ["ALL"]},
                            "privileged": False,
                            "readOnlyRootFilesystem": False,
                            "seccompProfile": {"type": "RuntimeDefault"}
                        },
                        "volumeMounts": [
                            {"name": "tmp", "mountPath": "/tmp/runtime"},  # NOSONAR
                            {"name": "workdir", "mountPath": "/home/codemie"}
                        ],
                        "resources": {
                            "limits": {
                                "memory": self.config.memory_limit,
                                "cpu": self.config.cpu_limit
                            },
                            "requests": {
                                "memory": self.config.memory_request,
                                "cpu": self.config.cpu_request
                            }
                        }
                    }
                ],
                "volumes": [
                    {"name": "tmp", "emptyDir": {}},
                    {"name": "workdir", "emptyDir": {}}
                ],
                "securityContext": {
                    "runAsUser": self.config.run_as_user,
                    "runAsGroup": self.config.run_as_group,
                    "fsGroup": self.config.fs_group,
                    "runAsNonRoot": True,
                    "seccompProfile": {"type": "RuntimeDefault"},
                    "supplementalGroups": [],
                    "fsGroupChangePolicy": "OnRootMismatch"
                },
                "hostNetwork": False,
                "hostPID": False,
                "hostIPC": False,
                "restartPolicy": "Never",
                "automountServiceAccountToken": False
            }
        }

    def execute(
            self,
            code: str,
            export_files: Optional[List[str]] = None
    ) -> str:
        """
        Execute Python code in a secure, isolated environment.

        This method orchestrates the code execution workflow:
        1. Acquires a sandbox session (reuses existing or creates new)
        2. Uploads input files to sandbox if provided (from constructor)
        3. Validates code against security policy
        4. Executes code with timeout protection
        5. Processes and formats results
        6. Exports files if requested

        Args:
            code: The Python code to execute
            export_files: List of file paths to export after execution

        Returns:
            Execution result including stdout, stderr, and exit code.
            If export_files is provided and file_repository is available,
            includes URLs for exported files.

        Raises:
            ToolException: If execution fails, security validation fails,
                          session acquisition fails, or file upload fails
        """
        try:
            user_workdir = self._get_user_workdir()
            session, session_time = self._acquire_session(user_workdir)

            # Upload input files to sandbox if provided in constructor
            if self.input_files:
                self._upload_files_to_sandbox(session, self.input_files, user_workdir)

            self._validate_code_security(session, code)

            result, exec_time = self._execute_code(session, code)
            self._log_execution_timing(session_time, exec_time)

            result_text = self._format_execution_result(result)
            exported_files = self._export_files_from_execution(session, export_files, user_workdir)
            if exported_files:
                result_text += ", ".join(exported_files)

            return result_text

        except ImportError as e:
            raise ToolException(
                "Required library is not installed. "
                "Please install it with: pip install 'llm-sandbox[k8s]'"
            ) from e
        except ToolException:
            raise
        except Exception as e:
            logger.error(f"Error executing code: {str(e)}", exc_info=True)
            raise ToolException(f"Error executing code: {str(e)}") from e

    def _upload_files_to_sandbox(
            self,
            session: SandboxSession,
            file_objects: List[FileObject],
            workdir: str
    ) -> None:
        """
        Upload files from file repository to the sandbox environment.

        Files are uploaded to the user's working directory in the sandbox,
        making them available for code execution by their original filenames.

        Performance optimization: Files are uploaded in parallel (max 3 concurrent uploads)
        to reduce total upload time, especially beneficial for multiple files.

        Args:
            session: Active sandbox session
            file_objects: List of FileObject instances to upload
            workdir: Working directory in the sandbox

        Raises:
            ToolException: If file upload fails or file repository is not available
        """
        if not self.file_repository:
            raise ToolException(
                "Cannot upload files: file_repository not available. "
                "Files must be provided through a file repository."
            )

        with tempfile.TemporaryDirectory() as temp_dir:
            # Download all files to temporary directory first
            for file_obj in file_objects:
                try:
                    # Write to temporary file in binary mode to preserve file integrity
                    temp_file_path = os.path.join(temp_dir, file_obj.name)
                    with open(temp_file_path, 'wb') as f:
                        f.write(
                            self.file_repository.read_file(
                                file_name=file_obj.name,
                                owner=file_obj.owner,
                                mime_type=file_obj.mime_type,
                            ).bytes_content()
                        )

                except Exception as e:
                    logger.error(f"Failed to download file {file_obj.name}: {e}")
                    raise ToolException(f"Failed to download file {file_obj.name}: {str(e)}")

            # Upload files to sandbox in parallel for better performance
            try:
                self._upload_files_parallel(session, file_objects, temp_dir, workdir)
            except Exception as e:
                logger.error(f"Failed to upload files to sandbox: {e}")
                raise ToolException(f"Failed to upload files to sandbox: {str(e)}")

    def _upload_files_parallel(
            self,
            session: SandboxSession,
            file_objects: List[FileObject],
            temp_dir: str,
            workdir: str
    ) -> None:
        """
        Upload files to sandbox in parallel for improved performance.

        Uses ThreadPoolExecutor to upload multiple files concurrently (max 3 workers).
        Each file is uploaded individually to its destination path in the sandbox.

        This approach:
        1. Fixes the broken "/." directory copy pattern that caused file corruption
        2. Provides significant performance improvement for multiple files
        3. Maintains proper error handling and reporting for each file

        Args:
            session: Active sandbox session
            file_objects: List of FileObject instances to upload
            temp_dir: Temporary directory containing downloaded files
            workdir: Working directory in the sandbox

        Raises:
            ToolException: If any file upload fails
        """
        start_time = time.time()
        max_workers = min(3, len(file_objects))  # Max 3 concurrent uploads

        def upload_single_file(file_obj: FileObject) -> tuple[str, bool, Optional[str]]:
            """
            Upload a single file to the sandbox.

            Returns:
                Tuple of (filename, success, error_message)
            """
            try:
                temp_file_path = os.path.join(temp_dir, file_obj.name)
                dest_file_path = f"{workdir}/{file_obj.name}"

                # Upload file individually - fixes the "/." pattern issue
                session.copy_to_runtime(temp_file_path, dest_file_path)

                return (file_obj.name, True, None)

            except Exception as e:
                error_msg = f"Failed to upload {file_obj.name}: {str(e)}"
                logger.error(error_msg)
                return (file_obj.name, False, error_msg)

        # Upload files in parallel
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all upload tasks
            futures = {
                executor.submit(upload_single_file, file_obj): file_obj
                for file_obj in file_objects
            }

            # Collect results and check for failures
            failed_uploads = []
            for future in as_completed(futures):
                _, success, error_msg = future.result()
                if not success:
                    failed_uploads.append(error_msg)

            # If any uploads failed, raise exception with details
            if failed_uploads:
                error_details = "\n".join(failed_uploads)
                raise ToolException(
                    f"Failed to upload {len(failed_uploads)} file(s):\n{error_details}"
                )

        # Log upload summary
        total_elapsed = time.time() - start_time
        file_names = [f.name for f in file_objects]
        logger.debug(f"Uploaded {len(file_objects)} file(s) in {total_elapsed:.2f}s: {file_names}")

    def _acquire_session(self, user_workdir: str) -> Tuple[SandboxSession, float]:
        """
        Acquire a sandbox session for code execution.

        Args:
            user_workdir: User-specific working directory

        Returns:
            tuple: (session, elapsed_time_seconds)

        Raises:
            ToolException: If session acquisition fails
        """
        start_time = time.time()

        pod_name = self._get_available_pod_name()
        if not pod_name:
            raise ToolException("No pods available in the pool")

        logger.debug(f"Using pod: {pod_name} with workdir: {user_workdir}")

        session_manager = SandboxSessionManager(config=self.config)
        pod_manifest = self._custom_pod_manifest or self._create_default_pod_manifest(pod_name)

        logger.debug(f"Using pod: {pod_name} with manifest: {pod_manifest}")
        session = session_manager.get_session(
            pod_name=pod_name,
            workdir=user_workdir,
            pod_manifest=pod_manifest,
            security_policy=self.security_policy
        )

        elapsed = time.time() - start_time
        logger.debug(f"✓ Session ready in {elapsed:.2f}s")

        return session, elapsed

    @staticmethod
    def _validate_code_security(session, code: str) -> None:
        """
        Validate code against security policy before execution.

        Args:
            session: Active sandbox session
            code: Python code to validate

        Raises:
            ToolException: If code fails security validation
        """
        is_safe, violations = session.is_safe(code)

        if not is_safe:
            violation_details = [
                f"  • [{v.severity.name}] {v.description}"
                for v in violations
            ]
            error_msg = (
                    f"Code failed security validation ({len(violations)} violation(s) detected):\n"
                    + "\n".join(violation_details) +
                    "\n\nPlease review your code and remove any restricted operations."
            )
            logger.warning(f"Security validation failed: {len(violations)} violation(s) - {', '.join([v.description for v in violations[:3]])}")
            raise ToolException(error_msg)

    def _execute_code(self, session, code: str) -> Tuple[Any, float]:
        """
        Execute code in the sandbox with timeout protection.

        Args:
            session: Active sandbox session
            code: Python code to execute

        Returns:
            tuple: (execution_result, elapsed_time_seconds)

        Raises:
            ToolException: If execution times out
        """
        start_time = time.time()

        # Log code summary for debugging
        code_lines = code.strip().split('\n')
        code_summary = f"{len(code_lines)} lines, {len(code)} chars"
        first_line = code_lines[0][:60] + '...' if len(code_lines[0]) > 60 else code_lines[0]

        try:
            result = session.run(code, timeout=self.config.execution_timeout)
        except SandboxTimeoutError as e:
            error_msg = (
                f"Code execution timed out after {self.config.execution_timeout} seconds. "
                "This may indicate an infinite loop or a resource-intensive operation. "
                "Please review your code and consider optimizing it."
            )
            logger.error(error_msg)
            raise ToolException(error_msg) from e

        elapsed = time.time() - start_time
        logger.debug(f"Executing code ({code_summary}): {first_line} - executed in {elapsed:.2f}s (exit_code={result.exit_code})")

        return result, elapsed

    @staticmethod
    def _log_execution_timing(session_time: float, exec_time: float) -> None:
        """
        Log execution timing information.

        Args:
            session_time: Time spent acquiring session
            exec_time: Time spent executing code
        """
        total_time = session_time + exec_time
        logger.debug(
            f"Total execution time: session={session_time:.2f}s, "
            f"exec={exec_time:.2f}s, total={total_time:.2f}s"
        )

    def _format_execution_result(self, result: Any) -> str:
        """
        Format execution result into a human-readable string.

        Filters out internal setup messages from stdout to provide cleaner output.

        Args:
            result: Execution result object with stdout, stderr, and exit_code

        Returns:
            str: Formatted result string

        Raises:
            ToolException: If execution failed (non-zero exit code)
        """
        output_parts = []

        # Filter stdout to remove internal setup messages
        if result.stdout:
            filtered_stdout = self._filter_stdout(result.stdout)
            if filtered_stdout:
                output_parts.append(f"{filtered_stdout}")

        if result.stderr:
            output_parts.append(f"STDERR:\n{result.stderr}")

        if result.exit_code != 0:
            logger.warning(f"Code execution failed with exit code {result.exit_code}")
            raise ToolException(f"Code execution failed.\n\n{chr(10).join(output_parts)}")

        return chr(10).join(output_parts) if output_parts else \
            "Code executed successfully with no output."

    @staticmethod
    def _filter_stdout(stdout: str) -> str:
        """
        Filter out internal setup messages from stdout.

        Args:
            stdout: Raw stdout output

        Returns:
            str: Filtered stdout with internal messages removed
        """
        # Filter out setup/initialization messages
        lines = stdout.split('\n')
        filtered_lines = [
            line for line in lines
            if 'Python plot detection setup complete' not in line
        ]
        return '\n'.join(filtered_lines).strip()

    def _export_files_from_execution(self, session, file_paths: Optional[List[str]], workdir: str) -> List[str]:
        """
        Export files from the execution environment and store them using file_repository.

        Args:
            session: The active execution session
            file_paths: List of paths to export from the execution environment
            workdir: The user-specific working directory

        Returns:
            List of URLs for the stored files
        """
        if not self.file_repository:
            logger.warning("Cannot export files: file_repository not available")
            return []

        if file_paths is None:
            return []

        urls = []
        with tempfile.TemporaryDirectory() as temp_dir:
            for i, src_path in enumerate(file_paths, 1):
                try:
                    filename = os.path.basename(src_path) or f"file_{i}"
                    temp_file_path = os.path.join(temp_dir, filename)

                    # Copy file from execution environment to host using user-specific workdir
                    session.copy_from_runtime(f"{workdir}/{src_path}", temp_file_path)

                    # Determine MIME type and read file content
                    extension = Path(src_path).suffix.lower().lstrip('.')
                    mime_type = self._determine_mime_type(extension)

                    with open(temp_file_path, 'rb') as f:
                        content = f.read()

                    # Store file in repository
                    unique_filename = f"{uuid.uuid4()}_{filename}"
                    stored_file = self.file_repository.write_file(
                        name=unique_filename,
                        mime_type=mime_type,
                        content=content,
                        owner=self.user_id
                    )

                    url = f" File '{filename}', URL `sandbox:/v1/files/{stored_file.to_encoded_url()}`"
                    urls.append(url)

                except Exception as e:
                    logger.error(f"Failed to export file {src_path}: {e}")

        return urls

    @staticmethod
    def _determine_mime_type(extension: str) -> str:
        """
        Determine the MIME type based on the file extension using Python's mimetypes module.

        Args:
            extension: The file extension (without leading dot)

        Returns:
            The MIME type string, defaults to 'application/octet-stream' if unknown
        """
        # Add dot prefix if not present for mimetypes.guess_type
        filename = f"file.{extension}" if not extension.startswith('.') else f"file{extension}"
        mime_type, _ = mimetypes.guess_type(filename)
        return mime_type or 'application/octet-stream'
