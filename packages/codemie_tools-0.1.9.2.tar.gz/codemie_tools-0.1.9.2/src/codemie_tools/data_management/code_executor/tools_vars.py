from codemie_tools.base.models import ToolMetadata

# System tools available in the sandbox environment
COMMON_SANDBOX_SYSTEM_TOOLS = [
    "git",
    "node (v22 LTS)",
]

# Python libraries available in the sandbox environment
COMMON_SANDBOX_LIBRARIES = [
    # Data manipulation and analysis
    "pandas",
    "numpy",
    # Plotting and visualization
    "matplotlib",
    # Data serialization
    "pydantic",
    "pydantic-settings",
    "python-dotenv",
    "python-dateutil",
    "click",
    "PyYAML",
    "structlog",
    # Document processing
    "pymupdf",
    "python-pptx",
    "lxml",
    "python-docx",
    "docx2txt",
    "openpyxl",
    "clevercsv",
    "markdownify",
    "markdown",
    "markitdown",
    "chardet",
    "requests"
]

# Safe Python standard library modules that can be used
SAFE_STDLIB_MODULES = "json, datetime, re, math, random, collections, itertools, functools, statistics, copy, csv, base64, hashlib, hmac, secrets, string, textwrap, unicodedata, difflib, heapq, bisect, array, enum, decimal, fractions, typing, dataclasses, time"

CODE_EXECUTOR_TOOL = ToolMetadata(
    name="code_executor",
    description=f"""
    ALWAYS use this tool to generate and execute Python code for user requests involving data analysis, document generation, plotting, calculations, or file processing.

    WHEN TO USE (ALWAYS generate code and execute):
    - User asks to analyze data → Generate analysis script, run it, return results
    - User asks to create/process document → Generate script, create file, return file URL
    - User asks to draw/plot/visualize → Generate plotting script, save file, return file URL
    - User asks for calculations → Generate calculation script, run it, return results
    - User requests any data processing → Generate script, execute, return output

    UPLOADED FILES:
    - When files are provided to the tool, they are listed at the top of the code field description
    - IMPORTANT: Use the EXACT filenames shown (including special characters like brackets, parentheses, spaces)
    - Files are available in the current working directory, use them directly by their names
    - Example: If shown '[Video] Template.pptx', use that exact name in your code, not 'Video Template.pptx'

    CRITICAL CONSTRAINTS:
    - Python ONLY
    - ONLY use pre-installed Python libraries: {', '.join(COMMON_SANDBOX_LIBRARIES)}
    - Available system tools (can be invoked via subprocess if allowed): {', '.join(COMMON_SANDBOX_SYSTEM_TOOLS)}
    - SAFE standard library modules: {SAFE_STDLIB_MODULES}
    - BLOCKED modules for security: (dynamically determined by security policy level)
    - External libraries NOT in this list will cause IMPORT ERRORS

    FILE OPERATIONS:
    - Input files are automatically available in working directory by their original filename
    - To export files: Set export_files parameter with list of file paths to export
    - Tool returns: stdout/stderr + file info in format: File 'filename', URL `sandbox:/v1/files/[encoded_url]`

    CRITICAL - FILE URL HANDLING (CONVERT TO MARKDOWN LINK):
    - Tool returns: " File 'filename', URL `sandbox:/v1/files/[base64_string]`"
    - Parse and convert to markdown link: [filename](sandbox:/v1/files/[base64_string])
    - Extract filename from quotes and URL from backticks
    - ALWAYS use markdown link format: [text](url)
    - MUST preserve in URL: sandbox:/ protocol (single slash), complete base64 string unchanged
    - DO NOT convert sandbox:/ to http://, localhost, or sandbox:// (double slash)
    - DO NOT use plain text format like "download file filename(url)"
    - WRONG ❌: "[data.csv](http://localhost:8080/v1/files/...)" (wrong protocol)
    - WRONG ❌: "download file data.csv(sandbox:/v1/files/...)" (not markdown link)
    - CORRECT ✅: "[data.csv](sandbox:/v1/files/OH50ZXh0L2NzdjE2...)" (markdown link)

    WORKFLOW:
    1. Generate complete Python code for the task
    2. Execute code using this tool
    3. If code creates files, specify them in export_files parameter
    4. Return tool output to user INCLUDING file URLs exactly as provided
    5. DO NOT modify or transform the file URLs - pass them as-is

    EXECUTION BEHAVIOR:
    - Code runs in isolated sandbox with resource/time limits
    - Returns: stdout, stderr, exit code, and file URLs (if files exported)
    - Security validation performed before execution
    - Timeout protection prevents infinite loops
    """.strip(),
    label="Code Executor",
    user_description="""
    Execute Python code to analyze data, generate visualizations, process documents, and perform calculations.

    Key Capabilities:
    - File Upload: Upload files to the sandbox environment for processing
    - Data Analysis: Process and analyze datasets using pandas and numpy
    - Visualizations: Create charts, graphs, and plots with matplotlib
    - Document Processing: Work with Excel, Word, PowerPoint, and PDF files
    - Computations: Perform mathematical calculations and data transformations
    - Image Processing: Manipulate and process images
    - File Export: Export generated files for download

    Use Cases:
    - Upload CSV or Excel files and generate insights
    - Process uploaded images and create visualizations
    - Create visualizations to illustrate trends and patterns
    - Extract information from uploaded documents
    - Perform complex calculations on uploaded data
    - Transform data between different formats and export results

    Workflow:
    1. Files are automatically uploaded to sandbox if provided to the tool
    2. Execute code that processes the uploaded files (available by filename)
    3. Generate new files or visualizations
    4. Export results using export_files parameter

    The code executes securely with all files isolated in a sandbox environment.
    """.strip(),
)
