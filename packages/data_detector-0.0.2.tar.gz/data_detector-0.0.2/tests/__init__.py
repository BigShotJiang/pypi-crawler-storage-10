"""Tests for data-detector."""
