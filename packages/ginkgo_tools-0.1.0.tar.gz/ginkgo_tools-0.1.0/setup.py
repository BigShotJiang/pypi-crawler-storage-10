from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ginkgo-tools",
    version="0.1.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="一套实用的 Python 工具库，包含日志、时间处理和多线程相关的工具函数",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/ginkgo-tools",  # 如果有 GitHub 仓库，可以替换为实际地址
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.6",
    install_requires=[],
)