import dataclasses


@dataclasses.dataclass
class LlamaCppServerAddress:
    host: str
    port: int

