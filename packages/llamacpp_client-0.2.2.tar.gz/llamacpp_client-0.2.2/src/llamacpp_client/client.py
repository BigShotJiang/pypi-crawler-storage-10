import dataclasses
import json
import logging
import random
from typing import AsyncGenerator, Generator

import requests
import httpx

from .response import (
    LlamaCppCompletionResponse,
    LlamaCppCompletionResponseChunk,
)

from .address import LlamaCppServerAddress


LOG = logging.getLogger("llamacpp_client")


class LlamaCppClient:
    """
    Client for communicating with a Llama.cpp-compatible REST server.

    Example:
        >>> client = LlamaCppClient([LlamaCppServerAddress("127.0.0.1", 8080)])
        >>> resp = client.completion("Tell me a joke.")
        >>> print(resp.get_text())
    """

    def __init__(self, endpoints: list[LlamaCppServerAddress]):
        if not all(isinstance(endpoint, LlamaCppServerAddress) for endpoint in endpoints):
            raise ValueError("expected all endpoints to be instances of LlamaCppServerAddress")
        self.endpoints = endpoints

    # -------------------------------------------------------------------------
    # Non-streaming synchronous methods
    # -------------------------------------------------------------------------

    def new_completion(
            self,
            prompt: str,
            *,
            temperature: float = 0.8,
            top_k: int = 40,
            top_p: float = 0.95,
            min_p: float = 0.05,
            n_predict: int = -1,
            n_keep: int = 0,
            stop: list[str] = [],  # list of stop words
            repeat_penalty: float = 1.1,
            repeat_last_n: int = 64,  # 0 is disabled, -1 is context size
            seed: int = -1,
        ) -> LlamaCppCompletionResponse:
        """
        Send a non-streaming completion request.
        Documentation:
            https://github.com/ggml-org/llama.cpp/tree/master/tools/server#post-completion-given-a-prompt-it-returns-the-predicted-completion

        Example:
            >>> response = client.completion("Once upon a time...")
            >>> response.content
        """
        request_payload = {
            "prompt": prompt,
            "temperature": temperature,
            "top_k": top_k,
            "top_p": top_p,
            "min_p": min_p,
            "n_predict": n_predict,
            "n_keep": n_keep,
            "stop": stop,
            "repeat_penalty": repeat_penalty,
            "repeat_last_n": repeat_last_n,
            "seed": seed,
            "stream": False,
            "response_fields": [
                "content",
                "stop_type",
                "stopping_word",
                "tokens_cached",
                "tokens_evaluated",
                "tokens_predicted",
                "truncated",
            ],
        }
        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/completion"

        if LOG.isEnabledFor(logging.DEBUG):
            LOG.debug("posting to %s: %s", url, json.dumps(request_payload, indent=4))

        try: # make HTTP request
            response = requests.post(url, json=request_payload)
            response.raise_for_status()
        except requests.RequestException as e:
            LOG.error("error while communicating with %r: %s", url, e)
            raise

        try: # parse JSON response
            response_payload = response.json()
            if LOG.isEnabledFor(logging.DEBUG):
                LOG.debug("response from %s: %s", url, json.dumps(response_payload, indent=4))
        except requests.JSONDecodeError as e:  # catches JSON decoding errors
            LOG.error("response from server is not valid JSON: %r", response.text)
            raise

        try: # validate response structure
            return LlamaCppCompletionResponse.model_validate(response_payload)
        except Exception:
            LOG.error("response from server is valid JSON but has unexpected structure: %r", response.text)
            raise

    def new_stream_completion(
        self,
        prompt: str,
        *,
        temperature: float = 0.8,
        top_k: int = 40,
        top_p: float = 0.95,
        min_p: float = 0.05,
        n_predict: int = -1,
        n_keep: int = 0,
        stop: list[str] = [],  # list of stop words
        repeat_penalty: float = 1.1,
        repeat_last_n: int = 64,  # 0 is disabled, -1 is context size
        seed: int = -1,
    ) -> Generator[LlamaCppCompletionResponseChunk, None, None]:
        """
        Send a streaming completion request and yield `CompletionResponse`
        objects for each chunk received.

        Documentation:
            https://github.com/ggml-org/llama.cpp/tree/master/tools/server#post-completion-given-a-prompt-it-returns-the-predicted-completion

        Example:
            >>> for chunk in client.stream_completion("Tell me a joke."):
            ...     print(chunk.content, end="", flush=True)
        """
        request_payload = {
            "prompt": prompt,
            "temperature": temperature,
            "top_k": top_k,
            "top_p": top_p,
            "min_p": min_p,
            "n_predict": n_predict,
            "n_keep": n_keep,
            "stop": stop,
            "repeat_penalty": repeat_penalty,
            "repeat_last_n": repeat_last_n,
            "seed": seed,
            "stream": True,
            "response_fields": [
                "content",
                "stop",
                "stop_type",
                "stopping_word",
                "tokens_cached",
                "tokens_evaluated",
                "truncated",
            ],
        }

        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/completion"

        if LOG.isEnabledFor(logging.DEBUG):
            LOG.debug("posting (stream) to %s: %s", url, json.dumps(request_payload, indent=4))

        try:
            # Important: stream=True to get a generator-like response
            with requests.post(url, json=request_payload, stream=True) as response:
                response.raise_for_status()

                # The server sends JSON lines, one per chunk
                for line in response.iter_lines(decode_unicode=True):
                    if not line or not line.startswith("data: "):
                        continue

                    try:
                        payload = json.loads(line[len("data: "):])
                    except json.JSONDecodeError:
                        LOG.warning("Invalid JSON chunk: %r", line)
                        continue

                    try:
                        chunk = LlamaCppCompletionResponseChunk.model_validate(payload)
                    except Exception:
                        LOG.exception("Unexpected chunk structure: %r", payload)
                        continue

                    yield chunk
        except requests.RequestException as e:
            LOG.error("error while communicating with %r: %s", url, e)
            raise

    def completion(self, prompt: str, **params) -> dict | str:
        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/completion"
        req_payload = {"prompt": prompt, **params}
        LOG.debug("posting to %s: %s", url, json.dumps(req_payload, indent=4))
        response = requests.post(url, json=req_payload)
        if params.get("stream", False):
            return response.text
        try:
            resp_payload = response.json()
            LOG.debug("response from %s: %s", url, json.dumps(resp_payload, indent=4))
            return resp_payload
        except Exception as ex:
            LOG.error("unexpected non-JSON response from server: %r", response.text)
            raise

    def v1_chat_completions(self, messages: list, **params) -> dict | str:
        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/v1/chat/completions"
        req_payload = {"messages": messages, **params}
        LOG.debug("posting to %s: %s", url, json.dumps(req_payload, indent=4))
        response = requests.post(url, json=req_payload)
        if params.get("stream", False):
            return response.text
        try:
            resp_payload = response.json()
            LOG.debug("response from %s: %s", url, json.dumps(resp_payload, indent=4))
            return resp_payload
        except Exception as ex:
            LOG.error("unexpected non-JSON response from server: %r", response.text)
            raise

    async def async_completion(self, prompt: str, **params):
        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/completion"
        req_payload = {"prompt": prompt, **params}
        LOG.debug("posting to %s: %s", url, json.dumps(req_payload, indent=4))
        client = httpx.AsyncClient(timeout=None)
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream("POST", url, json=req_payload) as response:
                async for chunk in response.aiter_bytes():
                    LOG.debug(
                        "passing through stream chunk: %s",
                        chunk.decode("utf-8", errors="ignore"),
                    )
                    yield chunk

    async def async_v1_chat_completions(self, messages: list, **params):
        endpoint = random.choice(self.endpoints)
        url = f"http://{endpoint.host}:{endpoint.port}/v1/chat/completions"
        req_payload = {"messages": messages, **params}
        LOG.debug("posting to %s: %s", url, json.dumps(req_payload, indent=4))
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream("POST", url, json=req_payload) as response:
                async for chunk in response.aiter_bytes():
                    LOG.debug(
                        "passing through stream chunk: %s",
                        chunk.decode("utf-8", errors="ignore"),
                    )
                    yield chunk
