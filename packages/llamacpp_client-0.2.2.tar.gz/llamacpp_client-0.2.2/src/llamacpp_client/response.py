from typing import Any, Optional
from pydantic import BaseModel, Field, model_validator


class LlamaCppResponse(BaseModel):
    """This is a superclass for classes modelling the responses from llamacpp server endpoints"""
    # We use this attribute to save the original JSON for debugging.
    raw: Optional[dict] = Field(default=None, exclude=True)

    @model_validator(mode="before")
    def keep_raw(cls, values):
        values["raw"] = dict(values)
        return values


class LlamaCppCompletionResponse(LlamaCppResponse):
    """This class models the response from a llamacpp server /completion endpoint"""
    content: str
    tokens_cached: int
    tokens_evaluated: int
    tokens_predicted: int
    stop_type: str
    truncated: bool


class LlamaCppCompletionResponseChunk(LlamaCppResponse):
    """This class models the chunks of a streamed response from a llamacpp server /completion endpoint"""
    # When streaming, these attributes are present on all chunks:
    content: str
    stop: bool
    tokens_evaluated: int
    # When streaming, this attribute is present on all chunks except the last one:
    tokens_predicted: Optional[int] = None
    # When streaming, these attributes are only present on the last streamed chunk:
    tokens_cached: Optional[int] = None
    stop_type: Optional[str] = None
    truncated: Optional[bool] = None


class OpenAiV1ChatCompletionsMessage(BaseModel):
    role: str
    content: str


class OpenAiV1ChatCompletionsChoice(BaseModel):
    index: int
    message: OpenAiV1ChatCompletionsMessage
    finish_reason: Optional[str] = None


class OpenAiV1ChatCompletionsUsage(BaseModel):
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    total_tokens: Optional[int] = None


class OpenAiV1ChatCompletionsResponse(LlamaCppResponse):
    choices: Optional[list[OpenAiV1ChatCompletionsChoice]] = None

    def get_text(self) -> str:
        """Safely extract the assistant's text content"""
        if self.choices and len(self.choices) > 0:
            msg = self.choices[0].message.content.strip()
            return msg
        raise ValueError("Invalid or empty response")


