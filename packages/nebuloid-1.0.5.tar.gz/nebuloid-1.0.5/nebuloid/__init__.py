# nebuloid/__init__.py
__version__ = "0.1.0"

from .core import Nebuloid
