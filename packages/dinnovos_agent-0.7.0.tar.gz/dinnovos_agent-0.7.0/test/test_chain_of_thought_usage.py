"""
Unit tests for Chain of Thought usage tracking functionality.
"""

import unittest
from unittest.mock import Mock, MagicMock
from dinnovos.utils.chain_of_thought import ChainOfThought


class TestChainOfThoughtUsageTracking(unittest.TestCase):
    """Test cases for usage tracking in ChainOfThought"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Create a mock LLM with usage tracking
        self.mock_llm = Mock()
        self.mock_llm.model = "test-model"
        
        # Mock the call method
        self.mock_llm.call = Mock(return_value="Test response")
        
        # Mock the get_last_usage method
        self.mock_llm.get_last_usage = Mock(return_value={
            "model": "test-model",
            "input_tokens": 100,
            "output_tokens": 50,
            "total_tokens": 150
        })
        
        # Create ChainOfThought instance
        self.cot = ChainOfThought(self.mock_llm)
    
    def test_initialization(self):
        """Test that usage tracking is initialized correctly"""
        usage = self.cot.get_last_usage()
        
        self.assertEqual(usage['model'], 'test-model')
        self.assertEqual(usage['input_tokens'], 0)
        self.assertEqual(usage['output_tokens'], 0)
        self.assertEqual(usage['total_tokens'], 0)
        self.assertEqual(usage['calls_count'], 0)
    
    def test_get_last_usage_returns_copy(self):
        """Test that get_last_usage returns a copy, not reference"""
        usage1 = self.cot.get_last_usage()
        usage2 = self.cot.get_last_usage()
        
        # Modify one copy
        usage1['total_tokens'] = 999
        
        # Other copy should be unchanged
        self.assertEqual(usage2['total_tokens'], 0)
    
    def test_reset_usage(self):
        """Test that reset_usage clears accumulated usage"""
        # Simulate some usage
        self.cot._accumulated_usage['input_tokens'] = 500
        self.cot._accumulated_usage['output_tokens'] = 300
        self.cot._accumulated_usage['total_tokens'] = 800
        self.cot._accumulated_usage['calls_count'] = 5
        
        # Reset
        self.cot.reset_usage()
        
        # Verify reset
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['input_tokens'], 0)
        self.assertEqual(usage['output_tokens'], 0)
        self.assertEqual(usage['total_tokens'], 0)
        self.assertEqual(usage['calls_count'], 0)
        self.assertEqual(usage['model'], 'test-model')  # Model should remain
    
    def test_accumulate_usage(self):
        """Test that _accumulate_usage correctly accumulates tokens"""
        # Call accumulate
        self.cot._accumulate_usage()
        
        # Verify accumulation
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['input_tokens'], 100)
        self.assertEqual(usage['output_tokens'], 50)
        self.assertEqual(usage['total_tokens'], 150)
        self.assertEqual(usage['calls_count'], 1)
        
        # Call again
        self.cot._accumulate_usage()
        
        # Verify double accumulation
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['input_tokens'], 200)
        self.assertEqual(usage['output_tokens'], 100)
        self.assertEqual(usage['total_tokens'], 300)
        self.assertEqual(usage['calls_count'], 2)
    
    def test_accumulate_usage_without_get_last_usage_method(self):
        """Test that _accumulate_usage handles LLMs without get_last_usage"""
        # Create LLM without get_last_usage method
        llm_no_usage = Mock()
        llm_no_usage.model = "test-model"
        llm_no_usage.call = Mock(return_value="Response")
        delattr(llm_no_usage, 'get_last_usage')
        
        cot = ChainOfThought(llm_no_usage)
        
        # Should not raise error
        cot._accumulate_usage()
        
        # Usage should remain at zero
        usage = cot.get_last_usage()
        self.assertEqual(usage['total_tokens'], 0)
        self.assertEqual(usage['calls_count'], 0)
    
    def test_accumulate_usage_with_none_return(self):
        """Test that _accumulate_usage handles None return from get_last_usage"""
        self.mock_llm.get_last_usage = Mock(return_value=None)
        
        # Should not raise error
        self.cot._accumulate_usage()
        
        # Usage should remain at zero
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['total_tokens'], 0)
        self.assertEqual(usage['calls_count'], 0)
    
    def test_implicit_reasoning_tracks_usage(self):
        """Test that implicit reasoning tracks usage"""
        # Mock call_stream for _parse_steps_from_text
        result = self.cot._implicit_reasoning(
            problem="Test problem",
            context=None,
            temperature=0.7
        )
        
        # Verify LLM was called
        self.mock_llm.call.assert_called_once()
        
        # Verify usage was tracked
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['calls_count'], 1)
        self.assertEqual(usage['total_tokens'], 150)
    
    def test_explicit_reasoning_tracks_multiple_calls(self):
        """Test that explicit reasoning tracks multiple LLM calls"""
        result = self.cot._explicit_reasoning(
            problem="Test problem",
            context=None,
            steps=2,
            temperature=0.7
        )
        
        # Should have 3 calls: 2 steps + 1 conclusion
        self.assertEqual(self.mock_llm.call.call_count, 3)
        
        # Verify usage accumulated across all calls
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['calls_count'], 3)
        self.assertEqual(usage['total_tokens'], 450)  # 150 * 3
    
    def test_verification_reasoning_tracks_all_calls(self):
        """Test that verification reasoning tracks steps and verifications"""
        result = self.cot._verification_reasoning(
            problem="Test problem",
            context=None,
            steps=2,
            temperature=0.7
        )
        
        # Should have 5 calls: 2 steps + 2 verifications + 1 conclusion
        self.assertEqual(self.mock_llm.call.call_count, 5)
        
        # Verify usage accumulated across all calls
        usage = self.cot.get_last_usage()
        self.assertEqual(usage['calls_count'], 5)
        self.assertEqual(usage['total_tokens'], 750)  # 150 * 5


class TestChainOfThoughtUsageIntegration(unittest.TestCase):
    """Integration tests for usage tracking with public methods"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.mock_llm = Mock()
        self.mock_llm.model = "test-model"
        self.mock_llm.call = Mock(return_value="Test response")
        self.mock_llm.get_last_usage = Mock(return_value={
            "model": "test-model",
            "input_tokens": 100,
            "output_tokens": 50,
            "total_tokens": 150
        })
        self.cot = ChainOfThought(self.mock_llm)
    
    def test_reason_explicit_strategy(self):
        """Test usage tracking with reason() method using explicit strategy"""
        result = self.cot.reason(
            problem="Test problem",
            steps=2,
            strategy="explicit"
        )
        
        usage = self.cot.get_last_usage()
        self.assertGreater(usage['calls_count'], 0)
        self.assertGreater(usage['total_tokens'], 0)
    
    def test_reason_implicit_strategy(self):
        """Test usage tracking with reason() method using implicit strategy"""
        result = self.cot.reason(
            problem="Test problem",
            strategy="implicit"
        )
        
        usage = self.cot.get_last_usage()
        self.assertGreater(usage['calls_count'], 0)
        self.assertGreater(usage['total_tokens'], 0)
    
    def test_reason_verification_strategy(self):
        """Test usage tracking with reason() method using verification strategy"""
        result = self.cot.reason(
            problem="Test problem",
            steps=2,
            strategy="verification"
        )
        
        usage = self.cot.get_last_usage()
        self.assertGreater(usage['calls_count'], 0)
        self.assertGreater(usage['total_tokens'], 0)
    
    def test_multiple_reason_calls_accumulate(self):
        """Test that multiple reason() calls accumulate usage"""
        # First call
        self.cot.reason(problem="Problem 1", strategy="implicit")
        usage1 = self.cot.get_last_usage()
        
        # Second call (without reset)
        self.cot.reason(problem="Problem 2", strategy="implicit")
        usage2 = self.cot.get_last_usage()
        
        # Usage should have accumulated
        self.assertGreater(usage2['total_tokens'], usage1['total_tokens'])
        self.assertGreater(usage2['calls_count'], usage1['calls_count'])
    
    def test_reset_between_calls(self):
        """Test that reset_usage() properly isolates sessions"""
        # First session
        self.cot.reason(problem="Problem 1", strategy="implicit")
        usage1 = self.cot.get_last_usage()
        
        # Reset
        self.cot.reset_usage()
        
        # Second session
        self.cot.reason(problem="Problem 2", strategy="implicit")
        usage2 = self.cot.get_last_usage()
        
        # Both sessions should have similar usage (not accumulated)
        self.assertEqual(usage1['calls_count'], usage2['calls_count'])
        self.assertEqual(usage1['total_tokens'], usage2['total_tokens'])


if __name__ == '__main__':
    unittest.main()
