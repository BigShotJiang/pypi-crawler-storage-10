"""Version information for Dinnovos Agent"""

__version__ = "0.7.0"