"""
Dashboard API Serializers

Simple serializers for dashboard endpoints - no nested serializers to avoid allOf.
Returns plain dict structures for TypeScript generation.
"""

from rest_framework import serializers


class StatCardSerializer(serializers.Serializer):
    """
    Serializer for dashboard statistics cards.

    Maps to StatCard Pydantic model.
    """

    title = serializers.CharField(help_text="Card title")
    value = serializers.CharField(help_text="Main value to display")
    icon = serializers.CharField(help_text="Material icon name")
    change = serializers.CharField(required=False, allow_null=True, help_text="Change indicator (e.g., '+12%')")
    change_type = serializers.ChoiceField(
        choices=['positive', 'negative', 'neutral'],
        default='neutral',
        help_text="Change type"
    )
    description = serializers.CharField(required=False, allow_null=True, help_text="Additional description")
    color = serializers.CharField(default='primary', help_text="Card color theme")


class SystemHealthItemSerializer(serializers.Serializer):
    """
    Serializer for system health status items.

    Maps to SystemHealthItem Pydantic model.
    """

    component = serializers.CharField(help_text="Component name")
    status = serializers.ChoiceField(
        choices=['healthy', 'warning', 'error', 'unknown'],
        help_text="Health status"
    )
    description = serializers.CharField(help_text="Status description")
    last_check = serializers.CharField(help_text="Last check time (ISO format)")
    health_percentage = serializers.IntegerField(
        required=False,
        allow_null=True,
        min_value=0,
        max_value=100,
        help_text="Health percentage (0-100)"
    )


class SystemHealthSerializer(serializers.Serializer):
    """Serializer for overall system health status."""

    overall_status = serializers.ChoiceField(
        choices=['healthy', 'warning', 'error', 'unknown'],
        help_text="Overall system health status"
    )
    overall_health_percentage = serializers.IntegerField(
        min_value=0,
        max_value=100,
        help_text="Overall health percentage"
    )
    components = SystemHealthItemSerializer(many=True, help_text="Health status of individual components")
    timestamp = serializers.CharField(help_text="Check timestamp (ISO format)")


class QuickActionSerializer(serializers.Serializer):
    """
    Serializer for quick action buttons.

    Maps to QuickAction Pydantic model.
    """

    title = serializers.CharField(help_text="Action title")
    description = serializers.CharField(help_text="Action description")
    icon = serializers.CharField(help_text="Material icon name")
    link = serializers.CharField(help_text="Action URL")
    color = serializers.ChoiceField(
        choices=['primary', 'success', 'warning', 'danger', 'secondary'],
        default='primary',
        help_text="Button color theme"
    )
    category = serializers.CharField(default='general', help_text="Action category")


class ActivityEntrySerializer(serializers.Serializer):
    """Serializer for recent activity entries."""

    id = serializers.IntegerField(help_text="Activity ID")
    user = serializers.CharField(help_text="User who performed the action")
    action = serializers.CharField(help_text="Action type (created, updated, deleted, etc.)")
    resource = serializers.CharField(help_text="Resource affected")
    timestamp = serializers.CharField(help_text="Activity timestamp (ISO format)")
    icon = serializers.CharField(help_text="Material icon name")
    color = serializers.CharField(help_text="Icon color")


class SystemMetricsSerializer(serializers.Serializer):
    """Serializer for system performance metrics."""

    cpu_usage = serializers.FloatField(help_text="CPU usage percentage")
    memory_usage = serializers.FloatField(help_text="Memory usage percentage")
    disk_usage = serializers.FloatField(help_text="Disk usage percentage")
    network_in = serializers.CharField(help_text="Network incoming bandwidth")
    network_out = serializers.CharField(help_text="Network outgoing bandwidth")
    response_time = serializers.CharField(help_text="Average response time")
    uptime = serializers.CharField(help_text="System uptime")


class UserStatisticsSerializer(serializers.Serializer):
    """Serializer for user statistics."""

    total_users = serializers.IntegerField(help_text="Total number of users")
    active_users = serializers.IntegerField(help_text="Active users (last 30 days)")
    new_users = serializers.IntegerField(help_text="New users (last 7 days)")
    superusers = serializers.IntegerField(help_text="Number of superusers")


class AppStatisticsSerializer(serializers.Serializer):
    """Serializer for application-specific statistics."""

    app_name = serializers.CharField(help_text="Application name")
    statistics = serializers.DictField(
        child=serializers.IntegerField(),
        help_text="Application statistics"
    )


class DashboardOverviewSerializer(serializers.Serializer):
    """
    Main serializer for dashboard overview endpoint.
    Uses DictField to avoid allOf generation in OpenAPI.
    """

    stat_cards = serializers.ListField(
        child=serializers.DictField(),
        help_text="Dashboard statistics cards"
    )
    system_health = serializers.ListField(
        child=serializers.DictField(),
        help_text="System health status"
    )
    quick_actions = serializers.ListField(
        child=serializers.DictField(),
        help_text="Quick action buttons"
    )
    recent_activity = serializers.ListField(
        child=serializers.DictField(),
        help_text="Recent activity entries"
    )
    system_metrics = serializers.DictField(help_text="System performance metrics")
    user_statistics = serializers.DictField(help_text="User statistics")
    timestamp = serializers.CharField(help_text="Data timestamp (ISO format)")


class APIResponseSerializer(serializers.Serializer):
    """Standard API response wrapper."""

    success = serializers.BooleanField(help_text="Operation success status")
    message = serializers.CharField(required=False, help_text="Success message")
    error = serializers.CharField(required=False, help_text="Error message")
    data = serializers.DictField(required=False, help_text="Response data")
