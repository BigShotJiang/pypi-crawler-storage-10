"""
Dashboard API ViewSets

Provides RESTful endpoints for dashboard data.
No ORM dependencies - uses services for data collection.
"""

import logging
from datetime import datetime
from typing import Any, Dict

from drf_spectacular.utils import OpenApiParameter, OpenApiResponse, extend_schema, inline_serializer
from drf_spectacular.types import OpenApiTypes
from rest_framework import serializers, status, viewsets
from rest_framework.authentication import BasicAuthentication, SessionAuthentication
from rest_framework.decorators import action
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response

from ..services import StatisticsService, SystemHealthService
from .serializers import (
    ActivityEntrySerializer,
    APIResponseSerializer,
    AppStatisticsSerializer,
    DashboardOverviewSerializer,
    QuickActionSerializer,
    StatCardSerializer,
    SystemHealthItemSerializer,
    SystemHealthSerializer,
    SystemMetricsSerializer,
    UserStatisticsSerializer,
)

logger = logging.getLogger(__name__)


class DashboardViewSet(viewsets.GenericViewSet):
    """
    Dashboard Data ViewSet

    Provides comprehensive dashboard endpoints for Next.js frontend.
    All data is collected via services without ORM dependencies.

    %%PRIORITY:HIGH%%
    %%AI_HINT: Main entry point for dashboard API%%

    TAGS: dashboard, api, viewset
    USED_BY: Next.js admin panel
    """

    authentication_classes = [SessionAuthentication, BasicAuthentication]
    permission_classes = [IsAdminUser]
    serializer_class = DashboardOverviewSerializer

    @action(detail=False, methods=['get'], url_path='overview')
    @extend_schema(
        summary="Get dashboard overview",
        description="Retrieve complete dashboard data including stats, health, actions, and metrics",
        responses={200: DashboardOverviewSerializer},
        tags=["Dashboard"]
    )
    def overview(self, request):
        """
        Get complete dashboard overview.

        Returns all dashboard data in a single request:
        - Statistics cards
        - System health status
        - Quick actions
        - Recent activity
        - System metrics
        - User statistics
        """
        try:
            stats_service = StatisticsService()
            health_service = SystemHealthService()

            data = {
                'stat_cards': stats_service.get_stat_cards(),
                'system_health': health_service.get_all_health_checks(),
                'quick_actions': health_service.get_quick_actions(),
                'recent_activity': stats_service.get_recent_activity(limit=10),
                'system_metrics': stats_service.get_system_metrics(),
                'user_statistics': stats_service.get_user_statistics(),
                'timestamp': datetime.now().isoformat(),
            }

            return Response(data)

        except Exception as e:
            logger.error(f"Dashboard overview API error: {e}", exc_info=True)
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get statistics cards",
        description="Retrieve dashboard statistics cards with key metrics",
        responses=StatCardSerializer(many=True),
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='stats/cards', pagination_class=None, serializer_class=StatCardSerializer)
    def stat_cards(self, request):
        """Get dashboard statistics cards."""
        try:
            stats_service = StatisticsService()
            cards = stats_service.get_stat_cards()

            return Response(cards)

        except Exception as e:
            logger.error(f"Stat cards API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get system health status",
        description="Retrieve overall system health including all component checks",
        responses={200: SystemHealthSerializer},
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='health', serializer_class=SystemHealthSerializer)
    def system_health(self, request):
        """Get overall system health status."""
        try:
            health_service = SystemHealthService()
            health_data = health_service.get_overall_health_status()

            return Response(health_data)

        except Exception as e:
            logger.error(f"System health API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get quick actions",
        description="Retrieve quick action buttons for dashboard",
        responses=QuickActionSerializer(many=True),
        tags=["Dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='actions', pagination_class=None, serializer_class=QuickActionSerializer)
    def quick_actions(self, request):
        """Get quick action buttons."""
        try:
            health_service = SystemHealthService()
            actions = health_service.get_quick_actions()

            return Response(actions)

        except Exception as e:
            logger.error(f"Quick actions API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get recent activity",
        description="Retrieve recent system activity entries",
        parameters=[
            OpenApiParameter(
                name='limit',
                description='Maximum number of entries to return',
                required=False,
                type=int,
                default=10
            ),
        ],
        responses=ActivityEntrySerializer(many=True),
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='activity', pagination_class=None, serializer_class=ActivityEntrySerializer)
    def recent_activity(self, request):
        """Get recent activity entries."""
        try:
            limit = int(request.query_params.get('limit', 10))
            stats_service = StatisticsService()
            activity = stats_service.get_recent_activity(limit=limit)

            return Response(activity)

        except Exception as e:
            logger.error(f"Recent activity API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get system metrics",
        description="Retrieve system performance metrics (CPU, memory, disk, etc.)",
        responses={200: SystemMetricsSerializer},
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='metrics', serializer_class=SystemMetricsSerializer)
    def system_metrics(self, request):
        """Get system performance metrics."""
        try:
            stats_service = StatisticsService()
            metrics = stats_service.get_system_metrics()

            return Response(metrics)

        except Exception as e:
            logger.error(f"System metrics API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get user statistics",
        description="Retrieve user-related statistics",
        responses={200: UserStatisticsSerializer},
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='stats/users', serializer_class=UserStatisticsSerializer)
    def user_statistics(self, request):
        """Get user statistics."""
        try:
            stats_service = StatisticsService()
            user_stats = stats_service.get_user_statistics()

            return Response(user_stats)

        except Exception as e:
            logger.error(f"User statistics API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @extend_schema(
        summary="Get application statistics",
        description="Retrieve statistics for all enabled django-cfg applications",
        responses=AppStatisticsSerializer(many=True),
        tags=["dashboard"]
    )
    @action(detail=False, methods=['get'], url_path='stats/apps', pagination_class=None, serializer_class=AppStatisticsSerializer)
    def app_statistics(self, request):
        """Get application-specific statistics."""
        try:
            stats_service = StatisticsService()
            app_stats = stats_service.get_app_statistics()

            # Convert dict to list of {app_name, statistics} objects
            data = [
                {'app_name': app_name, 'statistics': stats}
                for app_name, stats in app_stats.items()
            ]

            return Response(data)

        except Exception as e:
            logger.error(f"App statistics API error: {e}")
            return Response({
                'error': str(e)
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
