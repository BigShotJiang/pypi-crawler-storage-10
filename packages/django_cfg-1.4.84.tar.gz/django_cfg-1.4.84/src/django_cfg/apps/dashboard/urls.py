"""
Dashboard URLs

RESTful API endpoints for dashboard data.
Follows the same pattern as tasks app.
"""

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from .api.viewsets import DashboardViewSet

app_name = 'dashboard'

# Main router for ViewSets
router = DefaultRouter()
router.register(r'', DashboardViewSet, basename='dashboard')

urlpatterns = [
    # RESTful API endpoints using ViewSets
    # Mounted at cfg/dashboard/api/
    path('api/', include(router.urls)),
]
