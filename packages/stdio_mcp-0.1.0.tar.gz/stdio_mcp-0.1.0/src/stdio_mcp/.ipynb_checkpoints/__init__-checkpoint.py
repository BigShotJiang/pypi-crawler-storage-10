from fastmcp import FastMCP
import argparse



    


def main() -> None:
    """Main entry point for the MCP server."""

    # 设置命令行参数解析
    parser = argparse.ArgumentParser()
    parser.add_argument("--greeting", type=str, default="Hello", help="Custom greeting to use")
    args = parser.parse_args()
    
    mcp = FastMCP("My MCP Server")
    
    # 将参数存储在mcp对象中或作为全局变量，以便工具函数可以访问
    custom_greeting = args.greeting
    
    @mcp.tool
    def greet(name: str) -> str:
        """Greet someone by name with a custom greeting.
        
        Args:
            name: The name of the person to greet
        """
        return f"{custom_greeting}, {name}!"  # 使用传入的greeting参数
    
    @mcp.tool
    def add_numbers(a: float, b: float) -> float:
        """Add two numbers together.
        
        Args:
            a: First number
            b: Second number
        """
        return a + b
    mcp.run(transport="stdio")
