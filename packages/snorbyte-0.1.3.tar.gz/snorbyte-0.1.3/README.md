# snorbyte

Minimal Snorbyte TTS client with **streaming**, **PCM ring-buffer playback**, and **ffplay/ffmpeg required** for compressed live playback/encoding.

## DEPENDENCIES (VERY IMPORTANT)

We **require** both `ffplay` and `ffmpeg` to be available on your system **PATH**.
We also use `sounddevice` for PCM playback, which depends on **PortAudio** (OS package) on Linux.

### Windows

**Option A (winget)**
```powershell
winget install -e --id Gyan.FFmpeg
```

**Option B (chocolatey)**
```powershell
choco install ffmpeg
```

**Verify**

After install, ensure the ffmpeg/bin folder is on your PATH.
```powershell
ffmpeg -version
ffplay -version
```

### Linux

**Debian/Ubuntu**
```powershell
sudo apt-get update
sudo apt-get install -y ffmpeg libportaudio2
```

**Fedora/RHEL/CentOS (dnf)**
```powershell
sudo dnf install -y ffmpeg portaudio
```

**Arch/Manjaro**
```powershell
sudo pacman -S --needed ffmpeg portaudio
```

**Verify**
```powershell
ffmpeg -version
ffplay -version
```

## INSTALL PACKAGE
```powershell
pip install snorbyte
```

## EXAMPLE USAGE
```python
from snorbyte import Snorbyte

def consume_stream(b: bytes):
    # b is raw stream bytes (PCM aligned for fmt="pcm", raw MP3/WAV chunks otherwise)
    print(f"chunk {len(b)} bytes")

client = Snorbyte(
    api_key="<YOUR-API-KEY>",
    endpoint="http://api.snorbyte.com/tts",
)

path, data, info = client.tts(
    utterance="दोस्त, दिल टूटा है तो क्या, रात भर प्लेलिस्ट रोएगी पर सुबह धूप आएगी, खुद से वादा कर—जो गया, जाने दे, जो आएगा, मुस्कुराकर अपनाएंगे।",
    speaker_id=233,
    speaker_name="",
    tone="Encouraging",
    speed=1.00,
    chunk_size=8192,
    denoise=True,
    stream=True,
    stream_bytes_callback=consume_stream,
    fmt="pcm",               # "mp3" | "wav" | "pcm"
    save_to="out5.mp3",      # optional; auto-name if omitted
    temperature=0.0,
    top_p=1.0,
    repetition_penalty=1.05,
)

print("Saved to:", path)
print("Bytes in memory:", len(data) if data else None)
print("Info (ms):", info["latency_ms"])
```
