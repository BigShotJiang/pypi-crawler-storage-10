#!/usr/bin/env python3
"""
Minimal client library for Snorbyte TTS (callable class).

Usage:
    from snorbyte import Snorbyte
    client = Snorbyte(
        api_key="YOUR_KEY",
        endpoint="http://api.snorbyte.com/tts",
        sample_rate=24000,
        channels=1,
        bits_per_sample=16,
        prebuffer_ms=25,
        ring_ms=1000,
        blocksize_frames=256,
        latency_hint="low",
        overflow_policy="block",
    )

    saved_path, data_bytes, info = client.tts(
        "hello world",
        speaker_id=228,
        tone="Encouraging",
        fmt="mp3",
        save_to="out.mp3",
        stream=True,
        playback=True,   # <- NEW: play audio only when True (default True)
    )
"""

from __future__ import annotations
import os, time, json, pathlib, datetime, requests, typing as _t
import contextlib, subprocess, shutil, struct
import numpy as np

# PCM playback dependency (PortAudio via sounddevice)
import sounddevice as sd

# --------------------------- Defaults ---------------------------

DEFAULT_ENDPOINT = "http://api.snorbyte.com/tts"

_MIME_BY_FMT = {
    "mp3": "audio/mpeg",
    "wav": "audio/wav",
    "pcm": "application/octet-stream",
}
_EXT_BY_FMT = {
    "mp3": "mp3",
    "wav": "wav",
    "pcm": "raw",
}

def _now_ts() -> str:
    return f"{datetime.datetime.now():%Y%m%d_%H%M%S}"

def _ms(sec: float | None) -> float | None:
    return round(sec * 1000.0, 2) if sec is not None else None

def _safe_bool(b: bool) -> str:
    return "true" if b else "false"

# --------------------------- FFmpeg/ffplay helpers ---------------------------

def _graceful_close(proc: subprocess.Popen | None,
                    stdin=None,
                    timeout: float = 3.0) -> None:
    """Close stdin, wait, and kill on timeout; always reap to avoid zombies."""
    if proc is None:
        return
    with contextlib.suppress(Exception):
        if stdin:
            stdin.close()
    try:
        proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        with contextlib.suppress(Exception):
            proc.kill()
        with contextlib.suppress(Exception):
            proc.communicate(timeout=2.0)
    except Exception:
        with contextlib.suppress(Exception):
            proc.kill()
        with contextlib.suppress(Exception):
            proc.communicate(timeout=2.0)

def _have_ffplay() -> bool:
    return shutil.which("ffplay") is not None

def _have_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None

def _ffplay_cmd_for(fmt: str) -> list[str]:
    # low latency flags
    return [
        "ffplay", "-loglevel", "error", "-nodisp", "-autoexit",
        "-fflags", "nobuffer", "-flags", "low_delay",
        "-probesize", "32", "-analyzeduration", "0",
        "-i", "pipe:0",
    ]

def _spawn_ffplay(fmt: str):
    if not _have_ffplay():
        raise RuntimeError(
            "Playback requested for non-PCM format, but 'ffplay' was not found on PATH. "
            "Install FFmpeg (which includes ffplay). See README for OS-specific instructions."
        )
    cmd = _ffplay_cmd_for(fmt)
    if os.name == "nt":
        POPEN_KW = {"stdin": subprocess.PIPE, "bufsize": 0,
                    "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    else:
        POPEN_KW = {"stdin": subprocess.PIPE, "bufsize": 0, "stderr": subprocess.PIPE}
    return subprocess.Popen(cmd, **POPEN_KW)

def _spawn_ffmpeg_mp3_encoder(dest_path: str, sample_rate: int, channels: int):
    if not _have_ffmpeg():
        raise RuntimeError(
            "Saving PCM as MP3 requires 'ffmpeg' on PATH. "
            "Install FFmpeg. See README for OS-specific instructions."
        )
    # ffmpeg -f s16le -ar 24000 -ac 1 -i pipe:0 -c:a libmp3lame -b:a 128k out.mp3
    cmd = [
        "ffmpeg", "-loglevel", "error", "-y",
        "-f", "s16le", "-ar", str(sample_rate), "-ac", str(channels), "-i", "pipe:0",
        "-c:a", "libmp3lame", "-b:a", "128k",
        dest_path,
    ]
    if os.name == "nt":
        POPEN_KW = {"stdin": subprocess.PIPE,
                    "creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
    else:
        POPEN_KW = {"stdin": subprocess.PIPE, "stderr": subprocess.PIPE}
    return subprocess.Popen(cmd, **POPEN_KW)

def _safe_sink_write(sink, buf: bytes) -> bool:
    if sink is None:
        return False
    try:
        sink.write(buf)
        if hasattr(sink, "flush"):
            sink.flush()
        return True
    except (BrokenPipeError, OSError, ValueError):
        return False

# --------------------------- WAV header helpers ---------------------------

_WAV_HEADER_BYTES = 44  # standard PCM header size

def _write_wav_placeholder(f, channels: int, sample_rate: int, bits: int):
    """Write a placeholder 44-byte header; sizes are patched at the end."""
    f.write(b"\x00" * _WAV_HEADER_BYTES)

def _patch_wav_header_in_place(f, data_size: int, channels: int, sample_rate: int, bits: int):
    byte_rate   = sample_rate * channels * bits // 8
    block_align = channels * bits // 8
    riff_size   = 36 + data_size
    header = (
        b"RIFF" + struct.pack("<I", riff_size) + b"WAVE"
      + b"fmt " + struct.pack("<I", 16) + struct.pack("<HHIIHH",
            1,  # PCM
            channels,
            sample_rate,
            byte_rate,
            block_align,
            bits
        )
      + b"data" + struct.pack("<I", data_size)
    )
    assert len(header) == _WAV_HEADER_BYTES
    f.seek(0)
    f.write(header)
    f.flush()

# --------------------------- PCM Playback (sounddevice) ---------------------------

class _RingBuffer:
    """Simple thread-safe-ish ring buffer (float32 mono)."""
    def __init__(self, capacity_frames: int, overflow_policy: str = "block"):
        self.capacity = int(capacity_frames)
        self.buf = np.zeros(self.capacity, dtype=np.float32)
        self.read_idx = 0
        self.write_idx = 0
        self.overflow_policy = overflow_policy

    def _used(self) -> int:
        used = self.write_idx - self.read_idx
        return used + self.capacity if used < 0 else used

    def _free(self) -> int:
        return self.capacity - self._used() - 1

    def write(self, data) -> None:
        if data.size == 0:
            return
        written = 0
        while written < data.size:
            free = self._free()
            if free == 0:
                if self.overflow_policy == "drop_oldest":
                    self.read_idx = (self.read_idx + 1) % self.capacity
                    free = 1
                elif self.overflow_policy == "drop_newest":
                    return
                else:
                    time.sleep(0.001)
                    continue
            can = min(free, data.size - written)
            first = min(can, self.capacity - self.write_idx)
            self.buf[self.write_idx:self.write_idx + first] = data[written:written + first]
            rem = can - first
            if rem > 0:
                self.buf[0:rem] = data[written + first:written + first + rem]
            self.write_idx = (self.write_idx + can) % self.capacity
            written += can

    def read_into(self, out) -> int:
        frames = out.size
        avail = self._used()
        to_read = min(frames, avail)
        first = min(to_read, self.capacity - self.read_idx)
        if first > 0:
            out[:first] = self.buf[self.read_idx:self.read_idx + first]
        rem = to_read - first
        if rem > 0:
            out[first:first + rem] = self.buf[0:rem]
        self.read_idx = (self.read_idx + to_read) % self.capacity
        return to_read

    def available(self) -> int:
        return self._used()

class _PCMPlayer:
    """Low-latency mono float32 playback using sounddevice (optional)."""
    def __init__(self, out_sr: int, prebuffer_ms: int, ring_ms: int,
                 blocksize_frames: int, latency_hint: float | str, overflow_policy: str):
        self.sd = sd
        self.np = np
        self.out_sr = int(out_sr)
        self.prebuffer_frames = int((prebuffer_ms / 1000.0) * self.out_sr)
        capacity = int((ring_ms / 1000.0) * self.out_sr)
        self.ring = _RingBuffer(max(capacity, self.prebuffer_frames + 1024), overflow_policy=overflow_policy)
        self.blocksize = int(blocksize_frames)
        self.latency = latency_hint
        self._stream = None

    def _cb(self, outdata, frames, *_):
        out = outdata[:, 0]
        got = self.ring.read_into(out)
        if got < frames:
            out[got:] = 0.0

    def start(self):
        self._stream = self.sd.OutputStream(
            samplerate=self.out_sr, channels=1, dtype="float32",
            blocksize=self.blocksize, latency=self.latency, callback=self._cb
        )
        self._stream.start()

    def stop(self):
        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

# --------------------------- Hard requirement check ---------------------------

def _assert_ff_tools_present():
    missing = []
    if not _have_ffmpeg():
        missing.append("ffmpeg")
    if not _have_ffplay():
        missing.append("ffplay")
    if missing:
        raise RuntimeError(
            "Required external tools missing: {}. "
            "Please install FFmpeg (which includes both 'ffmpeg' and 'ffplay') "
            "and ensure they are on PATH. See README for Windows/Linux install commands."
            .format(", ".join(missing))
        )

# =========================== Class Wrapper ===========================

class Snorbyte:
    def __init__(
        self,
        api_key: str,
        endpoint: str = DEFAULT_ENDPOINT,
        sample_rate: int = 24000,
        channels: int = 1,
        bits_per_sample: int = 16,
        prebuffer_ms: int = 25,
        ring_ms: int = 1000,
        blocksize_frames: int = 256,
        latency_hint: float | str = "low",
        overflow_policy: str = "block",
    ):
        print("[SNORBYTE] Initializing client...")

        # Make ffplay/ffmpeg **compulsory**
        _assert_ff_tools_present()

        self.api_key = api_key
        self.endpoint = endpoint
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.bits_per_sample = int(bits_per_sample)
        self.prebuffer_ms = int(prebuffer_ms)
        self.ring_ms = int(ring_ms)
        self.blocksize_frames = int(blocksize_frames)
        self.latency_hint = latency_hint
        self.overflow_policy = overflow_policy

        # PCM player (spawn at init as requested)
        self.pcm_player: _PCMPlayer | None = _PCMPlayer(
            out_sr=self.sample_rate,
            prebuffer_ms=self.prebuffer_ms,
            ring_ms=self.ring_ms,
            blocksize_frames=self.blocksize_frames,
            latency_hint=self.latency_hint,
            overflow_policy=self.overflow_policy,
        )
        self.pcm_player.start()

        # ffplay procs (spawn at init as requested; stdin closed per call)
        self.ff_proc_play_mp3 = _spawn_ffplay("mp3")
        self.ff_sink_play_mp3 = self.ff_proc_play_mp3.stdin

        self.ff_proc_play_wav = _spawn_ffplay("wav")
        self.ff_sink_play_wav = self.ff_proc_play_wav.stdin

        print("[SNORBYTE] Client Initialized.")

    def reset(self):
        # Close old procs
        _graceful_close(self.ff_proc_play_mp3, self.ff_sink_play_mp3, timeout=2.0)
        _graceful_close(self.ff_proc_play_wav, self.ff_sink_play_wav, timeout=2.0)

        # Recreate PCM player
        if self.pcm_player is not None:
            with contextlib.suppress(Exception):
                self.pcm_player.stop()

        self.pcm_player = _PCMPlayer(
            out_sr=self.sample_rate,
            prebuffer_ms=self.prebuffer_ms,
            ring_ms=self.ring_ms,
            blocksize_frames=self.blocksize_frames,
            latency_hint=self.latency_hint,
            overflow_policy=self.overflow_policy,
        )
        self.pcm_player.start()

        # Respawn ffplay
        self.ff_proc_play_mp3 = _spawn_ffplay("mp3")
        self.ff_sink_play_mp3 = self.ff_proc_play_mp3.stdin

        self.ff_proc_play_wav = _spawn_ffplay("wav")
        self.ff_sink_play_wav = self.ff_proc_play_wav.stdin

    def close(self):
        # graceful cleanup
        _graceful_close(self.ff_proc_play_mp3, self.ff_sink_play_mp3, timeout=2.0)
        _graceful_close(self.ff_proc_play_wav, self.ff_sink_play_wav, timeout=2.0)
        if self.pcm_player is not None:
            with contextlib.suppress(Exception):
                self.pcm_player.stop()
        self.pcm_player = None
        self.ff_proc_play_mp3 = None
        self.ff_sink_play_mp3 = None
        self.ff_proc_play_wav = None
        self.ff_sink_play_wav = None

    def __del__(self):
        with contextlib.suppress(Exception):
            self.close()

    # --------------------------- Public API (callable) ---------------------------
    def tts(
        self,
        utterance: str,
        *,
        speaker_id: int | str | None = None,
        speaker_name: str = "",
        tone: str = "",
        temperature: float = 0.0,
        top_p: float = 1.0,
        repetition_penalty: float = 1.05,
        speed: float = 1.0,
        denoise: bool = True,
        stream: bool = True,
        stream_bytes_callback: _t.Callable[[bytes], None] | None = None,
        fmt: str = "mp3",
        save_to: str | None = None,
        return_bytes: bool = True,
        chunk_size: int = 8192,
        playback: bool = True,  # <- NEW: only play audio when True
    ) -> tuple[str | None, bytes | None, dict]:
        """
        Returns:
            (saved_path, data_bytes_or_none, info_dict)
        """
        fmt = fmt.lower().strip()
        if fmt not in _MIME_BY_FMT:
            raise ValueError(f"fmt must be one of {list(_MIME_BY_FMT)}")

        # -------- Resolve output path + special PCM container behavior --------
        if save_to is None:
            ext = ("wav" if fmt == "pcm" else _EXT_BY_FMT[fmt])
            save_to = f"tts_{_now_ts()}.{ext}"
        dest = pathlib.Path(save_to)
        dest.parent.mkdir(parents=True, exist_ok=True)

        ext_lower = dest.suffix.lower()
        if fmt == "pcm":
            if ext_lower == "":
                dest = dest.with_suffix(".wav")
                ext_lower = ".wav"
            allowed_pcm_ext = {".wav", ".mp3", ".raw", ".pcm"}
            if ext_lower not in allowed_pcm_ext:
                raise ValueError(f"When fmt='pcm', filename must end with one of {allowed_pcm_ext}.")

        pcm_player = self.pcm_player

        pcm_container = None   # 'raw' | 'wav' | 'mp3'
        if fmt == "pcm":
            if ext_lower in (".raw", ".pcm"):
                pcm_container = "raw"
            elif ext_lower == ".wav":
                pcm_container = "wav"
            elif ext_lower == ".mp3":
                pcm_container = "mp3"

        # -------- Prepare network request --------
        headers = {"accept": _MIME_BY_FMT[fmt] }
        if speaker_id is None and speaker_name is None:
            raise ValueError("Either speaker_id or speaker_name must be provided.")
        if utterance is None:
            raise ValueError("utterance must be provided.")
        if self.api_key is None:
            raise ValueError("api_key must be provided.")
        if ((speaker_id == 233 or speaker_id == 228) or (speaker_name.lower() == "charan" or speaker_name.lower() == "shreeja")) and tone not in ("Encouraging", "Consoling"):
            raise ValueError("For the selected speaker, tone must be either 'Encouraging' or 'Consoling'.")
        if not((speaker_id == 233 or speaker_id == 228) or (speaker_name.lower() == "charan" or speaker_name.lower() == "shreeja")) and tone != "":
            raise ValueError("Tone can only be set for speaker 'charan' or 'shreeja'.")

        params = {
            "utterance": utterance,
            "api_key": self.api_key,
            "speaker_id": str(speaker_id) if speaker_id is not None else "",
            "speaker_name": str(speaker_name) if speaker_name is not None else "",
            "tone": tone,
            "temperature": str(temperature),
            "top_p": str(top_p),
            "repetition_penalty": str(repetition_penalty),
            "speed": f"{speed:.2f}",
            "denoise": _safe_bool(denoise),
            "stream": _safe_bool(stream),
            "stream_format": fmt,
        }

        info = {
            "endpoint": self.endpoint,
            "params": {**params, "api_key": "***redacted***"},
            "mode": "stream" if stream else "non-stream",
            "fmt": fmt,
        }

        # -------- HTTP call --------
        t0 = time.perf_counter()
        print("[SNORBYTE] Sending TTS Request")
        resp = requests.post(self.endpoint, params=params, headers=headers, data=b"", timeout=180, stream=stream)
        resp.raw.decode_content = False
        t_headers = time.perf_counter()
        resp.raise_for_status()

        info.update({
            "status_code": resp.status_code,
            "content_type": resp.headers.get("Content-Type"),
            "content_length_header": int(resp.headers.get("Content-Length", "-1")) if resp.headers.get("Content-Length") else None,
            "server_timing": resp.headers.get("Server-Timing"),
            "x_request_id": resp.headers.get("x-request-id"),
            "date_header": resp.headers.get("Date"),
            "latency_ms": {"time_to_headers": _ms(t_headers - t0)},
        })

        # -------- Initialize writers/players --------
        f = None
        total_file_bytes = 0  # bytes written to output file
        total_pcm_bytes  = 0  # PCM payload bytes seen (for WAV header patch)

        if fmt != "pcm":
            if dest.exists():
                dest.unlink()
            f = open(dest, "wb")
        else:
            if pcm_container in ("raw", "wav"):
                if dest.exists():
                    dest.unlink()
                mode = "wb+"
                f = open(dest, mode)
                if pcm_container == "wav":
                    _write_wav_placeholder(f, channels=self.channels, sample_rate=self.sample_rate, bits=self.bits_per_sample)
                    total_file_bytes += _WAV_HEADER_BYTES

        # Select ffplay sinks only if we will actually play
        ff_proc_play = None
        ff_sink_play = None
        if playback and fmt in ("mp3", "wav") and stream:
            if fmt == "mp3":
                ff_proc_play = self.ff_proc_play_mp3
                ff_sink_play = self.ff_proc_play_mp3.stdin if self.ff_proc_play_mp3 else None
            elif fmt == "wav":
                ff_proc_play = self.ff_proc_play_wav
                ff_sink_play = self.ff_proc_play_wav.stdin if self.ff_proc_play_wav else None

        ff_proc_enc = None
        ff_sink_enc = None
        if fmt == "pcm" and pcm_container == "mp3":
            ff_proc_enc = _spawn_ffmpeg_mp3_encoder(str(dest), sample_rate=self.sample_rate, channels=self.channels)
            ff_sink_enc = ff_proc_enc.stdin

        # -------- Prime first payload chunk ASAP --------
        t_first_byte = None
        t_first_play_write = None
        t_first_audible = None

        if stream:
            it = resp.iter_content(chunk_size=chunk_size)
            first_chunk = b""
            for chunk in it:
                if chunk:
                    first_chunk = chunk
                    t_first_byte = time.perf_counter()
                    break
        else:
            first_chunk = resp.content
            t_first_byte = t_headers

        # -------- Helpers for writing --------
        def _write_file(buf: bytes):
            nonlocal total_file_bytes
            if f is not None:
                f.write(buf)
                total_file_bytes += len(buf)

        def _handle_pcm_bytes(pcm_bytes: bytes):
            nonlocal total_pcm_bytes, t_first_play_write, t_first_audible
            if not pcm_bytes:
                return
            total_pcm_bytes += len(pcm_bytes)

            # File writing depending on container
            if pcm_container == "raw":
                _write_file(pcm_bytes)
            elif pcm_container == "wav":
                _write_file(pcm_bytes)
            elif pcm_container == "mp3":
                if ff_sink_enc is not None:
                    _safe_sink_write(ff_sink_enc, pcm_bytes)

            # Playback (PCM path) only if requested
            if playback and pcm_player is not None:
                pcm16 = np.frombuffer(memoryview(pcm_bytes), dtype="<i2")
                f32 = pcm16.astype(np.float32) / 32768.0
                if t_first_play_write is None and f32.size:
                    t_first_play_write = time.perf_counter()
                pcm_player.ring.write(f32)
                if t_first_audible is None:
                    need = int((self.prebuffer_ms / 1000.0) * self.sample_rate)
                    if pcm_player.ring.available() >= need:
                        t_first_audible = time.perf_counter()

        # -------- Handle primed first chunk --------
        leftover = b""
        if fmt == "pcm":
            data = leftover + first_chunk
            usable = (len(data) // 2) * 2
            if usable:
                if stream_bytes_callback: stream_bytes_callback(data[:usable])
                _handle_pcm_bytes(data[:usable])
                leftover = data[usable:]
            else:
                leftover = data
        else:
            if stream_bytes_callback and first_chunk:
                stream_bytes_callback(first_chunk)
            _write_file(first_chunk)
            # Play compressed only if requested
            if playback and ff_sink_play is not None and first_chunk:
                if t_first_play_write is None:
                    t_first_play_write = time.perf_counter()
                ok = _safe_sink_write(ff_sink_play, first_chunk)
                if not ok:
                    ff_sink_play = None

        # If non-streaming and playback=True, we still want to play the full buffer
        if (not stream) and playback and fmt in ("mp3", "wav"):
            # Feed the entire content to ffplay now (already done as first_chunk above).
            # No extra work needed here because first_chunk == resp.content.

            # If you prefer ensuring the player drains for non-stream,
            # the finalize section below will close stdin to ffplay.
            pass

        # -------- Stream the rest --------
        if stream:
            for chunk in it:
                if not chunk:
                    continue
                if fmt == "pcm":
                    data = leftover + chunk
                    usable = (len(data) // 2) * 2
                    if usable:
                        if stream_bytes_callback: stream_bytes_callback(data[:usable])
                        _handle_pcm_bytes(data[:usable])
                        leftover = data[usable:]
                    else:
                        leftover = data
                else:
                    if stream_bytes_callback: stream_bytes_callback(chunk)
                    _write_file(chunk)
                    if playback and ff_sink_play is not None:
                        if t_first_play_write is None:
                            t_first_play_write = time.perf_counter()
                        ok = _safe_sink_write(ff_sink_play, chunk)
                        if not ok:
                            ff_sink_play = None

        t_last_byte = time.perf_counter()

        # -------- Finalize / drain --------
        try:
            # finalize WAV header if needed
            if fmt == "pcm" and pcm_container == "wav" and f is not None:
                _patch_wav_header_in_place(f, data_size=total_pcm_bytes,
                                           channels=self.channels, sample_rate=self.sample_rate, bits=self.bits_per_sample)

            # close encoders
            if ff_sink_enc is not None:
                with contextlib.suppress(Exception):
                    ff_sink_enc.close()
            if ff_proc_enc is not None:
                with contextlib.suppress(Exception):
                    ff_proc_enc.wait(timeout=5)

            # Drain PCM playback ring only if we played
            if playback and pcm_player is not None:
                drain_start = time.perf_counter()
                while pcm_player.ring.available() > 0 and (time.perf_counter() - drain_start) < 5:
                    time.sleep(0.01)
                pcm_player.stop()

            # Close ffplay stdin only if we used it this call
            if playback and ff_sink_play is not None:
                with contextlib.suppress(Exception):
                    ff_sink_play.close()
            if playback and ff_proc_play is not None:
                with contextlib.suppress(Exception):
                    ff_proc_play.wait(timeout=3)

        finally:
            if f is not None:
                f.flush()
                f.close()

        # -------- Metrics --------
        info["total_bytes"] = (total_file_bytes if fmt != "pcm" or pcm_container != "mp3"
                               else (dest.stat().st_size if dest.exists() else None))
        lm = info["latency_ms"]
        lm.update({
            "time_to_headers": _ms(t_headers - t0),
            "time_to_first_byte": _ms((t_first_byte - t0) if t_first_byte else None),
            "network_time_to_first_byte": _ms((t_first_byte - t_headers) if (t_first_byte and t_headers) else None),
            "time_to_first_playback_write": _ms((t_first_play_write - t0) if t_first_play_write else None),
            "time_to_first_audible": _ms((t_first_audible - t0) if t_first_audible else None),  # PCM only
            "first_audio_kpi": _ms(((t_first_audible or t_first_play_write) - t0)
                                   if (t_first_audible or t_first_play_write) else None),
            "time_to_last_byte": _ms(t_last_byte - t0),
            "download_time_ms": _ms(t_last_byte - t_headers),
        })

        # -------- Return bytes if requested --------
        ret_bytes = None
        if return_bytes:
            try:
                ret_bytes = dest.read_bytes()
            except Exception:
                ret_bytes = None

        # Prepare for next call (matches original reset-at-end behavior)
        self.reset()

        return str(dest), ret_bytes, info
