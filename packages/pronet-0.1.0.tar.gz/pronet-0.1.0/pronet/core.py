import requests
import networkx as nx
import matplotlib.pyplot as plt
import csv
import os

# ==========================
# متغيرات عامة
# ==========================
G = None
data_global = []
main_proteins_global = []
selected_layout = "spring"

# ==========================
# دوال الشبكة
# ==========================
def get_string_interactions(protein_names, species=9606, score_threshold=400):
    """
    استدعاء STRING API للحصول على التفاعلات بين البروتينات
    protein_names: قائمة أسماء البروتينات
    species: NCBI taxonomy ID (9606 = الإنسان)
    score_threshold: أقل قيمة للتفاعل للظهور
    """
    all_data = []
    for protein_name in protein_names:
        url = "https://string-db.org/api/json/network"
        params = {
            "identifiers": protein_name,
            "species": species,
            "required_score": score_threshold
        }
        try:
            response = requests.get(url, params=params)
            data = response.json()
            if "error" not in data:
                all_data.extend(data)
        except:
            continue
    return all_data

def get_layout(G, layout_type="spring"):
    """اختيار نوع رسم الشبكة"""
    if layout_type == "spring":
        return nx.spring_layout(G, seed=42)
    elif layout_type == "circular":
        return nx.circular_layout(G)
    elif layout_type == "shell":
        return nx.shell_layout(G)
    else:
        return nx.spring_layout(G, seed=42)

def build_network(data, protein_names, layout_type="spring", show_plot=True):
    """
    بناء شبكة البروتينات
    data: بيانات التفاعلات من STRING
    protein_names: قائمة البروتينات الرئيسية
    layout_type: نوع التخطيط (spring/circular/shell)
    show_plot: إذا True يعرض الرسم البياني
    """
    global G, data_global, main_proteins_global
    G = nx.Graph()
    main_proteins = set([p.strip() for p in protein_names])
    main_proteins_global = main_proteins
    data_global = data

    for interaction in data:
        a = interaction['preferredName_A']
        b = interaction['preferredName_B']
        G.add_node(a)
        G.add_node(b)
        G.add_edge(a, b, weight=interaction['score'])

    if show_plot:
        node_colors = ['red' if node in main_proteins else 'lightblue' for node in G.nodes()]
        pos = get_layout(G, layout_type)
        plt.figure(figsize=(10,8))
        nx.draw(G, pos, with_labels=True, node_color=node_colors, node_size=1500, font_size=10, edge_color='gray')
        plt.show()

    return G

def generate_report(G, protein_names, data, save_path="protein_network_report.txt"):
    """توليد تقرير نصي لشبكة البروتينات"""
    main_proteins = set([p.strip() for p in protein_names])
    with open(save_path, "w") as f:
        f.write("=== Protein Network Report ===\n\n")
        f.write(f"Main proteins: {', '.join(main_proteins)}\n")
        f.write(f"Number of nodes: {G.number_of_nodes()}\n")
        f.write(f"Number of edges: {G.number_of_edges()}\n\n")

        degrees = dict(G.degree())
        max_deg_node = max(degrees, key=degrees.get)
        f.write(f"Most connected protein: {max_deg_node} ({degrees[max_deg_node]} connections)\n\n")

        sorted_edges = sorted(data, key=lambda x: x['score'], reverse=True)[:5]
        f.write("Top 5 interactions:\n")
        for edge in sorted_edges:
            f.write(f"{edge['preferredName_A']} - {edge['preferredName_B']}, score: {edge['score']}\n")
        f.write("\n")

        scores = [edge['score'] for edge in data]
        if scores:
            f.write(f"Max score: {max(scores)}\n")
            f.write(f"Min score: {min(scores)}\n")
            f.write(f"Average score: {sum(scores)/len(scores):.2f}\n\n")

        f.write("Protein list:\n")
        for node in G.nodes():
            tag = "(Main)" if node in main_proteins else ""
            f.write(f"{node} {tag}\n")

    print(f"Report saved to {save_path}")
    return save_path

def save_network_png(G, protein_names, file_path="network.png", layout_type="spring"):
    """حفظ صورة الشبكة بصيغة PNG"""
    if G is None:
        raise ValueError("Network has not been generated yet!")
    node_colors = ['red' if node in protein_names else 'lightblue' for node in G.nodes()]
    pos = get_layout(G, layout_type)
    plt.figure(figsize=(10,8))
    nx.draw(G, pos, with_labels=True, node_color=node_colors, node_size=1500, font_size=10, edge_color='gray')
    plt.savefig(file_path)
    print(f"Network saved as PNG: {file_path}")
    return file_path

def save_report_csv(data, file_path="network.csv"):
    """حفظ تقرير الشبكة بصيغة CSV"""
    if not data:
        raise ValueError("No network data to save!")
    with open(file_path, "w", newline='') as csvfile:
        fieldnames = ['Protein A', 'Protein B', 'Score']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for edge in data:
            writer.writerow({'Protein A': edge['preferredName_A'], 'Protein B': edge['preferredName_B'], 'Score': edge['score']})
    print(f"Report saved as CSV: {file_path}")
    return file_path

# ==========================
# مثال تشغيل مباشر
# ==========================
def main():
    proteins = ["TP53", "BRCA1", "EGFR"]  # مثال
    data = get_string_interactions(proteins)
    if not data:
        print("No interactions found.")
        return
    G = build_network(data, proteins, show_plot=True)
    generate_report(G, proteins, data)
    save_network_png(G, proteins, file_path="network.png")
    save_report_csv(data, file_path="network.csv")

if __name__ == "__main__":
    main()
