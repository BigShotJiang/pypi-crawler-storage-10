# setup.py
from setuptools import setup, find_packages

setup(
    name="pronet",               # اسم المكتبة
    version="0.1.0",             # نسخة المكتبة
    packages=find_packages(),     # يلتقط كل المجلدات التي تحتوي على __init__.py
    install_requires=[            # الحزم المطلوبة
        "requests",
        "networkx",
        "matplotlib"
    ],
    python_requires='>=3.8',
    description="A Python library for building and analyzing protein interaction networks",
    author="Sarah",
    license="MIT",
    url="https://github.com/username/pronet",  # ضع رابط المشروع لو عندك GitHub
)
