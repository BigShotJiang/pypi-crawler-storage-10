# data/constants.py
from core.models import ReportReason

# Report reason mapping to Telegram Raw Types
REASON_MAPPING = {
    ReportReason.SPAM: "InputReportReasonSpam",
    ReportReason.VIOLENCE: "InputReportReasonViolence", 
    ReportReason.PORNOGRAPHY: "InputReportReasonPornography",
    ReportReason.CHILD_ABUSE: "InputReportReasonChildAbuse",
    ReportReason.ILLEGAL_DRUGS: "InputReportReasonIllegalDrugs",
    ReportReason.PERSONAL_DETAILS: "InputReportReasonPersonalDetails",
    ReportReason.ILLEGAL: "InputReportReasonIllegal",
    ReportReason.OTHER: "InputReportReasonOther"
}

# Persian names for report reasons
PERSIAN_NAMES = {
    ReportReason.SPAM: "اسپم",
    ReportReason.VIOLENCE: "خشونت",
    ReportReason.PORNOGRAPHY: "پورنوگرافی", 
    ReportReason.CHILD_ABUSE: "سوء استفاده از کودکان",
    ReportReason.ILLEGAL_DRUGS: "مواد مخدر غیرقانونی",
    ReportReason.PERSONAL_DETAILS: "افشای اطلاعات شخصی",
    ReportReason.ILLEGAL: "فعالیت غیرقانونی",
    ReportReason.OTHER: "سایر موارد"
}

# Help text constant
HELP_TEXT = """
🎯 **سیستم گزارش‌دهی پیشرفته تلگرام**

**📋 فرمت دستور:**
`/report لینک_هدف آی‌دی_پیام دلیل [تعداد] [کامنت]`

**🔧 پارامترهای ضروری:**
• `لینک_هدف` - آدرس کاربر، کانال یا گروه
• `آی‌دی_پیام` - شماره پیام مورد نظر  
• `دلیل` - دلیل گزارش (لیست زیر)

**🎭 دلایل گزارش:**
• `spam` - اسپم
• `violence` - خشونت
• `porn` - پورنوگرافی
• `child_abuse` - سوء استفاده از کودکان
• `drugs` - مواد مخدر غیرقانونی
• `personal` - افشای اطلاعات شخصی
• `illegal` - فعالیت غیرقانونی
• `other` - سایر موارد

**⚙️ پارامترهای اختیاری:**
• `تعداد` - تعداد گزارش (۱ تا ۱۰)
• `کامنت` - توضیح اضافی (اختیاری)

**🔍 مثال‌های کاربردی:**
`/report @username 123 porn`
`/report @channel 456 spam 3`
`/report @user 789 violence 2 ارسال محتوای خشونت‌آمیز`
`/report https://t.me/channel 321 child_abuse 1`

**⚠️ ملاحظات امنیتی:**
• رعایت حریم خصوصی کاربران
• استفاده تنها برای موارد قانونی
• پایبندی به قوانین تلگرام
"""

# Reasons list text
REASONS_TEXT = """
📚 **لیست کامل دلایل گزارش:**

🔹 **اسپم**
   کد: `spam`
   مثال: `/report @target 123 spam`

🔹 **خشونت**  
   کد: `violence`
   مثال: `/report @target 123 violence`

🔹 **پورنوگرافی**
   کد: `porn` 
   مثال: `/report @target 123 porn`

🔹 **سوء استفاده از کودکان**
   کد: `child_abuse`
   مثال: `/report @target 123 child_abuse`

🔹 **مواد مخدر غیرقانونی**
   کد: `drugs`
   مثال: `/report @target 123 drugs`

🔹 **افشای اطلاعات شخصی**
   کد: `personal`
   مثال: `/report @target 123 personal`

🔹 **فعالیت غیرقانونی**
   کد: `illegal`
   مثال: `/report @target 123 illegal`

🔹 **سایر موارد**
   کد: `other`
   مثال: `/report @target 123 other`

📝 برای اطلاعات بیشتر از `/report` استفاده کنید
"""