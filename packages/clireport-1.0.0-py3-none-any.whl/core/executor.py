# core/executor.py
import asyncio
import logging
from typing import Optional
from pyrogram import Client
from pyrogram.errors import (
    FloodWait, 
    PeerIdInvalid, 
    ChannelInvalid, 
    UserNotParticipant,
    ChatAdminRequired
)
from pyrogram.raw import functions, types

from .models import ReportReason, ReportRequest
from .config import Config

logger = logging.getLogger(__name__)

class ReportExecutor:
    """Class for executing report operations"""
    
    def __init__(self, client: Client):
        self.client = client
        self._active_operations = 0
    
    async def execute_report(
        self, 
        target_entity: str, 
        message_id: int, 
        reason: ReportReason, 
        comment: str = ""
    ) -> bool:
        """Execute a single report operation"""
        self._active_operations += 1
        
        try:
            # Resolve target peer
            peer = await self.client.resolve_peer(target_entity)
            
            # Prepare report parameters
            report_params = {
                'peer': peer,
                'id': [message_id],
                'reason': self._get_reason_type(reason),
            }
            
            # Add comment if provided
            if comment:
                report_params['message'] = comment
            
            # Execute report
            await self.client.invoke(functions.messages.Report(**report_params))
            logger.info(f"Report sent successfully to {target_entity} for message {message_id}")
            return True
            
        except FloodWait as e:
            logger.warning(f"FloodWait: Waiting {e.value} seconds")
            await asyncio.sleep(e.value)
            # Retry after flood wait
            return await self.execute_report(target_entity, message_id, reason, comment)
            
        except (PeerIdInvalid, ChannelInvalid) as e:
            logger.error(f"Target resolution failed: {type(e).__name__} - {target_entity}")
            raise
            
        except UserNotParticipant:
            logger.error(f"Bot is not participant in chat: {target_entity}")
            raise
            
        except ChatAdminRequired:
            logger.error(f"Admin rights required in: {target_entity}")
            raise
            
        except Exception as e:
            logger.error(f"Report execution failed for {target_entity}: {str(e)}")
            return False
            
        finally:
            self._active_operations -= 1
    
    def _get_reason_type(self, reason: ReportReason) -> types.ReportReason:
        """Get Telegram raw type for report reason"""
        reason_mapping = {
            ReportReason.SPAM: types.InputReportReasonSpam(),
            ReportReason.VIOLENCE: types.InputReportReasonViolence(),
            ReportReason.PORNOGRAPHY: types.InputReportReasonPornography(),
            ReportReason.CHILD_ABUSE: types.InputReportReasonChildAbuse(),
            ReportReason.ILLEGAL_DRUGS: types.InputReportReasonIllegalDrugs(),
            ReportReason.PERSONAL_DETAILS: types.InputReportReasonPersonalDetails(),
            ReportReason.ILLEGAL: types.InputReportReasonIllegal(),
            ReportReason.OTHER: types.InputReportReasonOther()
        }
        
        return reason_mapping.get(reason, types.InputReportReasonOther())
    
    @property
    def active_operations(self) -> int:
        """Get number of active report operations"""
        return self._active_operations
    
    async def execute_bulk_reports(
        self, 
        report_request: ReportRequest
    ) -> Tuple[int, int]:
        """Execute multiple reports with proper rate limiting"""
        successful = 0
        failed = 0
        
        for attempt in range(report_request.report_count):
            try:
                # Add delay between reports
                if attempt > 0:
                    await asyncio.sleep(Config.DELAY_BETWEEN_REPORTS)
                
                success = await self.execute_report(
                    report_request.target_entity,
                    report_request.message_id,
                    report_request.reason,
                    report_request.comment
                )
                
                if success:
                    successful += 1
                else:
                    failed += 1
                    
            except (PeerIdInvalid, ChannelInvalid, UserNotParticipant, ChatAdminRequired) as e:
                # Stop bulk operation on critical errors
                logger.error(f"Bulk operation stopped due to: {type(e).__name__}")
                failed += (report_request.report_count - attempt)
                break
                
            except Exception as e:
                logger.error(f"Unexpected error in bulk report {attempt + 1}: {str(e)}")
                failed += 1
                continue
        
        return successful, failed