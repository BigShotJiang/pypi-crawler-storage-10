# core/validator.py
import re
from typing import List, Tuple, Optional
from .models import ReportReason
from .config import Config

class InputValidator:
    """Class for validating and parsing user input"""
    
    @staticmethod
    def validate_command_length(parts: List[str], min_length: int) -> bool:
        """Validate minimum command parts length"""
        return len(parts) >= min_length
    
    @staticmethod
    def parse_message_id(message_id_str: str) -> Tuple[bool, Optional[int]]:
        """Parse and validate message ID"""
        try:
            message_id = int(message_id_str)
            if message_id > 0:
                return True, message_id
            return False, None
        except (ValueError, TypeError):
            return False, None
    
    @staticmethod
    def parse_report_count(count_str: str) -> Tuple[bool, Optional[int]]:
        """Parse and validate report count"""
        try:
            count = int(count_str)
            if 1 <= count <= Config.MAX_REPORTS_PER_REQUEST:
                return True, count
            return False, None
        except (ValueError, TypeError):
            return False, None
    
    @staticmethod
    def extract_comment(parts: List[str], start_index: int) -> str:
        """Extract and validate comment from command parts"""
        if start_index >= len(parts):
            return ""
        
        comment = " ".join(parts[start_index:])
        # Trim comment length if too long
        if len(comment) > Config.MAX_COMMENT_LENGTH:
            comment = comment[:Config.MAX_COMMENT_LENGTH] + "..."
        
        return comment.strip()
    
    @staticmethod
    def sanitize_entity(entity: str) -> str:
        """Sanitize entity name/URL"""
        if not entity:
            return ""
        
        # Remove protocol and @ symbol
        sanitized = re.sub(r'^(https?://t\.me/|@)', '', entity).strip()
        
        # Remove any extra spaces and invalid characters
        sanitized = re.sub(r'[^\w@]', '', sanitized)
        
        return sanitized
    
    @staticmethod
    def validate_entity(entity: str) -> bool:
        """Validate entity format"""
        if not entity:
            return False
        
        sanitized = InputValidator.sanitize_entity(entity)
        return len(sanitized) > 0 and len(sanitized) <= 32
    
    @classmethod
    def validate_report_request(cls, command_parts: List[str]) -> Tuple[bool, Optional[str]]:
        """Comprehensive validation of report request"""
        if not cls.validate_command_length(command_parts, 4):
            return False, "فرمت دستور نادرست است"
        
        target_entity = command_parts[1]
        if not cls.validate_entity(target_entity):
            return False, "لینک هدف نامعتبر است"
        
        is_valid_msg_id, message_id = cls.parse_message_id(command_parts[2])
        if not is_valid_msg_id:
            return False, "آی‌دی پیام باید یک عدد مثبت باشد"
        
        return True, None