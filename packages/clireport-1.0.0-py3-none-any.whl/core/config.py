# core/config.py
import os
from typing import List

class Config:
    """Configuration class for the report bot"""
    
    # Admin IDs
    ADMIN_IDS: List[int] = [123, 456]  # Replace with actual admin IDs
    
    # Report limits
    MAX_REPORTS_PER_REQUEST: int = 10
    DELAY_BETWEEN_REPORTS: int = 2
    
    # Session settings
    SESSION_NAME: str = "report_bot"
    API_ID: int = int(os.getenv("API_ID", 0))
    API_HASH: str = os.getenv("API_HASH", "")
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # Security
    MAX_COMMENT_LENGTH: int = 200
    REQUEST_TIMEOUT: int = 30