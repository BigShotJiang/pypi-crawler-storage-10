# core/models.py
from enum import Enum
from dataclasses import dataclass
from typing import Optional
from datetime import datetime

class ReportReason(Enum):
    """Enumeration of all available report reasons"""
    SPAM = "spam"
    VIOLENCE = "violence"
    PORNOGRAPHY = "porn"
    CHILD_ABUSE = "child_abuse"
    ILLEGAL_DRUGS = "drugs"
    PERSONAL_DETAILS = "personal"
    ILLEGAL = "illegal"
    OTHER = "other"

@dataclass
class ReportRequest:
    """Data class for report request"""
    target_entity: str
    message_id: int
    reason: ReportReason
    report_count: int = 1
    comment: str = ""
    user_id: int = 0

@dataclass
class ReportResult:
    """Data class for report operation result"""
    successful: int
    failed: int
    target: str
    message_id: int
    reason: ReportReason
    comment: str
    start_time: datetime
    end_time: datetime
    
    @property
    def duration(self) -> float:
        """Calculate operation duration"""
        return (self.end_time - self.start_time).total_seconds()