# handlers/command_handlers.py
from pyrogram import Client
from pyrogram.types import Message

from managers.response_builder import ResponseBuilder
from managers.report_manager import ReportManager

async def show_help(client: Client, message: Message):
    """Show help when only /report is sent"""
    help_text = ResponseBuilder.build_help_text()
    await message.reply_text(help_text)

async def show_reasons(client: Client, message: Message):
    """Show available report reasons"""
    reasons_text = ResponseBuilder.build_reasons_text()
    await message.reply_text(reasons_text)

async def show_stats(client: Client, message: Message):
    """Show bot statistics"""
    stats_text = ResponseBuilder.build_stats_text()
    await message.reply_text(stats_text)