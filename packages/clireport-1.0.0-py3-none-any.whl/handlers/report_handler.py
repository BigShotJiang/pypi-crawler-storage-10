# handlers/report_handler.py
import logging
from datetime import datetime
from pyrogram import Client
from pyrogram.types import Message

from core.config import Config
from core.models import ReportReason, ReportRequest, ReportResult
from core.validator import InputValidator
from core.executor import ReportExecutor
from managers.report_manager import ReportManager
from managers.response_builder import ResponseBuilder

logger = logging.getLogger(__name__)

async def handle_report_command(client: Client, message: Message):
    """Main report command handler"""
    start_time = datetime.now()
    executor = ReportExecutor(client)
    validator = InputValidator()
    
    try:
        # Initial response
        processing_msg = await message.reply(
            ResponseBuilder.build_success_text("operation_started")
        )
        
        # Parse command
        command_parts = message.text.split()
        
        # Validate basic command structure
        is_valid, error_msg = validator.validate_report_request(command_parts)
        if not is_valid:
            await processing_msg.edit_text(
                ResponseBuilder.build_error_text("invalid_command", error_msg)
            )
            return
        
        # Extract parameters
        target_entity = validator.sanitize_entity(command_parts[1])
        
        # Validate message ID
        is_valid_msg_id, message_id = validator.parse_message_id(command_parts[2])
        if not is_valid_msg_id:
            await processing_msg.edit_text(
                ResponseBuilder.build_error_text("invalid_message_id")
            )
            return
        
        # Validate report reason
        report_reason = ReportManager.get_reason_from_string(command_parts[3])
        if not report_reason:
            await processing_msg.edit_text(
                ResponseBuilder.build_error_text("invalid_reason")
            )
            return
        
        # Parse optional parameters
        report_count = 1
        comment = ""
        
        if len(command_parts) > 4:
            # Try to parse report count
            is_valid_count, count = validator.parse_report_count(command_parts[4])
            if is_valid_count:
                report_count = count
                comment = validator.extract_comment(command_parts, 5)
            else:
                comment = validator.extract_comment(command_parts, 4)
        
        # Create report request
        report_request = ReportRequest(
            target_entity=target_entity,
            message_id=message_id,
            reason=report_reason,
            report_count=report_count,
            comment=comment,
            user_id=message.from_user.id
        )
        
        # Update status with details
        await processing_msg.edit_text(
            f"🔍 **در حال پردازش درخواست...**\n\n"
            f"• هدف: `{target_entity}`\n"
            f"• پیام: `{message_id}`\n"
            f"• دلیل: `{ReportManager.get_persian_name(report_reason)}`\n"
            f"• تعداد: `{report_count}`\n"
            f"• کامنت: `{comment if comment else 'ندارد'}`"
        )
        
        # Execute bulk reports
        successful_reports, failed_reports = await executor.execute_bulk_reports(report_request)
        
        # Create result object
        end_time = datetime.now()
        report_result = ReportResult(
            successful=successful_reports,
            failed=failed_reports,
            target=target_entity,
            message_id=message_id,
            reason=report_reason,
            comment=comment,
            start_time=start_time,
            end_time=end_time
        )
        
        # Update statistics
        ReportManager.update_stats(
            successful=successful_reports,
            failed=failed_reports
        )
        
        # Send final summary
        summary_text = ResponseBuilder.build_summary_text(report_result)
        await processing_msg.edit_text(summary_text)
        
        logger.info(
            f"Report operation completed for user {message.from_user.id}: "
            f"{successful_reports} successful, {failed_reports} failed"
        )
        
    except Exception as e:
        logger.error(f"Critical error in report handler: {str(e)}")
        error_msg = ResponseBuilder.build_error_text("unknown_error", str(e))
        
        try:
            await processing_msg.edit_text(error_msg)
        except:
            await message.reply_text(error_msg)