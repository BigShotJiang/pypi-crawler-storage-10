# managers/report_manager.py
import logging
from datetime import datetime
from typing import Dict, Optional
from core.models import ReportReason
from data.constants import PERSIAN_NAMES

logger = logging.getLogger(__name__)

class ReportManager:
    """Manager class for handling report operations"""
    
    _instance = None
    _report_stats: Dict[str, int] = {
        'total_reports': 0,
        'successful_reports': 0,
        'failed_reports': 0,
        'flood_waits': 0
    }
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ReportManager, cls).__new__(cls)
        return cls._instance
    
    @classmethod
    def get_reason_from_string(cls, reason_str: str) -> Optional[ReportReason]:
        """Get ReportReason enum from string"""
        try:
            for reason in ReportReason:
                if reason_str.lower() == reason.value:
                    return reason
        except (AttributeError, TypeError):
            pass
        return None
    
    @classmethod
    def get_persian_name(cls, reason: ReportReason) -> str:
        """Get Persian name for report reason"""
        return PERSIAN_NAMES.get(reason, "نامشخص")
    
    @classmethod
    def update_stats(cls, successful: int = 0, failed: int = 0, flood_waits: int = 0):
        """Update report statistics"""
        cls._report_stats['total_reports'] += (successful + failed)
        cls._report_stats['successful_reports'] += successful
        cls._report_stats['failed_reports'] += failed
        cls._report_stats['flood_waits'] += flood_waits
    
    @classmethod
    def get_stats(cls) -> Dict[str, int]:
        """Get current statistics"""
        return cls._report_stats.copy()
    
    @classmethod
    def format_duration(cls, start_time: datetime, end_time: datetime) -> str:
        """Format duration between two timestamps"""
        duration = (end_time - start_time).total_seconds()
        
        if duration < 60:
            return f"{duration:.2f} ثانیه"
        elif duration < 3600:
            minutes = int(duration // 60)
            seconds = duration % 60
            return f"{minutes} دقیقه و {seconds:.2f} ثانیه"
        else:
            hours = int(duration // 3600)
            minutes = int((duration % 3600) // 60)
            return f"{hours} ساعت و {minutes} دقیقه"
    
    @classmethod
    def validate_reason_availability(cls, reason: ReportReason) -> bool:
        """Validate if report reason is available"""
        return reason in ReportReason
    
    @classmethod
    def get_all_reasons(cls) -> Dict[str, str]:
        """Get all available reasons with their Persian names"""
        return {reason.value: cls.get_persian_name(reason) for reason in ReportReason}