# managers/response_builder.py
from datetime import datetime
from typing import Dict
from core.models import ReportReason, ReportResult
from core.config import Config
from managers.report_manager import ReportManager

class ResponseBuilder:
    """Class for building formatted responses"""
    
    @staticmethod
    def build_help_text() -> str:
        """Build comprehensive help text"""
        from data.constants import HELP_TEXT
        return HELP_TEXT
    
    @staticmethod
    def build_reasons_text() -> str:
        """Build detailed reasons list"""
        from data.constants import REASONS_TEXT
        return REASONS_TEXT
    
    @staticmethod
    def build_summary_text(result: ReportResult) -> str:
        """Build operation summary text"""
        duration_str = ReportManager.format_duration(result.start_time, result.end_time)
        
        summary = (
            "📊 **گزارش عملیات گزارش‌دهی**\n\n"
            f"✅ **گزارش‌های موفق:** `{result.successful}`\n"
            f"❌ **گزارش‌های ناموفق:** `{result.failed}`\n"
            f"⏱️ **زمان اجرا:** `{duration_str}`\n"
            f"📈 **کارایی:** `{(result.successful / (result.successful + result.failed) * 100):.1f}%`\n\n"
            f"🎯 **هدف:** `{result.target}`\n"
            f"📨 **پیام:** `{result.message_id}`\n"
            f"🚩 **دلیل:** {ReportManager.get_persian_name(result.reason)}\n"
            f"💬 **کامنت:** {result.comment if result.comment else '❌ بدون کامنت'}\n\n"
            f"🕒 **زمان پایان:** {result.end_time.strftime('%Y-%m-%d %H:%M:%S')}"
        )
        
        return summary
    
    @staticmethod
    def build_progress_text(
        current: int, 
        total: int, 
        successful: int, 
        failed: int,
        target: str
    ) -> str:
        """Build progress update text"""
        percentage = (current / total) * 100 if total > 0 else 0
        
        progress_bar = "█" * int(percentage / 10) + "░" * (10 - int(percentage / 10))
        
        progress_text = (
            f"📤 **در حال ارسال گزارش‌ها...**\n\n"
            f"`[{progress_bar}] {percentage:.1f}%`\n\n"
            f"• **پیشرفت:** `{current}/{total}`\n"
            f"• **موفق:** `{successful}` | **ناموفق:** `{failed}`\n"
            f"• **هدف:** `{target}`\n"
            f"⏳ لطفاً منتظر بمانید..."
        )
        
        return progress_text
    
    @staticmethod
    def build_stats_text() -> str:
        """Build statistics text"""
        stats = ReportManager.get_stats()
        
        success_rate = (stats['successful_reports'] / stats['total_reports'] * 100) if stats['total_reports'] > 0 else 0
        
        stats_text = (
            "📈 **آمار سیستم گزارش‌دهی**\n\n"
            f"📊 **آمار کلی:**\n"
            f"• کل گزارش‌ها: `{stats['total_reports']}`\n"
            f"• گزارش‌های موفق: `{stats['successful_reports']}`\n"
            f"• گزارش‌های ناموفق: `{stats['failed_reports']}`\n"
            f"• FloodWait ها: `{stats['flood_waits']}`\n"
            f"• نرخ موفقیت: `{success_rate:.1f}%`\n\n"
            f"⚙️ **تنظیمات سیستم:**\n"
            f"• حداکثر گزارش درخواست: `{Config.MAX_REPORTS_PER_REQUEST}`\n"
            f"• تاخیر بین گزارش‌ها: `{Config.DELAY_BETWEEN_REPORTS}` ثانیه\n"
            f"• ادمین‌های مجاز: `{len(Config.ADMIN_IDS)}` کاربر\n\n"
            f"🛠 **دستورات موجود:**\n"
            "• `/report` - راهنمای کامل\n"
            "• `/reasons` - لیست دلایل\n"
            "• `/report_stats` - این صفحه"
        )
        
        return stats_text
    
    @staticmethod
    def build_error_text(error_type: str, details: str = "") -> str:
        """Build error response text"""
        error_templates = {
            "invalid_command": "❌ **خطا در فرمت دستور**\n\nلطفاً از فرمت صحیح استفاده کنید:\n`/report لینک آی‌دی دلیل [تعداد] [کامنت]`",
            "invalid_entity": "❌ **لینک هدف نامعتبر**\n\nلطفاً یک لینک معتبر کاربر، کانال یا گروه وارد کنید.",
            "invalid_message_id": "❌ **آی‌دی پیام نامعتبر**\n\nآی‌دی پیام باید یک عدد مثبت باشد.",
            "invalid_reason": "❌ **دلیل گزارش نامعتبر**\n\nلطفاً یکی از دلایل معتبر را انتخاب کنید.",
            "invalid_count": f"❌ **تعداد گزارش نامعتبر**\n\nتعداد باید بین ۱ تا {Config.MAX_REPORTS_PER_REQUEST} باشد.",
            "rate_limit": "⏳ **محدودیت نرخ**\n\nلطفاً چند لحظه صبر کنید و دوباره تلاش کنید.",
            "access_denied": "🚫 **دسترسی denied**\n\nشما دسترسی لازم برای این عملیات را ندارید.",
            "target_not_found": "❌ **هدف یافت نشد**\n\nکاربر، کانال یا گروه مورد نظر یافت نشد.",
            "unknown_error": "❌ **خطای ناشناخته**\n\nخطایی در اجرای دستور رخ داد."
        }
        
        base_error = error_templates.get(error_type, error_templates["unknown_error"])
        
        if details:
            return f"{base_error}\n\n**جزئیات:** {details}"
        
        return base_error
    
    @staticmethod
    def build_success_text(operation: str, details: str = "") -> str:
        """Build success response text"""
        success_templates = {
            "operation_started": "🔄 **عملیات آغاز شد**\n\nدر حال پردازش درخواست شما...",
            "operation_completed": "✅ **عملیات با موفقیت انجام شد**",
            "settings_updated": "⚙️ **تنظیمات به‌روزرسانی شد**",
            "access_granted": "🔓 **دسترسی اعطا شد**"
        }
        
        base_success = success_templates.get(operation, "✅ **عملیات با موفقیت انجام شد**")
        
        if details:
            return f"{base_success}\n\n**جزئیات:** {details}"
        
        return base_success