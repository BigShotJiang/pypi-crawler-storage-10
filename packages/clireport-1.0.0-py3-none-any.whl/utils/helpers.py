# utils/helpers.py
import re
from typing import Optional
from core.config import Config

def format_entity(entity: str) -> Optional[str]:
    """Format entity for display"""
    if not entity:
        return None
    
    # Remove protocol and clean up
    formatted = re.sub(r'^(https?://t\.me/|@)', '', entity)
    
    # Add @ if it's a username
    if not formatted.startswith('@') and not formatted.startswith('+'):
        formatted = f"@{formatted}"
    
    return formatted

def validate_user_access(user_id: int) -> bool:
    """Validate if user has access to bot"""
    return user_id in Config.ADMIN_IDS

def parse_command_args(text: str) -> list:
    """Parse command arguments with proper handling"""
    if not text:
        return []
    
    # Split by spaces but preserve quoted text
    parts = []
    current_part = ""
    in_quotes = False
    
    for char in text:
        if char == '"':
            in_quotes = not in_quotes
        elif char == ' ' and not in_quotes:
            if current_part:
                parts.append(current_part)
                current_part = ""
        else:
            current_part += char
    
    if current_part:
        parts.append(current_part)
    
    return parts

def truncate_text(text: str, max_length: int) -> str:
    """Truncate text to maximum length"""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."