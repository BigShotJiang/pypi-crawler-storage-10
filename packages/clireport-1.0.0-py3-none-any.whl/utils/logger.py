# utils/logger.py
import logging
import sys
from core.config import Config

def setup_logging():
    """Setup comprehensive logging configuration"""
    
    # Create formatter
    formatter = logging.Formatter(Config.LOG_FORMAT)
    
    # Create file handler
    file_handler = logging.FileHandler('report_bot.log', encoding='utf-8')
    file_handler.setFormatter(formatter)
    
    # Create stream handler
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, Config.LOG_LEVEL))
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Add handlers
    root_logger.addHandler(file_handler)
    root_logger.addHandler(stream_handler)
    
    # Set specific log levels for libraries
    logging.getLogger('pyrogram').setLevel(logging.WARNING)
    logging.getLogger('httpx').setLevel(logging.WARNING)