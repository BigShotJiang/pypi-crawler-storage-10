from._logger import logger
from sixgill.definitions import ModelComponents,Parameters
def set_operating_glv_parameters(self,gl_rate,gl_depth):
	B='GLV';A=self
	try:
		A.gl_depth=gl_depth;A.gl_rate=gl_rate/1000000
		try:A.model.set_value(context=B,parameter=Parameters.GasLiftInjection.TOPMEASUREDDEPTH,value=A.gl_depth);A.model.set_value(context=B,parameter=Parameters.GasLiftInjection.GASRATE,value=A.gl_rate)
		except:A.model.add(ModelComponents.GASLIFTINJECTION,B,context='main_well',parameters={Parameters.GasLiftInjection.TOPMEASUREDDEPTH:A.gl_depth,Parameters.GasLiftInjection.GASRATE:A.gl_rate})
		A.model.save();logger.info('Gas lift system activated.')
	except Exception as C:logger.error(f"Unable to add gas lift to the model. Error: {C}")