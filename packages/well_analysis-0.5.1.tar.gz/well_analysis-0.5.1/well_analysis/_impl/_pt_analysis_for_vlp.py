E=None
D=print
from._logger import logger
from sixgill.definitions import SystemVariables,ProfileVariables,Parameters,Constants
import pandas as O
def _pt_analysis_for_vlp(self,parameters=E,profile_variables=E):
	N='Property: {}';M='Message: {}';L='Path: {}';K='Issue {}';J='main_well';I=profile_variables;H=parameters;A=self
	try:
		A.system_variables=[SystemVariables.PRESSURE,SystemVariables.TEMPERATURE,SystemVariables.VOLUME_FLOWRATE_LIQUID_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_WATER_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.GOR_STOCKTANK,SystemVariables.WATER_CUT_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.WATER_CUT_INSITU,SystemVariables.WELLHEAD_VOLUME_FLOWRATE_FLUID_INSITU,SystemVariables.OUTLET_VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.OUTLET_VOLUME_FLOWRATE_OIL_STOCKTANK,SystemVariables.OUTLET_VOLUME_FLOWRATE_WATER_STOCKTANK,SystemVariables.SYSTEM_OUTLET_TEMPERATURE,SystemVariables.BOTTOM_HOLE_PRESSURE,SystemVariables.OUTLET_GLR_STOCKTANK,SystemVariables.OUTLET_WATER_CUT_STOCKTANK]
		if I is E:A.profile_variables=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE]
		else:A.profile_variables=I
		if H is E:A.parameters={Parameters.PTProfileSimulation.OUTLETPRESSURE:A.thp,Parameters.PTProfileSimulation.GASFLOWRATE:A.q_gas/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.INLETPRESSURE}
		else:A.parameters=H
		P=A.model.tasks.ptprofilesimulation.run(producer=J,parameters=A.parameters,system_variables=A.system_variables,profile_variables=A.profile_variables);F=A.model.tasks.ptprofilesimulation.validate(producer=J);C=1
		for B in F:D(K.format(C));D(L.format(B.path));D(M.format(B.message));D(N.format(B.property_name));C=C+1
		for(S,Q)in P.profile.items():G=O.DataFrame.from_dict(Q)
		return G.loc[G['BranchEquipment']=='Tub1','Pressure'].values[0],G
	except Exception as R:
		logger.error(f"Trying to run PT-analysis at unfeasible parameters. Error: {R}, Issues: {F}")
		for B in F:logger.error(K.format(C));logger.error(L.format(B.path));logger.error(M.format(B.message));logger.error(N.format(B.property_name));C=C+1