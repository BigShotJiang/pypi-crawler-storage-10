C=None
from._logger import logger
from sixgill.definitions import SystemVariables,ProfileVariables,Parameters,Constants
import pandas as b,os
from openpyxl import load_workbook
def perform_pt_analysis(self,study_name=C,thp=C,reservoir_pressure=C,q_gas=C,q_oil=C,q_water=C,api=C,gg=C,gl_depth=C,gl_rate=C):
	f=False;e='openpyxl';d='wellfluid';c=gl_depth;a='GLV';W=gl_rate;V=reservoir_pressure;U=study_name;R=gg;Q=api;P=q_water;L=q_gas;K=q_oil;J=thp;I='LiquidLoadingGasRate';H='VolumeFlowrateGasStockTank';G='Pressure';F=True;A=self
	try:
		if c is not C:A.model.set_value(context=a,parameter=Parameters.GasLiftInjection.TOPMEASUREDDEPTH,value=c)
		if W is not C:
			if W<=0:A.model.set_value(context=a,parameter=Parameters.GasLiftInjection.GASRATE,value=1/1000000)
			else:A.model.set_value(context=a,parameter=Parameters.GasLiftInjection.GASRATE,value=W/1000000)
		g=[L,K,P,Q,R];X=J is C;Y=all(A is C for A in g);h=L is C;i=K is C
		if Q is C:Q=A.api
		if R is C:R=A.gg
		if V is not C and J is not C:
			if A.gas_well==F:D={Parameters.PTProfileSimulation.INLETPRESSURE:V,Parameters.PTProfileSimulation.OUTLETPRESSURE:J,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.FLOWRATE}
			else:D={Parameters.PTProfileSimulation.INLETPRESSURE:V,Parameters.PTProfileSimulation.OUTLETPRESSURE:J,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.LIQUIDFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.FLOWRATE}
			E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		elif Y:
			D={Parameters.PTProfileSimulation.OUTLETPRESSURE:J,Parameters.PTProfileSimulation.GASFLOWRATE:A.q_gas/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.INLETPRESSURE};E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		elif X:
			N=L/K;O=P/(P+K)*100;A.model.set_values(context=d,dict={Parameters.BlackOilFluid.GOR:N,Parameters.BlackOilFluid.WATERCUT:O,Parameters.BlackOilFluid.API:Q,Parameters.BlackOilFluid.GASSPECIFICGRAVITY:R});E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			D=D={Parameters.PTProfileSimulation.INLETPRESSURE:A.reservoir_pressure,Parameters.PTProfileSimulation.GASFLOWRATE:A.q_gas/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.OUTLETPRESSURE};M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		elif X and Y:M,B=A._pt_analysis_for_vlp()
		elif not X and not Y:
			try:O=P/(P+K)*100
			except:O=A.wc
			try:N=L/K
			except:N=A.gor
			A.model.set_values(context=d,dict={Parameters.BlackOilFluid.GOR:N,Parameters.BlackOilFluid.WATERCUT:O,Parameters.BlackOilFluid.API:Q,Parameters.BlackOilFluid.GASSPECIFICGRAVITY:R});E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			try:D=D={Parameters.PTProfileSimulation.OUTLETPRESSURE:J,Parameters.PTProfileSimulation.GASFLOWRATE:L/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.INLETPRESSURE}
			except:D=D={Parameters.PTProfileSimulation.OUTLETPRESSURE:J,Parameters.PTProfileSimulation.GASFLOWRATE:A.q_gas/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.INLETPRESSURE}
			M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		elif not h:
			if J is C:J=A.thp
			N=A.gor;O=A.wc;E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			D=D={Parameters.PTProfileSimulation.INLETPRESSURE:A.reservoir_pressure,Parameters.PTProfileSimulation.GASFLOWRATE:L/1000000,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.GASFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.OUTLETPRESSURE};M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		elif not i:
			if J is C:J=A.thp
			N=A.gor;O=A.wc;j=K/A.q_oil*(A.q_oil+A.q_water);E=[ProfileVariables.TEMPERATURE,ProfileVariables.PRESSURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,ProfileVariables.VOLUME_FLOWRATE_WATER_STOCKTANK]
			if A.gas_well==F:E.append(ProfileVariables.LIQUID_LOADING_GAS_RATE)
			D=D={Parameters.PTProfileSimulation.INLETPRESSURE:A.reservoir_pressure,Parameters.PTProfileSimulation.LIQUIDFLOWRATE:j,Parameters.PTProfileSimulation.FLOWRATETYPE:Constants.FlowRateType.LIQUIDFLOWRATE,Parameters.PTProfileSimulation.CALCULATEDVARIABLE:Constants.CalculatedVariable.OUTLETPRESSURE};M,B=A._pt_analysis_for_vlp(parameters=D,profile_variables=E);B[G]=(B[G]-1.01325)/.980665;B[H]=B[H]*1000000
			if A.gas_well==F:B[I]=B[I]*1000000
		logger.info(f"PT analysis completed");os.makedirs('./pipesim-results',exist_ok=F);S=f"./pipesim-results/{A.well_name}-PT-analysis-report.xlsx"
		if U!='internal-use':
			if U is C:U='Study-1'
			T=U
			if os.path.exists(S):
				while T in list(load_workbook(S).sheetnames):T+='-new'
				with b.ExcelWriter(S,mode='a',engine=e,if_sheet_exists='new')as Z:B.to_excel(Z,sheet_name=T,index=f)
			else:
				with b.ExcelWriter(S,engine=e)as Z:B.to_excel(Z,sheet_name=T,index=f)
			logger.info(f"PT analysis outputs have been written to sheet '{T}' in {S}")
		return B
	except Exception as k:logger.error(f"PT analysis failed. Error:{k}")