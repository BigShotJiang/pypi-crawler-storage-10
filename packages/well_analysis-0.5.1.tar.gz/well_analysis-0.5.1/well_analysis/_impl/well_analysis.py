H=Exception
E=str
A=None
from sixgill.pipesim import Model,Units
from sixgill.definitions import ModelComponents,Parameters,Constants,SystemVariables,ProfileVariables
import pandas as B,os
from._plot_utility import NA_plot
from._logger import logger
from._add_black_oil import add_black_oil
from._create_ipr import create_ipr
from._find_operating_glv_depth import find_operating_glv_depth
from._pt_analysis_for_vlp import _pt_analysis_for_vlp
from._ipr_vlp_matching import ipr_vlp_matching
from._perform_pt_analysis import perform_pt_analysis
from._plot_operating_point import plot_operating_point
from._set_operating_glv_parameters import set_operating_glv_parameters
from._install_new_glv import install_new_glv
from._perform_sensitivity import perform_sensitivity
from._open_model import open_model
class WELL_ANALYSIS:
	def __init__(B,well_name,tubing_dia=A,perforation_depth=A,packer_depth=A,well_trajectory=A,tubing_shoe_depth=A,casing_dia=6.18,casing_shoe_depth=A,existing_model_directory=A):
		Q='Tub1';P='Csg1';O=existing_model_directory;N=casing_shoe_depth;M=casing_dia;L=tubing_shoe_depth;K=well_trajectory;J=packer_depth;I=tubing_dia;F=well_name;D=perforation_depth;C='main_well'
		try:
			B.existing_model_directory=O
			if B.existing_model_directory is not A:
				try:
					logger.debug(f"Existing directory path: {O}.");logger.debug(f"CWD: {os.getcwd()}.")
					if B.existing_model_directory=='':B.model=Model.open(E(f"{F}.pips"))
					else:B.model=Model.open(E(B.existing_model_directory)+E(f"/{F}.pips"))
					logger.info(f"Using existing model")
				except H as G:logger.error(f"Incorrect model directory. Provide the correct path for model directory. Error: {G}")
			else:
				B.well_name=F;B.perforation_depth=D
				if J is A:B.packer_depth=D-100
				else:B.packer_depth=J
				B.model=Model.new(f"{B.well_name}.pips",units=Units.METRIC,overwrite=True)
				if K is not A:B.model.add(ModelComponents.WELL,C,parameters={Parameters.Well.AMBIENTTEMPERATURE:30,Parameters.Well.DeviationSurvey.SURVEYTYPE:'TwoDimensional'});B.model.set_trajectory(C,value=K)
				else:B.model.add(ModelComponents.WELL,C,parameters={Parameters.Well.AMBIENTTEMPERATURE:30,Parameters.Well.DeviationSurvey.SURVEYTYPE:'VerticalDeviation'})
				if N is A:B.model.add(ModelComponents.CASING,P,context=C,parameters={Parameters.Casing.TOPMEASUREDDEPTH:0,Parameters.Casing.LENGTH:D+5,Parameters.Casing.INNERDIAMETER:M*25.4,Parameters.Casing.BOREHOLEDIAMETER:762.,Parameters.Casing.WALLTHICKNESS:12.7})
				else:B.model.add(ModelComponents.CASING,P,context=C,parameters={Parameters.Casing.TOPMEASUREDDEPTH:0,Parameters.Casing.LENGTH:N,Parameters.Casing.INNERDIAMETER:M*25.4,Parameters.Casing.BOREHOLEDIAMETER:762.,Parameters.Casing.WALLTHICKNESS:12.7})
				if L is A:B.model.add(ModelComponents.TUBING,Q,context=C,parameters={Parameters.Tubing.TOPMEASUREDDEPTH:0,Parameters.Tubing.LENGTH:D-5,Parameters.Tubing.INNERDIAMETER:I*25.4,Parameters.Tubing.WALLTHICKNESS:5.08})
				else:B.model.add(ModelComponents.TUBING,Q,context=C,parameters={Parameters.Tubing.TOPMEASUREDDEPTH:0,Parameters.Tubing.LENGTH:L,Parameters.Tubing.INNERDIAMETER:I*25.4,Parameters.Tubing.WALLTHICKNESS:5.08})
				B.model.add(ModelComponents.PACKER,'Packer',context=C,parameters={Parameters.Packer.TOPMEASUREDDEPTH:B.packer_depth});B.model.save();logger.info(f"Initial well model created and saved at {os.getcwd()}")
		except H as G:logger.error(f"Unable to create the base well model. Error: {G}")
	def set_operating_glv_parameters(A,gl_rate,gl_depth):return set_operating_glv_parameters(A,gl_rate,gl_depth)
	def add_black_oil(A,q_gas,q_oil,q_water,api,gg,gas_well=False):return add_black_oil(A,q_gas,q_oil,q_water,api,gg,gas_well)
	def create_ipr(A,reservoir_temperature,reservoir_pressure,liquid_pi,fbhp=A):return create_ipr(A,reservoir_temperature,reservoir_pressure,liquid_pi,fbhp)
	def find_operating_glv_depth(A,gas_injection_pressure,thp,existing_glvs):return find_operating_glv_depth(A,gas_injection_pressure,thp,existing_glvs)
	def _pt_analysis_for_vlp(A,parameters=A,profile_variables=A):return _pt_analysis_for_vlp(A,parameters,profile_variables)
	def ipr_vlp_matching(A,thp,fbhp):return ipr_vlp_matching(A,thp,fbhp)
	def perform_pt_analysis(A,study_name=A,thp=A,reservoir_pressure=A,q_gas=A,q_oil=A,q_water=A,api=A,gg=A,gl_depth=A,gl_rate=A):return perform_pt_analysis(A,study_name,thp,reservoir_pressure,q_gas,q_oil,q_water,api,gg,gl_depth,gl_rate)
	def plot_operating_point(A,thp=A):return plot_operating_point(A,thp)
	def install_new_glv(A,gas_injection_pressure,thp=A):return install_new_glv(A,gas_injection_pressure,thp)
	def perform_sensitivity(A,study_name=A,thp_sensitivity=A,tubing_sensitivity=A,lift_gas_sensitivity=A,watercut_sensitivity=A,GOR_sensitivity=A,reservoir_pressure_sensitivity=A,sensitivity_type='permuted'):return perform_sensitivity(A,study_name,thp_sensitivity,tubing_sensitivity,lift_gas_sensitivity,watercut_sensitivity,GOR_sensitivity,reservoir_pressure_sensitivity,sensitivity_type)
	def open_model(A,well_name,well_details):return open_model(A,well_name,well_details)