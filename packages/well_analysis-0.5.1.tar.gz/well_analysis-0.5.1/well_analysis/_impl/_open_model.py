from._logger import logger
from sixgill.pipesim import Model,Units
import json
def open_model(self,well_name,well_details):
	Q='liquid_pi';P='gas_well';O='gas_injection_pressure';N='fbhp';M='reservoir_pressure';L='gl_rate';K='gl_depth';J='api';I='q_water';H='q_oil';G='q_gas';F='thp';E='well_name';D='reservoir_temperature';C=None;B=self;A=well_details
	try:
		logger.debug(A);logger.info('Opening the well model.');B.model=Model.open('./'+str(well_name)+'.pips',Units.METRIC)
		if A[E]is not C:B.well_name=A[E]
		if A[F]is not C:B.thp=A[F]
		if A[G]is not C:B.q_gas=A[G]
		if A[H]is not C:B.q_oil=A[H]
		if A[I]is not C:B.q_water=A[I]
		if A[J]is not C:B.api=A[J]
		if A['gg']is not C:B.gg=A['gg']
		if A[K]is not C:B.gl_depth=A[K]
		if A[L]is not C:B.gl_rate=A[L]
		if A[M]is not C:B.reservoir_pressure=A[M]
		if A[D]is not C:B.reservoir_temperature=A[D]
		if A[D]is not C:B.reservoir_temperature=A[D]
		if A[N]is not C:B.fbhp=A[N]
		if A[O]is not C:B.gas_injection_pressure=A[O]
		if A[P]is not C:B.gas_well=A[P]
		if A[Q]is not C:B.liquid_pi=A[Q]
		logger.debug(B.api);return B
	except Exception as R:logger.error(f"Unable to open the well model. Error: {R}")