F=float
from._logger import logger
from sixgill.definitions import ModelComponents,Parameters,Constants
from sixgill.definitions import Parameters,SystemVariables,ProfileVariables,Constants
import pandas as A,numpy as H
from scipy.interpolate import interp1d
import math
def z_factor(sg_gas,p,t,A=0,B=0):C=sg_gas;I=709.6-58.7*C;D=170.5+307.3*C;E=120*(A**.9-A**1.6)+15*(B**.5-B**4);F=D-E;J=I*(F/(D+B*(1-B)*E));G=p/J;H=(t+460)/F;K=1-3.52*G/10**(.9813*H)+.274*G**2/10**(.8157*H);return K
def gas_annulus_pressure(depth,surface_pressure,sg_gas,t1,t2):
	C=sg_gas;B=depth;D=200;G=H.linspace(0,B,D);A=[surface_pressure]
	for I in G:
		E=((t2-t1)/B*I+2*t1)/2+460
		if len(A)<2:F=A[-1]
		else:F=(A[-1]+A[-2])/2
		J=z_factor(C,F,E);K=.01877*C*B/D/J/E;A.append(A[-1]*math.e**K)
	return A
def find_operating_glv_depth(self,gas_injection_pressure,thp,existing_glvs):
	L='Elevation';K='internal-use';I=gas_injection_pressure;D=thp;A=self
	if D is not None:A.thp=D
	if A.thp>=I:logger.info('Injection not possible.')
	else:
		try:
			try:B=A.perform_pt_analysis(study_name=K,thp=A.thp,q_gas=A.q_gas,q_oil=A.q_oil,q_water=A.q_water,api=A.api,gg=A.gg,gl_depth=A.gl_depth,gl_rate=0)
			except:B=A.perform_pt_analysis(study_name=K,thp=A.thp,q_gas=A.q_gas,q_oil=A.q_oil,q_water=A.q_water,api=A.api,gg=A.gg)
			M=B.loc[B['BranchEquipment']=='Tub1','Pressure'].values[0];D=A.thp;G=B[L].min();H=gas_annulus_pressure(G,I,A.gg,50,A.reservoir_temperature);N=(M-D)/G;O=(H[-1]-H[0])/G;P=(H[0]-D)/(N-O);Q=B[L].values;J=B['TotalDistance'].values;R=interp1d(Q,J,kind='linear',fill_value='extrapolate');C=F(R(P));C=min(A.packer_depth-50,max(J)-C-50);E=[F(A)for A in existing_glvs if F(A)<C]
			if len(E)>0:E=sorted(E);C=E[-1]
			else:logger.info('All GLVs are set at lower depth than deepest injection point.')
			logger.info(f"Operating GLV is at depth: {C:.2f} m and not set as operating GLV. Use `set_operating_glv_parameters` to set this valve as operating GLV.");return C
		except Exception as S:logger.error(f"Gas injection not possible. Error: {S}")