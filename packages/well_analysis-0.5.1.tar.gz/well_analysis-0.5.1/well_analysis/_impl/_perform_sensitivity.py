d='permuted'
U=print
T=range
D=round
Q=len
P=int
O=str
H=list
F=float
B=None
from._logger import logger
from sixgill.definitions import ModelComponents,Parameters,Constants
import pandas as M
from sixgill.pipesim import Model
from sixgill.definitions import Parameters,SystemVariables,ProfileVariables,Constants
import tempfile
from typing import Optional
from sixgill.simulation_result import SimulationResult
import re,pandas as M
from openpyxl import load_workbook
import os
def convert_units(text):
	E=text
	if not isinstance(E,O):return E
	A=E;H=re.search('POUT\\s*=\\s*([\\d.]+)\\s*psia',A)
	if H:B=F(H.group(1));C=P(D(B/14.2233-1.01325));A=re.sub('POUT\\s*=\\s*[\\d.]+\\s*psia',f"POUT={C} ksc",A)
	I=re.search('PWSTATIC\\s*=\\s*([\\d.]+)\\s*psia',A)
	if I:B=F(I.group(1));C=P(D(B/14.2233-1.01325));A=re.sub('PWSTATIC\\s*=\\s*[\\d.]+\\s*psia',f"PWSTATIC={C} ksc",A)
	J=re.search('Flowrate\\s*=\\s*([\\d.]+)\\s*sbbl/day',A)
	if J:B=F(J.group(1));C=B/6.29;A=re.sub('Flowrate\\s*=\\s*[\\d.]+\\s*sbbl/day',f"Flowrate={C:.1f} sm3/d",A)
	K=re.search('INJGAS\\s*=\\s*([\\d.]+)\\s*mmscfd',A)
	if K:B=F(K.group(1));C=P(D(B*28317));A=re.sub('INJGAS\\s*=\\s*[\\d.]+\\s*mmscfd',f"INJGAS={C} SCMD",A)
	G=re.search('(GOR|GLR)\\s*=\\s*([\\d.]+)\\s*scf/sbbl',A)
	if G:L=G.group(1);B=F(G.group(2));C=P(D(B*6.29/35.3147));A=re.sub(rf"{L}\s*=\s*[\d.]+\s*scf/sbbl",f"{L}={C} m3/m3",A)
	return A
def perform_sensitivity(self,study_name=B,thp_sensitivity=B,tubing_sensitivity=B,lift_gas_sensitivity=B,watercut_sensitivity=B,GOR_sensitivity=B,reservoir_pressure_sensitivity=B,sensitivity_type=d):
	i='openpyxl';h='main_well';f=GOR_sensitivity;e=watercut_sensitivity;c=True;b='VertComp1';W=sensitivity_type;V=study_name;L=reservoir_pressure_sensitivity;K=lift_gas_sensitivity;J=tubing_sensitivity;I=thp_sensitivity;G=self
	try:
		D=[]
		if I is not B:
			I=H(I)
			for C in T(Q(I)):I[C]=I[C]*.98066+1.01325
			D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:'System Data',Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.SystemAnalysisSimulation.OUTLETPRESSURE,Parameters.SystemAnalysisSimulation.SensitivityVariable.VALUES:I})
		if J is not B:
			J=H(J)
			for C in T(Q(J)):J[C]=J[C]*25.4
			D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:'Tub1',Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.Tubing.INNERDIAMETER,Parameters.WellPerformanceCurvesSimulation.SensitivityVariable.VALUES:J})
		if K is not B:
			K=H(K)
			for C in T(Q(K)):K[C]=K[C]/1000000
			D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:'GLV',Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.GasLiftInjection.GASRATE,Parameters.SystemAnalysisSimulation.SensitivityVariable.VALUES:H(K)})
		if e is not B:D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:b,Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.Completion.WATERCUT,Parameters.SystemAnalysisSimulation.SensitivityVariable.VALUES:H(e)})
		if f is not B:D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:b,Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.Completion.GOR,Parameters.SystemAnalysisSimulation.SensitivityVariable.VALUES:H(f)})
		if L is not B:
			L=H(L)
			for C in T(Q(L)):L[C]=L[C]*.98066+1.01325
			D.append({Parameters.SystemAnalysisSimulation.SensitivityVariable.COMPONENT:b,Parameters.SystemAnalysisSimulation.SensitivityVariable.VARIABLE:Parameters.Completion.RESERVOIRPRESSURE,Parameters.SystemAnalysisSimulation.SensitivityVariable.VALUES:L})
		if Q(D)==0:logger.info('No sensitivity parameter selected.');return
		j=[SystemVariables.PRESSURE,SystemVariables.TEMPERATURE,SystemVariables.VOLUME_FLOWRATE_LIQUID_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_OIL_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_WATER_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.GOR_STOCKTANK,SystemVariables.WATER_CUT_STOCKTANK,SystemVariables.VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.WATER_CUT_INSITU,SystemVariables.WELLHEAD_VOLUME_FLOWRATE_FLUID_INSITU,SystemVariables.OUTLET_VOLUME_FLOWRATE_GAS_STOCKTANK,SystemVariables.OUTLET_VOLUME_FLOWRATE_OIL_STOCKTANK,SystemVariables.OUTLET_VOLUME_FLOWRATE_WATER_STOCKTANK,SystemVariables.OUTLET_VOLUME_FLOWRATE_LIQUID_STOCKTANK,SystemVariables.SYSTEM_OUTLET_TEMPERATURE,SystemVariables.BOTTOM_HOLE_PRESSURE,SystemVariables.OUTLET_GLR_STOCKTANK,SystemVariables.OUTLET_WATER_CUT_STOCKTANK];k=[ProfileVariables.TEMPERATURE,ProfileVariables.ELEVATION,ProfileVariables.TOTAL_DISTANCE,ProfileVariables.PRESSURE]
		if W.lower()==d:W='Permuted';g={Parameters.SystemAnalysisSimulation.INLETPRESSURE:G.reservoir_pressure,Parameters.SystemAnalysisSimulation.OUTLETPRESSURE:G.thp,Parameters.SystemAnalysisSimulation.SENSITIVITYMETHOD:Constants.SensitivityMethod.PERMUTED,Parameters.SystemAnalysisSimulation.SENSITIVITYVARIABLES:D}
		else:W='StepWithXAxis';g={Parameters.SystemAnalysisSimulation.INLETPRESSURE:G.reservoir_pressure,Parameters.SystemAnalysisSimulation.OUTLETPRESSURE:G.thp,Parameters.SystemAnalysisSimulation.SENSITIVITYMETHOD:Constants.SensitivityMethod.STEPWITHXAXIS,Parameters.SystemAnalysisSimulation.SENSITIVITYVARIABLES:D}
		l=G.model.tasks.systemanalysissimulation.run(h,system_variables=j,profile_variables=k,parameters=g);m=G.model.tasks.systemanalysissimulation.validate(h);X=1
		for Y in m:U('Issue {}'.format(X));U('Path: {}'.format(Y.path));U('Message: {}'.format(Y.message));U('Property: {}'.format(Y.property_name));X=X+1
		A=M.DataFrame(l.system);A.index=A.index.map(convert_units);n=A.iloc[0];A=A[1:];A.columns=M.MultiIndex.from_arrays([A.columns,n]);o=1000000;p=lambda bara:(bara-1.01325)/.98066
		for Z in A.columns:
			N,E=Z
			if M.isna(E):continue
			if'mmsm3/d'in O(E).lower()or'mmscmd'in O(E).lower():A[N,'SCMD']=A[N,E].astype(F)*o;A.drop(columns=[Z],inplace=c);continue
			if'bara'in O(E).lower():A[N,'ksc']=A[N,E].astype(F).apply(p);A.drop(columns=[Z],inplace=c);continue
			if'scmd'in O(E).lower():A[N,E]=A[N,E].astype(F).round(0).astype(P)
		A.columns=[', '.join(filter(B,A)).strip()for A in A.columns];os.makedirs('./pipesim-results',exist_ok=c);R=f"./pipesim-results/{G.well_name}-sensitivity-analysis-report.xlsx"
		if V is B:V='Study-1'
		S=V
		if os.path.exists(R):
			while S in H(load_workbook(R).sheetnames):S+='-new'
			with M.ExcelWriter(R,mode='a',engine=i,if_sheet_exists='new')as a:A.to_excel(a,sheet_name=S)
		else:
			with M.ExcelWriter(R,engine=i)as a:A.to_excel(a,sheet_name=S)
		logger.info('Sensitivity analysis completed.');logger.info(f"Sensitivity analysis outputs have been written to sheet '{S}' in {R}")
	except Exception as q:logger.info(f"Sensitivity analysis failed! Error: {q}")