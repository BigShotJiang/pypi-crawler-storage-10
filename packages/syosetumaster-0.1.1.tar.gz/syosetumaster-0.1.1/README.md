

read this :
https://github.com/Hijkstuv/syosetumaster

