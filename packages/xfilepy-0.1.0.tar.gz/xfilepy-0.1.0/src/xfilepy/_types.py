from __future__ import annotations

from collections.abc import Callable
from typing import Protocol


class FileHandlerLike(Protocol):
    """Public interface for the platform-specific FileHandler class."""

    @classmethod
    def from_uri_string(cls, uri_string: str, require_write: bool = False): ...

    @classmethod
    def create_via_picker(
        cls, on_ready: Callable[[FileHandlerLike], None], start_at: str | None = None
    ): ...

    @classmethod
    def create_via_multi_picker(
        cls,
        on_ready_many: Callable[[list[FileHandlerLike]], None],
        start_at: str | None = None,
    ): ...

    @classmethod
    def create_via_save_dialog(
        cls,
        on_ready: Callable[[FileHandlerLike], None],
        default_name: str = "untitled.bin",
        start_at: str | None = None,
    ): ...

    def to_uri_string(self) -> str | None: ...
    def has_access(self, require_write: bool = False) -> bool: ...
    def write_bytes(self, data: bytes) -> None: ...
    def append_bytes(self, data: bytes) -> None: ...
    def read_bytes(self, callback: Callable[[bytes], None]) -> None: ...
