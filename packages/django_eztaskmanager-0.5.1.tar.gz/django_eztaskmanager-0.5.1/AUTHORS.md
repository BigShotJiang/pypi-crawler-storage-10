# Authors

- Guglielmo Celata ([@guglielmo](https://github.com/guglielmo))

# Original django-uwsgi-taskmanagers authors

* Gabriele Giaccari ([@gabbork](https://github.com/gabbork))
* Gabriele Lucci ([@gabrielelucci](https://github.com/gabrielelucci))
* Guglielmo Celata ([@guglielmo](https://github.com/guglielmo))
* Paolo Melchiorre ([@pauloxnet](https://github.com/pauloxnet))
