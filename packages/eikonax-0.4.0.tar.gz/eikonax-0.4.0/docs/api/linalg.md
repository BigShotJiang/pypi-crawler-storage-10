# Tensor Algebra

::: eikonax.linalg