# fileselector

A lightweight Tkinter file and folder selector for Python.

## Example

```python
import fileselector

fileselector.help()
path = fileselector.select(file_extension=".png")
print(path)
