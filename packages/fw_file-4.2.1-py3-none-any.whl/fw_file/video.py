"""Video file format (non-DICOM)."""

import ffmpegio
from fw_meta import MetaData

from .base import AnyPath, FieldsMixin, File, ReadOnly


class Video(ReadOnly, FieldsMixin, File):
    """Video file format."""

    def __init__(self, file: AnyPath) -> None:
        """Read and parse a video file.

        Args:
            file (AnyPath): File to load.
        """
        super().__init__(file)
        object.__setattr__(self, "fields", ffmpegio.probe.full_details(file))

    def get_meta(self) -> MetaData:
        """Return the default Flywheel metadata of the Video."""
        return MetaData({"file.type": "video", "file.name": self.filename})
