"""
path     : anson.py3/src/io/odysz/semantic/__init__.py
Namespace: src.io.odysz.semantic
import   : io.odysz.semantic

@since 0.2.6
"""