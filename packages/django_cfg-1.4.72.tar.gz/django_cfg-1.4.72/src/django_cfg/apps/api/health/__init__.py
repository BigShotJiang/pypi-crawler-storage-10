"""
Django CFG Health Check Module

Built-in health monitoring endpoints for django_cfg.
"""
