from setuptools import setup

setup(
    name="xcore-coref",
    version="0.1.2",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/sapienzanlp/xcore",
    packages=["xcore", "xcore.models", "xcore.data", "xcore.utils", "xcore.common"],
    install_requires=[
        "pytorch-lightning>=1.8.0",
        "pandas>=1.3.5",
        "hydra-core>=1.2",
        "transformers>=4.34",
        "spacy>=3.7.2",
        "jsonlines==4.0.0",
        "sentencepiece==0.2.0",
        "protobuf==3.20",
        "nltk==3.8.1",
        "scipy>=1.10",
    ],
    python_requires=">=3.8.0",
    author="Giuliano Martinelli, Bruno Gatti",
    author_email="giuliano.martinelli97@gmail.com",
    zip_safe=False,
)
