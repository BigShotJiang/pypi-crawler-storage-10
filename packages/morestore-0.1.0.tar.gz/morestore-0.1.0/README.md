# MoreStore CLI

Python command-line client for [MoreStore.ai](https://morestore.ai) API - Generate perfect scenes for product images using AI.

## Installation

```bash
pip install morestore
```

## Quick Start

Generate a perfect scene for a product image:

```bash
morestore perfect-scene image.jpg
```

The generated image will be saved as `image_perfect_scene.jpg` in the same directory.

## Usage

### Basic Usage

```bash
# Generate perfect scene with default settings
morestore perfect-scene product.jpg

# Specify output file
morestore perfect-scene product.jpg --output result.jpg

# Disable progress updates
morestore perfect-scene product.jpg --no-progress
```

### Advanced Options

```bash
# Provide brand and product context
morestore perfect-scene product.jpg --brand-name "My Brand" --product-name "Product Name"

# Use a custom prompt
morestore perfect-scene product.jpg --custom-prompt "Create a modern minimalist scene with natural lighting"

# Scale image resolution
morestore perfect-scene product.jpg --scale-to-megapixels 2.0

# Use custom API endpoint
morestore perfect-scene product.jpg --api-url https://custom-api.example.com
```

## Command Options

### `perfect-scene` Command

- `image` (required): Path to the input image file (JPG or PNG)
- `--output`, `-o`: Path to save the generated image (default: input name with "_perfect_scene" suffix)
- `--brand-name`: Brand name for better context
- `--product-name`: Product name
- `--custom-prompt`: Custom prompt for scene generation (auto-generated if not provided)
- `--scale-to-megapixels`: Target megapixels for image scaling (default: 1.0)
- `--no-progress`: Disable progress updates
- `--api-url`: Base URL of the MoreStore API (default: https://morestore.ai)

## Examples

```bash
# Simple usage
morestore perfect-scene photo.jpg

# With brand context
morestore perfect-scene shoe.jpg --brand-name "Nike" --product-name "Air Max"

# Custom prompt
morestore perfect-scene bottle.jpg --custom-prompt "Create a luxury lifestyle scene with natural lighting"

# High resolution output
morestore perfect-scene watch.jpg --scale-to-megapixels 2.0 --output high-res-watch.jpg
```

## Python API

You can also use MoreStore as a Python library:

```python
from morestore_cli.client import MoreStoreClient

client = MoreStoreClient()

# Generate perfect scene
output_path = client.generate_perfect_scene(
    image_path="product.jpg",
    output_path="result.jpg",
    brand_name="My Brand",
    product_name="Product Name",
    show_progress=True
)

print(f"Generated image saved to: {output_path}")
```

## Progress Updates

By default, the CLI shows real-time progress updates via Server-Sent Events (SSE):

```
🔗 Starting progress listener for session: 12345678...
📡 Connected to progress stream...
✅ Connected (session: 12345678...)

📤 Uploading image and starting generation...
🚀 Starting perfect scene generation for product.jpg...
   📝 Analyzing product image to generate prompt...
   ✅ Prompt generated: Transform this into a beautiful modern scene...
   🎨 Loading AI model for scene generation...
   🎨 Generating perfect scene (this may take 30-60 seconds)...
   💓 Still generating... (5s elapsed)
   💓 Still generating... (10s elapsed)
✅ Perfect scene generation completed!
   ⏱️  Generation time: 45.2 seconds

✅ Perfect scene image saved successfully!
⏱️  Total generation time: 45.2 seconds
```

## Requirements

- Python 3.7 or higher
- Internet connection (to connect to MoreStore.ai API)

## License

MIT License

## Support

For issues, questions, or suggestions, please visit:
- Website: https://morestore.ai
- Documentation: https://morestore.ai/docs
- Issues: https://github.com/morestore/morestore-cli/issues
