#!/usr/bin/env python3
"""
Simple test of duckduckgo-search package
"""

def test_ddgs_package():
    """Test the duckduckgo-search package directly"""
    
    print("🧪 Testing duckduckgo-search package directly")
    print("=" * 50)
    
    try:
        from duckduckgo_search import DDGS
        
        print("✅ Successfully imported DDGS")
        
        # Test search
        query = "artificial intelligence in healthcare"
        print(f"🔍 Searching for: '{query}'")
        
        ddgs = DDGS()
        results = ddgs.text(query, max_results=10)
        
        print(f"✅ Search completed! Found {len(list(results))} results")
        
        # Convert to list and display results
        results_list = list(results)
        
        for i, result in enumerate(results_list, 1):
            print(f"\n--- Result {i} ---")
            print(f"Title: {result.get('title', 'No title')}")
            print(f"URL: {result.get('href', 'No URL')}")
            print(f"Body: {result.get('body', 'No body')[:200]}...")
        
        print(f"\n🎉 Success! DuckDuckGo Search API is working correctly!")
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("💡 Please install the package first:")
        print("   pip install duckduckgo-search")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_ddgs_package()