"""Command-line interface for MoreStore"""

import argparse
import sys
from pathlib import Path

from morestore_cli.client import MoreStoreClient


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="MoreStore CLI - Generate perfect scenes for product images",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s perfect-scene image.jpg
  %(prog)s perfect-scene image.jpg --output result.jpg
  %(prog)s perfect-scene image.jpg --brand-name "My Brand" --product-name "Product Name"
  %(prog)s perfect-scene image.jpg --custom-prompt "Create a modern minimalist scene"
  %(prog)s perfect-scene image.jpg --no-progress
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # Perfect scene command
    perfect_scene_parser = subparsers.add_parser(
        'perfect-scene',
        help='Generate a perfect scene for a product image',
        description='Generate a perfect scene for a product image using AI'
    )
    
    perfect_scene_parser.add_argument(
        'image',
        type=str,
        help='Path to the input image file (JPG or PNG)'
    )
    
    perfect_scene_parser.add_argument(
        '--output', '-o',
        type=str,
        help='Path to save the generated image (default: input name with "_perfect_scene" suffix)'
    )
    
    perfect_scene_parser.add_argument(
        '--brand-name',
        type=str,
        help='Brand name for better context'
    )
    
    perfect_scene_parser.add_argument(
        '--product-name',
        type=str,
        help='Product name'
    )
    
    perfect_scene_parser.add_argument(
        '--custom-prompt',
        type=str,
        help='Custom prompt for scene generation (auto-generated if not provided)'
    )
    
    perfect_scene_parser.add_argument(
        '--scale-to-megapixels',
        type=float,
        default=1.0,
        help='Target megapixels for image scaling (default: 1.0)'
    )
    
    perfect_scene_parser.add_argument(
        '--no-progress',
        action='store_true',
        help='Disable progress updates'
    )
    
    perfect_scene_parser.add_argument(
        '--api-url',
        type=str,
        default='https://morestore.ai',
        help='Base URL of the MoreStore API (default: https://morestore.ai)'
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Initialize client
    client = MoreStoreClient(base_url=args.api_url)
    
    # Execute command
    if args.command == 'perfect-scene':
        try:
            output_path = client.generate_perfect_scene(
                image_path=args.image,
                output_path=args.output,
                brand_name=args.brand_name,
                product_name=args.product_name,
                custom_prompt=args.custom_prompt,
                scale_to_megapixels=args.scale_to_megapixels,
                show_progress=not args.no_progress
            )
            
            print(f"\n✅ Success! Generated image saved to: {output_path}")
            sys.exit(0)
        
        except FileNotFoundError as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            sys.exit(1)
        
        except Exception as e:
            print(f"❌ Error: {e}", file=sys.stderr)
            sys.exit(1)

if __name__ == '__main__':
    main()

