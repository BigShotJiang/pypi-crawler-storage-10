# MoreStore CLI Package

This directory contains the Python package for the MoreStore CLI.

## Package Structure

```
morestore_cli/
├── __init__.py      # Package initialization
├── client.py        # API client library
└── cli.py          # Command-line interface
```

## Installation

### For Development

```bash
# Install in development mode
pip install -e .

# Or install from the package directory
cd morestore_cli
pip install -e .
```

### For Distribution

```bash
# Build the package
python setup.py sdist bdist_wheel

# Install from wheel
pip install dist/morestore-*.whl

# Or install from source
pip install dist/morestore-*.tar.gz
```

## Testing Locally

After installation, test the CLI:

```bash
# Test the command
morestore perfect-scene test-photo.JPG

# Test with options
morestore perfect-scene test-photo.JPG --brand-name "Test Brand" --output result.jpg
```

## Publishing to PyPI

1. **Update version** in `morestore_cli/__init__.py` and `setup.py`

2. **Build the package**:
   ```bash
   python -m build
   ```

3. **Test the build**:
   ```bash
   pip install dist/morestore-*.whl --force-reinstall
   ```

4. **Upload to PyPI** (requires PyPI credentials):
   ```bash
   python -m twine upload dist/*
   ```

   Or upload to TestPyPI first:
   ```bash
   python -m twine upload --repository testpypi dist/*
   ```

## Requirements

- Python 3.7+
- `requests` library (automatically installed)

## Usage

Once installed, users can run:

```bash
morestore perfect-scene image.jpg
```

The `morestore` command will be available globally after installation.

