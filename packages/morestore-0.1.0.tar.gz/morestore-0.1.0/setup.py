"""Setup script for MoreStore CLI package"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding='utf-8') if readme_file.exists() else ""

# Read version from package
version_file = Path(__file__).parent / "morestore_cli" / "__init__.py"
version = "0.1.0"
if version_file.exists():
    for line in version_file.read_text().splitlines():
        if line.startswith('__version__'):
            version = line.split('=')[1].strip().strip('"').strip("'")
            break

setup(
    name="morestore",
    version=version,
    description="Python CLI client for MoreStore.ai API - Generate perfect scenes for product images",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="MoreStore",
    author_email="info@morestore.ai",
    url="https://morestore.ai",
    packages=find_packages(),
    py_modules=[],
    install_requires=[
        "requests>=2.31.0",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "morestore=morestore_cli.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Multimedia :: Graphics",
    ],
    keywords="morestore ai image generation product photography",
    project_urls={
        "Documentation": "https://morestore.ai/docs",
        "Source": "https://github.com/morestore/morestore-cli",
        "Tracker": "https://github.com/morestore/morestore-cli/issues",
    },
)

