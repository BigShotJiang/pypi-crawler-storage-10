# airfoilplotter/core.py
import numpy as np
import matplotlib.pyplot as plt


def naca4(m, p, t, num_points=100, symmetric=False):
    """
    Generate coordinates for a 4-digit NACA airfoil.

    Parameters:
        m (float): Maximum camber (e.g., 0.02 for 2%)
        p (float): Location of maximum camber (e.g., 0.4)
        t (float): Maximum thickness (e.g., 0.12 for 12%)
        num_points (int): Number of points along the chord
        symmetric (bool): If True, generate a symmetric airfoil (no camber)
    """
    x = np.linspace(0, 1, num_points)
    yt = (t / 0.2) * (0.2969 * np.sqrt(x) - 0.1260 * x -
                      0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)

    if symmetric:
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p, (m / p**2) * (2 * p * x - x**2),
                      (m / (1 - p)**2) * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p, (2 * m / p**2) * (p - x),
                          (2 * m / (1 - p)**2) * (p - x))

    theta = np.arctan(dyc_dx)
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    return xu, yu, xl, yl


def naca5(l, p, t, num_points=100, symmetric=False):
    x = np.linspace(0, 1, num_points)
    m = l / 6
    yt = (t / 0.2) * (0.2969 * np.sqrt(x) - 0.1260 * x -
                      0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)

    if symmetric:
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p, (m / p**2) * (2 * p * x - x**2),
                      (m / (1 - p)**2) * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p, (2 * m / p**2) * (p - x),
                          (2 * m / (1 - p)**2) * (p - x))

    theta = np.arctan(dyc_dx)
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    return xu, yu, xl, yl


def naca6_series(Cl, t, num_points=100, symmetric=False):
    x = np.linspace(0, 1, num_points)
    m = Cl / 0.9
    p = 0.4
    yt = (t / 0.2) * (0.2969 * np.sqrt(x) - 0.1260 * x -
                      0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)

    if symmetric:
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p, (m / p**2) * (2 * p * x - x**2),
                      (m / (1 - p)**2) * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p, (2 * m / p**2) * (p - x),
                          (2 * m / (1 - p)**2) * (p - x))

    theta = np.arctan(dyc_dx)
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    return xu, yu, xl, yl


def naca7_series(Cl, t, num_points=100, symmetric=False):
    x = np.linspace(0, 1, num_points)
    m = Cl / 0.8
    p = 0.5
    yt = (t / 0.2) * (0.2969 * np.sqrt(x) - 0.1260 * x -
                      0.3516 * x**2 + 0.2843 * x**3 - 0.1015 * x**4)

    if symmetric:
        yc = np.zeros_like(x)
        dyc_dx = np.zeros_like(x)
    else:
        yc = np.where(x < p, (m / p**2) * (2 * p * x - x**2),
                      (m / (1 - p)**2) * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc_dx = np.where(x < p, (2 * m / p**2) * (p - x),
                          (2 * m / (1 - p)**2) * (p - x))

    theta = np.arctan(dyc_dx)
    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)
    return xu, yu, xl, yl


def plot_airfoil(xu, yu, xl, yl, title="Airfoil"):
    plt.figure(figsize=(8, 4))
    plt.plot(xu, yu, 'r', label="Upper Surface")
    plt.plot(xl, yl, 'b', label="Lower Surface")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.title(title)
    plt.axis("equal")
    plt.legend()
    plt.grid(True)
    plt.show()


