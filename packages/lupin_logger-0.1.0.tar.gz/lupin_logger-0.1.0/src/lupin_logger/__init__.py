from .logger import get_logger


__author__ = """LupinDental"""
__email__ = "contact@lupindental.com"
__all__ = ["get_logger"]
