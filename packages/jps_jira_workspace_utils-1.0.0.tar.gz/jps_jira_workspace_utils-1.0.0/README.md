# jps-jira-workspace-utils

A lightweight command-line utility for creating Jira ticket workspaces and seeding README.md files.

## Installation
```bash
pip install jps-jira-workspace-utils
```

## Usage
```bash
create-jira-workspace --ticket BISD-1050
```

If no ticket is provided, you will be prompted to enter one interactively.

## Example
```bash
$ create-jira-workspace --ticket BISD-1050
~/jira/BISD-1050
~/jira/BISD-1050/README.md
```

## License
MIT License © 2025 Jaideep Sundaram
