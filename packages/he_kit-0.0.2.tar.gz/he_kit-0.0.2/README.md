# Helicon kit

A project generator that bootstraps a FastAPI setup following Helicon's
standards and best practices.

## Local development setup

### Testing from local disk

```
mkdir test-dir
cd test-dir
uv venv
pip install -e ../path/to/he-kit
```
