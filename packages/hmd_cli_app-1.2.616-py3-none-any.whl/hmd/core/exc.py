class HmdAppError(Exception):
    """Generic errors."""

    pass
