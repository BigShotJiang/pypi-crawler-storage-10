import dataclasses
import pyperclip
import subprocess
import webbrowser

from rich.console import Console
from boj.core import constant

from boj.core.command import Command
from boj.core.fs.file_object import TextFile
from boj.core.fs.file_search_strategy import StaticSearchStrategy, UpwardSearchStrategy
from boj.core.fs.repository import Repository
from boj.core.html import HtmlParser
from boj.data.config import Config
from boj.data.boj_info import BojInfo
from boj.data.credential import Credential
from boj.web.boj_submit_page import (
    BojSubmitPageRequest,
    BojSubmitPostRequest,
    make_submit_post_body,
)


@dataclasses.dataclass
class SubmitCommand(Command):
    console: Console
    config_repository: Repository[Config]
    boj_info_repository: Repository[BojInfo]
    text_file_repository: Repository[TextFile]

    def execute(self, args):
        config = self.config_repository.find()

        with self.console.status("Loading config..") as status:
            status.update("Looking for problem information..")
            self.boj_info_repository.search_strategy = (
                StaticSearchStrategy() if args.problem_id else UpwardSearchStrategy()
            )
            cwd = config.workspace.search_dir(args.problem_id)
            boj_info = self.boj_info_repository.find(cwd, ".boj-info.json")

            source_code = self.text_file_repository.find(
                cwd=boj_info.metadata.dir,
                query=boj_info.source_path(abs_=False),
            )
            pyperclip.copy(source_code.content)
            # submit_command = config.general.submit_command.replace(
            #     "$url",
            #     constant.boj_submit_url(boj_info.id),
            # )
            webbrowser.open(constant.boj_submit_url(boj_info.id))

            # _ = subprocess.run(submit_command.split())

        self.console.rule(style="dim white")
        self.console.print(f"• [{boj_info.id}] {boj_info.title}")
