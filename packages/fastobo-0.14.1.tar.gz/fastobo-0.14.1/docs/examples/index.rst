Examples
========

This section contains examples of Python code, generated from Jupyter notebooks
with `nbsphinx <nbsphinx.readthedocs.io/>`_ against the latest version of
``fastobo``.

.. toctree::
   :maxdepth: 1

   descriptions
   obsolete
   graph
