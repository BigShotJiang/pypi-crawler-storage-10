Qualifier
=========

.. currentmodule:: fastobo.qual
.. automodule:: fastobo.qual

.. autoclass:: Qualifier
   :members:
   :special-members:

.. autoclass:: QualifierList
   :members:
   :special-members:
