Xref
====

.. currentmodule:: fastobo.xref
.. automodule:: fastobo.xref

.. autoclass:: Xref
   :members:
   :special-members:

.. autoclass:: XrefList
   :members:
   :special-members:
