Property-Value
==============

.. currentmodule:: fastobo.pv
.. automodule:: fastobo.pv


.. autoclass:: AbstractPropertyValue
   :members:
   :special-members:


.. autoclass:: LiteralPropertyValue(AbstractPropertyValue)
   :members:
   :special-members:


.. autoclass:: ResourcePropertyValue(AbstractPropertyValue)
   :members:
   :special-members:
