Document
========

.. currentmodule:: fastobo.doc
.. automodule:: fastobo.doc


``OboDoc``
----------

.. autoclass:: OboDoc
   :members:
   :special-members:
