#![allow(dead_code)]

use pyo3::prelude::*;

include!(concat!(env!("OUT_DIR"), "/built.rs"));
