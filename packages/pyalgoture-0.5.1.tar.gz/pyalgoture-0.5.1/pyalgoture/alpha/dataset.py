import os
import time
from collections.abc import Callable
from datetime import datetime
from multiprocessing import get_context
from multiprocessing.context import BaseContext
from typing import cast

import pandas as pd
import polars as pl
from tqdm import tqdm  # type: ignore

try:
    from ..utils.factor_analysis.tears import create_full_tear_sheet  # type: ignore
    from ..utils.factor_analysis.utils import (  # type: ignore
        get_clean_factor_and_forward_returns,
    )
except ImportError:
    # pip install alphalens-reloaded
    try:
        from alphalens.tears import create_full_tear_sheet  # type: ignore
        from alphalens.utils import get_clean_factor_and_forward_returns  # type: ignore
    except ImportError:
        raise ImportError("AlphaDataset required package 'alphalens'. pip install alphalens-reloaded")

from ..utils.logger import get_logger
from .datasets.utils.utility import (
    Segment,
    calculate_by_expression,
    calculate_by_polars,
    to_datetime,
)


class AlphaDataset:
    """Alpha dataset template class"""

    def __init__(
        self,
        df: pl.DataFrame,
        train_period: tuple[str, str],
        valid_period: tuple[str, str],
        test_period: tuple[str, str],
        process_type: str = "append",
    ) -> None:
        """Constructor"""
        self.logger = get_logger()

        self.df: pl.DataFrame = df

        # DataFrames for processed data
        self.result_df: pl.DataFrame
        self.raw_df: pl.DataFrame
        self.infer_df: pl.DataFrame
        self.learn_df: pl.DataFrame

        # New version
        self.data_periods: dict[Segment, tuple[str, str]] = {
            Segment.TRAIN: train_period,
            Segment.VALID: valid_period,
            Segment.TEST: test_period,
        }

        self.feature_expressions: dict[str, str | pl.expr.expr.Expr] = {}
        self.feature_results: dict[str, pl.DataFrame] = {}
        self.label_expression: str = ""

        self.process_type: str = process_type
        self.infer_processors: list = []
        self.learn_processors: list = []

    def __getstate__(self) -> dict:
        """
        Customize the state to be pickled when serializing the object.
        This method is called by pickle when dumping an object.
        """
        state = self.__dict__.copy()

        # Print serialization information for debugging
        print(f"Serializing AlphaDataset with {len(self.feature_expressions)} features")
        print(f"Data periods: {self.data_periods}")

        # Remove logger as it's not serializable
        if "logger" in state:
            del state["logger"]

        return state

    def __setstate__(self, state: dict) -> None:
        """
        Restore the state when unpickling the object.
        This method is called by pickle when loading an object.
        """
        self.__dict__.update(state)

        # Restore logger
        self.logger = get_logger()

        print(f"Deserialized AlphaDataset with {len(self.feature_expressions)} features")

    def add_feature(
        self,
        name: str,
        expression: str | pl.expr.expr.Expr | None = None,
        result: pl.DataFrame | None = None,
    ) -> None:
        """
        Add a feature expression
        """
        if expression is not None and result is not None:
            raise ValueError("Only one of 'expression' or 'result' can be provided")

        if expression is not None:
            self.feature_expressions[name] = expression
        elif result is not None:
            self.feature_results[name] = result

    def set_label(self, expression: str) -> None:
        """
        Set the label expression
        """
        self.label_expression = expression

    def add_processor(self, task: str, processor: Callable[[pl.DataFrame], None]) -> None:
        """
        Add a feature preprocessor
        """
        if task == "infer":
            self.infer_processors.append(processor)
        else:
            self.learn_processors.append(processor)

    def prepare_data(self, filters: dict | None = None, max_workers: int | None = None) -> None:
        """
        Generate required data
        """
        # List for feature data results
        results: list = []

        # Iterate through expressions for calculation
        expressions: list[tuple[str, str | pl.expr.expr.Expr]] = list(self.feature_expressions.items())

        if self.label_expression:
            expressions.append(("label", self.label_expression))

        # Create process pool
        self.logger.info("Start calculating expression factor features")

        args: list[tuple] = [(self.df, name, expression) for name, expression in expressions]

        context: BaseContext = get_context("spawn")
        # context: BaseContext = get_context("fork")

        if max_workers is None:
            cpu_count = os.cpu_count()
            max_workers = (cpu_count - 2) if cpu_count is not None else 1

        with context.Pool(processes=max_workers) as pool:
            # Calculate all expressions in parallel
            it = pool.imap(calculate_feature, args)
            # it = pool.imap_unordered(calculate_feature, args)

            # Collect results
            for result in tqdm(it, total=len(args)):
                results.append(result)

        self.result_df = self.df.with_columns(results)

        # Merge result data factor features
        self.logger.info("Start merging result data factor features")

        for name, result in tqdm(self.feature_results.items()):
            result = result.rename({"data": name})
            self.result_df = self.result_df.join(result, on=["datetime", "aio_symbol"], how="inner")

        # Generate raw data
        raw_df = self.result_df.fill_null(float("nan"))

        if filters:
            self.logger.info("Start filtering components data")

            filtered_df = pl.DataFrame()

            for aio_symbol, ranges in tqdm(filters.items(), total=len(filters)):
                for start, end in ranges:
                    temp_df = raw_df.filter(
                        (pl.col("aio_symbol") == aio_symbol)
                        & (pl.col("datetime") >= pl.lit(start))
                        & (pl.col("datetime") <= pl.lit(end))
                    )
                    filtered_df = pl.concat([filtered_df, temp_df])

            raw_df = filtered_df

        # Only keep feature columns
        select_columns: list[str] = ["datetime", "aio_symbol"] + raw_df.columns[self.df.width :]
        self.raw_df = raw_df.select(select_columns).sort(["datetime", "aio_symbol"])

        # Generate inference data
        self.infer_df = self.raw_df
        for processor in self.infer_processors:
            self.infer_df = processor(df=self.infer_df)

        # Generate learning data
        if self.process_type == "append":
            self.learn_df = self.infer_df
        else:
            self.learn_df = self.raw_df

        for processor in self.learn_processors:
            self.learn_df = processor(df=self.learn_df)

    def fetch_raw(self, segment: Segment) -> pl.DataFrame:
        """
        Get raw data for a specific segment
        """
        start, end = self.data_periods[segment]
        return query_by_time(self.raw_df, start, end)

    def fetch_infer(self, segment: Segment) -> pl.DataFrame:
        """
        Get inference data for a specific segment
        """
        start, end = self.data_periods[segment]
        return query_by_time(self.infer_df, start, end)

    def fetch_learn(self, segment: Segment) -> pl.DataFrame:
        """
        Get learning data for a specific segment
        """
        start, end = self.data_periods[segment]
        return query_by_time(self.learn_df, start, end)

    def show_feature_performance(self, name: str) -> None:
        """
        Perform performance analysis for a feature
        """
        starts: list[datetime] = []
        ends: list[datetime] = []

        for period in self.data_periods.values():
            starts.append(to_datetime(period[0]))
            ends.append(to_datetime(period[1]))

        start: datetime = min(starts)
        end: datetime = max(ends)

        # Select range
        df: pl.DataFrame = query_by_time(self.result_df, start, end)

        # Extract feature
        feature_df: pd.DataFrame = df.select(["datetime", "aio_symbol", name]).to_pandas()
        feature_df.set_index(["datetime", "aio_symbol"], inplace=True)

        feature_s: pd.Series = feature_df[name]

        # Extract price
        price_df: pd.DataFrame = df.select(["datetime", "aio_symbol", "close"]).to_pandas()
        price_df = price_df.pivot(index="datetime", columns="aio_symbol", values="close")

        # Merge data
        clean_data: pd.DataFrame = get_clean_factor_and_forward_returns(feature_s, price_df, quantiles=10)

        # Perform analysis
        create_full_tear_sheet(clean_data)
        return clean_data

    def show_signal_performance(self, signal: pl.DataFrame, quantiles: int = 10) -> None:
        """
        Perform performance analysis for prediction signals
        """
        # Get signal start and end times
        start: datetime = cast(datetime, signal["datetime"].min())
        end: datetime = cast(datetime, signal["datetime"].max())

        # Select range
        df: pl.DataFrame = query_by_time(self.result_df, start, end)

        # Extract feature
        signal_df: pd.DataFrame = signal.to_pandas()
        signal_df.set_index(["datetime", "aio_symbol"], inplace=True)
        signal_s: pd.Series = signal_df["signal"]

        # Extract price
        price_df: pd.DataFrame = df.select(["datetime", "aio_symbol", "close"]).to_pandas()
        price_df = price_df.pivot(index="datetime", columns="aio_symbol", values="close")

        # Merge data
        clean_data: pd.DataFrame = get_clean_factor_and_forward_returns(
            signal_s, price_df, max_loss=1.0, quantiles=quantiles
        )

        # Perform analysis
        create_full_tear_sheet(clean_data)


def query_by_time(df: pl.DataFrame, start: datetime | str = "", end: datetime | str = "") -> pl.DataFrame:
    """
    Filter DataFrame based on time range
    """
    if start:
        start = to_datetime(start)
        df = df.filter(pl.col("datetime") >= start)

    if end:
        end = to_datetime(end)
        df = df.filter(pl.col("datetime") <= end)

    return df.sort(["datetime", "aio_symbol"])


def calculate_feature(
    args: tuple[pl.DataFrame, str, str | pl.expr.expr.Expr],
) -> pl.Series:
    """
    Calculate feature by expression
    """
    start = time.time()

    df, name, expression = args

    # print(f"[calculate_feature] {name}: {df} {df.columns} | expression: {expression}")

    if isinstance(expression, pl.expr.expr.Expr):
        result = calculate_by_polars(df, expression)["data"].alias(name)
    else:
        result = calculate_by_expression(df, expression)["data"].alias(name)

    end = time.time()
    print(f"Feature calculation {name} took: {end - start} seconds | {expression}")

    return result
