from .kvaeser_node import KvaeserCanNode

NODES = [KvaeserCanNode]
