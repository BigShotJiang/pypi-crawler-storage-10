from setuptools import setup


if __name__ == "__main__":  # pragma: no cover - executed only when called directly
    raise RuntimeError(
        "This project is built with maturin. Run `maturin develop` or `maturin build` instead of invoking setup.py."
    )