"""A module for changing various files in /etc"""
from nanodeploy import Deployment


def set_hostname(deployment: Deployment, hostname: str):
    """Changes /etc/hostname to change the systems Hostname"""
    deployment.write_file(f"Set Hostname to {hostname}", hostname, "/etc/hostname")