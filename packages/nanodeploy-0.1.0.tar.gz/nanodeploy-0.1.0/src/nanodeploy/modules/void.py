"""A module for various things specific to Void Linux"""
from nanodeploy import Deployment


def install_xbps_package(deployment: Deployment, package_name: str, no_ask: bool = True):
    """
    Installs the given package during Activation.

    :param deployment: The deployment to use
    :param package_name: A string, representing the package names
    :param no_ask: If true (default), adds the --yes flag to the xbps command. It is recommended, that is parameter is always true.
    """

    command = "xbps-install "
    if no_ask:
        command += "--yes "

    command += package_name
    deployment.execute_sh(f"Install {package_name} using XBPS", command)


def install_xbps_packages(deployment: Deployment, package_names: list[str], no_ask: bool = True):
    """
    Installs the given packages during Activation.

    :param deployment: The deployment to use
    :param package_names: A list of strings, representing the package names
    :param no_ask: If true (default), adds the --yes flag to the xbps command. It is recommended, that is parameter is always true.
    """

    command = "xbps-install "
    if no_ask:
        command += "--yes "

    command += " ".join(package_names)
    deployment.execute_sh(f"Install {package_names} using XBPS", command)


def update_xbps_packages(deployment: Deployment, no_ask: bool = True):
    """
    Updates all packages during Activation.

    :param deployment: The deployment to use
    :param no_ask: If true (default), adds the --yes flag to the xbps command. It is recommended, that is parameter is always true.
    """
    command = "xbps-install "
    if no_ask:
        command += "--yes "

    command += "--sync --update"
    deployment.execute_sh("Update all packages using XBPS", command)


def remove_orphan_xbps_packages(deployment: Deployment, no_ask: bool = True):
    """
    Removes orphaned packages during Activation

    :param deployment: The deployment to use
    :param no_ask: If true (default), adds the --yes flag to the xbps command. It is recommended, that is parameter is always true.
    """
    command = "xbps-remove "
    if no_ask:
        command += "--yes "

    command += "--remove-orphans"
    deployment.execute_sh("Removes orphaned packages using XBPS", command)
