"""A module for handling Git Repositories"""

from nanodeploy import Deployment


def pull_git_repository(deployment: Deployment, repository: str):
    """
    Pulls a single Git Repository during activation.

    :param deployment: The deployment to use
    :param repository: The path where the repository is located
    """

    deployment.execute_sh(f"Pull Git Repository at {repository}", "git pull", repository)
