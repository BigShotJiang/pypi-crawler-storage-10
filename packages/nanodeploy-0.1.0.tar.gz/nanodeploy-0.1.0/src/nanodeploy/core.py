"""The Core Modules of nanodeploy. Using them directly in the Deployment is discouraged"""
import os
import shutil
import subprocess
import typing
from collections.abc import Callable


class ActivationCallError(Exception):
    """This error is thrown, when an Execution throws an error"""

    def __init__(self, execution_name: str, execution_exception: Exception):
        self.message = f"Error running {execution_name}: {execution_exception}"
        super().__init__(self.message)

    def __str__(self):
        return self.message


class Execution:
    """An Execution is a function called during activation."""

    def __init__(self, execution_name: str, call: Callable):
        self.execution_name = execution_name
        self.call = call

    def execute(self):
        """Calls the function"""
        self.call()

    def ask_execute(self, default: bool = True) -> bool:
        """
        Asks stdin for confirmation if the function shall be called.

        :param default: The default value (when no input is provided). Default is yes (true).
        :type default: bool
        :return The result of the confirmation
        :rtype bool
        """

        possible_text = "[y/N]"
        if default:
            possible_text = "[Y/n]"

        confirmation = input(f"Do you want to run {self.execution_name}? {possible_text} ")

        if confirmation.lower() == "y":
            return True
        elif confirmation.lower() == "n":
            return False
        elif confirmation == "":
            return default
        else:
            return self.ask_execute(default)


class Deployment:
    """A Deployment is the Base of nanodeploy."""

    def __init__(self):
        self.on_activation_calls: list[Execution] = []

    def execute_sh(self, execution_name: str, command: str, working_directory: typing.Optional[str] = None,
                   environment: typing.Optional[dict[str, str]] = None):
        """Executes the given command during activation"""

        working_path = working_directory

        if working_path is not None:
            working_path = os.path.expanduser(working_path)
            working_path = os.path.realpath(working_path)

        self.on_activation_calls.append(Execution(execution_name,
                                                  lambda: subprocess.run(args=command, shell=True, env=environment,
                                                                         cwd=working_path).check_returncode()))

    def copy_file(self, execution_name: str, source: str, target: str):
        """Copies the given file path to the source path during activation"""
        source_path = os.path.expanduser(source)
        source_path = os.path.realpath(source)

        destination_path = os.path.expanduser(target)
        destination_path = os.path.realpath(destination_path)

        self.on_activation_calls.append(Execution(execution_name, lambda: shutil.copy(source_path, destination_path)))

    def write_file(self, execution_name: str, content: str, target: str):
        """Writes the given content to the source path during activation"""
        destination_path = os.path.expanduser(target)
        destination_path = os.path.realpath(destination_path)

        def write():
            with open(destination_path, "wt") as f:
                f.write(content)

        self.on_activation_calls.append(Execution(execution_name, write))

    def activate(self, verbose: bool = False, ask: bool = False):
        """
        Actually runs everything.
        Generally, this should be executed at the very bottom of your Deployment file.

        :param verbose: Whether the activation should be verbose.
        :type verbose: bool

        :param ask: Whether stdin should be asked for confirmation before running anything.
        :type ask: bool

        """
        for call in self.on_activation_calls:
            should_run = True

            if ask:
                should_run = call.ask_execute(True)

            if should_run:
                if verbose:
                    print(f"Running {call.execution_name}")

                try:
                    call.call()
                except Exception as e:
                    raise ActivationCallError(call.execution_name, e)
