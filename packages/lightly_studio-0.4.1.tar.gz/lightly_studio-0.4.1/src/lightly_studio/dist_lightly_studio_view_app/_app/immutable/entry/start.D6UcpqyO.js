import{l as o,e as r}from"../chunks/BHoO7UL_.js";export{o as load_css,r as start};
