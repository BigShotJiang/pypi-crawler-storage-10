__version__ = "1.4.5"
__version_info__ = tuple(int(i) for i in __version__.split("."))

# Database schema version for migration support
DB_SCHEMA_VERSION = "1.0"
