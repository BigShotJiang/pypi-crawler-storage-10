def add(x, y):
    return x + y

print("Hello from main.py")
print(add(6, 5))