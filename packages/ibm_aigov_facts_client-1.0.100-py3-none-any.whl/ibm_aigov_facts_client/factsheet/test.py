from ibm_aigov_facts_client.factsheet.asset_utils_me import ModelUsecaseUtilities
from ibm_aigov_facts_client.factsheet.approaches import ApproachUtilities
from packaging import version as pkg_version
from ibm_aigov_facts_client.factsheet.external_deployments import Deployment
from ibm_aigov_facts_client.utils.utils import validate_enum
from ibm_aigov_facts_client.supporting_classes.factsheet_utils import DeploymentDetails
from ibm_aigov_facts_client.utils.client_errors import *
from typing import BinaryIO, Dict, List, TextIO, Union, Any
import json
import re
import hashlib



def track_externally_managed_asset(self, asset_id: str , inventory_id: str , usecase: ModelUsecaseUtilities = None, approach: ApproachUtilities = None, grc_model: dict = None, version_number: str = None, version_comment: str = None):
    """
        Link Model to model use case. Model asset should be stored in either Project or Space and corrsponding ID should be provided when registering to model use case.

        Supported for CPD version >=4.7.0

        :param ModelUsecaseUtilities usecase: Instance of ModelUsecaseUtilities
        :param ApproachUtilities approach: Instance of ApproachUtilities
        :param asset_id : The asset id
        :param inventory_id : The inventory id
        :param str grc_model: (Optional) Openpages model id. Only applicable for CPD environments. This should be dictionary, output of get_grc_model()
        :param str version_number: Version number of model. supports either a semantic versioning string or one of the following keywords for auto-incrementing based on the latest version in the approach: "patch", "minor", "major"
        :param str version_comment: (Optional) An optional comment describing the changes made in this version

        :rtype: ModelAssetUtilities

        For tracking model with model usecase:

        >>> model.track(usecase=<instance of ModelUsecaseUtilities>,approach=<instance of ApproachUtilities>,version_number=<version>)
    """

    output_width = 125
    print("-" * output_width)
    print("Tracking Process Started".center(output_width))
    print("-" * output_width)

    if self._is_cp4d and self._cp4d_version < "4.6.5":
        raise ClientError(
            "Version mismatch: Track model with model usecase and approach functionality is only supported in CP4D version 4.6.5 or higher. Current version of CP4D is " + self._cp4d_version)

    # if (model_usecase is None or model_usecase == ""):
    #     raise MissingValue("model_usecase", "ModelUsecaseUtilities object or instance is missing")

    if (usecase is None or usecase == ""):
        raise MissingValue(
            "ai usecase", "ModelUsecaseUtilities object or instance is missing")

    if (not isinstance(usecase, ModelUsecaseUtilities)):
        raise ClientError(
            "Provide ModelUsecaseUtilities object for usecase parameter")

    if (approach is None or approach == ""):
        raise MissingValue(
            "approach", "ApproachUtilities object or instance is missing")

    if (not isinstance(approach, ApproachUtilities)):
        raise ClientError("Provide ApproachUtilities object for approach")

    if (version_number is None or version_number == ""):
        raise MissingValue("version_number", "version number is missing")

    payload = {}
    version_details = {}


    # model_usecase_id = model_usecase.get_id()
    # model_usecase_catalog_id = model_usecase.get_container_id()
    model_usecase_id = usecase.get_id()
    model_usecase_catalog_id = usecase.get_container_id()
    model_usecase_name = usecase.get_name()

    approach_id = approach.get_id()
    approach_name = approach.get_name()
    model_asset_id = asset_id

    if approach._versions is None:
        approach._versions = []
    else:
        approach._versions.clear()

    _logger.info("Assigned {} to {} for tracking.".format(approach_name, model_usecase_name))

    latest_version_data = self._get_latest_approach_version(model_usecase_id, model_usecase_catalog_id, approach_id)
    if latest_version_data:
        approach._versions.append({
            "number": latest_version_data['number'],
            "comment": latest_version_data['comment']
        })
    else:
        raise ClientError("Failed to fetch the latest version")

    approachVersionList = approach.get_versions()
    versionList = []
    for version in approachVersionList:
        versionList.append(version["number"])
    finalVersionValList = self._finalVersion(versionList)
    finalVersionVal = finalVersionValList[-1]

    payload['model_entry_catalog_id'] = model_usecase_catalog_id or self._assets_client._get_pac_catalog_id()
    payload['model_entry_asset_id'] = model_usecase_id

    version_details['approach_id'] = approach_id

    if version_comment:
        version_details['comment'] = version_comment

    if version_number in ["major", "minor", "patch"]:
        finalVersionVal = self._increment_ver(finalVersionVal, version_number)
    else:
        finalVersionVal = version_number

    latest_version = latest_version_data['number'] if latest_version_data else None
    latest_version = pkg_version.parse(latest_version)
    requested_version = pkg_version.parse(finalVersionVal)

    if latest_version > requested_version:
        _logger.warning(
            f"The latest version in this approach is {latest_version}. Please confirm that you want to assign a lower version number to this model.")

    version_details['number'] = finalVersionVal

    payload['version_details'] = version_details

    if grc_model:
        payload['grc_model_id'] = grc_model.get('GrcModel').get('id')

    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "track"

    if model_usecase_id:
        _logger.info("Initiate linking model to existing AI usecase {}".format(
            model_usecase_id))
    else:
        _logger.info("Initiate linking model to new AI usecase......")

    response = requests.post(url,
                             headers=self._get_headers(),
                             data=json.dumps(payload))

    if response.status_code == 200:
        _logger.info("Successfully finished linking Model {} to AI usecase".format(
            model_asset_id))
        # approach._versions.clear()

    else:
        error_msg = u'Model registration failed'
        reason = response.text
        _logger.info(error_msg)
        raise ClientError(error_msg + '. Error: ' +
                          str(response.status_code) + '. ' + reason)
    return response.json()


def set_phase_for_externally_managed_asset(self, to_container: str, asset_id: str, inventory_id: str) -> None:
    if  to_container == '':
        raise ClientError(
            "To containers can not be empty string")
    validate_enum(to_container, "to_container",
                  ModelEntryContainerType, True)
    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "lifecycle_phase"
    params = {}
    params['to'] = to_container
    response = requests.post(url,
                             headers=self._get_headers(),
                             params=params)
    if response.status_code == 200:
        _logger.info("Asset successfully moved to {} environment".format( to_container))
    else:
        raise ClientError("Asset space update failed. ERROR {}. {}".format(
            response.status_code, response.text))


def add_deployments_for_externally_managed_asset(self,asset_id: str, inventory_id: str, phase: str, deployment_details:'DeploymentDetails'=None) -> list:
    """
        Adds deployments for external models for documentation purposes only. Supported for CPD version 4.7.0 and above
        :param asset_id: asset id
        :param inventory_id: inventory id
        :param phase: phase
        :param list deployments: List of deployments to be added. Provide deployments in a list.

        :rtype: list(Deployment)

        :return: External model deployments are added

        The way to use me is,::

            model.add_deployments([{"id":"<id>","name":"<name>","type":"<type>","scoring_endpoint":"<scoring_endpoint>","description":"<description>"}])

    """

    params = {}
    validate_enum(phase, "to_container",
                  ModelEntryContainerType, True)
    params['phase'] = phase
    failed_deployments = []
    deployments_response = []

    deployment_identifier = deployment_details.id
    name = deployment_details.name
    type = deployment_details.type
    scoring_endpoint = deployment_details.scoring_endpoint
    description = deployment_details.description

    if (deployment_identifier is None or deployment_identifier == ""):
        raise MissingValue("id", "ID is missing")
    if (name is None or name == ""):
        raise MissingValue("name", "name is missing")

    id = self._encode_id(deployment_identifier)

    body = {
        "id": id,
        "external_identifier": deployment_identifier,
        "name": name,
        "type": type,
        "scoring_endpoint": scoring_endpoint,
        "description": description
    }
    final_body = {k: v for (k, v) in body.items() if v is not None}

    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "deployments"
    response = requests.post(url, data=json.dumps(
        final_body), params=params, headers=self._get_headers())
    print ("header",self._get_headers())

    if response.status_code == 200:
        _logger.info(
            "Deployment added successfully to a model")
        deployments_response.append(Deployment(self, id, name, type, scoring_endpoint, deployment_identifier,
                                               "false", description, self.get_name()))
    else:
        failed_deployments.append(response.text)
    if len(deployments_response) > 0:
        return deployments_response

    if len(failed_deployments) > 0:
        raise ClientError(
            "Failed while adding deployment to a model. ERROR {}".format(failed_deployments))


def get_deployments_for_externally_managed_asset(self,asset_id: str, inventory_id: str, phase: str, deployment_id: str) -> List:
    """
        Get  deployment details

        :return: All deployment details for external model
        :rtype: list(Deployment)

        The way to use me is,::

           model.get_deployments()

    """

    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "deployments" + deployment_id
    params = {}
    validate_enum(phase, "to_container",
                  ModelEntryContainerType, True)
    params['phase'] = phase

    response = requests.get(url, headers=self._get_headers(), params=params)

    if response.status_code == 200:
        _logger.info("Deployments retrieved successfully")
        deployment_list = response.json()["deployment_details"]
        deployment_list_values = []
        for deployment in deployment_list:
            deployment_list_values.append(Deployment(self, deployment.get('id'), deployment.get('name'), deployment.get('type'), deployment.get('scoring_endpoint'), deployment.get(
                'external_identifier'), deployment.get('is_deleted'), deployment.get('description'), self.get_name()))
        return deployment_list_values
    else:
        raise ClientError("Failed in retrieving deployments. ERROR {}. {}".format(
            response.status_code, response.text))

def delete_deployments_for_externally_managed_asset(self,asset_id: str, inventory_id: str, phase: str, deployment_id: str):
    """
        Delete the deployments in external model for documentation purposes only. Supported for CPD version >=4.7.0

        :param list deployment_ids: List of deployment ID's to be deleted. Provide deployment_ids in a list.

        :rtype: None

        :return: External model deployments are deleted.

        The way to use me is,::

            model.delete_deployments([deployment_ids])
    """
    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "deployments" + deployment_id
    params = {}
    validate_enum(phase, "to_container",
                  ModelEntryContainerType, True)
    params['phase'] = phase

    response = requests.delete(url, headers=self._get_headers() , params=params)
    if response.status_code == 204:
        _logger.info("Deployment " + deployment_id +
                     " deleted successfully")
    else:
        raise ClientError("Failed in deleting deployment {}. ERROR {}. {}".format(
            deployment_id, response.status_code, response.text))






def update_evaluation_for_externally_managed_asset(self,inventory_id: str, asset_id: str, lifecycle_phase: str, evaluation_data: dict[str, Any]):
    params = {}
    validate_enum(lifecycle_phase, "to_container",
                  ModelEntryContainerType, True)
    params['lifecycle_phase'] = lifecycle_phase
    body = evaluation_data
    url = self._get_externally_managed_asset_url(asset_id, inventory_id) + "evaluation_data"
    response = requests.post(url,data=json.dumps(
        body), headers=self._get_headers(),params=params)

    if response.status_code == 200:
        _logger.info("Evaluation updated successfully")
    else:
        raise ClientError("Failed update evaluation. ERROR {}. {}".format(
            response.status_code, response.text))




def _get_latest_approach_version(self, model_asset_id, model_usecase_catalog_id, approach_id):
    url = self._get_approach_url(model_asset_id, model_usecase_catalog_id)
    response = requests.get(url, headers=self._get_headers())

    if response.status_code != 200:
        raise ClientError(f"Failed to fetch approach versions. Error: {response.status_code}")

    approach_response = response.json()
    approaches_list = approach_response.get("approaches", [])

    for approach_data in approaches_list:
        if approach_data.get('id') == approach_id:
            versions = approach_data.get('versions', [])
            if versions:
                return {
                    "number": versions[0].get('number'),
                    "comment": versions[0].get('comment')
                }
            return {"number": "0.0.0", "comment": ""}

    raise ClientError(f"Approach with ID {approach_id} not found")


def _get_approach_url(self, model_usecase_asset_id: str = None, catalog_id: str = None):
    if not model_usecase_asset_id or not catalog_id:
        raise ValueError("Model usecase asset ID and catalog ID are required.")

    append_url = '/v1/aigov/model_inventory/model_usecases/' + \
                 model_usecase_asset_id + '/tracked_model_versions?catalog_id=' + catalog_id

    if self._is_cp4d:
        url = self._cpd_configs["url"] + append_url
    else:
        if get_env() == 'dev':
            url = dev_config["DEFAULT_DEV_SERVICE_URL"] + append_url
        elif get_env() == 'test':
            url = test_config["DEFAULT_TEST_SERVICE_URL"] + append_url
        else:
            url = prod_config["DEFAULT_SERVICE_URL"] + append_url

    return url


def _finalVersion(self, versionList: list = None):
    splitVersion = []
    FinalVersionList = []
    convertFromString = []

    version_pattern = r"^(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"

    for version in versionList:
        # Match version using the regex pattern
        version_parts = re.match(version_pattern, version)
        if not version_parts:
            raise ValueError(f"Invalid version format: {version}")

        major, minor, patch = int(version_parts[1]), int(version_parts[2]), int(version_parts[3])
        pre_release, build_metadata = version_parts[4], version_parts[5]

        splitVersion.append([major, minor, patch, pre_release, build_metadata])

        convertFromString.append([major, minor, patch])

    # Sort the versions by their numeric values (major, minor, patch)
    sortedVersion = sorted(convertFromString)

    # Reconstruct the sorted versions into the original format (including pre-release and build metadata)
    for sortedVal in sortedVersion:
        # Find the corresponding original version and reattach the pre-release and build metadata
        for idx, val in enumerate(splitVersion):
            if sortedVal == val[:3]:  # Match major, minor, patch (ignore pre-release/build for sorting)
                major, minor, patch, pre_release, build_metadata = val
                version_str = f"{major}.{minor}.{patch}"
                if pre_release:
                    version_str += f"-{pre_release}"
                if build_metadata:
                    version_str += f"+{build_metadata}"
                FinalVersionList.append(version_str)
                break

    return FinalVersionList

def _increment_ver(self, version, releaseVal):

    version_pattern = r"^(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?$"
    version_parts = re.match(version_pattern, version)

    # if not version_parts:
    #     raise ValueError(f"Invalid version format: {version}")

    major = int(version_parts.group("major"))
    minor = int(version_parts.group("minor"))
    patch = int(version_parts.group("patch"))

    version_list = [major, minor, patch]

    # version = version.split('.')
    if releaseVal == "major":
        major += 1
        minor = 0
        patch = 0
    elif releaseVal == "minor":
        minor += 1
        patch = 0
    elif releaseVal == "patch":
        patch += 1
    else:
        raise ValueError(f"Unknown release value: {releaseVal}")

    return '.'.join(map(str, [major, minor, patch]))

def _encode_id(self, id):
    encoded_id = hashlib.md5(id.encode("utf-8")).hexdigest()
    return encoded_id



