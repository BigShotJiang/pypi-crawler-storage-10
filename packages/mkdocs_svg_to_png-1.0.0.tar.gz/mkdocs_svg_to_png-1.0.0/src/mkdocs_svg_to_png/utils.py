"""SVG 変換補助のファイル操作やユーティリティ関数群。"""

import hashlib
import logging
import os
import tempfile
from pathlib import Path

from .logging_config import get_logger


def generate_image_filename(
    page_file: str, block_index: int, svg_content: str, image_format: str
) -> str:
    """ページ情報と SVG 内容から PNG ファイル名を決定する。"""
    page_name = Path(page_file).stem

    code_hash = hashlib.md5(
        svg_content.encode("utf-8"), usedforsecurity=False
    ).hexdigest()[:8]  # nosec B324

    # SVGファイルパスが含まれている場合、シンプルに拡張子をimage_formatに変更
    if svg_content.endswith(".svg"):
        svg_file_path = Path(svg_content)
        svg_basename = svg_file_path.stem  # 拡張子を除いたベース名
        return f"{svg_basename}.{image_format}"

    return f"{page_name}_svg_{block_index}_{code_hash}.{image_format}"


def ensure_directory(directory: str) -> None:
    """ディレクトリが存在しない場合に再帰的に作成する。"""
    Path(directory).mkdir(parents=True, exist_ok=True)


def get_temp_file_path(suffix: str = ".svg") -> str:
    """指定された拡張子を持つ一時ファイルパスを生成する。"""
    fd, path = tempfile.mkstemp(suffix=suffix)

    os.close(fd)

    return path


def _get_cleanup_suggestion(error_type: str) -> str:
    """エラー種別ごとに適切な対処ヒントを返す。"""
    if error_type == "PermissionError":
        return "Check file permissions or run with privileges"
    elif error_type == "OSError":
        return "File may be locked by another process"
    else:
        return "Try again or check system logs for details"


def clean_file_with_error_handling(
    file_path: str,
    logger: logging.Logger | None = None,
    operation_type: str = "cleanup",
) -> tuple[bool, bool]:
    """ファイル削除の共通処理（エラーハンドリング付き）。

    引数:
        file_path: 削除するファイルのパス
        logger: ロガーインスタンス（None の場合はログ出力なし）
        operation_type: 操作の種類（ログ出力用）

    戻り値:
        (success, had_error) のタプル。
        - success: 削除が成功した場合 True
        - had_error: ファイル非存在以外のエラーが発生した場合 True
    """
    if not file_path:
        return False, False

    file_obj = Path(file_path)

    try:
        if file_obj.exists():
            file_obj.unlink()
            if logger:
                logger.debug(f"Successfully cleaned file: {file_path}")
            return True, False
        return False, False  # ファイルが存在しない場合は異常とみなさない
    except (PermissionError, OSError) as e:
        error_type = type(e).__name__
        if logger:
            logger.warning(
                f"{error_type} when cleaning file: {file_path}",
                extra={
                    "context": {
                        "file_path": file_path,
                        "operation_type": operation_type,
                        "error_type": error_type,
                        "error_message": str(e),
                        "suggestion": _get_cleanup_suggestion(error_type),
                    }
                },
            )
        return False, True  # Actual error occurred


def clean_temp_file(file_path: str) -> None:
    """一時ファイルをクリーンアップする。"""
    logger = get_logger(__name__)
    clean_file_with_error_handling(file_path, logger, "temp_cleanup")


def get_relative_path(file_path: str, base_path: str) -> str:
    """基準パスからの相対パスを計算し、POSIX 形式に揃える。"""
    if not file_path or not base_path:
        return file_path

    logger = get_logger(__name__)

    try:
        rel_path = os.path.relpath(file_path, base_path)
        # テストは POSIX スラッシュを期待するため統一
        return rel_path.replace("\\", "/")
    except ValueError as e:
        logger.warning(
            f"Cannot calculate relative path from {base_path} to {file_path}",
            extra={
                "context": {
                    "file_path": file_path,
                    "base_path": base_path,
                    "error_type": "ValueError",
                    "error_message": str(e),
                    "fallback": "Using absolute path",
                    "suggestion": "Often happens with cross-drive paths on Windows",
                }
            },
        )
        return file_path


def clean_generated_images(
    image_paths: list[str], logger: logging.Logger | None
) -> None:
    """生成された画像ファイルをクリーンアップする。"""
    if not image_paths:
        return

    results = [
        clean_file_with_error_handling(path, logger, "image_cleanup")
        for path in image_paths
        if path
    ]

    cleaned_count = sum(success for success, _ in results)
    error_count = sum(had_error for _, had_error in results)

    if (cleaned_count > 0 or error_count > 0) and logger:
        logger.info(f"Image cleanup: {cleaned_count} cleaned, {error_count} errors")
