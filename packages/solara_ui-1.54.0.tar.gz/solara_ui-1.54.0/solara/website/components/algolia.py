import solara


@solara.component_vue("algolia_api.vue")
def Algolia():
    pass
