---
title: Overview of how to deploy your Solara application or dashboard
description: Solara apps can be easily either self hosted, or hosted on a variety of cloud platforms.
---
# Deploying a solara app

A Solara app can be [self hosted](/documentation/getting_started/deploying/self-hosted) or [cloud hosted](/documentation/getting_started/deploying/cloud-hosted).
