The entries are meant as deeper dives into specific topics. Although we try to write each as a standalone document, some parts may build on previous ones.
