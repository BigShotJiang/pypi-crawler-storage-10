import solara


page = solara.Button("Click me")
