<template>
  <div>{{ value }}</div>
</template>
