select implementation details of empix
======================================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:
