.. _reference_guide_sec:

empix reference guide
=====================

.. autosummary::
   :toctree: _autosummary
   :template: custom_module_template.rst
   :recursive:

   empix
