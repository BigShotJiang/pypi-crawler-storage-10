# Whisper-tools
#### High-level python library for stream and static transcription with whisper

## Translating .wav file

1. Using local model
```python
def example_file_transcription():
    whisper_local = WhisperLocal(model_name="openai/whisper-tiny")
    text = whisper_local.transcribe_file("sound_example.wav")
    print(text)
```

2. Using llm api
```python
def example_file_transcription():
    whisper_local = WhisperAPI(api_key="your_key", base_url="your_url")
    text = whisper_local.transcribe_file("sound_example.wav")
    print(text)
```

## Stream translating 

1. Using local model
```python
def example_streaming():
    recorder = StreamRecorder(WhisperLocal(model_name="openai/whisper-tiny"))

    try:
        recorder.start_recording()
        print("Recording... Press Ctrl+C to stop")
        while True:
            text = recorder.process_chunk()
            if text:
                print(f"Recognized: {text}")
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        recorder.stop_recording()
```

2. Using llm api
```python
def example_streaming():
    recorder = StreamRecorder(WhisperAPI(api_key="your_key", base_url="your_url"))

    try:
        recorder.start_recording()
        print("Recording... Press Ctrl+C to stop")
        while True:
            text = recorder.process_chunk()
            if text:
                print(f"Recognized: {text}")
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        recorder.stop_recording()
```