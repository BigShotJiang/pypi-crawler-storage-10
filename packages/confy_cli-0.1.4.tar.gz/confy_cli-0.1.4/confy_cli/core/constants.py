"""Core CLI constants."""

from typing import Final

RAW_PAYLOAD_LENGTH: Final[int] = 2
