"""implements a class that wraps tensorflow compiled inference models with trainable pytorch classifier using opensoundscape

subclassed by BirdNET and Perch
"""

import pandas as pd
import torch

import opensoundscape
from opensoundscape.ml.cnn import CNN
from opensoundscape.ml.shallow_classifier import MLPClassifier


class TensorFlowModelWithPytorchClassifier(CNN):
    def __init__(self, embedding_size, classes, sample_duration):
        """base class for TensorFlow models with trainable pytorch classifier head

        Args:
            embedding_size: int, size of the 1D feature vector output by the TensorFlow model
            classes: list of str, class names for the classifier
            sample_duration: float, duration of audio samples in seconds
        """
        # initialize a CNN where self.network is a pytorch classification head
        self.embedding_size = embedding_size
        # separate custom_classes list from self.classes (original class list)
        self._custom_classes = ["undefined"]
        self._original_classes = classes

        self.use_custom_classifier = False
        """(bool) whether to generate predictions using self.tf_model or the custom classifier

        initially False, but gets set to True if .train() is called
        """
        clf = MLPClassifier(
            input_size=embedding_size, output_size=len(self._custom_classes)
        )
        super().__init__(
            architecture=clf, classes=classes, sample_duration=sample_duration
        )

        self.tf_model = None  # set by subclass, holds the TensorFlow model

    @property
    def classes(self):
        if self.use_custom_classifier:
            return self._custom_classes
        else:
            return self._original_classes

    # setter
    @classes.setter
    def classes(self, new_classes):
        if self.use_custom_classifier:
            self._custom_classes = new_classes
        else:
            self._original_classes = new_classes

    @property
    def classifier(self):
        return self.network

    def change_classes(self, new_classes, hidden_layer_sizes=()):
        """alias for initialize_custom_classifier"""
        self.initialize_custom_classifier(
            new_classes=new_classes, hidden_layer_sizes=hidden_layer_sizes
        )

    def initialize_custom_classifier(self, new_classes, hidden_layer_sizes=()):
        """initialize a custom classifier to replace the BirdNET classifier head

        The classifier is a multi-layer perceptron with ReLU activations and a final
        linear layer. The input size is the size of the embeddings from the BirdNET model,
        and the output size is the number of classes.

        The new classifier (self.network) will have random weights, and can be trained with
        self.train().

        Sets self.use_custom_classifier = True, so that predict() returns outputs from the
        custom classifier rather than from the original TF model classification head.
        Set .use_custom_classifier=False if you want predict to return the original
        model's classification logits.

        Args:
            hidden_layer_sizes: tuple of int, sizes of hidden layers in the classifier
                [default: ()]
            classes: list of str, class names for the classifier. Will run self.change_classes(classes)
                if not None. If None, uses self.classes. [default: None]

        Effects:
            sets self.network to a new MLPClassifier with the specified shape
            runs self.change_classes(classes) if classes is not None, resulting in
                self.classes = classes
        """
        self._custom_classes = new_classes
        self.network = MLPClassifier(
            input_size=self.embedding_size,
            output_size=len(new_classes),
            hidden_layer_sizes=hidden_layer_sizes,
        )
        self.use_custom_classifier = True
        self._init_torch_metrics()

    @property
    def custom_classifier(self):
        """alias for self.network"""
        return self.network

    def _batch_forward(self, batch_data):
        """This method should return the tensorflow model output  logits if
        self.use_custom_classifier is False, otherwise it should use the custom
        classifier (self.network) to generate logits on the embeddings from the
        tensorflow model.

        It must return (embeddings, logits) on a single batch of samples
        """
        raise NotImplementedError("This method should be implemented in subclasses")

    def __call__(self, dataloader):
        """This method should call _batch_forward() for each batch in the dataloader

        Return values might depend on the model or be configurable through arguments
        """
        raise NotImplementedError("This method should be implemented in subclasses")

    def embed(self, samples):
        """This method should call __call__() on the output of self.predict_dataloader(samples)

        Return values might depend on the model or be configurable through arguments
        """
        raise NotImplementedError("This method should be implemented in subclasses")

    # def training_step(self, samples, batch_idx):
    #     """a standard Lightning method used within the training loop, acting on each batch

    #     returns loss

    #     Effects:
    #         logs metrics and loss to the current logger
    #     """
    #     batch_data, batch_labels = samples
    #     # first run the preprocessed samples through the tensorflow feature extractor
    #     # discard the logits produced by the tensorflow classifier, just keep embeddings
    #     self.use_custom_classifier = False
    #     embeddings, _ = self._batch_forward(batch_data)
    #     # switch from Tensorflow classifier head to custom classifier (self.network)
    #     self.use_custom_classifier = True
    #     # then run the embeddings through the trainable classifier with a typical "train" step
    #     return super().training_step(
    #         (torch.tensor(embeddings), torch.tensor(batch_labels)), batch_idx
    #     )
    def train(
        self,
        train_df,
        validation_df,
        n_augmentation_variants=0,
        embedding_batch_size=1,
        embedding_num_workers=0,
        steps=1000,
        optimizer=None,
        criterion=None,
        device=torch.device("cpu"),
    ):
        """train a custom classifier head on the embeddings from the tensorflow model

        this function calls opensoundscape.ml.shallow_classifier.fit_classifier_on_embeddings()

        Before calling this function, the user should call self.initialize_custom_classifier()
            or self.change_classes() to modify the classifier head to match the number of classes.

        We can't train the tensorflow model (it is inference only), so this function only trains
        the classification head. First, it embeds the training and validation samples with
        the .tf_model. If num_augmentation_variants is >0, it generates embeddings on
        stochastically augmented versions of the samples.
        Next, it trains the custom classifier head (self.network) without any batching.

        Running this function is equivalent to embeddings samples then fitting a classifier,
        a workflow demonstrated in the opensoundscape tutorial notebooks.

        Args:
            train_df: pd.DataFrame, training data
            validation_df: pd.DataFrame, validation data
            n_augmentation_variants: int, number of augmentations to apply to each sample
                [default: 0]
            batch_size: int, batch size for embedding [default: 1]
            num_workers: int, number of workers for embedding data loading [default: 0]
            steps: int, number of training steps [default: 1000]
            optimizer: torch.optim.Optimizer, optimizer for training
                [default: None uses torch.optim.Adam()]
            criterion: torch.nn.Module, loss function for training
                [default: None uses torch.nn.CrossEntropyLoss()]
            device: torch.device, device for training [default: torch.device("cpu")]


        Example:
        ```
        import bioacoustics_model_zoo as bmz
        model = bmz.BirdNET()
        model.initialize_custom_classifier(hidden_layer_sizes=(256,), classes=["A", "B", "C"])
        model.train(train_df, validation_df)
        model.predict(validation_df)
        ```
        """
        from opensoundscape.ml.shallow_classifier import fit_classifier_on_embeddings

        fit_classifier_on_embeddings(
            embedding_model=self,
            classifier_model=self.network,
            train_df=train_df,
            validation_df=validation_df,
            n_augmentation_variants=n_augmentation_variants,
            embedding_batch_size=embedding_batch_size,
            embedding_num_workers=embedding_num_workers,
            steps=steps,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
        )

        # switch from original (.tf_model) to custom trained classifier (.network) for inference
        self.use_custom_classifier = True

    def save(self, *args, **kwargs):
        """save model to path

        Note: the tf Interpreter is not pickable, so it is set to None before saving
        and re-assigned after saving (even if saving fails)

        Args: see opensoundscape.ml.cnn.CNN.save()
        """
        assert isinstance(
            self.network, MLPClassifier
        ), "model.save() and model.load() only supports reloading .network if it is and instance of the MLPClassifier class"

        # since the tf Interpreter is not pickable, we don't include it in the saved file
        # instead we can recreate it with __init__ and a checkpoint
        temp_tf_model = self.tf_model
        try:
            # save the model with .tf_model (Tensorflow Interpreter) set to None
            self.tf_model = None
            super().save(*args, **kwargs)
        finally:
            # reassign the Tensorflow Interpreter to .tf_model
            # this needs to happen even if the model saving fails!
            self.tf_model = temp_tf_model

    @classmethod
    def load(cls, path, **kwargs):
        """load model from path

        re-loads custom classifier head trained by user
        (only supports the Classifier class)

        Sets self.use_custom_classifier to True, since loading from a file
        is only necessary if the user has trained a custom classifier
        (otherwise simply use BirdNET() to create a new model)

        Args:
            path: path to model saved using BirdNET.save()
            kwargs are passed to self.__init__()

        Returns:
            model including any custom trained classifier head
        """
        import warnings

        model_dict = torch.load(path)

        opso_version = (
            model_dict.pop("opensoundscape_version")
            if isinstance(model_dict, dict)
            else model_dict.opensoundscape_version
        )
        if opso_version != opensoundscape.__version__:
            warnings.warn(
                f"Model was saved with OpenSoundscape version {opso_version}, "
                f"but you are currently using version {opensoundscape.__version__}. "
                "This might not be an issue but you should confirm that the model behaves as expected."
            )

        if isinstance(model_dict, dict):
            # load up the weights and instantiate from dictionary keys
            # includes preprocessing parameters and settings
            # assumes that model_dict["architecture"] is a tuple of args for __init__
            # of the MLPClassifier class (which will be true if model was saved with BirdNET.save()
            # and MLPClassifier was used to create the model.network)
            model = cls(**kwargs)
            hidden_layer_sizes = model_dict["architecture"][2]
            model.initialize_custom_classifier(
                hidden_layer_sizes=hidden_layer_sizes, classes=model_dict["classes"]
            )
            # load state dict of custom classifier
            model.network.load_state_dict(model_dict["weights"])

        else:
            model = model_dict  # entire pickled object, not dictionary
            opso_version = model.opensoundscape_version

            # re-create the tensorflow inference model using __init__
            # since it is not saved with self.save() due to pickling issues
            model.tf_model = cls(**kwargs).tf_model

        model.use_custom_classifier = True
        return model
