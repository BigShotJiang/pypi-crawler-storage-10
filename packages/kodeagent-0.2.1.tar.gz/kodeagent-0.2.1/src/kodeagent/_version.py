"""Single-source package version for KodeAgent.

Update the __version__ string here *before* making a release on GitHub.
"""

__version__ = '0.2.1'
