# package_name

`rocket_ahmed` is a Python library for instantiating & manipulating rocket objects

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install `rocket_ahmed`.

```bash
pip install rocket_ahmed
```

## Usage

```python
import rocket_ahmed

# returns 'words'
rocket_ahmed.module_name('word')

# returns 'geese'
rocket_ahmed.module_name('goose')

# returns 'phenomenon'
rocket_ahmed.module_name('phenomena')
```

## License
[MIT](https://choosealicense.com/licenses/mit/)