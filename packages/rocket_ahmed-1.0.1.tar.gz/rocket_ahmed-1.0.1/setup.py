from setuptools import setup

setup(
   name='rocket_ahmed',
   version='1.0.1',
   author='ahmed',
   author_email='ay.bouguessa@esi-sba.dz',
   packages=['rocket_ahmed'],
   url='http://pypi.python.org/pypi/rocket_ahmed/',
   license='LICENSE.txt',
   description='An awesome package that does something',
   long_description=open('README.md').read(),
   long_description_content_type="text/markdown",
   install_requires=['rocket_ahmed']
)