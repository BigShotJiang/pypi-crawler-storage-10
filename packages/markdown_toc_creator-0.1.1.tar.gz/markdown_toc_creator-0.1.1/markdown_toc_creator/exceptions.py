class HeaderLevelNotContinuousException(Exception):
    """Exception when header levels are not continuous"""

    pass
