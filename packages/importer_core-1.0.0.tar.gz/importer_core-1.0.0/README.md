Importer Core

A comprehensive Python package and module management system with  analysis capabilities.

Overview

Importer Core is a powerful library designed for deep analysis and management of Python packages and modules. It provides developers with  tools for package inspection, dependency analysis, code quality assessment, and performance monitoring.

Key Features

Package Management

· Advanced Module Analysis: Deep inspection of Python packages and modules
· Dependency Management: Comprehensive dependency tree analysis and conflict detection
· Package Operations: Install, update, uninstall packages with  options
· PyPI Integration: Search and analyze packages from PyPI with intelligent caching

Code Analysis

· Source Code Analysis: Extract metadata, signatures, and structure from source files
· AST-Based Analysis: Advanced Abstract Syntax Tree parsing for deep code understanding
· Performance Monitoring: Real-time code execution tracking and memory usage analysis
· Quality Assessment: Code quality checks and pattern detection

Advanced Tools

· Module Comparison: Compare different versions of modules and packages
· Version Management: Automated version tracking and tagging· Visualization: Export dependency trees to various formats (Graphviz, Mermaid)
· Security: Safe package operations with validation and error handling

Installation

pip install importer-core

Quick Start

Basic Module Analysis

from importer import Modulex

# Analyze a module
mod = Modulex('requests')
print(f"Version: {mod.version}")
print(f"Stats: {mod.stats()}")

Package Exploration

from importer import pmeX

# Explore package structure
explorer = pmeX('numpy')
print(explorer.tree())
print(explorer.structure().classes())

PyPI Search

from importer import PyPISearch

async def search_packages():
    async with PyPISearch() as searcher:
        results = await searcher.search("web framework", max_results=5)
        for package in results:
            print(f"{package.name} {package.version}: {package.summary}")

# Run the search
import asyncio
asyncio.run(search_packages())

Dependency Analysis

from importer import get_dep_tree

# Analyze dependency tree
tree = get_dep_tree("requests", max_depth=3)
print(tree)

Core Components

Modulex

Comprehensive module analysis and management:

mod = Modulex('your-package')
print(mod.version)           # Package version
print(mod.is_installed())    # Installation status
print(mod.structure())       # File structure

pmeX (Python Module Explorer)

module exploration and manipulation:

explorer = pmeX('package-name')
explorer.inject("NEW_CONSTANT = 42")  # Code injection
explorer.disable_feature("function_name")  # Feature controlPyPISearch

Intelligent PyPI package search:

searcher = PyPISearch()
results = await searcher.search("data science", include_details=True)

Source Analysis

Deep source code analysis:

from importer import Source

src = Source(your_function)
print(src.source)        # Source code
print(src.decorators)    # Function decorators
print(src.type_hints)    # Type annotations

Usage

Batch Package Installation

from importer import installs

# Install multiple packages concurrently
results = installs(["requests", "numpy", "pandas"], mode="thread")
for result in results:
    status = "Success" if result['success'] else "Failed"
    print(f"{result['package']}: {status}")

Module Comparison

from importer import ModuleComparator

# Compare two versions of a module
comparator = ModuleComparator('package-name', './other-version')
print("Different files:", comparator.diff_files)
print("Statistics:", comparator.stats)

Code Quality Analysis

from importer import Source

def analyze_code_quality(module):
    analyzer = Source(module)

    print("Code Quality Report:")
    print(f"Total functions: {len(analyzer.defs)}")
    print(f"Total classes: {len(analyzer.classes)}")
    print(f"Type hints coverage: {analyzer.type_hints_coverage}")

    # Detect potential issues
    unreachable = analyzer.unreachable_code
    if unreachable:
        print(f"Unreachable code found: {len(unreachable)} locations")

Configuration

The library can be configured for different use cases:

# Custom cache settings
searcher = PyPISearch(cache_ttl=600, max_concurrent=5)

# Performance optimization
analyzer = size('large-package', worker=os.cpu_count() * 10)Requirements

· Python 3.8 or higher
· aiohttp >= 3.8.0
· packaging >= 21.0
· PyYAML >= 6.0

Optional Dependencies

· python-minifier: For code minification features
· graphviz: For dependency visualization
· build & twine: For package publishing

Documentation

Full documentation is available in the project's GitHub repository:

· API Reference
· Examples
· Best Practices

Contributing

Contributions are welcome! Please feel free to submit pull requests, report bugs, or suggest new features.

License

This project is licensed under the MIT License - see the LICENSE file for details.

Support

For support and questions:

· Create an issue on GitHub
· Check the documentation
· Review existing examples

Version History

· 1.0.0: Initial release with core functionality
· Module analysis and management
· Dependency tracking
· PyPI integration
· Code analysis tools

---

Developed by Moamen Walid - GitHub Repository
