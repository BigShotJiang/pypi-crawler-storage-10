from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
	name="importer-core",
	version="1.0.0",
	author="Moamen Walid",
	author_email="mikl37228@gmail.com",
	description="A comprehensive Python package and module management system with analysis capabilities",
	long_description=long_description,
	long_description_content_type="text/markdown",
	url="https://github.com/mikl37228-spec/importer-core",
	license="MIT",
	license_files=["LICENSE"],
	packages=find_packages(include=["importer_core", "importer_core.*"]),
	package_data={"importer_core": ["py.typed"]},
	classifiers=[
		"Development Status :: 4 - Beta",
		"Intended Audience :: Developers",
		"Topic :: Software Development :: Libraries :: Python Modules",
		"Topic :: System :: Archiving :: Packaging",
		"Topic :: Utilities",
		"Programming Language :: Python :: 3",
		"Programming Language :: Python :: 3.8",
		"Programming Language :: Python :: 3.9",
		"Programming Language :: Python :: 3.10",
		"Programming Language :: Python :: 3.11",
		"Programming Language :: Python :: 3.12",
		"Operating System :: OS Independent",
	],
	keywords=[
		"importer", "package-manager", "module-analysis", "dependency-management",
		"python-packages", "code-analysis", "ast", "metadata", "pypi"
	],
	python_requires=">=3.8",
	install_requires=[
		"aiohttp>=3.8.0",
		"packaging>=21.0",
		"pyyaml>=6.0",
		"python-minifier>=2.8.0",
		"build>=1.0.0",
		"twine>=4.0.0",
	],
	extras_require={
		"dev": [
			"pytest>=7.0.0", "pytest-cov>=4.0.0", "black>=23.0.0",
			"isort>=5.12.0", "mypy>=1.0.0", "flake8>=6.0.0",
		],
		"full": [
			"graphviz>=0.20.0", "matplotlib>=3.7.0", "networkx>=3.0",
		],
	},
	project_urls={
		"Documentation": "https://github.com/mikl37228-spec/importer-core/docs",
		"Source": "https://github.com/mikl37228-spec/importer-core",
		"Tracker": "https://github.com/mikl37228-spec/importer-core/issues",
		"Changelog": "https://github.com/mikl37228-spec/importer-core/releases",
	},
)