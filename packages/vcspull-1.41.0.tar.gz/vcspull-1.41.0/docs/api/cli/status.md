# vcspull status - `vcspull.cli.status`

```{eval-rst}
.. automodule:: vcspull.cli.status
   :members:
   :show-inheritance:
   :undoc-members:
```
