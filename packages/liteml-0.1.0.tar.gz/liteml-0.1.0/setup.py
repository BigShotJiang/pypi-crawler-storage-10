from setuptools import setup, find_packages

setup(
    name="liteml",
    version="0.1.0",
    packages=find_packages(),
    description="A small ML library implemented using only the Python standard library",
    author=  '',
    python_requires=">=3.7",
)
