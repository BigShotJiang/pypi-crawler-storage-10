# pureml

`liteml` is a small educational machine learning library implemented using only the Python standard library (no NumPy, scikit-learn, or other external dependencies).

## Included algorithms
- Linear Regression (gradient descent)
- Logistic Regression (binary, gradient descent)
- k-Nearest Neighbors (brute force)
- Decision Tree Classifier (CART, Gini)
- Gaussian Naive Bayes
- Perceptron (binary)

## Utilities
- train_test_split (random and stratified)
- normalize (min-max)
- metrics: MSE, accuracy, F1

## Usage example

```py
from liteml.model_selection import train_test_split
from liteml.linear_regression import LinearRegression
from liteml.metrics import mean_squared_error

X = [[1],[2],[3],[4],[5]]
y = [2,4,6,8,10]

X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.4, seed=42)
model = LinearRegression(lr=0.01, epochs=2000)
model.fit(X_train, y_train)
preds = model.predict(X_test)
print("MSE:", mean_squared_error(y_test, preds))
```

## Notes
- This library is educational and not optimized for performance.
- Some algorithms (e.g., decision tree) use simple approaches for splitting and are intended for clarity rather than speed.
