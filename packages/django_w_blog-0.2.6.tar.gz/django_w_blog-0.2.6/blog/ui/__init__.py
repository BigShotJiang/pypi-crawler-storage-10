"""blog UI"""
