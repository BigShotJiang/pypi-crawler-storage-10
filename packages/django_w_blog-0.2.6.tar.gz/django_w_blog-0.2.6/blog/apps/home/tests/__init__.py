"""Tests for blog.home"""
