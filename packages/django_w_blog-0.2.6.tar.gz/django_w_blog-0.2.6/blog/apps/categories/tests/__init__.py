"""Tests for blog.categories"""
