"""
Snakia framework
"""
