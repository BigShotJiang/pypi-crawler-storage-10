# Timeliner MCP Service

A simple Model Context Protocol (MCP) microservice that logs milestones from worker agents as an append-only log. This service forms the foundation for the c4ai context flow system.

## Features

- **Append-only logging** of task milestones
- **Human-friendly task IDs** using Haikunator (e.g., "happy-cloud-42")
- **Separate storage** for tasks and milestones
- **Simple JSON database** using TinyDB
- **MCP tools** for interacting with the service
- **CLI interface** built with Typer for easy command-line usage
- **Time-based filtering** for milestone retrieval
- **Task ID filtering** for bulk milestone queries
- **User prompt tracking** for initial task context

## Installation

Using uv:
```bash
cd timeliner
uv sync --all-extras
```

## Usage

### CLI Commands

Timeliner provides a CLI interface built with Typer:

```bash
# Show help
uv run timeliner --help

# Generate a new task ID
uv run timeliner generate-id

# Create a new task with optional initial prompt
uv run timeliner task-create "Implement new feature" --prompt "User wants OAuth2 support"

# Save a milestone to existing task
uv run timeliner save-milestone "task-id-42" "Completed feature X" --tag feature --tag backend

# List all tasks
uv run timeliner task-list

# Show milestones for a specific task (by task ID or doc ID)
uv run timeliner task-show "happy-cloud-42"  # by task ID
uv run timeliner task-show 25                 # by doc ID

# Show all milestones with optional time filter
uv run timeliner show
uv run timeliner show --since "2025-01-12T00:00:00Z"

# Show specific milestone by doc ID
uv run timeliner show 1
```

### Running the MCP Server

```bash
# Using the CLI
uv run timeliner serve
```

### Available MCP Tools

1. **task_create** - Create a new task
   - `task_description`: Description of the task (required)
   - `user_prompt`: Optional initial user prompt to save as first milestone
   - Returns: `task_id` of the created task

2. **save_milestone** - Save a milestone for an existing task
   - `task_id`: Unique task identifier (required)
   - `outcomes`: Detailed outcomes of work done (required)
   - `tags`: Optional list of tags
   - `metadata`: Optional metadata (links to PRs, commits, etc.)

3. **get_milestones** - Retrieve milestones with filtering
   - `since_timestamp`: Optional ISO format timestamp to filter from
   - `task_ids`: Optional list of task IDs to filter by
   - Returns: List of milestones with count

4. **task_list** - List all tasks in the system
   - Returns: List of all tasks with descriptions

5. **generate_task_id** - Generate a new unique task ID
   - Returns: Human-friendly task ID

### Example Usage

```python
# Create a new task with initial prompt
task_create(
    task_description="Add OAuth2 support",
    user_prompt="User wants secure authentication with Google and GitHub"
)  # Returns: {"task_id": "happy-cloud-42"}

# Save a milestone to existing task
save_milestone(
    task_id="happy-cloud-42",
    outcomes="Implemented user authentication module",
    tags=["auth", "feature"],
    metadata={"pr": "#123", "commit": "abc123"}
)

# Get all milestones since a date
get_milestones(
    since_timestamp="2025-01-12T00:00:00Z"
)

# Get milestones for specific tasks
get_milestones(
    task_ids=["happy-cloud-42", "gentle-wind-77"]
)
```

## Data Structure

### Task
- `task_id`: Unique human-friendly identifier (e.g., "happy-cloud-42")
- `description`: Task description (required)
- `doc_id`: Database document ID (auto-assigned)

### Milestone
- `task_id`: Reference to parent task (required)
- `timestamp`: UTC timestamp of creation (auto-generated)
- `outcomes`: Detailed outcomes/results (required)
- `tags`: Optional list of tags for categorization
- `metadata`: Optional links and references (dict)
- `doc_id`: Database document ID (auto-assigned)

## Testing

Run tests with pytest:
```bash
uv sync --all-extras
uv run pytest tests/ -v
```

## Architecture

The service follows a simple layered architecture:
- **Models** (`app/models.py`): Pydantic data models
- **Service** (`app/services.py`): Business logic and database operations
- **MCP** (`app/mcp.py`): MCP tool definitions
- **CLI** (`app/main.py`): Typer CLI application
- **Database**: TinyDB JSON file storage in `data/db.json`

## Development

This is a Proof of Concept (PoC) for the c4ai context flow system. The service provides a foundation for tracking AI agent work through an append-only log of milestones.

### Version History

- **v0.6.2** - Added task_ids filter to `get_milestones`
- **v0.6.1** - CLI `task-show` command supports doc_id
- **v0.6** - Add milestone retrieval and filtering features
- **v0.5** - Enhanced API with user_prompt parameter
- **v0.4** - Rebuilt save command integration
- **v0.3** - Split task creation and milestone saving
- **v0.2** - Initial MCP implementation
- **v0.1** - Basic service structure