from fastmcp import FastMCP
from loguru import logger

from .services import Timeline

app = FastMCP("timeliner")
service = Timeline()


@app.tool(enabled=False)
def task_create(task_title: str, user_prompt: str = "") -> dict:
    """
    Creates a new task with an auto-generated task ID.
    Args:
        task_title: Title of the task to be created
        user_prompt: Optional initial user prompt to save with task creation
    Returns: dict: Task creation result
    """
    task = service.create_task(task_title)
    if not task:
        raise ValueError(f"Unable to create task '{task_title}'")

    logger.info(f"Created new task '{task_title}' with id: {task.task_id}")

    # If user_prompt is provided, immediately save it as the first step
    if user_prompt:
        service.create_step(task.task_id, "Initial prompt", user_prompt, tags=["prompt"])
        logger.info(f"Saved initial prompt as step for task {task.task_id}")

    return {"task_id": task.task_id, "md_file": task.file_path}


@app.tool(enabled=False)  # disable for now, use get_steps() with task_id as param
def task_show(task_id: str) -> dict:
    """
    Retrieves all steps for a given task.
    Args: task_id: The task identifier
    Returns: dict: List of steps for the task
    """
    steps = service.get_steps_by_task_id(task_id)
    return {"task_id": task_id, "steps": [m.model_dump() for m in steps]}


@app.tool()
def task_list() -> dict:
    """
    Lists all tasks in the system.
    Returns: dict: List of all tasks
    """
    tasks = service.get_all_tasks()
    return {"tasks": [task.model_dump() for task in tasks]}


@app.tool()
def save_step(task_id: str, title: str, outcomes: str, tags: list[str] | None = None, metadata: dict[str, str] | None = None) -> dict:
    """
    Saves a Step for the Task. Creates new Task if 'task_id' is empty string.
    Args:
        task_id: The task identifier for which the step is being recorded (required)
        title: Short description of the step
        outcomes: The detailed outcomes of the work done
        tags: Optional list of tags: ["telephony", "bugfix"]
        metadata: Optional links to tasks, issues, PRs, commits, etc, as a dictionary: {"github_issue": "http://...", "jira_ticket": "http://..."}
    Returns: dict: Step creation result
    """
    # Check correctness of 'task_id'
    if task_id is None or not isinstance(task_id, str):
        raise ValueError(f"Invalid type of task_id ({task_id}). Please provide a valid task_id type or empty string.")

    # fetch Task instance and check if task exist
    if not task_id:
        task = service.create_task(title=title)
        if not task:
            raise ValueError(f"Unable to create task ({task_id}). Failed when at file creating.")  # TODO @vz: what llm should do?
    else:
        task = service.get_task(task_id)
        if not task:
            raise ValueError(f"Task with id {task_id} does not exist. Please provide a valid task_id or empty string.")

    # Create step
    step = service.create_step(task.task_id, title, outcomes, tags, metadata)
    if not step:
        raise ValueError("Failed to create the step.")  # TODO @vz: what llm should do?

    logger.info(f"Successfully saved step for task {task_id}")
    return {"task_id": task.task_id, "step_id": step.step_id, "file_path": task.file_path}


@app.tool()
def get_task_file_path(task_id: str) -> dict:
    """
    Returns the absolute file path for a given task ID.
    Args:
        task_id: The task identifier
    Returns: dict: Absolute file path to the task markdown file
    """
    task = service.get_task(task_id)
    if not task:
        raise ValueError(f"Task with id {task_id} does not exist")
    return {"task_id": task_id, "file_path": task.file_path}


@app.tool()
def get_steps(since_timestamp: str = "", task_ids: list[str] | None = None) -> dict:
    """
    Retrieves all steps across all tasks with optional time and task filtering.
    Args:
        since_timestamp: Optional ISO format timestamp to filter steps from (e.g., "2025-01-01T00:00:00Z")
        task_ids: Optional list of task IDs to filter steps (e.g., ["happy-cloud-42", "gentle-wind-77"])
    Returns: dict: List of all steps, optionally filtered by time and task IDs
    """
    steps = service.get_all_steps(since_timestamp=since_timestamp)

    # Filter by task_ids if provided
    if task_ids:
        steps = [m for m in steps if m.task_id in task_ids]

    step_dicts = []
    for m in steps:
        m_dict = m.model_dump()
        m_dict["timestamp"] = m.timestamp.isoformat()
        step_dicts.append(m_dict)
    return {"steps": step_dicts, "count": len(steps)}


@app.tool(enabled=False)
def get_step(doc_id: int) -> dict:
    """
    Retrieves a specific step by its document ID.
    Args:
        doc_id: The document ID of the step to retrieve
    Returns: dict: The step data or error if not found
    """
    step = service.get_step_by_doc_id(doc_id)
    if not step:
        raise ValueError(f"Step with doc_id {doc_id} not found")
    m_dict = step.model_dump()
    m_dict["timestamp"] = step.timestamp.isoformat()
    return {"step": m_dict}
