from unittest.mock import Mock, patch

import pytest

from app.services import TimelinerService


class TestTimelinerService:
    def test_create_task(self, tmp_path):
        db_path = tmp_path / "test_db.json"
        service = TimelinerService(str(db_path))

        task = service.create_task("Test task")

        assert task.doc_id == 1
        assert task.title == "Test task"
        assert len(service.get_all_tasks()) == 1

    def test_get_task_by_id(self, tmp_path):
        db_path = tmp_path / "test_db.json"
        service = TimelinerService(str(db_path))

        created_task = service.create_task("Test task")
        retrieved_task = service.get_task_by_id(created_task.task_id)

        assert retrieved_task is not None
        assert retrieved_task.task_id == created_task.task_id
        assert retrieved_task.title == "Test task"

    def test_create_step(self, tmp_path):
        db_path = tmp_path / "test_db.json"
        service = TimelinerService(str(db_path))

        # First create a task
        task = service.create_task("Test task")

        # Then create a step for it
        step = service.create_step(task_id=task.task_id, title="Test step", outcomes="Completed the test", tags=["test", "poc"], metadata={"pr": "#123"})

        assert step.doc_id == 1

        steps = service.get_steps_by_task(task.task_id)
        assert len(steps) == 1
        assert steps[0].outcomes == "Completed the test"

    def test_generate_task_id(self, tmp_path):
        db_path = tmp_path / "test_db.json"
        service = TimelinerService(str(db_path))

        task_id = service.generate_task_id()
        assert isinstance(task_id, str)
        assert len(task_id.split("-")) == 3


class TestMCPTools:
    @patch("app.mcp.service")
    def test_create_task(self, mock_service):
        from app.mcp import task_create

        mock_task = Mock(task_id="happy-cloud-42", doc_id=1)
        mock_service.create_task.return_value = mock_task

        result = task_create.fn(task_title="Test task")

        assert result["task_id"] == "happy-cloud-42"
        mock_service.create_task.assert_called_once_with("Test task", "")

    @patch("app.mcp.service")
    def test_create_task_with_prompt(self, mock_service):
        from app.mcp import task_create

        mock_task = Mock(task_id="happy-cloud-42", doc_id=1)
        mock_step = Mock(doc_id=1)
        mock_service.create_task.return_value = mock_task
        mock_service.create_step.return_value = mock_step

        result = task_create.fn(task_title="Test task", user_prompt="Initial user prompt")

        assert result["task_id"] == "happy-cloud-42"
        mock_service.create_task.assert_called_once_with("Test task", "")
        mock_service.create_step.assert_called_once_with("happy-cloud-42", "Initial prompt", "## Initial prompt\nInitial user prompt\n", tags=["prompt"])

    @patch("app.mcp.service")
    def test_save_step_success(self, mock_service):
        from app.mcp import save_step

        mock_task = Mock(task_id="happy-cloud-42", file_path="work/docs/test.md")
        mock_step = Mock(step_id="20251003T120000.000000Z")
        mock_service.get_task.return_value = mock_task
        mock_service.create_step.return_value = mock_step

        result = save_step.fn(task_id="happy-cloud-42", title="Test step", outcomes="Test completed", tags=["test"], metadata={"commit": "abc123"})

        assert result["task_id"] == "happy-cloud-42"
        assert "step_id" in result

        mock_service.get_task.assert_called_once_with("happy-cloud-42")
        mock_service.create_step.assert_called_once()

    @patch("app.mcp.service")
    def test_save_step_task_not_exists(self, mock_service):
        from app.mcp import save_step

        # Test when task doesn't exist
        mock_service.get_task.return_value = None

        with pytest.raises(ValueError) as exc_info:
            save_step.fn(task_id="happy-cloud-42", title="Test step", outcomes="Test completed")

        assert "Task with id happy-cloud-42 does not exist" in str(exc_info.value)

    @patch("app.mcp.service")
    def test_show_task(self, mock_service):
        from app.mcp import task_show

        mock_step1 = Mock()
        mock_step1.model_dump.return_value = {"task_id": "happy-cloud-42", "outcomes": "First step"}
        mock_step2 = Mock()
        mock_step2.model_dump.return_value = {"task_id": "happy-cloud-42", "outcomes": "Second step"}
        mock_steps = [mock_step1, mock_step2]
        mock_service.get_steps_by_task.return_value = mock_steps

        result = task_show.fn("happy-cloud-42")

        assert result["task_id"] == "happy-cloud-42"
        assert len(result["steps"]) == 2
        assert result["steps"][0]["outcomes"] == "First step"
        assert result["steps"][1]["outcomes"] == "Second step"

    @patch("app.mcp.service")
    def test_list_tasks(self, mock_service):
        from app.mcp import task_list

        mock_task1 = Mock(task_id="happy-cloud-42", title="First task", doc_id=1)
        mock_task2 = Mock(task_id="sunny-sky-99", title="Second task", doc_id=2)
        mock_task1.model_dump.return_value = {"task_id": "happy-cloud-42", "title": "First task", "doc_id": 1}
        mock_task2.model_dump.return_value = {"task_id": "sunny-sky-99", "title": "Second task", "doc_id": 2}
        mock_tasks = [mock_task1, mock_task2]
        mock_service.get_all_tasks.return_value = mock_tasks

        result = task_list.fn()

        assert len(result["tasks"]) == 2
        assert result["tasks"][0]["task_id"] == "happy-cloud-42"
        assert result["tasks"][1]["task_id"] == "sunny-sky-99"

    @patch("app.mcp.service")
    def test_generate_task_id(self, mock_service):
        from app.mcp import generate_task_id

        mock_service.generate_task_id.return_value = "happy-cloud-42"

        result = generate_task_id.fn()

        assert result["task_id"] == "happy-cloud-42"
