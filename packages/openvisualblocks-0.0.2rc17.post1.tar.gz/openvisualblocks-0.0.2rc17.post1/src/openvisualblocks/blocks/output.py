class Output:
    def __init__(self, name: str, dtype: type):
        self.name = name
        self.dtype = dtype