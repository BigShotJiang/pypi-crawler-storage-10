#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2025 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Base Backend
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Optional, Union

# Type aliases
ParamValue = Optional[Union[bool, int, float, str]]
NodeId = Optional[int]

class BaseBackend(ABC):
    """Abstract base class defining the backend communication interface."""

    def __init__(self) -> None:
        """Initialize the base backend."""

    @abstractmethod
    def subscribe(self, topic: str, callback: Callable, node_id: NodeId = None) -> None:
        """Subscribe to messages from a given topic."""

    @abstractmethod
    def read_param(self, param_name: str, node_id: NodeId) -> ParamValue:
        """Read a parameter from the node."""

    @abstractmethod
    def write_param(self, param_name: str, value: Any, node_id: NodeId) -> ParamValue:
        """Write a parameter value to the node."""

    @abstractmethod
    def get_info(self, node_id: int) -> dict:
        """Get node information (software/hardware versions, UID, etc.)."""

    @abstractmethod
    def register_periodic_publisher(self, topic: str, field: str, frequency: float = 10.0) -> None:
        """Register a periodic message publisher."""

    @abstractmethod
    def update_periodic_publisher(self, topic: str, field: str, value: Any) -> None:
        """Update value for an existing periodic publisher."""

    @abstractmethod
    def tick(self, dt: float) -> None:
        """Perform backend-specific periodic tasks."""
