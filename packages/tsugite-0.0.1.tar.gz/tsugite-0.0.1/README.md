# [![](https://badge.fury.io/py/tsugite.svg)](https://pypi.org/project/tsugite/) Tsugite

A system-oriented dashboard for Cyphal (CAN + UDP) & DroneCAN (from YAML) that renders live panels from a YAML manifest—so you watch the system, not just the bus.

## Why this exists

Most tools are **bus-oriented** (frames/subjects). Field work needs **system-oriented** views:
- “Is my **VTOL** healthy? Which **nodes** are missing? Are **critical topics** alive?”
- “Can the **phone** in my pocket show a health dashboard over Wi-Fi?”

Tsugite answers with:
- A **YAML system manifest** that defines your expected nodes, roles, and topics.
- A **backend** that speaks Cyphal & DroneCAN.
- One or more **frontends** (desktop PySide6, and maybe something else in future) that render system health.

## Usage

```bash
pip install .[all]

tsugite --help
```

## MVP scope (what we build first)

- ✅ **Transports**: SocketCAN/slcan (Linux/Win/macOS where possible), UDP (Cyphal).
- ✅ **Protocols**: Cyphal, DroneCAN.
- ✅ **System manifest** (YAML): expected nodes, panels, widgets, topics.
- ✅ **Node list** with heartbeat/health/uptime/firmware/5v/vin/temperature/bootloader.
- ✅ **Safe mode**: read-only; guardrails for publishing/param writes (disabled in MVP by default).
- ✅ **Paramters editor**: read-only; guardrails for publishing/param writes (disabled in MVP by default).
- ✅ **Specification checker**.
