# Development

## Prerequisites
- Python 3.10+
- flit (for build/publish). Install with:
```sh
python -m pip install -U flit
```


## Pulling the project
```sh
git clone https://github.com/anptrs/flextex.git
cd flextex
```


## Editable install (project root)
First install with editable option (run from project's root, flextex dir)
```sh
$ flit install --symlink
```
This lets you edit the module without reinstalling and enables tests to import the local package.
Alternatively, without flit:
```sh
python -m pip install -e .
```


# Testing
Run tests from project's root:
```sh
$ python -m pytest
```
To get a coverage (with branches) report, execute the following in the terminal (we aim for 100% coverage in `core.py`):
```sh
$ python -m coverage run --branch -m pytest
$ python -m coverage html -i
```
This will run the tests and generate an HTML coverage report.
- `-i` flag is necessary because the tests use compile/eval features of the template engine and _coverage_ will fail to generate the report while trying to find sources for those ephemeral test template expressions.
- The tests use `drawch` library to colorize the error messages. The tests will still run fine without it, but the error messages will be much less readable (as they will contain style tags).

## Release (maintainers)
```sh
# Build
flit build
# Publish to PyPI
flit publish
```

## Project Status
- Fully functional and stable.
- Tests provide 100% statement and branch coverage in `src/core.py`.

## Notes

- Template's expression compilation cache (if your template uses Python expressions) is attached to the AST nodes that use expressions. This means that in the extremely rare case where two threads evaluate exactly the same expression (AST node) for the _first time_ concurrently, the expression may be compiled more than once. This is harmless and not a correctness issue. Subsequent evaluations of the same expression from any thread will use the cached bytecode. Locking the cache updates would cost more performance-wise than the extreme rarity of a harmless double compilation event, so this is more than an acceptable trade-off.
