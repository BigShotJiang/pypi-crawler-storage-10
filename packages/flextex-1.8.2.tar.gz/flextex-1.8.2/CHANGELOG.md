# Changelog

All notable changes to this project are documented here.
This project follows Keep a Changelog and Semantic Versioning.

## [Unreleased]
### Added
-
### Changed
-
### Fixed
-

## [1.8.1] - 2025-10-30
Initial public release.

### Added
- Examples and initial documentation.

### Changed
- Interface cleanup and ergonomics improvements.

### Fixed
-

### Testing/Tracing
- Achieved 100% statement and branch coverage.

[Unreleased]: https://github.com/anptrs/flextex/compare/v1.8.1...HEAD
[1.8.1]: https://github.com/anptrs/flextex/releases/tag/v1.8.1
