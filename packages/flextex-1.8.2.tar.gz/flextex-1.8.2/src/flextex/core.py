# Copyright (c) 2025 Anton Petersen
# SPDX-License-Identifier: MIT
# This file is part of the Flextex project.
# Licensed under the MIT License. See LICENSE file in the project root for full license information.

# pylint: disable=line-too-long,too-many-lines,missing-function-docstring,multiple-statements
# pylint: disable=too-few-public-methods,too-many-statements
"""Text template engine with branching, loops, macros, and expressions."""
from collections.abc import Iterable, Mapping, MutableMapping, Sequence
from functools import partial
from typing import Any, Callable, Union

from parsek import Parser, In, Not, Val, add_static

INDENT = 4      # Default structural indent size
NOEVAL = False  # Global flag to disable expression evaluation (for safe builds)

_NO_SUB = object()  # Sentinel for no substitution found
_NoOpener = type('_NoOpener', (), {})  # Sentinel for no opener
_NoCloser = type('_NoCloser', (), {})  # Sentinel for no closer

def set_indent(indent: int | None) -> int:
    """ Set global INDENT. Returns previous value.
    Args:
        indent (int|None):
            - If None, leaves INDENT unchanged. returns current value.
            - If int, sets INDENT to given value (must be >=0).
    """
    global INDENT  # pylint: disable=global-statement
    ret = INDENT
    if indent is not None:
        try:
            indent = int(indent)
            if indent < 0:
                raise ValueError()
        except ValueError:
            raise ValueError(f"Invalid indent value: {indent!r} - must be non-negative integer") from None
        INDENT = indent
    return ret

def set_noeval(noeval: bool|None) -> bool:
    """ Set global NOEVAL flag. Returns previous value.
    Args:
        noeval (bool|None):
            - If None, leaves NOEVAL unchanged. returns current value.
            - If `True` disables eval() in all templates.
            - If `False` enables eval() globally; you can still disable per template eval(). (default)
    """
    global NOEVAL  # pylint: disable=global-statement
    ret = NOEVAL
    if noeval is not None:
        NOEVAL = bool(noeval)
    return ret

def is_identifier(s: str) -> bool:
    """ Check if the given string a python identifier."""
    return s.isidentifier()

def is_renderer(obj):
    """ Check if the object is a renderer. """
    return hasattr(obj, 'render_text') and callable(obj.render_text)

def dedent_max(text: str, max_spaces: int) -> str:
    """ Remove up to `max_spaces` leading spaces from each line (except first) in `text`."""
    if not text or max_spaces <= 0:
        return text
    r = []
    r.append(next(it := iter(text.splitlines(keepends=True))))  # skip first line
    for line in it:
        if (len(line) - len(stripped := line.lstrip(' '))) > max_spaces:
            stripped = line[max_spaces:]
        r.append(stripped)
    return "".join(r)

def dedent_min_max(text: str, min_spaces: int, max_spaces: int) -> str:
    """ Remove leading spaces from each line (except first) in `text`. Non empty line
    with least leading spaces is the reference line that dictates how many spaces to remove:

    - If reference line has less than `max_spaces`, remove leading spaces for all
      lines, down to at most min_spaces
    - Otherwise remove leading spaces for all lines down to at most spaces reference line has.
    """
    if not text or min_spaces < 0 or max_spaces <= 0:
        return text
    n_spaces = None
    next(it := iter(text.splitlines()))  # skip first line
    # find the least leading spaces across all non-empty line
    for line in it:
        if (stripped := line.lstrip(' ')):
            leading = len(line) - len(stripped)
            n_spaces = leading if n_spaces is None else min(n_spaces, leading)
    return dedent_max(text, min_spaces if n_spaces is not None and n_spaces < max_spaces else max_spaces)

def find_substitution(name: str, subs: tuple[dict, ...]):
    """ Find a substitution by name in a tuple of dictionaries. Returns _NO_SUB if not found. """
    return next((v for sub in subs if sub and (v := sub.get(name, _NO_SUB)) is not _NO_SUB), _NO_SUB)

@add_static('files_', None)
def load_source(name: str, pos: int, ctx: '_Context') -> str | None:
    """ Load external source by name. Return None if not found. """
    if name.startswith(("data:", "module:", "package:", "resource:")):
        if load_source.files_ is None: # lazy import
            from importlib.resources import files #pylint: disable=import-outside-toplevel
            load_source.files_ = files
        scheme, _, path = name.partition(':')
        if path.startswith("//"):  # trim leading two slashes if any
            path = path[2:]
        anchor, _, resource = path.partition('/')
        if not resource:
            raise FlextexError(f"Import of {name!r} failed: Must specify both module and"
                               f" resource, e.g. '{scheme}://module.sub-module/resource.txt'", pos, ctx)
        try:
            return load_source.files_(anchor).joinpath(resource).read_text()
        except Exception as e: # pylint: disable=broad-except
            raise FlextexError(f"Import of {name!r} failed", pos, ctx) from e

    if (is_file := name.startswith("file://")):
        name = name[7:]
    elif (is_file := name.startswith("file:")):
        name = name[5:]
    try:
        with open(name, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e: # pylint: disable=broad-except
        if is_file:
            raise FlextexError(f"Import of {name!r} failed", pos, ctx) from e
    return None  # not found

def offset_to_row_col_line(source: str, offset: int) -> tuple[int, int, str]:
    """ Convert a character offset into a (row, col, line) tuple (1-based).
        Returned source line will contain underline character at the offset position. """
    lines = source.splitlines(keepends=True) if source and offset >= 0 else []
    total = 0
    for idx, line in enumerate(lines):
        if offset < (next_total := total + len(line)):
            row, col = idx + 1, offset - total + 1
            return row, col, (line := line.rstrip('\n\r'))[:col] + ('\u0332' if line else '') + line[col:]
        total = next_total
    if lines:
        return len(lines), len(line := lines[-1].rstrip('\n\r')) + 1, line + ('\u0332' if line else '')
    return 1, offset + 1, ""

def alpha_index(idx: int) -> str:
    """Convert 0-based idx to spreadsheet-style letters (A, B, ..., Z, AA, AB, ...)."""
    idx = to_int(idx, 'alpha()')
    chars = []
    while True:
        idx, rem = divmod(idx, 26)
        chars.append(chr(ord('A') + rem))
        if idx == 0:
            return ''.join(reversed(chars))
        idx -= 1

def cardinal(n: int, sep: str = ' ') -> str:
    """Convert an integer to its spelled-out English form in lowercase.
       Examples: 0->'zero', 21->'twenty one', -7->'minus seven'
       Use sep='_' to get 'twenty_one'.
    """
    n = to_int(n, 'cardinal()')

    ones = ('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine')
    teens = ('ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen',
             'sixteen', 'seventeen', 'eighteen', 'nineteen')
    tens = ('', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety')
    scales = ((10**12, 'trillion'), (10**9, 'billion'), (10**6, 'million'), (1000, 'thousand'))

    def chunk_to_words(x: int) -> list[str]:
        parts: list[str] = []
        if x >= 100:
            parts.append(ones[x // 100])
            parts.append('hundred')
            x %= 100
        if x >= 20:
            parts.append(tens[x // 10])
            if x % 10:
                parts.append(ones[x % 10])
        elif x >= 10:
            parts.append(teens[x - 10])
        elif x > 0:
            parts.append(ones[x])
        return parts

    if n == 0:
        return 'zero'
    words = []
    if n < 0:
        words.append('minus')
        n = -n
    for value, name in scales:
        if n >= value:
            words.extend(chunk_to_words(n // value))
            words.append(name)
            n %= value
    if n > 0:
        words.extend(chunk_to_words(n))
    return sep.join(words)


def ordinal(n: int) -> str:
    """ Return ordinal string for an integer (1 -> '1st', 2 -> '2nd', etc.)."""
    n = to_int(n, 'ordinal()')
    return str(n) + ('th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th'))

def roman(n: int) -> str:
    """ Return Roman numeral for n in 1..10,000+ range. For lower case simply call `lower()` on the result."""
    n = to_int(n, 'roman()')
    val = [(10000, 'X̄'), (9000, 'C̄M̄'), (5000, 'M̄'), (1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
        (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'), (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')]
    r = ""
    for (a, rom) in val:
        while n >= a:  r += rom;  n -= a
    return r

def render_inline_list(items, separator=", ", serial_comma=True, conjunction="and"):
    """ Return a string with list items joined using simple serialization. """
    if not (n := len(items := list(items))): # pylint: disable=superfluous-parens
        return ""
    if n == 1:
        return str(items[0])
    if n == 2:
        return f"{items[0]} {conjunction} {items[1]}"
    if serial_comma:
        return f"{separator.join(map(str, items[:-1]))}{separator}{conjunction} {items[-1]}"
    return f"{separator.join(map(str, items[:-2]))}{separator}{items[-2]} {conjunction} {items[-1]}"

def render_value(value, depth: int | None):
    """ Render a value of supported types to a string. """
    if not isinstance(value, str):
        if value is None:
            value = ""
        elif is_renderer(value):
            value = value.render_text(depth=depth)
        elif callable(value):
            value = render_value(value(), None)
        elif hasattr(value, '__iter__'):
            value = OLRenderer(value, item_format='{li}',
                               separator=render_inline_list if depth is None else None).render_text(depth=depth)
        else:
            value = str(value)
    if depth is not None:
        value = "\n" + "".join(f"{' ' * depth}{line}" for line in value.splitlines(keepends=True))
    return value

def to_int(v, label: str | None = None) -> int:
    """ Convert a value to integer, raising TypeError if not possible. """
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        if v.is_integer():
            return int(v)
        raise TypeError(f"{f'{label} ' if label else ''}expected integer value, got non-integer float: {v!r}")
    if isinstance(v, str):
        try:
            return int(v)
        except ValueError as ve:
            raise TypeError(f"{f'{label} ' if label else ''}expected integer value, got string: {v!r}") from ve
    raise TypeError(f"{f'{label} ' if label else ''}expected integer value, got {type(v).__name__}: {v!r}")

def to_list(items: Any) -> list:
    """ Convert a value to a renderable list used by ol/ul/foreach """
    if items is None:
        return []
    if isinstance(items, str):
        return [items]

    def to_li(li):
        if isinstance(li, (str, NestedList)):
            return li
        if li is None:
            return ''
        if isinstance(li, list): # We have to limit to strictly lists here
            return NestedList(None, list(map(to_li, li)))
        if isinstance(li, Mapping):
            if 'header' in li: # we accept 'header': ..., 'body'|'items': nested_items
                if body := li.get('body', li.get('items')):
                    return NestedList(to_li(li['header']), list(map(to_li, body)))
                return to_li(li['header'])
        if callable(li):
            return to_li(li())
        return li
    return list(map(to_li, items() if callable(items) else items))

class NestedList:
    """ Nested list structure with a header and items. """
    __slots__ = ('header', 'items', )
    def __init__(self, header: str | None, items: list):
        self.header = header
        self.items = items
    def __bool__(self):             return bool(self.items)
    def __str__(self):              return self.header
    # Sequence protocol
    def __len__(self):              return len(self.items)
    def __getitem__(self, idx):     return self.items[idx]
    def __iter__(self):             return iter(self.items)
    def __contains__(self, value):  return value in self.items


Sourceable = Union[str, bytes, 'Source', tuple[str, str | bytes]]

class Source():
    """ Representation of an import source, e.g., a file or a substitution """
    __slots__ = ('name','data','import_pos')
    def __init__(self, name: str| None, data: str | bytes = None, import_pos: int = None):
        self.name = None # name of the source, e.g, file-name, or None for unnamed sources
        self.data = data # source data/text
        # offset in source data/text of the import directive in the __previous__ source,
        # None if this is the root source:
        self.import_pos  = import_pos
        if name is not None: # not root?
            self.name = name.strip()
            if not self.name:
                raise FlextexError("Expected import source name, but none was provided")
        if data is not None:
            if isinstance(data, bytes):
                self.data = data.decode('utf-8')
            elif not isinstance(data, str):
                self.data = str(data)  # try convert to string

    def __repr__(self):
        return f"Source(name={self.name!r}, import_pos={self.import_pos})"

    @staticmethod
    def from_any(v: Sourceable | None) -> 'Source':
        if isinstance(v, str): # most used case
            return Source(name=None, data=v)
        if isinstance(v, Source):
            return v
        if isinstance(v, bytes):
            return Source(name=None, data=v.decode('utf-8'))
        if isinstance(v, Sequence) and len(v) == 2 and isinstance(name := v[0], str)\
            and isinstance(data := v[1], (str, bytes)):
            return Source(name=name, data=data.decode('utf-8') if isinstance(data, bytes) else data)
        if v is None:
            return Source(name=None)
        return Source(name=None, data=str(v)) # try converting to string


class _Context:
    """ Evaluation Context """
    __slots__ = ('subs', 'sources', 'noeval')
    def __init__(self, subs: tuple = None, sources: Source = None, noeval: bool = False):
        self.subs = subs
        self.noeval = noeval

        if sources is None:
            self.sources = tuple()
        elif isinstance(sources, Source):
            self.sources = (sources, )
        else:
            assert isinstance(sources, Iterable) and not isinstance(sources, (str, bytes)),\
                   "`source` should be iterable"
            assert all(isinstance(s, Source) for s in sources), "All sources must be of type Source"
            self.sources = tuple(sources)
    def __repr__(self):
        return f"_Context(subs={self.subs}, sources={self.sources}, noeval={self.noeval})"
    @property
    def source(self) -> Source:
        """ Return current source. """
        return self.sources[0] if self.sources else None
    @property
    def source_data(self) -> str | None:
        """ Return current source data. """
        return self.source.data if self.source else None

    def with_subs(self, subs: dict | tuple | list):
        """ Return new context with additional substitutions. """
        if isinstance(subs, (tuple, list)):
            return _Context((*subs, *self.subs), self.sources, self.noeval)
        assert isinstance(subs, dict), "`subs` must be a dictionary, list, or tuple"
        return _Context((subs, *self.subs), self.sources, self.noeval)

    def with_source(self, source: Source):
        """ Return new context with additional source. """
        return _Context(self.subs, (source, *self.sources), self.noeval)

class _Offset(int):
    """ An offset from a position in the source text. """

class FlextexError(Exception):
    """ Flextex exception with context information.

    Attributes:
        message (str): The error message.
        pos (int, optional): The position in the source text where the error occurred.
        source (Any, optional): The source text related to the error.

    """
    def __init__(self, message: str, pos: int = None, source: str | Source | tuple[Source] | _Context= None):
        self.message = message
        self.pos = pos.pos if pos is not None and hasattr(pos, 'pos') else pos # extract from node if given
        if isinstance(source, _Context):
            source = source.sources
        elif source is None:
            source = ()
        elif isinstance(source, Source):
            source = (source, )
        elif isinstance(source, str):
            source = (Source(None, source), )
        else:
            assert isinstance(source, tuple), "Invalid `source` type"
            assert all(isinstance(s, Source) for s in source), "All sources must be of type Source"
        self._sources = source
        super().__init__(message)

    @property
    def source(self) -> str | None:
        return self._sources[0].data if self._sources else None

    @property
    def source_name(self) -> str | None:
        return self._sources[0].name if self._sources else None

    def __str__(self):
        msg = self.message
        if self.pos is not None and self.source is not None:
            row, col, line = offset_to_row_col_line(self.source, self.pos)
            msg += f"\n<{self.source_name if self.source_name else 'template'}>:{row}:{col}: `{line}`"
        for i,s in enumerate(self._sources[1:] if self._sources else []):
            row, col, line = offset_to_row_col_line(s.data, self._sources[i].import_pos or 0)
            msg += f"\nImported from <{s.name if s.name else 'template'}>:{row}:{col}: `{line}`"
        if self.__cause__ is not None:
            msg = f"{msg}\nCause: {self.__cause__}"
        return msg

    def set_pos(self, pos):
        self.pos = (self.pos + pos) if isinstance(self.pos, _Offset) and pos is not None else pos
        return self

    def set_sources(self, pos: int, sources: tuple[Source] ):
        assert sources is None or isinstance(sources, tuple), "Invalid `sources` type"
        self._sources = sources
        return self.set_pos(pos)

class SubNotFoundError(KeyError):
    """ Exception raised when a substitution is not found. """
    def __str__(self):
        return f"Substitution '{self.args[0]}' not found"

class OLRenderer:
    """ Ordered list renderer with nested lists support """

    class Index:
        """Hierarchical index for nested list items, e.g. (0, 1, 2) for '1.b.iii'"""
        __slots__ = ('_index',)
        def __init__(self, index: tuple[int, ...]=tuple()):
            self._index = index
        @property
        def levels(self):
            return len(self._index)
        def append(self, n: int) -> 'OLRenderer.Index':
            return OLRenderer.Index(self._index + (n,))

        @staticmethod
        @add_static('cache_', {})
        def _parse_spec(s: str):
            if in_cache := (cache_ := OLRenderer.Index._parse_spec.cache_).get(s):
                return in_cache
            @Parser.subroutine
            def spec(p: Parser, r): # ~? ..SPEC... OR  ..SPEC..`  OR  `..BULLET..`...
                fs = {'pad': 1}
                p.if_.one(p.EOF).end.endif.if_.one('|').endif.\
                  if_.one("~", (fs, 'suppress', lambda _: True)).endif.\
                  if_.zero_or_more(Not(In("AaIiRr0`" + p.EOF)), (fs, 'prefix')).endif.\
                  if_.one_or_more('0', (fs, 'pad', lambda _: 1)).\
                      one(In("Ii"), (fs, 'f'), nomatch="Expected 'I' or 'i'").\
                  elif_.one('`').zero_or_more(Not(In('`' + p.EOF)), (fs, 'bullet')).\
                        one('`', nomatch="Expected closing ` for bullet").\
                  else_.one(In("AaIiRr"), (fs, 'f'), nomatch="Expected format specifier (A/a/I/i/R/r)").endif.\
                  zero_or_more(Not(In("|~AaIiRr0`" + p.EOF)), (fs, 'suffix')).do(r.append, fs)
                return True
            Parser(s).zero_or_more(spec, r := [])
            cache_[s] = r
            return r
        def __format__(self, spec: str) -> str:
            # spec string, e.g. "A.a-I" -> upper-alpha.lower-alpha-decimal
            # Per-level format tokens:
            #   - A/a: alphabetic index (A,B,...) / (a,b,...)
            #   - I/i: decimal (1-based / 0-based); prefix with '0' to enable zero-padding
            #   - R/r: Roman numerals (I,II,...) / (i,ii,...)
            #   - `...`: bullet literal for this level (e.g., `*`, `-`, or `` for none)
            #   - ~: suppress this level when deeper levels exist; otherwise render it
            #   - '|' stops this level's index spec
            #   - Any other chars are copied verbatim and attach to the preceding element.
            #     Example: "A.a" yields "A." at top level, "A.a" for nested items.
            # Repetition:
            #   If fewer spec parts than levels, repeat the last part.
            if not spec:
                spec = "I." # Default: 1-base index with period, producing: '1.2.3.'

            if len(parts := self._parse_spec(spec)) < len(self._index):
                parts += [parts[-1]] * (len(self._index) - len(parts)) # Repeat last specifier
            out = ''
            for i, (idx, fmt) in enumerate(zip(self._index, parts)):
                if fmt.get('suppress') and i < len(self._index) - 1:
                    continue # suppress if there a more indexes after this one
                out += fmt.get('prefix', '')
                match fmt.get('f'): # one of A,a,I,i,X,x
                    case "A":   out += alpha_index(idx)
                    case "a":   out += alpha_index(idx).lower()
                    case "I":   out += str(idx + 1).zfill(fmt.get('pad', 0))
                    case 'i':   out += str(idx).zfill(fmt.get('pad', 0))
                    case "R":   out += roman(idx + 1)
                    case "r":   out += roman(idx + 1).lower()
                    case  _ :
                        if bullet := fmt.get('bullet'):
                            out += bullet
                out += fmt.get('suffix', '')
            return out

    __slots__ = ('items', 'item_format', 'nested_indent', 'separator')
    def __init__(self, items: list, item_format: str = None, nested_indent: int | str = '  ',
                 separator: str|Callable[[list[str]], str] = None):
        self.items = items
        self.item_format = item_format
        self.nested_indent = nested_indent
        if isinstance(nested_indent, int):
            nested_indent = max(nested_indent, 0)
            self.nested_indent = ' ' * nested_indent
        if not isinstance(nested_indent, str):
            self.nested_indent = '  ' # default 2-space indent for nested lists
        self.separator = separator

    def render_text(self, depth: int = None) -> str:
        item_format = ("({i:I|.I}) {li}" if depth is None else "{i} {li}") if not self.item_format else self.item_format
        separator = self.separator if self.separator is not None else (", " if depth is None else "\n")
        return self._render_list(self.items, depth, item_format, separator, self.nested_indent)

    @staticmethod
    def _render_list(items, depth, item_format, joiner, nested_indent, index=None):
        """ Render the list items with the given depth and item format. """
        count = len(l := to_list(items))
        output = []
        index = OLRenderer.Index() if index is None else index
        indent = nested_indent * index.levels if depth is not None else ''
        for i, item in enumerate(l):
            if isinstance(item, NestedList):
                output.append(indent + item_format.format(n=count, i=index.append(i), I=i+1,
                                li=render_value(item.items if item.header is None else item.header, None) ))
                if item.header is not None:
                    output.append(OLRenderer._render_list(item.items, depth, item_format,
                                                          joiner, nested_indent, index.append(i)))
            else:
                output.append(indent + item_format.format(n=count, i=index.append(i), I=i+1, li=item))
        if callable(joiner):
            return joiner(output)
        return joiner.join(output)

class ULRenderer(OLRenderer):
    """ Renderer for unordered lists. """
    def render_text(self, depth: int = None) -> str:
        item_format = ("(*) {li}" if depth is None else "- {li}") if not self.item_format else self.item_format
        separator = self.separator if self.separator is not None else (", " if depth is None else "\n")
        return self._render_list(self.items, depth, item_format, separator, self.nested_indent)

class MutableVarsDict(dict):
    """ A dictionary that allows variables to be changed through directives in the template.
    Used by 'var' directives but could be used by an adventurous user to make their subs mutable."""

class _SubsMapping(MutableMapping):
    """ A mapping for substitutions used by evaluation contexts. """
    __slots__ = ('subs', )
    def __init__(self, subs):
        self.subs = subs

    def __getitem__(self, key):
        for d in self.subs:
            if d and (found := d.get(key, _NO_SUB)) is not _NO_SUB:
                return found
        if key == 'outer':
            return self.outer
        raise SubNotFoundError(key)

    def __setitem__(self, key, value):
        for d in self.subs:
            if d and key in d:
                if isinstance(d, MutableVarsDict):
                    d[key] = value
                    return
                raise ValueError(f"variable {key!r} is not mutable")
        raise SubNotFoundError(key)

    def __delitem__(self, key):
        # NOTE: Python converts ANY Exception thrown here to NameError(key)
        for d in self.subs:
            if d and key in d:
                raise ValueError(f"variable/substitution {key!r} cannot be deleted")
        raise SubNotFoundError(key)

    def __iter__(self):
        seen = set()
        for d in self.subs:
            for k in d or {}:
                if k not in seen:
                    seen.add(k)
                    yield k

    def __len__(self):
        seen = set()
        for d in self.subs:
            if d: seen.update(d)
        return len(seen)

    def outer(self, key, level=1):
        level = max(0, level)
        for d in self.subs:
            if d and (found := d.get(key, _NO_SUB)) is not _NO_SUB:
                if level == 0:
                    return found
                level -= 1
        raise SubNotFoundError(key)


class _Node: # Base class for syntax nodes & tokens
    __slots__ = ('depth','pos')
    def __init__(self, depth: int = None):
        self.depth = depth # if None then the Node is a span,
        self.pos = None # position in the source text, used for error reporting

    def __bool__(self):
        return True

    def __repr__(self):
        return f"{self.__class__.__name__}(depth={self.depth}, pos={self.pos})"

    def __str__(self):
        return self.node_name()

    @classmethod
    def node_name(cls) -> str:
        """ Return the pretty name of the node class. """
        return cls.__name__[1:].lower() if cls.__name__.startswith('_') else cls.__name__.lower()

    def closed_with(self, other: '_Node') -> bool:
        """ Check if this node is a matching opener/closer for the other node. """
        return self.closer == other.__class__ # or self.closer == other.opener

    @property
    def opener(self):  return _NoOpener

    @property
    def closer(self):  return _NoCloser

    @property
    def is_span(self) -> bool:
        """ Check if the node is a span, i.e., depth is None """
        return self.depth is None

    @property
    def has_body(self) -> bool:
        """ Check if the node has a 'body' attribute. This also makes it a block node. """
        return hasattr(self, 'body')

    @property
    def has_non_empty_orelse(self) -> bool:
        """ Check if the node has an 'else' and it is non-empty. """
        return hasattr(self, 'orelse') and self.orelse # pylint: disable=no-member

    is_an_if       = property(lambda self: isinstance(self, _If)) # both If and Elif are considered 'an_if' nodes
    is_block_start = property(lambda self: self.is_if or isinstance(self, (_Def, _Foreach, _List)))
    is_directive   = property(lambda self: not self.is_text)

    is_def         = property(lambda self: isinstance(self, _Def))
    is_elif        = property(lambda self: isinstance(self, _Elif))
    is_else        = property(lambda self: isinstance(self, _Else))
    is_end_def     = property(lambda self: isinstance(self, _EndDef))
    is_end_foreach = property(lambda self: isinstance(self, _EndForeach))
    is_end_li      = property(lambda self: isinstance(self, _EndListItem))
    is_end_list    = property(lambda self: isinstance(self, _EndList))
    is_endif       = property(lambda self: isinstance(self, _Endif))
    is_foreach     = property(lambda self: isinstance(self, _Foreach))
    is_if          = property(lambda self: self.__class__ is _If)
    is_import      = property(lambda self: isinstance(self, _Import))
    is_li          = property(lambda self: isinstance(self, _ListItem))
    is_list        = property(lambda self: isinstance(self, _List))
    is_list_def    = property(lambda self: False) # named list definition, i.e., `{% list name %}`
    is_list_conv   = property(lambda self: isinstance(self, _ListConversion))
    is_meta        = property(lambda self: isinstance(self, _Meta))
    is_sub         = property(lambda self: isinstance(self, _Substitution))
    is_text        = property(lambda self: self.__class__ is _Text)
    is_var         = property(lambda self: self.__class__ is _Var)

    def dedent(self, base: int=0, indent: int=0, *, struct_indent:int=INDENT):
        # Dedent the node to the given base depth + indent.
        if self.depth is not None:
            if (new_depth := max(0, self.depth - base)) >= struct_indent:
                new_depth -= struct_indent
            new_depth += indent
            base = self.depth
            self.depth = new_depth
            if self.has_body and self.body: # pylint: disable=no-member
                for node in self.body:      # pylint: disable=no-member
                    node.dedent(base, new_depth, struct_indent=struct_indent)
            if self.has_non_empty_orelse:
                for node in self.orelse:    # pylint: disable=no-member
                    node.dedent(base, new_depth, struct_indent=struct_indent)

    def _compile_no_raise(self, expr: str, ctx: _Context, offset: int = 0, mode: str = 'eval'):
        if NOEVAL or ctx.noeval:
            self._raise_noeval(ctx, offset)
        return compile(expr, self.node_name(), mode)

    def _compile(self, expr: str, ctx: _Context, offset: int = 0, mode: str = 'eval'):
        if NOEVAL or ctx.noeval:
            self._raise_noeval(ctx, offset)
        src_name = self.node_name()
        try:
            return compile(expr, src_name, mode)
        except SyntaxError as e:
            pos = self._offset((offset if offset else (3 + len(src_name))) + e.offset)
            raise FlextexError(f"Failed to compile `{src_name}`: {e.msg}", pos, ctx)# pylint: disable=raise-missing-from

    def _eval(self, code, ctx: _Context, offset: int = 0):
        if NOEVAL or ctx.noeval:
            self._raise_noeval(ctx, offset, act='evaluate')
        try:
            return eval(code, {}, _SubsMapping(ctx.subs)) #pylint: disable=eval-used
        except Exception as e:
            src_name = self.node_name()
            pos = self._offset(offset if offset else (4 + len(src_name)))
            raise FlextexError(f"Failed to evaluate `{src_name}`", pos, ctx) from e

    def _convert(self, to_type, v, ctx: _Context, offset: int = 0):
        try:
            return to_type(v)
        except Exception as e:
            pos = self._offset(offset if offset else (4 + len(self.node_name())))
            raise FlextexError(f"Failed to convert `{v}` to {to_type.__name__}", pos, ctx) from e

    def _raise_noeval(self, ctx: _Context, offset: int = 0, act: str = 'compile'):
        src_name = self.node_name()
        pos = self._offset(offset if offset else (4 + len(src_name)))
        raise FlextexError(f"Failed to {act} `{src_name}`: Evaluation is disabled", pos, ctx)

    def _render(self, value, depth: int | None, ctx: _Context, offset: int = 0):
        try:
            return render_value(value, depth)
        except Exception as e:
            pos = self._offset(offset if offset else 3)
            raise FlextexError("Failed to render", pos, ctx) from e

    def _offset(self, offset: int):
        return self.pos + offset if self.pos is not None else None

class _Import(_Node): # Import/Root: {% < source > %}
    __slots__ = ('source', 'body')
    def __init__(self, *, name: str = None, source: Source = None, body: list[_Node] = None):
        super().__init__()
        if source is None:
            try:
                self.source = Source(name)
            except FlextexError as e:
                raise e.set_pos(_Offset(4))
        else:
            assert isinstance(source, Source), "`source` must be an instance of Source"
            assert name is None, "Cannot specify both `name` and `source`"
            self.source = source
        self.body = body

    @property
    def name(self):   return self.source.name
    @property
    def data(self):   return self.source.data
    @data.setter
    def data(self, value):   self.source.data = value

    def _resolve(self, ctx: _Context) -> str:
        """ Evaluate the import name and return the import contents """
        if (found := find_substitution(self.name, ctx.subs)) is not _NO_SUB:
            return self._render(found, depth=None, ctx=ctx)
        if (source := load_source(self.name, self._offset(4), ctx)) is not None:
            return source
        raise FlextexError(f"Import '{self.name}' not found", self._offset(4), ctx)

    def evaluate(self, ctx: _Context):
        self.data = self._resolve(ctx)
        self.source.import_pos = self._offset(4) # {% <...> %}
        self.body = _make_ast(_tokenize(new_ctx := ctx.with_source(self.source)), new_ctx)

class _Text(_Node): # Plain text
    __slots__ = ('text',)

    def __init__(self, text: str, depth: int = None):
        super().__init__(depth=depth)
        self.text = text

    def dedent(self, base: int=0, indent: int=0, *, struct_indent:int=INDENT):
        if self.depth is None:
            self.text = dedent_min_max(self.text, base, base + struct_indent)
        else:
            prev = self.depth
            super().dedent(base, indent, struct_indent=struct_indent)
            self.text = dedent_max(self.text, prev - self.depth)

class _If(_Node): # If
    __slots__ = ('test', 'body', 'orelse', '_evaluate')
    def __init__(self, test: str):
        super().__init__()
        self.test = test
        self.body = []    # list of nodes in the true branch
        self.orelse = []  # list of nodes in the false branch
        self._evaluate = None

    @property
    def closer(self):  return _Endif

    def evaluate(self, ctx: _Context) -> bool:
        """ Evaluate the condition and return the result as a bool. """
        if self._evaluate is None:
            if is_identifier(self.test):
                def _substitution(ctx):
                    if (found := find_substitution(self.test, ctx.subs)) is not _NO_SUB:
                        return found() if callable(found) else bool(found)
                    raise FlextexError(f"Conditional reference '{self.test}' not found", self._offset(6), ctx)
                self._evaluate = _substitution
            else: # Compile the expression
                code = self._compile(self.test, ctx)
                def _expression(ctx):
                    return self._convert(bool, self._eval(code, ctx), ctx)
                self._evaluate = _expression
        return self._evaluate(ctx)

class _Else(_Node): ... # Else branch in a condition (not in AST)

class _Elif(_If): ... # Elif branch in a condition

class _Endif(_Node): # End of an if-else condition (not in AST)
    @property
    def opener(self):  return _If

class _List(_Node): # List construction block
    __slots__ = ('name', 'body', 'nested')

    def __init__(self, name: str = None):
        super().__init__()
        self.name = name
        self.body = []  # Body of the list block
        self.nested = False
        if name is not None:
            if not is_identifier(name):
                raise FlextexError(f"Invalid list name: {name!r}"
                                   " - must be a valid Python identifier", _Offset(8))
    @property
    def is_list_def(self):   return self.name is not None
    @property
    def closer(self):  return _EndList

class _ListConversion(_Node): # List conversion (not in AST)
    __slots__ = ('body','header','items',)
    def __init__(self, body: list):
        super().__init__()
        self.body = body
        self.header = None
        self.items = []

    def append_nested(self, l: '_ListConversion'):
        self.items.append(NestedList(l.header, l.items))

class _EndList(_Node): # End of a list block (not in AST)
    @property
    def opener(self):  return _List

class _ListItem(_Node): # List item inside a _List
    __slots__ = ('body',)

    def __init__(self):
        super().__init__()
        self.body = []
    @property
    def closer(self):  return _EndListItem

class _EndListItem(_Node): # End of a list item (not in AST)
    @property
    def opener(self):  return _ListItem

class _Substitution(_Node): # Substitution: {% expr %}
    __slots__ = ('name','_evaluate')
    def __init__(self, name: str):
        super().__init__()
        self.name = name
        self._evaluate = None

    def evaluate(self, ctx) -> str:
        """ Evaluate the substitution expression and return the result as a string. """
        if self._evaluate is None:
            if is_identifier(self.name):
                def _substitution(ctx):
                    if (found := find_substitution(self.name, ctx.subs)) is not _NO_SUB:
                        return self._render(found, depth=self.depth, ctx=ctx)
                    raise FlextexError(f"Reference '{self.name}' not found", self._offset(3), ctx)
                self._evaluate = _substitution
            else: # Compile the expression
                try:
                    code = self._compile_no_raise(self.name, ctx, offset=3) # try 'eval' first
                except SyntaxError as _e:
                    # this could be statement like an assignment to a variable, e.g. "var1 = 1":
                    code = self._compile(self.name, ctx, offset=3, mode='single')
                def _expression(ctx):
                    return self._render(self._eval(code, ctx, offset=3), depth=self.depth, ctx=ctx)
                self._evaluate = _expression
        return self._evaluate(ctx)

class _Def(_Node): # Macro definition node
    __slots__ = ('name', 'args', 'body')
    def __init__(self, name: str):
        super().__init__()
        self.name = name
        self.args = None
        self.body = []  # Body of the macro, to be filled later

        parts = name.split('(', maxsplit=1)
        if len(parts) > 1:
            if not is_identifier(name := parts[0].strip()):
                raise FlextexError(f"Invalid macro name: {name!r} - must be a valid Python identifier", _Offset(7))
            self.name = name
            if (args := parts[1].strip()):
                if not args.endswith(')'):
                    raise FlextexError(f"Invalid {name!r} macro definition"
                                       " - arguments must be enclosed in parentheses", _Offset(7 + len(name)))
                args = args[:-1].rstrip()
                if args:
                    self.args = [arg.strip() for arg in args.split(',')]
                    for i, arg in enumerate(self.args, start=1):
                        if not arg:
                            raise FlextexError(f"Invalid {ordinal(i)} {name!r} macro argument"
                                               " - must not be empty", _Offset(7 + len(name)))
                        if not is_identifier(arg):
                            raise FlextexError(f"Invalid {ordinal(i)} {name!r} macro argument: {arg!r}"
                                               " - must be a valid Python identifier", _Offset(7 + len(name)))
            else:
                raise FlextexError(f"Invalid {name!r} macro definition"
                                   " - missing closing parenthesis", _Offset(7 + len(name)))
        else:
            if not is_identifier(name):
                raise FlextexError(f"Invalid macro name: {name!r} - must be a valid Python identifier", _Offset(7))

    @property
    def closer(self):  return _EndDef

class _EndDef(_Node): # End of a macro definition (not in AST)
    @property
    def opener(self):  return _Def

class _Foreach(_Node): # Foreach loop node
    __slots__ = ('items', 'body', '_evaluate')
    def __init__(self, items: str):
        super().__init__()
        self.items = items
        self.body = []
        self._evaluate = None

    @property
    def closer(self):  return _EndForeach

    def evaluate(self, ctx) -> str:
        """ Evaluate the list items expression and return the result as a list. """
        if self._evaluate is None:
            if is_identifier(self.items):
                def _substitution(ctx):
                    if (found := find_substitution(self.items, ctx.subs)) is not _NO_SUB:
                        return to_list(found)
                    raise FlextexError(f"List reference '{self.items}' not found", self._offset(11), ctx)
                self._evaluate = _substitution
            else: # Compile the expression
                code = self._compile(self.items, ctx)
                def _expression(ctx):
                    return self._convert(list, self._eval(code, ctx), ctx)
                self._evaluate = _expression
        return self._evaluate(ctx)


class _EndForeach(_Node):  # End of a foreach loop (not in AST)
    @property
    def opener(self):  return _Foreach

class _Meta(_Node):  # Meta information (not in AST)
    __slots__ = ('key', 'value')
    def __init__(self, key: str):
        super().__init__()
        self.value = None
        if len(parts := (key := key.strip()).split('=', maxsplit=1)) > 1 and is_identifier(key := parts[0].strip()):
            if not (value := parts[1].strip()):
                raise FlextexError(f"Missing value for meta key {key!r}", _Offset(9 + len(key)))
            self.value = value
        elif not is_identifier(key):
            raise FlextexError(f"Invalid meta key: {key!r} - must be a valid Python identifier", _Offset(8))
        self.key = key
        if key == 'indent': # accept only known meta keys
            try:
                self.value = INDENT if self.value is None else int(self.value)
                if self.value < 0: raise ValueError()
            except ValueError:
                raise FlextexError(f"Invalid indent value: {self.value!r} - must be non-negative integer",
                                    _Offset(9 + len(self.key))) from None
        else: raise FlextexError(f"Unknown meta key: {self.key!r}, expected 'indent'", _Offset(8))

class _Var(_Node):  # Variable declaration
    __slots__ = ('name', 'initializer', '_evaluate',)
    def __init__(self, name: str):
        super().__init__()
        self.name = name.strip()
        self.initializer = None
        self._evaluate = None
        # the name may contain an optional initializer, e.g., "a = 0", parse it out:
        if len(parts := name.split('=', maxsplit=1)) > 1:
            if not is_identifier(name := parts[0].strip()):
                raise FlextexError(f"Invalid variable name: {name!r} - must be a valid Python identifier", _Offset(7))
            self.name = name
            if not (initializer := parts[1].strip()):
                raise FlextexError(f"Missing initializer for variable {name!r}", _Offset(8 + len(name)))
            self.initializer = initializer
        else:
            if not is_identifier(name):
                raise FlextexError(f"Invalid variable name: {name!r} - must be a valid Python identifier", _Offset(7))

    def evaluate(self, ctx) -> str:
        """ Evaluate the initializer expression and return the result. """
        if self._evaluate is None:
            if not self.initializer:
                self._evaluate = lambda _subs: None  # None initializer
            elif is_identifier(self.initializer):
                def _substitution(ctx):
                    if (found := find_substitution(self.initializer, ctx.subs)) is not _NO_SUB:
                        return found
                    raise FlextexError(f"Initializer '{self.initializer}' for variable '{self.name}'"
                                       " not found", self._offset(9+len(self.name)), ctx)
                self._evaluate = _substitution
            else:  # Compile the expression
                offset = 8 + len(self.name)  # 8 for "{% var "
                code = self._compile(self.initializer, ctx, offset=offset)
                def _expression(ctx):
                    return self._eval(code, ctx, offset=offset)
                self._evaluate = _expression
        return self._evaluate(ctx)

class AST():
    """ Compiled template's node tree (AST) containing single `root` (_Import) node. """
    __slots__ = ('root', 'noeval')
    def __init__(self, root, noeval: bool = False):
        self.root = root
        self.noeval = noeval
    def __iter__(self):   yield self.root
    def __len__(self):    return 1
    def __getitem__(self, i):
        if isinstance(i, slice):
            return [self.root][i]
        if i in (0, -1):
            return self.root
        raise IndexError('AST index out of range')

class _EvalNode: # Base for node evaluation
    __slots__ = ('node', 'ctx')

    def __init__(self, node: _Node, ctx: _Context = None):
        self.node = node
        self.ctx = ctx

class _ListEval(_EvalNode): # Evaluates a list definition
    def __iter__(self):
        l = _ListConversion(self.node.body)  # host the list's body in the special List node
        _evaluate_ast([l], self.ctx, ([], None))
        yield from l.items

class _MacroEval(_EvalNode): # Evaluates a macro
    def __call__(self, *args, **kwds):
        arg_names = self.node.args or []
        n_args = len(arg_names)
        if (n_args_exp := len(args) + len(kwds)) != n_args:
            raise FlextexError(f"Macro `{self.node.name}({', '.join(arg_names)})` takes {n_args or 'no'} "
                               f"arguments, but got {n_args_exp or 'none'}", self.node._offset(7), self.ctx)
        m_args = {}
        # Assign positional arguments
        for i, value in enumerate(args):
            m_args[arg_names[i]] = value
        # Assign keyword arguments
        for k, v in kwds.items():
            if k not in arg_names:
                raise FlextexError(f"Macro `{self.node.name}({', '.join(arg_names)})` got an unexpected "
                                   f"keyword argument '{k}'", self.node._offset(7), self.ctx)
            if k in m_args:
                raise FlextexError(f"Macro `{self.node.name}({', '.join(arg_names)})` got multiple values "
                                   f"for argument '{k}'", self.node._offset(7), self.ctx)
            m_args[k] = v
        _evaluate_ast(self.node.body, self.ctx.with_subs(m_args), (r := [], None))
        if r and r[0].startswith('\n'): # macro's span/block render depends on the call site
            r[0] = r[0][1:] # remove first leading newline; will be handled in (_Substitution.evaluate)
        return "".join(r)

    def __str__(self):
        return self.__call__()


def _parse_directive(directive: str) -> _Node:
    # Return a _Node. Returns None if the directive is empty. Raises if the directive is invalid. """
    names = {'if': (_If, 1), 'else': (_Else, 0), 'elif': (_Elif, 1), 'endif': (_Endif, 0), '/if': (_Endif, 0),
             'foreach': (_Foreach, 1), 'for': (_Foreach, 1), 'endfor': (_EndForeach, 0),
             '/foreach': (_EndForeach, 0), '/for': (_EndForeach, 0), 'endforeach': (_EndForeach, 0),
             'list': (_List, -1), 'endlist': (_EndList, 0), '/list': (_EndList, 0),
             'li': (_ListItem, 0), 'endli': (_EndListItem, 0), '/li': (_EndListItem, 0),
             'def': (_Def, 1), 'enddef': (_EndDef, 0), 'endef': (_EndDef, 0), '/def': (_EndDef, 0),
             'meta': (_Meta, 1), 'var': (_Var, 1) }
    # Split the directive into name and arguments
    if not (parts := directive.split(maxsplit=1)):
        raise FlextexError("Empty directive", _Offset(2))
        #return None # Empty directive
    if (name := parts[0].lower()) in names:
        d_cls, arg_no = names[name]
        arg_count = len(parts) - 1
        if arg_no < 0:  # negative arg_no means the arg is optional and abs(arg_no) is the maximum number of args
            arg_no = -arg_no
        elif arg_count != arg_no:
            raise FlextexError(f"`{name}` expects {arg_no or 'no'} parameter(s), but got"
                               f" {('at least ' + str(arg_count)) if arg_count else 'none'}", _Offset(3+len(name)))
        return d_cls(*parts[1:])
    # It's either a substitution or an import
    if directive.startswith('<'):
        if not directive.endswith('>'):
            raise FlextexError("Expected closing '>' in import directive", _Offset(3+len(directive)))
        return _Import(name=directive[1:-1].strip())
    return _Substitution(directive)

class _Raises: # Functor that raises from parser routines
    __slots__ = ('ctx', 'msg',)
    def __init__(self, ctx: _Context, msg: str):
        self.ctx = ctx
        self.msg = msg

    def __call__(self, p: Parser):
        raise FlextexError(self.msg, pos=p.pos, source=self.ctx)

def tokenize(tmpl: Sourceable):
    """ Parse the source template. Returns a list of tokens ready to be assembled into an AST."""
    return _tokenize(_Context(None, Source.from_any(tmpl)))

def _tokenize(ctx: _Context):
    # Extract directives '{% ... %}', escape '{{' and '}}', and remove comments '{# ... #}'.
    # Simple job gets complicated by having to handle the spaces and newlines correctly to preserve
    # the user's intended indentation while removing the superficial structural indents
    # In fact, most of the code here is about handling the indentation and newlines correctly.
    p = Parser(ctx.source_data)
    text_ch = Not(In('\n{}' + Parser.EOF))
    nl = "\n" # new-line singleton
    r = []

    @p.subroutine # parses text until a directive or end-of-input is found
    def text(p: Parser, txt_head: Val, txt: Val, txt_tail: Val):
        r = []     # mini-tokens: '\n', text, '\n', text
        t = Val()  # text buffer
        comments = set() # indices of lines containing comments: -1, 1, 2...
        def em_txt(): # emit text from buffer
            if t: r.append(t.value); t.reset()

        while (p.zero_or_more(text_ch, acc=t).
                 if_.one('\n').do(em_txt).do(r.append, nl).            # new-line
                 elif_.one('{{').do(t.append, '{').                    # escape '{{'
                 elif_.one('}').if_.one('}').endif.do(t.append, '}').  # escape '}}'
                 elif_.one('{#', lambda _: comments.add(len(r)-1)).    # comment
                       zero_or_more(Not('#}', p.EOF)).
                       one('#}', nomatch=_Raises(ctx, "Unclosed comment block, expected `#}`")).
                 elif_.one('{', not_a_directive := Val()).one(Not('%'), not_a_directive).
                       do(t.append, not_a_directive.value).
                 else_.do(em_txt).break_.
                 endif
               ): pass
        # remove any trailing spaces
        for i in range(1, len(r)):
            if r[i] is nl and (nxt := r[i-1]) is not nl:
                r[i-1] = nxt.rstrip()
        # remove lines containing just comment(s): (c=`\n`, `\n`) or (c=`\n`, '', `\n`)
        for c in sorted(comments, reverse=True):
            if c >= 0 and r[c] is nl and (c1 := c + 1) < len(r):
                if (nxt := r[c1]) is nl:
                    del r[c1]
                elif nxt == '' and (c2 := c + 2) < len(r) and r[c2] is nl:
                    del r[c1:c2 + 1]
        # remove any empty text tokens (after rstrip); set head & tail
        # txt_head -> leading '\n  ' of the text, to set the text fragment indent
        # txt_tail -> trailing '\n  ' sets the indent of the following directive
        # txt      -> text between directives (contains both txt_head and txt_tail)
        # txt_head & txt_tail can represent the same substring, e.g., txt = '\n  ' -> txt_head=txt_tail='\n  '
        if r := [tok for tok in r if tok != '']:
            if r[0] is nl: # head: count leading spaces of next text token after '\n'
                txt_head.set(len(r[1]) - len(r[1].lstrip()) if len(r) > 1 else 0)
            if r[-1] is nl: # tail: end of r is ['\n'] or [isspace,'\n']
                txt_tail.set(0)
            elif len(r) > 1 and r[-2] is nl and r[-1].isspace():
                txt_tail.set(len(r[-1]))
        txt.set(''.join(r))
        return True

    first_block = None
    @p.subroutine
    def text_or_directive(p: Parser):
        nonlocal first_block
        directive = Val()
        d_pos = Val() # directive position in source for error reporting later
        txt_head, txt, txt_tail = Val(), Val(), Val()

        p.if_.one(text, txt_head, txt, txt_tail).endif.\
          if_.one('{%').do(d_pos.set, p.pos-2).do(directive.set, "").\
              zero_or_more(Not(p.EOF, '%}'), acc=directive).\
              one('%}', nomatch=_Raises(ctx, "Expected closing `%}`")).\
          elif_.one(p.EOF).end.endif()

        new_directive = None
        prev_directive = r[-1] if r and r[-1].is_directive else None

        if directive.is_str: # no directive is only at the end of input
            try: # parse the directive into a corresponding node
                new_directive = _parse_directive(directive.value.strip())
                new_directive.pos = d_pos.value  # position in the source text
            except FlextexError as e:
                raise e.set_sources(d_pos.value, ctx.sources)

        if txt:
            if first_block and txt_head.is_int:
                first_block.depth = 0 # set the first block indent to 0
                first_block = None
            if txt_tail.is_int and new_directive: # trim the tail if not at the end of input
                txt.value = txt.value[:-(1+txt_tail.v)]
            if txt.value:  # Any text left after trimming?
                r.append(_Text(txt.value, depth=txt_head.v))
        elif not prev_directive and new_directive and new_directive.is_block_start:
            # no-text and no previous directive means we are at the very start of input
            first_block = new_directive # save the first block directive to set the indent later

        if new_directive:
            new_directive.depth = txt_tail.v
            r.append(new_directive)
        return True

    p.zero_or_more(text_or_directive).one(p.EOF, nomatch=_Raises(ctx, "Unexpected end of input"))
    return r

def make_ast(tokens: list[_Node], subs: dict | tuple[dict, ...] = None,
             source: str | Source | None = None, noeval: bool = False):
    """ Convert a list of tokens (e.g., result of `tokenize`) into abstract syntax tree (AST).
    **ALL** imports are processed recursively, i.e., tokenized, parsed, and the the content
    is recursively expanded until no more imports are found.
    """
    if subs is None:
        subs = tuple()
    elif not isinstance(subs, Sequence):
        subs = (subs,)
    source = Source.from_any(source)
    noeval = noeval or NOEVAL

    if (ast := _make_ast(tokens, _Context(subs, source, noeval))) and len(ast) == 1 and ast[0].is_import:
        return AST(ast[0], noeval) # return as-is if only one node and is an import
    return AST(_Import(source=source, body=ast), noeval) # wrap the AST in an import (root) node

def _make_ast(tokens: list[_Node], ctx: _Context):
    body = block = [] # `block` -> Current block (nesting level)
    blocks = [] # stack of flow control and data structures (if, elif, else, foreach, def, list)
    struct_indent = INDENT

    def push_block(new_block: _Node):
        nonlocal block, blocks
        blocks.append(new_block)
        block = new_block.body

    def pop_block(closer: _Node = None):
        nonlocal block, blocks
        if not blocks:
            raise FlextexError(f"`{closer}` without matching `{closer.opener.node_name()}`", closer, ctx)
        if not (popped := blocks.pop()).closed_with(closer):
            raise FlextexError(f"Mismatched end tag: expected `{popped.closer.node_name()}` for "
                               f"`{popped}`, but got `{closer}` instead", closer, ctx)

        if blocks:  # if there are still blocks in the stack, continue with the last
            prev_block = blocks[-1]
            block = prev_block.orelse if prev_block.has_non_empty_orelse else prev_block.body
        else:
            popped.dedent(struct_indent=struct_indent)
            block = body

    # NOTE: lists are special since closing tags {% /li %} are optional
    def pop_li():  # close previous list item if any?
        if blocks and blocks[-1].is_li:
            pop_block(_EndListItem())

    def is_inside_list() -> bool:
        # are we are inside a list block, go backwards in the blocks stack and find first _List node
        return any(b.is_list for b in reversed(blocks))

    def is_inside_nested_list_def() -> bool:
        # check if we are inside a list definition but not within a list item
        for b in reversed(blocks):
            if b.is_list_def:  return True
            if b.is_li:        return False
        return False

    for token in tokens:
        if token.is_list:
            token.nested = is_inside_nested_list_def()
            block.append(token)
            push_block(token)
        elif token.is_block_start:  # if, foreach, def, and NOT list
            block.append(token)
            push_block(token)
        elif token.is_elif:   # `elif` -> new `if` branch inside the last if's `else` branch
            pop_li()
            parent_if = blocks[-1] if blocks else None
            if parent_if is None or not parent_if.is_an_if:
                raise FlextexError("`elif` without matching `if`", token, ctx)
            if parent_if.orelse:
                raise FlextexError("`elif` inside an `else` branch", token, ctx)
            parent_if.orelse.append(token)
            push_block(token)
        elif token.is_else:
            pop_li()
            parent_if = blocks[-1] if blocks else None
            if parent_if is None or not parent_if.is_an_if:
                raise FlextexError("`else` without matching `if`", token, ctx)
            if parent_if.orelse:
                raise FlextexError("`if` already has an else branch", token, ctx)
            block = parent_if.orelse
        elif token.is_endif:
            pop_li()
            prev_if = blocks[-1] if blocks else None
            while prev_if is not None and prev_if.is_elif: # pop all elif's until we reach the if
                blocks.pop()  # pop the last flow control structure
                prev_if = blocks[-1] if blocks else None
            pop_block(token)
        elif token.is_end_foreach or token.is_end_list:
            pop_li()
            pop_block(token)
        elif token.is_end_def or token.is_end_li:
            pop_block(token)
        elif token.is_li:
            pop_li()
            if not is_inside_list():
                raise FlextexError("`li` outside of a `list` block", token, ctx)
            block.append(token)
            push_block(token)
        elif token.is_import:
            token.evaluate(ctx)
            block.append(token)
        elif token.is_meta:
            if blocks: # meta is restricted to top level, mostly for sanity
                raise FlextexError("`meta` directive outside top level", token, ctx)
            struct_indent = token.value # only one meta type right now: 'indent'
        else: # non flow control structure: text, substitution or var
            assert token.is_text or token.is_sub or token.is_var, f"Unexpected token type: {token.__class__.__name__}"
            block.append(token)

    if blocks and not blocks[-1].is_import:
        raise FlextexError(f"Unclosed `{blocks[-1].node_name()}` block", blocks[-1], ctx)
    return body

_GLOBS = {'alpha': alpha_index,
    'en_and': partial(render_inline_list, serial_comma=False, conjunction="and"),
    'en_comma_and': partial(render_inline_list, serial_comma=True, conjunction="and"),
    'en_or': partial(render_inline_list, serial_comma=False, conjunction="or"),
    'en_comma_or': partial(render_inline_list, serial_comma=True, conjunction="or"),
    'is_list': lambda v: isinstance(v, list), 'is_nested_list': lambda v: isinstance(v, NestedList),
    'cardinal': cardinal, 'ol': OLRenderer, 'ordinal': ordinal, 'roman': roman, 'ul': ULRenderer,
    'True': True, 'False': False, 'None': None,}

def evaluate_ast(ast: AST, subs: tuple[dict, ...] = None) -> str:
    """ Evaluate the AST and return the final text. """
    if subs is None:
        subs = (_GLOBS,)
    elif not isinstance(subs, Sequence):
        subs = (subs, _GLOBS,)
    else:
        subs = (*subs, _GLOBS,)

    _evaluate_ast(ast, _Context(subs, noeval=ast.noeval), (output := [], None))
    if output and output[0].startswith('\n'):
        output[0] = output[0][1:] # FIXUP: remove first leading newline, 99% of the time it is not the user's intent
    return ''.join(output)

def _evaluate_ast(ast: Iterable[_Node], ctx: _Context, state: tuple) -> str:
    # each call to _evaluate_ast gets its own 'stack' and 'scope'.
    ctx = ctx.with_subs((vars_ := MutableVarsDict(), macros := {}))
    output, list_vars = state  # Unpack the state
    l = len(output)

    def add_nl(node, add_l: int): # add a leading newline if needed
        if not node.is_span and add_l and not (first := output[-add_l]).startswith('\n'):
            output[-add_l] = '\n' + " "*node.depth + first

    for node in ast:
        if node.is_import:
            add_l = _evaluate_ast(node.body, ctx.with_source(node.source), state=(output,list_vars))
            add_nl(node, add_l)
        elif node.is_text:
            output.append(node.text)
        elif node.is_an_if:
            if (branch := node.body if node.evaluate(ctx) else node.orelse):
                add_l = _evaluate_ast(branch, ctx, state=(output,list_vars))
                add_nl(node, add_l)
        elif node.is_foreach:
            items = node.evaluate(ctx) # get the list[ListItem] to iterate over.
            if node.body and items:
                list_vars = {'items': items, 'count': len(items), 'i': -1, 'I': 0, 'item': None, 'is_last': False}
                list_ctx = ctx.with_subs(list_vars) # add the list variables to the substitutions
                add_l = 0
                for i, item in enumerate(items):
                    list_vars['item'] = item
                    list_vars['i'] = i;   list_vars['I'] = i + 1
                    list_vars['is_last'] = len(items) == i + 1
                    add_l += _evaluate_ast(node.body, list_ctx, state=(output,list_vars))
                add_nl(node, add_l)
        elif node.is_def:  # macro definition {% def my_macro(a, b) %}
            macros[node.name] = _MacroEval(node, ctx)
        elif node.is_list_def: # it's a list definition, e.g. {% list name %}
            macros[node.name] = _ListEval(node, ctx)
        elif node.is_list: # it's a list expansion, e.g. {% list %} no list name given
            if node.body:
                if node.nested: # nested list inside another list definition
                    assert list_vars and list_vars.get('__list_conv'), "Parent list conversion expected"
                    _evaluate_ast([lc := _ListConversion(node.body)], ctx, ([], None))
                    list_vars.get('__list_conv').append_nested(lc)
                else:
                    add_l = _evaluate_ast(node.body, ctx.with_subs(new_list_vars := {'i': -1, 'I': 0}),
                                          state=(output,new_list_vars))
                    add_nl(node, add_l)
        elif node.is_list_conv: # special node where we don't make text but make a list of items
            if node.body:
                new_list_vars = {'i': -1, 'I': 0, '__list_conv': node}
                _evaluate_ast(node.body, ctx.with_subs(new_list_vars), state=(header := [], new_list_vars))
                node.header = ''.join(header).strip() if header else None
        elif node.is_li: # list-item, {% li %}
            if node.body:
                list_vars['i'] += 1;   list_vars['I'] += 1
                if (list_conv := list_vars.get('__list_conv')) is not None:
                    add_l = _evaluate_ast(node.body, ctx, state=(list_item_output := [],list_vars))
                    list_conv.items.append(''.join(list_item_output))
                else:
                    add_l = _evaluate_ast(node.body, ctx, state=(output,list_vars))
                    add_nl(node, add_l)
        elif node.is_sub:
            output.append(node.evaluate(ctx))
        else:
            assert node.is_var, f"Unexpected node type: {node.__class__.__name__}"
            vars_[node.name] = node.evaluate(ctx)

    return len(output) - l  # return the length of the additional output

def precompile(tmpl: str, subs: dict | tuple[dict, ...] = None, *, noeval: bool = False):
    """ Compile the template (`tmpl`) into an abstract syntax tree (AST). That can later
    be evaluated to produce the final text output.

    Args:
        tmpl (str): The source template to compile. _Hint:_ You can directly process a
            file or resource by passing `tmpl` containing a single import directive, e.g.,
            ```python
            ast = precompile("{% <path/to/file.txt> %}", subs)   # file OR resource
            ast = precompile("{% <resource://module.sub-module/resource_name> %}", subs)
            ```
            This can also be a `Source` object where you can name the template if desired
            and name is not a file or resource. or tuple: (name, data)

        subs (dict | tuple[dict, ...], optional): _names_ (other than files or resources)
            that are used by the `import` directives in your template.
            This should be a dictionary or a tuple of dictionaries.
            If a tuple, precedence is given to the dictionaries in the order they are
            provided. Substitutions can contain simple strings, callables, or any
            other objects convertible to list, or strings.

        noeval (bool, optional): If `True`, the compiled template has eval() disabled for
            security reasons. This means that any expressions in the template that
            require evaluation will raise an error when the template is evaluated.
            Default is `False`. Note: global NOEVAL takes precedence over this argument.

    Returns:
        AST: The compiled abstract syntax tree (AST) representing the template. Use it
            with `evaluate` to produce the final rendered text output.
    """
    return make_ast(tokenize(source := Source.from_any(tmpl)), subs=subs, source=source, noeval=noeval)


def evaluate(tmpl: Sourceable|AST, subs: dict | tuple[dict, ...] = None) -> str:
    """ Compile, evaluate, and render the template (`tmpl`) into a final text output.

    Args:
        tmpl (str|AST): The source template to compile and evaluate or precompiled AST.
            _Hint:_ You can directly process a file or resource by passing `tmpl`
            containing a single import directive, e.g.,
            ```python
            txt = evaluate("{% <path/to/file.txt> %}", subs)   # file OR resource
            txt = evaluate("{% <resource://module.sub-module/resource_name> %}", subs)
            ```
            you can also pass an already compiled AST (from `precompile` or `make_ast`)
            to this function.

        subs (dict | tuple[dict, ...], optional): Substitution _names_ used in the
            template. This should be a dictionary or a tuple of dictionaries. If a tuple,
            precedence is given to the dictionaries in the order they are provided.
            Substitutions may contain simple strings, callables, or any other objects.
            If you use expressions in the template, the `subs` must contain the necessary
            context for those expressions to evaluate correctly.

    Returns:
        str: The final rendered text output.
    """
    if not isinstance(tmpl, AST):
        tmpl = make_ast(tokenize(source := Source.from_any(tmpl)), subs=subs, source=source)
    return evaluate_ast(tmpl, subs=subs)
