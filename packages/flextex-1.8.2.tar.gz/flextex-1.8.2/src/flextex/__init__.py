# Copyright (c) 2025 Anton Petersen
# SPDX-License-Identifier: MIT
# This file is part of the Flextex project.
# Licensed under the MIT License. See LICENSE file in the project root for full license information.
"""FlexTex - text template engine.

Key entry points:
- precompile / evaluate
"""
from importlib.metadata import version
__version__ = version("flextex")

from parsek import Predicate
from .core import (evaluate, precompile, AST, FlextexError, Source, set_indent, set_noeval)
