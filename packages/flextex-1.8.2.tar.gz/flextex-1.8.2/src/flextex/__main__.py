# Copyright (c) 2025 Anton Petersen
# SPDX-License-Identifier: MIT
# This file is part of the Flextex project.
# Licensed under the MIT License. See LICENSE file in the project root for full license information.
""" Main entry point for the flextex package.
Run to see available options: `python -m flextex -h`
"""
import argparse
from . import __version__

def main():
    """ Provides basic command-line interface for flextex """
    parser = argparse.ArgumentParser(
        prog="python -m flextex",
        description=f"FlexTex {__version__} - text template library\n\n"
                    "Optionally read JSON substitutions from STDIN for -e/--eval and -c/--compile.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples for piping JSON substitutions via STDIN:\n"
            "  python -m flextex -e 'Hello {% name %}' <<< '{\"name\":\"World\"}'\n"
            "  echo '{\"name\":\"World\"}' | python -m flextex -e 'Hello {% name %}'\n"
            "  cat subs.json | python -m flextex -e template.flex\n"
            "  jq -n '{\"name\":\"World\"}' | python -m flextex -e template.flex\n"
            "  (Note: <<< here-strings require bash/zsh)\n"
        ),
    )
    parser.add_argument("--version", "-V", "-v", action="store_true", help="Show version and exit")

    group = parser.add_mutually_exclusive_group()
    group.add_argument("-e", "--eval", metavar="TEMPLATE_OR_FILE",
        help="Inline template string OR path to a template file (auto wrapped as {%% <path> %%})")
    group.add_argument("-c", "--compile", metavar="TEMPLATE_OR_FILE",
        help="Compile template and report errors without rendering (auto wraps file path as {%% <path> %%})")
    args = parser.parse_args()

    if args.version:
        print(__version__)
        return 0

    if (is_eval := args.eval is not None) or args.compile is not None:
        import sys, json            # pylint: disable=import-outside-toplevel,multiple-imports
        from pathlib import Path    # pylint: disable=import-outside-toplevel
        from .core import evaluate, precompile  # pylint: disable=import-outside-toplevel

        # Read JSON substitutions from stdin if piped, else empty dict
        if not sys.stdin.isatty():
            try:
                subs = json.load(sys.stdin)
            except json.JSONDecodeError:
                subs = {}
        else:
            subs = {}

        if (p := Path(template := args.eval if is_eval else args.compile).expanduser()).is_file():
            template = f"{{% <{p}> %}}"

        try:
            if is_eval:
                print(evaluate(template, subs))
            else:
                precompile(template, subs)
                print("OK")
        except Exception as e:  # pylint: disable=broad-except
            print(e, file=sys.stderr)
            return 1
        return 0

    parser.print_help()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
