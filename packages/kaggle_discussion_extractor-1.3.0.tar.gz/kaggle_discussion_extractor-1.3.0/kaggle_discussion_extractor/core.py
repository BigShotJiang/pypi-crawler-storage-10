#!/usr/bin/env python3
"""
Kaggle Discussion Extractor - Core Module
Based on the working neurips_extractor_final.py with all functionality preserved
"""

import sys
import asyncio
import json
import re
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict

# Setup logging
logger = logging.getLogger(__name__)

# Check for playwright
try:
    from playwright.async_api import async_playwright, Page, ElementHandle
except ImportError:
    logger.error("playwright not installed. Please run: pip install playwright && playwright install chromium")
    sys.exit(1)


@dataclass
class Author:
    """Author information with ranking/badges"""
    name: str
    username: str
    rank: Optional[str] = None
    badges: List[str] = None
    profile_url: str = ""
    
    def __post_init__(self):
        if self.badges is None:
            self.badges = []


@dataclass
class Reply:
    """Represents a discussion reply with hierarchy"""
    reply_number: str  # e.g., "1", "1.1", "1.1.1"
    content: str
    author: Author
    upvotes: int
    timestamp: str
    depth: int = 0
    sub_replies: List['Reply'] = None
    
    def __post_init__(self):
        if self.sub_replies is None:
            self.sub_replies = []


@dataclass
class Discussion:
    """Complete discussion thread"""
    title: str
    url: str
    main_content: str
    main_author: Author
    main_upvotes: int
    replies: List[Reply]
    total_replies: int
    extraction_time: str


class KaggleDiscussionExtractor:
    """Main extractor class with all functionality from neurips_extractor_final.py"""
    
    def __init__(self, dev_mode: bool = False, headless: bool = True, 
                 date_format: bool = False, date_position: str = "suffix"):
        """
        Initialize the extractor
        
        Args:
            dev_mode: Enable development mode with detailed logging
            headless: Run browser in headless mode
            date_format: Include YYMMDD date in filename
            date_position: Position of date - 'prefix' or 'suffix'
        """
        self.dev_mode = dev_mode
        self.headless = headless
        self.date_format = date_format
        self.date_position = date_position
        
        # Setup logging based on mode
        log_level = logging.DEBUG if dev_mode else logging.INFO
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        if dev_mode:
            logger.info("Development mode enabled - detailed logging active")
    
    async def extract_author_info(self, element) -> Author:
        """Extract detailed author information from an element"""
        try:
            # Find author link
            author_links = await element.query_selector_all('a[href^="/"]')
            author_link = None
            username = "unknown"
            
            for link in author_links:
                href = await link.get_attribute('href')
                if href and href.startswith('/') and not any(skip in href for skip in ['/competitions/', '/discussion/', '/code/', '/datasets/']):
                    username_match = re.match(r'^/([^/]+)$', href)
                    if username_match:
                        author_link = link
                        username = username_match.group(1)
                        break
            
            if not author_link:
                return Author(name="Unknown", username="unknown")
            
            # Get author name
            name = username
            link_text = await author_link.text_content()
            if link_text and link_text.strip():
                name = link_text.strip()
            
            # Extract rank
            rank = None
            try:
                parent_html = await element.inner_html()
                rank_match = re.search(r'(\d+(?:st|nd|rd|th))\s+in\s+this\s+Competition', parent_html)
                if rank_match:
                    rank = rank_match.group(0)
            except:
                pass
            
            # Extract badges
            badges = []
            badge_spans = await element.query_selector_all('span')
            for span in badge_spans:
                text = await span.text_content()
                if text and any(badge_word in text for badge_word in ['Host', 'Expert', 'Master', 'Grandmaster']):
                    if text not in badges:
                        badges.append(text)
            
            return Author(
                name=name,
                username=username,
                rank=rank,
                badges=badges if badges else None,
                profile_url=f"https://www.kaggle.com/{username}"
            )
        except Exception as e:
            if self.dev_mode:
                logger.warning(f"Error extracting author: {e}")
            return Author(name="Unknown", username="unknown")

    async def extract_upvotes(self, element) -> int:
        """Extract upvote count from element"""
        try:
            vote_buttons = await element.query_selector_all('button[aria-label*="vote"]')
            for vote_button in vote_buttons:
                aria_label = await vote_button.get_attribute('aria-label')
                if aria_label:
                    match = re.search(r'(-?\d+)\s+votes?', aria_label)
                    if match:
                        return int(match.group(1))
            
            buttons = await element.query_selector_all('button')
            for button in buttons:
                text = await button.text_content()
                if text and re.match(r'^-?\d+$', text.strip()):
                    return int(text.strip())
        except:
            pass
        return 0

    async def extract_comment_content(self, element, author_username: str) -> str:
        """Extract only the content from this specific comment, excluding nested replies"""
        try:
            # Use JavaScript to get text content excluding nested comments
            content_text = await element.evaluate('''
                (element) => {
                    const clone = element.cloneNode(true);

                    // Remove nested comment elements
                    const nestedComments = clone.querySelectorAll('[data-testid="discussions-comment"]');
                    nestedComments.forEach(c => c.remove());

                    // Remove voting/action buttons
                    const buttons = clone.querySelectorAll('button');
                    buttons.forEach(b => b.remove());

                    return clone.textContent;
                }
            ''')

            if not content_text:
                return ""

            # Clean up the content
            import re
            text = content_text.strip()

            # Remove author/metadata prefix (everything before the actual content)
            # Pattern: "username Posted X ago • rank in Competition CONTENT"
            text = re.sub(r'^.*?(\d+(?:st|nd|rd|th))\s+in\s+this\s+Competition\s*', '', text, flags=re.IGNORECASE)

            # If that didn't work, try removing just "Posted" metadata
            if not text or len(text) < 10:
                text = content_text.strip()
                text = re.sub(r'^.*?Posted\s+\d+.*?(?:ago|minutes?|hours?|days?).*?', '', text, flags=re.IGNORECASE)

            # Split into lines
            lines = text.split('\n')
            content_lines = []

            for line in lines:
                line = line.strip()

                # Skip empty lines
                if not line:
                    continue

                # Skip pure metadata lines
                if re.match(r'^(arrow_drop|more_vert|topic author)$', line, re.IGNORECASE):
                    continue

                # Skip very short fragments
                if len(line) < 3:
                    continue

                # Accept substantial content
                if len(line) > 5:
                    content_lines.append(line)

            # If we got content, return it
            if content_lines:
                return '\n\n'.join(content_lines)

            # Last resort: if text has substantial content, return it as-is
            if text and len(text.strip()) > 10:
                return text.strip()

            return ""

        except Exception as e:
            if self.dev_mode:
                logger.warning(f"Error extracting content: {e}")
            return ""

    async def extract_hierarchical_replies(self, page: Page, skip_index: int = -1) -> List[Reply]:
        """
        Extract replies with proper content separation - no duplication

        Args:
            page: Playwright page object
            skip_index: Index of comment to skip (the main post), -1 to skip none
        """
        replies = []

        try:
            # Get ALL comment elements
            all_comments = await page.query_selector_all('div[data-testid="discussions-comment"]')

            if not all_comments:
                if self.dev_mode:
                    logger.debug("No comment elements found")
                return replies

            # Skip the main post comment by index
            if skip_index >= 0 and skip_index < len(all_comments):
                all_comments = all_comments[:skip_index] + all_comments[skip_index+1:]
                if self.dev_mode:
                    logger.debug(f"Skipping comment at index {skip_index} (main post), processing {len(all_comments)} replies")

            if self.dev_mode:
                logger.debug(f"Found {len(all_comments)} total comment elements")
            
            processed_comments = []
            
            # First pass: identify hierarchy
            for i, comment_elem in enumerate(all_comments):
                try:
                    # Check if nested using JavaScript DOM traversal
                    is_nested = await comment_elem.evaluate('''
                        (element) => {
                            let current = element.parentElement;
                            while (current) {
                                if (current.classList && 
                                    (current.classList.contains('sc-gGOevJ') || 
                                     current.classList.contains('hvAeBk'))) {
                                    return true;
                                }
                                current = current.parentElement;
                            }
                            return false;
                        }
                    ''')
                    
                    # Extract author first to get username
                    author = await self.extract_author_info(comment_elem)
                    
                    if author.username == "unknown":
                        continue
                    
                    # Extract content specific to this comment only
                    content = await self.extract_comment_content(comment_elem, author.username)

                    # Only skip if truly empty (accept even very short replies)
                    if not content or len(content.strip()) == 0:
                        if self.dev_mode:
                            logger.debug(f"Skipping comment from {author.username} - no content extracted")
                        continue
                    
                    # Extract other metadata
                    upvotes = await self.extract_upvotes(comment_elem)
                    
                    timestamp = ""
                    time_elem = await comment_elem.query_selector('span[title]')
                    if time_elem:
                        timestamp = await time_elem.get_attribute('title') or ""
                    
                    # Find parent if nested
                    parent_idx = None
                    if is_nested:
                        # Find the most recent non-nested comment as parent
                        for j in range(len(processed_comments) - 1, -1, -1):
                            if not processed_comments[j]['is_nested']:
                                parent_idx = j
                                break
                    
                    processed_comments.append({
                        'author': author,
                        'content': content,
                        'upvotes': upvotes,
                        'timestamp': timestamp,
                        'is_nested': is_nested,
                        'parent_idx': parent_idx,
                        'original_idx': i
                    })
                    
                except Exception as e:
                    if self.dev_mode:
                        logger.warning(f"Error processing comment {i}: {e}")
                    continue
            
            if self.dev_mode:
                logger.debug(f"Processed {len(processed_comments)} valid comments")
            
            # Second pass: build hierarchy
            reply_objects = []
            for data in processed_comments:
                reply = Reply(
                    reply_number="",
                    content=data['content'],
                    author=data['author'],
                    upvotes=data['upvotes'],
                    timestamp=data['timestamp'],
                    depth=0
                )
                reply_objects.append(reply)
            
            # Build parent-child relationships
            for i, data in enumerate(processed_comments):
                if data['is_nested'] and data['parent_idx'] is not None:
                    parent_reply = reply_objects[data['parent_idx']]
                    child_reply = reply_objects[i]
                    parent_reply.sub_replies.append(child_reply)
                    child_reply.depth = parent_reply.depth + 1
            
            # Get only top-level replies
            top_level_replies = []
            for i, data in enumerate(processed_comments):
                if not data['is_nested']:
                    top_level_replies.append(reply_objects[i])
            
            # Assign reply numbers with correct hierarchy
            reply_counter = 1
            for reply in top_level_replies:
                reply.reply_number = str(reply_counter)
                
                # All sub-replies of the same parent get consecutive numbers
                sub_counter = 1
                for sub_reply in reply.sub_replies:
                    sub_reply.reply_number = f"{reply_counter}.{sub_counter}"
                    sub_counter += 1
                    
                    # Sub-sub-replies get incremental numbers under their parent
                    sub_sub_counter = 1
                    for sub_sub_reply in sub_reply.sub_replies:
                        sub_sub_reply.reply_number = f"{reply_counter}.{sub_counter - 1}.{sub_sub_counter}"
                        sub_sub_counter += 1
                
                reply_counter += 1
            
            nested_count = sum(len(r.sub_replies) for r in top_level_replies)
            if self.dev_mode:
                if nested_count > 0:
                    logger.info(f"Found {len(top_level_replies)} top-level and {nested_count} nested replies")
                else:
                    logger.info(f"Found {len(top_level_replies)} top-level replies (no nested detected)")
            
            return top_level_replies
            
        except Exception as e:
            logger.error(f"Error extracting replies: {e}")
            return []

    async def extract_single_discussion(self, page: Page, url: str) -> Optional[Discussion]:
        """Extract a single discussion with all replies"""
        try:
            if self.dev_mode:
                logger.debug(f"Loading: {url.split('/')[-1]}")
            
            await page.goto(url, wait_until="networkidle", timeout=30000)
            await asyncio.sleep(3)
            
            # Get title - try multiple strategies
            title = "Unknown Title"

            # Strategy 1: Look for discussion-specific title selectors
            title_selectors = [
                'h1[data-testid="discussion-title"]',
                'h1.discussion-title',
                'h2[data-testid="discussion-title"]',
                'h2.discussion-title',
                '[data-testid*="discussion-title"]',
                'div[data-testid="discussions-topic-header"] h1',
                'div[data-testid="discussions-topic-header"] h2',
                'div[data-testid="discussions-topic-header"] h3',
                '.discussion-header h1',
                '.discussion-header h2',
                '.topic-header h1',
                '.topic-header h2'
            ]

            for selector in title_selectors:
                title_elem = await page.query_selector(selector)
                if title_elem:
                    text = await title_elem.text_content()
                    if text and text.strip() and len(text.strip()) > 5:
                        title = text.strip()
                        break

            # Strategy 2: Fallback to general selectors but filter out competition names
            if title == "Unknown Title":
                general_selectors = ['h1', 'h2', 'h3[class*="kvnevz"]', '[data-testid*="title"]']
                for selector in general_selectors:
                    title_elem = await page.query_selector(selector)
                    if title_elem:
                        text = await title_elem.text_content()
                        if text and text.strip():
                            # Filter out generic competition titles
                            clean_text = text.strip()
                            if not any(generic in clean_text.lower() for generic in [
                                'neurips', 'google code golf', 'championship',
                                'competition', 'kaggle', 'leaderboard'
                            ]) and len(clean_text) > 5:
                                title = clean_text
                                break
                            elif title == "Unknown Title":  # Keep as fallback
                                title = clean_text

            # Strategy 3: Extract from URL if still unknown
            if title == "Unknown Title" or len(title) < 5:
                url_parts = url.split('/')
                if len(url_parts) > 1:
                    discussion_id = url_parts[-1]
                    if discussion_id.isdigit():
                        title = f"Discussion {discussion_id}"
            
            # Get main post - extract from topic header area, NOT from comment elements
            # The main post is in the topic header, ALL comment elements are replies
            main_content = ""
            main_author = Author(name="Unknown", username="unknown")
            main_upvotes = 0

            # Check if this is a writeup page (different structure)
            is_writeup = '/writeups/' in url

            # Strategy 1: For writeup pages, extract content before first comment
            if is_writeup:
                if self.dev_mode:
                    logger.debug("Detected writeup page - using writeup extraction strategy")

                # Extract better title for writeups
                writeup_title = await page.evaluate('''
                    () => {
                        const headings = document.querySelectorAll('h1, h2, h3');
                        for (const h of headings) {
                            const text = h.textContent?.trim();
                            if (text && text.length > 10 && text.length < 150 &&
                                (text.toLowerCase().includes('place') ||
                                 text.toLowerCase().includes('solution'))) {
                                return text;
                            }
                        }
                        return null;
                    }
                ''')
                if writeup_title:
                    title = writeup_title

                # Get all comment elements
                all_comments = await page.query_selector_all('div[data-testid="discussions-comment"]')

                if all_comments and len(all_comments) > 0:
                    # Find the largest content div before first comment
                    writeup_html = await page.evaluate('''
                        () => {
                            const firstComment = document.querySelectorAll('[data-testid="discussions-comment"]')[0];
                            if (!firstComment) return '';

                            const commentY = firstComment.getBoundingClientRect().top;
                            let bestDiv = null;
                            let maxLength = 0;

                            // Find largest content div above comments
                            document.querySelectorAll('div').forEach(div => {
                                const rect = div.getBoundingClientRect();
                                if (rect.bottom < commentY - 30) {
                                    const text = div.textContent?.trim();
                                    if (text && text.length > maxLength && text.length > 500) {
                                        bestDiv = div;
                                        maxLength = text.length;
                                    }
                                }
                            });

                            if (!bestDiv) return '';

                            const clone = bestDiv.cloneNode(true);

                            // Remove unwanted elements
                            ['nav', 'header', 'footer', 'button', '[role="navigation"]',
                             '[class*="Navigation"]', '[class*="Menu"]',
                             '[data-testid="discussions-comment"]'].forEach(sel => {
                                clone.querySelectorAll(sel).forEach(el => el.remove());
                            });

                            return clone.innerHTML;
                        }
                    ''')

                    if writeup_html and len(writeup_html) > 100:
                        import re
                        from html import unescape

                        # Convert to markdown
                        writeup_html = re.sub(r'<a[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', r'[\2](\1)', writeup_html, flags=re.DOTALL)

                        # Headers
                        for level in range(1, 7):
                            writeup_html = re.sub(f'<h{level}[^>]*>(.*?)</h{level}>', lambda m: f'{"#" * level} {m.group(1).strip()}\n\n', writeup_html, flags=re.DOTALL)

                        # Code
                        writeup_html = re.sub(r'<pre[^>]*><code[^>]*>(.*?)</code></pre>', r'```\n\1\n```\n', writeup_html, flags=re.DOTALL)
                        writeup_html = re.sub(r'<code[^>]*>(.*?)</code>', r'`\1`', writeup_html, flags=re.DOTALL)

                        # Paragraphs and lists
                        writeup_html = re.sub(r'<p[^>]*>(.*?)</p>', r'\1\n\n', writeup_html, flags=re.DOTALL)
                        writeup_html = re.sub(r'<li[^>]*>(.*?)</li>', r'- \1\n', writeup_html, flags=re.DOTALL)
                        writeup_html = re.sub(r'<br\s*/?>', '\n', writeup_html)

                        # Remove remaining tags
                        writeup_html = re.sub(r'<[^>]+>', '', writeup_html)
                        writeup_html = unescape(writeup_html)

                        # Deduplicate and clean
                        lines = [l.strip() for l in writeup_html.split('\n')]
                        seen, unique = set(), []

                        for line in lines:
                            if not line or len(line) < 10:
                                continue
                            # Skip junk
                            if any(j in line for j in ['search', 'explore', 'emoji_events', 'expand_more', 'Kaggle uses cookies']) and len(line) < 60:
                                continue
                            # Deduplicate
                            if line not in seen:
                                seen.add(line)
                                unique.append(line)

                        main_content = '\n\n'.join(unique)

                        if self.dev_mode:
                            logger.debug(f"Extracted writeup: {len(main_content)} chars")

                # Extract author
                for comment in all_comments:
                    if 'Topic Author' in await comment.inner_html():
                        main_author = await self.extract_author_info(comment)
                        main_upvotes = await self.extract_upvotes(comment)
                        break

            # Strategy 2: Extract from discussions-topic-header (for regular discussions)
            if not main_content:
                topic_header = await page.query_selector('div[data-testid="discussions-topic-header"]')
                if topic_header:
                    main_author = await self.extract_author_info(topic_header)
                    main_upvotes = await self.extract_upvotes(topic_header)

                    # Get content from header, excluding comment elements
                    header_content = await topic_header.evaluate('''
                        (element) => {
                            const clone = element.cloneNode(true);
                            const comments = clone.querySelectorAll('[data-testid="discussions-comment"]');
                            comments.forEach(c => c.remove());
                            return clone.textContent;
                        }
                    ''')

                    if header_content:
                        lines = header_content.strip().split('\n')
                        content_lines = []

                        for line in lines:
                            line = line.strip()
                            # Skip short lines and metadata
                            if line and len(line) > 20 and not any(skip in line.lower() for skip in [
                                'posted', 'edited', 'arrow_drop', 'more_vert',
                                'in this competition', ' ago'
                            ]):
                                content_lines.append(line)

                        if content_lines:
                            main_content = '\n\n'.join(content_lines)
                            if self.dev_mode:
                                logger.debug(f"Extracted main post from topic header")

            # Strategy 3: Fallback to finding Topic Author comment (if topic header didn't work)
            if not main_content:
                all_comments = await page.query_selector_all('div[data-testid="discussions-comment"]')
                if all_comments and len(all_comments) > 0:
                    # Look for the comment with the "Topic Author" badge
                    # The badge appears in the author metadata line (first few lines of the comment)
                    for i, comment in enumerate(all_comments):
                        comment_text = await comment.text_content()
                        lines = comment_text.split('\n')

                        # Check if "Topic Author" appears in the first 3 lines (author metadata area)
                        # and not deep in the content
                        is_topic_author = False
                        for line_idx, line in enumerate(lines[:3]):
                            if 'Topic Author' in line:
                                is_topic_author = True
                                break

                        if is_topic_author:
                            main_author = await self.extract_author_info(comment)
                            main_upvotes = await self.extract_upvotes(comment)
                            main_content = await self.extract_comment_content(comment, main_author.username)

                            if self.dev_mode:
                                logger.debug(f"Found main post at comment index {i} (Topic Author fallback, user: {main_author.username})")
                            break

                    # Last resort fallback: if no "Topic Author" found, use first comment
                    if not main_content and len(all_comments) > 0:
                        comment = all_comments[0]
                        main_author = await self.extract_author_info(comment)
                        main_upvotes = await self.extract_upvotes(comment)
                        main_content = await self.extract_comment_content(comment, main_author.username)

                        if self.dev_mode:
                            logger.debug(f"Using first comment as main post (last resort)")

            # Strategy 2: Try writeup-specific selectors
            if not main_content:
                writeup_content_elem = await page.query_selector('div.sc-gVrasc div.sc-vpdSi div.sc-eTCgfj')
            else:
                writeup_content_elem = None

            if writeup_content_elem and not main_content:
                # This is likely a writeup - extract content and author separately
                content_html = await writeup_content_elem.inner_html()
                if content_html:
                    # Extract content from various HTML elements
                    import re
                    content_parts = []
                    
                    # Extract headers
                    headers = re.findall(r'<h[1-6][^>]*>(.*?)</h[1-6]>', content_html, re.DOTALL)
                    for header in headers:
                        clean_header = re.sub(r'<[^>]+>', '', header).strip()
                        if clean_header:
                            content_parts.append(f"# {clean_header}")
                    
                    # Extract paragraphs
                    paragraphs = re.findall(r'<p[^>]*>(.*?)</p>', content_html, re.DOTALL)
                    for p_content in paragraphs:
                        # Convert links to markdown
                        p_content = re.sub(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', r'[\2](\1)', p_content)
                        # Convert line breaks
                        p_content = re.sub(r'<br\s*/?>', '\n', p_content)
                        # Remove other HTML tags
                        clean_p = re.sub(r'<[^>]+>', '', p_content).strip()
                        if clean_p:
                            content_parts.append(clean_p)
                    
                    # Extract list items
                    lists = re.findall(r'<ul[^>]*>(.*?)</ul>', content_html, re.DOTALL)
                    for ul_content in lists:
                        items = re.findall(r'<li[^>]*>(.*?)</li>', ul_content, re.DOTALL)
                        for item in items:
                            clean_item = re.sub(r'<[^>]+>', '', item).strip()
                            if clean_item:
                                content_parts.append(f"- {clean_item}")
                    
                    main_content = '\n\n'.join(content_parts) if content_parts else ""
                
                # Extract author information from writeup author section
                author_elem = await page.query_selector('div.sc-jRLKYd div.sc-evzeyV')
                if author_elem:
                    main_author = await self.extract_author_info(author_elem)
                
                # Extract upvotes from writeup voting section
                vote_elem = await page.query_selector('div.sc-hpIEio div.sc-kZyiuq')
                if vote_elem:
                    main_upvotes = await self.extract_upvotes(vote_elem)
            
            # Strategy 3: Fallback to discussion-style selectors (only if we don't have content yet)
            if not main_content:
                main_selectors = [
                    'div[data-testid="discussions-topic-header"]',
                    'div[class*="topic-header"]',
                    'article:first-of-type'
                ]

                for selector in main_selectors:
                    main_elem = await page.query_selector(selector)
                    if main_elem:
                        # Only extract author if we don't have one yet
                        if main_author.username == "unknown":
                            main_author = await self.extract_author_info(main_elem)
                            main_upvotes = await self.extract_upvotes(main_elem)

                        # Extract main content - try multiple selectors
                        content_selectors = [
                            'div[class*="eTCgfj"]',
                            'div[class*="jMpVQY"]',
                            'div[class*="content"]',
                            'div.markdown-content',
                            'div.discussion-content',
                            'div[data-testid="discussion-content"]',
                            'div.sc-vpdSi',  # Common Kaggle content class
                            'div.sc-eTCgfj',  # Another common class
                            'div.post-content',
                            'div.topic-content'
                        ]

                        for content_selector in content_selectors:
                            content_elem = await main_elem.query_selector(content_selector)
                            if content_elem:
                                # Get only direct text, excluding nested comment elements
                                main_content_html = await content_elem.evaluate('''
                                    (element) => {
                                        // Clone the element
                                        const clone = element.cloneNode(true);
                                        // Remove all nested comment elements
                                        const comments = clone.querySelectorAll('[data-testid="discussions-comment"]');
                                        comments.forEach(c => c.remove());
                                        // Return the text content
                                        return clone.textContent;
                                    }
                                ''')
                                if main_content_html and main_content_html.strip():
                                    main_content = main_content_html.strip()
                                    break

                        if main_content:
                            break

                # If still no content, try a more aggressive approach
                if not main_content:
                    # Look for the first large text block after the header
                    all_divs = await page.query_selector_all('div')
                    for div in all_divs:
                        text = await div.text_content()
                        if text and len(text.strip()) > 100:  # Likely to be main content
                            # Check if this is not a comment/reply
                            is_comment = await div.evaluate('''
                                (element) => {
                                    return element.getAttribute('data-testid') === 'discussions-comment' ||
                                           element.classList.toString().includes('comment') ||
                                           element.classList.toString().includes('reply');
                                }
                            ''')
                            if not is_comment:
                                # Check if it contains author info (to avoid header)
                                contains_author = main_author.username in text if main_author.username != "unknown" else False
                                if not contains_author or len(text.strip()) > 200:
                                    # Clean the text
                                    lines = text.strip().split('\n')
                                    clean_lines = []
                                    for line in lines:
                                        line = line.strip()
                                        # Skip metadata lines
                                        if not any(skip in line.lower() for skip in [
                                            'posted', 'edited', 'vote', 'reply',
                                            'in this competition', '·', 'ago'
                                        ]):
                                            if len(line) > 10:
                                                clean_lines.append(line)

                                    if clean_lines:
                                        main_content = '\n'.join(clean_lines[:20])  # Limit to first 20 lines
                                        break
            
            if self.dev_mode:
                logger.debug(f"Author: {main_author.name} (@{main_author.username})")
                if main_author.rank:
                    logger.debug(f"Rank: {main_author.rank}")
            
            # Extract replies with proper content separation (all comments are replies)
            replies = await self.extract_hierarchical_replies(page, skip_index=-1)
            
            return Discussion(
                title=title,
                url=url,
                main_content=main_content,
                main_author=main_author,
                main_upvotes=main_upvotes,
                replies=replies,
                total_replies=self._count_all_replies(replies),
                extraction_time=datetime.now().isoformat()
            )
            
        except Exception as e:
            logger.error(f"Error extracting discussion: {e}")
            return None

    def _count_all_replies(self, replies: List[Reply]) -> int:
        """Count all replies including sub-replies recursively"""
        count = 0
        for reply in replies:
            count += 1
            count += self._count_all_replies(reply.sub_replies)
        return count

    def save_discussion_markdown(self, discussion: Discussion, output_file: Path):
        """Save discussion in markdown format with proper hierarchy"""
        content = f"# {discussion.title}\n\n"
        content += f"**URL**: {discussion.url}\n"
        content += f"**Discussion Title**: {discussion.title}\n"
        content += f"**Total Comments**: {discussion.total_replies}\n"
        content += f"**Extracted**: {discussion.extraction_time}\n\n"
        content += "---\n\n"
        
        # Main post
        content += "## Main Post\n\n"
        content += f"**Author**: {discussion.main_author.name} (@{discussion.main_author.username})\n"
        if discussion.main_author.rank:
            content += f"**Rank**: {discussion.main_author.rank}\n"
        if discussion.main_author.badges:
            content += f"**Badges**: {', '.join(discussion.main_author.badges)}\n"
        content += f"**Upvotes**: {discussion.main_upvotes}\n\n"
        content += f"{discussion.main_content}\n\n"
        content += "---\n\n"
        
        # Replies with hierarchy
        if discussion.replies:
            content += "## Replies\n\n"
            
            def format_reply(reply: Reply, indent_level: int = 0) -> str:
                indent = "  " * indent_level
                result = ""
                
                # Format header based on depth
                if indent_level == 0:
                    result += f"### Reply {reply.reply_number}\n\n"
                elif indent_level == 1:
                    result += f"{indent}#### Reply {reply.reply_number}\n\n"
                else:
                    result += f"{indent}##### Reply {reply.reply_number}\n\n"
                
                result += f"{indent}- **Author**: {reply.author.name} (@{reply.author.username})\n"
                if reply.author.rank:
                    result += f"{indent}- **Rank**: {reply.author.rank}\n"
                if reply.author.badges:
                    result += f"{indent}- **Badges**: {', '.join(reply.author.badges)}\n"
                result += f"{indent}- **Upvotes**: {reply.upvotes}\n"
                if reply.timestamp:
                    result += f"{indent}- **Timestamp**: {reply.timestamp}\n"
                result += "\n"
                
                # Reply content
                for line in reply.content.split('\n'):
                    result += f"{indent}{line}\n"
                result += "\n"
                
                # Add sub-replies
                for sub_reply in reply.sub_replies:
                    result += format_reply(sub_reply, indent_level + 1)
                
                if indent_level == 0:
                    result += "---\n\n"
                
                return result
            
            for reply in discussion.replies:
                content += format_reply(reply)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        if self.dev_mode:
            logger.debug(f"Saved: {output_file.name}")

    async def extract_competition_discussions(self, competition_url: str, limit: Optional[int] = None) -> bool:
        """
        Extract all discussions from a Kaggle competition
        
        Args:
            competition_url: Full URL to the Kaggle competition
            limit: Number of discussions to extract (None = all)
            
        Returns:
            bool: Success status
        """
        logger.info(f"Starting extraction for: {competition_url}")
        
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.headless)
            page = await browser.new_page()
            
            try:
                # Load competition page
                await page.goto(competition_url, wait_until="domcontentloaded")
                await asyncio.sleep(3)
                
                discussions_url = f"{competition_url}/discussion"
                await page.goto(discussions_url, wait_until="domcontentloaded")
                await asyncio.sleep(5)
                
                # Get discussion links from all pages
                discussion_links = []
                page_num = 1
                
                while True:
                    page_url = f"{discussions_url}?page={page_num}" if page_num > 1 else discussions_url
                    if self.dev_mode:
                        logger.debug(f"Loading page {page_num}: {page_url}")
                    
                    await page.goto(page_url, wait_until="domcontentloaded")
                    await asyncio.sleep(3)
                    
                    # Get discussion links from current page
                    all_links = await page.query_selector_all('a[href*="/discussion/"]')
                    page_links = []
                    
                    for link in all_links:
                        href = await link.get_attribute('href')
                        if href and '/discussion/' in href:
                            full_url = f"https://www.kaggle.com{href}" if href.startswith('/') else href
                            base_url = full_url.split('#')[0]
                            if not base_url.endswith('/discussion') and base_url not in discussion_links:
                                page_links.append(base_url)
                                discussion_links.append(base_url)
                    
                    if self.dev_mode:
                        logger.debug(f"Page {page_num}: Found {len(page_links)} discussions")
                    
                    # Check if there's a next page
                    next_button = await page.query_selector('button[aria-label="Go to next page"], a[aria-label="Go to next page"], [data-testid="pagination-next"]')
                    
                    is_disabled = False
                    if next_button:
                        is_disabled = await next_button.evaluate('el => el.disabled || el.classList.contains("disabled")')
                    
                    if not next_button or is_disabled or len(page_links) == 0:
                        if self.dev_mode:
                            logger.debug(f"Reached last page (page {page_num})")
                        break
                    
                    page_num += 1
                    
                    # Safety limit
                    if page_num > 50:
                        logger.warning("Reached maximum page limit (50)")
                        break
                
                discussion_links = list(dict.fromkeys(discussion_links))
                
                if not discussion_links:
                    logger.error("No discussion links found!")
                    return False
                
                logger.info(f"Found {len(discussion_links)} unique discussions")
                
                # Apply limit if specified
                extract_count = min(limit, len(discussion_links)) if limit else len(discussion_links)
                logger.info(f"Extracting {extract_count} discussions")
                
                # Create output directory
                output_dir = Path("kaggle_discussions_extracted")
                if output_dir.exists():
                    import shutil
                    shutil.rmtree(output_dir)
                output_dir.mkdir(exist_ok=True)
                
                successful_extractions = 0
                for i, url in enumerate(discussion_links[:extract_count], 1):
                    logger.info(f"[{i}/{extract_count}] Processing discussion...")
                    
                    try:
                        discussion = await self.extract_single_discussion(page, url)
                        
                        if discussion:
                            safe_title = re.sub(r'[<>:"/\\|?*]', '_', discussion.title[:50])
                            
                            # Generate filename with optional date
                            if self.date_format:
                                # Extract date from discussion timestamp or use current date
                                from datetime import datetime
                                try:
                                    # Try to parse the extraction time
                                    dt = datetime.fromisoformat(discussion.extraction_time.replace('Z', '+00:00'))
                                except:
                                    dt = datetime.now()
                                
                                date_str = dt.strftime("%y%m%d")
                                
                                if self.date_position == "prefix":
                                    md_file = output_dir / f"{date_str}_{i:02d}_{safe_title}.md"
                                else:  # suffix
                                    md_file = output_dir / f"{i:02d}_{safe_title}_{date_str}.md"
                            else:
                                md_file = output_dir / f"{i:02d}_{safe_title}.md"
                            
                            self.save_discussion_markdown(discussion, md_file)
                            
                            successful_extractions += 1
                            
                            nested = sum(len(r.sub_replies) for r in discussion.replies)
                            if nested > 0:
                                logger.info(f"   Stats: {len(discussion.replies)} top-level, {nested} nested replies")
                            else:
                                logger.info(f"   Stats: {discussion.total_replies} replies total")
                            
                            await asyncio.sleep(2)
                        
                    except Exception as e:
                        logger.error(f"   Error: {e}")
                        continue
                
                if successful_extractions > 0:
                    logger.info(f"SUCCESS: Extracted {successful_extractions}/{extract_count} discussions")
                    logger.info(f"Output saved in: {output_dir.absolute()}")
                    return True
                else:
                    logger.error("No discussions successfully extracted!")
                    return False
                    
            finally:
                await browser.close()