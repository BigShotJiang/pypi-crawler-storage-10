# 这是一个示例 Python 脚本。

# 按 Shift+F10 执行或将其替换为您的代码。
# 按 双击 Shift 在所有地方搜索类、文件、工具窗口、操作和设置。
import zhkj_plugins

def print_ver(name):
    # 在下面的代码行中使用断点来调试脚本。
    print(f'当前版本: {name}')  # 按 Ctrl+F8 切换断点。


# 按装订区域中的绿色按钮以运行脚本。
if __name__ == '__main__':
    print_ver(zhkj_plugins.__version__)
    print(zhkj_plugins.PluginManager({}).is_plugin_installed("aaa"))
    print(zhkj_plugins.PluginManager().package_plugin("jianying", r"C:\Users\123\Downloads\JianyingPro5.9版本\JianyingPro", "1.0.0"))

# 访问 https://www.jetbrains.com/help/pycharm/ 获取 PyCharm 帮助
