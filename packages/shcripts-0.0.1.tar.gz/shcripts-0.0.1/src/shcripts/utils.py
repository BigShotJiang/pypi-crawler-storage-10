"""Utilities for script templating and rendering."""

from pathlib import Path
from typing import Optional

import jinja2
from jinja2 import Environment, FileSystemLoader, Template

from shcripts.models import SlurmConfig


def render_template(template_path: Path, variables: dict[str, str]) -> str:
    """Render a Jinja2 template with the given variables."""
    env = Environment(loader=FileSystemLoader(template_path.parent))
    template = env.get_template(template_path.name)
    return template.render(**variables)


def render_template_string(template_str: str, variables: dict[str, str]) -> str:
    """Render a Jinja2 template string with the given variables."""
    template = Template(template_str)
    return template.render(**variables)


def parse_slurm_script(script_path: Path) -> Optional[SlurmConfig]:
    """Parse SLURM configuration from an existing script."""
    content = script_path.read_text()
    lines = content.split("\n")

    config = {}

    for line in lines:
        line = line.strip()
        if not line.startswith("#SBATCH"):
            continue

        # Parse SBATCH directive
        parts = line.replace("#SBATCH", "").strip().split("=", 1)
        if len(parts) != 2:
            continue

        key = parts[0].strip().lstrip("--")
        value = parts[1].strip()

        # Map SBATCH parameters to SlurmConfig fields
        key_mapping = {
            "job-name": "job_name",
            "cpus-per-task": "cpus_per_task",
            "mail-user": "mail_user",
            "mail-type": "mail_type",
        }

        config_key = key_mapping.get(key, key.replace("-", "_"))

        # Convert numeric values
        if config_key in ["ntasks", "cpus_per_task", "nodes"]:
            try:
                value = int(value)
            except ValueError:
                pass

        config[config_key] = value

    if config:
        return SlurmConfig(**config)
    return None


def extract_variables(template_path: Path) -> set[str]:
    """Extract Jinja2 variables from a template."""
    content = template_path.read_text()
    template = Template(content)
    return template.environment.parse(content).find_all(type=jinja2.nodes.Name)


def create_slurm_script(
    slurm_config: SlurmConfig,
    script_body: str,
    preamble: Optional[str] = None,
) -> str:
    """Create a complete SLURM script with header and body."""
    lines = slurm_config.to_sbatch_header()
    lines.append("")  # Empty line after header

    if preamble:
        lines.append(preamble)
        lines.append("")

    lines.append(script_body)

    return "\n".join(lines)
