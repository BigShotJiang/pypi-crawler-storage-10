"""Storage management for scripts and jobs."""

import json
from pathlib import Path
from typing import Optional

from shcripts.models import JobRecord, ScriptTemplate


class Storage:
    """Manages persistent storage for scripts and jobs."""

    def __init__(self, base_dir: Optional[Path] = None):
        """Initialize storage in the given directory."""
        if base_dir is None:
            base_dir = Path.home() / ".shcripts"

        self.base_dir = base_dir
        self.templates_dir = base_dir / "templates"
        self.scripts_db = base_dir / "scripts.json"
        self.jobs_db = base_dir / "jobs.json"

        # Create directories if they don't exist
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.templates_dir.mkdir(exist_ok=True)

        # Initialize databases if they don't exist
        if not self.scripts_db.exists():
            self.scripts_db.write_text("[]")
        if not self.jobs_db.exists():
            self.jobs_db.write_text("[]")

    def get_all_scripts(self) -> list[ScriptTemplate]:
        """Get all registered script templates."""
        data = json.loads(self.scripts_db.read_text())
        return [ScriptTemplate.from_dict(item) for item in data]

    def get_script(self, name: str) -> Optional[ScriptTemplate]:
        """Get a script template by name."""
        scripts = self.get_all_scripts()
        for script in scripts:
            if script.name == name:
                return script
        return None

    def add_script(self, script: ScriptTemplate) -> None:
        """Add or update a script template."""
        scripts = self.get_all_scripts()
        # Remove existing script with the same name
        scripts = [s for s in scripts if s.name != script.name]
        scripts.append(script)

        data = [s.to_dict() for s in scripts]
        self.scripts_db.write_text(json.dumps(data, indent=2))

    def remove_script(self, name: str) -> bool:
        """Remove a script template."""
        scripts = self.get_all_scripts()
        initial_count = len(scripts)
        scripts = [s for s in scripts if s.name != name]

        if len(scripts) < initial_count:
            data = [s.to_dict() for s in scripts]
            self.scripts_db.write_text(json.dumps(data, indent=2))
            return True
        return False

    def get_all_jobs(self) -> list[JobRecord]:
        """Get all job records."""
        data = json.loads(self.jobs_db.read_text())
        return [JobRecord.from_dict(item) for item in data]

    def get_job(self, job_id: str) -> Optional[JobRecord]:
        """Get a job record by ID."""
        jobs = self.get_all_jobs()
        for job in jobs:
            if job.job_id == job_id:
                return job
        return None

    def add_job(self, job: JobRecord) -> None:
        """Add a job record."""
        jobs = self.get_all_jobs()
        # Remove existing job with the same ID
        jobs = [j for j in jobs if j.job_id != job.job_id]
        jobs.append(job)

        data = [j.to_dict() for j in jobs]
        self.jobs_db.write_text(json.dumps(data, indent=2))

    def update_job_status(self, job_id: str, status: str) -> bool:
        """Update a job's status."""
        job = self.get_job(job_id)
        if job:
            job.status = status
            self.add_job(job)
            return True
        return False

    def get_template_path(self, name: str) -> Path:
        """Get the path for a template file."""
        return self.templates_dir / f"{name}.sh"
