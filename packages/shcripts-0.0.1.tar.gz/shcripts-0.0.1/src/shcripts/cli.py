"""CLI application for managing bash scripts and SLURM job submissions."""

import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.syntax import Syntax
from rich.table import Table

from shcripts.models import JobRecord, ScriptTemplate
from shcripts.storage import Storage
from shcripts.utils import render_template

app = typer.Typer(help="Manage bash scripts and SLURM job submissions")
console = Console()
storage = Storage()


@app.command()
def add(
    name: str = typer.Argument(..., help="Name for the script template"),
    script_path: str = typer.Argument(..., help="Path to the script file"),
    description: str = typer.Option(
        "", "--description", "-d", help="Script description"
    ),
    category: str = typer.Option("general", "--category", "-c", help="Script category"),
    tags: Optional[list[str]] = typer.Option(
        None, "--tag", "-t", help="Tags for the script"
    ),
):
    """Add a new script template to the collection."""
    script_file = Path(script_path)

    if not script_file.exists():
        console.print(f"[red]Error:[/red] Script file not found: {script_path}")
        raise typer.Exit(1)

    # Copy template to storage
    template_path = storage.get_template_path(name)
    template_path.write_text(script_file.read_text())

    # Create template entry
    template = ScriptTemplate(
        name=name,
        description=description,
        template_path=template_path,
        category=category,
        tags=tags or [],
    )

    storage.add_script(template)

    console.print(
        Panel(
            f"[green]✓[/green] Added script template: [bold]{name}[/bold]\n"
            f"Category: {category}\n"
            f"Location: {template_path}",
            title="Script Added",
            border_style="green",
        )
    )


@app.command()
def remove(
    name: str = typer.Argument(..., help="Name of the script template to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Remove a script template from the collection."""
    script = storage.get_script(name)

    if not script:
        console.print(f"[red]Error:[/red] Script template not found: {name}")
        raise typer.Exit(1)

    if not force:
        confirm = Confirm.ask(f"Remove script template '{name}'?")
        if not confirm:
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    # Remove template file
    if script.template_path.exists():
        script.template_path.unlink()

    storage.remove_script(name)

    console.print(f"[green]✓[/green] Removed script template: [bold]{name}[/bold]")


@app.command(name="list")
def list_scripts(
    category: Optional[str] = typer.Option(
        None, "--category", "-c", help="Filter by category"
    ),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
):
    """List all stored script templates."""
    scripts = storage.get_all_scripts()

    # Apply filters
    if category:
        scripts = [s for s in scripts if s.category == category]
    if tag:
        scripts = [s for s in scripts if tag in s.tags]

    if not scripts:
        console.print("[yellow]No script templates found[/yellow]")
        return

    table = Table(title="Script Templates", show_lines=True)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")
    table.add_column("Category", style="magenta")
    table.add_column("Tags", style="blue")
    table.add_column("Created", style="green")

    for script in scripts:
        tags_str = ", ".join(script.tags) if script.tags else "-"
        created = datetime.fromisoformat(script.created_at).strftime("%Y-%m-%d %H:%M")
        table.add_row(
            script.name,
            script.description or "-",
            script.category,
            tags_str,
            created,
        )

    console.print(table)


@app.command()
def show(
    name: str = typer.Argument(..., help="Name of the script template to show"),
    raw: bool = typer.Option(
        False, "--raw", "-r", help="Show raw file content without syntax highlighting"
    ),
):
    """Show the content of a script template."""
    script = storage.get_script(name)

    if not script:
        console.print(f"[red]Error:[/red] Script template not found: {name}")
        raise typer.Exit(1)

    content = script.template_path.read_text()

    if raw:
        console.print(content)
    else:
        syntax = Syntax(content, "bash", theme="monokai", line_numbers=True)
        console.print(Panel(syntax, title=f"[bold]{name}[/bold]", border_style="cyan"))


@app.command()
def generate(
    template_name: str = typer.Argument(..., help="Name of the script template to use"),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file path"
    ),
    var: Optional[list[str]] = typer.Option(
        None, "--var", "-v", help="Variables in key=value format"
    ),
):
    """Generate a script from a template with variable substitution."""
    script = storage.get_script(template_name)

    if not script:
        console.print(f"[red]Error:[/red] Script template not found: {template_name}")
        raise typer.Exit(1)

    # Parse variables
    variables = {}
    if var:
        for v in var:
            if "=" not in v:
                console.print(
                    f"[red]Error:[/red] Invalid variable format: {v}. Use key=value"
                )
                raise typer.Exit(1)
            key, value = v.split("=", 1)
            variables[key] = value

    # Render template
    try:
        rendered = render_template(script.template_path, variables)
    except Exception as e:
        console.print(f"[red]Error rendering template:[/red] {e}")
        raise typer.Exit(1)

    if output:
        output_path = Path(output)
        output_path.write_text(rendered)
        console.print(f"[green]✓[/green] Generated script: [bold]{output}[/bold]")
    else:
        syntax = Syntax(rendered, "bash", theme="monokai")
        console.print(syntax)


@app.command()
def submit(
    script_path: Optional[str] = typer.Argument(
        None, help="Path to script file to submit"
    ),
    template_name: Optional[str] = typer.Option(
        None, "--template", "-t", help="Template name to use"
    ),
    var: Optional[list[str]] = typer.Option(
        None, "--var", "-v", help="Variables in key=value format"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be submitted without submitting"
    ),
):
    """Submit a SLURM job (either from a file or template)."""
    script_content = None
    template_used = None

    if template_name:
        # Generate from template
        script = storage.get_script(template_name)
        if not script:
            console.print(
                f"[red]Error:[/red] Script template not found: {template_name}"
            )
            raise typer.Exit(1)

        variables = {}
        if var:
            for v in var:
                if "=" not in v:
                    console.print(
                        f"[red]Error:[/red] Invalid variable format: {v}. Use key=value"
                    )
                    raise typer.Exit(1)
                key, value = v.split("=", 1)
                variables[key] = value

        try:
            script_content = render_template(script.template_path, variables)
            template_used = template_name
        except Exception as e:
            console.print(f"[red]Error rendering template:[/red] {e}")
            raise typer.Exit(1)

    elif script_path:
        script_file = Path(script_path)
        if not script_file.exists():
            console.print(f"[red]Error:[/red] Script file not found: {script_path}")
            raise typer.Exit(1)
        script_content = script_file.read_text()

    else:
        console.print(
            "[red]Error:[/red] Either provide a script path or use --template"
        )
        raise typer.Exit(1)

    if dry_run:
        console.print(
            Panel(
                Syntax(script_content, "bash", theme="monokai"),
                title="[bold]Dry Run - Would Submit:[/bold]",
                border_style="yellow",
            )
        )
        return

    # Write to temporary file and submit
    temp_script = Path("/tmp") / f"shcripts_submit_{datetime.now().timestamp()}.sh"
    temp_script.write_text(script_content)

    try:
        result = subprocess.run(
            ["sbatch", str(temp_script)],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            # Parse job ID from output (typically "Submitted batch job 12345")
            job_id = result.stdout.strip().split()[-1]

            # Record the job
            job = JobRecord(
                job_id=job_id,
                script_name=script_path or f"template:{template_name}",
                template_name=template_used,
                submitted_at=datetime.now().isoformat(),
                status="SUBMITTED",
            )
            storage.add_job(job)

            console.print(
                Panel(
                    f"[green]✓[/green] Job submitted successfully\n"
                    f"Job ID: [bold]{job_id}[/bold]",
                    title="Job Submitted",
                    border_style="green",
                )
            )
        else:
            console.print(f"[red]Error submitting job:[/red]\n{result.stderr}")
            raise typer.Exit(1)

    finally:
        # Clean up temp file
        if temp_script.exists():
            temp_script.unlink()


@app.command()
def status(
    job_id: Optional[str] = typer.Argument(None, help="Job ID to check status"),
    all: bool = typer.Option(False, "--all", "-a", help="Show all tracked jobs"),
):
    """Check the status of SLURM jobs."""
    if all:
        jobs = storage.get_all_jobs()

        if not jobs:
            console.print("[yellow]No tracked jobs found[/yellow]")
            return

        table = Table(title="Tracked Jobs")
        table.add_column("Job ID", style="cyan")
        table.add_column("Script", style="white")
        table.add_column("Template", style="magenta")
        table.add_column("Status", style="green")
        table.add_column("Submitted", style="blue")

        for job in jobs:
            submitted = datetime.fromisoformat(job.submitted_at).strftime(
                "%Y-%m-%d %H:%M"
            )
            table.add_row(
                job.job_id,
                job.script_name,
                job.template_name or "-",
                job.status,
                submitted,
            )

        console.print(table)

    elif job_id:
        # Check specific job with squeue
        try:
            result = subprocess.run(
                [
                    "squeue",
                    "-j",
                    job_id,
                    "-o",
                    "%.18i %.9P %.50j %.8u %.8T %.10M %.6D %R",
                ],
                capture_output=True,
                text=True,
            )

            if result.returncode == 0 and result.stdout.strip():
                console.print(
                    Panel(
                        result.stdout,
                        title=f"[bold]Job {job_id} Status[/bold]",
                        border_style="cyan",
                    )
                )

                # Update status in storage if tracked
                job = storage.get_job(job_id)
                if job:
                    lines = result.stdout.strip().split("\n")
                    if len(lines) > 1:
                        status_line = lines[1]
                        parts = status_line.split()
                        if len(parts) >= 5:
                            storage.update_job_status(job_id, parts[4])
            else:
                console.print(f"[yellow]No information found for job {job_id}[/yellow]")

        except FileNotFoundError:
            console.print(
                "[red]Error:[/red] 'squeue' command not found. Is SLURM installed?"
            )
            raise typer.Exit(1)

    else:
        console.print(
            "[yellow]Provide a job ID or use --all to see all tracked jobs[/yellow]"
        )


@app.command()
def history(
    limit: int = typer.Option(
        10, "--limit", "-n", help="Number of recent jobs to show"
    ),
):
    """Show job submission history."""
    jobs = storage.get_all_jobs()

    if not jobs:
        console.print("[yellow]No job history found[/yellow]")
        return

    # Sort by submission time (newest first)
    jobs.sort(key=lambda j: j.submitted_at, reverse=True)
    jobs = jobs[:limit]

    table = Table(title=f"Recent Jobs (Last {len(jobs)})")
    table.add_column("Job ID", style="cyan")
    table.add_column("Script/Template", style="white")
    table.add_column("Status", style="green")
    table.add_column("Submitted", style="blue")

    for job in jobs:
        submitted = datetime.fromisoformat(job.submitted_at).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        script_info = job.template_name or job.script_name
        table.add_row(job.job_id, script_info, job.status, submitted)

    console.print(table)


@app.command()
def init(
    with_examples: bool = typer.Option(
        True, "--examples/--no-examples", help="Include example templates"
    ),
):
    """Initialize shcripts with example templates."""
    console.print("[cyan]Initializing shcripts...[/cyan]")

    # Storage is automatically initialized
    console.print(f"[green]✓[/green] Storage directory: {storage.base_dir}")
    console.print(f"[green]✓[/green] Templates directory: {storage.templates_dir}")

    if with_examples:
        # Add example templates from the package
        from pathlib import Path
        import shcripts

        package_dir = Path(shcripts.__file__).parent
        template_dir = package_dir / "template"

        examples = [
            (
                "example-slurm",
                "example.sh",
                "MontePython MCMC example",
                "mcmc",
                ["slurm", "python"],
            ),
            (
                "generic",
                "generic-slurm.sh",
                "Generic SLURM template with variables",
                "general",
                ["slurm", "template"],
            ),
        ]

        for name, filename, desc, category, tags in examples:
            template_file = template_dir / filename
            if template_file.exists():
                template_path = storage.get_template_path(name)
                template_path.write_text(template_file.read_text())

                template = ScriptTemplate(
                    name=name,
                    description=desc,
                    template_path=template_path,
                    category=category,
                    tags=tags,
                )
                storage.add_script(template)
                console.print(
                    f"[green]✓[/green] Added example template: [bold]{name}[/bold]"
                )

    console.print("\n[bold green]✓ Initialization complete![/bold green]")
    console.print("\nNext steps:")
    console.print("  • Run [cyan]shcripts list[/cyan] to see available templates")
    console.print(
        "  • Run [cyan]shcripts show generic[/cyan] to see an example template"
    )
    console.print(
        "  • Run [cyan]shcripts generate generic --help[/cyan] to learn about generating scripts"
    )
    console.print("\nFor more examples, see EXAMPLES.md")


def main():
    app()


if __name__ == "__main__":
    main()
