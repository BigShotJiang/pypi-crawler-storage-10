"""Data models for scripts and jobs management."""

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


@dataclass
class SlurmConfig:
    """SLURM job configuration parameters."""

    job_name: str
    time: str = "01:00:00"
    ntasks: int = 1
    cpus_per_task: int = 1
    partition: str = "cpu"
    mem: str = "8GB"
    output: Optional[str] = None
    nodes: Optional[int] = None
    account: Optional[str] = None
    mail_user: Optional[str] = None
    mail_type: Optional[str] = None

    def to_sbatch_header(self) -> list[str]:
        """Convert to SBATCH directives."""
        lines = [
            "#!/bin/bash",
            f"#SBATCH --job-name={self.job_name}",
            f"#SBATCH --time={self.time}",
            f"#SBATCH --ntasks={self.ntasks}",
            f"#SBATCH --cpus-per-task={self.cpus_per_task}",
            f"#SBATCH --partition={self.partition}",
            f"#SBATCH --mem={self.mem}",
        ]

        if self.output:
            lines.append(f"#SBATCH --output={self.output}")
        if self.nodes:
            lines.append(f"#SBATCH --nodes={self.nodes}")
        if self.account:
            lines.append(f"#SBATCH --account={self.account}")
        if self.mail_user:
            lines.append(f"#SBATCH --mail-user={self.mail_user}")
        if self.mail_type:
            lines.append(f"#SBATCH --mail-type={self.mail_type}")

        return lines


@dataclass
class ScriptTemplate:
    """A script template with metadata."""

    name: str
    description: str
    template_path: Path
    category: str = "general"
    tags: list[str] = field(default_factory=list)
    variables: dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON storage."""
        return {
            "name": self.name,
            "description": self.description,
            "template_path": str(self.template_path),
            "category": self.category,
            "tags": self.tags,
            "variables": self.variables,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ScriptTemplate":
        """Create from dictionary."""
        data["template_path"] = Path(data["template_path"])
        return cls(**data)


@dataclass
class JobRecord:
    """Record of a submitted job."""

    job_id: str
    script_name: str
    template_name: Optional[str]
    submitted_at: str
    status: str = "PENDING"
    parameters: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON storage."""
        return {
            "job_id": self.job_id,
            "script_name": self.script_name,
            "template_name": self.template_name,
            "submitted_at": self.submitted_at,
            "status": self.status,
            "parameters": self.parameters,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "JobRecord":
        """Create from dictionary."""
        return cls(**data)
