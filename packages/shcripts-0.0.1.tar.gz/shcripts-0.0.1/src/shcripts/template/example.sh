#!/bin/bash
#SBATCH --job-name=Bc-lss
#SBATCH --time=180:33:33
#SBATCH --ntasks=8
#SBATCH --cpus-per-task=4
#SBATCH --partition=cpu
#SBATCH --mem=128GB
#SBATCH --output=/home/calderon/projects/Features-EFTofLSS/log/Binned-LSS-slurm-%A_%a.out

echo "sbatch-INFO: start of job"
echo "sbatch-INFO: nodes: ${SLURM_JOB_NODELIST}"
echo "sbatch-INFO: system: ${SLURM_CLUSTER_NAME}"

module load mpi4py/3.1.4-gompi-2023a
source ~/.venvs/primefeat/bin/activate
cd /home/calderon/montepython_public/

time srun python montepython/MontePython.py run \
    -p /home/calderon/projects/Features-EFTofLSS/input/montepython/10-bins-c/LSS.param \
    -o /home/calderon/projects/Features-EFTofLSS/chains/10-bins-c/LSS \
    -b /home/calderon/projects/Features-EFTofLSS/bestfits/10-bins-a/Planck_BOSS_eBOSS_binned.bestfit \
    -c /home/calderon/projects/Features-EFTofLSS/covmats/10-bins-a/BOSS_eBOSS_binned_a.covmat \
    -N 400_000 \
    --superupdate 20 \
    --conf features.conf

echo "sbatch-INFO: we're done"
date
wait
