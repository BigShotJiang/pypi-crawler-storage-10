#!/bin/bash
#SBATCH --job-name={{ job_name | default("analysis-job") }}
#SBATCH --time={{ time | default("24:00:00") }}
#SBATCH --ntasks={{ ntasks | default(8) }}
#SBATCH --cpus-per-task={{ cpus_per_task | default(4) }}
#SBATCH --partition={{ partition | default("cpu") }}
#SBATCH --mem={{ memory | default("64GB") }}
#SBATCH --output={{ output_dir | default("/home/user/logs") }}/{{ job_name }}-slurm-%A_%a.out

echo "=========================================="
echo "Job: {{ job_name }}"
echo "Description: {{ description | default('No description provided') }}"
echo "=========================================="
echo "Job started at: $(date)"
echo "Running on node: ${SLURM_JOB_NODELIST}"
echo "Working directory: {{ work_dir | default('$PWD') }}"
echo "=========================================="

# Load required modules
{% if modules %}
{% for module in modules.split(',') %}
module load {{ module.strip() }}
{% endfor %}
{% endif %}

# Activate virtual environment if specified
{% if venv_path %}
source {{ venv_path }}/bin/activate
{% endif %}

# Change to working directory
{% if work_dir %}
cd {{ work_dir }}
{% endif %}

# Main command execution
echo "Starting main execution..."
{% if command %}
{{ command }}
{% else %}
echo "No command specified - add --var command='your command here'"
{% endif %}

echo "=========================================="
echo "Job completed at: $(date)"
echo "=========================================="
