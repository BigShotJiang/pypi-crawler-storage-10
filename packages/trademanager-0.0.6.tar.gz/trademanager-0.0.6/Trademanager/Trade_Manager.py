#!/usr/bin/env python3
"""
pip install TradeManager

Launcher file for AutoTradeManager class.
Edit the variables below to configure your session.

"""

from Trademanager import AutoTradeManager

# CONFIG / HARDCODED TRADES
# =========================================================

DB_FILE                     = "trade_manager.db"

DEFAULT_CAPITAL             = 10000.0
DEFAULT_RISK_PCT            = 1.0             # Percent of capital risked per trade (2%)

# Auto-stop defaults (percent of initial capital)
DEFAULT_MAX_DRAWDOWN_PCT    = 3.0             # -3% daily drawdown
DEFAULT_MAX_PROFIT_PCT      = 5.0             # +5% daily profit cap (optional)

MAX_OPEN_TRADES             = 3
MAX_LOSS_TRADES             = 1
MAX_TARGET_TRADES           = 2

# Hardcoded startup option (you asked for this — not ignored)
HARD_CODED_MODE_ON_START = False              # True  False

HARDCODED_TRADES = [
    {"symbol": "NIFTY", "entry": 25000, "stop_loss": 24800, "target": 25200, "lot_size": 50},
    {"symbol": "BANKNIFTY", "entry": 61000, "stop_loss": 60500, "target": 62000, "lot_size": 25},
]


if __name__ == "__main__":
    atm = AutoTradeManager(
        db_file                 = DB_FILE,
        default_capital         = DEFAULT_CAPITAL,
        default_risk_pct        = DEFAULT_RISK_PCT,
        max_drawdown_pct        = DEFAULT_MAX_DRAWDOWN_PCT,
        max_profit_pct          = DEFAULT_MAX_PROFIT_PCT,
        max_open_trades         = MAX_OPEN_TRADES,
        max_loss_trades         = MAX_LOSS_TRADES,
        max_target_trades       = MAX_TARGET_TRADES,
        hardcoded_mode          = HARD_CODED_MODE_ON_START,
        hardcoded_trades        = HARDCODED_TRADES,
    )
    atm.run()
