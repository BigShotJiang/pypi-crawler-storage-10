import inspect
import warnings
import logging
import json
import os
from dotenv import load_dotenv
from openai import OpenAI
from rich.traceback import install
from rich.logging import RichHandler
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from pydantic import BaseModel, Field

load_dotenv()

install(show_locals=True)
console = Console()

logging.basicConfig(
    level="NOTSET",
    format="%(message)s",
    datefmt="[%X]",
    handlers=[
        RichHandler(
            rich_tracebacks=True,
            markup=True,
            show_time=True,
            show_level=True,
            show_path=True
        )
    ],
)

log = logging.getLogger("rich")

# Disable noisy logs
for noisy_logger in ["httpx", "openai", "urllib3", "httpcore", "stainless_sdk"]:
    logging.getLogger(noisy_logger).setLevel(logging.CRITICAL)
    logging.getLogger(noisy_logger).propagate = False

warnings.filterwarnings("ignore")


class ErrorSuggestion(BaseModel):
    cause: str = Field(..., description="Reason for error why error occurs.")
    fix: str = Field(..., description="Short explanation of how to fix it.")


def openai_assist(error: str, source_code: str, args=None, kwargs=None, result=None, instruction: str = None):
    """
    Use OpenAI to analyze an error and suggest fixes.
    Optional: pass custom 'instruction' to control explanation detail.
    """
    api_key = os.getenv("API_KEY")
    base_url = os.getenv("BASE_URL")
    instruction = os.getenv("INSTRUCTION",  None)

    
    print(instruction)
    if not api_key:
        raise ValueError("API_KEY not found in environment variables. Please set it in your .env file.")

    client = OpenAI(api_key=api_key, base_url=base_url)

    args_repr = json.dumps(args, default=str)
    kwargs_repr = json.dumps(kwargs, default=str)

    base_prompt = (
        "You are an expert Python assistant. Analyze the user's function behavior. "
        "If there is an exception, explain why it happened. "
        "Don't show the decorators when an error occurs. "
        "If no exception is raised, simply summarize the function output.\n\n"
        "Response structure:\n"
        "- Cause: (1-2 lines)\n"
        "- Fix: (under 5 lines)\n"
    )

    if instruction:
        base_prompt += f"\nFollow this additional user instruction: {instruction}\n"

    prompt = f"""
    {base_prompt}

    Error or Output Analysis:
    {error or "No exception raised"}

    Args: {args_repr}
    Kwargs: {kwargs_repr}
    Output: {result}

    Code:
    ```python
    {source_code}
    ```
    """

    with console.status("[bold green]Working on your task ....", spinner="dots10"):
        try:
            response = client.beta.chat.completions.parse(
                model="gemini-2.5-flash",
                messages=[
                    {"role": "system", "content": "You are a concise Python assistant."},
                    {"role": "user", "content": prompt},
                ],
                response_format=ErrorSuggestion,
            )
            content = response.choices[0].message.parsed
            return content

        except Exception as e:
            return {"cause": "AI suggestion unavailable", "fix": str(e)}


def catch(function):
    def wrapper(*args, **kwargs):
        try:
            result = function(*args, **kwargs)
            return result

        except Exception as e:

            user_instruction = "Explain the error in more detail with examples."  

            ai_data = openai_assist(
                str(e),
                inspect.getsource(function),
                args,
                kwargs,
                instruction=user_instruction
            )

            console.print(Panel(Text(f"{type(e).__name__}: {e}", style="bold red"),
                                title="[bold red]Error", border_style="red"))

            console.print(Panel(Text(ai_data.cause.strip(), style="bold red"),
                                title="[bold red]Error Cause", border_style="red"))

            console.print(Panel(Text(ai_data.fix.strip(), style="bold green"),
                                title="[bold green]Fix Suggestion", border_style="green"))

    return wrapper
