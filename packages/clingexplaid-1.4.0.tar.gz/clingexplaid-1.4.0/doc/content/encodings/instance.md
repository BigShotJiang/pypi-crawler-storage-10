# Instance

## Constants
```{list-table}
:header-rows: 1
:widths: 25 100

* - Name
  - Description
* - `horizon`
  - The description of a constant.
```

## Predicates

### `predicate(X,Y)`

Description

```{admonition} Example
```prolog
predicate(1,2).
```

### `another_predicate(X)`

Description

```{admonition} Example
```prolog
another_predicate(1).
```
