# ASP Encodings

Descriptions of ASP encodings.

```{toctree}
instance.md
```
