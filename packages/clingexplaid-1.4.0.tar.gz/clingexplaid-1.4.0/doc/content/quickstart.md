# Quick start

A simple explanation on how to use the system.

```console
$ clingexplaid -h
```

```{tip}
Tips on how to use the system.
```
