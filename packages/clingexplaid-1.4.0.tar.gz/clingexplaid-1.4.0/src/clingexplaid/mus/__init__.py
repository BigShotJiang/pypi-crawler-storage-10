"""
Minimal Unsatisfiable Core Utilities
"""

from .core_computer import CoreComputer

__all__ = [
    "CoreComputer",
]
