"""
Constant definitions for the transformers package
"""

REMOVED_TOKEN = "__REMOVED__"
RULE_ID_SIGNATURE = "_rule"
