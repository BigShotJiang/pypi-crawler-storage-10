"""
Constant definitions for the unsat_constraints package
"""

UNSAT_CONSTRAINT_SIGNATURE = "__unsat__"
