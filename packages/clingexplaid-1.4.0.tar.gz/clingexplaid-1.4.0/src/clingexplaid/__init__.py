"""
The clingexplaid project.
"""
