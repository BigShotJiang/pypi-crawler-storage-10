MODE_MUS_STYLE = """
#content.mode-mus{

}
"""
