"""Framework tests package."""
