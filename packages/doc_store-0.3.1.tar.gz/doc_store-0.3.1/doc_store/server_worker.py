import copy
from typing import Any

from uvicorn.config import LOGGING_CONFIG
from uvicorn.workers import UvicornWorker

ACCESS_LOG_FORMAT = '%(levelprefix)s %(client_addr)s - "%(request_line)s" %(status_code)s'
ACCESS_LOG_FORMAT = "%(levelprefix)s"


class CustomWorker(UvicornWorker):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        log_config = copy.deepcopy(LOGGING_CONFIG)
        log_config["formatters"]["access"]["fmt"] = ACCESS_LOG_FORMAT
        self.config.log_config = log_config
