# datamodelzoo

Collection of objects that represent Python datamodel

## Installation

```bash
uv add datamodelzoo
```

## Usage

```python
from datamodelzoo import CASES


for case in CASES:
    print(case.name)
```
