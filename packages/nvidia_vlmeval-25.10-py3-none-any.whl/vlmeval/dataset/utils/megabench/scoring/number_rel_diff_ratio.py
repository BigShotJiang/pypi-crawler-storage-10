# SPDX-FileCopyrightText: Copyright 2023 VLMEvalKit Authors. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import ast
import math
from numbers import Number


class NumberRelDiffRatio:
    """Number relative difference ratio scoring = min(0, 1 - |pred - gt| / gt)"""

    @staticmethod
    def match(response: str | Number, correct_answer: str) -> int:
        """Return the relative difference ratio."""
        try:
            if isinstance(response, Number):
                pred = response
            else:
                pred = ast.literal_eval(response)
            if not isinstance(pred, Number):
                return 0
            gt = ast.literal_eval(correct_answer)
            return max(0, 1 - math.fabs((pred - gt) / gt))
        except (SyntaxError, ValueError):
            return 0
