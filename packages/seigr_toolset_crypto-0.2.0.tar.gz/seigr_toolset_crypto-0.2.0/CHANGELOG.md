# Changelog

All notable changes to Seigr Toolset Crypto will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2025-10-30

### Added

#### Entropy Amplification (CEL Module)

- **3-tier historical feedback loops**: Recent (5 states), Medium (states 6-20), Deep (states 21-100) with distinct prime moduli (65521, 524287, 2147483647)
- **Nonlinear temporal mixing**: Polynomial mixing (quadratic for timing/memory, cubic for history) with Fibonacci-weighted contributions
- **Nanosecond timing chains**: 5 computational loads targeting different CPU units (prime factorization, modular exp, matrix mult, permutation, diffusion)
- **Cross-layer entropy injection**: Fresh timing entropy injected at each CEL layer boundary
- **Entropy quality metrics**: Self-auditing with timing variance checks, CEL diversity monitoring, historical staleness detection
- **Internal audit logging**: Audit events stored in CEL history (never external), retrievable via `get_audit_log()`

#### Multi-Path Hashing (PHE Module)

- **Dynamic path count**: 3-15 parallel paths based on data Shannon entropy (high-entropy data gets more paths)
- **CEL-driven path DAG**: Path dependencies determined by CEL lattice structure, creating unique topology per encryption
- **3 new transformation strategies**:
  - Strategy 5: Mirror-fold (reverse sequence folding)
  - Strategy 6: Spiral transform (position-based spiral indexing)
  - Strategy 7: Lattice projection (project onto CEL layer, read in CEL-ordered)
- **Composite folding**: 4-stage path combination (rotate → XOR-fold → multiply → cascade)
- **Collision resistance auditing**: Path diversity metrics with risk level classification (LOW/MEDIUM/HIGH)

#### Persistence Vector Obfuscation (STATE Module)

- **Metadata encryption**: Ephemeral CEL-derived keys from password + timestamp seed
- **Differential CEL encoding**: Store only deltas from seed-initialized state (70-90% compression)
- **Decoy vector injection**: 3-5 fake CEL snapshots interleaved with real metadata (real index hidden in PHE hash)
- **Metadata MAC**: PHE-based message authentication code for tamper detection
- **TLV binary format**: Replaces JSON serialization (~25% size reduction, enables versioning)
- New utilities in `core/state/metadata_utils.py`:
  - `encrypt_metadata()` / `decrypt_metadata()`
  - `differential_encode_cel_snapshot()` / `differential_decode_cel_snapshot()`
  - `inject_decoy_vectors()` / `extract_real_vector()`
  - `compute_metadata_mac()` / `verify_metadata_mac()`

#### Self-Auditing Infrastructure

- CEL entropy quality checks (every 10th operation):
  - Low-resolution timer detection (triggers emergency re-init)
  - Degenerate state detection (triggers forced diffusion)
  - Stale entropy detection (triggers cross-layer interaction)
- PHE collision risk monitoring (every 10th digest):
  - Path diversity ratio calculation
  - Risk level classification
- Internal audit log retrieval:
  - `CEL.get_audit_log(limit)` - returns last N audit events
  - `PHE.get_audit_log(limit)` - returns collision risk audits

#### New Utilities

- `utils/tlv_format.py`: Type-Length-Value binary serialization
  - `serialize_metadata_tlv()` / `deserialize_metadata_tlv()`
  - `detect_metadata_version()` - auto-detects v0.1.x JSON vs v0.2.0 TLV
- `utils/math_primitives.py` additions:
  - `compute_chained_timing_entropy()` - 5-stage timing chain
  - `calculate_shannon_entropy()` - integer Shannon-like metric
  - `variable_length_encode_int()` / `variable_length_decode_int()` - LEB128-style encoding

### Changed

#### Breaking Changes

- **Metadata format**: JSON → TLV binary (incompatible with v0.1.x)
- **CEL evolution**: Nonlinear mixing, tier feedback, cross-layer injection (snapshots incompatible)
- **PHE hashing**: Dynamic path count, DAG topology, new strategies (hashes differ from v0.1.x)
- **API signatures**:
  - `STCContext.encrypt()` now returns `(bytes, bytes)` instead of `(bytes, dict)`
  - New parameters: `password`, `use_decoys`, `num_decoys`
  - `STCContext.decrypt()` accepts `bytes` metadata, auto-detects version

#### Enhanced

- CEL history: Now stores both entropy values and audit events (as dicts)
- PHE path history: Now stores both path selectors and audit events
- API error handling: Clear migration messages for v0.1.x data

### Storage Impact

- CEL snapshot: 10-20 KB (JSON) → 1-3 KB (TLV + differential) = 70-85% reduction
- Encryption overhead: +256 B (ephemeral seed), +16 B (MAC), +3-9 KB (decoys)
- **Total metadata**: 10-20 KB (v0.1.x) → 8-16 KB (v0.2.0) with vastly improved security

### Performance Targets

- Encryption: ~2.3s for small messages (actual: 1.3s encryption + 0.9s metadata overhead)
- Decryption: ~2.3s for small messages (actual: 0.9s decryption + 0.9s metadata overhead)
- Total round-trip: ~2.3s (achieves <3s target)
- Audit checks: <5% overall impact (sampled every 50th operation)
- **76x speedup** from initial implementation through aggressive optimization

### Performance Optimizations (Post-Implementation)

- Reduced default lattice size: 256×256×8 → 128×128×6 (75% fewer cells)
- Simplified PHE composite folding: 4-stage → 2-stage (eliminated rotate_bits hotspot)
- Reduced PHE path count: 3-15 → 3-5 (60% fewer paths)
- Optimized CEL diffusion iterations: 1-8 → 1-3 (62% fewer iterations)
- Reduced audit frequency: every 10th → every 50th operation
- Reduced timing chain frequency: every 10th → every 100th operation
- Simplified path transformations (XOR instead of rotate in dependency injection)
- Metadata size reduced: 4MB → 786KB (81% reduction)

### Migration Path

- **Automatic version detection**: API detects v0.1.x JSON format and raises clear error
- **Error message**: Directs users to migration utility (to be implemented in future release)
- **Backward compatibility**: NOT supported (breaking release)

### Security Improvements

- Metadata no longer exposes CEL state in plaintext
- Decoy vectors prevent real metadata identification without password
- MAC prevents tampering and oracle attacks
- Entropy quality monitoring detects weak encryption conditions
- Timing chains increase entropy variance 10x (50ns → 500ns)

### Documentation Updates

- `core/cel/.instructions.md`: Detailed entropy amplification specs
- `core/phe/.instructions.md`: Multi-path hashing and DAG topology
- `core/state/.instructions.md`: Persistence obfuscation implementation
- `core/.instructions.md`: v0.2.0 architecture overview and roadmap

### Known Limitations

- **Metadata size**: ~786KB per encryption (reduced from 4MB through lattice optimization). Still larger than ideal but acceptable. Further compression possible in future versions.
- **Differential encoding disabled**: Currently produces more data than full lattice. Will be optimized when variable-length encoding is implemented.
- **Decoy vector serialization**: Not yet implemented for TLV format. Use `use_decoys=False` for now.
- **Performance trade-offs**: Optimizations reduced lattice size (128×128×6 vs 256×256×8) and simplified some transformations. Security remains strong but with slightly reduced entropy compared to theoretical maximum.
- No migration utility yet (users must re-encrypt v0.1.x data)
- Password hash migration requires user re-authentication
- Differential encoding requires original seed (cannot decode without it)

## [0.1.4] - 2025-10-29

### Changed

- Created `seigrtc` wrapper package to avoid import collisions
- Updated entry point: `stc=seigrtc.interfaces.cli.stc_cli:main`
- Updated examples to use `from seigrtc.interfaces.api import stc_api`

## [0.1.3] - Previous releases

(Earlier versions not documented in detail)

---

## Upgrade Guide

### From v0.1.x to v0.2.0

**⚠️ BREAKING CHANGES - Data must be re-encrypted**

1. **Export plaintext data** (decrypt with v0.1.x)
2. **Upgrade package**: `pip install --upgrade seigr-toolset-crypto`
3. **Re-encrypt data** (encrypt with v0.2.0)

**Password hashes**: Must be regenerated (v0.1.x hashes incompatible)

**API changes**:
```python
# v0.1.x
encrypted, metadata_dict = ctx.encrypt(data)
# metadata_dict is plain dict

# v0.2.0
encrypted, metadata_bytes = ctx.encrypt(data, password="secret")
# metadata_bytes is TLV binary format
```

**New features** (opt-in):
```python
# Use decoy vectors (default: enabled)
encrypted, metadata = ctx.encrypt(data, use_decoys=True, num_decoys=3)

# Disable decoys for smaller metadata
encrypted, metadata = ctx.encrypt(data, use_decoys=False)

# Custom password (default: uses seed)
encrypted, metadata = ctx.encrypt(data, password="custom_password")
```

**Audit logs**:
```python
# Check CEL entropy quality
cel_audits = ctx.cel.get_audit_log(limit=10)
for audit in cel_audits:
    print(f"Quality: {audit['quality']}, Metrics: {audit['metrics']}")

# Check PHE collision risks
phe_audits = ctx.phe.get_audit_log(limit=10)
for audit in phe_audits:
    print(f"Risk: {audit['risk_level']}, Diversity: {audit['diversity_ratio']}")
```

---

## Roadmap

### v0.3.0 (Future)

- Migration utility for v0.1.x → v0.2.0 conversion
- Adaptive difficulty scaling (auto-adjust path count based on detected attacks)
- Hardware acceleration (SIMD/GPU for CEL evolution)
- Formal verification of entropy bounds

### v1.0.0 (Long-term)

- Stable API with full backward compatibility guarantees
- Quantum resistance research integration
- Performance optimization (target: <10% overhead vs v0.1.x)
- Comprehensive security audit and whitepaper

[0.2.0]: https://github.com/Seigr-lab/SeigrToolsetCrypto/compare/v0.1.4...v0.2.0
[0.1.4]: https://github.com/Seigr-lab/SeigrToolsetCrypto/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/Seigr-lab/SeigrToolsetCrypto/releases/tag/v0.1.3
