# builtins
Supported Python builtins.

::: doc_stubs.builtins
