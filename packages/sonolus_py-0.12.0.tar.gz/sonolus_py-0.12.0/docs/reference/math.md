# math
Supported functions in the Python standard library `math` module.

::: doc_stubs.math
