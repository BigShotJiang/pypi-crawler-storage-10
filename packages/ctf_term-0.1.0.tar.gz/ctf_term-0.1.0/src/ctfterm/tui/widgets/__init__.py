"""TUI widgets."""

