"""TUI views."""

