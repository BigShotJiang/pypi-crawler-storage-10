"""Tests for CTF Terminal."""

