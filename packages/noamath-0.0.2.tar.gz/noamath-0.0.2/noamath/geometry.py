from .main import pi
def circleArea(r):
    return pi * r ** 2
def squareArea(s):
    return s**2
def rectArea(s1,s2):
    return s1 * s2
