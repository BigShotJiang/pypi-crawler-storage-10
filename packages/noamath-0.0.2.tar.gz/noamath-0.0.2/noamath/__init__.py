from .main import add
from .main import remove
from .main import e
from .main import pi
from .main import sqrt
from .main import pow
from .geometry import squareArea
from .geometry import rectArea
from .geometry import circleArea
from .main import dot
from .main import divide
from .main import multiply
__version__ = "0.0.1"
__all__ = ["add","remove","e","pi","sqrt","pow","circleArea","rectArea","squareArea","dot","divide","multiply"]