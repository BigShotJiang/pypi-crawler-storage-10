"""Codemark package initialization."""
