#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PLPM包管理器基本使用示例

这个示例文件展示了如何使用PLPM包管理器的各种功能，
包括自动检测包管理器、包管理操作等。
"""

import sys
import os

# 添加src目录到Python路径，以便导入plpm模块
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plpm import (
    OnlinePackageManager, 
    OfflinePackageManager, 
    get_package_manager, 
    list_available_managers,
    detect_online_package_manager,
    detect_offline_package_manager
)


def demo_online_package_manager():
    """演示在线包管理器使用"""
    print("=== 在线包管理器演示 ===")
    
    # 创建在线包管理器实例（自动检测）
    manager = OnlinePackageManager()
    
    # 检查是否有可用的在线包管理器
    if manager.is_manager_available():
        print(f"✅ 检测到在线包管理器: {manager.get_manager_name()}")
        
        # 检查包管理器是否可用
        current_manager = manager.get_current_manager()
        if current_manager and current_manager.is_available():
            print("✅ 包管理器可用")
            
            # 更新包列表
            print("🔄 正在更新包列表...")
            if current_manager.update():
                print("✅ 包列表更新成功")
            else:
                print("❌ 包列表更新失败")
            
            # 搜索包
            print("🔍 搜索Python相关包...")
            packages = current_manager.search("python")
            print(f"📦 找到 {len(packages)} 个相关包")
            if packages:
                for i, pkg in enumerate(packages[:3]):  # 只显示前3个
                    print(f"   {i+1}. {pkg.get('name', 'N/A')} - {pkg.get('description', '')}")
            
            # 列出已安装的包
            print("📋 列出已安装的包...")
            installed = current_manager.list_installed()
            print(f"📦 已安装 {len(installed)} 个包")
            if installed:
                for i, pkg in enumerate(installed[:5]):  # 只显示前5个
                    print(f"   {i+1}. {pkg.get('name', 'N/A')} - {pkg.get('version', '')}")
            
            # 检查特定包是否已安装
            test_packages = ["python3", "curl", "wget"]
            for pkg in test_packages:
                if current_manager.installed(pkg):
                    print(f"✅ {pkg} 已安装")
                else:
                    print(f"❌ {pkg} 未安装")
            
            # 获取包信息
            print("📊 获取Python3包信息...")
            info = current_manager.info("python3")
            if info:
                print(f"   📦 包名: {info.get('name', 'N/A')}")
                print(f"   📄 版本: {info.get('version', 'N/A')}")
                print(f"   📝 描述: {info.get('description', 'N/A')}")
            else:
                print("❌ 无法获取包信息")
            
        else:
            print("❌ 包管理器不可用")
    else:
        print("❌ 未检测到可用的在线包管理器")
    
    print()


def demo_offline_package_manager():
    """演示离线包管理器使用"""
    print("=== 离线包管理器演示 ===")
    
    # 创建离线包管理器实例（自动检测）
    manager = OfflinePackageManager()
    
    # 检查是否有可用的离线包管理器
    if manager.is_manager_available():
        print(f"✅ 检测到离线包管理器: {manager.get_manager_name()}")
        
        # 检查包管理器是否可用
        current_manager = manager.get_current_manager()
        if current_manager and current_manager.is_available():
            print("✅ 包管理器可用")
            
            # 搜索包
            print("🔍 搜索Python相关包...")
            packages = current_manager.search("python")
            print(f"📦 找到 {len(packages)} 个相关包")
            if packages:
                for i, pkg in enumerate(packages[:3]):  # 只显示前3个
                    print(f"   {i+1}. {pkg.get('name', 'N/A')} - {pkg.get('description', '')}")
            
            # 列出已安装的包
            print("📋 列出已安装的包...")
            installed = current_manager.list_installed()
            print(f"📦 已安装 {len(installed)} 个包")
            if installed:
                for i, pkg in enumerate(installed[:5]):  # 只显示前5个
                    print(f"   {i+1}. {pkg.get('name', 'N/A')} - {pkg.get('version', '')}")
            
            # 检查特定包是否已安装
            test_packages = ["python3", "curl", "wget"]
            for pkg in test_packages:
                if current_manager.installed(pkg):
                    print(f"✅ {pkg} 已安装")
                else:
                    print(f"❌ {pkg} 未安装")
            
            # 获取包信息
            print("📊 获取Python3包信息...")
            info = current_manager.info("python3")
            if info:
                print(f"   📦 包名: {info.get('name', 'N/A')}")
                print(f"   📄 版本: {info.get('version', 'N/A')}")
                print(f"   📝 描述: {info.get('description', 'N/A')}")
            else:
                print("❌ 无法获取包信息")
            
            print("💡 注意: 离线包管理器不支持update和upgrade操作")
            
        else:
            print("❌ 包管理器不可用")
    else:
        print("❌ 未检测到可用的离线包管理器")
    
    print()


def demo_specific_managers():
    """演示特定包管理器使用"""
    print("=== 特定包管理器演示 ===")
    
    # 测试各种包管理器
    managers_to_test = ['apt', 'yum', 'dnf', 'pacman', 'zypper', 'apk', 'dpkg', 'rpm']
    
    for manager_name in managers_to_test:
        print(f"\n🔧 测试 {manager_name} 包管理器...")
        
        try:
            manager = get_package_manager(manager_name=manager_name)
            
            if manager and manager.is_available():
                print(f"✅ {manager_name} 可用")
                
                # 检查是否支持特定操作
                if hasattr(manager, 'update'):
                    print("   🔄 支持更新操作")
                if hasattr(manager, 'upgrade'):
                    print("   ⬆️  支持升级操作")
                if hasattr(manager, 'install'):
                    print("   📥 支持安装操作")
                if hasattr(manager, 'remove'):
                    print("   🗑️  支持移除操作")
                    
            else:
                print(f"❌ {manager_name} 不可用")
                
        except Exception as e:
            print(f"❌ 测试 {manager_name} 时出错: {e}")
    
    print()


def demo_available_managers():
    """演示列出可用包管理器"""
    print("=== 可用包管理器列表 ===")
    
    # 列出系统中可用的包管理器
    available = list_available_managers()
    print(f"📋 可用的包管理器: {len(available)} 个")
    
    for i, name in enumerate(available):
        print(f"   {i+1}. {name}")
    
    print()


def demo_detection_functions():
    """演示检测函数"""
    print("=== 包管理器检测功能 ===")
    
    # 检测在线包管理器
    print("🔍 检测在线包管理器...")
    online_manager = detect_online_package_manager()
    if online_manager:
        print(f"✅ 检测到在线包管理器: {online_manager.__class__.__name__}")
    else:
        print("❌ 未检测到在线包管理器")
    
    # 检测离线包管理器
    print("🔍 检测离线包管理器...")
    offline_manager = detect_offline_package_manager()
    if offline_manager:
        print(f"✅ 检测到离线包管理器: {offline_manager.__class__.__name__}")
    else:
        print("❌ 未检测到离线包管理器")
    
    print()


def main():
    """主函数"""
    print("🚀 PLPM包管理器使用示例")
    print("=" * 50)
    
    try:
        # 演示各种功能
        demo_available_managers()
        demo_detection_functions()
        demo_online_package_manager()
        demo_offline_package_manager()
        demo_specific_managers()
        
        print("✅ 示例演示完成！")
        
    except Exception as e:
        print(f"❌ 演示过程中出错: {e}")
        print("💡 提示: 请确保在Linux系统上运行此示例")


if __name__ == "__main__":
    main()