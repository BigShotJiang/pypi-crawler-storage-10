"""
Test cases for online and offline package management interfaces.
"""

import unittest
import sys
import os

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plpm.unified import OnlinePackageManager, OfflinePackageManager, get_package_manager, list_available_managers


class TestOnlinePackageManager(unittest.TestCase):
    """Test cases for OnlinePackageManager."""
    
    def test_online_package_manager_initialization(self):
        """Test OnlinePackageManager initialization."""
        try:
            manager = OnlinePackageManager()
            self.assertIsNotNone(manager)
        except:
            # It's okay if no online package manager is available
            pass
    
    def test_online_package_manager_with_sudo(self):
        """Test OnlinePackageManager with sudo option."""
        try:
            manager = OnlinePackageManager(sudo=True)
            self.assertIsNotNone(manager)
        except:
            # It's okay if no online package manager is available
            pass
    
    def test_online_package_manager_with_preferred_manager(self):
        """Test OnlinePackageManager with preferred manager."""
        try:
            # Try with a specific online manager
            manager = OnlinePackageManager(preferred_manager='apt')
            self.assertIsNotNone(manager)
        except:
            # It's okay if the preferred manager is not available
            pass
    
    def test_get_current_manager(self):
        """Test get_current_manager method."""
        try:
            manager = OnlinePackageManager()
            current_manager = manager.get_current_manager()
            # This could be None if no manager is available
            if current_manager is not None:
                self.assertTrue(hasattr(current_manager, 'name'))
        except:
            pass
    
    def test_get_manager_name(self):
        """Test get_manager_name method."""
        try:
            manager = OnlinePackageManager()
            name = manager.get_manager_name()
            # This could be None if no manager is available
            if name is not None:
                self.assertIsInstance(name, str)
        except:
            pass
    
    def test_is_manager_available(self):
        """Test is_manager_available method."""
        try:
            manager = OnlinePackageManager()
            available = manager.is_manager_available()
            self.assertIsInstance(available, bool)
        except:
            pass


class TestOfflinePackageManager(unittest.TestCase):
    """Test cases for OfflinePackageManager."""
    
    def test_offline_package_manager_initialization(self):
        """Test OfflinePackageManager initialization."""
        try:
            manager = OfflinePackageManager()
            self.assertIsNotNone(manager)
        except:
            # It's okay if no offline package manager is available
            pass
    
    def test_offline_package_manager_with_sudo(self):
        """Test OfflinePackageManager with sudo option."""
        try:
            manager = OfflinePackageManager(sudo=True)
            self.assertIsNotNone(manager)
        except:
            # It's okay if no offline package manager is available
            pass
    
    def test_offline_package_manager_with_preferred_manager(self):
        """Test OfflinePackageManager with preferred manager."""
        try:
            # Try with a specific offline manager
            manager = OfflinePackageManager(preferred_manager='dpkg')
            self.assertIsNotNone(manager)
        except:
            # It's okay if the preferred manager is not available
            pass
    
    def test_get_current_manager(self):
        """Test get_current_manager method."""
        try:
            manager = OfflinePackageManager()
            current_manager = manager.get_current_manager()
            # This could be None if no manager is available
            if current_manager is not None:
                self.assertTrue(hasattr(current_manager, 'name'))
        except:
            pass
    
    def test_get_manager_name(self):
        """Test get_manager_name method."""
        try:
            manager = OfflinePackageManager()
            name = manager.get_manager_name()
            # This could be None if no manager is available
            if name is not None:
                self.assertIsInstance(name, str)
        except:
            pass
    
    def test_is_manager_available(self):
        """Test is_manager_available method."""
        try:
            manager = OfflinePackageManager()
            available = manager.is_manager_available()
            self.assertIsInstance(available, bool)
        except:
            pass


class TestGetPackageManager(unittest.TestCase):
    """Test cases for get_package_manager function."""
    
    def test_get_package_manager_exists(self):
        """Test that get_package_manager function exists."""
        self.assertTrue(callable(get_package_manager))
    
    def test_get_package_manager_with_manager_name(self):
        """Test get_package_manager with specific manager name."""
        try:
            manager = get_package_manager(manager_name='apt')
            # This could be None if the manager is not available
            if manager is not None:
                self.assertEqual(manager.name, 'apt')
        except:
            pass
    
    def test_get_package_manager_auto_detect(self):
        """Test get_package_manager auto-detection."""
        try:
            manager = get_package_manager()
            # This could be None if no manager is available
            if manager is not None:
                self.assertTrue(hasattr(manager, 'name'))
        except:
            pass


class TestListAvailableManagers(unittest.TestCase):
    """Test cases for list_available_managers function."""
    
    def test_list_available_managers_exists(self):
        """Test that list_available_managers function exists."""
        self.assertTrue(callable(list_available_managers))
    
    def test_list_available_managers_return_type(self):
        """Test that list_available_managers returns a list."""
        available = list_available_managers()
        self.assertIsInstance(available, list)
    
    def test_list_available_managers_content(self):
        """Test that list_available_managers returns valid manager names."""
        available = list_available_managers()
        valid_managers = ['apt', 'yum', 'dnf', 'apk', 'dpkg', 'rpm']
        
        for manager in available:
            self.assertIn(manager, valid_managers)


if __name__ == '__main__':
    unittest.main()