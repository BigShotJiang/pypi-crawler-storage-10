"""
Test cases for core package management functionality.
"""

import unittest
import sys
import os

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plpm.core import PackageManager, OnlinePackageManager, OfflinePackageManager, detect_package_manager, detect_online_package_manager, detect_offline_package_manager


class TestPackageManager(unittest.TestCase):
    """Test cases for PackageManager abstract base class."""
    
    def test_package_manager_initialization(self):
        """Test PackageManager initialization."""
        # This should raise TypeError since PackageManager is abstract
        with self.assertRaises(TypeError):
            PackageManager()
    
    def test_abstract_methods(self):
        """Test that abstract methods are defined."""
        # Check that abstract methods exist
        self.assertTrue(hasattr(PackageManager, 'install'))
        self.assertTrue(hasattr(PackageManager, 'remove'))
        self.assertTrue(hasattr(PackageManager, 'update'))
        self.assertTrue(hasattr(PackageManager, 'upgrade'))
        self.assertTrue(hasattr(PackageManager, 'search'))
        self.assertTrue(hasattr(PackageManager, 'info'))
        self.assertTrue(hasattr(PackageManager, 'list_installed'))
        self.assertTrue(hasattr(PackageManager, 'is_available'))


class TestOnlinePackageManager(unittest.TestCase):
    """Test cases for OnlinePackageManager abstract base class."""
    
    def test_online_package_manager_initialization(self):
        """Test OnlinePackageManager initialization."""
        # This should raise TypeError since OnlinePackageManager is abstract
        with self.assertRaises(TypeError):
            OnlinePackageManager()
    
    def test_clean_cache_abstract_method(self):
        """Test that clean_cache abstract method is defined."""
        self.assertTrue(hasattr(OnlinePackageManager, 'clean_cache'))


class TestOfflinePackageManager(unittest.TestCase):
    """Test cases for OfflinePackageManager abstract base class."""
    
    def test_offline_package_manager_initialization(self):
        """Test OfflinePackageManager initialization."""
        # This should raise TypeError since OfflinePackageManager is abstract
        with self.assertRaises(TypeError):
            OfflinePackageManager()
    
    def test_verify_abstract_method(self):
        """Test that verify abstract method is defined."""
        self.assertTrue(hasattr(OfflinePackageManager, 'verify'))
    
    def test_install_from_file_abstract_method(self):
        """Test that install_from_file abstract method is defined."""
        self.assertTrue(hasattr(OfflinePackageManager, 'install_from_file'))


class TestDetectPackageManager(unittest.TestCase):
    """Test cases for package manager detection."""
    
    def test_detect_package_manager_exists(self):
        """Test that detect_package_manager function exists."""
        self.assertTrue(callable(detect_package_manager))
    
    def test_detect_package_manager_return_type(self):
        """Test that detect_package_manager returns None or PackageManager instance."""
        result = detect_package_manager()
        if result is not None:
            self.assertIsInstance(result, PackageManager)


class TestDetectOnlinePackageManager(unittest.TestCase):
    """Test cases for online package manager detection."""
    
    def test_detect_online_package_manager_exists(self):
        """Test that detect_online_package_manager function exists."""
        self.assertTrue(callable(detect_online_package_manager))
    
    def test_detect_online_package_manager_return_type(self):
        """Test that detect_online_package_manager returns None or OnlinePackageManager instance."""
        result = detect_online_package_manager()
        if result is not None:
            self.assertIsInstance(result, OnlinePackageManager)


class TestDetectOfflinePackageManager(unittest.TestCase):
    """Test cases for offline package manager detection."""
    
    def test_detect_offline_package_manager_exists(self):
        """Test that detect_offline_package_manager function exists."""
        self.assertTrue(callable(detect_offline_package_manager))
    
    def test_detect_offline_package_manager_return_type(self):
        """Test that detect_offline_package_manager returns None or OfflinePackageManager instance."""
        result = detect_offline_package_manager()
        if result is not None:
            self.assertIsInstance(result, OfflinePackageManager)


if __name__ == '__main__':
    unittest.main()