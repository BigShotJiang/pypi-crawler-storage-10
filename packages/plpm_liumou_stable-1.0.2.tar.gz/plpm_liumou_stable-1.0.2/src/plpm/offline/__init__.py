"""
离线包管理器模块。
"""

from .dpkg import DpkgManager
from .rpm import RpmManager

__all__ = ["DpkgManager", "RpmManager"]