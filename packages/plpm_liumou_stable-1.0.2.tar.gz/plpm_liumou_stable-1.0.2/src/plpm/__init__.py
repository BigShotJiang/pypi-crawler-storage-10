"""
plpm_liumou_Stable - 统一的Linux包管理接口

一个Python库，提供统一的Linux包管理工具接口，
支持离线（dpkg/rpm）和在线（apt/yum/dnf）包管理器。
"""

from .core import PackageManager, OnlinePackageManager, OfflinePackageManager, detect_package_manager, detect_online_package_manager, detect_offline_package_manager
from .online import AptManager, YumManager, DnfManager
from .offline import DpkgManager, RpmManager
from .unified import OnlinePackageManager, OfflinePackageManager, get_package_manager, list_available_managers

__all__ = [
    "PackageManager",
    "OnlinePackageManager", 
    "OfflinePackageManager",
    "detect_package_manager",
    "detect_online_package_manager",
    "detect_offline_package_manager",
    "AptManager",
    "YumManager", 
    "DnfManager",
    "DpkgManager",
    "RpmManager",
    "UnifiedPackageManager",
    "get_package_manager",
    "list_available_managers"
]