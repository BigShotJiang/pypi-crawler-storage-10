"""
APK包管理器实现，用于Alpine Linux系统。
"""

import os
import re
import subprocess

from ..core import OnlinePackageManager


class ApkManager(OnlinePackageManager):
    """APK包管理器，用于Alpine Linux系统。"""
    
    def __init__(self, sudo=False):
        """
        初始化APK包管理器。
        
        参数:
            sudo (bool): 是否使用sudo执行特权操作，默认为False
            示例: sudo=True
        """
        super(ApkManager, self).__init__(sudo)
        self.name = "apk"
    
    def is_available(self):
        """
        检查APK是否在系统上可用。
        
        返回:
            bool: 如果APK可用返回True，否则返回False
        """
        try:
            result = subprocess.run(
                ['which', 'apk'], 
                capture_output=True, 
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def install(self, packages):
        """
        使用apk安装软件包。
        
        参数:
            packages (str|list): 要安装的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['apk', 'add'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def remove(self, packages):
        """
        使用apk移除软件包。
        
        参数:
            packages (str|list): 要移除的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 移除成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['apk', 'del'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def update(self):
        """
        更新软件包列表。
        
        返回:
            bool: 更新成功返回True，失败返回False
        """
        command = ['apk', 'update']
        result = self._run_command(command)
        return result.returncode == 0
    
    def upgrade(self, packages=None):
        """
        升级软件包。
        
        参数:
            packages (str|list|None): 要升级的软件包名称或列表，None表示升级所有包
            示例: packages="curl" 或 packages=["curl", "wget"] 或 packages=None
        
        返回:
            bool: 升级成功返回True，失败返回False
        """
        if packages:
            if isinstance(packages, str):
                packages = [packages]
            command = ['apk', 'upgrade'] + packages
        else:
            command = ['apk', 'upgrade']
        
        result = self._run_command(command)
        return result.returncode == 0
    
    def search(self, pattern):
        """
        搜索软件包。
        
        参数:
            pattern (str): 搜索模式
            示例: pattern="python"
        
        返回:
            list: 包含匹配软件包信息的字典列表
        """
        command = ['apk', 'search', pattern]
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if line and not line.startswith('WARNING'):
                    # APK搜索输出格式: 软件包名称-版本
                    package_name = line.split('-')[0] if '-' in line else line
                    packages.append({
                        'name': package_name.strip(),
                        'description': f"APK软件包: {package_name}"
                    })
        
        return packages
    
    def info(self, package):
        """
        获取软件包信息。
        
        参数:
            package (str): 软件包名称
            示例: package="python3"
        
        返回:
            dict|None: 软件包信息字典，如果包不存在返回None
        """
        command = ['apk', 'info', package]
        result = self._run_command(command)
        
        if result.returncode != 0:
            return None
        
        info = {'name': package}
        for line in result.stdout.strip().split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                info[key.strip()] = value.strip()
        
        return info
    
    def list_installed(self):
        """
        列出已安装的软件包。
        
        返回:
            list: 包含已安装软件包信息的字典列表
        """
        command = ['apk', 'info', '-v']
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if line:
                    # 格式: 软件包名称-版本
                    parts = line.split('-')
                    if len(parts) >= 2:
                        package_name = '-'.join(parts[:-1])  # 处理包含连字符的名称
                        version = parts[-1]
                        packages.append({
                            'name': package_name,
                            'version': version,
                            'architecture': ''  # APK在此格式中不显示架构
                        })
        
        return packages
    
    def clean_cache(self):
        """
        清理APK缓存。
        
        返回:
            bool: 清理成功返回True，失败返回False
        """
        command = ['apk', 'cache', 'clean']
        result = self._run_command(command)
        return result.returncode == 0
    
    def autoremove(self):
        """
        移除孤立的软件包。
        
        返回:
            bool: 移除成功返回True，失败返回False
        """
        command = ['apk', 'del', '--purge']
        result = self._run_command(command)
        return result.returncode == 0
    
    def add_repository(self, repository):
        """
        向APK添加软件源。
        
        参数:
            repository (str): 软件源地址
            示例: repository="http://dl-cdn.alpinelinux.org/alpine/edge/main"
        
        返回:
            bool: 添加成功返回True，失败返回False
        """
        command = ['apk', 'add', '--repository', repository]
        result = self._run_command(command)
        return result.returncode == 0
    
    def fix_broken(self):
        """
        修复损坏的软件包。
        
        返回:
            bool: 修复成功返回True，失败返回False
        """
        command = ['apk', 'fix']
        result = self._run_command(command)
        return result.returncode == 0