"""
YUM包管理器实现，用于Red Hat/CentOS系统。
"""

import subprocess

from ..core import OnlinePackageManager


class YumManager(OnlinePackageManager):
    """YUM包管理器，用于Red Hat-based系统。"""
    
    def __init__(self, sudo=False):
        """
        初始化YUM包管理器。
        
        参数:
            sudo (bool): 是否使用sudo执行特权操作，默认为False
            示例: sudo=True
        """
        super(YumManager, self).__init__(sudo)
        self.name = "yum"
    
    def is_available(self):
        """
        检查YUM是否在系统上可用。
        
        返回:
            bool: 如果YUM可用返回True，否则返回False
        """
        try:
            result = subprocess.run(
                ['which', 'yum'], 
                capture_output=True, 
                text=True
            )
            return result.returncode == 0
        except:
            return False
    
    def install(self, packages):
        """
        使用yum安装软件包。
        
        参数:
            packages (str|list): 要安装的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 安装成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['yum', 'install', '-y'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def remove(self, packages):
        """
        使用yum移除软件包。
        
        参数:
            packages (str|list): 要移除的软件包名称或列表
            示例: packages="curl" 或 packages=["curl", "wget"]
        
        返回:
            bool: 移除成功返回True，失败返回False
        """
        if isinstance(packages, str):
            packages = [packages]
        
        command = ['yum', 'remove', '-y'] + packages
        result = self._run_command(command)
        return result.returncode == 0
    
    def update(self):
        """
        更新软件包列表。
        
        返回:
            bool: 更新成功返回True，失败返回False
        """
        command = ['yum', 'check-update']
        result = self._run_command(command)
        return result.returncode == 0 or result.returncode == 100
    
    def upgrade(self, packages=None):
        """
        升级软件包。
        
        参数:
            packages (str|list|None): 要升级的软件包名称或列表，None表示升级所有包
            示例: packages="curl" 或 packages=["curl", "wget"] 或 packages=None
        
        返回:
            bool: 升级成功返回True，失败返回False
        """
        if packages:
            if isinstance(packages, str):
                packages = [packages]
            command = ['yum', 'update', '-y'] + packages
        else:
            command = ['yum', 'update', '-y']
        
        result = self._run_command(command)
        return result.returncode == 0
    
    def search(self, pattern):
        """
        搜索软件包。
        
        参数:
            pattern (str): 搜索模式
            示例: pattern="python"
        
        返回:
            list: 包含匹配软件包信息的字典列表
        """
        command = ['yum', 'search', pattern]
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line and not line.startswith('='):
                    parts = line.split(' : ', 1)
                    if len(parts) == 2:
                        packages.append({
                            'name': parts[0].strip(),
                            'description': parts[1].strip()
                        })
        
        return packages
    
    def info(self, package):
        """
        获取软件包信息。
        
        参数:
            package (str): 软件包名称
            示例: package="python3"
        
        返回:
            dict|None: 软件包信息字典，如果包不存在返回None
        """
        command = ['yum', 'info', package]
        result = self._run_command(command)
        
        if result.returncode != 0:
            return None
        
        info = {}
        for line in result.stdout.strip().split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                info[key.strip()] = value.strip()
        
        return info
    
    def list_installed(self):
        """
        列出已安装的软件包。
        
        返回:
            list: 包含已安装软件包信息的字典列表
        """
        command = ['rpm', '-qa', '--queryformat', '%{NAME}\t%{VERSION}\t%{ARCH}\n']
        result = self._run_command(command)
        
        packages = []
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if line:
                    parts = line.split('\t')
                    if len(parts) >= 2:
                        packages.append({
                            'name': parts[0],
                            'version': parts[1],
                            'architecture': parts[2] if len(parts) > 2 else ''
                        })
        
        return packages
    
    def clean_cache(self):
        """
        清理YUM缓存。
        
        返回:
            bool: 清理成功返回True，失败返回False
        """
        command = ['yum', 'clean', 'all']
        result = self._run_command(command)
        return result.returncode == 0