"""
在线包管理器模块。
"""

from .apt import AptManager
from .yum import YumManager
from .dnf import DnfManager
from .apk import ApkManager
from .pacman import PacmanManager
from .zypper import ZypperManager

__all__ = ["AptManager", "YumManager", "DnfManager", "ApkManager", "PacmanManager", "ZypperManager"]