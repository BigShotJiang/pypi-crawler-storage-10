# coding: utf-8

import six

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListLoadBalancersResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'loadbalancers': 'list[LoadBalancer]',
        'page_info': 'PageInfo',
        'request_id': 'str'
    }

    attribute_map = {
        'loadbalancers': 'loadbalancers',
        'page_info': 'page_info',
        'request_id': 'request_id'
    }

    def __init__(self, loadbalancers=None, page_info=None, request_id=None):
        r"""ListLoadBalancersResponse

        The model defined in huaweicloud sdk

        :param loadbalancers: **参数解释**：负载均衡器列表。
        :type loadbalancers: list[:class:`huaweicloudsdkelb.v3.LoadBalancer`]
        :param page_info: 
        :type page_info: :class:`huaweicloudsdkelb.v3.PageInfo`
        :param request_id: **参数解释**：请求ID。  **取值范围**：由数字、小写字母和中划线（-）组成的字符串，自动生成。
        :type request_id: str
        """
        
        super(ListLoadBalancersResponse, self).__init__()

        self._loadbalancers = None
        self._page_info = None
        self._request_id = None
        self.discriminator = None

        if loadbalancers is not None:
            self.loadbalancers = loadbalancers
        if page_info is not None:
            self.page_info = page_info
        if request_id is not None:
            self.request_id = request_id

    @property
    def loadbalancers(self):
        r"""Gets the loadbalancers of this ListLoadBalancersResponse.

        **参数解释**：负载均衡器列表。

        :return: The loadbalancers of this ListLoadBalancersResponse.
        :rtype: list[:class:`huaweicloudsdkelb.v3.LoadBalancer`]
        """
        return self._loadbalancers

    @loadbalancers.setter
    def loadbalancers(self, loadbalancers):
        r"""Sets the loadbalancers of this ListLoadBalancersResponse.

        **参数解释**：负载均衡器列表。

        :param loadbalancers: The loadbalancers of this ListLoadBalancersResponse.
        :type loadbalancers: list[:class:`huaweicloudsdkelb.v3.LoadBalancer`]
        """
        self._loadbalancers = loadbalancers

    @property
    def page_info(self):
        r"""Gets the page_info of this ListLoadBalancersResponse.

        :return: The page_info of this ListLoadBalancersResponse.
        :rtype: :class:`huaweicloudsdkelb.v3.PageInfo`
        """
        return self._page_info

    @page_info.setter
    def page_info(self, page_info):
        r"""Sets the page_info of this ListLoadBalancersResponse.

        :param page_info: The page_info of this ListLoadBalancersResponse.
        :type page_info: :class:`huaweicloudsdkelb.v3.PageInfo`
        """
        self._page_info = page_info

    @property
    def request_id(self):
        r"""Gets the request_id of this ListLoadBalancersResponse.

        **参数解释**：请求ID。  **取值范围**：由数字、小写字母和中划线（-）组成的字符串，自动生成。

        :return: The request_id of this ListLoadBalancersResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this ListLoadBalancersResponse.

        **参数解释**：请求ID。  **取值范围**：由数字、小写字母和中划线（-）组成的字符串，自动生成。

        :param request_id: The request_id of this ListLoadBalancersResponse.
        :type request_id: str
        """
        self._request_id = request_id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListLoadBalancersResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
