from enum import Enum


class StartOrEnd(Enum):
    START = "start"
    END = "end"
