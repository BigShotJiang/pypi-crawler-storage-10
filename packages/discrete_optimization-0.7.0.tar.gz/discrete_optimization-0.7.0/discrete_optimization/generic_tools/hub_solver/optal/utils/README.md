# Directory `benchmarks/utils`

Utilities for benchmarking:

* `utils.mts`: small utilities used by most benchmarks.
* `solveJSONs.mts`: solve model(s) saved in JSON format (using `--exportJSON` parameter in benchmarks).
