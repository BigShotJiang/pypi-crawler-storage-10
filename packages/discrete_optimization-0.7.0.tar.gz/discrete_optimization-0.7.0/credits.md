
# Thank You to Our Contributors!

We would like to extend our sincere thanks to the following people who have contributed to this repository,
even before it was released:

- [g-poveda](https://github.com/g-poveda), [olivierabz](https://github.com/olivierabz) for codesigning the library
- [nhuet](https://github.com/nhuet) for maintaining it and reach scikit-decide level of maturity.
- [fteicht](https://github.com/fteicht) for his constant support.
- [galleon](https://github.com/galleon) for first integration of scheduling in [scikit-decide](https://github.com/airbus/scikit-decide/blob/master/notebooks/13_scheduling_tuto.ipynb)

Also many thanks to beta testers and users helping debugging and improving the library.
We appreciate your hard work and dedication to this project.
