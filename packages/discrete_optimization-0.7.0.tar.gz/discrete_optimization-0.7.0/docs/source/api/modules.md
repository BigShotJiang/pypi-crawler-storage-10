# API Reference

```{toctree}
---
maxdepth: 4
---
discrete_optimization
```
