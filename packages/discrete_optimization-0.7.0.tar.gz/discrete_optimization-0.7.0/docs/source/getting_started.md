# Getting started

To get started with the library,
one can refer to the [tutorials](./notebooks) under the "notebooks" section.

You can also have a look to the [dashboard](dashboard.md) section to see how
to get graphs summarizing experiments on a bunch of solvers and problems.
