# Notebooks

We present here a curated list of notebooks recommended to start with discrete-optimization,
available in the `notebooks/` folder of the repository.

```{contents}
---
depth: 3
local: true
---
```

[[notebooks-list]]
