
# Copyright Disney Enterprises, Inc.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License
# and the following modification to it: Section 6 Trademarks.
# deleted and replaced with:
#
# 6. Trademarks. This License does not grant permission to use the
# trade names, trademarks, service marks, or product names of the
# Licensor and its affiliates, except as required for reproducing
# the content of the NOTICE file.
#
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0


if (WIN32)
    find_path( PTEX_INCLUDE_DIR
        NAMES
            Ptexture.h
        HINTS
            "${PTEX_LOCATION}/include"
            "$ENV{PTEX_LOCATION}/include"
        PATHS
            "$ENV{PROGRAMFILES}/Ptex/include"
            /usr/include
            DOC "The directory where Ptexture.h resides")
    find_library( PTEX_LIBRARY
        NAMES
            Ptex32 Ptex32s Ptex
        HINTS
            "${PTEX_LOCATION}/lib64"
            "${PTEX_LOCATION}/lib"
            "$ENV{PTEX_LOCATION}/lib64"
            "$ENV{PTEX_LOCATION}/lib"
        PATHS
            "$ENV{PROGRAMFILES}/Ptex/lib"
            /usr/lib64
            /usr/lib
            /usr/lib/w32api
            /usr/local/lib64
            /usr/local/lib
            DOC "The Ptex library")
elseif (APPLE)
    find_path( PTEX_INCLUDE_DIR
        NAMES
            Ptexture.h
        HINTS
            "${PTEX_LOCATION}/include"
            "$ENV{PTEX_LOCATION}/include"
        PATHS
            DOC "The directory where Ptexture.h resides")
    find_library( PTEX_LIBRARY
        NAMES
            Ptex libPtex.a
        PATHS
            "${PTEX_LOCATION}/lib"
            "$ENV{PTEX_LOCATION}/lib"
            DOC "The Ptex Library")
else ()
    find_path( PTEX_INCLUDE_DIR
        NAMES
            Ptexture.h
        HINTS
            "${PTEX_LOCATION}/include"
            "${PTEX_LOCATION}/include/wdas"
            "$ENV{PTEX_LOCATION}/include"
            "$ENV{PTEX_LOCATION}/include/wdas"
        PATHS
            /usr/include
            /usr/local/include
            DOC "The directory where Ptexture.h resides")
    find_library( PTEX_LIBRARY
        NAMES
            Ptex wdasPtex
        HINTS
            "${PTEX_LOCATION}/lib64"
            "${PTEX_LOCATION}/lib"
            "$ENV{PTEX_LOCATION}/lib64"
            "$ENV{PTEX_LOCATION}/lib"
        PATHS
            /usr/lib64
            /usr/lib
            /usr/local/lib64
            /usr/local/lib
            DOC "The Ptex library")
endif ()

if (PTEX_INCLUDE_DIR AND EXISTS "${PTEX_INCLUDE_DIR}/PtexVersion.h" )

    file(STRINGS "${PTEX_INCLUDE_DIR}/PtexVersion.h" TMP REGEX "^#define PtexAPIVersion.*$")
    string(REGEX MATCHALL "[0-9]+" API ${TMP})
    
    file(STRINGS "${PTEX_INCLUDE_DIR}/PtexVersion.h" TMP REGEX "^#define PtexLibraryMajorVersion.*$")
    string(REGEX MATCHALL "[0-9]+" MAJOR ${TMP})

    file(STRINGS "${PTEX_INCLUDE_DIR}/PtexVersion.h" TMP REGEX "^#define PtexLibraryMinorVersion.*$")
    string(REGEX MATCHALL "[0-9]+" MINOR ${TMP})

    set(PTEX_VERSION ${MAJOR}.${MINOR})

elseif (PTEX_INCLUDE_DIR AND EXISTS "${PTEX_INCLUDE_DIR}/Ptexture.h" )

    file(STRINGS "${PTEX_INCLUDE_DIR}/Ptexture.h" TMP REGEX "^#define PtexAPIVersion.*$")
    string(REGEX MATCHALL "[0-9]+" API ${TMP})
    
    file(STRINGS "${PTEX_INCLUDE_DIR}/Ptexture.h" TMP REGEX "^#define PtexFileMajorVersion.*$")
    string(REGEX MATCHALL "[0-9]+" MAJOR ${TMP})

    file(STRINGS "${PTEX_INCLUDE_DIR}/Ptexture.h" TMP REGEX "^#define PtexFileMinorVersion.*$")
    string(REGEX MATCHALL "[0-9]+" MINOR ${TMP})

    set(PTEX_VERSION ${MAJOR}.${MINOR})

endif()

include(FindPackageHandleStandardArgs)

find_package_handle_standard_args(Ptex
    REQUIRED_VARS
        PTEX_INCLUDE_DIR
        PTEX_LIBRARY
    VERSION_VAR
        PTEX_VERSION
)

if (PTEX_FOUND)
    set(Ptex_FOUND TRUE)
    set(PTEX_LIBRARIES ${PTEX_LIBRARY})
    set(PTEX_INCLUDES ${PTEX_INCLUDE_DIR})
    set(Ptex_VERSION ${PTEX_VERSION})
    if (NOT TARGET Ptex::Ptex_dynamic)
        add_library(Ptex::Ptex_dynamic UNKNOWN IMPORTED)
        set_target_properties(Ptex::Ptex_dynamic PROPERTIES
            INTERFACE_INCLUDE_DIRECTORIES "${PTEX_INCLUDES}")
        if (PTEX_LIBRARIES)
            set_property(TARGET Ptex::Ptex_dynamic APPEND PROPERTY
                IMPORTED_LOCATION "${PTEX_LIBRARIES}")
        endif ()
    endif ()
else ()
    set (PTEX_INCLUDE_DIR "")
endif()

mark_as_advanced(
  PTEX_INCLUDE_DIR
  PTEX_LIBRARY
)
