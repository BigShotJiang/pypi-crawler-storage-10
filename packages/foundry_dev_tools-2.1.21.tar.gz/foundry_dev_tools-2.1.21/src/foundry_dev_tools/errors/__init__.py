"""Custom Foundry DevTools errors."""
