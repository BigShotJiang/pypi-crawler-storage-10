import hashlib
import os


class FileCryptor:
    def __init__(self):
        self.version = "1.0.0"

    def _generate_key(self, user_key):
        """Generate a secure key from user input"""
        return hashlib.sha256(user_key.encode()).digest()

    def encrypt_file(self, input_file, output_file, key):
        """
        Encrypt file to hexadecimal format
        """
        try:
            # Generate secure key
            crypto_key = self._generate_key(key)

            # Read original file
            with open(input_file, 'rb') as f:
                file_data = f.read()

            # Simple XOR encryption with key cycling
            encrypted_data = bytearray()
            for i, byte in enumerate(file_data):
                key_byte = crypto_key[i % len(crypto_key)]
                encrypted_byte = byte ^ key_byte
                encrypted_data.append(encrypted_byte)

            # Convert to hexadecimal
            hex_data = encrypted_data.hex()

            # Save as text file
            with open(output_file, 'w') as f:
                f.write(hex_data)

            original_size = len(file_data)
            encrypted_size = len(hex_data)

            return True, f"SUCCESS: Encryption successful! Original: {original_size} bytes, Encrypted: {encrypted_size} bytes, Saved as: {output_file}"

        except Exception as e:
            return False, f"ERROR: Encryption failed: {str(e)}"

    def decrypt_file(self, encrypted_file, output_file, key):
        """
        Decrypt hexadecimal file back to original
        """
        try:
            # Generate same key
            crypto_key = self._generate_key(key)

            # Read hex data
            with open(encrypted_file, 'r') as f:
                hex_data = f.read().strip()

            # Convert hex to bytes
            try:
                encrypted_data = bytes.fromhex(hex_data)
            except ValueError:
                return False, "ERROR: Invalid hex file format"

            # Decrypt using XOR
            decrypted_data = bytearray()
            for i, byte in enumerate(encrypted_data):
                key_byte = crypto_key[i % len(crypto_key)]
                decrypted_byte = byte ^ key_byte
                decrypted_data.append(decrypted_byte)

            # Save original file
            with open(output_file, 'wb') as f:
                f.write(decrypted_data)

            return True, f"SUCCESS: Decryption successful! File restored: {output_file}"

        except Exception as e:
            return False, f"ERROR: Decryption failed: {str(e)}"


# Convenience functions
def encrypt_file(input_file, output_file, key):
    """Convenience function for encryption"""
    cryptor = FileCryptor()
    return cryptor.encrypt_file(input_file, output_file, key)


def decrypt_file(encrypted_file, output_file, key):
    """Convenience function for decryption"""
    cryptor = FileCryptor()
    return cryptor.decrypt_file(encrypted_file, output_file, key)