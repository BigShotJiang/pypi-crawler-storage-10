"""
FileCryptor - Encrypt/decrypt files using key-based hexadecimal conversion
"""

from .core import encrypt_file, decrypt_file, FileCryptor

__version__ = "1.0.0"
__all__ = ['encrypt_file', 'decrypt_file', 'FileCryptor']