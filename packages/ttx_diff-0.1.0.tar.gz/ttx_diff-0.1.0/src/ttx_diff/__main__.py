"""Allow running ttx-diff as `python -m ttx_diff`."""

from ttx_diff.cli import main

if __name__ == "__main__":
    main()
