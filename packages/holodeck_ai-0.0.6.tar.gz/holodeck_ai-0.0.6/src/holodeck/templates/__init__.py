"""HoloDeck templates module - Contains bundled project templates."""
