"""HoloDeck CLI - Command-line interface for agent initialization."""

from holodeck.cli.main import __version__, main

__all__ = ["main", "__version__"]
