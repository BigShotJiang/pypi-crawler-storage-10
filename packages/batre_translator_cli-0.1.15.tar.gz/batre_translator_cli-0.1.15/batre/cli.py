import sys
import os
from rich.console import Console

console = Console()

def print_help(user_mode=True):
    console.print("[bold cyan]Batre Translator CLI[/bold cyan]")
    console.print("Usage: batre [command]\n")

    if user_mode:
        console.print("Commands:")
        console.print("  [green]sync[/green]     Sync localization files with Batre Translator")
        console.print("  [green]export[/green]   Export translations to local project\n")
        console.print("Examples:")
        console.print("  batre sync\n  batre export\n")
    else:
        console.print("Developer Commands:")
        console.print("  [green]venv[/green]          Create Python virtual environment")
        console.print("  [green]install[/green]       Install runtime dependencies")
        console.print("  [green]install-dev[/green]   Install dev dependencies (black, isort, twine, build)")
        console.print("  [green]lint[/green]          Run black + isort formatters")
        console.print("  [green]aggregate[/green]     Run local translation aggregator")
        console.print("  [green]sync[/green]          Sync with Batre Translator API (full)")
        console.print("  [green]bump[/green]          Auto bump version in pyproject.toml")
        console.print("  [green]build[/green]         Build distribution package (wheel)")
        console.print("  [green]publish[/green]       Upload package to PyPI or GitLab")
        console.print("  [green]export[/green]        Export translations from Batre API")
        console.print("  [green]changelog[/green]     Generate changelog based on commits")
        console.print("  [green]clean[/green]         Remove venv and caches")
        console.print("  [green]clean-repo[/green]    Remove cloned temporary repos")
        console.print("  [green]setup-hooks[/green]   Setup Husky + Commitlint")
        console.print("")
        console.print("💡 Tip: You can run any of these directly from CLI:\n")
        console.print("   batre dev <command>   → calls 'make <command>' internally\n")
        console.print("Examples:")
        console.print("   batre dev build")
        console.print("   batre dev publish")
        console.print("   batre dev changelog\n")


def main():
    if len(sys.argv) < 2:
        print_help()
        sys.exit(0)

    cmd = sys.argv[1].lower()

    if cmd == "sync":
        from batre.sync import main as sync_main
        sync_main()
    elif cmd == "export":
        from batre.export import main as export_main
        export_main()
    elif cmd in ["help", "-h", "--help"]:
        print_help()
    elif cmd == "dev":
        # Developer subcommands
        if len(sys.argv) == 2 or sys.argv[2] in ["help", "--help", "-h"]:
            print_help(user_mode=False)
            sys.exit(0)

        dev_cmd = sys.argv[2]
        valid_dev_cmds = [
            "venv", "install", "install-dev", "lint", "aggregate", "sync",
            "bump", "build", "publish", "export", "changelog",
            "clean", "clean-repo", "setup-hooks"
        ]
        if dev_cmd in valid_dev_cmds:
            # 🧩 Check for 'make' availability
            if os.system("make -v > /dev/null 2>&1") != 0:
                console.print("[yellow]⚠️  'make' not found. Developer commands unavailable on this system.[/yellow]")
                sys.exit(1)

            os.system(f"make {dev_cmd}")
        else:
            console.print(f"[red]Unknown dev command:[/red] {dev_cmd}\n")
            print_help(user_mode=False)
            sys.exit(1)

    else:
        console.print(f"[red]Unknown command:[/red] {cmd}\n")
        print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
