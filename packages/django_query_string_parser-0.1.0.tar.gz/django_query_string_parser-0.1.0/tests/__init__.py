"""Tests for django-query-parser"""
