# Vertex AI Example
```bash
pip install genai-otel-instrument[vertexai]
gcloud auth application-default login
python example.py
```
