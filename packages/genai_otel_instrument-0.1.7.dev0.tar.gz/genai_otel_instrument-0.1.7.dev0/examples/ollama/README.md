# Ollama Example - Local Models
```bash
pip install genai-otel-instrument[ollama]
ollama pull llama2
python example.py
```
