# Beekeeper monitors extension - watsonx

## Installation 

```bash
pip install beekeeper-observers-watsonx
```
