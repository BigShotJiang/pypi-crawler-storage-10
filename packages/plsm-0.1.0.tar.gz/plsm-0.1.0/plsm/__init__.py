"""
Python Linux Service Manager (plsm)
专注于Linux系统服务管理的Python库

主要功能：
- 服务配置管理
- 服务状态管理
- 服务启动/停止/重启
- 服务状态监控
"""

from .config_manager import ServiceConfig, ServiceConfigManager
from .status_manager import ServiceStatus, ServiceInfo, ServiceStatusManager
from .service_manager import ServiceManager

__version__ = "0.1.0"
__author__ = "坐公交也用券"
__email__ = "liumou.site@qq.com"

__all__ = [
    "ServiceConfig",
    "ServiceConfigManager",
    "ServiceStatus", 
    "ServiceInfo",
    "ServiceStatusManager", 
    "ServiceManager",
]