// Entry point for the notebook bundle containing custom model definitions.
//
define(function() {
    "use strict";

    window['requirejs'].config({
        paths: {
            d3: 'https://cdn.jsdelivr.net/npm/d3@7.9.0/dist/d3.min'
        },
        map: {
            '*': {
                'vizpro-js': 'nbextensions/vizpro/index',
            },
        }
    });
    // Export the required load_ipython_extension function
    return {
        load_ipython_extension : function() {}
    };
});