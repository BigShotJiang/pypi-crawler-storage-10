class RubyWeb3Error(Exception):
    """Base exception for Ruby Manager Web3"""
    pass

class ContractError(RubyWeb3Error):
    """Contract-related errors"""
    pass

class TransactionError(RubyWeb3Error):
    """Transaction-related errors"""
    pass

class ConfigurationError(RubyWeb3Error):
    """Configuration-related errors"""
    pass