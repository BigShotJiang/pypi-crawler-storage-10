from dataclasses import dataclass
from typing import Optional

@dataclass
class TokenInfo:
    address: str
    name: str
    symbol: str
    decimals: int
    total_supply: int

@dataclass
class TokenBalance:
    token_address: str
    wallet_address: str
    balance: int
    readable_balance: float
    decimals: int