# LOGORYTHEM

A simple Python library for simulating common Operating System (OS) algorithms, including CPU scheduling and page replacement.

This project is designed to be a clean, importable library for academic use, allowing you to easily run and compare different algorithms.

## Features

`logorythem` includes two main modules:

### 🧠 CPU Scheduling (`scheduling`)
Calculates metrics like waiting time, turnaround time, and completion time for a list of processes.
* **First-Come, First-Served (FCFS)**
* **Round Robin (RR)**
* **Shortest Job First (SJF) Non-Preemptive**
* **Shortest Job First (SJF) Preemptive (SRTF)**

### 💾 Page Replacement (`page_replacement`)
Calculates the total number of page faults for a given reference string.
* **First-In, First-Out (FIFO)**
* **Least Recently Used (LRU)**
* **Optimal (OPT)**

---

## Installation

This project is not on PyPI. You can install it locally from this source code.

1.  Clone or download this repository.
2.  Navigate to the root `LOGORYTHEM` directory (the one with `pyproject.toml`).
3.  Run the local install command:

```bash
# This command builds and installs the library in your Python environment
pip install .