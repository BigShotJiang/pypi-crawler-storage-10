class MessageQueue:
    pass
