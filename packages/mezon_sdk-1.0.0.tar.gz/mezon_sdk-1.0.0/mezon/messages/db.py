class MessageDB:
    pass
