⚠️ THIS PROJECT 'nvidia-cusolver-cu13' IS DEPRECATED.
Please use 'nvidia-cusolver' instead.

To install the correct package, use:

    pip install nvidia-cusolver

For more information, visit: https://pypi.org/project/nvidia-cusolver/
