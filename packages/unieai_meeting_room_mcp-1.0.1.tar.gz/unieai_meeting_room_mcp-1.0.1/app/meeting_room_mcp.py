import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import asyncio

# -----------------------------
# 會議室 API Client
# -----------------------------
class MeetingRoomClient:
    def __init__(self, base_url: str = "http://0.tcp.jp.ngrok.io:11710"):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=10.0)

    async def get_rooms(self):
        """查詢所有會議室"""
        try:
            resp = await self.client.get(f"{self.base_url}/rooms")
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"查詢會議室失敗：{e.response.text}")
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線到伺服器：{str(e)}")

    async def create_reservation(self, room_id: int, start_time: str, end_time: str, reserved_by: str):
        """預約會議室"""
        data = {
            "room_id": room_id,
            "start_time": start_time,
            "end_time": end_time,
            "reserved_by": reserved_by,
        }
        try:
            resp = await self.client.post(f"{self.base_url}/reservations", json=data)
            if resp.status_code >= 400:
                raise HTTPException(status_code=resp.status_code, detail=f"預約失敗：{resp.text}")
            return resp.json()
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線到伺服器：{str(e)}")

    async def get_room_reservations(self, room_id: int):
        """查詢會議室預約紀錄"""
        try:
            resp = await self.client.get(f"{self.base_url}/rooms/{room_id}/reservations")
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            raise HTTPException(status_code=e.response.status_code, detail=f"查詢預約失敗：{e.response.text}")
        except httpx.RequestError as e:
            raise HTTPException(status_code=500, detail=f"無法連線到伺服器：{str(e)}")

    async def close(self):
        await self.client.aclose()


# -----------------------------
# Pydantic 資料模型
# -----------------------------
class ReservationRequest(BaseModel):
    room_id: int = Field(..., description="會議室 ID")
    start_time: str = Field(..., description="開始時間 (ISO 格式，例如 2025-10-21T09:00:00)")
    end_time: str = Field(..., description="結束時間 (ISO 格式)")
    reserved_by: str = Field(..., description="預約人姓名")


class ReservationResponse(BaseModel):
    reservation_id: Optional[int]
    status: str


class Room(BaseModel):
    id: int
    name: str
    capacity: int


class RoomReservation(BaseModel):
    id: int
    room_id: int
    start_time: str
    end_time: str
    reserved_by: str


# -----------------------------
# FastAPI 伺服器設定
# -----------------------------
app = FastAPI(title="Meeting Room MCP API", version="1.0.0")

client = MeetingRoomClient()


@app.get("/rooms", response_model=List[Room])
async def list_rooms():
    """取得所有會議室"""
    return await client.get_rooms()


@app.get("/rooms/{room_id}/reservations", response_model=List[RoomReservation])
async def list_room_reservations(room_id: int):
    """取得某會議室的預約紀錄"""
    return await client.get_room_reservations(room_id)


@app.post("/reservations", response_model=ReservationResponse)
async def create_reservation(req: ReservationRequest):
    """預約會議室"""
    return await client.create_reservation(
        req.room_id, req.start_time, req.end_time, req.reserved_by
    )


@app.on_event("shutdown")
async def shutdown_event():
    """應用程式關閉時釋放資源"""
    await client.close()


def main():
    """主程式入口點"""
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


if __name__ == "__main__":
    main()