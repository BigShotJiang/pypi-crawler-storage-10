from .server import serve


def main():
    """MCP Server for China Union Lotto - Help you select china union lotto numbers."""
    import argparse
    import asyncio

    # parser = argparse.ArgumentParser(
    #     description="help you select china union lotto numbers"
    # )
    # parser.add_argument("--numbers", type=str, help="how many numbers to select")

    # args = parser.parse_args()
    asyncio.run(serve())

if __name__ == "__main__":
    main()
