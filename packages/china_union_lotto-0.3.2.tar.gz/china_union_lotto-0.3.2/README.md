# china-union-lotto

## 概述
一个双色球的MCP Server项目

## 参考
https://zhuanlan.zhihu.com/p/1914511215515923435

## 开发
```shell
uv init
uv venv
.venv/Scripts/activate

uv add fastmcp
uv add asyncio
uv add argparse
uv add tzlocal

python -m china_union_lotto


uv pip install build twine
uv pip install requests beautifulsoup4 python-dotenv
uv pip install loguru

uv add beautifulsoup4
uv add loguru
uv add python-dotenv
uv add requests

# 新上传
uv add "mcp[cli]" httpx

mcp dev -v

python -m build

python -m twine upload ./dist/*

# 更新
# 更新toml文件中的版本号

uv cache clean

uvx china-union-lotto

# TODO


```
