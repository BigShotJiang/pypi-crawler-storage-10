## 0.3.1 (2025-10-24)

### 🩹 Fixes

- Version wasn't updated on release

### 📖 Documentation

- **sdk-python:** Improve doc

## 0.3.0 (2025-10-24)

### 📖 Documentation

- **sdk-python:** Improve doc

## 0.2.0 (2025-10-06)

### 🚀 Features

- **sdk-python:** Add sync/threaded version

## 0.1.1 (2025-10-01)

### 🩹 Fixes

- **sdk-python:** Include all src files into the wheel

## 0.1.0 (2025-09-30)

### 🚀 Features

- **sdk-python:** Improve dataclass usage
- **sdk-python:** Add version generation
- **sdk-python:** Use dataclass instead of TypedDict
- **sdk-python:** Initial asyncio version of Python SDK