from setuptools import setup, find_packages

setup(
    name='free-cauculator',
    version='1.0.1',
    author='Gabriel',
    description='Uma calculadora simples com Tkinter.',
    packages=find_packages(),
    python_requires='>=3.7',
)
