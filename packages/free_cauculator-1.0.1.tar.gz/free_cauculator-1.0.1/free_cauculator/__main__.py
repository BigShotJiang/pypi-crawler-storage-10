import sys
from free_cauculator.gui import iniciar_calculadora

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "play":
        iniciar_calculadora()
    else:
        print("Uso: python -m free_cauculator play")

if __name__ == "__main__":
    main()
