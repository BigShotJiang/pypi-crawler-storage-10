import tkinter as tk

def iniciar_calculadora():
    root = tk.Tk()
    root.title("Free Calculator 🧮")
    root.geometry("500x700")  # 🔹 tamanho ideal para tela cheia e conforto visual
    root.resizable(False, False)
    root.configure(bg="#1e1e1e")  # 🔹 modo escuro moderno

    entrada = tk.Entry(
        root,
        font=("Segoe UI", 32),
        borderwidth=8,
        relief="ridge",
        justify="right",
        bg="#2b2b2b",
        fg="white",
        insertbackground="white"
    )
    entrada.grid(row=0, column=0, columnspan=4, padx=20, pady=20, ipady=15)

    def clicar(num):
        entrada.insert(tk.END, num)

    def limpar():
        entrada.delete(0, tk.END)

    def calcular():
        try:
            resultado = eval(entrada.get())
            entrada.delete(0, tk.END)
            entrada.insert(tk.END, resultado)
        except Exception:
            entrada.delete(0, tk.END)
            entrada.insert(tk.END, "Erro")

    botoes = [
        "7", "8", "9", "÷",
        "4", "5", "6", "×",
        "1", "2", "3", "-",
        "0", ".", "=", "+"
    ]

    def criar_botao(texto, linha, coluna, comando=None, cor="#3a3a3a"):
        if not comando:
            comando = lambda x=texto: clicar(x)
        return tk.Button(
            root,
            text=texto,
            width=6,
            height=2,
            font=("Segoe UI", 22, "bold"),
            bg=cor,
            fg="white",
            activebackground="#555",
            activeforeground="white",
            relief="flat",
            command=comando,
            cursor="hand2"
        ).grid(row=linha, column=coluna, padx=10, pady=10, sticky="nsew")

    linha = 1
    coluna = 0
    for botao in botoes:
        cor = "#3a3a3a"
        if botao in {"+", "-", "×", "÷"}:
            cor = "#f39c12"
        elif botao == "=":
            cor = "#27ae60"
        criar_botao(botao, linha, coluna, comando=(calcular if botao == "=" else None), cor=cor)
        coluna += 1
        if coluna > 3:
            coluna = 0
            linha += 1

    tk.Button(
        root,
        text="Limpar",
        width=29,
        height=2,
        font=("Segoe UI", 20, "bold"),
        bg="#e74c3c",
        fg="white",
        activebackground="#c0392b",
        relief="flat",
        command=limpar,
        cursor="hand2"
    ).grid(row=linha, column=0, columnspan=4, padx=10, pady=20)

    for i in range(5):
        root.grid_rowconfigure(i, weight=1)
        root.grid_columnconfigure(i, weight=1)

    root.mainloop()
