# commitizen-cz-fogoprobr

## Instalação

```
pip install commitizen-cz-fogoprobr
```

## Uso

Listar commitizen instalados

```
cz ls
```

*Commit* de *code* em *stage*

```
cz --name cz_fogoprobr commit
```

Alternativamente, definindo o commitizen do projeto em um arquivo ```.cz``` do projeto

```
(echo [commitizen] & echo.name = cz_fogoprobr) >> .cz
cz commit
```

## Requisitos

- [commitizen](https://github.com/commitizen-tools/commitizen) ```2.21.2```

## Autor
Joao Fogo (melatto.fogo@live.com)

# How the template works

- ```TYPES```

    The selectable commit “types” shown in the prompt. Each item has:

    - ```value```: what goes into the message (```feat```, ```fix```, …)
    - ```name```: the human-friendly label shown in the menu.

- ```SCHEMA_PATTERN```

    A regex Commitizen uses to validate and later parse each commit’s header.

    Your pattern enforces:

    ``` 
    <type>(<scope>)!: <subject>
    ```

    where:

    - ```type``` ∈ ```feat|fix|docs|refactor|perf|test|chore```
    - ```scope``` is optional: ```(<something>)```
    - ```!``` is optional: marks a breaking change
    - ```subject``` is free text after ```:```

- ```BUMP_PATTERN``` / ```BUMP_MAP```

    Tell ```cz bump``` how to compute the next version from commit history:

  - If a commit body/footer contains **BREAKING CHANGE**, → **MAJOR**
  - If a header’s ```type``` is **feat**, →** MINOR**
  - If a header’s ```type``` is **fix**, → **PATCH**

- ```CHANGELOG_PATTERN```

Which commits are included in the changelog (your list of types).

- ```CzFogoprobr``` methods

  - ```info()``` / ```example()``` / ```schema()``` → used by help commands.
  - ```schema_pattern()``` → returns the regex above.
  - ```questions()``` → defines the interactive prompts shown by cz commit:

    1. pick ```type``` (from ```TYPES```)
    2. ```scope``` (optional)
    3. ```is_breaking``` (yes/no)
    4. ```subject``` (validated to be 5–72 chars)
  - ```message(answers)``` → builds the final commit text:
    ```
    {type}({scope}){!}: {subject}
    ```
  - ```subject(commit)``` → how a line appears in changelog sections.
  
## Quick command cheat-sheet

``` bash
cz --name cz_fogoprobr info       # show adapter info
cz --name cz_fogoprobr example    # show an example commit
cz commit                          # guided commit using your prompts
cz check                           # validate messages in range
cz bump                            # compute and apply next version
cz changelog                       # regenerate CHANGELOG.md
cz ls                              # list available adapters (your plugin should appear)
```