class ContinueDispatching(Exception):
    pass
