# torchic

 torchic is a simple and lightweight library for building and training neural networks in PyTorch.