import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DataSourceEnum(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    UPLOAD: _ClassVar[DataSourceEnum]
    PVGIS: _ClassVar[DataSourceEnum]

class ObservationTypeEnum(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TMY: _ClassVar[ObservationTypeEnum]
    OBSERVED: _ClassVar[ObservationTypeEnum]

class ObservationPeriodEnum(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Deprecated_ZenithAzimuthSpecified: _ClassVar[ObservationPeriodEnum]
    Instantaneous: _ClassVar[ObservationPeriodEnum]
    EndOfHour: _ClassVar[ObservationPeriodEnum]
    StartOfHour: _ClassVar[ObservationPeriodEnum]
    MiddleOfHour: _ClassVar[ObservationPeriodEnum]
UPLOAD: DataSourceEnum
PVGIS: DataSourceEnum
TMY: ObservationTypeEnum
OBSERVED: ObservationTypeEnum
Deprecated_ZenithAzimuthSpecified: ObservationPeriodEnum
Instantaneous: ObservationPeriodEnum
EndOfHour: ObservationPeriodEnum
StartOfHour: ObservationPeriodEnum
MiddleOfHour: ObservationPeriodEnum

class WeatherSetting(_message.Message):
    __slots__ = ("weatherRows", "Latitude", "Longitude", "Elevation_Metres", "StartDate", "EndDate", "ObservationType", "DataSource", "HorizonShadowsIncluded", "RadiationDB", "MeteoDB", "HorizonDB", "LocalStandardTimeOffset_Minutes", "LocalTimeZone_IANA", "ObservationPeriod", "versionNumber", "ObservationPeriodDuration")
    WEATHERROWS_FIELD_NUMBER: _ClassVar[int]
    LATITUDE_FIELD_NUMBER: _ClassVar[int]
    LONGITUDE_FIELD_NUMBER: _ClassVar[int]
    ELEVATION_METRES_FIELD_NUMBER: _ClassVar[int]
    STARTDATE_FIELD_NUMBER: _ClassVar[int]
    ENDDATE_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONTYPE_FIELD_NUMBER: _ClassVar[int]
    DATASOURCE_FIELD_NUMBER: _ClassVar[int]
    HORIZONSHADOWSINCLUDED_FIELD_NUMBER: _ClassVar[int]
    RADIATIONDB_FIELD_NUMBER: _ClassVar[int]
    METEODB_FIELD_NUMBER: _ClassVar[int]
    HORIZONDB_FIELD_NUMBER: _ClassVar[int]
    LOCALSTANDARDTIMEOFFSET_MINUTES_FIELD_NUMBER: _ClassVar[int]
    LOCALTIMEZONE_IANA_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONPERIOD_FIELD_NUMBER: _ClassVar[int]
    VERSIONNUMBER_FIELD_NUMBER: _ClassVar[int]
    OBSERVATIONPERIODDURATION_FIELD_NUMBER: _ClassVar[int]
    weatherRows: _containers.RepeatedCompositeFieldContainer[WeatherRow]
    Latitude: float
    Longitude: float
    Elevation_Metres: float
    StartDate: _timestamp_pb2.Timestamp
    EndDate: _timestamp_pb2.Timestamp
    ObservationType: ObservationTypeEnum
    DataSource: DataSourceEnum
    HorizonShadowsIncluded: bool
    RadiationDB: str
    MeteoDB: str
    HorizonDB: str
    LocalStandardTimeOffset_Minutes: NullableInt32
    LocalTimeZone_IANA: str
    ObservationPeriod: ObservationPeriodEnum
    versionNumber: int
    ObservationPeriodDuration: _duration_pb2.Duration
    def __init__(self, weatherRows: _Optional[_Iterable[_Union[WeatherRow, _Mapping]]] = ..., Latitude: _Optional[float] = ..., Longitude: _Optional[float] = ..., Elevation_Metres: _Optional[float] = ..., StartDate: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., EndDate: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., ObservationType: _Optional[_Union[ObservationTypeEnum, str]] = ..., DataSource: _Optional[_Union[DataSourceEnum, str]] = ..., HorizonShadowsIncluded: bool = ..., RadiationDB: _Optional[str] = ..., MeteoDB: _Optional[str] = ..., HorizonDB: _Optional[str] = ..., LocalStandardTimeOffset_Minutes: _Optional[_Union[NullableInt32, _Mapping]] = ..., LocalTimeZone_IANA: _Optional[str] = ..., ObservationPeriod: _Optional[_Union[ObservationPeriodEnum, str]] = ..., versionNumber: _Optional[int] = ..., ObservationPeriodDuration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...

class WeatherRow(_message.Message):
    __slots__ = ("ObservationTime_UTC", "GlobalHorizontalIrradiance_WattsPerMetreSquared", "DirectNormalIrradiance_WattsPerMetreSquared", "DiffuseHorizontalIrradiance_WattsPerMetreSquared", "SurfaceAirPressure_Pascals", "DryBulbTemperature_DegreesCeliusAt2Metres", "WindVelocity_MetresPerSecondAt10Metres", "WindDirection_DegreesClockwiseFromNorthAt10Metres", "RelativeHumidity_Percent", "SurfaceInfraredIrradiance_WattsPerMeterSquared", "PrecipitableWaterVapourCM", "SolarZenith", "SolarAzimuth", "Ozone_AtmCm", "Turbidity", "FarFieldAlbedo_Percent")
    OBSERVATIONTIME_UTC_FIELD_NUMBER: _ClassVar[int]
    GLOBALHORIZONTALIRRADIANCE_WATTSPERMETRESQUARED_FIELD_NUMBER: _ClassVar[int]
    DIRECTNORMALIRRADIANCE_WATTSPERMETRESQUARED_FIELD_NUMBER: _ClassVar[int]
    DIFFUSEHORIZONTALIRRADIANCE_WATTSPERMETRESQUARED_FIELD_NUMBER: _ClassVar[int]
    SURFACEAIRPRESSURE_PASCALS_FIELD_NUMBER: _ClassVar[int]
    DRYBULBTEMPERATURE_DEGREESCELIUSAT2METRES_FIELD_NUMBER: _ClassVar[int]
    WINDVELOCITY_METRESPERSECONDAT10METRES_FIELD_NUMBER: _ClassVar[int]
    WINDDIRECTION_DEGREESCLOCKWISEFROMNORTHAT10METRES_FIELD_NUMBER: _ClassVar[int]
    RELATIVEHUMIDITY_PERCENT_FIELD_NUMBER: _ClassVar[int]
    SURFACEINFRAREDIRRADIANCE_WATTSPERMETERSQUARED_FIELD_NUMBER: _ClassVar[int]
    PRECIPITABLEWATERVAPOURCM_FIELD_NUMBER: _ClassVar[int]
    SOLARZENITH_FIELD_NUMBER: _ClassVar[int]
    SOLARAZIMUTH_FIELD_NUMBER: _ClassVar[int]
    OZONE_ATMCM_FIELD_NUMBER: _ClassVar[int]
    TURBIDITY_FIELD_NUMBER: _ClassVar[int]
    FARFIELDALBEDO_PERCENT_FIELD_NUMBER: _ClassVar[int]
    ObservationTime_UTC: _timestamp_pb2.Timestamp
    GlobalHorizontalIrradiance_WattsPerMetreSquared: NullableFloat
    DirectNormalIrradiance_WattsPerMetreSquared: NullableFloat
    DiffuseHorizontalIrradiance_WattsPerMetreSquared: NullableFloat
    SurfaceAirPressure_Pascals: NullableFloat
    DryBulbTemperature_DegreesCeliusAt2Metres: NullableFloat
    WindVelocity_MetresPerSecondAt10Metres: NullableFloat
    WindDirection_DegreesClockwiseFromNorthAt10Metres: NullableFloat
    RelativeHumidity_Percent: NullableFloat
    SurfaceInfraredIrradiance_WattsPerMeterSquared: NullableFloat
    PrecipitableWaterVapourCM: NullableFloat
    SolarZenith: NullableFloat
    SolarAzimuth: NullableFloat
    Ozone_AtmCm: NullableFloat
    Turbidity: NullableFloat
    FarFieldAlbedo_Percent: NullableFloat
    def __init__(self, ObservationTime_UTC: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., GlobalHorizontalIrradiance_WattsPerMetreSquared: _Optional[_Union[NullableFloat, _Mapping]] = ..., DirectNormalIrradiance_WattsPerMetreSquared: _Optional[_Union[NullableFloat, _Mapping]] = ..., DiffuseHorizontalIrradiance_WattsPerMetreSquared: _Optional[_Union[NullableFloat, _Mapping]] = ..., SurfaceAirPressure_Pascals: _Optional[_Union[NullableFloat, _Mapping]] = ..., DryBulbTemperature_DegreesCeliusAt2Metres: _Optional[_Union[NullableFloat, _Mapping]] = ..., WindVelocity_MetresPerSecondAt10Metres: _Optional[_Union[NullableFloat, _Mapping]] = ..., WindDirection_DegreesClockwiseFromNorthAt10Metres: _Optional[_Union[NullableFloat, _Mapping]] = ..., RelativeHumidity_Percent: _Optional[_Union[NullableFloat, _Mapping]] = ..., SurfaceInfraredIrradiance_WattsPerMeterSquared: _Optional[_Union[NullableFloat, _Mapping]] = ..., PrecipitableWaterVapourCM: _Optional[_Union[NullableFloat, _Mapping]] = ..., SolarZenith: _Optional[_Union[NullableFloat, _Mapping]] = ..., SolarAzimuth: _Optional[_Union[NullableFloat, _Mapping]] = ..., Ozone_AtmCm: _Optional[_Union[NullableFloat, _Mapping]] = ..., Turbidity: _Optional[_Union[NullableFloat, _Mapping]] = ..., FarFieldAlbedo_Percent: _Optional[_Union[NullableFloat, _Mapping]] = ...) -> None: ...

class NullableFloat(_message.Message):
    __slots__ = ("null", "data")
    NULL_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    null: _struct_pb2.NullValue
    data: float
    def __init__(self, null: _Optional[_Union[_struct_pb2.NullValue, str]] = ..., data: _Optional[float] = ...) -> None: ...

class NullableInt32(_message.Message):
    __slots__ = ("null", "data")
    NULL_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    null: _struct_pb2.NullValue
    data: int
    def __init__(self, null: _Optional[_Union[_struct_pb2.NullValue, str]] = ..., data: _Optional[int] = ...) -> None: ...
