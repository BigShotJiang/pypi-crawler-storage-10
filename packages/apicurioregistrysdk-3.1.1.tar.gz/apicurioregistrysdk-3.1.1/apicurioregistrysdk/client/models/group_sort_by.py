from enum import Enum

class GroupSortBy(str, Enum):
    GroupId = "groupId",
    CreatedOn = "createdOn",
    ModifiedOn = "modifiedOn",

