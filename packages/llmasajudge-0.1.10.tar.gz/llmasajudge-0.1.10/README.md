# llmasajudge

A lightweight judge for LLM evaluation. Compares model outputs against ground truth
and returns right/wrong votes, with support for multiple models and majority voting.
