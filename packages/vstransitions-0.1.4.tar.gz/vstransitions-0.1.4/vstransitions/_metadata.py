"""VapourSynth functions for making transitions and reanimating static shots"""

__version__ = "0.1.4"

__author_name__, __author_email__ = "Setsugen no ao", "setsugen@setsugen.dev"
__maintainer_name__, __maintainer_email__ = __author_name__, __author_email__

__author__ = f"{__author_name__} <{__author_email__}>"
__maintainer__ = __author__

if __name__ == "__github__":
    print(__version__)
