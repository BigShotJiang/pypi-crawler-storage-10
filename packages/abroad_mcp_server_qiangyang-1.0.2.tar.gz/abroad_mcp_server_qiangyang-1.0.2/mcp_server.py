"""
MCP服务器 - FastMCP服务器启动入口
"""
import os
import importlib
import pkgutil
from typing import List
import asyncio
from loguru import logger

# 导入配置和工具
from mcp_framework.config.settings import settings
from mcp_framework.utils.logger import setup_logger
from mcp_framework.mcp_tools import mcp

# ------------------- 新增代码开始 -------------------
def print_routes(app):
    """打印所有已注册的路由"""
    logger.info("=" * 40)
    logger.info("==========      服务器已注册的路由      ==========")
    logger.info("=" * 40)
    for route in app.routes:
        # 尝试获取路由的更多信息
        methods = ", ".join(getattr(route, 'methods', ['N/A']))
        path = getattr(route, 'path', 'N/A')
        name = getattr(route, 'name', 'N/A')
        
        # FastAPI的路由有不同的类型，我们分别处理
        if hasattr(route, 'endpoint'):
            logger.info(f"路径: {path} | 名称: {name} | 方法: [{methods}]")
        else:
            # 可能是子挂载的应用，如WebSocket等
            logger.info(f"路径: {path} | 名称: {name} (可能为子应用或挂载点)")
    logger.info("=" * 40)
# ------------------- 新增代码结束 -------------------


def import_all_tools() -> List[str]:
    """
    动态导入所有工具模块
    
    Returns:
        已导入的工具模块名称列表
    """
    # 基础工具包路径
    package_path = os.path.dirname(os.path.abspath(__file__))
    tools_path = os.path.join(package_path, "mcp_tools")
    
    # 跳过__init__.py和不包含工具的文件
    tools_to_skip = {"__init__", "__pycache__"}
    
    imported_tools = []
    
    # 查找所有可能的工具模块
    for _, module_name, is_pkg in pkgutil.iter_modules([tools_path]):
        if module_name in tools_to_skip:
            continue
        
        try:
            # 导入工具模块
            module_path = f"mcp_framework.mcp_tools.{module_name}"
            importlib.import_module(module_path)
            logger.info(f"已加载工具模块: {module_path}")
            
            imported_tools.append(module_name)
        except Exception as e:
            logger.error(f"加载工具模块 {module_name} 失败: {str(e)}")
    
    return imported_tools

def run_mcp_server():
        """启动MCP服务器"""
        # 设置日志器
        setup_logger(
            log_file=settings.get("LOG_FILE"),
            level=settings.get("LOG_LEVEL")
        )

        # 动态导入所有工具
        imported_tools = import_all_tools() # 确保此函数在您的版本中存在且工作正常
        logger.info(f"已导入 {len(imported_tools)} 个工具模块: {', '.join(imported_tools)}")
        # 如果需要记录已注册工具，后续需要找到正确的方法，mcp.tools 不可用

        transport_mode = settings.get("MCP_TRANSPORT", "stdio").lower()

        # ------------------- 新增代码开始 -------------------
        # 在启动服务前，打印所有路由
        if hasattr(mcp, 'app'):
            print_routes(mcp.app)
        else:
            logger.warning("无法在 'mcp' 对象上找到 'app' 属性，无法打印路由。")
        # ------------------- 新增代码结束 -------------------

        if transport_mode == "sse":
            configured_sse_port = settings.get("MCP_SSE_PORT", 8000) # 用于日志记录
            logger.info(f"以SSE模式启动MCP服务器 (端口由FastMCP实例配置: {configured_sse_port})")
            # FastMCP实例在 mcp_tools/__init__.py 中已使用 settings.get("MCP_SSE_PORT") 配置了port
            mcp.run(transport="sse")

        elif transport_mode == "stdio": 
            # 默认stdio传输模式 (Cursor/Claude使用此模式)
            logger.info("启动MCP服务器 (STDIO模式)")
            mcp.run(transport="stdio")
            
        else:
            logger.error(f"不支持的传输模式: '{transport_mode}'. 支持的模式有 'http', 'sse', 'stdio'.")
            logger.info("由于传输模式未知，将默认以STDIO模式启动。")
            mcp.run(transport="stdio")

if __name__ == "__main__":
    run_mcp_server() 