"""
日志配置模块
"""
import os
import sys
from loguru import logger

def setup_logger(log_file: str = "logs/mcp_server.log", level: str = "INFO"):
    """
    设置全局日志器
    
    Args:
        log_file: 日志文件路径
        level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    # 确保日志目录存在
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)
    
    # 移除默认处理器
    logger.remove()
    
    # 添加标准输出处理器
    logger.add(
        sys.stdout,
        level=level,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    
    # 添加文件处理器
    logger.add(
        log_file,
        level=level,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        rotation="10 MB",  # 按文件大小轮转
        retention="1 week",  # 保留一周日志
        compression="zip"  # 压缩旧日志
    )
    
    logger.info(f"日志系统已初始化, 级别: {level}, 文件: {log_file}") 