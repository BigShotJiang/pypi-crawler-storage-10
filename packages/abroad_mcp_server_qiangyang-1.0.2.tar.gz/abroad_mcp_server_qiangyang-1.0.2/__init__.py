"""
MCP开发框架 - 简单易用的MCP工具开发框架
适用于开发Cursor/Claude等AI助手使用的MCP工具
"""
__version__ = "1.0.0"

import os
import sys

# 将当前包所在路径添加到系统路径，确保可以正确导入
package_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(package_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# 暴露主要模块和函数，便于导入
from mcp_framework.mcp_tools import mcp
from mcp_framework.mcp_server import run_mcp_server
from mcp_framework.config.settings import settings

__all__ = ['mcp', 'run_mcp_server', 'settings'] 