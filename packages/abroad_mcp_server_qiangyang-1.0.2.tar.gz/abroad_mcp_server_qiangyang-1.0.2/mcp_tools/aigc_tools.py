"""
AIGC工具 - 提供AI生成内容相关的MCP工具
"""
from typing import Dict, Any
from loguru import logger

from mcp_framework.mcp_tools import mcp
from mcp_framework.business.aigc.video import video_client


@mcp.tool()
async def generate_video(
    product_image_url: str,
    video_title: str,
    video_content: str,
    narration_script: str
) -> Dict[str, Any]:
    """生成营销视频
    
    该工具用于基于产品图片和视频脚本生成营销视频。提交生成任务后，会返回一个task_id，
    可以使用该task_id通过check_video_task_status工具查询视频生成进度和结果。
    
    典型使用流程：
    1. 调用本工具提交视频生成任务，获取task_id
    2. 使用task_id定期调用check_video_task_status查询生成状态
    3. 当状态为success时，可以从结果中获取视频URL
    
    Args:
        product_image_url: 产品图片的URL地址（必须是可访问的HTTP/HTTPS链接）
        video_title: 视频标题，简短描述视频主题
        video_content: 视频内容描述，详细说明视频要展示的内容
        narration_script: 视频旁白脚本，用于生成配音
        
    Returns:
        返回数据包含以下字段：
        - success: 布尔值，表示请求是否成功
        - task_id: 字符串，视频生成任务的唯一标识符，用于后续查询
        - message: 字符串，操作结果描述信息
        
        成功示例：
        {
            "success": true,
            "task_id": "abc123def456",
            "message": "视频生成任务已提交"
        }
        
        失败示例：
        {
            "success": false,
            "error": "网络请求错误",
            "message": "连接超时"
        }
    """
    logger.info(f"MCP工具: 生成视频 - 标题: {video_title}")
    
    try:
        result = await video_client.generate_video(
            product_image_url=product_image_url,
            video_title=video_title,
            video_content=video_content,
            narration_script=narration_script
        )
        
        return result
        
    except Exception as e:
        logger.error(f"生成视频失败: {str(e)}")
        return {
            "success": False,
            "error": "生成视频异常",
            "message": str(e)
        }


@mcp.tool()
async def check_video_task_status(task_id: str) -> Dict[str, Any]:
    """查询视频生成任务状态
    
    该工具用于查询之前提交的视频生成任务的当前状态和结果。
    视频生成是异步过程，通常需要几分钟到十几分钟。
    
    任务状态说明：
    - pending: 任务已提交，等待处理
    - processing/running: 正在生成视频
    - success/completed: 视频生成成功，可以获取视频URL
    - failed/error: 生成失败
    
    Args:
        task_id: 视频生成任务的唯一标识符（由generate_video工具返回）
        
    Returns:
        返回数据包含以下字段：
        - success: 布尔值，表示查询是否成功
        - task_id: 任务ID
        - status: 任务状态（pending/processing/success/failed等）
        - created_at: 任务创建时间
        - updated_at: 任务更新时间
        - video_url: 视频URL（仅当status为success时存在）
        - video_status: 视频处理状态（仅当有结果时存在）
        - video_status_message: 视频状态说明（仅当有结果时存在）
        - error_message: 错误信息（仅当失败时存在）
        
        成功且已完成示例：
        {
            "success": true,
            "task_id": "abc123def456",
            "status": "success",
            "created_at": "2025-10-27T10:00:00Z",
            "updated_at": "2025-10-27T10:05:00Z",
            "video_url": "https://example.com/videos/abc123.mp4",
            "video_status": "success",
            "video_status_message": "视频生成成功"
        }
        
        处理中示例：
        {
            "success": true,
            "task_id": "abc123def456",
            "status": "processing",
            "created_at": "2025-10-27T10:00:00Z",
            "updated_at": "2025-10-27T10:02:00Z"
        }
    """
    logger.info(f"MCP工具: 查询视频任务状态 - task_id: {task_id}")
    
    try:
        result = await video_client.get_video_task_status(task_id)
        return result
        
    except Exception as e:
        logger.error(f"查询视频任务状态失败: {str(e)}")
        return {
            "success": False,
            "error": "查询任务状态异常",
            "message": str(e)
        }


@mcp.tool()
async def generate_video_and_wait(
    product_image_url: str,
    video_title: str,
    video_content: str,
    narration_script: str,
    max_wait_minutes: int = 10
) -> Dict[str, Any]:
    """生成视频并等待完成（一步到位）
    
    该工具会提交视频生成任务，然后自动轮询等待任务完成，直到获得最终结果或超时。
    这是一个便捷工具，适合不想手动轮询的场景。
    
    注意：该工具会阻塞等待，可能需要较长时间（通常5-10分钟）。
    如果需要异步处理，建议使用generate_video和check_video_task_status组合。
    
    Args:
        product_image_url: 产品图片的URL地址
        video_title: 视频标题
        video_content: 视频内容描述
        narration_script: 视频旁白脚本
        max_wait_minutes: 最大等待时间（分钟），默认10分钟
        
    Returns:
        返回最终的任务结果，字段同check_video_task_status工具
        
        成功示例：
        {
            "success": true,
            "task_id": "abc123def456",
            "status": "success",
            "video_url": "https://example.com/videos/abc123.mp4",
            "video_status": "success",
            "video_status_message": "视频生成成功",
            "created_at": "2025-10-27T10:00:00Z",
            "updated_at": "2025-10-27T10:05:00Z"
        }
        
        超时示例：
        {
            "success": false,
            "error": "等待超时",
            "message": "视频生成超过最大等待时间 600 秒",
            "task_id": "abc123def456"
        }
    """
    logger.info(f"MCP工具: 生成视频并等待完成 - 标题: {video_title}, 最大等待: {max_wait_minutes}分钟")
    
    try:
        # 1. 提交视频生成任务
        generate_result = await video_client.generate_video(
            product_image_url=product_image_url,
            video_title=video_title,
            video_content=video_content,
            narration_script=narration_script
        )
        
        if not generate_result.get("success"):
            return generate_result
        
        task_id = generate_result.get("task_id")
        if not task_id:
            return {
                "success": False,
                "error": "未获取到任务ID",
                "message": "视频生成请求返回异常"
            }
        
        logger.info(f"视频生成任务已提交: {task_id}, 开始等待完成...")
        
        # 2. 等待任务完成
        max_wait_seconds = max_wait_minutes * 60
        result = await video_client.wait_for_video_completion(
            task_id=task_id,
            max_wait_seconds=max_wait_seconds,
            poll_interval=10  # 每10秒查询一次
        )
        
        return result
        
    except Exception as e:
        logger.error(f"生成视频并等待完成失败: {str(e)}")
        return {
            "success": False,
            "error": "操作异常",
            "message": str(e)
        }

