"""
MCP工具包 - 提供MCP工具函数
"""
from mcp.server.fastmcp import FastMCP
from mcp_framework.config.settings import settings

# 获取 MCP 名称
mcp_name = settings.get("MCP_NAME", "mytools")

# 根据最终的配置来决定 FastMCP 的初始化方式
# settings 对象此时应该已经反映了来自配置文件和命令行参数的最终值
effective_transport_mode = settings.get("MCP_TRANSPORT", "stdio").lower()

if effective_transport_mode == "sse":
    # SSE模式下，FastMCP 需要在构造时知道端口
    try:
        sse_port_for_constructor = int(settings.get("MCP_SSE_PORT", 8000))
        # 使用 print 而不是 logger，因为 logger 可能尚未在此处完全配置
        print(f"INFO: Initializing FastMCP for SSE mode with port: {sse_port_for_constructor}")
        mcp = FastMCP(mcp_name, port=sse_port_for_constructor)
    except ValueError:
        # 如果配置的 SSE 端口无效，则回退到默认端口或不带端口初始化（取决于 FastMCP 的行为）
        # 为了安全，这里我们使用一个默认值，或者您可以选择抛出错误
        default_sse_port = 8000
        print(f"WARNING: Invalid MCP_SSE_PORT value '{settings.get('MCP_SSE_PORT')}'. "
              f"FastMCP for SSE will be initialized with default port {default_sse_port}.")
        mcp = FastMCP(mcp_name, port=default_sse_port)
else:
    # 对于 stdio 模式或 HTTP 模式（如果通过 FastAPI/Uvicorn 外部处理），
    # FastMCP 构造函数中不需要 port 参数。
    print(f"INFO: Initializing FastMCP for mode '{effective_transport_mode}' (port not passed to constructor).")
    mcp = FastMCP(mcp_name)

# 导入子模块，使其中定义的工具函数被 fastmcp 注册
from . import dsp_tools
from . import analysis_tools
from . import aigc_tools