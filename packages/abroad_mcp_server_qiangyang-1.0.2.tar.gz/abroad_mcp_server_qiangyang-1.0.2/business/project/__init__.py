"""
项目配置模块 - 提供项目配置相关功能
"""
from mcp_framework.business.project.config import get_project_custom_index, get_plan_project_map 