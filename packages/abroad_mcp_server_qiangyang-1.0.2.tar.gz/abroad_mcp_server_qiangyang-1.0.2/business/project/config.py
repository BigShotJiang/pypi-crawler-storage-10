"""
项目配置API - 提供项目配置相关功能的业务接口
"""
from typing import Dict, Any
from loguru import logger

from mcp_framework.business.api_client import api_client

async def get_project_custom_index(project_id: int) -> Dict[str, Any]:
    """获取项目设置的计算指标数据
    
    Args:
        project_id: 项目ID
        
    Returns:
        项目自定义指标配置数据，包含基础字段、计算字段、行为字段等
    """
    params = {
        "id": project_id
    }
    
    # 调用API客户端发送请求
    result = await api_client.request("projects", "custom/index/get", params)
    
    if not result.get("success"):
        logger.error(f"获取项目自定义指标数据失败: {result.get('error')}")
    
    return result


async def get_project_index(project_id: int, master_id : int , module: str = "report_flow_list", identify: str = None) -> Dict[str, Any]:
    """获取项目设置的计算指标数据
    
    Args:
        project_id: 项目ID
        master_id: 主计划ID
        module: 模块标识
        identify: 自定义列标识
        
    Returns:
        项目自定义指标配置数据，包含基础字段、指标字段等
        返回数据示例：
        {
        "msg": "success",
        "code": 0,
        "data": {
            "dataColumn": [
            {
                "columns": [
                {
                    "checked": true,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "id",
                    "title": "计划ID",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "planStatusName",
                    "title": "计划状态",
                    "type": 0
                },
                {
                    "checked": true,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "budgetDay",
                    "title": "日预算",
                    "type": 0
                },
                {
                    "checked": true,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "consumerCost",
                    "title": "客户花费",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "cpm",
                    "title": "CPM",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "cpc",
                    "title": "CPC",
                    "type": 0
                }
                ],
                "key": "basic",
                "title": "基础指标"
            },
            {
                "columns": [
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "reach",
                    "title": "到达",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "action15",
                    "title": "唤端",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD1",
                    "title": "唤端成本",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD2",
                    "title": "唤端率",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD5",
                    "title": "曝光唤端率",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "action18",
                    "title": "首唤",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD3",
                    "title": "首唤成本",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD4",
                    "title": "首唤率",
                    "type": 0
                },
                {
                    "checked": false,
                    "indexCategory": "",
                    "insertRule": "",
                    "key": "actionD6",
                    "title": "曝光首唤率",
                    "type": 0
                }
                ],
                "key": "action",
                "title": "转化指标"
            }
            ],
            "identify": ""
        },
        "message": "success"
        }
    """
    params = {
        "projectId": project_id,
        "masterId": master_id,
        "module": module,
        "identify": identify
    }
    
    # 调用API客户端发送请求
    result = await api_client.request("projects", "custom/index/get", params)

    if result.get("code") != 0:
        logger.error(f"获取项目数据指标失败: {result.get('error')}")

    # 删除 draggableList 部分
    # result.pop("draggableList")
     # 只保留 dataColumn里 key为 basic 和 action 的 columns
    result["data"]["dataColumn"] = [
        item for item in result["data"]["dataColumn"] 
        if item["key"] in ["basic", "action"]
    ]
    
    return result


async def get_plan_project_map(plan_id: int) -> Dict[str, Any]:
    """获取计划对应的项目ID和名称
    
    Args:
        plan_id: 计划ID
        
    Returns:
        计划与项目的映射关系数据
    """
    params = {
        "id": plan_id
    }
    
    # 调用API客户端发送请求
    result = await api_client.request("plans", "get/project/map", params)
    
    if not result.get("success"):
        logger.error(f"获取计划项目映射关系失败: {result.get('error')}")
    
    return result 