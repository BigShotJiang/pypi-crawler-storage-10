"""
引擎模块 - 计划诊断信息相关业务逻辑
"""
from typing import Dict, Any, Optional
from loguru import logger

from mcp_framework.business.api_client import api_client

async def get_plan_flow_info(plan_id: str, day: str, hour: int = None, time_zone : int = 8) -> Dict[str, Any]:
    """获取计划诊断信息
    
    Args:
        plan_id: 计划ID
        day: 查询日期，格式为YYYY-MM-DD
        hour: 0 - 23，需要查询的小时，注意：该参数不是必须的，如果不传则代表查询整天的数据，如果指定了小时，则查询指定小时数据
        time_zone: 项目的时区，默认8(UTC+8)，非显示要求一般不指定，后端默认使用项目默认时区
        
    Returns:
        计划诊断详情数据，包含各环节过滤流量的数量
    """
    params = {
        "id": plan_id,
        "day": day,
        "timeZone": time_zone
    }
    if hour:
        params["hour"] = hour
    
    # 调用API客户端发送请求
    result = await api_client.request("flow", "plan/get", params)
    
    if not result.get("success"):
        logger.error(f"获取计划诊断信息失败: {result.get('error')}")
    
    return result 