"""
市场模块 - 账户相关业务逻辑
"""
from typing import Dict, Any, List, Optional
from loguru import logger

from mcp_framework.business.api_client import api_client

async def get_account_list(
    page: int = 1, 
    page_size: int = 10, 
    filter_params: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """获取账户列表
    
    Args:
        page: 页码，从1开始
        page_size: 每页记录数
        filter_params: 筛选条件
        
    Returns:
        账户列表数据
    """
    params = {
        "page": page,
        "pageSize": page_size
    }
    
    # 合并筛选条件
    if filter_params:
        params.update(filter_params)
    
    # 调用API客户端发送请求
    result = await api_client.request("market", "accounts/list", params)
    
    if not result.get("success"):
        logger.error(f"获取账户列表失败: {result.get('error')}")
    
    return result

async def get_account_details(account_id: str) -> Dict[str, Any]:
    """获取账户详情
    
    Args:
        account_id: 账户ID
        
    Returns:
        账户详情数据
    """
    params = {
        "accountId": account_id
    }
    
    # 调用API客户端发送请求
    result = await api_client.request("market", "accounts/get", params)
    
    if not result.get("success"):
        logger.error(f"获取账户详情失败: {result.get('error')}")
    
    return result 