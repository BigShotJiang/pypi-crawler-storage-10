"""
分析报表模块 - 提供多维分析报表相关功能
"""
from mcp_framework.business.analysis.reports import get_analysis_report 