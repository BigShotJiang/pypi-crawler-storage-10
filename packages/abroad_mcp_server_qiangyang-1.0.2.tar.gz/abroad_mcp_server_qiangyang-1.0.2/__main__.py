"""
MCP框架主模块的直接执行入口
支持通过 `python -m mcp_framework` 运行
"""
import sys
import argparse 
from mcp_framework.mcp_server import run_mcp_server
from mcp_framework.config.settings import settings


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="MCP工具服务器")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"], 
        default=None, 
        help="传输方式: stdio, 或 sse"
    )
  
    parser.add_argument( # <--- 新增SSE端口参数
        "--sse-port",
        type=int,
        default=None,
        help="SSE模式下的端口号 (例如: 8000, 会覆盖配置文件中的设置)"
    )
    
    return parser.parse_args()
 
if __name__ == "__main__":
    args = parse_args()
        
    # 更新配置
    if args.transport:
        settings.set("MCP_TRANSPORT", args.transport)
    
    if args.sse_port: 
        settings.set("MCP_SSE_PORT", args.sse_port)
    
    # 启动服务器
    run_mcp_server()