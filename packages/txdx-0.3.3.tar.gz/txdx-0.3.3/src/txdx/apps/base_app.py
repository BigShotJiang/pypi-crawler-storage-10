from abc import ABC, abstractmethod
from typing import Optional, Any

from txdx.models.todo import Todo

class BaseApp(ABC):
    name: str = "BaseApp"
    description: str = "Abstract base app"
    config: dict[str, Any] = {}

    def __init__(self, config: Optional[dict[str, Any]] = None):
        if config:
            self.config = config

    # -----------------------------
    # Configuration hook
    # -----------------------------
    @abstractmethod
    def configure(self) -> dict[str, Any]:
        """
        Ask the user for configuration (API keys, file paths, etc.)
        Returns a dict to be saved in the central config.json
        """
        raise NotImplementedError

    # -----------------------------
    # Main interface
    # -----------------------------
    @abstractmethod
    def write_todos(self, todos: list[Todo]):
        """Write todos to the target app."""
        raise NotImplementedError
