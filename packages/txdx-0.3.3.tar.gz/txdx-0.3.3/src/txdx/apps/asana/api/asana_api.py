import requests
from requests import Response


class AsanaApi:
    """Low-level Asana API client for making HTTP requests."""

    def __init__(self, api_key):
        self._api = requests.Session()

        self._api.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
        self._base_url = "https://app.asana.com/api/1.0/"

    def get(self, relative_path: str) -> dict:
        """
        Send a GET request to the Asana API.

        Args:
            relative_path: The API endpoint path (e.g., "/projects/123")

        Returns:
            The 'data' field from the API response
        """
        response = self._api.get(self._construct_url(relative_path))
        return self._handle_api_response(response).get("data", {})

    def get_paginated(self, relative_path: str) -> list:
        """
        Send paginated GET requests to retrieve all items.

        Args:
            relative_path: The API endpoint path

        Returns:
            A list of all items from all pages
        """
        items = []
        path = relative_path

        while True:
            response = self._api.get(self._construct_url(path))
            payload = self._handle_api_response(response)

            items.extend(payload.get('data', []))

            next_page = payload.get('next_page')
            if not next_page:
                break

            path = next_page.get('path', relative_path)

        return items

    def post(self, relative_path: str, data: dict = None) -> dict:
        """
        Send a POST request to the Asana API.

        Args:
            relative_path: The API endpoint path
            data: The request body data

        Returns:
            The 'data' field from the API response
        """
        response = self._api.post(self._construct_url(relative_path), json=data)
        return self._handle_api_response(response).get("data", {})

    def put(self, relative_path: str, data: dict = None) -> dict:
        """
        Send a PUT request to the Asana API.

        Args:
            relative_path: The API endpoint path
            data: The request body data

        Returns:
            The 'data' field from the API response
        """
        response = self._api.put(self._construct_url(relative_path), json=data)
        return self._handle_api_response(response).get("data", {})

    def delete(self, relative_path: str) -> dict:
        """
        Send a DELETE request to the Asana API.

        Args:
            relative_path: The API endpoint path

        Returns:
            The 'data' field from the API response
        """
        response = self._api.delete(self._construct_url(relative_path))
        return self._handle_api_response(response).get("data", {})

    def _construct_url(self, relative_path: str) -> str:
        """Construct the full URL from a relative path."""
        base = self._base_url.rstrip('/')
        path = relative_path.lstrip('/')
        return f"{base}/{path}"

    def _handle_api_response(self, response: Response) -> dict:
        """
        Handle and validate an API response.

        Args:
            response: The HTTP response object

        Returns:
            The parsed JSON payload

        Raises:
            Exception: If the response is invalid or contains errors
        """
        context = f"{response.request.method} {response.request.url}"

        try:
            payload = response.json()
        except ValueError:
            raise Exception(
                f"Invalid JSON from Asana API ({response.status_code}) for {context}: {response.text[:200]}"
            )

        errors = payload.get("errors", [])

        if errors or not response.ok:
            error_msg = errors[0].get("message") if errors else response.text[:200]
            raise Exception(f"Asana API error ({response.status_code}) for {context}: {error_msg}")

        data = payload.get("data")
        if data is None and response.status_code not in (201, 204):
            raise Exception(f"Missing 'data' field in Asana API response for {context}")

        return payload