
from typing import Any
from txdx.apps.asana.api.asana_api import AsanaApi
from txdx.apps.asana.api.tasks_api import TasksApi
from txdx.apps.base_app import BaseApp
from txdx.models.todo import Todo


class AsanaApp(BaseApp):

    def __init__(self, config: dict = None):
        super().__init__(config)
        self.base_project = self.config.get("base_project", None)
        self.parent_task = self.config.get("parent_task", None)
        self.api_token = self.config.get("api_token", None)

    def configure(self) -> dict[str, Any]:
        api_token = input(f"Enter API Token [{self.api_token}]: ").strip()

        if (not api_token):
            raise ValueError("API Token is required.")

        parent_task = input(f"Enter task GID to save todos (type none to clear) [{self.parent_task}]: ").strip()

        if (not parent_task or parent_task.lower() == 'none'):
            base_project = input(f"Enter project GID to save todos (type none to clear) [{self.base_project}]: ").strip()
        
        if ((not base_project or base_project.lower() == 'none') and (not parent_task and parent_task.lower() == 'none')):
            raise ValueError("Either project GID or task GID are required.")

        self.config['api_token'] = api_token
        self.config['base_project'] = None if base_project.lower == 'none' else base_project
        self.config['parent_task'] = None if parent_task.lower == 'none' else parent_task

        return self.config

    def write_todos(self, todos: list[Todo]):
        asana = AsanaApi(self.api_token)
        tasks_api = TasksApi(asana)
        tasks_api.create_tasks_in_batch(todos, self.base_project, self.parent_task)
