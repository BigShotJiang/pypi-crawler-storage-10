class Todo:
    def __init__(self, summary, body, file_path, line):
        """
        Creates a todo object.

        - `summary` - first line of the todo comment
        - `body` - entire todo comment (including multiline)
        - `file_path` - path to the file containing the TODO
        - `line` - line number (1-based) where TODO starts
        """
        self.summary = summary
        self.body = body
        self.file_path = file_path
        self.line = line
