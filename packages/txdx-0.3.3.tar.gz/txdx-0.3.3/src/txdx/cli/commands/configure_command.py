"""
Configure command - handles app configuration setup.
"""
from argparse import ArgumentParser, Namespace

from txdx.cli.commands.base_command import BaseCommand


class ConfigureCommand(BaseCommand):
    """Command to configure a specific app."""

    def execute(self, args: Namespace):
        """Execute the configure command."""
        app_name = args.app
        config = self.config_manager.load()

        # Find the app in available apps
        app_meta = self._find_app(config, app_name)
        if not app_meta:
            self.output.error(f"App '{app_name}' not found.")
            return

        # Load the app class
        try:
            app_class = self.app_loader.load_app_class(app_meta)
        except RuntimeError as e:
            self.output.error(str(e))
            return

        if not app_class:
            self.output.error(f"Failed to load app '{app_name}'.")
            return

        # Configure the app
        self.output.heading(f"Configuring {app_meta['name']}")
        current_config = self.config_manager.load_app_config(app_meta["name"])
        app_instance = self.app_loader.create_app_instance(app_class, current_config)

        try:
            new_config = app_instance.configure()
            self.config_manager.save_app_config(app_meta["name"], new_config)
            
            # Mark as connected
            config["connected_apps"][app_meta["name"]] = {"status": "connected"}
            self.config_manager.save(config)
            
            self.output.success(f"Configuration for '{app_meta['name']}' saved successfully.")
        except Exception as e:
            self.output.error(f"Configuration failed: {e}")

    def _find_app(self, config: dict, app_name: str) -> dict:
        """Find app metadata by name (case-insensitive)."""
        return next(
            (a for a in config["available_apps"] if a["name"].lower() == app_name.lower()),
            None
        )

    @staticmethod
    def configure_parser(parser: ArgumentParser):
        """Configure parser for the configure command."""
        parser.add_argument("app", help="App name to configure")
