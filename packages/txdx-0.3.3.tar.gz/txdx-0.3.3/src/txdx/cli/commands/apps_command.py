"""
Apps command - displays all available and connected apps.
"""
from argparse import ArgumentParser, Namespace

from txdx.cli.commands.base_command import BaseCommand


class AppsCommand(BaseCommand):
    """Command to list all available apps."""

    def execute(self, args: Namespace):
        """Execute the apps command."""
        config = self.config_manager.load()
        connected = config.get("connected_apps", {})
        available = config.get("available_apps", [])

        if not available:
            self.output.warning("No apps available.")
            return

        self.output.print_apps_table(available, connected)

    @staticmethod
    def configure_parser(parser: ArgumentParser):
        """Configure parser for the apps command."""
        # No additional arguments needed for apps command
        pass
