"""
Abstract base class for CLI commands.
All command implementations should inherit from this class.
"""
from abc import ABC, abstractmethod
from argparse import ArgumentParser, Namespace

from txdx.cli.utils.app_loader import AppLoader
from txdx.cli.utils.output import Output
from txdx.configs.config_manager import ConfigManager


class BaseCommand(ABC):
    """Base class for all CLI commands."""

    def __init__(self, config_manager: ConfigManager, output: Output, app_loader: AppLoader):
        """
        Initialize command with shared dependencies.

        Args:
            config_manager: Configuration manager instance
            output: Output handler for console display
            app_loader: App loader for dynamic app loading
        """
        self.config_manager = config_manager
        self.output = output
        self.app_loader = app_loader

    @abstractmethod
    def execute(self, args: Namespace):
        """
        Execute the command with parsed arguments.

        Args:
            args: Parsed command-line arguments
        """
        raise NotImplementedError

    @staticmethod
    @abstractmethod
    def configure_parser(parser: ArgumentParser):
        """
        Configure the argument parser for this command.

        Args:
            parser: ArgumentParser to configure
        """
        raise NotImplementedError
