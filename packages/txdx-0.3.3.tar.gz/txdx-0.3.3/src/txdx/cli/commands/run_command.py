"""
Run command - scans codebase for TODOs and exports to configured apps.
"""
from argparse import ArgumentParser, Namespace
from typing import List

from txdx.cli.commands.base_command import BaseCommand
from txdx.services.files_service import FilesService
from txdx.services.todo_service import TodoService
from txdx.models.todo import Todo


class RunCommand(BaseCommand):
    """Command to scan codebase and export TODOs."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.todo_service = TodoService()

    def execute(self, args: Namespace):
        """Execute the run command."""
        # Scan for TODOs
        todos = self._scan_todos(args)
        
        if not todos:
            self.output.info("No TODOs found in the codebase.")
            return

        # Export to apps
        if not args.apps:
            self.output.warning("No apps specified. Use --apps to define export targets.")
            self.output.info(f"Found {len(todos)} TODOs. Specify --apps to export them.")
            return

        self._export_todos(todos, args.apps)

    def _scan_todos(self, args: Namespace) -> List[Todo]:
        """Scan the codebase for TODO comments."""
        with self.output.progress_context("Scanning codebase...") as progress:
            task = progress.add_task("Scanning...", total=None)
            
            files_service = FilesService(
                include_ignored=args.noignore,
                ignore_file=args.ignore,
                directory=args.dir,
                recursive=args.r if hasattr(args, 'r') else True,
            )

            files = files_service.get_files()
            todos = self.todo_service.get_todos(files)
            
            progress.update(task, completed=True)

        self.output.print_scan_summary(len(files), len(todos))
        return todos

    def _export_todos(self, todos: List[Todo], apps_string: str):
        """Export TODOs to specified apps."""
        config = self.config_manager.load()
        target_apps = [a.strip() for a in apps_string.split(",")]

        for app_name in target_apps:
            self._export_to_app(app_name, todos, config)

        self.output.success("All exports completed!")

    def _export_to_app(self, app_name: str, todos: List[Todo], config: dict):
        """Export TODOs to a single app."""
        # Find app metadata
        app_meta = next(
            (a for a in config["available_apps"] if a["name"].lower() == app_name.lower()),
            None
        )

        if not app_meta:
            self.output.error(f"Unknown app '{app_name}', skipping.")
            return

        # Check if connected
        connected = config.get("connected_apps", {}).get(app_meta["name"], {}).get("status") == "connected"
        if not connected:
            self.output.warning(f"App '{app_meta['name']}' is not connected. Run 'txdx configure {app_name}' first.")
            return

        # Load app class
        try:
            app_class = self.app_loader.load_app_class(app_meta)
        except RuntimeError as e:
            self.output.error(f"Failed to load '{app_meta['name']}': {e}")
            return

        if not app_class:
            self.output.error(f"Failed to load app '{app_meta['name']}'.")
            return

        # Export TODOs
        app_config = self.config_manager.load_app_config(app_meta["name"])
        app_instance = self.app_loader.create_app_instance(app_class, app_config)

        try:
            with self.output.progress_context(f"Exporting to {app_meta['name']}...") as progress:
                task = progress.add_task("Exporting...", total=None)
                app_instance.write_todos(todos)
                progress.update(task, completed=True)
            
            self.output.success(f"Exported {len(todos)} TODOs to {app_meta['name']}")
        except Exception as e:
            self.output.error(f"Export to {app_meta['name']} failed: {e}")

    @staticmethod
    def configure_parser(parser: ArgumentParser):
        """Configure parser for the run command."""
        parser.add_argument("--apps", type=str, help="Comma-separated list of apps to write to")
        parser.add_argument("-n", "--noignore", action="store_true", help="Include git-ignored files")
        parser.add_argument("--ignore", type=str, help="Path to custom ignore file or directory")
        parser.add_argument("-dir", type=str, help="Directory to scan")
        parser.add_argument("-r", action="store_true", help="Recursively scan directory")
