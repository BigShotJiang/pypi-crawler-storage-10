"""
Remove command - removes app configuration and credentials.
"""
from argparse import ArgumentParser, Namespace

from txdx.cli.commands.base_command import BaseCommand


class RemoveCommand(BaseCommand):
    """Command to remove an app's configuration."""

    def execute(self, args: Namespace):
        """Execute the remove command."""
        app_name = args.app
        config = self.config_manager.load()

        # Check if app exists
        if app_name not in config.get("connected_apps", {}):
            self.output.warning(f"App '{app_name}' is not configured.")
            return

        # Remove from connected apps
        if app_name in config.get("connected_apps", {}):
            del config["connected_apps"][app_name]

        # Remove app config
        if app_name in config.get("apps_config", {}):
            del config["apps_config"][app_name]

        self.config_manager.save(config)
        self.output.success(f"Removed configuration for '{app_name}'.")

    @staticmethod
    def configure_parser(parser: ArgumentParser):
        """Configure parser for the remove command."""
        parser.add_argument("app", help="App name to remove")
