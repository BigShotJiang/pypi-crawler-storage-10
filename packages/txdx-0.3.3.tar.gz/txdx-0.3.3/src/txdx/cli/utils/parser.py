"""
Argument parser configuration for the CLI.
Builds the parser structure with all command subparsers.
"""
import argparse
from typing import Dict, Type

from txdx.cli.commands.base_command import BaseCommand
from txdx.cli.commands.apps_command import AppsCommand
from txdx.cli.commands.configure_command import ConfigureCommand
from txdx.cli.commands.remove_command import RemoveCommand
from txdx.cli.commands.run_command import RunCommand


class Parser:
    """Handles CLI argument parsing configuration."""

    def __init__(self):
        self.parser = self._build_parser()
        self.command_map = self._build_command_map()

    def parse(self, argv: list) -> argparse.Namespace:
        """Parse command-line arguments."""
        return self.parser.parse_args(argv)

    def get_command_class(self, command_name: str) -> Type[BaseCommand]:
        """Get the command class for a given command name."""
        return self.command_map.get(command_name)

    def _build_parser(self) -> argparse.ArgumentParser:
        """Build the main argument parser with all subcommands."""
        parser = argparse.ArgumentParser(
            prog="txdx",
            description="TODO-to-Task CLI — manage and sync TODOs with task apps",
            add_help=False
        )

        parser.add_argument(
            "-h", "--help", "-?",
            action="help",
            help="Show help message and exit"
        )

        subparsers = parser.add_subparsers(dest="command", required=True)

        # Configure subparser
        configure_parser = subparsers.add_parser(
            "configure",
            help="Set up a specific app"
        )
        ConfigureCommand.configure_parser(configure_parser)

        # Apps subparser
        apps_parser = subparsers.add_parser(
            "apps",
            help="List all active and available apps"
        )
        AppsCommand.configure_parser(apps_parser)

        # Remove subparser
        remove_parser = subparsers.add_parser(
            "remove",
            help="Remove app configuration"
        )
        RemoveCommand.configure_parser(remove_parser)

        # Run subparser
        run_parser = subparsers.add_parser(
            "run",
            help="Scan codebase and export TODOs"
        )
        RunCommand.configure_parser(run_parser)

        return parser

    def _build_command_map(self) -> Dict[str, Type[BaseCommand]]:
        """Build mapping of command names to command classes."""
        return {
            "configure": ConfigureCommand,
            "apps": AppsCommand,
            "remove": RemoveCommand,
            "run": RunCommand,
        }