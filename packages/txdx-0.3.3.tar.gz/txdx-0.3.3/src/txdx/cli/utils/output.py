"""
Console output handler using rich for beautiful terminal UI.
Provides consistent styling and formatting across the CLI.
"""
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from typing import List, Dict, Any


class Output:
    """Handles all console output with rich formatting."""

    def __init__(self):
        self.console = Console()

    def success(self, message: str):
        """Print success message with green checkmark."""
        self.console.print(f"[green]✓[/green] {message}")

    def error(self, message: str):
        """Print error message with red X."""
        self.console.print(f"[red]✗[/red] {message}", style="red")

    def warning(self, message: str):
        """Print warning message with yellow icon."""
        self.console.print(f"[yellow]⚠[/yellow] {message}", style="yellow")

    def info(self, message: str):
        """Print info message with blue icon."""
        self.console.print(f"[blue]ℹ[/blue] {message}")

    def heading(self, text: str):
        """Print a section heading."""
        self.console.print(f"\n[bold cyan]{text}[/bold cyan]")

    def print(self, message: str):
        """Print plain message."""
        self.console.print(message)

    def print_apps_table(self, apps: List[Dict[str, Any]], connected_apps: Dict[str, Any]):
        """Display apps in a formatted table."""
        table = Table(title="Available Apps", show_header=True, header_style="bold magenta")
        table.add_column("Name", style="cyan", width=15)
        table.add_column("Status", width=15)
        table.add_column("Description", style="white")

        for app in apps:
            name = app["name"]
            description = app["description"]
            status = connected_apps.get(name, {}).get("status", "not connected")
            
            # Style status with colors
            if status == "connected":
                status_text = "[green]✓ connected[/green]"
            else:
                status_text = "[dim]not connected[/dim]"

            table.add_row(name, status_text, description)

        self.console.print(table)

    def print_scan_summary(self, files_count: int, todos_count: int):
        """Display scan results summary."""
        panel = Panel(
            f"[cyan]Files scanned:[/cyan] {files_count}\n"
            f"[cyan]TODOs found:[/cyan] {todos_count}",
            title="[bold]Scan Results[/bold]",
            border_style="green"
        )
        self.console.print(panel)

    def progress_context(self, description: str):
        """Create a progress context manager for long operations."""
        return Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
            transient=True
        )

    def panel(self, content: str, title: str = "", style: str = ""):
        """Display content in a panel."""
        self.console.print(Panel(content, title=title, border_style=style))
