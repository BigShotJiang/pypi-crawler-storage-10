"""
Service for dynamically loading and instantiating app classes.
Handles the complexity of importing modules and finding BaseApp subclasses.
"""
import importlib.util
import inspect
import sys
from pathlib import Path
from typing import Optional, Type

from txdx.apps.base_app import BaseApp


class AppLoader:
    """Handles dynamic loading of app classes."""

    @staticmethod
    def load_app_class(app_meta: dict) -> Optional[Type[BaseApp]]:
        """
        Dynamically load an app class from its file path.

        Args:
            app_meta: Dictionary containing app metadata (name, path, description)

        Returns:
            The loaded app class, or None if loading fails
        """
        try:
            path = Path(app_meta["path"])
            spec = importlib.util.spec_from_file_location(app_meta["name"], str(path))
            
            if not spec or not spec.loader:
                return None

            module = importlib.util.module_from_spec(spec)
            sys.modules[app_meta["name"]] = module
            spec.loader.exec_module(module)

        except Exception as e:
            raise RuntimeError(f"Failed to import {app_meta['name']}: {e}")

        # Find the BaseApp subclass in the module
        for _, cls in inspect.getmembers(module, inspect.isclass):
            if issubclass(cls, BaseApp) and cls is not BaseApp:
                return cls

        return None

    @staticmethod
    def create_app_instance(app_class: Type[BaseApp], config: dict) -> BaseApp:
        """
        Create an instance of an app class with the given configuration.

        Args:
            app_class: The app class to instantiate
            config: Configuration dictionary for the app

        Returns:
            An instance of the app
        """
        return app_class(config)
