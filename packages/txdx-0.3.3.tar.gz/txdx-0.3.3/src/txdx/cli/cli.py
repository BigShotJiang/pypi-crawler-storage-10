"""
Main CLI orchestrator - coordinates all CLI components.
This is a thin layer that delegates to specialized components.
"""
from typing import List

from txdx.cli.utils.app_loader import AppLoader
from txdx.cli.utils.output import Output
from txdx.cli.utils.parser import Parser
from txdx.configs.config_manager import ConfigManager


class CLI:
    """
    Main command-line interface orchestrator.
    
    Responsibilities:
    - Initialize dependencies
    - Parse arguments
    - Dispatch to appropriate command
    - Handle top-level errors
    """

    def __init__(self):
        """Initialize CLI with all dependencies."""
        self.output = Output()
        self.config_manager = ConfigManager()
        self.app_loader = AppLoader()
        self.parser = Parser()

    def run(self, argv: List[str]):
        """
        Run the CLI with the given arguments.

        Args:
            argv: List of command-line arguments (excluding program name)
        """
        try:
            # Parse arguments
            args = self.parser.parse(argv)

            # Get command class
            command_class = self.parser.get_command_class(args.command)
            
            if not command_class:
                self.output.error(f"Unknown command: {args.command}")
                return

            # Instantiate and execute command
            command = command_class(
                config_manager=self.config_manager,
                output=self.output,
                app_loader=self.app_loader
            )
            command.execute(args)

        except KeyboardInterrupt:
            self.output.warning("\nOperation cancelled by user.")
        except Exception as e:
            self.output.error(f"An unexpected error occurred: {e}")
            # Optionally add debug mode to show full traceback
            # import traceback
            # traceback.print_exc()
