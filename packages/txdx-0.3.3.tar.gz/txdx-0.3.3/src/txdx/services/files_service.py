from pathlib import Path
from typing import List, Optional
import os
import pathspec


class FilesService:
    """
    Service responsible for discovering files in a codebase according to
    CLI-like arguments. It supports .gitignore filtering, directory selection,
    recursion, and overrides.
    """

    def __init__(
        self,
        include_ignored: bool = False,
        ignore_file: Optional[str] = None,
        directory: Optional[str] = None,
        recursive: bool = True,
    ):
        """
        Initializes a file scanning service.

        Args:
            include_ignored: If True, include files ignored by .gitignore.
            ignore_file: Path to a custom ignore file or directory containing one.
            directory: Directory to scan (defaults to current working directory).
            recursive: Whether to scan directories recursively.
        """
        self.include_ignored = include_ignored
        self.ignore_file = ignore_file
        self.directory = Path(directory or os.getcwd())
        self.recursive = recursive

        self._gitignore_spec = None
        if not include_ignored:
            self._gitignore_spec = self._load_ignore_spec()

    def get_files(self) -> List[str]:
        """
        Returns a list of file paths matching the configured parameters.
        """
        all_files = self._collect_files()
        if self._gitignore_spec:
            all_files = self._filter_ignored_files(all_files)
        return [str(file) for file in all_files]

    # -------------------------
    # Internal helper functions
    # -------------------------

    def _collect_files(self) -> List[Path]:
        """Collect all files from the specified directory."""
        if self.recursive:
            return [f for f in self.directory.rglob("*") if f.is_file()]
        return [f for f in self.directory.glob("*") if f.is_file()]

    def _load_ignore_spec(self) -> Optional[pathspec.PathSpec]:
        """
        Load .gitignore or custom ignore file into a PathSpec for pattern matching.
        """
        ignore_path = self._resolve_ignore_file()
        if not ignore_path or not ignore_path.exists():
            return None

        try:
            with ignore_path.open("r", encoding="utf-8") as f:
                return pathspec.PathSpec.from_lines("gitwildmatch", f)
        except Exception:
            return None

    def _resolve_ignore_file(self) -> Optional[Path]:
        """Resolve which ignore file should be used."""
        if self.ignore_file:
            custom_path = Path(self.ignore_file)
            if custom_path.is_dir():
                return custom_path / ".gitignore"
            return custom_path

        # Fallback to .gitignore in repo root
        gitignore_path = self.directory / ".gitignore"
        return gitignore_path if gitignore_path.exists() else None

    def _filter_ignored_files(self, files: List[Path]) -> List[Path]:
        """Filter out files that match .gitignore patterns."""
        if not self._gitignore_spec:
            return files

        base = self.directory.resolve()
        return [
            f
            for f in files
            if not self._gitignore_spec.match_file(str(f.relative_to(base)))
        ]
