"""
Path resolver - determines configuration directory locations.
Handles OS-specific configuration paths following best practices.
"""
import os
from pathlib import Path
from typing import Optional


class PathResolver:
    """Resolves configuration directory paths for different operating systems."""

    CONFIG_DIR_NAME = ".txdx"

    @classmethod
    def get_config_dir(cls, custom_dir: Optional[Path] = None) -> Path:
        """
        Get the configuration directory path.

        Args:
            custom_dir: Optional custom configuration directory

        Returns:
            Path to configuration directory

        Note:
            - On Windows: %APPDATA%/.txdx
            - On macOS/Linux: ~/.txdx
            - Can be overridden with custom_dir parameter
        """
        if custom_dir:
            return Path(custom_dir).resolve()

        if os.name == "nt":
            # Windows: use APPDATA
            appdata = os.getenv("APPDATA")
            if appdata:
                return Path(appdata) / cls.CONFIG_DIR_NAME
            
            return Path.home() / cls.CONFIG_DIR_NAME
        else:
            # Unix-like: use home directory
            return Path.home() / cls.CONFIG_DIR_NAME

    @classmethod
    def get_config_file_path(cls, custom_dir: Optional[Path] = None) -> Path:
        """
        Get the full path to the configuration file.

        Args:
            custom_dir: Optional custom configuration directory

        Returns:
            Path to config.json file
        """
        return cls.get_config_dir(custom_dir) / "config.json"

    @classmethod
    def ensure_config_dir_exists(cls, custom_dir: Optional[Path] = None) -> Path:
        """
        Ensure the configuration directory exists, creating it if necessary.

        Args:
            custom_dir: Optional custom configuration directory

        Returns:
            Path to configuration directory
        """
        config_dir = cls.get_config_dir(custom_dir)
        config_dir.mkdir(parents=True, exist_ok=True)
        return config_dir

    @classmethod
    def is_writable(cls, custom_dir: Optional[Path] = None) -> bool:
        """
        Check if the configuration directory is writable.

        Args:
            custom_dir: Optional custom configuration directory

        Returns:
            True if directory is writable, False otherwise
        """
        try:
            config_dir = cls.ensure_config_dir_exists(custom_dir)
            test_file = config_dir / ".write_test"
            
            # Try to write and remove a test file
            test_file.touch()
            test_file.unlink()
            return True
        except (OSError, PermissionError):
            return False
