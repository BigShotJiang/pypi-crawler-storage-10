"""
App discovery - finds and catalogs available app plugins.
Discovers all classes that inherit from BaseApp in the apps package.
"""
import importlib
import inspect
import pkgutil
from typing import List, Dict, Any, Optional
from pathlib import Path


class AppDiscovery:
    """Discovers available app plugins in the apps package."""

    def __init__(self, apps_package: str = "txdx.apps"):
        """
        Initialize app discovery.

        Args:
            apps_package: Fully qualified name of the apps package
        """
        self.apps_package = apps_package
        self._base_app_class = None

    def discover_apps(self) -> List[Dict[str, Any]]:
        """
        Discover all available apps in the apps package.

        Returns:
            List of app metadata dictionaries with keys: name, description, path

        Note:
            This method handles both development and installed package scenarios.
            It gracefully handles import errors and skips problematic modules.
        """
        apps = []

        try:
            package = importlib.import_module(self.apps_package)
        except ImportError as e:
            print(f"Warning: Could not import apps package '{self.apps_package}': {e}")
            return []

        # Import BaseApp for comparison
        try:
            base_module = importlib.import_module(f"{self.apps_package}.base_app")
            self._base_app_class = getattr(base_module, "BaseApp")
        except (ImportError, AttributeError) as e:
            print(f"Warning: Could not import BaseApp: {e}")
            return []

        # Discover apps in the package
        apps.extend(self._discover_in_package(package))

        return sorted(apps, key=lambda x: x["name"].lower())

    def _discover_in_package(self, package) -> List[Dict[str, Any]]:
        """
        Recursively discover apps in a package.

        Args:
            package: The package to search

        Returns:
            List of discovered app metadata
        """
        apps = []
        package_path = getattr(package, "__path__", None)

        if not package_path:
            return apps

        # Iterate through all modules in the package
        for _, module_name, is_pkg in pkgutil.iter_modules(package_path):
            # Skip base_app module and certain utility packages
            if module_name in ("base_app",):
                continue

            full_module_name = f"{package.__name__}.{module_name}"

            try:
                module = importlib.import_module(full_module_name)
                
                # Always check the current module for apps first
                apps.extend(self._find_apps_in_module(module))
                
                # If it's a package, recurse into it
                if is_pkg:
                    apps.extend(self._discover_in_package(module))

            except Exception as e:
                # Log but don't fail - some modules might have import issues
                print(f"Warning: Could not import module '{full_module_name}': {e}")
                continue

        return apps

    def _find_apps_in_module(self, module) -> List[Dict[str, Any]]:
        """
        Find BaseApp subclasses in a module.

        Args:
            module: The module to search

        Returns:
            List of discovered app metadata
        """
        apps = []

        if not self._base_app_class:
            return apps

        for name, obj in inspect.getmembers(module, inspect.isclass):
            # Check if it's a BaseApp subclass (but not BaseApp itself)
            if (issubclass(obj, self._base_app_class) and 
                obj is not self._base_app_class and
                obj.__module__ == module.__name__):  # Ensure it's defined in this module
                
                app_info = self._extract_app_info(obj, module)
                if app_info:
                    apps.append(app_info)

        return apps

    def _extract_app_info(self, app_class, module) -> Optional[Dict[str, Any]]:
        """
        Extract metadata from an app class.

        Args:
            app_class: The app class to extract info from
            module: The module containing the class

        Returns:
            Dictionary with app metadata, or None if extraction fails
        """
        try:
            return {
                "name": getattr(app_class, "name", app_class.__name__),
                "description": getattr(app_class, "description", "No description provided"),
                "path": str(Path(module.__file__).resolve()),
                "class_name": app_class.__name__,
                "module": module.__name__
            }
        except Exception as e:
            print(f"Warning: Could not extract info from {app_class.__name__}: {e}")
            return None

    def validate_app_metadata(self, app_info: Dict[str, Any]) -> bool:
        """
        Validate that app metadata has required fields.

        Args:
            app_info: App metadata dictionary

        Returns:
            True if valid, False otherwise
        """
        required_fields = ["name", "description", "path"]
        return all(field in app_info for field in required_fields)