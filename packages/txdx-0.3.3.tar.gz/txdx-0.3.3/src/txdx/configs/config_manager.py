"""
Configuration Manager - orchestrates configuration management.
Coordinates configuration storage, app discovery, and validation.
"""
from pathlib import Path
from typing import Dict, Any, Optional

from txdx.configs.config_store import ConfigStore
from txdx.configs.app_discovery import AppDiscovery
from txdx.configs.path_resolver import PathResolver
from txdx.configs.config_validator import ConfigValidator


class ConfigManager:
    """
    Manages application configuration.
    
    Responsibilities:
    - Load and save configuration
    - Discover available apps
    - Manage app-specific configurations
    - Validate configuration data
    
    This class follows the Single Responsibility Principle by delegating
    specific tasks to specialized components.
    """

    def __init__(self, custom_config_dir: Optional[Path] = None, apps_package: str = "txdx.apps"):
        """
        Initialize the configuration manager.

        Args:
            custom_config_dir: Optional custom configuration directory
            apps_package: Package name where apps are located
        """
        # Initialize components
        config_path = PathResolver.get_config_file_path(custom_config_dir)
        self.store = ConfigStore(config_path)
        self.discovery = AppDiscovery(apps_package)
        self.validator = ConfigValidator()

        # Ensure configuration exists
        self._initialize_config()

    # -----------------------------
    # Public API - Configuration
    # -----------------------------

    def load(self) -> Dict[str, Any]:
        """
        Load configuration from disk and refresh available apps.

        Returns:
            Configuration dictionary with refreshed app list
        """
        config = self.store.load()
        
        # Sanitize to ensure structure is valid
        config = self.validator.sanitize_config(config)
        
        # Refresh available apps on every load
        config["available_apps"] = self.discovery.discover_apps()
        
        return config

    def save(self, config: Dict[str, Any]) -> None:
        """
        Validate and save configuration to disk.

        Args:
            config: Configuration dictionary to save

        Raises:
            ValueError: If configuration is invalid
            OSError: If unable to write to disk
        """
        # Validate before saving
        is_valid, error_msg = self.validator.validate_config(config)
        if not is_valid:
            raise ValueError(f"Invalid configuration: {error_msg}")

        self.store.save(config)

    # -----------------------------
    # Public API - App Configuration
    # -----------------------------

    def load_app_config(self, app_name: str) -> Dict[str, Any]:
        """
        Load configuration for a specific app.

        Args:
            app_name: Name of the app

        Returns:
            App configuration dictionary (empty dict if not found)
        """
        config = self.load()
        return config.get("apps_config", {}).get(app_name, {})

    def save_app_config(self, app_name: str, app_config: Dict[str, Any]) -> None:
        """
        Save configuration for a specific app.

        Args:
            app_name: Name of the app
            app_config: App configuration dictionary

        Raises:
            ValueError: If app configuration is invalid
        """
        # Validate app config
        is_valid, error_msg = self.validator.validate_app_config(app_name, app_config)
        if not is_valid:
            raise ValueError(error_msg)

        # Load, update, and save
        config = self.load()
        if "apps_config" not in config:
            config["apps_config"] = {}
        
        config["apps_config"][app_name] = app_config
        self.save(config)

    def delete_app_config(self, app_name: str) -> bool:
        """
        Delete configuration for a specific app.

        Args:
            app_name: Name of the app

        Returns:
            True if config was deleted, False if it didn't exist
        """
        config = self.load()
        
        deleted = False
        
        # Remove from connected apps
        if app_name in config.get("connected_apps", {}):
            del config["connected_apps"][app_name]
            deleted = True

        # Remove from apps config
        if app_name in config.get("apps_config", {}):
            del config["apps_config"][app_name]
            deleted = True

        if deleted:
            self.save(config)
        
        return deleted

    # -----------------------------
    # Public API - App Management
    # -----------------------------

    def mark_app_connected(self, app_name: str) -> None:
        """
        Mark an app as connected.

        Args:
            app_name: Name of the app
        """
        config = self.load()
        if "connected_apps" not in config:
            config["connected_apps"] = {}
        
        config["connected_apps"][app_name] = {"status": "connected"}
        self.save(config)

    def mark_app_disconnected(self, app_name: str) -> None:
        """
        Mark an app as disconnected.

        Args:
            app_name: Name of the app
        """
        config = self.load()
        if app_name in config.get("connected_apps", {}):
            del config["connected_apps"][app_name]
            self.save(config)

    def is_app_connected(self, app_name: str) -> bool:
        """
        Check if an app is connected.

        Args:
            app_name: Name of the app

        Returns:
            True if connected, False otherwise
        """
        config = self.load()
        return self.validator.is_app_connected(config, app_name)

    def get_available_apps(self) -> list:
        """
        Get list of all available apps.

        Returns:
            List of app metadata dictionaries
        """
        return self.discovery.discover_apps()

    def find_app(self, app_name: str) -> Optional[Dict[str, Any]]:
        """
        Find app metadata by name (case-insensitive).

        Args:
            app_name: Name of the app

        Returns:
            App metadata dictionary, or None if not found
        """
        config = self.load()
        return self.validator.find_app_by_name(config, app_name)

    # -----------------------------
    # Private Methods
    # -----------------------------

    def _initialize_config(self) -> None:
        """Initialize configuration if it doesn't exist."""
        if not self.store.exists():
            initial_config = {
                "connected_apps": {},
                "apps_config": {},
                "available_apps": self.discovery.discover_apps()
            }
            self.store.save(initial_config)

    # -----------------------------
    # Utility Methods
    # -----------------------------

    def get_config_path(self) -> Path:
        """Get the path to the configuration file."""
        return self.store.config_path

    def config_exists(self) -> bool:
        """Check if configuration file exists."""
        return self.store.exists()

    def reset_config(self) -> None:
        """Reset configuration to default state (dangerous!)."""
        default_config = {
            "connected_apps": {},
            "apps_config": {},
            "available_apps": self.discovery.discover_apps()
        }
        self.store.save(default_config)
