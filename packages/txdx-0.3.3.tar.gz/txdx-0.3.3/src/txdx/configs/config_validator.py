"""
Configuration validator - validates configuration data structure and content.
Ensures configuration integrity and provides helpful error messages.
"""
from typing import Dict, Any, List, Optional


class ConfigValidator:
    """Validates configuration data structures."""

    @staticmethod
    def validate_config(config: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """
        Validate the overall configuration structure.

        Args:
            config: Configuration dictionary to validate

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not isinstance(config, dict):
            return False, "Configuration must be a dictionary"

        required_keys = ["connected_apps", "apps_config", "available_apps"]
        for key in required_keys:
            if key not in config:
                return False, f"Missing required key: {key}"

        # Validate each section
        if not isinstance(config["connected_apps"], dict):
            return False, "connected_apps must be a dictionary"

        if not isinstance(config["apps_config"], dict):
            return False, "apps_config must be a dictionary"

        if not isinstance(config["available_apps"], list):
            return False, "available_apps must be a list"

        return True, None

    @staticmethod
    def validate_app_config(app_name: str, app_config: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """
        Validate an individual app's configuration.

        Args:
            app_name: Name of the app
            app_config: App configuration dictionary

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not isinstance(app_config, dict):
            return False, f"Configuration for {app_name} must be a dictionary"

        # TODO App-specific validation could go here
        # For now, just ensure it's a dict

        return True, None

    @staticmethod
    def sanitize_config(config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sanitize configuration by ensuring all required keys exist.

        Args:
            config: Configuration dictionary to sanitize

        Returns:
            Sanitized configuration dictionary
        """
        sanitized = {
            "connected_apps": config.get("connected_apps", {}),
            "apps_config": config.get("apps_config", {}),
            "available_apps": config.get("available_apps", [])
        }

        # Ensure connected_apps are valid
        if not isinstance(sanitized["connected_apps"], dict):
            sanitized["connected_apps"] = {}

        # Ensure apps_config are valid
        if not isinstance(sanitized["apps_config"], dict):
            sanitized["apps_config"] = {}

        # Ensure available_apps is a list
        if not isinstance(sanitized["available_apps"], list):
            sanitized["available_apps"] = []

        return sanitized

    @staticmethod
    def is_app_connected(config: Dict[str, Any], app_name: str) -> bool:
        """
        Check if an app is connected.

        Args:
            config: Configuration dictionary
            app_name: Name of the app

        Returns:
            True if app is connected, False otherwise
        """
        connected_apps = config.get("connected_apps", {})
        app_info = connected_apps.get(app_name, {})
        return app_info.get("status") == "connected"

    @staticmethod
    def get_app_names(config: Dict[str, Any]) -> List[str]:
        """
        Get list of all available app names.

        Args:
            config: Configuration dictionary

        Returns:
            List of app names
        """
        available_apps = config.get("available_apps", [])
        return [app["name"] for app in available_apps if "name" in app]

    @staticmethod
    def find_app_by_name(config: Dict[str, Any], app_name: str) -> Optional[Dict[str, Any]]:
        """
        Find app metadata by name (case-insensitive).

        Args:
            config: Configuration dictionary
            app_name: Name of the app to find

        Returns:
            App metadata dictionary, or None if not found
        """
        available_apps = config.get("available_apps", [])
        app_name_lower = app_name.lower()
        
        for app in available_apps:
            if app.get("name", "").lower() == app_name_lower:
                return app
        
        return None
