"""
Configuration storage - handles JSON file persistence.
Responsible only for reading and writing configuration data.
"""
import json
from pathlib import Path
from typing import Dict, Any


class ConfigStore:
    """Handles configuration file storage and retrieval."""

    def __init__(self, config_path: Path):
        """
        Initialize the configuration store.

        Args:
            config_path: Path to the configuration file
        """
        self.config_path = config_path
        self._ensure_config_dir()

    def load(self) -> Dict[str, Any]:
        """
        Load configuration from disk.

        Returns:
            Configuration dictionary, or empty structure if file doesn't exist
        """
        if not self.config_path.exists():
            return self._get_default_config()

        try:
            with self.config_path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            # If file is corrupted, log warning and return default
            print(f"Warning: Failed to load config from {self.config_path}: {e}")
            return self._get_default_config()

    def save(self, config: Dict[str, Any]) -> None:
        """
        Save configuration to disk.

        Args:
            config: Configuration dictionary to save

        Raises:
            OSError: If unable to write to file
        """
        self._ensure_config_dir()
        
        try:
            with self.config_path.open("w", encoding="utf-8") as f:
                json.dump(config, f, indent=4, ensure_ascii=False)
        except OSError as e:
            raise OSError(f"Failed to save config to {self.config_path}: {e}")

    def exists(self) -> bool:
        """Check if configuration file exists."""
        return self.config_path.exists()

    def _ensure_config_dir(self) -> None:
        """Ensure the configuration directory exists."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration structure."""
        return {
            "connected_apps": {},
            "apps_config": {},
            "available_apps": []
        }
