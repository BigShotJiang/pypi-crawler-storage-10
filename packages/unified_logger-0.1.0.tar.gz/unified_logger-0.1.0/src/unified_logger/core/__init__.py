"""Core logging functionality for unified_logger."""

from .backend import LoggingBackend
from .exceptions import BackendError, ConfigurationError, UnifiedLoggerError
from .logger import UnifiedLogger

__all__ = [
    "UnifiedLogger",
    "LoggingBackend",
    "UnifiedLoggerError",
    "BackendError",
    "ConfigurationError",
]
