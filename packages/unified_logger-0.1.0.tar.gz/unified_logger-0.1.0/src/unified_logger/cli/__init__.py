"""CLI interface for unified_logger."""

from .main import cli

__all__ = ["cli"]
