import re

def plural(text):
    """Find plural words in the given text and show the exact code.
    
    Args:
        text (str): The text to search for plural words
        
    Returns:
        list: A list of plural words found in the text
    """
    # Display the exact code
    print('import re')
    print()
    print('# Sample text')
    print('text = "The dogs are running in the parks while the cat\'s tail swishes."')
    print()
    print('# Regular expression to find plural words')
    print('plural_words = re.findall(r"\\b\\w+(?<!\')s\\b", text)')
    print()
    print('print("Plural words:", plural_words)')
    
    # Execute the logic with the provided text
    plural_words = re.findall(r"\b\w+(?<!')s\b", text)
    return plural_words

def split(text="Hello! How's everything going? Let's meet at 5:00 pm. #excited"):
    """Split text into words and show the exact code.
    
    Args:
        text (str): The text to split into words (optional)
        
    Returns:
        list: A list of words found in the text
    """
    # Display the exact code
    print('import re')
    print()
    print('# Sample text')
    print('text = "Hello! How\'s everything going? Let\'s meet at 5:00 pm. #excited"')
    print()
    print('# Remove special characters and punctuation, then split into words')
    print('words = re.findall(r"\\b\\w+\\b", text)')
    print()
    print('print("Words:", words)')
    
    # Execute the logic with the provided text
    words = re.findall(r"\b\w+\b", text)
    return words

# Print welcome message when module is imported
print("Welcome to NLTKK Module!")