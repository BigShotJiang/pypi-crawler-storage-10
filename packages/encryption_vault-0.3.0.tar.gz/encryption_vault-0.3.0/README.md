# Encryption Vault

Encryption Vault packages the PDFSage desktop utility for managing PGP key material, AES passwords, and credential storage into a redistributable Python module. Installing the project from PyPI exposes a console entry point named `encryption` that launches the Tkinter user interface.

## Features
- Generate, import, and store PGP key pairs with optional secure vault persistence.
- Manage multiple public/private keys and their passphrases from the PGP Vault tab.
- Encrypt, decrypt, sign, and verify messages using GnuPG.
- AES-256 encryption helpers for text and files.
- Built-in password and payment card vault backed by the system keyring service.
- Friendly password generator with Apple-style segments, memorable passphrases, and legacy high-entropy mode.
- Hash calculator for MD5 and SHA-256 integrity checks.

## Installation
```bash
pip install encryption-vault
```

Ensure you have a working GnuPG installation (`gpg` available on your PATH) before launching the application.

## Usage
After the package is installed, launch the GUI from any terminal:
```bash
encryption
```
This command invokes the packaged Tkinter application. The first launch will prompt you to create or select a master account vaulted in the local keyring. Private-key passphrases entered during decryption or signing are saved automatically alongside the key material so they can be recalled from the vault tab when needed.

### Password generator styles
The credentials tab now offers three generation strategies:

* **Apple-style** (default) – four-character segments separated by hyphens, avoiding look-alike symbols while guaranteeing a mix of upper, lower, and numeric characters.
* **Memorable** – short passphrases assembled from a curated English word list with an optional numeric suffix.
* **Random** – legacy full-character-set generator for maximum entropy.

Each strategy prompts for style-specific parameters (segments, word count, etc.) before the secret is copied to the clipboard.

## Development
Install dependencies and run the app locally without packaging:
```bash
pip install -r requirements.txt
python -m encryption_vault.app
```

To build the wheel and source distribution:
```bash
python -m build
```
The project is configured to publish to PyPI via the `workflow.yml` GitHub Actions workflow once valid credentials are provided.
