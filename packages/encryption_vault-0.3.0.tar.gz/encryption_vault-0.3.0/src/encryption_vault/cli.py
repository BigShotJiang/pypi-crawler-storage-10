"""Console entry-point for the Encryption Vault application."""
from __future__ import annotations

import runpy
from typing import Optional


def main() -> int:
    """Launch the legacy Tkinter application via the packaged module."""
    try:
        runpy.run_module('encryption_vault.app', run_name='__main__')
    except SystemExit as exc:  # propagate meaningful exit status without stack traces
        code: Optional[int] = exc.code
        return int(code) if isinstance(code, int) else 0
    return 0
