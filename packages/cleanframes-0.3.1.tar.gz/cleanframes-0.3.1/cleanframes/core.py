import os, cv2, shutil, hashlib, json
import numpy as np, torch, torch.nn as nn
from tqdm import tqdm
from PIL import Image, ImageFile
from torchvision import models, transforms
from transformers import AutoImageProcessor, AutoModel
from timm import create_model
import open_clip
from sklearn.cluster import KMeans, DBSCAN
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import imagehash
from rich.console import Console
from rich.table import Table
from datetime import datetime

try:
    import hdbscan
except ImportError:
    hdbscan = None

ImageFile.LOAD_TRUNCATED_IMAGES = True
console = Console()


class CleanFrame:
    """
    =============================================================
    CleanFrame: Professional Video Frame Deduplication & Clustering Tool
    =============================================================

    Features:
      1. Extracts frames from video
      2. MD5 exact-duplicate removal
      3. Perceptual-hash near-duplicate removal
      4. Deep-embedding semantic cleaning (CLIP, Swin, ResNet, DINOv2)
      5. Clustering (KMeans, DBSCAN, HDBSCAN)
      6. t-SNE/PCA visualization
      7. Smart caching + Rich-based reporting
    """

    def __init__(self, video_path=None, device="cpu"):
        self.video_path = video_path
        self.device = torch.device(
            device if torch.cuda.is_available() or device == "mps" else "cpu"
        )
        self.video_name = (
            os.path.splitext(os.path.basename(video_path))[0]
            if video_path
            else "default"
        )
        self.root_cache = os.path.join(".cleanframe_cache", self.video_name)
        os.makedirs(self.root_cache, exist_ok=True)
        self.frames_dir = os.path.join(self.root_cache, "frames")
        os.makedirs(self.frames_dir, exist_ok=True)

        self.embeddings = None
        self.paths = None
        self.labels = None
        self.model_name = None
        self.cluster_method = None
        self.clean_stats = None

    # ==========================================================
    # Utility and Cache Helpers
    # ==========================================================

    def _safe_open(self, path):
        try:
            return Image.open(path).convert("RGB")
        except Exception:
            return None

    def _cache_path(self, key):
        return os.path.join(self.root_cache, f"{key}.npz")

    def _save_cache(self, key, **kwargs):
        try:
            np.savez_compressed(self._cache_path(key), **kwargs)
        except Exception as e:
            console.print(f"[yellow]Cache warning:[/yellow] {e}")

    def _load_cache(self, key):
        path = self._cache_path(key)
        if os.path.exists(path):
            try:
                data = np.load(path, allow_pickle=True)
                return dict(data)
            except Exception:
                return None
        return None

    # ==========================================================
    # Frame Extraction
    # ==========================================================

    def load_frames(self, frame_skip=10):
        """Extracts frames from the video and caches them."""
        if len(os.listdir(self.frames_dir)) > 0:
            console.print(
                f"[green]Frames already cached:[/green] {self.frames_dir}"
            )
            return self.frames_dir

        cap = cv2.VideoCapture(self.video_path)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open video: {self.video_path}")

        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        os.makedirs(self.frames_dir, exist_ok=True)

        frame_idx = 0
        saved = 0
        with tqdm(total=total, desc="[Extracting Frames]") as pbar:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                if frame_idx % frame_skip == 0:
                    out_path = os.path.join(
                        self.frames_dir, f"frame_{frame_idx:06d}.jpg"
                    )
                    cv2.imwrite(out_path, frame)
                    saved += 1
                frame_idx += 1
                pbar.update(1)
        cap.release()
        console.print(
            f"[cyan]Extracted {saved} frames → {self.frames_dir}[/cyan]"
        )
        return self.frames_dir

    # ==========================================================
    # Embedding Extraction
    # ==========================================================

    def embed_frames(self, model="clip"):
        """Generates embeddings for cached frames using the selected model."""
        self.model_name = model.lower()
        cache = self._load_cache(f"embeddings_{self.model_name}")
        if cache:
            self.embeddings, self.paths = cache["embeddings"], list(cache["paths"])
            console.print(f"[green]Loaded cached embeddings for {model}[/green]")
            return self.embeddings, self.paths

        folder = self.frames_dir
        if not os.path.exists(folder):
            raise RuntimeError("No frames found. Run load_frames() first.")

        # -----------------------
        # Dispatch to model type
        # -----------------------
        if model == "resnet":
            model_fn = self._embed_resnet
        elif model == "swin":
            model_fn = self._embed_swin
        elif model == "clip":
            model_fn = self._embed_clip
        elif model == "dino":
            model_fn = self._embed_dino
        else:
            raise ValueError("model must be one of ['clip','swin','resnet','dino'].")

        self.embeddings, self.paths = model_fn(folder)
        self._save_cache(
            f"embeddings_{self.model_name}",
            embeddings=self.embeddings,
            paths=np.array(self.paths),
        )
        return self.embeddings, self.paths

    def _embed_resnet(self, folder):
        model = models.resnet50(pretrained=True)
        model = nn.Sequential(*list(model.children())[:-1]).to(self.device).eval()
        tf = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        )
        embs, paths = [], []
        for f in tqdm(os.listdir(folder), desc="[ResNet]"):
            if not f.lower().endswith((".jpg", ".jpeg", ".png")):
                continue
            p = os.path.join(folder, f)
            img = self._safe_open(p)
            if img is None:
                continue
            x = tf(img).unsqueeze(0).to(self.device)
            feat = model(x).detach().squeeze().cpu().numpy()
            embs.append(feat / np.linalg.norm(feat))
            paths.append(p)
        return np.array(embs), paths

    def _embed_swin(self, folder):
        model = create_model("swin_tiny_patch4_window7_224", pretrained=True, num_classes=0)
        model.to(self.device).eval()
        tf = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        )
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[Swin]"):
                if not f.lower().endswith((".jpg", ".jpeg", ".png")):
                    continue
                p = os.path.join(folder, f)
                img = self._safe_open(p)
                if img is None:
                    continue
                x = tf(img).unsqueeze(0).to(self.device)
                feat = model(x).detach().squeeze().cpu().numpy()
                embs.append(feat / np.linalg.norm(feat))
                paths.append(p)
        return np.array(embs), paths

    def _embed_clip(self, folder):
        model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="openai")
        model.to(self.device).eval()
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[CLIP]"):
                if not f.lower().endswith((".jpg", ".jpeg", ".png")):
                    continue
                p = os.path.join(folder, f)
                img = self._safe_open(p)
                if img is None:
                    continue
                x = preprocess(img).unsqueeze(0).to(self.device)
                feat = model.encode_image(x)
                feat /= feat.norm(dim=-1, keepdim=True)
                embs.append(feat.cpu().numpy().flatten())
                paths.append(p)
        return np.array(embs), paths

    def _embed_dino(self, folder):
        model_id = "facebook/dinov2-base"
        processor = AutoImageProcessor.from_pretrained(model_id)
        model = AutoModel.from_pretrained(model_id).to(self.device).eval()
        embs, paths = [], []
        with torch.no_grad():
            for f in tqdm(os.listdir(folder), desc="[DINOv2]"):
                if not f.lower().endswith((".jpg", ".jpeg", ".png")):
                    continue
                p = os.path.join(folder, f)
                img = self._safe_open(p)
                if img is None:
                    continue
                x = processor(images=img, return_tensors="pt").to(self.device)
                feat = model(**x).last_hidden_state.mean(dim=1)
                feat = feat / feat.norm(dim=-1, keepdim=True)
                embs.append(feat.cpu().numpy().flatten())
                paths.append(p)
        return np.array(embs), paths

    # ==========================================================
    # Clustering
    # ==========================================================

    def cluster_frames(self, method="kmeans", n_clusters=5, eps=0.5, min_samples=5):
        """Clusters embeddings to group similar frames."""
        self.cluster_method = method.lower()
        cache = self._load_cache(f"cluster_{self.model_name}_{self.cluster_method}")
        if cache:
            self.labels = cache["labels"]
            console.print(f"[green]Loaded cached clusters ({method})[/green]")
            return self.labels

        emb = self.embeddings
        if emb is None:
            raise RuntimeError("Run embed_frames() first.")

        if method == "kmeans":
            labels = KMeans(n_clusters=n_clusters, random_state=42, n_init="auto").fit_predict(emb)
        elif method == "dbscan":
            labels = DBSCAN(eps=eps, min_samples=min_samples).fit_predict(emb)
        elif method == "hdbscan":
            if hdbscan is None:
                raise ImportError("Install hdbscan first: pip install hdbscan")
            labels = hdbscan.HDBSCAN(min_cluster_size=min_samples).fit_predict(emb)
        else:
            raise ValueError("method must be one of ['kmeans','dbscan','hdbscan'].")

        self.labels = labels
        self._save_cache(f"cluster_{self.model_name}_{self.cluster_method}", labels=labels)
        return labels
    


        # ==========================================================
    # Cleaning
    # ==========================================================

    def clean_frames(self, threshold=0.95):
        """Cleans clustered frames and saves results per cluster."""
        if self.embeddings is None or self.labels is None:
            raise RuntimeError("Run embed_frames() and cluster_frames() first.")

        unique_clusters = [c for c in np.unique(self.labels) if c != -1]
        cleaned_dir = os.path.join(
            self.root_cache,
            "cleaned",
            f"cleaned_frames_{self.model_name}&{self.cluster_method}_{threshold}",
        )
        removed_dir = os.path.join(
            self.root_cache,
            "cleaned",
            f"removed_frames_{self.model_name}&{self.cluster_method}_{threshold}",
        )
        os.makedirs(cleaned_dir, exist_ok=True)
        os.makedirs(removed_dir, exist_ok=True)

        total_kept, total_removed = 0, 0
        report_rows = []

        for cid in unique_clusters:
            idx = np.where(self.labels == cid)[0]
            cluster_paths = [self.paths[i] for i in idx]
            if len(cluster_paths) == 0:
                continue

            # MD5 deduplication
            md5_seen, md5_unique = set(), []
            for p in cluster_paths:
                try:
                    h = hashlib.md5(open(p, "rb").read()).hexdigest()
                    if h not in md5_seen:
                        md5_seen.add(h)
                        md5_unique.append(p)
                    else:
                        shutil.copy(p, os.path.join(removed_dir, os.path.basename(p)))
                except Exception:
                    continue

            # Perceptual hash
            phash_dict, phash_unique = {}, []
            for p in md5_unique:
                try:
                    h = imagehash.phash(Image.open(p))
                    if not any(h - hh < 5 for hh in phash_dict.values()):
                        phash_dict[p] = h
                        phash_unique.append(p)
                    else:
                        shutil.copy(p, os.path.join(removed_dir, os.path.basename(p)))
                except Exception:
                    continue

            # Embedding cosine similarity
            kept, kept_idx = [], []
            if len(phash_unique) > 0:
                first = phash_unique[0]
                kept.append(first)
                kept_idx.append(self.paths.index(first))
                for p in phash_unique[1:]:
                    idxp = self.paths.index(p)
                    sims = cosine_similarity(
                        self.embeddings[idxp].reshape(1, -1),
                        self.embeddings[kept_idx],
                    )[0]
                    if np.max(sims) < threshold:
                        kept.append(p)
                        kept_idx.append(idxp)
                    else:
                        shutil.copy(p, os.path.join(removed_dir, os.path.basename(p)))

            for p in kept:
                shutil.copy(p, os.path.join(cleaned_dir, os.path.basename(p)))

            kept_count, total_count = len(kept), len(cluster_paths)
            removed_count = total_count - kept_count
            total_kept += kept_count
            total_removed += removed_count
            report_rows.append(
                {
                    "cluster": cid,
                    "images": total_count,
                    "kept": kept_count,
                    "removed": removed_count,
                    "kept_pct": round(kept_count / total_count * 100, 1),
                    "removed_pct": round(removed_count / total_count * 100, 1),
                }
            )

        self.clean_stats = {
            "rows": report_rows,
            "total_kept": total_kept,
            "total_removed": total_removed,
            "cleaned_dir": cleaned_dir,
            "removed_dir": removed_dir,
            "threshold": threshold,
        }
        return self.clean_stats

    # ==========================================================
    # Reporting
    # ==========================================================

    def report(self):
        """Displays per-cluster and global cleaning summary."""
        if not self.clean_stats:
            raise RuntimeError("Run clean_frames() first.")

        rows = self.clean_stats["rows"]
        total_kept = self.clean_stats["total_kept"]
        total_removed = self.clean_stats["total_removed"]
        cleaned_dir = self.clean_stats["cleaned_dir"]
        removed_dir = self.clean_stats["removed_dir"]

        table = Table(
            title=f"CleanFrames Report — {self.model_name.upper()} + {self.cluster_method.upper()}",
            show_lines=True,
            header_style="bold magenta",
        )
        table.add_column("Cluster", justify="center")
        table.add_column("Images", justify="center")
        table.add_column("Kept", justify="center")
        table.add_column("Removed", justify="center")
        table.add_column("Kept %", justify="center")
        table.add_column("Removed %", justify="center")

        for row in rows:
            table.add_row(
                str(row["cluster"]),
                str(row["images"]),
                str(row["kept"]),
                str(row["removed"]),
                f"{row['kept_pct']}%",
                f"{row['removed_pct']}%",
            )

        total = total_kept + total_removed
        console.rule("[bold green]CLEANFRAMES SUMMARY")
        console.print(table)
        console.print(
            f"[bold cyan]Total Frames:[/bold cyan] {total}    "
            f"[bold cyan]Kept:[/bold cyan] {total_kept} ({(total_kept/total)*100:.2f}%)    "
            f"[bold cyan]Removed:[/bold cyan] {total_removed} ({(total_removed/total)*100:.2f}%)"
        )
        console.print(
            f"[bold yellow]Output:[/bold yellow] {cleaned_dir}\n"
            f"[bold yellow]Removed:[/bold yellow] {removed_dir}"
        )
        console.rule()

    # ==========================================================
    # Visualization
    # ==========================================================

    def visualize(self, method="tsne", save=True):
        """Visualizes clustered embeddings."""
        if self.embeddings is None or self.labels is None:
            raise RuntimeError("Run embed_frames() and cluster_frames() first.")

        cache_key = f"vis_{self.model_name}_{self.cluster_method}_{method}"
        cache = self._load_cache(cache_key)
        if cache:
            emb2d = cache["emb2d"]
        else:
            reducer = (
                TSNE(n_components=2, perplexity=30, random_state=42)
                if method == "tsne"
                else PCA(n_components=2)
            )
            emb2d = reducer.fit_transform(self.embeddings)
            self._save_cache(cache_key, emb2d=emb2d)

        import matplotlib.pyplot as plt

        plt.figure(figsize=(7, 6))
        plt.scatter(emb2d[:, 0], emb2d[:, 1], c=self.labels, cmap="tab10", s=10)
        plt.title(f"{self.model_name.upper()} + {self.cluster_method.upper()} ({method.upper()})")
        plt.axis("off")

        if save:
            vis_dir = os.path.join(self.root_cache, "cluster_results")
            os.makedirs(vis_dir, exist_ok=True)
            out = os.path.join(
                vis_dir, f"{self.model_name}_{self.cluster_method}_{method}.png"
            )
            plt.savefig(out, bbox_inches="tight")
            console.print(f"[green]Saved visualization → {out}[/green]")
        plt.show()


# ==============================================================
# CleanFrame_optimized
# ==============================================================

try:
    import onnxruntime as ort
except ImportError:
    ort = None


class CleanFrame_optimized:
    """
    =============================================================
    CleanFrame_optimized: High-Performance Cleaner for Large Datasets
    =============================================================
    Enhances CleanFrame with:
      - Batched embedding extraction
      - Mixed precision acceleration (FP16)
      - Optional ONNXRuntime inference
      - Automatic fallback to standard CleanFrame methods
    """

    def __init__(self, device="cuda", fast_mode=True, batch_size=64, use_onnx=False):
        self.base = CleanFrame(device=device)
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.fast_mode = fast_mode
        self.batch_size = batch_size
        self.use_onnx = use_onnx and ort is not None
        self._fp16 = self.fast_mode and (self.device.type in ["cuda", "mps"])

        if self.use_onnx:
            console.print("[bold green]ONNX acceleration enabled.[/bold green]")
        elif use_onnx and ort is None:
            console.print("[yellow]onnxruntime not installed, using PyTorch.[/yellow]")

        console.print(
            "[bold cyan]Precision:[/bold cyan] "
            + ("FP16" if self._fp16 else "FP32")
        )

    # ------------------------------
    # Proxy standard methods
    # ------------------------------

    def load_frames(self, *a, **kw):
        return self.base.load_frames(*a, **kw)

    def cluster_frames(self, *a, **kw):
        return self.base.cluster_frames(*a, **kw)

    def clean_frames(self, *a, **kw):
        return self.base.clean_frames(*a, **kw)

    def report(self, *a, **kw):
        return self.base.report(*a, **kw)

    def visualize(self, *a, **kw):
        return self.base.visualize(*a, **kw)

    # ==========================================================
    # Batched Embedding Extraction
    # ==========================================================

    def _batch_images(self, folder, tf):
        files = [
            os.path.join(folder, f)
            for f in os.listdir(folder)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        images, paths = [], []
        for p in files:
            try:
                img = Image.open(p).convert("RGB")
                images.append(tf(img))
                paths.append(p)
            except Exception as e:
                console.print(f"[yellow]Skip:[/yellow] {p} ({e})")
        return images, paths

    def _batched_forward(self, model, images):
        embs = []
        model.eval()
        with torch.no_grad():
            for i in range(0, len(images), self.batch_size):
                batch = torch.stack(images[i : i + self.batch_size]).to(self.device)
                if self._fp16:
                    batch = batch.half()
                feat = model(batch)
                feat = feat.squeeze()
                if len(feat.shape) == 1:
                    feat = feat.unsqueeze(0)
                feat = feat.cpu().numpy()
                embs.append(feat)
        embs = np.concatenate(embs, axis=0)
        embs /= np.linalg.norm(embs, axis=1, keepdims=True)
        return embs

    # ==========================================================
    # Optimized Embedding API
    # ==========================================================

    def embed_frames(self, model="clip"):
        """High-performance embedding extractor."""
        folder = self.base.frames_dir
        cache = self.base._load_cache(f"embeddings_{model}_opt")
        if cache:
            self.base.embeddings, self.base.paths = (
                cache["embeddings"],
                list(cache["paths"]),
            )
            return self.base.embeddings, self.base.paths

        if model == "resnet":
            self._embed_resnet(folder)
        elif model == "swin":
            self._embed_swin(folder)
        elif model == "clip":
            self._embed_clip(folder)
        elif model == "dino":
            self._embed_dino(folder)
        else:
            raise ValueError("model must be one of ['clip','swin','resnet','dino'].")

        return self.base.embeddings, self.base.paths

    def _embed_resnet(self, folder):
        model = models.resnet50(pretrained=True)
        model = nn.Sequential(*list(model.children())[:-1])
        model.to(self.device).eval()
        tf = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        )
        images, paths = self._batch_images(folder, tf)
        embs = self._batched_forward(model, images)
        self.base.embeddings, self.base.paths = embs, paths
        self.base._save_cache(f"embeddings_resnet_opt", embeddings=embs, paths=np.array(paths))

    def _embed_clip(self, folder):
        model, _, preprocess = open_clip.create_model_and_transforms("ViT-B-32", pretrained="openai")
        model.to(self.device).eval()
        if self._fp16:
            model = model.half()

        files = [
            os.path.join(folder, f)
            for f in os.listdir(folder)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        images, paths = [], []
        for p in files:
            try:
                img = preprocess(Image.open(p).convert("RGB"))
                images.append(img)
                paths.append(p)
            except Exception:
                continue

        embs = []
        with torch.no_grad():
            for i in tqdm(range(0, len(images), self.batch_size), desc="[CLIP-opt]"):
                batch = torch.stack(images[i : i + self.batch_size]).to(self.device)
                if self._fp16:
                    batch = batch.half()
                feat = model.encode_image(batch)
                feat = feat / feat.norm(dim=-1, keepdim=True)
                embs.append(feat.cpu().numpy())
        embs = np.concatenate(embs, axis=0)
        self.base.embeddings, self.base.paths = embs, paths
        self.base._save_cache(f"embeddings_clip_opt", embeddings=embs, paths=np.array(paths))

    def _embed_swin(self, folder):
        model = create_model("swin_tiny_patch4_window7_224", pretrained=True, num_classes=0)
        model.to(self.device).eval()
        if self._fp16:
            model = model.half()

        tf = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        )
        images, paths = self._batch_images(folder, tf)
        embs = self._batched_forward(model, images)
        self.base.embeddings, self.base.paths = embs, paths
        self.base._save_cache(f"embeddings_swin_opt", embeddings=embs, paths=np.array(paths))

    def _embed_dino(self, folder):
        model_id = "facebook/dinov2-base"
        processor = AutoImageProcessor.from_pretrained(model_id)
        model = AutoModel.from_pretrained(model_id).to(self.device).eval()
        if self._fp16:
            model = model.half()

        files = [
            os.path.join(folder, f)
            for f in os.listdir(folder)
            if f.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        embs, paths = [], []
        with torch.no_grad():
            for i in tqdm(range(0, len(files), self.batch_size), desc="[DINOv2-opt]"):
                batch_imgs = [Image.open(p).convert("RGB") for p in files[i : i + self.batch_size]]
                x = processor(images=batch_imgs, return_tensors="pt").to(self.device)
                if self._fp16:
                    x = {k: v.half() for k, v in x.items()}
                feat = model(**x).last_hidden_state.mean(dim=1)
                feat = feat / feat.norm(dim=-1, keepdim=True)
                embs.append(feat.cpu().numpy())
                paths.extend(files[i : i + self.batch_size])
        embs = np.concatenate(embs, axis=0)
        self.base.embeddings, self.base.paths = embs, paths
        self.base._save_cache(f"embeddings_dino_opt", embeddings=embs, paths=np.array(paths))

