## Links
DOCS_LINK = "https://gorunn.io/docs"
DOCS_LINK_GETTING_STARTED = f"{DOCS_LINK}/getting-started"
DOCS_LINK_config = f"{DOCS_LINK}/config"
DOCS_LINK_USAGE = f"{DOCS_LINK}/usage"
DOCS_LINK_PROJECTS = f"{DOCS_LINK_USAGE}/projects"

NOT_SET_UP = "gorunn is not set up. Run `gorunn init` first!"
