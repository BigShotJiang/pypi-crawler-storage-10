GRANT ALL ON *.* TO 'gorunn'@'%';
