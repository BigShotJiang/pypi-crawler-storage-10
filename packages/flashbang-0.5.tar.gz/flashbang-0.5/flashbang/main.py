import tkinter as tk
from PIL import Image, ImageTk
from pathlib import Path
import pygame

def flashbang():
    root = tk.Tk()
    root.attributes('-fullscreen', True)
    root.configure(bg="white")

    # Play sound
    audio_path = Path(__file__).parent / "audio.mp3"
    pygame.mixer.init()
    pygame.mixer.music.load(str(audio_path))
    pygame.mixer.music.play()

    # Function to show image
    def show_image():
        img_path = Path(__file__).parent / "Job.png"
        try:
            img = Image.open(img_path)
        except FileNotFoundError:
            print(f"Image not found at {img_path}")
            root.destroy()
            return

        photo = ImageTk.PhotoImage(img)
        label = tk.Label(root, image=photo)
        label.image = photo  # keep a reference
        label.pack(expand=True)
        root.configure(bg="white")

        # Close window after 2 seconds
        root.after(2000, root.destroy)

    # Schedule to show image after 700ms (flash duration)
    root.after(700, show_image)

    root.mainloop()

if __name__ == "__main__":
    flashbang()
