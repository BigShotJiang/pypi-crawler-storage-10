from setuptools import setup, find_packages

setup(
    name="flashbang",
    version="0.5",  # bump version
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "flashbang": ["*.mp3", "*.png"]  # include both audio and image
    },
    install_requires=[
        "Pillow",
        "pygame",
    ],
    entry_points={
        "console_scripts": [
            "flashbang=flashbang.main:flashbang",
        ],
    },
)
