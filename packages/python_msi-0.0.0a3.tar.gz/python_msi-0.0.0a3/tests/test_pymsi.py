import pymsi


def test_version():
    assert pymsi.__version__
