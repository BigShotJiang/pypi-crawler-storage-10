#-----------------------------------------------------------------------
# Name:        helper (huff package)
# Purpose:     Huff Model helper functions and definitions
# Author:      Thomas Wieland 
#              ORCID: 0000-0001-5168-9846
#              mail: geowieland@googlemail.com              
# Version:     1.1.2
# Last update: 2025-10-26 12:12
# Copyright (c) 2025 Thomas Wieland
#-----------------------------------------------------------------------

import pandas as pd
import numpy as np
from math import sqrt, pi
from pandas.api.types import is_numeric_dtype


PERMITTED_LOCATION_TYPES = [
    "origins",
    "destinations"
]

# Default column names:
DEFAULT_COLNAME_ATTRAC = "A_j"
DEFAULT_COLNAME_TC = "t_ij"
DEFAULT_COLNAME_UTILITY = "U_ij"
DEFAULT_COLNAME_UTILITY_SUM = "U_i"
DEFAULT_COLNAME_MARKETSIZE = "C_i"
DEFAULT_COLNAME_PROBABILITY = "p_ij"
DEFAULT_COLNAME_FLOWS = "E_ij"
DEFAULT_COLNAME_CUSTOMER_ORIGINS = "i"
DEFAULT_COLNAME_SUPPLY_LOCATIONS = "j"
DEFAULT_COLNAME_INTERACTION = "ij"
DEFAULT_COLNAME_TOTAL_MARKETAREA = "T_j"

# Default column name suffixes:
DEFAULT_LCT_SUFFIX = "__LCT"
DEFAULT_WEIGHTED_SUFFIX = "_weighted"
DEFAULT_OBSERVED_SUFFIX = "_emp"

DEFAULT_COLNAME_ATTRAC_WEIGHTED = f"{DEFAULT_COLNAME_ATTRAC}{DEFAULT_WEIGHTED_SUFFIX}"
DEFAULT_COLNAME_TC_WEIGHTED = f"{DEFAULT_COLNAME_TC}{DEFAULT_WEIGHTED_SUFFIX}"

DEFAULT_COLNAME_PROBABILITY_OBSERVED = f"{DEFAULT_COLNAME_PROBABILITY}{DEFAULT_OBSERVED_SUFFIX}"
DEFAULT_COLNAME_FLOWS_OBSERVED = f"{DEFAULT_COLNAME_FLOWS}{DEFAULT_OBSERVED_SUFFIX}"
DEFAULT_COLNAME_TOTAL_MARKETAREA_OBSERVED = f"{DEFAULT_COLNAME_TOTAL_MARKETAREA}{DEFAULT_OBSERVED_SUFFIX}"

# Default descriptions:
DEFAULT_NAME_ATTRAC = "Attraction"
DEFAULT_NAME_TC = "Transport costs"

# Default weighting functions:
PERMITTED_WEIGHTING_FUNCTIONS = {
    "power": {
        "description": "Power function",
        "function": "a*(values**b)",
        "no_params": 1
        },
    "exponential": {
        "description": "Exponential function",
        "function": "a*np.exp(b*values)",
        "no_params": 1
        },
    "logistic": {
        "description": "Logistic function",
        "function": "1+np.exp(b+c*values)",
        "no_params": 2
        },
    "linear": {
        "description": "Linear function",
        "function": "a+(b*values)",
        "no_params": 1
        }
    }
PERMITTED_WEIGHTING_FUNCTIONS_LIST = list(PERMITTED_WEIGHTING_FUNCTIONS.keys())

MCI_TRANSFORMATIONS = {
    "LCT": "Log-centering transformation",
    "ILCT": "Inverse log-centering transformation"
}
MCI_TRANSFORMATIONS_LIST = list(MCI_TRANSFORMATIONS.keys())
DEFAULT_MCI_TRANSFORMATION = MCI_TRANSFORMATIONS_LIST[0]


GOODNESS_OF_FIT = {
    "Sum of squared residuals": "SQR",
    "R-squared": "Rsq",
    "Mean squared error": "MSE",
    "Root mean squared error": "RMSE",
}


# ORS config:

ORS_SERVER = "https://api.openrouteservice.org/v2/"
ORS_URL_RESTRICTIONS = "https://openrouteservice.org/restrictions/"

ORS_HEADERS = {
    "Content-Type": "application/json; charset=utf-8",
    "Accept": "application/json, application/geo+json, application/gpx+xml, img/png; charset=utf-8",    
}

ORS_AUTH = "5b3ce3597851110001cf62480a15aafdb5a64f4d91805929f8af6abd"
# for TESTING

ORS_ENDPOINTS = {
    "Isochrones": {
        "endpoint": "isochrones/",
        "Restrictions": {
            "Locations": 5,
            "Intervals": 10,
            "Range distance": 120,
            "Range time (Foot profiles)": 20,
            "Range time (Cycling profiles)": 5,
            "Range time (Driving profiles)": 1
        },
        "Parameters": {
            "unit": {
                "param": "range_type",
                "type": str,
                "options": {
                    "time": {
                        "description": "Time [minutes]",
                        "param": "time"
                    },
                    "distance": {
                        "description": "Distance [meters]",
                        "param": "distance"
                    }
                },
            },
        }
    },
    "Matrix": {
        "endpoint": "matrix/",
        "Restrictions": {
            "Locations (origin x destination)": 3500            
        },
        "Parameters": {
            "unit": {
                "param": "metrics",
                "type": str,
                "options": {
                    "time": {
                        "description": "Time [minutes]",
                        "param": "duration"
                    },
                    "distance": {
                        "description": "Distance [meters]",
                        "param": "distance"
                    }
                },
            },
        },
    }
}
    
ORS_PROFILES = {
    "Driving car": "driving-car",
    "Driving heavy goods vehicle": "driving-hgv",
    "Walking by foot": "foot-walking",
}
ORS_PROFILES_LIST = ORS_PROFILES.keys()
ORS_PROFILES_LIST_API = list(ORS_PROFILES.values())

ORS_RANGE_TYPES = {
    "Time [minutes]": "time",
    "Distance [meters]": "distance"
    }
ORS_RANGE_TYPES_LIST = ORS_RANGE_TYPES.keys()
ORS_RANGE_TYPES_LIST_API = list(ORS_RANGE_TYPES.values())


# OSM config:

OSM_TILES_SERVER = "http://a.tile.openstreetmap.org/"

DEFAULT_FILENAME_ORS_TMP = "osm_map.png"


# GIS constants and defaults:

WGS84_EPSG = 4326
WGS84_CRS = f"EPSG:{WGS84_EPSG}"
PSEUDO_MERCATOR_EPSG = 3857
PSEUDO_MERCATOR_CRS = f"EPSG:{PSEUDO_MERCATOR_EPSG}"

DISTANCE_TYPES = {
    "Euclidean distance": "euclidean",
    "Manhattan distance": "manhattan"
}
DISTANCE_TYPES_LIST = list(DISTANCE_TYPES.keys())
DISTANCE_TYPES_LIST_FUNC = list(DISTANCE_TYPES.values())

DEFAULT_SEGMENTS_COL = "segment"

DEFAULT_LAYER_ALPHA = 0.6
DEFAULT_LAYER_LABEL = "Layer"
DEFAULT_LEGEND_LOC = "lower right"
DEFAULT_LEGEND_FONTSIZE = "small"


# Helper functions:

def weighting(
    values: pd.Series,
    func: str,
    b: float,
    c: float = None,
    a: float = 1.0
    ):
    
    if func not in PERMITTED_WEIGHTING_FUNCTIONS_LIST:
        raise ValueError (f"Parameter 'func' must be one of {', '.join(PERMITTED_WEIGHTING_FUNCTIONS_LIST)}")
    
    if not check_numeric_series(values):
        raise TypeError("Vector given by parameter 'series' is not numeric")    
    
    result = None
    
    calc_formula = PERMITTED_WEIGHTING_FUNCTIONS[func]["function"]
    
    calc_dict = {"a": a, "b": b, "values": values, "np": np}
    
    if "c" in calc_formula:
        if c is None:
            raise ValueError("Parameter 'c' must be provided for this function")
        calc_dict["c"] = c
        
    result = eval(calc_formula, {}, calc_dict)
    
    return result


def log_centering_transformation(
    df: pd.DataFrame,
    ref_col: str,
    cols: list,
    suffix: str = DEFAULT_LCT_SUFFIX
    ):
   
    check_vars(
        df = df,
        cols = cols
        )
    
    if ref_col not in df.columns:
        raise KeyError(f"Error in log-centering transformation: Column '{ref_col}' not in dataframe.")

    def lct (x):

        x_geom = np.exp(np.log(x).mean())
        x_lct = np.log(x/x_geom)

        return x_lct
    
    for var in cols:
        
        unique_values = df[var].unique()
        if set(unique_values).issubset({0, 1}):
            df[var+suffix] = df[var]
            print (f"Column {var} is a dummy variable and requires/allows no log-centering transformation")
            continue

        if (df[var] <= 0).any():
            df[var+suffix] = float("nan")
            print (f"Column {var} contains values <= 0. No log-centering transformation possible.")
            continue

        var_t = df.groupby(ref_col)[var].apply(lct)
        var_t = var_t.reset_index()
        df[var+suffix] = var_t[var]

    return df


def modelfit(
    observed, 
    expected,
    remove_nan: bool = True,
    verbose: bool = False
    ):

    observed_no = len(observed)
    expected_no = len(expected)

    if not observed_no == expected_no:
        raise ValueError("Error while calculating fit metrics: Observed and expected differ in length")
    
    if not isinstance(observed, np.number): 
        if not is_numeric_dtype(observed):
            raise ValueError("Error while calculating fit metrics: Observed column is not numeric")
    if not isinstance(expected, np.number):
        if not is_numeric_dtype(expected):
            raise ValueError("Error while calculating fit metrics: Expected column is not numeric")
    
    if remove_nan:
        
        observed = observed.reset_index(drop=True)
        expected = expected.reset_index(drop=True)

        obs_exp = pd.DataFrame(
            {
                "observed": observed, 
                "expected": expected
                }
            )
        
        obs_exp_clean = obs_exp.dropna(subset=["observed", "expected"])

        if len(obs_exp_clean) < len(observed) or len(obs_exp_clean) < len(expected):
            if verbose:
                print("NOTE: Vectors 'observed' and/or 'expected' contain NaNs which are dropped.")
        
        observed = obs_exp_clean["observed"].to_numpy()
        expected = obs_exp_clean["expected"].to_numpy()
    
    else:
        
        if np.isnan(observed).any():
            raise ValueError("Error while calculating fit metrics: Vector with observed data contains NaNs and 'remove_nan' is False")
        if np.isnan(expected).any():
            raise ValueError("Error while calculating fit metrics: Vector with expected data contains NaNs and 'remove_nan' is False")
    
    residuals = np.array(observed)-np.array(expected)
    residuals_sq = residuals**2
    residuals_abs = abs(residuals)
 
    if any(observed == 0):
        if verbose:
            print ("Vector 'observed' contains values equal to zero. No APE/MAPE calculated.")
        APE = np.full_like(observed, np.nan)
        MAPE = None
    else:
        APE = abs(observed-expected)/observed*100
        MAPE = float(np.mean(APE))
        
    sAPE = abs(observed-expected)/((abs(observed)+abs(expected))/2)*100
    
    data_residuals = pd.DataFrame({
        "observed": observed,
        "expected": expected,
        "residuals": residuals,
        "residuals_sq": residuals_sq,
        "residuals_abs": residuals_abs,
        "APE": APE,
        "sAPE": sAPE
        })

    SQR = float(np.sum(residuals_sq))
    SAR = float(np.sum(residuals_abs))    
    observed_mean = float(np.sum(observed)/observed_no)
    SQT = float(np.sum((observed-observed_mean)**2))
    Rsq = float(1-(SQR/SQT))
    MSE = float(SQR/observed_no)
    RMSE = float(sqrt(MSE))
    MAE = float(SAR/observed_no)
    LL = np.sum(np.log(residuals_sq))
    
    sMAPE = float(np.mean(sAPE))

    resid_below5 = float(len(data_residuals[data_residuals["APE"] < 5])/expected_no*100)
    resid_below10 = float(len(data_residuals[data_residuals["APE"] < 10])/expected_no*100)
    resid_below15 = float(len(data_residuals[data_residuals["APE"] < 15])/expected_no*100)
    resid_below20 = float(len(data_residuals[data_residuals["APE"] < 20])/expected_no*100)
    resid_below25 = float(len(data_residuals[data_residuals["APE"] < 25])/expected_no*100)
    resid_below30 = float(len(data_residuals[data_residuals["APE"] < 30])/expected_no*100)
    resid_below35 = float(len(data_residuals[data_residuals["APE"] < 35])/expected_no*100)
    resid_below40 = float(len(data_residuals[data_residuals["APE"] < 40])/expected_no*100)
    resid_below45 = float(len(data_residuals[data_residuals["APE"] < 45])/expected_no*100)
    resid_below50 = float(len(data_residuals[data_residuals["APE"] < 50])/expected_no*100)

    data_lossfunctions = {
        "SQR": SQR,
        "SAR": SAR,
        "SQT": SQT,
        "Rsq": Rsq,
        "MSE": MSE,
        "RMSE": RMSE,
        "MAE": MAE,
        "MAPE": MAPE,
        "sMAPE": sMAPE,
        "LL": -LL,
        "APE": {
            "resid_below5": resid_below5,
            "resid_below10": resid_below10,
            "resid_below15": resid_below15,
            "resid_below20": resid_below20,
            "resid_below25": resid_below25,
            "resid_below30": resid_below30,
            "resid_below35": resid_below35,
            "resid_below40": resid_below40,
            "resid_below45": resid_below45,
            "resid_below50": resid_below50,
        }   
    }    
    
    modelfit_results = [
        data_residuals,
        data_lossfunctions
    ]

    return modelfit_results


def check_vars(
    df: pd.DataFrame,
    cols: list,
    check_numeric: bool = True,
    check_zero: bool = True
    ):

    for col in cols:
        if col not in df.columns:
            raise KeyError(f"Column '{col}' not in dataframe.")
    
    if check_numeric:
        for col in cols:
            if not check_numeric_series(df[col]):
                raise TypeError(f"Column '{col}' is not numeric. All stated columns must be numeric.")
    
    if check_zero:
        for col in cols:
            if (df[col] <= 0).any():
                raise ValueError(f"Column '{col}' includes values <= 0. All values must be numeric and positive.")


def lonlat_transform(
    source: list,
    destination: list,
    transform: bool = True
    ):

    lon1 = source[0]
    lat1 = source[1]
    lon2 = destination[0]
    lat2 = destination[1]

    if transform:
        lat1_r = lat1*pi/180
        lon1_r = lon1*pi/180
        lat2_r = lat2*pi/180
        lon2_r = lon2*pi/180

        return lat1_r, lat2_r, lon1_r, lon2_r
    
    else:

        return lat1, lat2, lon1, lon2


def check_numeric_series(
    values: pd.Series
    ):
    
    if not pd.api.types.is_numeric_dtype(values):
        return False
    else:
        return True
