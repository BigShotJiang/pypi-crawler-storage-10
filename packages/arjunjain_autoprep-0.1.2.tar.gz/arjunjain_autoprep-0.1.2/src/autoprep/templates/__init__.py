import jinja2
from pathlib import Path

class TemplateManager:
    """Manages loading and rendering of Jinja2 templates."""
    def __init__(self, template_name: str, config: dict):
        self.template_name = template_name
        self.config = config
        self.env = self._create_env()

    def _create_env(self) -> jinja2.Environment:
        """Create a Jinja2 environment pointing to the templates directory."""
        template_path = Path(__file__).parent / self.template_name
        if not template_path.exists():
            # Fallback to a base template if the specified one doesn't exist
            template_path = Path(__file__).parent / 'base'
        
        loader = jinja2.FileSystemLoader(template_path)
        return jinja2.Environment(loader=loader)

    def render(self, template_file: Path) -> str:
        """Render a template file with the project configuration."""
        # Convert absolute path to relative path for Jinja's loader
        relative_path = template_file.relative_to(self.template_path)
        template = self.env.get_template(str(relative_path))
        return template.render(self.config)

    def get_template_files(self) -> list[Path]:
        """List all files in the template directory."""
        self.template_path = Path(__file__).parent / self.template_name
        if not self.template_path.exists():
            self.template_path = Path(__file__).parent / 'base'
        
        return [p for p in self.template_path.glob('**/*') if p.is_file()]