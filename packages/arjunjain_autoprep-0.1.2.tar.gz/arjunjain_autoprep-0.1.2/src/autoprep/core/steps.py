import abc
import os
import subprocess
from pathlib import Path
from rich.console import Console

class BaseStep(abc.ABC):
    """Abstract base class for a setup step."""
    def __init__(self, config: dict, console: Console):
        self.config = config
        self.console = console

    @abc.abstractmethod
    def run(self) -> None:
        """Execute the step."""
        pass

class CreateStructureStep(BaseStep):
    """Creates the project directory structure."""
    def run(self) -> None:
        project_name = self.config["project"]["name"]
        project_path = Path(project_name)
        if project_path.exists():
            self.console.print(f"[yellow]Directory '{project_name}' already exists. Skipping.[/yellow]")
            return
        project_path.mkdir()
        self.console.print(f"[green]✓[/green] Created project directory: '{project_name}'")

class InitGitStep(BaseStep):
    """Initializes a git repository."""
    def run(self) -> None:
        project_path = Path(self.config["project"]["name"])
        try:
            subprocess.run(["git", "init"], cwd=project_path, check=True, capture_output=True)
            self.console.print("[green]✓[/green] Initialized git repository.")
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.console.print("[red]✗[/red] Failed to initialize git repository. Is git installed?")

from autoprep.templates import TemplateManager

class GenerateFilesStep(BaseStep):
    """Generates default files from templates."""
    def run(self) -> None:
        project_path = Path(self.config["project"]["name"])
        template_name = self.config["template"]["name"]
        tm = TemplateManager(template_name, self.config)

        template_files = tm.get_template_files()
        if not template_files:
            self.console.print(f"[yellow]No templates found for '{template_name}'. Skipping file generation.[/yellow]")
            return

        for template_file in template_files:
            # Calculate the path relative to the template's root directory
            relative_path = template_file.relative_to(tm.template_path)
            output_path = project_path / str(relative_path).replace('.j2', '')

            # Ensure the parent directory exists
            output_path.parent.mkdir(parents=True, exist_ok=True)

            # Render the template using the full path
            content = tm.render(template_file)
            
            with open(output_path, "w") as f:
                f.write(content)

        self.console.print(f"[green]✓[/green] Generated files from '{template_name}' template.")

class CreateVenvStep(BaseStep):
    """Creates a virtual environment."""
    def run(self) -> None:
        project_path = Path(self.config["project"]["name"])
        venv_path = project_path / ".venv"
        try:
            subprocess.run(["python", "-m", "venv", str(venv_path)], check=True, capture_output=True)
            self.console.print(f"[green]✓[/green] Created venv at {venv_path}")
        except subprocess.CalledProcessError as e:
            self.console.print(f"[red]✗[/red] Failed to create virtual environment: {e.stderr.decode()}")

class InstallDepsStep(BaseStep):
    """Installs dependencies into the virtual environment."""
    def run(self) -> None:
        project_path = Path(self.config["project"]["name"])
        venv_path = project_path / ".venv"
        pip_path = venv_path / ("Scripts" if os.name == "nt" else "bin") / "pip"
        deps = self.config.get("deps", [])
        if not deps:
            self.console.print("[yellow]No dependencies to install. Skipping.[/yellow]")
            return
        
        try:
            subprocess.run([str(pip_path), "install"] + deps, check=True, capture_output=True)
            self.console.print(f"[green]✓[/green] Installed dependencies: {', '.join(deps)}")
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            self.console.print(f"[red]✗[/red] Failed to install dependencies: {e}")

class AddDockerStep(BaseStep):
    """Adds a Dockerfile to the project."""
    def run(self) -> None:
        if not self.config.get("options", {}).get("docker"):
            return

        project_path = Path(self.config["project"]["name"])
        template_name = self.config["template"]["name"]
        tm = TemplateManager(template_name, self.config)

        try:
            content = tm.render("Dockerfile.j2")
            with open(project_path / "Dockerfile", "w") as f:
                f.write(content)
            self.console.print("[green]✓[/green] Added Dockerfile.")
        except Exception:
            self.console.print("[yellow]No Dockerfile.j2 template found. Skipping.[/yellow]")

class AddLintingStep(BaseStep):
    """Sets up pre-commit for linting."""
    def run(self) -> None:
        if not self.config.get("options", {}).get("lint"):
            return

        project_path = Path(self.config["project"]["name"])
        pre_commit_config = """
repos:
-   repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.3.0
    hooks:
    -   id: trailing-whitespace
    -   id: end-of-file-fixer
    -   id: check-yaml
-   repo: https://github.com/psf/black
    rev: 22.10.0
    hooks:
    -   id: black
"""
        with open(project_path / ".pre-commit-config.yaml", "w") as f:
            f.write(pre_commit_config)
        
        try:
            venv_path = project_path / ".venv"
            pip_path = venv_path / ("Scripts" if os.name == "nt" else "bin") / "pip"
            subprocess.run([str(pip_path), "install", "pre-commit"], check=True, capture_output=True)
            
            pre_commit_path = venv_path / ("Scripts" if os.name == "nt" else "bin") / "pre-commit"
            subprocess.run([str(pre_commit_path), "install"], cwd=project_path, check=True, capture_output=True)
            self.console.print("[green]✓[/green] Set up pre-commit for linting.")
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            self.console.print(f"[red]✗[/red] Failed to set up linting: {e}")

# A mapping from step names to classes
STEP_REGISTRY = {
    "create_structure": CreateStructureStep,
    "init_git": InitGitStep,
    "create_venv": CreateVenvStep,
    "install_deps": InstallDepsStep,
    "generate_files": GenerateFilesStep,
    "add_docker": AddDockerStep,
    "add_linting": AddLintingStep,
}