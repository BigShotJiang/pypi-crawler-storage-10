from rich.console import Console
from .steps import STEP_REGISTRY

class Pipeline:
    """Represents a sequence of setup steps."""
    def __init__(self, config: dict, console: Console):
        self.config = config
        self.console = console
        self.steps = self._create_steps()

    def _create_steps(self):
        """Instantiate step objects based on the configuration."""
        step_names = self.config.get("steps", [])
        return [STEP_REGISTRY[name](self.config, self.console) for name in step_names if name in STEP_REGISTRY]

    def run(self):
        """Execute all steps in the pipeline."""
        project_name = self.config.get("project", {}).get("name", "new-project")
        self.console.print(f"🚀 Starting setup for project: [bold cyan]{project_name}[/bold cyan]")
        for step in self.steps:
            step.run()
        self.console.print("✅ Project setup complete!")