import typer
import click
from pathlib import Path
from typing_extensions import Annotated
from rich.console import Console

from autoprep.config import load_config
from autoprep.core.pipeline import Pipeline

app = typer.Typer()
console = Console()

from rich.prompt import Prompt, Confirm
from rich.panel import Panel

@app.command()
def new(
    lang: Annotated[str, typer.Option(help="Programming language for the project.")] = "python",
    name: Annotated[str, typer.Option(help="Name of the project.")] = None,
    deps: Annotated[str, typer.Option(help="Comma-separated list of dependencies.")] = "",
    template: Annotated[str, typer.Option(help="Project template to use.")] = None,
    profile: Annotated[str, typer.Option(help="Project profile to load.")] = "",
    docker: Annotated[bool, typer.Option(help="Add a Dockerfile.")] = None,
    lint: Annotated[bool, typer.Option(help="Set up linting with pre-commit.")] = None,
):
    """Initialize a new project. If options are not provided, an interactive prompt will appear."""
    
    if name is None:
        console.print(Panel.fit("🚀 [bold green]Welcome to Autoprep![/bold green] Let's create a new project.", border_style="green"))
        name = Prompt.ask("[bold]Project name[/bold]", default="my-awesome-project")
        
        available_templates = ["base", "webapi", "cli", "python", "webd"]
        template = Prompt.ask(
            "[bold]Select a template[/bold]", 
            choices=available_templates, 
            default="base"
        )
        
        deps = Prompt.ask("[bold]Additional dependencies (comma-separated)[/bold]", default="")
        docker = Confirm.ask("[bold]Add a Dockerfile?[/bold]", default=False)
        lint = Confirm.ask("[bold]Set up linting with pre-commit?[/bold]", default=False)

    console.print(f"✨ Starting a new project: [bold magenta]{name}[/bold magenta]")

    cli_args = {
        "project": {"lang": lang, "name": name},
        "template": {"name": template},
        "options": {"docker": docker, "lint": lint},
        "profile": profile,
        "deps": [d.strip() for d in deps.split(',')] if deps else []
    }

    project_path = Path.cwd() / name
    config = load_config(project_path, cli_args)
    
    pipeline = Pipeline(config, console)
    pipeline.run()

from rich.table import Table

@app.command(name="list-templates")
def list_templates():
    """List available project templates."""
    table = Table(title="Available Templates", border_style="blue")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Description", style="magenta")

    # In a real app, this would be discovered from the filesystem
    templates = {
        "python-base": "A minimal boilerplate for any new Python project.",
        "python-webapi": "A FastAPI-based project for web backends or microservices.",
        "python-cli": "A preconfigured CLI application using Typer.",
        "python-library": "A reusable Python library with a proper packaging setup.",
        "nodejs-express": "A NodeJS backend project using Express.",
        "react-vite": "A React frontend application using Vite.",
        "rust-cli": "A command-line application using Rust and Cargo.",
        "go-webapi": "A lightweight backend service using Go's standard library.",
        "python-ml": "A standard structure for data science and ML projects.",
        "dockerized-microservice": "A language-agnostic scaffold for a containerized service.",
    }

    for name, desc in templates.items():
        table.add_row(name, desc)

    console.print(table)

import yaml

@app.command(name="list-profiles")
def list_profiles():
    """List available project profiles."""
    profiles_path = Path.home() / ".autoprep" / "profiles.yml"
    if not profiles_path.exists():
        console.print("[yellow]No profiles file found at ~/.autoprep/profiles.yml[/yellow]")
        return

    with open(profiles_path, "r") as f:
        profiles = yaml.safe_load(f).get("profiles", {})

    if not profiles:
        console.print("[yellow]No profiles defined in ~/.autoprep/profiles.yml[/yellow]")
        return

    table = Table(title="Available Profiles", border_style="green")
    table.add_column("Profile Name", style="cyan", no_wrap=True)
    table.add_column("Template", style="magenta")
    table.add_column("Options", style="white")

    for name, config in profiles.items():
        template = config.get("template", "N/A")
        options = ", ".join([f"{k}={v}" for k, v in config.get("options", {}).items()])
        table.add_row(name, template, options)

    console.print(table)

@app.command()
def version():
    """Show the version of autoprep."""
    console.print("autoprep version 0.1.0")

if __name__ == "__main__":
    app()