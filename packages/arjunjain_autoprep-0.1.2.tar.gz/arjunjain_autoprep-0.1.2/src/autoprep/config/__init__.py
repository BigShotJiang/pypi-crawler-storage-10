import yaml
import toml
from pathlib import Path
from collections import ChainMap
from .default import DEFAULT_CONFIG

def load_config(project_path: Path, cli_args: dict) -> ChainMap:
    """Load and merge configurations from multiple sources."""
    configs = []

    # 1. Project-specific config
    project_config_path = project_path / ".autoprep.yml"
    if project_config_path.exists():
        with open(project_config_path, "r") as f:
            configs.append(yaml.safe_load(f))

    # 2. Global user config
    global_config_path = Path.home() / ".autoprep" / "config.yml"
    if global_config_path.exists():
        with open(global_config_path, "r") as f:
            configs.append(yaml.safe_load(f))

    # 3. Profiles config
    profiles_path = Path.home() / ".autoprep" / "profiles.yml"
    if profiles_path.exists():
        with open(profiles_path, "r") as f:
            profiles_config = yaml.safe_load(f)
            if cli_args.get("profile") and profiles_config:
                profile_name = cli_args["profile"]
                if profile_name in profiles_config.get("profiles", {}):
                    configs.append(profiles_config["profiles"][profile_name])

    # 3. CLI arguments
    configs.append(cli_args)

    # 4. Default config
    configs.append(DEFAULT_CONFIG)

    return ChainMap(*configs)

def get_project_config(project_path: Path) -> dict:
    """Load pyproject.toml if it exists."""
    pyproject_path = project_path / "pyproject.toml"
    if pyproject_path.exists():
        with open(pyproject_path, "r") as f:
            return toml.load(f)
    return {}