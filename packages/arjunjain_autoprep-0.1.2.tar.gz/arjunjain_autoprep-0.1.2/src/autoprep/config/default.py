DEFAULT_CONFIG = {
    "user": {
        "name": "Default User",
        "email": "user@example.com",
    },
    "project": {
        "lang": "python",
        "name": "new-project",
        "version": "0.1.0",
        "description": "A new project created with autoprep.",
        "author": "Default User",
        "email": "user@example.com",
    },
    "steps": [
        "create_structure",
        "init_git",
        "create_venv",
        "install_deps",
        "generate_files",
    ],
    "template": {
        "name": "base",
        "path": None, 
    },
    "profiles": {
        "webapi": {
            "template": "webapi",
            "deps": ["flask", "pytest"],
            "steps": [
                "create_structure",
                "init_git",
                "create_venv",
                "install_deps",
                "generate_files",
                "add_docker",
            ]
        }
    },
    "options": {
        "docker": False,
        "lint": False,
        "ci": None,
    }
}