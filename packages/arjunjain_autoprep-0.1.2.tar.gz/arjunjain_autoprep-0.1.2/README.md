# autoprep

A one-command project setup utility for bootstrapping new projects quickly.

## Features

- **One-Command Setup**: Initialize new projects with a single command.
- **Extensible Pipeline**: Customize the setup process with a step-based pipeline.
- **Templating**: Use Jinja2 templates to generate boilerplate code.
- **Configuration**: Override default settings with global and project-specific config files.
- **Optional Integrations**: Add Docker, linting, and more with simple flags.

## Installation

```bash
pip install arjunjain-autoprep
```

## Usage

`autoprep` can be run from any directory. It is recommended to run it from the folder where you want your new project to be created.

### Interactive Mode

For the best experience, run the `new` command without any options to launch the interactive setup wizard:

```bash
python -m autoprep new
```

The CLI will guide you, asking for the project name, template, and other options.

### Non-Interactive Mode

You can also provide all the options as command-line arguments:

```bash
python -m autoprep new --name myapp --template webapi --deps "flask,pytest" --docker
```

### Available Commands

- `autoprep new`: Initialize a new project.
- `autoprep list-templates`: See a detailed list of all available project templates.

### Available Templates

| Template Name             | Description                                                  |
| ------------------------- | ------------------------------------------------------------ |
| `python-base`             | A minimal boilerplate for any new Python project.            |
| `python-webapi`           | A FastAPI-based project for web backends or microservices.   |
| `python-cli`              | A preconfigured CLI application using Typer.                 |
| `python-library`          | A reusable Python library with a proper packaging setup.     |
| `nodejs-express`          | A NodeJS backend project using Express.                      |
| `react-vite`              | A React frontend application using Vite.                     |
| `rust-cli`                | A command-line application using Rust and Cargo.             |
| `go-webapi`               | A lightweight backend service using Go's standard library.   |
| `python-ml`               | A standard structure for data science and ML projects.       |
| `dockerized-microservice` | A language-agnostic scaffold for a containerized service.    |
- `autoprep list-profiles`: View your custom-defined project profiles.
- `autoprep version`: Show the version of autoprep.

## Troubleshooting

If you encounter an error like `autoprep: command not found` after installation, please refer to the **[Troubleshooting Guide](TROUBLESHOOTING.md)** for a step-by-step solution.

## Profiles

For even faster setup, you can define profiles in a `~/.autoprep/profiles.yml` file. A profile is a pre-defined combination of a template and options.

### Example `profiles.yml`

```yaml
profiles:
  webapi:
    template: python-webapi
    options:
      docker: true
      lint: true
  cli_tool:
    template: python-cli
    options:
      lint: true
```

Now, you can bootstrap a complete web API project with a single command:

```bash
autoprep new --profile webapi
```

## Configuration

For more advanced customization, `autoprep` can be configured through a global `~/.autoprep/config.yml` file and a project-specific `.autoprep.yml` file. Command-line options will always override settings from the configuration files.

### Example `config.yml`

```yaml
user:
  name: Your Name
  email: your.email@example.com

project:
  lang: python
  author: Your Name
  email: your.email@example.com

profiles:
  my-profile:
    template: webapi
    deps:
      - flask
      - pytest
      - black
    steps:
      - create_structure
      - init_git
      - create_venv
      - install_deps
      - generate_files
      - add_docker
      - add_linting
```
