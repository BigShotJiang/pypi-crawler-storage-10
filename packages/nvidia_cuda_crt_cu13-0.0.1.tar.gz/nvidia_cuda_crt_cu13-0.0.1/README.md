⚠️ THIS PROJECT 'nvidia-cuda-crt-cu13' IS DEPRECATED.
Please use 'nvidia-cuda-crt' instead.

To install the correct package, use:

    pip install nvidia-cuda-crt

For more information, visit: https://pypi.org/project/nvidia-cuda-crt/
