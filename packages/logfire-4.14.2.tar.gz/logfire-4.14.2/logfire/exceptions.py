"""Logfire exceptions."""


class LogfireConfigError(ValueError):
    """Error raised when there is a problem with the Logfire configuration."""
