"""Snowflake Singer Tap."""

__version__ = "0.3.0"
