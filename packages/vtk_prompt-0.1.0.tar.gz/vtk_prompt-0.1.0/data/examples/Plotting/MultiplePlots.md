### Description

Display multiple plots by using viewports in a single render window.

In this case, we display two graphs side-by-side.

The difference between setting a background in the renderer and setting the chart background is shown.

!!! Note
   This example was prompted by this discussion [vtk chart background shifted towards origin](https://discourse.vtk.org/t/vtk-chart-background-shifted-towards-origin/5890).
