### Description

A spider plot is used to display multivariate data. See [this wikipedia article](https://en.wikipedia.org/wiki/Radar_chart) for more information.
