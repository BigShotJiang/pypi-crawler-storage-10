### Description

Scale the vertices based on a data array.
