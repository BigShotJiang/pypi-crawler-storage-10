### Description

We create the tree, and label the vertices and edges.

!!! info
  This is an update of the original example found in `vtk/Examples/Infovis/Cxx/CreateTree.cxx`.
