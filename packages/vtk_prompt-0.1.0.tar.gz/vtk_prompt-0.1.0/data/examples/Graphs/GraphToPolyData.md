### Description

This example creates a simple graph and then converts it to a polydata for visualization using Paraview.
