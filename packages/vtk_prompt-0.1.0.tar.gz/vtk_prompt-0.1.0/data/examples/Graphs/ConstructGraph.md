### Description

This example shows how to construct a simple graph.
