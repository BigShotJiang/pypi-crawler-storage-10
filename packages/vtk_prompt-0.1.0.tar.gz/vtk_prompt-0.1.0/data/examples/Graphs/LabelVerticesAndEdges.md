### Description

This example sets and displays labels of vertices and edges of a graph.
