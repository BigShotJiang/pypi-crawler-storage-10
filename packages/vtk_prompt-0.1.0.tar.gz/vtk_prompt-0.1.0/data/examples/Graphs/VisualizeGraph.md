### Description

* Contributed by Jim McCusker

!!! note
    AddEdge() is not enabled through python, but AddGraphEdge() is.
