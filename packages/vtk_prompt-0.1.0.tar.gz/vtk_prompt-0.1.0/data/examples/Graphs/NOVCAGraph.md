### Description

<img style="float:middle" src="https://raw.githubusercontent.com/Kitware/vtk-examples/gh-pages/src/SupplementaryData/Python/Graphs/NOVACGraph.png">

* This example shows how to construct a graph to visualize it in ParaView/VisIt using the VTK output file testVertex.vtu.

* Contributed by Sanjaya Gajurel, Case Western Reserve University
