### Description

This is two dimensional Delaunay triangulation of a random set of points. Points and edges are shown highlighted with spheres and tubes.

!!! info
    See [Figure 9-54](../../../VTKBook/09Chapter9/#Figure%209-54) in [Chapter 9](../../../VTKBook/09Chapter9) The [VTK Textbook](../../../VTKBook/01Chapter1).
