### Description
This example is similar to [Finance](../Finance), but here we read a .vtk file with vtkDataObjectReader. The file is: `src/Testing/Data/financial.vtk`.

The generated image is Figure 5 in [VTKFileFormats](../../../VTKFileFormats#legacy-file-examples).
