### Description

This example creates a tube around a line. This is helpful because when you zoom the camera, the thickness of a line remains constant, while the thickness of a tube varies.
