### Description

This script creates a vtkLine and deflects it using a vtkWarpVector.
