### Decription

Creates a file called TestTriangleColored.vtp.
