### Description

This example creates 50 random points and extracts 10 of them (the points with ids 10-19).

Also demonstrated is how to invert the selection.

The three actors in the render window display from left to right:

- all the points
- the selected points
- the points not selected.
