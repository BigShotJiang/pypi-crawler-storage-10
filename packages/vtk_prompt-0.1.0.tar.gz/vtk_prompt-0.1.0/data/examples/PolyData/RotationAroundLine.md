### Description

NOTE: this example shows both the original and the rotated object using different colors. Not exactly equivalent to the C++ example with the same name.
