### Description

This is an example from the vtkPolyDataToImageStencil tests. It converts polydata to imagedata and masks the given imagedata.
