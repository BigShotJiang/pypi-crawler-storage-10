### Description

Create a terrain with regularly spaced points. The triangles are created manually. Then different types of smoothing filters are used to smooth the terrain.

Left : initial terrain, middle : vtkLoopSubdivisionFilter, right : vtkButterflySubdivisionFilter

* Contributed by Michka Popoff, with the help of Bill Lorensen and madz (madaramh).
