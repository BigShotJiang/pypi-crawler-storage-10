### Description

This example uses vtkCutter to create contour lines. It processes these lines with vtkStripper to create continuous poly lines. After exiting the example with the "e" key, the lines are printed.
