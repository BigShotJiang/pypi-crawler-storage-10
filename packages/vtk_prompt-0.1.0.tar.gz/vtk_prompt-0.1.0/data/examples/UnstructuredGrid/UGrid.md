### Description

Creation of an unstructured grid.

!!! info
    See [Figure 5-21](../../../VTKBook/05Chapter5/#Figure%205-21) in [Chapter 05](../../..//VTKBook/05Chapter5) the [VTK Textbook](../../../VTKBook/01Chapter1).
