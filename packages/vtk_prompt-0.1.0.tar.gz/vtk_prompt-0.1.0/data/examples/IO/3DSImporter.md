### Description

This example illustrates Importing files in VTK. An importer creates a vtkRenderWindow that describes the scene.

!!! info
    See [Figure 4-13](../../../VTKBook/04Chapter4/#Figure%204-13) in [Chapter 4](../../../VTKBook/04Chapter4) the [VTK Textbook](../../../VTKBook/01Chapter1).
