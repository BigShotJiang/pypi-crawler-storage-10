### Description

This example demonstrates how to read an unstructured grid (VTU) file. The front facing faces are colored Misty Rose, while the back facing faces are colored Tomato.

An example file to use is `src/Testing/Data/tetra.vtu`.
