### Description

This example reads a polygonal data (.vtp) file, for example `src/Testing/Data/Torso.vtp`.
