### Description

This example reads an image data (.vti) file.
