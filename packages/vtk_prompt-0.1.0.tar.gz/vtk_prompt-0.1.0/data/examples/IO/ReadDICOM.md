### Description

This example reads a DICOM file and displays it on the screen. <a id="raw-url" href="https://raw.githubusercontent.com/Kitware/vtk-examples/gh-pages/src/SupplementaryData/Cxx/IO/DICOM_Prostate.zip">DICOM_Prostate</a> is an example data set.
