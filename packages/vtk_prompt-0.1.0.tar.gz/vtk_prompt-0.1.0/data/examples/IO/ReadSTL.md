### Description

Read an STL file and create a PolyData output
