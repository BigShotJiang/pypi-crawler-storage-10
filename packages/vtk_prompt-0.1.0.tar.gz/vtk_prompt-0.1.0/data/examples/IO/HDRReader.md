### Description

Demonstrates how to read high-dynamic-range imaging files.

A callback is used to print out the color window (move the mouse horizontally over the image) and color level (move the mouse vertically over the image).

This is based on IO/Image/Testing/Cxx/TestHDRReader.cxx in the VTK source files.
