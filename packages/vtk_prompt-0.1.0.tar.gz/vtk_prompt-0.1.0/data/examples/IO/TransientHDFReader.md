### Description

That example uses a feature of vtk_hdf5 that is only available in [vtk/master](https://gitlab.kitware.com/vtk/vtk) and will be released with VTK 9.3. See [this blog post](https://www.kitware.com/how-to-write-time-dependent-data-in-vtkhdf-files/) for more information.
