### Description

The example uses vtkExodusIIReader to read an ExodusII file. The nodal variable to read is the second argument. The nodal variable is displayed with a color map.
