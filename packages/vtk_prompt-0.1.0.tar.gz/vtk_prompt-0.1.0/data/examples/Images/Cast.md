### Description

Cast an image to a different type.
