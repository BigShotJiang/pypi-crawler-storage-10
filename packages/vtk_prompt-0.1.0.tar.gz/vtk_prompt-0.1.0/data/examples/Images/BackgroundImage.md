### Description

This example displays an image as the "background" of a scene, and renders a superquadric in front of it.

The example accepts a jpeg file on the command line to use as a background image. If there is no file, it generates a simple background.
