### Description

This example demonstrates how to use multiple renderers within a
render window.
