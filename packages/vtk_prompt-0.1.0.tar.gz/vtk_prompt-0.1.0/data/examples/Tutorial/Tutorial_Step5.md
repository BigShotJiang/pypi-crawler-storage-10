### Description

This example introduces the concepts of interaction into the
Python environment. A different interaction style (than
the default) is defined.
