### Description

This example demonstrates the creation of multiple actors and the
manipulation of their properties and transformations.
