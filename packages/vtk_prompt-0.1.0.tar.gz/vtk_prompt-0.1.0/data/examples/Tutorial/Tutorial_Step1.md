### Description

This example creates a polygonal model of a cone, and then renders it to
the screen. It will rotate the cone 360 degrees and then exit. The basic
setup of `source -> mapper -> actor -> renderer -> renderwindow` is typical of most VTK programs.
