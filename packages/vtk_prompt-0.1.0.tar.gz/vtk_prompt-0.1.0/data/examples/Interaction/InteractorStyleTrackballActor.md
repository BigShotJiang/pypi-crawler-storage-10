### Description

Move, rotate, and scale an object in 3D.
