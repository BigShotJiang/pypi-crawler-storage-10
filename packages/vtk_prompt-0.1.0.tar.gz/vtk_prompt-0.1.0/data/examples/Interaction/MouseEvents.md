### Description

This example creates a new vtkInteractorStyle which can be used to implement custom reactions on user events. If you just want to disable single events you can also have a look at [MouseEventsObserver](../MouseEventsObserver). This specific example just prints a simple message and then calls the original eventhandler of the vtkInteractorStyleTrackballCamera.
