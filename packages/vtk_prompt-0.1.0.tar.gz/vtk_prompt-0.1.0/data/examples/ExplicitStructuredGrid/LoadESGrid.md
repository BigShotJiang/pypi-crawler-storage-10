### Description

This example displays the [UNISIM-II-D reservoir model](https://www.unisim.cepetro.unicamp.br/benchmarks/en/unisim-ii/unisim-ii-d) using the vtkExplicitStructuredGrid class.
