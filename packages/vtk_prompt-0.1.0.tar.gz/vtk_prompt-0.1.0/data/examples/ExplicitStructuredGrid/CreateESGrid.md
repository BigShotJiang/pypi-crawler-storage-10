### Description

This example demonstrates how (1) to create an explicit structured grid and (2) to convert an explicit structured grid into an unstructured grid or vice versa.
