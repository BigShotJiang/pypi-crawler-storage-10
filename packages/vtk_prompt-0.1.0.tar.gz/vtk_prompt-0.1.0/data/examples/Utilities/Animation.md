### Description

This example demonstrates how to create a simple animation. A timer is used to move a sphere across a scene.
