### Description

Comparison of Gaussian and Median smoothing for reducing low-probability high-amplitude noise.

!!! info
    See [this figure](../../../VTKBook/10Chapter10/#Figure%2010-3) in [Chapter 10](../../../VTKBook/10Chapter10) the [VTK Textbook](../../../VTKBook/01Chapter1).
