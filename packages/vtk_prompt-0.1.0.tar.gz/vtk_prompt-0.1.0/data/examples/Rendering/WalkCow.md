### Description

This generates Fig. 3-32: The cow "walking" around the global origin; Fig. 3-33: The cow rotating about a vector passing through her nose. (a) With origin (0,0,0). (b) With origin at (6.1,1.3,.02). found in [VTKTextbook](https://www.kitware.com/products/books/VTKTextbook.pdf).

The example allows an optional second argument that selects the figure to be generated. A *0* generates Fig 3-32, *1* generates Fig 3-33a and *2* generates Fig 3-33b.

!!! info
    See [Figure 3-32](../../../VTKBook/03Chapter3/#Figure%203-32) in [Chapter 3](../../../VTKBook/03Chapter3) the [VTK Textbook](../../../VTKBook/01Chapter1).
