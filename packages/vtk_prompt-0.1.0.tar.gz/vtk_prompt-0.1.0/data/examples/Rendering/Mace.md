### Description

An example of multiple inputs and outputs.

!!! info
    See [Figure 4-21](../../../VTKBook/04Chapter4/#Figure%204-21) in [Chapter 4](../../../VTKBook/04Chapter4) the [VTK Textbook](../../../VTKBook/01Chapter1).
