### Description

This example modifies vtkActor's properties and transformation matrix.

!!! info
    See [Figure 3-28](../../../VTKBook/03Chapter3/#Figure%203-28) in [Chapter 3](../../../VTKBook/03Chapter3) the [VTK Textbook](../../../VTKBook/01Chapter1).
