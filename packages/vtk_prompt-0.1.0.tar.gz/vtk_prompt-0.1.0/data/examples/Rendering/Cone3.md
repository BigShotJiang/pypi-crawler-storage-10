### Description

!!! info
    See [Figure 3-27](../../../VTKBook/03Chapter3/#Figure%203-27) in [Chapter 3](../../../VTKBook/03Chapter3) the [VTK Textbook](../../../VTKBook/01Chapter1).
