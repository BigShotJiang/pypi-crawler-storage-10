### Description

Rotations of a cow about her axes. In this model, the *x* axis is from the left to right; the *y* axis is from bottom to top; and the *z* axis emerges from the image. The camera location is the same in all four images.

!!! info
    See [Figure 3-31](../../../VTKBook/03Chapter3/#Figure%203-31) in [Chapter 3](../../..//VTKBook/03Chapter3) the [VTK Textbook](../../../VTKBook/01Chapter1).
