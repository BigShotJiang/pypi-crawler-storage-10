### Description

Example of motion blur.

!!! info
    See [Figure 7-36](../../../VTKBook/07Chapter7/#Figure%207-36) in [Chapter 7](../../../VTKBook/07Chapter7) in the [VTK Textbook](../../../VTKBook/01Chapter1/).
