### Description

Sum multiple images. Images must be of the same size and type.
