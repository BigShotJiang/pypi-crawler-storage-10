### Description

Convert a vtkImageData to a vtkPolyData.
