### Description

Creating a rectilinear grid dataset. The coordinates along each axis are defined using an instance of vtkDataArray.

!!! info
    See [Figure 5-20](../../../VTKBook/05Chapter5/#Figure%205-20) in [Chapter 5](../../../VTKBook/05Chapter5) the [VTK Textbook](../../../VTKBook/01Chapter1).
