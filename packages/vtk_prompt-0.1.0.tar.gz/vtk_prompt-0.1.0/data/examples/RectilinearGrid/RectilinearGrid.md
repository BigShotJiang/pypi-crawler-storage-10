### Description

Shows how to create a vtkRectilinearGrid.
