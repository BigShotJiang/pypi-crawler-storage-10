### Description
See: [Parametric Equations for Surfaces](http://www.vtk.org/wp-content/uploads/2015/11/ParametricSurfaces.pdf)

This example also demonstrates how to manipulate lists of VTK objects using lists. Notice how parameters of the various Parametric Objects are accessed and set in the parametricObjects list.
