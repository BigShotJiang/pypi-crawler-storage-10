### Description
See [Parametric Equations for Surfaces](http://www.vtk.org/wp-content/uploads/2015/11/ParametricSurfaces.pdf) by Andrew Maclean for an excellent description of these beautiful parametric surfaces.

You can edit the following code by selecting any one of the functions and the corresponding object will be displayed.
