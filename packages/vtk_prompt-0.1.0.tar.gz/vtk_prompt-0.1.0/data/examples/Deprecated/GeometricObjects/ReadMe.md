# Deprecated GeometricObjects

## ParametricObjects

These examples:

- ParametricObjects
- ParametricObjectsDemo
- ParametricObjectsDemo2

Have been replaced by a single example

- ParametricObjectsDemo

That encompasses all the functionality of the deprecated examples.
