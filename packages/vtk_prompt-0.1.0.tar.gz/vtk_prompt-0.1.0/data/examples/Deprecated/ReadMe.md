# Deprecated examples

In this folder you will find examples that have been deprecated.
