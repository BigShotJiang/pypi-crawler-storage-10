### Description


* Contributed by Jim McCusker


!!! note
    The vtkGeovisCore classes as well as the module vtkViewsGeovis have been deprecated for VTK 8.2 and will be removed in a future version.
    See [VTK Merge Request 4395](https://gitlab.kitware.com/vtk/vtk/merge_requests/4395)
