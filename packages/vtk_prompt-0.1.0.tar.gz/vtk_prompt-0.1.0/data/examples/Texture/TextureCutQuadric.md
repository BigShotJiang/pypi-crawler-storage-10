### Description

Clip geometry using a 2D texture map and two implicit functions. The
technique is described in : [Geometric Clipping Using Boolean
Textures](http://marchingcubes.org/images/c/c0/GeometricClippingUsingBooleanTextures.pdf).

!!! info
    See [Figure 9-45b](../../../VTKBook/09Chapter9/#Figure%209-45b) in [Chapter 9](../../../VTKBook/09Chapter9) The [VTK Textbook](../../../VTKBook/01Chapter1).
