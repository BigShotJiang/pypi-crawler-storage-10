### Description

Get values from a vtkPolyData source, normals in this case.
