### Description

Renaming the normals array.
