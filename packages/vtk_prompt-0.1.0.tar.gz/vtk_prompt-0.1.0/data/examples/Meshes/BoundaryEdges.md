### Description

This filter will extract the boundary edges of a mesh. The original mesh is shown with the feature edges shown in red.
