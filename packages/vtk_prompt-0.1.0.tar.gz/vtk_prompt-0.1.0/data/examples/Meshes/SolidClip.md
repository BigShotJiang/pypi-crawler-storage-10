### Description

This example clips a mesh and applies a backface property to that mesh so that it appears to have a solid interior.

The "ghost" of the part clipped away is also shown.
