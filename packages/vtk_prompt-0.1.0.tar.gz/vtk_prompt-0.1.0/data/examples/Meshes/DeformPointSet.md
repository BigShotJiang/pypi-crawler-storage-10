### Description

An example that shows how to use the vtkDeformPointSet filter to deform a sphere with arbitrary polydata. This example uses a vtkSphereSource to generate polydata to use, however any polydata could be used, including stl files.
