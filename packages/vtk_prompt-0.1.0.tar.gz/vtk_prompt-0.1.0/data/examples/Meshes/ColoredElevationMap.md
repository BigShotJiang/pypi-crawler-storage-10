### Description

This example creates a elevation map with different color based on height.
