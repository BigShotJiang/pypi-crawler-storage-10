### Description

This example uses vtkPointInterpolator with a Gaussian Kernel (or other kernel) to interpolate and extrapolate more smoothly the fields inside and outside the probed area.

!!! info
    This C++ code is translated from the python code that Kenichiro Yoshimi wrote to respond to Hosam. See the [discourse discussion](https://discourse.vtk.org/t/interpolate-on-stl-plotting-scalar-field-on-50-points-on-an-70000-points-stl-surface/450).
