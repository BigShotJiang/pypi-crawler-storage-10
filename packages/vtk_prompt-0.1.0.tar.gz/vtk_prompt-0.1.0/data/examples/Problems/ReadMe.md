# Problem examples

In this folder you will find that have problems. Usually bugs that need fixing.
