### Description

This example finds the squared distance and the Euclidean distance between two 3D points.
