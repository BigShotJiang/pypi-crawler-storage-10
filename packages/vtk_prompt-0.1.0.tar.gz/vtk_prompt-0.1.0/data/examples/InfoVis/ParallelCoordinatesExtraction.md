### Description

Using Parallel Coordinates View to plot and compare data set attributes, and then using selections in the parallel coordinates  view to extract and view data points associated with those selections.
