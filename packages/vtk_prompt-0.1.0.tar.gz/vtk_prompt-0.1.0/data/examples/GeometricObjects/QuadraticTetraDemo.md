### Description

This example shows the effect of changing the chord length error for a vtkQuadraticTetra.
