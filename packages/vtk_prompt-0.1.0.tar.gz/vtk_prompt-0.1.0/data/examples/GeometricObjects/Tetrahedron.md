### Description

Tetrahedron. The tetrahedron is a primary three-dimensional cell. The tetrahedron is defined by a list of four nonplanar
points. The tetrahedron has six edges and four triangular faces.
