### Description

This example shows how to position an vtkAxesActor in 3D. Notice that position and orientation of the vtkAxesActor is
done with a user transform.

!!! seealso
    [DisplayCoordinateAxes](../../Visualization/DisplayCoordinateAxes).
