### Description

The example shows the vtkPolyLine that forms the base of the elliptical cylinder and an oriented arrow that represents
the vector that vtkLinearExtrusionFilter uses to create the cylinder. The example takes an optional triple that defines
the vector for the filter. The length of the vector is the height of the cylinder.
