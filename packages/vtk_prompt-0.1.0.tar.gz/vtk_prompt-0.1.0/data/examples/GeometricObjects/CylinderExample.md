### Description

This example creates a minimal visualization program, demonstrating VTK's basic rendering and pipeline creation.

!!! note
    This original C++ source code for this example is [here](https://gitlab.kitware.com/vtk/vtk/blob/73465690278158b9e89661cd6aed26bead781378/Examples/Rendering/Cxx/Cylinder.cxx).
