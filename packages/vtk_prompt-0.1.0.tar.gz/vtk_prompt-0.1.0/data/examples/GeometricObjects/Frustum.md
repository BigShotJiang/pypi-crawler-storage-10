### Description

This example gets the frustum from a camera and displays it on the screen.
