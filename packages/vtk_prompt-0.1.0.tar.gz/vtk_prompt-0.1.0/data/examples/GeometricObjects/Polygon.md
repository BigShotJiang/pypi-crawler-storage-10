### Description

The polygon is a primary two-dimensional cell. The polygon is defined by an ordered list of three or more points lying
in a plane. The polygon normal is implicitly defined by a counterclockwise ordering of its points using the right-hand
rule.

The polygon may be nonconvex, but may not have internal loops, and it cannot self-intersect. The polygon has n edges,
where n is the number of points in the polygon.
