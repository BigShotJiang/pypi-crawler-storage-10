### Description

Connect several points with a line.

!!! seealso
    [ColoredLines](../ColoredLines).
