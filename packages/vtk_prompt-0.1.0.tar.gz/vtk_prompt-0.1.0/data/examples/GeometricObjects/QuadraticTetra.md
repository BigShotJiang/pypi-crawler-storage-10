### Description

The quadratic tetrahedron is a primary three-dimensional cell. It is defined by ten points. The first four points are
located at the vertices of the tetrahedron; the next six are located in the middle of each of the six edges.
