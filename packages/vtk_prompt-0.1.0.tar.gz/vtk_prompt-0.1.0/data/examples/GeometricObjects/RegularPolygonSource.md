### Description

This example creates a pentagon.
