### Description

Linear cell types found in VTK.

The numbers define the ordering of the defining points.

Options are provided to show a wire frame (`-w`) or to add a back face color (`-b`). You can also remove the plinth with the (`-n`) option.
If you want a single object, use `-o` followed by the object number.

With the back face option selected, the back face color will be visible as the objects are semitransparent.
