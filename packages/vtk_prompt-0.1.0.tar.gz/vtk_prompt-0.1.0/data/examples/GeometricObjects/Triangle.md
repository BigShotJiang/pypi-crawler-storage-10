### Description

The triangle is a primary two-dimensional cell. The triangle is defined by a counterclockwise ordered list of three
points. The order of the points specifies the direction of the surface normal using the right-hand rule.
