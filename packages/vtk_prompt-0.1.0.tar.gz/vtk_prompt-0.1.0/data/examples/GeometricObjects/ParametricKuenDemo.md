### Description

The example shows interaction with the vtkParametricKuen vtkParametricFunctionSource.
The [Kuen Surface](http://mathworld.wolfram.com/KuenSurface.html) This surface of constant Gaussian curvature K = -1 was
discovered early. It is very popular because of its beauty.

Here's the embedded video:
<br>
<iframe width="256" src="https://www.youtube.com/embed/vaYORrzl8DI" frameborder="0" allow="accelerometer; autoplay; loop; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
