### Description

This is based on the C++
example [Examples/DataManipulation/Cxx/Cube.cxx](http://vtk.org/gitweb?p=VTK.git;a=blob;f=Examples/DataManipulation/Cxx/Cube.cxx)
in the VTK source distribution.

It illustrates the manual use of vtkPolyData to construct a cube and differs from the Wiki
examples [Cube1.cxx](../../../Cxx/GeometricObjects/Cube1) and [Cube1.py](../Cube1), which use vtkCubeSource.
