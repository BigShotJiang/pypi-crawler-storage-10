### Description

The hexahedron is a primary three-dimensional cell consisting of six quadrilateral faces, twelve edges, and eight
vertices. The hexahedron is defined by an ordered list of eight points. The faces and edges must not intersect any other
faces and edges, and the hexahedron must be convex.
