### Description

The polyline is a composite one-dimensional cell consisting of one or more connected lines. The polyline is defined by
an ordered list of n+1 points, where n is the number of lines in the polyline. Each pair of points (i, i+1) defines a
line.
