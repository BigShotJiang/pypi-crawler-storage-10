### Description

Display a cube.

A nice simple example that demonstrates the operation of the VTK pipeline.
