### Description

vtkPoints object represents 3D points. The data model for vtkPoints is an array of vx-vy-vz triplets accessible by (
point or cell) id.
