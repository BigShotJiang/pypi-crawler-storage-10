### Description

A circle is simply the limiting case of a regular polygon. We use vtkRegularPolygonSource with a large number of Sides
to approximate a circle.
