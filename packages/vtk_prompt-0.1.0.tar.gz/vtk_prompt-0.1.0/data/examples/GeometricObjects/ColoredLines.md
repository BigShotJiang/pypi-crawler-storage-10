### Description

Displays two lines, each with a different color.

!!! seealso
    [LongLine](../LongLine).
