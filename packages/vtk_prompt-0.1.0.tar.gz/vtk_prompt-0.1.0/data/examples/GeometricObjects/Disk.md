### Description

vtkDiskSource objects creates a polygonal disk with a hole in the center.

The disk has zero height. The user can specify the inner and outer radius of the disk, and the radial and
circumferential resolution of the polygonal representation.
