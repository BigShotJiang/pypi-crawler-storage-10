### Description

The vertex is a primary zero-dimensional cell. It is defined by a single point.
