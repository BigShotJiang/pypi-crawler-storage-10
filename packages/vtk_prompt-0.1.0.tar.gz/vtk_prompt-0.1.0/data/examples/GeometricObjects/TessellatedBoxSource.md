### Description

Generates a box(cube) using vtkTessellatedBoxSource with 6 sides. The faces of the box can be subdivided into multiple
triangles or quads.

!!! seealso
    [Cube](../Cube) generates multiple quads or triangles per side.
