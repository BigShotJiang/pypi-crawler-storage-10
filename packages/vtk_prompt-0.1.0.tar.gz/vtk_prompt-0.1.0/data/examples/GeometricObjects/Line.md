### Description

The line is a primary one-dimensional cell. It is defined by two points. The direction along the line is from the first
point to the second point.
