### Description

Creating a structured grid dataset of a semicylinder. Vectors are created whose magnitude is proportional to radius and oriented in tangential direction. 

!!! info
    See [Figure 5-19](../../../VTKBook/05Chapter5/#Figure%205-19) in [Chapter 5](../../../VTKBook/05Chapter5) the [VTK Textbook](../../../VTKBook/01Chapter1).
