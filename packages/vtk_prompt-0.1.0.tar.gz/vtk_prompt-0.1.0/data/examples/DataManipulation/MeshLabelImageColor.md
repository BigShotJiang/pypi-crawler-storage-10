### Description

This example takes a label image in Meta format and meshes a single label of it. It then smooths the mesh and colours the vertices according to the displacement error introduced by the smoothing. The whole thing is then displayed.
