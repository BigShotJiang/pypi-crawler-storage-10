### Description

Create an ellipsoid by using the implicit quadric.
