### Description

Shows how to create a surface representing a sphere by creating an implicit sphere, sampling the implicit function, and finally contouring the sampled data to produce the surface.
