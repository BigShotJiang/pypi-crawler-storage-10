### Description

Demonstration on how to perform boolean operations with implicit functions.
