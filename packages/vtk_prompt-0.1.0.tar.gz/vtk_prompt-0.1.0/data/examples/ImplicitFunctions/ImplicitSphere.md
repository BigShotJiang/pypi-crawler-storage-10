### Description

This example creates an isosurface of sampled sphere.

!!! info
    See [Figure 6-23b](../../../VTKBook/06Chapter6/#Figure%206-23b) in [Chapter 6](../../../VTKBook/06Chapter6) the [VTK Textbook](../../../VTKBook/01Chapter1).
