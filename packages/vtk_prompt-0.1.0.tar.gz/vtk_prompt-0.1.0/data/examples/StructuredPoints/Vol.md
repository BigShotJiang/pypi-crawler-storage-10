### Description

 Creating a image data dataset. Scalar data is generated from the equation for a sphere. Volume dimensions are 26^3. 

!!! info
    See [Figure 5-18](../../../VTKBook/05Chapter5/#Figure%205-18) in [Chapter 5](../../../VTKBook/05Chapter5) the [VTK Textbook](../../../VTKBook/01Chapter1).
