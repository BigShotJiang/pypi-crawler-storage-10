### Description

Copy a polydata to every point in the input set. We use a hexagon for the demo.
