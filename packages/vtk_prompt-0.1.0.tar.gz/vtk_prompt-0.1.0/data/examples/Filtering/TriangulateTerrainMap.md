### Description

This example generates heights (z-values) on a 10x10 grid (a terrain map) and triangulates the points.
