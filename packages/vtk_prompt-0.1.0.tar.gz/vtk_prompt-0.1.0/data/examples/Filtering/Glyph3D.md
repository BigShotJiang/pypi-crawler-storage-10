### Description

This example applies an object at every point. We use a cube for the demo.
