### Description

This example demonstrates how to apply a transform to a data set. It uses vtkTransformPolyDataFilter, but it can be
replaced with vtkTransformFilter for different types of data sets, including vtkUnstructuredGrid and vtkStructuredGrid.
vtkTransformFilter will work with vtkPolyData, too).
