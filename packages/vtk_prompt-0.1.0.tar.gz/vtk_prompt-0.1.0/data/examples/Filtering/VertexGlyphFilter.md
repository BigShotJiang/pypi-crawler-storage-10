### Description

This example creates a set of points and adds a vertex at each point using vtkVertexGlyphFilter.
