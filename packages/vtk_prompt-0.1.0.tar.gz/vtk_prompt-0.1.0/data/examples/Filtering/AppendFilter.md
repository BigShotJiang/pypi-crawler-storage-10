### Description

This example loads points into a polydata and an unstructured grid then combines them.

The example should be extended to show cells being combined as well.
