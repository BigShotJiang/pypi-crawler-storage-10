### Description

This example reads two .vtp files (or produces them if not specified as command line arguments), combines them, and
displays the result to the screen.
