### Description

This example demonstrates the use of multiline 2D text using
vtkTextMapper.  It shows several justifications as well as
single-line and multiple-line text inputs.
