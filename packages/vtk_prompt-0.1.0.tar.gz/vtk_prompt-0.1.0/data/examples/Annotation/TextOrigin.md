### Description

This example demonstrates the use of vtkVectorText and vtkFollower.
vtkVectorText is used to create 3D annotation.  vtkFollower is used to
position the 3D text and to ensure that the text always faces the
renderer's active camera (i.e., the text is always readable).
