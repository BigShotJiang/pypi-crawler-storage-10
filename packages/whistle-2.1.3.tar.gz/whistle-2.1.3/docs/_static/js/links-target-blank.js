$(document).ready(function () {
    $('a.external').attr('target', '_blank');
});
