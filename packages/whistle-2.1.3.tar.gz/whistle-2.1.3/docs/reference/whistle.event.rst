whistle.event
=============

.. automodule:: whistle.event
    :members:
    :undoc-members:
    :show-inheritance:
