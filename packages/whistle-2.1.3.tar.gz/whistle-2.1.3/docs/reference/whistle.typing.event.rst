whistle.typing.event
====================

.. automodule:: whistle.typing.event
    :members:
    :undoc-members:
    :show-inheritance:
