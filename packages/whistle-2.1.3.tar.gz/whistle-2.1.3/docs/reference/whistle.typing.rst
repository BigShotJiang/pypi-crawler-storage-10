whistle.typing
==============

.. automodule:: whistle.typing
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::
    :maxdepth: 1

    whistle.typing.dispatcher
    whistle.typing.event
    whistle.typing.listener
