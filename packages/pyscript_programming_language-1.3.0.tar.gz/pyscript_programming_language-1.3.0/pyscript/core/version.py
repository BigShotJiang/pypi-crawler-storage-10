__version__ = '1.3.0'
__date__ = '25 October 2025, 17:00 UTC+7'

version = '{} ({})'.format(__version__, __date__)
version_info = None