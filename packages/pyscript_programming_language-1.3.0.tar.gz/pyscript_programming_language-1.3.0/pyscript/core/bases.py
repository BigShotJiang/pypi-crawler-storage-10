class Pys:
    """
    Base class for all PyScript objects.
    """