# coding: utf-8

import six

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListDisasterRecoveryRecordRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'x_language': 'str',
        'instance_id': 'str',
        'entity_id': 'str',
        'entity_type': 'str',
        'limit': 'int',
        'offset': 'int'
    }

    attribute_map = {
        'x_language': 'X-Language',
        'instance_id': 'instance_id',
        'entity_id': 'entity_id',
        'entity_type': 'entity_type',
        'limit': 'limit',
        'offset': 'offset'
    }

    def __init__(self, x_language=None, instance_id=None, entity_id=None, entity_type=None, limit=None, offset=None):
        r"""ListDisasterRecoveryRecordRequest

        The model defined in huaweicloud sdk

        :param x_language: **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us
        :type x_language: str
        :param instance_id: 实例id。
        :type instance_id: str
        :param entity_id: 实体id（容灾id）
        :type entity_id: str
        :param entity_type: 实体类型（容灾类型）
        :type entity_type: str
        :param limit: 查询记录数。默认为100，不能为负数，最小值为1，最大值为100。
        :type limit: int
        :param offset: 索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。
        :type offset: int
        """
        
        

        self._x_language = None
        self._instance_id = None
        self._entity_id = None
        self._entity_type = None
        self._limit = None
        self._offset = None
        self.discriminator = None

        if x_language is not None:
            self.x_language = x_language
        self.instance_id = instance_id
        self.entity_id = entity_id
        self.entity_type = entity_type
        if limit is not None:
            self.limit = limit
        if offset is not None:
            self.offset = offset

    @property
    def x_language(self):
        r"""Gets the x_language of this ListDisasterRecoveryRecordRequest.

        **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us

        :return: The x_language of this ListDisasterRecoveryRecordRequest.
        :rtype: str
        """
        return self._x_language

    @x_language.setter
    def x_language(self, x_language):
        r"""Sets the x_language of this ListDisasterRecoveryRecordRequest.

        **参数解释**: 语言。 **约束限制**: 不涉及。 **取值范围**:   - zh-cn   - en-us  **默认取值**: en-us

        :param x_language: The x_language of this ListDisasterRecoveryRecordRequest.
        :type x_language: str
        """
        self._x_language = x_language

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ListDisasterRecoveryRecordRequest.

        实例id。

        :return: The instance_id of this ListDisasterRecoveryRecordRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ListDisasterRecoveryRecordRequest.

        实例id。

        :param instance_id: The instance_id of this ListDisasterRecoveryRecordRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def entity_id(self):
        r"""Gets the entity_id of this ListDisasterRecoveryRecordRequest.

        实体id（容灾id）

        :return: The entity_id of this ListDisasterRecoveryRecordRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        r"""Sets the entity_id of this ListDisasterRecoveryRecordRequest.

        实体id（容灾id）

        :param entity_id: The entity_id of this ListDisasterRecoveryRecordRequest.
        :type entity_id: str
        """
        self._entity_id = entity_id

    @property
    def entity_type(self):
        r"""Gets the entity_type of this ListDisasterRecoveryRecordRequest.

        实体类型（容灾类型）

        :return: The entity_type of this ListDisasterRecoveryRecordRequest.
        :rtype: str
        """
        return self._entity_type

    @entity_type.setter
    def entity_type(self, entity_type):
        r"""Sets the entity_type of this ListDisasterRecoveryRecordRequest.

        实体类型（容灾类型）

        :param entity_type: The entity_type of this ListDisasterRecoveryRecordRequest.
        :type entity_type: str
        """
        self._entity_type = entity_type

    @property
    def limit(self):
        r"""Gets the limit of this ListDisasterRecoveryRecordRequest.

        查询记录数。默认为100，不能为负数，最小值为1，最大值为100。

        :return: The limit of this ListDisasterRecoveryRecordRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListDisasterRecoveryRecordRequest.

        查询记录数。默认为100，不能为负数，最小值为1，最大值为100。

        :param limit: The limit of this ListDisasterRecoveryRecordRequest.
        :type limit: int
        """
        self._limit = limit

    @property
    def offset(self):
        r"""Gets the offset of this ListDisasterRecoveryRecordRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :return: The offset of this ListDisasterRecoveryRecordRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListDisasterRecoveryRecordRequest.

        索引位置，偏移量。从第一条数据偏移offset条数据后开始查询，默认为0（偏移0条数据，表示从第一条数据开始查询），必须为数字，不能为负数。

        :param offset: The offset of this ListDisasterRecoveryRecordRequest.
        :type offset: int
        """
        self._offset = offset

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.openapi_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        if six.PY2:
            import sys
            reload(sys)
            sys.setdefaultencoding("utf-8")
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListDisasterRecoveryRecordRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
