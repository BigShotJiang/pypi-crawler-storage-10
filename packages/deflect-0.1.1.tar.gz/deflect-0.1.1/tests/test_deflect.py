import pytest
import httpx
from deflect import Deflect, DeflectError, DeflectOptions, AsyncDeflect, VerdictRequest

class MockTransport(httpx.BaseTransport):
    def __init__(self, responses):
        self._responses = responses
        self.calls = 0

    def handle_request(self, request):  # type: ignore
        idx = min(self.calls, len(self._responses) - 1)
        self.calls += 1
        fn = self._responses[idx]
        return fn(request)


def json_response(data, status=200):
    return httpx.Response(status, json=data)


def test_success():
    transport = MockTransport([
        lambda req: json_response({"success": True, "verdict": {"can_pass": True}})
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.get_verdict(VerdictRequest(token="tok"))
    assert data["success"] is True
    assert data["verdict"]["can_pass"] is True
    assert transport.calls == 1


def test_retry_network():
    class NetErrTransport(MockTransport):
        def handle_request(self, request):  # type: ignore
            current_call = self.calls
            self.calls += 1  # Increment call counter like base class does
            if current_call == 0:  # First call
                raise httpx.NetworkError("boom")
            return json_response({"success": True, "verdict": {"can_pass": False}})

    transport = NetErrTransport([
        lambda req: json_response({"success": True, "verdict": {"can_pass": False}})
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.get_verdict(VerdictRequest(token="tok"))
    assert data["verdict"]["can_pass"] is False
    assert transport.calls == 2


def test_retry_5xx():
    transport = MockTransport([
        lambda req: httpx.Response(502, json={"error": True}),
        lambda req: json_response({"success": True, "verdict": {"can_pass": True}})
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.get_verdict(VerdictRequest(token="tok"))
    assert data["verdict"]["can_pass"] is True
    assert transport.calls == 2


def test_no_retry_400():
    transport = MockTransport([
        lambda req: httpx.Response(400, json={"error": "bad"})
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    with pytest.raises(DeflectError):
        client.get_verdict(VerdictRequest(token="tok"))
    assert transport.calls == 1


def test_verdict_with_optional_fields():
    transport = MockTransport([
        lambda req: json_response({"success": True, "verdict": {"can_pass": True}})
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.get_verdict(VerdictRequest(
        token="tok",
        id="user123",
        email="test@example.com",
        phone_number="+14155552671"
    ))
    assert data["success"] is True
    assert data["verdict"]["can_pass"] is True
    assert transport.calls == 1


@pytest.mark.asyncio
async def test_async_success():
    class AsyncMockTransport(httpx.AsyncBaseTransport):
        def __init__(self, responses):
            self._responses = responses
            self.calls = 0
        async def handle_async_request(self, request):  # type: ignore
            idx = min(self.calls, len(self._responses) - 1)
            self.calls += 1
            fn = self._responses[idx]
            return fn(request)

    transport = AsyncMockTransport([
        lambda req: json_response({"success": True, "verdict": {"can_pass": True}})
    ])
    async_client = httpx.AsyncClient(transport=transport)
    client = AsyncDeflect(DeflectOptions(api_key="k", action_id="a", async_client=async_client))
    data = await client.get_verdict(VerdictRequest(token="tok"))
    assert data["verdict"]["can_pass"] is True
    assert transport.calls == 1


def test_email_intelligence_success():
    transport = MockTransport([
        lambda req: json_response({
            "success": True,
            "data": {
                "is_valid": True,
                "is_trusted": True,
                "trust_score": 85,
                "has_aliasing": False,
                "normalized_email": "test@example.com",
                "domain": "example.com"
            }
        })
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.email_intelligence("test@example.com")
    assert data["success"] is True
    assert data["data"]["is_valid"] is True
    assert data["data"]["trust_score"] == 85
    assert transport.calls == 1


def test_phone_intelligence_success():
    transport = MockTransport([
        lambda req: json_response({
            "success": True,
            "data": {
                "is_valid": True,
                "e164_format": "+14155552671",
                "country_code": "1",
                "country": "US",
                "country_name": "United States",
                "number_type": "mobile",
                "line_type": "wireless",
                "carrier": "Verizon",
                "carrier_type": "mobile",
                "risk_score": 10,
                "is_disposable": False,
                "is_virtual": False,
                "is_threat": False,
                "is_spam": False,
                "last_updated": "2023-11-07T05:31:56Z"
            }
        })
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.phone_intelligence("+14155552671")
    assert data["success"] is True
    assert data["data"]["is_valid"] is True
    assert data["data"]["country"] == "US"
    assert transport.calls == 1


def test_ip_intelligence_success():
    transport = MockTransport([
        lambda req: json_response({
            "success": True,
            "data": {
                "is_vpn": False,
                "is_datacenter_proxy": False,
                "is_residential_proxy": False,
                "is_bogon": False,
                "is_tor_node": False,
                "is_threat": False,
                "city": "San Francisco",
                "postal_code": "94105",
                "country": "US",
                "continent": "NA",
                "latitude": 37,
                "longitude": -122,
                "asn_number": 15169,
                "asn_organization": "Google LLC",
                "isp": "Google"
            }
        })
    ])
    client = Deflect(DeflectOptions(api_key="k", action_id="a", client=httpx.Client(transport=transport)))
    data = client.ip_intelligence("8.8.8.8")
    assert data["success"] is True
    assert data["data"]["is_vpn"] is False
    assert data["data"]["city"] == "San Francisco"
    assert transport.calls == 1


@pytest.mark.asyncio
async def test_async_email_intelligence_success():
    class AsyncMockTransport(httpx.AsyncBaseTransport):
        def __init__(self, responses):
            self._responses = responses
            self.calls = 0
        async def handle_async_request(self, request):  # type: ignore
            idx = min(self.calls, len(self._responses) - 1)
            self.calls += 1
            fn = self._responses[idx]
            return fn(request)

    transport = AsyncMockTransport([
        lambda req: json_response({
            "success": True,
            "data": {
                "is_valid": True,
                "is_trusted": True,
                "trust_score": 85,
                "has_aliasing": False,
                "normalized_email": "test@example.com",
                "domain": "example.com"
            }
        })
    ])
    async_client = httpx.AsyncClient(transport=transport)
    client = AsyncDeflect(DeflectOptions(api_key="k", action_id="a", async_client=async_client))
    data = await client.email_intelligence("test@example.com")
    assert data["success"] is True
    assert data["data"]["is_valid"] is True
    assert transport.calls == 1
