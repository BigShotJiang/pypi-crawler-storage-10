# PeakEvo

An application to acquire data from a spectrometer (supports OceanView hardware
via the seabreeze module) and track the position of a peak over time.

## Installation

> Note: for Windows users, see [seabreeze installation instructions](https://github.com/ap--/python-seabreeze#using-the-backend-pyseabreeze-in-windows)

### With uv (recommended)

1. Install uv (follow the [official installation instructions](https://docs.astral.sh/uv/getting-started/installation/))
2. Use uv to install the latest stable release of peakevo (*): 
   ```
   uv tool install -U peakevo
   ```
   
   > (*) **Tip:** to install the latest *development* version, replace the previous command by 
   > ```
   > uv tool install -U git+https://gitlab.com/c-p/peakevo.git@master
   > ``` 

### With pip
This is also a valid installation method, but you need to handle virtual environments manually:
1. Create a python virtual environment (e.g. with `conda`, or `pyhon -m venv` or ...) and activate it.
2. Run `pip install peakevo`


## Launching the GUI
Run: 
```
peakevo
```