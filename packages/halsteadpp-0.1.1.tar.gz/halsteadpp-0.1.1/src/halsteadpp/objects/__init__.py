from .function import Function

__all__ = ["Function"]
