from setuptools import setup

setup(name='luckytools',
      version='0.6',
      description='Print utility',
      packages=['luckytools'],
      author_email='sayginaego.say@gmail.com',
      zip_safe=False)

# pypi-AgEIcHlwaS5vcmcCJDgwYWE2OWU4LWIyYzctNDBmNi1iNzJhLTExZjVkMWY4YmNlYgACKlszLCI4YjlmZDQxYy0yNjVhLTQxODEtOTMyZS0xMGM0OThiZDhiMjciXQAABiAJbTTROHlD69PnzZ8Wya_S5S8PZivScP7QMG-FfmiXXg