#!/bin/bash
git push --tags