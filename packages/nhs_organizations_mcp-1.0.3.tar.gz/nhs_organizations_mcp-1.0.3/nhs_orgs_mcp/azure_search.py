"""Azure API Management service integration"""

import os
import logging
from typing import List, Optional
import httpx
from .models import PostcodeResult, Organization

logger = logging.getLogger(__name__)


class AzureSearchService:
    """Service for interacting with Azure API Management for NHS service search"""
    
    def __init__(self):
        # API Management endpoint
        self.endpoint = os.getenv(
            "API_MANAGEMENT_ENDPOINT", 
            "https://nhsuk-apim-int-uks.azure-api.net/service-search"
        )
        # Subscription key
        self.subscription_key = os.getenv("API_MANAGEMENT_SUBSCRIPTION_KEY", "")
        
        if not self.subscription_key:
            logger.warning("API_MANAGEMENT_SUBSCRIPTION_KEY not configured")
    
    @property
    def is_configured(self) -> bool:
        """Check if API Management is properly configured"""
        return bool(self.subscription_key)
    
    async def get_postcode_coordinates(self, postcode: str) -> Optional[PostcodeResult]:
        """Convert a UK postcode to latitude/longitude coordinates using API Management
        
        Args:
            postcode: UK postcode (e.g., 'SW1A 1AA')
            
        Returns:
            PostcodeResult with coordinates if found, None otherwise
        """
        if not self.is_configured:
            logger.error("API Management not configured")
            return None
        
        # Use query parameter instead of path parameter
        url = f"{self.endpoint}/postcodesandplaces/"
        params = {
            "search": postcode,
            "api-version": "2"
        }
        
        headers = {
            "subscription-key": self.subscription_key,
            "Content-Type": "application/json"
        }
        
        try:
            async with httpx.AsyncClient() as client:
                logger.info(f"Searching for postcode: {postcode}")
                response = await client.get(url, params=params, headers=headers, timeout=30.0)
                response.raise_for_status()
                
                data = response.json()
                logger.debug(f"Postcode search response: {data}")
                
                # Handle both direct object and array responses
                if isinstance(data, dict):
                    if "value" in data and isinstance(data["value"], list) and len(data["value"]) > 0:
                        # Response is wrapped in "value" array
                        result = data["value"][0]
                    elif "Latitude" in data and "Longitude" in data:
                        # Direct response object
                        result = data
                    else:
                        logger.warning(f"Unexpected response format: {data}")
                        return None
                else:
                    logger.warning(f"Unexpected response type: {type(data)}")
                    return None
                
                return PostcodeResult(
                    Latitude=result.get("Latitude"),
                    Longitude=result.get("Longitude"),
                    Postcode=postcode
                )
                
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error getting postcode coordinates: {e.response.status_code} - {e.response.text}")
            return None
        except Exception as e:
            logger.error(f"Error getting postcode coordinates: {str(e)}")
            return None
    
    async def search_organizations(
        self, 
        organization_type: str, 
        latitude: float, 
        longitude: float, 
        max_results: int = 10
    ) -> List[Organization]:
        """Search for NHS organizations near a location using API Management
        
        Args:
            organization_type: Type of organization (e.g., 'PHA', 'GPP', 'HOS')
            latitude: Latitude coordinate
            longitude: Longitude coordinate
            max_results: Maximum number of results to return
            
        Returns:
            List of Organization objects
        """
        if not self.is_configured:
            logger.error("API Management not configured")
            return []
        
        url = f"{self.endpoint}/search"
        params = {"api-version": "2"}
        
        # Create search body with geo filter
        search_body = {
            "search": "*",
            "filter": f"OrganizationTypeID eq '{organization_type}'",
            "orderby": f"geo.distance(Geocode, geography'POINT({longitude} {latitude})')",
            "top": max_results,
            "count": True
        }
        
        headers = {
            "subscription-key": self.subscription_key,
            "Content-Type": "application/json"
        }
        
        try:
            async with httpx.AsyncClient() as client:
                logger.info(f"Searching for {organization_type} near ({latitude}, {longitude})")
                response = await client.post(
                    url,
                    params=params,
                    json=search_body,
                    headers=headers,
                    timeout=30.0
                )
                response.raise_for_status()
                
                data = response.json()
                logger.debug(f"Organization search response: {data}")
                
                # Handle both direct array and wrapped responses
                if isinstance(data, dict) and "value" in data:
                    results = data["value"]
                elif isinstance(data, list):
                    results = data
                else:
                    logger.warning(f"Unexpected response format: {data}")
                    return []
                
                organizations = []
                for item in results:
                    geocode = item.get("Geocode", {})
                    
                    # Calculate distance
                    distance = self._calculate_distance(
                        latitude, longitude,
                        geocode.get("Latitude", 0),
                        geocode.get("Longitude", 0)
                    )
                    
                    org = Organization(
                        OrganizationName=item.get("OrganizationName"),
                        OrganizationTypeID=item.get("OrganizationTypeID"),
                        ODSCode=item.get("ODSCode"),
                        Address=item.get("Address1", ""),
                        Postcode=item.get("Postcode"),
                        Distance=distance,
                        Geocode=PostcodeResult(
                            Latitude=geocode.get("Latitude"),
                            Longitude=geocode.get("Longitude"),
                            Postcode=None
                        ) if geocode else None
                    )
                    organizations.append(org)
                
                return organizations
                
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error searching organizations: {e.response.status_code} - {e.response.text}")
            return []
        except Exception as e:
            logger.error(f"Error searching organizations: {str(e)}")
            return []
    
    def _calculate_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two points in miles using Haversine formula"""
        from math import radians, sin, cos, sqrt, atan2
        
        R = 3959  # Earth's radius in miles
        
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return R * c

    async def get_health_topic(self, topic_slug: str) -> Optional[dict]:
        """Get health condition/topic information from NHS API
        
        Args:
            topic_slug: The URL slug for the condition (e.g., 'asthma', 'diabetes', 'flu')
            
        Returns:
            Dictionary with health topic information including name, description, and content
        """
        if not self.is_configured:
            logger.error("API Management not configured")
            return None
        
        # Conditions API endpoint (different from service-search)
        url = f"https://nhsuk-apim-int-uks.azure-api.net/conditions/{topic_slug}"
        
        headers = {
            "subscription-key": self.subscription_key
        }
        
        try:
            async with httpx.AsyncClient() as client:
                logger.info(f"Fetching health topic: {topic_slug}")
                response = await client.get(url, headers=headers, timeout=30.0)
                response.raise_for_status()
                
                data = response.json()
                logger.debug(f"Health topic response: {data.get('name', 'Unknown')}")
                
                # Extract relevant information
                result = {
                    "name": data.get("name"),
                    "description": data.get("description"),
                    "url": data.get("url"),
                    "dateModified": data.get("dateModified"),
                    "lastReviewed": data.get("lastReviewed", [None, None]),
                    "genre": data.get("genre", []),
                }
                
                # Extract main content sections if available
                if "mainEntityOfPage" in data:
                    main_content = data["mainEntityOfPage"]
                    if isinstance(main_content, list):
                        result["sections"] = []
                        for section in main_content:
                            if isinstance(section, dict):
                                result["sections"].append({
                                    "headline": section.get("headline"),
                                    "text": section.get("text"),
                                    "description": section.get("description")
                                })
                
                return result
                
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning(f"Health topic not found: {topic_slug}")
                return None
            logger.error(f"HTTP error fetching health topic: {e.response.status_code} - {e.response.text}")
            return None
        except Exception as e:
            logger.error(f"Error fetching health topic: {str(e)}")
            return None
