# jax2onnx/plugins/jax/nn/initializers/__init__.py

"""IR-only nn initializer lowerings."""
