# jax2onnx/plugins/equinox/eqx/nn/__init__.py

"""Equinox nn primitives."""
