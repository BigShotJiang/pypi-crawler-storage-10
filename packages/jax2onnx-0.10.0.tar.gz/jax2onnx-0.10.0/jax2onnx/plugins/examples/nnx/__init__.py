# jax2onnx/plugins/examples/nnx/__init__.py
