.. _examples:

Examples
============

Here is a list of example notebooks to illustrate how to use the various earthkit components together.

.. toctree::
    :maxdepth: 1
    :glob:

    examples/*
