"""Models for Archer applications and field definitions."""

from typing import List, Optional, Dict, Any
from enum import IntEnum
from pydantic import BaseModel, Field


class FieldTypeEnum(IntEnum):
    """Field types in Archer."""
    TEXT = 1
    NUMERIC = 2
    DATE = 3
    VALUES_LIST = 4
    EXTERNAL_LINKS = 7
    PERMISSIONS = 8
    CROSS_REFERENCE = 9
    ATTACHMENT = 11
    IMAGE = 12
    MATRIX = 16
    IP_ADDRESS = 19
    RELATED_RECORDS = 23
    SUB_FORM = 24


class FieldDefinition(BaseModel):
    """Represents a field definition in an Archer application."""
    
    Id: int = Field(..., description="Field ID")
    Name: str = Field(..., description="Field name")
    Type: int = Field(..., description="Field type")
    LevelId: int = Field(..., description="Application/Level ID")
    IsRequired: Optional[bool] = Field(None, description="Whether field is required")
    
    @property
    def type_name(self) -> str:
        """Get human-readable field type name."""
        try:
            return FieldTypeEnum(self.Type).name
        except ValueError:
            return f"Unknown({self.Type})"
    
    class Config:
        json_schema_extra = {
            "example": {
                "Id": 1001,
                "Name": "Title",
                "Type": 1,
                "LevelId": 75,
                "IsRequired": True
            }
        }


class Application(BaseModel):
    """Represents an Archer application."""
    
    Id: int = Field(..., description="Application ID")
    Name: str = Field(..., description="Application name")
    Alias: Optional[str] = Field(None, description="Application alias")
    Type: Optional[int] = Field(None, description="Application type")
    LanguageId: Optional[int] = Field(None)
    
    # Additional metadata
    fields: Optional[List[FieldDefinition]] = Field(None, description="Application fields")
    
    def get_field_by_name(self, field_name: str) -> Optional[FieldDefinition]:
        """
        Get field definition by name.
        
        Args:
            field_name: Name of the field
            
        Returns:
            FieldDefinition if found, None otherwise
        """
        if not self.fields:
            return None
        
        return next((f for f in self.fields if f.Name == field_name), None)
    
    def get_field_by_id(self, field_id: int) -> Optional[FieldDefinition]:
        """
        Get field definition by ID.
        
        Args:
            field_id: ID of the field
            
        Returns:
            FieldDefinition if found, None otherwise
        """
        if not self.fields:
            return None
        
        return next((f for f in self.fields if f.Id == field_id), None)