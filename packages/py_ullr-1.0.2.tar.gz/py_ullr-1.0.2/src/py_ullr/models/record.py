from typing import Dict, List, Optional, Any, Union
from enum import IntEnum
from pydantic import BaseModel, Field, validator


class FieldType(IntEnum):
    """Archer field types based on API documentation."""
    TEXT = 1  # Text - Single Line, Text Area - HTML
    NUMERIC = 2
    DATE = 3  # Date Only, Date and Time
    VALUES_LIST = 4
    EXTERNAL_LINKS = 7
    PERMISSIONS = 8  # Record Permissions, User/Groups List
    CROSS_REFERENCE = 9
    ATTACHMENT = 11
    IMAGE = 12
    MATRIX = 16
    IP_ADDRESS = 19
    RELATED_RECORDS = 23
    SUB_FORM = 24


class FieldContent(BaseModel):
    """Represents a single field's content in an Archer record."""
    
    Type: int = Field(..., description="Field type ID from FieldType enum")
    Value: Union[str, int, float, List, Dict, None] = Field(..., description="Field value")
    FieldId: Optional[int] = Field(None, description="Field ID")
    
    class Config:
        use_enum_values = True
    
    @validator('Type')
    def validate_type(cls, v):
        """Ensure Type is a valid FieldType."""
        valid_types = [ft.value for ft in FieldType]
        if v not in valid_types:
            raise ValueError(f"Invalid field type: {v}. Must be one of {valid_types}")
        return v


class RecordContent(BaseModel):
    """Represents the content structure of an Archer record."""
    
    Id: Optional[int] = Field(None, description="Content/Record ID")
    LevelId: int = Field(..., description="Application ID")
    FieldContents: Dict[str, FieldContent] = Field(
        default_factory=dict,
        description="Dictionary of field contents keyed by field ID or name"
    )
    Version: Optional[str] = Field(None, description="Record version for optimistic locking")
    
    class Config:
        json_schema_extra = {
            "example": {
                "Id": 123456,
                "LevelId": 75,
                "FieldContents": {
                    "Title": {
                        "Type": 1,
                        "Value": "Test Record",
                        "FieldId": 1001
                    },
                    "Status": {
                        "Type": 4,
                        "Value": {"ValuesListIds": [2405]},
                        "FieldId": 1002
                    }
                }
            }
        }


class RecordCreateRequest(BaseModel):
    """Request model for creating a new record."""
    
    Content: RecordContent
    SubformFieldId: Optional[int] = Field(None, description="Required when saving subform content")
    
    @classmethod
    def from_fields(
        cls,
        application_id: int,
        field_values: Dict[str, Any],
        subform_field_id: Optional[int] = None
    ) -> "RecordCreateRequest":
        """
        Convenient factory method to create a request from simple field values.
        
        Args:
            application_id: The application ID
            field_values: Dictionary mapping field names to values
            subform_field_id: Optional subform field ID
            
        Returns:
            RecordCreateRequest instance
            
        Example:
            >>> request = RecordCreateRequest.from_fields(
            ...     application_id=75,
            ...     field_values={
            ...         "Title": "New Record",
            ...         "Priority": 1,
            ...         "Status": "Open"
            ...     }
            ... )
        """
        field_contents = {}
        for field_name, value in field_values.items():
            # Infer field type from value
            if isinstance(value, str):
                field_type = FieldType.TEXT
            elif isinstance(value, (int, float)):
                field_type = FieldType.NUMERIC
            elif isinstance(value, list):
                field_type = FieldType.VALUES_LIST
            else:
                field_type = FieldType.TEXT
            
            field_contents[field_name] = FieldContent(
                Type=field_type,
                Value=value
            )
        
        content = RecordContent(
            LevelId=application_id,
            FieldContents=field_contents
        )
        
        return cls(Content=content, SubformFieldId=subform_field_id)


class RecordUpdateRequest(BaseModel):
    """Request model for updating an existing record."""
    
    Content: RecordContent
    SubformFieldId: Optional[int] = Field(None, description="Required when saving subform content")
    
    @validator('Content')
    def validate_content_has_id(cls, v):
        """Ensure Content has an Id for updates."""
        if v.Id is None:
            raise ValueError("Content.Id is required for update operations")
        return v


class RecordResponse(BaseModel):
    """Response model from record operations."""
    
    Links: List[Any] = Field(default_factory=list)
    RequestedObject: Dict[str, Any] = Field(default_factory=dict)
    IsSuccessful: bool
    ValidationMessages: List[str] = Field(default_factory=list)
    
    @property
    def record_id(self) -> Optional[int]:
        """Extract the record ID from the response."""
        return self.RequestedObject.get("Id")
    
    @property
    def has_errors(self) -> bool:
        """Check if the response contains errors."""
        return not self.IsSuccessful or len(self.ValidationMessages) > 0
