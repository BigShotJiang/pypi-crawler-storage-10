"""Application operations for Archer REST API with model support."""

import logging
from typing import List, Dict, Any, Union

from ..models import Application, FieldDefinition
from .base import BaseAPI


logger = logging.getLogger(__name__)


class ApplicationsAPI(BaseAPI):
    """API client for Archer application operations."""
    
    def get_all(self, as_model: bool = False) -> Union[List[Dict[str, Any]], List[Application]]:
        """
        Get all applications.
        
        Args:
            as_model: If True, return as list of Application models
            
        Returns:
            List of applications as dicts or Application models
            
        Example:
            >>> # As dictionaries
            >>> apps = client.rest.applications.get_all()
            >>> 
            >>> # As models with validation and helper methods
            >>> apps = client.rest.applications.get_all(as_model=True)
            >>> for app in apps:
            ...     print(f"{app.Name} (ID: {app.Id})")
        """
        url = f"{self.base_url}/api/core/system/application"
        response = self._make_request("GET", url)
        data = response.json()
        
        if as_model:
            return [Application(**app) for app in data]
        return data
    
    def get(
        self,
        application_id: int,
        as_model: bool = False,
        include_fields: bool = False
    ) -> Union[Dict[str, Any], Application]:
        """
        Get a specific application.
        
        Args:
            application_id: Application ID
            as_model: If True, return as Application model
            include_fields: If True and as_model=True, fetch and include field definitions
            
        Returns:
            Application data as dict or Application model
            
        Example:
            >>> # Get with fields included
            >>> app = client.rest.applications.get(
            ...     application_id=75,
            ...     as_model=True,
            ...     include_fields=True
            ... )
            >>> 
            >>> # Use helper methods
            >>> title_field = app.get_field_by_name("Title")
            >>> print(f"Title field ID: {title_field.Id}")
            >>> print(f"Title field type: {title_field.type_name}")
        """
        url = f"{self.base_url}/api/core/system/application/{application_id}"
        response = self._make_request("GET", url)
        data = response.json()
        
        if as_model:
            app = Application(**data)
            
            # Optionally fetch and attach field definitions
            if include_fields:
                fields_data = self.get_fields(application_id)
                app.fields = [FieldDefinition(**f) for f in fields_data]
            
            return app
        
        return data
    
    def get_fields(
        self,
        application_id: int,
        as_model: bool = False
    ) -> Union[List[Dict[str, Any]], List[FieldDefinition]]:
        """
        Get fields for an application.
        
        Args:
            application_id: Application ID
            as_model: If True, return as list of FieldDefinition models
            
        Returns:
            List of field definitions
            
        Example:
            >>> fields = client.rest.applications.get_fields(75, as_model=True)
            >>> for field in fields:
            ...     print(f"{field.Name}: {field.type_name}")
        """
        url = f"{self.base_url}/api/core/system/fielddefinition/application/{application_id}"
        response = self._make_request("GET", url)
        data = response.json()
        
        if as_model:
            return [FieldDefinition(**f) for f in data]
        return data
