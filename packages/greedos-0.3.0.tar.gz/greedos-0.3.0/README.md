
   
  
   ~ GreeDoS a Cybersecurity Red Team tool based on DDoS ~
  
## Description

- **Advanced Cybersecurity Red Team Tool**
- **Test Network Resilience:** Simulate multi-vector DDoS attacks to evaluate how well network defenses hold up under stress as penetration testing purpose.
- **Validate Security Controls:** Assess the effectiveness of firewalls, intrusion prevention systems (IPS), and DDoS mitigation solutions in real-world scenarios.
- **Conduct Red Team Exercises:** Use the tool during authorized penetration tests to mimic attacker behavior and identify weaknesses in infrastructure.
- **Improve Incident Response:** Train SOC teams to detect, analyze, and respond to DDoS attacks by running controlled attack simulations.
- **Optimize Network Performance:** Identify bottlenecks and failure points under high traffic loads, enabling proactive network tuning.
- **Automated Testing:** Cybersecurity professionals can automate DDoS simulation tests within security testing suites, improving red teaming efficiency.
- **Rapid Deployment:** Network engineers can deploy the tool across environments for stress testing network resilience without complex setup.

  📫 How to reach me: **http://mrechofi.github.io/Tanjib_portfolio_website/** & **tanjibisham777@gmail.com & tanjibisham888@gmail.com**


# Installation Process via 'git' :
    git clone https://github.com/MrEchoFi/GreeDoS_V2.git

    cd GreeDoS_V2

    // install external libraries, 

    pip install requests scapy rich

    or,

    pip install -r requirements.txt

    // If you want to ensure everything is up-to-date, you can use:

     pip install --upgrade requests scapy rich

    // then run the tool,
   
    python3 GreeDoS_ii.py

Note: Install Npcap externally.

# Install Tcpreplay for high-speed packet replay:
   sudo apt install tcpreplay
   

# Recommendations:
   
        - you can run this tool in Ubuntu, kali linux, WSL, Debian & Arch, Parrot OS.
        - Use good level of router & ethernet cable.
        - If u want to run this tool aggressively for testing or lab based attacks with more time & thread then use high CPU, GPU and RAM based device.
  
