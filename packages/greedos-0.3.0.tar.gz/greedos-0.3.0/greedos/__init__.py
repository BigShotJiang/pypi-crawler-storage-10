"""greedos package initializer

This file existed previously as `_init_.py` (incorrect name). Python requires
`__init__.py` for the package to be recognized when installed/imported.

Keep this file minimal to avoid side effects. Package-level metadata can be
added here if needed later.
"""

__all__ = ["GreeDoS_ii"]

__version__ = "0.2.0"
