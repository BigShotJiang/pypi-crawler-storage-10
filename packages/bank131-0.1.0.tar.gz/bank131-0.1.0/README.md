# Bank131 Python SDK

Официальный Python SDK для работы с API [Bank131](https://developer.131.ru/).

## Установка
```bash
pip install bank131-python-sdk.zip
```

## Использование
```python
from bank131 import Bank131Client

client = Bank131Client(
    project_id="your_project_id",
    private_key_path="private.pem",
    base_url="https://demo.bank131.ru/api/v1"
)

session = client.create_session(1000, "RUB", "Test payment")
print(session)
```
