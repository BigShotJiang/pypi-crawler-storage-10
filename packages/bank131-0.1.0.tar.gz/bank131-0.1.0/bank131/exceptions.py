class Bank131Error(Exception):
    """Базовое исключение SDK"""
    pass
