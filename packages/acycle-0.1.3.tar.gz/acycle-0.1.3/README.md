# Calculator Demo

A simple calculator package for PyPI demonstration purposes.

## Features

- Basic arithmetic operations (add, subtract, multiply, divide)
- Advanced mathematical functions (power, square root, factorial, logarithm)
- Calculation history tracking
- Easy-to-use API

## Installation

```bash
pip install calculator-demo