# Codex Usage Monitor

Monitor your Codex CLI token usage in real-time.

## Features

- 📊 5-hour and weekly usage tracking
- 🔥 Recent session activity
- 🔮 Usage predictions
- 🔄 Automatic token refresh
- 🎨 Color-coded progress bars

## Installation

### From PyPI (when published)

```bash
pip install codex-usage-monitor
```

### From source

```bash
git clone https://github.com/Coldsewoo/codex-usage-monitor
cd codex-usage-monitor
pip install .
```

### Development mode

```bash
pip install -e .
```

## Usage

After installation, run:

```bash
codex-monitor
# or
cmon
# or
python -m codex_monitor
```

The monitor will:
1. Read your token from `~/.codex/auth.json`
2. Display current usage for 5-hour and weekly windows
3. Show recent sessions with token counts
4. Auto-refresh every 30 seconds

Press `Ctrl+C` to exit.

## Requirements

- Python 3.9+
- Codex CLI (logged in)
- `requests` library (auto-installed)

## Building from Source

### Build the package

```bash
# Install build tools
pip install build

# Build distribution packages
python -m build
```

This creates:
- `dist/codex_usage_monitor-1.0.0-py3-none-any.whl`
- `dist/codex-usage-monitor-1.0.0.tar.gz`

### Install from wheel

```bash
pip install dist/codex_usage_monitor-1.0.0-py3-none-any.whl
```

### Using uvx (no installation)

```bash
# Run directly without installing
uvx --from . codex-monitor

# Or from wheel
uvx --from dist/codex_usage_monitor-1.0.0-py3-none-any.whl codex-monitor
```

## Publishing to PyPI

```bash
# Install twine
pip install twine

# Check distribution
twine check dist/*

# Upload to PyPI
twine upload dist/*
```

## Troubleshooting

**"Codex auth file not found"**
- Login to Codex CLI first: `codex`

**"Token refresh failed"**
- Re-login to Codex CLI: `codex`

**"Module 'requests' not found"**
- Install: `pip install requests`

**Build errors**
- Clean: `rm -rf build/ dist/ *.egg-info`
- Update tools: `pip install --upgrade build setuptools wheel`

## License

MIT
