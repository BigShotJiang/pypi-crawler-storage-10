"""Main CLI entry point for Codex Usage Monitor."""

import os
import sys
import time
from datetime import datetime

import requests

from codex_monitor.core.api import CodexUsageAPI
from codex_monitor.core.auth import CodexTokenExtractor
from codex_monitor.core.sessions import SessionAnalyzer
from codex_monitor.ui.display import display_usage


def main():
    """Main entry point."""

    print("\n🚀 Codex Usage Monitor (Enhanced)")
    print("─" * 60)

    try:
        # Initialize components
        print("🔑 Reading token from ~/.codex/auth.json...")
        token_extractor = CodexTokenExtractor()
        api = CodexUsageAPI(token_extractor)
        analyzer = SessionAnalyzer()

        print("✓ Token loaded")
        print("📊 Fetching usage data...")

        # Main loop
        while True:
            try:
                # Fetch current usage
                data = api.get_usage()

                # Clear screen
                os.system("clear" if os.name == "posix" else "cls")

                # Display enhanced view
                display_usage(data, analyzer)

                # Footer
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                print(f"Last updated: {now}")
                print("💡 Press Ctrl+C to exit")

                # Wait 30 seconds
                time.sleep(30)

            except requests.exceptions.HTTPError as e:
                print(f"\n❌ API Error: {e}")
                print("Retrying in 30 seconds...")
                time.sleep(30)

            except KeyboardInterrupt:
                print("\n\n👋 Monitoring stopped")
                return 0

    except Exception as e:
        print(f"\n❌ Error: {e}")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
