from inspect import signature
from pprint import pprint, pformat
from deepdiff import DeepDiff
from robot.api import logger
from robot.api.deco import keyword, library
import fitz
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple
from DocTest.config import DEFAULT_DPI
from DocTest.DocumentRepresentation import DocumentRepresentation
from DocTest.Downloader import is_url, download_file_from_url
from DocTest.PdfStructureComparator import StructureTolerance, compare_document_structures
from DocTest.PdfStructureModels import StructureExtractionConfig
from DocTest.llm import LLMDependencyError, load_llm_settings

if TYPE_CHECKING:  # pragma: no cover - typing only
    from DocTest.llm.types import LLMDecision, LLMDecisionLabel
else:  # pragma: no cover - runtime fallback
    LLMDecision = Any  # type: ignore[misc, assignment]
    LLMDecisionLabel = Any  # type: ignore[misc, assignment]


_PDF_LLM_RUNTIME: Optional[Tuple[Any, Any, Any]] = None


def _coerce_label_value(label: Any) -> str:
    value = getattr(label, "value", label)
    return str(value)


def _decision_equals_flag(label: Any, enum_cls: Any) -> bool:
    candidate = _coerce_label_value(label).lower()
    if enum_cls is None:
        return candidate == "flag"
    flag_member = getattr(enum_cls, "FLAG", None)
    if flag_member is None:
        return candidate == "flag"
    flag_value = _coerce_label_value(flag_member).lower()
    return candidate == flag_value


def _load_pdf_llm_runtime() -> Tuple[Any, Any, Any]:
    global _PDF_LLM_RUNTIME
    if _PDF_LLM_RUNTIME is not None:
        return _PDF_LLM_RUNTIME
    try:
        from DocTest.llm.client import assess_pdf_diff, create_binary_content
        from DocTest.llm.types import LLMDecisionLabel as _LLMDecisionLabel
    except Exception as exc:  # pragma: no cover - optional dependency missing
        raise LLMDependencyError() from exc
    _PDF_LLM_RUNTIME = (assess_pdf_diff, create_binary_content, _LLMDecisionLabel)
    return _PDF_LLM_RUNTIME


def _as_bool(value, default=False):
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in ("true", "1", "yes", "on"):
            return True
        if lowered in ("false", "0", "no", "off"):
            return False
    return bool(value)


def _as_float(value, default):
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int_or_none(value):
    if value is None:
        return None
    if isinstance(value, str) and value.strip().lower() == "none":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None

ROBOT_AUTO_KEYWORDS = False

class PdfTest(object):
    
    
    def __init__(self, **kwargs):
        fitz.TOOLS.set_aa_level(0)
        pass
    
    @keyword
    def compare_pdf_documents(self, reference_document, candidate_document, **kwargs):
        """Compare two PDF documents by metadata, content, and optionally layout.

        ``reference_document`` and ``candidate_document`` may be file paths or URLs.
        Use the ``compare`` argument (comma or ``|`` separated) to select which facets to
        validate. Supported values:

            - ``all`` (default)
            - ``metadata``
            - ``text``
            - ``fonts``
            - ``images``
            - ``signatures``
            - ``structure`` (layout + line/geometry comparison that ignores font subset differences)

        When ``structure`` is requested the following optional kwargs control behaviour:

            - ``structure_position_tolerance`` (float, default ``15.0``) – max positional delta in points
            - ``structure_size_tolerance`` (float, default equals position tolerance) – max width/height delta in points
            - ``structure_relative_tolerance`` (float, default ``0.05``) – fallback percentage tolerance
            - ``structure_case_sensitive`` (bool, default ``True``) – toggle case-sensitive text matching
            - ``structure_strip_font_subset`` (bool, default ``True``) – drop font subset prefixes
            - ``structure_collapse_whitespace`` (bool, default ``True``)
            - ``structure_strip_line_edges`` (bool, default ``True``)
            - ``structure_drop_empty_lines`` (bool, default ``True``)
            - ``structure_whitespace_replacement`` (str, default single space)
            - ``structure_round_precision`` (int or ``None``, default ``3``) – rounding precision for coordinates
            - ``structure_dpi`` (int, default: library DPI) – DPI used when rasterising PDFs prior to structure extraction

        Optional LLM integration parameters:

        | =Arguments= | =Description= |
        | ``llm`` / ``llm_enabled`` | When ``${True}``, forward detected differences to the configured LLM. Default ``${False}``. |
        | ``llm_override`` | Allow an approving LLM verdict to override baseline comparison failures. Default ``${False}``. |
        | ``llm_prompt`` / ``llm_pdf_prompt`` | Custom prompt for this comparison. Default ``None`` uses the built-in prompt. |

        Result passes only if every requested facet matches.

        Examples:
        | `Compare Pdf Documents`    reference.pdf    candidate.pdf
        | `Compare Pdf Documents`    reference.pdf    candidate.pdf    compare=text
        | `Compare Pdf Documents`    reference.pdf    candidate.pdf    compare=structure
        | `Compare Pdf Documents`    reference.pdf    candidate.pdf    compare=structure|metadata    structure_position_tolerance=5.0
        | `Compare Pdf Documents`    reference.pdf    candidate.pdf    llm=${True}    llm_prompt=Summarise differences using JSON

        """
        llm_requested = bool(
            kwargs.pop("llm", False)
            or kwargs.pop("llm_enabled", False)
            or kwargs.pop("use_llm", False)
        )
        llm_override_result = bool(kwargs.pop("llm_override", False))
        llm_overrides: Dict[str, Optional[str]] = {}
        llm_general_notes: List[str] = []
        llm_differences: List[Dict[str, Any]] = []
        custom_llm_prompt = kwargs.pop("llm_prompt", None)
        pdf_prompt_override = kwargs.pop("llm_pdf_prompt", None)
        if pdf_prompt_override:
            custom_llm_prompt = pdf_prompt_override
        llm_keys = [
            "llm_provider",
            "llm_models",
            "llm_api_key",
            "llm_base_url",
            "llm_temperature",
            "llm_max_output_tokens",
            "llm_request_timeout",
            "azure_openai_endpoint",
            "azure_openai_deployment",
            "azure_openai_api_version",
            "azure_openai_api_key",
        ]
        for key in llm_keys:
            if key in kwargs:
                value = kwargs.pop(key)
                if value is not None:
                    llm_overrides[key] = value

        mask = kwargs.pop('mask', None)
        check_pdf_text = _as_bool(kwargs.pop('check_pdf_text', False))
        llm_general_notes.append(f"check_pdf_text={check_pdf_text}")

        compare_value = kwargs.pop('compare', "all")
        compare_value = compare_value.replace('|', ',')
        compare_tokens = [token.strip().lower() for token in compare_value.split(',') if token.strip()]
        if not compare_tokens:
            compare_tokens = ['all']
        compare_set = set(compare_tokens)
        llm_general_notes.append(f"Compare facets: {sorted(compare_set)}")

        structure_position_tolerance = _as_float(kwargs.pop('structure_position_tolerance', 15.0), 15.0)
        structure_size_tolerance = _as_float(kwargs.pop('structure_size_tolerance', structure_position_tolerance), structure_position_tolerance)
        structure_relative_tolerance = _as_float(kwargs.pop('structure_relative_tolerance', 0.05), 0.05)
        structure_case_sensitive = _as_bool(kwargs.pop('structure_case_sensitive', True), True)
        structure_strip_font_subset = _as_bool(kwargs.pop('structure_strip_font_subset', True), True)
        structure_collapse_whitespace = _as_bool(kwargs.pop('structure_collapse_whitespace', True), True)
        structure_strip_line_edges = _as_bool(kwargs.pop('structure_strip_line_edges', True), True)
        structure_drop_empty_lines = _as_bool(kwargs.pop('structure_drop_empty_lines', True), True)
        structure_whitespace_replacement = kwargs.pop('structure_whitespace_replacement', " ")
        structure_round_precision = _as_int_or_none(kwargs.pop('structure_round_precision', 3))
        structure_dpi = _as_int_or_none(kwargs.pop('structure_dpi', None))
        if structure_dpi is None:
            structure_dpi = _as_int_or_none(kwargs.get('dpi'))
        if structure_dpi is None:
            structure_dpi = DEFAULT_DPI
        structure_requested = 'structure' in compare_set
        if structure_requested:
            llm_general_notes.append(
                f"structure_tolerance(position={structure_position_tolerance}, size={structure_size_tolerance}, relative={structure_relative_tolerance})"
            )

        extraction_config = StructureExtractionConfig(
            collapse_whitespace=structure_collapse_whitespace,
            strip_font_subset=structure_strip_font_subset,
            whitespace_replacement=str(structure_whitespace_replacement),
            strip_line_edges=structure_strip_line_edges,
            drop_empty_lines=structure_drop_empty_lines,
            round_precision=structure_round_precision,
        )


        reference_document = self._ensure_local_document(reference_document)
        candidate_document = self._ensure_local_document(candidate_document)
        ref_doc = fitz.open(reference_document)
        cand_doc = fitz.open(candidate_document)
        reference = {}
        reference['pages'] = []
        reference['metadata']=ref_doc.metadata
        reference['page_count']=ref_doc.page_count
        reference['sigflags']=ref_doc.get_sigflags()
        for i, page in enumerate(ref_doc.pages()):
            signature_list = []
            text = [x for x in page.get_text("text").splitlines() if not is_masked(x, mask)]
            for widget in page.widgets():
                if widget.is_signed:
                    signature_list.append(list((widget.field_name, widget.field_label, widget.field_value)))
            reference['pages'].append(dict([('number',i+1), ('fonts', page.get_fonts()), ('images', page.get_images()), ('rotation', page.rotation), ('mediabox', page.mediabox), ('signatures', signature_list),('text', text)]))


        candidate = {}
        candidate['pages'] = []
        candidate['metadata']=cand_doc.metadata
        candidate['page_count']=cand_doc.page_count
        candidate['sigflags']=cand_doc.get_sigflags()
        for i, page in enumerate(cand_doc.pages()):
            signature_list = []
            text = [x for x in page.get_text("text").splitlines() if not is_masked(x, mask)]
            for widget in page.widgets():
                if widget.is_signed:
                    signature_list.append(list((widget.field_name, widget.field_label, widget.field_value)))
            candidate['pages'].append(dict([('number',i+1), ('fonts', page.get_fonts()), ('images', page.get_images()), ('rotation', page.rotation), ('mediabox', page.mediabox), ('signatures', signature_list),('text', text)]))

        differences_detected=False

        if 'metadata' in compare_set or 'all' in compare_set:
            diff = DeepDiff(reference['metadata'], candidate['metadata'])
            if diff != {}:
                differences_detected=True
                print("Different metadata")
                pprint(diff, width=200)
                llm_differences.append(
                    {
                        "facet": "metadata",
                        "description": "Metadata differs between reference and candidate.",
                        "details": pformat(diff, width=200),
                    }
                )
        if 'signatures' in compare_set or 'all' in compare_set:
            diff = DeepDiff(reference['sigflags'], candidate['sigflags'])
            if diff != {}:
                differences_detected=True
                print("Different signature")
                pprint(diff, width=200)
                llm_differences.append(
                    {
                        "facet": "signatures",
                        "description": "PDF signature flags differ.",
                        "details": pformat(diff, width=200),
                    }
                )
        for ref_page, cand_page in zip(reference['pages'], candidate['pages']):
            diff = DeepDiff(ref_page['rotation'], cand_page['rotation'])
            if diff != {}:
                differences_detected=True
                print("Different rotation")
                pprint(diff, width=200)
                llm_differences.append(
                    {
                        "facet": "rotation",
                        "description": f"Page {ref_page['number']} rotation differs.",
                        "details": pformat(diff, width=200),
                    }
                )
            # diff = DeepDiff(ref_page['mediabox'], cand_page['mediabox'])
            # if diff != {}:
            #     differences_detected=True
            #     print("Different mediabox")
            #     pprint(diff, width=200)
            if 'text' in compare_set or 'all' in compare_set:
                diff = DeepDiff(ref_page['text'], cand_page['text'])
                if diff != {}:
                    differences_detected=True
                    print("Different text")
                    pprint(diff, width=200)
                    llm_differences.append(
                        {
                            "facet": "text",
                            "description": f"Page {ref_page['number']} text content differs.",
                            "details": pformat(diff, width=200),
                        }
                    )
            if 'fonts' in compare_set or 'all' in compare_set:
                diff = DeepDiff(ref_page['fonts'], cand_page['fonts'])
                if diff != {}:
                    differences_detected=True
                    print("Different fonts")
                    pprint(diff, width=200)
                    llm_differences.append(
                        {
                            "facet": "fonts",
                            "description": f"Page {ref_page['number']} font usage differs.",
                            "details": pformat(diff, width=200),
                        }
                    )
            if 'images' in compare_set or 'all' in compare_set:
                diff = DeepDiff(ref_page['images'], cand_page['images'])
                if diff != {}:
                    differences_detected=True
                    print("Different images")
                    pprint(diff, width=200)
                    llm_differences.append(
                        {
                            "facet": "images",
                            "description": f"Page {ref_page['number']} embedded images differ.",
                            "details": pformat(diff, width=200),
                        }
                    )
            if 'signatures' in compare_set or 'all' in compare_set:
                diff = DeepDiff(ref_page['signatures'], cand_page['signatures'])
                if diff != {}:
                    differences_detected=True
                    print("Different signatures")
                    pprint(diff, width=200)
                    llm_differences.append(
                        {
                            "facet": "signatures",
                            "description": f"Page {ref_page['number']} form signatures differ.",
                            "details": pformat(diff, width=200),
                        }
                    )

        if structure_requested:
            tolerance = StructureTolerance(
                position=structure_position_tolerance,
                size=structure_size_tolerance,
                relative=structure_relative_tolerance,
            )
            structure_result = self._perform_structure_comparison(
                reference_document=reference_document,
                candidate_document=candidate_document,
                tolerance=tolerance,
                extraction_config=extraction_config,
                case_sensitive=structure_case_sensitive,
                dpi=structure_dpi,
            )
            if not structure_result.passed:
                differences_detected = True
                summary = getattr(structure_result, "summary", None)
                page_diffs = getattr(structure_result, "page_differences", None)
                details_parts: List[str] = []
                if summary:
                    details_parts.extend(str(item) for item in summary)
                if page_diffs:
                    for page, diffs in page_diffs.items():
                        for diff in diffs:
                            details_parts.append(f"Page {page}: {diff.message}")
                llm_differences.append(
                    {
                        "facet": "structure",
                        "description": "PDF structural comparison failed.",
                        "details": "\n".join(details_parts) if details_parts else "Structure comparison differences detected.",
                    }
                )

        llm_decision = None
        llm_label_enum = None
        if differences_detected and llm_requested:
            llm_general_notes.append(f"mask_applied={'yes' if mask else 'no'}")
            try:
                assess_pdf_diff_fn, create_binary_content_fn, llm_label_enum = (
                    _load_pdf_llm_runtime()
                )
            except LLMDependencyError as exc:
                print(str(exc))
            else:
                llm_decision = self._handle_llm_for_pdf_differences(
                    reference_document=reference_document,
                    candidate_document=candidate_document,
                    differences=llm_differences,
                    overrides=llm_overrides,
                    notes=llm_general_notes,
                    custom_prompt=custom_llm_prompt,
                    create_binary_content_fn=create_binary_content_fn,
                    assess_pdf_diff_fn=assess_pdf_diff_fn,
                )
            if llm_decision:
                decision_value = _coerce_label_value(llm_decision.decision)
                print(
                    f"LLM decision: {decision_value} "
                    f"(confidence={llm_decision.confidence!r}) - {llm_decision.reason}"
                )
                if llm_decision.notes:
                    print(f"LLM notes: {llm_decision.notes}")
                if llm_override_result and llm_decision.is_positive:
                    print("LLM approved PDF differences. Overriding baseline failure.")
                    differences_detected = False
                elif _decision_equals_flag(llm_decision.decision, llm_label_enum):
                    print("LLM returned FLAG - keeping original PDF comparison result.")
                elif not llm_decision.is_positive and llm_override_result:
                    print("LLM rejected PDF differences. Baseline failure will stand.")

        if differences_detected:
            ref_doc = None
            cand_doc = None             
            raise AssertionError('The compared PDF Document Data is different.')
        # if reference!=candidate:
        #     pprint(DeepDiff(reference, candidate), width=200)
        #     print("Reference Document:")
        #     pprint(reference)
        #     print("Candidate Document:")
        #     pprint(candidate)           
        #     raise AssertionError('The compared PDF Document Data is different.')

    @keyword
    def compare_pdf_structure(self, reference_document, candidate_document, **kwargs):
        """Assert PDF structure/layout matches while tolerating font substitutions.

        The keyword compares per-line text order and bounding boxes between two PDFs.
        Fonts are normalised (subset prefixes removed) and layout is evaluated against
        configurable tolerances. Both ``reference_document`` and ``candidate_document``
        can be file paths or URLs.

        Optional arguments:

            - ``position_tolerance`` (float, default ``15.0``): absolute max delta (points) for line positions.
            - ``size_tolerance`` (float, default equals ``position_tolerance``): absolute delta for width/height.
            - ``relative_tolerance`` (float, default ``0.05``): extra tolerance expressed as percentage of reference value.
            - ``case_sensitive`` (bool, default ``True``): toggle case-sensitive text comparison.
            - ``strip_font_subset`` (bool, default ``True``): remove PDF font subset prefixes.
            - ``collapse_whitespace`` (bool, default ``True``): collapse consecutive whitespace before comparing.
            - ``strip_line_edges`` (bool, default ``True``): trim leading/trailing whitespace.
            - ``drop_empty_lines`` (bool, default ``True``): ignore empty text lines after normalisation.
            - ``whitespace_replacement`` (str, default single space): character inserted when collapsing whitespace.
            - ``round_precision`` (int or ``None``, default ``3``): precision for rounding bounding boxes.
            - ``dpi`` (int, optional): DPI used when building the structure (defaults to library DPI).

        Examples:
        | `Compare Pdf Structure`    reference.pdf    candidate.pdf
        | `Compare Pdf Structure`    reference.pdf    candidate.pdf    position_tolerance=3    relative_tolerance=0.02
        | `Run Keyword And Expect Error`    The compared PDF structure is different.    Compare Pdf Structure    reference.pdf    candidate_with_changed_text.pdf

        """
        reference_document = self._ensure_local_document(reference_document)
        candidate_document = self._ensure_local_document(candidate_document)

        position_tolerance = _as_float(kwargs.get('position_tolerance', 15.0), 15.0)
        size_tolerance = _as_float(kwargs.get('size_tolerance', position_tolerance), position_tolerance)
        relative_tolerance = _as_float(kwargs.get('relative_tolerance', 0.05), 0.05)
        case_sensitive = _as_bool(kwargs.get('case_sensitive', True), True)
        strip_font_subset = _as_bool(kwargs.get('strip_font_subset', True), True)
        collapse_whitespace = _as_bool(kwargs.get('collapse_whitespace', True), True)
        strip_line_edges = _as_bool(kwargs.get('strip_line_edges', True), True)
        drop_empty_lines = _as_bool(kwargs.get('drop_empty_lines', True), True)
        whitespace_replacement = kwargs.get('whitespace_replacement', " ")
        round_precision = _as_int_or_none(kwargs.get('round_precision', 3))
        dpi = _as_int_or_none(kwargs.get('dpi'))
        if dpi is None:
            dpi = DEFAULT_DPI

        extraction_config = StructureExtractionConfig(
            collapse_whitespace=collapse_whitespace,
            strip_font_subset=strip_font_subset,
            whitespace_replacement=str(whitespace_replacement),
            strip_line_edges=strip_line_edges,
            drop_empty_lines=drop_empty_lines,
            round_precision=round_precision,
        )
        tolerance = StructureTolerance(
            position=position_tolerance,
            size=size_tolerance,
            relative=relative_tolerance,
        )
        result = self._perform_structure_comparison(
            reference_document=reference_document,
            candidate_document=candidate_document,
            tolerance=tolerance,
            extraction_config=extraction_config,
            case_sensitive=case_sensitive,
            dpi=dpi,
        )
        if not result.passed:
            raise AssertionError('The compared PDF structure is different.')

    @keyword
    def check_text_content(self, expected_text_list, candidate_document):
        """*DEPRECATED!!* Use keyword `PDF Should Contain Strings` instead.
        
        Checks if each item provided in the list ``expected_text_list`` appears in the PDF File ``candidate_document``.
        
        ``expected_text_list`` is a list of strings, ``candidate_document`` is the path to a PDF File.
        
        Examples:

        | @{strings}=    Create List    One String    Another String   
        | `Check Text Content`    ${strings}    candidate.pdf   
        
        """
        if is_url(candidate_document):
            candidate_document = download_file_from_url(candidate_document)
        doc = fitz.open(candidate_document)
        missing_text_list = []
        all_texts_were_found = None
        for text_item in expected_text_list:
            text_found_in_page = False
            for page in doc.pages():
                if any(text_item in s for s in page.get_text("text").splitlines()):
                    text_found_in_page = True
                    break
            if text_found_in_page:
                continue
            all_texts_were_found = False
            missing_text_list.append({'text':text_item, 'document':candidate_document})
        if all_texts_were_found is False:
            print(missing_text_list)
            doc = None
            raise AssertionError('Some expected texts were not found in document')
    
    @keyword
    def PDF_should_contain_strings(self, expected_text_list, candidate_document):
        """Checks if each item provided in the list ``expected_text_list`` appears in the PDF File ``candidate_document``.
        
        ``expected_text_list`` is a list of strings or a single string, ``candidate_document`` is the path or URL to a PDF File.
        
        Examples:

        | @{strings}=    Create List    One String    Another String   
        | `PDF Should Contain Strings`    ${strings}    candidate.pdf   
        | `PDF Should Contain Strings`    One String    candidate.pdf   
        
        """
        if is_url(candidate_document):
            candidate_document = download_file_from_url(candidate_document)
        doc = fitz.open(candidate_document)
        # if expected_text_list is a string, convert it to a list
        if isinstance(expected_text_list, str):
            expected_text_list = [expected_text_list]
        missing_text_list = []
        found_text_list = []
        all_texts_were_found = None
        for text_item in expected_text_list:
            text_found_in_page = False
            for page in doc.pages():
                if any(text_item in s for s in page.get_text("text").splitlines()):
                    text_found_in_page = True
                    found_text_list.append({'text':text_item, 'document':candidate_document, 'page':page.number+1})
                    break
            if text_found_in_page:
                continue
            all_texts_were_found = False
            missing_text_list.append({'text':text_item, 'document':candidate_document})
        if all_texts_were_found is False:
            print(f"Missing Texts:\n{missing_text_list}")
            print(f"Found Texts:\n{found_text_list}")
            doc = None
            raise AssertionError('Some expected texts were not found in document')
        else:
            doc = None
            print(f"Found Texts:\n{found_text_list}")

    @keyword
    def PDF_should_not_contain_strings(self, expected_text_list, candidate_document):
        """Checks if each item provided in the list ``expected_text_list`` does NOT appear in the PDF File ``candidate_document``.
        
        ``expected_text_list`` is a list of strings or a single string, ``candidate_document`` is the path or URL to a PDF File.
        
        Examples:

        | @{strings}=    Create List    One String    Another String   
        | `PDF Should Not Contain Strings`    ${strings}    candidate.pdf   
        | `PDF Should Not Contain Strings`    One String    candidate.pdf   
        
        """
        if is_url(candidate_document):
            candidate_document = download_file_from_url(candidate_document)
        doc = fitz.open(candidate_document)
        # if expected_text_list is a string, convert it to a list
        if isinstance(expected_text_list, str):
            expected_text_list = [expected_text_list]
        missing_text_list = []
        found_text_list = []
        for text_item in expected_text_list:
            text_item_found = False
            for page in doc.pages():
                if any(text_item in s for s in page.get_text("text").splitlines()):
                    text_item_found = True
                    found_text_list.append({'text':text_item, 'document':candidate_document, 'page':page.number+1})
                    continue
            if text_item_found == False:
                missing_text_list.append({'text':text_item, 'document':candidate_document})
        if found_text_list:
            print(f"Missing Texts:\n{missing_text_list}")
            print(f"Found Texts:\n{found_text_list}")
            doc = None
            raise AssertionError('Some non-expected texts were found in document')
        else:
            doc = None
            print('None of the non-expected texts were found in document')
            print(f"Missing Texts:\n{missing_text_list}")
    
    @keyword
    def compare_pdf_documents_with_llm(self, *args, llm_override: bool = False, **kwargs):
        """Compare PDF files and consult the configured LLM before failing.

        | =Arguments= | =Description= |
        | ``*args`` | Positional arguments forwarded to ``Compare Pdf Documents`` (reference and candidate). |
        | ``llm_override`` | When ``${True}``, allow an approving LLM verdict to override baseline failures. Default ``${False}``. |
        | ``**kwargs`` | Keyword arguments forwarded to ``Compare Pdf Documents``. ``llm_prompt`` / ``llm_pdf_prompt`` may be used to customise the LLM prompt. |

        Example:
        | `Compare Pdf Documents With LLM`   reference.pdf   candidate.pdf   compare=text   llm_override=${True}
        """
        kwargs["llm_enabled"] = kwargs.get("llm_enabled", True)
        if "llm_override" not in kwargs:
            kwargs["llm_override"] = llm_override
        return self.compare_pdf_documents(*args, **kwargs)

    def _perform_structure_comparison(
        self,
        reference_document: str,
        candidate_document: str,
        tolerance: StructureTolerance,
        extraction_config: StructureExtractionConfig,
        *,
        case_sensitive: bool,
        dpi: int,
    ):
        reference_representation = DocumentRepresentation(reference_document, dpi=dpi)
        candidate_representation = DocumentRepresentation(candidate_document, dpi=dpi)
        reference_structure = reference_representation.get_pdf_structure(config=extraction_config)
        candidate_structure = candidate_representation.get_pdf_structure(config=extraction_config)
        result = compare_document_structures(
            reference=reference_structure,
            candidate=candidate_structure,
            tolerance=tolerance,
            case_sensitive=case_sensitive,
        )
        self._log_structure_result(result)
        return result

    def _log_structure_result(self, result):
        if result.summary:
            for entry in result.summary:
                logger.warn(f"[PDF Structure] {entry}")
        if result.page_differences:
            for page in sorted(result.page_differences.keys()):
                for diff in result.page_differences[page]:
                    message = f"[PDF Structure] Page {page}: {diff.message}"
                    details = []
                    if diff.reference_index is not None:
                        details.append(f"reference line={diff.reference_index}")
                    if diff.candidate_index is not None:
                        details.append(f"candidate line={diff.candidate_index}")
                    if details:
                        message = f"{message} ({', '.join(details)})"
                    logger.warn(message)
                    if diff.deltas:
                        pretty = ", ".join(f"{axis}={value:.3f}" for axis, value in diff.deltas.items())
                        logger.debug(f"[PDF Structure] Page {page} deltas: {pretty}")
        if result.passed:
            logger.info("[PDF Structure] Documents match within configured tolerances.")

    def _ensure_local_document(self, document):
        return download_file_from_url(document) if is_url(document) else document

    def _handle_llm_for_pdf_differences(
        self,
        reference_document: str,
        candidate_document: str,
        differences: List[Dict[str, Any]],
        overrides: Dict[str, Optional[str]],
        notes: List[str],
        custom_prompt: Optional[str],
        create_binary_content_fn: Optional[Any] = None,
        assess_pdf_diff_fn: Optional[Any] = None,
    ) -> Optional[LLMDecision]:
        overrides = {key: (str(value) if value is not None else None) for key, value in overrides.items()}
        overrides.setdefault("llm_enabled", "true")
        overrides.setdefault("llm_pdf_enabled", "true")

        try:
            settings = load_llm_settings(overrides)
        except Exception as exc:  # pragma: no cover - defensive
            logger.warn(f"Failed to load LLM settings: {exc}")
            return None

        if not settings.pdf_enabled:
            print("LLM PDF evaluation requested but disabled via settings.")
            return None

        if create_binary_content_fn is None or assess_pdf_diff_fn is None:
            try:
                default_assess, default_create, _ = _load_pdf_llm_runtime()
            except LLMDependencyError as exc:
                print(str(exc))
                return None
            if assess_pdf_diff_fn is None:
                assess_pdf_diff_fn = default_assess
            if create_binary_content_fn is None:
                create_binary_content_fn = default_create

        summary_lines = [
            f"Reference document: {reference_document}",
            f"Candidate document: {candidate_document}",
        ]
        attachments = []
        try:
            reference_bytes = Path(reference_document).read_bytes()
            attachments.append(
                create_binary_content_fn(reference_bytes, "application/pdf")
            )
        except FileNotFoundError:
            logger.warn("Reference document not found for LLM attachment: %s", reference_document)
        except LLMDependencyError as exc:
            print(str(exc))
            return None
        except Exception as exc:  # pragma: no cover - defensive
            logger.warn("Failed to attach reference document for LLM: %s", exc)

        try:
            candidate_bytes = Path(candidate_document).read_bytes()
            attachments.append(
                create_binary_content_fn(candidate_bytes, "application/pdf")
            )
        except FileNotFoundError:
            logger.warn("Candidate document not found for LLM attachment: %s", candidate_document)
        except LLMDependencyError as exc:
            print(str(exc))
            return None
        except Exception as exc:  # pragma: no cover - defensive
            logger.warn("Failed to attach candidate document for LLM: %s", exc)

        for item in differences:
            facet = item.get("facet", "unknown")
            description = item.get("description", "")
            detail = item.get("details")
            summary_lines.append(f"{facet}: {description}")
            if detail:
                detail_text = str(detail)
                if len(detail_text) > 2000:
                    detail_text = f"{detail_text[:2000]} ... (truncated)"
                summary_lines.append(detail_text)

        extra_messages = list(notes or [])

        try:
            decision = assess_pdf_diff_fn(
                settings=settings,
                textual_summary="\n".join(summary_lines),
                attachments=tuple(attachments),
                extra_messages=extra_messages,
                system_prompt=custom_prompt,
            )
        except LLMDependencyError as exc:
            print(str(exc))
            return None
        except Exception as exc:  # pragma: no cover - defensive
            logger.warn("LLM PDF evaluation failed: %s", exc)
            return None
        return decision

def is_masked(text, mask):
    if isinstance(mask, str):
        mask = [mask]
    if isinstance(mask, list):
        for single_mask in mask:
            if re.match(single_mask, text):
                return True
    return  False



