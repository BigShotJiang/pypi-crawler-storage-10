# linux_macrorecorder is now simple_macrorecorder

This package has been renamed. Use `pip install simple_macrorecorder` instead.

New package: https://pypi.org/project/simple_macrorecorder/
