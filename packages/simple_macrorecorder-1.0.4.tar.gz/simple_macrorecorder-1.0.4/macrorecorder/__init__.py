"""Macro Recorder application package."""

from .gui.application import MacroRecorderApp, main
