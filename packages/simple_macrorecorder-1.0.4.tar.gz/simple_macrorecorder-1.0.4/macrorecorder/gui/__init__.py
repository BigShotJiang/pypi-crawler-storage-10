"""Graphical user interface components for the Macro Recorder."""

from .application import MacroRecorderApp, main
