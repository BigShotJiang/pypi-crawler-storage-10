class AppConfig:
    verbosity = 1
settings = AppConfig()