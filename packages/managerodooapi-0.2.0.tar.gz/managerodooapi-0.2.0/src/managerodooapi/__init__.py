"""
Manager Odoo API - Una librería completa para gestionar conexiones y operaciones con Odoo
"""

__version__ = "0.1.0"
__author__ = "Carlos Servin"
__email__ = "tu.email@ejemplo.com"
__description__ = "Una librería de Python completa para gestionar conexiones y operaciones con Odoo"

# Importar las clases principales
from .odoo import OdooConnector, Credentials

# Definir qué se exporta cuando se hace "from managerodooapi import *"
__all__ = [
    "OdooConnector",
    "Credentials",
]