import pandas as pd
import numpy as np
import xmlrpc.client
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

@dataclass
class Credentials:
    url: str
    db: str
    username: str
    password: str


class OdooConnector:
    """
    Clase para conectar y operar con Odoo de manera genérica.
    Permite crear registros en cualquier modelo con mapeo de campos flexible.
    Soporta multi-compañía.
    """
    
    def __init__(self,creds:Credentials, connect_imediately:bool = True):
        self.creds = creds
        self.uid: Optional[Any] = None
        self.models: Any = None
        if connect_imediately:
            self.connect()
    
    def connect(self):
        try:
            common = xmlrpc.client.ServerProxy(f'{self.creds.url}/xmlrpc/2/common', allow_none=True)
            self.uid = common.authenticate(self.creds.db,self.creds.username,self.creds.password,{})
            if not self.uid:
                raise RuntimeError("Failed authentication")
            self.models = xmlrpc.client.ServerProxy(f'{self.creds.url}/xmlrpc/2/object', allow_none=True)
            print(f"Connected to Odoo instance at {self.creds.url} as user {self.creds.username}")
        except Exception as e:
            raise RuntimeError(f"Connection failed: {e}")
        
    def _ensure_connection(self):
        if self.uid is None or self.models is None:
            self.connect()

    def execute_kw(self, db: str, uid: Any, password: str, model: str, method: str, 
                   args: Optional[List] = None, kwargs: Optional[Dict] = None):
        """
        Método directo para ejecutar cualquier método de Odoo.
        Expone la funcionalidad completa de execute_kw.
        """
        self._ensure_connection()
        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}
        
        try:
            return self.models.execute_kw(db, uid, password, model, method, args, kwargs)
        except Exception as e:
            raise RuntimeError(f"Execute_kw failed on {model}.{method}: {e}")

    def _build_context(self, company_id: Optional[int] = None, extra_context: Optional[Dict] = None) -> Dict:
        """Construye el contexto con información de compañía."""
        context = extra_context.copy() if extra_context else {}
        if company_id:
            context.update({
                'company_id': company_id,
                'allowed_company_ids': [company_id],
            })
        return context

    def get_fields(self, model: str, company_id: Optional[int] = None) -> Dict[str, Any]:
        self._ensure_connection()
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'fields_get', [], 
                {'attributes': ['string', 'type', 'required', 'help'], 'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Failed to get fields for model {model}: {e}")

    def search(self, model: str, domain: Optional[List]=None, limit: Optional[int]=None, company_id: Optional[int] = None) -> List[int]:
        self._ensure_connection()
        if domain is None:
            domain = []
        
        # Agregar filtro de compañía al domain si se especifica
        if company_id:
            domain = domain + [('company_id', '=', company_id)]
        
        try:
            context = self._build_context(company_id)
            kwargs = {'context': context}
            if limit:
                kwargs['limit'] = limit # type: ignore
                
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'search', [domain], kwargs
            )
        except Exception as e:
            raise RuntimeError(f"Search failed on model {model}: {e}")
        
    def read(self, model: str, fields: Optional[list[str]]=None, domain: Optional[List]=None, 
             limit: Optional[int]=None, company_id: Optional[int] = None) -> List[Dict]:
        self._ensure_connection()
        if domain is None:
            domain = []
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return []
        try:
            context = self._build_context(company_id)
            kwargs = {'context': context}
            if fields:
                kwargs['fields'] = fields # type: ignore
                
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'read', [ids], kwargs
            )
        except Exception as e:
            raise RuntimeError(f"Read failed on model {model}: {e}")

    def create(self, model: str, values: Union[Dict,List[Dict]], company_id: Optional[int] = None) -> Union[int, List[int]]:
        """
        Create one or multiple records in the specified model.
        values can be a single dictionary or a list of dictionaries.
        Returns the ID or list of IDs of the created records.
        """
        self._ensure_connection()
        
        # Agregar company_id a los valores si se especifica
        if company_id:
            if isinstance(values, dict):
                values['company_id'] = company_id
            elif isinstance(values, list):
                for val_dict in values:
                    val_dict['company_id'] = company_id
        
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'create', [values], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Create failed on model {model}: {e}")
        
    def update(self, model: str, ids: Sequence[int], values: Dict, company_id: Optional[int] = None) -> bool:
        """
        Update records in the specified model.
        ids: list of record IDs to update
        """
        self._ensure_connection()
        if not ids:
            return False
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password, 
                model, 'write', [list(ids), values], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Update failed on model {model}: {e}")

    def update_by_domain(self, model: str, domain: List, values: Dict, 
                        limit: Optional[int]=None, company_id: Optional[int] = None) -> Tuple[List[int], bool]:
        """
        Update records in the specified model matching the domain.
        domain: search domain to find records
        values: dictionary of values to update
        """
        self._ensure_connection()
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return [], False
        ok = self.update(model, ids, values, company_id)
        return ids, ok
    
    def delete(self, model: str, ids: Sequence[int], company_id: Optional[int] = None) -> bool:
        """
        Delete records in the specified model.
        ids: list of record IDs to delete
        """
        self._ensure_connection()
        if not ids:
            return False
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password, 
                model, 'unlink', [list(ids)], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Delete failed on model {model}: {e}")
        
    def delete_by_domain(self, model: str, domain: List, limit: Optional[int]=None, 
                        company_id: Optional[int] = None) -> Tuple[List[int], bool]:
        """
        Delete records in the specified model matching the domain.
        domain: search domain to find records
        """
        self._ensure_connection()
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return [], False
        ok = self.delete(model, ids, company_id)
        return ids, ok
    
    # Data helpers
    def _normalize_value(self, val):
        if pd.isna(val):
            return None
        if isinstance(val, np.integer):
            return int(val)
        if isinstance(val, np.floating):
            return float(val)
        return val
    
    def create_from_df(self, model: str, df: pd.DataFrame, field_map: Dict[str, str], 
                       static_values: Optional[Dict[str, Any]]=None, batch_size: int=50, 
                       validate: bool=True, company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Create records in the specified model from a DataFrame.
        field_map: mapping from DataFrame columns to Odoo fields
        company_id: opcional, para crear registros en una compañía específica
        Returns list of created record IDs.
        """
        if static_values is None:
            static_values = {}
        
        # validate columns
        missing = [col for col in field_map.keys() if col not in df.columns]
        if missing:
            raise ValueError(f"DataFrame is missing required columns: {missing}")
        
        result = {'created_ids': [], 'errors': [], 'total_processed': 0, 'total_created': 0}
        total = len(df)
        for start in range(0, total, batch_size):
            batch = df.iloc[start:start + batch_size]
            payload = []
            for idx, row in batch.iterrows():
                values = dict(static_values)
                for df_column, odoo_field in field_map.items():
                    v = row[df_column]
                    nv = self._normalize_value(v)
                    if nv is None:
                        continue
                    values[odoo_field] = nv
                try:
                    if validate and not values:
                        raise ValueError("Registro vacío tras normalización")
                    print(f"Preparando para crear: {values}")
                    payload.append(values)
                except Exception as e:
                    result['errors'].append({'row_index': idx, 'error': str(e), 'row_data': row.to_dict()})
            print(f"Creando lote de {len(payload)} registros en {model}...")
            print(f"Payload: {payload}")
            if payload:
                try:
                    created = self.create(model, payload, company_id)
                    # created puede ser int o lista
                    if isinstance(created, list):
                        result['created_ids'].extend(created)
                        result['total_created'] += len(created)
                    else:
                        result['created_ids'].append(created)
                        result['total_created'] += 1
                except Exception as e:
                    # fallback: intentar individualmente
                    print(f"Error bulk create, intentando individual: {e}")
                    for rec in payload:
                        try:
                            cid = self.create(model, rec, company_id)
                            if isinstance(cid, list):
                                result['created_ids'].append(cid[0] if cid else None)
                            else:
                                result['created_ids'].append(cid)
                            result['total_created'] += 1
                        except Exception as ie:
                            result['errors'].append({'record': rec, 'error': str(ie)})
            result['total_processed'] += len(batch)
        print(f"Creación completada: procesados {result['total_processed']}, creados {result['total_created']}, errores {len(result['errors'])}")
        return result

    def upsert_by_external_id(self, model: str, external_id_field: str, external_id_value: str, 
                             values: Dict, company_id: Optional[int] = None) -> Tuple[int, bool]:
        """
        Crear o actualizar registro basado en ID externo.
        Retorna (record_id, was_created)
        """
        domain = [(external_id_field, '=', external_id_value)]
        existing_ids = self.search(model, domain, limit=1, company_id=company_id)
        
        if existing_ids:
            # Actualizar
            self.update(model, existing_ids, values, company_id)
            return existing_ids[0], False
        else:
            # Crear
            values[external_id_field] = external_id_value
            new_id = self.create(model, values, company_id)
            # self.create can return int or List[int]; normalize to int
            if isinstance(new_id, list):
                if not new_id:
                    raise RuntimeError("Create returned an empty list when creating record with external id")
                new_id = new_id[0]
            if not isinstance(new_id, int):
                raise RuntimeError(f"Unexpected id type returned from create: {type(new_id)}")
            return new_id, True

    # === MÉTODOS PARA EXPLORAR RELACIONES ENTRE MODELOS ===
    
    def get_model_relations(self, model: str, company_id: Optional[int] = None) -> Dict[str, Dict[str, Any]]:
        """
        Obtiene todas las relaciones (campos relacionales) de un modelo específico.
        
        Args:
            model: Nombre del modelo (ej: 'res.partner')
            company_id: ID de compañía específica
            
        Returns:
            Diccionario con campos relacionales y su información
        """
        self._ensure_connection()
        
        try:
            context = self._build_context(company_id)
            all_fields = self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'fields_get', [], 
                {'context': context}
            )
            
            # Filtrar solo campos relacionales
            relational_fields = {}
            relational_types = ['many2one', 'one2many', 'many2many']
            
            for field_name, field_info in all_fields.items():
                if field_info.get('type') in relational_types:
                    relational_fields[field_name] = {
                        'type': field_info.get('type'),
                        'relation': field_info.get('relation'),
                        'string': field_info.get('string', ''),
                        'help': field_info.get('help', ''),
                        'required': field_info.get('required', False),
                        'readonly': field_info.get('readonly', False),
                    }
                    
                    # Información adicional para one2many y many2many
                    if field_info.get('type') in ['one2many', 'many2many']:
                        relational_fields[field_name]['relation_field'] = field_info.get('relation_field')
                        
            return relational_fields
            
        except Exception as e:
            raise RuntimeError(f"Error obteniendo relaciones del modelo {model}: {e}")
    
    def explore_model_structure(self, model: str, max_depth: int = 2, 
                              company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Explora la estructura completa de un modelo incluyendo sus relaciones.
        
        Args:
            model: Nombre del modelo a explorar
            max_depth: Profundidad máxima de exploración (evita ciclos infinitos)
            company_id: ID de compañía específica
            
        Returns:
            Estructura jerárquica del modelo con sus relaciones
        """
        self._ensure_connection()
        
        def _explore_recursive(current_model: str, current_depth: int, visited: set) -> Dict:
            if current_depth >= max_depth or current_model in visited:
                return {'model': current_model, 'max_depth_reached': True}
                
            visited.add(current_model)
            
            try:
                # Obtener información básica del modelo
                model_info = {
                    'model': current_model,
                    'depth': current_depth,
                    'relations': {},
                    'field_count': 0
                }
                
                # Obtener campos del modelo
                relations = self.get_model_relations(current_model, company_id)
                model_info['field_count'] = len(relations)
                
                # Explorar cada relación
                for field_name, field_info in relations.items():
                    related_model = field_info.get('relation')
                    if related_model:
                        model_info['relations'][field_name] = {
                            'field_info': field_info,
                            'related_model': _explore_recursive(
                                related_model, current_depth + 1, visited.copy()
                            )
                        }
                
                return model_info
                
            except Exception as e:
                return {
                    'model': current_model,
                    'error': str(e),
                    'depth': current_depth
                }
        
        return _explore_recursive(model, 0, set())
    
    def get_reverse_relations(self, model: str, company_id: Optional[int] = None) -> Dict[str, List[Dict]]:
        """
        Encuentra qué otros modelos referencian al modelo especificado.
        
        Args:
            model: Modelo del cual buscar referencias inversas
            company_id: ID de compañía específica
            
        Returns:
            Diccionario con modelos que referencian al modelo dado
        """
        self._ensure_connection()
        
        try:
            # Obtener lista de todos los modelos
            context = self._build_context(company_id)
            
            # Buscar en modelos comunes que podrían tener referencias
            common_models = [
                'res.partner', 'res.users', 'res.company', 'res.country',
                'product.product', 'product.template', 'product.category',
                'sale.order', 'sale.order.line', 'purchase.order', 'purchase.order.line',
                'account.move', 'account.move.line', 'account.payment',
                'stock.picking', 'stock.move', 'stock.location',
                'project.project', 'project.task', 'hr.employee'
            ]
            
            reverse_relations = {}
            
            for check_model in common_models:
                try:
                    relations = self.get_model_relations(check_model, company_id)
                    
                    for field_name, field_info in relations.items():
                        if field_info.get('relation') == model:
                            if check_model not in reverse_relations:
                                reverse_relations[check_model] = []
                                
                            reverse_relations[check_model].append({
                                'field_name': field_name,
                                'field_type': field_info.get('type'),
                                'field_string': field_info.get('string', ''),
                                'required': field_info.get('required', False)
                            })
                            
                except Exception:
                    # Ignorar modelos que no existen o no son accesibles
                    continue
            
            return reverse_relations
            
        except Exception as e:
            raise RuntimeError(f"Error buscando relaciones inversas para {model}: {e}")
    
    def get_related_records(self, model: str, record_id: int, relation_field: str,
                          fields: Optional[List[str]] = None, limit: Optional[int] = None,
                          company_id: Optional[int] = None) -> List[Dict]:
        """
        Obtiene registros relacionados a través de un campo específico.
        
        Args:
            model: Modelo principal
            record_id: ID del registro principal
            relation_field: Campo de relación a seguir
            fields: Campos a leer de los registros relacionados
            limit: Límite de registros a retornar
            company_id: ID de compañía específica
            
        Returns:
            Lista de registros relacionados
        """
        self._ensure_connection()
        
        try:
            # Leer el campo de relación del registro principal
            context = self._build_context(company_id)
            
            main_record = self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'read', [record_id], 
                {'fields': [relation_field], 'context': context}
            )
            
            if not main_record:
                return []
            
            relation_value = main_record[0].get(relation_field)
            if not relation_value:
                return []
            
            # Obtener información del campo para saber el tipo de relación
            field_info = self.get_fields(model, company_id).get(relation_field, {})
            related_model = field_info.get('relation')
            
            if not related_model:
                return []
            
            # Determinar IDs a buscar según el tipo de relación
            related_ids = []
            
            if field_info.get('type') == 'many2one':
                # many2one retorna [id, name]
                if isinstance(relation_value, list) and len(relation_value) >= 1:
                    related_ids = [relation_value[0]]
                elif isinstance(relation_value, int):
                    related_ids = [relation_value]
                    
            elif field_info.get('type') in ['one2many', 'many2many']:
                # one2many y many2many retornan lista de IDs
                if isinstance(relation_value, list):
                    related_ids = relation_value
            
            if not related_ids:
                return []
            
            # Leer los registros relacionados
            kwargs = {'context': context}
            if fields:
                kwargs['fields'] = fields
            if limit:
                kwargs['limit'] = limit
                
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                related_model, 'read', [related_ids], kwargs
            )
            
        except Exception as e:
            raise RuntimeError(f"Error obteniendo registros relacionados: {e}")
    
    def analyze_model_usage(self, model: str, sample_size: int = 100, 
                          company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Analiza el uso de un modelo en la base de datos.
        
        Args:
            model: Modelo a analizar
            sample_size: Cantidad de registros a muestrear
            company_id: ID de compañía específica
            
        Returns:
            Análisis de uso del modelo
        """
        self._ensure_connection()
        
        try:
            context = self._build_context(company_id)
            
            # Contar total de registros
            total_count = len(self.search(model, company_id=company_id))
            
            # Obtener muestra de registros
            sample_ids = self.search(model, limit=sample_size, company_id=company_id)
            
            if not sample_ids:
                return {
                    'model': model,
                    'total_records': 0,
                    'analysis': 'No records found'
                }
            
            # Obtener relaciones del modelo
            relations = self.get_model_relations(model, company_id)
            
            # Analizar uso de campos relacionales
            relation_usage = {}
            
            if sample_ids and relations:
                sample_records = self.models.execute_kw(
                    self.creds.db, self.uid, self.creds.password,
                    model, 'read', [sample_ids[:min(20, len(sample_ids))]], 
                    {'fields': list(relations.keys()), 'context': context}
                )
                
                for field_name in relations.keys():
                    filled_count = sum(1 for record in sample_records 
                                     if record.get(field_name))
                    relation_usage[field_name] = {
                        'usage_percentage': (filled_count / len(sample_records)) * 100,
                        'filled_records': filled_count,
                        'total_sampled': len(sample_records),
                        'relation_info': relations[field_name]
                    }
            
            return {
                'model': model,
                'total_records': total_count,
                'sampled_records': len(sample_ids),
                'relational_fields_count': len(relations),
                'relation_usage': relation_usage,
                'most_used_relations': sorted(
                    relation_usage.items(),
                    key=lambda x: x[1]['usage_percentage'],
                    reverse=True
                )[:5]
            }
            
        except Exception as e:
            raise RuntimeError(f"Error analizando modelo {model}: {e}")


__all__ = ["Credentials", "OdooConnector"]

