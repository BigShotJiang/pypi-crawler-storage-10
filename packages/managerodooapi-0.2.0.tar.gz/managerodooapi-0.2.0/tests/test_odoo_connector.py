"""
Tests para la clase OdooConnector
"""

import pytest
import pandas as pd
from unittest.mock import Mock, patch, MagicMock
from managerodooapi.odoo import OdooConnector, Credentials


class TestCredentials:
    """Tests para la clase Credentials"""
    
    def test_credentials_creation(self):
        """Test de creación de credenciales"""
        creds = Credentials(
            url="http://localhost:8069",
            db="test_db", 
            username="admin",
            password="admin"
        )
        
        assert creds.url == "http://localhost:8069"
        assert creds.db == "test_db"
        assert creds.username == "admin"
        assert creds.password == "admin"


class TestOdooConnector:
    """Tests para la clase OdooConnector"""
    
    def setup_method(self):
        """Configuración para cada test"""
        self.creds = Credentials(
            url="http://localhost:8069",
            db="test_db",
            username="admin", 
            password="admin"
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_init_with_immediate_connection(self, mock_server_proxy):
        """Test de inicialización con conexión inmediata"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds, connect_imediately=True)
        
        assert connector.creds == self.creds
        assert connector.uid == 1
        assert connector.models == mock_models
        
        # Verificar que se llamaron los métodos correctos
        assert mock_server_proxy.call_count == 2
        mock_common.authenticate.assert_called_once_with("test_db", "admin", "admin", {})
    
    @patch('xmlrpc.client.ServerProxy')
    def test_init_without_immediate_connection(self, mock_server_proxy):
        """Test de inicialización sin conexión inmediata"""
        connector = OdooConnector(self.creds, connect_imediately=False)
        
        assert connector.creds == self.creds
        assert connector.uid is None
        assert connector.models is None
        
        # No debería haberse llamado ServerProxy
        mock_server_proxy.assert_not_called()
    
    @patch('xmlrpc.client.ServerProxy')
    def test_connect_success(self, mock_server_proxy):
        """Test de conexión exitosa"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds, connect_imediately=False)
        connector.connect()
        
        assert connector.uid == 1
        assert connector.models == mock_models
    
    @patch('xmlrpc.client.ServerProxy')
    def test_connect_authentication_failure(self, mock_server_proxy):
        """Test de fallo de autenticación"""
        mock_common = Mock()
        mock_common.authenticate.return_value = False
        
        mock_server_proxy.return_value = mock_common
        
        connector = OdooConnector(self.creds, connect_imediately=False)
        
        with pytest.raises(RuntimeError, match="Failed authentication"):
            connector.connect()
    
    @patch('xmlrpc.client.ServerProxy')
    def test_search_basic(self, mock_server_proxy):
        """Test básico de búsqueda"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = [1, 2, 3]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        result = connector.search('res.partner')
        
        assert result == [1, 2, 3]
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "search", [[]], {'context': {}}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_search_with_domain_and_limit(self, mock_server_proxy):
        """Test de búsqueda con dominio y límite"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = [1, 2]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        domain = [('name', 'ilike', 'test')]
        result = connector.search('res.partner', domain=domain, limit=10)
        
        assert result == [1, 2]
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "search", [domain], 
            {'context': {}, 'limit': 10}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_read_basic(self, mock_server_proxy):
        """Test básico de lectura"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.side_effect = [
            [1, 2, 3],  # search result
            [{'id': 1, 'name': 'Test 1'}, {'id': 2, 'name': 'Test 2'}]  # read result
        ]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        result = connector.read('res.partner', fields=['name'])
        
        assert len(result) == 2
        assert result[0]['name'] == 'Test 1'
        assert mock_models.execute_kw.call_count == 2
    
    @patch('xmlrpc.client.ServerProxy') 
    def test_create_single_record(self, mock_server_proxy):
        """Test de creación de un registro"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = 5
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        values = {'name': 'New Partner', 'email': 'test@example.com'}
        result = connector.create('res.partner', values)
        
        assert result == 5
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "create", [values], {'context': {}}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_create_multiple_records(self, mock_server_proxy):
        """Test de creación de múltiples registros"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = [5, 6]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        values = [
            {'name': 'Partner 1'}, 
            {'name': 'Partner 2'}
        ]
        result = connector.create('res.partner', values)
        
        assert result == [5, 6]
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "create", [values], {'context': {}}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_update_records(self, mock_server_proxy):
        """Test de actualización de registros"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = True
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        values = {'name': 'Updated Name'}
        result = connector.update('res.partner', [1, 2], values)
        
        assert result is True
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "write", [[1, 2], values], {'context': {}}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_delete_records(self, mock_server_proxy):
        """Test de eliminación de registros"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = True
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        result = connector.delete('res.partner', [1, 2])
        
        assert result is True
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "unlink", [[1, 2]], {'context': {}}
        )
    
    @patch('xmlrpc.client.ServerProxy')
    def test_create_from_df(self, mock_server_proxy):
        """Test de creación desde DataFrame"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = [10, 11]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        
        # Crear DataFrame de prueba
        df = pd.DataFrame({
            'nombre': ['Cliente 1', 'Cliente 2'],
            'correo': ['c1@test.com', 'c2@test.com']
        })
        
        field_map = {
            'nombre': 'name',
            'correo': 'email'
        }
        
        result = connector.create_from_df('res.partner', df, field_map)
        
        assert result['total_created'] == 2
        assert result['total_processed'] == 2
        assert len(result['errors']) == 0
        assert result['created_ids'] == [10, 11]
    
    @patch('xmlrpc.client.ServerProxy')
    def test_upsert_by_external_id_create(self, mock_server_proxy):
        """Test de upsert que crea nuevo registro"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.side_effect = [
            [],  # search result (no existe)
            10   # create result
        ]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        record_id, was_created = connector.upsert_by_external_id(
            'res.partner', 'ref', 'EXT001', {'name': 'New Partner'}
        )
        
        assert record_id == 10
        assert was_created is True
        assert mock_models.execute_kw.call_count == 2
    
    @patch('xmlrpc.client.ServerProxy')
    def test_upsert_by_external_id_update(self, mock_server_proxy):
        """Test de upsert que actualiza registro existente"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.side_effect = [
            [5],  # search result (existe)
            True  # update result
        ]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        record_id, was_created = connector.upsert_by_external_id(
            'res.partner', 'ref', 'EXT001', {'name': 'Updated Partner'}
        )
        
        assert record_id == 5
        assert was_created is False
        assert mock_models.execute_kw.call_count == 2
    
    @patch('xmlrpc.client.ServerProxy')
    def test_with_company_id(self, mock_server_proxy):
        """Test de operaciones con company_id específico"""
        mock_common = Mock()
        mock_common.authenticate.return_value = 1
        mock_models = Mock()
        mock_models.execute_kw.return_value = [1, 2]
        
        mock_server_proxy.side_effect = [mock_common, mock_models]
        
        connector = OdooConnector(self.creds)
        result = connector.search('res.partner', company_id=2)
        
        expected_context = {
            'company_id': 2,
            'allowed_company_ids': [2]
        }
        
        mock_models.execute_kw.assert_called_once_with(
            "test_db", 1, "admin", "res.partner", "search", 
            [[('company_id', '=', 2)]], {'context': expected_context}
        )
    
    def test_normalize_value(self):
        """Test de normalización de valores"""
        connector = OdooConnector(self.creds, connect_imediately=False)
        
        # Test con pandas NA
        assert connector._normalize_value(pd.NA) is None
        
        # Test con numpy int
        import numpy as np
        assert connector._normalize_value(np.int64(42)) == 42
        assert isinstance(connector._normalize_value(np.int64(42)), int)
        
        # Test con numpy float
        assert connector._normalize_value(np.float64(42.5)) == 42.5
        assert isinstance(connector._normalize_value(np.float64(42.5)), float)
        
        # Test con valor normal
        assert connector._normalize_value("test") == "test"