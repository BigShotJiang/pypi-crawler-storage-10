"""Configuration files and templates."""
