"""Linlinegg MCP Calculator Server - 一个简单的 MCP 服务器示例"""

__version__ = "0.1.0"
__author__ = "Linlinegg"
__email__ = "your.email@example.com"

from .server import main

__all__ = ["main"]

