"""Interactive plotting utilities for climatrix datasets."""

from .core import Plot

__all__ = ["Plot"]
