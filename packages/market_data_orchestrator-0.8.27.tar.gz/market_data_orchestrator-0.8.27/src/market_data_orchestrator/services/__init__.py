"""
Services for orchestrator.

Phase 8.0 Day 2: Federation directory services.
"""

from .federation_directory import StaticDirectory

__all__ = ["StaticDirectory"]

