from enum import Enum


class Division(Enum):
    """# Ranked division"""

    I = "I"  # noqa: E741
    II = "II"
    III = "III"
    IV = "IV"
