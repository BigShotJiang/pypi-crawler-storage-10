"""@private"""

__version__ = "1.3.0"
__author__ = "diodemusic"
__title__ = "pyke"
