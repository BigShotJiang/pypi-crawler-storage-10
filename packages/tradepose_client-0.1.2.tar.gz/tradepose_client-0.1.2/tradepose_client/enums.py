"""
Enumerations for Tradepose strategy configuration

All enums are aligned with Rust backend types for JSON serialization.
"""

from enum import Enum


class Freq(str, Enum):
    """
    Time frequency enum (aligned with Rust Freq enum)

    Values:
        MIN_1: 1 minute
        MIN_5: 5 minutes
        MIN_15: 15 minutes
        MIN_30: 30 minutes
        HOUR_1: 1 hour
        HOUR_4: 4 hours
        DAY_1: 1 day
        WEEK_1: 1 week
        MONTH_1: 1 month
    """

    MIN_1 = "1min"
    MIN_5 = "5min"
    MIN_15 = "15min"
    MIN_30 = "30min"
    HOUR_1 = "1h"
    HOUR_4 = "4h"
    DAY_1 = "1D"
    WEEK_1 = "1W"
    MONTH_1 = "1M"


class OrderStrategy(str, Enum):
    """
    Order strategy enum (aligned with Rust OrderStrategy enum)

    Used to specify the execution strategy for entry/exit triggers.

    Rust mapping:
    - Rust: OrderStrategy::ImmediateEntry      → Python: OrderStrategy.IMMEDIATE_ENTRY      (u32: 0)
    - Rust: OrderStrategy::FavorableDelayEntry → Python: OrderStrategy.FAVORABLE_DELAY_ENTRY (u32: 1)
    - Rust: OrderStrategy::AdverseDelayEntry   → Python: OrderStrategy.ADVERSE_DELAY_ENTRY   (u32: 2)
    - Rust: OrderStrategy::ImmediateExit       → Python: OrderStrategy.IMMEDIATE_EXIT        (u32: 3)
    - Rust: OrderStrategy::StopLoss            → Python: OrderStrategy.STOP_LOSS             (u32: 4)
    - Rust: OrderStrategy::TakeProfit          → Python: OrderStrategy.TAKE_PROFIT           (u32: 5)
    - Rust: OrderStrategy::TrailingStop        → Python: OrderStrategy.TRAILING_STOP         (u32: 6)
    - Rust: OrderStrategy::Breakeven           → Python: OrderStrategy.BREAKEVEN             (u32: 7)
    - Rust: OrderStrategy::TimeoutExit         → Python: OrderStrategy.TIMEOUT_EXIT          (u32: 8)

    Entry Strategies:
        IMMEDIATE_ENTRY: Immediate entry on signal (required for Base Blueprint)
        FAVORABLE_DELAY_ENTRY: Wait for favorable price (pullback/retracement)
        ADVERSE_DELAY_ENTRY: Wait for breakout/aggressive entry

    Exit Strategies:
        IMMEDIATE_EXIT: Immediate exit on signal (required for Base Blueprint)
        STOP_LOSS: Fixed stop loss
        TAKE_PROFIT: Fixed take profit
        TRAILING_STOP: Dynamic trailing stop
        BREAKEVEN: Move stop to breakeven after profit
        TIMEOUT_EXIT: Exit after time limit
    """

    IMMEDIATE_ENTRY = "ImmediateEntry"
    FAVORABLE_DELAY_ENTRY = "FavorableDelayEntry"
    ADVERSE_DELAY_ENTRY = "AdverseDelayEntry"
    IMMEDIATE_EXIT = "ImmediateExit"
    STOP_LOSS = "StopLoss"
    TAKE_PROFIT = "TakeProfit"
    TRAILING_STOP = "TrailingStop"
    BREAKEVEN = "Breakeven"
    TIMEOUT_EXIT = "TimeoutExit"


class Weekday(str, Enum):
    """
    Weekday enum (aligned with Rust Weekday enum)

    Used for Market Profile WeeklyTime configuration.

    Mapping:
        MON (Monday) = 0
        TUE (Tuesday) = 1
        WED (Wednesday) = 2
        THU (Thursday) = 3
        FRI (Friday) = 4
        SAT (Saturday) = 5
        SUN (Sunday) = 6
    """

    MON = "Mon"
    TUE = "Tue"
    WED = "Wed"
    THU = "Thu"
    FRI = "Fri"
    SAT = "Sat"
    SUN = "Sun"


class IndicatorType(str, Enum):
    """
    Indicator type enum

    Maps to Indicator factory methods in models.py.

    Values:
        SMA: Simple Moving Average
        EMA: Exponential Moving Average
        SMMA: Smoothed Moving Average
        WMA: Weighted Moving Average
        ATR: Average True Range
        ATR_QUANTILE: ATR Rolling Quantile
        SUPERTREND: SuperTrend
        MARKET_PROFILE: Market Profile
        CCI: Commodity Channel Index
        RSI: Relative Strength Index
        BOLLINGER_BANDS: Bollinger Bands
        MACD: Moving Average Convergence Divergence
        STOCHASTIC: Stochastic Oscillator
        ADX: Average Directional Index
        RAW_OHLCV: Raw OHLCV column
    """

    SMA = "sma"
    EMA = "ema"
    SMMA = "smma"
    WMA = "wma"
    ATR = "atr"
    ATR_QUANTILE = "atr_quantile"
    SUPERTREND = "supertrend"
    MARKET_PROFILE = "market_profile"
    CCI = "cci"
    RSI = "rsi"
    BOLLINGER_BANDS = "bollinger_bands"
    MACD = "macd"
    STOCHASTIC = "stochastic"
    ADX = "adx"
    RAW_OHLCV = "raw_ohlcv"


class TradeDirection(str, Enum):
    """
    Trade direction enum

    Used to specify the trading direction in Blueprint.

    Values:
        LONG: Long trades only
        SHORT: Short trades only
        BOTH: Both long and short trades (currently not fully supported)
    """

    LONG = "Long"
    SHORT = "Short"
    BOTH = "Both"


class TrendType(str, Enum):
    """
    Trend type enum

    Used to categorize strategy trading style.

    Values:
        TREND: Trend-following strategies
        RANGE: Range-bound/mean-reversion strategies
        REVERSAL: Reversal/counter-trend strategies
    """

    TREND = "Trend"
    RANGE = "Range"
    REVERSAL = "Reversal"
