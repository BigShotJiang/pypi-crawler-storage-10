# bitwarden secrets (for poor ppl :3)

wrapper program to take a regular bitwarden vault and make it act like like a bitwarden secrets application by using the bitwarden cli app. the program will pull all items in a folder and then inject them into the environment using the item name and password field before running a passed command

## installation

### pypi

this package is publish and can be pulled from pypi using either `pip install bw_secrets` or `pipx install bw_secrets`

### releases

download the wheel from the releases page and install with either pip or pipx. pipx of course is the recommended installation method

## usage

this will assume that you have the bitwarden cli program installed on your machine and have logged in with it.

### Config

first, run the config using `bwsp config`, this will prompt you to enter your vault master password. this will be saved in a read only file in the users home directory: `~/.config/bw_secrets/pass.key`

this can be skipped, however, if you have a password file that you would like to use in a directory of your own. note, that this will required you to pass the path of the file with every run

### running

this can be done with `bwsp run <folder> <command>`

example:

```bash
bwsp run 'secrets/vaultwarden' 'docker compose up -d'
```

the passed folder can be either the folder id, which can be found through the url in the web vault after opening the folder, or by passing the folder name

**note** that when giving the folder name, this will increase the execution time as the wrapper then has to search for the correct folder and verify that it is the only folder with that name

#### running options
- `lock` will lock the vault after running. this is not done by default due to the time increase on multiple runs. simply running `bw lock` after you are finished will have the same effect
- `password-file` can point to a custom password file
- `no-sync` will skip the vault sync. this can save time if you know that the local vault already has the data you need
