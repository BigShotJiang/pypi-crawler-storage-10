from .consts import TRADATE2025PATH


def _load_dates() -> tuple[list[str], set[str], dict[str, str], dict[str, str]]:
    """加载交易日期数据并返回优化后的数据结构"""
    dates_list = [
        line.strip()
        for line in TRADATE2025PATH.read_text(encoding="utf-8").splitlines()
    ]
    dates_set = set(dates_list)

    date_prevdate = {
        next_date: current_date
        for current_date, next_date in zip(dates_list, dates_list[1:])
    }
    date_nextdate = {
        current_date: next_date
        for current_date, next_date in zip(dates_list, dates_list[1:])
    }

    return dates_list, dates_set, date_prevdate, date_nextdate


# 模块级别加载，避免重复加载
_DATES_LIST, _DATES_SET, _DATE_PREVDATE, _DATE_NEXTDATE = _load_dates()


def is_tradate(date: str) -> bool:
    """
    检查给定日期是否为交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'，例如'2025-10-24'

    Returns:
        bool: 如果是交易日返回True，否则返回False
    """
    return date in _DATES_SET


def today_is_tradate() -> bool:
    """
    检查今天是否为交易日

    Returns:
        bool: 如果今天是交易日返回True，否则返回False
    """
    from datetime import datetime

    return is_tradate(datetime.now().strftime("%Y-%m-%d"))


def get_prev_date(date: str) -> str:
    """
    获取指定日期的前一个交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'

    Returns:
        str: 前一个交易日，如果不存在则返回空字符串
    """
    return _DATE_PREVDATE.get(date, "")


def get_next_date(date: str) -> str:
    """
    获取指定日期的后一个交易日

    Args:
        date: 日期字符串，格式为'YYYY-MM-DD'

    Returns:
        str: 后一个交易日，如果不存在则返回空字符串
    """
    return _DATE_NEXTDATE.get(date, "")


def get_all_dates() -> list[str]:
    """
    获取所有交易日期列表（按顺序）

    Returns:
        List[str]: 按顺序排列的交易日期列表
    """
    return _DATES_LIST.copy()  # 返回副本以防止外部修改
