"""Package to compute shape distance between edge profiles."""

__all__ = [
    "get_sample_path",
]

from .samples import get_sample_path
