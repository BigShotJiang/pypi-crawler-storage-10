from arrowbit.ext.runtime import Environment

class Cog:
    def __init__(self, env: Environment):
        self.env = env

    def setup(self):
        raise NotImplementedError("A setup() method must be defined")

def load_cog(cog: Cog):
    if not issubclass(type(cog), Cog):
        raise TypeError(f"Expected a Cog object, got {type(Cog).__name__}.")

    cog.setup()