"""Decorator for handleing events."""
from .roombase import RoomBase

event = RoomBase.event
