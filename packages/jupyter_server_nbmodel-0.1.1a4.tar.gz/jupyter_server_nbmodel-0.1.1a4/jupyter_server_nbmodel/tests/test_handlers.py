# Copyright (c) 2024-2025 Datalayer, Inc.
#
# Distributed under the terms of the Modified BSD License.

import asyncio
import datetime
import json
import re
import nbformat

import pytest
from jupyter_client.kernelspec import NATIVE_KERNEL_NAME
from jupyter_client.asynchronous.client import AsyncKernelClient
from jupyter_server_nbmodel.models import PendingInput
from jupyter_server_nbmodel.actions import kernel_worker

TEST_TIMEOUT = 15

SLEEP = 0.25


REQUEST_REGEX = re.compile(r"^/api/kernels/\w+-\w+-\w+-\w+-\w+/requests/\w+-\w+-\w+-\w+-\w+$")
ANSI_REGEX = re.compile("\x1b\\[(.*?)([@-~])")


def strip_ansi(text: str):
    return ANSI_REGEX.sub("", text)


async def _wait_request(fetch, endpoint: str):
    """Poll periodically to fetch the execution request result."""
    start_time = datetime.datetime.now()
    elapsed = 0.0
    while elapsed < 0.9 * TEST_TIMEOUT:
        await asyncio.sleep(SLEEP)
        response = await fetch(endpoint, raise_error=False)
        if response.code >= 400:
            response.rethrow()
        if response.code != 202:
            return response

        elapsed = (datetime.datetime.now() - start_time).total_seconds()

    raise TimeoutError(f"Request {endpoint} timed out ({elapsed}s).")


async def wait_for_request(fetch, *args, **kwargs):
    """Wait for execution request."""
    r = await fetch(*args, **kwargs)
    assert r.code == 202
    location = r.headers["Location"]
    assert REQUEST_REGEX.match(location) is not None

    ans = await _wait_request(fetch, location)
    return ans


@pytest.fixture()
def pending_kernel_is_ready(jp_serverapp):
    async def _(kernel_id, ready=None):
        km = jp_serverapp.kernel_manager
        if getattr(km, "use_pending_kernels", False):
            kernel = km.get_kernel(kernel_id)
            if getattr(kernel, "ready", None):
                new_ready = kernel.ready
                # Make sure we get a new ready promise (for a restart)
                while new_ready == ready:
                    await asyncio.sleep(0.1)
                if not isinstance(new_ready, asyncio.Future):
                    new_ready = asyncio.wrap_future(new_ready)
                await new_ready
                return new_ready

    return _


@pytest.fixture()
def rtc_test_notebook(jp_serverapp, rtc_create_notebook):
    async def _(notebook, path="test.ipynb"):
        nb_content = nbformat.writes(notebook, version=4)
        returned_path, _ = await rtc_create_notebook(path, nb_content, store=True)
        assert path == returned_path
        document_id = get_document_id(jp_serverapp, "test.ipynb")
        return document_id
    return _


def get_document_id(jp_serverapp, notebook_name):
    fim = jp_serverapp.web_app.settings["file_id_manager"]
    document_id = f'json:notebook:{fim.get_id(notebook_name)}'
    return document_id


@pytest.mark.timeout(TEST_TIMEOUT)
@pytest.mark.parametrize(
    "snippet,output",
    (
        (
            "print('hello buddy')",
            '{"output_type": "stream", "name": "stdout", "text": "hello buddy\\n"}',
        ),
    ),
)
async def test_post_execute_no_ycell(jp_fetch, pending_kernel_is_ready, snippet, output):
    r = await jp_fetch(
        "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
    )
    kernel = json.loads(r.body.decode())
    await pending_kernel_is_ready(kernel["id"])

    response = await wait_for_request(
        jp_fetch,
        "api",
        "kernels",
        kernel["id"],
        "execute",
        method="POST",
        body=json.dumps({"code": snippet}),
    )

    assert response.code == 200
    payload = json.loads(response.body)
    assert payload == {
        "status": "ok",
        "execution_count": 1,
        "outputs": f"[{output}]",
    }

    response2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
    assert response2.code == 204

    await asyncio.sleep(1)


@pytest.mark.timeout(2 * TEST_TIMEOUT)
@pytest.mark.parametrize(
    "snippet,output",
    (
        (
            "print('hello buddy')",
            '{"output_type": "stream", "name": "stdout", "text": ["hello buddy"]}',
        ),
        ("a = 1", ""),
        (
            """from IPython.display import HTML
HTML('<p><b>Jupyter</b> rocks.</p>')""",
            '{"output_type": "execute_result", "metadata": {}, "data": {"text/plain": "<IPython.core.display.HTML object>", "text/html": "<p><b>Jupyter</b> rocks.</p>"}, "execution_count": 1}',  # noqa: E501
        ),
        (
          "display('a'); print('b')",
          (
            '{"output_type": "display_data", "metadata": {}, "data": {"text/plain": "\'a\'"}}'
            ', {"output_type": "stream", "name": "stdout", "text": ["b"]}'
          )
        )
    ),
)
async def test_post_execute_wiht_ycell(jp_fetch, pending_kernel_is_ready, snippet, output, rtc_test_notebook):
    r = await jp_fetch(
        "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
    )
    kernel = json.loads(r.body.decode())
    await pending_kernel_is_ready(kernel["id"])

    nb = nbformat.v4.new_notebook(
        cells=[nbformat.v4.new_code_cell(source=snippet)]
    )
    document_id = await rtc_test_notebook(nb)
    cell_id = nb["cells"][0]["id"]

    response = await wait_for_request(
        jp_fetch,
        "api",
        "kernels",
        kernel["id"],
        "execute",
        method="POST",
        body=json.dumps({
            "code": snippet,
            "metadata": {
                "cell_id": cell_id,
                "document_id": document_id
            }
        }),
    )

    assert response.code == 200
    payload = json.loads(response.body)
    assert payload == {
        "status": "ok",
        "execution_count": 1,
        "outputs": f"[{output}]",
    }

    response2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
    assert response2.code == 204

    await asyncio.sleep(1)


@pytest.mark.timeout(TEST_TIMEOUT)
@pytest.mark.parametrize(
    "snippet,output",
    (
        (
            "1 / 0",
            {
                "output_type": "error",
                "ename": "ZeroDivisionError",
                "evalue": "division by zero",
                "traceback": [
                    "---------------------------------------------------------------------------",
                    "ZeroDivisionError                         Traceback (most recent call last)",
                    "Cell In[1], line 1\n----> 1 1 / 0\n",
                    "ZeroDivisionError: division by zero"
                ]
            },
        ),
    ),
)
async def test_post_erroneous_execute(jp_fetch, pending_kernel_is_ready, snippet, output):
    # Start the first kernel
    r = await jp_fetch(
        "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
    )
    kernel = json.loads(r.body.decode())
    await pending_kernel_is_ready(kernel["id"])

    response = await wait_for_request(
        jp_fetch,
        "api",
        "kernels",
        kernel["id"],
        "execute",
        method="POST",
        body=json.dumps({"code": snippet}),
    )

    assert response.code == 200
    payload = json.loads(response.body)
    outputs = payload["outputs"]
    del payload["outputs"]
    assert payload == {
        "status": "error",
        "execution_count": 1
    }
    outputs = json.loads(outputs)
    for output in outputs:
        output["traceback"] = [
            strip_ansi(line)
            for line in output["traceback"]
        ]

    assert outputs == [output]

    response2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
    assert response2.code == 204

    await asyncio.sleep(1)


@pytest.mark.asyncio
async def test_kernel_worker_reports_error(monkeypatch):
    # Patch _execute_snippet to raise an error
    async def fake_execute(client, ydoc, snippet, metadata, stdin_hook):
        raise RuntimeError("simulated failure")
    monkeypatch.setattr(
        "jupyter_server_nbmodel.actions._execute_snippet",
        fake_execute,
    )

    queue = asyncio.Queue()
    results = {}
    pending_input = PendingInput()

    uid = "test-uid"
    snippet = "print('won't run')"
    metadata = {"foo": "bar"}
    await queue.put((uid, snippet, metadata))

    client = AsyncKernelClient()
    ydoc = None

    worker_task = asyncio.create_task(
        kernel_worker("kernel-id", client, ydoc, queue, results, pending_input)
    )

    await asyncio.sleep(0.05)

    # The worker will hit RuntimeError
    with pytest.raises(RuntimeError) as excinfo:
        await worker_task

    assert "simulated failure" in str(excinfo.value)

    assert uid in results, "kernel_worker should have recorded an entry for our uid"
    assert isinstance(results[uid], dict)
    assert "error" in results[uid], f"Expected an 'error' key in results[{uid!r}]"
    assert "simulated failure" in results[uid]["error"]


@pytest.mark.timeout(TEST_TIMEOUT)
async def test_execution_timing_metadata(jp_root_dir, jp_fetch, pending_kernel_is_ready, rtc_test_notebook, jp_serverapp):
    snippet = "a = 1"
    nb = nbformat.v4.new_notebook(
        cells=[nbformat.v4.new_code_cell(source=snippet, execution_count=1)]
    )
    path = "test.ipynb"
    document_id = await rtc_test_notebook(nb, path=path)
    collaboration = jp_serverapp.web_app.settings["jupyter_server_ydoc"]
    cell_id = nb["cells"][0]["id"]

    r = await jp_fetch(
        "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
    )
    kernel = json.loads(r.body.decode())
    await pending_kernel_is_ready(kernel["id"])

    response = await wait_for_request(
        jp_fetch,
        "api",
        "kernels",
        kernel["id"],
        "execute",
        method="POST",
        body=json.dumps({
            "code": snippet,
            "metadata": {
                "cell_id": cell_id,
                "document_id": document_id,
                "record_timing": True
            }
        }),
    )
    assert response.code == 200

    document = await collaboration.get_document(
        path=path, content_type="notebook", file_format="json", copy=False
    )
    cell_data = document.get()["cells"][0]
    assert 'execution' in cell_data['metadata'], "'execution' does not exist in 'metadata'"

    # Assert that start and end time exist in 'execution'
    execution = cell_data['metadata']['execution']
    assert 'shell.execute_reply.started' in execution, "'shell.execute_reply.started' does not exist in 'execution'"
    assert 'shell.execute_reply' in execution, "'shell.execute_reply' does not exist in 'execution'"

    started_time = execution['shell.execute_reply.started']
    reply_time = execution['shell.execute_reply']

    started_dt = datetime.datetime.fromisoformat(started_time)
    reply_dt = datetime.datetime.fromisoformat(reply_time)

    # Assert that reply_time is greater than started_time
    assert reply_dt > started_dt, "The reply time is not greater than the started time."
    response2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
    assert response2.code == 204
    await asyncio.sleep(1)


@pytest.mark.timeout(TEST_TIMEOUT)
async def test_post_input_execute(jp_fetch, pending_kernel_is_ready):
    # Start the first kernel
    r = await jp_fetch(
        "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
    )
    kernel = json.loads(r.body.decode())
    await pending_kernel_is_ready(kernel["id"])

    response = await jp_fetch(
        "api",
        "kernels",
        kernel["id"],
        "execute",
        method="POST",
        body=json.dumps({"code": "input('Age:')"}),
    )
    assert response.code == 202
    location = response.headers["Location"]

    response2 = await _wait_request(jp_fetch, location)

    assert response2.code == 300
    payload = json.loads(response2.body)
    assert "parent_header" in payload
    assert payload["input_request"] == {"prompt": "Age:", "password": False}

    response3 = await jp_fetch(
        "api", "kernels", kernel["id"], "input", method="POST", body=json.dumps({"input": "42"})
    )
    assert response3.code == 201

    response4 = await _wait_request(jp_fetch, location)
    assert response4.code == 200
    payload2 = json.loads(response4.body)
    assert payload2 == {
        "status": "ok",
        "execution_count": 1,
        "outputs": '[{"output_type": "execute_result", "metadata": {}, "data": {"text/plain": "\'42\'"}, "execution_count": 1}]',  # noqa: E501
    }

    r2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
    assert r2.code == 204

    await asyncio.sleep(1)


# FIXME
# @pytest.mark.timeout(TEST_TIMEOUT)
# async def test_cancel_execute(jp_fetch, pending_kernel_is_ready):
#     # Start the first kernel
#     r = await jp_fetch(
#         "api", "kernels", method="POST", body=json.dumps({"name": NATIVE_KERNEL_NAME})
#     )
#     kernel = json.loads(r.body.decode())
#     await pending_kernel_is_ready(kernel["id"])

#     response = await jp_fetch(
#         "api",
#         "kernels",
#         kernel["id"],
#         "execute",
#         method="POST",
#         body=json.dumps({"code": """import time
# time.sleep(10)
# print("end")
# """}),
#     )

#     assert response.code == 202
#     location = response.headers["Location"]

#     # Cancel task
#     response2 = await jp_fetch(location, method="DELETE")

#     assert response2.code == 204

#     response3 = await jp_fetch(location)
#     payload = json.loads(response3.body)
#     assert payload == {
#         "status": "error",
#         "execution_count": 1
#     }

#     r2 = await jp_fetch("api", "kernels", kernel["id"], method="DELETE")
#     assert r2.code == 204
