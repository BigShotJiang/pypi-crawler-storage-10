"""
Word文档排版工具函数

仅保留一个核心功能：为指定级别标题（Heading 1-9）统一设置样式。
"""

import os
import re
from typing import Optional
from .utils import (
    ensure_docx_extension,
    check_file_writeable,
)


async def style_heading(
    filename: str,
    level: int,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    color: Optional[str] = None,
    font_size: Optional[int] = None,
    font_name: Optional[str] = None,
    align: Optional[str] = None,
    spacing_before: Optional[int] = None,
    spacing_after: Optional[int] = None,
    add_numbering: Optional[bool] = None,
    numbering_separator: Optional[str] = None,
    numbering_suffix: Optional[str] = None,
    remove_numbering: Optional[bool] = None,
    remove_all_levels: Optional[bool] = None,
) -> str:
    """为指定级别标题样式（Heading 1-9）应用格式。

    说明：此操作会直接修改文档内对应的样式对象（如 "Heading 1"），从而使所有使用该样式的段落统一更新。
    """
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    filename = ensure_docx_extension(filename)

    # 校验参数类型
    try:
        level = int(level)
        if font_size is not None:
            font_size = int(font_size)
        if spacing_before is not None:
            spacing_before = int(spacing_before)
        if spacing_after is not None:
            spacing_after = int(spacing_after)
    except (ValueError, TypeError):
        raise ValueError("Invalid parameter: level/font_size/spacing_before/spacing_after must be integers")

    if level < 1 or level > 9:
        raise ValueError("Heading level must be between 1 and 9")

    if not os.path.exists(filename):
        raise FileNotFoundError(f"Document {filename} does not exist")

    # 可写性检查
    is_writeable, error_message = check_file_writeable(filename)
    if not is_writeable:
        raise PermissionError(f"Cannot modify document: {error_message}. Consider creating a copy first.")

    # 颜色映射与解析
    def parse_color(value: str):
        color_map = {
            'red': RGBColor(255, 0, 0),
            'blue': RGBColor(0, 0, 255),
            'green': RGBColor(0, 128, 0),
            'black': RGBColor(0, 0, 0),
            'white': RGBColor(255, 255, 255),
            'yellow': RGBColor(255, 255, 0),
            'orange': RGBColor(255, 165, 0),
            'purple': RGBColor(128, 0, 128),
            'gray': RGBColor(128, 128, 128),
            'grey': RGBColor(128, 128, 128),
        }
        if not value:
            return None
        try:
            v = value.strip()
            if v.lower() in color_map:
                return color_map[v.lower()]
            # hex like #RRGGBB or RRGGBB
            if v.startswith('#'):
                v = v[1:]
            if len(v) == 6:
                r = int(v[0:2], 16)
                g = int(v[2:4], 16)
                b = int(v[4:6], 16)
                return RGBColor(r, g, b)
        except Exception:
            pass
        return None

    try:
        try:
            doc = Document(filename)
        except Exception as open_error:
            try:
                from docx.opc.exceptions import PackageNotFoundError
            except Exception:
                PackageNotFoundError = tuple()  # type: ignore
            if isinstance(open_error, PackageNotFoundError):
                raise RuntimeError(
                    f"The file is not a valid .docx package or is corrupted: {os.path.abspath(filename)}. "
                    "Please ensure the document is a real .docx (not .doc) and not open/locked in another app."
                )
            raise

        style_name = f"Heading {level}"
        # 若样式不存在，直接抛错，避免创建非预期样式名
        try:
            heading_style = doc.styles[style_name]
        except KeyError:
            raise ValueError(f"Style '{style_name}' not found in document. Please ensure headings use built-in styles.")

        font = heading_style.font
        pf = heading_style.paragraph_format

        if bold is not None:
            font.bold = bold
        if italic is not None:
            font.italic = italic
        if underline is not None:
            font.underline = underline
        if font_size is not None and font_size > 0:
            font.size = Pt(font_size)
        if font_name:
            font.name = font_name
        if color:
            rgb = parse_color(color)
            if rgb is not None:
                font.color.rgb = rgb

        if align:
            al = align.strip().lower()
            if al == 'left':
                pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
            elif al == 'center':
                pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif al == 'right':
                pf.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif al == 'justify':
                pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            else:
                raise ValueError("Invalid align value. Use left/center/right/justify")

        if spacing_before is not None and spacing_before >= 0:
            pf.space_before = Pt(spacing_before)
        if spacing_after is not None and spacing_after >= 0:
            pf.space_after = Pt(spacing_after)

        # 仅移除编号（优先级最高）
        if remove_numbering:
            # 支持常见模式："1 ", "1.", "1. ", "1)", "1- ", 多级如 "1.2.3 " 等
            try:
                _sep = numbering_separator if (isinstance(numbering_separator, str) and numbering_separator) else "."
                import re as _re
                # 开头可能有空白；数字+（.或-或)）可重复；可带自定义分隔符；最后跟一个可选的 .|)|- 再跟空格
                _pat = _re.compile(r"^\s*\d+(?:" + _re.escape(_sep) + r"\d+)*(?:[\.|\)|\-])?\s+")
            except Exception:
                _pat = None

            for para in doc.paragraphs:
                try:
                    style_n = para.style.name if para.style else ""
                except Exception:
                    style_n = ""
                if style_n.startswith("Heading "):
                    try:
                        lvl = int(style_n.split()[-1])
                    except Exception:
                        continue
                    # 若 remove_all_levels 为真，则所有级别都移除；否则仅移除目标 level
                    if remove_all_levels or lvl == level:
                        if _pat is not None:
                            para.text = _pat.sub("", para.text or "")
            # 若仅移除，不再添加编号
        # 自动编号（多级）
        elif add_numbering:
            sep = numbering_separator if (isinstance(numbering_separator, str) and numbering_separator) else "."
            suffix = numbering_suffix if (isinstance(numbering_suffix, str)) else " "
            counters = [0] * 9
            # 识别并去除已有编号前缀，避免重复编号
            num_pattern = None
            try:
                import re as _re
                num_pattern = _re.compile(r"^\s*\d+(?:" + _re.escape(sep) + r"\d+)*(?:[\.|\)|\-])?\s+")
            except Exception:
                num_pattern = None

            for para in doc.paragraphs:
                try:
                    style_n = para.style.name if para.style else ""
                except Exception:
                    style_n = ""
                if style_n.startswith("Heading "):
                    try:
                        lvl = int(style_n.split()[-1])
                    except Exception:
                        continue
                    if 1 <= lvl <= 9:
                        # 更新计数器以保持层级关系（即便不改该级文本）
                        counters[lvl - 1] += 1
                        for i in range(lvl, 9):
                            counters[i] = 0
                        # 仅当当前段落级别等于目标 level 时，才写入编号前缀
                        if lvl == level:
                            parts = [str(counters[i]) for i in range(lvl) if counters[i] > 0]
                            num_str = sep.join(parts)
                            base_text = para.text or ""
                            if num_pattern is not None:
                                base_text = num_pattern.sub("", base_text)
                            new_text = f"{num_str}{suffix}{base_text}".strip()
                            para.text = new_text

        doc.save(filename)
        return f"Styled '{style_name}' successfully."
    except Exception as e:
        raise RuntimeError(f"Failed to style heading: {str(e)}")
