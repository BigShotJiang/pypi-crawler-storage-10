# libnvfatbin

A useful Python package with utility functions.

## Installation

```bash
pip install libnvfatbin
```

## Usage

```python
import libnvfatbin

print(libnvfatbin.hello_world())
result = libnvfatbin.add_numbers(5, 3)
print(result)
```
