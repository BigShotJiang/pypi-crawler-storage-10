# cuda-version

A useful Python package with utility functions.

## Installation

```bash
pip install cuda-version
```

## Usage

```python
import cuda-version

print(cuda-version.hello_world())
result = cuda-version.add_numbers(5, 3)
print(result)
```
