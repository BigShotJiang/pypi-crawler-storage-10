""" Expose version """

__version__ = "0.6.2"
VERSION = __version__.split(".")
