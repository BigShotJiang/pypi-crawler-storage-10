# coding: utf-8
__all__ = []
__version__ = "2025.10.25"

default_app_config = "common.apps.CommonConfig"
