# test_server_pytest.py
import pytest
import sys
import os

sys.path.append(os.path.dirname(__file__))

from server import query_welcome_speech
from server import query_weather


@pytest.mark.asyncio
async def test_query_welcome_speech():
    """测试欢迎语查询工具"""
    # 测试正常情况
    result = await query_welcome_speech("CHAT", 123)
    assert isinstance(result, str)
    print(f"测试结果: {result}")

@pytest.mark.asyncio
async def test_query_weather():
    """测试欢迎语查询工具"""
    # 测试正常情况
    result = await query_weather("dali")
    assert isinstance(result, str)
    print(f"测试结果: {result}")


@pytest.mark.asyncio
async def test_multiple_cases():
    """测试多个用例"""
    test_cases = [
        ("greeting", "user_001"),
        ("welcome", "user_002"),
        ("introduction", "user_003"),
    ]

    for intention, user_id in test_cases:
        result = await query_welcome_speech(intention, user_id)
        assert result is not None
        print(f"意图: {intention}, 用户: {user_id} -> 结果: {result}")


if __name__ == "__main__":
    # 直接运行 pytest
    import pytest

    pytest.main([__file__, "-v", "-s"])