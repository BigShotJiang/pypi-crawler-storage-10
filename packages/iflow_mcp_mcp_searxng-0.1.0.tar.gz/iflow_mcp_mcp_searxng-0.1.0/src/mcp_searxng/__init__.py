import asyncio
from .main import run

def main() -> None:
    asyncio.run(run())