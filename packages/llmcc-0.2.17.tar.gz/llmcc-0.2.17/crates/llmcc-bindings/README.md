# llmcc Python Bindings

This package provides the Python bindings for the `llmcc` project, which offers a language-model oriented context compiler for code and documents.

See the main project documentation for full details:

- Project repository: https://github.com/allenanswerzq/llmcc
- Documentation: https://github.com/allenanswerzq/llmcc#readme
