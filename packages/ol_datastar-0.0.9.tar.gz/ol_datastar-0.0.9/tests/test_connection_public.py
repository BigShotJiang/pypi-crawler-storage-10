from __future__ import annotations

from typing import Any, Dict, List
from unittest.mock import MagicMock

import pytest

from datastar.connection import Connection
from datastar.connections.delimited_connection import DelimitedConnection
from datastar.project import Project


@pytest.fixture
def conn_api(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    api = MagicMock()
    # Create/update/delete
    api.create_connection.return_value = "conn-1"
    api.update_connection.return_value = None
    api.delete_connection.return_value = None
    # Collections
    api.get_connectors.return_value = {
        "items": [
            {"id": "c1", "name": "A", "type": "dsv"},
            {"id": "c2", "name": "B", "type": "optidb"},
        ]
    }
    # Patch Connection._api to return this mock
    monkeypatch.setattr(Connection, "_api", classmethod(lambda cls: api))
    return api


def test_get_collections_and_filter(conn_api: MagicMock):
    all_names = Connection.get_collections()
    assert all_names == ["A", "B"]
    only_dsv = Connection.get_collections(connector_type="dsv")
    assert only_dsv == ["A"]


def test_delimited_connection_persist_save_delete(conn_api: MagicMock):
    c = DelimitedConnection(path="/tmp/file.csv", name="DSV1", description="Desc")
    assert c.id == "conn-1"
    c.description = "Updated"
    c.save()
    conn_api.update_connection.assert_called_once()
    c.delete()
    conn_api.delete_connection.assert_called_once_with("conn-1")


def test_project_get_sandbox_uses_special_id(api: MagicMock):
    # Reuse the project fixture’s api monkeypatch from conftest for Project
    p = Project(name="SandboxProj")
    sb = p.get_sandbox()
    from datastar.datastar_api import DatastarAPI

    assert sb.id == DatastarAPI.SANDBOX_CONNECTOR_ID

