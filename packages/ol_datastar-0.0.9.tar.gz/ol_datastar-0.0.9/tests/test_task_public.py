from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

from datastar.tasks.task_import import ImportTask


class ConnStub:
    def __init__(self, id_value: str) -> None:
        self.id = id_value


def test_task_save_and_update_flow(macro, api, tmp_path: Path):
    src, dst = ConnStub("src-1"), ConnStub("dst-1")

    # Build without persistence first
    t = ImportTask(
        macro,
        name="Imp",
        description="d",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
        persist=False,
    )
    assert not t.is_persisted()

    # Persist via save; should call create_task
    t.save()
    api.create_task.assert_called()
    assert t.is_persisted()

    # Save again; should call update_task
    t.description = "updated"
    t.save()
    api.update_task.assert_called()


def test_task_delete_calls_api(macro, api):
    src, dst = ConnStub("src-2"), ConnStub("dst-2")
    t = macro.add_import_task(
        name="ToDelete",
        description="",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
    )
    t.delete()
    api.delete_task.assert_called_with(macro.project._id, t._id)


def test_export_to_file_writes_json(macro, api, tmp_path: Path):
    src, dst = ConnStub("src-3"), ConnStub("dst-3")
    t = ImportTask(
        macro,
        name="ExportMe",
        description="",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
        persist=False,
    )
    out = t.export_to_file(folder=str(tmp_path))
    p = Path(out)
    assert p.exists()
    # Simple content check
    data = p.read_text(encoding="utf-8")
    assert "\"taskType\": \"import\"" in data


def test_get_and_remove_dependencies(macro, api):
    src, dst = ConnStub("src-4"), ConnStub("dst-4")
    first = macro.add_import_task(
        name="First",
        description="",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
    )
    second = macro.add_import_task(
        name="Second",
        description="",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
    )

    # Ensure task name lookup can resolve ids -> names
    def get_tasks(project_id: str, macro_id: str):
        return {
            "items": [
                {"id": "start-1", "name": "Start", "taskType": "start", "workflowId": macro_id, "configuration": {}},
                {"id": first._id, "name": "First", "taskType": "import", "workflowId": macro_id, "configuration": {}},
                {"id": second._id, "name": "Second", "taskType": "import", "workflowId": macro_id, "configuration": {}},
            ]
        }
    api.get_tasks.side_effect = get_tasks

    # Simulate an existing dependency from second -> first
    api.get_task_dependencies.return_value = {
        "items": [
            {
                "id": "dep-1",
                "name": "First",
                "dependencyTaskId": first._id,
            }
        ]
    }

    names = second.get_dependencies()
    assert names == ["First"]

    # Remove by name should call delete_task_dependency with dep id
    second.remove_dependency("First")
    api.delete_task_dependency.assert_called_with(macro.project._id, "dep-1")

    # Add by name: ensure our lookup returns an id that we interpret as the previous task id
    api.get_task_dependencies.return_value = {
        "items": [
            {
                "id": first._id,  # treated as dependency task id by our test harness
                "name": "First",
                "dependencyTaskId": first._id,
            }
        ]
    }
    second.add_dependency("First")
    api.create_task_dependency.assert_called_with(macro.project._id, second._id, first._id)
