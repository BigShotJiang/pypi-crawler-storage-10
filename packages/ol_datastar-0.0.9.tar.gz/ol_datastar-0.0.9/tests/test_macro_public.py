from __future__ import annotations

from typing import Any, Dict

from datastar.tasks.task_import import ImportTask
from datastar.tasks.task_export import ExportTask


class ConnStub:
    def __init__(self, id_value: str) -> None:
        self.id = id_value


def test_add_import_task_persists_and_auto_joins(macro, api):
    src, dst = ConnStub("src-1"), ConnStub("dst-1")

    t = macro.add_import_task(
        name="Imp",
        description="desc",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
    )

    assert isinstance(t, ImportTask)
    api.create_task.assert_called_once()
    api.create_task_dependency.assert_called_once_with(macro.project._id, "task-1", "start-1")


def test_add_import_task_no_auto_join(macro, api):
    src, dst = ConnStub("src-2"), ConnStub("dst-2")

    macro.add_import_task(
        name="Imp2",
        description="",
        source_connection=src,
        destination_connection=dst,
        source_table="s",
        destination_table="d",
        auto_join=False,
    )

    api.create_task.assert_called_once()
    api.create_task_dependency.assert_not_called()


def test_get_task_returns_correct_subclass(macro, api, monkeypatch):
    def get_tasks(project_id: str, macro_id: str) -> Dict[str, Any]:
        return {
            "items": [
                {
                    "id": "start-1",
                    "name": "Start",
                    "description": "",
                    "taskType": "start",
                    "workflowId": macro_id,
                    "configuration": {},
                },
                {
                    "id": "t1",
                    "name": "Exp",
                    "description": "d",
                    "taskType": "export",
                    "workflowId": macro_id,
                    "configuration": {
                        "source": {"connectorId": "s", "table": ""},
                        "destination": {"type": "file", "fileName": "out.csv"},
                    },
                },
            ]
        }

    api.get_tasks.side_effect = get_tasks

    task = macro.get_task("Exp")
    assert isinstance(task, ExportTask)
    assert task.is_persisted()


def test_delete_task_invokes_api(macro, api):
    def get_tasks(project_id: str, macro_id: str) -> Dict[str, Any]:
        return {
            "items": [
                {
                    "id": "start-1",
                    "name": "Start",
                    "description": "",
                    "taskType": "start",
                    "workflowId": macro_id,
                    "configuration": {},
                },
                {
                    "id": "sql-1",
                    "name": "SQL",
                    "description": "",
                    "taskType": "runsql",
                    "workflowId": macro_id,
                    "configuration": {"query": "select 1", "target": {"connectorId": "c"}},
                },
            ]
        }

    api.get_tasks.side_effect = get_tasks

    macro.delete_task("SQL")
    api.delete_task.assert_called_once_with(macro.project._id, "sql-1")


def test_get_tasks_filtering(macro, api):
    # Return an export task so filtering yields it by name
    def get_tasks(project_id: str, macro_id: str) -> Dict[str, Any]:
        return {
            "items": [
                {
                    "id": "start-1",
                    "name": "Start",
                    "description": "",
                    "taskType": "start",
                    "workflowId": macro_id,
                    "configuration": {},
                },
                {
                    "id": "e1",
                    "name": "E1",
                    "description": "",
                    "taskType": "export",
                    "workflowId": macro_id,
                    "configuration": {
                        "source": {"connectorId": "s", "table": "t"},
                        "destination": {"type": "file", "fileName": "out.csv"},
                    },
                },
            ]
        }

    api.get_tasks.side_effect = get_tasks

    names = macro.get_tasks(type_filter="export")
    assert "E1" in names


def test_run_and_wait_for_done(macro, api):
    run_id = macro.run({"x": 1})
    assert run_id == "run-1"
    macro.wait_for_done(run_id)
    api.execute_macro.assert_called_once()
    assert api.get_macro_run.call_count >= 1
