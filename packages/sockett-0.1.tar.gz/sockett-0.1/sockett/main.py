import socket as socket_module

class socket:
    socket = socket_module.socket