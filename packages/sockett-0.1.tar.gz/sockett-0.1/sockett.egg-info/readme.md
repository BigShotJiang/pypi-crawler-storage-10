# Sockett

Socket modülü için basit ve kullanışlı bir wrapper.

## Kurulum
```bash
pip install sockett
```

## Özellikler

- Standart Python `socket` modülünün tüm özelliklerini içerir
- Kolay ve anlaşılır kullanım
- TCP/IP socket programlama için idealdir

## Kullanım

### Basit Sunucu Örneği
```python
import sockett

# Sunucu oluştur
server = sockett.socket.socket()
server.bind(("0.0.0.0", 5000))
server.listen(1)

print("Bağlantı Bekleniyor...")
baglanti, adres = server.accept()
print("Bağlandı:", adres)

while True:
    # Mesaj al
    mesaj = baglanti.recv(1024).decode('utf-8')
    print("Gelen Mesaj:", mesaj)
    
    if mesaj == "exit":
        break
    
    # Cevap gönder
    cevap = input("Kullanıcı1: ")
    baglanti.send(cevap.encode("utf-8"))
    
    if cevap == "exit":
        break

baglanti.close()
server.close()
```

### Basit İstemci Örneği
```python
import sockett

# İstemci oluştur
client = sockett.socket.socket()
client.connect(("localhost", 5000))

while True:
    # Mesaj gönder
    mesaj = input("Kullanıcı2: ")
    client.send(mesaj.encode("utf-8"))
    
    if mesaj == "exit":
        break
    
    # Cevap al
    cevap = client.recv(1024).decode('utf-8')
    print("Gelen Mesaj:", cevap)
    
    if cevap == "exit":
        break

client.close()
```

## Gereksinimler

- Python 3.6 veya üzeri

## Lisans

MIT License

## Katkıda Bulunma

Pull request'ler memnuniyetle karşılanır. Büyük değişiklikler için lütfen önce bir issue açın.

## Destek

Sorularınız için issue açabilirsiniz.

## Yazar

[Özgür Özen]

## Değişiklik Geçmişi

### 0.1.0 (2025-10-29)
- İlk sürüm
- Temel socket wrapper fonksiyonalitesi