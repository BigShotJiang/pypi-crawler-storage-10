# libgfortran5

A useful Python package with utility functions.

## Installation

```bash
pip install libgfortran5
```

## Usage

```python
import libgfortran5

print(libgfortran5.hello_world())
result = libgfortran5.add_numbers(5, 3)
print(result)
```
