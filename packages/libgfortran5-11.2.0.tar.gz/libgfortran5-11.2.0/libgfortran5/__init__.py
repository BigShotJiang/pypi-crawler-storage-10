"""
libgfortran5 - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libgfortran5!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libgfortran5",
        "version": "11.2.0",
        "description": "A useful Python package"
    }

# Package version
__version__ = "11.2.0"
