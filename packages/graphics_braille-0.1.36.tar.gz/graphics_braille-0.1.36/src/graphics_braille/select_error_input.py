# select_error_input.py


class SelectErrorInput(Exception):
    """ Input conversion error
    """
    pass
