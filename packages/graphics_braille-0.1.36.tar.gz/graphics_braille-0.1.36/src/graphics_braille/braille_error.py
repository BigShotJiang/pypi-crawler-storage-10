# braille_error.py    15Feb2023  crs, Author

class BrailleError(Exception):
    """Base class for exceptions in this module."""
    pass
