# select_fail.py

class SelectFail(Exception):
    """Base class for testing failures."""
    pass
