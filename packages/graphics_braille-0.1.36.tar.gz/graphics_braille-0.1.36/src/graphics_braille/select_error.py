# select_error.py

class SelectError(Exception):
    """Base class for exceptions in this module."""
    pass
