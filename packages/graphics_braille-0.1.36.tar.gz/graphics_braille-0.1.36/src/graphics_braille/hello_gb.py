#hello_gb.py   09Oct2025  crs, just a hello
print(f"hello from {__file__}")
def echo(msg):
    print(f"msg: {msg}")