"""Model-related common components."""
