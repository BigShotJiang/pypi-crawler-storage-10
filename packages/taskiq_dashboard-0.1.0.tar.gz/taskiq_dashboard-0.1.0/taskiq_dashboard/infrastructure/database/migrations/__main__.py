from taskiq_dashboard.infrastructure.database.migrations import main


if __name__ == '__main__':
    main()
