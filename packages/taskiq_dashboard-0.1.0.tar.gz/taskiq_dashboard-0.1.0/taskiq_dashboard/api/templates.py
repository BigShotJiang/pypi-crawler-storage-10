from fastapi.templating import Jinja2Templates


jinja_templates = Jinja2Templates(directory='taskiq_dashboard/api/templates')
