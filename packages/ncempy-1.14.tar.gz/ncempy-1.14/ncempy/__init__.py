""" ncempy

"""

from . import algo
from . import io
from . import eval
from . import viz

from .io import read
from .viz import plot