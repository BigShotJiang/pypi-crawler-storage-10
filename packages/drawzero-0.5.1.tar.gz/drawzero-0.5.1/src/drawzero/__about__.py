__all__ = [
    "__version__",
    "__license__",
    "__author__",
    "__copyright__",
]

__version__ = '0.5.1'
__author__ = "Sergey Shashkov"
__license__ = "MIT"
__copyright__ = "Copyright 2020- Sergey Shashkov"
