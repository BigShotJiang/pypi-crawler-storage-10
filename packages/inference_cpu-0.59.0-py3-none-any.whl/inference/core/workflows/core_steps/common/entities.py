from enum import Enum


class StepExecutionMode(Enum):
    LOCAL = "local"
    REMOTE = "remote"
