---
title: API reference
hide:
- navigation
---

# ::: mlflow_oidc_auth_groups_plugin_adfs
