# mlflow-oidc-auth-groups-plugin-adfs

[![ci](https://github.com/kenr-authpm/mlflow-oidc-auth-groups-plugin-adfs/workflows/ci/badge.svg)](https://github.com/kenr-authpm/mlflow-oidc-auth-groups-plugin-adfs/actions?query=workflow%3Aci)
[![documentation](https://img.shields.io/badge/docs-mkdocs-708FCC.svg?style=flat)](https://kenr-authpm.github.io/mlflow-oidc-auth-groups-plugin-adfs/)
[![pypi version](https://img.shields.io/pypi/v/mlflow-oidc-auth-groups-plugin-adfs.svg)](https://pypi.org/project/mlflow-oidc-auth-groups-plugin-adfs/)
[![gitter](https://img.shields.io/badge/matrix-chat-4DB798.svg?style=flat)](https://app.gitter.im/#/room/#mlflow-oidc-auth-groups-plugin-adfs:gitter.im)



## Installation

```bash
pip install mlflow-oidc-auth-groups-plugin-adfs
```

With [`uv`](https://docs.astral.sh/uv/):

```bash
uv tool install mlflow-oidc-auth-groups-plugin-adfs
```
