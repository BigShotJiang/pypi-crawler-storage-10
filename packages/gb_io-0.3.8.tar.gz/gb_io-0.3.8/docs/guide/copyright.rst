Copyright Notice
================

``gb-io``
---------

The ``gb-io`` library is developed under the MIT license:

.. literalinclude:: ../../COPYING 


Additional libraries
--------------------

This package may vendor the source of several additional packages that are
licensed under the `Apache-2.0 <https://choosealicense.com/licenses/apache-2.0/>`_,
`MIT <https://choosealicense.com/licenses/mit/>`_ or
`BSD-3-Clause <https://choosealicense.com/licenses/bsd-3-clause/>`_ licenses;
see the license file distributed with the source copy of each vendored
dependency for more information.