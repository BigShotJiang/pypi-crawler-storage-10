Reader
======

.. currentmodule:: gb_io

.. autoclass:: gb_io.RecordReader
   :special-members: __init__, __iter__, __next__
   :members:

