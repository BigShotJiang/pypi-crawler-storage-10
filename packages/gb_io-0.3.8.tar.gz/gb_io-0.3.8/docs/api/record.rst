Record
======

.. currentmodule:: gb_io


.. autoclass:: gb_io.Record
   :special-members: __init__
   :members:
