Source
======

.. currentmodule:: gb_io


.. autoclass:: gb_io.Source
   :special-members: __init__
   :members:
