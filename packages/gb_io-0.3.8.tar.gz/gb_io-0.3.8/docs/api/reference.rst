Reference
=========

.. currentmodule:: gb_io


.. autoclass:: gb_io.Reference
   :special-members: __init__
   :members:
