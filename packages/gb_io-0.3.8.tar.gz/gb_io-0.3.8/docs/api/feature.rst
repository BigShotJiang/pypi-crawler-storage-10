Feature
=======

.. currentmodule:: gb_io


.. autoclass:: gb_io.Feature
   :special-members: __init__
   :members:
