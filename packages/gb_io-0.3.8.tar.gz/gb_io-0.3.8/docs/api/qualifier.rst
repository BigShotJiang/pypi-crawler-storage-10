Qualifier
=========

.. currentmodule:: gb_io


.. autoclass:: gb_io.Qualifier
   :special-members: __init__
   :members:
