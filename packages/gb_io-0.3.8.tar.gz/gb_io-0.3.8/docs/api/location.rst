Location
=========

.. currentmodule:: gb_io


Location
^^^^^^^^

.. autoclass:: gb_io.Location
   :special-members: __init__
   :members:


Between
^^^^^^^

.. autoclass:: gb_io.Between
   :special-members: __init__
   :members:


Bond
^^^^

.. autoclass:: gb_io.Bond
   :special-members: __init__
   :members:


Complement
^^^^^^^^^^

.. autoclass:: gb_io.Complement
   :special-members: __init__
   :members:


External
^^^^^^^^

.. autoclass:: gb_io.External
   :special-members: __init__
   :members:


Join
^^^^

.. autoclass:: gb_io.Join
   :special-members: __init__
   :members:


OneOf
^^^^^

.. autoclass:: gb_io.OneOf
   :special-members: __init__
   :members:


Order
^^^^^

.. autoclass:: gb_io.Order
   :special-members: __init__
   :members:


Range
^^^^^

.. autoclass:: gb_io.Range
   :special-members: __init__
   :members: