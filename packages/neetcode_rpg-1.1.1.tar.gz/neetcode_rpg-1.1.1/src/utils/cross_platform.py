"""
Cross-platform compatibility utilities for Windows/Linux/Mac support
Handles Unicode, emoji, and terminal encoding issues
"""

import os
import sys
import platform
from typing import Dict, Optional


class CrossPlatformDisplay:
    """Handles cross-platform display compatibility"""
    
    def __init__(self):
        self.is_windows = platform.system() == "Windows"
        self.supports_unicode = self._check_unicode_support()
        self.emoji_map = self._create_emoji_fallbacks()
        self.unicode_chars = self._create_unicode_fallbacks()
        
        # Try to enable UTF-8 on Windows
        if self.is_windows:
            self._setup_windows_unicode()
    
    def _check_unicode_support(self) -> bool:
        """Check if terminal supports Unicode characters"""
        try:
            # Test if we can encode/decode Unicode
            test_char = "█"
            test_char.encode('utf-8')
            
            # Check if stdout supports UTF-8
            if hasattr(sys.stdout, 'encoding'):
                encoding = sys.stdout.encoding or 'ascii'
                return 'utf' in encoding.lower()
            
            return not self.is_windows  # Assume Unix-like systems support Unicode
        except:
            return False
    
    def _setup_windows_unicode(self):
        """Setup Unicode support on Windows"""
        try:
            # Try to set console to UTF-8 mode
            if hasattr(sys.stdout, 'reconfigure'):
                sys.stdout.reconfigure(encoding='utf-8')
            if hasattr(sys.stderr, 'reconfigure'):
                sys.stderr.reconfigure(encoding='utf-8')
            
            # Set console code page to UTF-8 on Windows
            os.system('chcp 65001 >nul 2>&1')
        except:
            pass
    
    def _create_emoji_fallbacks(self) -> Dict[str, str]:
        """Create ASCII fallbacks for emojis"""
        return {
            # Level titles
            "🌱": "[Seedling]",
            "🚀": "[Rocket]", 
            "⚔️": "[Sword]",
            "🧙♂️": "[Wizard]",
            "🏆": "[Trophy]",
            "👑": "[Crown]",
            "🌟": "[Star]",
            "🔥": "[Fire]",
            "💎": "[Diamond]",
            "🎯": "[Target]",
            "🌌": "[Galaxy]",
            
            # Status indicators
            "✅": "[OK]",
            "❌": "[X]",
            "⚠️": "[!]",
            "💡": "[i]",
            "📚": "[Book]",
            "⚡": "[Lightning]",
            "🎮": "[Game]",
            "📊": "[Chart]",
            "📈": "[Up]",
            "📅": "[Cal]",
            "🎓": "[Grad]",
            "🏅": "[Medal]",
            "💰": "[Money]",
            "✨": "[Sparkle]",
            "🔍": "[Search]",
            "👤": "[User]",
            "📄": "[Doc]",
            "⭐": "[Star]",
            "🎉": "[Party]",
            "💪": "[Strong]",
            "🎨": "[Art]",
            "🛠️": "[Tools]",
            "📋": "[List]",
            "🌅": "[Dawn]",
            "🎪": "[Circus]",
        }
    
    def _create_unicode_fallbacks(self) -> Dict[str, str]:
        """Create ASCII fallbacks for Unicode box drawing characters"""
        return {
            # Progress bar characters
            "█": "#",
            "░": "-",
            "▓": "=",
            "▒": ":",
            
            # Box drawing
            "╔": "+",
            "╗": "+", 
            "╚": "+",
            "╝": "+",
            "║": "|",
            "═": "=",
            "╠": "+",
            "╣": "+",
            "╦": "+",
            "╩": "+",
            "╬": "+",
            
            # Simple box drawing
            "┌": "+",
            "┐": "+",
            "└": "+", 
            "┘": "+",
            "│": "|",
            "─": "-",
            "├": "+",
            "┤": "+",
            "┬": "+",
            "┴": "+",
            "┼": "+",
        }
    
    def format_text(self, text: str) -> str:
        """Convert text to be compatible with current platform"""
        if self.supports_unicode:
            return text
        
        # Replace emojis with ASCII alternatives
        result = text
        for emoji, fallback in self.emoji_map.items():
            result = result.replace(emoji, fallback)
        
        # Replace Unicode box drawing characters
        for unicode_char, fallback in self.unicode_chars.items():
            result = result.replace(unicode_char, fallback)
        
        return result
    
    def create_progress_bar(self, progress: float, width: int = 20) -> str:
        """Create a cross-platform progress bar"""
        filled = int(width * progress)
        
        if self.supports_unicode:
            return "█" * filled + "░" * (width - filled)
        else:
            return "#" * filled + "-" * (width - filled)
    
    def get_level_title(self, level: int) -> str:
        """Get level title with proper platform formatting"""
        titles = {
            1: "🌱 Coding Seedling",
            5: "🚀 Algorithm Apprentice", 
            10: "⚔️ Data Structure Warrior",
            15: "🧙♂️ Code Wizard",
            20: "🏆 Algorithm Master",
            25: "👑 DSA Champion",
            30: "🌟 Legendary Coder",
            40: "🔥 Mythical Programmer",
            50: "💎 Diamond Developer",
            75: "🌌 Cosmic Coder",
            100: "🎯 NeetCode Deity"
        }
        
        # Find the appropriate title for the level
        title = "🌱 Coding Seedling"  # Default
        for level_threshold in sorted(titles.keys(), reverse=True):
            if level >= level_threshold:
                title = titles[level_threshold]
                break
        
        return self.format_text(title)


# Global instance
display = CrossPlatformDisplay()
