from __future__ import annotations
from typing import Any

from nervels.document import NLSDocument
from nervels.nodes import ColorNode

class NLSCompiler:
    def __init__(self, document: NLSDocument) -> None:
        self.document: NLSDocument = document

    def compile(self) -> tuple[str, str, list[str], str, str]:
        large_logo: str = "\n".join(self.document.get_section("large"))
        small_logo: str = "\n".join(self.document.get_section("small"))
        colors: list[str] = self.document.get_section("colors")

        title_color: str = self._get_property_value(key="title", default="AnsiColor.White")
        keys_color:  str = self._get_property_value(key="keys", default="AnsiColor.White")

        return large_logo, small_logo, colors, title_color, keys_color

    def _get_property_value(self, key: str, default: str) -> str:
        value: Any = self.document.get_property(key)
        return value.value if isinstance(value, ColorNode) else (value or default)
