"""
Pydantic models for cluster API endpoints.

This module contains auto-generated Pydantic v2 models for request and response
validation in the cluster API endpoints.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..base.types import ProxmoxNode, ProxmoxVMID


class ClusterGETResponse(BaseModel):
    """
    Response model for /cluster GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ReplicationGETResponse(BaseModel):
    """
    Response model for /cluster/replication GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ReplicationPOSTRequest(BaseModel):
    """
    Request model for /cluster/replication POST
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable/deactivate the entry.\u0027",
    )
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    rate: float | str | None = Field(
        ge=1.0,
        description="\u0027Rate limit in mbps (megabytes per second) as floating point number.\u0027",
    )
    remove_job: Literal["full", "local"] | None = Field(
        description="\"Mark the replication job for removal. The job will remove all local replication snapshots. When set to \u0027full\u0027, it also tries to remove replicated volumes on the target. The job then removes itself from the configuration file.\"",
    )
    schedule: str | None = Field(
        default="*/15",
        max_length=128,
        description="\u0027Storage replication schedule. The format is a subset of `systemd` calendar events.\u0027",
    )
    source: ProxmoxNode | None = Field(
        description="\u0027For internal use, to detect if the guest was stolen.\u0027",
    )
    target: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    type: Literal["local"] = Field(
        description="\u0027Section type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Replication_IdDELETERequest(BaseModel):
    """
    Request model for /cluster/replication/{id} DELETE
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Will remove the jobconfig entry, but will not cleanup.\u0027",
    )
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    keep: bool | int | str | None = Field(
        default=0,
        description="\u0027Keep replicated data at target (do not remove).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Replication_IdGETRequest(BaseModel):
    """
    Request model for /cluster/replication/{id} GET
    """
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Replication_IdGETResponse(BaseModel):
    """
    Response model for /cluster/replication/{id} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Replication_IdPUTRequest(BaseModel):
    """
    Request model for /cluster/replication/{id} PUT
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable/deactivate the entry.\u0027",
    )
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    rate: float | str | None = Field(
        ge=1.0,
        description="\u0027Rate limit in mbps (megabytes per second) as floating point number.\u0027",
    )
    remove_job: Literal["full", "local"] | None = Field(
        description="\"Mark the replication job for removal. The job will remove all local replication snapshots. When set to \u0027full\u0027, it also tries to remove replicated volumes on the target. The job then removes itself from the configuration file.\"",
    )
    schedule: str | None = Field(
        default="*/15",
        max_length=128,
        description="\u0027Storage replication schedule. The format is a subset of `systemd` calendar events.\u0027",
    )
    source: ProxmoxNode | None = Field(
        description="\u0027For internal use, to detect if the guest was stolen.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_MetricsGETResponse(BaseModel):
    """
    Response model for /cluster/metrics GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_ServerGETResponse(BaseModel):
    """
    Response model for /cluster/metrics/server GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_Server_IdDELETERequest(BaseModel):
    """
    Request model for /cluster/metrics/server/{id} DELETE
    """
    id: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_Server_IdGETRequest(BaseModel):
    """
    Request model for /cluster/metrics/server/{id} GET
    """
    id: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_Server_IdGETResponse(BaseModel):
    """
    Response model for /cluster/metrics/server/{id} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_Server_IdPOSTRequest(BaseModel):
    """
    Request model for /cluster/metrics/server/{id} POST
    """
    api_path_prefix: str | None = Field(
        description="\"An API path prefix inserted between \u0027\u003chost\u003e:\u003cport\u003e/\u0027 and \u0027/api2/\u0027. Can be useful if the InfluxDB service runs behind a reverse proxy.\"",
    )
    bucket: str | None = Field(
        description="\u0027The InfluxDB bucket/db. Only necessary when using the http v2 api.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the plugin.\u0027",
    )
    id: str = Field(
        description="\u0027The ID of the entry.\u0027",
    )
    influxdbproto: Literal["http", "https", "udp"] | None = Field(
        default="udp",
    )
    max_body_size: int | str | None = Field(
        default=25000000,
        ge=1,
        description="\u0027InfluxDB max-body-size in bytes. Requests are batched up to this size.\u0027",
    )
    mtu: int | str | None = Field(
        default=1500,
        ge=512,
        le=65536,
        description="\u0027MTU for metrics transmission over UDP\u0027",
    )
    organization: str | None = Field(
        description="\u0027The InfluxDB organization. Only necessary when using the http v2 api. Has no meaning when using v2 compatibility api.\u0027",
    )
    path: str | None = Field(
        description="\u0027root graphite path (ex: proxmox.mycluster.mykey)\u0027",
    )
    port: int | str = Field(
        ge=1,
        le=65536,
        description="\u0027server network port\u0027",
    )
    proto: Literal["tcp", "udp"] | None = Field(
        description="\u0027Protocol to send graphite data. TCP or UDP (default)\u0027",
    )
    server: str = Field(
        description="\u0027server dns name or IP address\u0027",
    )
    timeout: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027graphite TCP socket timeout (default=1)\u0027",
    )
    token: str | None = Field(
        description="\"The InfluxDB access token. Only necessary when using the http v2 api. If the v2 compatibility api is used, use \u0027user:password\u0027 instead.\"",
    )
    type: Literal["graphite", "influxdb"] = Field(
        description="\u0027Plugin type.\u0027",
    )
    verify_certificate: bool | int | str | None = Field(
        default=1,
        description="\u0027Set to 0 to disable certificate verification for https endpoints.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Metrics_Server_IdPUTRequest(BaseModel):
    """
    Request model for /cluster/metrics/server/{id} PUT
    """
    api_path_prefix: str | None = Field(
        description="\"An API path prefix inserted between \u0027\u003chost\u003e:\u003cport\u003e/\u0027 and \u0027/api2/\u0027. Can be useful if the InfluxDB service runs behind a reverse proxy.\"",
    )
    bucket: str | None = Field(
        description="\u0027The InfluxDB bucket/db. Only necessary when using the http v2 api.\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the plugin.\u0027",
    )
    id: str = Field(
        description="\u0027The ID of the entry.\u0027",
    )
    influxdbproto: Literal["http", "https", "udp"] | None = Field(
        default="udp",
    )
    max_body_size: int | str | None = Field(
        default=25000000,
        ge=1,
        description="\u0027InfluxDB max-body-size in bytes. Requests are batched up to this size.\u0027",
    )
    mtu: int | str | None = Field(
        default=1500,
        ge=512,
        le=65536,
        description="\u0027MTU for metrics transmission over UDP\u0027",
    )
    organization: str | None = Field(
        description="\u0027The InfluxDB organization. Only necessary when using the http v2 api. Has no meaning when using v2 compatibility api.\u0027",
    )
    path: str | None = Field(
        description="\u0027root graphite path (ex: proxmox.mycluster.mykey)\u0027",
    )
    port: int | str = Field(
        ge=1,
        le=65536,
        description="\u0027server network port\u0027",
    )
    proto: Literal["tcp", "udp"] | None = Field(
        description="\u0027Protocol to send graphite data. TCP or UDP (default)\u0027",
    )
    server: str = Field(
        description="\u0027server dns name or IP address\u0027",
    )
    timeout: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027graphite TCP socket timeout (default=1)\u0027",
    )
    token: str | None = Field(
        description="\"The InfluxDB access token. Only necessary when using the http v2 api. If the v2 compatibility api is used, use \u0027user:password\u0027 instead.\"",
    )
    verify_certificate: bool | int | str | None = Field(
        default=1,
        description="\u0027Set to 0 to disable certificate verification for https endpoints.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ConfigGETResponse(BaseModel):
    """
    Response model for /cluster/config GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ConfigPOSTRequest(BaseModel):
    """
    Request model for /cluster/config POST
    """
    clustername: ProxmoxNode = Field(
        max_length=15,
        description="\u0027The name of the cluster.\u0027",
    )
    link_n_: str | None = Field(
        description="\u0027Address and priority information of a single corosync link. (up to 8 links supported; link0..link7)\u0027",
    )
    nodeid: int | str | None = Field(
        ge=1,
        description="\u0027Node id for this node.\u0027",
    )
    votes: int | str | None = Field(
        ge=1,
        description="\u0027Number of votes for this node.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ConfigPOSTResponse(BaseModel):
    """
    Response model for /cluster/config POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_ApiversionGETResponse(BaseModel):
    """
    Response model for /cluster/config/apiversion GET
    """
    data: int | str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_NodesGETResponse(BaseModel):
    """
    Response model for /cluster/config/nodes GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_Nodes_NodeDELETERequest(BaseModel):
    """
    Request model for /cluster/config/nodes/{node} DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_Nodes_NodePOSTRequest(BaseModel):
    """
    Request model for /cluster/config/nodes/{node} POST
    """
    apiversion: int | str | None = Field(
        description="\u0027The JOIN_API_VERSION of the new node.\u0027",
    )
    force: bool | int | str | None = Field(
        description="\u0027Do not throw error if node already exists.\u0027",
    )
    link_n_: str | None = Field(
        description="\u0027Address and priority information of a single corosync link. (up to 8 links supported; link0..link7)\u0027",
    )
    new_node_ip: str | None = Field(
        description="\u0027IP Address of node to add. Used as fallback if no links are given.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nodeid: int | str | None = Field(
        ge=1,
        description="\u0027Node id for this node.\u0027",
    )
    votes: int | str | None = Field(
        ge=0,
        description="\u0027Number of votes for this node\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_Nodes_NodePOSTResponse(BaseModel):
    """
    Response model for /cluster/config/nodes/{node} POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_JoinGETRequest(BaseModel):
    """
    Request model for /cluster/config/join GET
    """
    node: ProxmoxNode | None = Field(
        default="current connected node",
        description="\u0027The node for which the joinee gets the nodeinfo. \u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_JoinGETResponse(BaseModel):
    """
    Response model for /cluster/config/join GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_JoinPOSTRequest(BaseModel):
    """
    Request model for /cluster/config/join POST
    """
    fingerprint: str = Field(
        description="\u0027Certificate SHA 256 fingerprint.\u0027",
    )
    force: bool | int | str | None = Field(
        description="\u0027Do not throw error if node already exists.\u0027",
    )
    hostname: str = Field(
        description="\u0027Hostname (or IP) of an existing cluster member.\u0027",
    )
    link_n_: str | None = Field(
        description="\u0027Address and priority information of a single corosync link. (up to 8 links supported; link0..link7)\u0027",
    )
    nodeid: int | str | None = Field(
        ge=1,
        description="\u0027Node id for this node.\u0027",
    )
    password: str = Field(
        max_length=128,
        description="\u0027Superuser (root) password of peer node.\u0027",
    )
    votes: int | str | None = Field(
        ge=0,
        description="\u0027Number of votes for this node\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_JoinPOSTResponse(BaseModel):
    """
    Response model for /cluster/config/join POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_TotemGETResponse(BaseModel):
    """
    Response model for /cluster/config/totem GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Config_QdeviceGETResponse(BaseModel):
    """
    Response model for /cluster/config/qdevice GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_FirewallGETResponse(BaseModel):
    """
    Response model for /cluster/firewall GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_GroupsGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/groups GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_GroupsPOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/groups POST
    """
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )
    rename: str | None = Field(
        max_length=18,
        description="\"Rename/update an existing security group. You can set \u0027rename\u0027 to the same value as \u0027name\u0027 to update the \u0027comment\u0027 of an existing group.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_GroupDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group} DELETE
    """
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_GroupGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group} GET
    """
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_GroupGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/groups/{group} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_GroupPOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group} POST
    """
    action: str = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_Group_PosDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group}/{pos} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_Group_PosGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group}/{pos} GET
    """
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_Group_PosGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/groups/{group}/{pos} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Groups_Group_PosPUTRequest(BaseModel):
    """
    Request model for /cluster/firewall/groups/{group}/{pos} PUT
    """
    action: str | None = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    group: str = Field(
        max_length=18,
        description="\u0027Security Group name.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    moveto: int | str | None = Field(
        ge=0,
        description="\u0027Move rule to new position \u003cmoveto\u003e. Other arguments are ignored.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] | None = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_RulesGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/rules GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_RulesPOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/rules POST
    """
    action: str = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Rules_PosDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/rules/{pos} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Rules_PosGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/rules/{pos} GET
    """
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Rules_PosGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/rules/{pos} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Rules_PosPUTRequest(BaseModel):
    """
    Request model for /cluster/firewall/rules/{pos} PUT
    """
    action: str | None = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    moveto: int | str | None = Field(
        ge=0,
        description="\u0027Move rule to new position \u003cmoveto\u003e. Other arguments are ignored.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] | None = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_IpsetGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/ipset GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_IpsetPOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset POST
    """
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\"Rename an existing IPSet. You can set \u0027rename\u0027 to the same value as \u0027name\u0027 to update the \u0027comment\u0027 of an existing IPSet.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_NameDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name} DELETE
    """
    force: bool | int | str | None = Field(
        description="\u0027Delete all members of the IPSet, if there are any.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_NameGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_NameGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/ipset/{name} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_NamePOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name} POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_Name_CidrDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name}/{cidr} DELETE
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_Name_CidrGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name}/{cidr} GET
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_Name_CidrGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/ipset/{name}/{cidr} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Ipset_Name_CidrPUTRequest(BaseModel):
    """
    Request model for /cluster/firewall/ipset/{name}/{cidr} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_AliasesGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/aliases GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_AliasesPOSTRequest(BaseModel):
    """
    Request model for /cluster/firewall/aliases POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Aliases_NameDELETERequest(BaseModel):
    """
    Request model for /cluster/firewall/aliases/{name} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Aliases_NameGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/aliases/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Aliases_NameGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/aliases/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_Aliases_NamePUTRequest(BaseModel):
    """
    Request model for /cluster/firewall/aliases/{name} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\u0027Rename an existing alias.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_OptionsGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/options GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_OptionsPUTRequest(BaseModel):
    """
    Request model for /cluster/firewall/options PUT
    """
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    ebtables: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable ebtables rules cluster wide.\u0027",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Enable or disable the firewall cluster wide.\u0027",
    )
    log_ratelimit: str | None = Field(
        description="\u0027Log ratelimiting settings\u0027",
    )
    policy_in: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Input policy.\u0027",
    )
    policy_out: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Output policy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_MacrosGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/macros GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_RefsGETRequest(BaseModel):
    """
    Request model for /cluster/firewall/refs GET
    """
    type: Literal["alias", "ipset"] | None = Field(
        description="\u0027Only list references of specified type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Firewall_RefsGETResponse(BaseModel):
    """
    Response model for /cluster/firewall/refs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_BackupGETResponse(BaseModel):
    """
    Response model for /cluster/backup GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_BackupPOSTRequest(BaseModel):
    """
    Request model for /cluster/backup POST
    """
    all: bool | int | str | None = Field(
        default=0,
        description="\u0027Backup all known guest systems on this host.\u0027",
    )
    bwlimit: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Limit I/O bandwidth (KBytes per second).\u0027",
    )
    comment: str | None = Field(
        max_length=512,
        description="\u0027Description for the Job.\u0027",
    )
    compress: Literal["0", "1", "gzip", "lzo", "zstd"] | None = Field(
        default="0",
        description="\u0027Compress dump file.\u0027",
    )
    dow: str | None = Field(
        default="mon,tue,wed,thu,fri,sat,sun",
        description="\u0027Day of week selection.\u0027",
    )
    dumpdir: str | None = Field(
        description="\u0027Store resulting files to specified directory.\u0027",
    )
    enabled: bool | int | str | None = Field(
        default="1",
        description="\u0027Enable or disable the job.\u0027",
    )
    exclude: list[ProxmoxVMID] | None = Field(
        description="\u0027Exclude specified guest systems (assumes --all)\u0027",
    )
    exclude_path: str | None = Field(
        description="\"Exclude certain files/directories (shell globs). Paths starting with \u0027/\u0027 are anchored to the container\u0027s root,  other paths match relative to each subdirectory.\"",
    )
    id: str | None = Field(
        description="\u0027Job ID (will be autogenerated).\u0027",
    )
    ionice: int | str | None = Field(
        default=7,
        ge=0,
        le=8,
        description="\u0027Set CFQ ionice priority.\u0027",
    )
    lockwait: int | str | None = Field(
        default=180,
        ge=0,
        description="\u0027Maximal time to wait for the global lock (minutes).\u0027",
    )
    mailnotification: Literal["always", "failure"] | None = Field(
        default="always",
        description="\u0027Specify when to send an email\u0027",
    )
    mailto: str | None = Field(
        description="\u0027Comma-separated list of email addresses or users that should receive email notifications.\u0027",
    )
    maxfiles: int | str | None = Field(
        ge=1,
        description="\"Deprecated: use \u0027prune-backups\u0027 instead. Maximal number of backup files per guest system.\"",
    )
    mode: Literal["snapshot", "stop", "suspend"] | None = Field(
        default="snapshot",
        description="\u0027Backup mode.\u0027",
    )
    node: ProxmoxNode | None = Field(
        description="\u0027Only run if executed on this node.\u0027",
    )
    notes_template: str | None = Field(
        max_length=1024,
        description="\"Template string for generating notes for the backup(s). It can contain variables which will be replaced by their values. Currently supported are {{cluster}}, {{guestname}}, {{node}}, and {{vmid}}, but more might be added in the future. Needs to be a single line, newline and backslash need to be escaped as \u0027\\\\n\u0027 and \u0027\\\\\\\\\u0027 respectively.\"",
    )
    performance: str | None = Field(
        description="\u0027Other performance-related settings.\u0027",
    )
    pigz: int | str | None = Field(
        default=0,
        description="\u0027Use pigz instead of gzip when N\u003e0. N=1 uses half of cores, N\u003e1 uses N as thread count.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Backup all known guest systems included in the specified pool.\u0027",
    )
    protected: bool | int | str | None = Field(
        description="\u0027If true, mark backup(s) as protected.\u0027",
    )
    prune_backups: str | None = Field(
        default="keep-all=1",
        description="\u0027Use these retention options instead of those from the storage configuration.\u0027",
    )
    quiet: bool | int | str | None = Field(
        default=0,
        description="\u0027Be quiet.\u0027",
    )
    remove: bool | int | str | None = Field(
        default=1,
        description="\"Prune older backups according to \u0027prune-backups\u0027.\"",
    )
    repeat_missed: bool | int | str | None = Field(
        default=0,
        description="\u0027If true, the job will be run as soon as possible if it was missed while the scheduler was not running.\u0027",
    )
    schedule: str | None = Field(
        max_length=128,
        description="\u0027Backup schedule. The format is a subset of `systemd` calendar events.\u0027",
    )
    script: str | None = Field(
        description="\u0027Use specified hook script.\u0027",
    )
    starttime: str | None = Field(
        description="\u0027Job Start time.\u0027",
    )
    stdexcludes: bool | int | str | None = Field(
        default=1,
        description="\u0027Exclude temporary files and logs.\u0027",
    )
    stop: bool | int | str | None = Field(
        default=0,
        description="\u0027Stop running backup jobs on this host.\u0027",
    )
    stopwait: int | str | None = Field(
        default=10,
        ge=0,
        description="\u0027Maximal time to wait until a guest system is stopped (minutes).\u0027",
    )
    storage: str | None = Field(
        description="\u0027Store resulting file to this storage.\u0027",
    )
    tmpdir: str | None = Field(
        description="\u0027Store temporary files to specified directory.\u0027",
    )
    vmid: list[ProxmoxVMID] | None = Field(
        description="\u0027The ID of the guest system you want to backup.\u0027",
    )
    zstd: int | str | None = Field(
        default=1,
        description="\u0027Zstd threads. N=0 uses half of the available cores, N\u003e0 uses N as thread count.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_IdDELETERequest(BaseModel):
    """
    Request model for /cluster/backup/{id} DELETE
    """
    id: str = Field(
        max_length=50,
        description="\u0027The job ID.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_IdGETRequest(BaseModel):
    """
    Request model for /cluster/backup/{id} GET
    """
    id: str = Field(
        max_length=50,
        description="\u0027The job ID.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_IdGETResponse(BaseModel):
    """
    Response model for /cluster/backup/{id} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_IdPUTRequest(BaseModel):
    """
    Request model for /cluster/backup/{id} PUT
    """
    all: bool | int | str | None = Field(
        default=0,
        description="\u0027Backup all known guest systems on this host.\u0027",
    )
    bwlimit: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Limit I/O bandwidth (KBytes per second).\u0027",
    )
    comment: str | None = Field(
        max_length=512,
        description="\u0027Description for the Job.\u0027",
    )
    compress: Literal["0", "1", "gzip", "lzo", "zstd"] | None = Field(
        default="0",
        description="\u0027Compress dump file.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dow: str | None = Field(
        description="\u0027Day of week selection.\u0027",
    )
    dumpdir: str | None = Field(
        description="\u0027Store resulting files to specified directory.\u0027",
    )
    enabled: bool | int | str | None = Field(
        default="1",
        description="\u0027Enable or disable the job.\u0027",
    )
    exclude: list[ProxmoxVMID] | None = Field(
        description="\u0027Exclude specified guest systems (assumes --all)\u0027",
    )
    exclude_path: str | None = Field(
        description="\"Exclude certain files/directories (shell globs). Paths starting with \u0027/\u0027 are anchored to the container\u0027s root,  other paths match relative to each subdirectory.\"",
    )
    id: str = Field(
        max_length=50,
        description="\u0027The job ID.\u0027",
    )
    ionice: int | str | None = Field(
        default=7,
        ge=0,
        le=8,
        description="\u0027Set CFQ ionice priority.\u0027",
    )
    lockwait: int | str | None = Field(
        default=180,
        ge=0,
        description="\u0027Maximal time to wait for the global lock (minutes).\u0027",
    )
    mailnotification: Literal["always", "failure"] | None = Field(
        default="always",
        description="\u0027Specify when to send an email\u0027",
    )
    mailto: str | None = Field(
        description="\u0027Comma-separated list of email addresses or users that should receive email notifications.\u0027",
    )
    maxfiles: int | str | None = Field(
        ge=1,
        description="\"Deprecated: use \u0027prune-backups\u0027 instead. Maximal number of backup files per guest system.\"",
    )
    mode: Literal["snapshot", "stop", "suspend"] | None = Field(
        default="snapshot",
        description="\u0027Backup mode.\u0027",
    )
    node: ProxmoxNode | None = Field(
        description="\u0027Only run if executed on this node.\u0027",
    )
    notes_template: str | None = Field(
        max_length=1024,
        description="\"Template string for generating notes for the backup(s). It can contain variables which will be replaced by their values. Currently supported are {{cluster}}, {{guestname}}, {{node}}, and {{vmid}}, but more might be added in the future. Needs to be a single line, newline and backslash need to be escaped as \u0027\\\\n\u0027 and \u0027\\\\\\\\\u0027 respectively.\"",
    )
    performance: str | None = Field(
        description="\u0027Other performance-related settings.\u0027",
    )
    pigz: int | str | None = Field(
        default=0,
        description="\u0027Use pigz instead of gzip when N\u003e0. N=1 uses half of cores, N\u003e1 uses N as thread count.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Backup all known guest systems included in the specified pool.\u0027",
    )
    protected: bool | int | str | None = Field(
        description="\u0027If true, mark backup(s) as protected.\u0027",
    )
    prune_backups: str | None = Field(
        default="keep-all=1",
        description="\u0027Use these retention options instead of those from the storage configuration.\u0027",
    )
    quiet: bool | int | str | None = Field(
        default=0,
        description="\u0027Be quiet.\u0027",
    )
    remove: bool | int | str | None = Field(
        default=1,
        description="\"Prune older backups according to \u0027prune-backups\u0027.\"",
    )
    repeat_missed: bool | int | str | None = Field(
        default=0,
        description="\u0027If true, the job will be run as soon as possible if it was missed while the scheduler was not running.\u0027",
    )
    schedule: str | None = Field(
        max_length=128,
        description="\u0027Backup schedule. The format is a subset of `systemd` calendar events.\u0027",
    )
    script: str | None = Field(
        description="\u0027Use specified hook script.\u0027",
    )
    starttime: str | None = Field(
        description="\u0027Job Start time.\u0027",
    )
    stdexcludes: bool | int | str | None = Field(
        default=1,
        description="\u0027Exclude temporary files and logs.\u0027",
    )
    stop: bool | int | str | None = Field(
        default=0,
        description="\u0027Stop running backup jobs on this host.\u0027",
    )
    stopwait: int | str | None = Field(
        default=10,
        ge=0,
        description="\u0027Maximal time to wait until a guest system is stopped (minutes).\u0027",
    )
    storage: str | None = Field(
        description="\u0027Store resulting file to this storage.\u0027",
    )
    tmpdir: str | None = Field(
        description="\u0027Store temporary files to specified directory.\u0027",
    )
    vmid: list[ProxmoxVMID] | None = Field(
        description="\u0027The ID of the guest system you want to backup.\u0027",
    )
    zstd: int | str | None = Field(
        default=1,
        description="\u0027Zstd threads. N=0 uses half of the available cores, N\u003e0 uses N as thread count.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_Id_Included_VolumesGETRequest(BaseModel):
    """
    Request model for /cluster/backup/{id}/included_volumes GET
    """
    id: str = Field(
        max_length=50,
        description="\u0027The job ID.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_Id_Included_VolumesGETResponse(BaseModel):
    """
    Response model for /cluster/backup/{id}/included_volumes GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_InfoGETResponse(BaseModel):
    """
    Response model for /cluster/backup-info GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Backup_Info_Not_Backed_UpGETResponse(BaseModel):
    """
    Response model for /cluster/backup-info/not-backed-up GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_HaGETResponse(BaseModel):
    """
    Response model for /cluster/ha GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_ResourcesGETRequest(BaseModel):
    """
    Request model for /cluster/ha/resources GET
    """
    type: Literal["ct", "vm"] | None = Field(
        description="\u0027Only list resources of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_ResourcesGETResponse(BaseModel):
    """
    Response model for /cluster/ha/resources GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_ResourcesPOSTRequest(BaseModel):
    """
    Request model for /cluster/ha/resources POST
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    group: str | None = Field(
        description="\u0027The HA group identifier.\u0027",
    )
    max_relocate: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027Maximal number of service relocate tries when a service failes to start.\u0027",
    )
    max_restart: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027Maximal number of tries to restart the service on a node after its start failed.\u0027",
    )
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )
    state: Literal["disabled", "enabled", "ignored", "started", "stopped"] | None = Field(
        default="started",
        description="\u0027Requested resource state.\u0027",
    )
    type: Literal["ct", "vm"] | None = Field(
        description="\u0027Resource type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_SidDELETERequest(BaseModel):
    """
    Request model for /cluster/ha/resources/{sid} DELETE
    """
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_SidGETRequest(BaseModel):
    """
    Request model for /cluster/ha/resources/{sid} GET
    """
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_SidGETResponse(BaseModel):
    """
    Response model for /cluster/ha/resources/{sid} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_SidPUTRequest(BaseModel):
    """
    Request model for /cluster/ha/resources/{sid} PUT
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    group: str | None = Field(
        description="\u0027The HA group identifier.\u0027",
    )
    max_relocate: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027Maximal number of service relocate tries when a service failes to start.\u0027",
    )
    max_restart: int | str | None = Field(
        default=1,
        ge=0,
        description="\u0027Maximal number of tries to restart the service on a node after its start failed.\u0027",
    )
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )
    state: Literal["disabled", "enabled", "ignored", "started", "stopped"] | None = Field(
        default="started",
        description="\u0027Requested resource state.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_Sid_MigratePOSTRequest(BaseModel):
    """
    Request model for /cluster/ha/resources/{sid}/migrate POST
    """
    node: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Resources_Sid_RelocatePOSTRequest(BaseModel):
    """
    Request model for /cluster/ha/resources/{sid}/relocate POST
    """
    node: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    sid: str = Field(
        description="\u0027HA resource ID. This consists of a resource type followed by a resource specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and containers, you can simply use the VM or CT id as a shortcut (example: 100).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_GroupsGETResponse(BaseModel):
    """
    Response model for /cluster/ha/groups GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_GroupsPOSTRequest(BaseModel):
    """
    Request model for /cluster/ha/groups POST
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    group: str = Field(
        description="\u0027The HA group identifier.\u0027",
    )
    nodes: str = Field(
        description="\u0027List of cluster node names with optional priority.\u0027",
    )
    nofailback: bool | int | str | None = Field(
        default=0,
        description="\u0027The CRM tries to run services on the node with the highest priority. If a node with higher priority comes online, the CRM migrates the service to that node. Enabling nofailback prevents that behavior.\u0027",
    )
    restricted: bool | int | str | None = Field(
        default=0,
        description="\u0027Resources bound to restricted groups may only run on nodes defined by the group.\u0027",
    )
    type: Literal["group"] | None = Field(
        description="\u0027Group type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Groups_GroupDELETERequest(BaseModel):
    """
    Request model for /cluster/ha/groups/{group} DELETE
    """
    group: str = Field(
        description="\u0027The HA group identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Groups_GroupGETRequest(BaseModel):
    """
    Request model for /cluster/ha/groups/{group} GET
    """
    group: str = Field(
        description="\u0027The HA group identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Groups_GroupGETResponse(BaseModel):
    """
    Response model for /cluster/ha/groups/{group} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Groups_GroupPUTRequest(BaseModel):
    """
    Request model for /cluster/ha/groups/{group} PUT
    """
    comment: str | None = Field(
        max_length=4096,
        description="\u0027Description.\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    group: str = Field(
        description="\u0027The HA group identifier.\u0027",
    )
    nodes: str | None = Field(
        description="\u0027List of cluster node names with optional priority.\u0027",
    )
    nofailback: bool | int | str | None = Field(
        default=0,
        description="\u0027The CRM tries to run services on the node with the highest priority. If a node with higher priority comes online, the CRM migrates the service to that node. Enabling nofailback prevents that behavior.\u0027",
    )
    restricted: bool | int | str | None = Field(
        default=0,
        description="\u0027Resources bound to restricted groups may only run on nodes defined by the group.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_StatusGETResponse(BaseModel):
    """
    Response model for /cluster/ha/status GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Status_CurrentGETResponse(BaseModel):
    """
    Response model for /cluster/ha/status/current GET
    """
    data: list[Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ha_Status_Manager_StatusGETResponse(BaseModel):
    """
    Response model for /cluster/ha/status/manager_status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_AcmeGETResponse(BaseModel):
    """
    Response model for /cluster/acme GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_PluginsGETRequest(BaseModel):
    """
    Request model for /cluster/acme/plugins GET
    """
    type: Literal["dns", "standalone"] | None = Field(
        description="\u0027Only list ACME plugins of a specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_PluginsGETResponse(BaseModel):
    """
    Response model for /cluster/acme/plugins GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_PluginsPOSTRequest(BaseModel):
    """
    Request model for /cluster/acme/plugins POST
    """
    api: str | None = Field(
        description="\u0027API plugin name\u0027",
    )
    data: str | None = Field(
        description="\u0027DNS plugin data. (base64 encoded)\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the config.\u0027",
    )
    id: str = Field(
        description="\u0027ACME Plugin ID name\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    type: Literal["dns", "standalone"] = Field(
        description="\u0027ACME challenge type.\u0027",
    )
    validation_delay: int | str | None = Field(
        default=30,
        ge=0,
        le=172800,
        description="\u0027Extra delay in seconds to wait before requesting validation. Allows to cope with a long TTL of DNS records.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Plugins_IdDELETERequest(BaseModel):
    """
    Request model for /cluster/acme/plugins/{id} DELETE
    """
    id: str = Field(
        description="\u0027Unique identifier for ACME plugin instance.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Plugins_IdGETRequest(BaseModel):
    """
    Request model for /cluster/acme/plugins/{id} GET
    """
    id: str = Field(
        description="\u0027Unique identifier for ACME plugin instance.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Plugins_IdGETResponse(BaseModel):
    """
    Response model for /cluster/acme/plugins/{id} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Plugins_IdPUTRequest(BaseModel):
    """
    Request model for /cluster/acme/plugins/{id} PUT
    """
    api: str | None = Field(
        description="\u0027API plugin name\u0027",
    )
    data: str | None = Field(
        description="\u0027DNS plugin data. (base64 encoded)\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the config.\u0027",
    )
    id: str = Field(
        description="\u0027ACME Plugin ID name\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    validation_delay: int | str | None = Field(
        default=30,
        ge=0,
        le=172800,
        description="\u0027Extra delay in seconds to wait before requesting validation. Allows to cope with a long TTL of DNS records.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_AccountGETResponse(BaseModel):
    """
    Response model for /cluster/acme/account GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_AccountPOSTRequest(BaseModel):
    """
    Request model for /cluster/acme/account POST
    """
    contact: str = Field(
        description="\u0027Contact email addresses.\u0027",
    )
    directory: str | None = Field(
        default="https://acme-v02.api.letsencrypt.org/directory",
        description="\u0027URL of ACME CA directory endpoint.\u0027",
    )
    name: str | None = Field(
        default="default",
        description="\u0027ACME account config file name.\u0027",
    )
    tos_url: str | None = Field(
        description="\u0027URL of CA TermsOfService - setting this indicates agreement.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_AccountPOSTResponse(BaseModel):
    """
    Response model for /cluster/acme/account POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NameDELETERequest(BaseModel):
    """
    Request model for /cluster/acme/account/{name} DELETE
    """
    name: str | None = Field(
        default="default",
        description="\u0027ACME account config file name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NameDELETEResponse(BaseModel):
    """
    Response model for /cluster/acme/account/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NameGETRequest(BaseModel):
    """
    Request model for /cluster/acme/account/{name} GET
    """
    name: str | None = Field(
        default="default",
        description="\u0027ACME account config file name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NameGETResponse(BaseModel):
    """
    Response model for /cluster/acme/account/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NamePUTRequest(BaseModel):
    """
    Request model for /cluster/acme/account/{name} PUT
    """
    contact: str | None = Field(
        description="\u0027Contact email addresses.\u0027",
    )
    name: str | None = Field(
        default="default",
        description="\u0027ACME account config file name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Account_NamePUTResponse(BaseModel):
    """
    Response model for /cluster/acme/account/{name} PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_TosGETRequest(BaseModel):
    """
    Request model for /cluster/acme/tos GET
    """
    directory: str | None = Field(
        default="https://acme-v02.api.letsencrypt.org/directory",
        description="\u0027URL of ACME CA directory endpoint.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_TosGETResponse(BaseModel):
    """
    Response model for /cluster/acme/tos GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_DirectoriesGETResponse(BaseModel):
    """
    Response model for /cluster/acme/directories GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Acme_Challenge_SchemaGETResponse(BaseModel):
    """
    Response model for /cluster/acme/challenge-schema GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_CephGETResponse(BaseModel):
    """
    Response model for /cluster/ceph GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_MetadataGETRequest(BaseModel):
    """
    Request model for /cluster/ceph/metadata GET
    """
    scope: Literal["all", "versions"] | None = Field(
        default="all",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_MetadataGETResponse(BaseModel):
    """
    Response model for /cluster/ceph/metadata GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_StatusGETResponse(BaseModel):
    """
    Response model for /cluster/ceph/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_FlagsGETResponse(BaseModel):
    """
    Response model for /cluster/ceph/flags GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_FlagsPUTRequest(BaseModel):
    """
    Request model for /cluster/ceph/flags PUT
    """
    nobackfill: bool | int | str | None = Field(
        description="\u0027Backfilling of PGs is suspended.\u0027",
    )
    nodeep_scrub: bool | int | str | None = Field(
        description="\u0027Deep Scrubbing is disabled.\u0027",
    )
    nodown: bool | int | str | None = Field(
        description="\u0027OSD failure reports are being ignored, such that the monitors will not mark OSDs down.\u0027",
    )
    noin: bool | int | str | None = Field(
        description="\u0027OSDs that were previously marked out will not be marked back in when they start.\u0027",
    )
    noout: bool | int | str | None = Field(
        description="\u0027OSDs will not automatically be marked out after the configured interval.\u0027",
    )
    norebalance: bool | int | str | None = Field(
        description="\u0027Rebalancing of PGs is suspended.\u0027",
    )
    norecover: bool | int | str | None = Field(
        description="\u0027Recovery of PGs is suspended.\u0027",
    )
    noscrub: bool | int | str | None = Field(
        description="\u0027Scrubbing is disabled.\u0027",
    )
    notieragent: bool | int | str | None = Field(
        description="\u0027Cache tiering activity is suspended.\u0027",
    )
    noup: bool | int | str | None = Field(
        description="\u0027OSDs are not allowed to start.\u0027",
    )
    pause: bool | int | str | None = Field(
        description="\u0027Pauses read and writes.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_FlagsPUTResponse(BaseModel):
    """
    Response model for /cluster/ceph/flags PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_Flags_FlagGETRequest(BaseModel):
    """
    Request model for /cluster/ceph/flags/{flag} GET
    """
    flag: str = Field(
        description="\u0027The name of the flag name to get.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_Flags_FlagGETResponse(BaseModel):
    """
    Response model for /cluster/ceph/flags/{flag} GET
    """
    data: bool | int | str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Ceph_Flags_FlagPUTRequest(BaseModel):
    """
    Request model for /cluster/ceph/flags/{flag} PUT
    """
    flag: str = Field(
        description="\u0027The ceph flag to update\u0027",
    )
    value: bool | int | str = Field(
        description="\u0027The new value of the flag\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_JobsGETResponse(BaseModel):
    """
    Response model for /cluster/jobs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Jobs_Schedule_AnalyzeGETRequest(BaseModel):
    """
    Request model for /cluster/jobs/schedule-analyze GET
    """
    iterations: int | str | None = Field(
        default=10,
        ge=1,
        le=100,
        description="\u0027Number of event-iteration to simulate and return.\u0027",
    )
    schedule: str = Field(
        max_length=128,
        description="\u0027Job schedule. The format is a subset of `systemd` calendar events.\u0027",
    )
    starttime: int | str | None = Field(
        description="\u0027UNIX timestamp to start the calculation from. Defaults to the current time.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Jobs_Schedule_AnalyzeGETResponse(BaseModel):
    """
    Response model for /cluster/jobs/schedule-analyze GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_SdnGETResponse(BaseModel):
    """
    Response model for /cluster/sdn GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_SdnPUTResponse(BaseModel):
    """
    Response model for /cluster/sdn PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_VnetsGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_VnetsGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/vnets GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_VnetsPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets POST
    """
    alias: str | None = Field(
        max_length=256,
        description="\u0027alias name of the vnet\u0027",
    )
    tag: int | str | None = Field(
        description="\u0027vlan or vxlan id\u0027",
    )
    type: Literal["vnet"] | None = Field(
        description="\u0027Type\u0027",
    )
    vlanaware: bool | int | str | None = Field(
        description="\u0027Allow vm VLANs to pass through this vnet.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )
    zone: str = Field(
        description="\u0027zone id\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_VnetDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet} DELETE
    """
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_VnetGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet} GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_VnetGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/vnets/{vnet} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_VnetPUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet} PUT
    """
    alias: str | None = Field(
        max_length=256,
        description="\u0027alias name of the vnet\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    tag: int | str | None = Field(
        description="\u0027vlan or vxlan id\u0027",
    )
    vlanaware: bool | int | str | None = Field(
        description="\u0027Allow vm VLANs to pass through this vnet.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )
    zone: str | None = Field(
        description="\u0027zone id\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_SubnetsGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet}/subnets GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_SubnetsGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/vnets/{vnet}/subnets GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_SubnetsPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet}/subnets POST
    """
    dnszoneprefix: str | None = Field(
        description="\"dns domain zone prefix  ex: \u0027adm\u0027 -\u003e \u003chostname\u003e.adm.mydomain.com\"",
    )
    gateway: str | None = Field(
        description="\u0027Subnet Gateway: Will be assign on vnet for layer3 zones\u0027",
    )
    snat: bool | int | str | None = Field(
        description="\u0027enable masquerade for this subnet if pve-firewall\u0027",
    )
    subnet: str = Field(
        description="\u0027The SDN subnet object identifier.\u0027",
    )
    type: Literal["subnet"] = Field(
    )
    vnet: str = Field(
        description="\u0027associated vnet\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_Subnets_SubnetDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet}/subnets/{subnet} DELETE
    """
    subnet: str = Field(
        description="\u0027The SDN subnet object identifier.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_Subnets_SubnetGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet}/subnets/{subnet} GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    subnet: str = Field(
        description="\u0027The SDN subnet object identifier.\u0027",
    )
    vnet: str = Field(
        description="\u0027The SDN vnet object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_Subnets_SubnetGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/vnets/{vnet}/subnets/{subnet} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Vnets_Vnet_Subnets_SubnetPUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/vnets/{vnet}/subnets/{subnet} PUT
    """
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dnszoneprefix: str | None = Field(
        description="\"dns domain zone prefix  ex: \u0027adm\u0027 -\u003e \u003chostname\u003e.adm.mydomain.com\"",
    )
    gateway: str | None = Field(
        description="\u0027Subnet Gateway: Will be assign on vnet for layer3 zones\u0027",
    )
    snat: bool | int | str | None = Field(
        description="\u0027enable masquerade for this subnet if pve-firewall\u0027",
    )
    subnet: str = Field(
        description="\u0027The SDN subnet object identifier.\u0027",
    )
    vnet: str | None = Field(
        description="\u0027associated vnet\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ZonesGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/zones GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    type: Literal["evpn", "faucet", "qinq", "simple", "vlan", "vxlan"] | None = Field(
        description="\u0027Only list SDN zones of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ZonesGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/zones GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ZonesPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/zones POST
    """
    advertise_subnets: bool | int | str | None = Field(
        description="\u0027Advertise evpn subnets if you have silent hosts\u0027",
    )
    bridge: str | None = Field(
    )
    bridge_disable_mac_learning: bool | int | str | None = Field(
        description="\u0027Disable auto mac learning.\u0027",
    )
    controller: str | None = Field(
        description="\u0027Frr router name\u0027",
    )
    disable_arp_nd_suppression: bool | int | str | None = Field(
        description="\u0027Disable ipv4 arp \u0026\u0026 ipv6 neighbour discovery suppression\u0027",
    )
    dns: str | None = Field(
        description="\u0027dns api server\u0027",
    )
    dnszone: str | None = Field(
        description="\u0027dns domain zone  ex: mydomain.com\u0027",
    )
    dp_id: int | str | None = Field(
        description="\u0027Faucet dataplane id\u0027",
    )
    exitnodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    exitnodes_local_routing: bool | int | str | None = Field(
        description="\u0027Allow exitnodes to connect to evpn guests\u0027",
    )
    exitnodes_primary: ProxmoxNode | None = Field(
        description="\u0027Force traffic to this exitnode first.\u0027",
    )
    ipam: str | None = Field(
        description="\u0027use a specific ipam\u0027",
    )
    mac: str | None = Field(
        description="\u0027Anycast logical router mac address\u0027",
    )
    mtu: int | str | None = Field(
        description="\u0027MTU\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    peers: str | None = Field(
        description="\u0027peers address list.\u0027",
    )
    reversedns: str | None = Field(
        description="\u0027reverse dns api server\u0027",
    )
    rt_import: str | None = Field(
        description="\u0027Route-Target import\u0027",
    )
    tag: int | str | None = Field(
        ge=0,
        description="\u0027Service-VLAN Tag\u0027",
    )
    type: Literal["evpn", "faucet", "qinq", "simple", "vlan", "vxlan"] = Field(
        description="\u0027Plugin type.\u0027",
    )
    vlan_protocol: Literal["802.1ad", "802.1q"] | None = Field(
        default="802.1q",
    )
    vrf_vxlan: int | str | None = Field(
        description="\u0027l3vni.\u0027",
    )
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Zones_ZoneDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/zones/{zone} DELETE
    """
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Zones_ZoneGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/zones/{zone} GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Zones_ZoneGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/zones/{zone} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Zones_ZonePUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/zones/{zone} PUT
    """
    advertise_subnets: bool | int | str | None = Field(
        description="\u0027Advertise evpn subnets if you have silent hosts\u0027",
    )
    bridge: str | None = Field(
    )
    bridge_disable_mac_learning: bool | int | str | None = Field(
        description="\u0027Disable auto mac learning.\u0027",
    )
    controller: str | None = Field(
        description="\u0027Frr router name\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disable_arp_nd_suppression: bool | int | str | None = Field(
        description="\u0027Disable ipv4 arp \u0026\u0026 ipv6 neighbour discovery suppression\u0027",
    )
    dns: str | None = Field(
        description="\u0027dns api server\u0027",
    )
    dnszone: str | None = Field(
        description="\u0027dns domain zone  ex: mydomain.com\u0027",
    )
    dp_id: int | str | None = Field(
        description="\u0027Faucet dataplane id\u0027",
    )
    exitnodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    exitnodes_local_routing: bool | int | str | None = Field(
        description="\u0027Allow exitnodes to connect to evpn guests\u0027",
    )
    exitnodes_primary: ProxmoxNode | None = Field(
        description="\u0027Force traffic to this exitnode first.\u0027",
    )
    ipam: str | None = Field(
        description="\u0027use a specific ipam\u0027",
    )
    mac: str | None = Field(
        description="\u0027Anycast logical router mac address\u0027",
    )
    mtu: int | str | None = Field(
        description="\u0027MTU\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    peers: str | None = Field(
        description="\u0027peers address list.\u0027",
    )
    reversedns: str | None = Field(
        description="\u0027reverse dns api server\u0027",
    )
    rt_import: str | None = Field(
        description="\u0027Route-Target import\u0027",
    )
    tag: int | str | None = Field(
        ge=0,
        description="\u0027Service-VLAN Tag\u0027",
    )
    vlan_protocol: Literal["802.1ad", "802.1q"] | None = Field(
        default="802.1q",
    )
    vrf_vxlan: int | str | None = Field(
        description="\u0027l3vni.\u0027",
    )
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ControllersGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/controllers GET
    """
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )
    type: Literal["bgp", "evpn", "faucet"] | None = Field(
        description="\u0027Only list sdn controllers of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ControllersGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/controllers GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_ControllersPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/controllers POST
    """
    asn: int | str | None = Field(
        ge=0,
        le=4294967296,
        description="\u0027autonomous system number\u0027",
    )
    bgp_multipath_as_path_relax: bool | int | str | None = Field(
    )
    controller: str = Field(
        description="\u0027The SDN controller object identifier.\u0027",
    )
    ebgp: bool | int | str | None = Field(
        description="\u0027Enable ebgp. (remote-as external)\u0027",
    )
    ebgp_multihop: int | str | None = Field(
    )
    loopback: str | None = Field(
        description="\u0027source loopback interface.\u0027",
    )
    node: ProxmoxNode | None = Field(
        description="\u0027The cluster node name.\u0027",
    )
    peers: str | None = Field(
        description="\u0027peers address list.\u0027",
    )
    type: Literal["bgp", "evpn", "faucet"] = Field(
        description="\u0027Plugin type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Controllers_ControllerDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/controllers/{controller} DELETE
    """
    controller: str = Field(
        description="\u0027The SDN controller object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Controllers_ControllerGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/controllers/{controller} GET
    """
    controller: str = Field(
        description="\u0027The SDN controller object identifier.\u0027",
    )
    pending: bool | int | str | None = Field(
        description="\u0027Display pending config.\u0027",
    )
    running: bool | int | str | None = Field(
        description="\u0027Display running config.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Controllers_ControllerGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/controllers/{controller} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Controllers_ControllerPUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/controllers/{controller} PUT
    """
    asn: int | str | None = Field(
        ge=0,
        le=4294967296,
        description="\u0027autonomous system number\u0027",
    )
    bgp_multipath_as_path_relax: bool | int | str | None = Field(
    )
    controller: str = Field(
        description="\u0027The SDN controller object identifier.\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    ebgp: bool | int | str | None = Field(
        description="\u0027Enable ebgp. (remote-as external)\u0027",
    )
    ebgp_multihop: int | str | None = Field(
    )
    loopback: str | None = Field(
        description="\u0027source loopback interface.\u0027",
    )
    node: ProxmoxNode | None = Field(
        description="\u0027The cluster node name.\u0027",
    )
    peers: str | None = Field(
        description="\u0027peers address list.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_IpamsGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/ipams GET
    """
    type: Literal["netbox", "phpipam", "pve"] | None = Field(
        description="\u0027Only list sdn ipams of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_IpamsGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/ipams GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_IpamsPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/ipams POST
    """
    ipam: str = Field(
        description="\u0027The SDN ipam object identifier.\u0027",
    )
    section: int | str | None = Field(
    )
    token: str | None = Field(
    )
    type: Literal["netbox", "phpipam", "pve"] = Field(
        description="\u0027Plugin type.\u0027",
    )
    url: str | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Ipams_IpamDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/ipams/{ipam} DELETE
    """
    ipam: str = Field(
        description="\u0027The SDN ipam object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Ipams_IpamGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/ipams/{ipam} GET
    """
    ipam: str = Field(
        description="\u0027The SDN ipam object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Ipams_IpamGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/ipams/{ipam} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Ipams_IpamPUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/ipams/{ipam} PUT
    """
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    ipam: str = Field(
        description="\u0027The SDN ipam object identifier.\u0027",
    )
    section: int | str | None = Field(
    )
    token: str | None = Field(
    )
    url: str | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_DnsGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/dns GET
    """
    type: Literal["powerdns"] | None = Field(
        description="\u0027Only list sdn dns of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_DnsGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/dns GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_DnsPOSTRequest(BaseModel):
    """
    Request model for /cluster/sdn/dns POST
    """
    dns: str = Field(
        description="\u0027The SDN dns object identifier.\u0027",
    )
    key: str = Field(
    )
    reversemaskv6: int | str | None = Field(
    )
    reversev6mask: int | str | None = Field(
    )
    ttl: int | str | None = Field(
    )
    type: Literal["powerdns"] = Field(
        description="\u0027Plugin type.\u0027",
    )
    url: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Dns_DnsDELETERequest(BaseModel):
    """
    Request model for /cluster/sdn/dns/{dns} DELETE
    """
    dns: str = Field(
        description="\u0027The SDN dns object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Dns_DnsGETRequest(BaseModel):
    """
    Request model for /cluster/sdn/dns/{dns} GET
    """
    dns: str = Field(
        description="\u0027The SDN dns object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Dns_DnsGETResponse(BaseModel):
    """
    Response model for /cluster/sdn/dns/{dns} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_Sdn_Dns_DnsPUTRequest(BaseModel):
    """
    Request model for /cluster/sdn/dns/{dns} PUT
    """
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dns: str = Field(
        description="\u0027The SDN dns object identifier.\u0027",
    )
    key: str | None = Field(
    )
    reversemaskv6: int | str | None = Field(
    )
    ttl: int | str | None = Field(
    )
    url: str | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_LogGETRequest(BaseModel):
    """
    Request model for /cluster/log GET
    """
    max: int | str | None = Field(
        ge=1,
        description="\u0027Maximum number of entries.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_LogGETResponse(BaseModel):
    """
    Response model for /cluster/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ResourcesGETRequest(BaseModel):
    """
    Request model for /cluster/resources GET
    """
    type: Literal["node", "sdn", "storage", "vm"] | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_ResourcesGETResponse(BaseModel):
    """
    Response model for /cluster/resources GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_TasksGETResponse(BaseModel):
    """
    Response model for /cluster/tasks GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_OptionsGETResponse(BaseModel):
    """
    Response model for /cluster/options GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_OptionsPUTRequest(BaseModel):
    """
    Request model for /cluster/options PUT
    """
    bwlimit: str | None = Field(
        description="\u0027Set bandwidth/io limits various operations.\u0027",
    )
    console: Literal["applet", "html5", "vv", "xtermjs"] | None = Field(
        description="\u0027Select the default Console viewer. You can either use the builtin java applet (VNC; deprecated and maps to html5), an external virt-viewer comtatible application (SPICE), an HTML5 based vnc viewer (noVNC), or an HTML5 based console client (xtermjs). If the selected viewer is not available (e.g. SPICE not activated for the VM), the fallback is noVNC.\u0027",
    )
    crs: str | None = Field(
        description="\u0027Cluster resource scheduling settings.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    description: str | None = Field(
        max_length=65536,
        description="\u0027Datacenter description. Shown in the web-interface datacenter notes panel. This is saved as comment inside the configuration file.\u0027",
    )
    email_from: str | None = Field(
        description="\u0027Specify email address to send notification from (default is root@$hostname)\u0027",
    )
    fencing: Literal["both", "hardware", "watchdog"] | None = Field(
        default="watchdog",
        description="\"Set the fencing mode of the HA cluster. Hardware mode needs a valid configuration of fence devices in /etc/pve/ha/fence.cfg. With both all two modes are used.\\n\\nWARNING: \u0027hardware\u0027 and \u0027both\u0027 are EXPERIMENTAL \u0026 WIP\"",
    )
    ha: str | None = Field(
        description="\u0027Cluster wide HA settings.\u0027",
    )
    http_proxy: str | None = Field(
        description="\"Specify external http proxy which is used for downloads (example: \u0027http://username:password@host:port/\u0027)\"",
    )
    keyboard: str | None = Field(
        description="\u0027Default keybord layout for vnc server.\u0027",
    )
    language: str | None = Field(
        description="\u0027Default GUI language.\u0027",
    )
    mac_prefix: str | None = Field(
        description="\u0027Prefix for autogenerated MAC addresses.\u0027",
    )
    max_workers: int | str | None = Field(
        ge=1,
        description="\"Defines how many workers (per node) are maximal started  on actions like \u0027stopall VMs\u0027 or task from the ha-manager.\"",
    )
    migration: str | None = Field(
        description="\u0027For cluster wide migration settings.\u0027",
    )
    migration_unsecure: bool | int | str | None = Field(
        description="\"Migration is secure using SSH tunnel by default. For secure private networks you can disable it to speed up migration. Deprecated, use the \u0027migration\u0027 property instead!\"",
    )
    next_id: str | None = Field(
        description="\u0027Control the range for the free VMID auto-selection pool.\u0027",
    )
    notify: str | None = Field(
        description="\u0027Cluster-wide notification settings.\u0027",
    )
    registered_tags: str | None = Field(
        description="\"A list of tags that require a `Sys.Modify` on \u0027/\u0027 to set and delete. Tags set here that are also in \u0027user-tag-access\u0027 also require `Sys.Modify`.\"",
    )
    tag_style: str | None = Field(
        description="\u0027Tag style options.\u0027",
    )
    u2f: str | None = Field(
        description="\u0027u2f\u0027",
    )
    user_tag_access: str | None = Field(
        description="\u0027Privilege options for user-settable tags\u0027",
    )
    webauthn: str | None = Field(
        description="\u0027webauthn configuration\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_StatusGETResponse(BaseModel):
    """
    Response model for /cluster/status GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_NextidGETRequest(BaseModel):
    """
    Request model for /cluster/nextid GET
    """
    vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Cluster_NextidGETResponse(BaseModel):
    """
    Response model for /cluster/nextid GET
    """
    data: int | str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

