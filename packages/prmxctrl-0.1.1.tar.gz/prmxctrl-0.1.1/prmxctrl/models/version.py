"""
Pydantic models for version API endpoints.

This module contains auto-generated Pydantic v2 models for request and response
validation in the version API endpoints.
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class VersionGETResponse(BaseModel):
    """
    Response model for /version GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

