"""
Pydantic models for storage API endpoints.

This module contains auto-generated Pydantic v2 models for request and response
validation in the storage API endpoints.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..base.types import ProxmoxNode


class StorageGETRequest(BaseModel):
    """
    Request model for /storage GET
    """
    type: str | None = Field(
        description="\u0027Only list storage of specific type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class StorageGETResponse(BaseModel):
    """
    Response model for /storage GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class StoragePOSTRequest(BaseModel):
    """
    Request model for /storage POST
    """
    authsupported: str | None = Field(
        description="\u0027Authsupported.\u0027",
    )
    base: str | None = Field(
        description="\u0027Base volume. This volume is automatically activated.\u0027",
    )
    blocksize: str | None = Field(
        description="\u0027block size\u0027",
    )
    bwlimit: str | None = Field(
        description="\u0027Set bandwidth/io limits various operations.\u0027",
    )
    comstar_hg: str | None = Field(
        description="\u0027host group for comstar views\u0027",
    )
    comstar_tg: str | None = Field(
        description="\u0027target group for comstar views\u0027",
    )
    content: str | None = Field(
        description="\"Allowed content types.\\n\\nNOTE: the value \u0027rootdir\u0027 is used for Containers, and value \u0027images\u0027 for VMs.\\n\"",
    )
    content_dirs: str | None = Field(
        description="\u0027Overrides for default content type directories.\u0027",
    )
    data_pool: str | None = Field(
        description="\u0027Data Pool (for erasure coding only)\u0027",
    )
    datastore: str | None = Field(
        description="\u0027Proxmox Backup Server datastore name.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the storage.\u0027",
    )
    domain: str | None = Field(
        max_length=256,
        description="\u0027CIFS domain.\u0027",
    )
    encryption_key: str | None = Field(
        description="\"Encryption key. Use \u0027autogen\u0027 to generate one automatically without passphrase.\"",
    )
    export: str | None = Field(
        description="\u0027NFS export path.\u0027",
    )
    fingerprint: str | None = Field(
        description="\u0027Certificate SHA 256 fingerprint.\u0027",
    )
    format: str | None = Field(
        description="\u0027Default image format.\u0027",
    )
    fs_name: str | None = Field(
        description="\u0027The Ceph filesystem name.\u0027",
    )
    fuse: bool | int | str | None = Field(
        description="\u0027Mount CephFS through FUSE.\u0027",
    )
    is_mountpoint: str | None = Field(
        default="no",
        description="\u0027Assume the given path is an externally managed mountpoint and consider the storage offline if it is not mounted. Using a boolean (yes/no) value serves as a shortcut to using the target path in this field.\u0027",
    )
    iscsiprovider: str | None = Field(
        description="\u0027iscsi provider\u0027",
    )
    keyring: str | None = Field(
        description="\u0027Client keyring contents (for external clusters).\u0027",
    )
    krbd: bool | int | str | None = Field(
        description="\u0027Always access rbd through krbd kernel module.\u0027",
    )
    lio_tpg: str | None = Field(
        description="\u0027target portal group for Linux LIO targets\u0027",
    )
    master_pubkey: str | None = Field(
        description="\u0027Base64-encoded, PEM-formatted public RSA key. Used to encrypt a copy of the encryption-key which will be added to each encrypted backup.\u0027",
    )
    max_protected_backups: int | str | None = Field(
        default="Unlimited for users with Datastore.Allocate privilege, 5 for other users",
        ge=-1,
        description="\"Maximal number of protected backups per guest. Use \u0027-1\u0027 for unlimited.\"",
    )
    maxfiles: int | str | None = Field(
        ge=0,
        description="\"Deprecated: use \u0027prune-backups\u0027 instead. Maximal number of backup files per VM. Use \u00270\u0027 for unlimited.\"",
    )
    mkdir: bool | int | str | None = Field(
        default="yes",
        description="\"Create the directory if it doesn\u0027t exist.\"",
    )
    monhost: str | None = Field(
        description="\u0027IP addresses of monitors (for external clusters).\u0027",
    )
    mountpoint: str | None = Field(
        description="\u0027mount point\u0027",
    )
    namespace: str | None = Field(
        description="\u0027Namespace.\u0027",
    )
    nocow: bool | int | str | None = Field(
        default=0,
        description="\u0027Set the NOCOW flag on files. Disables data checksumming and causes data errors to be unrecoverable from while allowing direct I/O. Only use this if data does not need to be any more safe than on a single ext4 formatted disk with no underlying raid system.\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    nowritecache: bool | int | str | None = Field(
        description="\u0027disable write caching on the target\u0027",
    )
    options: str | None = Field(
        description="\"NFS mount options (see \u0027man nfs\u0027)\"",
    )
    password: str | None = Field(
        max_length=256,
        description="\u0027Password for accessing the share/datastore.\u0027",
    )
    path: str | None = Field(
        description="\u0027File system path.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Pool.\u0027",
    )
    port: int | str | None = Field(
        default=8007,
        ge=1,
        le=65535,
        description="\u0027For non default port.\u0027",
    )
    portal: str | None = Field(
        description="\u0027iSCSI portal (IP or DNS name with optional port).\u0027",
    )
    preallocation: Literal["falloc", "full", "metadata", "off"] | None = Field(
        default="metadata",
        description="\"Preallocation mode for raw and qcow2 images. Using \u0027metadata\u0027 on raw images results in preallocation=off.\"",
    )
    prune_backups: str | None = Field(
        description="\u0027The retention options with shorter intervals are processed first with --keep-last being the very first one. Each option covers a specific period of time. We say that backups within this period are covered by this option. The next option does not take care of already covered backups and only considers older backups.\u0027",
    )
    saferemove: bool | int | str | None = Field(
        description="\u0027Zero-out data when removing LVs.\u0027",
    )
    saferemove_throughput: str | None = Field(
        description="\u0027Wipe throughput (cstream -t parameter value).\u0027",
    )
    server: str | None = Field(
        description="\u0027Server IP or DNS name.\u0027",
    )
    server2: str | None = Field(
        description="\u0027Backup volfile server IP or DNS name.\u0027",
    )
    share: str | None = Field(
        description="\u0027CIFS share.\u0027",
    )
    shared: bool | int | str | None = Field(
        description="\u0027Mark storage as shared.\u0027",
    )
    smbversion: Literal["2.0", "2.1", "3", "3.0", "3.11", "default"] | None = Field(
        default="default",
        description="\"SMB protocol version. \u0027default\u0027 if not set, negotiates the highest SMB2+ version supported by both the client and server.\"",
    )
    sparse: bool | int | str | None = Field(
        description="\u0027use sparse volumes\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    subdir: str | None = Field(
        description="\u0027Subdir to mount.\u0027",
    )
    tagged_only: bool | int | str | None = Field(
        description="\"Only use logical volumes tagged with \u0027pve-vm-ID\u0027.\"",
    )
    target: str | None = Field(
        description="\u0027iSCSI target.\u0027",
    )
    thinpool: str | None = Field(
        description="\u0027LVM thin pool LV name.\u0027",
    )
    transport: Literal["rdma", "tcp", "unix"] | None = Field(
        description="\u0027Gluster transport: tcp or rdma\u0027",
    )
    type: str = Field(
        description="\u0027Storage type.\u0027",
    )
    username: str | None = Field(
        description="\u0027RBD Id.\u0027",
    )
    vgname: str | None = Field(
        description="\u0027Volume group name.\u0027",
    )
    volume: str | None = Field(
        description="\u0027Glusterfs Volume.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class StoragePOSTResponse(BaseModel):
    """
    Response model for /storage POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Storage_StorageDELETERequest(BaseModel):
    """
    Request model for /storage/{storage} DELETE
    """
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Storage_StorageGETRequest(BaseModel):
    """
    Request model for /storage/{storage} GET
    """
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Storage_StorageGETResponse(BaseModel):
    """
    Response model for /storage/{storage} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Storage_StoragePUTRequest(BaseModel):
    """
    Request model for /storage/{storage} PUT
    """
    blocksize: str | None = Field(
        description="\u0027block size\u0027",
    )
    bwlimit: str | None = Field(
        description="\u0027Set bandwidth/io limits various operations.\u0027",
    )
    comstar_hg: str | None = Field(
        description="\u0027host group for comstar views\u0027",
    )
    comstar_tg: str | None = Field(
        description="\u0027target group for comstar views\u0027",
    )
    content: str | None = Field(
        description="\"Allowed content types.\\n\\nNOTE: the value \u0027rootdir\u0027 is used for Containers, and value \u0027images\u0027 for VMs.\\n\"",
    )
    content_dirs: str | None = Field(
        description="\u0027Overrides for default content type directories.\u0027",
    )
    data_pool: str | None = Field(
        description="\u0027Data Pool (for erasure coding only)\u0027",
    )
    delete: str | None = Field(
        max_length=4096,
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disable: bool | int | str | None = Field(
        description="\u0027Flag to disable the storage.\u0027",
    )
    domain: str | None = Field(
        max_length=256,
        description="\u0027CIFS domain.\u0027",
    )
    encryption_key: str | None = Field(
        description="\"Encryption key. Use \u0027autogen\u0027 to generate one automatically without passphrase.\"",
    )
    fingerprint: str | None = Field(
        description="\u0027Certificate SHA 256 fingerprint.\u0027",
    )
    format: str | None = Field(
        description="\u0027Default image format.\u0027",
    )
    fs_name: str | None = Field(
        description="\u0027The Ceph filesystem name.\u0027",
    )
    fuse: bool | int | str | None = Field(
        description="\u0027Mount CephFS through FUSE.\u0027",
    )
    is_mountpoint: str | None = Field(
        default="no",
        description="\u0027Assume the given path is an externally managed mountpoint and consider the storage offline if it is not mounted. Using a boolean (yes/no) value serves as a shortcut to using the target path in this field.\u0027",
    )
    keyring: str | None = Field(
        description="\u0027Client keyring contents (for external clusters).\u0027",
    )
    krbd: bool | int | str | None = Field(
        description="\u0027Always access rbd through krbd kernel module.\u0027",
    )
    lio_tpg: str | None = Field(
        description="\u0027target portal group for Linux LIO targets\u0027",
    )
    master_pubkey: str | None = Field(
        description="\u0027Base64-encoded, PEM-formatted public RSA key. Used to encrypt a copy of the encryption-key which will be added to each encrypted backup.\u0027",
    )
    max_protected_backups: int | str | None = Field(
        default="Unlimited for users with Datastore.Allocate privilege, 5 for other users",
        ge=-1,
        description="\"Maximal number of protected backups per guest. Use \u0027-1\u0027 for unlimited.\"",
    )
    maxfiles: int | str | None = Field(
        ge=0,
        description="\"Deprecated: use \u0027prune-backups\u0027 instead. Maximal number of backup files per VM. Use \u00270\u0027 for unlimited.\"",
    )
    mkdir: bool | int | str | None = Field(
        default="yes",
        description="\"Create the directory if it doesn\u0027t exist.\"",
    )
    monhost: str | None = Field(
        description="\u0027IP addresses of monitors (for external clusters).\u0027",
    )
    mountpoint: str | None = Field(
        description="\u0027mount point\u0027",
    )
    namespace: str | None = Field(
        description="\u0027Namespace.\u0027",
    )
    nocow: bool | int | str | None = Field(
        default=0,
        description="\u0027Set the NOCOW flag on files. Disables data checksumming and causes data errors to be unrecoverable from while allowing direct I/O. Only use this if data does not need to be any more safe than on a single ext4 formatted disk with no underlying raid system.\u0027",
    )
    nodes: list[ProxmoxNode] | None = Field(
        description="\u0027List of cluster node names.\u0027",
    )
    nowritecache: bool | int | str | None = Field(
        description="\u0027disable write caching on the target\u0027",
    )
    options: str | None = Field(
        description="\"NFS mount options (see \u0027man nfs\u0027)\"",
    )
    password: str | None = Field(
        max_length=256,
        description="\u0027Password for accessing the share/datastore.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Pool.\u0027",
    )
    port: int | str | None = Field(
        default=8007,
        ge=1,
        le=65535,
        description="\u0027For non default port.\u0027",
    )
    preallocation: Literal["falloc", "full", "metadata", "off"] | None = Field(
        default="metadata",
        description="\"Preallocation mode for raw and qcow2 images. Using \u0027metadata\u0027 on raw images results in preallocation=off.\"",
    )
    prune_backups: str | None = Field(
        description="\u0027The retention options with shorter intervals are processed first with --keep-last being the very first one. Each option covers a specific period of time. We say that backups within this period are covered by this option. The next option does not take care of already covered backups and only considers older backups.\u0027",
    )
    saferemove: bool | int | str | None = Field(
        description="\u0027Zero-out data when removing LVs.\u0027",
    )
    saferemove_throughput: str | None = Field(
        description="\u0027Wipe throughput (cstream -t parameter value).\u0027",
    )
    server: str | None = Field(
        description="\u0027Server IP or DNS name.\u0027",
    )
    server2: str | None = Field(
        description="\u0027Backup volfile server IP or DNS name.\u0027",
    )
    shared: bool | int | str | None = Field(
        description="\u0027Mark storage as shared.\u0027",
    )
    smbversion: Literal["2.0", "2.1", "3", "3.0", "3.11", "default"] | None = Field(
        default="default",
        description="\"SMB protocol version. \u0027default\u0027 if not set, negotiates the highest SMB2+ version supported by both the client and server.\"",
    )
    sparse: bool | int | str | None = Field(
        description="\u0027use sparse volumes\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    subdir: str | None = Field(
        description="\u0027Subdir to mount.\u0027",
    )
    tagged_only: bool | int | str | None = Field(
        description="\"Only use logical volumes tagged with \u0027pve-vm-ID\u0027.\"",
    )
    transport: Literal["rdma", "tcp", "unix"] | None = Field(
        description="\u0027Gluster transport: tcp or rdma\u0027",
    )
    username: str | None = Field(
        description="\u0027RBD Id.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Storage_StoragePUTResponse(BaseModel):
    """
    Response model for /storage/{storage} PUT
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

