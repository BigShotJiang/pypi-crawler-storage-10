"""
Pydantic models for pools API endpoints.

This module contains auto-generated Pydantic v2 models for request and response
validation in the pools API endpoints.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..base.types import ProxmoxVMID


class PoolsGETResponse(BaseModel):
    """
    Response model for /pools GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class PoolsPOSTRequest(BaseModel):
    """
    Request model for /pools POST
    """
    comment: str | None = Field(
    )
    poolid: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Pools_PoolidDELETERequest(BaseModel):
    """
    Request model for /pools/{poolid} DELETE
    """
    poolid: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Pools_PoolidGETRequest(BaseModel):
    """
    Request model for /pools/{poolid} GET
    """
    poolid: str = Field(
    )
    type: Literal["lxc", "qemu", "storage"] | None = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Pools_PoolidGETResponse(BaseModel):
    """
    Response model for /pools/{poolid} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Pools_PoolidPUTRequest(BaseModel):
    """
    Request model for /pools/{poolid} PUT
    """
    comment: str | None = Field(
    )
    delete: bool | int | str | None = Field(
        description="\u0027Remove vms/storage (instead of adding it).\u0027",
    )
    poolid: str = Field(
    )
    storage: list[str] | None = Field(
        description="\u0027List of storage IDs.\u0027",
    )
    vms: list[ProxmoxVMID] | None = Field(
        description="\u0027List of virtual machines.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

