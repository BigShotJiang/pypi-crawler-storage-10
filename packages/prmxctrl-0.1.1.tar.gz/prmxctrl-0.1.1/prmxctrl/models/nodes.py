"""
Pydantic models for nodes API endpoints.

This module contains auto-generated Pydantic v2 models for request and response
validation in the nodes API endpoints.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..base.types import ProxmoxNode, ProxmoxVMID


class NodesGETResponse(BaseModel):
    """
    Response model for /nodes GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_NodeGETRequest(BaseModel):
    """
    Request model for /nodes/{node} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_NodeGETResponse(BaseModel):
    """
    Response model for /nodes/{node} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_QemuGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu GET
    """
    full: bool | int | str | None = Field(
        description="\u0027Determine the full status of active VMs.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_QemuGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_QemuPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu POST
    """
    acpi: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable ACPI.\u0027",
    )
    affinity: str | None = Field(
        description="\u0027List of host cores used to execute guest processes, for example: 0,5,8-11\u0027",
    )
    agent: str | None = Field(
        description="\u0027Enable/disable communication with the QEMU Guest Agent and its properties.\u0027",
    )
    arch: Literal["aarch64", "x86_64"] | None = Field(
        description="\u0027Virtual processor architecture. Defaults to the host.\u0027",
    )
    archive: str | None = Field(
        max_length=255,
        description="\"The backup archive. Either the file system path to a .tar or .vma file (use \u0027-\u0027 to pipe data from stdin) or a proxmox storage backup volume identifier.\"",
    )
    args: str | None = Field(
        description="\u0027Arbitrary arguments passed to kvm.\u0027",
    )
    audio0: str | None = Field(
        description="\u0027Configure a audio device, useful in combination with QXL/Spice.\u0027",
    )
    autostart: bool | int | str | None = Field(
        default=0,
        description="\u0027Automatic restart after crash (currently ignored).\u0027",
    )
    balloon: int | str | None = Field(
        ge=0,
        description="\u0027Amount of target RAM for the VM in MiB. Using zero disables the ballon driver.\u0027",
    )
    bios: Literal["ovmf", "seabios"] | None = Field(
        default="seabios",
        description="\u0027Select BIOS implementation.\u0027",
    )
    boot: str | None = Field(
        description="\"Specify guest boot order. Use the \u0027order=\u0027 sub-property as usage with no key or \u0027legacy=\u0027 is deprecated.\"",
    )
    bootdisk: str | None = Field(
        description="\"Enable booting from specified disk. Deprecated: Use \u0027boot: order=foo;bar\u0027 instead.\"",
    )
    bwlimit: int | str | None = Field(
        default="restore limit from datacenter or storage config",
        ge=0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    cdrom: str | None = Field(
        description="\u0027This is an alias for option -ide2\u0027",
    )
    cicustom: str | None = Field(
        description="\u0027cloud-init: Specify custom files to replace the automatically generated ones at start.\u0027",
    )
    cipassword: str | None = Field(
        description="\u0027cloud-init: Password to assign the user. Using this is generally not recommended. Use ssh keys instead. Also note that older cloud-init versions do not support hashed passwords.\u0027",
    )
    citype: Literal["configdrive2", "nocloud", "opennebula"] | None = Field(
        description="\u0027Specifies the cloud-init configuration format. The default depends on the configured operating system type (`ostype`. We use the `nocloud` format for Linux, and `configdrive2` for windows.\u0027",
    )
    ciuser: str | None = Field(
        description="\"cloud-init: User name to change ssh keys and password for instead of the image\u0027s configured default user.\"",
    )
    cores: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of cores per socket.\u0027",
    )
    cpu: str | None = Field(
        description="\u0027Emulated CPU type.\u0027",
    )
    cpulimit: float | str | None = Field(
        default=0,
        ge=0.0,
        le=128.0,
        description="\u0027Limit of CPU usage.\u0027",
    )
    cpuunits: int | str | None = Field(
        default="cgroup v1: 1024, cgroup v2: 100",
        ge=1,
        le=262144,
        description="\u0027CPU weight for a VM, will be clamped to [1, 10000] in cgroup v2.\u0027",
    )
    description: str | None = Field(
        max_length=8192,
        description="\"Description for the VM. Shown in the web-interface VM\u0027s summary. This is saved as comment inside the configuration file.\"",
    )
    efidisk0: str | None = Field(
        description="\"Configure a disk for storing EFI vars. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and that the default EFI vars are copied to the volume instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    force: bool | int | str | None = Field(
        description="\u0027Allow to overwrite existing VM.\u0027",
    )
    freeze: bool | int | str | None = Field(
        description="\"Freeze CPU at startup (use \u0027c\u0027 monitor command to start execution).\"",
    )
    hookscript: str | None = Field(
        description="\u0027Script that will be executed during various steps in the vms lifetime.\u0027",
    )
    hostpci_n_: str | None = Field(
        description="\u0027Map host PCI devices into guest.\u0027",
    )
    hotplug: str | None = Field(
        default="network,disk,usb",
        description="\"Selectively enable hotplug features. This is a comma separated list of hotplug features: \u0027network\u0027, \u0027disk\u0027, \u0027cpu\u0027, \u0027memory\u0027, \u0027usb\u0027 and \u0027cloudinit\u0027. Use \u00270\u0027 to disable hotplug completely. Using \u00271\u0027 as value is an alias for the default `network,disk,usb`. USB hotplugging is possible for guests with machine version \u003e= 7.1 and ostype l26 or windows \u003e 7.\"",
    )
    hugepages: Literal["1024", "2", "any"] | None = Field(
        description="\u0027Enable/disable hugepages memory.\u0027",
    )
    ide_n_: str | None = Field(
        description="\"Use volume as IDE hard disk or CD-ROM (n is 0 to 3). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    ipconfig_n_: str | None = Field(
        description="\"cloud-init: Specify IP addresses and gateways for the corresponding interface.\\n\\nIP addresses use CIDR notation, gateways are optional but need an IP of the same type specified.\\n\\nThe special string \u0027dhcp\u0027 can be used for IP addresses to use DHCP, in which case no explicit\\ngateway should be provided.\\nFor IPv6 the special string \u0027auto\u0027 can be used to use stateless autoconfiguration. This requires\\ncloud-init 19.4 or newer.\\n\\nIf cloud-init is enabled and neither an IPv4 nor an IPv6 address is specified, it defaults to using\\ndhcp on IPv4.\\n\"",
    )
    ivshmem: str | None = Field(
        description="\u0027Inter-VM shared memory. Useful for direct communication between VMs, or to the host.\u0027",
    )
    keephugepages: bool | int | str | None = Field(
        default=0,
        description="\u0027Use together with hugepages. If enabled, hugepages will not not be deleted after VM shutdown and can be used for subsequent starts.\u0027",
    )
    keyboard: str | None = Field(
        description="\u0027Keyboard layout for VNC server. This option is generally not required and is often better handled from within the guest OS.\u0027",
    )
    kvm: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable KVM hardware virtualization.\u0027",
    )
    live_restore: bool | int | str | None = Field(
        description="\u0027Start the VM immediately from the backup and restore in background. PBS only.\u0027",
    )
    localtime: bool | int | str | None = Field(
        description="\u0027Set the real time clock (RTC) to local time. This is enabled by default if the `ostype` indicates a Microsoft Windows OS.\u0027",
    )
    lock: Literal["backup", "clone", "create", "migrate", "rollback", "snapshot", "snapshot-delete", "suspended", "suspending"] | None = Field(
        description="\u0027Lock/unlock the VM.\u0027",
    )
    machine: str | None = Field(
        max_length=40,
        description="\u0027Specifies the QEMU machine type.\u0027",
    )
    memory: int | str | None = Field(
        default=512,
        ge=16,
        description="\u0027Amount of RAM for the VM in MiB. This is the maximum available memory when you use the balloon device.\u0027",
    )
    migrate_downtime: float | str | None = Field(
        default=0.1,
        ge=0.0,
        description="\u0027Set maximum tolerated downtime (in seconds) for migrations.\u0027",
    )
    migrate_speed: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Set maximum speed (in MB/s) for migrations. Value 0 is no limit.\u0027",
    )
    name: str | None = Field(
        description="\u0027Set a name for the VM. Only used on the configuration web interface.\u0027",
    )
    nameserver: str | None = Field(
        description="\u0027cloud-init: Sets DNS server IP address for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    net_n_: str | None = Field(
        description="\u0027Specify network devices.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    numa: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable NUMA.\u0027",
    )
    numa_n_: str | None = Field(
        description="\u0027NUMA topology.\u0027",
    )
    onboot: bool | int | str | None = Field(
        default=0,
        description="\u0027Specifies whether a VM will be started during system bootup.\u0027",
    )
    ostype: str | None = Field(
        description="\u0027Specify guest operating system.\u0027",
    )
    parallel_n_: str | None = Field(
        description="\u0027Map host parallel devices (n is 0 to 2).\u0027",
    )
    pool: str | None = Field(
        description="\u0027Add the VM to the specified pool.\u0027",
    )
    protection: bool | int | str | None = Field(
        default=0,
        description="\u0027Sets the protection flag of the VM. This will disable the remove VM and remove disk operations.\u0027",
    )
    reboot: bool | int | str | None = Field(
        default=1,
        description="\"Allow reboot. If set to \u00270\u0027 the VM exit on reboot.\"",
    )
    rng0: str | None = Field(
        description="\u0027Configure a VirtIO-based Random Number Generator.\u0027",
    )
    sata_n_: str | None = Field(
        description="\"Use volume as SATA hard disk or CD-ROM (n is 0 to 5). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsi_n_: str | None = Field(
        description="\"Use volume as SCSI hard disk or CD-ROM (n is 0 to 30). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsihw: Literal["lsi", "lsi53c810", "megasas", "pvscsi", "virtio-scsi-pci", "virtio-scsi-single"] | None = Field(
        default="lsi",
        description="\u0027SCSI controller model\u0027",
    )
    searchdomain: str | None = Field(
        description="\u0027cloud-init: Sets DNS search domains for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    serial_n_: str | None = Field(
        description="\u0027Create a serial device inside the VM (n is 0 to 3)\u0027",
    )
    shares: int | str | None = Field(
        default=1000,
        ge=0,
        le=50000,
        description="\u0027Amount of memory shares for auto-ballooning. The larger the number is, the more memory this VM gets. Number is relative to weights of all other running VMs. Using zero disables auto-ballooning. Auto-ballooning is done by pvestatd.\u0027",
    )
    smbios1: str | None = Field(
        max_length=512,
        description="\u0027Specify SMBIOS type 1 fields.\u0027",
    )
    smp: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPUs. Please use option -sockets instead.\u0027",
    )
    sockets: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPU sockets.\u0027",
    )
    spice_enhancements: str | None = Field(
        description="\u0027Configure additional enhancements for SPICE.\u0027",
    )
    sshkeys: str | None = Field(
        description="\u0027cloud-init: Setup public SSH keys (one key per line, OpenSSH format).\u0027",
    )
    start: bool | int | str | None = Field(
        default=0,
        description="\u0027Start VM after it was created successfully.\u0027",
    )
    startdate: str | None = Field(
        default="now",
        description="\"Set the initial date of the real time clock. Valid format for date are:\u0027now\u0027 or \u00272006-06-17T16:01:21\u0027 or \u00272006-06-17\u0027.\"",
    )
    startup: str | None = Field(
        description="\"Startup and shutdown behavior. Order is a non-negative number defining the general startup order. Shutdown in done with reverse ordering. Additionally you can set the \u0027up\u0027 or \u0027down\u0027 delay in seconds, which specifies a delay to wait before the next VM is started or stopped.\"",
    )
    storage: str | None = Field(
        description="\u0027Default storage.\u0027",
    )
    tablet: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable the USB tablet device.\u0027",
    )
    tags: str | None = Field(
        description="\u0027Tags of the VM. This is only meta information.\u0027",
    )
    tdf: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable time drift fix.\u0027",
    )
    template: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable Template.\u0027",
    )
    tpmstate0: str | None = Field(
        description="\"Configure a Disk for storing TPM state. The format is fixed to \u0027raw\u0027. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and 4 MiB will be used instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    unique: bool | int | str | None = Field(
        description="\u0027Assign a unique random ethernet address.\u0027",
    )
    unused_n_: str | None = Field(
        description="\u0027Reference to unused volumes. This is used internally, and should not be modified manually.\u0027",
    )
    usb_n_: str | None = Field(
        description="\u0027Configure an USB device (n is 0 to 4, for machine version \u003e= 7.1 and ostype l26 or windows \u003e 7, n can be up to 14).\u0027",
    )
    vcpus: int | str | None = Field(
        default=0,
        ge=1,
        description="\u0027Number of hotplugged vcpus.\u0027",
    )
    vga: str | None = Field(
        description="\u0027Configure the VGA hardware.\u0027",
    )
    virtio_n_: str | None = Field(
        description="\"Use volume as VIRTIO hard disk (n is 0 to 15). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    vmgenid: str | None = Field(
        default="1 (autogenerated)",
        description="\"Set VM Generation ID. Use \u00271\u0027 to autogenerate on create or update, pass \u00270\u0027 to disable explicitly.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmstatestorage: str | None = Field(
        description="\u0027Default storage for VM state volumes/files.\u0027",
    )
    watchdog: str | None = Field(
        description="\u0027Create a virtual hardware watchdog device.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_QemuPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_VmidDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid} DELETE
    """
    destroy_unreferenced_disks: bool | int | str | None = Field(
        default=0,
        description="\u0027If set, destroy additionally all disks not referenced in the config but with a matching VMID from all enabled storages.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    purge: bool | int | str | None = Field(
        description="\u0027Remove VMID from configurations, like backup \u0026 replication jobs and HA.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_VmidDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_VmidGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_VmidGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_FirewallGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_FirewallGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_RulesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/rules GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_RulesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/rules GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_RulesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/rules POST
    """
    action: str = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] = Field(
        description="\u0027Rule type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Rules_PosDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/rules/{pos} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Rules_PosGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/rules/{pos} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Rules_PosGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/rules/{pos} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Rules_PosPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/rules/{pos} PUT
    """
    action: str | None = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    moveto: int | str | None = Field(
        ge=0,
        description="\u0027Move rule to new position \u003cmoveto\u003e. Other arguments are ignored.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] | None = Field(
        description="\u0027Rule type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_AliasesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/aliases GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_AliasesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/aliases GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_AliasesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/aliases POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Aliases_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/aliases/{name} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Aliases_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/aliases/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Aliases_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/aliases/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Aliases_NamePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/aliases/{name} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\u0027Rename an existing alias.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_IpsetGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_IpsetGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/ipset GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_IpsetPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset POST
    """
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\"Rename an existing IPSet. You can set \u0027rename\u0027 to the same value as \u0027name\u0027 to update the \u0027comment\u0027 of an existing IPSet.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name} DELETE
    """
    force: bool | int | str | None = Field(
        description="\u0027Delete all members of the IPSet, if there are any.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_NamePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name} POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_Name_CidrDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name}/{cidr} DELETE
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_Name_CidrGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name}/{cidr} GET
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_Name_CidrGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name}/{cidr} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_Ipset_Name_CidrPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/ipset/{name}/{cidr} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_OptionsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/options GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_OptionsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/options GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_OptionsPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/options PUT
    """
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dhcp: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable DHCP.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    enable: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable firewall rules.\u0027",
    )
    ipfilter: bool | int | str | None = Field(
        description="\"Enable default IP filters. This is equivalent to adding an empty ipfilter-net\u003cid\u003e ipset for every interface. Such ipsets implicitly contain sane default restrictions such as restricting IPv6 link local addresses to the one derived from the interface\u0027s MAC address. For containers the configured IP addresses will be implicitly added.\"",
    )
    log_level_in: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for incoming traffic.\u0027",
    )
    log_level_out: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for outgoing traffic.\u0027",
    )
    macfilter: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable MAC address filter.\u0027",
    )
    ndp: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable NDP (Neighbor Discovery Protocol).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    policy_in: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Input policy.\u0027",
    )
    policy_out: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Output policy.\u0027",
    )
    radv: bool | int | str | None = Field(
        description="\u0027Allow sending Router Advertisement.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/log GET
    """
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    since: int | str | None = Field(
        ge=0,
        description="\u0027Display log since this UNIX epoch.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )
    until: int | str | None = Field(
        ge=0,
        description="\u0027Display log until this UNIX epoch.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_RefsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/firewall/refs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    type: Literal["alias", "ipset"] | None = Field(
        description="\u0027Only list references of specified type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Firewall_RefsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/firewall/refs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_AgentGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_AgentGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_AgentPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent POST
    """
    command: str = Field(
        description="\u0027The QGA command.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_AgentPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_FreezePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-freeze POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_FreezePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-freeze POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_StatusPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-status POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_StatusPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-status POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_ThawPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-thaw POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Fsfreeze_ThawPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/fsfreeze-thaw POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_FstrimPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/fstrim POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_FstrimPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/fstrim POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_FsinfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-fsinfo GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_FsinfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-fsinfo GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Host_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-host-name GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Host_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-host-name GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Memory_Block_InfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-memory-block-info GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Memory_Block_InfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-memory-block-info GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Memory_BlocksGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-memory-blocks GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_Memory_BlocksGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-memory-blocks GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_OsinfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-osinfo GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_OsinfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-osinfo GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_TimeGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-time GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_TimeGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-time GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_TimezoneGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-timezone GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_TimezoneGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-timezone GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_UsersGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-users GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_UsersGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-users GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_VcpusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/get-vcpus GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Get_VcpusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/get-vcpus GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_InfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/info GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_InfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/info GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Network_Get_InterfacesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/network-get-interfaces GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Network_Get_InterfacesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/network-get-interfaces GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_PingPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/ping POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_PingPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/ping POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_ShutdownPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/shutdown POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_ShutdownPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/shutdown POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_DiskPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/suspend-disk POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_DiskPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/suspend-disk POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_HybridPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/suspend-hybrid POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_HybridPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/suspend-hybrid POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_RamPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/suspend-ram POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Suspend_RamPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/suspend-ram POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Set_User_PasswordPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/set-user-password POST
    """
    crypted: bool | int | str | None = Field(
        default=0,
        description="\u0027set to 1 if the password has already been passed through crypt()\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    password: str = Field(
        max_length=1024,
        description="\u0027The new password.\u0027",
    )
    username: str = Field(
        description="\u0027The user to set the password for.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Set_User_PasswordPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/set-user-password POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_ExecPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/exec POST
    """
    command: str | None = Field(
        description="\u0027The command as a list of program + arguments\u0027",
    )
    input_data: str | None = Field(
        max_length=65536,
        description="\"Data to pass as \u0027input-data\u0027 to the guest. Usually treated as STDIN to \u0027command\u0027.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_ExecPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/exec POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Exec_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/exec-status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pid: int | str = Field(
        description="\u0027The PID to query\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_Exec_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/exec-status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_File_ReadGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/file-read GET
    """
    file: str = Field(
        description="\u0027The path to the file\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_File_ReadGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/agent/file-read GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Agent_File_WritePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/agent/file-write POST
    """
    content: str = Field(
        max_length=61440,
        description="\u0027The content to write into the file.\u0027",
    )
    encode: bool | int | str | None = Field(
        default=1,
        description="\u0027If set, the content will be encoded as base64 (required by QEMU).Otherwise the content needs to be encoded beforehand - defaults to true.\u0027",
    )
    file: str = Field(
        description="\u0027The path to the file.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_RrdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/rrd GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    ds: str = Field(
        description="\u0027The list of datasources you want to display.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_RrdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/rrd GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_RrddataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/rrddata GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_RrddataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/rrddata GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/config GET
    """
    current: bool | int | str | None = Field(
        default=0,
        description="\u0027Get current values (instead of pending values).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapshot: str | None = Field(
        max_length=40,
        description="\u0027Fetch config values from given snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/config GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ConfigPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/config POST
    """
    acpi: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable ACPI.\u0027",
    )
    affinity: str | None = Field(
        description="\u0027List of host cores used to execute guest processes, for example: 0,5,8-11\u0027",
    )
    agent: str | None = Field(
        description="\u0027Enable/disable communication with the QEMU Guest Agent and its properties.\u0027",
    )
    arch: Literal["aarch64", "x86_64"] | None = Field(
        description="\u0027Virtual processor architecture. Defaults to the host.\u0027",
    )
    args: str | None = Field(
        description="\u0027Arbitrary arguments passed to kvm.\u0027",
    )
    audio0: str | None = Field(
        description="\u0027Configure a audio device, useful in combination with QXL/Spice.\u0027",
    )
    autostart: bool | int | str | None = Field(
        default=0,
        description="\u0027Automatic restart after crash (currently ignored).\u0027",
    )
    background_delay: int | str | None = Field(
        ge=1,
        le=30,
        description="\"Time to wait for the task to finish. We return \u0027null\u0027 if the task finish within that time.\"",
    )
    balloon: int | str | None = Field(
        ge=0,
        description="\u0027Amount of target RAM for the VM in MiB. Using zero disables the ballon driver.\u0027",
    )
    bios: Literal["ovmf", "seabios"] | None = Field(
        default="seabios",
        description="\u0027Select BIOS implementation.\u0027",
    )
    boot: str | None = Field(
        description="\"Specify guest boot order. Use the \u0027order=\u0027 sub-property as usage with no key or \u0027legacy=\u0027 is deprecated.\"",
    )
    bootdisk: str | None = Field(
        description="\"Enable booting from specified disk. Deprecated: Use \u0027boot: order=foo;bar\u0027 instead.\"",
    )
    cdrom: str | None = Field(
        description="\u0027This is an alias for option -ide2\u0027",
    )
    cicustom: str | None = Field(
        description="\u0027cloud-init: Specify custom files to replace the automatically generated ones at start.\u0027",
    )
    cipassword: str | None = Field(
        description="\u0027cloud-init: Password to assign the user. Using this is generally not recommended. Use ssh keys instead. Also note that older cloud-init versions do not support hashed passwords.\u0027",
    )
    citype: Literal["configdrive2", "nocloud", "opennebula"] | None = Field(
        description="\u0027Specifies the cloud-init configuration format. The default depends on the configured operating system type (`ostype`. We use the `nocloud` format for Linux, and `configdrive2` for windows.\u0027",
    )
    ciuser: str | None = Field(
        description="\"cloud-init: User name to change ssh keys and password for instead of the image\u0027s configured default user.\"",
    )
    cores: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of cores per socket.\u0027",
    )
    cpu: str | None = Field(
        description="\u0027Emulated CPU type.\u0027",
    )
    cpulimit: float | str | None = Field(
        default=0,
        ge=0.0,
        le=128.0,
        description="\u0027Limit of CPU usage.\u0027",
    )
    cpuunits: int | str | None = Field(
        default="cgroup v1: 1024, cgroup v2: 100",
        ge=1,
        le=262144,
        description="\u0027CPU weight for a VM, will be clamped to [1, 10000] in cgroup v2.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    description: str | None = Field(
        max_length=8192,
        description="\"Description for the VM. Shown in the web-interface VM\u0027s summary. This is saved as comment inside the configuration file.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    efidisk0: str | None = Field(
        description="\"Configure a disk for storing EFI vars. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and that the default EFI vars are copied to the volume instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    force: bool | int | str | None = Field(
        description="\"Force physical removal. Without this, we simple remove the disk from the config file and create an additional configuration entry called \u0027unused[n]\u0027, which contains the volume ID. Unlink of unused[n] always cause physical removal.\"",
    )
    freeze: bool | int | str | None = Field(
        description="\"Freeze CPU at startup (use \u0027c\u0027 monitor command to start execution).\"",
    )
    hookscript: str | None = Field(
        description="\u0027Script that will be executed during various steps in the vms lifetime.\u0027",
    )
    hostpci_n_: str | None = Field(
        description="\u0027Map host PCI devices into guest.\u0027",
    )
    hotplug: str | None = Field(
        default="network,disk,usb",
        description="\"Selectively enable hotplug features. This is a comma separated list of hotplug features: \u0027network\u0027, \u0027disk\u0027, \u0027cpu\u0027, \u0027memory\u0027, \u0027usb\u0027 and \u0027cloudinit\u0027. Use \u00270\u0027 to disable hotplug completely. Using \u00271\u0027 as value is an alias for the default `network,disk,usb`. USB hotplugging is possible for guests with machine version \u003e= 7.1 and ostype l26 or windows \u003e 7.\"",
    )
    hugepages: Literal["1024", "2", "any"] | None = Field(
        description="\u0027Enable/disable hugepages memory.\u0027",
    )
    ide_n_: str | None = Field(
        description="\"Use volume as IDE hard disk or CD-ROM (n is 0 to 3). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    ipconfig_n_: str | None = Field(
        description="\"cloud-init: Specify IP addresses and gateways for the corresponding interface.\\n\\nIP addresses use CIDR notation, gateways are optional but need an IP of the same type specified.\\n\\nThe special string \u0027dhcp\u0027 can be used for IP addresses to use DHCP, in which case no explicit\\ngateway should be provided.\\nFor IPv6 the special string \u0027auto\u0027 can be used to use stateless autoconfiguration. This requires\\ncloud-init 19.4 or newer.\\n\\nIf cloud-init is enabled and neither an IPv4 nor an IPv6 address is specified, it defaults to using\\ndhcp on IPv4.\\n\"",
    )
    ivshmem: str | None = Field(
        description="\u0027Inter-VM shared memory. Useful for direct communication between VMs, or to the host.\u0027",
    )
    keephugepages: bool | int | str | None = Field(
        default=0,
        description="\u0027Use together with hugepages. If enabled, hugepages will not not be deleted after VM shutdown and can be used for subsequent starts.\u0027",
    )
    keyboard: str | None = Field(
        description="\u0027Keyboard layout for VNC server. This option is generally not required and is often better handled from within the guest OS.\u0027",
    )
    kvm: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable KVM hardware virtualization.\u0027",
    )
    localtime: bool | int | str | None = Field(
        description="\u0027Set the real time clock (RTC) to local time. This is enabled by default if the `ostype` indicates a Microsoft Windows OS.\u0027",
    )
    lock: Literal["backup", "clone", "create", "migrate", "rollback", "snapshot", "snapshot-delete", "suspended", "suspending"] | None = Field(
        description="\u0027Lock/unlock the VM.\u0027",
    )
    machine: str | None = Field(
        max_length=40,
        description="\u0027Specifies the QEMU machine type.\u0027",
    )
    memory: int | str | None = Field(
        default=512,
        ge=16,
        description="\u0027Amount of RAM for the VM in MiB. This is the maximum available memory when you use the balloon device.\u0027",
    )
    migrate_downtime: float | str | None = Field(
        default=0.1,
        ge=0.0,
        description="\u0027Set maximum tolerated downtime (in seconds) for migrations.\u0027",
    )
    migrate_speed: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Set maximum speed (in MB/s) for migrations. Value 0 is no limit.\u0027",
    )
    name: str | None = Field(
        description="\u0027Set a name for the VM. Only used on the configuration web interface.\u0027",
    )
    nameserver: str | None = Field(
        description="\u0027cloud-init: Sets DNS server IP address for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    net_n_: str | None = Field(
        description="\u0027Specify network devices.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    numa: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable NUMA.\u0027",
    )
    numa_n_: str | None = Field(
        description="\u0027NUMA topology.\u0027",
    )
    onboot: bool | int | str | None = Field(
        default=0,
        description="\u0027Specifies whether a VM will be started during system bootup.\u0027",
    )
    ostype: str | None = Field(
        description="\u0027Specify guest operating system.\u0027",
    )
    parallel_n_: str | None = Field(
        description="\u0027Map host parallel devices (n is 0 to 2).\u0027",
    )
    protection: bool | int | str | None = Field(
        default=0,
        description="\u0027Sets the protection flag of the VM. This will disable the remove VM and remove disk operations.\u0027",
    )
    reboot: bool | int | str | None = Field(
        default=1,
        description="\"Allow reboot. If set to \u00270\u0027 the VM exit on reboot.\"",
    )
    revert: str | None = Field(
        description="\u0027Revert a pending change.\u0027",
    )
    rng0: str | None = Field(
        description="\u0027Configure a VirtIO-based Random Number Generator.\u0027",
    )
    sata_n_: str | None = Field(
        description="\"Use volume as SATA hard disk or CD-ROM (n is 0 to 5). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsi_n_: str | None = Field(
        description="\"Use volume as SCSI hard disk or CD-ROM (n is 0 to 30). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsihw: Literal["lsi", "lsi53c810", "megasas", "pvscsi", "virtio-scsi-pci", "virtio-scsi-single"] | None = Field(
        default="lsi",
        description="\u0027SCSI controller model\u0027",
    )
    searchdomain: str | None = Field(
        description="\u0027cloud-init: Sets DNS search domains for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    serial_n_: str | None = Field(
        description="\u0027Create a serial device inside the VM (n is 0 to 3)\u0027",
    )
    shares: int | str | None = Field(
        default=1000,
        ge=0,
        le=50000,
        description="\u0027Amount of memory shares for auto-ballooning. The larger the number is, the more memory this VM gets. Number is relative to weights of all other running VMs. Using zero disables auto-ballooning. Auto-ballooning is done by pvestatd.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    smbios1: str | None = Field(
        max_length=512,
        description="\u0027Specify SMBIOS type 1 fields.\u0027",
    )
    smp: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPUs. Please use option -sockets instead.\u0027",
    )
    sockets: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPU sockets.\u0027",
    )
    spice_enhancements: str | None = Field(
        description="\u0027Configure additional enhancements for SPICE.\u0027",
    )
    sshkeys: str | None = Field(
        description="\u0027cloud-init: Setup public SSH keys (one key per line, OpenSSH format).\u0027",
    )
    startdate: str | None = Field(
        default="now",
        description="\"Set the initial date of the real time clock. Valid format for date are:\u0027now\u0027 or \u00272006-06-17T16:01:21\u0027 or \u00272006-06-17\u0027.\"",
    )
    startup: str | None = Field(
        description="\"Startup and shutdown behavior. Order is a non-negative number defining the general startup order. Shutdown in done with reverse ordering. Additionally you can set the \u0027up\u0027 or \u0027down\u0027 delay in seconds, which specifies a delay to wait before the next VM is started or stopped.\"",
    )
    tablet: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable the USB tablet device.\u0027",
    )
    tags: str | None = Field(
        description="\u0027Tags of the VM. This is only meta information.\u0027",
    )
    tdf: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable time drift fix.\u0027",
    )
    template: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable Template.\u0027",
    )
    tpmstate0: str | None = Field(
        description="\"Configure a Disk for storing TPM state. The format is fixed to \u0027raw\u0027. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and 4 MiB will be used instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    unused_n_: str | None = Field(
        description="\u0027Reference to unused volumes. This is used internally, and should not be modified manually.\u0027",
    )
    usb_n_: str | None = Field(
        description="\u0027Configure an USB device (n is 0 to 4, for machine version \u003e= 7.1 and ostype l26 or windows \u003e 7, n can be up to 14).\u0027",
    )
    vcpus: int | str | None = Field(
        default=0,
        ge=1,
        description="\u0027Number of hotplugged vcpus.\u0027",
    )
    vga: str | None = Field(
        description="\u0027Configure the VGA hardware.\u0027",
    )
    virtio_n_: str | None = Field(
        description="\"Use volume as VIRTIO hard disk (n is 0 to 15). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    vmgenid: str | None = Field(
        default="1 (autogenerated)",
        description="\"Set VM Generation ID. Use \u00271\u0027 to autogenerate on create or update, pass \u00270\u0027 to disable explicitly.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmstatestorage: str | None = Field(
        description="\u0027Default storage for VM state volumes/files.\u0027",
    )
    watchdog: str | None = Field(
        description="\u0027Create a virtual hardware watchdog device.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ConfigPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/config POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ConfigPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/config PUT
    """
    acpi: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable ACPI.\u0027",
    )
    affinity: str | None = Field(
        description="\u0027List of host cores used to execute guest processes, for example: 0,5,8-11\u0027",
    )
    agent: str | None = Field(
        description="\u0027Enable/disable communication with the QEMU Guest Agent and its properties.\u0027",
    )
    arch: Literal["aarch64", "x86_64"] | None = Field(
        description="\u0027Virtual processor architecture. Defaults to the host.\u0027",
    )
    args: str | None = Field(
        description="\u0027Arbitrary arguments passed to kvm.\u0027",
    )
    audio0: str | None = Field(
        description="\u0027Configure a audio device, useful in combination with QXL/Spice.\u0027",
    )
    autostart: bool | int | str | None = Field(
        default=0,
        description="\u0027Automatic restart after crash (currently ignored).\u0027",
    )
    balloon: int | str | None = Field(
        ge=0,
        description="\u0027Amount of target RAM for the VM in MiB. Using zero disables the ballon driver.\u0027",
    )
    bios: Literal["ovmf", "seabios"] | None = Field(
        default="seabios",
        description="\u0027Select BIOS implementation.\u0027",
    )
    boot: str | None = Field(
        description="\"Specify guest boot order. Use the \u0027order=\u0027 sub-property as usage with no key or \u0027legacy=\u0027 is deprecated.\"",
    )
    bootdisk: str | None = Field(
        description="\"Enable booting from specified disk. Deprecated: Use \u0027boot: order=foo;bar\u0027 instead.\"",
    )
    cdrom: str | None = Field(
        description="\u0027This is an alias for option -ide2\u0027",
    )
    cicustom: str | None = Field(
        description="\u0027cloud-init: Specify custom files to replace the automatically generated ones at start.\u0027",
    )
    cipassword: str | None = Field(
        description="\u0027cloud-init: Password to assign the user. Using this is generally not recommended. Use ssh keys instead. Also note that older cloud-init versions do not support hashed passwords.\u0027",
    )
    citype: Literal["configdrive2", "nocloud", "opennebula"] | None = Field(
        description="\u0027Specifies the cloud-init configuration format. The default depends on the configured operating system type (`ostype`. We use the `nocloud` format for Linux, and `configdrive2` for windows.\u0027",
    )
    ciuser: str | None = Field(
        description="\"cloud-init: User name to change ssh keys and password for instead of the image\u0027s configured default user.\"",
    )
    cores: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of cores per socket.\u0027",
    )
    cpu: str | None = Field(
        description="\u0027Emulated CPU type.\u0027",
    )
    cpulimit: float | str | None = Field(
        default=0,
        ge=0.0,
        le=128.0,
        description="\u0027Limit of CPU usage.\u0027",
    )
    cpuunits: int | str | None = Field(
        default="cgroup v1: 1024, cgroup v2: 100",
        ge=1,
        le=262144,
        description="\u0027CPU weight for a VM, will be clamped to [1, 10000] in cgroup v2.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    description: str | None = Field(
        max_length=8192,
        description="\"Description for the VM. Shown in the web-interface VM\u0027s summary. This is saved as comment inside the configuration file.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    efidisk0: str | None = Field(
        description="\"Configure a disk for storing EFI vars. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and that the default EFI vars are copied to the volume instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    force: bool | int | str | None = Field(
        description="\"Force physical removal. Without this, we simple remove the disk from the config file and create an additional configuration entry called \u0027unused[n]\u0027, which contains the volume ID. Unlink of unused[n] always cause physical removal.\"",
    )
    freeze: bool | int | str | None = Field(
        description="\"Freeze CPU at startup (use \u0027c\u0027 monitor command to start execution).\"",
    )
    hookscript: str | None = Field(
        description="\u0027Script that will be executed during various steps in the vms lifetime.\u0027",
    )
    hostpci_n_: str | None = Field(
        description="\u0027Map host PCI devices into guest.\u0027",
    )
    hotplug: str | None = Field(
        default="network,disk,usb",
        description="\"Selectively enable hotplug features. This is a comma separated list of hotplug features: \u0027network\u0027, \u0027disk\u0027, \u0027cpu\u0027, \u0027memory\u0027, \u0027usb\u0027 and \u0027cloudinit\u0027. Use \u00270\u0027 to disable hotplug completely. Using \u00271\u0027 as value is an alias for the default `network,disk,usb`. USB hotplugging is possible for guests with machine version \u003e= 7.1 and ostype l26 or windows \u003e 7.\"",
    )
    hugepages: Literal["1024", "2", "any"] | None = Field(
        description="\u0027Enable/disable hugepages memory.\u0027",
    )
    ide_n_: str | None = Field(
        description="\"Use volume as IDE hard disk or CD-ROM (n is 0 to 3). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    ipconfig_n_: str | None = Field(
        description="\"cloud-init: Specify IP addresses and gateways for the corresponding interface.\\n\\nIP addresses use CIDR notation, gateways are optional but need an IP of the same type specified.\\n\\nThe special string \u0027dhcp\u0027 can be used for IP addresses to use DHCP, in which case no explicit\\ngateway should be provided.\\nFor IPv6 the special string \u0027auto\u0027 can be used to use stateless autoconfiguration. This requires\\ncloud-init 19.4 or newer.\\n\\nIf cloud-init is enabled and neither an IPv4 nor an IPv6 address is specified, it defaults to using\\ndhcp on IPv4.\\n\"",
    )
    ivshmem: str | None = Field(
        description="\u0027Inter-VM shared memory. Useful for direct communication between VMs, or to the host.\u0027",
    )
    keephugepages: bool | int | str | None = Field(
        default=0,
        description="\u0027Use together with hugepages. If enabled, hugepages will not not be deleted after VM shutdown and can be used for subsequent starts.\u0027",
    )
    keyboard: str | None = Field(
        description="\u0027Keyboard layout for VNC server. This option is generally not required and is often better handled from within the guest OS.\u0027",
    )
    kvm: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable KVM hardware virtualization.\u0027",
    )
    localtime: bool | int | str | None = Field(
        description="\u0027Set the real time clock (RTC) to local time. This is enabled by default if the `ostype` indicates a Microsoft Windows OS.\u0027",
    )
    lock: Literal["backup", "clone", "create", "migrate", "rollback", "snapshot", "snapshot-delete", "suspended", "suspending"] | None = Field(
        description="\u0027Lock/unlock the VM.\u0027",
    )
    machine: str | None = Field(
        max_length=40,
        description="\u0027Specifies the QEMU machine type.\u0027",
    )
    memory: int | str | None = Field(
        default=512,
        ge=16,
        description="\u0027Amount of RAM for the VM in MiB. This is the maximum available memory when you use the balloon device.\u0027",
    )
    migrate_downtime: float | str | None = Field(
        default=0.1,
        ge=0.0,
        description="\u0027Set maximum tolerated downtime (in seconds) for migrations.\u0027",
    )
    migrate_speed: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Set maximum speed (in MB/s) for migrations. Value 0 is no limit.\u0027",
    )
    name: str | None = Field(
        description="\u0027Set a name for the VM. Only used on the configuration web interface.\u0027",
    )
    nameserver: str | None = Field(
        description="\u0027cloud-init: Sets DNS server IP address for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    net_n_: str | None = Field(
        description="\u0027Specify network devices.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    numa: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable NUMA.\u0027",
    )
    numa_n_: str | None = Field(
        description="\u0027NUMA topology.\u0027",
    )
    onboot: bool | int | str | None = Field(
        default=0,
        description="\u0027Specifies whether a VM will be started during system bootup.\u0027",
    )
    ostype: str | None = Field(
        description="\u0027Specify guest operating system.\u0027",
    )
    parallel_n_: str | None = Field(
        description="\u0027Map host parallel devices (n is 0 to 2).\u0027",
    )
    protection: bool | int | str | None = Field(
        default=0,
        description="\u0027Sets the protection flag of the VM. This will disable the remove VM and remove disk operations.\u0027",
    )
    reboot: bool | int | str | None = Field(
        default=1,
        description="\"Allow reboot. If set to \u00270\u0027 the VM exit on reboot.\"",
    )
    revert: str | None = Field(
        description="\u0027Revert a pending change.\u0027",
    )
    rng0: str | None = Field(
        description="\u0027Configure a VirtIO-based Random Number Generator.\u0027",
    )
    sata_n_: str | None = Field(
        description="\"Use volume as SATA hard disk or CD-ROM (n is 0 to 5). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsi_n_: str | None = Field(
        description="\"Use volume as SCSI hard disk or CD-ROM (n is 0 to 30). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    scsihw: Literal["lsi", "lsi53c810", "megasas", "pvscsi", "virtio-scsi-pci", "virtio-scsi-single"] | None = Field(
        default="lsi",
        description="\u0027SCSI controller model\u0027",
    )
    searchdomain: str | None = Field(
        description="\u0027cloud-init: Sets DNS search domains for a container. Create will automatically use the setting from the host if neither searchdomain nor nameserver are set.\u0027",
    )
    serial_n_: str | None = Field(
        description="\u0027Create a serial device inside the VM (n is 0 to 3)\u0027",
    )
    shares: int | str | None = Field(
        default=1000,
        ge=0,
        le=50000,
        description="\u0027Amount of memory shares for auto-ballooning. The larger the number is, the more memory this VM gets. Number is relative to weights of all other running VMs. Using zero disables auto-ballooning. Auto-ballooning is done by pvestatd.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    smbios1: str | None = Field(
        max_length=512,
        description="\u0027Specify SMBIOS type 1 fields.\u0027",
    )
    smp: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPUs. Please use option -sockets instead.\u0027",
    )
    sockets: int | str | None = Field(
        default=1,
        ge=1,
        description="\u0027The number of CPU sockets.\u0027",
    )
    spice_enhancements: str | None = Field(
        description="\u0027Configure additional enhancements for SPICE.\u0027",
    )
    sshkeys: str | None = Field(
        description="\u0027cloud-init: Setup public SSH keys (one key per line, OpenSSH format).\u0027",
    )
    startdate: str | None = Field(
        default="now",
        description="\"Set the initial date of the real time clock. Valid format for date are:\u0027now\u0027 or \u00272006-06-17T16:01:21\u0027 or \u00272006-06-17\u0027.\"",
    )
    startup: str | None = Field(
        description="\"Startup and shutdown behavior. Order is a non-negative number defining the general startup order. Shutdown in done with reverse ordering. Additionally you can set the \u0027up\u0027 or \u0027down\u0027 delay in seconds, which specifies a delay to wait before the next VM is started or stopped.\"",
    )
    tablet: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable the USB tablet device.\u0027",
    )
    tags: str | None = Field(
        description="\u0027Tags of the VM. This is only meta information.\u0027",
    )
    tdf: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable time drift fix.\u0027",
    )
    template: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable Template.\u0027",
    )
    tpmstate0: str | None = Field(
        description="\"Configure a Disk for storing TPM state. The format is fixed to \u0027raw\u0027. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Note that SIZE_IN_GiB is ignored here and 4 MiB will be used instead. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    unused_n_: str | None = Field(
        description="\u0027Reference to unused volumes. This is used internally, and should not be modified manually.\u0027",
    )
    usb_n_: str | None = Field(
        description="\u0027Configure an USB device (n is 0 to 4, for machine version \u003e= 7.1 and ostype l26 or windows \u003e 7, n can be up to 14).\u0027",
    )
    vcpus: int | str | None = Field(
        default=0,
        ge=1,
        description="\u0027Number of hotplugged vcpus.\u0027",
    )
    vga: str | None = Field(
        description="\u0027Configure the VGA hardware.\u0027",
    )
    virtio_n_: str | None = Field(
        description="\"Use volume as VIRTIO hard disk (n is 0 to 15). Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume. Use STORAGE_ID:0 and the \u0027import-from\u0027 parameter to import from an existing volume.\"",
    )
    vmgenid: str | None = Field(
        default="1 (autogenerated)",
        description="\"Set VM Generation ID. Use \u00271\u0027 to autogenerate on create or update, pass \u00270\u0027 to disable explicitly.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmstatestorage: str | None = Field(
        description="\u0027Default storage for VM state volumes/files.\u0027",
    )
    watchdog: str | None = Field(
        description="\u0027Create a virtual hardware watchdog device.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_PendingGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/pending GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_PendingGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/pending GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_CloudinitGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/cloudinit GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_CloudinitGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/cloudinit GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_CloudinitPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/cloudinit PUT
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Cloudinit_DumpGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/cloudinit/dump GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    type: Literal["meta", "network", "user"] = Field(
        description="\u0027Config type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Cloudinit_DumpGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/cloudinit/dump GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_UnlinkPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/unlink PUT
    """
    force: bool | int | str | None = Field(
        description="\"Force physical removal. Without this, we simple remove the disk from the config file and create an additional configuration entry called \u0027unused[n]\u0027, which contains the volume ID. Unlink of unused[n] always cause physical removal.\"",
    )
    idlist: str = Field(
        description="\u0027A list of disk IDs you want to delete.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_VncproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/vncproxy POST
    """
    generate_password: bool | int | str | None = Field(
        default=0,
        description="\u0027Generates a random password to be used as ticket instead of the API ticket.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    websocket: bool | int | str | None = Field(
        description="\u0027starts websockify instead of vncproxy\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_VncproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/vncproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_TermproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/termproxy POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    serial: Literal["serial0", "serial1", "serial2", "serial3"] | None = Field(
        description="\u0027opens a serial terminal (defaults to display)\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_TermproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/termproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_VncwebsocketGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/vncwebsocket GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    port: int | str = Field(
        ge=5900,
        le=5999,
        description="\u0027Port number returned by previous vncproxy call.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vncticket: str = Field(
        max_length=512,
        description="\u0027Ticket from previous call to vncproxy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_VncwebsocketGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/vncwebsocket GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SpiceproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/spiceproxy POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    proxy: str | None = Field(
        description="\"SPICE proxy server. This can be used by the client to specify the proxy server. All nodes in a cluster runs \u0027spiceproxy\u0027, so it is up to the client to choose one. By default, we return the node where the VM is currently running. As reasonable setting is to use same node you use to connect to the API (This is window.location.hostname for the JS GUI).\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SpiceproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/spiceproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_CurrentGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/current GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_CurrentGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/current GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_StartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/start POST
    """
    force_cpu: str | None = Field(
        description="\"Override QEMU\u0027s -cpu argument with the given string.\"",
    )
    machine: str | None = Field(
        max_length=40,
        description="\u0027Specifies the QEMU machine type.\u0027",
    )
    migratedfrom: ProxmoxNode | None = Field(
        description="\u0027The cluster node name.\u0027",
    )
    migration_network: str | None = Field(
        description="\u0027CIDR of the (sub) network that is used for migration.\u0027",
    )
    migration_type: Literal["insecure", "secure"] | None = Field(
        description="\u0027Migration traffic is encrypted using an SSH tunnel by default. On secure, completely private networks this can be disabled to increase performance.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    stateuri: str | None = Field(
        max_length=128,
        description="\u0027Some command save/restore state from this location.\u0027",
    )
    targetstorage: str | None = Field(
        description="\"Mapping from source to target storages. Providing only a single storage ID maps all source storages to that storage. Providing the special value \u00271\u0027 will map each source storage to itself.\"",
    )
    timeout: int | str | None = Field(
        default="max(30, vm memory in GiB)",
        ge=0,
        description="\u0027Wait maximal timeout seconds.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_StartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/start POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_StopPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/stop POST
    """
    keepActive: bool | int | str | None = Field(
        default=0,
        description="\u0027Do not deactivate storage volumes.\u0027",
    )
    migratedfrom: ProxmoxNode | None = Field(
        description="\u0027The cluster node name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    timeout: int | str | None = Field(
        ge=0,
        description="\u0027Wait maximal timeout seconds.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_StopPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/stop POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ResetPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/reset POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ResetPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/reset POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ShutdownPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/shutdown POST
    """
    forceStop: bool | int | str | None = Field(
        default=0,
        description="\u0027Make sure the VM stops.\u0027",
    )
    keepActive: bool | int | str | None = Field(
        default=0,
        description="\u0027Do not deactivate storage volumes.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    timeout: int | str | None = Field(
        ge=0,
        description="\u0027Wait maximal timeout seconds.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ShutdownPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/shutdown POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_RebootPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/reboot POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeout: int | str | None = Field(
        ge=0,
        description="\u0027Wait maximal timeout seconds for the shutdown.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_RebootPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/reboot POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_SuspendPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/suspend POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    statestorage: str | None = Field(
        description="\u0027The storage for the VM state\u0027",
    )
    todisk: bool | int | str | None = Field(
        default=0,
        description="\u0027If set, suspends the VM to disk. Will be resumed on next VM start.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_SuspendPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/suspend POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ResumePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/status/resume POST
    """
    nocheck: bool | int | str | None = Field(
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Status_ResumePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/status/resume POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SendkeyPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/sendkey PUT
    """
    key: str = Field(
        description="\u0027The key (qemu monitor encoding).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_FeatureGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/feature GET
    """
    feature: Literal["clone", "copy", "snapshot"] = Field(
        description="\u0027Feature to check.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str | None = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_FeatureGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/feature GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ClonePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/clone POST
    """
    bwlimit: int | str | None = Field(
        default="clone limit from datacenter or storage config",
        ge=0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    description: str | None = Field(
        description="\u0027Description for the new VM.\u0027",
    )
    format: Literal["qcow2", "raw", "vmdk"] | None = Field(
        description="\u0027Target format for file storage. Only valid for full clone.\u0027",
    )
    full: bool | int | str | None = Field(
        description="\u0027Create a full copy of all disks. This is always done when you clone a normal VM. For VM templates, we try to create a linked clone by default.\u0027",
    )
    name: str | None = Field(
        description="\u0027Set a name for the new VM.\u0027",
    )
    newid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027VMID for the clone.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Add the new VM to the specified pool.\u0027",
    )
    snapname: str | None = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    storage: str | None = Field(
        description="\u0027Target storage for full clone.\u0027",
    )
    target: ProxmoxNode | None = Field(
        description="\u0027Target node. Only allowed if the original VM is on shared storage.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ClonePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/clone POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Move_DiskPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/move_disk POST
    """
    bwlimit: int | str | None = Field(
        default="move limit from datacenter or storage config",
        ge=0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    delete: bool | int | str | None = Field(
        default=0,
        description="\u0027Delete the original disk after successful copy. By default the original disk is kept as unused disk.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1\"\\n\\t\\t    .\" digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disk: str = Field(
        description="\u0027The disk you want to move.\u0027",
    )
    format: Literal["qcow2", "raw", "vmdk"] | None = Field(
        description="\u0027Target Format.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027Target storage.\u0027",
    )
    target_digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if the current config file of the target VM has a\"\\n\\t\\t    .\" different SHA1 digest. This can be used to detect concurrent modifications.\u0027",
    )
    target_disk: str | None = Field(
        description="\u0027The config key the disk will be moved to on the target VM (for example, ide0 or scsi1). Default is the source disk key.\u0027",
    )
    target_vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Move_DiskPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/move_disk POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MigrateGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/migrate GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    target: ProxmoxNode | None = Field(
        description="\u0027Target node.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MigrateGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/migrate GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MigratePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/migrate POST
    """
    bwlimit: int | str | None = Field(
        default="migrate limit from datacenter or storage config",
        ge=0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    force: bool | int | str | None = Field(
        description="\u0027Allow to migrate VMs which use local devices. Only root may use this option.\u0027",
    )
    migration_network: str | None = Field(
        description="\u0027CIDR of the (sub) network that is used for migration.\u0027",
    )
    migration_type: Literal["insecure", "secure"] | None = Field(
        description="\u0027Migration traffic is encrypted using an SSH tunnel by default. On secure, completely private networks this can be disabled to increase performance.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    online: bool | int | str | None = Field(
        description="\u0027Use online/live migration if VM is running. Ignored if VM is stopped.\u0027",
    )
    target: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    targetstorage: str | None = Field(
        description="\"Mapping from source to target storages. Providing only a single storage ID maps all source storages to that storage. Providing the special value \u00271\u0027 will map each source storage to itself.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    with_local_disks: bool | int | str | None = Field(
        description="\u0027Enable live storage migration for local disk\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MigratePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/migrate POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Remote_MigratePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/remote_migrate POST
    """
    bwlimit: int | str | None = Field(
        default="migrate limit from datacenter or storage config",
        ge=0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    delete: bool | int | str | None = Field(
        default=0,
        description="\u0027Delete the original VM and related data after successful migration. By default the original VM is kept on the source cluster in a stopped state.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    online: bool | int | str | None = Field(
        description="\u0027Use online/live migration if VM is running. Ignored if VM is stopped.\u0027",
    )
    target_bridge: str = Field(
        description="\"Mapping from source to target bridges. Providing only a single bridge ID maps all source bridges to that bridge. Providing the special value \u00271\u0027 will map each source bridge to itself.\"",
    )
    target_endpoint: str = Field(
        description="\u0027Remote target endpoint\u0027",
    )
    target_storage: str = Field(
        description="\"Mapping from source to target storages. Providing only a single storage ID maps all source storages to that storage. Providing the special value \u00271\u0027 will map each source storage to itself.\"",
    )
    target_vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Remote_MigratePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/remote_migrate POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MonitorPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/monitor POST
    """
    command: str = Field(
        description="\u0027The monitor command.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MonitorPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/monitor POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_ResizePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/resize PUT
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disk: str = Field(
        description="\u0027The disk you want to resize.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    size: str = Field(
        description="\u0027The new size. With the `+` sign the value is added to the actual size of the volume and without it, the value is taken as an absolute one. Shrinking disk size is not supported.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SnapshotGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SnapshotGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SnapshotPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot POST
    """
    description: str | None = Field(
        description="\u0027A textual description or comment.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vmstate: bool | int | str | None = Field(
        description="\u0027Save the vmstate\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_SnapshotPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_SnapnameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname} DELETE
    """
    force: bool | int | str | None = Field(
        description="\u0027For removal from config file, even if removing disk snapshots fails.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_SnapnameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_SnapnameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_SnapnameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_Snapname_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname}/config GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_Snapname_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname}/config GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_Snapname_ConfigPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname}/config PUT
    """
    description: str | None = Field(
        description="\u0027A textual description or comment.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_Snapname_RollbackPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname}/rollback POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    start: bool | int | str | None = Field(
        default=0,
        description="\u0027Whether the VM should get started after rolling back successfully. (Note: VMs will be automatically started if the snapshot includes RAM.)\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_Snapshot_Snapname_RollbackPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/snapshot/{snapname}/rollback POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_TemplatePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/template POST
    """
    disk: str | None = Field(
        description="\u0027If you want to convert only 1 disk to base image.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_TemplatePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/template POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MtunnelPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/mtunnel POST
    """
    bridges: str | None = Field(
        description="\u0027List of network bridges to check availability. Will be checked again for actually used bridges during migration.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storages: list[str] | None = Field(
        description="\u0027List of storages to check permission and availability. Will be checked again for all actually used storages during migration.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MtunnelPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/mtunnel POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MtunnelwebsocketGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/qemu/{vmid}/mtunnelwebsocket GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    socket: str = Field(
        description="\u0027unix socket to forward to\u0027",
    )
    ticket: str = Field(
        description="\"ticket return by initial \u0027mtunnel\u0027 API call, or retrieved via \u0027ticket\u0027 tunnel command\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Qemu_Vmid_MtunnelwebsocketGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/qemu/{vmid}/mtunnelwebsocket GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_LxcGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_LxcGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_LxcPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc POST
    """
    arch: Literal["amd64", "arm64", "armhf", "i386", "riscv32", "riscv64"] | None = Field(
        default="amd64",
        description="\u0027OS architecture type.\u0027",
    )
    bwlimit: float | str | None = Field(
        default="restore limit from datacenter or storage config",
        ge=0.0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    cmode: Literal["console", "shell", "tty"] | None = Field(
        default="tty",
        description="\"Console mode. By default, the console command tries to open a connection to one of the available tty devices. By setting cmode to \u0027console\u0027 it tries to attach to /dev/console instead. If you set cmode to \u0027shell\u0027, it simply invokes a shell inside the container (no login).\"",
    )
    console: bool | int | str | None = Field(
        default=1,
        description="\u0027Attach a console device (/dev/console) to the container.\u0027",
    )
    cores: int | str | None = Field(
        ge=1,
        le=8192,
        description="\u0027The number of cores assigned to the container. A container can use all available cores by default.\u0027",
    )
    cpulimit: float | str | None = Field(
        default=0,
        ge=0.0,
        le=8192.0,
        description="\"Limit of CPU usage.\\n\\nNOTE: If the computer has 2 CPUs, it has a total of \u00272\u0027 CPU time. Value \u00270\u0027 indicates no CPU limit.\"",
    )
    cpuunits: int | str | None = Field(
        default="cgroup v1: 1024, cgroup v2: 100",
        ge=0,
        le=500000,
        description="\u0027CPU weight for a container, will be clamped to [1, 10000] in cgroup v2.\u0027",
    )
    debug: bool | int | str | None = Field(
        default=0,
        description="\u0027Try to be more verbose. For now this only enables debug log-level on start.\u0027",
    )
    description: str | None = Field(
        max_length=8192,
        description="\"Description for the Container. Shown in the web-interface CT\u0027s summary. This is saved as comment inside the configuration file.\"",
    )
    features: str | None = Field(
        description="\u0027Allow containers access to advanced features.\u0027",
    )
    force: bool | int | str | None = Field(
        description="\u0027Allow to overwrite existing container.\u0027",
    )
    hookscript: str | None = Field(
        description="\u0027Script that will be exectued during various steps in the containers lifetime.\u0027",
    )
    hostname: str | None = Field(
        max_length=255,
        description="\u0027Set a host name for the container.\u0027",
    )
    ignore_unpack_errors: bool | int | str | None = Field(
        description="\u0027Ignore errors when extracting the template.\u0027",
    )
    lock: Literal["backup", "create", "destroyed", "disk", "fstrim", "migrate", "mounted", "rollback", "snapshot", "snapshot-delete"] | None = Field(
        description="\u0027Lock/unlock the container.\u0027",
    )
    memory: int | str | None = Field(
        default=512,
        ge=16,
        description="\u0027Amount of RAM for the container in MB.\u0027",
    )
    mp_n_: str | None = Field(
        description="\u0027Use volume as container mount point. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume.\u0027",
    )
    nameserver: str | None = Field(
        description="\u0027Sets DNS server IP address for a container. Create will automatically use the setting from the host if you neither set searchdomain nor nameserver.\u0027",
    )
    net_n_: str | None = Field(
        description="\u0027Specifies network interfaces for the container.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    onboot: bool | int | str | None = Field(
        default=0,
        description="\u0027Specifies whether a container will be started during system bootup.\u0027",
    )
    ostemplate: str = Field(
        max_length=255,
        description="\u0027The OS template or backup file.\u0027",
    )
    ostype: str | None = Field(
        description="\"OS type. This is used to setup configuration inside the container, and corresponds to lxc setup scripts in /usr/share/lxc/config/\u003costype\u003e.common.conf. Value \u0027unmanaged\u0027 can be used to skip and OS specific setup.\"",
    )
    password: str | None = Field(
        description="\u0027Sets root password inside container.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Add the VM to the specified pool.\u0027",
    )
    protection: bool | int | str | None = Field(
        default=0,
        description="\"Sets the protection flag of the container. This will prevent the CT or CT\u0027s disk remove/update operation.\"",
    )
    restore: bool | int | str | None = Field(
        description="\u0027Mark this as restore task.\u0027",
    )
    rootfs: str | None = Field(
        description="\u0027Use volume as container root.\u0027",
    )
    searchdomain: str | None = Field(
        description="\u0027Sets DNS search domains for a container. Create will automatically use the setting from the host if you neither set searchdomain nor nameserver.\u0027",
    )
    ssh_public_keys: str | None = Field(
        description="\u0027Setup public SSH keys (one key per line, OpenSSH format).\u0027",
    )
    start: bool | int | str | None = Field(
        default=0,
        description="\u0027Start the CT after its creation finished successfully.\u0027",
    )
    startup: str | None = Field(
        description="\"Startup and shutdown behavior. Order is a non-negative number defining the general startup order. Shutdown in done with reverse ordering. Additionally you can set the \u0027up\u0027 or \u0027down\u0027 delay in seconds, which specifies a delay to wait before the next VM is started or stopped.\"",
    )
    storage: str | None = Field(
        default="local",
        description="\u0027Default Storage.\u0027",
    )
    swap: int | str | None = Field(
        default=512,
        ge=0,
        description="\u0027Amount of SWAP for the container in MB.\u0027",
    )
    tags: str | None = Field(
        description="\u0027Tags of the Container. This is only meta information.\u0027",
    )
    template: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable Template.\u0027",
    )
    timezone: str | None = Field(
        description="\"Time zone to use in the container. If option isn\u0027t set, then nothing will be done. Can be set to \u0027host\u0027 to match the host time zone, or an arbitrary time zone option from /usr/share/zoneinfo/zone.tab\"",
    )
    tty: int | str | None = Field(
        default=2,
        ge=0,
        le=6,
        description="\u0027Specify the number of tty available to the container\u0027",
    )
    unique: bool | int | str | None = Field(
        description="\u0027Assign a unique random ethernet address.\u0027",
    )
    unprivileged: bool | int | str | None = Field(
        default=0,
        description="\u0027Makes the container run as unprivileged user. (Should not be modified manually.)\u0027",
    )
    unused_n_: str | None = Field(
        description="\u0027Reference to unused volumes. This is used internally, and should not be modified manually.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_LxcPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_VmidDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid} DELETE
    """
    destroy_unreferenced_disks: bool | int | str | None = Field(
        description="\u0027If set, destroy additionally all disks with the VMID from all enabled storages which are not referenced in the config.\u0027",
    )
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Force destroy, even if running.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    purge: bool | int | str | None = Field(
        default=0,
        description="\u0027Remove container from all related configurations. For example, backup jobs, replication jobs or HA. Related ACLs and Firewall entries will *always* be removed.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_VmidDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_VmidGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_VmidGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/config GET
    """
    current: bool | int | str | None = Field(
        default=0,
        description="\u0027Get current values (instead of pending values).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapshot: str | None = Field(
        max_length=40,
        description="\u0027Fetch config values from given snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/config GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ConfigPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/config PUT
    """
    arch: Literal["amd64", "arm64", "armhf", "i386", "riscv32", "riscv64"] | None = Field(
        default="amd64",
        description="\u0027OS architecture type.\u0027",
    )
    cmode: Literal["console", "shell", "tty"] | None = Field(
        default="tty",
        description="\"Console mode. By default, the console command tries to open a connection to one of the available tty devices. By setting cmode to \u0027console\u0027 it tries to attach to /dev/console instead. If you set cmode to \u0027shell\u0027, it simply invokes a shell inside the container (no login).\"",
    )
    console: bool | int | str | None = Field(
        default=1,
        description="\u0027Attach a console device (/dev/console) to the container.\u0027",
    )
    cores: int | str | None = Field(
        ge=1,
        le=8192,
        description="\u0027The number of cores assigned to the container. A container can use all available cores by default.\u0027",
    )
    cpulimit: float | str | None = Field(
        default=0,
        ge=0.0,
        le=8192.0,
        description="\"Limit of CPU usage.\\n\\nNOTE: If the computer has 2 CPUs, it has a total of \u00272\u0027 CPU time. Value \u00270\u0027 indicates no CPU limit.\"",
    )
    cpuunits: int | str | None = Field(
        default="cgroup v1: 1024, cgroup v2: 100",
        ge=0,
        le=500000,
        description="\u0027CPU weight for a container, will be clamped to [1, 10000] in cgroup v2.\u0027",
    )
    debug: bool | int | str | None = Field(
        default=0,
        description="\u0027Try to be more verbose. For now this only enables debug log-level on start.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    description: str | None = Field(
        max_length=8192,
        description="\"Description for the Container. Shown in the web-interface CT\u0027s summary. This is saved as comment inside the configuration file.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    features: str | None = Field(
        description="\u0027Allow containers access to advanced features.\u0027",
    )
    hookscript: str | None = Field(
        description="\u0027Script that will be exectued during various steps in the containers lifetime.\u0027",
    )
    hostname: str | None = Field(
        max_length=255,
        description="\u0027Set a host name for the container.\u0027",
    )
    lock: Literal["backup", "create", "destroyed", "disk", "fstrim", "migrate", "mounted", "rollback", "snapshot", "snapshot-delete"] | None = Field(
        description="\u0027Lock/unlock the container.\u0027",
    )
    memory: int | str | None = Field(
        default=512,
        ge=16,
        description="\u0027Amount of RAM for the container in MB.\u0027",
    )
    mp_n_: str | None = Field(
        description="\u0027Use volume as container mount point. Use the special syntax STORAGE_ID:SIZE_IN_GiB to allocate a new volume.\u0027",
    )
    nameserver: str | None = Field(
        description="\u0027Sets DNS server IP address for a container. Create will automatically use the setting from the host if you neither set searchdomain nor nameserver.\u0027",
    )
    net_n_: str | None = Field(
        description="\u0027Specifies network interfaces for the container.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    onboot: bool | int | str | None = Field(
        default=0,
        description="\u0027Specifies whether a container will be started during system bootup.\u0027",
    )
    ostype: str | None = Field(
        description="\"OS type. This is used to setup configuration inside the container, and corresponds to lxc setup scripts in /usr/share/lxc/config/\u003costype\u003e.common.conf. Value \u0027unmanaged\u0027 can be used to skip and OS specific setup.\"",
    )
    protection: bool | int | str | None = Field(
        default=0,
        description="\"Sets the protection flag of the container. This will prevent the CT or CT\u0027s disk remove/update operation.\"",
    )
    revert: str | None = Field(
        description="\u0027Revert a pending change.\u0027",
    )
    rootfs: str | None = Field(
        description="\u0027Use volume as container root.\u0027",
    )
    searchdomain: str | None = Field(
        description="\u0027Sets DNS search domains for a container. Create will automatically use the setting from the host if you neither set searchdomain nor nameserver.\u0027",
    )
    startup: str | None = Field(
        description="\"Startup and shutdown behavior. Order is a non-negative number defining the general startup order. Shutdown in done with reverse ordering. Additionally you can set the \u0027up\u0027 or \u0027down\u0027 delay in seconds, which specifies a delay to wait before the next VM is started or stopped.\"",
    )
    swap: int | str | None = Field(
        default=512,
        ge=0,
        description="\u0027Amount of SWAP for the container in MB.\u0027",
    )
    tags: str | None = Field(
        description="\u0027Tags of the Container. This is only meta information.\u0027",
    )
    template: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable Template.\u0027",
    )
    timezone: str | None = Field(
        description="\"Time zone to use in the container. If option isn\u0027t set, then nothing will be done. Can be set to \u0027host\u0027 to match the host time zone, or an arbitrary time zone option from /usr/share/zoneinfo/zone.tab\"",
    )
    tty: int | str | None = Field(
        default=2,
        ge=0,
        le=6,
        description="\u0027Specify the number of tty available to the container\u0027",
    )
    unprivileged: bool | int | str | None = Field(
        default=0,
        description="\u0027Makes the container run as unprivileged user. (Should not be modified manually.)\u0027",
    )
    unused_n_: str | None = Field(
        description="\u0027Reference to unused volumes. This is used internally, and should not be modified manually.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_CurrentGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/current GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_CurrentGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/current GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_StartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/start POST
    """
    debug: bool | int | str | None = Field(
        default=0,
        description="\u0027If set, enables very verbose debug log-level on start.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_StartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/start POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_StopPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/stop POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skiplock: bool | int | str | None = Field(
        description="\u0027Ignore locks - only root is allowed to use this option.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_StopPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/stop POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_ShutdownPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/shutdown POST
    """
    forceStop: bool | int | str | None = Field(
        default=0,
        description="\u0027Make sure the Container stops.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeout: int | str | None = Field(
        default=60,
        ge=0,
        description="\u0027Wait maximal timeout seconds.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_ShutdownPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/shutdown POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_SuspendPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/suspend POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_SuspendPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/suspend POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_ResumePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/resume POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_ResumePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/resume POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_RebootPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/status/reboot POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeout: int | str | None = Field(
        ge=0,
        description="\u0027Wait maximal timeout seconds for the shutdown.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Status_RebootPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/status/reboot POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SnapshotGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SnapshotGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SnapshotPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot POST
    """
    description: str | None = Field(
        description="\u0027A textual description or comment.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SnapshotPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_SnapnameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname} DELETE
    """
    force: bool | int | str | None = Field(
        description="\u0027For removal from config file, even if removing disk snapshots fails.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_SnapnameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_SnapnameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_SnapnameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_Snapname_RollbackPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname}/rollback POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    start: bool | int | str | None = Field(
        default=0,
        description="\u0027Whether the container should get started after rolling back successfully\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_Snapname_RollbackPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname}/rollback POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_Snapname_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname}/config GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_Snapname_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname}/config GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Snapshot_Snapname_ConfigPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/snapshot/{snapname}/config PUT
    """
    description: str | None = Field(
        description="\u0027A textual description or comment.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_FirewallGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_FirewallGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_RulesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/rules GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_RulesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/rules GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_RulesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/rules POST
    """
    action: str = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] = Field(
        description="\u0027Rule type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Rules_PosDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/rules/{pos} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Rules_PosGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/rules/{pos} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Rules_PosGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/rules/{pos} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Rules_PosPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/rules/{pos} PUT
    """
    action: str | None = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    moveto: int | str | None = Field(
        ge=0,
        description="\u0027Move rule to new position \u003cmoveto\u003e. Other arguments are ignored.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] | None = Field(
        description="\u0027Rule type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_AliasesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/aliases GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_AliasesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/aliases GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_AliasesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/aliases POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/aliases/{name} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/aliases/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/aliases/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Aliases_NamePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/aliases/{name} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027Alias name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\u0027Rename an existing alias.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_IpsetGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_IpsetGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/ipset GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_IpsetPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset POST
    """
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    rename: str | None = Field(
        max_length=64,
        description="\"Rename an existing IPSet. You can set \u0027rename\u0027 to the same value as \u0027name\u0027 to update the \u0027comment\u0027 of an existing IPSet.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name} DELETE
    """
    force: bool | int | str | None = Field(
        description="\u0027Delete all members of the IPSet, if there are any.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name} GET
    """
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_NamePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name} POST
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_Name_CidrDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name}/{cidr} DELETE
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_Name_CidrGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name}/{cidr} GET
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_Name_CidrGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name}/{cidr} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_Ipset_Name_CidrPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/ipset/{name}/{cidr} PUT
    """
    cidr: str = Field(
        description="\u0027Network/IP specification in CIDR format.\u0027",
    )
    comment: str | None = Field(
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    name: str = Field(
        max_length=64,
        description="\u0027IP set name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nomatch: bool | int | str | None = Field(
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_OptionsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/options GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_OptionsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/options GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_OptionsPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/options PUT
    """
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dhcp: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable DHCP.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    enable: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable/disable firewall rules.\u0027",
    )
    ipfilter: bool | int | str | None = Field(
        description="\"Enable default IP filters. This is equivalent to adding an empty ipfilter-net\u003cid\u003e ipset for every interface. Such ipsets implicitly contain sane default restrictions such as restricting IPv6 link local addresses to the one derived from the interface\u0027s MAC address. For containers the configured IP addresses will be implicitly added.\"",
    )
    log_level_in: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for incoming traffic.\u0027",
    )
    log_level_out: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for outgoing traffic.\u0027",
    )
    macfilter: bool | int | str | None = Field(
        default=1,
        description="\u0027Enable/disable MAC address filter.\u0027",
    )
    ndp: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable NDP (Neighbor Discovery Protocol).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    policy_in: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Input policy.\u0027",
    )
    policy_out: Literal["ACCEPT", "DROP", "REJECT"] | None = Field(
        description="\u0027Output policy.\u0027",
    )
    radv: bool | int | str | None = Field(
        description="\u0027Allow sending Router Advertisement.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/log GET
    """
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    since: int | str | None = Field(
        ge=0,
        description="\u0027Display log since this UNIX epoch.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )
    until: int | str | None = Field(
        ge=0,
        description="\u0027Display log until this UNIX epoch.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_RefsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/firewall/refs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    type: Literal["alias", "ipset"] | None = Field(
        description="\u0027Only list references of specified type.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Firewall_RefsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/firewall/refs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_RrdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/rrd GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    ds: str = Field(
        description="\u0027The list of datasources you want to display.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_RrdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/rrd GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_RrddataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/rrddata GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_RrddataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/rrddata GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_VncproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/vncproxy POST
    """
    height: int | str | None = Field(
        ge=16,
        le=2160,
        description="\u0027sets the height of the console in pixels.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    websocket: bool | int | str | None = Field(
        description="\u0027use websocket instead of standard VNC.\u0027",
    )
    width: int | str | None = Field(
        ge=16,
        le=4096,
        description="\u0027sets the width of the console in pixels.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_VncproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/vncproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_TermproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/termproxy POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_TermproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/termproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_VncwebsocketGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/vncwebsocket GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    port: int | str = Field(
        ge=5900,
        le=5999,
        description="\u0027Port number returned by previous vncproxy call.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    vncticket: str = Field(
        max_length=512,
        description="\u0027Ticket from previous call to vncproxy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_VncwebsocketGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/vncwebsocket GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SpiceproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/spiceproxy POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    proxy: str | None = Field(
        description="\"SPICE proxy server. This can be used by the client to specify the proxy server. All nodes in a cluster runs \u0027spiceproxy\u0027, so it is up to the client to choose one. By default, we return the node where the VM is currently running. As reasonable setting is to use same node you use to connect to the API (This is window.location.hostname for the JS GUI).\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_SpiceproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/spiceproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Remote_MigratePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/remote_migrate POST
    """
    bwlimit: float | str | None = Field(
        default="migrate limit from datacenter or storage config",
        ge=0.0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    delete: bool | int | str | None = Field(
        default=0,
        description="\u0027Delete the original CT and related data after successful migration. By default the original CT is kept on the source cluster in a stopped state.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    online: bool | int | str | None = Field(
        description="\u0027Use online/live migration.\u0027",
    )
    restart: bool | int | str | None = Field(
        description="\u0027Use restart migration\u0027",
    )
    target_bridge: str = Field(
        description="\"Mapping from source to target bridges. Providing only a single bridge ID maps all source bridges to that bridge. Providing the special value \u00271\u0027 will map each source bridge to itself.\"",
    )
    target_endpoint: str = Field(
        description="\u0027Remote target endpoint\u0027",
    )
    target_storage: str = Field(
        description="\"Mapping from source to target storages. Providing only a single storage ID maps all source storages to that storage. Providing the special value \u00271\u0027 will map each source storage to itself.\"",
    )
    target_vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    timeout: int | str | None = Field(
        default=180,
        description="\u0027Timeout in seconds for shutdown for restart migration\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Remote_MigratePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/remote_migrate POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MigratePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/migrate POST
    """
    bwlimit: float | str | None = Field(
        default="migrate limit from datacenter or storage config",
        ge=0.0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    online: bool | int | str | None = Field(
        description="\u0027Use online/live migration.\u0027",
    )
    restart: bool | int | str | None = Field(
        description="\u0027Use restart migration\u0027",
    )
    target: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    target_storage: str | None = Field(
        description="\"Mapping from source to target storages. Providing only a single storage ID maps all source storages to that storage. Providing the special value \u00271\u0027 will map each source storage to itself.\"",
    )
    timeout: int | str | None = Field(
        default=180,
        description="\u0027Timeout in seconds for shutdown for restart migration\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MigratePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/migrate POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_FeatureGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/feature GET
    """
    feature: Literal["clone", "copy", "snapshot"] = Field(
        description="\u0027Feature to check.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    snapname: str | None = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_FeatureGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/feature GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_TemplatePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/template POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ClonePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/clone POST
    """
    bwlimit: float | str | None = Field(
        default="clone limit from datacenter or storage config",
        ge=0.0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    description: str | None = Field(
        description="\u0027Description for the new CT.\u0027",
    )
    full: bool | int | str | None = Field(
        description="\u0027Create a full copy of all disks. This is always done when you clone a normal CT. For CT templates, we try to create a linked clone by default.\u0027",
    )
    hostname: str | None = Field(
        description="\u0027Set a hostname for the new CT.\u0027",
    )
    newid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027VMID for the clone.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Add the new CT to the specified pool.\u0027",
    )
    snapname: str | None = Field(
        max_length=40,
        description="\u0027The name of the snapshot.\u0027",
    )
    storage: str | None = Field(
        description="\u0027Target storage for full clone.\u0027",
    )
    target: ProxmoxNode | None = Field(
        description="\u0027Target node. Only allowed if the original VM is on shared storage.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ClonePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/clone POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ResizePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/resize PUT
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    disk: str = Field(
        description="\u0027The disk you want to resize.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    size: str = Field(
        description="\"The new size. With the \u0027+\u0027 sign the value is added to the actual size of the volume and without it, the value is taken as an absolute one. Shrinking disk size is not supported.\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_ResizePUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/resize PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Move_VolumePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/move_volume POST
    """
    bwlimit: float | str | None = Field(
        default="clone limit from datacenter or storage config",
        ge=0.0,
        description="\u0027Override I/O bandwidth limit (in KiB/s).\u0027",
    )
    delete: bool | int | str | None = Field(
        default=0,
        description="\u0027Delete the original volume after successful copy. By default the original is kept as an unused volume entry.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 \" .\\n\\t\\t    \"digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027Target Storage.\u0027",
    )
    target_digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file of the target \" .\\n\\t\\t    \"container has a different SHA1 digest. This can be used to prevent \" .\\n\\t\\t    \"concurrent modifications.\u0027",
    )
    target_vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    target_volume: str | None = Field(
        description="\u0027The config key the volume will be moved to. Default is the source volume key.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )
    volume: str = Field(
        description="\u0027Volume which will be moved.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_Move_VolumePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/move_volume POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_PendingGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/pending GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_PendingGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/pending GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MtunnelPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/mtunnel POST
    """
    bridges: str | None = Field(
        description="\u0027List of network bridges to check availability. Will be checked again for actually used bridges during migration.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storages: list[str] | None = Field(
        description="\u0027List of storages to check permission and availability. Will be checked again for all actually used storages during migration.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MtunnelPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/mtunnel POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MtunnelwebsocketGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/lxc/{vmid}/mtunnelwebsocket GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    socket: str = Field(
        description="\u0027unix socket to forward to\u0027",
    )
    ticket: str = Field(
        description="\"ticket return by initial \u0027mtunnel\u0027 API call, or retrieved via \u0027ticket\u0027 tunnel command\"",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027The (unique) ID of the VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Lxc_Vmid_MtunnelwebsocketGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/lxc/{vmid}/mtunnelwebsocket GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CephGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CephGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_CfgGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/cfg GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_CfgGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/cfg GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cfg_RawGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/cfg/raw GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cfg_RawGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/cfg/raw GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cfg_DbGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/cfg/db GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cfg_DbGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/cfg/db GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_OsdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_OsdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_OsdPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd POST
    """
    crush_device_class: str | None = Field(
        description="\u0027Set the device class of the OSD in crush.\u0027",
    )
    db_dev: str | None = Field(
        description="\u0027Block device name for block.db.\u0027",
    )
    db_dev_size: float | str | None = Field(
        default="bluestore_block_db_size or 10% of OSD size",
        ge=1.0,
        description="\u0027Size in GiB for block.db.\u0027",
    )
    dev: str = Field(
        description="\u0027Block device name.\u0027",
    )
    encrypted: bool | int | str | None = Field(
        default=0,
        description="\u0027Enables encryption of the OSD.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    wal_dev: str | None = Field(
        description="\u0027Block device name for block.wal.\u0027",
    )
    wal_dev_size: float | str | None = Field(
        default="bluestore_block_wal_size or 1% of OSD size",
        ge=0.5,
        description="\u0027Size in GiB for block.wal.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_OsdPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_OsdidDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid} DELETE
    """
    cleanup: bool | int | str | None = Field(
        default=0,
        description="\u0027If set, we remove partition table entries.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_OsdidDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd/{osdid} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_OsdidGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_OsdidGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd/{osdid} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_MetadataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid}/metadata GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_MetadataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd/{osdid}/metadata GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_Lv_InfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid}/lv-info GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )
    type: Literal["block", "db", "wal"] | None = Field(
        default="block",
        description="\u0027OSD device type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_Lv_InfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/osd/{osdid}/lv-info GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_InPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid}/in POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_OutPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid}/out POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Osd_Osdid_ScrubPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/osd/{osdid}/scrub POST
    """
    deep: bool | int | str | None = Field(
        default=0,
        description="\u0027If set, instructs a deep scrub instead of a normal one.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    osdid: int | str = Field(
        description="\u0027OSD ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MdsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mds GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MdsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mds GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mds_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mds/{name} DELETE
    """
    name: str = Field(
        description="\u0027The name (ID) of the mds\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mds_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mds/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mds_NamePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mds/{name} POST
    """
    hotstandby: bool | int | str | None = Field(
        default="0",
        description="\u0027Determines whether a ceph-mds daemon should poll and replay the log of an active MDS. Faster switch on MDS failure, but needs more idle resources.\u0027",
    )
    name: str | None = Field(
        default="nodename",
        max_length=200,
        description="\u0027The ID for the mds, when omitted the same as the nodename\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mds_NamePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mds/{name} POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MgrGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mgr GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MgrGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mgr GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mgr_IdDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mgr/{id} DELETE
    """
    id: str = Field(
        description="\u0027The ID of the manager\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mgr_IdDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mgr/{id} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mgr_IdPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mgr/{id} POST
    """
    id: str | None = Field(
        max_length=200,
        description="\u0027The ID for the manager, when omitted the same as the nodename\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mgr_IdPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mgr/{id} POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MonGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mon GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_MonGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mon GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mon_MonidDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mon/{monid} DELETE
    """
    monid: str = Field(
        description="\u0027Monitor ID\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mon_MonidDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mon/{monid} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mon_MonidPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/mon/{monid} POST
    """
    mon_address: str | None = Field(
        description="\u0027Overwrites autodetected monitor IP address(es). Must be in the public network(s) of Ceph.\u0027",
    )
    monid: str | None = Field(
        max_length=200,
        description="\u0027The ID for the monitor, when omitted the same as the nodename\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Mon_MonidPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/mon/{monid} POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_FsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/fs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_FsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/fs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Fs_NamePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/fs/{name} POST
    """
    add_storage: bool | int | str | None = Field(
        default=0,
        description="\u0027Configure the created CephFS as storage for this cluster.\u0027",
    )
    name: str | None = Field(
        default="cephfs",
        description="\u0027The ceph filesystem name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_num: int | str | None = Field(
        default=128,
        ge=8,
        le=32768,
        description="\u0027Number of placement groups for the backing data pool. The metadata pool will use a quarter of this.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Fs_NamePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/fs/{name} POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool POST
    """
    add_storages: bool | int | str | None = Field(
        default="0; for erasure coded pools: 1",
        description="\u0027Configure VM and CT storage using the new pool.\u0027",
    )
    application: Literal["cephfs", "rbd", "rgw"] | None = Field(
        default="rbd",
        description="\u0027The application of the pool.\u0027",
    )
    crush_rule: str | None = Field(
        description="\u0027The rule to use for mapping object placement in the cluster.\u0027",
    )
    erasure_coding: str | None = Field(
        description="\"Create an erasure coded pool for RBD with an accompaning replicated pool for metadata storage. With EC, the common ceph options \u0027size\u0027, \u0027min_size\u0027 and \u0027crush_rule\u0027 parameters will be applied to the metadata pool.\"",
    )
    min_size: int | str | None = Field(
        default=2,
        ge=1,
        le=7,
        description="\u0027Minimum number of replicas per object\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_autoscale_mode: Literal["off", "on", "warn"] | None = Field(
        default="warn",
        description="\u0027The automatic PG scaling mode of the pool.\u0027",
    )
    pg_num: int | str | None = Field(
        default=128,
        ge=1,
        le=32768,
        description="\u0027Number of placement groups.\u0027",
    )
    pg_num_min: int | str | None = Field(
        le=32768,
        description="\u0027Minimal number of placement groups.\u0027",
    )
    size: int | str | None = Field(
        default=3,
        ge=1,
        le=7,
        description="\u0027Number of replicas per object\u0027",
    )
    target_size: str | None = Field(
        description="\u0027The estimated target size of the pool for the PG autoscaler.\u0027",
    )
    target_size_ratio: float | str | None = Field(
        description="\u0027The estimated target ratio of the pool for the PG autoscaler.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool/{name} DELETE
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027If true, destroys pool even if in use\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    remove_ecprofile: bool | int | str | None = Field(
        default=1,
        description="\u0027Remove the erasure code profile. Defaults to true, if applicable.\u0027",
    )
    remove_storages: bool | int | str | None = Field(
        default=0,
        description="\u0027Remove all pveceph-managed storages configured for this pool\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool/{name} GET
    """
    name: str = Field(
        description="\u0027The name of the pool.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool/{name} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NamePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool/{name} PUT
    """
    application: Literal["cephfs", "rbd", "rgw"] | None = Field(
        description="\u0027The application of the pool.\u0027",
    )
    crush_rule: str | None = Field(
        description="\u0027The rule to use for mapping object placement in the cluster.\u0027",
    )
    min_size: int | str | None = Field(
        ge=1,
        le=7,
        description="\u0027Minimum number of replicas per object\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_autoscale_mode: Literal["off", "on", "warn"] | None = Field(
        description="\u0027The automatic PG scaling mode of the pool.\u0027",
    )
    pg_num: int | str | None = Field(
        ge=1,
        le=32768,
        description="\u0027Number of placement groups.\u0027",
    )
    pg_num_min: int | str | None = Field(
        le=32768,
        description="\u0027Minimal number of placement groups.\u0027",
    )
    size: int | str | None = Field(
        ge=1,
        le=7,
        description="\u0027Number of replicas per object\u0027",
    )
    target_size: str | None = Field(
        description="\u0027The estimated target size of the pool for the PG autoscaler.\u0027",
    )
    target_size_ratio: float | str | None = Field(
        description="\u0027The estimated target ratio of the pool for the PG autoscaler.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_NamePUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool/{name} PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_Name_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pool/{name}/status GET
    """
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    verbose: bool | int | str | None = Field(
        default=0,
        description="\u0027If enabled, will display additional data(eg. statistics).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pool_Name_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pool/{name}/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pools GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pools GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolsPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pools POST
    """
    add_storages: bool | int | str | None = Field(
        default="0; for erasure coded pools: 1",
        description="\u0027Configure VM and CT storage using the new pool.\u0027",
    )
    application: Literal["cephfs", "rbd", "rgw"] | None = Field(
        default="rbd",
        description="\u0027The application of the pool.\u0027",
    )
    crush_rule: str | None = Field(
        description="\u0027The rule to use for mapping object placement in the cluster.\u0027",
    )
    erasure_coding: str | None = Field(
        description="\"Create an erasure coded pool for RBD with an accompaning replicated pool for metadata storage. With EC, the common ceph options \u0027size\u0027, \u0027min_size\u0027 and \u0027crush_rule\u0027 parameters will be applied to the metadata pool.\"",
    )
    min_size: int | str | None = Field(
        default=2,
        ge=1,
        le=7,
        description="\u0027Minimum number of replicas per object\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_autoscale_mode: Literal["off", "on", "warn"] | None = Field(
        default="warn",
        description="\u0027The automatic PG scaling mode of the pool.\u0027",
    )
    pg_num: int | str | None = Field(
        default=128,
        ge=1,
        le=32768,
        description="\u0027Number of placement groups.\u0027",
    )
    pg_num_min: int | str | None = Field(
        le=32768,
        description="\u0027Minimal number of placement groups.\u0027",
    )
    size: int | str | None = Field(
        default=3,
        ge=1,
        le=7,
        description="\u0027Number of replicas per object\u0027",
    )
    target_size: str | None = Field(
        description="\u0027The estimated target size of the pool for the PG autoscaler.\u0027",
    )
    target_size_ratio: float | str | None = Field(
        description="\u0027The estimated target ratio of the pool for the PG autoscaler.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_PoolsPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pools POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pools/{name} DELETE
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027If true, destroys pool even if in use\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    remove_ecprofile: bool | int | str | None = Field(
        default=1,
        description="\u0027Remove the erasure code profile. Defaults to true, if applicable.\u0027",
    )
    remove_storages: bool | int | str | None = Field(
        default=0,
        description="\u0027Remove all pveceph-managed storages configured for this pool\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pools/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pools/{name} GET
    """
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    verbose: bool | int | str | None = Field(
        default=0,
        description="\u0027If enabled, will display additional data(eg. statistics).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pools/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NamePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/pools/{name} PUT
    """
    application: Literal["cephfs", "rbd", "rgw"] | None = Field(
        description="\u0027The application of the pool.\u0027",
    )
    crush_rule: str | None = Field(
        description="\u0027The rule to use for mapping object placement in the cluster.\u0027",
    )
    min_size: int | str | None = Field(
        ge=1,
        le=7,
        description="\u0027Minimum number of replicas per object\u0027",
    )
    name: str = Field(
        description="\u0027The name of the pool. It must be unique.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_autoscale_mode: Literal["off", "on", "warn"] | None = Field(
        description="\u0027The automatic PG scaling mode of the pool.\u0027",
    )
    pg_num: int | str | None = Field(
        ge=1,
        le=32768,
        description="\u0027Number of placement groups.\u0027",
    )
    pg_num_min: int | str | None = Field(
        le=32768,
        description="\u0027Minimal number of placement groups.\u0027",
    )
    size: int | str | None = Field(
        ge=1,
        le=7,
        description="\u0027Number of replicas per object\u0027",
    )
    target_size: str | None = Field(
        description="\u0027The estimated target size of the pool for the PG autoscaler.\u0027",
    )
    target_size_ratio: float | str | None = Field(
        description="\u0027The estimated target ratio of the pool for the PG autoscaler.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Pools_NamePUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/pools/{name} PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/config GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/config GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_ConfigdbGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/configdb GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_ConfigdbGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/configdb GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_InitPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/init POST
    """
    cluster_network: str | None = Field(
        max_length=128,
        description="\u0027Declare a separate cluster network, OSDs will routeheartbeat, object replication and recovery traffic over it\u0027",
    )
    disable_cephx: bool | int | str | None = Field(
        default=0,
        description="\u0027Disable cephx authentication.\\n\\nWARNING: cephx is a security feature protecting against man-in-the-middle attacks. Only consider disabling cephx if your network is private!\u0027",
    )
    min_size: int | str | None = Field(
        default=2,
        ge=1,
        le=7,
        description="\u0027Minimum number of available replicas per object to allow I/O\u0027",
    )
    network: str | None = Field(
        max_length=128,
        description="\u0027Use specific network for all ceph related traffic\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pg_bits: int | str | None = Field(
        default=6,
        ge=6,
        le=14,
        description="\"Placement group bits, used to specify the default number of placement groups.\\n\\nNOTE: \u0027osd pool default pg num\u0027 does not work for default pools.\"",
    )
    size: int | str | None = Field(
        default=3,
        ge=1,
        le=7,
        description="\u0027Targeted number of replicas per object\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StopPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/stop POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str | None = Field(
        default="ceph.target",
        description="\u0027Ceph service name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StopPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/stop POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/start POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str | None = Field(
        default="ceph.target",
        description="\u0027Ceph service name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/start POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_RestartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/restart POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str | None = Field(
        default="ceph.target",
        description="\u0027Ceph service name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_RestartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/restart POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_CrushGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/crush GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_CrushGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/crush GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/log GET
    """
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_RulesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/rules GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_RulesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/rules GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cmd_SafetyGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/ceph/cmd-safety GET
    """
    action: Literal["destroy", "stop"] = Field(
        description="\u0027Action to check\u0027",
    )
    id: str = Field(
        description="\u0027ID of the service\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: Literal["mds", "mon", "osd"] = Field(
        description="\u0027Service type\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Ceph_Cmd_SafetyGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/ceph/cmd-safety GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VzdumpPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/vzdump POST
    """
    all: bool | int | str | None = Field(
        default=0,
        description="\u0027Backup all known guest systems on this host.\u0027",
    )
    bwlimit: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Limit I/O bandwidth (KBytes per second).\u0027",
    )
    compress: Literal["0", "1", "gzip", "lzo", "zstd"] | None = Field(
        default="0",
        description="\u0027Compress dump file.\u0027",
    )
    dumpdir: str | None = Field(
        description="\u0027Store resulting files to specified directory.\u0027",
    )
    exclude: list[ProxmoxVMID] | None = Field(
        description="\u0027Exclude specified guest systems (assumes --all)\u0027",
    )
    exclude_path: str | None = Field(
        description="\"Exclude certain files/directories (shell globs). Paths starting with \u0027/\u0027 are anchored to the container\u0027s root,  other paths match relative to each subdirectory.\"",
    )
    ionice: int | str | None = Field(
        default=7,
        ge=0,
        le=8,
        description="\u0027Set CFQ ionice priority.\u0027",
    )
    lockwait: int | str | None = Field(
        default=180,
        ge=0,
        description="\u0027Maximal time to wait for the global lock (minutes).\u0027",
    )
    mailnotification: Literal["always", "failure"] | None = Field(
        default="always",
        description="\u0027Specify when to send an email\u0027",
    )
    mailto: str | None = Field(
        description="\u0027Comma-separated list of email addresses or users that should receive email notifications.\u0027",
    )
    maxfiles: int | str | None = Field(
        ge=1,
        description="\"Deprecated: use \u0027prune-backups\u0027 instead. Maximal number of backup files per guest system.\"",
    )
    mode: Literal["snapshot", "stop", "suspend"] | None = Field(
        default="snapshot",
        description="\u0027Backup mode.\u0027",
    )
    node: ProxmoxNode | None = Field(
        description="\u0027Only run if executed on this node.\u0027",
    )
    notes_template: str | None = Field(
        max_length=1024,
        description="\"Template string for generating notes for the backup(s). It can contain variables which will be replaced by their values. Currently supported are {{cluster}}, {{guestname}}, {{node}}, and {{vmid}}, but more might be added in the future. Needs to be a single line, newline and backslash need to be escaped as \u0027\\\\n\u0027 and \u0027\\\\\\\\\u0027 respectively.\"",
    )
    performance: str | None = Field(
        description="\u0027Other performance-related settings.\u0027",
    )
    pigz: int | str | None = Field(
        default=0,
        description="\u0027Use pigz instead of gzip when N\u003e0. N=1 uses half of cores, N\u003e1 uses N as thread count.\u0027",
    )
    pool: str | None = Field(
        description="\u0027Backup all known guest systems included in the specified pool.\u0027",
    )
    protected: bool | int | str | None = Field(
        description="\u0027If true, mark backup(s) as protected.\u0027",
    )
    prune_backups: str | None = Field(
        default="keep-all=1",
        description="\u0027Use these retention options instead of those from the storage configuration.\u0027",
    )
    quiet: bool | int | str | None = Field(
        default=0,
        description="\u0027Be quiet.\u0027",
    )
    remove: bool | int | str | None = Field(
        default=1,
        description="\"Prune older backups according to \u0027prune-backups\u0027.\"",
    )
    script: str | None = Field(
        description="\u0027Use specified hook script.\u0027",
    )
    stdexcludes: bool | int | str | None = Field(
        default=1,
        description="\u0027Exclude temporary files and logs.\u0027",
    )
    stdout: bool | int | str | None = Field(
        description="\u0027Write tar to stdout, not to a file.\u0027",
    )
    stop: bool | int | str | None = Field(
        default=0,
        description="\u0027Stop running backup jobs on this host.\u0027",
    )
    stopwait: int | str | None = Field(
        default=10,
        ge=0,
        description="\u0027Maximal time to wait until a guest system is stopped (minutes).\u0027",
    )
    storage: str | None = Field(
        description="\u0027Store resulting file to this storage.\u0027",
    )
    tmpdir: str | None = Field(
        description="\u0027Store temporary files to specified directory.\u0027",
    )
    vmid: list[ProxmoxVMID] | None = Field(
        description="\u0027The ID of the guest system you want to backup.\u0027",
    )
    zstd: int | str | None = Field(
        default=1,
        description="\u0027Zstd threads. N=0 uses half of the available cores, N\u003e0 uses N as thread count.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VzdumpPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/vzdump POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Vzdump_DefaultsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/vzdump/defaults GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Vzdump_DefaultsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/vzdump/defaults GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Vzdump_ExtractconfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/vzdump/extractconfig GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    volume: str = Field(
        description="\u0027Volume identifier\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Vzdump_ExtractconfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/vzdump/extractconfig GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ServicesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/services GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ServicesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/services GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_ServiceGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_ServiceGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StateGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service}/state GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StateGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service}/state GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service}/start POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service}/start POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StopPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service}/stop POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_StopPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service}/stop POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_RestartPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service}/restart POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_RestartPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service}/restart POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_ReloadPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/services/{service}/reload POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str = Field(
        description="\u0027Service ID\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Services_Service_ReloadPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/services/{service}/reload POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SubscriptionDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/subscription DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SubscriptionGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/subscription GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SubscriptionGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/subscription GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SubscriptionPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/subscription POST
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Always connect to server, even if we have up to date info inside local cache.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SubscriptionPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/subscription PUT
    """
    key: str = Field(
        max_length=32,
        description="\u0027Proxmox VE subscription key\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/network DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/network GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    type: Literal["OVSBond", "OVSBridge", "OVSIntPort", "OVSPort", "alias", "any_bridge", "bond", "bridge", "eth", "vlan"] | None = Field(
        description="\u0027Only list specific interface types.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/network GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/network POST
    """
    address: str | None = Field(
        description="\u0027IP address.\u0027",
    )
    address6: str | None = Field(
        description="\u0027IP address.\u0027",
    )
    autostart: bool | int | str | None = Field(
        description="\u0027Automatically start interface on boot.\u0027",
    )
    bond_primary: str | None = Field(
        description="\u0027Specify the primary interface for active-backup bond.\u0027",
    )
    bond_mode: Literal["802.3ad", "active-backup", "balance-alb", "balance-rr", "balance-slb", "balance-tlb", "balance-xor", "broadcast", "lacp-balance-slb", "lacp-balance-tcp"] | None = Field(
        description="\u0027Bonding mode.\u0027",
    )
    bond_xmit_hash_policy: Literal["layer2", "layer2+3", "layer3+4"] | None = Field(
        description="\u0027Selects the transmit hash policy to use for slave selection in balance-xor and 802.3ad modes.\u0027",
    )
    bridge_ports: str | None = Field(
        description="\u0027Specify the interfaces you want to add to your bridge.\u0027",
    )
    bridge_vlan_aware: bool | int | str | None = Field(
        description="\u0027Enable bridge vlan support.\u0027",
    )
    cidr: str | None = Field(
        description="\u0027IPv4 CIDR.\u0027",
    )
    cidr6: str | None = Field(
        description="\u0027IPv6 CIDR.\u0027",
    )
    comments: str | None = Field(
        description="\u0027Comments\u0027",
    )
    comments6: str | None = Field(
        description="\u0027Comments\u0027",
    )
    gateway: str | None = Field(
        description="\u0027Default gateway address.\u0027",
    )
    gateway6: str | None = Field(
        description="\u0027Default ipv6 gateway address.\u0027",
    )
    iface: str = Field(
        max_length=20,
        description="\u0027Network interface name.\u0027",
    )
    mtu: int | str | None = Field(
        ge=1280,
        le=65520,
        description="\u0027MTU.\u0027",
    )
    netmask: str | None = Field(
        description="\u0027Network mask.\u0027",
    )
    netmask6: int | str | None = Field(
        ge=0,
        le=128,
        description="\u0027Network mask.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    ovs_bonds: str | None = Field(
        description="\u0027Specify the interfaces used by the bonding device.\u0027",
    )
    ovs_bridge: str | None = Field(
        description="\u0027The OVS bridge associated with a OVS port. This is required when you create an OVS port.\u0027",
    )
    ovs_options: str | None = Field(
        max_length=1024,
        description="\u0027OVS interface options.\u0027",
    )
    ovs_ports: str | None = Field(
        description="\u0027Specify the interfaces you want to add to your bridge.\u0027",
    )
    ovs_tag: int | str | None = Field(
        ge=1,
        le=4094,
        description="\u0027Specify a VLan tag (used by OVSPort, OVSIntPort, OVSBond)\u0027",
    )
    slaves: str | None = Field(
        description="\u0027Specify the interfaces used by the bonding device.\u0027",
    )
    type: Literal["OVSBond", "OVSBridge", "OVSIntPort", "OVSPort", "alias", "bond", "bridge", "eth", "unknown", "vlan"] = Field(
        description="\u0027Network interface type\u0027",
    )
    vlan_id: int | str | None = Field(
        ge=1,
        le=4094,
        description="\u0027vlan-id for a custom named vlan interface (ifupdown2 only).\u0027",
    )
    vlan_raw_device: str | None = Field(
        description="\u0027Specify the raw interface for the vlan interface.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/network PUT
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetworkPUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/network PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Network_IfaceDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/network/{iface} DELETE
    """
    iface: str = Field(
        max_length=20,
        description="\u0027Network interface name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Network_IfaceGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/network/{iface} GET
    """
    iface: str = Field(
        max_length=20,
        description="\u0027Network interface name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Network_IfaceGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/network/{iface} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Network_IfacePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/network/{iface} PUT
    """
    address: str | None = Field(
        description="\u0027IP address.\u0027",
    )
    address6: str | None = Field(
        description="\u0027IP address.\u0027",
    )
    autostart: bool | int | str | None = Field(
        description="\u0027Automatically start interface on boot.\u0027",
    )
    bond_primary: str | None = Field(
        description="\u0027Specify the primary interface for active-backup bond.\u0027",
    )
    bond_mode: Literal["802.3ad", "active-backup", "balance-alb", "balance-rr", "balance-slb", "balance-tlb", "balance-xor", "broadcast", "lacp-balance-slb", "lacp-balance-tcp"] | None = Field(
        description="\u0027Bonding mode.\u0027",
    )
    bond_xmit_hash_policy: Literal["layer2", "layer2+3", "layer3+4"] | None = Field(
        description="\u0027Selects the transmit hash policy to use for slave selection in balance-xor and 802.3ad modes.\u0027",
    )
    bridge_ports: str | None = Field(
        description="\u0027Specify the interfaces you want to add to your bridge.\u0027",
    )
    bridge_vlan_aware: bool | int | str | None = Field(
        description="\u0027Enable bridge vlan support.\u0027",
    )
    cidr: str | None = Field(
        description="\u0027IPv4 CIDR.\u0027",
    )
    cidr6: str | None = Field(
        description="\u0027IPv6 CIDR.\u0027",
    )
    comments: str | None = Field(
        description="\u0027Comments\u0027",
    )
    comments6: str | None = Field(
        description="\u0027Comments\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    gateway: str | None = Field(
        description="\u0027Default gateway address.\u0027",
    )
    gateway6: str | None = Field(
        description="\u0027Default ipv6 gateway address.\u0027",
    )
    iface: str = Field(
        max_length=20,
        description="\u0027Network interface name.\u0027",
    )
    mtu: int | str | None = Field(
        ge=1280,
        le=65520,
        description="\u0027MTU.\u0027",
    )
    netmask: str | None = Field(
        description="\u0027Network mask.\u0027",
    )
    netmask6: int | str | None = Field(
        ge=0,
        le=128,
        description="\u0027Network mask.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    ovs_bonds: str | None = Field(
        description="\u0027Specify the interfaces used by the bonding device.\u0027",
    )
    ovs_bridge: str | None = Field(
        description="\u0027The OVS bridge associated with a OVS port. This is required when you create an OVS port.\u0027",
    )
    ovs_options: str | None = Field(
        max_length=1024,
        description="\u0027OVS interface options.\u0027",
    )
    ovs_ports: str | None = Field(
        description="\u0027Specify the interfaces you want to add to your bridge.\u0027",
    )
    ovs_tag: int | str | None = Field(
        ge=1,
        le=4094,
        description="\u0027Specify a VLan tag (used by OVSPort, OVSIntPort, OVSBond)\u0027",
    )
    slaves: str | None = Field(
        description="\u0027Specify the interfaces used by the bonding device.\u0027",
    )
    type: Literal["OVSBond", "OVSBridge", "OVSIntPort", "OVSPort", "alias", "bond", "bridge", "eth", "unknown", "vlan"] = Field(
        description="\u0027Network interface type\u0027",
    )
    vlan_id: int | str | None = Field(
        ge=1,
        le=4094,
        description="\u0027vlan-id for a custom named vlan interface (ifupdown2 only).\u0027",
    )
    vlan_raw_device: str | None = Field(
        description="\u0027Specify the raw interface for the vlan interface.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TasksGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/tasks GET
    """
    errors: bool | int | str | None = Field(
        default=0,
        description="\u0027Only list tasks with a status of ERROR.\u0027",
    )
    limit: int | str | None = Field(
        default=50,
        ge=0,
        description="\u0027Only list this amount of tasks.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    since: int | str | None = Field(
        description="\u0027Only list tasks since this UNIX epoch.\u0027",
    )
    source: Literal["active", "all", "archive"] | None = Field(
        default="archive",
        description="\u0027List archived, active or all tasks.\u0027",
    )
    start: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027List tasks beginning from this offset.\u0027",
    )
    statusfilter: str | None = Field(
        description="\u0027List of Task States that should be returned.\u0027",
    )
    typefilter: str | None = Field(
        description="\u0027Only list tasks of this type (e.g., vzstart, vzdump).\u0027",
    )
    until: int | str | None = Field(
        description="\u0027Only list tasks until this UNIX epoch.\u0027",
    )
    userfilter: str | None = Field(
        description="\u0027Only list tasks from this user.\u0027",
    )
    vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027Only list tasks for this VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TasksGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/tasks GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_UpidDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/tasks/{upid} DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    upid: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_UpidGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/tasks/{upid} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    upid: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_UpidGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/tasks/{upid} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_Upid_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/tasks/{upid}/log GET
    """
    download: bool | int | str | None = Field(
        description="\"Whether the tasklog file should be downloaded. This parameter can\u0027t be used in conjunction with other parameters\"",
    )
    limit: int | str | None = Field(
        default=50,
        ge=0,
        description="\u0027The amount of lines to read from the tasklog.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    start: int | str | None = Field(
        default=0,
        ge=0,
        description="\u0027Start at this line when reading the tasklog\u0027",
    )
    upid: str = Field(
        description="\"The task\u0027s unique ID.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_Upid_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/tasks/{upid}/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_Upid_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/tasks/{upid}/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    upid: str = Field(
        description="\"The task\u0027s unique ID.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Tasks_Upid_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/tasks/{upid}/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ScanGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ScanGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_NfsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/nfs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    server: str = Field(
        description="\u0027The server address (name or IP).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_NfsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/nfs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_CifsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/cifs GET
    """
    domain: str | None = Field(
        description="\u0027SMB domain (Workgroup).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    password: str | None = Field(
        description="\u0027User password.\u0027",
    )
    server: str = Field(
        description="\u0027The server address (name or IP).\u0027",
    )
    username: str | None = Field(
        description="\u0027User name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_CifsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/cifs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_PbsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/pbs GET
    """
    fingerprint: str | None = Field(
        description="\u0027Certificate SHA 256 fingerprint.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    password: str = Field(
        description="\u0027User password or API token secret.\u0027",
    )
    port: int | str | None = Field(
        default=8007,
        ge=1,
        le=65535,
        description="\u0027Optional port.\u0027",
    )
    server: str = Field(
        description="\u0027The server address (name or IP).\u0027",
    )
    username: str = Field(
        description="\u0027User-name or API token-ID.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_PbsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/pbs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_GlusterfsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/glusterfs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    server: str = Field(
        description="\u0027The server address (name or IP).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_GlusterfsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/glusterfs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_IscsiGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/iscsi GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    portal: str = Field(
        description="\u0027The iSCSI portal (IP or DNS name with optional port).\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_IscsiGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/iscsi GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_LvmGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/lvm GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_LvmGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/lvm GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_LvmthinGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/lvmthin GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vg: str = Field(
        max_length=100,
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_LvmthinGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/lvmthin GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_ZfsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/scan/zfs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Scan_ZfsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/scan/zfs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_HardwareGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hardware GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_HardwareGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hardware GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_PciGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hardware/pci GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pci_class_blacklist: str | None = Field(
        default="05;06;0b",
        description="\u0027A list of blacklisted PCI classes, which will not be returned. Following are filtered by default: Memory Controller (05), Bridge (06) and Processor (0b).\u0027",
    )
    verbose: bool | int | str | None = Field(
        default=1,
        description="\u0027If disabled, does only print the PCI IDs. Otherwise, additional information like vendor and device will be returned.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_PciGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hardware/pci GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_Pci_PciidGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hardware/pci/{pciid} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pciid: str = Field(
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_Pci_PciidGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hardware/pci/{pciid} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_Pci_Pciid_MdevGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hardware/pci/{pciid}/mdev GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pciid: str = Field(
        description="\u0027The PCI ID to list the mdev types for.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_Pci_Pciid_MdevGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hardware/pci/{pciid}/mdev GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_UsbGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hardware/usb GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Hardware_UsbGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hardware/usb GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CapabilitiesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/capabilities GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CapabilitiesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/capabilities GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_QemuGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/capabilities/qemu GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_QemuGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/capabilities/qemu GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_Qemu_CpuGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/capabilities/qemu/cpu GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_Qemu_CpuGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/capabilities/qemu/cpu GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_Qemu_MachinesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/capabilities/qemu/machines GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Capabilities_Qemu_MachinesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/capabilities/qemu/machines GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StorageGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage GET
    """
    content: str | None = Field(
        description="\u0027Only list stores which support this content type.\u0027",
    )
    enabled: bool | int | str | None = Field(
        default=0,
        description="\u0027Only list stores which are enabled (not disabled in config).\u0027",
    )
    format: bool | int | str | None = Field(
        default=0,
        description="\u0027Include information about formats\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027Only list status for  specified storage\u0027",
    )
    target: ProxmoxNode | None = Field(
        description="\"If target is different to \u0027node\u0027, we only lists shared storages which content is accessible on this \u0027node\u0027 and the specified \u0027target\u0027 node.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StorageGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_StorageGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_StorageGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_PrunebackupsDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/prunebackups DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    prune_backups: str | None = Field(
        description="\u0027Use these retention options instead of those from the storage configuration.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    type: Literal["lxc", "qemu"] | None = Field(
        description="\"Either \u0027qemu\u0027 or \u0027lxc\u0027. Only consider backups for guests of this type.\"",
    )
    vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027Only prune backups for this VM.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_PrunebackupsDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/prunebackups DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_PrunebackupsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/prunebackups GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    prune_backups: str | None = Field(
        description="\u0027Use these retention options instead of those from the storage configuration.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    type: Literal["lxc", "qemu"] | None = Field(
        description="\"Either \u0027qemu\u0027 or \u0027lxc\u0027. Only consider backups for guests of this type.\"",
    )
    vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027Only consider backups for this guest.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_PrunebackupsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/prunebackups GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_ContentGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content GET
    """
    content: str | None = Field(
        description="\u0027Only list content of this type.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    vmid: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027Only list images for this VM\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_ContentGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/content GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_ContentPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content POST
    """
    filename: str = Field(
        description="\u0027The name of the file to create.\u0027",
    )
    format: Literal["qcow2", "raw", "subvol"] | None = Field(
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    size: str = Field(
        description="\"Size in kilobyte (1024 bytes). Optional suffixes \u0027M\u0027 (megabyte, 1024K) and \u0027G\u0027 (gigabyte, 1024M)\"",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    vmid: ProxmoxVMID = Field(
        ge=1,
        description="\u0027Specify owner VM\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_ContentPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/content POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumeDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content/{volume} DELETE
    """
    delay: int | str | None = Field(
        ge=1,
        le=30,
        description="\"Time to wait for the task to finish. We return \u0027null\u0027 if the task finish within that time.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027The storage identifier.\u0027",
    )
    volume: str = Field(
        description="\u0027Volume identifier\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumeDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/content/{volume} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumeGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content/{volume} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027The storage identifier.\u0027",
    )
    volume: str = Field(
        description="\u0027Volume identifier\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumeGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/content/{volume} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content/{volume} POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str | None = Field(
        description="\u0027The storage identifier.\u0027",
    )
    target: str = Field(
        description="\u0027Target volume identifier\u0027",
    )
    target_node: ProxmoxNode | None = Field(
        description="\u0027Target node. Default is local node.\u0027",
    )
    volume: str = Field(
        description="\u0027Source volume identifier\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/content/{volume} POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Content_VolumePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/content/{volume} PUT
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    notes: str | None = Field(
        description="\u0027The new notes.\u0027",
    )
    protected: bool | int | str | None = Field(
        description="\u0027Protection status. Currently only supported for backups.\u0027",
    )
    storage: str | None = Field(
        description="\u0027The storage identifier.\u0027",
    )
    volume: str = Field(
        description="\u0027Volume identifier\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_File_Restore_ListGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/file-restore/list GET
    """
    filepath: str = Field(
        description="\u0027base64-path to the directory or file being listed, or \"/\".\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    volume: str = Field(
        description="\u0027Backup volume ID or name. Currently only PBS snapshots are supported.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_File_Restore_ListGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/file-restore/list GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_File_Restore_DownloadGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/file-restore/download GET
    """
    filepath: str = Field(
        description="\u0027base64-path to the directory or file to download.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    volume: str = Field(
        description="\u0027Backup volume ID or name. Currently only PBS snapshots are supported.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_File_Restore_DownloadGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/file-restore/download GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_RrdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/rrd GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    ds: str = Field(
        description="\u0027The list of datasources you want to display.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_RrdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/rrd GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_RrddataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/rrddata GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_RrddataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/rrddata GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_UploadPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/upload POST
    """
    checksum: str | None = Field(
        description="\u0027The expected checksum of the file.\u0027",
    )
    checksum_algorithm: Literal["md5", "sha1", "sha224", "sha256", "sha384", "sha512"] | None = Field(
        description="\u0027The algorithm to calculate the checksum of the file.\u0027",
    )
    content: Literal["iso", "vztmpl"] = Field(
        description="\u0027Content type.\u0027",
    )
    filename: str = Field(
        max_length=255,
        description="\u0027The name of the file to create. Caution: This will be normalized!\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    tmpfilename: str | None = Field(
        description="\u0027The source file name. This parameter is usually set by the REST handler. You can only overwrite it when connecting to the trusted port on localhost.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_UploadPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/upload POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Download_UrlPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/storage/{storage}/download-url POST
    """
    checksum: str | None = Field(
        description="\u0027The expected checksum of the file.\u0027",
    )
    checksum_algorithm: Literal["md5", "sha1", "sha224", "sha256", "sha384", "sha512"] | None = Field(
        description="\u0027The algorithm to calculate the checksum of the file.\u0027",
    )
    content: Literal["iso", "vztmpl"] = Field(
        description="\u0027Content type.\u0027",
    )
    filename: str = Field(
        max_length=255,
        description="\u0027The name of the file to create. Caution: This will be normalized!\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    url: str = Field(
        description="\u0027The URL to download the file from.\u0027",
    )
    verify_certificates: bool | int | str | None = Field(
        default=1,
        description="\u0027If false, no SSL/TLS certificates will be verified.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Storage_Storage_Download_UrlPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/storage/{storage}/download-url POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_DisksGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_DisksGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvm GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvm GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvm POST
    """
    add_storage: bool | int | str | None = Field(
        default=0,
        description="\u0027Configure storage using the Volume Group\u0027",
    )
    device: str = Field(
        description="\u0027The block device you want to create the volume group on\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvm POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Lvm_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvm/{name} DELETE
    """
    cleanup_config: bool | int | str | None = Field(
        default=0,
        description="\u0027Marks associated storage(s) as not available on this node anymore or removes them from the configuration (if configured for this node only).\u0027",
    )
    cleanup_disks: bool | int | str | None = Field(
        default=0,
        description="\u0027Also wipe disks so they can be repurposed afterwards.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Lvm_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvm/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmthinGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvmthin GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmthinGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvmthin GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmthinPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvmthin POST
    """
    add_storage: bool | int | str | None = Field(
        default=0,
        description="\u0027Configure storage using the thinpool.\u0027",
    )
    device: str = Field(
        description="\u0027The block device you want to create the thinpool on.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_LvmthinPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvmthin POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Lvmthin_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/lvmthin/{name} DELETE
    """
    cleanup_config: bool | int | str | None = Field(
        default=0,
        description="\u0027Marks associated storage(s) as not available on this node anymore or removes them from the configuration (if configured for this node only).\u0027",
    )
    cleanup_disks: bool | int | str | None = Field(
        default=0,
        description="\u0027Also wipe disks so they can be repurposed afterwards.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    volume_group: str = Field(
        description="\u0027The storage identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Lvmthin_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/lvmthin/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_DirectoryGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/directory GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_DirectoryGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/directory GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_DirectoryPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/directory POST
    """
    add_storage: bool | int | str | None = Field(
        default=0,
        description="\u0027Configure storage using the directory.\u0027",
    )
    device: str = Field(
        description="\u0027The block device you want to create the filesystem on.\u0027",
    )
    filesystem: Literal["ext4", "xfs"] | None = Field(
        default="ext4",
        description="\u0027The desired filesystem.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_DirectoryPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/directory POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Directory_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/directory/{name} DELETE
    """
    cleanup_config: bool | int | str | None = Field(
        default=0,
        description="\u0027Marks associated storage(s) as not available on this node anymore or removes them from the configuration (if configured for this node only).\u0027",
    )
    cleanup_disks: bool | int | str | None = Field(
        default=0,
        description="\u0027Also wipe disk so it can be repurposed afterwards.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Directory_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/directory/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ZfsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/zfs GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ZfsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/zfs GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ZfsPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/zfs POST
    """
    add_storage: bool | int | str | None = Field(
        default=0,
        description="\u0027Configure storage using the zpool.\u0027",
    )
    ashift: int | str | None = Field(
        default=12,
        ge=9,
        le=16,
        description="\u0027Pool sector size exponent.\u0027",
    )
    compression: Literal["gzip", "lz4", "lzjb", "off", "on", "zle", "zstd"] | None = Field(
        default="on",
        description="\u0027The compression algorithm to use.\u0027",
    )
    devices: str = Field(
        description="\u0027The block devices you want to create the zpool on.\u0027",
    )
    draid_config: str | None = Field(
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    raidlevel: Literal["draid", "draid2", "draid3", "mirror", "raid10", "raidz", "raidz2", "raidz3", "single"] = Field(
        description="\u0027The RAID level to use.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ZfsPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/zfs POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Zfs_NameDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/zfs/{name} DELETE
    """
    cleanup_config: bool | int | str | None = Field(
        default=0,
        description="\u0027Marks associated storage(s) as not available on this node anymore or removes them from the configuration (if configured for this node only).\u0027",
    )
    cleanup_disks: bool | int | str | None = Field(
        default=0,
        description="\u0027Also wipe disks so they can be repurposed afterwards.\u0027",
    )
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Zfs_NameDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/zfs/{name} DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Zfs_NameGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/zfs/{name} GET
    """
    name: str = Field(
        description="\u0027The storage identifier.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_Zfs_NameGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/zfs/{name} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ListGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/list GET
    """
    include_partitions: bool | int | str | None = Field(
        default=0,
        description="\u0027Also include partitions.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    skipsmart: bool | int | str | None = Field(
        default=0,
        description="\u0027Skip smart checks.\u0027",
    )
    type: Literal["journal_disks", "unused"] | None = Field(
        description="\u0027Only list specific types of disks.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_ListGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/list GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_SmartGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/smart GET
    """
    disk: str = Field(
        description="\u0027Block device name\u0027",
    )
    healthonly: bool | int | str | None = Field(
        description="\u0027If true returns only the health status\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_SmartGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/smart GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_InitgptPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/initgpt POST
    """
    disk: str = Field(
        description="\u0027Block device name\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    uuid: str | None = Field(
        max_length=36,
        description="\u0027UUID for the GPT table\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_InitgptPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/initgpt POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_WipediskPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/disks/wipedisk PUT
    """
    disk: str = Field(
        description="\u0027Block device name\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Disks_WipediskPUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/disks/wipedisk PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AptGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AptGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_UpdateGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/update GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_UpdateGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt/update GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_UpdatePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/update POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    notify: bool | int | str | None = Field(
        default=0,
        description="\"Send notification mail about new packages (to email address specified for user \u0027root@pam\u0027).\"",
    )
    quiet: bool | int | str | None = Field(
        default=0,
        description="\u0027Only produces output suitable for logging, omitting progress indicators.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_UpdatePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt/update POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_ChangelogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/changelog GET
    """
    name: str = Field(
        description="\u0027Package name.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    version: str | None = Field(
        description="\u0027Package version.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_ChangelogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt/changelog GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_RepositoriesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/repositories GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_RepositoriesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt/repositories GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_RepositoriesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/repositories POST
    """
    digest: str | None = Field(
        max_length=80,
        description="\u0027Digest to detect modifications.\u0027",
    )
    enabled: bool | int | str | None = Field(
        description="\u0027Whether the repository should be enabled or not.\u0027",
    )
    index: int | str = Field(
        description="\u0027Index within the file (starting from 0).\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    path: str = Field(
        description="\u0027Path to the containing file.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_RepositoriesPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/repositories PUT
    """
    digest: str | None = Field(
        max_length=80,
        description="\u0027Digest to detect modifications.\u0027",
    )
    handle: str = Field(
        description="\u0027Handle that identifies a repository.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_VersionsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/apt/versions GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Apt_VersionsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/apt/versions GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_FirewallGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_FirewallGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/firewall GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_RulesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/rules GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_RulesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/firewall/rules GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_RulesPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/rules POST
    """
    action: str = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_Rules_PosDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/rules/{pos} DELETE
    """
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_Rules_PosGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/rules/{pos} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_Rules_PosGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/firewall/rules/{pos} GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_Rules_PosPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/rules/{pos} PUT
    """
    action: str | None = Field(
        max_length=20,
        description="\"Rule action (\u0027ACCEPT\u0027, \u0027DROP\u0027, \u0027REJECT\u0027) or security group name.\"",
    )
    comment: str | None = Field(
        description="\u0027Descriptive comment.\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    dest: str | None = Field(
        max_length=512,
        description="\"Restrict packet destination address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    dport: str | None = Field(
        description="\"Restrict TCP/UDP destination port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    enable: int | str | None = Field(
        ge=0,
        description="\u0027Flag to enable/disable a rule.\u0027",
    )
    icmp_type: str | None = Field(
        description="\"Specify icmp-type. Only valid if proto equals \u0027icmp\u0027.\"",
    )
    iface: str | None = Field(
        max_length=20,
        description="\"Network interface name. You have to use network configuration key names for VMs and containers (\u0027net\\\\d+\u0027). Host related rules can use arbitrary strings.\"",
    )
    log: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for firewall rule.\u0027",
    )
    macro: str | None = Field(
        max_length=128,
        description="\u0027Use predefined standard macro.\u0027",
    )
    moveto: int | str | None = Field(
        ge=0,
        description="\u0027Move rule to new position \u003cmoveto\u003e. Other arguments are ignored.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    pos: int | str | None = Field(
        ge=0,
        description="\u0027Update rule at position \u003cpos\u003e.\u0027",
    )
    proto: str | None = Field(
        description="\"IP protocol. You can use protocol names (\u0027tcp\u0027/\u0027udp\u0027) or simple numbers, as defined in \u0027/etc/protocols\u0027.\"",
    )
    source: str | None = Field(
        max_length=512,
        description="\"Restrict packet source address. This can refer to a single IP address, an IP set (\u0027+ipsetname\u0027) or an IP alias definition. You can also specify an address range like \u002720.34.101.207-201.3.9.99\u0027, or a list of IP addresses and networks (entries are separated by comma). Please do not mix IPv4 and IPv6 addresses inside such lists.\"",
    )
    sport: str | None = Field(
        description="\"Restrict TCP/UDP source port. You can use service names or simple numbers (0-65535), as defined in \u0027/etc/services\u0027. Port ranges can be specified with \u0027\\\\d+:\\\\d+\u0027, for example \u002780:85\u0027, and you can use comma separated list to match several ports or ranges.\"",
    )
    type: Literal["group", "in", "out"] | None = Field(
        description="\u0027Rule type.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_OptionsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/options GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_OptionsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/firewall/options GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_OptionsPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/options PUT
    """
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    enable: bool | int | str | None = Field(
        description="\u0027Enable host firewall rules.\u0027",
    )
    log_level_in: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for incoming traffic.\u0027",
    )
    log_level_out: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for outgoing traffic.\u0027",
    )
    log_nf_conntrack: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable logging of conntrack information.\u0027",
    )
    ndp: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable NDP (Neighbor Discovery Protocol).\u0027",
    )
    nf_conntrack_allow_invalid: bool | int | str | None = Field(
        default=0,
        description="\u0027Allow invalid packets on connection tracking.\u0027",
    )
    nf_conntrack_helpers: str | None = Field(
        default="",
        description="\u0027Enable conntrack helpers for specific protocols. Supported protocols: amanda, ftp, irc, netbios-ns, pptp, sane, sip, snmp, tftp\u0027",
    )
    nf_conntrack_max: int | str | None = Field(
        default=262144,
        ge=32768,
        description="\u0027Maximum number of tracked connections.\u0027",
    )
    nf_conntrack_tcp_timeout_established: int | str | None = Field(
        default=432000,
        ge=7875,
        description="\u0027Conntrack established timeout.\u0027",
    )
    nf_conntrack_tcp_timeout_syn_recv: int | str | None = Field(
        default=60,
        ge=30,
        le=60,
        description="\u0027Conntrack syn recv timeout.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    nosmurfs: bool | int | str | None = Field(
        description="\u0027Enable SMURFS filter.\u0027",
    )
    protection_synflood: bool | int | str | None = Field(
        default=0,
        description="\u0027Enable synflood protection\u0027",
    )
    protection_synflood_burst: int | str | None = Field(
        default=1000,
        description="\u0027Synflood protection rate burst by ip src.\u0027",
    )
    protection_synflood_rate: int | str | None = Field(
        default=200,
        description="\u0027Synflood protection rate syn/sec by ip src.\u0027",
    )
    smurf_log_level: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for SMURFS filter.\u0027",
    )
    tcp_flags_log_level: Literal["alert", "crit", "debug", "emerg", "err", "info", "nolog", "notice", "warning"] | None = Field(
        description="\u0027Log level for illegal tcp flags filter.\u0027",
    )
    tcpflags: bool | int | str | None = Field(
        default=0,
        description="\u0027Filter illegal combinations of TCP flags.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/firewall/log GET
    """
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    since: int | str | None = Field(
        ge=0,
        description="\u0027Display log since this UNIX epoch.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )
    until: int | str | None = Field(
        ge=0,
        description="\u0027Display log until this UNIX epoch.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Firewall_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/firewall/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ReplicationGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/replication GET
    """
    guest: ProxmoxVMID | None = Field(
        ge=1,
        description="\u0027Only list replication jobs for this guest.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ReplicationGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/replication GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_IdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/replication/{id} GET
    """
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_IdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/replication/{id} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/replication/{id}/status GET
    """
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/replication/{id}/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_LogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/replication/{id}/log GET
    """
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_LogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/replication/{id}/log GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_Schedule_NowPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/replication/{id}/schedule_now POST
    """
    id: str = Field(
        description="\"Replication Job ID. The ID is composed of a Guest ID and a job number, separated by a hyphen, i.e. \u0027\u003cGUEST\u003e-\u003cJOBNUM\u003e\u0027.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Replication_Id_Schedule_NowPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/replication/{id}/schedule_now POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CertificatesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_CertificatesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_AcmeGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/acme GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_AcmeGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/acme GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificateDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/acme/certificate DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificateDELETEResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/acme/certificate DELETE
    """
    data: str = Field(
        description="\u0027Response data for DELETE\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificatePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/acme/certificate POST
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Overwrite existing custom certificate.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificatePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/acme/certificate POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificatePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/acme/certificate PUT
    """
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Force renewal even if expiry is more than 30 days away.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_Acme_CertificatePUTResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/acme/certificate PUT
    """
    data: str = Field(
        description="\u0027Response data for PUT\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_InfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/info GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_InfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/info GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_CustomDELETERequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/custom DELETE
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    restart: bool | int | str | None = Field(
        default=0,
        description="\u0027Restart pveproxy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_CustomPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/certificates/custom POST
    """
    certificates: str = Field(
        description="\u0027PEM encoded certificate (chain).\u0027",
    )
    force: bool | int | str | None = Field(
        default=0,
        description="\u0027Overwrite existing custom or ACME certificate files.\u0027",
    )
    key: str | None = Field(
        description="\u0027PEM encoded private key.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    restart: bool | int | str | None = Field(
        default=0,
        description="\u0027Restart pveproxy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Certificates_CustomPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/certificates/custom POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ConfigGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/config GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    property: Literal["acme", "acmedomain0", "acmedomain1", "acmedomain2", "acmedomain3", "acmedomain4", "acmedomain5", "all", "description", "startall-onboot-delay", "wakeonlan"] | None = Field(
        default="all",
        description="\u0027Return only a specific property from the node configuration.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ConfigGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/config GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ConfigPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/config PUT
    """
    acme: str | None = Field(
        description="\u0027Node specific ACME settings.\u0027",
    )
    acmedomain_n_: str | None = Field(
        description="\u0027ACME domain and validation plugin\u0027",
    )
    delete: str | None = Field(
        description="\u0027A list of settings you want to delete.\u0027",
    )
    description: str | None = Field(
        max_length=65536,
        description="\u0027Description for the Node. Shown in the web-interface node notes panel. This is saved as comment inside the configuration file.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    startall_onboot_delay: int | str | None = Field(
        default=0,
        ge=0,
        le=300,
        description="\u0027Initial delay in seconds, before starting all the Virtual Guests with on-boot enabled.\u0027",
    )
    wakeonlan: str | None = Field(
        description="\u0027MAC address for wake on LAN\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SdnGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/sdn GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SdnGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/sdn GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_ZonesGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/sdn/zones GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_ZonesGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/sdn/zones GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_Zones_ZoneGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/sdn/zones/{zone} GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_Zones_ZoneGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/sdn/zones/{zone} GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_Zones_Zone_ContentGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/sdn/zones/{zone}/content GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    zone: str = Field(
        description="\u0027The SDN zone object identifier.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Sdn_Zones_Zone_ContentGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/sdn/zones/{zone}/content GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VersionGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/version GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VersionGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/version GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StatusGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/status GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StatusGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/status GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StatusPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/status POST
    """
    command: Literal["reboot", "shutdown"] = Field(
        description="\u0027Specify the command.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetstatGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/netstat GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_NetstatGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/netstat GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ExecutePOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/execute POST
    """
    commands: str = Field(
        description="\u0027JSON encoded array of commands.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ExecutePOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/execute POST
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_WakeonlanPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/wakeonlan POST
    """
    node: ProxmoxNode = Field(
        description="\u0027target node for wake on LAN packet\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_WakeonlanPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/wakeonlan POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_RrdGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/rrd GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    ds: str = Field(
        description="\u0027The list of datasources you want to display.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_RrdGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/rrd GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_RrddataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/rrddata GET
    """
    cf: Literal["AVERAGE", "MAX"] | None = Field(
        description="\u0027The RRD consolidation function\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeframe: Literal["day", "hour", "month", "week", "year"] = Field(
        description="\u0027Specify the time frame you are interested in.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_RrddataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/rrddata GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SyslogGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/syslog GET
    """
    limit: int | str | None = Field(
        ge=0,
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    service: str | None = Field(
        max_length=128,
        description="\u0027Service ID\u0027",
    )
    since: str | None = Field(
        description="\u0027Display all log since this date-time string.\u0027",
    )
    start: int | str | None = Field(
        ge=0,
    )
    until: str | None = Field(
        description="\u0027Display all log until this date-time string.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SyslogGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/syslog GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_JournalGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/journal GET
    """
    endcursor: str | None = Field(
        description="\"End before the given Cursor. Conflicts with \u0027until\u0027\"",
    )
    lastentries: int | str | None = Field(
        ge=0,
        description="\u0027Limit to the last X lines. Conflicts with a range.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    since: int | str | None = Field(
        ge=0,
        description="\"Display all log since this UNIX epoch. Conflicts with \u0027startcursor\u0027.\"",
    )
    startcursor: str | None = Field(
        description="\"Start after the given Cursor. Conflicts with \u0027since\u0027\"",
    )
    until: int | str | None = Field(
        ge=0,
        description="\"Display all log until this UNIX epoch. Conflicts with \u0027endcursor\u0027.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_JournalGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/journal GET
    """
    data: list[str] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VncshellPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/vncshell POST
    """
    cmd: Literal["ceph_install", "login", "upgrade"] | None = Field(
        default="login",
        description="\u0027Run specific command or default to login.\u0027",
    )
    cmd_opts: str | None = Field(
        default="",
        description="\u0027Add parameters to a command. Encoded as null terminated strings.\u0027",
    )
    height: int | str | None = Field(
        ge=16,
        le=2160,
        description="\u0027sets the height of the console in pixels.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    websocket: bool | int | str | None = Field(
        description="\u0027use websocket instead of standard vnc.\u0027",
    )
    width: int | str | None = Field(
        ge=16,
        le=4096,
        description="\u0027sets the width of the console in pixels.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VncshellPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/vncshell POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TermproxyPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/termproxy POST
    """
    cmd: Literal["ceph_install", "login", "upgrade"] | None = Field(
        default="login",
        description="\u0027Run specific command or default to login.\u0027",
    )
    cmd_opts: str | None = Field(
        default="",
        description="\u0027Add parameters to a command. Encoded as null terminated strings.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TermproxyPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/termproxy POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VncwebsocketGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/vncwebsocket GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    port: int | str = Field(
        ge=5900,
        le=5999,
        description="\u0027Port number returned by previous vncproxy call.\u0027",
    )
    vncticket: str = Field(
        max_length=512,
        description="\u0027Ticket from previous call to vncproxy.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_VncwebsocketGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/vncwebsocket GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SpiceshellPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/spiceshell POST
    """
    cmd: Literal["ceph_install", "login", "upgrade"] | None = Field(
        default="login",
        description="\u0027Run specific command or default to login.\u0027",
    )
    cmd_opts: str | None = Field(
        default="",
        description="\u0027Add parameters to a command. Encoded as null terminated strings.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    proxy: str | None = Field(
        description="\"SPICE proxy server. This can be used by the client to specify the proxy server. All nodes in a cluster runs \u0027spiceproxy\u0027, so it is up to the client to choose one. By default, we return the node where the VM is currently running. As reasonable setting is to use same node you use to connect to the API (This is window.location.hostname for the JS GUI).\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_SpiceshellPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/spiceshell POST
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_DnsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/dns GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_DnsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/dns GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_DnsPUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/dns PUT
    """
    dns1: str | None = Field(
        description="\u0027First name server IP address.\u0027",
    )
    dns2: str | None = Field(
        description="\u0027Second name server IP address.\u0027",
    )
    dns3: str | None = Field(
        description="\u0027Third name server IP address.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    search: str = Field(
        description="\u0027Search domain for host-name lookup.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TimeGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/time GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TimeGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/time GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_TimePUTRequest(BaseModel):
    """
    Request model for /nodes/{node}/time PUT
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timezone: str = Field(
        description="\"Time zone. The file \u0027/usr/share/zoneinfo/zone.tab\u0027 contains the list of valid names.\"",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AplinfoGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/aplinfo GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AplinfoGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/aplinfo GET
    """
    data: list[dict[str, Any]] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AplinfoPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/aplinfo POST
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    storage: str = Field(
        description="\u0027The storage where the template will be stored\u0027",
    )
    template: str = Field(
        max_length=255,
        description="\u0027The template which will downloaded\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_AplinfoPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/aplinfo POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Query_Url_MetadataGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/query-url-metadata GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    url: str = Field(
        description="\u0027The URL to query the metadata from.\u0027",
    )
    verify_certificates: bool | int | str | None = Field(
        default=1,
        description="\u0027If false, no SSL/TLS certificates will be verified.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_Query_Url_MetadataGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/query-url-metadata GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ReportGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/report GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_ReportGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/report GET
    """
    data: str = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StartallPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/startall POST
    """
    force: bool | int | str | None = Field(
        default="off",
        description="\"Issue start command even if virtual guest have \u0027onboot\u0027 not set or set to off.\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    vms: list[ProxmoxVMID] | None = Field(
        description="\u0027Only consider guests from this comma separated list of VMIDs.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StartallPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/startall POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StopallPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/stopall POST
    """
    force_stop: bool | int | str | None = Field(
        default=1,
        description="\u0027Force a hard-stop after the timeout.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    timeout: int | str | None = Field(
        default=180,
        ge=0,
        le=7200,
        description="\u0027Timeout for each guest shutdown task. Depending on `force-stop`, the shutdown gets then simply aborted or a hard-stop is forced.\u0027",
    )
    vms: list[ProxmoxVMID] | None = Field(
        description="\u0027Only consider Guests with these IDs.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_StopallPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/stopall POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_MigrateallPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/migrateall POST
    """
    maxworkers: int | str | None = Field(
        ge=1,
        description="\"Maximal number of parallel migration job. If not set, uses\u0027max_workers\u0027 from datacenter.cfg. One of both must be set!\"",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )
    target: ProxmoxNode = Field(
        description="\u0027Target node.\u0027",
    )
    vms: list[ProxmoxVMID] | None = Field(
        description="\u0027Only consider Guests with these IDs.\u0027",
    )
    with_local_disks: bool | int | str | None = Field(
        description="\u0027Enable live storage migration for local disk\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_MigrateallPOSTResponse(BaseModel):
    """
    Response model for /nodes/{node}/migrateall POST
    """
    data: str = Field(
        description="\u0027Response data for POST\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_HostsGETRequest(BaseModel):
    """
    Request model for /nodes/{node}/hosts GET
    """
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_HostsGETResponse(BaseModel):
    """
    Response model for /nodes/{node}/hosts GET
    """
    data: dict[str, Any] = Field(
        description="\u0027Response data for GET\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

class Nodes_Node_HostsPOSTRequest(BaseModel):
    """
    Request model for /nodes/{node}/hosts POST
    """
    data: str = Field(
        description="\u0027The target content of /etc/hosts.\u0027",
    )
    digest: str | None = Field(
        max_length=40,
        description="\u0027Prevent changes if current configuration file has different SHA1 digest. This can be used to prevent concurrent modifications.\u0027",
    )
    node: ProxmoxNode = Field(
        description="\u0027The cluster node name.\u0027",
    )

    model_config = ConfigDict(extra="forbid", validate_assignment=True)

