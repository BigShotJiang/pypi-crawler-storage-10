"""Generated endpoint classes"""
