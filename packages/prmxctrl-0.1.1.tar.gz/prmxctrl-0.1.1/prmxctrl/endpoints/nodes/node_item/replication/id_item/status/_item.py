"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Replication_Id_StatusGETRequest,
    Nodes_Node_Replication_Id_StatusGETResponse,  # type: ignore
)


class NodesReplicationStatusEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/replication/{id}/status
    """



    async def get(self, params: Nodes_Node_Replication_Id_StatusGETRequest | None = None) -> Nodes_Node_Replication_Id_StatusGETResponse:
        """
        Get replication job status.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

