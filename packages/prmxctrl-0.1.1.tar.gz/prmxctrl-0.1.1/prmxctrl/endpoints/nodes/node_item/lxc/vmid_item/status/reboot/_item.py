"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_Status_RebootPOSTRequest,
    Nodes_Node_Lxc_Vmid_Status_RebootPOSTResponse,  # type: ignore
)


class NodesLxcStatusRebootEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/status/reboot
    """



    async def vm_reboot(self, params: Nodes_Node_Lxc_Vmid_Status_RebootPOSTRequest | None = None) -> Nodes_Node_Lxc_Vmid_Status_RebootPOSTResponse:
        """
        Reboot the container by shutting it down, and starting it again. Applies pending changes.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

