"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_TermproxyPOSTRequest,
    Nodes_Node_Lxc_Vmid_TermproxyPOSTResponse,  # type: ignore
)


class NodesLxcTermproxyEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/termproxy
    """



    async def termproxy(self, params: Nodes_Node_Lxc_Vmid_TermproxyPOSTRequest | None = None) -> Nodes_Node_Lxc_Vmid_TermproxyPOSTResponse:
        """
        Creates a TCP proxy connection.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

