"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_RrdGETRequest,
    Nodes_Node_Lxc_Vmid_RrdGETResponse,  # type: ignore
)


class NodesLxcRrdEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/rrd
    """



    async def get(self, params: Nodes_Node_Lxc_Vmid_RrdGETRequest | None = None) -> Nodes_Node_Lxc_Vmid_RrdGETResponse:
        """
        Read VM RRD statistics (returns PNG)

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

