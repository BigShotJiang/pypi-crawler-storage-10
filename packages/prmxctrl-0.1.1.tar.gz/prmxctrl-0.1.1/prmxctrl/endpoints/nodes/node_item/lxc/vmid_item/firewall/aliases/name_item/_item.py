"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from typing import Any

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameDELETERequest,
    Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETRequest,
    Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETResponse,
    Nodes_Node_Lxc_Vmid_Firewall_Aliases_NamePUTRequest,  # type: ignore
)


class NodesLxcFirewallAliasesEndpoints1(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/firewall/aliases/{name}
    """



    async def delete(self, params: Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameDELETERequest | None = None) -> Any:
        """
        Remove IP or Network alias.

        HTTP Method: DELETE
        """
        return await self._delete()

    async def get(self, params: Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETRequest | None = None) -> Nodes_Node_Lxc_Vmid_Firewall_Aliases_NameGETResponse:
        """
        Read alias.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

    async def update_alias(self, params: Nodes_Node_Lxc_Vmid_Firewall_Aliases_NamePUTRequest | None = None) -> Any:
        """
        Update IP or Network alias.

        HTTP Method: PUT
        """
        return await self._put(data=params.model_dump(exclude_none=True) if params else None)

