"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_Status_StopPOSTRequest,
    Nodes_Node_Lxc_Vmid_Status_StopPOSTResponse,  # type: ignore
)


class NodesLxcStatusStopEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/status/stop
    """



    async def vm_stop(self, params: Nodes_Node_Lxc_Vmid_Status_StopPOSTRequest | None = None) -> Nodes_Node_Lxc_Vmid_Status_StopPOSTResponse:
        """
        Stop the container. This will abruptly stop all processes running in the container.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

