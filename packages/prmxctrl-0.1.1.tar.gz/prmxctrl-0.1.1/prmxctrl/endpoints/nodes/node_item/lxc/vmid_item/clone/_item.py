"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_ClonePOSTRequest,
    Nodes_Node_Lxc_Vmid_ClonePOSTResponse,  # type: ignore
)


class NodesLxcCloneEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/clone
    """



    async def clone_vm(self, params: Nodes_Node_Lxc_Vmid_ClonePOSTRequest | None = None) -> Nodes_Node_Lxc_Vmid_ClonePOSTResponse:
        """
        Create a container clone/copy

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

