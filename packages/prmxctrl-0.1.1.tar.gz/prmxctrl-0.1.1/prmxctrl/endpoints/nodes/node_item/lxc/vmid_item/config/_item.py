"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from typing import Any

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Lxc_Vmid_ConfigGETRequest,
    Nodes_Node_Lxc_Vmid_ConfigGETResponse,
    Nodes_Node_Lxc_Vmid_ConfigPUTRequest,  # type: ignore
)


class NodesLxcConfigEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/lxc/{vmid}/config
    """



    async def get(self, params: Nodes_Node_Lxc_Vmid_ConfigGETRequest | None = None) -> Nodes_Node_Lxc_Vmid_ConfigGETResponse:
        """
        Get container configuration.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

    async def update_vm(self, params: Nodes_Node_Lxc_Vmid_ConfigPUTRequest | None = None) -> Any:
        """
        Set container options.

        HTTP Method: PUT
        """
        return await self._put(data=params.model_dump(exclude_none=True) if params else None)

