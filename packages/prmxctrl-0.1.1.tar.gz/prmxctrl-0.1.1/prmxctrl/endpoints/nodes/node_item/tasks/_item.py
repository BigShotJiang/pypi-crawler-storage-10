"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_TasksGETRequest,
    Nodes_Node_TasksGETResponse,  # type: ignore
)

from .upid_item._item import NodesTasksEndpoints1


class NodesTasksEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/tasks
    """


    def __call__(self, upid: int) -> NodesTasksEndpoints1:
        """Access specific upid"""
        from .upid_item._item import NodesTasksEndpoints1  # type: ignore
        return NodesTasksEndpoints1(
            self._client,
            self._build_path(str(upid))
        )


    async def list(self, params: Nodes_Node_TasksGETRequest | None = None) -> Nodes_Node_TasksGETResponse:
        """
        Read task list for one node (finished tasks).

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

