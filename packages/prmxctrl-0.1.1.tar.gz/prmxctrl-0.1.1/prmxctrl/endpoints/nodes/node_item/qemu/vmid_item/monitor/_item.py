"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Qemu_Vmid_MonitorPOSTRequest,
    Nodes_Node_Qemu_Vmid_MonitorPOSTResponse,  # type: ignore
)


class NodesQemuMonitorEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/qemu/{vmid}/monitor
    """



    async def monitor(self, params: Nodes_Node_Qemu_Vmid_MonitorPOSTRequest | None = None) -> Nodes_Node_Qemu_Vmid_MonitorPOSTResponse:
        """
        Execute QEMU monitor commands.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

