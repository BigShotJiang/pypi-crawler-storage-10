"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Qemu_Vmid_Status_CurrentGETRequest,
    Nodes_Node_Qemu_Vmid_Status_CurrentGETResponse,  # type: ignore
)


class NodesQemuStatusCurrentEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/qemu/{vmid}/status/current
    """



    async def get(self, params: Nodes_Node_Qemu_Vmid_Status_CurrentGETRequest | None = None) -> Nodes_Node_Qemu_Vmid_Status_CurrentGETResponse:
        """
        Get virtual machine status.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

