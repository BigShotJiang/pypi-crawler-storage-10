"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Qemu_Vmid_RrddataGETRequest,
    Nodes_Node_Qemu_Vmid_RrddataGETResponse,  # type: ignore
)


class NodesQemuRrddataEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/qemu/{vmid}/rrddata
    """



    async def list(self, params: Nodes_Node_Qemu_Vmid_RrddataGETRequest | None = None) -> Nodes_Node_Qemu_Vmid_RrddataGETResponse:
        """
        Read VM RRD statistics

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

