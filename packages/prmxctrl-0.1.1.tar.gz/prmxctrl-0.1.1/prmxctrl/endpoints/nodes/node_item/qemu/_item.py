"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_QemuGETRequest,
    Nodes_Node_QemuGETResponse,
    Nodes_Node_QemuPOSTRequest,
    Nodes_Node_QemuPOSTResponse,  # type: ignore
)

from .vmid_item._item import NodesQemuEndpoints1


class NodesQemuEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/qemu
    """


    def __call__(self, vmid: int) -> NodesQemuEndpoints1:
        """Access specific vmid"""
        from .vmid_item._item import NodesQemuEndpoints1  # type: ignore
        return NodesQemuEndpoints1(
            self._client,
            self._build_path(str(vmid))
        )


    async def list(self, params: Nodes_Node_QemuGETRequest | None = None) -> Nodes_Node_QemuGETResponse:
        """
        Virtual machine index (per node).

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

    async def create_vm(self, params: Nodes_Node_QemuPOSTRequest | None = None) -> Nodes_Node_QemuPOSTResponse:
        """
        Create or restore a virtual machine.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

