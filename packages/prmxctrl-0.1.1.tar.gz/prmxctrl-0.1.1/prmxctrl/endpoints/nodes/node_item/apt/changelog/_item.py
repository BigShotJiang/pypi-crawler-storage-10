"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Apt_ChangelogGETRequest,
    Nodes_Node_Apt_ChangelogGETResponse,  # type: ignore
)


class NodesAptChangelogEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/apt/changelog
    """



    async def get(self, params: Nodes_Node_Apt_ChangelogGETRequest | None = None) -> Nodes_Node_Apt_ChangelogGETResponse:
        """
        Get package changelogs.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

