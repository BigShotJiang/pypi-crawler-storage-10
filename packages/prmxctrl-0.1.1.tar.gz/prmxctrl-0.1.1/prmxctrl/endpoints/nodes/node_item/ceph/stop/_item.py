"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Ceph_StopPOSTRequest,
    Nodes_Node_Ceph_StopPOSTResponse,  # type: ignore
)


class NodesCephStopEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/ceph/stop
    """



    async def stop(self, params: Nodes_Node_Ceph_StopPOSTRequest | None = None) -> Nodes_Node_Ceph_StopPOSTResponse:
        """
        Stop ceph services.

        HTTP Method: POST
        """
        return await self._post(data=params.model_dump(exclude_none=True) if params else None)

