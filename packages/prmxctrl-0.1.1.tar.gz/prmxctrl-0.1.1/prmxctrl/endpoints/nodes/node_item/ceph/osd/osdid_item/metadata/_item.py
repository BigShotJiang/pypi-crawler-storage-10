"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Ceph_Osd_Osdid_MetadataGETRequest,
    Nodes_Node_Ceph_Osd_Osdid_MetadataGETResponse,  # type: ignore
)


class NodesCephOsdMetadataEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/ceph/osd/{osdid}/metadata
    """



    async def get(self, params: Nodes_Node_Ceph_Osd_Osdid_MetadataGETRequest | None = None) -> Nodes_Node_Ceph_Osd_Osdid_MetadataGETResponse:
        """
        Get OSD details

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

