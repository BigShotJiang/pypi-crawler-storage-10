"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.nodes import (
    Nodes_Node_Ceph_Cmd_SafetyGETRequest,
    Nodes_Node_Ceph_Cmd_SafetyGETResponse,  # type: ignore
)


class NodesCephCmd_SafetyEndpoints(EndpointBase):
    """
    Endpoint class for /nodes/{node}/ceph/cmd-safety
    """



    async def get(self, params: Nodes_Node_Ceph_Cmd_SafetyGETRequest | None = None) -> Nodes_Node_Ceph_Cmd_SafetyGETResponse:
        """
        Heuristical check if it is safe to perform an action.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

