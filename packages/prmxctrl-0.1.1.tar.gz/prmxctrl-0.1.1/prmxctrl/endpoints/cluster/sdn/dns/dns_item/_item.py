"""
Generated endpoint classes for Proxmox VE API endpoints.

This module contains auto-generated endpoint classes for hierarchical
API access to Proxmox VE endpoints.
DO NOT EDIT MANUALLY
"""

from typing import Any

from prmxctrl.base.endpoint_base import EndpointBase
from prmxctrl.models.cluster import (
    Cluster_Sdn_Dns_DnsDELETERequest,
    Cluster_Sdn_Dns_DnsGETRequest,
    Cluster_Sdn_Dns_DnsGETResponse,
    Cluster_Sdn_Dns_DnsPUTRequest,  # type: ignore
)


class ClusterSdnDnsEndpoints1(EndpointBase):
    """
    Endpoint class for /cluster/sdn/dns/{dns}
    """



    async def delete(self, params: Cluster_Sdn_Dns_DnsDELETERequest | None = None) -> Any:
        """
        Delete sdn dns object configuration.

        HTTP Method: DELETE
        """
        return await self._delete()

    async def get(self, params: Cluster_Sdn_Dns_DnsGETRequest | None = None) -> Cluster_Sdn_Dns_DnsGETResponse:
        """
        Read sdn dns configuration.

        HTTP Method: GET
        """
        return await self._get(params=params.model_dump(exclude_none=True) if params else None)

    async def update(self, params: Cluster_Sdn_Dns_DnsPUTRequest | None = None) -> Any:
        """
        Update sdn dns object configuration.

        HTTP Method: PUT
        """
        return await self._put(data=params.model_dump(exclude_none=True) if params else None)

