# Security Policy

Bytes is part of the Tokio project and uses the same security policy as [Tokio][tokio-security].

## Report a security issue

The process for reporting an issue is the same as for [Tokio][tokio-security]. This includes private reporting via security@tokio.rs.

[tokio-security]: https://github.com/tokio-rs/tokio/security/policy
