// SPDX-License-Identifier: (Apache-2.0 OR MIT)

mod ffi;
mod yyjson;

pub(crate) use yyjson::deserialize;
