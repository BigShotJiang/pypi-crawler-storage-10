# ecommerce

Minimal demo package for a tutorial. Contains a small `inventory` and `sales` module.

Install (after upload to PyPI):

    pip install ecommerce

Usage example:

    import ecommerce
    print(ecommerce.__version__)
