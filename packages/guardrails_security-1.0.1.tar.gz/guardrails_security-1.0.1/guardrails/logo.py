#!/usr/bin/env python3

"""
GuardRails ASCII Logo
This displays when the package is installed
"""

import sys

def display_logo():
    """Display the GuardRails ASCII logo"""
    logo = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║                    ████                                      ║
║                    █  █                                      ║
║                    █  █                                      ║
║                    ██--                                      ║
║                    █  █                                      ║
║                    ████                                      ║
║                                                              ║
║              🛡️  Security Scanner & Auto-Fixer  🛡️              ║
║                                                              ║
║    🔍 Scan for vulnerabilities                                    ║
║    🔧 Auto-fix security issues                                   ║
║    ⚡ Fast & intelligent analysis                               ║
║                                                              ║
║    Get started: guardrails scan . --fix                    ║
║    Docs: https://guardrails.dev                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(logo)

def display_welcome_message():
    """Display welcome message after installation"""
    print('\n🎉 GuardRails installed successfully!')
    print('📚 Documentation: https://guardrails.dev')
    print('🚀 Quick start: guardrails scan . --fix')
    print('💡 Pro tip: Use --dry-run to preview fixes before applying\n')

def main():
    """Main function to display logo and welcome message"""
    display_logo()
    display_welcome_message()

if __name__ == '__main__':
    main()
