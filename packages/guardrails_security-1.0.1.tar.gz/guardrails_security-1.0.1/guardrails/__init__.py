"""
GuardRails Security Scanner

AI-powered security scanner for modern development workflows.
"""

__version__ = "1.0.0"
__author__ = "GuardRails Team"
__email__ = "team@guardrails.dev"

from .scanner import GuardRailsScanner
from .cli import main

__all__ = ["GuardRailsScanner", "main"]
