"""Node module for running otpylib applications."""

from .core import (
    run,
)

__all__ = [
    "run",
]