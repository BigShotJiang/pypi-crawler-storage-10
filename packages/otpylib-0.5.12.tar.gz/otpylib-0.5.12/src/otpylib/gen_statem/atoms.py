from otpylib import atom


# New behavior constant (would be defined in otpylib.module)
GEN_STATEM = atom.ensure("gen_statem")