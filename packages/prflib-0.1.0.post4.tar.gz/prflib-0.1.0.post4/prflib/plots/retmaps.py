"""
"@Author  :   Siddharth Mittal",
"@Version :   1.0",
"@Contact :   siddharth.mittal@meduniwien.ac.at",
"@License :   (C)Copyright 2025, Siddharth Mittal",
"@Desc    :   None",     
"""

class RetinotopicMaps:
    def __init__(self):
        pass

    def generate_map(self):
        pass