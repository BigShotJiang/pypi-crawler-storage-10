class PRFEstimationResults:
    def __init__(self):
        pass

    def summarize_results(self):
        pass