"""
Probabilistic Hashing Engine (PHE)
Non-deterministic hashing with CEL-driven path variation

Implements multi-path hashing where each operation may use unique
permutations and transforms based on CEL state, making reproduction
impossible without original context.

Key principles:
- Multi-path hashing (variable operation graphs)
- CEL-driven path selection
- Variable arithmetic base
- Collision-resistant through dynamic topology
- NO classical hashing constructs (SHA, Blake, etc.)
"""

import numpy as np
from typing import Union, List, Dict, Any, Optional

from utils.math_primitives import (
    permute_sequence,
    modular_transform,
    variable_base_encode,
    variable_base_decode,
    rotate_bits,
    modular_exponentiation,
    data_fingerprint_entropy
)


class ProbabilisticHashingEngine:
    """
    PHE - Probabilistic hashing with context-dependent path selection
    
    Generates hashes through variable mathematical pathways determined
    by CEL state, creating unique transformations for each context.
    """
    
    def __init__(self):
        """Initialize PHE"""
        self.cel_snapshot: Optional[Dict[str, Any]] = None
        self.operation_count = 0
        self.path_history: List[int] = []
        
    def map_entropy(self, cel_snapshot: Dict[str, Any]) -> None:
        """
        Bind current CEL lattice snapshot for use in hashing
        
        Per PHE contract: PHE.map_entropy(CEL) → binds current lattice snapshot
        
        Args:
            cel_snapshot: Snapshot from CEL.snapshot()
        """
        self.cel_snapshot = cel_snapshot
        
    def digest(self, data: Union[bytes, str], context: Optional[Dict[str, Any]] = None) -> bytes:
        """
        Generate probabilistic hash of data
        
        Per PHE contract: PHE.digest(data, context) → probabilistic hash result
        
        Args:
            data: Data to hash (bytes or string)
            context: Optional context dictionary affecting hash path
            
        Returns:
            Hash digest as bytes
        """
        # Convert string to bytes if needed
        if isinstance(data, str):
            data = data.encode('utf-8')
        
        if not data:
            data = b'\x00'  # Handle empty data
        
        # Increment operation counter
        self.operation_count += 1
        
        # Determine hash path based on CEL state and context
        path_selector = self._select_hash_path(data, context)
        
        # Execute multi-path hashing
        hash_result = self._execute_hash_path(data, path_selector, context)
        
        # Store path in history
        self.path_history.append(path_selector)
        if len(self.path_history) > 100:
            self.path_history.pop(0)
        
        return hash_result
    
    def _select_hash_path(self, data: bytes, context: Optional[Dict[str, Any]]) -> int:
        """
        Select hash path based on CEL state, data, and context
        
        Args:
            data: Input data
            context: Optional context
            
        Returns:
            Path selector integer
        """
        # Base path from data fingerprint
        path = data_fingerprint_entropy(data)
        
        # Modify based on CEL state if available
        if self.cel_snapshot:
            cel_hash = self.cel_snapshot.get('seed_fingerprint', 0)
            operation_count = self.cel_snapshot.get('operation_count', 0)
            state_version = self.cel_snapshot.get('state_version', 0)
            
            path = (path + cel_hash + operation_count * 7919 + state_version) % (2**32)
        
        # Modify based on context if provided
        if context:
            context_str = str(context)
            context_entropy = data_fingerprint_entropy(context_str.encode('utf-8'))
            path = (path + context_entropy) % (2**32)
        
        # Add operation count
        path = (path + self.operation_count * 7919) % (2**32)
        
        return path
    
    def _execute_hash_path(self, data: bytes, path_selector: int, context: Optional[Dict[str, Any]]) -> bytes:
        """
        Execute hash computation along selected path
        
        Args:
            data: Input data
            path_selector: Path selection value
            context: Optional context
            
        Returns:
            Hash bytes
        """
        # Determine path strategy (multiple parallel transformations)
        num_paths = (path_selector % 5) + 3  # 3-7 parallel paths
        
        # Execute parallel hash paths
        path_results = []
        for path_idx in range(num_paths):
            result = self._compute_single_path(data, path_selector, path_idx, context)
            path_results.append(result)
        
        # Combine path results
        combined = self._combine_paths(path_results, path_selector)
        
        return combined
    
    def _compute_single_path(
        self, 
        data: bytes, 
        path_selector: int, 
        path_idx: int,
        context: Optional[Dict[str, Any]]
    ) -> List[int]:
        """
        Compute single hash path transformation
        
        Args:
            data: Input data
            path_selector: Path selection value
            path_idx: Index of this path
            context: Optional context
            
        Returns:
            List of transformed integers
        """
        # Convert data to integer sequence
        int_sequence = list(data)
        
        # Determine transformation strategy for this path
        strategy = (path_selector + path_idx) % 4
        
        if strategy == 0:
            return self._path_modular_cascade(int_sequence, path_selector, path_idx)
        elif strategy == 1:
            return self._path_rotation_mixing(int_sequence, path_selector, path_idx)
        elif strategy == 2:
            return self._path_base_conversion(int_sequence, path_selector, path_idx)
        else:
            return self._path_permutation_folding(int_sequence, path_selector, path_idx)
    
    def _path_modular_cascade(self, sequence: List[int], path_selector: int, path_idx: int) -> List[int]:
        """
        Path strategy: Modular cascading transformations
        
        Args:
            sequence: Input integer sequence
            path_selector: Path selection value
            path_idx: Path index
            
        Returns:
            Transformed sequence
        """
        result = sequence.copy()
        
        # Cascade through varying moduli
        base_modulus = 257  # Prime
        
        for i in range(len(result)):
            modulus = base_modulus + (path_selector % 100) + path_idx
            offset = (path_selector + i * 7919) % modulus
            
            result[i] = modular_transform(result[i], modulus, offset)
        
        # Second cascade with different parameters
        for i in range(len(result)):
            prev_val = result[(i - 1) % len(result)]
            result[i] = (result[i] + prev_val * path_idx) % 65536
        
        return result
    
    def _path_rotation_mixing(self, sequence: List[int], path_selector: int, path_idx: int) -> List[int]:
        """
        Path strategy: Bit rotation and mixing
        
        Args:
            sequence: Input integer sequence
            path_selector: Path selection value
            path_idx: Path index
            
        Returns:
            Transformed sequence
        """
        result = sequence.copy()
        
        for i in range(len(result)):
            # Rotate bits
            shift = (path_selector + i + path_idx * 13) % 32
            result[i] = rotate_bits(result[i], shift, 32)
            
            # Mix with neighbors
            if i > 0:
                result[i] = (result[i] + result[i-1]) % 65536
        
        return result
    
    def _path_base_conversion(self, sequence: List[int], path_selector: int, path_idx: int) -> List[int]:
        """
        Path strategy: Variable base conversion
        
        Args:
            sequence: Input integer sequence
            path_selector: Path selection value
            path_idx: Path index
            
        Returns:
            Transformed sequence
        """
        # Select variable base
        base = (path_selector % 20) + 10  # Base 10-29
        
        # Convert each value to variable base and back
        result = []
        for val in sequence:
            # Encode in variable base
            encoded = variable_base_encode(val, base)
            
            # Permute digits
            encoded = permute_sequence(encoded, path_selector + path_idx, rounds=2)
            
            # Decode in different base
            new_base = (base + path_idx * 3) % 20 + 10
            decoded = variable_base_decode(encoded, new_base) % 65536
            
            result.append(decoded)
        
        return result
    
    def _path_permutation_folding(self, sequence: List[int], path_selector: int, path_idx: int) -> List[int]:
        """
        Path strategy: Permutation with folding
        
        Args:
            sequence: Input integer sequence
            path_selector: Path selection value
            path_idx: Path index
            
        Returns:
            Transformed sequence
        """
        result = sequence.copy()
        
        # Multiple permutation rounds
        rounds = (path_selector % 5) + 1
        result = permute_sequence(result, path_selector + path_idx, rounds=rounds)
        
        # Folding: combine first and second half
        mid = len(result) // 2
        folded = []
        
        for i in range(mid):
            combined = (result[i] + result[mid + i]) % 65536
            folded.append(combined)
        
        # Handle odd length
        if len(result) % 2 == 1:
            folded.append(result[-1])
        
        return folded
    
    def _combine_paths(self, path_results: List[List[int]], path_selector: int) -> bytes:
        """
        Combine multiple path results into final hash
        
        Args:
            path_results: Results from parallel paths
            path_selector: Path selection value
            
        Returns:
            Combined hash as bytes
        """
        # Determine output length (fixed at 32 bytes for consistency)
        output_length = 32
        
        # Combine paths by interleaving and mixing
        combined = []
        
        # Flatten all paths
        all_values = []
        for path_result in path_results:
            all_values.extend(path_result)
        
        # Compress to output length using modular arithmetic
        for i in range(output_length):
            # Select values deterministically
            value = 0
            for j in range(len(all_values)):
                idx = (i + j * 7919) % len(all_values)
                weight = (path_selector + i + j) % 256
                value += all_values[idx] * weight
            
            combined.append(value % 256)
        
        return bytes(combined)
    
    def trace(self) -> Dict[str, Any]:
        """
        Output minimal verification signature
        
        Per PHE contract: PHE.trace() → output minimal verification signature
        
        Returns:
            Dictionary with trace information
        """
        return {
            'operation_count': self.operation_count,
            'path_history_length': len(self.path_history),
            'last_path': self.path_history[-1] if self.path_history else None,
            'cel_bound': self.cel_snapshot is not None,
        }
    
    def verify(self, data: Union[bytes, str], expected_hash: bytes, context: Optional[Dict[str, Any]] = None) -> bool:
        """
        Verify data against expected hash
        
        Args:
            data: Data to verify
            expected_hash: Expected hash value
            context: Optional context (must match original context)
            
        Returns:
            True if hash matches
        """
        computed_hash = self.digest(data, context)
        return computed_hash == expected_hash


def create_phe(cel_snapshot: Optional[Dict[str, Any]] = None) -> ProbabilisticHashingEngine:
    """
    Create and optionally initialize PHE instance
    
    Args:
        cel_snapshot: Optional CEL snapshot to bind
        
    Returns:
        PHE instance
    """
    phe = ProbabilisticHashingEngine()
    if cel_snapshot:
        phe.map_entropy(cel_snapshot)
    return phe
