"""
Continuous Entropy Lattice (CEL)
Foundation of STC entropy generation and evolution

The CEL is a self-evolving matrix of numerical states that regenerates
at each interaction using internal computational deltas, not external randomness.

Key properties:
- Deterministic regeneration from seed
- Context-sensitive evolution
- Snapshot/restore capability
- No reliance on environmental entropy sources
"""

import numpy as np
from typing import Dict, Any, Optional, List, Union
import time
import sys

from utils.math_primitives import (
    non_linear_diffusion,
    permute_sequence,
    modular_transform,
    compute_time_delta_entropy,
    memory_allocation_entropy,
    data_fingerprint_entropy,
    rotate_bits,
    modular_exponentiation
)


class ContinuousEntropyLattice:
    """
    CEL - The continuous entropy field for STC
    
    Generates and maintains an evolving lattice of entropy values
    derived exclusively from computational deltas, memory patterns,
    and temporal micro-variations.
    """
    
    def __init__(self, lattice_size: int = 256, depth: int = 8):
        """
        Initialize CEL structure
        
        Args:
            lattice_size: Dimension of entropy lattice (lattice_size x lattice_size)
            depth: Number of layered entropy matrices
        """
        self.lattice_size = lattice_size
        self.depth = depth
        
        # Multi-layered entropy lattice
        self.lattice: Optional[np.ndarray] = None
        
        # Operation counter for evolution tracking
        self.operation_count = 0
        
        # Seed fingerprint for reproducibility
        self.seed_fingerprint: Optional[int] = None
        
        # Historical entropy accumulator (for context continuity)
        self.entropy_history: List[int] = []
        
        # Internal state version (increments on each update)
        self.state_version = 0
        
    def init(self, seed: Union[str, bytes, int]) -> None:
        """
        Initialize entropy lattice from seed
        
        Per CEL contract: CEL.init(seed) → initialize from compact seed vector
        
        Args:
            seed: Seed value (string, bytes, or integer)
        """
        # Convert seed to deterministic numeric value
        if isinstance(seed, str):
            seed_bytes = seed.encode('utf-8')
        elif isinstance(seed, int):
            seed_bytes = seed.to_bytes((seed.bit_length() + 7) // 8, 'big')
        else:
            seed_bytes = seed
        
        # Generate seed fingerprint
        self.seed_fingerprint = data_fingerprint_entropy(seed_bytes)
        
        # Initialize lattice using seed-derived values
        self._initialize_lattice_from_seed(seed_bytes)
        
        # Reset state
        self.operation_count = 0
        self.entropy_history = [self.seed_fingerprint]
        self.state_version = 1
        
    def _initialize_lattice_from_seed(self, seed_bytes: bytes) -> None:
        """
        Create initial lattice state from seed bytes
        
        Args:
            seed_bytes: Seed as bytes
        """
        # Create deterministic but complex initialization
        # Use seed bytes to generate initial lattice values
        
        # Expand seed to fill lattice using deterministic process
        seed_value = int.from_bytes(seed_bytes, 'big') if seed_bytes else 1
        
        # Initialize each layer of the lattice
        self.lattice = np.zeros((self.depth, self.lattice_size, self.lattice_size), dtype=np.int64)
        
        # Use a prime modulus to avoid zeros from modular exponentiation
        prime_mod = 65521  # Large prime
        
        for layer in range(self.depth):
            for i in range(self.lattice_size):
                for j in range(self.lattice_size):
                    # Deterministic value generation from seed, position, and layer
                    # Uses modular exponentiation with prime modulus to avoid zeros
                    pos_factor = (i * self.lattice_size + j + 1)
                    layer_factor = (layer + 1) * 7919  # Prime multiplier
                    
                    # Compute base using seed and position
                    base = ((seed_value % prime_mod) + pos_factor) % prime_mod
                    if base == 0:
                        base = 1
                    
                    # Compute exponent
                    exp = (pos_factor + layer_factor) % (prime_mod - 1)  # Use Fermat's little theorem
                    if exp == 0:
                        exp = 1
                    
                    value = modular_exponentiation(base, exp, prime_mod)
                    
                    # Ensure non-zero value
                    if value == 0:
                        value = (pos_factor * layer_factor) % prime_mod + 1
                    
                    self.lattice[layer, i, j] = value
        
        # Apply initial diffusion to create complex patterns
        for layer in range(self.depth):
            self.lattice[layer] = non_linear_diffusion(
                self.lattice[layer],
                iterations=3
            )
    
    def update(self, context: Optional[Dict[str, Any]] = None) -> None:
        """
        Regenerate entropy field based on operation context
        
        Per CEL contract: CEL.update(context) → regenerate entropy field
        
        Args:
            context: Optional context dictionary with keys:
                     - 'data': bytes to incorporate
                     - 'operation': operation type string
                     - 'parameters': additional parameters
        """
        if self.lattice is None:
            raise RuntimeError("CEL not initialized. Call init() first.")
        
        # Increment operation counter
        self.operation_count += 1
        
        # Gather entropy from multiple sources
        entropy_sources = self._gather_entropy_sources(context)
        
        # Evolve lattice based on entropy sources
        self._evolve_lattice(entropy_sources)
        
        # Update state version
        self.state_version += 1
        
        # Store in history (keep last 100 for context)
        combined_entropy = sum(entropy_sources.values()) % (2**64)
        self.entropy_history.append(combined_entropy)
        if len(self.entropy_history) > 100:
            self.entropy_history.pop(0)
    
    def _gather_entropy_sources(self, context: Optional[Dict[str, Any]]) -> Dict[str, int]:
        """
        Gather entropy from various computational sources
        
        Args:
            context: Optional context dictionary
            
        Returns:
            Dictionary of entropy source values
        """
        sources = {}
        
        # Time-based entropy (computational timing deltas)
        sources['time_delta'] = compute_time_delta_entropy()
        
        # Memory-based entropy (allocation patterns)
        sources['memory'] = memory_allocation_entropy()
        
        # Operation count entropy
        sources['operation'] = self.operation_count * 7919 % (2**32)
        
        # Historical entropy (from previous states)
        if self.entropy_history:
            sources['history'] = sum(self.entropy_history[-10:]) % (2**32)
        
        # Context-specific entropy
        if context:
            if 'data' in context:
                sources['data'] = data_fingerprint_entropy(context['data'])
            
            if 'operation' in context:
                op_bytes = context['operation'].encode('utf-8')
                sources['operation_type'] = data_fingerprint_entropy(op_bytes)
            
            if 'parameters' in context:
                param_str = str(context['parameters'])
                sources['parameters'] = data_fingerprint_entropy(param_str.encode('utf-8'))
        
        return sources
    
    def _evolve_lattice(self, entropy_sources: Dict[str, int]) -> None:
        """
        Evolve lattice state using entropy sources
        
        Args:
            entropy_sources: Dictionary of entropy values
        """
        # Combine entropy sources
        combined_entropy = sum(entropy_sources.values())
        
        # Determine evolution strategy based on combined entropy
        strategy = combined_entropy % 3  # Three evolution strategies
        
        if strategy == 0:
            # Strategy 0: Rotation and permutation
            self._evolve_rotation(combined_entropy)
        elif strategy == 1:
            # Strategy 1: Non-linear diffusion
            self._evolve_diffusion(combined_entropy)
        else:
            # Strategy 2: Layer mixing
            self._evolve_mixing(combined_entropy)
        
        # Apply cross-layer interaction
        self._cross_layer_interaction(combined_entropy)
    
    def _evolve_rotation(self, entropy: int) -> None:
        """
        Evolution strategy: Rotate lattice values
        
        Args:
            entropy: Combined entropy value
        """
        for layer in range(self.depth):
            shift = (entropy + layer * 7919) % 64
            
            # Rotate all values in this layer
            flat = self.lattice[layer].flatten()
            for i in range(len(flat)):
                # Constrain value to 32 bits to prevent overflow
                val = int(flat[i]) % (2**32)
                rotated = rotate_bits(val, shift, 32)  # Use 32-bit rotation
                flat[i] = rotated % (2**16)  # Keep in 16-bit range
            
            self.lattice[layer] = flat.reshape(self.lattice_size, self.lattice_size)
    
    def _evolve_diffusion(self, entropy: int) -> None:
        """
        Evolution strategy: Apply non-linear diffusion
        
        Args:
            entropy: Combined entropy value
        """
        iterations = (entropy % 5) + 1  # 1-5 iterations
        
        for layer in range(self.depth):
            self.lattice[layer] = non_linear_diffusion(
                self.lattice[layer],
                iterations=iterations
            )
    
    def _evolve_mixing(self, entropy: int) -> None:
        """
        Evolution strategy: Mix layers
        
        Args:
            entropy: Combined entropy value
        """
        # Permute layer order
        layer_indices = list(range(self.depth))
        layer_indices = permute_sequence(layer_indices, entropy, rounds=2)
        
        # Apply permutation
        new_lattice = np.zeros_like(self.lattice)
        for new_idx, old_idx in enumerate(layer_indices):
            new_lattice[new_idx] = self.lattice[old_idx]
        
        self.lattice = new_lattice
    
    def _cross_layer_interaction(self, entropy: int) -> None:
        """
        Apply interactions between lattice layers
        
        Args:
            entropy: Combined entropy value
        """
        for layer in range(self.depth - 1):
            # Mix adjacent layers using modular arithmetic
            interaction_factor = max(1, (entropy + layer * 7919) % 256)  # Ensure non-zero
            
            self.lattice[layer] = (
                self.lattice[layer] + 
                (self.lattice[layer + 1] % interaction_factor) // 2
            ) % (2**16)
    
    def snapshot(self) -> Dict[str, Any]:
        """
        Export current entropy lattice state for reproducibility
        
        Per CEL contract: CEL.snapshot() → export current entropy lattice state
        
        Returns:
            Dictionary containing complete state information
        """
        if self.lattice is None:
            raise RuntimeError("CEL not initialized. Call init() first.")
        
        return {
            'lattice': self.lattice.copy(),
            'lattice_size': self.lattice_size,
            'depth': self.depth,
            'operation_count': self.operation_count,
            'seed_fingerprint': self.seed_fingerprint,
            'state_version': self.state_version,
            'entropy_history': self.entropy_history.copy(),
        }
    
    def restore_snapshot(self, snapshot: Dict[str, Any]) -> None:
        """
        Restore CEL state from snapshot
        
        Args:
            snapshot: State dictionary from snapshot()
        """
        self.lattice = snapshot['lattice'].copy()
        self.lattice_size = snapshot['lattice_size']
        self.depth = snapshot['depth']
        self.operation_count = snapshot['operation_count']
        self.seed_fingerprint = snapshot['seed_fingerprint']
        self.state_version = snapshot['state_version']
        self.entropy_history = snapshot['entropy_history'].copy()
    
    def extract_entropy(self, length: int, context: Optional[str] = None) -> np.ndarray:
        """
        Extract entropy vector from current lattice state
        
        Args:
            length: Length of entropy vector to extract
            context: Optional context string for extraction variation
            
        Returns:
            Entropy vector as numpy array
        """
        if self.lattice is None:
            raise RuntimeError("CEL not initialized. Call init() first.")
        
        # Flatten lattice
        flat_lattice = self.lattice.flatten()
        
        # Add context variation if provided
        offset = 0
        if context:
            offset = data_fingerprint_entropy(context.encode('utf-8'))
        
        # Extract entropy values using deterministic indexing
        entropy_vector = np.zeros(length, dtype=np.int64)
        
        for i in range(length):
            # Deterministic index selection
            idx = (i * 7919 + offset + self.operation_count) % len(flat_lattice)
            entropy_vector[i] = flat_lattice[idx]
        
        return entropy_vector
    
    def get_state_hash(self) -> int:
        """
        Compute compact hash of current CEL state
        
        Returns:
            Integer hash of current state
        """
        if self.lattice is None:
            return 0
        
        # Create deterministic hash from lattice state
        # Use clip and modulo to prevent overflow
        clipped_sum = int(np.clip(np.sum(self.lattice, dtype=np.float64), 0, 2**63 - 1))
        state_sum = clipped_sum % (2**32)
        state_product = (self.operation_count * self.state_version) % (2**32)
        
        return (state_sum + state_product) % (2**32)


# Module-level singleton for convenient access
_global_cel: Optional[ContinuousEntropyLattice] = None


def get_global_cel() -> ContinuousEntropyLattice:
    """
    Get or create global CEL instance
    
    Returns:
        Global CEL instance
    """
    global _global_cel
    if _global_cel is None:
        _global_cel = ContinuousEntropyLattice()
    return _global_cel


def initialize_cel(seed: Union[str, bytes, int], lattice_size: int = 256, depth: int = 8) -> ContinuousEntropyLattice:
    """
    Initialize and return a new CEL instance
    
    Args:
        seed: Seed value for initialization
        lattice_size: Lattice dimension
        depth: Number of lattice layers
        
    Returns:
        Initialized CEL instance
    """
    cel = ContinuousEntropyLattice(lattice_size=lattice_size, depth=depth)
    cel.init(seed)
    return cel
