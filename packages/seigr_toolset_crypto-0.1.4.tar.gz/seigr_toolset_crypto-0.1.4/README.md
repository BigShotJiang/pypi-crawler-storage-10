# Seigr Toolset Crypto (STC)

[![Sponsor Seigr-lab](https://img.shields.io/badge/Sponsor-Seigr--lab-forestgreen?style=flat&logo=github)](https://github.com/sponsors/Seigr-lab)


**Post-classical cryptographic engine with entropy-regenerative architecture**

## Overview

STC rejects traditional symmetric/asymmetric paradigms, avoiding XOR-based mixing, static keys, and classical block ciphers. Instead, it implements:

- **Continuous Entropy Lattice (CEL)** - Self-evolving entropy field regenerated from computational deltas
- **Probabilistic Hashing Engine (PHE)** - Multi-path hashing with CEL-driven path selection
- **Contextual Key Emergence (CKE)** - Ephemeral keys reconstructed from context intersections
- **Data-State Folding (DSF)** - Encryption via multidimensional tensor folding
- **Polymorphic Cryptographic Flow (PCF)** - Dynamic algorithmic morphing
- **State Management** - Deterministic reconstruction from compact persistence vectors

## Architecture

```
core/
├── cel/    # Continuous Entropy Lattice
├── phe/    # Probabilistic Hashing Engine
├── cke/    # Contextual Key Emergence
├── dsf/    # Data-State Folding
├── pcf/    # Polymorphic Cryptographic Flow
└── state/  # State persistence and reconstruction

interfaces/
├── api/    # Programmatic interface
├── cli/    # Command-line tools
└── bindings/  # Future cross-language bindings

utils/      # Mathematical primitives
tests/      # Validation and integrity checks
```

## Installation

### From GitHub Release (Recommended)

Download the latest release from [Releases](https://github.com/Seigr-lab/SeigrToolsetCrypto/releases):

```bash
# Install from wheel (recommended)
pip install seigr_toolset_crypto-0.1.0-py3-none-any.whl

# Or install from source tarball
pip install seigr_toolset_crypto-0.1.0.tar.gz
```

### From Source (Development)

```bash
git clone https://github.com/Seigr-lab/SeigrToolsetCrypto.git
cd SeigrToolsetCrypto
pip install -e .
```

## Usage

### Basic API

```python
from interfaces.api import stc_api

# Initialize STC context
context = stc_api.initialize(seed="your-seed-phrase")

# Encrypt data
encrypted, metadata = context.encrypt("sensitive information")

# Decrypt data
decrypted = context.decrypt(encrypted, metadata)

# Generate probabilistic hash
hash_result = context.hash("data to hash")
```

### Quick API (One-liners)

```python
from interfaces.api import stc_api

# Quick encrypt - returns encrypted data, metadata, and context
encrypted, metadata, context = stc_api.quick_encrypt("sensitive data", seed="your-seed")

# Quick decrypt - reconstructs context from metadata
decrypted = stc_api.quick_decrypt(encrypted, metadata, seed="your-seed")
```

### Alternative: Using convenience functions

```python
from interfaces.api import stc_api

context = stc_api.initialize(seed="your-seed-phrase")

# Encrypt using stc_api function
encrypted, metadata = stc_api.encrypt(data="sensitive information", context=context)

# Decrypt using stc_api function
decrypted = stc_api.decrypt(encrypted_data=encrypted, metadata=metadata, context=context)

# Hash using stc_api function
hash_result = stc_api.hash_data(data="data to hash", context=context)
```

## Principles

1. **No legacy cryptography** - No XOR, no substitution-permutation networks, no block ciphers
2. **No external randomness** - All entropy from internal computation (timing deltas, state evolution)
3. **Deterministic from seed** - Same seed produces same initial state; state evolves with CEL dynamics
4. **Context-sensitive polymorphism** - Behavior adapts to operation chains
5. **Ephemeral keys** - Keys emerge and discard, never persist
6. **Self-sovereign security** - No cloud dependencies, no external services, full user control

## Examples

See `examples/` directory for practical demonstrations:

- **`password_manager/`** - Secure credential storage with self-sovereign encryption
- **`config_encryption/`** - Configuration file encryption with metadata persistence

Run examples:

```bash
cd examples/password_manager
python password_manager.py

cd examples/config_encryption
python config_example.py
```


## Development Status

**Alpha** - Research-grade cryptographic engine under active development

## License

ANTI-CAPITALIST SOFTWARE LICENSE (v 1.4) - See LICENSE file for details
