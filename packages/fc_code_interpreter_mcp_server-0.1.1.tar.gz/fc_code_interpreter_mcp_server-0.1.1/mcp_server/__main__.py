"""Entry point for running mcp_server as a module."""

from .main import main

if __name__ == "__main__":
    main()
