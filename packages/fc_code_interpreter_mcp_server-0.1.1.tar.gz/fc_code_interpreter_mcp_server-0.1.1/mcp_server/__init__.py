"""FC Code Interpreter MCP Server package."""

from . import main

__all__ = ['main']
