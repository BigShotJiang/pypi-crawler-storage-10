import glob
import inspect
import os
import re
import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from functools import lru_cache
from pathlib import Path
from typing import Any

from litequery.config import Config, get_config


class Op(str, Enum):
    SELECT = ""
    SELECT_ONE = "^"
    SELECT_VALUE = "$"
    MODIFY = "!"
    INSERT_RETURNING = "<!"


@dataclass
class Query:
    name: str
    sql: str
    args: list
    op: Op = Op.SELECT


@lru_cache(maxsize=128)
def _get_fields(cls):
    sig = inspect.signature(cls)
    return {p.name for p in sig.parameters.values() if p.name != "self"}


class Row:
    __slots__ = ("_values", "_index")

    def __init__(self, columns: list[str], values: list[Any]):
        if len(set(columns)) != len(columns):
            dups = [c for c in columns if columns.count(c) > 1]
            raise ValueError(f"Duplicate columns: {set(dups)}. Use AS to alias.")

        self._values = values
        self._index = {c: i for i, c in enumerate(columns)}

    def _available_columns(self) -> str:
        return ", ".join([f"'{c}'" for c in self._index.keys()])

    def __repr__(self) -> str:
        items = [f"{col}={self._values[idx]!r}" for col, idx in self._index.items()]
        return f"{self.__class__.__name__}({', '.join(items)})"

    def __getitem__(self, key: int | str) -> Any:
        if isinstance(key, int):
            try:
                return self._values[key]
            except IndexError:
                raise IndexError(
                    f"Row only has {len(self._values)} columns, "
                    f"can't access index {key}"
                )
        try:
            return self._values[self._index[key]]
        except KeyError:
            raise KeyError(
                f"No column '{key}' found. Available: {self._available_columns()}"
            )

    def __getattr__(self, name: str) -> Any:
        error = AttributeError(
            f"No column '{name}' found. Available: {self._available_columns()}"
        )
        if name.startswith("_"):
            raise error

        try:
            return self._values[self._index[name]]
        except KeyError:
            raise error

    def __len__(self) -> int:
        return len(self._values)

    def __iter__(self) -> Iterator[Any]:
        return iter(self._values)

    def __eq__(self, other) -> bool:
        if not isinstance(other, Row):
            return False
        return self._values == other._values

    def to_dict(self) -> dict:
        return dict(zip(self._index.keys(), self._values))

    def into(self, cls):
        fields = _get_fields(cls)
        return cls(**{k: v for k, v in self.to_dict().items() if k in fields})


class Rows(list):
    def into(self, cls):
        return Rows([row.into(cls) for row in self])


def parse_file_queries(file_path):
    with open(file_path) as f:
        content = f.read()
    raw_queries = re.findall(r"-- name: (.+)\n([\s\S]*?);", content)

    queries = []
    op_pattern = "|".join("\\" + "\\".join(list(op.value)) for op in Op if op.value)
    pattern = rf"^([a-z_][a-z0-9_]*)({op_pattern})?$"
    for query_name, sql in raw_queries:
        match = re.match(pattern, query_name)
        if not match:
            raise NameError(f'Invalid query name: "{query_name}"')
        query_name = match.group(1)
        op_symbol = match.group(2) or ""
        op = Op(op_symbol)

        args = re.findall(r":(\w+)", sql)
        query = Query(name=query_name, sql=sql, args=args, op=op)
        queries.append(query)
    return queries


def parse_queries(path: Path) -> list[Query]:
    queries = []
    if os.path.isdir(path):
        for file_path in glob.glob(os.path.join(path, "*.sql")):
            queries.extend(parse_file_queries(file_path))
    elif os.path.isfile(path):
        queries.extend(parse_file_queries(path))
    else:
        raise ValueError(f"Path {path} is neither a file nor a directory.")
    return queries


def setup(db_path: str | None = None, queries_path: str | None = None):
    config = get_config(db_path, queries_path) if db_path else get_config()
    queries = parse_queries(config.queries_path)
    return Litequery(config, queries)


def row_factory(cursor, row):
    columns = [desc[0] for desc in cursor.description]
    return Row(columns, row)


def adapt_datetime(value: datetime):
    if value.tzinfo:
        value = value.astimezone(UTC)
    return value.replace(tzinfo=None).isoformat(sep=" ")


def convert_datetime(value: bytes):
    return datetime.fromisoformat(value.decode())


class Litequery:
    PRAGMAS = [
        ("journal_mode", "wal"),
        ("foreign_keys", 1),
        ("synchronous", "normal"),
        ("mmap_size", 134217728),  # 128 Mb
        ("journal_size_limit", 67108864),  # 64 Mb
        ("cache_size", 2000),
    ]

    def __init__(self, config: Config, queries):
        self.config = config
        self._thread_local = threading.local()
        self._create_methods(queries)

        sqlite3.register_adapter(datetime, adapt_datetime)
        sqlite3.register_converter("datetime", convert_datetime)

    def _create_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self.config.database_path,
            timeout=30,
            autocommit=True,
            detect_types=sqlite3.PARSE_COLNAMES | sqlite3.PARSE_DECLTYPES,
        )
        conn.row_factory = row_factory
        pragmas = (f"PRAGMA {p} = {v}" for p, v in self.PRAGMAS)
        conn.executescript(";".join(pragmas))
        return conn

    def _get_connection(self) -> sqlite3.Connection:
        if not hasattr(self._thread_local, "conn"):
            self._thread_local.conn = self._create_connection()
        return self._thread_local.conn

    def _create_methods(self, queries: list[Query]):
        for query in queries:
            if hasattr(self, query.name):
                if hasattr(Litequery, query.name):
                    raise NameError(f"Query name {query.name} isn't allowed.")

                if callable(getattr(self, query.name)):
                    raise NameError(
                        f"Duplicate query name '{query.name}'. "
                        "Each query must have a unique name."
                    )
            setattr(self, query.name, self._create_method(query))

    def _execute_query(
        self,
        sql: str,
        op: Op,
        parameters: dict | None = None,
    ):
        if not parameters:
            parameters = {}

        conn = self._get_connection()
        cursor = conn.execute(sql, parameters)

        if op == Op.SELECT:
            return Rows(cursor.fetchall())
        if op == Op.SELECT_ONE:
            return cursor.fetchone()
        if op == Op.SELECT_VALUE:
            row = cursor.fetchone()
            return row[0] if row else None
        if op == Op.MODIFY:
            return cursor.rowcount
        if op == Op.INSERT_RETURNING:
            return cursor.lastrowid

    def _create_method(self, query: Query):
        def query_method(**parameters):
            return self._execute_query(query.sql, query.op, parameters)

        return query_method

    def raw(self, sql: str, **parameters):
        return self._execute_query(sql, Op.SELECT, parameters)

    def raw_one(self, sql: str, **parameters):
        return self._execute_query(sql, Op.SELECT_ONE, parameters)

    def raw_value(self, sql: str, **parameters):
        return self._execute_query(sql, Op.SELECT_VALUE, parameters)

    @contextmanager
    def transaction(self):
        conn = self._get_connection()
        if conn.in_transaction:
            raise RuntimeError("Nested transactions are not supported")

        conn.autocommit = sqlite3.LEGACY_TRANSACTION_CONTROL
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.autocommit = True

    def close(self) -> None:
        if hasattr(self._thread_local, "conn"):
            self._thread_local.conn.close()
            del self._thread_local.conn
