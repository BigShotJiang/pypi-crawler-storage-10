class NotionaryException(Exception):
    pass
