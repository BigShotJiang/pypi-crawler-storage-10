from .builder import NotionWorkspaceQueryConfigBuilder
from .models import WorkspaceQueryConfig

__all__ = ["NotionWorkspaceQueryConfigBuilder", "WorkspaceQueryConfig"]
