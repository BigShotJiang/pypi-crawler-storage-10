from enum import Enum


class TaskType(Enum):
    CALLABLE = 'CALLABLE'
    SHELL = 'SHELL'