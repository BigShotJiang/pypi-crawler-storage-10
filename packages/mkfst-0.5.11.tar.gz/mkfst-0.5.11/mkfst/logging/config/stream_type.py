from enum import Enum


class StreamType(Enum):
    STDOUT="STDOUT"
    STDERR="STDERR"