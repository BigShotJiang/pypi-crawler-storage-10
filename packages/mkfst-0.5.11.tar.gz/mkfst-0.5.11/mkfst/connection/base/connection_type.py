from enum import Enum


class ConnectionType(Enum):
    UDP='udp'
    TCP='tcp'
    HTTP='http'