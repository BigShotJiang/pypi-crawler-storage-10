# MyRegression

A simple Python package to perform Linear Regression from scratch.

## 📦 Installation

### ✅ Offline:

pip install dist/myregression-0.1.0-py3-none-any.whl


### ✅ Online (after uploading to PyPI):

pip install myregression


## 💡 Usage

```python
from myregression import LinearRegression

model = LinearRegression()
x = [1,2,3,4]
y = [2,4,5,4]

model.fit(x, y)
print(model)          # prints equation
print(model.predict([5,6]))


---

## ✅ **6. Build Package (Offline)**

In terminal inside project folder:
```bash
python3 setup.py sdist bdist_wheel