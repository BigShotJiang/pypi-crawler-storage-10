from setuptools import setup, find_packages

setup(
    name="safouregression",
    version="0.1.0",
    description="A simple linear regression model from scratch",
    author="Safou",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.7",
)