from setuptools import setup, find_packages

setup(
    name='learn_bin',
    version='0.2',
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'learn_bin=learn_bin.main:print_db',
            ],
            },
            author='Shahaan Bharucha')