"""
Command-line interface for the advanced notebook converter.
"""

from __future__ import annotations

import sys
import click
import logging
from pathlib import Path
from typing import Optional, List, Tuple
import asyncio
from datetime import datetime

try:
    from rich.console import Console
    from rich.progress import Progress, TaskID
    from rich.table import Table
    from rich.panel import Panel
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

from .converter import AdvancedNotebookConverter, ConversionOptions
from .utils.batch_processor import BatchProcessor
from .plugins.base import PluginManager


# Initialize rich console if available
if RICH_AVAILABLE:
    console = Console()
else:
    console = None


def setup_logging(verbose: bool = False, debug: bool = False) -> logging.Logger:
    """Set up logging configuration."""
    level = logging.DEBUG if debug else logging.INFO if verbose else logging.WARNING
    
    if RICH_AVAILABLE:
        from rich.logging import RichHandler
        logging.basicConfig(
            level=level,
            format="%(message)s",
            datefmt="[%X]",
            handlers=[RichHandler(rich_tracebacks=True)]
        )
    else:
        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    return logging.getLogger('notebook_converter')


from . import __version__


@click.group()
@click.version_option(version=__version__, prog_name='notebook-to-code')
@click.option('-v', '--verbose', is_flag=True, help='Enable verbose output')
@click.option('--debug', is_flag=True, help='Enable debug output')
@click.pass_context
def cli(ctx, verbose: bool, debug: bool):
    """
    Advanced Jupyter Notebook to Python Script Converter.
    
    Convert notebooks with semantic markdown processing, round-trip support,
    quality analysis, and extensible plugin system.
    """
    ctx.ensure_object(dict)
    ctx.obj['logger'] = setup_logging(verbose, debug)
    ctx.obj['verbose'] = verbose
    ctx.obj['debug'] = debug


@cli.command()
@click.argument('input_path', type=click.Path(exists=True, path_type=Path))
@click.option('-o', '--output', 'output_path', type=click.Path(path_type=Path),
              help='Output file path')
@click.option('--theme', default='default', help='Conversion theme to use')
@click.option('--no-metadata', is_flag=True, help='Do not preserve notebook metadata')
@click.option('--no-round-trip', is_flag=True, help='Disable round-trip metadata')
@click.option('--no-semantic-markdown', is_flag=True, help='Disable semantic markdown processing')
@click.option('--quality-analysis', is_flag=True, help='Enable code quality analysis')
@click.option('--max-line-length', default=88, help='Maximum line length for comments')
@click.option('--custom-header', help='Custom header text for output file')
@click.option('--stats', is_flag=True, help='Show detailed conversion statistics')
@click.pass_context
def convert(ctx, input_path: Path, output_path: Optional[Path], theme: str,
           no_metadata: bool, no_round_trip: bool, no_semantic_markdown: bool,
           quality_analysis: bool, max_line_length: int, custom_header: Optional[str],
           stats: bool):
    """Convert a single notebook or script."""
    logger = ctx.obj['logger']
    
    try:
        # Create conversion options
        options = ConversionOptions(
            preserve_metadata=not no_metadata,
            round_trip_metadata=not no_round_trip,
            semantic_markdown=not no_semantic_markdown,
            quality_analysis=quality_analysis,
            theme=theme,
            max_line_length=max_line_length,
            custom_header=custom_header
        )
        
        # Create converter
        converter = AdvancedNotebookConverter(options=options, logger=logger)
        
        # Perform conversion
        if console:
            with console.status(f"Converting {input_path.name}..."):
                output_file, conversion_stats = converter.convert_notebook(
                    input_path, output_path
                )
        else:
            output_file, conversion_stats = converter.convert_notebook(
                input_path, output_path
            )
        
        # Display results
        success_msg = f"✓ Successfully converted to: {output_file}"
        if console:
            console.print(success_msg, style="green bold")
        else:
            click.echo(success_msg)
        
        # Show statistics if requested
        if stats or ctx.obj['verbose']:
            if console:
                _display_rich_stats(conversion_stats)
            else:
                click.echo(f"\n{conversion_stats}")
        
    except Exception as e:
        error_msg = f"✗ Conversion failed: {e}"
        if console:
            console.print(error_msg, style="red bold")
        else:
            click.echo(error_msg, err=True)
        
        if ctx.obj['debug']:
            import traceback
            if console:
                console.print_exception()
            else:
                traceback.print_exc()
        
        sys.exit(1)


@cli.command()
@click.argument('input_dir', type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option('-o', '--output-dir', type=click.Path(path_type=Path),
              help='Output directory')
@click.option('--pattern', default='*.ipynb', help='File pattern to match')
@click.option('--theme', default='default', help='Conversion theme to use')
@click.option('--no-parallel', is_flag=True, help='Disable parallel processing')
@click.option('--max-workers', type=int, help='Maximum number of worker processes')
@click.option('--quality-analysis', is_flag=True, help='Enable code quality analysis')
@click.option('--stats', is_flag=True, help='Show detailed statistics')
@click.pass_context
def batch(ctx, input_dir: Path, output_dir: Optional[Path], pattern: str,
         theme: str, no_parallel: bool, max_workers: Optional[int],
         quality_analysis: bool, stats: bool):
    """Batch convert multiple notebooks in a directory."""
    logger = ctx.obj['logger']
    
    try:
        # Create conversion options
        options = ConversionOptions(
            theme=theme,
            quality_analysis=quality_analysis
        )
        
        # Create batch processor
        processor = BatchProcessor(
            max_workers=max_workers,
            logger=logger
        )
        
        # Progress callback for rich display
        progress_task = None
        if console:
            progress = Progress()
            progress_task = progress.add_task("Converting...", total=None)
            progress.start()
            
            def progress_callback(completed: int, total: int):
                if progress_task:
                    progress.update(progress_task, completed=completed, total=total)
        else:
            def progress_callback(completed: int, total: int):
                click.echo(f"Progress: {completed}/{total}")
        
        # Process batch
        try:
            if console and progress_task:
                with progress:
                    results = processor.process_directory(
                        input_dir=input_dir,
                        output_dir=output_dir,
                        pattern=pattern,
                        options=options,
                        parallel=not no_parallel
                    )
            else:
                results = processor.process_directory(
                    input_dir=input_dir,
                    output_dir=output_dir,
                    pattern=pattern,
                    options=options,
                    parallel=not no_parallel
                )
        finally:
            if console and progress_task:
                progress.stop()
        
        # Display results
        if console:
            _display_batch_results(results)
        else:
            click.echo(f"\n{results}")
        
        if results.failed:
            sys.exit(1)
            
    except Exception as e:
        error_msg = f"✗ Batch conversion failed: {e}"
        if console:
            console.print(error_msg, style="red bold")
        else:
            click.echo(error_msg, err=True)
        sys.exit(1)


@cli.command()
@click.argument('script_path', type=click.Path(exists=True, path_type=Path))
@click.option('-o', '--output', 'output_path', type=click.Path(path_type=Path),
              help='Output notebook path')
@click.pass_context
def reverse(ctx, script_path: Path, output_path: Optional[Path]):
    """Convert an annotated Python script back to notebook format."""
    logger = ctx.obj['logger']
    
    if script_path.suffix.lower() != '.py':
        click.echo("Error: Input file must be a Python script (.py)", err=True)
        sys.exit(1)
    
    try:
        options = ConversionOptions()
        converter = AdvancedNotebookConverter(options=options, logger=logger)
        
        if console:
            with console.status(f"Converting {script_path.name} back to notebook..."):
                output_file, conversion_stats = converter.convert_notebook(
                    script_path, output_path
                )
        else:
            output_file, conversion_stats = converter.convert_notebook(
                script_path, output_path
            )
        
        success_msg = f"✓ Successfully converted to notebook: {output_file}"
        if console:
            console.print(success_msg, style="green bold")
        else:
            click.echo(success_msg)
            
    except Exception as e:
        error_msg = f"✗ Reverse conversion failed: {e}"
        if console:
            console.print(error_msg, style="red bold")
        else:
            click.echo(error_msg, err=True)
        sys.exit(1)


@cli.command()
@click.argument('original_path', type=click.Path(exists=True, path_type=Path))
@click.argument('converted_path', type=click.Path(exists=True, path_type=Path))
@click.pass_context
def validate(ctx, original_path: Path, converted_path: Path):
    """Validate round-trip conversion integrity."""
    logger = ctx.obj['logger']
    
    try:
        options = ConversionOptions(round_trip_metadata=True)
        converter = AdvancedNotebookConverter(options=options, logger=logger)
        
        if console:
            with console.status("Validating round-trip conversion..."):
                is_valid = converter.validate_round_trip(original_path, converted_path)
        else:
            is_valid = converter.validate_round_trip(original_path, converted_path)
        
        if is_valid:
            success_msg = "✓ Round-trip validation passed"
            if console:
                console.print(success_msg, style="green bold")
            else:
                click.echo(success_msg)
        else:
            error_msg = "✗ Round-trip validation failed"
            if console:
                console.print(error_msg, style="red bold")
            else:
                click.echo(error_msg, err=True)
            sys.exit(1)
            
    except Exception as e:
        error_msg = f"✗ Validation failed: {e}"
        if console:
            console.print(error_msg, style="red bold")
        else:
            click.echo(error_msg, err=True)
        sys.exit(1)


@cli.command()
@click.pass_context
def themes(ctx):
    """List available conversion themes."""
    plugin_manager = PluginManager()
    available_themes = plugin_manager.list_themes()
    
    if console:
        table = Table(title="Available Themes")
        table.add_column("Name", style="cyan")
        table.add_column("Description", style="white")
        
        for theme_name in available_themes:
            theme = plugin_manager.get_theme(theme_name)
            table.add_row(theme.name, theme.description)
        
        console.print(table)
    else:
        click.echo("Available themes:")
        for theme_name in available_themes:
            theme = plugin_manager.get_theme(theme_name)
            click.echo(f"  {theme.name}: {theme.description}")


@cli.command()
@click.argument('input_path', type=click.Path(exists=True, path_type=Path))
@click.pass_context
def analyze(ctx, input_path: Path):
    """Analyze code quality of a converted notebook."""
    logger = ctx.obj['logger']
    
    try:
        from .utils.quality_analyzer import QualityAnalyzer
        
        if input_path.suffix.lower() == '.ipynb':
            # Convert first, then analyze
            options = ConversionOptions(quality_analysis=True)
            converter = AdvancedNotebookConverter(options=options, logger=logger)
            temp_output, stats = converter.convert_notebook(input_path)
            
            # Display quality results from conversion
            if console:
                _display_quality_analysis(stats)
            else:
                click.echo(f"Quality Score: {stats.quality_score}")
                if stats.warnings:
                    click.echo(f"Warnings: {len(stats.warnings)}")
                if stats.errors:
                    click.echo(f"Errors: {len(stats.errors)}")
        
        elif input_path.suffix.lower() == '.py':
            # Analyze Python file directly
            analyzer = QualityAnalyzer()
            with open(input_path, 'r', encoding='utf-8') as f:
                code_content = f.read()
            
            results = analyzer.analyze_code(code_content)
            
            if console:
                _display_quality_results(results)
            else:
                click.echo(f"Quality Score: {results['score']}")
                if results['warnings']:
                    click.echo(f"Warnings: {len(results['warnings'])}")
                if results['errors']:
                    click.echo(f"Errors: {len(results['errors'])}")
        
        else:
            click.echo("Error: File must be .ipynb or .py", err=True)
            sys.exit(1)
            
    except ImportError:
        click.echo("Error: Quality analysis tools not available", err=True)
        sys.exit(1)
    except Exception as e:
        error_msg = f"✗ Analysis failed: {e}"
        if console:
            console.print(error_msg, style="red bold")
        else:
            click.echo(error_msg, err=True)
        sys.exit(1)


def _display_rich_stats(stats):
    """Display conversion statistics using rich formatting."""
    table = Table(title="Conversion Statistics")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")
    
    table.add_row("Total Cells", str(stats.total_cells))
    table.add_row("Code Cells", str(stats.code_cells))
    table.add_row("Markdown Cells", str(stats.markdown_cells))  
    table.add_row("Raw Cells", str(stats.raw_cells))
    table.add_row("Empty Cells", str(stats.empty_cells))
    table.add_row("Processing Time", f"{stats.processing_time:.3f}s")
    table.add_row("Output Size", f"{stats.output_size} bytes")
    
    if stats.quality_score is not None:
        score_style = "green" if stats.quality_score >= 80 else "yellow" if stats.quality_score >= 60 else "red"
        table.add_row("Quality Score", f"{stats.quality_score:.1f}", style=score_style)
    
    table.add_row("Warnings", str(len(stats.warnings)))
    table.add_row("Errors", str(len(stats.errors)))
    
    console.print(table)


def _display_batch_results(results):
    """Display batch processing results using rich formatting."""
    # Summary panel
    summary_text = (
        f"Successful: {len(results.successful)}\n"
        f"Failed: {len(results.failed)}\n" 
        f"Total time: {results.total_time:.2f}s"
    )
    
    panel_style = "green" if not results.failed else "yellow"
    console.print(Panel(summary_text, title="Batch Results", style=panel_style))
    
    # Failed files table
    if results.failed:
        table = Table(title="Failed Conversions")
        table.add_column("File", style="red")
        table.add_column("Error", style="white")
        
        for file_path, error in results.failed:
            table.add_row(str(file_path), str(error))
        
        console.print(table)


def _display_quality_analysis(stats):
    """Display quality analysis from conversion stats."""
    if stats.quality_score is None:
        console.print("No quality analysis available", style="yellow")
        return
    
    score_style = "green" if stats.quality_score >= 80 else "yellow" if stats.quality_score >= 60 else "red"
    
    panel_text = f"Quality Score: {stats.quality_score:.1f}/100"
    console.print(Panel(panel_text, title="Code Quality Analysis", style=score_style))
    
    if stats.warnings:
        console.print(f"\n[yellow]Warnings ({len(stats.warnings)}):[/yellow]")
        for warning in stats.warnings[:5]:  # Show first 5
            console.print(f"  • {warning}")
        if len(stats.warnings) > 5:
            console.print(f"  ... and {len(stats.warnings) - 5} more")
    
    if stats.errors:
        console.print(f"\n[red]Errors ({len(stats.errors)}):[/red]")
        for error in stats.errors[:5]:  # Show first 5  
            console.print(f"  • {error}")
        if len(stats.errors) > 5:
            console.print(f"  ... and {len(stats.errors) - 5} more")


def _display_quality_results(results):
    """Display detailed quality analysis results."""
    score_style = "green" if results['score'] >= 80 else "yellow" if results['score'] >= 60 else "red"
    
    panel_text = f"Quality Score: {results['score']:.1f}/100"
    console.print(Panel(panel_text, title="Code Quality Analysis", style=score_style))
    
    # Metrics table
    if results['metrics']:
        table = Table(title="Code Metrics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="white")
        
        for key, value in results['metrics'].items():
            table.add_row(key.replace('_', ' ').title(), str(value))
        
        console.print(table)
    
    # Issues
    if results['warnings']:
        console.print(f"\n[yellow]Warnings ({len(results['warnings'])}):[/yellow]")
        for warning in results['warnings'][:10]:
            console.print(f"  • {warning}")
    
    if results['errors']:
        console.print(f"\n[red]Errors ({len(results['errors'])}):[/red]")
        for error in results['errors'][:10]:
            console.print(f"  • {error}")
    
    # Suggestions
    if results['suggestions']:
        console.print(f"\n[blue]Suggestions:[/blue]")
        for suggestion in results['suggestions']:
            console.print(f"  • {suggestion}")


def main():
    """Main entry point for the CLI."""
    cli()


if __name__ == '__main__':
    main()
