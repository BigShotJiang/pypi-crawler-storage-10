"""
Advanced Jupyter Notebook Converter

A comprehensive tool for converting between Jupyter notebooks and Python scripts with:
- Semantic markdown processing
- Round-trip conversion support
- Quality analysis
- Plugin system for themes
- Batch processing capabilities
"""

from .converter import (
    AdvancedNotebookConverter,
    ConversionOptions,
    ConversionStats,
    NotebookConverterError,
    InvalidNotebookError,
    ConversionError,
    RoundTripError
)
from .cli import cli
from pathlib import Path

# Version of the package
__version__ = "3.0.4"
__author__ = "Your Name"
__license__ = "MIT"

# Define what gets imported with 'from package import *'
__all__ = [
    'AdvancedNotebookConverter',
    'ConversionOptions',
    'ConversionStats',
    'NotebookConverterError',
    'InvalidNotebookError',
    'ConversionError',
    'RoundTripError',
    'cli',
    'convert_notebook'
]

# Package-level logger
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

def get_version() -> str:
    """Get the current version of the package."""
    return __version__


def convert_notebook(input_path: str | Path,
                     output_path: str | Path | None = None,
                     *,
                     theme: str = "default",
                     preserve_metadata: bool = True,
                     round_trip_metadata: bool = True,
                     semantic_markdown: bool = True,
                     quality_analysis: bool = False,
                     max_line_length: int = 88,
                     custom_header: str | None = None):
    """Simple one-call conversion helper.

    Example:
        from notebook_converter import convert_notebook
        convert_notebook("capcom.ipynb", "out.py")

    Returns a tuple: (output_path: Path, stats: ConversionStats)
    """
    logger = logging.getLogger("notebook_converter.simple")

    options = ConversionOptions(
        preserve_metadata=preserve_metadata,
        round_trip_metadata=round_trip_metadata,
        semantic_markdown=semantic_markdown,
        quality_analysis=quality_analysis,
        theme=theme,
        max_line_length=max_line_length,
        custom_header=custom_header,
    )

    converter = AdvancedNotebookConverter(options=options, logger=logger)
    in_path = Path(input_path)
    out_path = Path(output_path) if output_path is not None else None
    return converter.convert_notebook(in_path, out_path)
