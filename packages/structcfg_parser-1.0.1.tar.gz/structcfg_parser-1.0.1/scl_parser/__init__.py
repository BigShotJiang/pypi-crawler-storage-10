"""
SCL Parser Library

A Python library for parsing and serializing Structured Configuration Language (SCL) files.
"""

from .parser import (
    load,
    loads,
    dump,
    dumps,
    SCLParseError,
    SCLSyntaxError,
)

__version__ = "1.0.0"
__author__ = "shareui"
__all__ = ["load", "loads", "dump", "dumps", "SCLParseError", "SCLSyntaxError"]