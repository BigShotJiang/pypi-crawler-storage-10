from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='kosty',
    version='1.3.2',
    author='Yassir Kachri',
    author_email='yassir@kosty.cloud',
    description='AWS Cost & Security Optimization CLI Tool - Identify and eliminate AWS cost waste and security issues across 16 core services',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/kosty-cloud/kosty',
    project_urls={
        'Bug Reports': 'https://github.com/kosty-cloud/kosty/issues',
        'Source': 'https://github.com/kosty-cloud/kosty',
        'Documentation': 'https://github.com/kosty-cloud/kosty/blob/main/docs/DOCUMENTATION.md',
    },
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'Topic :: System :: Systems Administration',
        'Topic :: Utilities',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
    ],
    keywords='aws cost optimization cloud infrastructure audit security',
    install_requires=[
        'click>=8.0.0',
        'boto3>=1.26.0',
    ],
    entry_points={
        'console_scripts': [
            'kosty=kosty.cli:cli',
        ],
    },
    python_requires='>=3.7',
    include_package_data=True,
    zip_safe=False,
)