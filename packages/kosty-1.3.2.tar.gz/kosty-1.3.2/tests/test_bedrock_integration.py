"""
Tests d'intégration avec moto (simulateur AWS)
"""

import pytest
from moto import mock_sts, mock_logs, mock_sagemaker, mock_cloudwatch
import boto3
from kosty.services.bedrock_audit import BedrockAuditService
from kosty.services.sagemaker_audit import SageMakerAuditService


@mock_sts
@mock_sagemaker
@mock_cloudwatch
class TestSageMakerWithMoto:
    """Tests SageMaker avec simulation AWS complète"""
    
    def test_list_endpoints_empty(self):
        """Test sans endpoints"""
        session = boto3.Session()
        service = SageMakerAuditService()
        
        results = service.cost_audit(session, 'us-east-1', days=7)
        
        # Pas d'endpoints = pas de résultats
        assert len(results) == 0
    
    @mock_sagemaker
    def test_create_and_detect_endpoint(self):
        """Test création et détection d'endpoint"""
        # Créer un endpoint simulé
        client = boto3.client('sagemaker', region_name='us-east-1')
        
        # Note: moto ne supporte pas toutes les opérations SageMaker
        # Ce test est un exemple de structure
        
        session = boto3.Session()
        service = SageMakerAuditService()
        
        # Tester avec endpoints mockés
        results = service.cost_audit(session, 'us-east-1', days=7)
        
        # Vérifier les résultats
        assert isinstance(results, list)


@mock_sts
class TestBedrockWithMoto:
    """Tests Bedrock basiques avec moto"""
    
    def test_get_caller_identity(self):
        """Test récupération account ID"""
        session = boto3.Session()
        sts = session.client('sts', region_name='us-east-1')
        
        identity = sts.get_caller_identity()
        
        assert 'Account' in identity
        assert len(identity['Account']) == 12  # Account ID = 12 chiffres