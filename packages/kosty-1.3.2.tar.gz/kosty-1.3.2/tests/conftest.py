"""
Fixtures pytest partagées
"""

import pytest
from unittest.mock import MagicMock, Mock
import boto3


@pytest.fixture
def mock_boto3_session(mocker):
    """Mock d'une boto3 Session"""
    mock_session = MagicMock(spec=boto3.Session)
    
    # Mock des clients
    mock_session.client = Mock(side_effect=mock_client_factory)
    
    return mock_session


def mock_client_factory(service_name, **kwargs):
    """Factory pour créer des clients mockés selon le service"""
    mock_client = MagicMock()
    
    if service_name == 'sts':
        from tests.fixtures.sample_responses import STS_CALLER_IDENTITY
        mock_client.get_caller_identity.return_value = STS_CALLER_IDENTITY
    
    elif service_name == 'ce':
        from tests.fixtures.sample_responses import COST_EXPLORER_RESPONSE
        mock_client.get_cost_and_usage.return_value = COST_EXPLORER_RESPONSE
    
    elif service_name == 'logs':
        from tests.fixtures.sample_responses import (
            CLOUDWATCH_LOGS_START_QUERY,
            CLOUDWATCH_LOGS_RESULTS
        )
        mock_client.start_query.return_value = CLOUDWATCH_LOGS_START_QUERY
        mock_client.get_query_results.return_value = CLOUDWATCH_LOGS_RESULTS
    
    elif service_name == 'bedrock':
        from tests.fixtures.sample_responses import BEDROCK_LOGGING_CONFIG
        mock_client.get_model_invocation_logging_configuration.return_value = BEDROCK_LOGGING_CONFIG
    
    elif service_name == 'sagemaker':
        from tests.fixtures.sample_responses import (
            SAGEMAKER_LIST_ENDPOINTS,
            SAGEMAKER_DESCRIBE_ENDPOINT_ACTIVE,
            SAGEMAKER_DESCRIBE_ENDPOINT_IDLE
        )
        mock_client.list_endpoints.return_value = SAGEMAKER_LIST_ENDPOINTS
        
        def describe_endpoint_side_effect(EndpointName):
            if 'idle' in EndpointName:
                return SAGEMAKER_DESCRIBE_ENDPOINT_IDLE
            return SAGEMAKER_DESCRIBE_ENDPOINT_ACTIVE
        
        mock_client.describe_endpoint.side_effect = describe_endpoint_side_effect
        mock_client.get_paginator.return_value.paginate.return_value = [SAGEMAKER_LIST_ENDPOINTS]
    
    elif service_name == 'cloudwatch':
        from tests.fixtures.sample_responses import (
            CLOUDWATCH_METRICS_HIGH_INVOCATIONS,
            CLOUDWATCH_METRICS_LOW_INVOCATIONS
        )
        
        def get_metrics_side_effect(**kwargs):
            endpoint_name = kwargs['Dimensions'][0]['Value']
            if 'idle' in endpoint_name:
                return CLOUDWATCH_METRICS_LOW_INVOCATIONS
            return CLOUDWATCH_METRICS_HIGH_INVOCATIONS
        
        mock_client.get_metric_statistics.side_effect = get_metrics_side_effect
    
    return mock_client