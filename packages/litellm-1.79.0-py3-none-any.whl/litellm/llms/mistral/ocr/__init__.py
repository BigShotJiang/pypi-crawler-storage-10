"""Mistral OCR transformation module."""

