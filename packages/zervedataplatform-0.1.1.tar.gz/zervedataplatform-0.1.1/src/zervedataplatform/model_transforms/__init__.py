"""Data models and transformations for database tables."""
