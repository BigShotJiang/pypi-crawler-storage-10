"""Custom decorators."""

# Avoid circular imports - import on demand
__all__ = ["deprecated"]
