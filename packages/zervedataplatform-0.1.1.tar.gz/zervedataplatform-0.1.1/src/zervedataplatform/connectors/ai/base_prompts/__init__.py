"""Base prompt handlers for LLM interactions."""

# Avoid circular imports - import on demand
__all__ = ["BasePromptHandler"]
