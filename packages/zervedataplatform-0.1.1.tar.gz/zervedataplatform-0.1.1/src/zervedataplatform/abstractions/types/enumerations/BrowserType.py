from enum import Enum


class BrowserType(Enum):
    chrome = 0
    firefox = 1
    safari = 2
