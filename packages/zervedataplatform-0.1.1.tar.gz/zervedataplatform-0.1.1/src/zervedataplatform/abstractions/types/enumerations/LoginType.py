from enum import Enum


class LoginType(Enum):
    guest = 0
    login = 1