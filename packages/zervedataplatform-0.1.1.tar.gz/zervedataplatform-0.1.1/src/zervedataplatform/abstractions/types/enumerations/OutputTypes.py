from enum import Enum


class OutputType(Enum):
    CSV = 0
    JSON = 1
    IMAGE = 2
