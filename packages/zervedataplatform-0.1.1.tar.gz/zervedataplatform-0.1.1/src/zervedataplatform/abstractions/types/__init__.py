"""Type definitions, enumerations, and data models."""
