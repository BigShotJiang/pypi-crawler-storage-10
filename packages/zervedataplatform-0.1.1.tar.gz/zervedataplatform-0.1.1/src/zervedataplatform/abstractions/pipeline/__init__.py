"""Pipeline component abstractions."""

# Avoid circular imports - import on demand
__all__ = ["PipelineComponent"]
