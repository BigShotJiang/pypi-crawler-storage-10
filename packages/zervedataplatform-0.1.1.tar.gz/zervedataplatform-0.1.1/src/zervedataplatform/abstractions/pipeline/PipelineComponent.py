
class PipelineComponent:
    def __init__(self):
        pass
