"""Abstract base classes and interfaces for the Zerve Data Platform."""

__version__ = "0.1.0"
