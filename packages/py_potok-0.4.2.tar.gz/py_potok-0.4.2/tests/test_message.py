import pypotok

text = b'''-INIT-
POTOK
0.1
GET
-HEAD-
Origin: here
Target: there
Path: /made/up/path/
From: 134.223.432.456
Key: "diex.4563gth"
-BODY-
hello world
this is the content of message'''

print('\n'.join([
    'Raw message',
    '=' * 20,
    text.decode(),
    '=' * 20
]))

message = pypotok.Message.from_bytes(text)

# Try to reconstruct data
reconstructed = message.to_bytes()

print()
print('\n'.join([
    'Reconstructed message',
    '=' * 20,
    text.decode(),
    '=' * 20
]))

print()
print('Message headers:')
print(message.head.tags)