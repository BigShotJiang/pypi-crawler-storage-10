#!/usr/bin/env python3
"""CLI entry point for code-defender"""

from .minify import main

if __name__ == "__main__":
    main()
