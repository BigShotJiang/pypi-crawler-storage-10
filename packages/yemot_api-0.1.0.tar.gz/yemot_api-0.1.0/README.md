```python
from typing import Annotated

from fastapi import FastAPI, Depends, responses

from yemot_api.api_model import ApiModel
from yemot_api.yemot_api import Yemot
from yemot_api.input_types import FileAction


class ApiModelExample(ApiModel):
    path: str
    token: str


app = FastAPI()


@app.get("/foo")
def foo(q: Annotated[WebhookModel, Depends()]) -> responses.PlainTextResponse:
    yemot_ins = Yemot(q.token)
    if not yemot_ins.check_if_file_exists(q.path, base_path=""):
        return responses.PlainTextResponse("ERROR", 404)
    content = yemot_ins.download_file(q.path, base_path="")
    yemot_ins.file_action(FileAction.MOVE, q.path, "ivr2:/1", base_path="")
    return responses.PlainTextResponse("OK", 200)
    
```