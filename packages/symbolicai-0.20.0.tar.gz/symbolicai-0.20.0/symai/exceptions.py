class ConstraintViolationException(Exception):
    pass


class InvalidPropertyException(Exception):
    pass


class TemplatePropertyException(Exception):
    pass
