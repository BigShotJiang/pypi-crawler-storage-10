AttrsDict
=========

.. autoclass:: dbetto.attrsdict.AttrsDict
   :members:
   :no-index:
