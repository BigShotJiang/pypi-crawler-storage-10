TextDB
======

.. autoclass:: dbetto.textdb.TextDB
   :members:
   :no-index:
