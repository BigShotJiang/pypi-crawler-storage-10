#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Position Encoding Kernels for mlxllm
// Implements Rotary Position Embedding (RoPE) and variants
// ============================================================================

// ============================================================================
// Rotary Position Embedding (RoPE) - NeoX style
// Applied to query and key tensors before attention
// ============================================================================

kernel void rotary_embedding_neox_kernel(
    device float* __restrict__ query [[buffer(0)]],              // [num_tokens, num_heads, head_size]
    device float* __restrict__ key [[buffer(1)]],                // [num_tokens, num_kv_heads, head_size] (optional)
    device const int* __restrict__ positions [[buffer(2)]],      // [num_tokens]
    device const float* __restrict__ cos_sin_cache [[buffer(3)]], // [max_position, rotary_dim]
    constant uint& num_tokens [[buffer(4)]],
    constant uint& num_heads [[buffer(5)]],
    constant uint& num_kv_heads [[buffer(6)]],
    constant uint& head_size [[buffer(7)]],
    constant uint& rotary_dim [[buffer(8)]],
    constant bool& has_key [[buffer(9)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_size = num_tokens * num_heads * head_size;
    if (tid >= total_size) return;

    uint token_idx = tid / (num_heads * head_size);
    uint remainder = tid % (num_heads * head_size);
    uint head_idx = remainder / head_size;
    uint feat_idx = remainder % head_size;

    // Only apply to rotary dimensions
    if (feat_idx >= rotary_dim) return;

    int position = positions[token_idx];

    // NeoX style: split into two halves and rotate
    uint half_rotary = rotary_dim / 2;
    uint rot_offset = feat_idx % half_rotary;
    uint pair_idx = (feat_idx < half_rotary) ? feat_idx + half_rotary : feat_idx - half_rotary;

    // Get cos/sin values
    uint cache_offset = position * rotary_dim + feat_idx;
    float cos_val = cos_sin_cache[cache_offset];
    float sin_val = cos_sin_cache[position * rotary_dim + half_rotary + rot_offset];

    // Apply rotation to query
    uint q_offset = token_idx * (num_heads * head_size) + head_idx * head_size + feat_idx;
    uint q_pair_offset = token_idx * (num_heads * head_size) + head_idx * head_size + pair_idx;

    float q = query[q_offset];
    float q_pair = query[q_pair_offset];

    if (feat_idx < half_rotary) {
        query[q_offset] = q * cos_val - q_pair * sin_val;
    } else {
        query[q_offset] = q * cos_val + q_pair * sin_val;
    }

    // Apply rotation to key if present
    if (has_key && head_idx < num_kv_heads) {
        uint k_offset = token_idx * (num_kv_heads * head_size) + head_idx * head_size + feat_idx;
        uint k_pair_offset = token_idx * (num_kv_heads * head_size) + head_idx * head_size + pair_idx;

        float k = key[k_offset];
        float k_pair = key[k_pair_offset];

        if (feat_idx < half_rotary) {
            key[k_offset] = k * cos_val - k_pair * sin_val;
        } else {
            key[k_offset] = k * cos_val + k_pair * sin_val;
        }
    }
}

// ============================================================================
// Rotary Position Embedding (RoPE) - GPT-J/GPT-NeoX alternate style
// Interleaves pairs: (x0, x1, x2, x3, ...) -> (x0, x1), (x2, x3), ...
// ============================================================================

kernel void rotary_embedding_gptj_kernel(
    device float* __restrict__ query [[buffer(0)]],
    device float* __restrict__ key [[buffer(1)]],
    device const int* __restrict__ positions [[buffer(2)]],
    device const float* __restrict__ cos_sin_cache [[buffer(3)]],
    constant uint& num_tokens [[buffer(4)]],
    constant uint& num_heads [[buffer(5)]],
    constant uint& num_kv_heads [[buffer(6)]],
    constant uint& head_size [[buffer(7)]],
    constant uint& rotary_dim [[buffer(8)]],
    constant bool& has_key [[buffer(9)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_pairs = num_tokens * num_heads * (rotary_dim / 2);
    if (tid >= total_pairs) return;

    uint token_idx = tid / (num_heads * rotary_dim / 2);
    uint remainder = tid % (num_heads * rotary_dim / 2);
    uint head_idx = remainder / (rotary_dim / 2);
    uint pair_idx = remainder % (rotary_dim / 2);

    int position = positions[token_idx];

    // GPTJ style: consecutive pairs (0,1), (2,3), etc.
    uint feat_idx_0 = pair_idx * 2;
    uint feat_idx_1 = pair_idx * 2 + 1;

    // Get cos/sin values
    float cos_val = cos_sin_cache[position * rotary_dim + pair_idx];
    float sin_val = cos_sin_cache[position * rotary_dim + rotary_dim / 2 + pair_idx];

    // Apply rotation to query
    uint q_offset_0 = token_idx * (num_heads * head_size) + head_idx * head_size + feat_idx_0;
    uint q_offset_1 = token_idx * (num_heads * head_size) + head_idx * head_size + feat_idx_1;

    float q0 = query[q_offset_0];
    float q1 = query[q_offset_1];

    query[q_offset_0] = q0 * cos_val - q1 * sin_val;
    query[q_offset_1] = q0 * sin_val + q1 * cos_val;

    // Apply rotation to key if present
    if (has_key && head_idx < num_kv_heads) {
        uint k_offset_0 = token_idx * (num_kv_heads * head_size) + head_idx * head_size + feat_idx_0;
        uint k_offset_1 = token_idx * (num_kv_heads * head_size) + head_idx * head_size + feat_idx_1;

        float k0 = key[k_offset_0];
        float k1 = key[k_offset_1];

        key[k_offset_0] = k0 * cos_val - k1 * sin_val;
        key[k_offset_1] = k0 * sin_val + k1 * cos_val;
    }
}

// ============================================================================
// Half precision version for FP16
// ============================================================================

kernel void rotary_embedding_neox_kernel_half(
    device half* __restrict__ query [[buffer(0)]],
    device half* __restrict__ key [[buffer(1)]],
    device const int* __restrict__ positions [[buffer(2)]],
    device const half* __restrict__ cos_sin_cache [[buffer(3)]],
    constant uint& num_tokens [[buffer(4)]],
    constant uint& num_heads [[buffer(5)]],
    constant uint& num_kv_heads [[buffer(6)]],
    constant uint& head_size [[buffer(7)]],
    constant uint& rotary_dim [[buffer(8)]],
    constant bool& has_key [[buffer(9)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_size = num_tokens * num_heads * head_size;
    if (tid >= total_size) return;

    uint token_idx = tid / (num_heads * head_size);
    uint remainder = tid % (num_heads * head_size);
    uint head_idx = remainder / head_size;
    uint feat_idx = remainder % head_size;

    if (feat_idx >= rotary_dim) return;

    int position = positions[token_idx];

    uint half_rotary = rotary_dim / 2;
    uint rot_offset = feat_idx % half_rotary;
    uint pair_idx = (feat_idx < half_rotary) ? feat_idx + half_rotary : feat_idx - half_rotary;

    uint cache_offset = position * rotary_dim + feat_idx;
    half cos_val = cos_sin_cache[cache_offset];
    half sin_val = cos_sin_cache[position * rotary_dim + half_rotary + rot_offset];

    uint q_offset = token_idx * (num_heads * head_size) + head_idx * head_size + feat_idx;
    uint q_pair_offset = token_idx * (num_heads * head_size) + head_idx * head_size + pair_idx;

    half q = query[q_offset];
    half q_pair = query[q_pair_offset];

    if (feat_idx < half_rotary) {
        query[q_offset] = q * cos_val - q_pair * sin_val;
    } else {
        query[q_offset] = q * cos_val + q_pair * sin_val;
    }

    if (has_key && head_idx < num_kv_heads) {
        uint k_offset = token_idx * (num_kv_heads * head_size) + head_idx * head_size + feat_idx;
        uint k_pair_offset = token_idx * (num_kv_heads * head_size) + head_idx * head_size + pair_idx;

        half k = key[k_offset];
        half k_pair = key[k_pair_offset];

        if (feat_idx < half_rotary) {
            key[k_offset] = k * cos_val - k_pair * sin_val;
        } else {
            key[k_offset] = k * cos_val + k_pair * sin_val;
        }
    }
}

// ============================================================================
// Precompute cos/sin cache for RoPE
// ============================================================================

kernel void precompute_rope_cache_kernel(
    device float* __restrict__ cos_sin_cache [[buffer(0)]], // [max_position, rotary_dim]
    constant uint& max_position [[buffer(1)]],
    constant uint& rotary_dim [[buffer(2)]],
    constant float& theta_base [[buffer(3)]],  // Usually 10000.0
    uint tid [[thread_position_in_grid]]
) {
    uint total = max_position * rotary_dim;
    if (tid >= total) return;

    uint pos = tid / rotary_dim;
    uint dim = tid % rotary_dim;

    uint half_dim = rotary_dim / 2;
    uint pair_dim = dim % half_dim;

    // Compute frequency: 1 / (theta_base ^ (2 * pair_dim / rotary_dim))
    float freq = 1.0f / pow(theta_base, float(2 * pair_dim) / float(rotary_dim));

    // Compute angle
    float angle = float(pos) * freq;

    // Store cos and sin
    if (dim < half_dim) {
        cos_sin_cache[tid] = cos(angle);
    } else {
        cos_sin_cache[tid] = sin(angle);
    }
}
