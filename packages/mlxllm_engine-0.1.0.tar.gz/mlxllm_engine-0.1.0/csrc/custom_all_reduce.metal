#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Custom All-Reduce Kernels for mlxllm
// Implements collective communication primitives for distributed inference
// ============================================================================

// ============================================================================
// All-Reduce Sum - combines values from all processes
// ============================================================================

kernel void all_reduce_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],      // Local input
    device float* __restrict__ output [[buffer(1)]],           // Output buffer
    device const float* __restrict__ peer_buffers [[buffer(2)]], // Peer data (flat)
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],                            // Number of elements
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    // Sum local input with all peer inputs
    float sum = input[tid];

    for (uint peer = 0; peer < num_peers; peer++) {
        sum += peer_buffers[peer * n + tid];
    }

    output[tid] = sum;
}

// ============================================================================
// All-Reduce Max
// ============================================================================

kernel void all_reduce_max_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float max_val = input[tid];

    for (uint peer = 0; peer < num_peers; peer++) {
        max_val = max(max_val, peer_buffers[peer * n + tid]);
    }

    output[tid] = max_val;
}

// ============================================================================
// All-Reduce Min
// ============================================================================

kernel void all_reduce_min_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float min_val = input[tid];

    for (uint peer = 0; peer < num_peers; peer++) {
        min_val = min(min_val, peer_buffers[peer * n + tid]);
    }

    output[tid] = min_val;
}

// ============================================================================
// All-Reduce Product
// ============================================================================

kernel void all_reduce_prod_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float prod = input[tid];

    for (uint peer = 0; peer < num_peers; peer++) {
        prod *= peer_buffers[peer * n + tid];
    }

    output[tid] = prod;
}

// ============================================================================
// Ring All-Reduce - more efficient for large data
// Step 1: Reduce-Scatter phase
// ============================================================================

kernel void ring_all_reduce_scatter_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ recv_buffer [[buffer(2)]],
    constant uint& chunk_size [[buffer(3)]],
    constant uint& chunk_offset [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= chunk_size) return;

    uint idx = chunk_offset + tid;
    output[idx] = input[idx] + recv_buffer[tid];
}

// ============================================================================
// Ring All-Reduce - Step 2: All-Gather phase
// ============================================================================

kernel void ring_all_gather_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& chunk_size [[buffer(2)]],
    constant uint& chunk_offset [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= chunk_size) return;

    uint idx = chunk_offset + tid;
    output[idx] = input[tid];
}

// ============================================================================
// Broadcast - send from root to all
// ============================================================================

kernel void broadcast_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = input[tid];
}

// ============================================================================
// Reduce - combine to root process
// ============================================================================

kernel void reduce_to_root_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    constant bool& is_root [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    if (is_root) {
        float sum = input[tid];
        for (uint peer = 0; peer < num_peers; peer++) {
            sum += peer_buffers[peer * n + tid];
        }
        output[tid] = sum;
    } else {
        // Non-root: just pass through
        output[tid] = input[tid];
    }
}

// ============================================================================
// All-Gather - collect from all processes
// ============================================================================

kernel void all_gather_kernel(
    device const float* __restrict__ input [[buffer(0)]],      // Local chunk
    device float* __restrict__ output [[buffer(1)]],           // Full output
    device const float* __restrict__ peer_buffers [[buffer(2)]], // Peer chunks
    constant uint& chunk_size [[buffer(3)]],
    constant uint& rank [[buffer(4)]],
    constant uint& num_peers [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= chunk_size) return;

    // Copy local chunk to output
    output[rank * chunk_size + tid] = input[tid];

    // Copy peer chunks
    for (uint peer = 0; peer < num_peers; peer++) {
        output[peer * chunk_size + tid] = peer_buffers[peer * chunk_size + tid];
    }
}

// ============================================================================
// Reduce-Scatter - reduce and distribute chunks
// ============================================================================

kernel void reduce_scatter_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& chunk_size [[buffer(3)]],
    constant uint& chunk_idx [[buffer(4)]],
    constant uint& num_peers [[buffer(5)]],
    constant uint& total_size [[buffer(6)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= chunk_size) return;

    uint global_idx = chunk_idx * chunk_size + tid;
    if (global_idx >= total_size) return;

    float sum = input[global_idx];
    for (uint peer = 0; peer < num_peers; peer++) {
        sum += peer_buffers[peer * total_size + global_idx];
    }

    output[tid] = sum;
}

// ============================================================================
// Optimized All-Reduce with FP16 for reduced bandwidth
// ============================================================================

kernel void all_reduce_sum_kernel_half(
    device const half* __restrict__ input [[buffer(0)]],
    device half* __restrict__ output [[buffer(1)]],
    device const half* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float sum = float(input[tid]);

    for (uint peer = 0; peer < num_peers; peer++) {
        sum += float(peer_buffers[peer * n + tid]);
    }

    output[tid] = half(sum);
}

// ============================================================================
// SIMD-optimized All-Reduce Sum
// Uses SIMD operations for better performance
// ============================================================================

kernel void all_reduce_sum_kernel_simd(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ peer_buffers [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]],
    uint simd_lane_id [[thread_index_in_simdgroup]]
) {
    if (tid >= n) return;

    float sum = input[tid];

    for (uint peer = 0; peer < num_peers; peer++) {
        sum += peer_buffers[peer * n + tid];
    }

    // SIMD-level reduction if needed
    output[tid] = sum;
}

// ============================================================================
// Barrier synchronization (dummy - actual sync is external)
// ============================================================================

kernel void barrier_kernel(
    device atomic_int* __restrict__ counter [[buffer(0)]],
    device atomic_int* __restrict__ sense [[buffer(1)]],
    constant uint& num_threads [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_threads) return;

    // Increment counter
    int count = atomic_fetch_add_explicit(counter, 1, memory_order_relaxed);

    // Last thread resets counter and flips sense
    if (count == num_threads - 1) {
        atomic_store_explicit(counter, 0, memory_order_relaxed);
        int old_sense = atomic_load_explicit(sense, memory_order_relaxed);
        atomic_store_explicit(sense, 1 - old_sense, memory_order_release);
    }
}

// ============================================================================
// Scatter - distribute from root to all
// ============================================================================

kernel void scatter_kernel(
    device const float* __restrict__ input [[buffer(0)]],      // Full data on root
    device float* __restrict__ output [[buffer(1)]],           // Local chunk
    constant uint& chunk_size [[buffer(2)]],
    constant uint& rank [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= chunk_size) return;

    uint src_idx = rank * chunk_size + tid;
    output[tid] = input[src_idx];
}

// ============================================================================
// All-to-All - personalized exchange
// ============================================================================

kernel void all_to_all_kernel(
    device const float* __restrict__ input [[buffer(0)]],      // [num_peers, chunk_size]
    device float* __restrict__ output [[buffer(1)]],           // [num_peers, chunk_size]
    device const float* __restrict__ peer_buffers [[buffer(2)]], // All peer data
    constant uint& chunk_size [[buffer(3)]],
    constant uint& rank [[buffer(4)]],
    constant uint& num_peers [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_peers * chunk_size;
    if (tid >= total_elements) return;

    uint dst_peer = tid / chunk_size;
    uint offset = tid % chunk_size;

    // Copy from peer_buffers[dst_peer][rank * chunk_size + offset] to output[tid]
    output[tid] = peer_buffers[dst_peer * (num_peers * chunk_size) + rank * chunk_size + offset];
}
