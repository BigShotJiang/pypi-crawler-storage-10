#include <metal_stdlib>
using namespace metal;

// ============================================================================
// RMS LayerNorm with Quantization Kernels for mlxllm
// Fuses normalization with FP8/INT8 quantization for efficiency
// ============================================================================

// ============================================================================
// RMS Norm + Static FP8 Quantization
// Normalizes and quantizes to FP8 E4M3 using fixed scale
// ============================================================================

kernel void rms_norm_static_fp8_quant_kernel(
    device const float* __restrict__ input [[buffer(0)]],    // [num_tokens, hidden_size]
    device const float* __restrict__ weight [[buffer(1)]],   // [hidden_size]
    device uchar* __restrict__ output [[buffer(2)]],         // [num_tokens, hidden_size] FP8
    device const float* __restrict__ scale [[buffer(3)]],    // [1] - static scale
    constant uint& num_tokens [[buffer(4)]],
    constant uint& hidden_size [[buffer(5)]],
    constant float& epsilon [[buffer(6)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_sum[256];
    const float max_fp8 = 448.0f;
    float scale_value = *scale;

    // Compute RMS
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = input[gid * hidden_size + i];
        sum_sq += val * val;
    }

    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    // Normalize, apply weight, and quantize to FP8
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float normalized = input[idx] * rms * weight[i];

        // Quantize to FP8 E4M3
        float scaled = normalized / scale_value;
        scaled = clamp(scaled, -max_fp8, max_fp8);

        output[idx] = uchar((scaled + max_fp8) * 255.0f / (2.0f * max_fp8));
    }
}

// ============================================================================
// Fused Add + RMS Norm + Static FP8 Quantization
// Combines residual addition, normalization, and quantization
// ============================================================================

kernel void fused_add_rms_norm_static_fp8_quant_kernel(
    device const float* __restrict__ input [[buffer(0)]],    // [num_tokens, hidden_size]
    device const float* __restrict__ residual [[buffer(1)]], // [num_tokens, hidden_size]
    device const float* __restrict__ weight [[buffer(2)]],   // [hidden_size]
    device uchar* __restrict__ output [[buffer(3)]],         // [num_tokens, hidden_size] FP8
    device const float* __restrict__ scale [[buffer(4)]],    // [1]
    constant uint& num_tokens [[buffer(5)]],
    constant uint& hidden_size [[buffer(6)]],
    constant float& epsilon [[buffer(7)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_sum[256];
    const float max_fp8 = 448.0f;
    float scale_value = *scale;

    // Add residual and compute RMS
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        sum_sq += val * val;
        shared_sum[tid + hidden_size] = val;  // Store for later (temp storage)
    }

    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    // Normalize, apply weight, and quantize
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        float normalized = val * rms * weight[i];

        float scaled = normalized / scale_value;
        scaled = clamp(scaled, -max_fp8, max_fp8);

        output[idx] = uchar((scaled + max_fp8) * 255.0f / (2.0f * max_fp8));
    }
}

// ============================================================================
// RMS Norm + Dynamic Per-Token Quantization
// Computes optimal scale per token for better precision
// ============================================================================

kernel void rms_norm_dynamic_per_token_quant_kernel(
    device const float* __restrict__ input [[buffer(0)]],    // [num_tokens, hidden_size]
    device const float* __restrict__ weight [[buffer(1)]],   // [hidden_size]
    device char* __restrict__ output [[buffer(2)]],          // [num_tokens, hidden_size] INT8
    device float* __restrict__ scales [[buffer(3)]],         // [num_tokens]
    constant uint& num_tokens [[buffer(4)]],
    constant uint& hidden_size [[buffer(5)]],
    constant float& epsilon [[buffer(6)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_data[512];  // Used for both RMS and max

    // Step 1: Compute RMS
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = input[gid * hidden_size + i];
        sum_sq += val * val;
    }

    shared_data[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] += shared_data[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_data[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_data[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_data[0];

    // Step 2: Find max absolute value of normalized output
    float local_max = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float normalized = input[idx] * rms * weight[i];
        local_max = max(local_max, abs(normalized));
    }

    shared_data[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Step 3: Compute scale and quantize
    float scale = 1.0f;
    if (tid == 0) {
        float max_val = shared_data[0];
        scale = max_val / 127.0f;
        if (scale == 0.0f) scale = 1.0f;
        scales[gid] = scale;
        shared_data[0] = scale;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    scale = shared_data[0];

    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float normalized = input[idx] * rms * weight[i];
        float quantized = round(normalized / scale);
        quantized = clamp(quantized, -127.0f, 127.0f);
        output[idx] = char(quantized);
    }
}

// ============================================================================
// Fused Add + RMS Norm + Dynamic Per-Token Quantization
// ============================================================================

kernel void fused_add_rms_norm_dynamic_quant_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device const float* __restrict__ residual [[buffer(1)]],
    device const float* __restrict__ weight [[buffer(2)]],
    device char* __restrict__ output [[buffer(3)]],
    device float* __restrict__ scales [[buffer(4)]],
    constant uint& num_tokens [[buffer(5)]],
    constant uint& hidden_size [[buffer(6)]],
    constant float& epsilon [[buffer(7)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_data[512];

    // Add residual and compute RMS
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        sum_sq += val * val;
    }

    shared_data[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] += shared_data[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_data[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_data[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_data[0];

    // Find max absolute value
    float local_max = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        float normalized = val * rms * weight[i];
        local_max = max(local_max, abs(normalized));
    }

    shared_data[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Compute scale and quantize
    float scale = 1.0f;
    if (tid == 0) {
        float max_val = shared_data[0];
        scale = max_val / 127.0f;
        if (scale == 0.0f) scale = 1.0f;
        scales[gid] = scale;
        shared_data[0] = scale;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    scale = shared_data[0];

    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        float normalized = val * rms * weight[i];
        float quantized = round(normalized / scale);
        quantized = clamp(quantized, -127.0f, 127.0f);
        output[idx] = char(quantized);
    }
}

// ============================================================================
// Half precision variant
// ============================================================================

kernel void rms_norm_dynamic_per_token_quant_kernel_half(
    device const half* __restrict__ input [[buffer(0)]],
    device const half* __restrict__ weight [[buffer(1)]],
    device char* __restrict__ output [[buffer(2)]],
    device float* __restrict__ scales [[buffer(3)]],
    constant uint& num_tokens [[buffer(4)]],
    constant uint& hidden_size [[buffer(5)]],
    constant float& epsilon [[buffer(6)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_data[512];

    // Compute RMS
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = float(input[gid * hidden_size + i]);
        sum_sq += val * val;
    }

    shared_data[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] += shared_data[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_data[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_data[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_data[0];

    // Find max
    float local_max = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float normalized = float(input[idx]) * rms * float(weight[i]);
        local_max = max(local_max, abs(normalized));
    }

    shared_data[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float scale = 1.0f;
    if (tid == 0) {
        float max_val = shared_data[0];
        scale = max_val / 127.0f;
        if (scale == 0.0f) scale = 1.0f;
        scales[gid] = scale;
        shared_data[0] = scale;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    scale = shared_data[0];

    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float normalized = float(input[idx]) * rms * float(weight[i]);
        float quantized = round(normalized / scale);
        quantized = clamp(quantized, -127.0f, 127.0f);
        output[idx] = char(quantized);
    }
}
