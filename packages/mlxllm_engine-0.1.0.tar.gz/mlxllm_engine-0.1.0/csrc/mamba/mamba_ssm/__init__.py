"""Mamba State Space Model Operations Module for MLX-LLM.

Provides Metal-optimized selective scan operations for Mamba architecture.
"""

from typing import Optional, Dict

try:
    from . import _mamba_ssm  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

if _EXTENSION_AVAILABLE:
    from ._mamba_ssm import (
        # Constants
        MAX_DSTATE,
        CHUNK_SIZE,
        # Operations
        selective_scan_fwd,
        selective_scan_fwd_config,
        # Configuration
        get_kernel_config,
        is_selective_scan_supported,
        # Benchmarking
        benchmark_selective_scan,
    )
    __all__ = [
        'MAX_DSTATE', 'CHUNK_SIZE',
        'selective_scan_fwd', 'selective_scan_fwd_config',
        'get_kernel_config', 'is_selective_scan_supported',
        'benchmark_selective_scan',
        'is_available',
    ]
else:
    def _unavailable(*args, **kwargs):
        raise RuntimeError(f"Mamba SSM extension not available: {_IMPORT_ERROR}")

    MAX_DSTATE = CHUNK_SIZE = 0
    selective_scan_fwd = selective_scan_fwd_config = _unavailable
    get_kernel_config = is_selective_scan_supported = _unavailable
    benchmark_selective_scan = _unavailable
    __all__ = ['is_available']

def is_available() -> bool:
    return _EXTENSION_AVAILABLE

__version__ = "0.1.0"
__backend__ = "Metal" if _EXTENSION_AVAILABLE else "None"
__architecture__ = "Mamba"
