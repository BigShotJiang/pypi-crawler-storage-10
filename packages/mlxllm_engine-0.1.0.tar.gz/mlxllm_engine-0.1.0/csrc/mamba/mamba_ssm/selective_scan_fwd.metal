#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Mamba Selective Scan Forward Kernel for Metal Backend
// Implements selective state space model scan operation
// Based on: https://arxiv.org/abs/2312.00752
// ============================================================================

// ============================================================================
// Constants
// ============================================================================

constant int MAX_DSTATE = 256;
constant int CHUNK_SIZE = 2048;
constant float LOG2E = 1.44269504088896340736f;  // log2(e)

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * @brief Softplus activation: log(1 + exp(x))
 */
inline float softplus(float x) {
    return (x <= 20.0f) ? log1pf(exp(x)) : x;
}

/**
 * @brief SiLU activation: x * sigmoid(x)
 */
inline float silu(float x) {
    return x / (1.0f + exp(-x));
}

/**
 * @brief Load input with bounds checking
 */
template<typename T>
inline void load_input_checked(
    device const T* input,
    thread T* output,
    uint offset,
    uint count,
    uint seqlen_remaining
) {
    #pragma unroll
    for (uint i = 0; i < count; ++i) {
        if (offset + i < seqlen_remaining) {
            output[i] = input[offset + i];
        } else {
            output[i] = T(0);
        }
    }
}

/**
 * @brief Store output with bounds checking
 */
template<typename T>
inline void store_output_checked(
    device T* output,
    thread const T* input,
    uint offset,
    uint count,
    uint seqlen_remaining
) {
    #pragma unroll
    for (uint i = 0; i < count; ++i) {
        if (offset + i < seqlen_remaining) {
            output[offset + i] = input[i];
        }
    }
}

// ============================================================================
// Threadgroup-Level Scan
// ============================================================================

/**
 * @brief Threadgroup prefix scan for SSM state propagation
 */
inline float2 threadgroup_scan_ssm(
    float2 value,
    threadgroup float2* shared,
    uint tid,
    uint threadgroup_size
) {
    shared[tid] = value;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Parallel prefix scan
    for (uint offset = 1; offset < threadgroup_size; offset <<= 1) {
        float2 temp = (tid >= offset) ? shared[tid - offset] : float2(1.0f, 0.0f);
        threadgroup_barrier(mem_flags::mem_threadgroup);
        
        if (tid >= offset) {
            // Combine: (A1*A2, A2*B1 + B2)
            shared[tid] = float2(
                value.x * temp.x,
                value.x * temp.y + value.y
            );
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        value = shared[tid];
    }

    return value;
}

// ============================================================================
// Main Selective Scan Kernel - FP16
// ============================================================================

/**
 * @brief Selective scan forward kernel (FP16 input, FP32 state)
 *
 * Implements: 
 *   delta = delta + delta_bias
 *   delta = softplus(delta) if delta_softplus
 *   A_bar = exp(delta * A)
 *   B_bar = delta * B
 *   x[t] = A_bar * x[t-1] + B_bar * u[t]
 *   y[t] = C * x[t] + D * u[t]
 *
 * @tparam kNThreads Threads per threadgroup
 * @tparam kNItems Items per thread
 * @tparam kNRows Rows to process
 * @tparam kIsVariableB Time-varying B matrix
 * @tparam kIsVariableC Time-varying C matrix
 * @tparam kHasZ Has gating (z)
 * @tparam kVarlen Variable length sequences
 */
template<
    int kNThreads,
    int kNItems,
    int kNRows,
    bool kIsVariableB,
    bool kIsVariableC,
    bool kHasZ,
    bool kVarlen
>
kernel void selective_scan_fwd_fp16(
    // Dimensions
    constant uint& batch [[buffer(0)]],
    constant uint& dim [[buffer(1)]],
    constant uint& seqlen [[buffer(2)]],
    constant uint& dstate [[buffer(3)]],
    constant uint& n_groups [[buffer(4)]],
    constant uint& dim_ngroups_ratio [[buffer(5)]],
    
    // Configuration
    constant bool& delta_softplus [[buffer(6)]],
    constant int64_t& pad_slot_id [[buffer(7)]],
    
    // Input tensors
    device const half* u [[buffer(8)]],              // [batch, seqlen, dim]
    device const half* delta_input [[buffer(9)]],    // [batch, seqlen, dim]
    device const half* A [[buffer(10)]],             // [dim, dstate]
    device const half* B [[buffer(11)]],             // [batch, seqlen, n_groups, dstate] or [n_groups, dstate]
    device const half* C [[buffer(12)]],             // [batch, seqlen, n_groups, dstate] or [n_groups, dstate]
    device const float* D [[buffer(13)]],            // [dim]
    device const float* delta_bias [[buffer(14)]],   // [dim]
    device const half* z [[buffer(15)]],             // [batch, seqlen, dim] (optional)
    
    // Output tensors
    device half* out [[buffer(16)]],                 // [batch, seqlen, dim]
    device float* ssm_states [[buffer(17)]],         // [batch, dim, dstate]
    device half* out_z [[buffer(18)]],               // [batch, seqlen, dim] (optional)
    
    // Variable length support
    device const int* query_start_loc [[buffer(19)]], // [batch+1]
    device const int* cache_indices [[buffer(20)]],   // [batch]
    device const bool* has_initial_state [[buffer(21)]], // [batch]
    
    // Strides
    constant uint& u_batch_stride [[buffer(22)]],
    constant uint& delta_batch_stride [[buffer(23)]],
    constant uint& A_d_stride [[buffer(24)]],
    constant uint& B_batch_stride [[buffer(25)]],
    constant uint& C_batch_stride [[buffer(26)]],
    constant uint& out_batch_stride [[buffer(27)]],
    constant uint& states_batch_stride [[buffer(28)]],
    
    // Thread configuration
    uint3 gid [[threadgroup_position_in_grid]],
    uint3 tid [[thread_position_in_threadgroup]],
    uint3 tg_size [[threads_per_threadgroup]])
{
    // Threadgroup shared memory
    threadgroup float2 shared_scan[kNThreads];
    threadgroup half shared_B[MAX_DSTATE];
    threadgroup half shared_C[MAX_DSTATE];

    uint batch_id = gid.x;
    uint dim_id = gid.y;
    uint group_id = dim_id / dim_ngroups_ratio;
    
    // Variable length handling
    uint seq_start = batch_id;
    uint seq_len = seqlen;
    if (kVarlen && query_start_loc != nullptr) {
        seq_start = query_start_loc[batch_id];
        seq_len = query_start_loc[batch_id + 1] - seq_start;
    }
    
    // Cache index for state storage
    uint cache_idx = (cache_indices != nullptr) ? cache_indices[batch_id] : batch_id;
    if (cache_idx == pad_slot_id) return;  // Padding slot
    
    // Check initial state
    bool use_initial_state = (has_initial_state != nullptr) && has_initial_state[batch_id];
    
    // Compute pointers for this batch/dim
    device const half* u_ptr = u + seq_start * u_batch_stride + dim_id * kNRows;
    device const half* delta_ptr = delta_input + seq_start * delta_batch_stride + dim_id * kNRows;
    device const half* A_ptr = A + dim_id * kNRows * A_d_stride;
    
    device half* out_ptr = out + seq_start * out_batch_stride + dim_id * kNRows;
    device float* state_ptr = ssm_states + cache_idx * states_batch_stride + dim_id * kNRows * dstate;
    
    // Load D and delta_bias
    float D_val[kNRows];
    float delta_bias_val[kNRows];
    
    #pragma unroll
    for (uint r = 0; r < kNRows; ++r) {
        D_val[r] = (D != nullptr) ? D[dim_id * kNRows + r] : 0.0f;
        delta_bias_val[r] = (delta_bias != nullptr) ? delta_bias[dim_id * kNRows + r] : 0.0f;
    }
    
    // Load B and C into shared memory if not time-varying
    if (tid.x == 0 && tid.y == 0 && !kIsVariableB) {
        for (uint i = 0; i < dstate; ++i) {
            shared_B[i] = B[group_id * dstate + i];
        }
    }
    if (tid.x == 0 && tid.y == 0 && !kIsVariableC) {
        for (uint i = 0; i < dstate; ++i) {
            shared_C[i] = C[group_id * dstate + i];
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    
    // Process in chunks
    uint n_chunks = (seq_len + CHUNK_SIZE - 1) / CHUNK_SIZE;
    
    for (uint chunk = 0; chunk < n_chunks; ++chunk) {
        uint chunk_start = chunk * CHUNK_SIZE;
        uint chunk_size = min(CHUNK_SIZE, seq_len - chunk_start);
        
        // Each thread processes kNItems elements
        uint thread_offset = tid.x * kNItems;
        
        if (thread_offset < chunk_size) {
            // Storage for this thread's work
            half u_vals[kNRows][kNItems];
            half delta_vals_raw[kNRows][kNItems];
            float delta_vals[kNRows][kNItems];
            float delta_u[kNRows][kNItems];
            float out_vals[kNRows][kNItems];
            
            // Load inputs
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                load_input_checked(
                    u_ptr + r + chunk_start,
                    u_vals[r],
                    thread_offset,
                    kNItems,
                    chunk_size
                );
                load_input_checked(
                    delta_ptr + r + chunk_start,
                    delta_vals_raw[r],
                    thread_offset,
                    kNItems,
                    chunk_size
                );
            }
            
            // Process delta and compute delta * u
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                #pragma unroll
                for (uint i = 0; i < kNItems; ++i) {
                    float u_val = float(u_vals[r][i]);
                    delta_vals[r][i] = float(delta_vals_raw[r][i]) + delta_bias_val[r];
                    
                    if (delta_softplus) {
                        delta_vals[r][i] = softplus(delta_vals[r][i]);
                    }
                    
                    delta_u[r][i] = delta_vals[r][i] * u_val;
                    out_vals[r][i] = D_val[r] * u_val;  // D * u (skip connection)
                }
            }
            
            // SSM computation for each state dimension
            for (uint state_idx = 0; state_idx < dstate; ++state_idx) {
                // Load A for this state
                half A_val[kNRows];
                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    A_val[r] = A_ptr[state_idx + r * A_d_stride];
                }
                
                // Load or get B and C
                half B_val;
                half C_val;
                
                if (kIsVariableB) {
                    // Time-varying B: load from input
                    B_val = B[seq_start * B_batch_stride + group_id * dstate + state_idx];
                } else {
                    B_val = shared_B[state_idx];
                }
                
                if (kIsVariableC) {
                    C_val = C[seq_start * C_batch_stride + group_id * dstate + state_idx];
                } else {
                    C_val = shared_C[state_idx];
                }
                
                // Process each row
                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    // Load initial state
                    float state_val = use_initial_state ? 
                        state_ptr[r * dstate + state_idx] : 0.0f;
                    
                    // SSM recurrence over sequence
                    #pragma unroll
                    for (uint i = 0; i < kNItems; ++i) {
                        if (thread_offset + i < chunk_size) {
                            // Discretize: A_bar = exp(delta * A), B_bar = delta * B
                            float A_discrete = exp(delta_vals[r][i] * float(A_val[r]) * LOG2E);
                            float B_discrete = delta_vals[r][i] * float(B_val);
                            
                            // State update: x[t] = A_bar * x[t-1] + B_bar * u[t]
                            state_val = A_discrete * state_val + B_discrete * float(u_vals[r][i]);
                            
                            // Output: y[t] = C * x[t]
                            out_vals[r][i] += float(C_val) * state_val;
                        }
                    }
                    
                    // Store final state
                    if (thread_offset + kNItems - 1 < chunk_size) {
                        state_ptr[r * dstate + state_idx] = state_val;
                    }
                }
            }
            
            // Apply gating if enabled
            if (kHasZ && z != nullptr) {
                half z_vals[kNRows][kNItems];
                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    load_input_checked(
                        z + seq_start + dim_id * kNRows + r + chunk_start,
                        z_vals[r],
                        thread_offset,
                        kNItems,
                        chunk_size
                    );
                    
                    #pragma unroll
                    for (uint i = 0; i < kNItems; ++i) {
                        out_vals[r][i] *= silu(float(z_vals[r][i]));
                    }
                }
            }
            
            // Store outputs
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                half out_half[kNItems];
                #pragma unroll
                for (uint i = 0; i < kNItems; ++i) {
                    out_half[i] = half(out_vals[r][i]);
                }
                
                store_output_checked(
                    out_ptr + r + chunk_start,
                    out_half,
                    thread_offset,
                    kNItems,
                    chunk_size
                );
            }
        }
        
        threadgroup_barrier(mem_flags::mem_device);
    }
}

// ============================================================================
// Main Selective Scan Kernel - FP32
// ============================================================================

template<
    int kNThreads,
    int kNItems,
    int kNRows,
    bool kIsVariableB,
    bool kIsVariableC,
    bool kHasZ,
    bool kVarlen
>
kernel void selective_scan_fwd_fp32(
    constant uint& batch [[buffer(0)]],
    constant uint& dim [[buffer(1)]],
    constant uint& seqlen [[buffer(2)]],
    constant uint& dstate [[buffer(3)]],
    constant uint& n_groups [[buffer(4)]],
    constant uint& dim_ngroups_ratio [[buffer(5)]],
    constant bool& delta_softplus [[buffer(6)]],
    constant int64_t& pad_slot_id [[buffer(7)]],

    device const float* u [[buffer(8)]],
    device const float* delta_input [[buffer(9)]],
    device const float* A [[buffer(10)]],
    device const float* B [[buffer(11)]],
    device const float* C [[buffer(12)]],
    device const float* D [[buffer(13)]],
    device const float* delta_bias [[buffer(14)]],
    device const float* z [[buffer(15)]],

    device float* out [[buffer(16)]],
    device float* ssm_states [[buffer(17)]],
    device float* out_z [[buffer(18)]],

    device const int* query_start_loc [[buffer(19)]],
    device const int* cache_indices [[buffer(20)]],
    device const bool* has_initial_state [[buffer(21)]],

    constant uint& u_batch_stride [[buffer(22)]],
    constant uint& delta_batch_stride [[buffer(23)]],
    constant uint& A_d_stride [[buffer(24)]],
    constant uint& B_batch_stride [[buffer(25)]],
    constant uint& C_batch_stride [[buffer(26)]],
    constant uint& out_batch_stride [[buffer(27)]],
    constant uint& states_batch_stride [[buffer(28)]],

    uint3 gid [[threadgroup_position_in_grid]],
    uint3 tid [[thread_position_in_threadgroup]],
    uint3 tg_size [[threads_per_threadgroup]])
{
    // Threadgroup shared memory
    threadgroup float2 shared_scan[kNThreads];
    threadgroup float shared_B[MAX_DSTATE];
    threadgroup float shared_C[MAX_DSTATE];

    uint batch_id = gid.x;
    uint dim_id = gid.y;
    uint group_id = dim_id / dim_ngroups_ratio;

    // Variable length handling
    uint seq_start = batch_id;
    uint seq_len = seqlen;
    if (kVarlen && query_start_loc != nullptr) {
        seq_start = query_start_loc[batch_id];
        seq_len = query_start_loc[batch_id + 1] - seq_start;
    }

    uint cache_idx = (cache_indices != nullptr) ? cache_indices[batch_id] : batch_id;
    if (cache_idx == pad_slot_id) return;

    bool use_initial_state = (has_initial_state != nullptr) && has_initial_state[batch_id];

    // Compute pointers
    device const float* u_ptr = u + seq_start * u_batch_stride + dim_id * kNRows;
    device const float* delta_ptr = delta_input + seq_start * delta_batch_stride + dim_id * kNRows;
    device const float* A_ptr = A + dim_id * kNRows * A_d_stride;

    device float* out_ptr = out + seq_start * out_batch_stride + dim_id * kNRows;
    device float* state_ptr = ssm_states + cache_idx * states_batch_stride + dim_id * kNRows * dstate;

    // Load D and delta_bias
    float D_val[kNRows];
    float delta_bias_val[kNRows];

    #pragma unroll
    for (uint r = 0; r < kNRows; ++r) {
        D_val[r] = (D != nullptr) ? D[dim_id * kNRows + r] : 0.0f;
        delta_bias_val[r] = (delta_bias != nullptr) ? delta_bias[dim_id * kNRows + r] : 0.0f;
    }

    // Load B and C into shared memory if not time-varying
    if (tid.x == 0 && tid.y == 0 && !kIsVariableB) {
        for (uint i = 0; i < dstate; ++i) {
            shared_B[i] = B[group_id * dstate + i];
        }
    }
    if (tid.x == 0 && tid.y == 0 && !kIsVariableC) {
        for (uint i = 0; i < dstate; ++i) {
            shared_C[i] = C[group_id * dstate + i];
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Process in chunks
    uint n_chunks = (seq_len + CHUNK_SIZE - 1) / CHUNK_SIZE;

    for (uint chunk = 0; chunk < n_chunks; ++chunk) {
        uint chunk_start = chunk * CHUNK_SIZE;
        uint chunk_size = min(CHUNK_SIZE, seq_len - chunk_start);

        uint thread_offset = tid.x * kNItems;

        if (thread_offset < chunk_size) {
            // Storage for this thread's work
            float u_vals[kNRows][kNItems];
            float delta_vals_raw[kNRows][kNItems];
            float delta_vals[kNRows][kNItems];
            float delta_u[kNRows][kNItems];
            float out_vals[kNRows][kNItems];

            // Load inputs
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                load_input_checked(
                    u_ptr + r + chunk_start,
                    u_vals[r],
                    thread_offset,
                    kNItems,
                    chunk_size
                );
                load_input_checked(
                    delta_ptr + r + chunk_start,
                    delta_vals_raw[r],
                    thread_offset,
                    kNItems,
                    chunk_size
                );
            }

            // Process delta
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                #pragma unroll
                for (uint i = 0; i < kNItems; ++i) {
                    float u_val = u_vals[r][i];
                    delta_vals[r][i] = delta_vals_raw[r][i] + delta_bias_val[r];

                    if (delta_softplus) {
                        delta_vals[r][i] = softplus(delta_vals[r][i]);
                    }

                    delta_u[r][i] = delta_vals[r][i] * u_val;
                    out_vals[r][i] = D_val[r] * u_val;
                }
            }

            // SSM computation
            for (uint state_idx = 0; state_idx < dstate; ++state_idx) {
                float A_val[kNRows];
                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    A_val[r] = A_ptr[state_idx + r * A_d_stride];
                }

                float B_val = kIsVariableB ?
                    B[seq_start * B_batch_stride + group_id * dstate + state_idx] :
                    shared_B[state_idx];

                float C_val = kIsVariableC ?
                    C[seq_start * C_batch_stride + group_id * dstate + state_idx] :
                    shared_C[state_idx];

                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    float state_val = use_initial_state ?
                        state_ptr[r * dstate + state_idx] : 0.0f;

                    #pragma unroll
                    for (uint i = 0; i < kNItems; ++i) {
                        if (thread_offset + i < chunk_size) {
                            float A_discrete = exp(delta_vals[r][i] * A_val[r] * LOG2E);
                            float B_discrete = delta_vals[r][i] * B_val;

                            state_val = A_discrete * state_val + B_discrete * u_vals[r][i];
                            out_vals[r][i] += C_val * state_val;
                        }
                    }

                    if (thread_offset + kNItems - 1 < chunk_size) {
                        state_ptr[r * dstate + state_idx] = state_val;
                    }
                }
            }

            // Apply gating
            if (kHasZ && z != nullptr) {
                float z_vals[kNRows][kNItems];
                #pragma unroll
                for (uint r = 0; r < kNRows; ++r) {
                    load_input_checked(
                        z + seq_start + dim_id * kNRows + r + chunk_start,
                        z_vals[r],
                        thread_offset,
                        kNItems,
                        chunk_size
                    );

                    #pragma unroll
                    for (uint i = 0; i < kNItems; ++i) {
                        out_vals[r][i] *= silu(z_vals[r][i]);
                    }
                }
            }

            // Store outputs
            #pragma unroll
            for (uint r = 0; r < kNRows; ++r) {
                store_output_checked(
                    out_ptr + r + chunk_start,
                    out_vals[r],
                    thread_offset,
                    kNItems,
                    chunk_size
                );
            }
        }

        threadgroup_barrier(mem_flags::mem_device);
    }
}

// ============================================================================
// Kernel Instantiations
// ============================================================================

// FP16 configurations
#define INSTANTIATE_SSM_KERNEL_FP16(THREADS, ITEMS, ROWS, VAR_B, VAR_C, HAS_Z, VARLEN) \
    template [[host_name("selective_scan_fp16_" #THREADS "_" #ITEMS "_" #ROWS "_" #VAR_B #VAR_C #HAS_Z #VARLEN)]] \
    kernel void selective_scan_fwd_fp16<THREADS, ITEMS, ROWS, VAR_B, VAR_C, HAS_Z, VARLEN>

// FP32 configurations
#define INSTANTIATE_SSM_KERNEL_FP32(THREADS, ITEMS, ROWS, VAR_B, VAR_C, HAS_Z, VARLEN) \
    template [[host_name("selective_scan_fp32_" #THREADS "_" #ITEMS "_" #ROWS "_" #VAR_B #VAR_C #HAS_Z #VARLEN)]] \
    kernel void selective_scan_fwd_fp32<THREADS, ITEMS, ROWS, VAR_B, VAR_C, HAS_Z, VARLEN>

// ============================================================================
// FP16 Kernel Instantiations
// ============================================================================

// Standard configurations (128 threads, 8 items, 1 row)
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, false, false, false, false);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, true, false, false, false);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, false, true, false, false);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, true, true, false, false);

// With gating
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, false, false, true, false);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, true, true, true, false);

// Variable length
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, false, false, false, true);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, true, true, false, true);
INSTANTIATE_SSM_KERNEL_FP16(128, 8, 1, true, true, true, true);

// Multi-row configurations (256 threads, 4 items, 2 rows)
INSTANTIATE_SSM_KERNEL_FP16(256, 4, 2, false, false, false, false);
INSTANTIATE_SSM_KERNEL_FP16(256, 4, 2, true, true, false, false);
INSTANTIATE_SSM_KERNEL_FP16(256, 4, 2, true, true, true, false);

// Higher throughput (256 threads, 8 items, 1 row)
INSTANTIATE_SSM_KERNEL_FP16(256, 8, 1, false, false, false, false);
INSTANTIATE_SSM_KERNEL_FP16(256, 8, 1, true, true, false, false);
INSTANTIATE_SSM_KERNEL_FP16(256, 8, 1, true, true, true, false);

// ============================================================================
// FP32 Kernel Instantiations
// ============================================================================

// Standard configurations
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, false, false, false, false);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, true, false, false, false);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, false, true, false, false);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, true, true, false, false);

// With gating
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, false, false, true, false);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, true, true, true, false);

// Variable length
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, false, false, false, true);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, true, true, false, true);
INSTANTIATE_SSM_KERNEL_FP32(128, 8, 1, true, true, true, true);

// Multi-row configurations
INSTANTIATE_SSM_KERNEL_FP32(256, 4, 2, false, false, false, false);
INSTANTIATE_SSM_KERNEL_FP32(256, 4, 2, true, true, false, false);
INSTANTIATE_SSM_KERNEL_FP32(256, 4, 2, true, true, true, false);
