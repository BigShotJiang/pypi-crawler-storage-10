#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Type Conversion Kernels for mlxllm
// Handles conversions between FP32, FP16, BF16, FP8, and INT8
// Optimized for Apple Silicon
// ============================================================================

// ============================================================================
// Float32 <-> Float16 Conversions
// ============================================================================

kernel void fp32_to_fp16_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device half* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = half(input[tid]);
}

kernel void fp16_to_fp32_kernel(
    device const half* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = float(input[tid]);
}

// Vectorized version (4x throughput)
kernel void fp32_to_fp16_kernel_vec4(
    device const float4* __restrict__ input [[buffer(0)]],
    device half4* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    float4 val = input[tid];
    output[tid] = half4(val);
}

kernel void fp16_to_fp32_kernel_vec4(
    device const half4* __restrict__ input [[buffer(0)]],
    device float4* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    half4 val = input[tid];
    output[tid] = float4(val);
}

// ============================================================================
// BFloat16 Conversions
// BFloat16: 1 sign + 8 exp + 7 mantissa (truncated FP32)
// ============================================================================

// Convert FP32 to BFloat16 (stored as uint16)
kernel void fp32_to_bf16_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device ushort* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    // BF16 is FP32 with truncated mantissa
    // Simply take upper 16 bits of FP32
    uint32_t fp32_bits = as_type<uint32_t>(input[tid]);

    // Round to nearest even
    uint32_t rounding_bias = 0x00007FFF + ((fp32_bits >> 16) & 1);
    fp32_bits += rounding_bias;

    output[tid] = ushort(fp32_bits >> 16);
}

// Convert BFloat16 to FP32
kernel void bf16_to_fp32_kernel(
    device const ushort* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    // BF16 to FP32: just shift left 16 bits
    uint32_t fp32_bits = uint32_t(input[tid]) << 16;
    output[tid] = as_type<float>(fp32_bits);
}

// ============================================================================
// FP8 E4M3 Conversions
// E4M3: 1 sign + 4 exp + 3 mantissa, range [-448, 448]
// ============================================================================

kernel void fp32_to_fp8_e4m3_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device uchar* __restrict__ output [[buffer(1)]],
    device float* __restrict__ scale [[buffer(2)]],  // Output scale
    constant uint& n [[buffer(3)]],
    constant float& scale_value [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float value = input[tid];
    const float max_fp8_e4m3 = 448.0f;

    // Scale and clamp
    float scaled = value / scale_value;
    scaled = clamp(scaled, -max_fp8_e4m3, max_fp8_e4m3);

    // Simple quantization (actual FP8 encoding would be more complex)
    // Map [-448, 448] to [0, 255]
    uchar quantized = uchar((scaled + max_fp8_e4m3) * 255.0f / (2.0f * max_fp8_e4m3));
    output[tid] = quantized;

    // Store scale (once)
    if (tid == 0) {
        *scale = scale_value;
    }
}

kernel void fp8_e4m3_to_fp32_kernel(
    device const uchar* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    const float max_fp8_e4m3 = 448.0f;

    // Dequantize from [0, 255] to [-448, 448]
    float dequantized = (float(input[tid]) * (2.0f * max_fp8_e4m3) / 255.0f) - max_fp8_e4m3;

    // Unscale
    output[tid] = dequantized * (*scale);
}

// ============================================================================
// FP8 E5M2 Conversions
// E5M2: 1 sign + 5 exp + 2 mantissa, range [-57344, 57344]
// ============================================================================

kernel void fp32_to_fp8_e5m2_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device uchar* __restrict__ output [[buffer(1)]],
    device float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& scale_value [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float value = input[tid];
    const float max_fp8_e5m2 = 57344.0f;

    float scaled = value / scale_value;
    scaled = clamp(scaled, -max_fp8_e5m2, max_fp8_e5m2);

    uchar quantized = uchar((scaled + max_fp8_e5m2) * 255.0f / (2.0f * max_fp8_e5m2));
    output[tid] = quantized;

    if (tid == 0) {
        *scale = scale_value;
    }
}

kernel void fp8_e5m2_to_fp32_kernel(
    device const uchar* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    const float max_fp8_e5m2 = 57344.0f;

    float dequantized = (float(input[tid]) * (2.0f * max_fp8_e5m2) / 255.0f) - max_fp8_e5m2;
    output[tid] = dequantized * (*scale);
}

// ============================================================================
// INT8 Quantization (Symmetric)
// ============================================================================

kernel void fp32_to_int8_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device char* __restrict__ output [[buffer(1)]],
    device float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& scale_value [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float value = input[tid];
    const float max_int8 = 127.0f;

    // Symmetric quantization
    float scaled = value / scale_value;
    scaled = clamp(scaled, -max_int8, max_int8);

    output[tid] = char(round(scaled));

    if (tid == 0) {
        *scale = scale_value;
    }
}

kernel void int8_to_fp32_kernel(
    device const char* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = float(input[tid]) * (*scale);
}

// ============================================================================
// INT4 Quantization (Packed)
// Two INT4 values per byte
// ============================================================================

kernel void fp32_to_int4_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device uchar* __restrict__ output [[buffer(1)]],  // Packed INT4
    device float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& scale_value [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint pair_idx = tid;
    uint elem_idx = pair_idx * 2;

    if (elem_idx >= n) return;

    const float max_int4 = 7.0f;  // 4-bit signed: -8 to 7

    // Quantize first element
    float val1 = input[elem_idx];
    float scaled1 = val1 / scale_value;
    scaled1 = clamp(scaled1, -8.0f, max_int4);
    char q1 = char(round(scaled1));

    // Quantize second element (if exists)
    char q2 = 0;
    if (elem_idx + 1 < n) {
        float val2 = input[elem_idx + 1];
        float scaled2 = val2 / scale_value;
        scaled2 = clamp(scaled2, -8.0f, max_int4);
        q2 = char(round(scaled2));
    }

    // Pack two 4-bit values into one byte
    uchar packed = (uchar(q1 & 0x0F) << 4) | uchar(q2 & 0x0F);
    output[pair_idx] = packed;

    if (tid == 0) {
        *scale = scale_value;
    }
}

kernel void int4_to_fp32_kernel(
    device const uchar* __restrict__ input [[buffer(0)]],  // Packed INT4
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    uint pair_idx = tid / 2;
    uint offset = tid % 2;

    uchar packed = input[pair_idx];

    // Unpack
    char value;
    if (offset == 0) {
        value = char((packed >> 4) & 0x0F);
        // Sign extend
        if (value & 0x08) value |= 0xF0;
    } else {
        value = char(packed & 0x0F);
        if (value & 0x08) value |= 0xF0;
    }

    output[tid] = float(value) * (*scale);
}

// ============================================================================
// Dynamic Per-Token Quantization
// Computes scale per token/row
// ============================================================================

kernel void fp32_to_int8_per_token_kernel(
    device const float* __restrict__ input [[buffer(0)]],   // [num_tokens, hidden_size]
    device char* __restrict__ output [[buffer(1)]],         // [num_tokens, hidden_size]
    device float* __restrict__ scales [[buffer(2)]],        // [num_tokens]
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_max[256];

    // Find max absolute value for this token
    float local_max = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = abs(input[gid * hidden_size + i]);
        local_max = max(local_max, val);
    }

    shared_max[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Reduce to find global max
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_max[tid] = max(shared_max[tid], shared_max[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Compute scale
    float scale = 1.0f;
    if (tid == 0) {
        float max_val = shared_max[0];
        scale = max_val / 127.0f;
        if (scale == 0.0f) scale = 1.0f;  // Avoid division by zero
        scales[gid] = scale;
        shared_max[0] = scale;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    scale = shared_max[0];

    // Quantize
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx];
        float quantized = round(val / scale);
        quantized = clamp(quantized, -127.0f, 127.0f);
        output[idx] = char(quantized);
    }
}

kernel void int8_to_fp32_per_token_kernel(
    device const char* __restrict__ input [[buffer(0)]],    // [num_tokens, hidden_size]
    device float* __restrict__ output [[buffer(1)]],        // [num_tokens, hidden_size]
    device const float* __restrict__ scales [[buffer(2)]],  // [num_tokens]
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint token_idx = tid / hidden_size;
    uint feature_idx = tid % hidden_size;

    if (token_idx >= num_tokens) return;

    float scale = scales[token_idx];
    output[tid] = float(input[tid]) * scale;
}
