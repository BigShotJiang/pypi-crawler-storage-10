#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Sparse Scaled Matrix Multiplication for mlxllm Metal Backend (M3/M4 Optimized)
// Implements efficient 2:4 sparse GEMM: C = alpha * sparse(A) * B + beta * C
// ============================================================================

// ============================================================================
// Configuration and Constants
// ============================================================================

constant uint TILE_M = 32;
constant uint TILE_N = 32;
constant uint TILE_K = 32;
constant uint SPARSE_GROUP_SIZE = 4;

// ============================================================================
// Metadata Decoding
// ============================================================================

/**
 * @brief Decode 2-bit metadata to get indices of non-zero values
 */
inline uint2 decode_sparse_metadata(uchar metadata, uint group_idx) {
    uint bit_offset = (group_idx % 4) * 2;
    uint packed = (metadata >> bit_offset) & 0x0F;
    uint idx0 = packed & 0x03;
    uint idx1 = (packed >> 2) & 0x03;
    return uint2(idx0, idx1);
}

/**
 * @brief Load sparse values using metadata
 */
inline half2 load_sparse_values_fp16(
    device const half* sparse_data,
    device const uchar* metadata,
    uint row,
    uint k_group,
    uint K_sparse)
{
    uint sparse_offset = row * K_sparse + k_group * 2;
    return half2(sparse_data[sparse_offset], sparse_data[sparse_offset + 1]);
}

inline float2 load_sparse_values_fp32(
    device const float* sparse_data,
    device const uchar* metadata,
    uint row,
    uint k_group,
    uint K_sparse)
{
    uint sparse_offset = row * K_sparse + k_group * 2;
    return float2(sparse_data[sparse_offset], sparse_data[sparse_offset + 1]);
}

// ============================================================================
// FP16 Sparse GEMM - Basic Implementation
// ============================================================================

/**
 * @brief Sparse GEMM: C = alpha * sparse(A) * B + beta * C
 *
 * @param sparse_A_values Compressed A values [M, K/2]
 * @param sparse_A_meta Metadata [M, K/4]
 * @param B Dense matrix B [K, N]
 * @param C Output matrix C [M, N]
 * @param alpha Scale for A*B
 * @param beta Scale for existing C
 * @param M, N, K Matrix dimensions (K must be multiple of 4)
 */
kernel void sparse_gemm_2_4_fp16(
    device const half* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const half* B [[buffer(2)]],
    device half* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    constant uint& N [[buffer(7)]],
    constant uint& K [[buffer(8)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    // Accumulate in FP32 for numerical stability
    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;  // Sparse has 2 values per group of 4

    // Iterate over K dimension in groups of 4
    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        // Load metadata for this group
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        // Decode to get which indices are non-zero
        uint2 indices = decode_sparse_metadata(meta_byte, k_group);
        uint k0 = k_group * 4 + indices.x;
        uint k1 = k_group * 4 + indices.y;

        // Load sparse A values
        half2 a_sparse = load_sparse_values_fp16(sparse_A_values, sparse_A_meta, row, k_group, K_sparse);

        // Load corresponding B values
        half b0 = B[k0 * N + col];
        half b1 = B[k1 * N + col];

        // Accumulate
        acc += float(a_sparse.x) * float(b0);
        acc += float(a_sparse.y) * float(b1);
    }

    // Apply scaling and write result
    uint c_idx = row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * float(C[c_idx]);
    }
    C[c_idx] = half(result);
}

// ============================================================================
// FP16 Sparse GEMM - Tiled Implementation (Optimized for M3/M4)
// ============================================================================

/**
 * @brief Tiled sparse GEMM for better cache locality
 * Uses threadgroup memory for tiling
 */
kernel void sparse_gemm_2_4_fp16_tiled(
    device const half* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const half* B [[buffer(2)]],
    device half* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    constant uint& N [[buffer(7)]],
    constant uint& K [[buffer(8)]],
    uint2 tid [[thread_position_in_threadgroup]],
    uint2 gid [[threadgroup_position_in_grid]],
    uint2 tg_size [[threads_per_threadgroup]])
{
    // Shared memory for tiles
    threadgroup half tile_B[TILE_K][TILE_N];

    // Compute output position
    uint row = gid.y * TILE_M + tid.y;
    uint col = gid.x * TILE_N + tid.x;

    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    // Tile over K dimension
    for (uint k_tile = 0; k_tile < K; k_tile += TILE_K) {
        // Load B tile into threadgroup memory
        for (uint i = tid.y; i < TILE_K; i += tg_size.y) {
            for (uint j = tid.x; j < TILE_N; j += tg_size.x) {
                uint k_idx = k_tile + i;
                uint n_idx = gid.x * TILE_N + j;
                if (k_idx < K && n_idx < N) {
                    tile_B[i][j] = B[k_idx * N + n_idx];
                } else {
                    tile_B[i][j] = half(0.0f);
                }
            }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);

        // Compute partial products
        if (row < M && col < N) {
            uint k_group_start = k_tile / 4;
            uint k_group_end = min(k_group_start + TILE_K / 4, K_groups);

            for (uint k_group = k_group_start; k_group < k_group_end; ++k_group) {
                // Load metadata
                uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
                uchar meta_byte = sparse_A_meta[meta_byte_idx];

                uint2 indices = decode_sparse_metadata(meta_byte, k_group);
                uint local_k0 = (k_group * 4 + indices.x) - k_tile;
                uint local_k1 = (k_group * 4 + indices.y) - k_tile;

                // Load sparse A values
                half2 a_sparse = load_sparse_values_fp16(sparse_A_values, sparse_A_meta, row, k_group, K_sparse);

                // Use tiled B
                if (local_k0 < TILE_K && local_k1 < TILE_K) {
                    half b0 = tile_B[local_k0][tid.x];
                    half b1 = tile_B[local_k1][tid.x];

                    acc += float(a_sparse.x) * float(b0);
                    acc += float(a_sparse.y) * float(b1);
                }
            }
        }

        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Write result
    if (row < M && col < N) {
        uint c_idx = row * N + col;
        float result = alpha * acc;
        if (beta != 0.0f) {
            result += beta * float(C[c_idx]);
        }
        C[c_idx] = half(result);
    }
}

// ============================================================================
// FP32 Sparse GEMM
// ============================================================================

kernel void sparse_gemm_2_4_fp32(
    device const float* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const float* B [[buffer(2)]],
    device float* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    constant uint& N [[buffer(7)]],
    constant uint& K [[buffer(8)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint2 indices = decode_sparse_metadata(meta_byte, k_group);
        uint k0 = k_group * 4 + indices.x;
        uint k1 = k_group * 4 + indices.y;

        float2 a_sparse = load_sparse_values_fp32(sparse_A_values, sparse_A_meta, row, k_group, K_sparse);

        float b0 = B[k0 * N + col];
        float b1 = B[k1 * N + col];

        acc += a_sparse.x * b0 + a_sparse.y * b1;
    }

    uint c_idx = row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * C[c_idx];
    }
    C[c_idx] = result;
}

// ============================================================================
// INT8 Sparse GEMM with Dequantization
// ============================================================================

/**
 * @brief Sparse GEMM with INT8 quantized weights and dynamic dequantization
 */
kernel void sparse_gemm_2_4_int8_dequant(
    device const char* sparse_A_values [[buffer(0)]],   // INT8 quantized
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const char* B [[buffer(2)]],                 // INT8 quantized
    device half* C [[buffer(3)]],                       // FP16 output
    constant float& scale_A [[buffer(4)]],
    constant float& scale_B [[buffer(5)]],
    constant float& alpha [[buffer(6)]],
    constant float& beta [[buffer(7)]],
    constant uint& M [[buffer(8)]],
    constant uint& N [[buffer(9)]],
    constant uint& K [[buffer(10)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint2 indices = decode_sparse_metadata(meta_byte, k_group);
        uint k0 = k_group * 4 + indices.x;
        uint k1 = k_group * 4 + indices.y;

        // Load and dequantize A
        uint sparse_offset = row * K_sparse + k_group * 2;
        float a0 = float(sparse_A_values[sparse_offset + 0]) * scale_A;
        float a1 = float(sparse_A_values[sparse_offset + 1]) * scale_A;

        // Load and dequantize B
        float b0 = float(B[k0 * N + col]) * scale_B;
        float b1 = float(B[k1 * N + col]) * scale_B;

        acc += a0 * b0 + a1 * b1;
    }

    uint c_idx = row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * float(C[c_idx]);
    }
    C[c_idx] = half(result);
}

// ============================================================================
// Batched Sparse GEMM
// ============================================================================

/**
 * @brief Batched sparse GEMM for multiple matrices
 */
kernel void batched_sparse_gemm_2_4_fp16(
    device const half* sparse_A_values [[buffer(0)]],   // [batch, M, K/2]
    device const uchar* sparse_A_meta [[buffer(1)]],    // [batch, M, K/4]
    device const half* B [[buffer(2)]],                 // [batch, K, N]
    device half* C [[buffer(3)]],                       // [batch, M, N]
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& batch_size [[buffer(6)]],
    constant uint& M [[buffer(7)]],
    constant uint& N [[buffer(8)]],
    constant uint& K [[buffer(9)]],
    uint3 gid [[thread_position_in_grid]])
{
    uint batch = gid.z;
    uint row = gid.y;
    uint col = gid.x;

    if (batch >= batch_size || row >= M || col >= N) return;

    // Compute offsets for this batch
    uint A_values_offset = batch * M * (K / 2);
    uint A_meta_offset = batch * M * (K / 4);
    uint B_offset = batch * K * N;
    uint C_offset = batch * M * N;

    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = A_meta_offset + row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint2 indices = decode_sparse_metadata(meta_byte, k_group);
        uint k0 = k_group * 4 + indices.x;
        uint k1 = k_group * 4 + indices.y;

        uint sparse_offset = A_values_offset + row * K_sparse + k_group * 2;
        half2 a_sparse = half2(
            sparse_A_values[sparse_offset],
            sparse_A_values[sparse_offset + 1]
        );

        half b0 = B[B_offset + k0 * N + col];
        half b1 = B[B_offset + k1 * N + col];

        acc += float(a_sparse.x) * float(b0);
        acc += float(a_sparse.y) * float(b1);
    }

    uint c_idx = C_offset + row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * float(C[c_idx]);
    }
    C[c_idx] = half(result);
}

// ============================================================================
// SIMD-Optimized Sparse GEMM (M3/M4 Pro/Max)
// ============================================================================

/**
 * @brief SIMD-optimized sparse GEMM using wider SIMD operations
 * Optimized for Apple M3/M4 Pro/Max with enhanced SIMD capabilities
 */
kernel void sparse_gemm_2_4_fp16_simd(
    device const half* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const half* B [[buffer(2)]],
    device half* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    constant uint& N [[buffer(7)]],
    constant uint& K [[buffer(8)]],
    uint2 gid [[thread_position_in_grid]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]])
{
    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    float acc = 0.0f;

    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    // Unroll loop for better instruction-level parallelism
    #pragma unroll 4
    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint2 indices = decode_sparse_metadata(meta_byte, k_group);
        uint k0 = k_group * 4 + indices.x;
        uint k1 = k_group * 4 + indices.y;

        half2 a_sparse = load_sparse_values_fp16(sparse_A_values, sparse_A_meta, row, k_group, K_sparse);

        half b0 = B[k0 * N + col];
        half b1 = B[k1 * N + col];

        // Fused multiply-add
        acc = fma(float(a_sparse.x), float(b0), acc);
        acc = fma(float(a_sparse.y), float(b1), acc);
    }

    // SIMD reduction across lanes if needed
    // (For now, direct output)

    uint c_idx = row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * float(C[c_idx]);
    }
    C[c_idx] = half(result);
}
