#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Sparse Scaled Matrix Multiplication Entry Point
// Dispatcher for sparse GEMM variants based on dimensions and data types
// ============================================================================

// ============================================================================
// External Kernel Declarations (from sparse_scaled_mm_c3x.metal)
// ============================================================================

// Basic kernels
kernel void sparse_gemm_2_4_fp16(
    device const half*, device const uchar*, device const half*, device half*,
    constant float&, constant float&, constant uint&, constant uint&, constant uint&,
    uint2);

kernel void sparse_gemm_2_4_fp32(
    device const float*, device const uchar*, device const float*, device float*,
    constant float&, constant float&, constant uint&, constant uint&, constant uint&,
    uint2);

// Optimized kernels
kernel void sparse_gemm_2_4_fp16_tiled(
    device const half*, device const uchar*, device const half*, device half*,
    constant float&, constant float&, constant uint&, constant uint&, constant uint&,
    uint2, uint2, uint2);

kernel void sparse_gemm_2_4_fp16_simd(
    device const half*, device const uchar*, device const half*, device half*,
    constant float&, constant float&, constant uint&, constant uint&, constant uint&,
    uint2, uint, uint);

kernel void sparse_gemm_2_4_int8_dequant(
    device const char*, device const uchar*, device const char*, device half*,
    constant float&, constant float&, constant float&, constant float&,
    constant uint&, constant uint&, constant uint&,
    uint2);

kernel void batched_sparse_gemm_2_4_fp16(
    device const half*, device const uchar*, device const half*, device half*,
    constant float&, constant float&, constant uint&, constant uint&, constant uint&, constant uint&,
    uint3);

// ============================================================================
// Kernel Selection Constants
// ============================================================================

constant uint SMALL_M_THRESHOLD = 64;
constant uint MEDIUM_M_THRESHOLD = 256;
constant uint LARGE_M_THRESHOLD = 1024;

constant uint SMALL_N_THRESHOLD = 1024;
constant uint MEDIUM_N_THRESHOLD = 4096;
constant uint LARGE_N_THRESHOLD = 8192;

constant uint TILED_MIN_SIZE = 128;
constant uint SIMD_MIN_SIZE = 512;

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * @brief Compute next power of 2
 */
inline uint next_pow_2(uint x) {
    x--;
    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    x |= x >> 8;
    x |= x >> 16;
    x++;
    return x;
}

/**
 * @brief Select optimal kernel based on matrix dimensions
 */
enum class KernelVariant : uint {
    BASIC_FP16 = 0,
    BASIC_FP32 = 1,
    TILED_FP16 = 2,
    SIMD_FP16 = 3,
    INT8_DEQUANT = 4,
    BATCHED_FP16 = 5
};

/**
 * @brief Heuristic for kernel selection
 */
inline KernelVariant select_kernel_variant(
    uint M, uint N, uint K,
    bool is_fp32, bool is_int8, bool is_batched)
{
    if (is_batched) {
        return KernelVariant::BATCHED_FP16;
    }

    if (is_int8) {
        return KernelVariant::INT8_DEQUANT;
    }

    if (is_fp32) {
        return KernelVariant::BASIC_FP32;
    }

    // FP16 kernel selection based on size
    uint mp2 = max(uint(64), next_pow_2(M));

    // Large matrices: use SIMD-optimized kernel
    if (M >= SIMD_MIN_SIZE && N >= SIMD_MIN_SIZE) {
        return KernelVariant::SIMD_FP16;
    }

    // Medium matrices: use tiled kernel
    if (M >= TILED_MIN_SIZE || N >= TILED_MIN_SIZE) {
        return KernelVariant::TILED_FP16;
    }

    // Small matrices: use basic kernel
    return KernelVariant::BASIC_FP16;
}

// ============================================================================
// Configuration Structure
// ============================================================================

struct SparseGemmConfig {
    uint M;
    uint N;
    uint K;
    float alpha;
    float beta;
    uint dtype;         // 0: FP16, 1: FP32, 2: INT8
    uint variant;       // Kernel variant
    bool is_batched;
    uint batch_size;
};

// ============================================================================
// Metadata Computation
// ============================================================================

/**
 * @brief Compute grid size for kernel launch
 */
inline uint3 compute_grid_size(uint M, uint N, uint batch_size, KernelVariant variant) {
    switch (variant) {
        case KernelVariant::TILED_FP16:
            return uint3((N + 31) / 32, (M + 31) / 32, 1);
        case KernelVariant::BATCHED_FP16:
            return uint3(N, M, batch_size);
        default:
            return uint3(N, M, 1);
    }
}

/**
 * @brief Compute threadgroup size
 */
inline uint3 compute_threadgroup_size(KernelVariant variant) {
    switch (variant) {
        case KernelVariant::TILED_FP16:
            return uint3(32, 32, 1);
        case KernelVariant::SIMD_FP16:
            return uint3(32, 8, 1);  // Wider SIMD groups
        default:
            return uint3(1, 1, 1);
    }
}

// ============================================================================
// Dispatch Entry Point
// ============================================================================

/**
 * @brief Main dispatch kernel - selects and launches appropriate sparse GEMM variant
 *
 * This is a meta-kernel that determines which specialized kernel to use.
 * In practice, this logic would be on the CPU side in PyTorch bindings.
 */
kernel void sparse_gemm_dispatch(
    device const void* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const void* B [[buffer(2)]],
    device void* C [[buffer(3)]],
    constant SparseGemmConfig& config [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]],
    uint tid [[thread_index_in_threadgroup]])
{
    // Dispatch based on variant
    // Note: In real implementation, this would be handled on CPU side
    // by selecting the appropriate kernel at command buffer encoding time

    if (tid == 0 && gid.x == 0 && gid.y == 0 && gid.z == 0) {
        // This is a placeholder - actual dispatching happens CPU-side
        // Here we just validate configuration
        
        bool valid = true;
        
        // Validate dimensions
        if (config.M == 0 || config.N == 0 || config.K == 0) {
            valid = false;
        }
        
        // Validate K is multiple of 4 (2:4 sparsity requirement)
        if (config.K % 4 != 0) {
            valid = false;
        }
        
        // Validate dtype
        if (config.dtype > 2) {
            valid = false;
        }
        
        // Store validation result (in real code, would throw exception)
        // For now, no-op
    }
}

// ============================================================================
// Specialized Entry Points for Common Sizes
// ============================================================================

/**
 * @brief Fast path for common Llama-style dimensions
 */
kernel void sparse_gemm_llama_4096(
    device const half* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const half* B [[buffer(2)]],
    device half* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    uint2 gid [[thread_position_in_grid]],
    uint tid [[thread_index_in_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]])
{
    // Specialized for N=4096, K=4096 (common in Llama 7B/13B)
    constant uint N = 4096;
    constant uint K = 4096;

    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    float acc = 0.0f;
    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    #pragma unroll 8
    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint bit_offset = (k_group % 4) * 2;
        uint packed = (meta_byte >> bit_offset) & 0x0F;
        uint idx0 = packed & 0x03;
        uint idx1 = (packed >> 2) & 0x03;

        uint k0 = k_group * 4 + idx0;
        uint k1 = k_group * 4 + idx1;

        uint sparse_offset = row * K_sparse + k_group * 2;
        half a0 = sparse_A_values[sparse_offset];
        half a1 = sparse_A_values[sparse_offset + 1];

        half b0 = B[k0 * N + col];
        half b1 = B[k1 * N + col];

        acc = fma(float(a0), float(b0), acc);
        acc = fma(float(a1), float(b1), acc);
    }

    uint c_idx = row * N + col;
    float result = alpha * acc;
    if (beta != 0.0f) {
        result += beta * float(C[c_idx]);
    }
    C[c_idx] = half(result);
}

/**
 * @brief Fast path for small batch inference (M <= 64)
 */
kernel void sparse_gemm_small_batch(
    device const half* sparse_A_values [[buffer(0)]],
    device const uchar* sparse_A_meta [[buffer(1)]],
    device const half* B [[buffer(2)]],
    device half* C [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& beta [[buffer(5)]],
    constant uint& M [[buffer(6)]],
    constant uint& N [[buffer(7)]],
    constant uint& K [[buffer(8)]],
    uint2 gid [[thread_position_in_grid]])
{
    // Optimized for small M (common in inference with batch_size=1 to 64)
    uint row = gid.y;
    uint col = gid.x;

    if (row >= M || col >= N) return;

    float acc = 0.0f;
    uint K_groups = K / 4;
    uint K_sparse = K / 2;

    // Fully unrolled for small K
    #pragma unroll 16
    for (uint k_group = 0; k_group < K_groups; ++k_group) {
        uint meta_byte_idx = row * (K / 4) / 4 + k_group / 4;
        uchar meta_byte = sparse_A_meta[meta_byte_idx];

        uint bit_offset = (k_group % 4) * 2;
        uint packed = (meta_byte >> bit_offset) & 0x0F;

        uint k0 = k_group * 4 + (packed & 0x03);
        uint k1 = k_group * 4 + ((packed >> 2) & 0x03);

        uint sparse_offset = row * K_sparse + k_group * 2;

        acc += float(sparse_A_values[sparse_offset]) * float(B[k0 * N + col]);
        acc += float(sparse_A_values[sparse_offset + 1]) * float(B[k1 * N + col]);
    }

    uint c_idx = row * N + col;
    C[c_idx] = half(alpha * acc + (beta != 0.0f ? beta * float(C[c_idx]) : 0.0f));
}

// ============================================================================
// Utility: Compute Effective Sparsity
// ============================================================================

/**
 * @brief Verify that matrix has valid 2:4 sparsity pattern
 */
kernel void verify_24_sparsity(
    device const uchar* metadata [[buffer(0)]],
    device atomic_uint* valid_count [[buffer(1)]],
    device atomic_uint* total_count [[buffer(2)]],
    constant uint& num_groups [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= num_groups) return;

    uchar meta_byte = metadata[gid / 4];
    uint bit_offset = (gid % 4) * 2;
    uint packed = (meta_byte >> bit_offset) & 0x0F;

    // Check that packed value is valid (0-15)
    // and represents 2 distinct indices in 0-3 range
    uint idx0 = packed & 0x03;
    uint idx1 = (packed >> 2) & 0x03;

    if (idx0 != idx1 && idx0 < 4 && idx1 < 4) {
        atomic_fetch_add_explicit(valid_count, 1, memory_order_relaxed);
    }
    atomic_fetch_add_explicit(total_count, 1, memory_order_relaxed);
}
