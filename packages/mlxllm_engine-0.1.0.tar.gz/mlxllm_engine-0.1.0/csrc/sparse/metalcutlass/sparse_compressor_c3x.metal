#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Sparse Matrix Compressor for mlxllm Metal Backend (Apple Silicon M3/M4)
// Implements 2:4 structured sparsity compression
// ============================================================================

// ============================================================================
// Constants and Configuration
// ============================================================================

constant uint SPARSE_GROUP_SIZE = 4;     // 2:4 sparsity: 2 non-zero per 4 elements
constant uint SPARSE_NONZERO_PER_GROUP = 2;
constant uint METADATA_BITS_PER_GROUP = 2;  // 2 bits to encode which 2 of 4

// ============================================================================
// Helper Functions for 2:4 Sparsity
// ============================================================================

/**
 * @brief Find indices of 2 largest absolute values in a group of 4
 * @return packed uint with indices (2 bits each: 0b0000_00yy_xxxx)
 */
inline uint find_top2_indices_fp16(half4 values) {
    float4 abs_vals = float4(abs(values));

    // Find max
    float max_val = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint max_idx = 0;
    if (abs_vals.y == max_val) max_idx = 1;
    else if (abs_vals.z == max_val) max_idx = 2;
    else if (abs_vals.w == max_val) max_idx = 3;

    // Zero out max to find second max
    abs_vals[max_idx] = -INFINITY;
    float second_max = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint second_idx = 0;
    if (abs_vals.y == second_max) second_idx = 1;
    else if (abs_vals.z == second_max) second_idx = 2;
    else if (abs_vals.w == second_max) second_idx = 3;

    // Pack indices (smaller index in lower 2 bits)
    uint idx0 = min(max_idx, second_idx);
    uint idx1 = max(max_idx, second_idx);
    return (idx1 << 2) | idx0;
}

inline uint find_top2_indices_fp32(float4 values) {
    float4 abs_vals = abs(values);

    float max_val = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint max_idx = 0;
    if (abs_vals.y == max_val) max_idx = 1;
    else if (abs_vals.z == max_val) max_idx = 2;
    else if (abs_vals.w == max_val) max_idx = 3;

    abs_vals[max_idx] = -INFINITY;
    float second_max = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint second_idx = 0;
    if (abs_vals.y == second_max) second_idx = 1;
    else if (abs_vals.z == second_max) second_idx = 2;
    else if (abs_vals.w == second_max) second_idx = 3;

    uint idx0 = min(max_idx, second_idx);
    uint idx1 = max(max_idx, second_idx);
    return (idx1 << 2) | idx0;
}

/**
 * @brief Extract 2 non-zero values based on metadata indices
 */
inline half2 extract_sparse_values_fp16(half4 dense, uint metadata) {
    uint idx0 = metadata & 0x03;
    uint idx1 = (metadata >> 2) & 0x03;
    return half2(dense[idx0], dense[idx1]);
}

inline float2 extract_sparse_values_fp32(float4 dense, uint metadata) {
    uint idx0 = metadata & 0x03;
    uint idx1 = (metadata >> 2) & 0x03;
    return float2(dense[idx0], dense[idx1]);
}

// ============================================================================
// FP16 2:4 Sparse Compression
// ============================================================================

/**
 * @brief Compress dense FP16 matrix to 2:4 sparse format
 *
 * For every 4 consecutive elements in a row, keep the 2 with largest magnitude.
 *
 * @param dense_weights Dense weight matrix [M, N]
 * @param sparse_values Output sparse values [M, N/2]
 * @param metadata Output metadata (2 bits per group of 4) [M, N/4]
 * @param M Number of rows
 * @param N Number of columns (must be multiple of 4)
 */
kernel void compress_2_4_sparse_fp16(
    device const half* dense_weights [[buffer(0)]],    // [M, N]
    device half* sparse_values [[buffer(1)]],          // [M, N/2]
    device uchar* metadata [[buffer(2)]],              // [M, N/4] packed 2-bit indices
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint group_col = gid.x;  // Each thread processes one group of 4

    if (row >= M || group_col >= (N / 4)) return;

    // Load 4 dense values
    uint dense_offset = row * N + group_col * 4;
    half4 dense_vals = half4(
        dense_weights[dense_offset + 0],
        dense_weights[dense_offset + 1],
        dense_weights[dense_offset + 2],
        dense_weights[dense_offset + 3]
    );

    // Find top 2 indices
    uint meta = find_top2_indices_fp16(dense_vals);

    // Extract sparse values
    half2 sparse = extract_sparse_values_fp16(dense_vals, meta);

    // Store sparse values (2 per group)
    uint sparse_offset = row * (N / 2) + group_col * 2;
    sparse_values[sparse_offset + 0] = sparse.x;
    sparse_values[sparse_offset + 1] = sparse.y;

    // Store metadata (pack 4 groups into 1 byte, so each group gets 2 bits)
    uint meta_byte_idx = row * (N / 4) / 4 + group_col / 4;
    uint meta_bit_offset = (group_col % 4) * 2;

    // Atomic OR to pack multiple groups into same byte
    // Note: This is simplified; production code would use proper packing
    device atomic_uint* atomic_meta = (device atomic_uint*)(metadata + meta_byte_idx);
    atomic_fetch_or_explicit(atomic_meta, (meta << meta_bit_offset), memory_order_relaxed);
}

// ============================================================================
// FP32 2:4 Sparse Compression
// ============================================================================

kernel void compress_2_4_sparse_fp32(
    device const float* dense_weights [[buffer(0)]],
    device float* sparse_values [[buffer(1)]],
    device uchar* metadata [[buffer(2)]],
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint group_col = gid.x;

    if (row >= M || group_col >= (N / 4)) return;

    uint dense_offset = row * N + group_col * 4;
    float4 dense_vals = float4(
        dense_weights[dense_offset + 0],
        dense_weights[dense_offset + 1],
        dense_weights[dense_offset + 2],
        dense_weights[dense_offset + 3]
    );

    uint meta = find_top2_indices_fp32(dense_vals);
    float2 sparse = extract_sparse_values_fp32(dense_vals, meta);

    uint sparse_offset = row * (N / 2) + group_col * 2;
    sparse_values[sparse_offset + 0] = sparse.x;
    sparse_values[sparse_offset + 1] = sparse.y;

    uint meta_byte_idx = row * (N / 4) / 4 + group_col / 4;
    uint meta_bit_offset = (group_col % 4) * 2;

    device atomic_uint* atomic_meta = (device atomic_uint*)(metadata + meta_byte_idx);
    atomic_fetch_or_explicit(atomic_meta, (meta << meta_bit_offset), memory_order_relaxed);
}

// ============================================================================
// INT8 Quantized 2:4 Sparse Compression
// ============================================================================

kernel void compress_2_4_sparse_int8(
    device const char* dense_weights [[buffer(0)]],
    device char* sparse_values [[buffer(1)]],
    device uchar* metadata [[buffer(2)]],
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint group_col = gid.x;

    if (row >= M || group_col >= (N / 4)) return;

    uint dense_offset = row * N + group_col * 4;
    char4 dense_vals = char4(
        dense_weights[dense_offset + 0],
        dense_weights[dense_offset + 1],
        dense_weights[dense_offset + 2],
        dense_weights[dense_offset + 3]
    );

    // Convert to float for comparison
    float4 abs_vals = float4(abs(dense_vals));

    float max_val = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint max_idx = 0;
    if (abs_vals.y == max_val) max_idx = 1;
    else if (abs_vals.z == max_val) max_idx = 2;
    else if (abs_vals.w == max_val) max_idx = 3;

    abs_vals[max_idx] = -INFINITY;
    float second_max = max(max(abs_vals.x, abs_vals.y), max(abs_vals.z, abs_vals.w));
    uint second_idx = 0;
    if (abs_vals.y == second_max) second_idx = 1;
    else if (abs_vals.z == second_max) second_idx = 2;
    else if (abs_vals.w == second_max) second_idx = 3;

    uint idx0 = min(max_idx, second_idx);
    uint idx1 = max(max_idx, second_idx);
    uint meta = (idx1 << 2) | idx0;

    uint sparse_offset = row * (N / 2) + group_col * 2;
    sparse_values[sparse_offset + 0] = dense_vals[idx0];
    sparse_values[sparse_offset + 1] = dense_vals[idx1];

    uint meta_byte_idx = row * (N / 4) / 4 + group_col / 4;
    uint meta_bit_offset = (group_col % 4) * 2;

    device atomic_uint* atomic_meta = (device atomic_uint*)(metadata + meta_byte_idx);
    atomic_fetch_or_explicit(atomic_meta, (meta << meta_bit_offset), memory_order_relaxed);
}

// ============================================================================
// Decompression (for testing/debugging)
// ============================================================================

/**
 * @brief Decompress sparse representation back to dense
 */
kernel void decompress_2_4_sparse_fp16(
    device const half* sparse_values [[buffer(0)]],
    device const uchar* metadata [[buffer(1)]],
    device half* dense_output [[buffer(2)]],
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint group_col = gid.x;

    if (row >= M || group_col >= (N / 4)) return;

    // Load metadata
    uint meta_byte_idx = row * (N / 4) / 4 + group_col / 4;
    uint meta_bit_offset = (group_col % 4) * 2;
    uchar meta_byte = metadata[meta_byte_idx];
    uint meta = (meta_byte >> meta_bit_offset) & 0x03;

    // Load sparse values
    uint sparse_offset = row * (N / 2) + group_col * 2;
    half val0 = sparse_values[sparse_offset + 0];
    half val1 = sparse_values[sparse_offset + 1];

    // Reconstruct dense group
    uint idx0 = meta & 0x03;
    uint idx1 = (meta >> 2) & 0x03;

    uint dense_offset = row * N + group_col * 4;

    // Zero-fill
    dense_output[dense_offset + 0] = half(0.0f);
    dense_output[dense_offset + 1] = half(0.0f);
    dense_output[dense_offset + 2] = half(0.0f);
    dense_output[dense_offset + 3] = half(0.0f);

    // Place non-zero values
    dense_output[dense_offset + idx0] = val0;
    dense_output[dense_offset + idx1] = val1;
}

// ============================================================================
// Metadata Extraction Utilities
// ============================================================================

/**
 * @brief Extract metadata for a specific group
 */
inline uint extract_metadata(device const uchar* metadata, uint row, uint group_col, uint N) {
    uint meta_byte_idx = row * (N / 4) / 4 + group_col / 4;
    uint meta_bit_offset = (group_col % 4) * 2;
    uchar meta_byte = metadata[meta_byte_idx];
    return (meta_byte >> meta_bit_offset) & 0x0F;  // 4 bits for 2 indices
}

/**
 * @brief Compute sparsity ratio
 */
kernel void compute_sparsity_ratio(
    device const half* dense_weights [[buffer(0)]],
    device atomic_uint* zero_count [[buffer(1)]],
    device atomic_uint* total_count [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;

    if (dense_weights[gid] == half(0.0f)) {
        atomic_fetch_add_explicit(zero_count, 1, memory_order_relaxed);
    }
    atomic_fetch_add_explicit(total_count, 1, memory_order_relaxed);
}

// ============================================================================
// Optimized Vectorized Compression (M3/M4)
// ============================================================================

/**
 * @brief Vectorized compression using SIMD
 * Optimized for Apple Silicon M3/M4 with wider SIMD
 */
kernel void compress_2_4_sparse_fp16_vectorized(
    device const half* dense_weights [[buffer(0)]],
    device half* sparse_values [[buffer(1)]],
    device uchar* metadata [[buffer(2)]],
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint2 gid [[thread_position_in_grid]],
    uint simd_lane_id [[thread_index_in_simdgroup]])
{
    uint row = gid.y;
    uint group_col_base = gid.x * 4;  // Process 4 groups (16 elements) per thread

    if (row >= M || group_col_base >= (N / 4)) return;

    // Process 4 groups in parallel using SIMD
    for (uint i = 0; i < 4; ++i) {
        uint group_col = group_col_base + i;
        if (group_col >= (N / 4)) break;

        uint dense_offset = row * N + group_col * 4;
        half4 dense_vals = half4(
            dense_weights[dense_offset + 0],
            dense_weights[dense_offset + 1],
            dense_weights[dense_offset + 2],
            dense_weights[dense_offset + 3]
        );

        uint meta = find_top2_indices_fp16(dense_vals);
        half2 sparse = extract_sparse_values_fp16(dense_vals, meta);

        uint sparse_offset = row * (N / 2) + group_col * 2;
        sparse_values[sparse_offset + 0] = sparse.x;
        sparse_values[sparse_offset + 1] = sparse.y;

        // Store metadata (simplified)
        uint meta_idx = row * (N / 4) + group_col;
        metadata[meta_idx] = uchar(meta);
    }
}
