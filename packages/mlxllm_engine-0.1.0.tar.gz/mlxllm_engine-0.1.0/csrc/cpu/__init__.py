"""CPU Fallback Operations Module for MLX-LLM.

Provides CPU implementations of operations as fallbacks when Metal is unavailable.
"""

from typing import Optional

try:
    from . import _cpu_ops  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

if _EXTENSION_AVAILABLE:
    from ._cpu_ops import (
        # Helper
        is_cpu_tensor, ensure_cpu,
        # Attention
        paged_attention_v1, rms_norm, silu_and_mul, gelu_and_mul, rotary_embedding,
        # Cache
        reshape_and_cache, copy_blocks, swap_blocks,
        # Quantization
        quantize_fp8, dequantize_fp8,
        # Sampling
        top_k_sampling, greedy_sampling,
        # DNNL
        is_dnnl_available, get_dnnl_version,
        # Performance
        get_num_threads, set_num_threads,
    )
    __all__ = [
        'is_cpu_tensor', 'ensure_cpu',
        'paged_attention_v1', 'rms_norm', 'silu_and_mul', 'gelu_and_mul', 'rotary_embedding',
        'reshape_and_cache', 'copy_blocks', 'swap_blocks',
        'quantize_fp8', 'dequantize_fp8',
        'top_k_sampling', 'greedy_sampling',
        'is_dnnl_available', 'get_dnnl_version',
        'get_num_threads', 'set_num_threads',
        'is_available',
    ]
else:
    def _unavailable(*args, **kwargs):
        raise RuntimeError(f"CPU extension not available: {_IMPORT_ERROR}")

    is_cpu_tensor = ensure_cpu = _unavailable
    paged_attention_v1 = rms_norm = silu_and_mul = gelu_and_mul = rotary_embedding = _unavailable
    reshape_and_cache = copy_blocks = swap_blocks = _unavailable
    quantize_fp8 = dequantize_fp8 = _unavailable
    top_k_sampling = greedy_sampling = _unavailable
    is_dnnl_available = get_dnnl_version = _unavailable
    get_num_threads = set_num_threads = _unavailable
    __all__ = ['is_available']

def is_available() -> bool:
    return _EXTENSION_AVAILABLE

__version__ = "0.1.0"
__backend__ = "CPU" if _EXTENSION_AVAILABLE else "None"
