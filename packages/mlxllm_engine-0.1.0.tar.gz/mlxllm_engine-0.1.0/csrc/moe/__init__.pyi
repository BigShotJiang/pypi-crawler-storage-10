"""Type stubs for csrc.moe module."""

from typing import Optional, Tuple
import torch

# Routing operations
def moe_topk_softmax(
    topk_weights: torch.Tensor,
    topk_indices: torch.Tensor,
    token_expert_indices: torch.Tensor,
    gating_output: torch.Tensor,
    renormalize: bool,
) -> None: ...

def moe_grouped_topk(
    scores: torch.Tensor,
    scores_with_bias: torch.Tensor,
    n_group: int,
    topk_group: int,
    topk: int,
    renormalize: bool,
    routed_scaling_factor: float,
) -> Tuple[torch.Tensor, torch.Tensor]: ...

# Permutation operations
def moe_permute(
    input: torch.Tensor,
    topk_ids: torch.Tensor,
    token_expert_indices: torch.Tensor,
    expert_map: Optional[torch.Tensor],
    n_expert: int,
    n_local_expert: int,
    topk: int,
    align_block_size: Optional[int],
    permuted_input: torch.Tensor,
    expert_first_token_offset: torch.Tensor,
    inv_permuted_idx: torch.Tensor,
    permuted_idx: torch.Tensor,
    m_indices: torch.Tensor,
) -> None: ...

def moe_unpermute(
    permuted_hidden_states: torch.Tensor,
    topk_weights: torch.Tensor,
    inv_permuted_idx: torch.Tensor,
    expert_first_token_offset: Optional[torch.Tensor],
    topk: int,
    hidden_states: torch.Tensor,
) -> None: ...

def moe_shuffle_rows(
    input_tensor: torch.Tensor,
    dst2src_map: torch.Tensor,
    output_tensor: torch.Tensor,
) -> None: ...

# Alignment operations
def moe_align_block_size(
    topk_ids: torch.Tensor,
    num_experts: int,
    block_size: int,
    sorted_token_ids: torch.Tensor,
    experts_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None: ...

def moe_batched_align_block_size(
    max_tokens_per_batch: int,
    block_size: int,
    expert_num_tokens: torch.Tensor,
    sorted_token_ids: torch.Tensor,
    experts_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None: ...

def moe_lora_align_block_size(
    topk_ids: torch.Tensor,
    token_lora_mapping: torch.Tensor,
    num_experts: int,
    block_size: int,
    max_loras: int,
    max_num_tokens_padded: int,
    max_num_m_blocks: int,
    sorted_token_ids: torch.Tensor,
    experts_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
) -> None: ...

# Reduction operations
def moe_sum(input: torch.Tensor, output: torch.Tensor) -> None: ...

# Quantized operations
def moe_wna16_gemm(
    input: torch.Tensor,
    output: torch.Tensor,
    b_qweight: torch.Tensor,
    b_scales: torch.Tensor,
    b_qzeros: Optional[torch.Tensor],
    topk_weights: Optional[torch.Tensor],
    sorted_token_ids: torch.Tensor,
    expert_ids: torch.Tensor,
    num_tokens_post_pad: torch.Tensor,
    top_k: int,
    BLOCK_SIZE_M: int,
    BLOCK_SIZE_N: int,
    BLOCK_SIZE_K: int,
    bit: int,
) -> torch.Tensor: ...

# Utilities
def moe_permute_unpermute_supported() -> bool: ...
def is_available() -> bool: ...

__version__: str
__backend__: str
