"""Mixture of Experts (MoE) Operations Module for MLX-LLM.

Provides Metal-optimized MoE operations including routing, permutation,
alignment, and quantized GEMM operations.
"""

from typing import Optional

try:
    from . import _moe_ops  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

if _EXTENSION_AVAILABLE:
    from ._moe_ops import (
        # Routing
        moe_topk_softmax,
        moe_grouped_topk,
        # Permutation
        moe_permute,
        moe_unpermute,
        moe_shuffle_rows,
        # Alignment
        moe_align_block_size,
        moe_batched_align_block_size,
        moe_lora_align_block_size,
        # Reduction
        moe_sum,
        # Quantized ops
        moe_wna16_gemm,
        # Utilities
        moe_permute_unpermute_supported,
    )
    __all__ = [
        'moe_topk_softmax', 'moe_grouped_topk',
        'moe_permute', 'moe_unpermute', 'moe_shuffle_rows',
        'moe_align_block_size', 'moe_batched_align_block_size', 'moe_lora_align_block_size',
        'moe_sum',
        'moe_wna16_gemm',
        'moe_permute_unpermute_supported',
        'is_available',
    ]
else:
    def _unavailable(*args, **kwargs):
        raise RuntimeError(f"MoE extension not available: {_IMPORT_ERROR}")

    moe_topk_softmax = moe_grouped_topk = _unavailable
    moe_permute = moe_unpermute = moe_shuffle_rows = _unavailable
    moe_align_block_size = moe_batched_align_block_size = moe_lora_align_block_size = _unavailable
    moe_sum = _unavailable
    moe_wna16_gemm = _unavailable
    moe_permute_unpermute_supported = _unavailable
    __all__ = ['is_available']

def is_available() -> bool:
    return _EXTENSION_AVAILABLE

__version__ = "0.1.0"
__backend__ = "Metal" if _EXTENSION_AVAILABLE else "None"
