#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Metal Shaders for MoE Permute/Unpermute Operations
// GPU kernels for Apple Silicon optimized token routing and permutation
// ============================================================================

// ============================================================================
// Constants and Helpers
// ============================================================================

constant int SIMD_WIDTH = 32;          // Metal SIMD group size
constant int THREADGROUP_SIZE = 256;   // Threads per threadgroup
constant int ELEMENTS_PER_THREAD = 4;  // 128-bit loads (4 x float32)

// ============================================================================
// Expand and Permute Input Rows (Float32)
// ============================================================================

/**
 * Expand input tokens by top-k factor and permute by expert assignment
 * Each input token is replicated k times and tokens for the same expert
 * are grouped together for efficient batched processing.
 */
kernel void moe_expand_input_rows_float(
    device const float* unpermuted_input [[buffer(0)]],
    device float* permuted_output [[buffer(1)]],
    device int* sorted_experts [[buffer(2)]],
    device const int* expanded_dest_row_to_expanded_source_row [[buffer(3)]],
    device int* expanded_source_row_to_expanded_dest_row [[buffer(4)]],
    device int* permuted_idx [[buffer(5)]],
    device const int64_t* expert_first_token_offset [[buffer(6)]],
    constant int64_t& num_rows [[buffer(7)]],
    device const int64_t* num_valid_tokens_ptr [[buffer(8)]],
    constant int64_t& cols [[buffer(9)]],
    constant int& k [[buffer(10)]],
    constant int& num_local_experts [[buffer(11)]],
    constant int& align_block_size [[buffer(12)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint3 thread_position_in_threadgroup [[thread_position_in_threadgroup]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  // Threadgroup-shared memory for expert token offsets
  threadgroup int64_t shared_expert_offsets[256];  // Max 256 local experts

  uint expanded_dest_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;

  // Load expert first token offsets into shared memory
  if (align_block_size > 0 && tid < (num_local_experts + 1)) {
    shared_expert_offsets[tid] = expert_first_token_offset[tid];
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);

  // Get source row and expert ID
  int64_t expanded_source_row = expanded_dest_row_to_expanded_source_row[expanded_dest_row];
  int expert_id = sorted_experts[expanded_dest_row];

  // Compute aligned destination row if block alignment is enabled
  int64_t final_dest_row = expanded_dest_row;
  if (align_block_size > 0) {
    // Calculate token offset within expert
    int64_t token_offset_in_expert = 0;
    if (expert_id < num_local_experts) {
      token_offset_in_expert = expanded_dest_row - shared_expert_offsets[expert_id];

      // Accumulate alignment offsets from previous experts
      int64_t accumulate_align_offset = 0;
      for (int eidx = 1; eidx <= expert_id; eidx++) {
        int64_t n_token_in_expert =
            shared_expert_offsets[eidx] - shared_expert_offsets[eidx - 1];
        accumulate_align_offset +=
            ((n_token_in_expert + align_block_size - 1) / align_block_size) * align_block_size;
      }
      final_dest_row = accumulate_align_offset + token_offset_in_expert;
    }
  }

  // Thread 0 updates permutation indices
  if (tid == 0) {
    expanded_source_row_to_expanded_dest_row[expanded_source_row] = (int)final_dest_row;
    if (expanded_dest_row < *num_valid_tokens_ptr) {
      permuted_idx[final_dest_row] = (int)expanded_source_row;
    }
  }

  // Skip if beyond valid tokens
  if (expanded_dest_row >= *num_valid_tokens_ptr) {
    return;
  }

  // Copy row data: source_row = expanded_source_row / k
  int64_t source_row = expanded_source_row / k;

  device const float* source_ptr = unpermuted_input + source_row * cols;
  device float* dest_ptr = permuted_output + final_dest_row * cols;

  // Copy data in 4-element chunks (128-bit loads/stores)
  for (int64_t idx = tid * ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * ELEMENTS_PER_THREAD) {
    if (idx + ELEMENTS_PER_THREAD <= cols) {
      // Vectorized load/store
      float4 data = *reinterpret_cast<device const float4*>(source_ptr + idx);
      *reinterpret_cast<device float4*>(dest_ptr + idx) = data;
    } else {
      // Handle remainder
      for (int e = 0; e < ELEMENTS_PER_THREAD && (idx + e) < cols; e++) {
        dest_ptr[idx + e] = source_ptr[idx + e];
      }
    }
  }
}

// ============================================================================
// Expand and Permute Input Rows (Float16)
// ============================================================================

kernel void moe_expand_input_rows_half(
    device const half* unpermuted_input [[buffer(0)]],
    device half* permuted_output [[buffer(1)]],
    device int* sorted_experts [[buffer(2)]],
    device const int* expanded_dest_row_to_expanded_source_row [[buffer(3)]],
    device int* expanded_source_row_to_expanded_dest_row [[buffer(4)]],
    device int* permuted_idx [[buffer(5)]],
    device const int64_t* expert_first_token_offset [[buffer(6)]],
    constant int64_t& num_rows [[buffer(7)]],
    device const int64_t* num_valid_tokens_ptr [[buffer(8)]],
    constant int64_t& cols [[buffer(9)]],
    constant int& k [[buffer(10)]],
    constant int& num_local_experts [[buffer(11)]],
    constant int& align_block_size [[buffer(12)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  threadgroup int64_t shared_expert_offsets[256];
  uint expanded_dest_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;

  if (align_block_size > 0 && tid < (num_local_experts + 1)) {
    shared_expert_offsets[tid] = expert_first_token_offset[tid];
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);

  int64_t expanded_source_row = expanded_dest_row_to_expanded_source_row[expanded_dest_row];
  int expert_id = sorted_experts[expanded_dest_row];
  int64_t final_dest_row = expanded_dest_row;

  if (align_block_size > 0 && expert_id < num_local_experts) {
    int64_t token_offset_in_expert = expanded_dest_row - shared_expert_offsets[expert_id];
    int64_t accumulate_align_offset = 0;
    for (int eidx = 1; eidx <= expert_id; eidx++) {
      int64_t n_token = shared_expert_offsets[eidx] - shared_expert_offsets[eidx - 1];
      accumulate_align_offset += ((n_token + align_block_size - 1) / align_block_size) * align_block_size;
    }
    final_dest_row = accumulate_align_offset + token_offset_in_expert;
  }

  if (tid == 0) {
    expanded_source_row_to_expanded_dest_row[expanded_source_row] = (int)final_dest_row;
    if (expanded_dest_row < *num_valid_tokens_ptr) {
      permuted_idx[final_dest_row] = (int)expanded_source_row;
    }
  }

  if (expanded_dest_row >= *num_valid_tokens_ptr) return;

  int64_t source_row = expanded_source_row / k;
  device const half* source_ptr = unpermuted_input + source_row * cols;
  device half* dest_ptr = permuted_output + final_dest_row * cols;

  // 8 half elements per 128-bit load
  constant int HALF_ELEMENTS_PER_THREAD = 8;
  for (int64_t idx = tid * HALF_ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * HALF_ELEMENTS_PER_THREAD) {
    if (idx + HALF_ELEMENTS_PER_THREAD <= cols) {
      // Vectorized half8 load/store
      half8 data = *reinterpret_cast<device const half8*>(source_ptr + idx);
      *reinterpret_cast<device half8*>(dest_ptr + idx) = data;
    } else {
      for (int e = 0; e < HALF_ELEMENTS_PER_THREAD && (idx + e) < cols; e++) {
        dest_ptr[idx + e] = source_ptr[idx + e];
      }
    }
  }
}

// ============================================================================
// Finalize MoE Routing: Unpermute and Reduce (Float32 -> Float32)
// ============================================================================

/**
 * Reverse permutation, apply routing weights, and sum expert outputs
 * Each output token accumulates weighted results from its top-k experts
 */
kernel void moe_finalize_routing_float_float(
    device const float* expanded_permuted_rows [[buffer(0)]],
    device float* reduced_unpermuted_output [[buffer(1)]],
    device const float* scales [[buffer(2)]],
    device const int* expanded_source_row_to_expanded_dest_row [[buffer(3)]],
    constant int64_t& num_rows [[buffer(4)]],
    constant int64_t& cols [[buffer(5)]],
    constant int64_t& k [[buffer(6)]],
    device const int64_t* num_valid_ptr [[buffer(7)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  uint output_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;

  if (output_row >= num_rows) return;

  device float* output_ptr = reduced_unpermuted_output + output_row * cols;

  // Initialize output to zero
  for (int64_t idx = tid * ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * ELEMENTS_PER_THREAD) {
    if (idx + ELEMENTS_PER_THREAD <= cols) {
      *reinterpret_cast<device float4*>(output_ptr + idx) = float4(0.0f);
    } else {
      for (int e = 0; e < ELEMENTS_PER_THREAD && (idx + e) < cols; e++) {
        output_ptr[idx + e] = 0.0f;
      }
    }
  }
  threadgroup_barrier(mem_flags::mem_device);

  // Accumulate weighted expert outputs
  for (int expert_idx = 0; expert_idx < k; expert_idx++) {
    int64_t expanded_source_row = output_row * k + expert_idx;
    int64_t expanded_dest_row = expanded_source_row_to_expanded_dest_row[expanded_source_row];

    if (expanded_dest_row < *num_valid_ptr) {
      float scale = scales[expanded_source_row];
      device const float* expert_output = expanded_permuted_rows + expanded_dest_row * cols;

      for (int64_t idx = tid * ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * ELEMENTS_PER_THREAD) {
        if (idx + ELEMENTS_PER_THREAD <= cols) {
          float4 expert_data = *reinterpret_cast<device const float4*>(expert_output + idx);
          float4 current = *reinterpret_cast<device float4*>(output_ptr + idx);
          *reinterpret_cast<device float4*>(output_ptr + idx) = current + expert_data * scale;
        } else {
          for (int e = 0; e < ELEMENTS_PER_THREAD && (idx + e) < cols; e++) {
            output_ptr[idx + e] += expert_output[idx + e] * scale;
          }
        }
      }
    }
    threadgroup_barrier(mem_flags::mem_device);
  }
}

// ============================================================================
// Finalize MoE Routing: Half -> Half
// ============================================================================

kernel void moe_finalize_routing_half_half(
    device const half* expanded_permuted_rows [[buffer(0)]],
    device half* reduced_unpermuted_output [[buffer(1)]],
    device const float* scales [[buffer(2)]],
    device const int* expanded_source_row_to_expanded_dest_row [[buffer(3)]],
    constant int64_t& num_rows [[buffer(4)]],
    constant int64_t& cols [[buffer(5)]],
    constant int64_t& k [[buffer(6)]],
    device const int64_t* num_valid_ptr [[buffer(7)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  uint output_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;

  if (output_row >= num_rows) return;

  device half* output_ptr = reduced_unpermuted_output + output_row * cols;
  constant int HALF_ELEMENTS = 8;

  // Initialize to zero
  for (int64_t idx = tid * HALF_ELEMENTS; idx < cols; idx += THREADGROUP_SIZE * HALF_ELEMENTS) {
    if (idx + HALF_ELEMENTS <= cols) {
      *reinterpret_cast<device half8*>(output_ptr + idx) = half8(0.0h);
    } else {
      for (int e = 0; e < HALF_ELEMENTS && (idx + e) < cols; e++) {
        output_ptr[idx + e] = 0.0h;
      }
    }
  }
  threadgroup_barrier(mem_flags::mem_device);

  // Accumulate weighted expert outputs
  for (int expert_idx = 0; expert_idx < k; expert_idx++) {
    int64_t expanded_source_row = output_row * k + expert_idx;
    int64_t expanded_dest_row = expanded_source_row_to_expanded_dest_row[expanded_source_row];

    if (expanded_dest_row < *num_valid_ptr) {
      half scale = half(scales[expanded_source_row]);
      device const half* expert_output = expanded_permuted_rows + expanded_dest_row * cols;

      for (int64_t idx = tid * HALF_ELEMENTS; idx < cols; idx += THREADGROUP_SIZE * HALF_ELEMENTS) {
        if (idx + HALF_ELEMENTS <= cols) {
          half8 expert_data = *reinterpret_cast<device const half8*>(expert_output + idx);
          half8 current = *reinterpret_cast<device half8*>(output_ptr + idx);
          *reinterpret_cast<device half8*>(output_ptr + idx) = current + expert_data * scale;
        } else {
          for (int e = 0; e < HALF_ELEMENTS && (idx + e) < cols; e++) {
            output_ptr[idx + e] += expert_output[idx + e] * scale;
          }
        }
      }
    }
    threadgroup_barrier(mem_flags::mem_device);
  }
}

// ============================================================================
// Mixed Precision Variants
// ============================================================================

// Float -> Half conversion during finalization
kernel void moe_finalize_routing_float_half(
    device const float* expanded_permuted_rows [[buffer(0)]],
    device half* reduced_unpermuted_output [[buffer(1)]],
    device const float* scales [[buffer(2)]],
    device const int* expanded_source_row_to_expanded_dest_row [[buffer(3)]],
    constant int64_t& num_rows [[buffer(4)]],
    constant int64_t& cols [[buffer(5)]],
    constant int64_t& k [[buffer(6)]],
    device const int64_t* num_valid_ptr [[buffer(7)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  uint output_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;
  if (output_row >= num_rows) return;

  // Accumulate in float, convert to half at the end
  threadgroup float accumulator[4096];  // Shared accumulation buffer
  int64_t cols_per_thread = (cols + THREADGROUP_SIZE - 1) / THREADGROUP_SIZE;
  int64_t start_col = tid * cols_per_thread;
  int64_t end_col = min(start_col + cols_per_thread, cols);

  // Initialize accumulator
  for (int64_t idx = start_col; idx < end_col; idx++) {
    accumulator[idx] = 0.0f;
  }

  // Accumulate in float precision
  for (int expert_idx = 0; expert_idx < k; expert_idx++) {
    int64_t expanded_source_row = output_row * k + expert_idx;
    int64_t expanded_dest_row = expanded_source_row_to_expanded_dest_row[expanded_source_row];

    if (expanded_dest_row < *num_valid_ptr) {
      float scale = scales[expanded_source_row];
      device const float* expert_output = expanded_permuted_rows + expanded_dest_row * cols;

      for (int64_t idx = start_col; idx < end_col; idx++) {
        accumulator[idx] += expert_output[idx] * scale;
      }
    }
  }

  threadgroup_barrier(mem_flags::mem_threadgroup);

  // Convert and write out as half
  device half* output_ptr = reduced_unpermuted_output + output_row * cols;
  for (int64_t idx = start_col; idx < end_col; idx++) {
    output_ptr[idx] = half(accumulator[idx]);
  }
}

// Half -> Float conversion during finalization
kernel void moe_finalize_routing_half_float(
    device const half* expanded_permuted_rows [[buffer(0)]],
    device float* reduced_unpermuted_output [[buffer(1)]],
    device const float* scales [[buffer(2)]],
    device const int* expanded_source_row_to_expanded_dest_row [[buffer(3)]],
    constant int64_t& num_rows [[buffer(4)]],
    constant int64_t& cols [[buffer(5)]],
    constant int64_t& k [[buffer(6)]],
    device const int64_t* num_valid_ptr [[buffer(7)]],
    uint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]],
    uint thread_index_in_threadgroup [[thread_index_in_threadgroup]]) {

  uint output_row = threadgroup_position_in_grid.x;
  uint tid = thread_index_in_threadgroup;
  if (output_row >= num_rows) return;

  device float* output_ptr = reduced_unpermuted_output + output_row * cols;

  // Initialize
  for (int64_t idx = tid * ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * ELEMENTS_PER_THREAD) {
    if (idx + ELEMENTS_PER_THREAD <= cols) {
      *reinterpret_cast<device float4*>(output_ptr + idx) = float4(0.0f);
    }
  }
  threadgroup_barrier(mem_flags::mem_device);

  // Accumulate (convert half to float during load)
  for (int expert_idx = 0; expert_idx < k; expert_idx++) {
    int64_t expanded_source_row = output_row * k + expert_idx;
    int64_t expanded_dest_row = expanded_source_row_to_expanded_dest_row[expanded_source_row];

    if (expanded_dest_row < *num_valid_ptr) {
      float scale = scales[expanded_source_row];
      device const half* expert_output = expanded_permuted_rows + expanded_dest_row * cols;

      for (int64_t idx = tid * ELEMENTS_PER_THREAD; idx < cols; idx += THREADGROUP_SIZE * ELEMENTS_PER_THREAD) {
        for (int e = 0; e < ELEMENTS_PER_THREAD && (idx + e) < cols; e++) {
          output_ptr[idx + e] += float(expert_output[idx + e]) * scale;
        }
      }
    }
    threadgroup_barrier(mem_flags::mem_device);
  }
}
