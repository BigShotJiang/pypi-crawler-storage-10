#include <metal_stdlib>
using namespace metal;

// ============================================================================
// RMS LayerNorm Kernels for mlxllm
// RMS Norm: y = x * rsqrt(mean(x^2) + epsilon) * weight
// Optimized for Apple Silicon with SIMD operations
// ============================================================================

// ============================================================================
// RMS Normalization
// ============================================================================

kernel void rms_norm_kernel(
    device const float* __restrict__ input [[buffer(0)]],    // [num_tokens, hidden_size]
    device const float* __restrict__ weight [[buffer(1)]],   // [hidden_size]
    device float* __restrict__ output [[buffer(2)]],         // [num_tokens, hidden_size]
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    // Shared memory for parallel reduction
    threadgroup float shared_sum[256];  // Max threadgroup size assumption

    // Compute sum of squares for this token
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = input[gid * hidden_size + i];
        sum_sq += val * val;
    }

    // Store in shared memory
    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Parallel reduction to compute total sum
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Compute RMS normalization factor
    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;  // Store for all threads
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    // Apply normalization and weight
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        output[idx] = input[idx] * rms * weight[i];
    }
}

kernel void rms_norm_kernel_half(
    device const half* __restrict__ input [[buffer(0)]],
    device const half* __restrict__ weight [[buffer(1)]],
    device half* __restrict__ output [[buffer(2)]],
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_sum[256];

    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = float(input[gid * hidden_size + i]);
        sum_sq += val * val;
    }

    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        output[idx] = half(float(input[idx]) * rms * float(weight[i]));
    }
}

// ============================================================================
// Fused Add + RMS Normalization (for residual connections)
// ============================================================================

kernel void fused_add_rms_norm_kernel(
    device float* __restrict__ input [[buffer(0)]],          // [num_tokens, hidden_size] - modified in-place
    device const float* __restrict__ residual [[buffer(1)]], // [num_tokens, hidden_size]
    device const float* __restrict__ weight [[buffer(2)]],   // [hidden_size]
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_sum[256];

    // Add residual and compute sum of squares
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = input[idx] + residual[idx];
        input[idx] = val;  // Update in-place
        sum_sq += val * val;
    }

    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    // Apply normalization and weight
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        input[idx] = input[idx] * rms * weight[i];
    }
}

kernel void fused_add_rms_norm_kernel_half(
    device half* __restrict__ input [[buffer(0)]],
    device const half* __restrict__ residual [[buffer(1)]],
    device const half* __restrict__ weight [[buffer(2)]],
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float shared_sum[256];

    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        float val = float(input[idx]) + float(residual[idx]);
        input[idx] = half(val);
        sum_sq += val * val;
    }

    shared_sum[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float rms = 1.0f;
    if (tid == 0) {
        float mean_sq = shared_sum[0] / float(hidden_size);
        rms = rsqrt(mean_sq + epsilon);
        shared_sum[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    rms = shared_sum[0];

    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        input[idx] = half(float(input[idx]) * rms * float(weight[i]));
    }
}

// ============================================================================
// Optimized SIMD version for better Apple Silicon performance
// Uses SIMD groups for faster reduction
// ============================================================================

kernel void rms_norm_kernel_simd(
    device const float* __restrict__ input [[buffer(0)]],
    device const float* __restrict__ weight [[buffer(1)]],
    device float* __restrict__ output [[buffer(2)]],
    constant uint& num_tokens [[buffer(3)]],
    constant uint& hidden_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_tokens) return;

    threadgroup float simd_sums[8];  // Up to 8 SIMD groups per threadgroup

    // Compute sum of squares using SIMD reduction
    float sum_sq = 0.0f;
    for (uint i = tid; i < hidden_size; i += tg_size) {
        float val = input[gid * hidden_size + i];
        sum_sq += val * val;
    }

    // SIMD group reduction
    sum_sq = simd_sum(sum_sq);

    // First thread of each SIMD group stores result
    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum_sq;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Final reduction across SIMD groups
    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        float mean_sq = total / float(hidden_size);
        float rms = rsqrt(mean_sq + epsilon);
        simd_sums[0] = rms;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    float rms = simd_sums[0];

    // Apply normalization
    for (uint i = tid; i < hidden_size; i += tg_size) {
        uint idx = gid * hidden_size + i;
        output[idx] = input[idx] * rms * weight[i];
    }
}
