#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Column Permutation Kernels for mlxllm
// Used for quantized weight preprocessing (GPTQ, AWQ)
// ============================================================================

// ============================================================================
// Permute Columns - INT32 weights
// Reorders columns based on permutation indices
// ============================================================================

kernel void permute_cols_kernel_int32(
    device const int* __restrict__ input [[buffer(0)]],     // [num_rows, num_cols]
    device int* __restrict__ output [[buffer(1)]],          // [num_rows, num_cols]
    device const int* __restrict__ perm [[buffer(2)]],      // [num_cols] - permutation indices
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    // Get permuted column index
    uint perm_col = perm[col];

    // Copy from input[row, perm_col] to output[row, col]
    uint input_idx = row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Permute Columns - UINT8 weights (for quantized models)
// ============================================================================

kernel void permute_cols_kernel_uint8(
    device const uchar* __restrict__ input [[buffer(0)]],
    device uchar* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    uint perm_col = perm[col];
    uint input_idx = row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Permute Columns - INT8 weights
// ============================================================================

kernel void permute_cols_kernel_int8(
    device const char* __restrict__ input [[buffer(0)]],
    device char* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    uint perm_col = perm[col];
    uint input_idx = row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Permute Columns - FP16 weights
// ============================================================================

kernel void permute_cols_kernel_half(
    device const half* __restrict__ input [[buffer(0)]],
    device half* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    uint perm_col = perm[col];
    uint input_idx = row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Permute Columns - FP32 weights
// ============================================================================

kernel void permute_cols_kernel_float(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    uint perm_col = perm[col];
    uint input_idx = row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Reverse Permute Columns - INT32
// Applies inverse permutation
// ============================================================================

kernel void reverse_permute_cols_kernel_int32(
    device const int* __restrict__ input [[buffer(0)]],
    device int* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    // Reverse: copy from input[row, col] to output[row, perm[col]]
    uint perm_col = perm[col];
    uint output_idx = row * num_cols + perm_col;
    output[output_idx] = input[tid];
}

// ============================================================================
// Optimized vectorized version for FP32 (4-wide)
// ============================================================================

kernel void permute_cols_kernel_float_vec4(
    device const float4* __restrict__ input [[buffer(0)]],
    device float4* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols_div4 [[buffer(4)]],  // num_cols / 4
    uint tid [[thread_position_in_grid]]
) {
    uint total_vec4 = num_rows * num_cols_div4;
    if (tid >= total_vec4) return;

    uint row = tid / num_cols_div4;
    uint col_vec = tid % num_cols_div4;

    // Process 4 columns at once
    uint base_col = col_vec * 4;

    float4 result;
    for (uint i = 0; i < 4; i++) {
        uint col = base_col + i;
        uint perm_col = perm[col];
        uint perm_vec = perm_col / 4;
        uint perm_offset = perm_col % 4;

        float4 input_vec = input[row * num_cols_div4 + perm_vec];
        result[i] = input_vec[perm_offset];
    }

    output[tid] = result;
}

// ============================================================================
// Batch Permute - permute multiple matrices with same permutation
// ============================================================================

kernel void batch_permute_cols_kernel_float(
    device const float* __restrict__ input [[buffer(0)]],   // [batch_size, num_rows, num_cols]
    device float* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& batch_size [[buffer(3)]],
    constant uint& num_rows [[buffer(4)]],
    constant uint& num_cols [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = batch_size * num_rows * num_cols;
    if (tid >= total_elements) return;

    uint batch_idx = tid / (num_rows * num_cols);
    uint remainder = tid % (num_rows * num_cols);
    uint row = remainder / num_cols;
    uint col = remainder % num_cols;

    uint perm_col = perm[col];
    uint input_idx = batch_idx * (num_rows * num_cols) + row * num_cols + perm_col;
    output[tid] = input[input_idx];
}

// ============================================================================
// Specialized permutation for packed INT4 weights (GPTQ/AWQ)
// Each byte stores two INT4 values
// ============================================================================

kernel void permute_cols_kernel_int4_packed(
    device const uchar* __restrict__ input [[buffer(0)]],   // [num_rows, num_cols/2]
    device uchar* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ perm [[buffer(2)]],      // [num_cols]
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],  // Actual columns (not packed)
    uint tid [[thread_position_in_grid]]
) {
    // Each thread handles one output element (packed byte)
    uint total_packed = num_rows * (num_cols / 2);
    if (tid >= total_packed) return;

    uint row = tid / (num_cols / 2);
    uint packed_col = tid % (num_cols / 2);

    // Each packed byte stores two INT4 values
    uint col_0 = packed_col * 2;
    uint col_1 = packed_col * 2 + 1;

    // Get permuted column indices
    uint perm_col_0 = perm[col_0];
    uint perm_col_1 = perm[col_1];

    // Extract INT4 values from input
    uint input_packed_0 = perm_col_0 / 2;
    uint input_offset_0 = perm_col_0 % 2;
    uint input_packed_1 = perm_col_1 / 2;
    uint input_offset_1 = perm_col_1 % 2;

    uchar input_byte_0 = input[row * (num_cols / 2) + input_packed_0];
    uchar input_byte_1 = input[row * (num_cols / 2) + input_packed_1];

    // Extract 4-bit values
    uchar val_0 = (input_offset_0 == 0) ? (input_byte_0 >> 4) : (input_byte_0 & 0x0F);
    uchar val_1 = (input_offset_1 == 0) ? (input_byte_1 >> 4) : (input_byte_1 & 0x0F);

    // Pack into output byte
    uchar output_byte = (val_0 << 4) | val_1;
    output[tid] = output_byte;
}

// ============================================================================
// In-place column permutation (requires temporary buffer)
// ============================================================================

kernel void permute_cols_inplace_kernel_float(
    device float* __restrict__ data [[buffer(0)]],          // [num_rows, num_cols]
    device float* __restrict__ temp [[buffer(1)]],          // Temporary buffer
    device const int* __restrict__ perm [[buffer(2)]],
    constant uint& num_rows [[buffer(3)]],
    constant uint& num_cols [[buffer(4)]],
    constant bool& copy_to_temp [[buffer(5)]],              // Phase 1: copy to temp, Phase 2: copy back
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = num_rows * num_cols;
    if (tid >= total_elements) return;

    uint row = tid / num_cols;
    uint col = tid % num_cols;

    if (copy_to_temp) {
        // Phase 1: Copy from data to temp with permutation
        uint perm_col = perm[col];
        uint input_idx = row * num_cols + perm_col;
        temp[tid] = data[input_idx];
    } else {
        // Phase 2: Copy from temp back to data
        data[tid] = temp[tid];
    }
}
