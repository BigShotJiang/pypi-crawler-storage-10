#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Quick Reduce Kernels for mlxllm
// Optimized reduction operations for Apple Silicon
// ============================================================================

// ============================================================================
// Quick Sum Reduction - optimized for Apple GPU SIMD
// ============================================================================

kernel void quick_reduce_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_sums[8];  // Up to 8 SIMD groups per threadgroup

    // Each thread sums its elements
    float sum = 0.0f;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        sum += input[i];
    }

    // SIMD group reduction (32 threads on Apple GPUs)
    sum = simd_sum(sum);

    // First thread in each SIMD group stores to threadgroup memory
    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Final reduction across SIMD groups
    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        atomic_fetch_add_explicit((device atomic<float>*)output, total, memory_order_relaxed);
    }
}

// ============================================================================
// Quick Max Reduction
// ============================================================================

kernel void quick_reduce_max_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_maxs[8];

    float max_val = -INFINITY;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        max_val = max(max_val, input[i]);
    }

    // SIMD group reduction
    max_val = simd_max(max_val);

    if (simd_lane_id == 0) {
        simd_maxs[simd_group_id] = max_val;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total_max = -INFINITY;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total_max = max(total_max, simd_maxs[i]);
        }

        // Atomic max (using compare-and-swap)
        device atomic<float>* atomic_output = (device atomic<float>*)output;
        float old_val = atomic_load_explicit(atomic_output, memory_order_relaxed);
        while (old_val < total_max) {
            if (atomic_compare_exchange_weak_explicit(atomic_output, &old_val, total_max,
                memory_order_relaxed, memory_order_relaxed)) {
                break;
            }
        }
    }
}

// ============================================================================
// Quick Min Reduction
// ============================================================================

kernel void quick_reduce_min_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_mins[8];

    float min_val = INFINITY;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        min_val = min(min_val, input[i]);
    }

    min_val = simd_min(min_val);

    if (simd_lane_id == 0) {
        simd_mins[simd_group_id] = min_val;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total_min = INFINITY;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total_min = min(total_min, simd_mins[i]);
        }

        device atomic<float>* atomic_output = (device atomic<float>*)output;
        float old_val = atomic_load_explicit(atomic_output, memory_order_relaxed);
        while (old_val > total_min) {
            if (atomic_compare_exchange_weak_explicit(atomic_output, &old_val, total_min,
                memory_order_relaxed, memory_order_relaxed)) {
                break;
            }
        }
    }
}

// ============================================================================
// Quick Mean Reduction
// ============================================================================

kernel void quick_reduce_mean_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_sums[8];

    float sum = 0.0f;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        sum += input[i];
    }

    sum = simd_sum(sum);

    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        float mean = total / float(n);
        atomic_fetch_add_explicit((device atomic<float>*)output, mean, memory_order_relaxed);
    }
}

// ============================================================================
// Quick Reduction with Multiple Outputs (Sum, Max, Min)
// ============================================================================

kernel void quick_reduce_stats_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ sum_output [[buffer(1)]],
    device float* __restrict__ max_output [[buffer(2)]],
    device float* __restrict__ min_output [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_sums[8];
    threadgroup float simd_maxs[8];
    threadgroup float simd_mins[8];

    float sum = 0.0f;
    float max_val = -INFINITY;
    float min_val = INFINITY;

    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        float val = input[i];
        sum += val;
        max_val = max(max_val, val);
        min_val = min(min_val, val);
    }

    // SIMD reductions
    sum = simd_sum(sum);
    max_val = simd_max(max_val);
    min_val = simd_min(min_val);

    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
        simd_maxs[simd_group_id] = max_val;
        simd_mins[simd_group_id] = min_val;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        uint num_simd_groups = (tg_size + 31) / 32;

        float total_sum = 0.0f;
        float total_max = -INFINITY;
        float total_min = INFINITY;

        for (uint i = 0; i < num_simd_groups; i++) {
            total_sum += simd_sums[i];
            total_max = max(total_max, simd_maxs[i]);
            total_min = min(total_min, simd_mins[i]);
        }

        atomic_fetch_add_explicit((device atomic<float>*)sum_output, total_sum, memory_order_relaxed);

        device atomic<float>* atomic_max = (device atomic<float>*)max_output;
        float old_max = atomic_load_explicit(atomic_max, memory_order_relaxed);
        while (old_max < total_max) {
            if (atomic_compare_exchange_weak_explicit(atomic_max, &old_max, total_max,
                memory_order_relaxed, memory_order_relaxed)) break;
        }

        device atomic<float>* atomic_min = (device atomic<float>*)min_output;
        float old_min = atomic_load_explicit(atomic_min, memory_order_relaxed);
        while (old_min > total_min) {
            if (atomic_compare_exchange_weak_explicit(atomic_min, &old_min, total_min,
                memory_order_relaxed, memory_order_relaxed)) break;
        }
    }
}

// ============================================================================
// Vectorized Quick Sum (float4)
// ============================================================================

kernel void quick_reduce_sum_vec4_kernel(
    device const float4* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],  // Number of float4 elements
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_sums[8];

    float sum = 0.0f;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        float4 vec = input[i];
        sum += vec.x + vec.y + vec.z + vec.w;
    }

    sum = simd_sum(sum);

    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        atomic_fetch_add_explicit((device atomic<float>*)output, total, memory_order_relaxed);
    }
}

// ============================================================================
// Per-Row Quick Reduction (2D)
// ============================================================================

kernel void quick_reduce_sum_per_row_kernel(
    device const float* __restrict__ input [[buffer(0)]],   // [num_rows, row_size]
    device float* __restrict__ output [[buffer(1)]],        // [num_rows]
    constant uint& num_rows [[buffer(2)]],
    constant uint& row_size [[buffer(3)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    if (gid >= num_rows) return;

    threadgroup float simd_sums[8];

    float sum = 0.0f;
    for (uint i = tid; i < row_size; i += tg_size) {
        sum += input[gid * row_size + i];
    }

    sum = simd_sum(sum);

    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        output[gid] = total;
    }
}

// ============================================================================
// Half precision variant
// ============================================================================

kernel void quick_reduce_sum_kernel_half(
    device const half* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint gid [[threadgroup_position_in_grid]],
    uint tg_size [[threads_per_threadgroup]],
    uint simd_lane_id [[thread_index_in_simdgroup]],
    uint simd_group_id [[simdgroup_index_in_threadgroup]]
) {
    threadgroup float simd_sums[8];

    float sum = 0.0f;
    for (uint i = gid * tg_size + tid; i < n; i += tg_size) {
        sum += float(input[i]);
    }

    sum = simd_sum(sum);

    if (simd_lane_id == 0) {
        simd_sums[simd_group_id] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (tid == 0) {
        float total = 0.0f;
        uint num_simd_groups = (tg_size + 31) / 32;
        for (uint i = 0; i < num_simd_groups; i++) {
            total += simd_sums[i];
        }
        atomic_fetch_add_explicit((device atomic<float>*)output, total, memory_order_relaxed);
    }
}
