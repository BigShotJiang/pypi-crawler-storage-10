"""
CSRC - C++ Source and Metal Kernels for MLX-LLM.

This package contains Metal kernel implementations (.metal files) and C++ extensions
for high-performance operations on Apple Silicon.

Subpackages:
    - metalcutlass_extensions: Python bindings for MetalCutlass GEMM operations
    - attention: Attention kernel implementations (paged attention, RoPE, RMS norm)
    - moe: Mixture-of-Experts kernels (routing, permutation, quantized GEMM)
    - all2all: All-to-all communication kernels (distributed inference)
    - core: Core utilities (type conversions, device management, math helpers)
    - cpu: CPU fallback implementations
    - mamba: Mamba State Space Model operations
"""

from typing import Dict

def get_extension_availability() -> Dict[str, bool]:
    """Check availability of all csrc extensions."""
    availability = {}
    for name in ['attention', 'moe', 'all2all', 'core', 'cpu', 'mamba', 'metalcutlass_extensions']:
        try:
            module = __import__(f'csrc.{name}', fromlist=['is_available'])
            availability[name] = getattr(module, 'is_available', lambda: False)()
        except ImportError:
            availability[name] = False
    return availability

__all__ = [
    "metalcutlass_extensions",
    "attention",
    "moe",
    "all2all",
    "core",
    "cpu",
    "mamba",
    "get_extension_availability",
]

__version__ = "0.1.0"
