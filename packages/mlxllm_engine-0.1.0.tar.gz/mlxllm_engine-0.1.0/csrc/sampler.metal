#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Sampling Kernels for mlxllm
// Implements Top-K, Top-P, Temperature, Repetition Penalties
// ============================================================================

// ============================================================================
// Apply Repetition Penalties
// Reduces probability of recently generated tokens
// ============================================================================

kernel void apply_repetition_penalties_kernel(
    device float* __restrict__ logits [[buffer(0)]],              // [batch_size, vocab_size]
    device const int* __restrict__ prompt_mask [[buffer(1)]],     // [batch_size, vocab_size]
    device const int* __restrict__ output_mask [[buffer(2)]],     // [batch_size, vocab_size]
    device const float* __restrict__ penalties [[buffer(3)]],     // [batch_size]
    constant uint& batch_size [[buffer(4)]],
    constant uint& vocab_size [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint batch_idx = tid / vocab_size;
    uint token_idx = tid % vocab_size;

    if (batch_idx >= batch_size) return;

    float penalty = penalties[batch_idx];

    // Apply penalty if token appears in prompt or output
    bool in_prompt = prompt_mask[tid] != 0;
    bool in_output = output_mask[tid] != 0;

    if (in_prompt || in_output) {
        float logit = logits[tid];
        // If logit > 0, divide by penalty (reduce probability)
        // If logit < 0, multiply by penalty (reduce probability more)
        if (logit > 0.0f) {
            logits[tid] = logit / penalty;
        } else {
            logits[tid] = logit * penalty;
        }
    }
}

// ============================================================================
// Top-K Sampling Per Row
// Selects top-K logits per batch item
// ============================================================================

kernel void top_k_per_row_kernel(
    device const float* __restrict__ logits [[buffer(0)]],     // [num_rows, vocab_size]
    device const int* __restrict__ row_starts [[buffer(1)]],   // [num_rows]
    device const int* __restrict__ row_ends [[buffer(2)]],     // [num_rows]
    device int* __restrict__ indices [[buffer(3)]],            // [num_rows, k]
    constant uint& num_rows [[buffer(4)]],
    constant uint& k [[buffer(5)]],
    constant uint& vocab_size [[buffer(6)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_rows) return;

    int start = row_starts[gid];
    int end = row_ends[gid];
    int row_size = end - start;

    if (row_size <= 0) return;

    threadgroup float top_k_values[256];  // Assuming k <= 256
    threadgroup int top_k_indices[256];

    // Initialize top-k arrays
    for (uint i = tid; i < k; i += tg_size) {
        top_k_values[i] = -INFINITY;
        top_k_indices[i] = -1;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Each thread processes subset of vocab
    for (int i = start + tid; i < end; i += tg_size) {
        float value = logits[i];
        int vocab_idx = i - start;

        // Find insertion point in top-k
        for (uint pos = 0; pos < k; pos++) {
            if (value > top_k_values[pos]) {
                // Shift elements down
                for (uint j = k - 1; j > pos; j--) {
                    top_k_values[j] = top_k_values[j - 1];
                    top_k_indices[j] = top_k_indices[j - 1];
                }
                top_k_values[pos] = value;
                top_k_indices[pos] = vocab_idx;
                break;
            }
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Write results
    if (tid == 0) {
        for (uint i = 0; i < k; i++) {
            indices[gid * k + i] = top_k_indices[i];
        }
    }
}

// ============================================================================
// Top-K for Decode Phase
// Optimized version for decoding with sequence-specific handling
// ============================================================================

kernel void top_k_decode_kernel(
    device const float* __restrict__ logits [[buffer(0)]],     // [batch_size, vocab_size]
    device const int* __restrict__ seq_lens [[buffer(1)]],     // [batch_size]
    device int* __restrict__ indices [[buffer(2)]],            // [batch_size, k]
    constant uint& batch_size [[buffer(3)]],
    constant uint& k [[buffer(4)]],
    constant uint& vocab_size [[buffer(5)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= batch_size) return;

    int seq_len = seq_lens[gid];
    if (seq_len <= 0) return;

    threadgroup float top_k_values[256];
    threadgroup int top_k_indices[256];

    // Initialize
    for (uint i = tid; i < k; i += tg_size) {
        top_k_values[i] = -INFINITY;
        top_k_indices[i] = -1;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Process logits for this batch
    uint logit_offset = gid * vocab_size;

    for (uint i = tid; i < vocab_size; i += tg_size) {
        float value = logits[logit_offset + i];

        for (uint pos = 0; pos < k; pos++) {
            if (value > top_k_values[pos]) {
                for (uint j = k - 1; j > pos; j--) {
                    top_k_values[j] = top_k_values[j - 1];
                    top_k_indices[j] = top_k_indices[j - 1];
                }
                top_k_values[pos] = value;
                top_k_indices[pos] = i;
                break;
            }
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Write results
    if (tid == 0) {
        for (uint i = 0; i < k; i++) {
            indices[gid * k + i] = top_k_indices[i];
        }
    }
}

// ============================================================================
// Temperature Scaling
// Scales logits by temperature before sampling
// ============================================================================

kernel void temperature_scaling_kernel(
    device float* __restrict__ logits [[buffer(0)]],        // [batch_size, vocab_size]
    device const float* __restrict__ temperatures [[buffer(1)]], // [batch_size]
    constant uint& batch_size [[buffer(2)]],
    constant uint& vocab_size [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    uint batch_idx = tid / vocab_size;
    uint vocab_idx = tid % vocab_size;

    if (batch_idx >= batch_size) return;

    float temperature = temperatures[batch_idx];

    // Avoid division by zero
    if (temperature > 0.0f) {
        logits[tid] /= temperature;
    }
}

// ============================================================================
// Softmax (for probability computation)
// ============================================================================

kernel void softmax_kernel(
    device const float* __restrict__ logits [[buffer(0)]],   // [batch_size, vocab_size]
    device float* __restrict__ probs [[buffer(1)]],          // [batch_size, vocab_size]
    constant uint& batch_size [[buffer(2)]],
    constant uint& vocab_size [[buffer(3)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= batch_size) return;

    threadgroup float shared_max;
    threadgroup float shared_sum;

    uint offset = gid * vocab_size;

    // Find max (for numerical stability)
    float local_max = -INFINITY;
    for (uint i = tid; i < vocab_size; i += tg_size) {
        local_max = max(local_max, logits[offset + i]);
    }

    // Reduce to find global max
    threadgroup float max_values[256];
    max_values[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            max_values[tid] = max(max_values[tid], max_values[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        shared_max = max_values[0];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Compute exp and sum
    float local_sum = 0.0f;
    for (uint i = tid; i < vocab_size; i += tg_size) {
        float exp_val = exp(logits[offset + i] - shared_max);
        probs[offset + i] = exp_val;
        local_sum += exp_val;
    }

    threadgroup float sum_values[256];
    sum_values[tid] = local_sum;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            sum_values[tid] += sum_values[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        shared_sum = sum_values[0];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Normalize
    for (uint i = tid; i < vocab_size; i += tg_size) {
        probs[offset + i] /= shared_sum;
    }
}

// ============================================================================
// Top-P (Nucleus) Sampling
// Selects smallest set of tokens with cumulative probability >= p
// ============================================================================

kernel void top_p_sampling_kernel(
    device const float* __restrict__ probs [[buffer(0)]],      // [batch_size, vocab_size]
    device int* __restrict__ indices [[buffer(1)]],            // [batch_size, max_tokens]
    device int* __restrict__ num_selected [[buffer(2)]],       // [batch_size]
    device const float* __restrict__ p_values [[buffer(3)]],   // [batch_size]
    constant uint& batch_size [[buffer(4)]],
    constant uint& vocab_size [[buffer(5)]],
    constant uint& max_tokens [[buffer(6)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]]
) {
    if (gid >= batch_size) return;

    float p = p_values[gid];
    uint offset = gid * vocab_size;

    threadgroup float sorted_probs[1024];  // Assuming vocab_size <= 1024
    threadgroup int sorted_indices[1024];

    // Copy and sort probabilities (simplified - would need proper parallel sort)
    if (tid == 0) {
        // Simple insertion sort for demonstration
        // In production, use parallel sorting algorithm
        for (uint i = 0; i < min(vocab_size, uint(1024)); i++) {
            sorted_probs[i] = probs[offset + i];
            sorted_indices[i] = i;
        }

        // Sort descending
        for (uint i = 0; i < min(vocab_size, uint(1024)) - 1; i++) {
            for (uint j = i + 1; j < min(vocab_size, uint(1024)); j++) {
                if (sorted_probs[j] > sorted_probs[i]) {
                    float temp_prob = sorted_probs[i];
                    sorted_probs[i] = sorted_probs[j];
                    sorted_probs[j] = temp_prob;

                    int temp_idx = sorted_indices[i];
                    sorted_indices[i] = sorted_indices[j];
                    sorted_indices[j] = temp_idx;
                }
            }
        }

        // Accumulate until we reach p
        float cumsum = 0.0f;
        int count = 0;
        for (uint i = 0; i < min(vocab_size, max_tokens); i++) {
            cumsum += sorted_probs[i];
            indices[gid * max_tokens + count] = sorted_indices[i];
            count++;
            if (cumsum >= p) break;
        }
        num_selected[gid] = count;
    }
}

// ============================================================================
// Greedy Sampling (Argmax)
// Selects token with highest probability
// ============================================================================

kernel void greedy_sampling_kernel(
    device const float* __restrict__ logits [[buffer(0)]],   // [batch_size, vocab_size]
    device int* __restrict__ selected [[buffer(1)]],         // [batch_size]
    constant uint& batch_size [[buffer(2)]],
    constant uint& vocab_size [[buffer(3)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= batch_size) return;

    uint offset = gid * vocab_size;

    threadgroup float max_values[256];
    threadgroup int max_indices[256];

    float local_max = -INFINITY;
    int local_idx = -1;

    for (uint i = tid; i < vocab_size; i += tg_size) {
        float val = logits[offset + i];
        if (val > local_max) {
            local_max = val;
            local_idx = i;
        }
    }

    max_values[tid] = local_max;
    max_indices[tid] = local_idx;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Reduce
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            if (max_values[tid + stride] > max_values[tid]) {
                max_values[tid] = max_values[tid + stride];
                max_indices[tid] = max_indices[tid + stride];
            }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        selected[gid] = max_indices[0];
    }
}
