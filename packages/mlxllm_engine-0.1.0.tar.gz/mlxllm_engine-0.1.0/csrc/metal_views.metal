#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Metal Tensor View Kernels for mlxllm
// Implements view operations: reshape, slice, expand, squeeze, unsqueeze
// ============================================================================

// ============================================================================
// Reshape/View Operations (no data copy, just indexing change)
// ============================================================================

kernel void reshape_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ old_shape [[buffer(2)]],    // [old_ndim]
    device const uint* __restrict__ new_shape [[buffer(3)]],    // [new_ndim]
    device const uint* __restrict__ old_strides [[buffer(4)]],  // [old_ndim]
    device const uint* __restrict__ new_strides [[buffer(5)]],  // [new_ndim]
    constant uint& old_ndim [[buffer(6)]],
    constant uint& new_ndim [[buffer(7)]],
    constant uint& total_elements [[buffer(8)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;

    // Compute multi-dimensional index in new shape
    uint linear_idx = tid;
    uint old_indices[8];  // Support up to 8 dimensions

    for (int i = new_ndim - 1; i >= 0; i--) {
        old_indices[i] = linear_idx % new_shape[i];
        linear_idx /= new_shape[i];
    }

    // Compute linear offset in old layout
    uint old_offset = 0;
    linear_idx = tid;
    for (int i = old_ndim - 1; i >= 0; i--) {
        uint idx = linear_idx % old_shape[i];
        old_offset += idx * old_strides[i];
        linear_idx /= old_shape[i];
    }

    output[tid] = input[old_offset];
}

// ============================================================================
// Slice Operations - extract subregion
// ============================================================================

kernel void slice_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ input_shape [[buffer(2)]],   // [ndim]
    device const uint* __restrict__ output_shape [[buffer(3)]],  // [ndim]
    device const int* __restrict__ starts [[buffer(4)]],         // [ndim] - slice start indices
    device const int* __restrict__ steps [[buffer(5)]],          // [ndim] - slice steps
    constant uint& ndim [[buffer(6)]],
    constant uint& total_output_elements [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_output_elements) return;

    // Compute multi-dimensional output index
    uint output_idx = tid;
    uint input_offset = 0;
    uint multiplier = 1;

    for (int i = ndim - 1; i >= 0; i--) {
        uint out_coord = output_idx % output_shape[i];
        output_idx /= output_shape[i];

        // Map to input coordinate
        uint in_coord = starts[i] + out_coord * steps[i];
        input_offset += in_coord * multiplier;
        multiplier *= input_shape[i];
    }

    output[tid] = input[input_offset];
}

// ============================================================================
// Expand/Broadcast - repeat along dimensions
// ============================================================================

kernel void expand_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ input_shape [[buffer(2)]],   // [ndim]
    device const uint* __restrict__ output_shape [[buffer(3)]],  // [ndim]
    constant uint& ndim [[buffer(4)]],
    constant uint& total_output_elements [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_output_elements) return;

    // Compute output coordinates
    uint output_idx = tid;
    uint input_offset = 0;
    uint input_multiplier = 1;

    for (int i = ndim - 1; i >= 0; i--) {
        uint out_coord = output_idx % output_shape[i];
        output_idx /= output_shape[i];

        // If input dimension is 1, broadcast by using 0 index
        uint in_coord = (input_shape[i] == 1) ? 0 : out_coord;
        input_offset += in_coord * input_multiplier;
        input_multiplier *= input_shape[i];
    }

    output[tid] = input[input_offset];
}

// ============================================================================
// Permute/Transpose - reorder dimensions
// ============================================================================

kernel void permute_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ input_shape [[buffer(2)]],   // [ndim]
    device const uint* __restrict__ permutation [[buffer(3)]],   // [ndim] - axis order
    constant uint& ndim [[buffer(4)]],
    constant uint& total_elements [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;

    // Compute output coordinates
    uint coords[8];
    uint temp_idx = tid;

    // Get output shape after permutation
    uint output_shape[8];
    for (uint i = 0; i < ndim; i++) {
        output_shape[i] = input_shape[permutation[i]];
    }

    // Compute coordinates in output space
    for (int i = ndim - 1; i >= 0; i--) {
        coords[i] = temp_idx % output_shape[i];
        temp_idx /= output_shape[i];
    }

    // Map to input coordinates using inverse permutation
    uint input_coords[8];
    for (uint i = 0; i < ndim; i++) {
        input_coords[permutation[i]] = coords[i];
    }

    // Compute linear input offset
    uint input_offset = 0;
    uint multiplier = 1;
    for (int i = ndim - 1; i >= 0; i--) {
        input_offset += input_coords[i] * multiplier;
        multiplier *= input_shape[i];
    }

    output[tid] = input[input_offset];
}

// ============================================================================
// Squeeze - remove dimensions of size 1
// ============================================================================

kernel void squeeze_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ input_strides [[buffer(2)]],
    device const int* __restrict__ squeeze_dims [[buffer(3)]],   // Which dims to squeeze
    constant uint& num_squeeze_dims [[buffer(4)]],
    constant uint& total_elements [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;
    // For squeeze, data layout doesn't change, just metadata
    output[tid] = input[tid];
}

// ============================================================================
// Unsqueeze - add dimensions of size 1
// ============================================================================

kernel void unsqueeze_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& total_elements [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;
    // For unsqueeze, data layout doesn't change
    output[tid] = input[tid];
}

// ============================================================================
// Flatten - reshape to 1D
// ============================================================================

kernel void flatten_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& total_elements [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;
    output[tid] = input[tid];
}

// ============================================================================
// Strided copy - for non-contiguous tensors
// ============================================================================

kernel void strided_copy_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ shape [[buffer(2)]],         // [ndim]
    device const uint* __restrict__ input_strides [[buffer(3)]], // [ndim]
    device const uint* __restrict__ output_strides [[buffer(4)]], // [ndim]
    constant uint& ndim [[buffer(5)]],
    constant uint& total_elements [[buffer(6)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;

    // Compute multi-dimensional coordinates
    uint coords[8];
    uint temp_idx = tid;
    for (int i = ndim - 1; i >= 0; i--) {
        coords[i] = temp_idx % shape[i];
        temp_idx /= shape[i];
    }

    // Compute offsets
    uint input_offset = 0;
    uint output_offset = 0;
    for (uint i = 0; i < ndim; i++) {
        input_offset += coords[i] * input_strides[i];
        output_offset += coords[i] * output_strides[i];
    }

    output[output_offset] = input[input_offset];
}

// ============================================================================
// Contiguous conversion - make tensor contiguous
// ============================================================================

kernel void as_contiguous_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ shape [[buffer(2)]],
    device const uint* __restrict__ strides [[buffer(3)]],
    constant uint& ndim [[buffer(4)]],
    constant uint& total_elements [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_elements) return;

    // Compute coordinates from linear output index
    uint coords[8];
    uint temp_idx = tid;
    for (int i = ndim - 1; i >= 0; i--) {
        coords[i] = temp_idx % shape[i];
        temp_idx /= shape[i];
    }

    // Compute strided input offset
    uint input_offset = 0;
    for (uint i = 0; i < ndim; i++) {
        input_offset += coords[i] * strides[i];
    }

    output[tid] = input[input_offset];
}

// ============================================================================
// Specialized 4D views (common for conv/pooling)
// ============================================================================

// NCHW to NHWC
kernel void nchw_to_nhwc_kernel(
    device const float* __restrict__ input [[buffer(0)]],  // [N, C, H, W]
    device float* __restrict__ output [[buffer(1)]],       // [N, H, W, C]
    constant uint& N [[buffer(2)]],
    constant uint& C [[buffer(3)]],
    constant uint& H [[buffer(4)]],
    constant uint& W [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total = N * C * H * W;
    if (tid >= total) return;

    uint n = tid / (C * H * W);
    uint remainder = tid % (C * H * W);
    uint c = remainder / (H * W);
    remainder = remainder % (H * W);
    uint h = remainder / W;
    uint w = remainder % W;

    // NCHW[n,c,h,w] -> NHWC[n,h,w,c]
    uint output_idx = n * (H * W * C) + h * (W * C) + w * C + c;
    output[output_idx] = input[tid];
}

// NHWC to NCHW
kernel void nhwc_to_nchw_kernel(
    device const float* __restrict__ input [[buffer(0)]],  // [N, H, W, C]
    device float* __restrict__ output [[buffer(1)]],       // [N, C, H, W]
    constant uint& N [[buffer(2)]],
    constant uint& H [[buffer(3)]],
    constant uint& W [[buffer(4)]],
    constant uint& C [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total = N * H * W * C;
    if (tid >= total) return;

    uint n = tid / (H * W * C);
    uint remainder = tid % (H * W * C);
    uint h = remainder / (W * C);
    remainder = remainder % (W * C);
    uint w = remainder / C;
    uint c = remainder % C;

    // NHWC[n,h,w,c] -> NCHW[n,c,h,w]
    uint output_idx = n * (C * H * W) + c * (H * W) + h * W + w;
    output[output_idx] = input[tid];
}

// ============================================================================
// Split along dimension
// ============================================================================

kernel void split_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ shape [[buffer(2)]],
    constant uint& ndim [[buffer(3)]],
    constant uint& split_dim [[buffer(4)]],
    constant uint& split_start [[buffer(5)]],
    constant uint& split_size [[buffer(6)]],
    constant uint& total_output_elements [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_output_elements) return;

    // Compute output coordinates
    uint coords[8];
    uint temp_idx = tid;

    // Compute output shape (same as input except split_dim)
    uint output_shape[8];
    for (uint i = 0; i < ndim; i++) {
        output_shape[i] = (i == split_dim) ? split_size : shape[i];
    }

    for (int i = ndim - 1; i >= 0; i--) {
        coords[i] = temp_idx % output_shape[i];
        temp_idx /= output_shape[i];
    }

    // Adjust coordinate for split dimension
    coords[split_dim] += split_start;

    // Compute input offset
    uint input_offset = 0;
    uint multiplier = 1;
    for (int i = ndim - 1; i >= 0; i--) {
        input_offset += coords[i] * multiplier;
        multiplier *= shape[i];
    }

    output[tid] = input[input_offset];
}

// ============================================================================
// Concatenate along dimension
// ============================================================================

kernel void concat_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const uint* __restrict__ output_shape [[buffer(2)]],
    constant uint& ndim [[buffer(3)]],
    constant uint& concat_dim [[buffer(4)]],
    constant uint& input_size_at_concat_dim [[buffer(5)]],
    constant uint& offset_at_concat_dim [[buffer(6)]],
    constant uint& total_input_elements [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= total_input_elements) return;

    // Compute input coordinates
    uint coords[8];
    uint temp_idx = tid;

    // Input shape (same as output except concat_dim)
    uint input_shape[8];
    for (uint i = 0; i < ndim; i++) {
        input_shape[i] = (i == concat_dim) ? input_size_at_concat_dim : output_shape[i];
    }

    for (int i = ndim - 1; i >= 0; i--) {
        coords[i] = temp_idx % input_shape[i];
        temp_idx /= input_shape[i];
    }

    // Adjust coordinate for concat dimension
    coords[concat_dim] += offset_at_concat_dim;

    // Compute output offset
    uint output_offset = 0;
    uint multiplier = 1;
    for (int i = ndim - 1; i >= 0; i--) {
        output_offset += coords[i] * multiplier;
        multiplier *= output_shape[i];
    }

    output[output_offset] = input[tid];
}
