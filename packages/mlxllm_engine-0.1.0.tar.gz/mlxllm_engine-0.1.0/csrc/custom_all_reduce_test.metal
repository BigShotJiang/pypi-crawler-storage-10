#include <metal_stdlib>
using namespace metal;

// ============================================================================
// All-Reduce Test Kernels for mlxllm
// Unit tests and validation for collective communication
// ============================================================================

// ============================================================================
// Test Pattern Generation
// ============================================================================

kernel void generate_test_pattern_kernel(
    device float* __restrict__ output [[buffer(0)]],
    constant uint& rank [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    constant uint& pattern_type [[buffer(3)]],  // 0: sequential, 1: constant, 2: rank-based
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    switch (pattern_type) {
        case 0:  // Sequential: 0, 1, 2, 3, ...
            output[tid] = float(tid);
            break;
        case 1:  // Constant: all 1.0
            output[tid] = 1.0f;
            break;
        case 2:  // Rank-based: all equal to rank
            output[tid] = float(rank);
            break;
        case 3:  // Alternating: 1, -1, 1, -1, ...
            output[tid] = (tid % 2 == 0) ? 1.0f : -1.0f;
            break;
        default:
            output[tid] = 0.0f;
    }
}

// ============================================================================
// Verify All-Reduce Sum Result
// ============================================================================

kernel void verify_all_reduce_sum_kernel(
    device const float* __restrict__ result [[buffer(0)]],
    device const float* __restrict__ expected [[buffer(1)]],
    device int* __restrict__ errors [[buffer(2)]],  // Output: number of errors
    constant uint& n [[buffer(3)]],
    constant float& epsilon [[buffer(4)]],  // Tolerance for float comparison
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float diff = abs(result[tid] - expected[tid]);
    if (diff > epsilon) {
        atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
    }
}

// ============================================================================
// Verify All-Reduce Max Result
// ============================================================================

kernel void verify_all_reduce_max_kernel(
    device const float* __restrict__ result [[buffer(0)]],
    device const float* __restrict__ input_buffers [[buffer(1)]],  // All peer inputs
    device int* __restrict__ errors [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    // Compute expected max
    float expected_max = input_buffers[tid];
    for (uint peer = 1; peer < num_peers; peer++) {
        expected_max = max(expected_max, input_buffers[peer * n + tid]);
    }

    float diff = abs(result[tid] - expected_max);
    if (diff > epsilon) {
        atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
    }
}

// ============================================================================
// Verify All-Gather Result
// ============================================================================

kernel void verify_all_gather_kernel(
    device const float* __restrict__ result [[buffer(0)]],       // [num_peers, chunk_size]
    device const float* __restrict__ local_inputs [[buffer(1)]], // [num_peers, chunk_size]
    device int* __restrict__ errors [[buffer(2)]],
    constant uint& num_peers [[buffer(3)]],
    constant uint& chunk_size [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total = num_peers * chunk_size;
    if (tid >= total) return;

    uint peer = tid / chunk_size;
    uint offset = tid % chunk_size;

    float expected = local_inputs[peer * chunk_size + offset];
    float diff = abs(result[tid] - expected);

    if (diff > epsilon) {
        atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
    }
}

// ============================================================================
// Verify Broadcast Result
// ============================================================================

kernel void verify_broadcast_kernel(
    device const float* __restrict__ result [[buffer(0)]],
    device const float* __restrict__ root_data [[buffer(1)]],
    device int* __restrict__ errors [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& epsilon [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float diff = abs(result[tid] - root_data[tid]);
    if (diff > epsilon) {
        atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
    }
}

// ============================================================================
// Performance Benchmark - measure bandwidth
// ============================================================================

kernel void benchmark_copy_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    constant uint& iterations [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    // Perform multiple copies to measure sustained bandwidth
    float value = input[tid];
    for (uint i = 0; i < iterations; i++) {
        output[tid] = value;
        value = output[tid];  // Prevent compiler optimization
    }
}

// ============================================================================
// Test Atomic Operations
// ============================================================================

kernel void test_atomic_add_kernel(
    device atomic_int* __restrict__ counter [[buffer(0)]],
    device int* __restrict__ thread_ids [[buffer(1)]],
    constant uint& num_threads [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_threads) return;

    // Each thread increments counter atomically
    int old_val = atomic_fetch_add_explicit(counter, 1, memory_order_relaxed);
    thread_ids[tid] = old_val;  // Store the value we got
}

// ============================================================================
// Verify Atomic Test Results
// ============================================================================

kernel void verify_atomic_test_kernel(
    device const int* __restrict__ thread_ids [[buffer(0)]],
    device int* __restrict__ errors [[buffer(1)]],
    constant uint& num_threads [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_threads) return;

    int value = thread_ids[tid];

    // Check that each thread got a unique value in [0, num_threads)
    if (value < 0 || value >= int(num_threads)) {
        atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
        return;
    }

    // Check for duplicates (simplified check)
    for (uint i = 0; i < num_threads; i++) {
        if (i != tid && thread_ids[i] == value) {
            atomic_fetch_add_explicit((device atomic_int*)errors, 1, memory_order_relaxed);
            break;
        }
    }
}

// ============================================================================
// Correctness Test - Sum of known sequence
// ============================================================================

kernel void test_known_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ result [[buffer(1)]],
    device int* __restrict__ pass [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& expected_sum [[buffer(4)]],
    constant float& epsilon [[buffer(5)]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    threadgroup float shared_sum[256];

    float sum = 0.0f;
    for (uint i = tid; i < n; i += tg_size) {
        sum += input[i];
    }

    shared_sum[tid] = sum;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        *result = shared_sum[0];
        float diff = abs(shared_sum[0] - expected_sum);
        *pass = (diff <= epsilon) ? 1 : 0;
    }
}

// ============================================================================
// Stress Test - high contention atomic operations
// ============================================================================

kernel void stress_test_atomic_kernel(
    device atomic_int* __restrict__ shared_counter [[buffer(0)]],
    device int* __restrict__ thread_counts [[buffer(1)]],
    constant uint& iterations [[buffer(2)]],
    constant uint& num_threads [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_threads) return;

    int local_count = 0;
    for (uint i = 0; i < iterations; i++) {
        atomic_fetch_add_explicit(shared_counter, 1, memory_order_relaxed);
        local_count++;
    }

    thread_counts[tid] = local_count;
}

// ============================================================================
// Verify Stress Test Results
// ============================================================================

kernel void verify_stress_test_kernel(
    device const atomic_int* __restrict__ shared_counter [[buffer(0)]],
    device const int* __restrict__ thread_counts [[buffer(1)]],
    device int* __restrict__ pass [[buffer(2)]],
    constant uint& num_threads [[buffer(3)]],
    constant uint& iterations [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid != 0) return;

    // Check total counter value
    int counter_val = atomic_load_explicit(shared_counter, memory_order_relaxed);
    int expected = num_threads * iterations;

    // Verify each thread completed its iterations
    int total_local = 0;
    for (uint i = 0; i < num_threads; i++) {
        total_local += thread_counts[i];
    }

    *pass = (counter_val == expected && total_local == expected) ? 1 : 0;
}

// ============================================================================
// Memory Ordering Test
// ============================================================================

kernel void test_memory_ordering_kernel(
    device atomic_int* __restrict__ flag [[buffer(0)]],
    device int* __restrict__ data [[buffer(1)]],
    constant uint& role [[buffer(2)]],  // 0: writer, 1: reader
    uint tid [[thread_position_in_grid]]
) {
    if (tid != 0) return;

    if (role == 0) {
        // Writer: write data then set flag
        *data = 42;
        atomic_store_explicit(flag, 1, memory_order_release);
    } else {
        // Reader: wait for flag then read data
        while (atomic_load_explicit(flag, memory_order_acquire) == 0) {
            // Spin wait
        }
        int value = *data;
        *data = value;  // Store back to verify
    }
}

// ============================================================================
// Print Debug Information
// ============================================================================

kernel void debug_print_values_kernel(
    device const float* __restrict__ values [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],  // Copy for debugging
    constant uint& n [[buffer(2)]],
    constant uint& max_print [[buffer(3)]],  // Max elements to copy
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n || tid >= max_print) return;
    output[tid] = values[tid];
}
