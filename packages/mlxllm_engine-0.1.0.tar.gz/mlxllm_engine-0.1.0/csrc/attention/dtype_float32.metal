#include <metal_stdlib>
#include "attention_dtypes.h"
using namespace metal;

// ============================================================================
// Float32 Attention Kernel Stubs
// ============================================================================
// NOTE: MLX handles dtype-specific kernels automatically.
// These are reference signatures only.
// ============================================================================

// Generic attention with float32
kernel void attention_float32_kernel(
    device const float* query [[buffer(0)]],
    device const float* key [[buffer(1)]],
    device const float* value [[buffer(2)]],
    device float* output [[buffer(3)]],
    constant AttentionParams& params [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]]
) {
    // STUB: See MLX Python implementation
}
