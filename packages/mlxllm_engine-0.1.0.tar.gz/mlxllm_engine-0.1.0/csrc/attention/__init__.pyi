"""Type stubs for csrc.attention module."""

from typing import Optional
import torch

# Paged attention operations
def paged_attention_v1(
    out: torch.Tensor,
    query: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    num_kv_heads: int,
    scale: float,
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    block_size: int,
    max_seq_len: int,
    alibi_slopes: Optional[torch.Tensor] = None,
    kv_cache_dtype: str = "auto",
    k_scale: float = 1.0,
    v_scale: float = 1.0,
    tp_rank: int = 0,
    blocksparse_local_blocks: int = -1,
    blocksparse_vert_stride: int = -1,
    blocksparse_block_size: int = -1,
    blocksparse_head_sliding_step: int = -1,
) -> None: ...

def paged_attention_v2(
    out: torch.Tensor,
    exp_sums: torch.Tensor,
    max_logits: torch.Tensor,
    tmp_out: torch.Tensor,
    query: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    num_kv_heads: int,
    scale: float,
    block_tables: torch.Tensor,
    seq_lens: torch.Tensor,
    block_size: int,
    max_seq_len: int,
    alibi_slopes: Optional[torch.Tensor] = None,
    kv_cache_dtype: str = "auto",
    k_scale: float = 1.0,
    v_scale: float = 1.0,
    tp_rank: int = 0,
    blocksparse_local_blocks: int = -1,
    blocksparse_vert_stride: int = -1,
    blocksparse_block_size: int = -1,
    blocksparse_head_sliding_step: int = -1,
) -> None: ...

# KV cache operations
def reshape_and_cache(
    key: torch.Tensor,
    value: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str = "auto",
    k_scale: float = 1.0,
    v_scale: float = 1.0,
) -> None: ...

def copy_blocks(
    key_caches: list[torch.Tensor],
    value_caches: list[torch.Tensor],
    block_mapping: torch.Tensor,
) -> None: ...

def swap_blocks(
    src: torch.Tensor,
    dst: torch.Tensor,
    block_mapping: torch.Tensor,
) -> None: ...

def reshape_and_cache_flash(
    key: torch.Tensor,
    value: torch.Tensor,
    key_cache: torch.Tensor,
    value_cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    kv_cache_dtype: str = "auto",
    k_scale: float = 1.0,
    v_scale: float = 1.0,
) -> None: ...

# Position encoding
def rotary_embedding(
    positions: torch.Tensor,
    query: torch.Tensor,
    key: Optional[torch.Tensor] = None,
    head_size: int = ...,
    cos_sin_cache: torch.Tensor = ...,
    is_neox: bool = True,
) -> None: ...

# Normalization
def rms_norm(
    out: torch.Tensor,
    input: torch.Tensor,
    weight: torch.Tensor,
    epsilon: float,
) -> None: ...

def fused_add_rms_norm(
    input: torch.Tensor,
    residual: torch.Tensor,
    weight: torch.Tensor,
    epsilon: float,
) -> None: ...

# Activations
def silu_and_mul(out: torch.Tensor, input: torch.Tensor) -> None: ...
def gelu_and_mul(out: torch.Tensor, input: torch.Tensor) -> None: ...
def gelu_tanh_and_mul(out: torch.Tensor, input: torch.Tensor) -> None: ...
def gelu_new(out: torch.Tensor, input: torch.Tensor) -> None: ...
def gelu_fast(out: torch.Tensor, input: torch.Tensor) -> None: ...

# Utilities
def get_metal_cache_block_size(available_memory_mb: int) -> int: ...
def is_metal_supported_cache_dtype(dtype: str) -> bool: ...
def is_available() -> bool: ...
def get_import_error() -> Optional[str]: ...

__version__: str
__backend__: str
