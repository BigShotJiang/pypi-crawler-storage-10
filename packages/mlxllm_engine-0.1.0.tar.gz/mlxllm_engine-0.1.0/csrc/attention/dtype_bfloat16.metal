#include <metal_stdlib>
#include "attention_dtypes.h"
using namespace metal;

// ============================================================================
// BFloat16 Attention Kernel Stubs
// ============================================================================
// NOTE: MLX handles dtype-specific kernels automatically.
// BFloat16 requires conversion utilities from attention_dtypes.h
// ============================================================================

// Generic attention with bfloat16
kernel void attention_bfloat16_kernel(
    device const bfloat16_t* query [[buffer(0)]],
    device const bfloat16_t* key [[buffer(1)]],
    device const bfloat16_t* value [[buffer(2)]],
    device bfloat16_t* output [[buffer(3)]],
    constant AttentionParams& params [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]]
) {
    // STUB: Convert to float32, compute attention, convert back
    // See MLX Python implementation with mx.bfloat16 dtype
}
