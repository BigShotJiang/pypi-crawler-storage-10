#include <metal_stdlib>
#include "attention_dtypes.h"

using namespace metal;

// ============================================================================
// Vertical Slash Indexing for Grouped Query Attention
// ============================================================================
//
// Vertical slash indexing is used in GQA to map query heads to KV heads.
// In GQA, multiple query heads share the same KV head (vertical slicing).
//
// Example: 32 query heads, 8 KV heads
// - Query heads 0-3 use KV head 0
// - Query heads 4-7 use KV head 1
// - ... (groups of 4)
//
// NOTE: Actual implementation uses MLX array indexing
//
// ============================================================================

// ============================================================================
// Compute KV Head Indices for Query Heads
// ============================================================================

kernel void compute_kv_head_indices_kernel(
    device int* __restrict__ kv_head_indices [[buffer(0)]],  // Output: [num_query_heads]
    constant uint& num_query_heads [[buffer(1)]],
    constant uint& num_kv_heads [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_query_heads) return;

    // Compute which KV head this query head uses
    uint num_groups = num_query_heads / num_kv_heads;
    uint kv_head = tid / num_groups;

    kv_head_indices[tid] = int(kv_head);
}

// ============================================================================
// Vertical Slice - Extract KV for Specific Query Head
// ============================================================================

kernel void vertical_slice_kv_kernel(
    device float* __restrict__ sliced_kv [[buffer(0)]],      // Output: [batch, seq_len, head_dim]
    device const float* __restrict__ full_kv [[buffer(1)]],  // Input: [batch, seq_len, num_kv_heads, head_dim]
    constant uint& batch_size [[buffer(2)]],
    constant uint& seq_len [[buffer(3)]],
    constant uint& num_kv_heads [[buffer(4)]],
    constant uint& head_dim [[buffer(5)]],
    constant uint& target_kv_head [[buffer(6)]],             // Which KV head to extract
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = batch_size * seq_len * head_dim;
    if (tid >= total_elements) return;

    // Decode indices
    uint batch = tid / (seq_len * head_dim);
    uint remainder = tid % (seq_len * head_dim);
    uint seq = remainder / head_dim;
    uint dim = remainder % head_dim;

    // Extract from target KV head
    uint input_idx = batch * (seq_len * num_kv_heads * head_dim) +
                     seq * (num_kv_heads * head_dim) +
                     target_kv_head * head_dim +
                     dim;

    sliced_kv[tid] = full_kv[input_idx];
}

// ============================================================================
// Gather KV Heads for Query Heads (Batch Version)
// ============================================================================

kernel void gather_kv_for_queries_kernel(
    device float* __restrict__ output_kv [[buffer(0)]],       // [batch, seq_len, num_query_heads, head_dim]
    device const float* __restrict__ input_kv [[buffer(1)]],  // [batch, seq_len, num_kv_heads, head_dim]
    device const int* __restrict__ kv_indices [[buffer(2)]],  // [num_query_heads] -> KV head mapping
    constant uint& batch_size [[buffer(3)]],
    constant uint& seq_len [[buffer(4)]],
    constant uint& num_query_heads [[buffer(5)]],
    constant uint& num_kv_heads [[buffer(6)]],
    constant uint& head_dim [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = batch_size * seq_len * num_query_heads * head_dim;
    if (tid >= total_elements) return;

    // Decode output indices
    uint batch = tid / (seq_len * num_query_heads * head_dim);
    uint remainder = tid % (seq_len * num_query_heads * head_dim);
    uint seq = remainder / (num_query_heads * head_dim);
    remainder = remainder % (num_query_heads * head_dim);
    uint query_head = remainder / head_dim;
    uint dim = remainder % head_dim;

    // Get corresponding KV head
    uint kv_head = uint(kv_indices[query_head]);

    // Read from KV tensor
    uint input_idx = batch * (seq_len * num_kv_heads * head_dim) +
                     seq * (num_kv_heads * head_dim) +
                     kv_head * head_dim +
                     dim;

    output_kv[tid] = input_kv[input_idx];
}

// ============================================================================
// Inverse Vertical Slice - Scatter to KV Heads
// ============================================================================

kernel void scatter_to_kv_heads_kernel(
    device float* __restrict__ kv_tensor [[buffer(0)]],      // [batch, seq_len, num_kv_heads, head_dim]
    device const float* __restrict__ updates [[buffer(1)]],   // [batch, seq_len, num_query_heads, head_dim]
    device const int* __restrict__ kv_indices [[buffer(2)]],  // [num_query_heads]
    device float* __restrict__ reduction_buffer [[buffer(3)]], // For atomic adds
    constant uint& batch_size [[buffer(4)]],
    constant uint& seq_len [[buffer(5)]],
    constant uint& num_query_heads [[buffer(6)]],
    constant uint& num_kv_heads [[buffer(7)]],
    constant uint& head_dim [[buffer(8)]],
    uint tid [[thread_position_in_grid]]
) {
    // STUB: Scatter query head updates back to KV heads
    // Used in MQA/GQA training (not typical in inference)
}

// ============================================================================
// Compute Vertical Slice Offsets
// ============================================================================

kernel void compute_vertical_slice_offsets_kernel(
    device uint* __restrict__ offsets [[buffer(0)]],         // Output: [num_query_heads + 1]
    device const int* __restrict__ kv_indices [[buffer(1)]], // [num_query_heads]
    constant uint& num_query_heads [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    // STUB: Compute cumulative offsets for each KV group
    // Used for efficient batch gathering
}

// ============================================================================
// Documentation
// ============================================================================

/*
 * Vertical Slicing in GQA/MQA:
 *
 * Standard Multi-Head Attention (MHA):
 *   - num_query_heads == num_kv_heads
 *   - Each query head has its own KV head
 *   - Memory: O(num_heads * 2 * head_dim) for KV cache
 *
 * Multi-Query Attention (MQA):
 *   - num_kv_heads = 1
 *   - All query heads share single KV head
 *   - Memory: O(2 * head_dim) for KV cache
 *   - Faster but may reduce quality
 *
 * Grouped Query Attention (GQA):
 *   - num_kv_heads < num_query_heads
 *   - num_query_heads = n * num_kv_heads (groups)
 *   - Each KV head shared by n query heads
 *   - Memory: O(num_kv_heads * 2 * head_dim)
 *   - Balance between MHA quality and MQA speed
 *
 * Vertical Slicing:
 *   Query heads are "vertically sliced" into groups:
 *   
 *   num_query_heads = 32, num_kv_heads = 8
 *   num_groups = 32 / 8 = 4
 *
 *   Q heads: [0, 1, 2, 3] | [4, 5, 6, 7] | ... | [28, 29, 30, 31]
 *            |             |             |       |
 *   KV head:    0              1         ...         7
 *
 *   Each "slice" contains num_groups query heads.
 *
 * Implementation in MLX:
 *   Python code uses mx.repeat() to expand KV heads:
 *   
 *   key = mx.repeat(key, num_groups, axis=kv_head_dim)
 *   
 *   This automatically handles vertical slicing without
 *   explicit indexing kernels.
 *
 * Usage:
 *   These kernels are primarily for:
 *   1. Explicit index computation (debugging)
 *   2. Custom attention implementations
 *   3. Mixed-precision KV cache (different dtype per group)
 */
