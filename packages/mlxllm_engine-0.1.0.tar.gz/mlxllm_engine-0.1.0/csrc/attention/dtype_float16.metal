#include <metal_stdlib>
#include "attention_dtypes.h"
using namespace metal;

// ============================================================================
// Float16 (half) Attention Kernel Stubs
// ============================================================================
// NOTE: MLX handles dtype-specific kernels automatically.
// These are reference signatures only.
// ============================================================================

// Generic attention with float16
kernel void attention_float16_kernel(
    device const half* query [[buffer(0)]],
    device const half* key [[buffer(1)]],
    device const half* value [[buffer(2)]],
    device half* output [[buffer(3)]],
    constant AttentionParams& params [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]]
) {
    // STUB: See MLX Python implementation
}
