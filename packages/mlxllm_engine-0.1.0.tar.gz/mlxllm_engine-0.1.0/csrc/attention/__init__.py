"""
Attention Operations Module for MLX-LLM.

This module provides Metal-optimized attention operations including:
- Paged attention (V1 and V2)
- KV cache management
- Rotary position embeddings (RoPE)
- RMS normalization
- Activation functions (SiLU, GELU, etc.)

Example:
    >>> from csrc.attention import paged_attention_v1, reshape_and_cache
    >>> import torch
    >>>
    >>> # Paged attention
    >>> query = torch.randn(32, 32, 128, device='mps')  # [batch, heads, dim]
    >>> key_cache = torch.zeros(1000, 16, 32, 128, device='mps')  # [blocks, block_size, heads, dim]
    >>> value_cache = torch.zeros_like(key_cache)
    >>> out = torch.empty_like(query)
    >>>
    >>> paged_attention_v1(
    ...     out=out,
    ...     query=query,
    ...     key_cache=key_cache,
    ...     value_cache=value_cache,
    ...     num_kv_heads=32,
    ...     scale=1.0/128**0.5,
    ...     block_tables=block_tables,
    ...     seq_lens=seq_lens,
    ...     block_size=16,
    ...     max_seq_len=2048
    ... )
"""

from typing import Optional

# Check if the compiled extension is available
try:
    from . import _attention_ops  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

# Re-export everything from the compiled extension
if _EXTENSION_AVAILABLE:
    # Paged attention operations
    from ._attention_ops import (
        paged_attention_v1,
        paged_attention_v2,
    )

    # KV cache operations
    from ._attention_ops import (
        reshape_and_cache,
        copy_blocks,
        swap_blocks,
        reshape_and_cache_flash,
    )

    # Position encoding
    from ._attention_ops import rotary_embedding

    # Normalization
    from ._attention_ops import (
        rms_norm,
        fused_add_rms_norm,
    )

    # Activations
    from ._attention_ops import (
        silu_and_mul,
        gelu_and_mul,
        gelu_tanh_and_mul,
        gelu_new,
        gelu_fast,
    )

    # Utilities
    from ._attention_ops import (
        get_metal_cache_block_size,
        is_metal_supported_cache_dtype,
    )

    __all__ = [
        # Attention
        'paged_attention_v1',
        'paged_attention_v2',
        # Cache
        'reshape_and_cache',
        'copy_blocks',
        'swap_blocks',
        'reshape_and_cache_flash',
        # Position encoding
        'rotary_embedding',
        # Normalization
        'rms_norm',
        'fused_add_rms_norm',
        # Activations
        'silu_and_mul',
        'gelu_and_mul',
        'gelu_tanh_and_mul',
        'gelu_new',
        'gelu_fast',
        # Utilities
        'get_metal_cache_block_size',
        'is_metal_supported_cache_dtype',
        'is_available',
    ]
else:
    # Provide error stubs
    def _unavailable(*args, **kwargs):
        raise RuntimeError(
            f"Attention extension not available. "
            f"Please build the extension first. Import error: {_IMPORT_ERROR}"
        )

    # Stub all functions
    paged_attention_v1 = _unavailable
    paged_attention_v2 = _unavailable
    reshape_and_cache = _unavailable
    copy_blocks = _unavailable
    swap_blocks = _unavailable
    reshape_and_cache_flash = _unavailable
    rotary_embedding = _unavailable
    rms_norm = _unavailable
    fused_add_rms_norm = _unavailable
    silu_and_mul = _unavailable
    gelu_and_mul = _unavailable
    gelu_tanh_and_mul = _unavailable
    gelu_new = _unavailable
    gelu_fast = _unavailable
    get_metal_cache_block_size = _unavailable
    is_metal_supported_cache_dtype = _unavailable

    __all__ = [
        'paged_attention_v1',
        'paged_attention_v2',
        'reshape_and_cache',
        'copy_blocks',
        'swap_blocks',
        'reshape_and_cache_flash',
        'rotary_embedding',
        'rms_norm',
        'fused_add_rms_norm',
        'silu_and_mul',
        'gelu_and_mul',
        'gelu_tanh_and_mul',
        'gelu_new',
        'gelu_fast',
        'get_metal_cache_block_size',
        'is_metal_supported_cache_dtype',
        'is_available',
    ]


def is_available() -> bool:
    """
    Check if the Attention extension is available.

    Returns:
        True if extension is compiled and loaded, False otherwise
    """
    return _EXTENSION_AVAILABLE


def get_import_error() -> Optional[str]:
    """
    Get the import error message if extension failed to load.

    Returns:
        Error message string if extension unavailable, None if available
    """
    if _EXTENSION_AVAILABLE:
        return None
    return _IMPORT_ERROR


# Module metadata
__version__ = "0.1.0"
__backend__ = "Metal" if _EXTENSION_AVAILABLE else "None"
