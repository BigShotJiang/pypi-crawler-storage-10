#include <metal_stdlib>
#include "attention_dtypes.h"

using namespace metal;

// ============================================================================
// Attention Utility Kernels for MLX-LLM
// ============================================================================
//
// This file provides utility functions for attention operations:
// - Causal mask generation
// - Sliding window masks
// - Index calculations for paged attention
// - ALiBi slope computation
//
// Note: These are helper utilities. Main attention computation is handled
// by MLX framework which automatically optimizes for Metal.
//
// ============================================================================

// ============================================================================
// Causal Mask Generation
// ============================================================================

// Generate causal mask for autoregressive attention
// mask[i, j] = 0 if j <= i, else -inf
kernel void generate_causal_mask(
    device float* __restrict__ mask [[buffer(0)]],
    constant uint& seq_len [[buffer(1)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint row = gid.y;
    uint col = gid.x;

    if (row >= seq_len || col >= seq_len) return;

    uint idx = row * seq_len + col;

    // Causal: can attend to current and previous tokens
    mask[idx] = (col <= row) ? 0.0f : -INFINITY;
}

// Generate causal mask with sliding window
kernel void generate_causal_sliding_window_mask(
    device float* __restrict__ mask [[buffer(0)]],
    constant uint& seq_len [[buffer(1)]],
    constant uint& window_size [[buffer(2)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint row = gid.y;
    uint col = gid.x;

    if (row >= seq_len || col >= seq_len) return;

    uint idx = row * seq_len + col;

    // Can only attend within window: [row - window_size, row]
    bool in_window = (col <= row) && (row - col <= window_size);
    mask[idx] = in_window ? 0.0f : -INFINITY;
}

// ============================================================================
// ALiBi (Attention with Linear Biases) Utilities
// ============================================================================

// Compute ALiBi slopes for num_heads
// slopes[i] = -(2^(-8i/num_heads))
kernel void compute_alibi_slopes(
    device float* __restrict__ slopes [[buffer(0)]],
    constant uint& num_heads [[buffer(1)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_heads) return;

    // ALiBi slope formula
    float base = 2.0f;
    float exponent = -8.0f * float(tid) / float(num_heads);
    slopes[tid] = -pow(base, exponent);
}

// Apply ALiBi biases to attention scores
// scores[i, j] += slopes[head] * (j - i)
kernel void apply_alibi_bias(
    device float* __restrict__ scores [[buffer(0)]],        // [batch, num_heads, seq_len, seq_len]
    device const float* __restrict__ slopes [[buffer(1)]],  // [num_heads]
    constant uint& batch_size [[buffer(2)]],
    constant uint& num_heads [[buffer(3)]],
    constant uint& seq_len [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]]
) {
    uint batch = gid.z;
    uint head = gid.y;
    uint row = gid.x / seq_len;
    uint col = gid.x % seq_len;

    if (batch >= batch_size || head >= num_heads || row >= seq_len || col >= seq_len) return;

    uint idx = batch * (num_heads * seq_len * seq_len) +
               head * (seq_len * seq_len) +
               row * seq_len +
               col;

    // Distance-based bias
    int distance = int(col) - int(row);
    scores[idx] += slopes[head] * float(distance);
}

// ============================================================================
// Paged Attention Index Calculation
// ============================================================================

// Convert logical token position to (block_id, offset_in_block)
kernel void compute_slot_mapping(
    device int* __restrict__ block_ids [[buffer(0)]],      // Output: block IDs
    device int* __restrict__ offsets [[buffer(1)]],        // Output: offsets
    device const int* __restrict__ block_table [[buffer(2)]],  // [batch_size, max_blocks]
    device const int* __restrict__ seq_lens [[buffer(3)]],     // [batch_size]
    constant uint& batch_size [[buffer(4)]],
    constant uint& max_blocks [[buffer(5)]],
    constant uint& block_size [[buffer(6)]],
    uint2 gid [[thread_position_in_grid]]
) {
    uint batch_idx = gid.y;
    uint token_idx = gid.x;

    if (batch_idx >= batch_size) return;

    int seq_len = seq_lens[batch_idx];
    if (token_idx >= uint(seq_len)) return;

    // Calculate block and offset
    uint block_num = token_idx / block_size;
    uint offset = token_idx % block_size;

    if (block_num >= max_blocks) {
        block_ids[batch_idx * seq_len + token_idx] = -1;
        offsets[batch_idx * seq_len + token_idx] = -1;
        return;
    }

    // Get physical block ID from block table
    int physical_block = block_table[batch_idx * max_blocks + block_num];

    block_ids[batch_idx * seq_len + token_idx] = physical_block;
    offsets[batch_idx * seq_len + token_idx] = int(offset);
}

// ============================================================================
// Softmax Utilities
// ============================================================================

// Row-wise softmax with numerical stability (log-sum-exp trick)
kernel void softmax_inplace(
    device float* __restrict__ data [[buffer(0)]],  // [num_rows, row_size]
    constant uint& num_rows [[buffer(1)]],
    constant uint& row_size [[buffer(2)]],
    uint gid [[threadgroup_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    if (gid >= num_rows) return;

    threadgroup float shared_max[256];
    threadgroup float shared_sum[256];

    device float* row = data + gid * row_size;

    // Find max for numerical stability
    float local_max = -INFINITY;
    for (uint i = tid; i < row_size; i += tg_size) {
        local_max = max(local_max, row[i]);
    }
    shared_max[tid] = local_max;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Reduction to find global max
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_max[tid] = max(shared_max[tid], shared_max[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float row_max = shared_max[0];
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Compute exp(x - max) and sum
    float local_sum = 0.0f;
    for (uint i = tid; i < row_size; i += tg_size) {
        float val = exp(row[i] - row_max);
        row[i] = val;
        local_sum += val;
    }
    shared_sum[tid] = local_sum;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Reduction to find sum
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    float row_sum = shared_sum[0];
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Normalize
    for (uint i = tid; i < row_size; i += tg_size) {
        row[i] = SAFE_DIV(row[i], row_sum, EPSILON_FP32);
    }
}

// ============================================================================
// Grouped Query Attention (GQA) Utilities
// ============================================================================

// Repeat KV heads for GQA: [num_kv_heads] -> [num_heads]
kernel void repeat_kv_heads(
    device const float* __restrict__ input [[buffer(0)]],   // [batch, seq_len, num_kv_heads, head_dim]
    device float* __restrict__ output [[buffer(1)]],        // [batch, seq_len, num_heads, head_dim]
    constant uint& batch_size [[buffer(2)]],
    constant uint& seq_len [[buffer(3)]],
    constant uint& num_heads [[buffer(4)]],
    constant uint& num_kv_heads [[buffer(5)]],
    constant uint& head_dim [[buffer(6)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = batch_size * seq_len * num_heads * head_dim;
    if (tid >= total_elements) return;

    // Decode indices
    uint batch = tid / (seq_len * num_heads * head_dim);
    uint remainder = tid % (seq_len * num_heads * head_dim);
    uint seq = remainder / (num_heads * head_dim);
    remainder = remainder % (num_heads * head_dim);
    uint head = remainder / head_dim;
    uint dim = remainder % head_dim;

    // Map to corresponding KV head
    uint num_groups = num_heads / num_kv_heads;
    uint kv_head = head / num_groups;

    // Calculate input index
    uint input_idx = batch * (seq_len * num_kv_heads * head_dim) +
                     seq * (num_kv_heads * head_dim) +
                     kv_head * head_dim +
                     dim;

    output[tid] = input[input_idx];
}

// ============================================================================
// Rotary Position Embedding (RoPE) Utilities
// ============================================================================

// Apply RoPE to query/key tensors
kernel void apply_rotary_pos_emb(
    device float* __restrict__ query [[buffer(0)]],         // [batch, seq_len, num_heads, head_dim]
    device float* __restrict__ key [[buffer(1)]],           // [batch, seq_len, num_kv_heads, head_dim]
    device const float* __restrict__ cos_cache [[buffer(2)]], // [max_seq_len, head_dim/2]
    device const float* __restrict__ sin_cache [[buffer(3)]], // [max_seq_len, head_dim/2]
    device const int* __restrict__ positions [[buffer(4)]],   // [batch, seq_len]
    constant uint& batch_size [[buffer(5)]],
    constant uint& seq_len [[buffer(6)]],
    constant uint& num_heads [[buffer(7)]],
    constant uint& num_kv_heads [[buffer(8)]],
    constant uint& head_dim [[buffer(9)]],
    uint3 gid [[thread_position_in_grid]]
) {
    uint batch = gid.z;
    uint seq = gid.y;
    uint head = gid.x;

    if (batch >= batch_size || seq >= seq_len) return;

    int pos = positions[batch * seq_len + seq];
    if (pos < 0) return;

    // Apply to query (if head < num_heads)
    if (head < num_heads) {
        device float* q = query + batch * (seq_len * num_heads * head_dim) +
                                 seq * (num_heads * head_dim) +
                                 head * head_dim;

        for (uint i = 0; i < head_dim / 2; i++) {
            float cos_val = cos_cache[pos * (head_dim / 2) + i];
            float sin_val = sin_cache[pos * (head_dim / 2) + i];

            float q0 = q[2 * i];
            float q1 = q[2 * i + 1];

            q[2 * i] = q0 * cos_val - q1 * sin_val;
            q[2 * i + 1] = q0 * sin_val + q1 * cos_val;
        }
    }

    // Apply to key (if head < num_kv_heads)
    if (head < num_kv_heads) {
        device float* k = key + batch * (seq_len * num_kv_heads * head_dim) +
                                seq * (num_kv_heads * head_dim) +
                                head * head_dim;

        for (uint i = 0; i < head_dim / 2; i++) {
            float cos_val = cos_cache[pos * (head_dim / 2) + i];
            float sin_val = sin_cache[pos * (head_dim / 2) + i];

            float k0 = k[2 * i];
            float k1 = k[2 * i + 1];

            k[2 * i] = k0 * cos_val - k1 * sin_val;
            k[2 * i + 1] = k0 * sin_val + k1 * cos_val;
        }
    }
}

// ============================================================================
// Batch Index Utilities
// ============================================================================

// Convert cumulative sequence lengths to batch indices
kernel void cu_seqlens_to_batch_indices(
    device int* __restrict__ batch_indices [[buffer(0)]],      // Output: [total_tokens]
    device const int* __restrict__ cu_seqlens [[buffer(1)]],   // [batch_size + 1]
    constant uint& batch_size [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= batch_size) return;

    int start = cu_seqlens[tid];
    int end = cu_seqlens[tid + 1];

    for (int i = start; i < end; i++) {
        batch_indices[i] = int(tid);
    }
}

// ============================================================================
// Memory Layout Conversion
// ============================================================================

// Transpose: [batch, seq_len, num_heads, head_dim] -> [batch, num_heads, seq_len, head_dim]
kernel void transpose_attention_layout(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& batch_size [[buffer(2)]],
    constant uint& seq_len [[buffer(3)]],
    constant uint& num_heads [[buffer(4)]],
    constant uint& head_dim [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total_elements = batch_size * seq_len * num_heads * head_dim;
    if (tid >= total_elements) return;

    // Decode input indices: [batch, seq, head, dim]
    uint batch = tid / (seq_len * num_heads * head_dim);
    uint remainder = tid % (seq_len * num_heads * head_dim);
    uint seq = remainder / (num_heads * head_dim);
    remainder = remainder % (num_heads * head_dim);
    uint head = remainder / head_dim;
    uint dim = remainder % head_dim;

    // Encode output indices: [batch, head, seq, dim]
    uint output_idx = batch * (num_heads * seq_len * head_dim) +
                      head * (seq_len * head_dim) +
                      seq * head_dim +
                      dim;

    output[output_idx] = input[tid];
}
