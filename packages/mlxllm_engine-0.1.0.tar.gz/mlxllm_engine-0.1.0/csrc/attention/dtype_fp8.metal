#include <metal_stdlib>
#include "attention_dtypes.h"
using namespace metal;

// ============================================================================
// FP8 Attention Kernel Stubs (Quantized KV Cache)
// ============================================================================
// NOTE: MLX handles dtype-specific kernels automatically.
// FP8 requires quantization/dequantization from attention_dtypes.h
// ============================================================================

// Generic attention with FP8 E4M3 KV cache
kernel void attention_fp8_e4m3_kernel(
    device const half* query [[buffer(0)]],            // Query usually in FP16
    device const fp8_e4m3_t* key [[buffer(1)]],       // Quantized key
    device const fp8_e4m3_t* value [[buffer(2)]],     // Quantized value
    device half* output [[buffer(3)]],
    device const float* kv_scale [[buffer(4)]],       // Dequantization scale
    constant AttentionParams& params [[buffer(5)]],
    uint3 gid [[thread_position_in_grid]]
) {
    // STUB: Dequantize K/V, compute attention
    // Used for extreme memory savings (experimental)
}

// Generic attention with FP8 E5M2 KV cache
kernel void attention_fp8_e5m2_kernel(
    device const half* query [[buffer(0)]],
    device const fp8_e5m2_t* key [[buffer(1)]],
    device const fp8_e5m2_t* value [[buffer(2)]],
    device half* output [[buffer(3)]],
    device const float* kv_scale [[buffer(4)]],
    constant AttentionParams& params [[buffer(5)]],
    uint3 gid [[thread_position_in_grid]]
) {
    // STUB: E5M2 variant for larger dynamic range
}
