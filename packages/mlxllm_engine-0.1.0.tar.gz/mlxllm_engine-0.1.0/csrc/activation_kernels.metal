#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Activation Function Kernels for mlxllm
// Optimized for Apple Silicon (M1/M2/M3/M4)
// ============================================================================

// Helper: SiLU (Swish) activation function
// SiLU(x) = x * sigmoid(x) = x / (1 + exp(-x))
template<typename T>
inline T silu(T x) {
    return x / (1.0f + exp(-x));
}

// Helper: GELU activation (exact)
// GELU(x) = x * �(x) where � is the CDF of standard normal distribution
template<typename T>
inline T gelu_exact(T x) {
    const T sqrt_2_over_pi = 0.7978845608028654f;  // sqrt(2/�)
    const T a = 0.044715f;
    T x_cubed = x * x * x;
    T inner = sqrt_2_over_pi * (x + a * x_cubed);
    return 0.5f * x * (1.0f + tanh(inner));
}

// Helper: GELU fast approximation
template<typename T>
inline T gelu_fast(T x) {
    return 0.5f * x * (1.0f + tanh(0.7978845608f * (x + 0.044715f * x * x * x)));
}

// Helper: GELU quick approximation
template<typename T>
inline T gelu_quick(T x) {
    return x * (1.0f / (1.0f + exp(-1.702f * x)));
}

// Helper: GELU tanh approximation
template<typename T>
inline T gelu_tanh(T x) {
    const T sqrt_2_over_pi = 0.7978845608028654f;
    return 0.5f * x * (1.0f + tanh(sqrt_2_over_pi * x));
}

// ============================================================================
// SiLU and Multiply (SwiGLU)
// ============================================================================

kernel void silu_and_mul_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    // Input has shape [num_tokens, 2*d]
    // First half is gate, second half is value
    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    // Apply SiLU to gate and multiply with value
    output[tid] = silu(gate) * value;
}

kernel void silu_and_mul_kernel_half(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    half gate = input[input_idx_gate];
    half value = input[input_idx_value];

    output[tid] = silu(gate) * value;
}

// ============================================================================
// GELU and Multiply
// ============================================================================

kernel void gelu_and_mul_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    output[tid] = gelu_exact(gate) * value;
}

kernel void gelu_and_mul_kernel_half(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    half gate = input[input_idx_gate];
    half value = input[input_idx_value];

    output[tid] = gelu_exact(gate) * value;
}

// ============================================================================
// GELU Tanh and Multiply
// ============================================================================

kernel void gelu_tanh_and_mul_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    output[tid] = gelu_tanh(gate) * value;
}

// ============================================================================
// GELU New (exact implementation)
// ============================================================================

kernel void gelu_new_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_exact(input[tid]);
}

kernel void gelu_new_kernel_half(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_exact(input[tid]);
}

// ============================================================================
// GELU Fast
// ============================================================================

kernel void gelu_fast_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_fast(input[tid]);
}

kernel void gelu_fast_kernel_half(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_fast(input[tid]);
}

// ============================================================================
// GELU Quick
// ============================================================================

kernel void gelu_quick_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_quick(input[tid]);
}

kernel void gelu_quick_kernel_half(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = gelu_quick(input[tid]);
}

// ============================================================================
// FATReLU and Multiply
// FATReLU(x) = max(0, x) if |x| <= threshold, else x
// ============================================================================

kernel void fatrelu_and_mul_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    constant float& threshold [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    // Apply FATReLU
    float activated;
    if (abs(gate) <= threshold) {
        activated = max(0.0f, gate);
    } else {
        activated = gate;
    }

    output[tid] = activated * value;
}

// ============================================================================
// SwiGLU OAI variant
// ============================================================================

kernel void swigluoai_and_mul_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    constant float& alpha [[buffer(4)]],
    constant float& limit [[buffer(5)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    // Clamp gate to [-limit, limit]
    gate = clamp(gate, -limit, limit);

    // Apply scaled SiLU
    float activated = alpha * silu(gate);

    output[tid] = activated * value;
}

// ============================================================================
// Multiply and SiLU (reverse order)
// ============================================================================

kernel void mul_and_silu_kernel(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& num_tokens [[buffer(2)]],
    constant uint& d [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_tokens * d) return;

    uint token_idx = tid / d;
    uint feature_idx = tid % d;

    uint input_idx_gate = token_idx * (2 * d) + feature_idx;
    uint input_idx_value = token_idx * (2 * d) + d + feature_idx;

    float gate = input[input_idx_gate];
    float value = input[input_idx_value];

    // Multiply first, then apply SiLU
    output[tid] = silu(gate * value);
}

// ============================================================================
// Optimized SIMD versions for better performance on Apple Silicon
// ============================================================================

// SiLU and multiply with SIMD (processes 4 elements at a time)
kernel void silu_and_mul_kernel_simd(
    device const float4* input [[buffer(0)]],
    device float4* output [[buffer(1)]],
    constant uint& num_elements [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_elements) return;

    // Load 4 elements at once
    float4 gate = input[tid * 2];
    float4 value = input[tid * 2 + 1];

    // Apply SiLU element-wise
    float4 result;
    result.x = silu(gate.x) * value.x;
    result.y = silu(gate.y) * value.y;
    result.z = silu(gate.z) * value.z;
    result.w = silu(gate.w) * value.w;

    output[tid] = result;
}
