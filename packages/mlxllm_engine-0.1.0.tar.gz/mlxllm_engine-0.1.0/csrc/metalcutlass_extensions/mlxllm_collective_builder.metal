/**
 * @file mlxllm_collective_builder.metal
 * @brief Collective operations and building blocks for distributed/batched inference
 * 
 * Provides collective operations like AllReduce, AllGather, ReduceScatter,
 * and other primitives useful for multi-GPU or batched inference scenarios.
 * 
 * Note: For single-GPU Apple Silicon (typical case), these are primarily
 * optimized for batched operations rather than true multi-device collectives.
 */

#include <metal_stdlib>
#include <metal_atomic>
using namespace metal;

// ============================================================================
// Constants and Configuration
// ============================================================================

constant uint MAX_THREADS_PER_THREADGROUP = 1024;
constant uint WARP_SIZE = 32;  // SIMD width on Apple GPUs

// ============================================================================
// Reduction Operations
// ============================================================================

/**
 * @brief Reduction operation types
 */
enum class ReduceOp : uint {
    SUM = 0,
    MAX = 1,
    MIN = 2,
    PROD = 3,
    AVG = 4
};

/**
 * @brief Apply reduction operation
 */
template<typename T>
inline T apply_reduce_op(T a, T b, ReduceOp op) {
    switch (op) {
        case ReduceOp::SUM:
            return a + b;
        case ReduceOp::MAX:
            return max(a, b);
        case ReduceOp::MIN:
            return min(a, b);
        case ReduceOp::PROD:
            return a * b;
        default:
            return a + b;
    }
}

/**
 * @brief Threadgroup-level reduction
 * 
 * Efficiently reduces values across all threads in a threadgroup.
 */
template<typename T>
inline T threadgroup_reduce(
    T val,
    threadgroup T* shared,
    uint tid,
    uint threadgroup_size,
    ReduceOp op)
{
    shared[tid] = val;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    
    // Tree-based reduction
    for (uint s = threadgroup_size / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared[tid] = apply_reduce_op(shared[tid], shared[tid + s], op);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    
    return shared[0];
}

// ============================================================================
// AllReduce Implementation
// ============================================================================

/**
 * @brief AllReduce across batches (batch-parallel reduction)
 * 
 * Reduces tensors across batch dimension and broadcasts result.
 * Useful for gradient accumulation or batch statistics.
 */
kernel void allreduce_batch_f32(
    device const float* inputs [[buffer(0)]],   // [batch_size, size]
    device float* output [[buffer(1)]],         // [size]
    constant uint& batch_size [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    constant uint& reduce_op [[buffer(4)]],
    uint gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    if (gid >= size) return;
    
    ReduceOp op = ReduceOp(reduce_op);
    
    // Reduce across batch dimension
    float result = inputs[0 * size + gid];
    for (uint b = 1; b < batch_size; ++b) {
        result = apply_reduce_op(result, inputs[b * size + gid], op);
    }
    
    // Apply averaging if needed
    if (op == ReduceOp::AVG) {
        result /= float(batch_size);
    }
    
    output[gid] = result;
}

/**
 * @brief AllReduce with atomic operations (for smaller tensors)
 */
kernel void allreduce_atomic_f32(
    device const float* input [[buffer(0)]],
    device atomic_uint* output [[buffer(1)]],  // Atomic accumulation
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    // Convert to uint for atomic operations
    uint val_as_uint = as_type<uint>(input[gid]);
    atomic_fetch_add_explicit(
        &output[gid],
        val_as_uint,
        memory_order_relaxed
    );
}

// ============================================================================
// AllGather Implementation
// ============================================================================

/**
 * @brief AllGather across batches
 * 
 * Gathers tensors from all batch elements into a single concatenated tensor.
 */
kernel void allgather_batch_f32(
    device const float* input [[buffer(0)]],    // [size]
    device float* output [[buffer(1)]],         // [batch_size, size]
    constant uint& batch_id [[buffer(2)]],
    constant uint& batch_size [[buffer(3)]],
    constant uint& size [[buffer(4)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    // Copy input to appropriate batch position
    output[batch_id * size + gid] = input[gid];
}

// ============================================================================
// ReduceScatter Implementation
// ============================================================================

/**
 * @brief ReduceScatter across batches
 * 
 * Reduces input tensors and scatters the result across batch dimension.
 */
kernel void reduce_scatter_batch_f32(
    device const float* inputs [[buffer(0)]],   // [batch_size, total_size]
    device float* output [[buffer(1)]],         // [chunk_size]
    constant uint& batch_id [[buffer(2)]],
    constant uint& batch_size [[buffer(3)]],
    constant uint& total_size [[buffer(4)]],
    constant uint& reduce_op [[buffer(5)]],
    uint gid [[thread_position_in_grid]])
{
    uint chunk_size = total_size / batch_size;
    if (gid >= chunk_size) return;
    
    ReduceOp op = ReduceOp(reduce_op);
    
    // Calculate offset for this batch's chunk
    uint offset = batch_id * chunk_size + gid;
    
    // Reduce across all batches for this chunk position
    float result = inputs[0 * total_size + offset];
    for (uint b = 1; b < batch_size; ++b) {
        result = apply_reduce_op(result, inputs[b * total_size + offset], op);
    }
    
    output[gid] = result;
}

// ============================================================================
// Broadcast Operations
// ============================================================================

/**
 * @brief Broadcast tensor to all batch elements
 */
kernel void broadcast_batch_f32(
    device const float* input [[buffer(0)]],    // [size]
    device float* outputs [[buffer(1)]],        // [batch_size, size]
    constant uint& batch_size [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    float val = input[gid];
    for (uint b = 0; b < batch_size; ++b) {
        outputs[b * size + gid] = val;
    }
}

// ============================================================================
// Scatter/Gather Operations
// ============================================================================

/**
 * @brief Scatter values from source to destinations
 */
kernel void scatter_f32(
    device const float* source [[buffer(0)]],
    device float* dest [[buffer(1)]],
    device const uint* indices [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    uint dest_idx = indices[gid];
    dest[dest_idx] = source[gid];
}

/**
 * @brief Gather values from source using indices
 */
kernel void gather_f32(
    device const float* source [[buffer(0)]],
    device float* dest [[buffer(1)]],
    device const uint* indices [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    uint source_idx = indices[gid];
    dest[gid] = source[source_idx];
}

// ============================================================================
// Batch Operations for Attention
// ============================================================================

/**
 * @brief Batched matrix transpose
 * 
 * Transposes multiple matrices in parallel.
 */
kernel void batched_transpose_f32(
    device const float* input [[buffer(0)]],    // [batch, M, N]
    device float* output [[buffer(1)]],         // [batch, N, M]
    constant uint& batch_size [[buffer(2)]],
    constant uint& M [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    uint3 gid [[thread_position_in_grid]])
{
    uint batch = gid.z;
    uint row = gid.y;
    uint col = gid.x;
    
    if (batch >= batch_size || row >= M || col >= N) return;
    
    uint in_offset = batch * M * N;
    uint out_offset = batch * N * M;
    
    output[out_offset + col * M + row] = input[in_offset + row * N + col];
}

/**
 * @brief Batched softmax
 * 
 * Computes softmax across the last dimension for batched inputs.
 */
kernel void batched_softmax_f32(
    device const float* input [[buffer(0)]],    // [batch, size]
    device float* output [[buffer(1)]],
    constant uint& batch_size [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint2 gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    uint batch = gid.y;
    if (batch >= batch_size) return;
    
    uint offset = batch * size;
    threadgroup float shared_mem[MAX_THREADS_PER_THREADGROUP];
    
    // Find max for numerical stability
    float local_max = -INFINITY;
    for (uint i = tid; i < size; i += threadgroup_size) {
        local_max = max(local_max, input[offset + i]);
    }
    
    float max_val = threadgroup_reduce(
        local_max, shared_mem, tid, threadgroup_size, ReduceOp::MAX
    );
    
    // Compute exp(x - max) and sum
    float local_sum = 0.0f;
    for (uint i = tid; i < size; i += threadgroup_size) {
        float exp_val = exp(input[offset + i] - max_val);
        output[offset + i] = exp_val;
        local_sum += exp_val;
    }
    
    float sum = threadgroup_reduce(
        local_sum, shared_mem, tid, threadgroup_size, ReduceOp::SUM
    );
    
    // Normalize
    for (uint i = tid; i < size; i += threadgroup_size) {
        output[offset + i] /= sum;
    }
}

/**
 * @brief Batched layer normalization
 */
kernel void batched_layer_norm_f32(
    device const float* input [[buffer(0)]],    // [batch, size]
    device float* output [[buffer(1)]],
    device const float* gamma [[buffer(2)]],    // [size]
    device const float* beta [[buffer(3)]],     // [size]
    constant uint& batch_size [[buffer(4)]],
    constant uint& size [[buffer(5)]],
    constant float& eps [[buffer(6)]],
    uint2 gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    uint batch = gid.y;
    if (batch >= batch_size) return;
    
    uint offset = batch * size;
    threadgroup float shared_mem[MAX_THREADS_PER_THREADGROUP];
    
    // Compute mean
    float local_sum = 0.0f;
    for (uint i = tid; i < size; i += threadgroup_size) {
        local_sum += input[offset + i];
    }
    float mean = threadgroup_reduce(
        local_sum, shared_mem, tid, threadgroup_size, ReduceOp::SUM
    ) / float(size);
    
    // Compute variance
    float local_var = 0.0f;
    for (uint i = tid; i < size; i += threadgroup_size) {
        float diff = input[offset + i] - mean;
        local_var += diff * diff;
    }
    float variance = threadgroup_reduce(
        local_var, shared_mem, tid, threadgroup_size, ReduceOp::SUM
    ) / float(size);
    
    // Normalize and scale
    float inv_std = rsqrt(variance + eps);
    for (uint i = tid; i < size; i += threadgroup_size) {
        float normalized = (input[offset + i] - mean) * inv_std;
        output[offset + i] = normalized * gamma[i] + beta[i];
    }
}

// ============================================================================
// KV-Cache Operations
// ============================================================================

/**
 * @brief Update KV cache with new keys/values
 * 
 * Useful for autoregressive generation where we cache past keys/values.
 */
kernel void update_kv_cache_f32(
    device const float* new_kv [[buffer(0)]],      // [batch, seq_new, hidden]
    device float* kv_cache [[buffer(1)]],          // [batch, seq_total, hidden]
    constant uint& batch_size [[buffer(2)]],
    constant uint& seq_new [[buffer(3)]],
    constant uint& seq_offset [[buffer(4)]],       // Where to insert in cache
    constant uint& hidden_size [[buffer(5)]],
    uint3 gid [[thread_position_in_grid]])
{
    uint batch = gid.z;
    uint seq = gid.y;
    uint hidden = gid.x;
    
    if (batch >= batch_size || seq >= seq_new || hidden >= hidden_size) return;
    
    uint src_idx = (batch * seq_new + seq) * hidden_size + hidden;
    uint dst_idx = (batch * seq_offset + (seq_offset + seq)) * hidden_size + hidden;
    
    kv_cache[dst_idx] = new_kv[src_idx];
}

/**
 * @brief Retrieve from KV cache
 */
kernel void retrieve_from_kv_cache_f32(
    device const float* kv_cache [[buffer(0)]],    // [batch, seq_total, hidden]
    device float* output [[buffer(1)]],             // [batch, seq_len, hidden]
    constant uint& batch_size [[buffer(2)]],
    constant uint& seq_start [[buffer(3)]],
    constant uint& seq_len [[buffer(4)]],
    constant uint& hidden_size [[buffer(5)]],
    uint3 gid [[thread_position_in_grid]])
{
    uint batch = gid.z;
    uint seq = gid.y;
    uint hidden = gid.x;
    
    if (batch >= batch_size || seq >= seq_len || hidden >= hidden_size) return;
    
    uint src_idx = (batch * seq_start + (seq_start + seq)) * hidden_size + hidden;
    uint dst_idx = (batch * seq_len + seq) * hidden_size + hidden;
    
    output[dst_idx] = kv_cache[src_idx];
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * @brief Parallel copy with stride
 */
kernel void strided_copy_f32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& input_stride [[buffer(2)]],
    constant uint& output_stride [[buffer(3)]],
    constant uint& copy_size [[buffer(4)]],
    constant uint& num_copies [[buffer(5)]],
    uint gid [[thread_position_in_grid]])
{
    uint copy_idx = gid / copy_size;
    uint elem_idx = gid % copy_size;
    
    if (copy_idx >= num_copies) return;
    
    output[copy_idx * output_stride + elem_idx] = input[copy_idx * input_stride + elem_idx];
}

/**
 * @brief Batched element-wise operation
 */
kernel void batched_elementwise_add_f32(
    device const float* a [[buffer(0)]],
    device const float* b [[buffer(1)]],
    device float* output [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = a[gid] + b[gid];
}

kernel void batched_elementwise_mul_f32(
    device const float* a [[buffer(0)]],
    device const float* b [[buffer(1)]],
    device float* output [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = a[gid] * b[gid];
}
