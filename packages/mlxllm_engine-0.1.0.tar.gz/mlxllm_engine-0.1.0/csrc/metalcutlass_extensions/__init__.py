"""
MetalCutlass Extensions for MLX-LLM.

This module provides Python bindings to the MetalCutlass library for
high-performance GEMM operations on Apple Silicon.
"""

from .mlxllm_metalcutlass_library_extension import (
    MetalCutlassBackend,
    get_backend,
    is_available,
    gemm,
    batched_gemm,
    conv2d,
    quantize_int8,
    quantize_int4,
)

__all__ = [
    'MetalCutlassBackend',
    'get_backend',
    'is_available',
    'gemm',
    'batched_gemm',
    'conv2d',
    'quantize_int8',
    'quantize_int4',
]
