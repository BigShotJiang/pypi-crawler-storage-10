#include <metal_stdlib>
using namespace metal;

/// Utility kernels for MetalCutlass operations in mlxllm

/// Convert float32 to bfloat16
kernel void convert_f32_to_bf16(
    device const float* input [[buffer(0)]],
    device ushort* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    float val = input[gid];
    uint bits = as_type<uint>(val);
    // BF16 is float32 with lower 16 bits truncated
    output[gid] = (bits >> 16) & 0xFFFF;
}

/// Convert bfloat16 to float32
kernel void convert_bf16_to_f32(
    device const ushort* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    uint bits = (uint(input[gid]) << 16);
    output[gid] = as_type<float>(bits);
}

/// Fused dequantize-GEMM for INT8 weights
/// This is a simplified version - production would use more optimized tiling
kernel void dequant_int8_gemm(
    device const int8_t* A_quant [[buffer(0)]],
    device const int8_t* B_quant [[buffer(1)]],
    device float* C [[buffer(2)]],
    constant float& scale_A [[buffer(3)]],
    constant float& scale_B [[buffer(4)]],
    constant uint& M [[buffer(5)]],
    constant uint& N [[buffer(6)]],
    constant uint& K [[buffer(7)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;
    
    if (row >= M || col >= N) return;
    
    float sum = 0.0f;
    for (uint k = 0; k < K; ++k) {
        float a = float(A_quant[row * K + k]) * scale_A;
        float b = float(B_quant[k * N + col]) * scale_B;
        sum += a * b;
    }
    
    C[row * N + col] = sum;
}

/// Optimized matrix transpose
kernel void matrix_transpose_f32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& rows [[buffer(2)]],
    constant uint& cols [[buffer(3)]],
    uint2 gid [[thread_position_in_grid]])
{
    uint row = gid.y;
    uint col = gid.x;
    
    if (row >= rows || col >= cols) return;
    
    output[col * rows + row] = input[row * cols + col];
}

/// Element-wise activation: ReLU
kernel void relu_f32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = max(0.0f, input[gid]);
}

/// Element-wise activation: GELU (approximation)
kernel void gelu_f32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    
    float x = input[gid];
    // GELU approximation: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
    float x3 = x * x * x;
    float inner = 0.7978845608f * (x + 0.044715f * x3);
    output[gid] = 0.5f * x * (1.0f + tanh(inner));
}

/// Batched matrix copy with stride
kernel void batched_matrix_copy(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& batch_size [[buffer(2)]],
    constant uint& matrix_size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= batch_size * matrix_size) return;
    output[gid] = input[gid];
}
