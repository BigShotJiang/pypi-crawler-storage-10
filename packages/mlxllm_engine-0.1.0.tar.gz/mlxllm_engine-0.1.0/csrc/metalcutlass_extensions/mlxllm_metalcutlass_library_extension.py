"""
MetalCutlass Python bindings for mlxllm.

This module provides Python access to the locally developed MetalCutlass library,
integrating high-performance GEMM operations for Apple Silicon into the mlxllm framework.
"""

import ctypes
import os
import sys
from pathlib import Path
from typing import Optional, Tuple, List
import numpy as np

# Try to import the MetalCutlass C extension
try:
    import metalcutlass
    _METALCUTLASS_AVAILABLE = metalcutlass._has_extension
except ImportError:
    _METALCUTLASS_AVAILABLE = False
    metalcutlass = None


class MetalCutlassBackend:
    """
    MetalCutlass backend for mlxllm operations.
    
    Provides a wrapper around the locally developed MetalCutlass library,
    exposing high-performance matrix operations for Apple Silicon.
    """
    
    def __init__(self):
        if not _METALCUTLASS_AVAILABLE:
            raise RuntimeError(
                "MetalCutlass extension not available. "
                "Please build and install metalcutlass: "
                "cd /Users/ryanoboyle/agent-xsh/metalcutlass && "
                "pip install -e ."
            )
        self._backend = metalcutlass
    
    def gemm(
        self,
        A: np.ndarray,
        B: np.ndarray,
        C: Optional[np.ndarray] = None,
        alpha: float = 1.0,
        beta: float = 0.0,
        transpose_A: bool = False,
        transpose_B: bool = False
    ) -> Tuple[np.ndarray, dict]:
        """
        Perform General Matrix Multiplication (GEMM).
        
        Computes: C = alpha * op(A) * op(B) + beta * C
        
        Args:
            A: Input matrix A, shape (M, K) or (K, M) if transpose_A
            B: Input matrix B, shape (K, N) or (N, K) if transpose_B
            C: Input/output matrix C, shape (M, N). If None, initialized to zeros.
            alpha: Scalar multiplier for A*B
            beta: Scalar multiplier for C
            transpose_A: Whether to transpose A
            transpose_B: Whether to transpose B
        
        Returns:
            Tuple of (result matrix, performance metrics dict)
        """
        # Validate inputs
        if A.dtype != np.float32:
            A = A.astype(np.float32)
        if B.dtype != np.float32:
            B = B.astype(np.float32)
        
        # Determine dimensions
        M = A.shape[1] if transpose_A else A.shape[0]
        K_A = A.shape[0] if transpose_A else A.shape[1]
        K_B = B.shape[1] if transpose_B else B.shape[0]
        N = B.shape[0] if transpose_B else B.shape[1]
        
        if K_A != K_B:
            raise ValueError(f"Inner dimensions must match: {K_A} != {K_B}")
        
        # Initialize C if needed
        if C is None:
            C = np.zeros((M, N), dtype=np.float32)
        elif C.dtype != np.float32:
            C = C.astype(np.float32)
        
        # Call MetalCutlass
        metrics = self._backend.gemm(A, B, C, alpha=alpha, beta=beta)
        
        return C, metrics
    
    def batched_gemm(
        self,
        A_list: List[np.ndarray],
        B_list: List[np.ndarray],
        C_list: Optional[List[np.ndarray]] = None,
        alpha: float = 1.0,
        beta: float = 0.0
    ) -> Tuple[List[np.ndarray], dict]:
        """
        Perform batched GEMM operations.
        
        Args:
            A_list: List of input matrices A
            B_list: List of input matrices B
            C_list: Optional list of input/output matrices C
            alpha: Scalar multiplier
            beta: Scalar multiplier
        
        Returns:
            Tuple of (list of result matrices, performance metrics dict)
        """
        batch_size = len(A_list)
        if len(B_list) != batch_size:
            raise ValueError("A_list and B_list must have the same length")
        
        if C_list is None:
            C_list = [None] * batch_size
        
        # Call MetalCutlass batched operation
        results = []
        total_metrics = None
        
        for A, B, C in zip(A_list, B_list, C_list):
            result, metrics = self.gemm(A, B, C, alpha, beta)
            results.append(result)
            if total_metrics is None:
                total_metrics = metrics
        
        return results, total_metrics
    
    def conv2d(
        self,
        input: np.ndarray,
        weight: np.ndarray,
        stride: Tuple[int, int] = (1, 1),
        padding: Tuple[int, int] = (0, 0)
    ) -> Tuple[np.ndarray, dict]:
        """
        Perform 2D convolution.
        
        Args:
            input: Input tensor, shape (N, C_in, H, W)
            weight: Weight tensor, shape (C_out, C_in, K_h, K_w)
            stride: (stride_h, stride_w)
            padding: (pad_h, pad_w)
        
        Returns:
            Tuple of (output tensor, performance metrics dict)
        """
        if input.dtype != np.float32:
            input = input.astype(np.float32)
        if weight.dtype != np.float32:
            weight = weight.astype(np.float32)
        
        # Call MetalCutlass conv2d
        metrics = self._backend.conv2d(
            input, weight,
            stride=stride,
            padding=padding
        )
        
        # Calculate output shape
        N, C_in, H, W = input.shape
        C_out, _, K_h, K_w = weight.shape
        H_out = (H + 2 * padding[0] - K_h) // stride[0] + 1
        W_out = (W + 2 * padding[1] - K_w) // stride[1] + 1
        
        output = np.zeros((N, C_out, H_out, W_out), dtype=np.float32)
        
        return output, metrics
    
    def quantize_int8(self, x: np.ndarray) -> Tuple[np.ndarray, float]:
        """
        Quantize floating point tensor to INT8.

        Args:
            x: Input tensor (float32)

        Returns:
            Tuple of (quantized tensor, scale factor)
        """
        if x.dtype != np.float32:
            x = x.astype(np.float32)

        # metalcutlass.quantize_int8 returns (quantized, scale, zero_point)
        quantized, scale, zero_point = self._backend.quantize_int8(x)
        return quantized, scale
    
    def quantize_int4(self, x: np.ndarray, group_size: int = 128) -> Tuple[np.ndarray, np.ndarray]:
        """
        Quantize floating point tensor to INT4.

        Args:
            x: Input tensor (float32)
            group_size: Group size for group-wise quantization (default: 128)

        Returns:
            Tuple of (packed quantized tensor, scales array)
        """
        if x.dtype != np.float32:
            x = x.astype(np.float32)

        # metalcutlass.quantize_int4 returns (packed, scales)
        packed, scales = self._backend.quantize_int4(x, group_size=group_size)
        return packed, scales
    
    @property
    def is_available(self) -> bool:
        """Check if MetalCutlass backend is available."""
        return _METALCUTLASS_AVAILABLE


# Global backend instance
_backend: Optional[MetalCutlassBackend] = None


def get_backend() -> MetalCutlassBackend:
    """Get or create the global MetalCutlass backend instance."""
    global _backend
    if _backend is None:
        _backend = MetalCutlassBackend()
    return _backend


def is_available() -> bool:
    """Check if MetalCutlass is available."""
    return _METALCUTLASS_AVAILABLE


# Convenience functions
def gemm(*args, **kwargs):
    """Convenience function for GEMM. See MetalCutlassBackend.gemm for details."""
    return get_backend().gemm(*args, **kwargs)


def batched_gemm(*args, **kwargs):
    """Convenience function for batched GEMM. See MetalCutlassBackend.batched_gemm for details."""
    return get_backend().batched_gemm(*args, **kwargs)


def conv2d(*args, **kwargs):
    """Convenience function for Conv2D. See MetalCutlassBackend.conv2d for details."""
    return get_backend().conv2d(*args, **kwargs)


def quantize_int8(*args, **kwargs):
    """Convenience function for INT8 quantization. See MetalCutlassBackend.quantize_int8 for details."""
    return get_backend().quantize_int8(*args, **kwargs)


def quantize_int4(*args, **kwargs):
    """Convenience function for INT4 quantization. See MetalCutlassBackend.quantize_int4 for details."""
    return get_backend().quantize_int4(*args, **kwargs)


__all__ = [
    'MetalCutlassBackend',
    'get_backend',
    'is_available',
    'gemm',
    'batched_gemm',
    'conv2d',
    'quantize_int8',
    'quantize_int4',
]
