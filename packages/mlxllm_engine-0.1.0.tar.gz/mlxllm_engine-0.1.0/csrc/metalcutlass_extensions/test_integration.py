#!/usr/bin/env python3
"""
Test script for MetalCutlass integration with mlxllm.

This script verifies that the MetalCutlass library is properly integrated
and can be used for basic operations.
"""

import sys
import numpy as np
import pytest


@pytest.fixture(scope="module")
def mc():
    """Fixture to provide MetalCutlass module."""
    try:
        from csrc.metalcutlass_extensions import mlxllm_metalcutlass_library_extension as mc

        if mc.is_available():
            return mc
        else:
            pytest.skip("MetalCutlass C extension not loaded")
    except ImportError as e:
        pytest.skip(f"Failed to import MetalCutlass: {e}")


def test_availability():
    """Test if MetalCutlass is available."""
    print("=" * 70)
    print("Testing MetalCutlass availability")
    print("=" * 70)

    try:
        from csrc.metalcutlass_extensions import mlxllm_metalcutlass_library_extension as mc

        if mc.is_available():
            print("✓ MetalCutlass is available!")
            assert mc.is_available()
        else:
            print("✗ MetalCutlass C extension not loaded")
            pytest.skip("MetalCutlass C extension not loaded")
    except ImportError as e:
        print(f"✗ Failed to import MetalCutlass: {e}")
        pytest.skip(f"Failed to import MetalCutlass: {e}")

def test_gemm(mc):
    """Test basic GEMM operation."""
    print("\n" + "=" * 70)
    print("Testing GEMM operation")
    print("=" * 70)

    # Small matrix for quick testing
    M, N, K = 64, 64, 64
    print(f"Matrix dimensions: M={M}, N={N}, K={K}")

    A = np.random.randn(M, K).astype(np.float32)
    B = np.random.randn(K, N).astype(np.float32)

    print("Executing GEMM...")
    result, metrics = mc.gemm(A, B)

    print(f"✓ GEMM completed successfully")
    print(f"  Result shape: {result.shape}")
    print(f"  Latency: {metrics.get('latency_ms', 'N/A'):.2f} ms")
    print(f"  Performance: {metrics.get('gflops', 'N/A'):.2f} GFLOPS")

    # Verify against NumPy
    expected = A @ B
    max_error = np.abs(result - expected).max()
    mean_error = np.abs(result - expected).mean()

    print(f"  Max error vs NumPy: {max_error:.6f}")
    print(f"  Mean error vs NumPy: {mean_error:.6f}")

    # Assert the result shape is correct
    assert result.shape == (M, N), f"Expected shape ({M}, {N}), got {result.shape}"

    if max_error < 1e-3:
        print("✓ Numerical accuracy is good")
    else:
        print("⚠ Large numerical error detected (known issue)")

def test_batched_gemm(mc):
    """Test batched GEMM operation."""
    print("\n" + "=" * 70)
    print("Testing batched GEMM operation")
    print("=" * 70)

    batch_size = 4
    M, N, K = 32, 32, 32
    print(f"Batch size: {batch_size}, Matrix dimensions: M={M}, N={N}, K={K}")

    A_batch = [np.random.randn(M, K).astype(np.float32) for _ in range(batch_size)]
    B_batch = [np.random.randn(K, N).astype(np.float32) for _ in range(batch_size)]

    print("Executing batched GEMM...")
    results, metrics = mc.batched_gemm(A_batch, B_batch)

    print(f"✓ Batched GEMM completed successfully")
    print(f"  Number of results: {len(results)}")
    print(f"  Latency: {metrics.get('latency_ms', 'N/A'):.2f} ms")

    # Assert we got the correct number of results
    assert len(results) == batch_size, f"Expected {batch_size} results, got {len(results)}"

def test_quantization(mc):
    """Test quantization operations."""
    print("\n" + "=" * 70)
    print("Testing quantization operations")
    print("=" * 70)

    # INT8 test with 1D array
    size = 1024
    x = np.random.randn(size).astype(np.float32)

    print("Testing INT8 quantization...")
    x_int8, scale_int8 = mc.quantize_int8(x)
    print(f"✓ INT8 quantization completed")
    print(f"  Scale: {scale_int8:.6f}")
    print(f"  Quantized dtype: {x_int8.dtype}")

    # Assert INT8 quantization produced results
    assert x_int8 is not None, "INT8 quantization failed"
    assert scale_int8 > 0, "INT8 scale should be positive"

    # INT4 test with 2D array (required by metalcutlass)
    print("\nTesting INT4 quantization...")
    x_2d = np.random.randn(128, 256).astype(np.float32)
    x_int4, scales_int4 = mc.quantize_int4(x_2d)
    print(f"✓ INT4 quantization completed")
    print(f"  Packed shape: {x_int4.shape}")
    print(f"  Scales shape: {scales_int4.shape}")
    print(f"  Compression: {x_2d.nbytes / x_int4.nbytes:.1f}x")

    # Assert INT4 quantization produced results
    assert x_int4 is not None, "INT4 quantization failed"
    assert scales_int4 is not None, "INT4 scales should not be None"
    assert x_int4.shape[0] == x_2d.shape[0], "Packed array should have same number of rows"

def main():
    """Run all tests."""
    print("\nMetalCutlass Integration Test Suite")
    print("=" * 70)
    
    # Test availability
    mc = test_availability()
    if mc is None:
        print("\n✗ MetalCutlass not available. Cannot run tests.")
        print("\nTo install MetalCutlass:")
        print("  cd /Users/ryanoboyle/agent-xsh/metalcutlass")
        print("  pip install -e .")
        return 1
    
    # Run tests
    results = []
    results.append(("GEMM", test_gemm(mc)))
    results.append(("Batched GEMM", test_batched_gemm(mc)))
    results.append(("Quantization", test_quantization(mc)))
    
    # Summary
    print("\n" + "=" * 70)
    print("Test Summary")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✓ PASSED" if result else "✗ FAILED"
        print(f"{name:20s} {status}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    return 0 if passed == total else 1

if __name__ == "__main__":
    sys.exit(main())
