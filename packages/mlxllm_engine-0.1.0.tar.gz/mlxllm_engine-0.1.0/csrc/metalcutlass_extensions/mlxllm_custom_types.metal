/**
 * @file mlxllm_custom_types.metal
 * @brief Custom type definitions and utilities for mlxllm Metal kernels
 * 
 * Provides type definitions, conversion utilities, and helper functions
 * for working with different precision types in Metal kernels.
 */

#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Type Aliases and Constants
// ============================================================================

typedef half float16_t;
typedef float float32_t;

/// BFloat16 represented as uint16_t (no native bfloat16 in Metal)
typedef ushort bfloat16_t;

/// INT4 packed into uint8_t (2 values per byte)
typedef uchar int4x2_t;

// ============================================================================
// BFloat16 Utilities
// ============================================================================

/**
 * @brief Convert float32 to bfloat16
 * BFloat16 format: 1 sign bit, 8 exponent bits, 7 mantissa bits
 */
inline bfloat16_t float_to_bfloat16(float val) {
    uint bits = as_type<uint>(val);
    // Round to nearest even
    uint rounding = 0x7FFF + ((bits >> 16) & 1);
    return as_type<ushort>((bits + rounding) >> 16);
}

/**
 * @brief Convert bfloat16 to float32
 */
inline float bfloat16_to_float(bfloat16_t val) {
    uint bits = uint(val) << 16;
    return as_type<float>(bits);
}

/**
 * @brief BFloat16 vector conversion
 */
inline float4 bfloat16x4_to_float4(ushort4 bf16_vec) {
    return float4(
        bfloat16_to_float(bf16_vec.x),
        bfloat16_to_float(bf16_vec.y),
        bfloat16_to_float(bf16_vec.z),
        bfloat16_to_float(bf16_vec.w)
    );
}

inline ushort4 float4_to_bfloat16x4(float4 f32_vec) {
    return ushort4(
        float_to_bfloat16(f32_vec.x),
        float_to_bfloat16(f32_vec.y),
        float_to_bfloat16(f32_vec.z),
        float_to_bfloat16(f32_vec.w)
    );
}

// ============================================================================
// INT4 Quantization Utilities
// ============================================================================

/**
 * @brief Pack two INT4 values into one byte
 * @param low Lower 4 bits
 * @param high Upper 4 bits
 */
inline uchar pack_int4(char low, char high) {
    return ((uchar(high) & 0x0F) << 4) | (uchar(low) & 0x0F);
}

/**
 * @brief Unpack INT4 values from byte
 * @param packed Packed byte
 * @param idx Index (0 = lower 4 bits, 1 = upper 4 bits)
 */
inline char unpack_int4(uchar packed, uint idx) {
    if (idx == 0) {
        // Lower 4 bits, sign-extend
        char val = char(packed & 0x0F);
        return (val & 0x08) ? (val | char(0xF0)) : val;
    } else {
        // Upper 4 bits, sign-extend
        char val = char((packed >> 4) & 0x0F);
        return (val & 0x08) ? (val | char(0xF0)) : val;
    }
}

/**
 * @brief Quantize float to INT4 with scale
 */
inline char quantize_float_to_int4(float val, float scale) {
    float scaled = val / scale;
    int quant = int(round(clamp(scaled, -8.0f, 7.0f)));
    return char(quant);
}

/**
 * @brief Dequantize INT4 to float with scale
 */
inline float dequantize_int4_to_float(char quant, float scale) {
    return float(quant) * scale;
}

// ============================================================================
// INT8 Quantization Utilities
// ============================================================================

/**
 * @brief Quantize float to INT8 with scale
 */
inline char quantize_float_to_int8(float val, float scale) {
    float scaled = val / scale;
    int quant = int(round(clamp(scaled, -128.0f, 127.0f)));
    return char(quant);
}

/**
 * @brief Dequantize INT8 to float with scale
 */
inline float dequantize_int8_to_float(char quant, float scale) {
    return float(quant) * scale;
}

/**
 * @brief Vectorized INT8 dequantization
 */
inline float4 dequantize_int8x4_to_float4(char4 quant, float scale) {
    return float4(
        float(quant.x) * scale,
        float(quant.y) * scale,
        float(quant.z) * scale,
        float(quant.w) * scale
    );
}

// ============================================================================
// Type Conversion Kernels
// ============================================================================

/**
 * @brief Convert float32 array to bfloat16
 */
kernel void convert_f32_to_bf16_kernel(
    device const float* input [[buffer(0)]],
    device bfloat16_t* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = float_to_bfloat16(input[gid]);
}

/**
 * @brief Convert bfloat16 array to float32
 */
kernel void convert_bf16_to_f32_kernel(
    device const bfloat16_t* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = bfloat16_to_float(input[gid]);
}

/**
 * @brief Convert float16 to float32
 */
kernel void convert_f16_to_f32_kernel(
    device const half* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = float(input[gid]);
}

/**
 * @brief Convert float32 to float16
 */
kernel void convert_f32_to_f16_kernel(
    device const float* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant uint& size [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = half(input[gid]);
}

// ============================================================================
// Quantization Kernels
// ============================================================================

/**
 * @brief Quantize float32 array to INT8
 * Computes scale as max(abs(input)) / 127
 */
kernel void quantize_f32_to_int8_kernel(
    device const float* input [[buffer(0)]],
    device char* output [[buffer(1)]],
    device float* scale [[buffer(2)]],  // Output: computed scale
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    // Note: This is a simplified version
    // Production code should use atomic max to compute scale first
    if (gid >= size) return;
    
    // Use pre-computed scale
    float s = scale[0];
    output[gid] = quantize_float_to_int8(input[gid], s);
}

/**
 * @brief Dequantize INT8 array to float32
 */
kernel void dequantize_int8_to_f32_kernel(
    device const char* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant float& scale [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= size) return;
    output[gid] = dequantize_int8_to_float(input[gid], scale);
}

/**
 * @brief Quantize float32 array to INT4 (packed)
 */
kernel void quantize_f32_to_int4_kernel(
    device const float* input [[buffer(0)]],
    device uchar* output [[buffer(1)]],  // Packed INT4 values
    device float* scale [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    uint idx = gid * 2;  // Each thread processes 2 values
    if (idx >= size) return;
    
    float s = scale[0];
    
    char low = quantize_float_to_int4(input[idx], s);
    char high = (idx + 1 < size) ? quantize_float_to_int4(input[idx + 1], s) : 0;
    
    output[gid] = pack_int4(low, high);
}

/**
 * @brief Dequantize INT4 (packed) to float32
 */
kernel void dequantize_int4_to_f32_kernel(
    device const uchar* input [[buffer(0)]],  // Packed INT4 values
    device float* output [[buffer(1)]],
    constant float& scale [[buffer(2)]],
    constant uint& size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    uint out_idx = gid * 2;
    if (out_idx >= size) return;
    
    uchar packed = input[gid];
    
    output[out_idx] = dequantize_int4_to_float(unpack_int4(packed, 0), scale);
    if (out_idx + 1 < size) {
        output[out_idx + 1] = dequantize_int4_to_float(unpack_int4(packed, 1), scale);
    }
}

// ============================================================================
// Mixed Precision Utilities
// ============================================================================

/**
 * @brief Mixed precision accumulation (FP16 -> FP32)
 */
struct MixedPrecisionAccumulator {
    float4 acc;
    
    MixedPrecisionAccumulator() : acc(0.0f) {}
    
    void accumulate_fp16(half4 val) {
        acc += float4(val);
    }
    
    void accumulate_bf16(ushort4 val) {
        acc += bfloat16x4_to_float4(val);
    }
    
    void accumulate_fp32(float4 val) {
        acc += val;
    }
    
    float4 get() const {
        return acc;
    }
};

/**
 * @brief Dot product with mixed precision
 */
inline float dot_mixed_precision_fp16(half4 a, half4 b) {
    float4 a_fp32 = float4(a);
    float4 b_fp32 = float4(b);
    return dot(a_fp32, b_fp32);
}

inline float dot_mixed_precision_bf16(ushort4 a, ushort4 b) {
    float4 a_fp32 = bfloat16x4_to_float4(a);
    float4 b_fp32 = bfloat16x4_to_float4(b);
    return dot(a_fp32, b_fp32);
}

// ============================================================================
// Helper Functions for Attention
// ============================================================================

/**
 * @brief Fast reciprocal square root for normalization
 */
inline float fast_rsqrt(float x) {
    return rsqrt(x);
}

/**
 * @brief Safe softmax computation (numerically stable)
 */
inline float safe_exp(float x, float max_val) {
    return exp(x - max_val);
}

/**
 * @brief Warp-level reduction (threadgroup)
 */
template<typename T>
inline T threadgroup_reduce_sum(T val, threadgroup T* shared_mem, uint tid, uint size) {
    shared_mem[tid] = val;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    
    // Tree reduction
    for (uint s = size / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared_mem[tid] += shared_mem[tid + s];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    
    return shared_mem[0];
}

/**
 * @brief Warp-level max reduction
 */
template<typename T>
inline T threadgroup_reduce_max(T val, threadgroup T* shared_mem, uint tid, uint size) {
    shared_mem[tid] = val;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    
    for (uint s = size / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared_mem[tid] = max(shared_mem[tid], shared_mem[tid + s]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    
    return shared_mem[0];
}
