"""Core Utilities Module for MLX-LLM.

Provides core utilities including type conversions, tensor validation,
device management, batch processing helpers, and math utilities.
"""

from typing import Dict, Optional, List
import torch

try:
    from . import _core_ops  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

if _EXTENSION_AVAILABLE:
    from ._core_ops import (
        # Type utilities
        scalar_type_to_string,
        scalar_type_size,
        # Tensor validation
        check_tensor_valid,
        get_tensor_stats,
        print_tensor_stats,
        # Device utilities
        get_metal_device_info,
        is_metal_available,
        get_available_memory,
        # Batch utilities
        check_batch_size,
        validate_batch_consistency,
        # Math utilities
        next_power_of_2,
        is_power_of_2,
        ceil_div,
        align_to,
        # Error handling
        throw_error,
        check_condition,
        # Constants
        BLOCK_SIZE_16,
        BLOCK_SIZE_32,
        BLOCK_SIZE_64,
        BLOCK_SIZE_128,
        BLOCK_SIZE_256,
        CACHE_LINE_SIZE,
        PAGE_SIZE,
    )
    __all__ = [
        'scalar_type_to_string', 'scalar_type_size',
        'check_tensor_valid', 'get_tensor_stats', 'print_tensor_stats',
        'get_metal_device_info', 'is_metal_available', 'get_available_memory',
        'check_batch_size', 'validate_batch_consistency',
        'next_power_of_2', 'is_power_of_2', 'ceil_div', 'align_to',
        'throw_error', 'check_condition',
        'BLOCK_SIZE_16', 'BLOCK_SIZE_32', 'BLOCK_SIZE_64', 'BLOCK_SIZE_128', 'BLOCK_SIZE_256',
        'CACHE_LINE_SIZE', 'PAGE_SIZE',
        'is_available',
    ]
else:
    def _unavailable(*args, **kwargs):
        raise RuntimeError(f"Core extension not available: {_IMPORT_ERROR}")

    scalar_type_to_string = scalar_type_size = _unavailable
    check_tensor_valid = get_tensor_stats = print_tensor_stats = _unavailable
    get_metal_device_info = is_metal_available = get_available_memory = _unavailable
    check_batch_size = validate_batch_consistency = _unavailable
    next_power_of_2 = is_power_of_2 = ceil_div = align_to = _unavailable
    throw_error = check_condition = _unavailable
    BLOCK_SIZE_16 = BLOCK_SIZE_32 = BLOCK_SIZE_64 = BLOCK_SIZE_128 = BLOCK_SIZE_256 = 0
    CACHE_LINE_SIZE = PAGE_SIZE = 0
    __all__ = ['is_available']

def is_available() -> bool:
    return _EXTENSION_AVAILABLE

__version__ = "0.1.0"
__backend__ = "Metal" if _EXTENSION_AVAILABLE else "None"
