#include <metal_stdlib>
using namespace metal;

// Internode dispatch kernels - prepare data for network transfer
// These kernels pack data efficiently for network transmission

struct InternodeDispatchParams {
    uint world_size;
    uint rank;
    uint chunk_size;
    uint total_elements;
    uint pack_alignment;  // Alignment for network buffers (e.g., 64 bytes)
};

// Float32 internode dispatch with packing
kernel void internode_dispatch_float32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeDispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    // Pack data for each peer rank
    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Align chunks to cache lines for better network performance
    uint aligned_chunk_size = ((params.chunk_size * sizeof(float) + params.pack_alignment - 1) /
                               params.pack_alignment) * params.pack_alignment / sizeof(float);

    uint output_idx = target_rank * aligned_chunk_size + offset_in_chunk;
    output[output_idx] = input[gid];
}

// Float16 internode dispatch
kernel void internode_dispatch_float16(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant InternodeDispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    uint aligned_chunk_size = ((params.chunk_size * sizeof(half) + params.pack_alignment - 1) /
                               params.pack_alignment) * params.pack_alignment / sizeof(half);

    uint output_idx = target_rank * aligned_chunk_size + offset_in_chunk;
    output[output_idx] = input[gid];
}

// Batched dispatch - prepare multiple chunks for pipelined transfer
kernel void internode_dispatch_float32_batched(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeDispatchParams& params [[buffer(2)]],
    constant uint& batch_size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    uint elements_per_batch = params.total_elements / batch_size;
    if (gid >= elements_per_batch) return;

    for (uint batch = 0; batch < batch_size; ++batch) {
        uint input_idx = batch * elements_per_batch + gid;
        uint target_rank = input_idx / params.chunk_size;
        uint offset_in_chunk = input_idx % params.chunk_size;

        uint output_base = batch * params.world_size * params.chunk_size;
        uint output_idx = output_base + target_rank * params.chunk_size + offset_in_chunk;

        if (input_idx < params.total_elements) {
            output[output_idx] = input[input_idx];
        }
    }
}

// Dispatch with compression/quantization for network bandwidth reduction
kernel void internode_dispatch_float32_to_int8(
    device const float* input [[buffer(0)]],
    device char* output [[buffer(1)]],
    device float* scale_factors [[buffer(2)]],
    constant InternodeDispatchParams& params [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    float value = input[gid];

    // Simple quantization: scale to [-127, 127]
    float abs_max = 0.0f;
    if (offset_in_chunk == 0) {
        // First thread in chunk computes scale
        for (uint i = 0; i < params.chunk_size; ++i) {
            uint idx = target_rank * params.chunk_size + i;
            if (idx < params.total_elements) {
                abs_max = max(abs_max, abs(input[idx]));
            }
        }
        scale_factors[target_rank] = abs_max / 127.0f;
    }

    threadgroup_barrier(mem_flags::mem_device);

    float scale = scale_factors[target_rank];
    char quantized = (scale > 0.0f) ? char(value / scale) : char(0);

    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;
    output[output_idx] = quantized;
}

// Copy to staging buffers with cache-line optimization
kernel void internode_dispatch_float32_staged(
    device const float* input [[buffer(0)]],
    device float* staging_buffers [[buffer(1)]],
    constant InternodeDispatchParams& params [[buffer(2)]],
    constant uint* buffer_offsets [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Use staging buffer offset for this rank
    uint staging_offset = buffer_offsets[target_rank];
    uint output_idx = staging_offset + offset_in_chunk;

    staging_buffers[output_idx] = input[gid];
}
