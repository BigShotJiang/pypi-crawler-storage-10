#include <metal_stdlib>
using namespace metal;

// Combined intranode all2all Metal kernels
// This file includes both dispatch and combine operations

#include "intranode_dispatch.metal"
#include "intranode_combine.metal"

// Fused all2all kernel for small transfers
// Combines dispatch and combine in single kernel pass for efficiency
kernel void intranode_all2all_fused_float32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    device float* staging [[buffer(2)]],
    constant uint& world_size [[buffer(3)]],
    constant uint& chunk_size [[buffer(4)]],
    uint gid [[thread_position_in_grid]],
    uint tid_in_group [[thread_index_in_threadgroup]],
    threadgroup float* shared_mem [[threadgroup(0)]])
{
    uint total_elements = world_size * chunk_size;

    // Stage 1: Dispatch to shared memory
    if (gid < total_elements) {
        uint target_rank = gid / chunk_size;
        uint offset_in_chunk = gid % chunk_size;
        uint shared_idx = target_rank * chunk_size + offset_in_chunk;
        shared_mem[shared_idx] = input[gid];
    }

    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Stage 2: Combine from shared memory
    if (gid < total_elements) {
        uint source_rank = gid / chunk_size;
        uint offset_in_chunk = gid % chunk_size;
        uint shared_idx = source_rank * chunk_size + offset_in_chunk;
        output[gid] = shared_mem[shared_idx];
    }
}
