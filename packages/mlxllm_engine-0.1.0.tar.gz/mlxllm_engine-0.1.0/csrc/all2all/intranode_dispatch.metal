#include <metal_stdlib>
using namespace metal;

// Dispatch kernel - splits input data into per-rank chunks
// Input: [world_size * chunk_size] data from current rank
// Output: [world_size][chunk_size] chunks to be distributed

struct DispatchParams {
    uint world_size;
    uint rank;
    uint chunk_size;      // Size per chunk in elements
    uint total_elements;  // Total elements in input
};

// Float32 dispatch kernel
kernel void intranode_dispatch_float32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    // Determine which rank this element goes to
    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Output layout: [rank0_chunk, rank1_chunk, ..., rankN_chunk]
    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;

    output[output_idx] = input[gid];
}

// Float16 dispatch kernel
kernel void intranode_dispatch_float16(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;
    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;

    output[output_idx] = input[gid];
}

// BFloat16 dispatch kernel
kernel void intranode_dispatch_bfloat16(
    device const bfloat* input [[buffer(0)]],
    device bfloat* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;
    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;

    output[output_idx] = input[gid];
}

// Optimized vectorized float32 dispatch (processes 4 elements at a time)
kernel void intranode_dispatch_float32_vec4(
    device const float4* input [[buffer(0)]],
    device float4* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    uint vec4_elements = params.total_elements / 4;
    if (gid >= vec4_elements) return;

    uint elem_base = gid * 4;
    uint target_rank = elem_base / params.chunk_size;
    uint offset_in_chunk = elem_base % params.chunk_size;
    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;

    output[output_idx / 4] = input[gid];
}

// Strided dispatch for handling non-contiguous layouts
kernel void intranode_dispatch_float32_strided(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    constant uint& input_stride [[buffer(3)]],
    constant uint& output_stride [[buffer(4)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    uint input_idx = gid * input_stride;
    uint output_idx = (target_rank * params.chunk_size + offset_in_chunk) * output_stride;

    output[output_idx] = input[input_idx];
}

// Dispatch with scaling/transformation
kernel void intranode_dispatch_float32_scaled(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant DispatchParams& params [[buffer(2)]],
    constant float& scale [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint target_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;
    uint output_idx = target_rank * params.chunk_size + offset_in_chunk;

    output[output_idx] = input[gid] * scale;
}
