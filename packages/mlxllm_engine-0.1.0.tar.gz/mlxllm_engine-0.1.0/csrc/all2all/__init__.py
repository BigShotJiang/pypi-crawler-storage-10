"""
All2All Communication Module for MLX-LLM.

This module provides Metal-optimized distributed communication patterns for
multi-GPU inference on Apple Silicon.

The module exposes:
- All2AllCoordinator: High-level coordinator for all2all operations
- IntranodeAll2All: Single-node multi-GPU communication
- InternodeAll2All: Multi-node networked communication
- Utility functions for data type and backend management

Example:
    >>> from csrc.all2all import All2AllCoordinator, DataType, CommBackend
    >>>
    >>> # Create coordinator
    >>> coordinator = All2AllCoordinator(
    ...     world_size=4,
    ...     rank=0,
    ...     buffer_size=1024*1024,
    ...     dtype="float16",
    ...     backend="intranode"
    ... )
    >>>
    >>> # Initialize Metal resources
    >>> coordinator.initialize()
    >>>
    >>> # Execute all2all operation
    >>> import torch
    >>> input_tensor = torch.randn(4, 1024, device='mps')
    >>> output_tensor = torch.empty_like(input_tensor)
    >>> coordinator.execute(input_tensor, output_tensor)
    >>>
    >>> # Get performance stats
    >>> stats = coordinator.get_stats()
    >>> print(f"Bandwidth: {stats['bandwidth_gbps']:.2f} GB/s")
"""

import sys
from typing import Dict, Optional, Any

# Check if the compiled extension is available
try:
    from . import _all2all  # type: ignore
    _EXTENSION_AVAILABLE = True
except ImportError as e:
    _EXTENSION_AVAILABLE = False
    _IMPORT_ERROR = str(e)

# Re-export everything from the compiled extension
if _EXTENSION_AVAILABLE:
    # Enums
    from ._all2all import DataType, CommBackend

    # Classes
    from ._all2all import All2AllCoordinator, IntranodeAll2All

    # Utility functions
    from ._all2all import (
        get_dtype_size,
        get_dtype_name,
        get_backend_name,
    )

    __all__ = [
        # Enums
        'DataType',
        'CommBackend',
        # Classes
        'All2AllCoordinator',
        'IntranodeAll2All',
        # Functions
        'get_dtype_size',
        'get_dtype_name',
        'get_backend_name',
        # Status
        'is_available',
    ]
else:
    # Provide stub implementations for when extension is not available
    class DataType:
        """Data type enumeration (stub)."""
        FLOAT32 = "float32"
        FLOAT16 = "float16"
        BFLOAT16 = "bfloat16"
        INT32 = "int32"
        INT8 = "int8"

    class CommBackend:
        """Communication backend enumeration (stub)."""
        INTRANODE = "intranode"
        INTERNODE = "internode"
        HYBRID = "hybrid"

    class All2AllCoordinator:
        """All2All coordinator (stub)."""
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                f"All2All extension not available. "
                f"Please build the extension first. Import error: {_IMPORT_ERROR}"
            )

    class IntranodeAll2All:
        """Intranode All2All (stub)."""
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                f"All2All extension not available. "
                f"Please build the extension first. Import error: {_IMPORT_ERROR}"
            )

    def get_dtype_size(*args, **kwargs):
        """Get dtype size (stub)."""
        raise RuntimeError(f"All2All extension not available: {_IMPORT_ERROR}")

    def get_dtype_name(*args, **kwargs):
        """Get dtype name (stub)."""
        raise RuntimeError(f"All2All extension not available: {_IMPORT_ERROR}")

    def get_backend_name(*args, **kwargs):
        """Get backend name (stub)."""
        raise RuntimeError(f"All2All extension not available: {_IMPORT_ERROR}")

    __all__ = [
        'DataType',
        'CommBackend',
        'All2AllCoordinator',
        'IntranodeAll2All',
        'get_dtype_size',
        'get_dtype_name',
        'get_backend_name',
        'is_available',
    ]


def is_available() -> bool:
    """
    Check if the All2All extension is available.

    Returns:
        True if extension is compiled and loaded, False otherwise
    """
    return _EXTENSION_AVAILABLE


def get_import_error() -> Optional[str]:
    """
    Get the import error message if extension failed to load.

    Returns:
        Error message string if extension unavailable, None if available
    """
    if _EXTENSION_AVAILABLE:
        return None
    return _IMPORT_ERROR


# Module metadata
__version__ = "0.1.0"
__backend__ = "Metal" if _EXTENSION_AVAILABLE else "None"
