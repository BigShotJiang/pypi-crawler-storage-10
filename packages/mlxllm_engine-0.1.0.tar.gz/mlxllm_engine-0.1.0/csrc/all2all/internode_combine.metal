#include <metal_stdlib>
using namespace metal;

// Internode combine kernels - unpack data received from network
// These kernels efficiently combine data from network buffers

struct InternodeCombineParams {
    uint world_size;
    uint rank;
    uint chunk_size;
    uint total_elements;
    uint pack_alignment;
};

// Float32 internode combine with unpacking
kernel void internode_combine_float32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    // Unpack data from each peer rank
    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Handle aligned chunks from network
    uint aligned_chunk_size = ((params.chunk_size * sizeof(float) + params.pack_alignment - 1) /
                               params.pack_alignment) * params.pack_alignment / sizeof(float);

    uint input_idx = source_rank * aligned_chunk_size + offset_in_chunk;
    output[gid] = input[input_idx];
}

// Float16 internode combine
kernel void internode_combine_float16(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    uint aligned_chunk_size = ((params.chunk_size * sizeof(half) + params.pack_alignment - 1) /
                               params.pack_alignment) * params.pack_alignment / sizeof(half);

    uint input_idx = source_rank * aligned_chunk_size + offset_in_chunk;
    output[gid] = input[input_idx];
}

// Batched combine - process multiple received batches
kernel void internode_combine_float32_batched(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    constant uint& batch_size [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    uint elements_per_batch = params.total_elements / batch_size;
    if (gid >= elements_per_batch) return;

    for (uint batch = 0; batch < batch_size; ++batch) {
        uint output_idx = batch * elements_per_batch + gid;
        uint source_rank = output_idx / params.chunk_size;
        uint offset_in_chunk = output_idx % params.chunk_size;

        uint input_base = batch * params.world_size * params.chunk_size;
        uint input_idx = input_base + source_rank * params.chunk_size + offset_in_chunk;

        if (output_idx < params.total_elements) {
            output[output_idx] = input[input_idx];
        }
    }
}

// Combine with decompression/dequantization
kernel void internode_combine_int8_to_float32(
    device const char* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    device const float* scale_factors [[buffer(2)]],
    constant InternodeCombineParams& params [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    uint input_idx = source_rank * params.chunk_size + offset_in_chunk;
    char quantized = input[input_idx];

    float scale = scale_factors[source_rank];
    output[gid] = float(quantized) * scale;
}

// Combine from staging buffers with async copy
kernel void internode_combine_float32_staged(
    device const float* staging_buffers [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    constant uint* buffer_offsets [[buffer(3)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Use staging buffer offset for this rank
    uint staging_offset = buffer_offsets[source_rank];
    uint input_idx = staging_offset + offset_in_chunk;

    output[gid] = staging_buffers[input_idx];
}

// Combine with reduction (sum across ranks) - useful for all-reduce
kernel void internode_combine_float32_sum(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    float sum = 0.0f;
    for (uint rank = 0; rank < params.world_size; ++rank) {
        uint aligned_chunk_size = ((params.chunk_size * sizeof(float) + params.pack_alignment - 1) /
                                   params.pack_alignment) * params.pack_alignment / sizeof(float);
        uint input_idx = rank * aligned_chunk_size + gid;
        sum += input[input_idx];
    }

    output[gid] = sum;
}

// Pipelined combine - processes data as it arrives from network
kernel void internode_combine_float32_pipelined(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant InternodeCombineParams& params [[buffer(2)]],
    constant uint& completed_ranks [[buffer(3)]],  // Bit mask of completed receives
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    // Only process ranks that have completed receiving
    for (uint rank = 0; rank < params.world_size; ++rank) {
        if (completed_ranks & (1u << rank)) {
            uint input_idx = rank * params.chunk_size + gid;
            uint output_idx = rank * params.chunk_size + gid;
            output[output_idx] = input[input_idx];
        }
    }
}
