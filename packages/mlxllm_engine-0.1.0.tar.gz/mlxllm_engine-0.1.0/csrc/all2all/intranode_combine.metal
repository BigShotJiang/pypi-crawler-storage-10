#include <metal_stdlib>
using namespace metal;

// Combine kernel - gathers chunks from all ranks into output
// Input: [world_size][chunk_size] chunks from all ranks
// Output: [world_size * chunk_size] combined data

struct CombineParams {
    uint world_size;
    uint rank;
    uint chunk_size;      // Size per chunk in elements
    uint total_elements;  // Total elements in output
};

// Float32 combine kernel
kernel void intranode_combine_float32(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    // Determine which rank this element comes from
    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    // Input layout: [rank0_chunk, rank1_chunk, ..., rankN_chunk]
    uint input_idx = source_rank * params.chunk_size + offset_in_chunk;

    output[gid] = input[input_idx];
}

// Float16 combine kernel
kernel void intranode_combine_float16(
    device const half* input [[buffer(0)]],
    device half* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;
    uint input_idx = source_rank * params.chunk_size + offset_in_chunk;

    output[gid] = input[input_idx];
}

// BFloat16 combine kernel
kernel void intranode_combine_bfloat16(
    device const bfloat* input [[buffer(0)]],
    device bfloat* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;
    uint input_idx = source_rank * params.chunk_size + offset_in_chunk;

    output[gid] = input[input_idx];
}

// Optimized vectorized float32 combine (processes 4 elements at a time)
kernel void intranode_combine_float32_vec4(
    device const float4* input [[buffer(0)]],
    device float4* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    uint vec4_elements = params.total_elements / 4;
    if (gid >= vec4_elements) return;

    uint elem_base = gid * 4;
    uint source_rank = elem_base / params.chunk_size;
    uint offset_in_chunk = elem_base % params.chunk_size;
    uint input_idx = source_rank * params.chunk_size + offset_in_chunk;

    output[gid] = input[input_idx / 4];
}

// Strided combine for handling non-contiguous layouts
kernel void intranode_combine_float32_strided(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    constant uint& input_stride [[buffer(3)]],
    constant uint& output_stride [[buffer(4)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.total_elements) return;

    uint source_rank = gid / params.chunk_size;
    uint offset_in_chunk = gid % params.chunk_size;

    uint input_idx = (source_rank * params.chunk_size + offset_in_chunk) * input_stride;
    uint output_idx = gid * output_stride;

    output[output_idx] = input[input_idx];
}

// Combine with accumulation (sum reduction)
kernel void intranode_combine_float32_sum(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    float sum = 0.0f;
    for (uint rank = 0; rank < params.world_size; ++rank) {
        uint input_idx = rank * params.chunk_size + gid;
        sum += input[input_idx];
    }

    output[gid] = sum;
}

// Combine with averaging
kernel void intranode_combine_float32_avg(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    float sum = 0.0f;
    for (uint rank = 0; rank < params.world_size; ++rank) {
        uint input_idx = rank * params.chunk_size + gid;
        sum += input[input_idx];
    }

    output[gid] = sum / float(params.world_size);
}

// Combine with max reduction
kernel void intranode_combine_float32_max(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    float max_val = -INFINITY;
    for (uint rank = 0; rank < params.world_size; ++rank) {
        uint input_idx = rank * params.chunk_size + gid;
        max_val = max(max_val, input[input_idx]);
    }

    output[gid] = max_val;
}

// Combine with min reduction
kernel void intranode_combine_float32_min(
    device const float* input [[buffer(0)]],
    device float* output [[buffer(1)]],
    constant CombineParams& params [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid >= params.chunk_size) return;

    float min_val = INFINITY;
    for (uint rank = 0; rank < params.world_size; ++rank) {
        uint input_idx = rank * params.chunk_size + gid;
        min_val = min(min_val, input[input_idx]);
    }

    output[gid] = min_val;
}
