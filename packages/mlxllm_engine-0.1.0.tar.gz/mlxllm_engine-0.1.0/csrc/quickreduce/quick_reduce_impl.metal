#include <metal_stdlib>
#include <metal_atomic>
using namespace metal;

// ============================================================================
// QuickReduce Implementation Kernels for Metal Backend
// High-performance reduction operations optimized for Apple Silicon
// ============================================================================

// ============================================================================
// Constants
// ============================================================================

constant uint TILE_SIZE = 1024 * 1024;
constant uint MAX_THREADGROUP_SIZE = 1024;
constant uint SIMD_WIDTH = 32;
constant uint TWO_SHOT_THREADGROUP_SIZE = 256;

// ============================================================================
// Quantization Codecs
// ============================================================================

/**
 * @brief FP16 codec (no quantization)
 */
template<typename T, int WorldSize>
struct CodecFP {
    static constant int world_size = WorldSize;
    using quant_type = T;

    inline static T quantize(T value, thread float& /*scale*/) {
        return value;
    }

    inline static T dequantize(T quant_val, float /*scale*/) {
        return quant_val;
    }

    inline static float compute_scale(thread const T* data, uint size) {
        return 1.0f;
    }
};

/**
 * @brief INT8 quantization codec
 */
template<typename T, int WorldSize>
struct CodecQ8 {
    static constant int world_size = WorldSize;
    using quant_type = char;

    inline static char quantize(T value, thread float& scale) {
        float val_f32 = float(value);
        float scaled = val_f32 / scale;
        int quant = int(round(clamp(scaled, -128.0f, 127.0f)));
        return char(quant);
    }

    inline static T dequantize(char quant_val, float scale) {
        return T(float(quant_val) * scale);
    }

    inline static float compute_scale(thread const T* data, uint size) {
        float max_abs = 0.0f;
        for (uint i = 0; i < size; ++i) {
            max_abs = max(max_abs, abs(float(data[i])));
        }
        return max_abs / 127.0f;
    }
};

/**
 * @brief INT6 quantization codec (packed into uint8)
 */
template<typename T, int WorldSize>
struct CodecQ6 {
    static constant int world_size = WorldSize;
    using quant_type = char;

    inline static char quantize(T value, thread float& scale) {
        float val_f32 = float(value);
        float scaled = val_f32 / scale;
        int quant = int(round(clamp(scaled, -32.0f, 31.0f)));
        return char(quant);
    }

    inline static T dequantize(char quant_val, float scale) {
        return T(float(quant_val) * scale);
    }

    inline static float compute_scale(thread const T* data, uint size) {
        float max_abs = 0.0f;
        for (uint i = 0; i < size; ++i) {
            max_abs = max(max_abs, abs(float(data[i])));
        }
        return max_abs / 31.0f;
    }
};

/**
 * @brief INT4 quantization codec
 */
template<typename T, int WorldSize>
struct CodecQ4 {
    static constant int world_size = WorldSize;
    using quant_type = char;

    inline static char quantize(T value, thread float& scale) {
        float val_f32 = float(value);
        float scaled = val_f32 / scale;
        int quant = int(round(clamp(scaled, -8.0f, 7.0f)));
        return char(quant);
    }

    inline static T dequantize(char quant_val, float scale) {
        return T(float(quant_val) * scale);
    }

    inline static float compute_scale(thread const T* data, uint size) {
        float max_abs = 0.0f;
        for (uint i = 0; i < size; ++i) {
            max_abs = max(max_abs, abs(float(data[i])));
        }
        return max_abs / 7.0f;
    }
};

// ============================================================================
// Reduction Operations
// ============================================================================

enum class ReduceOp : uint {
    SUM = 0,
    MAX = 1,
    MIN = 2,
    PROD = 3
};

template<typename T>
inline T apply_reduce_op(T a, T b, ReduceOp op) {
    switch (op) {
        case ReduceOp::SUM:
            return a + b;
        case ReduceOp::MAX:
            return max(a, b);
        case ReduceOp::MIN:
            return min(a, b);
        case ReduceOp::PROD:
            return a * b;
        default:
            return a + b;
    }
}

// ============================================================================
// Threadgroup-Level Reduction
// ============================================================================

template<typename T>
inline T threadgroup_reduce_sum(
    T value,
    threadgroup T* shared,
    uint tid,
    uint threadgroup_size)
{
    shared[tid] = value;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Tree reduction
    for (uint s = threadgroup_size / 2; s > 0; s >>= 1) {
        if (tid < s) {
            shared[tid] += shared[tid + s];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    return shared[0];
}

template<typename T>
inline T simd_reduce_sum(T value) {
    return simd_sum(value);
}

// ============================================================================
// Two-Shot All-Reduce Algorithm
// ============================================================================

/**
 * @brief Two-shot all-reduce kernel for FP16
 *
 * Phase 1: Reduce-scatter
 * Phase 2: All-gather
 */
template<typename T, typename Codec>
kernel void allreduce_twoshot_fp16(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    device uchar* comm_buffer [[buffer(2)]],       // Shared communication buffer
    device atomic_uint* flags [[buffer(3)]],        // Synchronization flags
    constant uint& N [[buffer(4)]],                 // Number of elements
    constant uint& world_size [[buffer(5)]],
    constant uint& rank [[buffer(6)]],
    constant uint& num_blocks [[buffer(7)]],
    constant uint& data_offset [[buffer(8)]],
    constant uint& flag_color [[buffer(9)]],
    uint gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint bid [[threadgroup_position_in_grid]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    threadgroup T shared_data[TWO_SHOT_THREADGROUP_SIZE];

    uint chunk_size = (N + world_size - 1) / world_size;
    uint my_chunk_start = rank * chunk_size;
    uint my_chunk_end = min(my_chunk_start + chunk_size, N);

    // Phase 1: Reduce-scatter
    // Each rank reduces its assigned chunk
    if (bid < num_blocks && gid < N) {
        uint chunk_idx = gid / chunk_size;
        uint local_idx = gid % chunk_size;

        if (chunk_idx == rank) {
            // Load local data
            T value = input[gid];

            // Sum contributions from all ranks (simplified)
            // In real implementation, would use peer-to-peer communication
            shared_data[tid] = value;
            threadgroup_barrier(mem_flags::mem_threadgroup);

            // Write to output
            if (tid == 0 && gid < N) {
                output[gid] = shared_data[0];
            }
        }
    }

    // Phase 2: All-gather
    // Broadcast reduced chunks to all ranks
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (gid < N) {
        // In real implementation, would gather from all ranks
        // For now, just copy local result
        output[gid] = output[gid];
    }
}

// ============================================================================
// One-Shot All-Reduce (for small data)
// ============================================================================

template<typename T>
kernel void allreduce_oneshot(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    device T* scratch [[buffer(2)]],
    constant uint& N [[buffer(3)]],
    constant uint& world_size [[buffer(4)]],
    constant uint& rank [[buffer(5)]],
    uint gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    threadgroup T shared[MAX_THREADGROUP_SIZE];

    // Load input
    T value = (gid < N) ? input[gid] : T(0);

    // Reduce within threadgroup
    T reduced = threadgroup_reduce_sum(value, shared, tid, threadgroup_size);

    // Write to scratch
    if (tid == 0 && gid < N) {
        scratch[gid] = reduced;
    }
    threadgroup_barrier(mem_flags::mem_device);

    // All-reduce across ranks (simplified)
    if (gid < N) {
        output[gid] = scratch[gid];
    }
}

// ============================================================================
// Quantized All-Reduce
// ============================================================================

template<typename T, typename Codec>
kernel void allreduce_quantized(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    device typename Codec::quant_type* quant_buffer [[buffer(2)]],
    device float* scales [[buffer(3)]],
    constant uint& N [[buffer(4)]],
    constant uint& world_size [[buffer(5)]],
    constant uint& rank [[buffer(6)]],
    uint gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    threadgroup T shared[MAX_THREADGROUP_SIZE];
    threadgroup float shared_scale;

    // Compute quantization scale
    if (tid == 0) {
        thread const T* local_data = &input[0];
        shared_scale = Codec::compute_scale(local_data, min(N, uint(MAX_THREADGROUP_SIZE)));
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    float scale = shared_scale;

    // Quantize
    if (gid < N) {
        T value = input[gid];
        quant_buffer[gid] = Codec::quantize(value, scale);
    }
    threadgroup_barrier(mem_flags::mem_device);

    // All-reduce on quantized values
    typename Codec::quant_type quant_sum = 0;
    if (gid < N) {
        quant_sum = quant_buffer[gid];
        // Accumulate from all ranks (simplified)
    }

    // Dequantize
    if (gid < N) {
        output[gid] = Codec::dequantize(quant_sum, scale);
    }
}

// ============================================================================
// Ring All-Reduce (for large world sizes)
// ============================================================================

template<typename T>
kernel void allreduce_ring(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    device T* ring_buffer [[buffer(2)]],
    constant uint& N [[buffer(3)]],
    constant uint& world_size [[buffer(4)]],
    constant uint& rank [[buffer(5)]],
    constant uint& step [[buffer(6)]],         // Current step in ring
    uint gid [[thread_position_in_grid]])
{
    uint chunk_size = (N + world_size - 1) / world_size;
    uint send_chunk = (rank - step + world_size) % world_size;
    uint recv_chunk = (rank - step - 1 + world_size) % world_size;

    uint send_start = send_chunk * chunk_size;
    uint send_end = min(send_start + chunk_size, N);

    uint recv_start = recv_chunk * chunk_size;
    uint recv_end = min(recv_start + chunk_size, N);

    // Send data
    if (gid >= send_start && gid < send_end) {
        uint local_idx = gid - send_start;
        ring_buffer[local_idx] = output[gid];
    }

    threadgroup_barrier(mem_flags::mem_device);

    // Receive and accumulate
    if (gid >= recv_start && gid < recv_end) {
        uint local_idx = gid - recv_start;
        output[gid] += ring_buffer[local_idx];
    }
}

// ============================================================================
// Local Reduction (single device)
// ============================================================================

template<typename T>
kernel void local_reduce_sum(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    constant uint& N [[buffer(2)]],
    uint gid [[thread_position_in_grid]],
    uint tid [[thread_position_in_threadgroup]],
    uint threadgroup_size [[threads_per_threadgroup]])
{
    threadgroup T shared[MAX_THREADGROUP_SIZE];

    // Each thread loads and sums multiple elements
    T sum = T(0);
    for (uint i = gid; i < N; i += threadgroup_size) {
        sum += input[i];
    }

    // Reduce within threadgroup
    T total = threadgroup_reduce_sum(sum, shared, tid, threadgroup_size);

    // Write result
    if (tid == 0) {
        atomic_fetch_add_explicit((device atomic<float>*)output, float(total), memory_order_relaxed);
    }
}

// ============================================================================
// Utility Kernels
// ============================================================================

/**
 * @brief Copy data between buffers
 */
template<typename T>
kernel void copy_buffer(
    device const T* input [[buffer(0)]],
    device T* output [[buffer(1)]],
    constant uint& N [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid < N) {
        output[gid] = input[gid];
    }
}

/**
 * @brief Initialize buffer with value
 */
template<typename T>
kernel void fill_buffer(
    device T* buffer [[buffer(0)]],
    constant T& value [[buffer(1)]],
    constant uint& N [[buffer(2)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid < N) {
        buffer[gid] = value;
    }
}

/**
 * @brief Zero out buffer
 */
kernel void zero_buffer(
    device uchar* buffer [[buffer(0)]],
    constant uint& N [[buffer(1)]],
    uint gid [[thread_position_in_grid]])
{
    if (gid < N) {
        buffer[gid] = 0;
    }
}
