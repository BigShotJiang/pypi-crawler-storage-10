#include <metal_stdlib>
using namespace metal;

// ============================================================================
// KV Cache Kernels for mlxllm
// Optimized for paged attention on Apple Silicon
// ============================================================================

// ============================================================================
// Reshape and Cache - stores keys/values into paged cache
// ============================================================================

kernel void reshape_and_cache_kernel(
    device const float* __restrict__ key [[buffer(0)]],        // [num_tokens, num_heads, head_size]
    device const float* __restrict__ value [[buffer(1)]],      // [num_tokens, num_heads, head_size]
    device float* __restrict__ key_cache [[buffer(2)]],        // [num_blocks, num_heads, head_size/x, block_size, x]
    device float* __restrict__ value_cache [[buffer(3)]],      // [num_blocks, num_heads, head_size, block_size]
    device const int* __restrict__ slot_mapping [[buffer(4)]], // [num_tokens]
    constant uint& num_tokens [[buffer(5)]],
    constant uint& num_heads [[buffer(6)]],
    constant uint& head_size [[buffer(7)]],
    constant uint& block_size [[buffer(8)]],
    constant uint& x [[buffer(9)]],  // Partitioning dimension (typically 16)
    uint tid [[thread_position_in_grid]]
) {
    uint token_idx = tid / (num_heads * head_size);
    uint remainder = tid % (num_heads * head_size);
    uint head_idx = remainder / head_size;
    uint head_offset = remainder % head_size;

    if (token_idx >= num_tokens) return;

    int slot_idx = slot_mapping[token_idx];
    if (slot_idx < 0) return;

    uint block_idx = slot_idx / block_size;
    uint block_offset = slot_idx % block_size;

    // Cache key
    uint x_idx = head_offset / x;
    uint x_offset = head_offset % x;

    uint key_cache_offset = block_idx * (num_heads * head_size * block_size) +
                           head_idx * (head_size * block_size) +
                           x_idx * (block_size * x) +
                           block_offset * x +
                           x_offset;

    key_cache[key_cache_offset] = key[tid];

    // Cache value
    uint value_cache_offset = block_idx * (num_heads * head_size * block_size) +
                             head_idx * (head_size * block_size) +
                             head_offset * block_size +
                             block_offset;

    value_cache[value_cache_offset] = value[tid];
}

kernel void reshape_and_cache_kernel_half(
    device const half* __restrict__ key [[buffer(0)]],
    device const half* __restrict__ value [[buffer(1)]],
    device half* __restrict__ key_cache [[buffer(2)]],
    device half* __restrict__ value_cache [[buffer(3)]],
    device const int* __restrict__ slot_mapping [[buffer(4)]],
    constant uint& num_tokens [[buffer(5)]],
    constant uint& num_heads [[buffer(6)]],
    constant uint& head_size [[buffer(7)]],
    constant uint& block_size [[buffer(8)]],
    constant uint& x [[buffer(9)]],
    uint tid [[thread_position_in_grid]]
) {
    uint token_idx = tid / (num_heads * head_size);
    uint remainder = tid % (num_heads * head_size);
    uint head_idx = remainder / head_size;
    uint head_offset = remainder % head_size;

    if (token_idx >= num_tokens) return;

    int slot_idx = slot_mapping[token_idx];
    if (slot_idx < 0) return;

    uint block_idx = slot_idx / block_size;
    uint block_offset = slot_idx % block_size;

    uint x_idx = head_offset / x;
    uint x_offset = head_offset % x;

    uint key_cache_offset = block_idx * (num_heads * head_size * block_size) +
                           head_idx * (head_size * block_size) +
                           x_idx * (block_size * x) +
                           block_offset * x +
                           x_offset;

    key_cache[key_cache_offset] = key[tid];

    uint value_cache_offset = block_idx * (num_heads * head_size * block_size) +
                             head_idx * (head_size * block_size) +
                             head_offset * block_size +
                             block_offset;

    value_cache[value_cache_offset] = value[tid];
}

// ============================================================================
// Copy Blocks - copies cache blocks according to mapping
// ============================================================================

kernel void copy_blocks_kernel(
    device const int* __restrict__ block_mapping [[buffer(0)]], // [num_pairs, 2]
    device float* __restrict__ key_cache [[buffer(1)]],
    device float* __restrict__ value_cache [[buffer(2)]],
    constant uint& num_pairs [[buffer(3)]],
    constant uint& block_size_in_bytes [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_pairs) return;

    int src_block_idx = block_mapping[tid * 2];
    int dst_block_idx = block_mapping[tid * 2 + 1];

    // Copy key cache block
    device const float* src_key = key_cache + src_block_idx * block_size_in_bytes / sizeof(float);
    device float* dst_key = key_cache + dst_block_idx * block_size_in_bytes / sizeof(float);

    for (uint i = 0; i < block_size_in_bytes / sizeof(float); i++) {
        dst_key[i] = src_key[i];
    }

    // Copy value cache block
    device const float* src_value = value_cache + src_block_idx * block_size_in_bytes / sizeof(float);
    device float* dst_value = value_cache + dst_block_idx * block_size_in_bytes / sizeof(float);

    for (uint i = 0; i < block_size_in_bytes / sizeof(float); i++) {
        dst_value[i] = src_value[i];
    }
}

// ============================================================================
// Swap Blocks - swaps cache blocks between src and dst
// ============================================================================

kernel void swap_blocks_kernel(
    device float* __restrict__ src [[buffer(0)]],
    device float* __restrict__ dst [[buffer(1)]],
    device const int* __restrict__ block_mapping [[buffer(2)]], // [num_pairs, 2]
    constant uint& num_pairs [[buffer(3)]],
    constant uint& block_size_in_bytes [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_pairs) return;

    int src_block_idx = block_mapping[tid * 2];
    int dst_block_idx = block_mapping[tid * 2 + 1];

    uint elements_per_block = block_size_in_bytes / sizeof(float);

    device float* src_block = src + src_block_idx * elements_per_block;
    device float* dst_block = dst + dst_block_idx * elements_per_block;

    // Swap elements
    for (uint i = 0; i < elements_per_block; i++) {
        float temp = src_block[i];
        src_block[i] = dst_block[i];
        dst_block[i] = temp;
    }
}

// ============================================================================
// Gather and Dequantize Cache
// Gathers cache entries from paged storage with optional dequantization
// ============================================================================

kernel void gather_cache_kernel(
    device const float* __restrict__ src_cache [[buffer(0)]],    // [num_blocks, block_size, ...]
    device float* __restrict__ dst [[buffer(1)]],                // [total_tokens, ...]
    device const int* __restrict__ block_table [[buffer(2)]],    // [batch_size, max_num_blocks]
    device const int* __restrict__ cu_seq_lens [[buffer(3)]],    // [batch_size + 1]
    constant uint& batch_size [[buffer(4)]],
    constant uint& block_size [[buffer(5)]],
    constant uint& num_features [[buffer(6)]],  // features per token
    constant uint& max_num_blocks [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    uint batch_idx = tid / num_features;
    uint feature_idx = tid % num_features;

    if (batch_idx >= batch_size) return;

    int seq_start = cu_seq_lens[batch_idx];
    int seq_end = cu_seq_lens[batch_idx + 1];
    int seq_len = seq_end - seq_start;

    for (int token_pos = 0; token_pos < seq_len; token_pos++) {
        int block_idx = token_pos / block_size;
        int block_offset = token_pos % block_size;

        if (block_idx >= max_num_blocks) break;

        int physical_block = block_table[batch_idx * max_num_blocks + block_idx];
        if (physical_block < 0) break;

        uint src_offset = physical_block * (block_size * num_features) +
                         block_offset * num_features +
                         feature_idx;

        uint dst_offset = (seq_start + token_pos) * num_features + feature_idx;

        dst[dst_offset] = src_cache[src_offset];
    }
}

// ============================================================================
// FP8 Conversion (for quantized KV cache)
// ============================================================================

// Simple FP8 E4M3 quantization (scale * clamp(input / scale))
kernel void convert_fp8_e4m3_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device uchar* __restrict__ output [[buffer(1)]],  // FP8 stored as uint8
    device float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    constant float& scale_value [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float value = input[tid];

    // Quantize to FP8 E4M3 range [-448, 448]
    const float max_fp8 = 448.0f;
    float scaled = value / scale_value;
    scaled = clamp(scaled, -max_fp8, max_fp8);

    // Store as uint8 (simplified - actual FP8 encoding would be more complex)
    output[tid] = static_cast<uchar>((scaled + max_fp8) * 255.0f / (2.0f * max_fp8));

    if (tid == 0) {
        *scale = scale_value;
    }
}

// FP8 dequantization
kernel void dequantize_fp8_e4m3_kernel(
    device const uchar* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const float* __restrict__ scale [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    const float max_fp8 = 448.0f;
    float quantized = static_cast<float>(input[tid]) * (2.0f * max_fp8) / 255.0f - max_fp8;
    output[tid] = quantized * (*scale);
}

// ============================================================================
// Multi-Latent Attention (MLA) Cache Operations
// ============================================================================

kernel void concat_and_cache_mla_kernel(
    device const float* __restrict__ kv_c [[buffer(0)]],       // Compressed KV [num_tokens, kv_lora_rank]
    device const float* __restrict__ k_pe [[buffer(1)]],       // Position encoding [num_tokens, qk_rope_head_dim]
    device float* __restrict__ kv_cache [[buffer(2)]],         // Combined cache
    device const int* __restrict__ slot_mapping [[buffer(3)]], // [num_tokens]
    constant uint& num_tokens [[buffer(4)]],
    constant uint& kv_lora_rank [[buffer(5)]],
    constant uint& qk_rope_head_dim [[buffer(6)]],
    constant uint& block_size [[buffer(7)]],
    uint tid [[thread_position_in_grid]]
) {
    uint token_idx = tid / (kv_lora_rank + qk_rope_head_dim);
    uint feature_idx = tid % (kv_lora_rank + qk_rope_head_dim);

    if (token_idx >= num_tokens) return;

    int slot_idx = slot_mapping[token_idx];
    if (slot_idx < 0) return;

    uint block_idx = slot_idx / block_size;
    uint block_offset = slot_idx % block_size;

    float value;
    if (feature_idx < kv_lora_rank) {
        // Copy from kv_c
        value = kv_c[token_idx * kv_lora_rank + feature_idx];
    } else {
        // Copy from k_pe
        uint pe_idx = feature_idx - kv_lora_rank;
        value = k_pe[token_idx * qk_rope_head_dim + pe_idx];
    }

    uint cache_stride = kv_lora_rank + qk_rope_head_dim;
    uint cache_offset = block_idx * (cache_stride * block_size) +
                       block_offset * cache_stride +
                       feature_idx;

    kv_cache[cache_offset] = value;
}
