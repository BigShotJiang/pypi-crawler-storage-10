#include <metal_stdlib>
using namespace metal;

// ============================================================================
// Metal Utility Kernels for mlxllm
// General-purpose operations and debugging utilities
// ============================================================================

// ============================================================================
// Memory Fill Operations
// ============================================================================

kernel void fill_float_kernel(
    device float* __restrict__ data [[buffer(0)]],
    constant float& value [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    data[tid] = value;
}

kernel void fill_int_kernel(
    device int* __restrict__ data [[buffer(0)]],
    constant int& value [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    data[tid] = value;
}

kernel void fill_half_kernel(
    device half* __restrict__ data [[buffer(0)]],
    constant half& value [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    data[tid] = value;
}

// ============================================================================
// Memory Copy Operations
// ============================================================================

kernel void memcpy_kernel(
    device const uchar* __restrict__ src [[buffer(0)]],
    device uchar* __restrict__ dst [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    dst[tid] = src[tid];
}

// Vectorized 4-byte copy
kernel void memcpy_kernel_vec4(
    device const uint* __restrict__ src [[buffer(0)]],
    device uint* __restrict__ dst [[buffer(1)]],
    constant uint& n [[buffer(2)]],  // Number of uint elements
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    dst[tid] = src[tid];
}

// ============================================================================
// Element-wise Arithmetic Operations
// ============================================================================

kernel void add_kernel(
    device const float* __restrict__ a [[buffer(0)]],
    device const float* __restrict__ b [[buffer(1)]],
    device float* __restrict__ output [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = a[tid] + b[tid];
}

kernel void add_scalar_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant float& scalar [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = input[tid] + scalar;
}

kernel void mul_kernel(
    device const float* __restrict__ a [[buffer(0)]],
    device const float* __restrict__ b [[buffer(1)]],
    device float* __restrict__ output [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = a[tid] * b[tid];
}

kernel void mul_scalar_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant float& scalar [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = input[tid] * scalar;
}

// ============================================================================
// Reduction Operations
// ============================================================================

// Sum reduction across all elements
kernel void reduce_sum_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    threadgroup float shared_data[256];

    // Each thread sums its assigned elements
    float sum = 0.0f;
    for (uint i = tid; i < n; i += tg_size) {
        sum += input[i];
    }

    shared_data[tid] = sum;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Parallel reduction in shared memory
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] += shared_data[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    // Thread 0 writes the result
    if (tid == 0) {
        *output = shared_data[0];
    }
}

// Max reduction
kernel void reduce_max_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    threadgroup float shared_data[256];

    float max_val = -INFINITY;
    for (uint i = tid; i < n; i += tg_size) {
        max_val = max(max_val, input[i]);
    }

    shared_data[tid] = max_val;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] = max(shared_data[tid], shared_data[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        *output = shared_data[0];
    }
}

// Min reduction
kernel void reduce_min_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    threadgroup float shared_data[256];

    float min_val = INFINITY;
    for (uint i = tid; i < n; i += tg_size) {
        min_val = min(min_val, input[i]);
    }

    shared_data[tid] = min_val;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_data[tid] = min(shared_data[tid], shared_data[tid + stride]);
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        *output = shared_data[0];
    }
}

// ============================================================================
// Clamp and Saturate Operations
// ============================================================================

kernel void clamp_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant float& min_val [[buffer(2)]],
    constant float& max_val [[buffer(3)]],
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = clamp(input[tid], min_val, max_val);
}

kernel void relu_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& n [[buffer(2)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = max(0.0f, input[tid]);
}

// ============================================================================
// Debugging and Validation Utilities
// ============================================================================

// Check for NaN/Inf values
kernel void check_finite_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device int* __restrict__ has_nan [[buffer(1)]],       // Output: 1 if NaN found
    device int* __restrict__ has_inf [[buffer(2)]],       // Output: 1 if Inf found
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;

    float val = input[tid];
    if (isnan(val)) {
        atomic_store_explicit((device atomic_int*)has_nan, 1, memory_order_relaxed);
    }
    if (isinf(val)) {
        atomic_store_explicit((device atomic_int*)has_inf, 1, memory_order_relaxed);
    }
}

// Compute statistics (mean, variance)
kernel void compute_stats_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ mean [[buffer(1)]],
    device float* __restrict__ variance [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_threadgroup]],
    uint tg_size [[threads_per_threadgroup]]
) {
    threadgroup float shared_sum[256];
    threadgroup float shared_sum_sq[256];

    // Compute local sum and sum of squares
    float sum = 0.0f;
    float sum_sq = 0.0f;
    for (uint i = tid; i < n; i += tg_size) {
        float val = input[i];
        sum += val;
        sum_sq += val * val;
    }

    shared_sum[tid] = sum;
    shared_sum_sq[tid] = sum_sq;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Reduce
    for (uint stride = tg_size / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared_sum[tid] += shared_sum[tid + stride];
            shared_sum_sq[tid] += shared_sum_sq[tid + stride];
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }

    if (tid == 0) {
        float total_sum = shared_sum[0];
        float total_sum_sq = shared_sum_sq[0];
        float mean_val = total_sum / float(n);
        float var_val = (total_sum_sq / float(n)) - (mean_val * mean_val);

        *mean = mean_val;
        *variance = var_val;
    }
}

// ============================================================================
// Gather/Scatter Operations
// ============================================================================

kernel void gather_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ indices [[buffer(2)]],
    constant uint& num_indices [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_indices) return;
    int idx = indices[tid];
    output[tid] = input[idx];
}

kernel void scatter_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ indices [[buffer(2)]],
    constant uint& num_indices [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= num_indices) return;
    int idx = indices[tid];
    output[idx] = input[tid];
}

// ============================================================================
// Index Generation
// ============================================================================

kernel void arange_kernel(
    device float* __restrict__ output [[buffer(0)]],
    constant float& start [[buffer(1)]],
    constant float& step [[buffer(2)]],
    constant uint& n [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = start + float(tid) * step;
}

// ============================================================================
// Masking Operations
// ============================================================================

kernel void apply_mask_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    device const int* __restrict__ mask [[buffer(2)]],     // 0 or 1
    constant float& mask_value [[buffer(3)]],              // Value for masked elements
    constant uint& n [[buffer(4)]],
    uint tid [[thread_position_in_grid]]
) {
    if (tid >= n) return;
    output[tid] = mask[tid] ? input[tid] : mask_value;
}

// ============================================================================
// Transpose 2D (small matrices)
// ============================================================================

kernel void transpose_kernel(
    device const float* __restrict__ input [[buffer(0)]],  // [rows, cols]
    device float* __restrict__ output [[buffer(1)]],       // [cols, rows]
    constant uint& rows [[buffer(2)]],
    constant uint& cols [[buffer(3)]],
    uint tid [[thread_position_in_grid]]
) {
    uint total = rows * cols;
    if (tid >= total) return;

    uint row = tid / cols;
    uint col = tid % cols;

    // input[row, col] -> output[col, row]
    output[col * rows + row] = input[tid];
}

// ============================================================================
// Optimized transpose using threadgroup memory (tile-based)
// ============================================================================

kernel void transpose_tiled_kernel(
    device const float* __restrict__ input [[buffer(0)]],
    device float* __restrict__ output [[buffer(1)]],
    constant uint& rows [[buffer(2)]],
    constant uint& cols [[buffer(3)]],
    uint2 gid [[threadgroup_position_in_grid]],
    uint2 tid [[thread_position_in_threadgroup]]
) {
    constexpr uint TILE_SIZE = 16;
    threadgroup float tile[TILE_SIZE][TILE_SIZE + 1];  // +1 to avoid bank conflicts

    uint base_row = gid.y * TILE_SIZE;
    uint base_col = gid.x * TILE_SIZE;

    uint row = base_row + tid.y;
    uint col = base_col + tid.x;

    // Load tile from input
    if (row < rows && col < cols) {
        tile[tid.y][tid.x] = input[row * cols + col];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    // Write transposed tile to output
    uint out_row = base_col + tid.y;
    uint out_col = base_row + tid.x;

    if (out_row < cols && out_col < rows) {
        output[out_row * rows + out_col] = tile[tid.x][tid.y];
    }
}
