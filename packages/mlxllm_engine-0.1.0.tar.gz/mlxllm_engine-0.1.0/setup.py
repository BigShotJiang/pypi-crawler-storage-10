#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Setup script for MLX-LLM package.

This package has a non-standard layout where the package code is in the repository
root directory rather than a src/ subdirectory. This means:
- ./__init__.py becomes mlxllm/__init__.py
- ./config/__init__.py becomes mlxllm/config/__init__.py
- etc.
"""

import os
import subprocess
import sys
from pathlib import Path
from setuptools import setup
from setuptools.command.develop import develop
from setuptools.command.install import install
from setuptools.command.build_py import build_py

# Import our requirements parser
try:
    # Add scripts directory to path for import
    scripts_dir = Path(__file__).parent / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))

    from parse_requirements import (
        get_install_requires,
        categorize_dev_requires,
        get_docs_requires,
    )
    USE_REQUIREMENTS_FILES = True
    print("✓ Using requirements files from requirements/ directory")
except ImportError as e:
    print(f"Warning: Could not import parse_requirements: {e}")
    print("Using hardcoded dependencies instead")
    USE_REQUIREMENTS_FILES = False


def build_metalcutlass():
    """Build and install metalcutlass package before mlxllm."""
    metalcutlass_dir = Path(__file__).parent / "packages" / "metalcutlass"

    if not metalcutlass_dir.exists():
        print("WARNING: metalcutlass directory not found, skipping build")
        return False

    print("=" * 70)
    print("Building metalcutlass (required dependency)...")
    print("=" * 70)

    # Check if metalcutlass is already installed
    try:
        import metalcutlass
        print(f"✓ metalcutlass already installed (version: {getattr(metalcutlass, '__version__', 'unknown')})")
        return True
    except ImportError:
        pass

    # Build and install metalcutlass
    original_dir = os.getcwd()
    try:
        os.chdir(metalcutlass_dir)
        print(f"Installing metalcutlass from: {metalcutlass_dir}")

        # Use pip to install in editable mode
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-e", "."],
            check=False,
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            print("ERROR: Failed to build metalcutlass")
            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)
            print("\nYou can manually install metalcutlass with:")
            print(f"  cd {metalcutlass_dir}")
            print("  pip install -e .")
            return False

        print("✓ metalcutlass built and installed successfully")
        return True

    except Exception as e:
        print(f"ERROR building metalcutlass: {e}")
        return False
    finally:
        os.chdir(original_dir)


class CustomDevelop(develop):
    """Custom develop command that builds metalcutlass first."""

    def run(self):
        # Build metalcutlass before installing mlxllm in develop mode
        if not build_metalcutlass():
            print("\nWARNING: metalcutlass build failed, but continuing...")
            print("mlxllm may not work correctly without metalcutlass.")

        # Run the standard develop installation
        develop.run(self)


class CustomInstall(install):
    """Custom install command that builds metalcutlass first."""

    def run(self):
        # Build metalcutlass before installing mlxllm
        if not build_metalcutlass():
            print("\nWARNING: metalcutlass build failed, but continuing...")
            print("mlxllm may not work correctly without metalcutlass.")

        # Run the standard installation
        install.run(self)


class CustomBuildPy(build_py):
    """Custom build_py command that builds metalcutlass first."""

    def run(self):
        # Build metalcutlass before building mlxllm
        if not build_metalcutlass():
            print("\nWARNING: metalcutlass build failed, but continuing...")
            print("mlxllm may not work correctly without metalcutlass.")

        # Run the standard build
        build_py.run(self)


# Find all packages by looking for __init__.py files
def find_mlxllm_packages():
    """Find all packages in current directory, mapping them to mlxllm.* or csrc.*"""
    packages = []
    base_path = Path(".")

    for init_file in sorted(base_path.rglob("__init__.py")):
        # Skip excluded directories
        parts = init_file.parts
        if any(p in ("tests", "docs", "examples", "__pycache__", "build", "dist", ".egg-info", "packages", "resources")
               for p in parts):
            continue

        pkg_dir = init_file.parent
        rel_path = pkg_dir.relative_to(base_path)

        # Root __init__.py becomes "mlxllm"
        if str(rel_path) == ".":
            packages.append("mlxllm")
        # csrc packages stay as csrc.*
        elif str(rel_path).startswith("csrc"):
            pkg_name = str(rel_path).replace("/", ".")
            packages.append(pkg_name)
        # mlxllm/ subdirectory packages
        elif str(rel_path).startswith("mlxllm"):
            # Already has mlxllm prefix, just convert slashes
            pkg_name = str(rel_path).replace("/", ".")
            packages.append(pkg_name)
        else:
            # Other packages get mlxllm prefix
            pkg_name = "mlxllm." + str(rel_path).replace("/", ".")
            packages.append(pkg_name)

    return packages

# Build package_dir mapping
def build_package_dir():
    """Map mlxllm.* and csrc.* packages to their actual directories."""
    package_dir = {"mlxllm": "."}  # Root

    base_path = Path(".")
    for init_file in base_path.rglob("__init__.py"):
        parts = init_file.parts
        if any(p in ("tests", "docs", "examples", "__pycache__", "build", "dist", ".egg-info", "packages", "resources")
               for p in parts):
            continue

        pkg_dir = init_file.parent
        rel_path = pkg_dir.relative_to(base_path)

        if str(rel_path) != ".":
            # csrc packages map directly
            if str(rel_path).startswith("csrc"):
                pkg_name = str(rel_path).replace("/", ".")
                package_dir[pkg_name] = str(rel_path)
            # mlxllm/ subdirectory packages
            elif str(rel_path).startswith("mlxllm"):
                pkg_name = str(rel_path).replace("/", ".")
                package_dir[pkg_name] = str(rel_path)
            else:
                # Other packages get mlxllm prefix
                pkg_name = "mlxllm." + str(rel_path).replace("/", ".")
                package_dir[pkg_name] = str(rel_path)

    return package_dir

# Read version
version = {}
version_file = Path(__file__).parent / "version.py"
if version_file.exists():
    with open(version_file) as f:
        exec(f.read(), version)
else:
    version["__version__"] = "0.1.0"

# Read long description
readme_file = Path(__file__).parent / "IMPLEMENTATION_PROGRESS.md"
if readme_file.exists():
    with open(readme_file, encoding="utf-8") as f:
        long_description = f.read()
else:
    long_description = "MLX-optimized vLLM v1 implementation for Apple Silicon"


def _get_extras_require():
    """
    Get extras_require dictionary from requirements files or fallback to hardcoded.

    Returns organized categories: dev, test, docs, lint, build, all
    """
    if USE_REQUIREMENTS_FILES:
        categories = categorize_dev_requires()
        docs_deps = get_docs_requires()

        # Build extras_require dict
        extras = {
            "test": categories.get("test", []),
            "lint": categories.get("lint", []),
            "docs": docs_deps,  # Use docs requirements file
            "build": categories.get("build", []),
        }

        # Create combined extras
        extras["dev"] = (
            extras["test"] +
            extras["lint"] +
            extras["docs"] +
            extras["build"]
        )

        # Create "all" that includes everything
        extras["all"] = list(set(extras["dev"]))  # Deduplicate

        return extras
    else:
        # Fallback to hardcoded dependencies
        return {
            "dev": [
                "pytest>=7.0.0",
                "pytest-asyncio>=0.21.0",
                "pytest-cov>=4.0.0",
                "pytest-benchmark>=4.0.0",
                "black>=23.0.0",
                "mypy>=1.0.0",
                "ruff>=0.1.0",
                "isort>=5.10.0",
            ],
            "test": [
                "pytest>=7.0.0",
                "pytest-asyncio>=0.21.0",
                "pytest-cov>=4.0.0",
                "pytest-benchmark>=4.0.0",
            ],
            "docs": [
                "sphinx>=7.0.0",
                "sphinx-rtd-theme>=2.0.0",
                "sphinx-autodoc-typehints>=2.0.0",
                "sphinx-copybutton>=0.5.0",
                "myst-parser>=2.0.0",
                "sphinx-autobuild>=2024.0.0",
            ],
        }


setup(
    name="mlxllm-engine",
    version=version.get("__version__", "0.1.0"),
    description="MLX-optimized vLLM v1 implementation for Apple Silicon",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Agent-XSH",
    author_email="dev@agent-xsh.ai",
    url="https://github.com/agent-xsh/mlxllm",
    license="Apache-2.0",
    packages=find_mlxllm_packages(),
    package_dir=build_package_dir(),
    # Custom commands that build metalcutlass automatically
    cmdclass={
        "develop": CustomDevelop,
        "install": CustomInstall,
        "build_py": CustomBuildPy,
    },
    package_data={
        "mlxllm": ["py.typed"],
        "csrc": ["*.metal", "**/*.metal"],
    },
    include_package_data=True,
    python_requires=">=3.11",
    # Install requirements from requirements/requirements.txt or fallback to hardcoded
    install_requires=get_install_requires() if USE_REQUIREMENTS_FILES else [
        "mlx>=0.19.0",
        "transformers>=4.40.0",
        "safetensors>=0.4.0",
        "numpy>=1.24.0",
        "tokenizers>=0.13.0",
        "torch>=2.0.0",
        "huggingface-hub>=0.16.0",
        # Note: metalcutlass must be installed separately first
        # from packages/metalcutlass directory
    ],
    # Extras from requirements files (categorized) or fallback to hardcoded
    extras_require=_get_extras_require(),
    entry_points={
        "console_scripts": [
            "mlxllm=mlxllm.entry_points.cli.main:main",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords=["mlx", "llm", "inference", "apple-silicon", "metal"],
    zip_safe=False,
)
