# SPDX-License-Identifier: Apache-2.0
"""Tests for encoder cache manager."""

from __future__ import annotations

import pytest

from mlxllm.core.encoder_cache_manager import EncoderCacheManager
from mlxllm.config import CacheConfig


@pytest.fixture
def cache_config():
    """Create a cache config."""
    return CacheConfig(
        block_size=16,
        num_gpu_blocks=100,
        enable_embedding_cache=True,
    )


@pytest.mark.unit
class TestEncoderCacheManager:
    """Tests for EncoderCacheManager class."""

    def test_creation(self, cache_config):
        """Test creating encoder cache manager."""
        manager = EncoderCacheManager(
            cache_config=cache_config,
            max_cache_size_mb=512,
        )

        assert manager.max_cache_size_mb == 512
        assert manager.current_size_bytes == 0
        assert len(manager.cache) == 0
        assert manager.hits == 0
        assert manager.misses == 0

    def test_get_miss(self, cache_config):
        """Test cache miss."""
        manager = EncoderCacheManager(cache_config)

        result = manager.get(input_hash=12345)

        assert result is None
        assert manager.misses == 1
        assert manager.hits == 0

    def test_put_and_get(self, cache_config):
        """Test caching and retrieving."""
        manager = EncoderCacheManager(cache_config)

        embedding = [1.0, 2.0, 3.0]
        size_bytes = 100

        manager.put(12345, embedding, size_bytes)

        result = manager.get(12345)

        assert result == embedding
        assert manager.hits == 1
        assert manager.current_size_bytes == size_bytes

    def test_remove(self, cache_config):
        """Test removing from cache."""
        manager = EncoderCacheManager(cache_config)

        manager.put(12345, [1.0, 2.0], 100)
        assert 12345 in manager.cache

        manager.remove(12345)
        assert 12345 not in manager.cache
        assert manager.current_size_bytes == 0

    def test_eviction(self, cache_config):
        """Test cache eviction when full."""
        manager = EncoderCacheManager(
            cache_config,
            max_cache_size_mb=1,  # Very small
        )

        max_bytes = manager.max_cache_size_bytes

        # Add entries until eviction occurs
        manager.put(1, [1.0], max_bytes // 2 + 1)
        manager.put(2, [2.0], max_bytes // 2 + 1)

        # First entry should be evicted
        assert 1 not in manager.cache
        assert 2 in manager.cache

    def test_clear(self, cache_config):
        """Test clearing cache."""
        manager = EncoderCacheManager(cache_config)

        manager.put(1, [1.0], 100)
        manager.put(2, [2.0], 100)

        manager.clear()

        assert len(manager.cache) == 0
        assert manager.current_size_bytes == 0
        assert manager.hits == 0
        assert manager.misses == 0

    def test_size_mb_property(self, cache_config):
        """Test size_mb property."""
        manager = EncoderCacheManager(cache_config)

        manager.put(1, [1.0], 1024 * 1024)  # 1 MB

        assert manager.size_mb == 1.0

    def test_utilization_property(self, cache_config):
        """Test utilization property."""
        manager = EncoderCacheManager(
            cache_config,
            max_cache_size_mb=10,
        )

        manager.put(1, [1.0], 5 * 1024 * 1024)  # 5 MB

        assert manager.utilization == 0.5

    def test_hit_rate_property(self, cache_config):
        """Test hit_rate property."""
        manager = EncoderCacheManager(cache_config)

        manager.put(1, [1.0], 100)

        # One miss when getting non-existent
        manager.get(2)

        # One hit
        manager.get(1)

        assert manager.hit_rate == 0.5

    def test_hit_rate_no_accesses(self, cache_config):
        """Test hit rate with no accesses."""
        manager = EncoderCacheManager(cache_config)

        assert manager.hit_rate == 0.0

    def test_caching_disabled(self, cache_config):
        """Test that caching is disabled when config says so."""
        cache_config.enable_embedding_cache = False
        manager = EncoderCacheManager(cache_config)

        manager.put(1, [1.0], 100)
        result = manager.get(1)

        assert result is None
        assert len(manager.cache) == 0

    def test_repr(self, cache_config):
        """Test string representation."""
        manager = EncoderCacheManager(cache_config)

        manager.put(1, [1.0], 1024 * 1024)

        repr_str = repr(manager)
        assert "EncoderCacheManager" in repr_str
        assert "size=" in repr_str
        assert "entries=1" in repr_str
