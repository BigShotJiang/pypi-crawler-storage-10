# SPDX-License-Identifier: Apache-2.0
"""Tests for scheduler interface."""

from __future__ import annotations

import pytest

from mlxllm.core.sched.interface import SchedulerInterface
from mlxllm.core.sched.output import SchedulerOutput
from mlxllm.sequence import Sequence, SequenceGroup
from mlxllm.sampling_params import SamplingParams


class MockScheduler(SchedulerInterface):
    """Mock scheduler for testing the interface."""

    def __init__(self):
        self.requests = {}
        self.schedule_calls = 0
        self.free_calls = 0

    def add_request(self, seq_group: SequenceGroup) -> None:
        """Add a request."""
        self.requests[seq_group.request_id] = seq_group

    def abort_request(self, request_id: str) -> None:
        """Abort a request."""
        if request_id in self.requests:
            del self.requests[request_id]

    def schedule(self) -> SchedulerOutput:
        """Schedule requests."""
        self.schedule_calls += 1
        return SchedulerOutput()

    def free_finished_requests(self) -> None:
        """Free finished requests."""
        self.free_calls += 1

    def get_num_unfinished_requests(self) -> int:
        """Get number of unfinished requests."""
        return len(self.requests)


@pytest.fixture
def mock_scheduler():
    """Create a mock scheduler."""
    return MockScheduler()


@pytest.fixture
def sample_sequence():
    """Create a sample sequence."""
    return Sequence(
        seq_id="seq_0",
        prompt="test prompt",
        prompt_token_ids=[1, 2, 3, 4, 5],
    )


@pytest.fixture
def sample_sequence_group(sample_sequence):
    """Create a sample sequence group."""
    return SequenceGroup(
        request_id="req_0",
        sequences=[sample_sequence],
        sampling_params=SamplingParams(),
        arrival_time=0.0,
    )


@pytest.mark.unit
class TestSchedulerInterface:
    """Tests for SchedulerInterface."""

    def test_interface_is_abstract(self):
        """Test that SchedulerInterface is abstract."""
        # Should not be able to instantiate directly
        with pytest.raises(TypeError):
            SchedulerInterface()

    def test_mock_implements_interface(self, mock_scheduler):
        """Test that MockScheduler implements the interface."""
        assert isinstance(mock_scheduler, SchedulerInterface)

    def test_add_request(self, mock_scheduler, sample_sequence_group):
        """Test adding a request."""
        mock_scheduler.add_request(sample_sequence_group)

        assert len(mock_scheduler.requests) == 1
        assert "req_0" in mock_scheduler.requests
        assert mock_scheduler.get_num_unfinished_requests() == 1

    def test_abort_request(self, mock_scheduler, sample_sequence_group):
        """Test aborting a request."""
        mock_scheduler.add_request(sample_sequence_group)
        assert len(mock_scheduler.requests) == 1

        mock_scheduler.abort_request("req_0")
        assert len(mock_scheduler.requests) == 0
        assert mock_scheduler.get_num_unfinished_requests() == 0

    def test_abort_nonexistent_request(self, mock_scheduler):
        """Test aborting a request that doesn't exist."""
        # Should not raise an error
        mock_scheduler.abort_request("nonexistent")
        assert len(mock_scheduler.requests) == 0

    def test_schedule(self, mock_scheduler):
        """Test schedule method."""
        output = mock_scheduler.schedule()

        assert isinstance(output, SchedulerOutput)
        assert mock_scheduler.schedule_calls == 1

    def test_schedule_multiple_calls(self, mock_scheduler):
        """Test multiple schedule calls."""
        for _ in range(5):
            mock_scheduler.schedule()

        assert mock_scheduler.schedule_calls == 5

    def test_free_finished_requests(self, mock_scheduler):
        """Test freeing finished requests."""
        mock_scheduler.free_finished_requests()
        assert mock_scheduler.free_calls == 1

    def test_get_num_unfinished_requests(self, mock_scheduler):
        """Test getting number of unfinished requests."""
        assert mock_scheduler.get_num_unfinished_requests() == 0

        # Add some requests
        for i in range(3):
            seq = Sequence(
                seq_id=f"seq_{i}",
                prompt="test",
                prompt_token_ids=[1, 2, 3],
            )
            seq_group = SequenceGroup(
                request_id=f"req_{i}",
                sequences=[seq],
                sampling_params=SamplingParams(),
                arrival_time=float(i),
            )
            mock_scheduler.add_request(seq_group)

        assert mock_scheduler.get_num_unfinished_requests() == 3

    def test_workflow(self, mock_scheduler, sample_sequence_group):
        """Test typical workflow with the interface."""
        # Add request
        mock_scheduler.add_request(sample_sequence_group)
        assert mock_scheduler.get_num_unfinished_requests() == 1

        # Schedule
        output = mock_scheduler.schedule()
        assert isinstance(output, SchedulerOutput)

        # Free finished
        mock_scheduler.free_finished_requests()

        # Abort remaining
        mock_scheduler.abort_request("req_0")
        assert mock_scheduler.get_num_unfinished_requests() == 0

    def test_multiple_requests(self, mock_scheduler):
        """Test handling multiple requests."""
        # Add multiple requests
        for i in range(5):
            seq = Sequence(
                seq_id=f"seq_{i}",
                prompt=f"prompt {i}",
                prompt_token_ids=list(range(i, i + 10)),
            )
            seq_group = SequenceGroup(
                request_id=f"req_{i}",
                sequences=[seq],
                sampling_params=SamplingParams(),
                arrival_time=float(i),
            )
            mock_scheduler.add_request(seq_group)

        assert mock_scheduler.get_num_unfinished_requests() == 5

        # Abort some
        mock_scheduler.abort_request("req_1")
        mock_scheduler.abort_request("req_3")

        assert mock_scheduler.get_num_unfinished_requests() == 3

        # Schedule
        output = mock_scheduler.schedule()
        assert isinstance(output, SchedulerOutput)
        assert mock_scheduler.schedule_calls == 1
