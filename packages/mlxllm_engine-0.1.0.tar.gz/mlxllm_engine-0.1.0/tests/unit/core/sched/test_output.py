# SPDX-License-Identifier: Apache-2.0
"""Tests for scheduler output data structures."""

from __future__ import annotations

import pytest

from mlxllm.core.sched.output import (
    ScheduledSequenceGroup,
    SchedulerOutput,
    SchedulerOutputType,
)
from mlxllm.sequence import Sequence, SequenceGroup
from mlxllm.sampling_params import SamplingParams


@pytest.fixture
def mock_sequence():
    """Create a mock sequence."""
    return Sequence(
        seq_id="seq_0",
        prompt="test prompt",
        prompt_token_ids=[1, 2, 3, 4, 5],
    )


@pytest.fixture
def mock_sequence_group(mock_sequence):
    """Create a mock sequence group."""
    return SequenceGroup(
        request_id="req_0",
        sequences=[mock_sequence],
        sampling_params=SamplingParams(),
        arrival_time=0.0,
    )


@pytest.mark.unit
class TestSchedulerOutputType:
    """Tests for SchedulerOutputType enum."""

    def test_enum_values(self):
        """Test that enum has expected values."""
        assert SchedulerOutputType.PREFILL == "prefill"
        assert SchedulerOutputType.DECODE == "decode"
        assert SchedulerOutputType.MIXED == "mixed"


@pytest.mark.unit
class TestScheduledSequenceGroup:
    """Tests for ScheduledSequenceGroup dataclass."""

    def test_creation(self, mock_sequence_group):
        """Test creating a ScheduledSequenceGroup."""
        scheduled = ScheduledSequenceGroup(
            seq_group=mock_sequence_group,
            token_chunk_size=10,
            is_prefill=True,
        )

        assert scheduled.seq_group == mock_sequence_group
        assert scheduled.token_chunk_size == 10
        assert scheduled.is_prefill is True

    def test_decode_scheduled_group(self, mock_sequence_group):
        """Test creating a decode-phase scheduled group."""
        scheduled = ScheduledSequenceGroup(
            seq_group=mock_sequence_group,
            token_chunk_size=1,
            is_prefill=False,
        )

        assert scheduled.token_chunk_size == 1
        assert scheduled.is_prefill is False


@pytest.mark.unit
class TestSchedulerOutput:
    """Tests for SchedulerOutput dataclass."""

    def test_empty_output(self):
        """Test creating an empty scheduler output."""
        output = SchedulerOutput()

        assert len(output.scheduled_groups) == 0
        assert output.num_batched_tokens == 0
        assert output.num_prefill_groups == 0
        assert output.num_decode_groups == 0
        assert len(output.ignored_groups) == 0
        assert len(output.preempted_groups) == 0
        assert len(output.swapped_in_groups) == 0
        assert len(output.swapped_out_groups) == 0
        assert len(output.blocks_to_swap_in) == 0
        assert len(output.blocks_to_swap_out) == 0
        assert len(output.blocks_to_copy) == 0

    def test_is_empty(self):
        """Test is_empty property."""
        output = SchedulerOutput()
        assert output.is_empty is True

        # Add a scheduled group
        seq = Sequence(seq_id="seq_0", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group = SequenceGroup(
            request_id="req_0",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )
        scheduled = ScheduledSequenceGroup(
            seq_group=seq_group,
            token_chunk_size=3,
            is_prefill=True,
        )
        output.scheduled_groups.append(scheduled)

        assert output.is_empty is False

    def test_output_type_prefill(self):
        """Test output_type for prefill-only batch."""
        output = SchedulerOutput(
            num_prefill_groups=2,
            num_decode_groups=0,
        )

        assert output.output_type == SchedulerOutputType.PREFILL

    def test_output_type_decode(self):
        """Test output_type for decode-only batch."""
        output = SchedulerOutput(
            num_prefill_groups=0,
            num_decode_groups=3,
        )

        assert output.output_type == SchedulerOutputType.DECODE

    def test_output_type_mixed(self):
        """Test output_type for mixed batch."""
        output = SchedulerOutput(
            num_prefill_groups=1,
            num_decode_groups=2,
        )

        assert output.output_type == SchedulerOutputType.MIXED

    def test_with_scheduled_groups(self, mock_sequence_group):
        """Test output with scheduled groups."""
        scheduled = ScheduledSequenceGroup(
            seq_group=mock_sequence_group,
            token_chunk_size=5,
            is_prefill=True,
        )

        output = SchedulerOutput(
            scheduled_groups=[scheduled],
            num_batched_tokens=5,
            num_prefill_groups=1,
            num_decode_groups=0,
        )

        assert len(output.scheduled_groups) == 1
        assert output.num_batched_tokens == 5
        assert output.output_type == SchedulerOutputType.PREFILL

    def test_with_swap_operations(self):
        """Test output with swap operations."""
        output = SchedulerOutput(
            blocks_to_swap_in={0: 10, 1: 11},
            blocks_to_swap_out={20: 30, 21: 31},
        )

        assert output.blocks_to_swap_in == {0: 10, 1: 11}
        assert output.blocks_to_swap_out == {20: 30, 21: 31}

    def test_with_preempted_groups(self, mock_sequence_group):
        """Test output with preempted groups."""
        output = SchedulerOutput(
            preempted_groups=[mock_sequence_group],
        )

        assert len(output.preempted_groups) == 1
        assert output.preempted_groups[0] == mock_sequence_group

    def test_with_ignored_groups(self, mock_sequence_group):
        """Test output with ignored groups."""
        output = SchedulerOutput(
            ignored_groups=[mock_sequence_group],
        )

        assert len(output.ignored_groups) == 1
        assert output.ignored_groups[0] == mock_sequence_group

    def test_blocks_to_copy(self):
        """Test blocks_to_copy for sequence forking."""
        output = SchedulerOutput(
            blocks_to_copy={0: [1, 2], 3: [4, 5, 6]},
        )

        assert output.blocks_to_copy[0] == [1, 2]
        assert output.blocks_to_copy[3] == [4, 5, 6]

    def test_repr(self):
        """Test string representation."""
        output = SchedulerOutput(
            num_batched_tokens=128,
            num_prefill_groups=2,
            num_decode_groups=3,
        )

        # Add some scheduled groups
        seq = Sequence(seq_id="seq_0", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group = SequenceGroup(
            request_id="req_0",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )
        scheduled = ScheduledSequenceGroup(
            seq_group=seq_group,
            token_chunk_size=3,
            is_prefill=True,
        )
        output.scheduled_groups.append(scheduled)

        repr_str = repr(output)
        assert "SchedulerOutput" in repr_str
        assert "groups=1" in repr_str
        assert "tokens=128" in repr_str
        assert "prefill=2" in repr_str
        assert "decode=3" in repr_str

    def test_full_output_with_all_fields(self, mock_sequence_group):
        """Test creating output with all fields populated."""
        scheduled = ScheduledSequenceGroup(
            seq_group=mock_sequence_group,
            token_chunk_size=10,
            is_prefill=True,
        )

        output = SchedulerOutput(
            scheduled_groups=[scheduled],
            num_batched_tokens=10,
            num_prefill_groups=1,
            num_decode_groups=0,
            ignored_groups=[],
            preempted_groups=[],
            swapped_in_groups=[],
            swapped_out_groups=[],
            blocks_to_swap_in={},
            blocks_to_swap_out={},
            blocks_to_copy={},
        )

        assert len(output.scheduled_groups) == 1
        assert output.num_batched_tokens == 10
        assert output.output_type == SchedulerOutputType.PREFILL
        assert output.is_empty is False
