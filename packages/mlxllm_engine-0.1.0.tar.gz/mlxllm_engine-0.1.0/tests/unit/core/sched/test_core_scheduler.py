# SPDX-License-Identifier: Apache-2.0
"""Tests for core scheduler."""

from __future__ import annotations

import pytest

from mlxllm.core.sched.scheduler import Scheduler
from mlxllm.core.sched.output import SchedulerOutputType
from mlxllm.config import SchedulerConfig, CacheConfig, KVCacheConfig, ModelConfig, ModelType
from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.sequence import Sequence, SequenceGroup, SequenceStatus
from mlxllm.sampling_params import SamplingParams


@pytest.fixture
def scheduler_config():
    """Create scheduler config."""
    return SchedulerConfig(
        max_num_batched_tokens=256,
        max_num_sequences=32,
        max_model_len=2048,
        policy="fcfs",
        preemption_mode="recompute",
    )


@pytest.fixture
def cache_config():
    """Create cache config."""
    return CacheConfig(
        kv_cache=KVCacheConfig(
            block_size=16,
            num_gpu_blocks=100,
        ),
    )


@pytest.fixture
def model_config():
    """Create model config."""
    return ModelConfig(
        model_type=ModelType.LLAMA,
        model_name="test-model",
        num_layers=2,
        num_attention_heads=8,
        num_kv_heads=8,
        head_dim=64,
        hidden_size=512,
        vocab_size=1000,
        max_position_embeddings=2048,
        dtype="bfloat16",
    )


@pytest.fixture
def kv_cache_manager(cache_config, model_config):
    """Create KV cache manager."""
    return KVCacheManager(cache_config.kv_cache, model_config)


@pytest.fixture
def scheduler(scheduler_config, cache_config, kv_cache_manager):
    """Create scheduler."""
    return Scheduler(scheduler_config, cache_config, kv_cache_manager)


@pytest.mark.unit
class TestScheduler:
    """Tests for Scheduler."""

    def test_creation(self, scheduler, scheduler_config):
        """Test creating scheduler."""
        assert scheduler.scheduler_config == scheduler_config
        assert len(scheduler.waiting) == 0
        assert len(scheduler.running) == 0
        assert len(scheduler.swapped) == 0

    def test_add_request(self, scheduler):
        """Test adding a request."""
        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )

        scheduler.add_request(seq_group)

        assert len(scheduler.waiting) == 1
        assert scheduler.get_num_unfinished_requests() == 1

    def test_abort_request_in_waiting(self, scheduler):
        """Test aborting request in waiting queue."""
        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )

        scheduler.add_request(seq_group)
        scheduler.abort_request("req_1")

        assert len(scheduler.waiting) == 0

    def test_schedule_empty(self, scheduler):
        """Test scheduling with no requests."""
        output = scheduler.schedule()

        assert output.is_empty
        assert output.num_batched_tokens == 0

    def test_schedule_single_request(self, scheduler):
        """Test scheduling a single request."""
        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3, 4, 5])
        seq_group = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )

        scheduler.add_request(seq_group)
        output = scheduler.schedule()

        assert not output.is_empty
        assert len(output.scheduled_groups) == 1
        assert output.output_type == SchedulerOutputType.PREFILL
        assert output.num_prefill_groups == 1

    def test_schedule_multiple_requests(self, scheduler):
        """Test scheduling multiple requests."""
        for i in range(3):
            seq = Sequence(seq_id=f"seq_{i}", prompt="test", prompt_token_ids=[1, 2, 3])
            seq_group = SequenceGroup(
                request_id=f"req_{i}",
                sequences=[seq],
                sampling_params=SamplingParams(),
                arrival_time=float(i),
            )
            scheduler.add_request(seq_group)

        output = scheduler.schedule()

        assert len(output.scheduled_groups) >= 1
        assert output.num_prefill_groups >= 1

    def test_free_finished_requests(self, scheduler):
        """Test freeing finished requests."""
        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3])
        seq.status = SequenceStatus.FINISHED
        seq_group = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )

        scheduler.running.append(seq_group)
        assert len(scheduler.running) == 1

        scheduler.free_finished_requests()

        assert len(scheduler.running) == 0

    def test_get_num_unfinished_requests(self, scheduler):
        """Test getting number of unfinished requests."""
        assert scheduler.get_num_unfinished_requests() == 0

        # Add to waiting
        seq1 = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group1 = SequenceGroup(
            request_id="req_1",
            sequences=[seq1],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )
        scheduler.add_request(seq_group1)

        # Add to running
        seq2 = Sequence(seq_id="seq_2", prompt="test", prompt_token_ids=[1, 2, 3])
        seq_group2 = SequenceGroup(
            request_id="req_2",
            sequences=[seq2],
            sampling_params=SamplingParams(),
            arrival_time=1.0,
        )
        scheduler.running.append(seq_group2)

        assert scheduler.get_num_unfinished_requests() == 2

    def test_token_budget_limit(self, scheduler, scheduler_config):
        """Test that token budget is respected."""
        # Create large request that exceeds budget
        long_tokens = [1] * 300  # Larger than max_num_batched_tokens (256)
        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=long_tokens)
        seq_group = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=SamplingParams(),
            arrival_time=0.0,
        )

        scheduler.add_request(seq_group)
        output = scheduler.schedule()

        # Should schedule with chunked prefill (limited to budget)
        if not output.is_empty:
            assert output.num_batched_tokens <= scheduler_config.max_num_batched_tokens

    def test_repr(self, scheduler):
        """Test string representation."""
        repr_str = repr(scheduler)

        assert "Scheduler" in repr_str
        assert "waiting=" in repr_str
        assert "running=" in repr_str
