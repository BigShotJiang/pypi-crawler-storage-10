# SPDX-License-Identifier: Apache-2.0
"""Tests for request queue implementations."""

from __future__ import annotations

import pytest

from mlxllm.core.sched.request_queue import (
    FCFSQueue,
    PriorityQueue,
    RequestQueue,
    SJFQueue,
    create_request_queue,
)
from mlxllm.sequence import Sequence, SequenceGroup
from mlxllm.sampling_params import SamplingParams


@pytest.fixture
def create_seq_group():
    """Factory for creating sequence groups."""
    def _create(request_id: str, priority: int = 0, max_tokens: int = 100, arrival_time: float = 0.0):
        seq = Sequence(
            seq_id=f"seq_{request_id}",
            prompt=f"prompt {request_id}",
            prompt_token_ids=[1, 2, 3, 4, 5],
        )
        seq.priority = priority

        sampling_params = SamplingParams(max_tokens=max_tokens)

        return SequenceGroup(
            request_id=request_id,
            sequences=[seq],
            sampling_params=sampling_params,
            arrival_time=arrival_time,
        )

    return _create


@pytest.mark.unit
class TestRequestQueue:
    """Tests for abstract RequestQueue."""

    def test_queue_is_abstract(self):
        """Test that RequestQueue is abstract."""
        with pytest.raises(TypeError):
            RequestQueue()


@pytest.mark.unit
class TestFCFSQueue:
    """Tests for FCFS (First-Come-First-Served) queue."""

    def test_creation(self):
        """Test creating an FCFS queue."""
        queue = FCFSQueue()
        assert len(queue) == 0
        assert queue.is_empty()

    def test_push_pop(self, create_seq_group):
        """Test push and pop operations."""
        queue = FCFSQueue()

        sg1 = create_seq_group("req_1")
        sg2 = create_seq_group("req_2")

        queue.push(sg1)
        queue.push(sg2)

        assert len(queue) == 2
        assert not queue.is_empty()

        # FCFS should return in order
        first = queue.pop()
        assert first.request_id == "req_1"

        second = queue.pop()
        assert second.request_id == "req_2"

        assert len(queue) == 0
        assert queue.is_empty()

    def test_pop_empty_queue(self):
        """Test popping from empty queue."""
        queue = FCFSQueue()
        result = queue.pop()
        assert result is None

    def test_contains(self, create_seq_group):
        """Test __contains__ operator."""
        queue = FCFSQueue()
        sg = create_seq_group("req_1")

        assert "req_1" not in queue

        queue.push(sg)
        assert "req_1" in queue

        queue.pop()
        assert "req_1" not in queue

    def test_remove(self, create_seq_group):
        """Test removing specific request."""
        queue = FCFSQueue()

        sg1 = create_seq_group("req_1")
        sg2 = create_seq_group("req_2")
        sg3 = create_seq_group("req_3")

        queue.push(sg1)
        queue.push(sg2)
        queue.push(sg3)

        assert len(queue) == 3

        # Remove middle element
        result = queue.remove("req_2")
        assert result is True
        assert len(queue) == 2
        assert "req_2" not in queue

        # Verify order is maintained
        assert queue.pop().request_id == "req_1"
        assert queue.pop().request_id == "req_3"

    def test_remove_nonexistent(self, create_seq_group):
        """Test removing nonexistent request."""
        queue = FCFSQueue()
        sg = create_seq_group("req_1")
        queue.push(sg)

        result = queue.remove("req_999")
        assert result is False
        assert len(queue) == 1

    def test_iter(self, create_seq_group):
        """Test iterating over queue."""
        queue = FCFSQueue()

        for i in range(3):
            queue.push(create_seq_group(f"req_{i}"))

        request_ids = [sg.request_id for sg in queue]
        assert request_ids == ["req_0", "req_1", "req_2"]


@pytest.mark.unit
class TestPriorityQueue:
    """Tests for priority-based queue."""

    def test_creation(self):
        """Test creating a priority queue."""
        queue = PriorityQueue()
        assert len(queue) == 0
        assert queue.is_empty()

    def test_priority_ordering(self, create_seq_group):
        """Test that higher priority items come first."""
        queue = PriorityQueue()

        # Add in random priority order
        sg_low = create_seq_group("req_low", priority=1)
        sg_high = create_seq_group("req_high", priority=10)
        sg_mid = create_seq_group("req_mid", priority=5)

        queue.push(sg_low)
        queue.push(sg_high)
        queue.push(sg_mid)

        # Should pop in priority order (high to low)
        assert queue.pop().request_id == "req_high"
        assert queue.pop().request_id == "req_mid"
        assert queue.pop().request_id == "req_low"

    def test_priority_with_arrival_time(self, create_seq_group):
        """Test that arrival time is used as tiebreaker."""
        queue = PriorityQueue()

        # Same priority, different arrival times
        sg1 = create_seq_group("req_1", priority=5, arrival_time=1.0)
        sg2 = create_seq_group("req_2", priority=5, arrival_time=0.5)
        sg3 = create_seq_group("req_3", priority=5, arrival_time=2.0)

        queue.push(sg1)
        queue.push(sg2)
        queue.push(sg3)

        # Should pop in arrival order when priority is same
        assert queue.pop().request_id == "req_2"  # Earliest arrival
        assert queue.pop().request_id == "req_1"
        assert queue.pop().request_id == "req_3"  # Latest arrival

    def test_remove(self, create_seq_group):
        """Test removing from priority queue."""
        queue = PriorityQueue()

        for i in range(5):
            queue.push(create_seq_group(f"req_{i}", priority=i))

        assert len(queue) == 5

        result = queue.remove("req_2")
        assert result is True
        assert len(queue) == 4
        assert "req_2" not in queue

    def test_contains(self, create_seq_group):
        """Test membership checking."""
        queue = PriorityQueue()
        sg = create_seq_group("req_1", priority=5)

        assert "req_1" not in queue
        queue.push(sg)
        assert "req_1" in queue

    def test_iter(self, create_seq_group):
        """Test iterating over priority queue."""
        queue = PriorityQueue()

        for i in range(3):
            queue.push(create_seq_group(f"req_{i}", priority=i))

        # Iteration order is not guaranteed to be priority order
        request_ids = {sg.request_id for sg in queue}
        assert request_ids == {"req_0", "req_1", "req_2"}


@pytest.mark.unit
class TestSJFQueue:
    """Tests for Shortest-Job-First queue."""

    def test_creation(self):
        """Test creating an SJF queue."""
        queue = SJFQueue()
        assert len(queue) == 0
        assert queue.is_empty()

    def test_sjf_ordering(self, create_seq_group):
        """Test that shortest jobs come first."""
        queue = SJFQueue()

        # Add with different max_tokens (job lengths)
        sg_long = create_seq_group("req_long", max_tokens=200)
        sg_short = create_seq_group("req_short", max_tokens=50)
        sg_medium = create_seq_group("req_medium", max_tokens=100)

        queue.push(sg_long)
        queue.push(sg_short)
        queue.push(sg_medium)

        # Should pop shortest first
        assert queue.pop().request_id == "req_short"
        assert queue.pop().request_id == "req_medium"
        assert queue.pop().request_id == "req_long"

    def test_sjf_with_arrival_time(self, create_seq_group):
        """Test that arrival time is used as tiebreaker."""
        queue = SJFQueue()

        # Same max_tokens, different arrival times
        sg1 = create_seq_group("req_1", max_tokens=100, arrival_time=1.0)
        sg2 = create_seq_group("req_2", max_tokens=100, arrival_time=0.5)
        sg3 = create_seq_group("req_3", max_tokens=100, arrival_time=2.0)

        queue.push(sg1)
        queue.push(sg2)
        queue.push(sg3)

        # Should pop in arrival order when length is same
        assert queue.pop().request_id == "req_2"
        assert queue.pop().request_id == "req_1"
        assert queue.pop().request_id == "req_3"

    def test_default_estimate(self, create_seq_group):
        """Test default estimate when max_tokens is not set."""
        queue = SJFQueue()

        # Create sequence group without max_tokens
        seq = Sequence(
            seq_id="seq_1",
            prompt="test",
            prompt_token_ids=[1, 2, 3],
        )
        sg = SequenceGroup(
            request_id="req_1",
            sequences=[seq],
            sampling_params=None,  # No sampling params
            arrival_time=0.0,
        )

        queue.push(sg)
        assert len(queue) == 1

        result = queue.pop()
        assert result.request_id == "req_1"

    def test_remove(self, create_seq_group):
        """Test removing from SJF queue."""
        queue = SJFQueue()

        for i in range(5):
            queue.push(create_seq_group(f"req_{i}", max_tokens=(i + 1) * 50))

        assert len(queue) == 5

        result = queue.remove("req_2")
        assert result is True
        assert len(queue) == 4

    def test_contains(self, create_seq_group):
        """Test membership checking."""
        queue = SJFQueue()
        sg = create_seq_group("req_1", max_tokens=100)

        assert "req_1" not in queue
        queue.push(sg)
        assert "req_1" in queue

    def test_iter(self, create_seq_group):
        """Test iterating over SJF queue."""
        queue = SJFQueue()

        for i in range(3):
            queue.push(create_seq_group(f"req_{i}", max_tokens=(i + 1) * 50))

        request_ids = {sg.request_id for sg in queue}
        assert request_ids == {"req_0", "req_1", "req_2"}


@pytest.mark.unit
class TestCreateRequestQueue:
    """Tests for request queue factory function."""

    def test_create_fcfs(self):
        """Test creating FCFS queue."""
        queue = create_request_queue("fcfs")
        assert isinstance(queue, FCFSQueue)

    def test_create_priority(self):
        """Test creating priority queue."""
        queue = create_request_queue("priority")
        assert isinstance(queue, PriorityQueue)

    def test_create_sjf(self):
        """Test creating SJF queue."""
        queue = create_request_queue("sjf")
        assert isinstance(queue, SJFQueue)

    def test_case_insensitive(self):
        """Test that policy names are case-insensitive."""
        queue = create_request_queue("FCFS")
        assert isinstance(queue, FCFSQueue)

        queue = create_request_queue("Priority")
        assert isinstance(queue, PriorityQueue)

        queue = create_request_queue("SJF")
        assert isinstance(queue, SJFQueue)

    def test_invalid_policy(self):
        """Test that invalid policy raises ValueError."""
        with pytest.raises(ValueError) as exc_info:
            create_request_queue("invalid")

        assert "Unknown scheduling policy" in str(exc_info.value)
        assert "invalid" in str(exc_info.value)
