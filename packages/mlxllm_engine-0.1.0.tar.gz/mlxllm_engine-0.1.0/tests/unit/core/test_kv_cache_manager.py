# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache manager."""

from __future__ import annotations

import pytest

from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.config import KVCacheConfig, ModelConfig, ModelType
from mlxllm.sequence import Sequence


@pytest.fixture
def cache_config():
    """Create cache config."""
    return KVCacheConfig(
        block_size=16,
        num_gpu_blocks=10,
        enable_prefix_caching=False,
    )


@pytest.fixture
def model_config():
    """Create model config."""
    return ModelConfig(
        model_type=ModelType.LLAMA,
        model_name="test-model",
        num_layers=2,
        num_attention_heads=8,
        num_kv_heads=8,
        head_dim=64,
        hidden_size=512,
        vocab_size=1000,
        max_position_embeddings=2048,
        dtype="bfloat16",
    )


@pytest.mark.unit
class TestKVCacheManager:
    """Tests for KVCacheManager."""

    def test_creation(self, cache_config, model_config):
        """Test creating cache manager."""
        manager = KVCacheManager(cache_config, model_config)

        assert manager.cache_config == cache_config
        assert manager.model_config == model_config
        assert manager.gpu_pool is not None
        assert manager.gpu_pool.num_blocks == 10

    def test_can_allocate(self, cache_config, model_config):
        """Test checking if we can allocate blocks."""
        manager = KVCacheManager(cache_config, model_config)

        assert manager.can_allocate(5) is True
        assert manager.can_allocate(10) is True
        assert manager.can_allocate(11) is False

    def test_allocate_single_block(self, cache_config, model_config):
        """Test allocating a single block."""
        manager = KVCacheManager(cache_config, model_config)

        block_id = manager.allocate()

        assert block_id is not None
        assert manager.get_num_free_blocks() == 9

    def test_allocate_oom(self, cache_config, model_config):
        """Test allocation when out of memory."""
        manager = KVCacheManager(cache_config, model_config)

        # Allocate all blocks
        for _ in range(10):
            manager.allocate()

        # Next allocation should fail
        block_id = manager.allocate()
        assert block_id is None

    def test_free_block(self, cache_config, model_config):
        """Test freeing a block."""
        manager = KVCacheManager(cache_config, model_config)

        block_id = manager.allocate()
        assert manager.get_num_free_blocks() == 9

        manager.free(block_id)
        assert manager.get_num_free_blocks() == 10

    def test_allocate_sequence(self, cache_config, model_config):
        """Test allocating blocks for a sequence."""
        manager = KVCacheManager(cache_config, model_config)

        seq = Sequence(
            seq_id="seq_1",
            prompt="test",
            prompt_token_ids=[1, 2, 3, 4, 5],
        )

        success = manager.allocate_sequence(seq)

        assert success is True
        assert len(manager.seq_to_blocks["seq_1"]) == 1
        assert manager.get_num_free_blocks() == 9

    def test_allocate_sequence_oom(self, cache_config, model_config):
        """Test sequence allocation when OOM."""
        manager = KVCacheManager(cache_config, model_config)

        # Allocate all blocks
        for _ in range(10):
            manager.allocate()

        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1, 2, 3])

        success = manager.allocate_sequence(seq)

        assert success is False

    def test_append_token_slots(self, cache_config, model_config):
        """Test appending token slots."""
        manager = KVCacheManager(cache_config, model_config)

        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)

        manager.allocate_sequence(seq)
        assert len(manager.seq_to_blocks["seq_1"]) == 1

        # Add more tokens (needs another block)
        seq.data.output_token_ids = [1] * 16
        success = manager.append_token_slots(seq)

        assert success is True
        assert len(manager.seq_to_blocks["seq_1"]) == 2

    def test_free_sequence(self, cache_config, model_config):
        """Test freeing a sequence."""
        manager = KVCacheManager(cache_config, model_config)

        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        manager.allocate_sequence(seq)

        assert manager.get_num_free_blocks() == 9

        manager.free_sequence(seq)

        assert "seq_1" not in manager.seq_to_blocks
        assert manager.get_num_free_blocks() == 10

    def test_get_utilization(self, cache_config, model_config):
        """Test getting utilization."""
        manager = KVCacheManager(cache_config, model_config)

        assert manager.get_utilization() == 0.0

        # Allocate 5 blocks
        for _ in range(5):
            manager.allocate()

        assert manager.get_utilization() == 0.5

    def test_reset(self, cache_config, model_config):
        """Test resetting cache manager."""
        manager = KVCacheManager(cache_config, model_config)

        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        manager.allocate_sequence(seq)

        manager.reset()

        assert manager.get_num_free_blocks() == 10
        assert len(manager.seq_to_blocks) == 0
