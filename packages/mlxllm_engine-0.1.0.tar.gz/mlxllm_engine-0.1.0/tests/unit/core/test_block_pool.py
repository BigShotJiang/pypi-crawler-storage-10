# SPDX-License-Identifier: Apache-2.0
"""Tests for block pool."""

from __future__ import annotations

import pytest

from mlxllm.core.block_pool import Block, BlockPool


@pytest.mark.unit
class TestBlock:
    """Tests for Block class."""

    def test_creation(self):
        """Test creating a block."""
        block = Block(block_id=0, block_size=16, device="metal")

        assert block.block_id == 0
        assert block.block_size == 16
        assert block.device == "metal"
        assert block.ref_count == 0
        assert block.data is None
        assert block.kv_data is None

    def test_increment_ref(self):
        """Test incrementing reference count."""
        block = Block(block_id=0, block_size=16)

        block.increment_ref()
        assert block.ref_count == 1

        block.increment_ref()
        assert block.ref_count == 2

    def test_decrement_ref(self):
        """Test decrementing reference count."""
        block = Block(block_id=0, block_size=16)

        block.increment_ref()
        block.increment_ref()
        assert block.ref_count == 2

        new_count = block.decrement_ref()
        assert new_count == 1
        assert block.ref_count == 1

        new_count = block.decrement_ref()
        assert new_count == 0
        assert block.ref_count == 0

    def test_decrement_ref_min_zero(self):
        """Test that ref count doesn't go negative."""
        block = Block(block_id=0, block_size=16)

        new_count = block.decrement_ref()
        assert new_count == 0
        assert block.ref_count == 0

    def test_is_free(self):
        """Test is_free property."""
        block = Block(block_id=0, block_size=16)

        assert block.is_free is True

        block.increment_ref()
        assert block.is_free is False

        block.decrement_ref()
        assert block.is_free is True

    def test_free(self):
        """Test freeing a block."""
        block = Block(block_id=0, block_size=16)
        block.increment_ref()
        block.data = "some_data"
        block.kv_data = "some_kv_data"

        block.free()

        assert block.data is None
        assert block.kv_data is None
        assert block.ref_count == 0

    def test_repr(self):
        """Test string representation."""
        block = Block(block_id=5, block_size=16, device="metal")
        block.increment_ref()

        repr_str = repr(block)
        assert "Block" in repr_str
        assert "id=5" in repr_str
        assert "refs=1" in repr_str
        assert "device=metal" in repr_str


@pytest.mark.unit
class TestBlockPool:
    """Tests for BlockPool class."""

    def test_creation(self):
        """Test creating a block pool."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
            dtype="bfloat16",
            device="metal",
        )

        assert pool.num_blocks == 10
        assert pool.block_size == 16
        assert pool.num_layers == 32
        assert pool.num_kv_heads == 8
        assert pool.head_dim == 128
        assert pool.dtype == "bfloat16"
        assert pool.device == "metal"

        assert len(pool.blocks) == 10
        assert pool.num_free_blocks == 10
        assert pool.num_allocated_blocks == 0

    def test_allocate_block(self):
        """Test allocating a block."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.allocate_block()

        assert block is not None
        assert block.ref_count == 1
        assert pool.num_free_blocks == 9
        assert pool.num_allocated_blocks == 1

    def test_allocate_multiple_blocks(self):
        """Test allocating multiple blocks."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        blocks = []
        for _ in range(3):
            block = pool.allocate_block()
            assert block is not None
            blocks.append(block)

        assert pool.num_free_blocks == 2
        assert pool.num_allocated_blocks == 3

    def test_allocate_all_blocks(self):
        """Test allocating all blocks."""
        pool = BlockPool(
            num_blocks=3,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        for _ in range(3):
            block = pool.allocate_block()
            assert block is not None

        # Try to allocate one more (should fail)
        block = pool.allocate_block()
        assert block is None
        assert pool.num_free_blocks == 0

    def test_free_block(self):
        """Test freeing a block."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.allocate_block()
        assert pool.num_free_blocks == 4

        pool.free_block(block)
        assert pool.num_free_blocks == 5
        assert block.ref_count == 0

    def test_share_block(self):
        """Test sharing a block."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.allocate_block()
        assert block.ref_count == 1

        pool.share_block(block)
        assert block.ref_count == 2

        # Free once
        pool.free_block(block)
        assert block.ref_count == 1
        assert pool.num_free_blocks == 4  # Still allocated

        # Free again
        pool.free_block(block)
        assert block.ref_count == 0
        assert pool.num_free_blocks == 5  # Now free

    def test_get_block(self):
        """Test getting block by ID."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.get_block(2)
        assert block.block_id == 2

    def test_get_block_by_id(self):
        """Test getting block by ID with bounds checking."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.get_block_by_id(2)
        assert block is not None
        assert block.block_id == 2

        # Out of bounds
        block = pool.get_block_by_id(10)
        assert block is None

        block = pool.get_block_by_id(-1)
        assert block is None

    def test_free_block_by_id(self):
        """Test freeing block by ID."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        block = pool.allocate_block()
        block_id = block.block_id
        assert pool.num_free_blocks == 4

        pool.free_block_by_id(block_id)
        assert pool.num_free_blocks == 5

    def test_utilization(self):
        """Test pool utilization calculation."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        assert pool.utilization == 0.0

        for _ in range(5):
            pool.allocate_block()

        assert pool.utilization == 0.5

        for _ in range(5):
            pool.allocate_block()

        assert pool.utilization == 1.0

    def test_prefix_caching(self):
        """Test prefix caching functionality."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        # Allocate and cache a block
        block = pool.allocate_block()
        prefix_hash = 12345

        pool.cache_block(prefix_hash, block)

        # Retrieve cached block
        cached_block = pool.get_cached_block(prefix_hash)
        assert cached_block is not None
        assert cached_block.block_id == block.block_id
        # Should increment ref count
        assert cached_block.ref_count == 2

    def test_prefix_cache_miss(self):
        """Test cache miss."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        cached_block = pool.get_cached_block(99999)
        assert cached_block is None

    def test_reset(self):
        """Test resetting the pool."""
        pool = BlockPool(
            num_blocks=5,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        # Allocate and cache some blocks
        block1 = pool.allocate_block()
        block2 = pool.allocate_block()
        pool.cache_block(123, block1)

        assert pool.num_free_blocks == 3

        # Reset
        pool.reset()

        assert pool.num_free_blocks == 5
        assert pool.num_allocated_blocks == 0
        assert len(pool.prefix_hash_to_block) == 0

    def test_repr(self):
        """Test string representation."""
        pool = BlockPool(
            num_blocks=10,
            block_size=16,
            num_layers=2,
            num_kv_heads=2,
            head_dim=64,
        )

        pool.allocate_block()
        pool.allocate_block()

        repr_str = repr(pool)
        assert "BlockPool" in repr_str
        assert "total=10" in repr_str
        assert "free=8" in repr_str
        assert "allocated=2" in repr_str
