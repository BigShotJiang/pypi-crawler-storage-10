# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache coordinator."""

from __future__ import annotations

import pytest
from unittest.mock import Mock

from mlxllm.core.kv_cache_coordinator import KVCacheCoordinator
from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.config import KVCacheConfig, ModelConfig, ModelType


@pytest.fixture
def cache_config():
    """Create cache config."""
    return KVCacheConfig(
        block_size=16,
        num_gpu_blocks=10,
    )


@pytest.fixture
def model_config():
    """Create model config."""
    return ModelConfig(
        model_type=ModelType.LLAMA,
        model_name="test-model",
        num_layers=2,
        num_attention_heads=8,
        num_kv_heads=8,
        head_dim=64,
        hidden_size=512,
        vocab_size=1000,
        max_position_embeddings=2048,
        dtype="bfloat16",
    )


@pytest.fixture
def cache_manager(cache_config, model_config):
    """Create cache manager."""
    return KVCacheManager(cache_config, model_config)


@pytest.mark.unit
class TestKVCacheCoordinator:
    """Tests for KVCacheCoordinator."""

    def test_creation_without_offload(self, cache_manager):
        """Test creating coordinator without offloading."""
        coordinator = KVCacheCoordinator(cache_manager)

        assert coordinator.cache_manager == cache_manager
        assert coordinator.offloading_enabled is False
        assert len(coordinator.offloaded_blocks) == 0

    def test_creation_with_offload(self, cache_manager):
        """Test creating coordinator with offloading."""
        mock_backend = Mock()
        mock_manager = Mock()

        coordinator = KVCacheCoordinator(
            cache_manager,
            offload_backend=mock_backend,
            offload_manager=mock_manager,
        )

        assert coordinator.offloading_enabled is True

    def test_should_offload_disabled(self, cache_manager):
        """Test should_offload when offloading is disabled."""
        coordinator = KVCacheCoordinator(cache_manager)

        assert coordinator.should_offload() is False

    def test_should_offload_enabled(self, cache_manager):
        """Test should_offload when offloading is enabled."""
        mock_backend = Mock()
        mock_manager = Mock()
        mock_manager.should_offload.return_value = True

        coordinator = KVCacheCoordinator(
            cache_manager,
            offload_backend=mock_backend,
            offload_manager=mock_manager,
        )

        result = coordinator.should_offload()

        assert result is True
        mock_manager.should_offload.assert_called_once()

    def test_offload_blocks_disabled(self, cache_manager):
        """Test offloading when disabled."""
        coordinator = KVCacheCoordinator(cache_manager)

        num_offloaded = coordinator.offload_blocks(3)

        assert num_offloaded == 0

    def test_clear_offloaded_blocks(self, cache_manager):
        """Test clearing offloaded blocks."""
        mock_backend = Mock()
        mock_manager = Mock()

        coordinator = KVCacheCoordinator(
            cache_manager,
            offload_backend=mock_backend,
            offload_manager=mock_manager,
        )

        coordinator.offloaded_blocks.add(0)
        coordinator.offloaded_blocks.add(1)

        coordinator.clear_offloaded_blocks()

        assert len(coordinator.offloaded_blocks) == 0
        mock_backend.clear.assert_called_once()

    def test_get_offload_stats_disabled(self, cache_manager):
        """Test getting stats when offloading is disabled."""
        coordinator = KVCacheCoordinator(cache_manager)

        stats = coordinator.get_offload_stats()

        assert stats["enabled"] is False

    def test_get_offload_stats_enabled(self, cache_manager):
        """Test getting stats when offloading is enabled."""
        mock_backend = Mock()
        mock_manager = Mock()

        mock_stats = Mock()
        mock_stats.num_offloaded_blocks = 5
        mock_stats.num_loaded_blocks = 3
        mock_stats.bytes_offloaded = 1000
        mock_stats.bytes_loaded = 500
        mock_stats.offload_time_ms = 10.0
        mock_stats.load_time_ms = 8.0
        mock_stats.avg_offload_bandwidth_gbps = 1.5
        mock_stats.avg_load_bandwidth_gbps = 2.0

        mock_backend.get_stats.return_value = mock_stats
        mock_backend.get_memory_usage.return_value = 2048

        coordinator = KVCacheCoordinator(
            cache_manager,
            offload_backend=mock_backend,
            offload_manager=mock_manager,
        )

        stats = coordinator.get_offload_stats()

        assert stats["enabled"] is True
        assert stats["total_offloaded"] == 5
        assert stats["cpu_memory_usage_bytes"] == 2048

    def test_repr_without_offload(self, cache_manager):
        """Test string representation without offloading."""
        coordinator = KVCacheCoordinator(cache_manager)

        repr_str = repr(coordinator)

        assert "KVCacheCoordinator" in repr_str
        assert "offloading=disabled" in repr_str

    def test_repr_with_offload(self, cache_manager):
        """Test string representation with offloading."""
        mock_backend = Mock()
        mock_backend.__class__.__name__ = "MockBackend"
        mock_manager = Mock()
        mock_manager.__class__.__name__ = "MockManager"

        coordinator = KVCacheCoordinator(
            cache_manager,
            offload_backend=mock_backend,
            offload_manager=mock_manager,
        )

        repr_str = repr(coordinator)

        assert "KVCacheCoordinator" in repr_str
        assert "offloading=enabled" in repr_str
        assert "MockBackend" in repr_str
        assert "MockManager" in repr_str
