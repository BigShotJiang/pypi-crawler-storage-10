# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache utilities."""

from __future__ import annotations

import pytest

from mlxllm.core.kv_cache_utils import (
    BlockHasher,
    calculate_num_blocks,
    compute_kv_cache_memory,
    compute_num_blocks_from_memory,
    format_memory_size,
    get_block_hashes,
    get_block_token_range,
    hash_block_tokens,
    hash_tokens,
)


@pytest.mark.unit
class TestHashTokens:
    """Tests for hash_tokens function."""

    def test_hash_same_tokens(self):
        """Test that same tokens produce same hash."""
        tokens = [1, 2, 3, 4, 5]

        hash1 = hash_tokens(tokens)
        hash2 = hash_tokens(tokens)

        assert hash1 == hash2

    def test_hash_different_tokens(self):
        """Test that different tokens produce different hashes."""
        tokens1 = [1, 2, 3, 4, 5]
        tokens2 = [5, 4, 3, 2, 1]

        hash1 = hash_tokens(tokens1)
        hash2 = hash_tokens(tokens2)

        assert hash1 != hash2

    def test_hash_order_matters(self):
        """Test that token order affects hash."""
        tokens1 = [1, 2, 3]
        tokens2 = [3, 2, 1]

        assert hash_tokens(tokens1) != hash_tokens(tokens2)

    def test_hash_empty_tokens(self):
        """Test hashing empty token list."""
        tokens = []
        hash_val = hash_tokens(tokens)
        assert isinstance(hash_val, int)

    def test_hash_single_token(self):
        """Test hashing single token."""
        tokens = [42]
        hash_val = hash_tokens(tokens)
        assert isinstance(hash_val, int)


@pytest.mark.unit
class TestHashBlockTokens:
    """Tests for hash_block_tokens function."""

    def test_hash_first_block(self):
        """Test hashing first block."""
        tokens = list(range(32))  # 32 tokens
        block_size = 16

        hash_val = hash_block_tokens(tokens, block_size, block_idx=0)
        expected = hash_tokens(tokens[0:16])

        assert hash_val == expected

    def test_hash_second_block(self):
        """Test hashing second block."""
        tokens = list(range(32))
        block_size = 16

        hash_val = hash_block_tokens(tokens, block_size, block_idx=1)
        expected = hash_tokens(tokens[16:32])

        assert hash_val == expected

    def test_hash_partial_block(self):
        """Test hashing partial block at end."""
        tokens = list(range(25))  # Not a multiple of block_size
        block_size = 16

        hash_val = hash_block_tokens(tokens, block_size, block_idx=1)
        expected = hash_tokens(tokens[16:25])

        assert hash_val == expected

    def test_different_blocks_different_hashes(self):
        """Test that different blocks have different hashes."""
        tokens = list(range(32))
        block_size = 16

        hash0 = hash_block_tokens(tokens, block_size, block_idx=0)
        hash1 = hash_block_tokens(tokens, block_size, block_idx=1)

        assert hash0 != hash1


@pytest.mark.unit
class TestCalculateNumBlocks:
    """Tests for calculate_num_blocks function."""

    def test_exact_fit(self):
        """Test when sequence length is exact multiple of block size."""
        assert calculate_num_blocks(16, 16) == 1
        assert calculate_num_blocks(32, 16) == 2
        assert calculate_num_blocks(48, 16) == 3

    def test_partial_block(self):
        """Test when sequence needs partial block."""
        assert calculate_num_blocks(17, 16) == 2
        assert calculate_num_blocks(25, 16) == 2
        assert calculate_num_blocks(31, 16) == 2
        assert calculate_num_blocks(33, 16) == 3

    def test_empty_sequence(self):
        """Test with empty sequence."""
        assert calculate_num_blocks(0, 16) == 0

    def test_single_token(self):
        """Test with single token."""
        assert calculate_num_blocks(1, 16) == 1

    def test_different_block_sizes(self):
        """Test with different block sizes."""
        seq_len = 100

        assert calculate_num_blocks(seq_len, 10) == 10
        assert calculate_num_blocks(seq_len, 16) == 7
        assert calculate_num_blocks(seq_len, 32) == 4


@pytest.mark.unit
class TestGetBlockTokenRange:
    """Tests for get_block_token_range function."""

    def test_first_block(self):
        """Test token range for first block."""
        start, end = get_block_token_range(block_idx=0, block_size=16, seq_len=32)
        assert start == 0
        assert end == 16

    def test_second_block(self):
        """Test token range for second block."""
        start, end = get_block_token_range(block_idx=1, block_size=16, seq_len=32)
        assert start == 16
        assert end == 32

    def test_partial_last_block(self):
        """Test token range for partial last block."""
        start, end = get_block_token_range(block_idx=1, block_size=16, seq_len=25)
        assert start == 16
        assert end == 25

    def test_full_last_block(self):
        """Test token range when last block is full."""
        start, end = get_block_token_range(block_idx=1, block_size=16, seq_len=32)
        assert start == 16
        assert end == 32


@pytest.mark.unit
class TestComputeKVCacheMemory:
    """Tests for compute_kv_cache_memory function."""

    def test_basic_computation(self):
        """Test basic memory computation."""
        memory = compute_kv_cache_memory(
            num_blocks=10,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
            dtype_bytes=2,
        )

        # 10 blocks * 16 tokens/block * 32 layers * 8 heads * 128 dim * 2 (K+V) * 2 bytes
        expected = 10 * 16 * 32 * 8 * 128 * 2 * 2
        assert memory == expected

    def test_fp16_vs_fp32(self):
        """Test memory difference between fp16 and fp32."""
        config = {
            "num_blocks": 10,
            "block_size": 16,
            "num_layers": 32,
            "num_kv_heads": 8,
            "head_dim": 128,
        }

        memory_fp16 = compute_kv_cache_memory(**config, dtype_bytes=2)
        memory_fp32 = compute_kv_cache_memory(**config, dtype_bytes=4)

        assert memory_fp32 == memory_fp16 * 2

    def test_zero_blocks(self):
        """Test with zero blocks."""
        memory = compute_kv_cache_memory(
            num_blocks=0,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
        )
        assert memory == 0


@pytest.mark.unit
class TestComputeNumBlocksFromMemory:
    """Tests for compute_num_blocks_from_memory function."""

    def test_basic_computation(self):
        """Test basic computation from memory."""
        # 1 GB of memory
        memory_bytes = 1024 * 1024 * 1024

        num_blocks = compute_num_blocks_from_memory(
            memory_bytes=memory_bytes,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
            dtype_bytes=2,
        )

        # Verify by computing memory for these blocks
        actual_memory = compute_kv_cache_memory(
            num_blocks=num_blocks,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
            dtype_bytes=2,
        )

        assert actual_memory <= memory_bytes

    def test_roundtrip(self):
        """Test roundtrip computation."""
        config = {
            "block_size": 16,
            "num_layers": 32,
            "num_kv_heads": 8,
            "head_dim": 128,
            "dtype_bytes": 2,
        }

        num_blocks_orig = 100
        memory = compute_kv_cache_memory(num_blocks=num_blocks_orig, **config)

        num_blocks_computed = compute_num_blocks_from_memory(
            memory_bytes=memory,
            **config,
        )

        assert num_blocks_computed == num_blocks_orig

    def test_insufficient_memory(self):
        """Test with insufficient memory for even one block."""
        memory_bytes = 100  # Very small

        num_blocks = compute_num_blocks_from_memory(
            memory_bytes=memory_bytes,
            block_size=16,
            num_layers=32,
            num_kv_heads=8,
            head_dim=128,
            dtype_bytes=2,
        )

        assert num_blocks == 0


@pytest.mark.unit
class TestGetBlockHashes:
    """Tests for get_block_hashes function."""

    def test_single_block(self):
        """Test hashing sequence with single block."""
        tokens = list(range(16))
        block_size = 16

        hashes = get_block_hashes(tokens, block_size)

        assert len(hashes) == 1
        assert hashes[0] == hash_tokens(tokens)

    def test_multiple_blocks(self):
        """Test hashing sequence with multiple blocks."""
        tokens = list(range(32))
        block_size = 16

        hashes = get_block_hashes(tokens, block_size)

        assert len(hashes) == 2
        assert hashes[0] == hash_tokens(tokens[0:16])
        assert hashes[1] == hash_tokens(tokens[16:32])

    def test_partial_last_block(self):
        """Test hashing with partial last block."""
        tokens = list(range(25))
        block_size = 16

        hashes = get_block_hashes(tokens, block_size)

        assert len(hashes) == 2
        assert hashes[0] == hash_tokens(tokens[0:16])
        assert hashes[1] == hash_tokens(tokens[16:25])

    def test_empty_tokens(self):
        """Test hashing empty token sequence."""
        tokens = []
        block_size = 16

        hashes = get_block_hashes(tokens, block_size)
        assert len(hashes) == 0


@pytest.mark.unit
class TestBlockHasher:
    """Tests for BlockHasher class."""

    def test_creation(self):
        """Test creating a BlockHasher."""
        hasher = BlockHasher(block_size=16)
        assert hasher.block_size == 16

    def test_hash_block(self):
        """Test hashing a block."""
        hasher = BlockHasher(block_size=16)
        tokens = list(range(32))

        hash_val = hasher.hash_block(tokens, block_idx=0)
        expected = hash_tokens(tokens[0:16])

        assert hash_val == expected

    def test_caching(self):
        """Test that hashing is cached."""
        hasher = BlockHasher(block_size=16)
        tokens = list(range(32))

        # First call
        hash1 = hasher.hash_block(tokens, block_idx=0)

        # Second call should use cache
        hash2 = hasher.hash_block(tokens, block_idx=0)

        assert hash1 == hash2
        # Verify cache was used by checking it's in the cache
        assert len(hasher._cache) > 0

    def test_different_blocks_cached_separately(self):
        """Test that different blocks are cached separately."""
        hasher = BlockHasher(block_size=16)
        tokens = list(range(32))

        hash0 = hasher.hash_block(tokens, block_idx=0)
        hash1 = hasher.hash_block(tokens, block_idx=1)

        assert hash0 != hash1
        assert len(hasher._cache) == 2

    def test_clear_cache(self):
        """Test clearing the cache."""
        hasher = BlockHasher(block_size=16)
        tokens = list(range(32))

        hasher.hash_block(tokens, block_idx=0)
        assert len(hasher._cache) > 0

        hasher.clear_cache()
        assert len(hasher._cache) == 0


@pytest.mark.unit
class TestFormatMemorySize:
    """Tests for format_memory_size function."""

    def test_bytes(self):
        """Test formatting bytes."""
        assert "B" in format_memory_size(100)

    def test_kilobytes(self):
        """Test formatting kilobytes."""
        result = format_memory_size(5 * 1024)
        assert "KB" in result

    def test_megabytes(self):
        """Test formatting megabytes."""
        result = format_memory_size(10 * 1024 * 1024)
        assert "MB" in result

    def test_gigabytes(self):
        """Test formatting gigabytes."""
        result = format_memory_size(2 * 1024 * 1024 * 1024)
        assert "GB" in result

    def test_terabytes(self):
        """Test formatting terabytes."""
        result = format_memory_size(3 * 1024 * 1024 * 1024 * 1024)
        assert "TB" in result

    def test_zero(self):
        """Test formatting zero bytes."""
        result = format_memory_size(0)
        assert "0.00" in result
        assert "B" in result

    def test_negative(self):
        """Test formatting negative size."""
        result = format_memory_size(-1024)
        assert "-" in result
        assert "KB" in result
