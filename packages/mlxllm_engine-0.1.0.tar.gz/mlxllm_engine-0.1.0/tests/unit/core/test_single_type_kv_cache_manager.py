# SPDX-License-Identifier: Apache-2.0
"""Tests for single-type KV cache manager."""

from __future__ import annotations

import pytest

from mlxllm.core.single_type_kv_cache_manager import SingleTypeKVCacheManager
from mlxllm.config import KVCacheConfig, ModelConfig, ModelType
from mlxllm.sequence import Sequence


@pytest.fixture
def cache_config():
    """Create cache config."""
    return KVCacheConfig(
        block_size=16,
        num_gpu_blocks=10,
        enable_prefix_caching=False,
    )


@pytest.fixture
def model_config():
    """Create model config."""
    return ModelConfig(
        model_type=ModelType.LLAMA,
        model_name="test-model",
        num_layers=2,
        num_attention_heads=8,
        num_kv_heads=8,
        head_dim=64,
        hidden_size=512,
        vocab_size=1000,
        max_position_embeddings=2048,
        dtype="bfloat16",
    )


@pytest.mark.unit
class TestSingleTypeKVCacheManager:
    """Tests for SingleTypeKVCacheManager."""

    def test_creation(self, cache_config, model_config):
        """Test creating manager."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        assert manager.uniform_allocation is True
        assert manager.common_num_blocks is None

    def test_uniform_allocation_tracking(self, cache_config, model_config):
        """Test that uniform allocation is tracked."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        # Allocate sequences with same length
        seq1 = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        seq2 = Sequence(seq_id="seq_2", prompt="test", prompt_token_ids=[1] * 16)

        manager.allocate_sequence(seq1)
        manager.allocate_sequence(seq2)

        # Should maintain uniform allocation
        assert manager.uniform_allocation is True
        assert manager.common_num_blocks == 1

    def test_non_uniform_allocation(self, cache_config, model_config):
        """Test detection of non-uniform allocation."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        # Different lengths
        seq1 = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        seq2 = Sequence(seq_id="seq_2", prompt="test", prompt_token_ids=[1] * 32)

        manager.allocate_sequence(seq1)
        manager.allocate_sequence(seq2)

        # Should detect non-uniform allocation
        assert manager.uniform_allocation is False
        assert manager.common_num_blocks is None

    def test_can_allocate_batch(self, cache_config, model_config):
        """Test batch allocation checking."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        # 10 blocks available, need 2 blocks/seq * 3 seqs = 6 blocks
        can_alloc = manager.can_allocate_batch(num_sequences=3, seq_len=32)

        assert can_alloc is True

    def test_can_allocate_batch_insufficient(self, cache_config, model_config):
        """Test batch allocation with insufficient blocks."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        # Need too many blocks
        can_alloc = manager.can_allocate_batch(num_sequences=10, seq_len=32)

        assert can_alloc is False

    def test_get_uniform_block_count(self, cache_config, model_config):
        """Test getting uniform block count."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        # No allocation yet
        assert manager.get_uniform_block_count() is None

        # Uniform allocation
        seq1 = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        manager.allocate_sequence(seq1)

        assert manager.get_uniform_block_count() == 1

    def test_reset(self, cache_config, model_config):
        """Test resetting manager."""
        manager = SingleTypeKVCacheManager(cache_config, model_config)

        seq = Sequence(seq_id="seq_1", prompt="test", prompt_token_ids=[1] * 16)
        manager.allocate_sequence(seq)

        manager.reset()

        assert manager.uniform_allocation is True
        assert manager.common_num_blocks is None
        assert len(manager.seq_to_blocks) == 0
