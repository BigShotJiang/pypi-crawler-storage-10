"""
Tests for csrc extension bindings availability.

This test file verifies that all csrc extensions can be imported
and their availability can be checked.
"""

import pytest


def test_csrc_module_import():
    """Test that csrc module can be imported."""
    import csrc
    assert hasattr(csrc, '__version__')
    assert hasattr(csrc, 'get_extension_availability')


def test_csrc_extension_availability():
    """Test availability checking for all extensions."""
    from csrc import get_extension_availability

    availability = get_extension_availability()

    # Check that we get a dict with expected keys
    assert isinstance(availability, dict)
    expected_extensions = ['attention', 'moe', 'all2all', 'core', 'cpu', 'mamba', 'metalcutlass_extensions']

    for ext in expected_extensions:
        assert ext in availability
        assert isinstance(availability[ext], bool)


def test_attention_module_import():
    """Test that attention module can be imported."""
    try:
        from csrc import attention
        assert hasattr(attention, 'is_available')
        assert hasattr(attention, '__version__')
        assert hasattr(attention, '__backend__')
    except ImportError as e:
        pytest.skip(f"Attention extension not built: {e}")


def test_moe_module_import():
    """Test that MoE module can be imported."""
    try:
        from csrc import moe
        assert hasattr(moe, 'is_available')
        assert hasattr(moe, '__version__')
    except ImportError as e:
        pytest.skip(f"MoE extension not built: {e}")


def test_all2all_module_import():
    """Test that all2all module can be imported."""
    try:
        from csrc import all2all
        assert hasattr(all2all, 'is_available')
        assert hasattr(all2all, 'DataType')
        assert hasattr(all2all, 'CommBackend')
    except ImportError as e:
        pytest.skip(f"All2All extension not built: {e}")


def test_core_module_import():
    """Test that core module can be imported."""
    try:
        from csrc import core
        assert hasattr(core, 'is_available')
    except ImportError as e:
        pytest.skip(f"Core extension not built: {e}")


def test_cpu_module_import():
    """Test that CPU module can be imported."""
    try:
        from csrc import cpu
        assert hasattr(cpu, 'is_available')
    except ImportError as e:
        pytest.skip(f"CPU extension not built: {e}")


def test_mamba_module_import():
    """Test that Mamba module can be imported."""
    try:
        from csrc.mamba import mamba_ssm
        assert hasattr(mamba_ssm, 'is_available')
    except ImportError as e:
        pytest.skip(f"Mamba extension not built: {e}")


def test_csrc_ops_integration():
    """Test that csrc_ops integration module works."""
    try:
        from mlxllm import csrc_ops
        assert hasattr(csrc_ops, 'get_availability')
        assert hasattr(csrc_ops, 'get_available_operations')
        assert hasattr(csrc_ops, 'is_any_available')
        assert hasattr(csrc_ops, 'print_availability_report')

        # Check availability functions work
        availability = csrc_ops.get_availability()
        assert isinstance(availability, dict)

        ops = csrc_ops.get_available_operations()
        assert isinstance(ops, dict)

        # These should return booleans
        assert isinstance(csrc_ops.is_any_available(), bool)
        assert isinstance(csrc_ops.is_all_available(), bool)

    except ImportError as e:
        pytest.skip(f"csrc_ops module not available: {e}")


def test_metal_ops_facade():
    """Test that metal_ops facade module works."""
    try:
        from mlxllm import metal_ops
        assert hasattr(metal_ops, 'is_metal_available')
        assert hasattr(metal_ops, 'is_cpu_fallback_available')
        assert hasattr(metal_ops, 'get_backend')
        assert hasattr(metal_ops, 'print_backend_info')

        # Check functions work
        assert isinstance(metal_ops.is_metal_available(), bool)
        assert isinstance(metal_ops.is_cpu_fallback_available(), bool)
        assert isinstance(metal_ops.get_backend(), str)

    except ImportError as e:
        pytest.skip(f"metal_ops module not available: {e}")


def test_attention_operations_exist():
    """Test that attention operations exist when extension is available."""
    try:
        from csrc.attention import (
            paged_attention_v1,
            reshape_and_cache,
            rotary_embedding,
            rms_norm,
            silu_and_mul,
        )

        # Check they're callable
        assert callable(paged_attention_v1)
    except ImportError as e:
        pytest.skip(f"Attention extension not available: {e}")
    assert callable(reshape_and_cache)
    assert callable(rotary_embedding)
    assert callable(rms_norm)
    assert callable(silu_and_mul)


@pytest.mark.skipif(
    not hasattr(__import__('csrc.moe', fromlist=['is_available']), 'is_available') or
    not __import__('csrc.moe', fromlist=['is_available']).is_available(),
    reason="MoE extension not available"
)
def test_moe_operations_exist():
    """Test that MoE operations exist when extension is available."""
    from csrc.moe import (
        moe_topk_softmax,
        moe_permute,
        moe_unpermute,
        moe_align_block_size,
    )

    # Check they're callable
    assert callable(moe_topk_softmax)
    assert callable(moe_permute)
    assert callable(moe_unpermute)
    assert callable(moe_align_block_size)


def test_graceful_degradation():
    """Test that modules provide helpful errors when extensions aren't available."""
    # This should always pass - we want graceful degradation
    try:
        from csrc import attention

        if not attention.is_available():
            # Extension not available - operations should raise helpful errors
            import pytest
            with pytest.raises(RuntimeError, match="extension not available"):
                attention.paged_attention_v1(None, None, None, None, 0, 0.0, None, None, 0, 0)
    except ImportError:
        # Module itself not importable - that's also okay for this test
        pass
