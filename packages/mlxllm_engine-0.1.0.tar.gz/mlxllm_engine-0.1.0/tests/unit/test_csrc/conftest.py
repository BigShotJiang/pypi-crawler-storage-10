"""
Pytest configuration and fixtures for csrc tests.

Provides shared fixtures and utilities for testing C++/Metal operations.
"""

import pytest
import torch
import sys

# Register MLX-based torch.ops.mlxllm operations for testing
try:
    from .mlx_torch_bridge import register_ops
    register_ops()
except ImportError as e:
    import warnings
    warnings.warn(f"Failed to register MLX torch bridge: {e}")


# ============================================================================
# Skip markers
# ============================================================================

def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers", "requires_metal: mark test as requiring Metal/MPS backend"
    )


# ============================================================================
# Metal/MPS availability
# ============================================================================

@pytest.fixture(scope="session")
def metal_available():
    """Check if Metal/MPS backend is available."""
    return torch.backends.mps.is_available()


@pytest.fixture(scope="session", autouse=True)
def check_metal_requirements(request, metal_available):
    """Auto-skip tests marked with requires_metal if Metal not available."""
    if request.node.get_closest_marker('requires_metal'):
        if not metal_available:
            pytest.skip("Metal/MPS backend not available")


# ============================================================================
# Device fixtures
# ============================================================================

@pytest.fixture
def mps_device():
    """Return MPS device if available, otherwise skip."""
    if not torch.backends.mps.is_available():
        pytest.skip("MPS device not available")
    return torch.device('mps')


@pytest.fixture
def cpu_device():
    """Return CPU device."""
    return torch.device('cpu')


# ============================================================================
# Tensor fixtures
# ============================================================================

@pytest.fixture
def sample_tensor_2d(mps_device):
    """Create a sample 2D tensor on MPS."""
    return torch.randn(32, 128, dtype=torch.float32, device=mps_device)


@pytest.fixture
def sample_tensor_3d(mps_device):
    """Create a sample 3D tensor on MPS."""
    return torch.randn(8, 16, 64, dtype=torch.float32, device=mps_device)


@pytest.fixture
def sample_tensor_4d(mps_device):
    """Create a sample 4D tensor on MPS."""
    return torch.randn(2, 4, 8, 32, dtype=torch.float32, device=mps_device)


# ============================================================================
# Attention-related fixtures
# ============================================================================

@pytest.fixture
def attention_params():
    """Common attention parameters."""
    return {
        'num_heads': 8,
        'head_dim': 64,
        'num_kv_heads': 8,
        'block_size': 16,
        'max_seq_len': 2048,
        'scale': 1.0 / (64 ** 0.5),
    }


@pytest.fixture
def sample_query(mps_device, attention_params):
    """Create sample query tensor for attention."""
    batch_size = 4
    seq_len = 128
    return torch.randn(
        batch_size, seq_len,
        attention_params['num_heads'], attention_params['head_dim'],
        dtype=torch.float32, device=mps_device
    )


@pytest.fixture
def sample_kv_cache(mps_device, attention_params):
    """Create sample KV cache tensors."""
    num_blocks = 256
    key_cache = torch.randn(
        num_blocks, attention_params['num_kv_heads'],
        attention_params['block_size'], attention_params['head_dim'],
        dtype=torch.float32, device=mps_device
    )
    value_cache = torch.randn(
        num_blocks, attention_params['num_kv_heads'],
        attention_params['block_size'], attention_params['head_dim'],
        dtype=torch.float32, device=mps_device
    )
    return key_cache, value_cache


# ============================================================================
# MoE-related fixtures
# ============================================================================

@pytest.fixture
def moe_config():
    """Common MoE configuration."""
    return {
        'num_experts': 8,
        'topk': 2,
        'hidden_dim': 256,
        'expert_dim': 1024,
    }


@pytest.fixture
def sample_gating_logits(mps_device, moe_config):
    """Create sample gating logits for MoE."""
    num_tokens = 64
    return torch.randn(
        num_tokens, moe_config['num_experts'],
        dtype=torch.float32, device=mps_device
    )


@pytest.fixture
def sample_expert_ids(mps_device, moe_config):
    """Create sample expert ID assignments."""
    num_tokens = 64
    return torch.randint(
        0, moe_config['num_experts'],
        (num_tokens, moe_config['topk']),
        dtype=torch.int64, device=mps_device
    )


# ============================================================================
# Normalization fixtures
# ============================================================================

@pytest.fixture
def sample_norm_input(mps_device):
    """Create sample input for normalization operations."""
    return torch.randn(32, 512, dtype=torch.float32, device=mps_device)


@pytest.fixture
def sample_norm_weight(mps_device):
    """Create sample weight for normalization operations."""
    return torch.ones(512, dtype=torch.float32, device=mps_device)


# ============================================================================
# Quantization fixtures
# ============================================================================

@pytest.fixture
def quant_config():
    """Common quantization configuration."""
    return {
        'bits': 8,
        'group_size': 128,
        'symmetric': True,
    }


@pytest.fixture
def sample_quant_input(mps_device):
    """Create sample input for quantization."""
    return torch.randn(64, 256, dtype=torch.float32, device=mps_device)


# ============================================================================
# Utility functions
# ============================================================================

def check_tensor_finite(tensor):
    """Check if tensor contains only finite values."""
    return not torch.isnan(tensor).any() and not torch.isinf(tensor).any()


def get_relative_error(actual, expected):
    """Calculate relative error between two tensors."""
    return torch.abs(actual - expected) / (torch.abs(expected) + 1e-10)


@pytest.fixture
def tensor_checker():
    """Fixture providing tensor checking utilities."""
    class TensorChecker:
        @staticmethod
        def is_finite(tensor):
            return check_tensor_finite(tensor)

        @staticmethod
        def relative_error(actual, expected):
            return get_relative_error(actual, expected)

        @staticmethod
        def assert_shape(tensor, expected_shape):
            assert tensor.shape == expected_shape, \
                f"Expected shape {expected_shape}, got {tensor.shape}"

        @staticmethod
        def assert_dtype(tensor, expected_dtype):
            assert tensor.dtype == expected_dtype, \
                f"Expected dtype {expected_dtype}, got {tensor.dtype}"

        @staticmethod
        def assert_device(tensor, expected_device):
            assert tensor.device.type == expected_device.type, \
                f"Expected device {expected_device}, got {tensor.device}"

    return TensorChecker()


# ============================================================================
# Performance benchmarking
# ============================================================================

@pytest.fixture
def benchmark_runner():
    """Fixture for running performance benchmarks."""
    import time

    class BenchmarkRunner:
        def __init__(self):
            self.results = {}

        def run(self, name, func, num_iterations=100, warmup=10):
            """Run benchmark for a function."""
            # Warmup
            for _ in range(warmup):
                func()

            # Synchronize before timing (for Metal operations)
            if torch.backends.mps.is_available():
                torch.mps.synchronize()

            # Benchmark
            start_time = time.perf_counter()
            for _ in range(num_iterations):
                func()

            # Synchronize after timing
            if torch.backends.mps.is_available():
                torch.mps.synchronize()

            end_time = time.perf_counter()
            avg_time = (end_time - start_time) / num_iterations

            self.results[name] = {
                'avg_time_ms': avg_time * 1000,
                'iterations': num_iterations,
            }

            return avg_time

        def print_results(self):
            """Print benchmark results."""
            print("\n" + "="*60)
            print("Benchmark Results")
            print("="*60)
            for name, result in self.results.items():
                print(f"{name:40s}: {result['avg_time_ms']:.4f} ms")
            print("="*60)

    return BenchmarkRunner()


# ============================================================================
# Cleanup hooks
# ============================================================================

@pytest.fixture(autouse=True)
def cleanup_metal_cache():
    """Clean up Metal cache after each test."""
    yield
    if torch.backends.mps.is_available():
        torch.mps.empty_cache()


# ============================================================================
# Test data directories
# ============================================================================

@pytest.fixture(scope="session")
def test_data_dir(tmp_path_factory):
    """Create temporary directory for test data."""
    return tmp_path_factory.mktemp("test_data")


# ============================================================================
# Assertion helpers
# ============================================================================

@pytest.fixture
def assert_close():
    """Fixture for asserting tensor closeness with common tolerances."""
    def _assert_close(actual, expected, dtype=torch.float32):
        if dtype == torch.float32:
            rtol, atol = 1e-4, 1e-5
        elif dtype == torch.float16:
            rtol, atol = 1e-2, 1e-3
        else:
            rtol, atol = 1e-3, 1e-4

        torch.testing.assert_close(actual, expected, rtol=rtol, atol=atol)

    return _assert_close
