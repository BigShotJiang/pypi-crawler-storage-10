"""
Unit tests for csrc C++/Objective-C/Metal operations.

This package tests the PyTorch custom operations exposed from the csrc module,
including attention kernels, MoE operations, quantization, and Metal-accelerated
operations for Apple Silicon.
"""
