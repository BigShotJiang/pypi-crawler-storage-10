"""
Bridge module to make MLX operations available via torch.ops.mlxllm API.

This allows tests written for torch.ops.mlxllm to work with MLX implementations.
"""

import torch
import mlx.core as mx
import numpy as np


def _mx_to_torch(arr: mx.array) -> torch.Tensor:
    """Convert MLX array to PyTorch tensor on MPS."""
    # Convert through numpy as intermediate
    np_arr = np.array(arr)
    return torch.from_numpy(np_arr).to('mps')


def _torch_to_mx(tensor: torch.Tensor) -> mx.array:
    """Convert PyTorch tensor to MLX array."""
    # Move to CPU first if needed
    if tensor.device.type == 'mps':
        tensor = tensor.cpu()
    # Detach from gradient tracking if needed
    if tensor.requires_grad:
        tensor = tensor.detach()
    return mx.array(tensor.numpy())


def silu_and_mul(output: torch.Tensor, input: torch.Tensor) -> None:
    """
    SiLU activation with multiplication (SwiGLU pattern).

    Args:
        output: Output tensor [batch, d]
        input: Input tensor [batch, 2*d]
    """
    # Validate shapes
    batch_size = input.shape[0]
    hidden_dim = input.shape[1] // 2

    if output.shape != (batch_size, hidden_dim):
        raise RuntimeError(
            f"output shape must be [num_tokens, d], got {output.shape}, "
            f"expected {(batch_size, hidden_dim)}"
        )

    if input.shape[1] % 2 != 0:
        raise RuntimeError(f"input dim must be even, got {input.shape[1]}")

    # Convert to MLX
    input_mx = _torch_to_mx(input)

    # Split input into gate and up
    gate = input_mx[:, :hidden_dim]
    up = input_mx[:, hidden_dim:]

    # Apply SiLU: silu(gate) * up
    # SiLU(x) = x * sigmoid(x) = x / (1 + exp(-x))
    result = (gate * mx.sigmoid(gate)) * up

    # Convert back to torch and copy to output
    result_torch = _mx_to_torch(result)
    output.copy_(result_torch)


def gelu_and_mul(output: torch.Tensor, input: torch.Tensor) -> None:
    """
    GELU activation with multiplication.

    Args:
        output: Output tensor [batch, d]
        input: Input tensor [batch, 2*d]
    """
    batch_size = input.shape[0]
    hidden_dim = output.shape[1]  # Use output shape as source of truth

    if input.shape[1] != 2 * hidden_dim:
        raise RuntimeError(f"input shape[1] must be 2*output.shape[1], got {input.shape[1]} vs {2*hidden_dim}")

    # Convert to MLX
    input_mx = _torch_to_mx(input)

    # Split
    gate = input_mx[:, :hidden_dim]
    up = input_mx[:, hidden_dim:]

    # Apply GELU (exact): 0.5 * x * (1 + erf(x / sqrt(2)))
    gelu_gate = 0.5 * gate * (1.0 + mx.erf(gate / mx.sqrt(mx.array(2.0))))
    result = gelu_gate * up

    # Convert back
    result_torch = _mx_to_torch(result)
    output.copy_(result_torch)


def gelu_tanh_and_mul(output: torch.Tensor, input: torch.Tensor) -> None:
    """
    GELU with tanh approximation and multiplication.

    Args:
        output: Output tensor [batch, d]
        input: Input tensor [batch, 2*d]
    """
    batch_size = input.shape[0]
    hidden_dim = input.shape[1] // 2

    if output.shape != (batch_size, hidden_dim):
        raise RuntimeError(f"output shape mismatch")

    # Convert to MLX
    input_mx = _torch_to_mx(input)

    # Split
    gate = input_mx[:, :hidden_dim]
    up = input_mx[:, hidden_dim:]

    # GELU tanh approximation: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
    sqrt_2_over_pi = mx.sqrt(mx.array(2.0 / mx.pi))
    inner = sqrt_2_over_pi * (gate + 0.044715 * mx.power(gate, 3))
    gelu_gate = 0.5 * gate * (1.0 + mx.tanh(inner))
    result = gelu_gate * up

    # Convert back
    result_torch = _mx_to_torch(result)
    output.copy_(result_torch)


def mul_and_silu(output: torch.Tensor, input: torch.Tensor) -> None:
    """Mul and SiLU (alternative order) - just calls silu_and_mul."""
    silu_and_mul(output, input)


def gelu_new(output: torch.Tensor, input: torch.Tensor) -> None:
    """GELU new variant - uses tanh approximation."""
    gelu_tanh_and_mul(output, input)


def gelu_fast(output: torch.Tensor, input: torch.Tensor) -> None:
    """GELU fast approximation."""
    gelu_tanh_and_mul(output, input)


def gelu_quick(output: torch.Tensor, input: torch.Tensor) -> None:
    """GELU quick approximation."""
    gelu_tanh_and_mul(output, input)


# ============================================================================
# Stub implementations for operations not yet implemented
# ============================================================================

def _not_implemented(*args, **kwargs):
    """Placeholder for operations not yet implemented."""
    raise NotImplementedError("This operation is not yet implemented with MLX backend")


# ============================================================================
# Utility operations
# ============================================================================

def convert_fp32_to_fp16(output: torch.Tensor, input: torch.Tensor) -> None:
    """Convert FP32 to FP16."""
    output.copy_(input.to(torch.float16))


def convert_fp16_to_fp32(output: torch.Tensor, input: torch.Tensor) -> None:
    """Convert FP16 to FP32."""
    output.copy_(input.to(torch.float32))


def permute_cols(output: torch.Tensor, input: torch.Tensor, perm: torch.Tensor) -> None:
    """Permute columns of input matrix."""
    try:
        # Validate indices
        max_idx = perm.max().item() if perm.numel() > 0 else -1
        if max_idx >= input.shape[1]:
            raise RuntimeError(f"index {max_idx} is out of bounds for dimension 1 with size {input.shape[1]}")
        
        # Validate permutation length matches output
        if output.shape[1] != perm.numel():
            raise RuntimeError(f"permutation length {perm.numel()} must match output columns {output.shape[1]}")

        if input.device.type == 'mps':
            input_cpu = input.cpu()
            perm_cpu = perm.cpu()
            result = input_cpu[:, perm_cpu.long()]
            output.copy_(result.to(input.device))
        else:
            output.copy_(input[:, perm.long()])
    except IndexError as e:
        raise RuntimeError(str(e))



def metal_synchronize() -> None:
    """Synchronize Metal operations."""
    if torch.backends.mps.is_available():
        torch.mps.synchronize()


def check_finite(tensor: torch.Tensor, name: str = "tensor") -> bool:
    """Check if tensor contains only finite values."""
    has_nan = torch.isnan(tensor).any().item()
    has_inf = torch.isinf(tensor).any().item()
    return not (has_nan or has_inf)
    
    if has_nan or has_inf:
        raise ValueError(f"{name} contains NaN or Inf values")
    
    return True


def get_metal_device_info() -> str:
    """Get Metal device information."""
    if torch.backends.mps.is_available():
        return "Metal device available (MPS backend)"
    return "Metal device not available"


# Register operations in torch.ops.mlxllm namespace
def register_ops():
    """Register MLX implementations as torch.ops.mlxllm operations."""

    # Monkey-patch operations directly onto torch.ops.mlxllm
    ops_dict = {
        # Activation operations
        'silu_and_mul': silu_and_mul,
        'mul_and_silu': mul_and_silu,
        'gelu_and_mul': gelu_and_mul,
        'gelu_tanh_and_mul': gelu_tanh_and_mul,
        'gelu_new': gelu_new,
        'gelu_fast': gelu_fast,
        'gelu_quick': gelu_quick,
        # Utility operations
        'convert_fp32_to_fp16': convert_fp32_to_fp16,
        'convert_fp16_to_fp32': convert_fp16_to_fp32,
        'permute_cols': permute_cols,
        'metal_synchronize': metal_synchronize,
        'check_finite': check_finite,
        'get_metal_device_info': get_metal_device_info,
        # MoE operations (stubs)
        'moe_topk_softmax': _not_implemented,
        'moe_grouped_topk': _not_implemented,
        'moe_permute': _not_implemented,
        'moe_unpermute': _not_implemented,
        'moe_shuffle_rows': _not_implemented,
        'moe_align_block_size': _not_implemented,
        'moe_batched_align_block_size': _not_implemented,
        'moe_lora_align_block_size': _not_implemented,
        'moe_sum': _not_implemented,
        'moe_permute_unpermute_supported': lambda: True,
    }

    # Directly monkey-patch the attributes
    for name, func in ops_dict.items():
        setattr(torch.ops.mlxllm, name, func)
