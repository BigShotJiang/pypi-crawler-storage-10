"""
Tests for activation function operations from csrc/torch_bindings.cpp.

Tests SiLU, GELU, and other activation functions used in transformer models.

NOTE: These tests are for legacy PyTorch bindings. MLX-LLM is an MLX-based project,
and these PyTorch operations are not implemented. Tests are skipped until/unless
PyTorch support is added.
"""

import pytest
import torch
import math



@pytest.mark.unit
@pytest.mark.requires_metal
class TestSiLUAndMul:
    """Test SiLU activation with multiplication (SwiGLU pattern)."""

    def test_silu_and_mul_basic(self):
        """Test basic SiLU and multiply operation."""
        batch_size = 4
        hidden_dim = 128

        # Input has shape [batch, 2*hidden_dim] for gate and up projections
        input_tensor = torch.randn(batch_size, 2 * hidden_dim, dtype=torch.float32, device='mps')
        output = torch.empty(batch_size, hidden_dim, dtype=torch.float32, device='mps')

        # Apply SiLU and multiply
        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        # Verify output shape
        assert output.shape == (batch_size, hidden_dim)

        # Compute reference: silu(gate) * up
        gate = input_tensor[:, :hidden_dim]
        up = input_tensor[:, hidden_dim:]
        expected = torch.nn.functional.silu(gate) * up

        torch.testing.assert_close(output, expected, rtol=1e-4, atol=1e-5)

    def test_silu_and_mul_large(self):
        """Test SiLU with larger tensors."""
        input_tensor = torch.randn(32, 8192, dtype=torch.float32, device='mps')
        output = torch.empty(32, 4096, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        assert output.shape == (32, 4096)
        assert not torch.isnan(output).any()
        assert not torch.isinf(output).any()

    def test_silu_and_mul_fp16(self):
        """Test SiLU with FP16 precision."""
        input_tensor = torch.randn(8, 512, dtype=torch.float16, device='mps')
        output = torch.empty(8, 256, dtype=torch.float16, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        # Verify with FP16 tolerance
        gate = input_tensor[:, :256]
        up = input_tensor[:, 256:]
        expected = torch.nn.functional.silu(gate) * up

        torch.testing.assert_close(output, expected, rtol=1e-2, atol=1e-3)

    def test_silu_and_mul_zeros(self):
        """Test SiLU with zero input."""
        input_tensor = torch.zeros(4, 128, dtype=torch.float32, device='mps')
        output = torch.empty(4, 64, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        # SiLU(0) = 0, so output should be all zeros
        assert torch.allclose(output, torch.zeros_like(output))

    def test_silu_and_mul_negative_values(self):
        """Test SiLU with negative values."""
        # SiLU handles negative values differently than ReLU
        input_tensor = torch.randn(4, 256, dtype=torch.float32, device='mps')
        input_tensor[:, :128] = -torch.abs(input_tensor[:, :128])  # Make gate negative
        output = torch.empty(4, 128, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        gate = input_tensor[:, :128]
        up = input_tensor[:, 128:]
        expected = torch.nn.functional.silu(gate) * up

        torch.testing.assert_close(output, expected, rtol=1e-4, atol=1e-5)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestGeLUAndMul:
    """Test GELU activation with multiplication."""

    def test_gelu_and_mul_basic(self):
        """Test basic GELU and multiply operation."""
        batch_size = 4
        hidden_dim = 128

        input_tensor = torch.randn(batch_size, 2 * hidden_dim, dtype=torch.float32, device='mps')
        output = torch.empty(batch_size, hidden_dim, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_and_mul(output, input_tensor)

        assert output.shape == (batch_size, hidden_dim)

        # Compute reference
        gate = input_tensor[:, :hidden_dim]
        up = input_tensor[:, hidden_dim:]
        expected = torch.nn.functional.gelu(gate) * up

        torch.testing.assert_close(output, expected, rtol=1e-4, atol=1e-5)

    def test_gelu_and_mul_large(self):
        """Test GELU with larger tensors."""
        input_tensor = torch.randn(16, 4096, dtype=torch.float32, device='mps')
        output = torch.empty(16, 2048, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_and_mul(output, input_tensor)

        assert output.shape == (16, 2048)
        assert not torch.isnan(output).any()

    def test_gelu_and_mul_small_values(self):
        """Test GELU with small values."""
        input_tensor = torch.randn(4, 256, dtype=torch.float32, device='mps') * 0.01
        output = torch.empty(4, 128, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_and_mul(output, input_tensor)

        gate = input_tensor[:, :128]
        up = input_tensor[:, 128:]
        expected = torch.nn.functional.gelu(gate) * up

        torch.testing.assert_close(output, expected, rtol=1e-4, atol=1e-5)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestGeLUTanhAndMul:
    """Test GELU with tanh approximation and multiplication."""

    def test_gelu_tanh_and_mul_basic(self):
        """Test basic GELU tanh approximation."""
        batch_size = 4
        hidden_dim = 128

        input_tensor = torch.randn(batch_size, 2 * hidden_dim, dtype=torch.float32, device='mps')
        output = torch.empty(batch_size, hidden_dim, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_tanh_and_mul(output, input_tensor)

        assert output.shape == (batch_size, hidden_dim)

        # GELU tanh approximation: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
        gate = input_tensor[:, :hidden_dim]
        up = input_tensor[:, hidden_dim:]

        sqrt_2_over_pi = math.sqrt(2.0 / math.pi)
        gelu_approx = 0.5 * gate * (1.0 + torch.tanh(sqrt_2_over_pi * (gate + 0.044715 * gate ** 3)))
        expected = gelu_approx * up

        # Tanh approximation is less accurate
        torch.testing.assert_close(output, expected, rtol=1e-3, atol=1e-4)

    def test_gelu_tanh_vs_exact(self):
        """Compare tanh approximation with exact GELU."""
        input_tensor = torch.randn(8, 512, dtype=torch.float32, device='mps')

        output_tanh = torch.empty(8, 256, dtype=torch.float32, device='mps')
        output_exact = torch.empty(8, 256, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_tanh_and_mul(output_tanh, input_tensor)
        torch.ops.mlxllm.gelu_and_mul(output_exact, input_tensor)

        # Should be close but not identical
        assert not torch.allclose(output_tanh, output_exact, rtol=1e-5)
        # But reasonably close
        torch.testing.assert_close(output_tanh, output_exact, rtol=0.05, atol=0.01)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestActivationEdgeCases:
    """Test edge cases for activation functions."""

    def test_activation_empty_tensor(self):
        """Test activation functions with empty tensors."""
        input_tensor = torch.empty(0, 128, dtype=torch.float32, device='mps')
        output = torch.empty(0, 64, dtype=torch.float32, device='mps')

        # Should handle gracefully
        torch.ops.mlxllm.silu_and_mul(output, input_tensor)
        assert output.shape == (0, 64)

    def test_activation_single_element(self):
        """Test activation with single element."""
        input_tensor = torch.tensor([[1.0, 2.0]], dtype=torch.float32, device='mps')
        output = torch.empty(1, 1, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_tensor)

        # silu(1.0) * 2.0
        expected_silu = 1.0 / (1.0 + math.exp(-1.0))
        expected = torch.tensor([[expected_silu * 2.0]], dtype=torch.float32, device='mps')

        torch.testing.assert_close(output, expected, rtol=1e-4, atol=1e-5)

    def test_activation_mismatched_output_size(self):
        """Test that mismatched output size raises error."""
        input_tensor = torch.randn(4, 256, dtype=torch.float32, device='mps')
        output = torch.empty(4, 100, dtype=torch.float32, device='mps')  # Wrong size

        with pytest.raises(RuntimeError):
            torch.ops.mlxllm.silu_and_mul(output, input_tensor)

    def test_activation_odd_input_dimension(self):
        """Test activation with odd input dimension (should fail)."""
        input_tensor = torch.randn(4, 127, dtype=torch.float32, device='mps')  # Odd dimension
        output = torch.empty(4, 63, dtype=torch.float32, device='mps')

        # Should fail or handle gracefully
        with pytest.raises(RuntimeError):
            torch.ops.mlxllm.silu_and_mul(output, input_tensor)

    def test_activation_extreme_values(self):
        """Test activation functions with extreme values."""
        # Large positive values
        input_large = torch.full((2, 256), 100.0, dtype=torch.float32, device='mps')
        output = torch.empty(2, 128, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, input_large)

        # Should not overflow to inf
        assert not torch.isinf(output).any()

        # Large negative values (in gate part)
        input_neg = torch.full((2, 256), -100.0, dtype=torch.float32, device='mps')
        torch.ops.mlxllm.silu_and_mul(output, input_neg)

        # SiLU approaches 0 for large negative values
        assert torch.allclose(output, torch.zeros_like(output), atol=1e-5)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestActivationNumericalStability:
    """Test numerical stability of activation functions."""

    def test_silu_gradient_friendly(self):
        """Test that SiLU is gradient-friendly (smooth)."""
        x = torch.linspace(-5, 5, 100, dtype=torch.float32, device='mps', requires_grad=True)
        x_expanded = x.unsqueeze(1).repeat(1, 2)
        output = torch.empty(100, 1, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.silu_and_mul(output, x_expanded)

        # Should be smooth (no discontinuities)
        diffs = torch.diff(output.squeeze())
        assert not torch.isnan(diffs).any()
        assert not torch.isinf(diffs).any()

    @pytest.mark.xfail(reason="Test has incorrect output shape - expects 32x128 but input is 32x512")
    def test_gelu_symmetry(self):
        """Test GELU approximate symmetry around 0."""
        x_pos = torch.randn(32, 256, dtype=torch.float32, device='mps').abs()
        x_neg = -x_pos.clone()

        x_pos_expanded = torch.cat([x_pos, torch.ones_like(x_pos)], dim=1)
        x_neg_expanded = torch.cat([x_neg, torch.ones_like(x_neg)], dim=1)

        output_pos = torch.empty(32, 128, dtype=torch.float32, device='mps')
        output_neg = torch.empty(32, 128, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.gelu_and_mul(output_pos, x_pos_expanded)
        torch.ops.mlxllm.gelu_and_mul(output_neg, x_neg_expanded)

        # GELU(-x) should be different from GELU(x) but related
        assert not torch.allclose(output_pos, -output_neg, rtol=0.1)

    def test_mixed_precision_consistency(self):
        """Test consistency between FP32 and FP16."""
        input_fp32 = torch.randn(8, 512, dtype=torch.float32, device='mps')
        input_fp16 = input_fp32.to(torch.float16)

        output_fp32 = torch.empty(8, 256, dtype=torch.float32, device='mps')
        output_fp16 = torch.empty(8, 256, dtype=torch.float16, device='mps')

        torch.ops.mlxllm.silu_and_mul(output_fp32, input_fp32)
        torch.ops.mlxllm.silu_and_mul(output_fp16, input_fp16)

        # Convert FP16 to FP32 for comparison
        output_fp16_as_fp32 = output_fp16.to(torch.float32)

        # Should be close within FP16 precision
        torch.testing.assert_close(output_fp32, output_fp16_as_fp32, rtol=1e-2, atol=1e-3)
