"""
Tests for MoE (Mixture of Experts) operations.

Tests routing, permutation, alignment, and quantized GEMM operations for MoE layers.

NOTE: MoE operations are not yet implemented - tests are marked as xfail (expected to fail).
"""

import pytest
import torch

pytestmark = pytest.mark.xfail(reason="MoE operations not yet implemented with MLX backend", raises=NotImplementedError)



@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoERouting:
    """Test MoE expert routing operations."""

    def test_moe_topk_softmax_basic(self):
        """Test basic topk softmax routing."""
        num_tokens = 32
        num_experts = 8
        topk = 2

        # Create gating logits
        gating_output = torch.randn(num_tokens, num_experts, dtype=torch.float32, device='mps')

        # Create output tensors
        topk_weights = torch.empty(num_tokens, topk, dtype=torch.float32, device='mps')
        topk_indices = torch.empty(num_tokens, topk, dtype=torch.int64, device='mps')
        token_expert_indices = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')

        # Apply topk softmax with renormalization
        torch.ops.mlxllm.moe_topk_softmax(
            topk_weights, topk_indices, token_expert_indices, gating_output, True
        )

        # Verify shapes
        assert topk_weights.shape == (num_tokens, topk)
        assert topk_indices.shape == (num_tokens, topk)
        assert token_expert_indices.shape == (num_tokens * topk,)

        # Verify weights are normalized (sum to 1 per token)
        weight_sums = topk_weights.sum(dim=1)
        torch.testing.assert_close(weight_sums, torch.ones(num_tokens, device='mps'), rtol=1e-5, atol=1e-6)

        # Verify all weights are non-negative
        assert (topk_weights >= 0).all()

        # Verify indices are in valid range
        assert (topk_indices >= 0).all() and (topk_indices < num_experts).all()

    def test_moe_topk_softmax_without_renormalize(self):
        """Test topk softmax without renormalization."""
        num_tokens = 16
        num_experts = 4
        topk = 2

        gating_output = torch.randn(num_tokens, num_experts, dtype=torch.float32, device='mps')
        topk_weights = torch.empty(num_tokens, topk, dtype=torch.float32, device='mps')
        topk_indices = torch.empty(num_tokens, topk, dtype=torch.int64, device='mps')
        token_expert_indices = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')

        # Without renormalization
        torch.ops.mlxllm.moe_topk_softmax(
            topk_weights, topk_indices, token_expert_indices, gating_output, False
        )

        # Weights may not sum to 1
        assert (topk_weights >= 0).all()

    def test_moe_grouped_topk(self):
        """Test grouped topk routing (hierarchical routing)."""
        num_tokens = 64
        num_experts = 64
        n_group = 8
        topk_group = 2
        topk = 4

        scores = torch.randn(num_tokens, num_experts, dtype=torch.float32, device='mps')
        scores_with_bias = scores.clone()

        topk_weights, topk_indices = torch.ops.mlxllm.moe_grouped_topk(
            scores, scores_with_bias, n_group, topk_group, topk, True, 1.0
        )

        assert topk_weights.shape == (num_tokens, topk)
        assert topk_indices.shape == (num_tokens, topk)

        # Verify normalization
        weight_sums = topk_weights.sum(dim=1)
        torch.testing.assert_close(weight_sums, torch.ones(num_tokens, device='mps'), rtol=1e-5, atol=1e-6)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoEPermutation:
    """Test MoE token permutation operations."""

    def test_moe_permute_basic(self):
        """Test basic token permutation by expert."""
        num_tokens = 32
        hidden_dim = 256
        n_expert = 8
        topk = 2

        # Create inputs
        input_tensor = torch.randn(num_tokens, hidden_dim, dtype=torch.float32, device='mps')
        topk_ids = torch.randint(0, n_expert, (num_tokens, topk), dtype=torch.int64, device='mps')
        token_expert_indices = topk_ids.flatten()

        # Create outputs
        permuted_input = torch.empty(num_tokens * topk, hidden_dim, dtype=torch.float32, device='mps')
        expert_first_token_offset = torch.empty(n_expert + 1, dtype=torch.int64, device='mps')
        inv_permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        m_indices = torch.empty(n_expert, dtype=torch.int64, device='mps')

        # Permute
        torch.ops.mlxllm.moe_permute(
            input_tensor, topk_ids, token_expert_indices, None,
            n_expert, n_expert, topk, None,
            permuted_input, expert_first_token_offset,
            inv_permuted_idx, permuted_idx, m_indices
        )

        assert permuted_input.shape == (num_tokens * topk, hidden_dim)
        assert expert_first_token_offset.shape == (n_expert + 1,)

    def test_moe_unpermute_basic(self):
        """Test unpermutation of expert outputs."""
        num_tokens = 32
        hidden_dim = 256
        topk = 2

        permuted_hidden_states = torch.randn(num_tokens * topk, hidden_dim, dtype=torch.float32, device='mps')
        topk_weights = torch.rand(num_tokens, topk, dtype=torch.float32, device='mps')

        # Normalize weights
        topk_weights = topk_weights / topk_weights.sum(dim=1, keepdim=True)

        inv_permuted_idx = torch.arange(num_tokens * topk, dtype=torch.int64, device='mps')
        hidden_states = torch.empty(num_tokens, hidden_dim, dtype=torch.float32, device='mps')

        # Unpermute
        torch.ops.mlxllm.moe_unpermute(
            permuted_hidden_states, topk_weights, inv_permuted_idx, None, topk, hidden_states
        )

        assert hidden_states.shape == (num_tokens, hidden_dim)
        assert not torch.isnan(hidden_states).any()

    def test_moe_shuffle_rows(self):
        """Test row shuffling operation."""
        num_rows = 64
        num_cols = 128

        input_tensor = torch.randn(num_rows, num_cols, dtype=torch.float32, device='mps')
        dst2src_map = torch.randperm(num_rows, dtype=torch.int64, device='mps')
        output_tensor = torch.empty_like(input_tensor)

        torch.ops.mlxllm.moe_shuffle_rows(input_tensor, dst2src_map, output_tensor)

        # Verify shuffling
        for i in range(min(10, num_rows)):  # Check first 10 rows
            src_idx = dst2src_map[i].item()
            torch.testing.assert_close(output_tensor[i], input_tensor[src_idx])


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoEAlignment:
    """Test MoE block alignment operations."""

    def test_moe_align_block_size_basic(self):
        """Test basic block size alignment."""
        num_tokens = 100
        num_experts = 8
        topk = 2
        block_size = 16

        topk_ids = torch.randint(0, num_experts, (num_tokens, topk), dtype=torch.int64, device='mps')

        sorted_token_ids = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        experts_ids = torch.empty(num_experts, dtype=torch.int64, device='mps')
        num_tokens_post_pad = torch.empty(num_experts, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_align_block_size(
            topk_ids, num_experts, block_size,
            sorted_token_ids, experts_ids, num_tokens_post_pad
        )

        # Verify all counts are divisible by block_size
        assert (num_tokens_post_pad % block_size == 0).all()

        # Verify total padded tokens >= original tokens
        assert num_tokens_post_pad.sum() >= num_tokens * topk

    def test_moe_batched_align_block_size(self):
        """Test batched block size alignment."""
        max_tokens_per_batch = 128
        num_experts = 8
        block_size = 32

        expert_num_tokens = torch.randint(0, max_tokens_per_batch, (num_experts,), dtype=torch.int64, device='mps')

        sorted_token_ids = torch.empty(max_tokens_per_batch * num_experts, dtype=torch.int64, device='mps')
        experts_ids = torch.empty(num_experts, dtype=torch.int64, device='mps')
        num_tokens_post_pad = torch.empty(num_experts, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_batched_align_block_size(
            max_tokens_per_batch, block_size, expert_num_tokens,
            sorted_token_ids, experts_ids, num_tokens_post_pad
        )

        # Verify alignment
        assert (num_tokens_post_pad % block_size == 0).all()

    def test_moe_lora_align_block_size(self):
        """Test MoE alignment with LoRA support."""
        num_tokens = 64
        num_experts = 4
        topk = 2
        block_size = 16
        max_loras = 8
        max_num_tokens_padded = 256
        max_num_m_blocks = 16

        topk_ids = torch.randint(0, num_experts, (num_tokens, topk), dtype=torch.int64, device='mps')
        token_lora_mapping = torch.randint(0, max_loras, (num_tokens,), dtype=torch.int64, device='mps')

        sorted_token_ids = torch.empty(max_num_tokens_padded, dtype=torch.int64, device='mps')
        experts_ids = torch.empty(num_experts, dtype=torch.int64, device='mps')
        num_tokens_post_pad = torch.empty(num_experts, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_lora_align_block_size(
            topk_ids, token_lora_mapping, num_experts, block_size,
            max_loras, max_num_tokens_padded, max_num_m_blocks,
            sorted_token_ids, experts_ids, num_tokens_post_pad
        )

        assert (num_tokens_post_pad % block_size == 0).all()


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoEReduction:
    """Test MoE reduction operations."""

    def test_moe_sum_basic(self):
        """Test summing expert outputs."""
        num_tokens = 32
        hidden_dim = 128
        topk = 2

        input_tensor = torch.randn(num_tokens * topk, hidden_dim, dtype=torch.float32, device='mps')
        output = torch.empty(num_tokens, hidden_dim, dtype=torch.float32, device='mps')

        torch.ops.mlxllm.moe_sum(input_tensor, output)

        assert output.shape == (num_tokens, hidden_dim)

        # Verify summation (check first few tokens)
        for i in range(min(5, num_tokens)):
            expected = input_tensor[i * topk:(i + 1) * topk].sum(dim=0)
            torch.testing.assert_close(output[i], expected, rtol=1e-4, atol=1e-5)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoEUtilities:
    """Test MoE utility functions."""

    def test_moe_permute_unpermute_supported(self):
        """Test checking if permute/unpermute is supported."""
        supported = torch.ops.mlxllm.moe_permute_unpermute_supported()

        # On Metal/MPS, should return True
        assert isinstance(supported, bool)
        assert supported is True


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMoEEdgeCases:
    """Test edge cases for MoE operations."""

    def test_moe_topk_single_expert(self):
        """Test routing with topk=1 (single expert)."""
        num_tokens = 16
        num_experts = 4
        topk = 1

        gating_output = torch.randn(num_tokens, num_experts, dtype=torch.float32, device='mps')
        topk_weights = torch.empty(num_tokens, topk, dtype=torch.float32, device='mps')
        topk_indices = torch.empty(num_tokens, topk, dtype=torch.int64, device='mps')
        token_expert_indices = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_topk_softmax(
            topk_weights, topk_indices, token_expert_indices, gating_output, True
        )

        # With topk=1, all weights should be 1.0
        assert torch.allclose(topk_weights, torch.ones_like(topk_weights))

    def test_moe_align_small_counts(self):
        """Test alignment with small token counts."""
        num_experts = 4
        block_size = 64
        num_tokens = 10  # Small number
        topk = 1

        topk_ids = torch.randint(0, num_experts, (num_tokens, topk), dtype=torch.int64, device='mps')

        sorted_token_ids = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        experts_ids = torch.empty(num_experts, dtype=torch.int64, device='mps')
        num_tokens_post_pad = torch.empty(num_experts, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_align_block_size(
            topk_ids, num_experts, block_size,
            sorted_token_ids, experts_ids, num_tokens_post_pad
        )

        # Should pad correctly even with small counts
        assert (num_tokens_post_pad % block_size == 0).all()
        assert num_tokens_post_pad.sum() >= num_tokens

    def test_moe_permute_unpermute_roundtrip(self):
        """Test that permute followed by unpermute recovers original data."""
        num_tokens = 16
        hidden_dim = 64
        n_expert = 4
        topk = 2

        # Original input
        input_tensor = torch.randn(num_tokens, hidden_dim, dtype=torch.float32, device='mps')
        topk_ids = torch.randint(0, n_expert, (num_tokens, topk), dtype=torch.int64, device='mps')
        topk_weights = torch.rand(num_tokens, topk, dtype=torch.float32, device='mps')
        topk_weights = topk_weights / topk_weights.sum(dim=1, keepdim=True)
        token_expert_indices = topk_ids.flatten()

        # Permute
        permuted_input = torch.empty(num_tokens * topk, hidden_dim, dtype=torch.float32, device='mps')
        expert_first_token_offset = torch.empty(n_expert + 1, dtype=torch.int64, device='mps')
        inv_permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        m_indices = torch.empty(n_expert, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_permute(
            input_tensor, topk_ids, token_expert_indices, None,
            n_expert, n_expert, topk, None,
            permuted_input, expert_first_token_offset,
            inv_permuted_idx, permuted_idx, m_indices
        )

        # Unpermute
        reconstructed = torch.empty(num_tokens, hidden_dim, dtype=torch.float32, device='mps')
        torch.ops.mlxllm.moe_unpermute(
            permuted_input, topk_weights, inv_permuted_idx, None, topk, reconstructed
        )

        # Should be close to a weighted version of the original
        assert not torch.isnan(reconstructed).any()
        assert reconstructed.shape == input_tensor.shape


@pytest.mark.unit
@pytest.mark.requires_metal
@pytest.mark.slow
class TestMoEPerformance:
    """Performance tests for MoE operations."""

    def test_moe_routing_large_scale(self):
        """Test routing with large number of tokens and experts."""
        num_tokens = 4096
        num_experts = 64
        topk = 8

        gating_output = torch.randn(num_tokens, num_experts, dtype=torch.float32, device='mps')
        topk_weights = torch.empty(num_tokens, topk, dtype=torch.float32, device='mps')
        topk_indices = torch.empty(num_tokens, topk, dtype=torch.int64, device='mps')
        token_expert_indices = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')

        # Should complete in reasonable time
        torch.ops.mlxllm.moe_topk_softmax(
            topk_weights, topk_indices, token_expert_indices, gating_output, True
        )

        assert topk_weights.shape == (num_tokens, topk)

    def test_moe_permute_large_hidden_dim(self):
        """Test permutation with large hidden dimension."""
        num_tokens = 1024
        hidden_dim = 4096
        n_expert = 16
        topk = 4

        input_tensor = torch.randn(num_tokens, hidden_dim, dtype=torch.float32, device='mps')
        topk_ids = torch.randint(0, n_expert, (num_tokens, topk), dtype=torch.int64, device='mps')
        token_expert_indices = topk_ids.flatten()

        permuted_input = torch.empty(num_tokens * topk, hidden_dim, dtype=torch.float32, device='mps')
        expert_first_token_offset = torch.empty(n_expert + 1, dtype=torch.int64, device='mps')
        inv_permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        permuted_idx = torch.empty(num_tokens * topk, dtype=torch.int64, device='mps')
        m_indices = torch.empty(n_expert, dtype=torch.int64, device='mps')

        torch.ops.mlxllm.moe_permute(
            input_tensor, topk_ids, token_expert_indices, None,
            n_expert, n_expert, topk, None,
            permuted_input, expert_first_token_offset,
            inv_permuted_idx, permuted_idx, m_indices
        )

        assert permuted_input.shape == (num_tokens * topk, hidden_dim)
