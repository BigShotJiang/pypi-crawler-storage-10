"""
Tests for utility operations from csrc/torch_bindings.cpp.

Tests type conversion, column permutation, synchronization, and validation operations.

NOTE: These tests are for legacy PyTorch bindings. MLX-LLM is an MLX-based project,
and these PyTorch operations are not implemented. Tests are skipped until/unless
PyTorch support is added.
"""

import pytest
import torch
import numpy as np



@pytest.mark.unit
class TestTypeConversion:
    """Test FP32 <-> FP16 conversion operations."""

    def test_convert_fp32_to_fp16_basic(self):
        """Test basic FP32 to FP16 conversion."""
        # Create FP32 input
        input_fp32 = torch.randn(128, 256, dtype=torch.float32, device='mps')
        output_fp16 = torch.empty_like(input_fp32, dtype=torch.float16)

        # Convert using custom op
        torch.ops.mlxllm.convert_fp32_to_fp16(output_fp16, input_fp32)

        # Compare with PyTorch native conversion
        expected = input_fp32.to(torch.float16)
        torch.testing.assert_close(output_fp16, expected, rtol=1e-3, atol=1e-3)

    def test_convert_fp16_to_fp32_basic(self):
        """Test basic FP16 to FP32 conversion."""
        # Create FP16 input
        input_fp16 = torch.randn(128, 256, dtype=torch.float16, device='mps')
        output_fp32 = torch.empty_like(input_fp16, dtype=torch.float32)

        # Convert using custom op
        torch.ops.mlxllm.convert_fp16_to_fp32(output_fp32, input_fp16)

        # Compare with PyTorch native conversion
        expected = input_fp16.to(torch.float32)
        torch.testing.assert_close(output_fp32, expected, rtol=1e-3, atol=1e-3)

    def test_convert_roundtrip(self):
        """Test FP32 -> FP16 -> FP32 roundtrip conversion."""
        original = torch.randn(64, 128, dtype=torch.float32, device='mps')
        fp16_temp = torch.empty_like(original, dtype=torch.float16)
        final_fp32 = torch.empty_like(original, dtype=torch.float32)

        # FP32 -> FP16
        torch.ops.mlxllm.convert_fp32_to_fp16(fp16_temp, original)
        # FP16 -> FP32
        torch.ops.mlxllm.convert_fp16_to_fp32(final_fp32, fp16_temp)

        # Should match within FP16 precision
        torch.testing.assert_close(final_fp32, original, rtol=1e-3, atol=1e-3)

    def test_convert_edge_cases(self):
        """Test conversion with edge case values."""
        # Test with special values
        input_fp32 = torch.tensor([0.0, 1.0, -1.0, 1e-4, 1e4, float('inf'), float('-inf')],
                                   dtype=torch.float32, device='mps')
        output_fp16 = torch.empty_like(input_fp32, dtype=torch.float16)

        torch.ops.mlxllm.convert_fp32_to_fp16(output_fp16, input_fp32)
        expected = input_fp32.to(torch.float16)

        # Check non-inf values
        torch.testing.assert_close(output_fp16[:5], expected[:5], rtol=1e-3, atol=1e-3)
        # Check inf values separately
        assert torch.isinf(output_fp16[5]) and output_fp16[5] > 0
        assert torch.isinf(output_fp16[6]) and output_fp16[6] < 0

    def test_convert_empty_tensor(self):
        """Test conversion with empty tensors."""
        input_fp32 = torch.empty(0, 10, dtype=torch.float32, device='mps')
        output_fp16 = torch.empty_like(input_fp32, dtype=torch.float16)

        # Should not crash
        torch.ops.mlxllm.convert_fp32_to_fp16(output_fp16, input_fp32)
        assert output_fp16.shape == (0, 10)


@pytest.mark.unit
class TestPermuteColumns:
    """Test column permutation operation."""

    def test_permute_cols_basic(self):
        """Test basic column permutation."""
        # Create input matrix
        input_mat = torch.arange(12, dtype=torch.float32, device='mps').reshape(3, 4)
        # Permutation: [0, 1, 2, 3] -> [3, 1, 0, 2]
        perm = torch.tensor([3, 1, 0, 2], dtype=torch.int32, device='mps')
        output = torch.empty_like(input_mat)

        torch.ops.mlxllm.permute_cols(output, input_mat, perm)

        # Manually verify permutation
        expected = input_mat[:, [3, 1, 0, 2]]
        torch.testing.assert_close(output, expected)

    def test_permute_cols_identity(self):
        """Test permutation with identity permutation."""
        input_mat = torch.randn(10, 20, dtype=torch.float32, device='mps')
        perm = torch.arange(20, dtype=torch.int32, device='mps')
        output = torch.empty_like(input_mat)

        torch.ops.mlxllm.permute_cols(output, input_mat, perm)

        torch.testing.assert_close(output, input_mat)

    def test_permute_cols_reverse(self):
        """Test permutation that reverses columns."""
        input_mat = torch.randn(5, 8, dtype=torch.float32, device='mps')
        perm = torch.arange(7, -1, -1, dtype=torch.int32, device='mps')
        output = torch.empty_like(input_mat)

        torch.ops.mlxllm.permute_cols(output, input_mat, perm)

        expected = torch.flip(input_mat, dims=[1])
        torch.testing.assert_close(output, expected)

    def test_permute_cols_large_matrix(self):
        """Test permutation on larger matrices."""
        n_rows, n_cols = 1024, 512
        input_mat = torch.randn(n_rows, n_cols, dtype=torch.float32, device='mps')
        perm = torch.randperm(n_cols, dtype=torch.int32, device='mps')
        output = torch.empty_like(input_mat)

        torch.ops.mlxllm.permute_cols(output, input_mat, perm)

        # Verify by checking a few columns
        for i in range(min(10, n_cols)):
            torch.testing.assert_close(output[:, i], input_mat[:, perm[i]])


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMetalSynchronization:
    """Test Metal synchronization operations."""

    def test_metal_synchronize(self):
        """Test Metal device synchronization."""
        # Should complete without error
        torch.ops.mlxllm.metal_synchronize()

    def test_synchronize_after_operation(self):
        """Test synchronization after a Metal operation."""
        # Perform some Metal operation
        a = torch.randn(100, 100, device='mps')
        b = torch.randn(100, 100, device='mps')
        c = a @ b

        # Synchronize
        torch.ops.mlxllm.metal_synchronize()

        # Result should be accessible
        assert c.shape == (100, 100)


@pytest.mark.unit
@pytest.mark.requires_metal
class TestCheckFinite:
    """Test finite value checking operation."""

    def test_check_finite_all_finite(self):
        """Test checking tensor with all finite values."""
        tensor = torch.randn(128, 256, device='mps')
        result = torch.ops.mlxllm.check_finite(tensor)
        assert result is True

    def test_check_finite_with_nan(self):
        """Test checking tensor with NaN values."""
        tensor = torch.randn(128, 256, device='mps')
        tensor[10, 20] = float('nan')
        result = torch.ops.mlxllm.check_finite(tensor)
        assert result is False

    def test_check_finite_with_inf(self):
        """Test checking tensor with Inf values."""
        tensor = torch.randn(128, 256, device='mps')
        tensor[50, 100] = float('inf')
        result = torch.ops.mlxllm.check_finite(tensor)
        assert result is False

    def test_check_finite_with_neg_inf(self):
        """Test checking tensor with -Inf values."""
        tensor = torch.randn(128, 256, device='mps')
        tensor[5, 5] = float('-inf')
        result = torch.ops.mlxllm.check_finite(tensor)
        assert result is False

    def test_check_finite_empty_tensor(self):
        """Test checking empty tensor."""
        tensor = torch.empty(0, 10, device='mps')
        result = torch.ops.mlxllm.check_finite(tensor)
        # Empty tensor should be considered finite
        assert result is True

    def test_check_finite_zeros(self):
        """Test checking tensor of zeros."""
        tensor = torch.zeros(64, 128, device='mps')
        result = torch.ops.mlxllm.check_finite(tensor)
        assert result is True


@pytest.mark.unit
@pytest.mark.requires_metal
class TestMetalDeviceInfo:
    """Test Metal device information query."""

    def test_get_metal_device_info(self):
        """Test getting Metal device information."""
        info = torch.ops.mlxllm.get_metal_device_info()

        # Should return a non-empty string
        assert isinstance(info, str)
        assert len(info) > 0

    def test_device_info_contains_metal(self):
        """Test that device info mentions Metal or GPU."""
        info = torch.ops.mlxllm.get_metal_device_info()

        # Should contain some indication this is a Metal device
        # (exact format depends on implementation)
        assert len(info) > 0


@pytest.mark.unit
class TestUtilityEdgeCases:
    """Test edge cases and error handling for utility operations."""

    def test_convert_mismatched_shapes(self):
        """Test that conversion with mismatched shapes fails appropriately."""
        input_fp32 = torch.randn(10, 20, dtype=torch.float32, device='mps')
        output_fp16 = torch.empty(10, 15, dtype=torch.float16, device='mps')

        # This should fail or handle gracefully
        with pytest.raises(RuntimeError):
            torch.ops.mlxllm.convert_fp32_to_fp16(output_fp16, input_fp32)

    def test_permute_invalid_indices(self):
        """Test permutation with out-of-bounds indices."""
        input_mat = torch.randn(5, 10, dtype=torch.float32, device='mps')
        # Invalid permutation (index 15 is out of bounds)
        perm = torch.tensor([0, 1, 2, 15], dtype=torch.int32, device='mps')
        output = torch.empty(5, 4, dtype=torch.float32, device='mps')

        # Should fail
        with pytest.raises(RuntimeError):
            torch.ops.mlxllm.permute_cols(output, input_mat, perm)

    def test_permute_wrong_perm_length(self):
        """Test permutation with wrong permutation length."""
        input_mat = torch.randn(5, 10, dtype=torch.float32, device='mps')
        # Permutation has wrong length
        perm = torch.tensor([0, 1, 2], dtype=torch.int32, device='mps')
        output = torch.empty_like(input_mat)

        # Should fail or handle gracefully
        with pytest.raises(RuntimeError):
            torch.ops.mlxllm.permute_cols(output, input_mat, perm)
