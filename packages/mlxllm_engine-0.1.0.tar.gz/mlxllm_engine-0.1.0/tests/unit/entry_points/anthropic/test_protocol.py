# SPDX-License-Identifier: Apache-2.0
"""Tests for Anthropic API protocol models."""

from __future__ import annotations

import sys
from unittest.mock import Mock

import pytest

# Mock the missing EngineClient to avoid import errors
sys.modules['mlxllm.engine.protocol'].EngineClient = Mock

from mlxllm.entry_points.anthropic.protocol import (
    AnthropicCompletionRequest,
    AnthropicCompletionResponse,
    AnthropicErrorResponse,
    AnthropicMessagesRequest,
    AnthropicMessagesResponse,
    AnthropicStreamEvent,
    AnthropicUsage,
    ContentBlock,
    ConversationContext,
    Message,
    Tool,
)


@pytest.mark.unit
class TestAnthropicUsage:
    """Test AnthropicUsage model."""

    def test_usage_creation(self):
        """Test creating usage object."""
        usage = AnthropicUsage(input_tokens=100, output_tokens=50)
        assert usage.input_tokens == 100
        assert usage.output_tokens == 50


@pytest.mark.unit
class TestContentBlock:
    """Test ContentBlock model."""

    def test_text_content_block(self):
        """Test text content block."""
        block = ContentBlock(type="text", text="Hello, world!")
        assert block.type == "text"
        assert block.text == "Hello, world!"

    def test_tool_use_content_block(self):
        """Test tool use content block."""
        block = ContentBlock(
            type="tool_use",
            id="tool_1",
            name="get_weather",
            input={"location": "San Francisco"}
        )
        assert block.type == "tool_use"
        assert block.name == "get_weather"
        assert block.input["location"] == "San Francisco"

    def test_tool_result_content_block(self):
        """Test tool result content block."""
        block = ContentBlock(
            type="tool_result",
            tool_use_id="tool_1",
            content="Weather is sunny",
            is_error=False
        )
        assert block.type == "tool_result"
        assert block.tool_use_id == "tool_1"
        assert block.content == "Weather is sunny"
        assert block.is_error is False

    def test_image_content_block(self):
        """Test image content block."""
        block = ContentBlock(
            type="image",
            source={"type": "base64", "media_type": "image/png", "data": "..."}
        )
        assert block.type == "image"
        assert block.source["type"] == "base64"


@pytest.mark.unit
class TestMessage:
    """Test Message model."""

    def test_user_message_string_content(self):
        """Test user message with string content."""
        msg = Message(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"

    def test_assistant_message_with_blocks(self):
        """Test assistant message with content blocks."""
        blocks = [
            ContentBlock(type="text", text="I'll help you with that."),
            ContentBlock(type="tool_use", id="tool_1", name="search", input={})
        ]
        msg = Message(role="assistant", content=blocks)
        assert msg.role == "assistant"
        assert isinstance(msg.content, list)
        assert len(msg.content) == 2


@pytest.mark.unit
class TestTool:
    """Test Tool model."""

    def test_tool_definition(self):
        """Test tool definition."""
        tool = Tool(
            name="get_weather",
            description="Get current weather for a location",
            input_schema={
                "type": "object",
                "properties": {
                    "location": {"type": "string"}
                },
                "required": ["location"]
            }
        )
        assert tool.name == "get_weather"
        assert "location" in tool.input_schema["properties"]


@pytest.mark.unit
class TestAnthropicMessagesRequest:
    """Test AnthropicMessagesRequest model."""

    def test_minimal_messages_request(self):
        """Test minimal messages request."""
        messages = [Message(role="user", content="Hello")]
        request = AnthropicMessagesRequest(
            model="claude-3-opus-20240229",
            messages=messages
        )
        assert request.model == "claude-3-opus-20240229"
        assert len(request.messages) == 1
        assert request.max_tokens == 1024
        assert request.stream is False

    def test_full_messages_request(self):
        """Test messages request with all parameters."""
        messages = [
            Message(role="user", content="What's the weather?")
        ]
        tools = [
            Tool(
                name="get_weather",
                description="Get weather",
                input_schema={"type": "object"}
            )
        ]
        request = AnthropicMessagesRequest(
            model="claude-3-opus-20240229",
            messages=messages,
            system="You are a helpful assistant",
            max_tokens=2048,
            temperature=0.7,
            top_p=0.9,
            top_k=40,
            stop_sequences=["STOP"],
            stream=True,
            tools=tools,
            tool_choice="auto"
        )
        assert request.system == "You are a helpful assistant"
        assert request.temperature == 0.7
        assert request.stream is True
        assert len(request.tools) == 1

    def test_request_field_validation(self):
        """Test request field validation."""
        messages = [Message(role="user", content="Test")]

        # Temperature validation
        with pytest.raises(ValueError):
            AnthropicMessagesRequest(
                model="claude-3-opus-20240229",
                messages=messages,
                temperature=3.0  # Out of range
            )


@pytest.mark.unit
class TestAnthropicMessagesResponse:
    """Test AnthropicMessagesResponse model."""

    def test_basic_response(self):
        """Test basic messages response."""
        content = [ContentBlock(type="text", text="Hello! How can I help you?")]
        usage = AnthropicUsage(input_tokens=10, output_tokens=20)
        response = AnthropicMessagesResponse(
            id="msg_123",
            content=content,
            model="claude-3-opus-20240229",
            stop_reason="end_turn",
            usage=usage
        )
        assert response.id == "msg_123"
        assert response.type == "message"
        assert response.role == "assistant"
        assert len(response.content) == 1
        assert response.stop_reason == "end_turn"

    def test_response_with_tool_use(self):
        """Test response with tool use."""
        content = [
            ContentBlock(type="text", text="Let me check the weather."),
            ContentBlock(
                type="tool_use",
                id="tool_1",
                name="get_weather",
                input={"location": "SF"}
            )
        ]
        usage = AnthropicUsage(input_tokens=15, output_tokens=25)
        response = AnthropicMessagesResponse(
            id="msg_124",
            content=content,
            model="claude-3-opus-20240229",
            stop_reason="tool_use",
            usage=usage
        )
        assert len(response.content) == 2
        assert response.stop_reason == "tool_use"


@pytest.mark.unit
class TestAnthropicStreamEvent:
    """Test AnthropicStreamEvent model."""

    def test_message_start_event(self):
        """Test message start event."""
        usage = AnthropicUsage(input_tokens=10, output_tokens=0)
        content = [ContentBlock(type="text", text="")]
        message = AnthropicMessagesResponse(
            id="msg_123",
            content=content,
            model="claude-3-opus-20240229",
            usage=usage
        )
        event = AnthropicStreamEvent(
            type="message_start",
            message=message
        )
        assert event.type == "message_start"
        assert event.message.id == "msg_123"

    def test_content_block_delta_event(self):
        """Test content block delta event."""
        event = AnthropicStreamEvent(
            type="content_block_delta",
            index=0,
            delta={"type": "text_delta", "text": "Hello"}
        )
        assert event.type == "content_block_delta"
        assert event.delta["text"] == "Hello"

    def test_message_stop_event(self):
        """Test message stop event."""
        event = AnthropicStreamEvent(type="message_stop")
        assert event.type == "message_stop"


@pytest.mark.unit
class TestAnthropicErrorResponse:
    """Test AnthropicErrorResponse model."""

    def test_error_response(self):
        """Test error response."""
        error = AnthropicErrorResponse(
            error={
                "type": "invalid_request_error",
                "message": "Invalid API key"
            }
        )
        assert error.type == "error"
        assert error.error["type"] == "invalid_request_error"


@pytest.mark.unit
class TestAnthropicCompletionRequest:
    """Test AnthropicCompletionRequest (legacy) model."""

    def test_minimal_completion_request(self):
        """Test minimal completion request."""
        request = AnthropicCompletionRequest(
            model="claude-2.1",
            prompt="\n\nHuman: Hello\n\nAssistant:"
        )
        assert request.model == "claude-2.1"
        assert "Human:" in request.prompt
        assert request.max_tokens_to_sample == 1024

    def test_full_completion_request(self):
        """Test completion request with all parameters."""
        request = AnthropicCompletionRequest(
            model="claude-2.1",
            prompt="\n\nHuman: Hello\n\nAssistant:",
            max_tokens_to_sample=2048,
            temperature=0.5,
            top_p=0.95,
            top_k=50,
            stop_sequences=["\n\nHuman:"],
            stream=True
        )
        assert request.temperature == 0.5
        assert request.stream is True
        assert "\n\nHuman:" in request.stop_sequences


@pytest.mark.unit
class TestAnthropicCompletionResponse:
    """Test AnthropicCompletionResponse model."""

    def test_completion_response(self):
        """Test completion response."""
        usage = AnthropicUsage(input_tokens=20, output_tokens=30)
        response = AnthropicCompletionResponse(
            id="cmpl_123",
            completion="Hello! How can I help you today?",
            stop_reason="stop_sequence",
            model="claude-2.1",
            usage=usage
        )
        assert response.type == "completion"
        assert response.completion == "Hello! How can I help you today?"
        assert response.stop_reason == "stop_sequence"


@pytest.mark.unit
class TestConversationContext:
    """Test ConversationContext model."""

    def test_conversation_context(self):
        """Test conversation context."""
        messages = [
            Message(role="user", content="Hello"),
            Message(role="assistant", content="Hi there!")
        ]
        context = ConversationContext(
            messages=messages,
            system="You are helpful",
            metadata={"user_id": "123"}
        )
        assert len(context.messages) == 2
        assert context.system == "You are helpful"
        assert context.metadata["user_id"] == "123"
