# SPDX-License-Identifier: Apache-2.0
"""Tests for entry points constants."""

from __future__ import annotations

import pytest

from mlxllm.entry_points import constants


@pytest.mark.unit
class TestConstants:
    """Test constants are defined correctly."""

    def test_h11_max_header_count_default(self):
        """Test H11 max header count constant."""
        assert constants.H11_MAX_HEADER_COUNT_DEFAULT == 100
        assert isinstance(constants.H11_MAX_HEADER_COUNT_DEFAULT, int)

    def test_h11_max_incomplete_event_size_default(self):
        """Test H11 max incomplete event size constant."""
        assert constants.H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT == 16 * 1024
        assert constants.H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT == 16384
        assert isinstance(constants.H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT, int)

    def test_constants_are_positive(self):
        """Test that all constants are positive values."""
        assert constants.H11_MAX_HEADER_COUNT_DEFAULT > 0
        assert constants.H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT > 0

    def test_constants_immutable(self):
        """Test that constants module attributes exist."""
        # Ensure constants are accessible
        assert hasattr(constants, 'H11_MAX_HEADER_COUNT_DEFAULT')
        assert hasattr(constants, 'H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT')
