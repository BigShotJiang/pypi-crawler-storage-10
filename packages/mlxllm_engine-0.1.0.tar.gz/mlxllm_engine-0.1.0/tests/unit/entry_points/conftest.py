# SPDX-License-Identifier: Apache-2.0
"""Shared fixtures for entry_points tests."""

from __future__ import annotations

from typing import AsyncGenerator
from unittest.mock import AsyncMock, Mock

import pytest

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.outputs import RequestOutput
from mlxllm.sampling_params import SamplingParams


@pytest.fixture
def mock_tokenizer():
    """Create a mock tokenizer."""
    tokenizer = Mock()
    tokenizer.encode = Mock(side_effect=lambda text: list(range(len(text.split()))))
    tokenizer.decode = Mock(side_effect=lambda tokens: " ".join([f"token_{t}" for t in tokens]))
    tokenizer.eos_token_id = 2
    tokenizer.bos_token_id = 1
    tokenizer.pad_token_id = 0
    tokenizer.vocab_size = 32000
    tokenizer.apply_chat_template = Mock(return_value="formatted_prompt")
    return tokenizer


@pytest.fixture
def mock_engine_client():
    """Create a mock async engine client."""
    client = AsyncMock()

    # Mock generate method
    async def mock_generate(
        prompt: str,
        sampling_params: SamplingParams,
        request_id: str,
    ) -> AsyncGenerator[RequestOutput, None]:
        """Mock generator for generate method."""
        # Simulate streaming output
        for i in range(3):
            output = RequestOutput(
                request_id=request_id,
                prompt=prompt,
                outputs=[{
                    "text": f"token_{i}",
                    "token_ids": [i],
                    "cumulative_logprob": -0.1 * i,
                    "finish_reason": None if i < 2 else "stop"
                }],
                finished=i == 2
            )
            yield output

    client.generate = mock_generate
    client.get_tokenizer = AsyncMock(return_value=mock_tokenizer())
    client.get_model_config = AsyncMock()
    return client


@pytest.fixture
def mock_model_config():
    """Create a mock ModelConfig."""
    config = Mock(spec=ModelConfig)
    config.model_name = "test-model"
    config.max_model_len = 8192
    config.vocab_size = 32000
    config.hidden_size = 4096
    config.num_heads = 32
    config.num_layers = 32
    config.rope_theta = 10000.0
    return config


@pytest.fixture
def mock_scheduler_config():
    """Create a mock SchedulerConfig."""
    config = Mock(spec=SchedulerConfig)
    config.max_num_seqs = 256
    config.max_num_batched_tokens = 8192
    config.policy = "fcfs"
    config.max_paddings = 256
    return config


@pytest.fixture
def mock_cache_config():
    """Create a mock CacheConfig."""
    config = Mock(spec=CacheConfig)
    config.block_size = 16
    config.gpu_memory_utilization = 0.9
    config.swap_space_gb = 4.0
    config.enable_prefix_caching = False
    return config


@pytest.fixture
def sample_sampling_params():
    """Create sample SamplingParams for testing."""
    return SamplingParams(
        temperature=0.7,
        top_p=0.9,
        top_k=50,
        max_tokens=128,
        stop=["STOP"],
        presence_penalty=0.0,
        frequency_penalty=0.0,
    )


@pytest.fixture
def sample_request_output():
    """Create a sample RequestOutput for testing."""
    return RequestOutput(
        request_id="test-request-123",
        prompt="Test prompt",
        outputs=[{
            "text": "Generated text",
            "token_ids": [10, 20, 30],
            "cumulative_logprob": -1.5,
            "finish_reason": "stop"
        }],
        finished=True
    )


@pytest.fixture
def sample_chat_messages():
    """Create sample chat messages."""
    return [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello, how are you?"},
        {"role": "assistant", "content": "I'm doing well, thank you!"},
        {"role": "user", "content": "Can you help me with something?"}
    ]


@pytest.fixture
def sample_openai_chat_messages():
    """Create sample OpenAI chat messages."""
    from mlxllm.entry_points.openai.protocol import ChatMessage

    return [
        ChatMessage(role="system", content="You are a helpful assistant."),
        ChatMessage(role="user", content="Hello!"),
        ChatMessage(role="assistant", content="Hi there!"),
    ]


@pytest.fixture
def sample_anthropic_messages():
    """Create sample Anthropic messages."""
    from mlxllm.entry_points.anthropic.protocol import Message

    return [
        Message(role="user", content="Hello!"),
        Message(role="assistant", content="Hi there! How can I help you?"),
    ]


@pytest.fixture
def mock_async_engine():
    """Create a mock AsyncLLMEngine."""
    engine = AsyncMock()
    engine.generate = AsyncMock()
    engine.abort_request = AsyncMock()
    engine.get_model_config = Mock(return_value=mock_model_config())
    engine.get_num_unfinished_requests = Mock(return_value=0)
    return engine


@pytest.fixture
async def mock_fastapi_request():
    """Create a mock FastAPI Request object."""
    request = Mock()
    request.url = Mock()
    request.url.path = "/v1/chat/completions"
    request.client = Mock()
    request.client.host = "127.0.0.1"
    request.headers = {"user-agent": "test-client"}
    return request


@pytest.fixture
def sample_tools():
    """Create sample tool definitions for testing."""
    return [
        {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "Get current weather for a location",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "City name"
                        },
                        "unit": {
                            "type": "string",
                            "enum": ["celsius", "fahrenheit"]
                        }
                    },
                    "required": ["location"]
                }
            }
        }
    ]


@pytest.fixture
def sample_embeddings():
    """Create sample embeddings for testing."""
    return [
        [0.1, 0.2, 0.3, 0.4],
        [0.5, 0.6, 0.7, 0.8],
        [0.9, 1.0, 1.1, 1.2]
    ]


@pytest.fixture
def temp_model_path(tmp_path):
    """Create a temporary model path for testing."""
    model_dir = tmp_path / "test-model"
    model_dir.mkdir()

    # Create dummy model files
    (model_dir / "config.json").write_text('{"model_type": "llama"}')
    (model_dir / "tokenizer.json").write_text('{}')

    return model_dir


@pytest.fixture
def sample_lora_modules():
    """Create sample LoRA module specifications."""
    return [
        {
            "name": "lora-1",
            "path": "/path/to/lora1",
            "base_model_name": "test-model"
        },
        {
            "name": "lora-2",
            "path": "/path/to/lora2"
        }
    ]


@pytest.fixture
def mock_http_client():
    """Create a mock HTTP client for testing API calls."""
    client = Mock()
    response = Mock()
    response.status_code = 200
    response.json = Mock(return_value={"status": "ok"})
    response.text = "Success"
    client.post = Mock(return_value=response)
    client.get = Mock(return_value=response)
    return client


@pytest.fixture
def benchmark_test_prompts():
    """Create test prompts for benchmarking."""
    return [
        "This is a test prompt for benchmarking.",
        "Another test prompt with different length and content.",
        "Short prompt.",
        "A longer test prompt that contains multiple sentences and more tokens for testing.",
    ]


@pytest.fixture
def mock_mlx_model():
    """Create a mock MLX model."""
    model = Mock()
    model.generate = Mock(return_value=[[1, 2, 3, 4, 5]])
    model.embed = Mock(return_value=[[0.1, 0.2, 0.3, 0.4]])
    model.config = Mock()
    model.config.max_position_embeddings = 8192
    return model


@pytest.fixture(autouse=True)
def reset_mocks():
    """Reset all mocks after each test."""
    yield
    # Cleanup happens automatically with pytest


@pytest.fixture
def sample_batch_requests():
    """Create sample batch processing requests."""
    return [
        {
            "custom_id": "request-1",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": "test-model",
                "messages": [{"role": "user", "content": "Hello"}]
            }
        },
        {
            "custom_id": "request-2",
            "method": "POST",
            "url": "/v1/completions",
            "body": {
                "model": "test-model",
                "prompt": "Once upon a time"
            }
        }
    ]


@pytest.fixture
def cli_serve_args():
    """Create sample CLI serve arguments."""
    from mlxllm.entry_points.cli.types import ServeArgs, APIProtocol

    return ServeArgs(
        model="test-model",
        host="127.0.0.1",
        port=8000,
        protocol=APIProtocol.OPENAI,
        max_model_len=8192,
        max_num_seqs=256,
    )


@pytest.fixture
def cli_generate_args():
    """Create sample CLI generate arguments."""
    from mlxllm.entry_points.cli.types import GenerateArgs

    return GenerateArgs(
        model="test-model",
        prompt="Test prompt",
        max_tokens=128,
        temperature=0.7
    )
