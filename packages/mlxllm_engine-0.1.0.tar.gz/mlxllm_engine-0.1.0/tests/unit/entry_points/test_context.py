# SPDX-License-Identifier: Apache-2.0
"""Tests for conversation context management."""

from __future__ import annotations

import pytest

from mlxllm.entry_points.context import ConversationContext, ConversationMessage


@pytest.mark.unit
class TestConversationMessage:
    """Test ConversationMessage dataclass."""

    def test_basic_message(self):
        """Test creating a basic message."""
        msg = ConversationMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.name is None
        assert msg.tool_calls is None
        assert msg.tool_call_id is None

    def test_message_with_name(self):
        """Test message with name field."""
        msg = ConversationMessage(role="user", content="Hello", name="Alice")
        assert msg.name == "Alice"

    def test_message_with_tool_calls(self):
        """Test message with tool calls."""
        tool_calls = [{"id": "call_1", "function": {"name": "get_weather"}}]
        msg = ConversationMessage(
            role="assistant",
            content="",
            tool_calls=tool_calls
        )
        assert msg.tool_calls == tool_calls

    def test_message_with_tool_call_id(self):
        """Test tool response message."""
        msg = ConversationMessage(
            role="tool",
            content="Weather is sunny",
            tool_call_id="call_1"
        )
        assert msg.tool_call_id == "call_1"


@pytest.mark.unit
class TestConversationContextInit:
    """Test ConversationContext initialization."""

    def test_init_default(self):
        """Test default initialization."""
        context = ConversationContext()
        assert context.messages == []
        assert context.max_context_length == 2048
        assert context.system_message is None

    def test_init_with_params(self):
        """Test initialization with parameters."""
        context = ConversationContext(
            max_context_length=4096,
            system_message="You are a helpful assistant"
        )
        assert context.max_context_length == 4096
        assert context.system_message == "You are a helpful assistant"

    def test_init_with_messages(self):
        """Test initialization with existing messages."""
        messages = [
            ConversationMessage(role="user", content="Hello"),
            ConversationMessage(role="assistant", content="Hi!")
        ]
        context = ConversationContext(messages=messages)
        assert len(context.messages) == 2


@pytest.mark.unit
class TestAddMessage:
    """Test adding messages to conversation."""

    def test_add_simple_message(self):
        """Test adding a simple message."""
        context = ConversationContext()
        context.add_message(role="user", content="Hello")

        assert len(context.messages) == 1
        assert context.messages[0].role == "user"
        assert context.messages[0].content == "Hello"

    def test_add_message_with_name(self):
        """Test adding message with name."""
        context = ConversationContext()
        context.add_message(role="user", content="Hello", name="Alice")

        assert context.messages[0].name == "Alice"

    def test_add_message_with_tool_calls(self):
        """Test adding message with tool calls."""
        context = ConversationContext()
        tool_calls = [{"id": "call_1"}]
        context.add_message(
            role="assistant",
            content="",
            tool_calls=tool_calls
        )

        assert context.messages[0].tool_calls == tool_calls

    def test_add_message_with_tool_call_id(self):
        """Test adding tool response message."""
        context = ConversationContext()
        context.add_message(
            role="tool",
            content="Result",
            tool_call_id="call_1"
        )

        assert context.messages[0].tool_call_id == "call_1"

    def test_add_multiple_messages(self):
        """Test adding multiple messages."""
        context = ConversationContext()
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi there!")
        context.add_message("user", "How are you?")

        assert len(context.messages) == 3
        assert context.messages[0].role == "user"
        assert context.messages[1].role == "assistant"
        assert context.messages[2].role == "user"


@pytest.mark.unit
class TestGetMessages:
    """Test retrieving messages from conversation."""

    def test_get_all_messages(self):
        """Test getting all messages."""
        context = ConversationContext()
        context.add_message("user", "Message 1")
        context.add_message("assistant", "Message 2")

        messages = context.get_messages()
        assert len(messages) == 2
        assert messages[0].content == "Message 1"
        assert messages[1].content == "Message 2"

    def test_get_messages_empty(self):
        """Test getting messages from empty conversation."""
        context = ConversationContext()
        messages = context.get_messages()
        assert messages == []

    def test_get_last_n_messages(self):
        """Test getting last N messages."""
        context = ConversationContext()
        context.add_message("user", "Msg 1")
        context.add_message("assistant", "Msg 2")
        context.add_message("user", "Msg 3")
        context.add_message("assistant", "Msg 4")

        last_two = context.get_last_n_messages(2)
        assert len(last_two) == 2
        assert last_two[0].content == "Msg 3"
        assert last_two[1].content == "Msg 4"

    def test_get_last_n_more_than_available(self):
        """Test getting more messages than available."""
        context = ConversationContext()
        context.add_message("user", "Only message")

        messages = context.get_last_n_messages(10)
        assert len(messages) == 1

    def test_get_last_n_zero(self):
        """Test getting zero messages."""
        context = ConversationContext()
        context.add_message("user", "Message")

        messages = context.get_last_n_messages(0)
        assert messages == []

    def test_get_last_n_negative(self):
        """Test getting negative number of messages."""
        context = ConversationContext()
        context.add_message("user", "Message")

        messages = context.get_last_n_messages(-1)
        assert messages == []


@pytest.mark.unit
class TestClear:
    """Test clearing conversation."""

    def test_clear_messages(self):
        """Test clearing all messages."""
        context = ConversationContext()
        context.add_message("user", "Message 1")
        context.add_message("assistant", "Message 2")

        assert len(context.messages) == 2

        context.clear()

        assert len(context.messages) == 0

    def test_clear_empty_conversation(self):
        """Test clearing already empty conversation."""
        context = ConversationContext()
        context.clear()

        assert len(context.messages) == 0

    def test_clear_preserves_system_message(self):
        """Test that clear preserves system message."""
        context = ConversationContext(system_message="You are helpful")
        context.add_message("user", "Hello")

        context.clear()

        assert context.system_message == "You are helpful"
        assert len(context.messages) == 0


@pytest.mark.unit
class TestToOpenAIFormat:
    """Test converting to OpenAI format."""

    def test_to_openai_format_simple(self):
        """Test simple conversion to OpenAI format."""
        context = ConversationContext()
        context.add_message("user", "Hello")
        context.add_message("assistant", "Hi there!")

        openai_msgs = context.to_openai_format()

        assert len(openai_msgs) == 2
        assert openai_msgs[0] == {"role": "user", "content": "Hello"}
        assert openai_msgs[1] == {"role": "assistant", "content": "Hi there!"}

    def test_to_openai_format_with_system(self):
        """Test conversion with system message."""
        context = ConversationContext(system_message="You are helpful")
        context.add_message("user", "Hello")

        openai_msgs = context.to_openai_format()

        assert len(openai_msgs) == 2
        assert openai_msgs[0] == {"role": "system", "content": "You are helpful"}
        assert openai_msgs[1] == {"role": "user", "content": "Hello"}

    def test_to_openai_format_with_name(self):
        """Test conversion with message names."""
        context = ConversationContext()
        context.add_message("user", "Hello", name="Alice")

        openai_msgs = context.to_openai_format()

        assert openai_msgs[0]["name"] == "Alice"

    def test_to_openai_format_with_tool_calls(self):
        """Test conversion with tool calls."""
        context = ConversationContext()
        tool_calls = [{"id": "call_1", "function": {"name": "get_weather"}}]
        context.add_message("assistant", "", tool_calls=tool_calls)

        openai_msgs = context.to_openai_format()

        assert openai_msgs[0]["tool_calls"] == tool_calls

    def test_to_openai_format_with_tool_call_id(self):
        """Test conversion with tool call ID."""
        context = ConversationContext()
        context.add_message("tool", "Result", tool_call_id="call_1")

        openai_msgs = context.to_openai_format()

        assert openai_msgs[0]["tool_call_id"] == "call_1"

    def test_to_openai_format_empty(self):
        """Test conversion of empty conversation."""
        context = ConversationContext()

        openai_msgs = context.to_openai_format()

        assert openai_msgs == []

    def test_to_openai_format_system_only(self):
        """Test conversion with only system message."""
        context = ConversationContext(system_message="You are helpful")

        openai_msgs = context.to_openai_format()

        assert len(openai_msgs) == 1
        assert openai_msgs[0] == {"role": "system", "content": "You are helpful"}


@pytest.mark.unit
class TestConversationContextEdgeCases:
    """Test edge cases for conversation context."""

    def test_very_long_conversation(self):
        """Test handling very long conversation."""
        context = ConversationContext()

        # Add 1000 messages
        for i in range(1000):
            context.add_message("user", f"Message {i}")

        assert len(context.messages) == 1000

        # Can still get last messages
        last_10 = context.get_last_n_messages(10)
        assert len(last_10) == 10
        assert last_10[-1].content == "Message 999"

    def test_unicode_content(self):
        """Test handling Unicode content."""
        context = ConversationContext()
        context.add_message("user", "Hello 世界 🌍")

        openai_msgs = context.to_openai_format()
        assert openai_msgs[0]["content"] == "Hello 世界 🌍"

    def test_empty_content(self):
        """Test handling empty content."""
        context = ConversationContext()
        context.add_message("user", "")

        assert context.messages[0].content == ""

    def test_message_order_preserved(self):
        """Test that message order is preserved."""
        context = ConversationContext()

        for i in range(10):
            context.add_message("user", f"User {i}")
            context.add_message("assistant", f"Assistant {i}")

        messages = context.get_messages()

        for i in range(10):
            assert messages[i*2].content == f"User {i}"
            assert messages[i*2 + 1].content == f"Assistant {i}"

    def test_system_message_always_first(self):
        """Test that system message is always first in OpenAI format."""
        context = ConversationContext(system_message="System")
        context.add_message("user", "First user message")

        openai_msgs = context.to_openai_format()

        assert openai_msgs[0]["role"] == "system"
        assert openai_msgs[1]["role"] == "user"
