# SPDX-License-Identifier: Apache-2.0
"""Tests for OpenAI API protocol models."""

from __future__ import annotations

import time
from typing import Any

import pytest

from mlxllm.entry_points.openai.protocol import (
    BatchRequest,
    BatchResponse,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionResponseChoice,
    ChatCompletionStreamResponse,
    ChatCompletionStreamResponseChoice,
    ChatCompletionStreamResponseDelta,
    ChatMessage,
    ClassificationRequest,
    ClassificationResponse,
    CompletionRequest,
    CompletionResponse,
    CompletionResponseChoice,
    CompletionStreamResponse,
    DetokenizeRequest,
    DetokenizeResponse,
    EmbeddingData,
    EmbeddingRequest,
    EmbeddingResponse,
    ErrorInfo,
    ErrorResponse,
    LoadLoRAAdapterRequest,
    ModelCard,
    ModelList,
    PoolingRequest,
    PoolingResponse,
    RerankRequest,
    RerankResponse,
    ScoreRequest,
    ScoreResponse,
    StreamOptions,
    TokenizeRequest,
    TokenizeResponse,
    TranscriptionRequest,
    TranscriptionResponse,
    TranslationRequest,
    TranslationResponse,
    UnloadLoRAAdapterRequest,
    UsageInfo,
)


@pytest.mark.unit
class TestUsageInfo:
    """Test UsageInfo model."""

    def test_usage_info_creation(self):
        """Test creating a UsageInfo object."""
        usage = UsageInfo(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        assert usage.prompt_tokens == 10
        assert usage.completion_tokens == 20
        assert usage.total_tokens == 30

    def test_usage_info_defaults(self):
        """Test UsageInfo with default values."""
        usage = UsageInfo()
        assert usage.prompt_tokens == 0
        assert usage.completion_tokens == 0
        assert usage.total_tokens == 0


@pytest.mark.unit
class TestErrorModels:
    """Test error-related models."""

    def test_error_info_creation(self):
        """Test creating an ErrorInfo object."""
        error = ErrorInfo(
            message="Invalid request",
            type="invalid_request_error",
            param="temperature",
            code="invalid_value"
        )
        assert error.message == "Invalid request"
        assert error.type == "invalid_request_error"
        assert error.param == "temperature"
        assert error.code == "invalid_value"

    def test_error_response(self):
        """Test ErrorResponse creation."""
        error_info = ErrorInfo(message="Test error", type="test_error")
        response = ErrorResponse(error=error_info)
        assert response.error.message == "Test error"
        assert response.error.type == "test_error"


@pytest.mark.unit
class TestChatMessage:
    """Test ChatMessage model."""

    def test_basic_message(self):
        """Test creating a basic chat message."""
        msg = ChatMessage(role="user", content="Hello, world!")
        assert msg.role == "user"
        assert msg.content == "Hello, world!"
        assert msg.name is None
        assert msg.tool_calls is None

    def test_assistant_message_with_tools(self):
        """Test assistant message with tool calls."""
        tool_calls = [
            {"id": "call_1", "type": "function", "function": {"name": "get_weather"}}
        ]
        msg = ChatMessage(role="assistant", content=None, tool_calls=tool_calls)
        assert msg.role == "assistant"
        assert msg.content is None
        assert len(msg.tool_calls) == 1
        assert msg.tool_calls[0]["id"] == "call_1"

    def test_tool_response_message(self):
        """Test tool response message."""
        msg = ChatMessage(role="tool", content="Weather is sunny", tool_call_id="call_1")
        assert msg.role == "tool"
        assert msg.content == "Weather is sunny"
        assert msg.tool_call_id == "call_1"


@pytest.mark.unit
class TestChatCompletionRequest:
    """Test ChatCompletionRequest model."""

    def test_minimal_request(self):
        """Test minimal chat completion request."""
        messages = [ChatMessage(role="user", content="Hello")]
        request = ChatCompletionRequest(model="gpt-3.5-turbo", messages=messages)
        assert request.model == "gpt-3.5-turbo"
        assert len(request.messages) == 1
        assert request.temperature == 1.0
        assert request.stream is False

    def test_full_request(self):
        """Test chat completion request with all parameters."""
        messages = [
            ChatMessage(role="system", content="You are a helpful assistant"),
            ChatMessage(role="user", content="Hello")
        ]
        request = ChatCompletionRequest(
            model="gpt-4",
            messages=messages,
            temperature=0.7,
            top_p=0.9,
            n=2,
            max_tokens=100,
            stop=["STOP"],
            stream=True,
            presence_penalty=0.5,
            frequency_penalty=0.5,
            logprobs=True,
            top_logprobs=5,
            seed=42
        )
        assert request.model == "gpt-4"
        assert request.temperature == 0.7
        assert request.top_p == 0.9
        assert request.n == 2
        assert request.max_tokens == 100
        assert request.stream is True
        assert request.seed == 42

    def test_request_with_tools(self):
        """Test chat completion request with tools."""
        messages = [ChatMessage(role="user", content="What's the weather?")]
        tools = [
            {
                "type": "function",
                "function": {
                    "name": "get_weather",
                    "description": "Get current weather",
                    "parameters": {"type": "object", "properties": {}}
                }
            }
        ]
        request = ChatCompletionRequest(
            model="gpt-4",
            messages=messages,
            tools=tools,
            tool_choice="auto"
        )
        assert len(request.tools) == 1
        assert request.tool_choice == "auto"


@pytest.mark.unit
class TestChatCompletionResponse:
    """Test ChatCompletionResponse models."""

    def test_basic_response(self):
        """Test basic chat completion response."""
        message = ChatMessage(role="assistant", content="Hello! How can I help you?")
        choice = ChatCompletionResponseChoice(
            index=0,
            message=message,
            finish_reason="stop"
        )
        usage = UsageInfo(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        response = ChatCompletionResponse(
            id="chatcmpl-123",
            model="gpt-3.5-turbo",
            choices=[choice],
            usage=usage
        )
        assert response.id == "chatcmpl-123"
        assert response.object == "chat.completion"
        assert len(response.choices) == 1
        assert response.choices[0].message.content == "Hello! How can I help you?"
        assert response.usage.total_tokens == 30

    def test_response_with_timestamp(self):
        """Test response includes timestamp."""
        message = ChatMessage(role="assistant", content="Test")
        choice = ChatCompletionResponseChoice(index=0, message=message)
        response = ChatCompletionResponse(
            id="test-123",
            model="gpt-4",
            choices=[choice]
        )
        assert response.created > 0
        assert response.created <= int(time.time())

    def test_streaming_response(self):
        """Test streaming chat completion response."""
        delta = ChatCompletionStreamResponseDelta(content="Hello")
        choice = ChatCompletionStreamResponseChoice(
            index=0,
            delta=delta,
            finish_reason=None
        )
        response = ChatCompletionStreamResponse(
            id="chatcmpl-stream-123",
            model="gpt-3.5-turbo",
            choices=[choice]
        )
        assert response.object == "chat.completion.chunk"
        assert response.choices[0].delta.content == "Hello"
        assert response.choices[0].finish_reason is None


@pytest.mark.unit
class TestCompletionRequest:
    """Test CompletionRequest model."""

    def test_string_prompt(self):
        """Test completion request with string prompt."""
        request = CompletionRequest(model="gpt-3.5-turbo", prompt="Once upon a time")
        assert request.model == "gpt-3.5-turbo"
        assert request.prompt == "Once upon a time"
        assert request.max_tokens == 16

    def test_list_prompt(self):
        """Test completion request with list of prompts."""
        prompts = ["Prompt 1", "Prompt 2"]
        request = CompletionRequest(model="gpt-3.5-turbo", prompt=prompts)
        assert len(request.prompt) == 2

    def test_token_prompt(self):
        """Test completion request with token IDs."""
        tokens = [1, 2, 3, 4, 5]
        request = CompletionRequest(model="gpt-3.5-turbo", prompt=tokens)
        assert request.prompt == tokens

    def test_full_completion_request(self):
        """Test completion request with all parameters."""
        request = CompletionRequest(
            model="gpt-3.5-turbo",
            prompt="Test",
            temperature=0.8,
            top_p=0.95,
            n=3,
            max_tokens=50,
            stop=["\n"],
            stream=True,
            logprobs=5,
            echo=True,
            seed=42
        )
        assert request.temperature == 0.8
        assert request.n == 3
        assert request.echo is True
        assert request.seed == 42


@pytest.mark.unit
class TestCompletionResponse:
    """Test CompletionResponse models."""

    def test_basic_completion_response(self):
        """Test basic completion response."""
        choice = CompletionResponseChoice(
            index=0,
            text="Once upon a time",
            finish_reason="length"
        )
        usage = UsageInfo(prompt_tokens=5, completion_tokens=10, total_tokens=15)
        response = CompletionResponse(
            id="cmpl-123",
            model="gpt-3.5-turbo",
            choices=[choice],
            usage=usage
        )
        assert response.object == "text_completion"
        assert len(response.choices) == 1
        assert response.choices[0].text == "Once upon a time"

    def test_completion_stream_response(self):
        """Test streaming completion response."""
        choice = CompletionResponseChoice(index=0, text="Hello")
        response = CompletionStreamResponse(
            id="cmpl-stream-123",
            model="gpt-3.5-turbo",
            choices=[choice]
        )
        assert response.object == "text_completion"
        assert response.choices[0].text == "Hello"


@pytest.mark.unit
class TestEmbeddingModels:
    """Test embedding-related models."""

    def test_embedding_request_string(self):
        """Test embedding request with string input."""
        request = EmbeddingRequest(model="text-embedding-ada-002", input="Hello world")
        assert request.model == "text-embedding-ada-002"
        assert request.input == "Hello world"
        assert request.encoding_format == "float"

    def test_embedding_request_list(self):
        """Test embedding request with list input."""
        inputs = ["Hello", "World"]
        request = EmbeddingRequest(model="text-embedding-ada-002", input=inputs)
        assert len(request.input) == 2

    def test_embedding_request_with_dimensions(self):
        """Test embedding request with dimensions parameter."""
        request = EmbeddingRequest(
            model="text-embedding-3-small",
            input="Test",
            dimensions=512
        )
        assert request.dimensions == 512

    def test_embedding_response(self):
        """Test embedding response."""
        embedding_data = [
            EmbeddingData(embedding=[0.1, 0.2, 0.3], index=0),
            EmbeddingData(embedding=[0.4, 0.5, 0.6], index=1)
        ]
        usage = UsageInfo(prompt_tokens=5, completion_tokens=0, total_tokens=5)
        response = EmbeddingResponse(
            data=embedding_data,
            model="text-embedding-ada-002",
            usage=usage
        )
        assert response.object == "list"
        assert len(response.data) == 2
        assert response.data[0].embedding == [0.1, 0.2, 0.3]


@pytest.mark.unit
class TestModelListModels:
    """Test model listing models."""

    def test_model_card(self):
        """Test ModelCard creation."""
        card = ModelCard(id="gpt-3.5-turbo", owned_by="openai")
        assert card.id == "gpt-3.5-turbo"
        assert card.object == "model"
        assert card.owned_by == "openai"
        assert card.created > 0

    def test_model_list(self):
        """Test ModelList creation."""
        cards = [
            ModelCard(id="gpt-3.5-turbo"),
            ModelCard(id="gpt-4")
        ]
        model_list = ModelList(data=cards)
        assert model_list.object == "list"
        assert len(model_list.data) == 2


@pytest.mark.unit
class TestTokenizationModels:
    """Test tokenization models."""

    def test_tokenize_request(self):
        """Test tokenization request."""
        request = TokenizeRequest(
            model="gpt-3.5-turbo",
            prompt="Hello world",
            add_special_tokens=True
        )
        assert request.model == "gpt-3.5-turbo"
        assert request.prompt == "Hello world"
        assert request.add_special_tokens is True

    def test_tokenize_response(self):
        """Test tokenization response."""
        response = TokenizeResponse(
            tokens=[15339, 1917],
            count=2,
            max_model_len=8192
        )
        assert len(response.tokens) == 2
        assert response.count == 2
        assert response.max_model_len == 8192

    def test_detokenize_request(self):
        """Test detokenization request."""
        request = DetokenizeRequest(
            model="gpt-3.5-turbo",
            tokens=[15339, 1917]
        )
        assert len(request.tokens) == 2

    def test_detokenize_response(self):
        """Test detokenization response."""
        response = DetokenizeResponse(text="Hello world")
        assert response.text == "Hello world"


@pytest.mark.unit
class TestClassificationModels:
    """Test classification models."""

    def test_classification_request(self):
        """Test classification request."""
        request = ClassificationRequest(
            model="classifier-model",
            input="This is a test sentence"
        )
        assert request.model == "classifier-model"
        assert request.input == "This is a test sentence"

    def test_classification_response(self):
        """Test classification response."""
        response = ClassificationResponse(
            id="classify-123",
            model="classifier-model",
            predictions=[{"label": "positive", "score": 0.95}]
        )
        assert response.object == "classification"
        assert len(response.predictions) == 1


@pytest.mark.unit
class TestScoringModels:
    """Test scoring/ranking models."""

    def test_score_request(self):
        """Test score request."""
        request = ScoreRequest(
            model="rerank-model",
            query="What is the capital of France?",
            documents=["Paris is the capital", "London is a city", "Berlin is nice"]
        )
        assert request.query == "What is the capital of France?"
        assert len(request.documents) == 3

    def test_score_response(self):
        """Test score response."""
        response = ScoreResponse(
            id="score-123",
            model="rerank-model",
            scores=[0.95, 0.2, 0.1]
        )
        assert response.object == "score"
        assert len(response.scores) == 3
        assert response.scores[0] == 0.95


@pytest.mark.unit
class TestPoolingModels:
    """Test pooling models."""

    def test_pooling_request(self):
        """Test pooling request."""
        request = PoolingRequest(
            model="pooling-model",
            input="Test input",
            pooling_type="mean"
        )
        assert request.pooling_type == "mean"

    def test_pooling_response(self):
        """Test pooling response."""
        response = PoolingResponse(
            id="pool-123",
            model="pooling-model",
            data=[{"pooled": [0.1, 0.2, 0.3]}],
            usage=UsageInfo(prompt_tokens=5)
        )
        assert response.object == "pooling"
        assert len(response.data) == 1


@pytest.mark.unit
class TestBatchModels:
    """Test batch processing models."""

    def test_batch_request(self):
        """Test batch request."""
        request = BatchRequest(
            input_file_id="file-123",
            endpoint="/v1/chat/completions",
            completion_window="24h"
        )
        assert request.input_file_id == "file-123"
        assert request.endpoint == "/v1/chat/completions"

    def test_batch_response(self):
        """Test batch response."""
        response = BatchResponse(
            id="batch-123",
            endpoint="/v1/chat/completions",
            input_file_id="file-123",
            completion_window="24h",
            status="completed",
            output_file_id="file-output-123"
        )
        assert response.object == "batch"
        assert response.status == "completed"
        assert response.output_file_id == "file-output-123"


@pytest.mark.unit
class TestTranscriptionModels:
    """Test audio transcription models."""

    def test_transcription_request(self):
        """Test transcription request."""
        request = TranscriptionRequest(
            file="audio.mp3",
            model="whisper-1",
            language="en",
            temperature=0.0
        )
        assert request.model == "whisper-1"
        assert request.language == "en"
        assert request.response_format == "json"

    def test_transcription_response(self):
        """Test transcription response."""
        response = TranscriptionResponse(text="Hello world")
        assert response.text == "Hello world"

    def test_translation_request(self):
        """Test translation request."""
        request = TranslationRequest(
            file="audio.mp3",
            model="whisper-1"
        )
        assert request.model == "whisper-1"

    def test_translation_response(self):
        """Test translation response."""
        response = TranslationResponse(text="Translated text")
        assert response.text == "Translated text"


@pytest.mark.unit
class TestRerankModels:
    """Test reranking models."""

    def test_rerank_request(self):
        """Test rerank request."""
        request = RerankRequest(
            model="rerank-model",
            query="search query",
            documents=["doc1", "doc2", "doc3"],
            top_n=2
        )
        assert request.query == "search query"
        assert len(request.documents) == 3
        assert request.top_n == 2

    def test_rerank_response(self):
        """Test rerank response."""
        response = RerankResponse(
            id="rerank-123",
            model="rerank-model",
            results=[
                {"index": 0, "score": 0.95},
                {"index": 2, "score": 0.85}
            ]
        )
        assert response.object == "rerank"
        assert len(response.results) == 2


@pytest.mark.unit
class TestLoRAModels:
    """Test LoRA adapter models."""

    def test_load_lora_request(self):
        """Test load LoRA adapter request."""
        request = LoadLoRAAdapterRequest(
            lora_name="my-lora",
            lora_path="/path/to/lora"
        )
        assert request.lora_name == "my-lora"
        assert request.lora_path == "/path/to/lora"

    def test_unload_lora_request(self):
        """Test unload LoRA adapter request."""
        request = UnloadLoRAAdapterRequest(lora_name="my-lora")
        assert request.lora_name == "my-lora"


@pytest.mark.unit
class TestStreamOptions:
    """Test streaming options."""

    def test_stream_options_defaults(self):
        """Test stream options with defaults."""
        options = StreamOptions()
        assert options.include_usage is False
        assert options.continuous_usage_stats is False

    def test_stream_options_enabled(self):
        """Test stream options enabled."""
        options = StreamOptions(
            include_usage=True,
            continuous_usage_stats=True
        )
        assert options.include_usage is True
        assert options.continuous_usage_stats is True
