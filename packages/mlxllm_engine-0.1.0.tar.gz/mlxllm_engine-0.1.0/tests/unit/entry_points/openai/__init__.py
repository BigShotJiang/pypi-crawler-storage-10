# SPDX-License-Identifier: Apache-2.0
"""OpenAI API unit tests."""
