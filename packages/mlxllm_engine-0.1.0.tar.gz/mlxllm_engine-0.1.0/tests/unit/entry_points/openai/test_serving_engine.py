# SPDX-License-Identifier: Apache-2.0
"""Tests for OpenAI serving engine base class."""

from __future__ import annotations

from unittest.mock import AsyncMock, Mock

import pytest

from mlxllm.config import ModelConfig
from mlxllm.entry_points.openai.protocol import ErrorResponse
from mlxllm.entry_points.openai.serving_engine import OpenAIServing
from mlxllm.sampling_params import SamplingParams


@pytest.fixture
def mock_engine_client():
    """Create a mock engine client."""
    client = AsyncMock()
    client.generate = AsyncMock()
    client.get_tokenizer = AsyncMock()
    return client


@pytest.fixture
def mock_model_config():
    """Create a mock model config."""
    config = Mock(spec=ModelConfig)
    config.max_model_len = 8192
    config.model_name = "test-model"
    return config


@pytest.fixture
def serving_instance(mock_engine_client, mock_model_config):
    """Create an OpenAIServing instance for testing."""
    return OpenAIServing(
        engine_client=mock_engine_client,
        model_config=mock_model_config,
        served_model_names=["test-model", "test-model-alias"],
        response_role="assistant"
    )


@pytest.mark.unit
class TestOpenAIServingInit:
    """Test OpenAIServing initialization."""

    def test_init_basic(self, mock_engine_client, mock_model_config):
        """Test basic initialization."""
        serving = OpenAIServing(
            engine_client=mock_engine_client,
            model_config=mock_model_config,
            served_model_names=["test-model"]
        )
        assert serving.engine_client == mock_engine_client
        assert serving.model_config == mock_model_config
        assert serving.served_model_names == ["test-model"]
        assert serving.response_role == "assistant"
        assert serving.max_model_len == 8192

    def test_init_custom_role(self, mock_engine_client, mock_model_config):
        """Test initialization with custom response role."""
        serving = OpenAIServing(
            engine_client=mock_engine_client,
            model_config=mock_model_config,
            served_model_names=["test-model"],
            response_role="bot"
        )
        assert serving.response_role == "bot"

    def test_init_multiple_models(self, mock_engine_client, mock_model_config):
        """Test initialization with multiple model names."""
        model_names = ["model-1", "model-2", "model-alias"]
        serving = OpenAIServing(
            engine_client=mock_engine_client,
            model_config=mock_model_config,
            served_model_names=model_names
        )
        assert serving.served_model_names == model_names


@pytest.mark.unit
class TestErrorResponse:
    """Test error response creation."""

    def test_create_error_response_defaults(self, serving_instance):
        """Test creating error response with defaults."""
        error = serving_instance.create_error_response("Test error")
        assert isinstance(error, ErrorResponse)
        assert error.error.message == "Test error"
        assert error.error.type == "BadRequestError"
        assert error.error.code == "400"

    def test_create_error_response_custom(self, serving_instance):
        """Test creating error response with custom parameters."""
        error = serving_instance.create_error_response(
            message="Custom error",
            err_type="NotFoundError",
            status_code=404
        )
        assert error.error.message == "Custom error"
        assert error.error.type == "NotFoundError"
        assert error.error.code == "404"


@pytest.mark.unit
class TestModelValidation:
    """Test model validation."""

    def test_validate_model_valid(self, serving_instance):
        """Test validation with valid model name."""
        result = serving_instance._validate_model("test-model")
        assert result is None

    def test_validate_model_alias(self, serving_instance):
        """Test validation with model alias."""
        result = serving_instance._validate_model("test-model-alias")
        assert result is None

    def test_validate_model_invalid(self, serving_instance):
        """Test validation with invalid model name."""
        error = serving_instance._validate_model("unknown-model")
        assert isinstance(error, ErrorResponse)
        assert "not found" in error.error.message.lower()
        assert error.error.type == "NotFoundError"
        assert error.error.code == "404"

    def test_validate_model_case_sensitive(self, serving_instance):
        """Test that model validation is case-sensitive."""
        error = serving_instance._validate_model("TEST-MODEL")
        assert isinstance(error, ErrorResponse)


@pytest.mark.unit
class TestPromptLengthValidation:
    """Test prompt length validation."""

    def test_validate_prompt_length_valid(self, serving_instance):
        """Test validation with valid prompt length."""
        result = serving_instance._validate_prompt_length(100)
        assert result is None

    def test_validate_prompt_length_at_limit(self, serving_instance):
        """Test validation with prompt at model limit."""
        error = serving_instance._validate_prompt_length(8192)
        assert isinstance(error, ErrorResponse)
        assert "exceeds maximum" in error.error.message.lower()

    def test_validate_prompt_length_over_limit(self, serving_instance):
        """Test validation with prompt over limit."""
        error = serving_instance._validate_prompt_length(10000)
        assert isinstance(error, ErrorResponse)
        assert "10000" in error.error.message

    def test_validate_prompt_with_max_tokens_valid(self, serving_instance):
        """Test validation with prompt + max_tokens within limit."""
        result = serving_instance._validate_prompt_length(
            prompt_length=100,
            max_tokens=50
        )
        assert result is None

    def test_validate_prompt_with_max_tokens_at_limit(self, serving_instance):
        """Test validation with prompt + max_tokens at limit."""
        result = serving_instance._validate_prompt_length(
            prompt_length=8000,
            max_tokens=192
        )
        assert result is None

    def test_validate_prompt_with_max_tokens_over_limit(self, serving_instance):
        """Test validation with prompt + max_tokens over limit."""
        error = serving_instance._validate_prompt_length(
            prompt_length=8000,
            max_tokens=300
        )
        assert isinstance(error, ErrorResponse)
        assert "max_tokens" in error.error.message.lower()


@pytest.mark.unit
class TestSamplingParamsCreation:
    """Test sampling parameters creation."""

    def test_create_sampling_params_defaults(self, serving_instance):
        """Test creating sampling params with defaults."""
        params = serving_instance.create_sampling_params()
        assert isinstance(params, SamplingParams)
        assert params.temperature == 1.0
        assert params.top_p == 1.0
        assert params.presence_penalty == 0.0
        assert params.frequency_penalty == 0.0

    def test_create_sampling_params_custom(self, serving_instance):
        """Test creating sampling params with custom values."""
        params = serving_instance.create_sampling_params(
            temperature=0.7,
            top_p=0.9,
            max_tokens=100,
            stop=["STOP", "END"],
            presence_penalty=0.5,
            frequency_penalty=0.3,
            seed=42
        )
        assert params.temperature == 0.7
        assert params.top_p == 0.9
        assert params.max_tokens == 100
        assert params.stop == ["STOP", "END"]
        assert params.presence_penalty == 0.5
        assert params.frequency_penalty == 0.3
        assert params.seed == 42

    def test_create_sampling_params_with_logprobs(self, serving_instance):
        """Test creating sampling params with logprobs."""
        params = serving_instance.create_sampling_params(
            logprobs=5
        )
        assert params.logprobs == 5

    def test_create_sampling_params_greedy(self, serving_instance):
        """Test creating greedy sampling params (temperature=0)."""
        params = serving_instance.create_sampling_params(temperature=0.0)
        assert params.temperature == 0.0

    def test_create_sampling_params_with_extra_kwargs(self, serving_instance):
        """Test that extra kwargs are handled gracefully."""
        # Should not raise an error
        params = serving_instance.create_sampling_params(
            temperature=0.8,
            extra_param="ignored"
        )
        assert params.temperature == 0.8


@pytest.mark.unit
class TestServingUtilities:
    """Test utility methods."""

    def test_max_model_len_from_config(self, mock_engine_client):
        """Test that max_model_len is read from config."""
        config = Mock(spec=ModelConfig)
        config.max_model_len = 4096
        serving = OpenAIServing(
            engine_client=mock_engine_client,
            model_config=config,
            served_model_names=["test"]
        )
        assert serving.max_model_len == 4096

    def test_max_model_len_default(self, mock_engine_client):
        """Test default max_model_len when not in config."""
        # Create a simple object without max_model_len attribute
        class ConfigWithoutMaxLen:
            pass

        config = ConfigWithoutMaxLen()
        serving = OpenAIServing(
            engine_client=mock_engine_client,
            model_config=config,
            served_model_names=["test"]
        )
        assert serving.max_model_len == 2048  # Default fallback
