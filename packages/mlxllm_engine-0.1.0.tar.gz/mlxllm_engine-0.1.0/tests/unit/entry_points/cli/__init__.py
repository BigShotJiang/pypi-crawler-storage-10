# SPDX-License-Identifier: Apache-2.0
"""CLI unit tests."""
