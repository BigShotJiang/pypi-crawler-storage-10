# SPDX-License-Identifier: Apache-2.0
"""Tests for CLI main entry point."""

from __future__ import annotations

import argparse
from unittest.mock import Mock, patch

import pytest

from mlxllm.entry_points.cli.types import (
    APIProtocol,
    CLICommand,
    LogLevel,
    QuantizationType,
)


@pytest.mark.unit
class TestCLICommandParsing:
    """Test CLI command parsing."""

    def test_cli_command_enum_values(self):
        """Test that CLI command enum has expected values."""
        assert CLICommand.SERVE.value == "serve"
        assert CLICommand.GENERATE.value == "generate"
        assert CLICommand.CHAT.value == "chat"
        assert CLICommand.BENCHMARK.value == "benchmark"

    def test_api_protocol_enum(self):
        """Test API protocol enum."""
        assert APIProtocol.OPENAI.value == "openai"
        assert APIProtocol.ANTHROPIC.value == "anthropic"

    def test_log_level_enum(self):
        """Test log level enum."""
        assert LogLevel.DEBUG.value == "debug"
        assert LogLevel.INFO.value == "info"
        assert LogLevel.WARNING.value == "warning"
        assert LogLevel.ERROR.value == "error"

    def test_quantization_type_enum(self):
        """Test quantization type enum."""
        assert QuantizationType.Q4_0.value == "q4_0"
        assert QuantizationType.Q8_0.value == "q8_0"
        assert QuantizationType.FP16.value == "fp16"


@pytest.mark.unit
class TestArgumentValidation:
    """Test argument validation functions."""

    def test_model_name_required(self):
        """Test that model name is required for most commands."""
        # Model name should be a required argument
        # This is validated at the argparse level
        pass

    def test_port_range_validation(self):
        """Test port range validation."""
        from mlxllm.entry_points.cli.types import validate_port

        # Valid ports
        assert validate_port("80") == 80
        assert validate_port("8000") == 8000
        assert validate_port("65535") == 65535

        # Invalid ports
        with pytest.raises(argparse.ArgumentTypeError):
            validate_port("0")
        with pytest.raises(argparse.ArgumentTypeError):
            validate_port("65536")
        with pytest.raises(argparse.ArgumentTypeError):
            validate_port("-1")

    def test_positive_int_validation(self):
        """Test positive integer validation."""
        from mlxllm.entry_points.cli.types import validate_positive_int

        assert validate_positive_int("1") == 1
        assert validate_positive_int("100") == 100

        with pytest.raises(argparse.ArgumentTypeError):
            validate_positive_int("0")
        with pytest.raises(argparse.ArgumentTypeError):
            validate_positive_int("-5")

    def test_probability_validation(self):
        """Test probability validation (0.0 to 1.0)."""
        from mlxllm.entry_points.cli.types import validate_probability

        assert validate_probability("0.0") == 0.0
        assert validate_probability("0.5") == 0.5
        assert validate_probability("1.0") == 1.0

        with pytest.raises(argparse.ArgumentTypeError):
            validate_probability("-0.1")
        with pytest.raises(argparse.ArgumentTypeError):
            validate_probability("1.5")


@pytest.mark.unit
class TestCLIDefaults:
    """Test CLI default values."""

    def test_serve_defaults(self):
        """Test default values for serve command."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(model="test-model")
        assert args.host == "0.0.0.0"
        assert args.port == 8000
        assert args.protocol == APIProtocol.OPENAI
        assert args.max_num_seqs == 256
        assert args.block_size == 16
        assert args.gpu_memory_utilization == 0.9

    def test_generate_defaults(self):
        """Test default values for generate command."""
        from mlxllm.entry_points.cli.types import GenerateArgs

        args = GenerateArgs(model="test-model", prompt="test")
        assert args.max_tokens == 128
        assert args.temperature == 1.0
        assert args.top_p == 1.0
        assert args.stream is False

    def test_benchmark_defaults(self):
        """Test default values for benchmark command."""
        from mlxllm.entry_points.cli.types import BenchmarkArgs

        args = BenchmarkArgs(model="test-model")
        assert args.num_prompts == 100
        assert args.prompt_length == 128
        assert args.output_length == 128
        assert args.batch_size == 1


@pytest.mark.unit
class TestLoRAModuleParsing:
    """Test LoRA module parsing."""

    def test_parse_basic_lora_module(self):
        """Test parsing basic LoRA module specification."""
        from mlxllm.entry_points.cli.types import parse_lora_modules

        result = parse_lora_modules("name=my-lora,path=/path/to/lora")
        assert result["name"] == "my-lora"
        assert result["path"] == "/path/to/lora"

    def test_parse_lora_with_base_model(self):
        """Test parsing LoRA module with base model."""
        from mlxllm.entry_points.cli.types import parse_lora_modules

        result = parse_lora_modules(
            "name=my-lora,path=/path/to/lora,base_model_name=llama"
        )
        assert result["name"] == "my-lora"
        assert result["path"] == "/path/to/lora"
        assert result["base_model_name"] == "llama"

    def test_parse_lora_missing_required_fields(self):
        """Test parsing fails without required fields."""
        from mlxllm.entry_points.cli.types import parse_lora_modules

        # Missing path
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_lora_modules("name=my-lora")
        assert "must specify 'name' and 'path'" in str(exc_info.value)

        # Missing name
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_lora_modules("path=/path/to/lora")
        assert "must specify 'name' and 'path'" in str(exc_info.value)


@pytest.mark.unit
class TestKeyValueParsing:
    """Test key-value argument parsing."""

    def test_parse_simple_key_value(self):
        """Test parsing simple key=value."""
        from mlxllm.entry_points.cli.types import parse_key_value_arg

        key, value = parse_key_value_arg("key=value")
        assert key == "key"
        assert value == "value"

    def test_parse_key_value_with_spaces(self):
        """Test parsing key=value with spaces."""
        from mlxllm.entry_points.cli.types import parse_key_value_arg

        key, value = parse_key_value_arg("key = value")
        assert key == "key"
        assert value == "value"

    def test_parse_key_value_with_equals_in_value(self):
        """Test parsing value containing equals sign."""
        from mlxllm.entry_points.cli.types import parse_key_value_arg

        key, value = parse_key_value_arg("url=http://example.com?param=value")
        assert key == "url"
        assert value == "http://example.com?param=value"

    def test_parse_invalid_format(self):
        """Test parsing invalid format."""
        from mlxllm.entry_points.cli.types import parse_key_value_arg

        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_key_value_arg("invalid")
        assert "Invalid format" in str(exc_info.value)


@pytest.mark.unit
class TestFilePathValidation:
    """Test file path validation."""

    def test_validate_existing_file(self, tmp_path):
        """Test validating existing file."""
        from mlxllm.entry_points.cli.types import validate_file_path

        test_file = tmp_path / "test.txt"
        test_file.write_text("test content")

        result = validate_file_path(str(test_file))
        assert result == test_file

    def test_validate_nonexistent_file(self):
        """Test validating non-existent file."""
        from mlxllm.entry_points.cli.types import validate_file_path

        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_file_path("/nonexistent/file.txt")
        assert "File not found" in str(exc_info.value)

    def test_validate_directory_as_file(self, tmp_path):
        """Test validating directory as file fails."""
        from mlxllm.entry_points.cli.types import validate_file_path

        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_file_path(str(tmp_path))
        assert "Not a file" in str(exc_info.value)


@pytest.mark.unit
class TestDirectoryPathValidation:
    """Test directory path validation."""

    def test_validate_existing_directory(self, tmp_path):
        """Test validating existing directory."""
        from mlxllm.entry_points.cli.types import validate_dir_path

        result = validate_dir_path(str(tmp_path))
        assert result == tmp_path

    def test_validate_nonexistent_directory(self, tmp_path):
        """Test validating non-existent directory (should succeed)."""
        from mlxllm.entry_points.cli.types import validate_dir_path

        new_dir = tmp_path / "new_directory"
        result = validate_dir_path(str(new_dir))
        assert result == new_dir

    def test_validate_file_as_directory(self, tmp_path):
        """Test validating file as directory fails."""
        from mlxllm.entry_points.cli.types import validate_dir_path

        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_dir_path(str(test_file))
        assert "Not a directory" in str(exc_info.value)


@pytest.mark.unit
class TestServeArgsCORS:
    """Test CORS configuration in ServeArgs."""

    def test_cors_disabled_by_default(self):
        """Test CORS is disabled by default."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(model="test-model")
        assert args.enable_cors is False

    def test_cors_enabled_with_defaults(self):
        """Test CORS enabled sets default values."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(model="test-model", enable_cors=True)
        assert args.enable_cors is True
        assert args.allowed_origins == ["*"]
        assert args.allowed_methods == ["*"]
        assert args.allowed_headers == ["*"]

    def test_cors_with_custom_values(self):
        """Test CORS with custom configuration."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(
            model="test-model",
            enable_cors=True,
            allowed_origins=["https://example.com"],
            allowed_methods=["GET", "POST"],
            allowed_headers=["Content-Type", "Authorization"]
        )
        assert args.allowed_origins == ["https://example.com"]
        assert args.allowed_methods == ["GET", "POST"]
        assert len(args.allowed_headers) == 2


@pytest.mark.unit
class TestServedModelNameExtraction:
    """Test served model name extraction from model path."""

    def test_extract_model_name_from_simple_path(self):
        """Test extracting model name from simple path."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(model="my-model")
        assert args.served_model_name == ["my-model"]

    def test_extract_model_name_from_hf_path(self):
        """Test extracting model name from HuggingFace path."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(model="meta-llama/Llama-2-7b-hf")
        assert args.served_model_name == ["Llama-2-7b-hf"]

    def test_custom_served_model_name(self):
        """Test providing custom served model name."""
        from mlxllm.entry_points.cli.types import ServeArgs

        args = ServeArgs(
            model="meta-llama/Llama-2-7b-hf",
            served_model_name=["custom-name", "alias"]
        )
        assert args.served_model_name == ["custom-name", "alias"]
