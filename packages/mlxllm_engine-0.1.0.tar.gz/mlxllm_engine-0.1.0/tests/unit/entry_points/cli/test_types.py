# SPDX-License-Identifier: Apache-2.0
"""Tests for CLI types and utilities."""

from __future__ import annotations

import argparse
from pathlib import Path

import pytest

from mlxllm.entry_points.cli.types import (
    APIProtocol,
    BenchmarkArgs,
    CLICommand,
    ChatArgs,
    ConvertArgs,
    EmbedArgs,
    GenerateArgs,
    LogLevel,
    QuantizationType,
    ServeArgs,
    TokenizeArgs,
    parse_key_value_arg,
    parse_lora_modules,
    validate_dir_path,
    validate_file_path,
    validate_non_negative_float,
    validate_port,
    validate_positive_int,
    validate_probability,
)


@pytest.mark.unit
class TestEnums:
    """Test enum definitions."""

    def test_cli_command_values(self):
        """Test CLICommand enum values."""
        assert CLICommand.SERVE.value == "serve"
        assert CLICommand.GENERATE.value == "generate"
        assert CLICommand.CHAT.value == "chat"
        assert CLICommand.EMBED.value == "embed"
        assert CLICommand.TOKENIZE.value == "tokenize"
        assert CLICommand.CONVERT.value == "convert"
        assert CLICommand.BENCHMARK.value == "benchmark"
        assert CLICommand.MODELS.value == "models"

    def test_log_level_values(self):
        """Test LogLevel enum values."""
        assert LogLevel.DEBUG.value == "debug"
        assert LogLevel.INFO.value == "info"
        assert LogLevel.WARNING.value == "warning"
        assert LogLevel.ERROR.value == "error"
        assert LogLevel.CRITICAL.value == "critical"

    def test_quantization_type_values(self):
        """Test QuantizationType enum values."""
        assert QuantizationType.Q4_0.value == "q4_0"
        assert QuantizationType.Q4_1.value == "q4_1"
        assert QuantizationType.Q8_0.value == "q8_0"
        assert QuantizationType.FP16.value == "fp16"
        assert QuantizationType.FP32.value == "fp32"

    def test_api_protocol_values(self):
        """Test APIProtocol enum values."""
        assert APIProtocol.OPENAI.value == "openai"
        assert APIProtocol.ANTHROPIC.value == "anthropic"


@pytest.mark.unit
class TestServeArgs:
    """Test ServeArgs dataclass."""

    def test_minimal_serve_args(self):
        """Test ServeArgs with minimal required parameters."""
        args = ServeArgs(model="test-model")
        assert args.model == "test-model"
        assert args.host == "0.0.0.0"
        assert args.port == 8000
        assert args.protocol == APIProtocol.OPENAI
        assert args.served_model_name == ["test-model"]

    def test_serve_args_with_path_model(self):
        """Test ServeArgs extracts model name from path."""
        args = ServeArgs(model="org/repo/model-name")
        assert args.served_model_name == ["model-name"]

    def test_serve_args_cors_defaults(self):
        """Test CORS default behavior."""
        args = ServeArgs(model="test", enable_cors=True)
        assert args.allowed_origins == ["*"]
        assert args.allowed_methods == ["*"]
        assert args.allowed_headers == ["*"]

    def test_serve_args_cors_custom(self):
        """Test CORS with custom values."""
        args = ServeArgs(
            model="test",
            enable_cors=True,
            allowed_origins=["https://example.com"],
            allowed_methods=["GET", "POST"],
            allowed_headers=["Content-Type"]
        )
        assert args.allowed_origins == ["https://example.com"]
        assert args.allowed_methods == ["GET", "POST"]
        assert args.allowed_headers == ["Content-Type"]

    def test_serve_args_full_config(self):
        """Test ServeArgs with full configuration."""
        args = ServeArgs(
            model="test-model",
            tokenizer="custom-tokenizer",
            revision="main",
            trust_remote_code=True,
            quantization=QuantizationType.Q4_0,
            host="127.0.0.1",
            port=8080,
            protocol=APIProtocol.ANTHROPIC,
            max_model_len=4096,
            max_num_seqs=128,
            gpu_memory_utilization=0.8,
            scheduler_policy="priority"
        )
        assert args.model == "test-model"
        assert args.tokenizer == "custom-tokenizer"
        assert args.quantization == QuantizationType.Q4_0
        assert args.port == 8080
        assert args.max_model_len == 4096


@pytest.mark.unit
class TestGenerateArgs:
    """Test GenerateArgs dataclass."""

    def test_minimal_generate_args(self):
        """Test GenerateArgs with minimal parameters."""
        args = GenerateArgs(model="test-model", prompt="Hello")
        assert args.model == "test-model"
        assert args.prompt == "Hello"
        assert args.max_tokens == 128
        assert args.temperature == 1.0
        assert args.stream is False

    def test_generate_args_full_config(self):
        """Test GenerateArgs with full configuration."""
        args = GenerateArgs(
            model="test-model",
            prompt="Test prompt",
            max_tokens=256,
            temperature=0.7,
            top_p=0.9,
            top_k=50,
            presence_penalty=0.5,
            frequency_penalty=0.3,
            stop=["STOP"],
            seed=42,
            stream=True
        )
        assert args.max_tokens == 256
        assert args.temperature == 0.7
        assert args.seed == 42
        assert args.stream is True


@pytest.mark.unit
class TestChatArgs:
    """Test ChatArgs dataclass."""

    def test_minimal_chat_args(self):
        """Test ChatArgs with minimal parameters."""
        args = ChatArgs(model="test-model")
        assert args.model == "test-model"
        assert args.chat_template is None
        assert args.system_prompt is None

    def test_chat_args_with_system_prompt(self):
        """Test ChatArgs with system prompt."""
        args = ChatArgs(
            model="test-model",
            system_prompt="You are a helpful assistant",
            chat_template="custom-template"
        )
        assert args.system_prompt == "You are a helpful assistant"
        assert args.chat_template == "custom-template"


@pytest.mark.unit
class TestEmbedArgs:
    """Test EmbedArgs dataclass."""

    def test_embed_args_string_input(self):
        """Test EmbedArgs with string input."""
        args = EmbedArgs(model="embed-model", input="Test text")
        assert args.model == "embed-model"
        assert args.input == "Test text"
        assert args.encoding_format == "float"

    def test_embed_args_list_input(self):
        """Test EmbedArgs with list input."""
        args = EmbedArgs(
            model="embed-model",
            input=["Text 1", "Text 2"],
            dimensions=512
        )
        assert isinstance(args.input, list)
        assert len(args.input) == 2
        assert args.dimensions == 512


@pytest.mark.unit
class TestTokenizeArgs:
    """Test TokenizeArgs dataclass."""

    def test_tokenize_args_defaults(self):
        """Test TokenizeArgs with defaults."""
        args = TokenizeArgs(model="test-model", text="Hello world")
        assert args.model == "test-model"
        assert args.text == "Hello world"
        assert args.add_special_tokens is True
        assert args.show_ids is True
        assert args.show_text is False


@pytest.mark.unit
class TestConvertArgs:
    """Test ConvertArgs dataclass."""

    def test_convert_args_minimal(self):
        """Test ConvertArgs with minimal parameters."""
        args = ConvertArgs(model="test-model", output_dir=Path("/tmp/output"))
        assert args.model == "test-model"
        assert args.output_dir == Path("/tmp/output")
        assert args.force is False
        assert args.upload_to_hf is False

    def test_convert_args_with_hf_upload(self):
        """Test ConvertArgs with HuggingFace upload."""
        args = ConvertArgs(
            model="test-model",
            output_dir=Path("/tmp/output"),
            upload_to_hf=True,
            hf_repo_id="org/repo"
        )
        assert args.upload_to_hf is True
        assert args.hf_repo_id == "org/repo"


@pytest.mark.unit
class TestBenchmarkArgs:
    """Test BenchmarkArgs dataclass."""

    def test_benchmark_args_defaults(self):
        """Test BenchmarkArgs with defaults."""
        args = BenchmarkArgs(model="test-model")
        assert args.model == "test-model"
        assert args.num_prompts == 100
        assert args.prompt_length == 128
        assert args.output_length == 128
        assert args.batch_size == 1

    def test_benchmark_args_custom(self):
        """Test BenchmarkArgs with custom values."""
        args = BenchmarkArgs(
            model="test-model",
            num_prompts=500,
            prompt_length=256,
            output_length=512,
            batch_size=8
        )
        assert args.num_prompts == 500
        assert args.prompt_length == 256
        assert args.batch_size == 8


@pytest.mark.unit
class TestParseKeyValueArg:
    """Test parse_key_value_arg function."""

    def test_parse_valid_key_value(self):
        """Test parsing valid key=value."""
        key, value = parse_key_value_arg("key=value")
        assert key == "key"
        assert value == "value"

    def test_parse_key_value_with_spaces(self):
        """Test parsing with spaces."""
        key, value = parse_key_value_arg("key = value with spaces")
        assert key == "key"
        assert value == "value with spaces"

    def test_parse_key_value_with_multiple_equals(self):
        """Test parsing value containing equals sign."""
        key, value = parse_key_value_arg("url=http://example.com?param=value")
        assert key == "url"
        assert value == "http://example.com?param=value"

    def test_parse_invalid_format(self):
        """Test parsing invalid format raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_key_value_arg("invalid_format")
        assert "Invalid format" in str(exc_info.value)


@pytest.mark.unit
class TestParseLoRAModules:
    """Test parse_lora_modules function."""

    def test_parse_basic_lora_module(self):
        """Test parsing basic LoRA module specification."""
        result = parse_lora_modules("name=my-lora,path=/path/to/lora")
        assert result["name"] == "my-lora"
        assert result["path"] == "/path/to/lora"

    def test_parse_lora_module_with_base_model(self):
        """Test parsing LoRA module with base model."""
        result = parse_lora_modules(
            "name=my-lora,path=/path/to/lora,base_model_name=llama"
        )
        assert result["name"] == "my-lora"
        assert result["path"] == "/path/to/lora"
        assert result["base_model_name"] == "llama"

    def test_parse_lora_module_missing_name(self):
        """Test parsing fails without name."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_lora_modules("path=/path/to/lora")
        assert "must specify 'name' and 'path'" in str(exc_info.value)

    def test_parse_lora_module_missing_path(self):
        """Test parsing fails without path."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            parse_lora_modules("name=my-lora")
        assert "must specify 'name' and 'path'" in str(exc_info.value)


@pytest.mark.unit
class TestValidateFilePath:
    """Test validate_file_path function."""

    def test_validate_existing_file(self, tmp_path):
        """Test validating existing file."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        result = validate_file_path(str(test_file))
        assert result == test_file

    def test_validate_nonexistent_file(self):
        """Test validating non-existent file raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_file_path("/nonexistent/file.txt")
        assert "File not found" in str(exc_info.value)

    def test_validate_directory_as_file(self, tmp_path):
        """Test validating directory as file raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_file_path(str(tmp_path))
        assert "Not a file" in str(exc_info.value)


@pytest.mark.unit
class TestValidateDirPath:
    """Test validate_dir_path function."""

    def test_validate_existing_directory(self, tmp_path):
        """Test validating existing directory."""
        result = validate_dir_path(str(tmp_path))
        assert result == tmp_path

    def test_validate_nonexistent_directory(self, tmp_path):
        """Test validating non-existent directory (should succeed)."""
        new_dir = tmp_path / "new_dir"
        result = validate_dir_path(str(new_dir))
        assert result == new_dir

    def test_validate_file_as_directory(self, tmp_path):
        """Test validating file as directory raises error."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_dir_path(str(test_file))
        assert "Not a directory" in str(exc_info.value)


@pytest.mark.unit
class TestValidatePort:
    """Test validate_port function."""

    def test_validate_valid_port(self):
        """Test validating valid port numbers."""
        assert validate_port("8000") == 8000
        assert validate_port("80") == 80
        assert validate_port("443") == 443
        assert validate_port("65535") == 65535

    def test_validate_port_too_low(self):
        """Test validating port below range."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_port("0")
        assert "Invalid port" in str(exc_info.value)

    def test_validate_port_too_high(self):
        """Test validating port above range."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_port("65536")
        assert "Invalid port" in str(exc_info.value)

    def test_validate_port_non_numeric(self):
        """Test validating non-numeric port."""
        with pytest.raises(argparse.ArgumentTypeError):
            validate_port("abc")


@pytest.mark.unit
class TestValidatePositiveInt:
    """Test validate_positive_int function."""

    def test_validate_positive_integers(self):
        """Test validating positive integers."""
        assert validate_positive_int("1") == 1
        assert validate_positive_int("100") == 100
        assert validate_positive_int("999999") == 999999

    def test_validate_zero(self):
        """Test validating zero raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_positive_int("0")
        assert "positive integer" in str(exc_info.value)

    def test_validate_negative(self):
        """Test validating negative raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_positive_int("-5")
        assert "positive integer" in str(exc_info.value)


@pytest.mark.unit
class TestValidateNonNegativeFloat:
    """Test validate_non_negative_float function."""

    def test_validate_non_negative_floats(self):
        """Test validating non-negative floats."""
        assert validate_non_negative_float("0.0") == 0.0
        assert validate_non_negative_float("1.5") == 1.5
        assert validate_non_negative_float("100") == 100.0

    def test_validate_negative_float(self):
        """Test validating negative float raises error."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_non_negative_float("-0.5")
        assert "non-negative" in str(exc_info.value)


@pytest.mark.unit
class TestValidateProbability:
    """Test validate_probability function."""

    def test_validate_valid_probabilities(self):
        """Test validating valid probability values."""
        assert validate_probability("0.0") == 0.0
        assert validate_probability("0.5") == 0.5
        assert validate_probability("1.0") == 1.0

    def test_validate_probability_below_range(self):
        """Test validating probability below 0."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_probability("-0.1")
        assert "between 0.0 and 1.0" in str(exc_info.value)

    def test_validate_probability_above_range(self):
        """Test validating probability above 1."""
        with pytest.raises(argparse.ArgumentTypeError) as exc_info:
            validate_probability("1.5")
        assert "between 0.0 and 1.0" in str(exc_info.value)
