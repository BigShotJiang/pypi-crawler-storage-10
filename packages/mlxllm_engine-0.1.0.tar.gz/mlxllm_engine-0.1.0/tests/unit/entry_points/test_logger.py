# SPDX-License-Identifier: Apache-2.0
"""Tests for request logger."""

from __future__ import annotations

import time
from unittest.mock import Mock

import pytest

from mlxllm.entry_points.logger import RequestLogger


@pytest.fixture
def request_logger():
    """Create a RequestLogger instance."""
    return RequestLogger(enable_debug=False)


@pytest.fixture
def debug_logger():
    """Create a RequestLogger with debug enabled."""
    return RequestLogger(enable_debug=True)


@pytest.fixture
def mock_output():
    """Create a mock RequestOutput."""
    output = Mock()
    output.outputs = [
        Mock(token_ids=[1, 2, 3, 4, 5]),
        Mock(token_ids=[6, 7, 8])
    ]
    return output


@pytest.mark.unit
class TestRequestLoggerInit:
    """Test RequestLogger initialization."""

    def test_init_default(self):
        """Test default initialization."""
        logger = RequestLogger()
        assert logger.enable_debug is False
        assert logger.requests == {}

    def test_init_with_debug(self):
        """Test initialization with debug enabled."""
        logger = RequestLogger(enable_debug=True)
        assert logger.enable_debug is True
        assert logger.requests == {}


@pytest.mark.unit
class TestLogRequestStart:
    """Test logging request start."""

    def test_log_request_start_basic(self, request_logger):
        """Test logging basic request start."""
        request_logger.log_request_start("test-123")

        assert "test-123" in request_logger.requests
        assert "start_time" in request_logger.requests["test-123"]
        assert request_logger.requests["test-123"]["prompt"] is None
        assert request_logger.requests["test-123"]["prompt_length"] is None

    def test_log_request_start_with_prompt(self, request_logger):
        """Test logging request start with prompt."""
        request_logger.log_request_start(
            "test-123",
            prompt="Test prompt",
            prompt_token_ids=[1, 2, 3, 4, 5]
        )

        assert request_logger.requests["test-123"]["prompt"] == "Test prompt"
        assert request_logger.requests["test-123"]["prompt_length"] == 5

    def test_log_request_start_with_token_ids(self, request_logger):
        """Test logging request start with token IDs only."""
        token_ids = [10, 20, 30]
        request_logger.log_request_start(
            "test-456",
            prompt_token_ids=token_ids
        )

        assert request_logger.requests["test-456"]["prompt_length"] == 3

    def test_log_request_start_timing(self, request_logger):
        """Test request start timing is recorded."""
        before = time.time()
        request_logger.log_request_start("test-789")
        after = time.time()

        start_time = request_logger.requests["test-789"]["start_time"]
        assert before <= start_time <= after

    def test_log_multiple_requests(self, request_logger):
        """Test logging multiple requests simultaneously."""
        request_logger.log_request_start("req-1")
        request_logger.log_request_start("req-2")
        request_logger.log_request_start("req-3")

        assert len(request_logger.requests) == 3
        assert "req-1" in request_logger.requests
        assert "req-2" in request_logger.requests
        assert "req-3" in request_logger.requests


@pytest.mark.unit
class TestLogRequestEnd:
    """Test logging request end."""

    def test_log_request_end_success(self, request_logger, mock_output):
        """Test logging successful request completion."""
        request_logger.log_request_start("test-123", prompt_token_ids=[1, 2, 3])

        # Sleep briefly to ensure duration > 0
        time.sleep(0.01)

        request_logger.log_request_end("test-123", output=mock_output)

        # Request should be cleaned up
        assert "test-123" not in request_logger.requests

    def test_log_request_end_error(self, request_logger):
        """Test logging failed request."""
        request_logger.log_request_start("test-456")

        error = ValueError("Test error")
        request_logger.log_request_end("test-456", error=error)

        # Request should be cleaned up
        assert "test-456" not in request_logger.requests

    def test_log_request_end_without_output(self, request_logger):
        """Test logging request end without output."""
        request_logger.log_request_start("test-789")
        request_logger.log_request_end("test-789")

        assert "test-789" not in request_logger.requests

    def test_log_request_end_unknown_request(self, request_logger, caplog):
        """Test logging end for unknown request."""
        request_logger.log_request_end("unknown-req")

        # Should log a warning
        assert any("not found" in record.message for record in caplog.records)

    def test_log_request_end_calculates_duration(self, request_logger):
        """Test that duration is calculated correctly."""
        request_logger.log_request_start("test-duration")
        start_time = request_logger.requests["test-duration"]["start_time"]

        time.sleep(0.05)  # Sleep 50ms

        # Duration should be at least 50ms
        end_time = time.time()
        duration = end_time - start_time
        assert duration >= 0.05

        request_logger.log_request_end("test-duration")


@pytest.mark.unit
class TestRequestLoggerDebugMode:
    """Test RequestLogger debug mode."""

    def test_debug_mode_logs_start(self, debug_logger, caplog):
        """Test debug mode logs request start."""
        import logging
        caplog.set_level(logging.DEBUG)

        debug_logger.log_request_start("debug-test")

        # Should have debug log
        assert any("started at" in record.message for record in caplog.records)

    def test_debug_mode_logs_output(self, debug_logger, mock_output, caplog):
        """Test debug mode logs output."""
        import logging
        caplog.set_level(logging.DEBUG)

        # Need to provide prompt_token_ids for proper token counting
        debug_logger.log_request_start("debug-test", prompt_token_ids=[1, 2, 3])
        debug_logger.log_request_end("debug-test", output=mock_output)

        # Should have debug log with output
        assert any("output" in record.message.lower() for record in caplog.records)

    def test_non_debug_mode_no_debug_logs(self, request_logger, caplog):
        """Test non-debug mode doesn't log debug messages."""
        import logging
        caplog.set_level(logging.DEBUG)

        request_logger.log_request_start("test")
        request_logger.log_request_end("test")

        # Should not have "started at" debug messages
        debug_messages = [r for r in caplog.records if r.levelname == "DEBUG"]
        start_messages = [r for r in debug_messages if "started at" in r.message]
        assert len(start_messages) == 0


@pytest.mark.unit
class TestRequestLoggerTokenCounting:
    """Test token counting in request logger."""

    def test_count_prompt_tokens(self, request_logger):
        """Test counting prompt tokens."""
        token_ids = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        request_logger.log_request_start("test", prompt_token_ids=token_ids)

        assert request_logger.requests["test"]["prompt_length"] == 10

    def test_count_completion_tokens(self, request_logger, mock_output):
        """Test counting completion tokens."""
        request_logger.log_request_start("test", prompt_token_ids=[1, 2, 3])
        request_logger.log_request_end("test", output=mock_output)

        # mock_output has outputs with 5 and 3 tokens = 8 total

    def test_empty_prompt_tokens(self, request_logger):
        """Test handling empty prompt tokens."""
        request_logger.log_request_start("test", prompt_token_ids=[])

        # Empty list evaluates to False, so None is returned
        # This is correct behavior since empty list is falsy
        assert request_logger.requests["test"]["prompt_length"] is None


@pytest.mark.unit
class TestRequestLoggerCleanup:
    """Test request logger cleanup behavior."""

    def test_cleanup_after_success(self, request_logger, mock_output):
        """Test requests are cleaned up after success."""
        request_logger.log_request_start("test-1", prompt_token_ids=[1, 2, 3])
        request_logger.log_request_start("test-2", prompt_token_ids=[4, 5])

        assert len(request_logger.requests) == 2

        request_logger.log_request_end("test-1", output=mock_output)

        assert len(request_logger.requests) == 1
        assert "test-1" not in request_logger.requests
        assert "test-2" in request_logger.requests

    def test_cleanup_after_error(self, request_logger):
        """Test requests are cleaned up after error."""
        request_logger.log_request_start("test")

        request_logger.log_request_end("test", error=Exception("Failed"))

        assert "test" not in request_logger.requests

    def test_no_memory_leak_with_many_requests(self, request_logger, mock_output):
        """Test no memory leak with many requests."""
        for i in range(100):
            request_id = f"req-{i}"
            request_logger.log_request_start(request_id, prompt_token_ids=[1, 2, 3])
            request_logger.log_request_end(request_id, output=mock_output)

        # All requests should be cleaned up
        assert len(request_logger.requests) == 0
