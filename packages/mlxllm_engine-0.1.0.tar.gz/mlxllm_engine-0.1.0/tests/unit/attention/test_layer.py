# SPDX-License-Identifier: Apache-2.0
"""Tests for main attention layer."""

from __future__ import annotations

import mlx.core as mx

from mlxllm.attention.layer import Attention, AttentionConfig, PagedAttention
from mlxllm.attention.backends.abstract import AttentionBackend, AttentionMetadata, AttentionType


class MockAttentionBackend(AttentionBackend):
    """Mock backend for testing."""

    def __init__(self):
        self.prefill_calls = 0
        self.decode_calls = 0
        self.update_calls = 0

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        self.prefill_calls += 1
        # Return query reshaped to match expected output
        batch, seq_len, num_heads, head_dim = query.shape
        return query

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        self.decode_calls += 1
        return query

    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        self.update_calls += 1

    def get_supported_head_sizes(self) -> list[int]:
        return [64, 128, 256]

    def get_name(self) -> str:
        return "mock"

    @classmethod
    def is_available(cls) -> bool:
        return True


class TestAttentionConfig:
    """Test AttentionConfig dataclass."""

    def test_attention_config_creation(self):
        """Test creating attention configuration."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )

        assert config.num_heads == 32
        assert config.num_kv_heads == 8
        assert config.head_dim == 128
        assert config.hidden_size == 4096

    def test_attention_config_with_defaults(self):
        """Test default values in attention config."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=64,
            hidden_size=2048,
        )

        assert config.max_position_embeddings == 8192
        assert config.rope_theta == 10000.0
        assert config.rope_scaling is None
        assert config.sliding_window is None
        assert config.attention_bias is False

    def test_attention_config_with_sliding_window(self):
        """Test attention config with sliding window."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=64,
            hidden_size=2048,
            sliding_window=512,
        )

        assert config.sliding_window == 512

    def test_attention_config_with_rope_scaling(self):
        """Test attention config with RoPE scaling."""
        rope_scaling = {"type": "linear", "factor": 2.0}
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=64,
            hidden_size=2048,
            rope_scaling=rope_scaling,
        )

        assert config.rope_scaling == rope_scaling

    def test_attention_config_with_bias(self):
        """Test attention config with bias enabled."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=64,
            hidden_size=2048,
            attention_bias=True,
        )

        assert config.attention_bias is True


class TestAttentionInitialization:
    """Test Attention layer initialization."""

    def test_attention_layer_creation(self):
        """Test creating attention layer."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        assert layer.num_heads == 8
        assert layer.num_kv_heads == 8
        assert layer.head_dim == 64
        assert layer.hidden_size == 512

    def test_attention_qkv_projection_size(self):
        """Test QKV projection has correct size."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        # q_size + 2 * kv_size
        expected_qkv_size = (32 * 128) + 2 * (8 * 128)
        assert layer.qkv_proj.weight.shape[0] == expected_qkv_size

    def test_attention_output_projection_size(self):
        """Test output projection has correct size."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        assert layer.o_proj.weight.shape[0] == 4096
        assert layer.o_proj.weight.shape[1] == 32 * 128

    def test_attention_scale_computed(self):
        """Test attention scale is computed correctly."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        expected_scale = 1.0 / (64**0.5)
        assert abs(layer.scale - expected_scale) < 1e-6

    def test_attention_with_gqa(self):
        """Test attention layer with GQA (grouped query attention)."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=8,  # 4:1 ratio
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        assert layer.num_heads == 32
        assert layer.num_kv_heads == 8
        assert layer.q_size == 32 * 128
        assert layer.kv_size == 8 * 128

    def test_attention_with_mqa(self):
        """Test attention layer with MQA (multi-query attention)."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=1,  # Single KV head
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()

        layer = Attention(config, backend)

        assert layer.num_heads == 32
        assert layer.num_kv_heads == 1
        assert layer.kv_size == 128


class TestAttentionForwardPrefill:
    """Test Attention forward pass in prefill mode."""

    def test_attention_forward_prefill_shape(self):
        """Test attention forward in prefill produces correct output shape."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size, seq_len = 2, 10
        hidden_states = mx.random.normal((batch_size * seq_len, config.hidden_size))
        positions = mx.tile(mx.arange(seq_len), batch_size)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len, seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = batch_size

        output = layer.forward(hidden_states, positions, None, metadata)

        assert output.shape == (batch_size * seq_len, config.hidden_size)

    def test_attention_prefill_calls_backend(self):
        """Test that prefill mode calls backend prefill_attention."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size, seq_len = 1, 10
        hidden_states = mx.random.normal((batch_size * seq_len, config.hidden_size))
        positions = mx.arange(seq_len)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = batch_size

        layer.forward(hidden_states, positions, None, metadata)

        assert backend.prefill_calls == 1
        assert backend.decode_calls == 0

    def test_attention_prefill_with_gqa(self):
        """Test prefill with Grouped Query Attention."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size, seq_len = 1, 16
        num_tokens = batch_size * seq_len
        hidden_states = mx.random.normal((num_tokens, config.hidden_size))
        positions = mx.arange(seq_len)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = batch_size

        output = layer.forward(hidden_states, positions, None, metadata)

        assert output.shape == (num_tokens, config.hidden_size)


class TestAttentionForwardDecode:
    """Test Attention forward pass in decode mode."""

    def test_attention_forward_decode_shape(self):
        """Test attention forward in decode produces correct output shape."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size = 2
        hidden_states = mx.random.normal((batch_size, config.hidden_size))
        positions = mx.array([10, 10])  # Current position for each sequence

        # Create KV cache
        num_blocks = 4
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[11, 11],
            max_seq_len=11,
            block_tables=[[0, 1], [2, 3]],
            context_lens=[10, 10],
            slot_mapping=[(0, 10), (2, 10)],
        )
        metadata.is_prefill = False

        output = layer.forward(hidden_states, positions, kv_cache, metadata)

        assert output.shape == (batch_size, config.hidden_size)

    def test_attention_decode_calls_backend(self):
        """Test that decode mode calls backend decode_attention."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size = 1
        hidden_states = mx.random.normal((batch_size, config.hidden_size))
        positions = mx.array([5])

        num_blocks = 2
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[6],
            max_seq_len=6,
            block_tables=[[0, 1]],
            context_lens=[5],
            slot_mapping=[(0, 5)],
        )
        metadata.is_prefill = False

        layer.forward(hidden_states, positions, kv_cache, metadata)

        assert backend.decode_calls == 1
        assert backend.prefill_calls == 0

    def test_attention_decode_updates_kv_cache(self):
        """Test that decode mode updates KV cache."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size = 1
        hidden_states = mx.random.normal((batch_size, config.hidden_size))
        positions = mx.array([5])

        num_blocks = 2
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[6],
            max_seq_len=6,
            block_tables=[[0, 1]],
            context_lens=[5],
            slot_mapping=[(0, 5)],
        )
        metadata.is_prefill = False

        layer.forward(hidden_states, positions, kv_cache, metadata)

        assert backend.update_calls == 1


class TestPagedAttention:
    """Test PagedAttention layer (decode-only variant)."""

    def test_paged_attention_creation(self):
        """Test creating paged attention layer."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()

        layer = PagedAttention(config, backend)

        assert layer.num_heads == 8
        assert layer.num_kv_heads == 8
        assert layer.head_dim == 64

    def test_paged_attention_forward_shape(self):
        """Test paged attention forward output shape."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()
        layer = PagedAttention(config, backend)

        batch_size = 2
        hidden_states = mx.random.normal((batch_size, config.hidden_size))
        positions = mx.array([10, 15])

        num_blocks = 4
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[11, 16],
            max_seq_len=16,
            block_tables=[[0, 1], [2, 3]],
            context_lens=[10, 15],
            slot_mapping=[(0, 10), (2, 15)],
        )

        output = layer.forward(hidden_states, positions, kv_cache, metadata)

        assert output.shape == (batch_size, config.hidden_size)

    def test_paged_attention_with_gqa(self):
        """Test paged attention with GQA."""
        config = AttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )
        backend = MockAttentionBackend()
        layer = PagedAttention(config, backend)

        batch_size = 1
        hidden_states = mx.random.normal((batch_size, config.hidden_size))
        positions = mx.array([20])

        num_blocks = 4
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[21],
            max_seq_len=21,
            block_tables=[[0, 1, 2]],
            context_lens=[20],
            slot_mapping=[(2, 4)],
        )

        output = layer.forward(hidden_states, positions, kv_cache, metadata)

        assert output.shape == (batch_size, config.hidden_size)


class TestAttentionWithRotary:
    """Test attention with rotary embeddings."""

    def test_attention_applies_rotary(self):
        """Test that attention applies rotary embeddings."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        # The layer should have rotary_emb attribute
        assert hasattr(layer, "rotary_emb")

    def test_attention_rotary_with_positions(self):
        """Test rotary embeddings with position indices."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size, seq_len = 1, 10
        hidden_states = mx.random.normal((batch_size * seq_len, config.hidden_size))
        positions = mx.arange(seq_len)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = batch_size

        # Should not raise
        output = layer.forward(hidden_states, positions, None, metadata)
        assert output is not None


class TestAttentionEdgeCases:
    """Test edge cases in attention."""

    def test_attention_single_token(self):
        """Test attention with single token (decode scenario)."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        hidden_states = mx.random.normal((1, config.hidden_size))
        positions = mx.array([0])

        num_blocks = 1
        block_size = 16
        kv_cache = mx.random.normal(
            (num_blocks, 2, block_size, config.num_kv_heads, config.head_dim)
        )

        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[1],
            max_seq_len=1,
            block_tables=[[0]],
            context_lens=[0],
            slot_mapping=[(0, 0)],
        )
        metadata.is_prefill = False

        output = layer.forward(hidden_states, positions, kv_cache, metadata)

        assert output.shape == (1, config.hidden_size)

    def test_attention_long_sequence(self):
        """Test attention with long sequence."""
        config = AttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        batch_size, seq_len = 1, 1024
        hidden_states = mx.random.normal((batch_size * seq_len, config.hidden_size))
        positions = mx.arange(seq_len)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = batch_size

        output = layer.forward(hidden_states, positions, None, metadata)

        assert output.shape == (batch_size * seq_len, config.hidden_size)

    def test_attention_batch_size_one(self):
        """Test attention with batch size of 1."""
        config = AttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = MockAttentionBackend()
        layer = Attention(config, backend)

        seq_len = 16
        hidden_states = mx.random.normal((seq_len, config.hidden_size))
        positions = mx.arange(seq_len)

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len],
            max_seq_len=seq_len,
        )
        metadata.is_prefill = True
        metadata.batch_size = 1

        output = layer.forward(hidden_states, positions, None, metadata)

        assert output.shape == (seq_len, config.hidden_size)
