# SPDX-License-Identifier: Apache-2.0
"""Tests for attention backend utilities."""

from __future__ import annotations

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.attention.backends.abstract import AttentionMetadata, AttentionType
from mlxllm.attention.backends.utils import (
    PAD_SLOT_ID,
    apply_alibi_bias,
    compute_attention_scale,
    create_alibi_slopes,
    create_block_tables_from_seq_lens,
    create_causal_mask,
    create_slot_mapping,
    get_num_kv_heads_per_query_head,
    repeat_kv,
    validate_metadata,
)


class TestComputeAttentionScale:
    """Test compute_attention_scale function."""

    def test_default_scale(self):
        """Test default scale is 1/sqrt(head_dim)."""
        scale = compute_attention_scale(head_dim=64)
        expected = 1.0 / (64**0.5)
        assert abs(scale - expected) < 1e-6

    def test_custom_scale(self):
        """Test that custom scale is used when provided."""
        custom_scale = 0.25
        scale = compute_attention_scale(head_dim=128, scale=custom_scale)
        assert scale == custom_scale

    @pytest.mark.parametrize("head_dim", [64, 80, 96, 112, 128, 256])
    def test_various_head_dims(self, head_dim: int):
        """Test scale computation for various head dimensions."""
        scale = compute_attention_scale(head_dim=head_dim)
        expected = 1.0 / (head_dim**0.5)
        assert abs(scale - expected) < 1e-6


class TestRepeatKV:
    """Test repeat_kv function for Grouped Query Attention."""

    def test_no_repeat_when_n_rep_is_1(self):
        """Test that input is returned unchanged when n_rep=1."""
        x = mx.random.normal((2, 10, 8, 64))
        result = repeat_kv(x, n_rep=1)
        assert mx.array_equal(result, x)

    def test_repeat_2x(self):
        """Test repeating KV heads 2x."""
        batch, seq_len, num_kv_heads, head_dim = 2, 10, 4, 64
        x = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(x, n_rep=2)

        assert result.shape == (batch, seq_len, num_kv_heads * 2, head_dim)

        # Check that values are correctly repeated
        for h in range(num_kv_heads):
            assert mx.array_equal(result[:, :, h * 2, :], x[:, :, h, :])
            assert mx.array_equal(result[:, :, h * 2 + 1, :], x[:, :, h, :])

    def test_repeat_4x(self):
        """Test repeating KV heads 4x."""
        batch, seq_len, num_kv_heads, head_dim = 1, 5, 2, 128
        x = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(x, n_rep=4)

        assert result.shape == (batch, seq_len, num_kv_heads * 4, head_dim)

        # Each KV head should be repeated 4 times
        for h in range(num_kv_heads):
            for r in range(4):
                assert mx.array_equal(result[:, :, h * 4 + r, :], x[:, :, h, :])

    def test_repeat_8x_for_mqa(self):
        """Test MQA scenario with single KV head repeated 8x."""
        batch, seq_len, num_kv_heads, head_dim = 1, 10, 1, 64
        x = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(x, n_rep=8)

        assert result.shape == (batch, seq_len, 8, head_dim)

        # All 8 heads should be identical
        for h in range(8):
            assert mx.array_equal(result[:, :, h, :], x[:, :, 0, :])


class TestCreateCausalMask:
    """Test create_causal_mask function."""

    def test_causal_mask_shape(self):
        """Test that causal mask has correct shape."""
        seq_len = 10
        mask = create_causal_mask(seq_len)
        assert mask.shape == (seq_len, seq_len)

    def test_causal_mask_is_lower_triangular(self):
        """Test that causal mask is lower triangular (can attend to past)."""
        seq_len = 5
        mask = create_causal_mask(seq_len)

        # Convert to numpy for easier checking
        mask_np = np.array(mask)

        # Upper triangle (future tokens) should be -inf
        for i in range(seq_len):
            for j in range(i + 1, seq_len):
                assert mask_np[i, j] == float("-inf")

        # Lower triangle and diagonal should be 0
        for i in range(seq_len):
            for j in range(i + 1):
                assert mask_np[i, j] == 0.0

    def test_causal_mask_dtype(self):
        """Test causal mask data type."""
        mask_float32 = create_causal_mask(5, dtype=mx.float32)
        assert mask_float32.dtype == mx.float32

        mask_float16 = create_causal_mask(5, dtype=mx.float16)
        assert mask_float16.dtype == mx.float16


class TestCreateAlibiSlopes:
    """Test create_alibi_slopes for ALiBi positional encoding."""

    def test_alibi_slopes_shape(self):
        """Test that ALiBi slopes have correct shape."""
        num_heads = 8
        slopes = create_alibi_slopes(num_heads)
        assert slopes.shape == (num_heads,)

    def test_alibi_slopes_power_of_2(self):
        """Test ALiBi slopes for power-of-2 number of heads."""
        num_heads = 8
        slopes = create_alibi_slopes(num_heads)

        # Slopes should be geometric sequence
        slopes_np = np.array(slopes)
        assert len(slopes_np) == num_heads
        assert all(slopes_np > 0)  # All slopes should be positive

    def test_alibi_slopes_non_power_of_2(self):
        """Test ALiBi slopes for non-power-of-2 number of heads."""
        num_heads = 12
        slopes = create_alibi_slopes(num_heads)

        assert slopes.shape == (num_heads,)
        assert all(np.array(slopes) > 0)

    @pytest.mark.parametrize("num_heads", [1, 2, 4, 8, 16, 32])
    def test_alibi_slopes_various_sizes(self, num_heads: int):
        """Test ALiBi slopes for various head counts."""
        slopes = create_alibi_slopes(num_heads)
        assert slopes.shape == (num_heads,)
        assert slopes.dtype == mx.float32


class TestApplyAlibiBias:
    """Test apply_alibi_bias function."""

    def test_alibi_bias_shape(self):
        """Test that ALiBi bias has correct output shape."""
        batch, num_heads, seq_len_q, seq_len_k = 2, 8, 10, 10
        attn_scores = mx.zeros((batch, num_heads, seq_len_q, seq_len_k))
        alibi_slopes = create_alibi_slopes(num_heads)

        result = apply_alibi_bias(attn_scores, alibi_slopes, seq_len_q, seq_len_k)

        assert result.shape == attn_scores.shape

    def test_alibi_bias_adds_position_penalty(self):
        """Test that ALiBi bias penalizes distant positions."""
        batch, num_heads, seq_len = 1, 4, 5
        attn_scores = mx.zeros((batch, num_heads, seq_len, seq_len))
        alibi_slopes = create_alibi_slopes(num_heads)

        result = apply_alibi_bias(attn_scores, alibi_slopes, seq_len, seq_len)
        result_np = np.array(result[0, 0])  # First batch, first head

        # For causal attention, closer tokens should have less penalty
        # Position (i, i) should have 0 bias
        for i in range(seq_len):
            assert abs(result_np[i, i]) < 1e-5

        # Future tokens should have negative bias
        for i in range(seq_len - 1):
            assert result_np[i, i + 1] < 0

    def test_alibi_bias_preserves_causality(self):
        """Test that ALiBi bias maintains causal structure."""
        batch, num_heads, seq_len = 1, 8, 10
        attn_scores = mx.zeros((batch, num_heads, seq_len, seq_len))
        alibi_slopes = create_alibi_slopes(num_heads)

        result = apply_alibi_bias(attn_scores, alibi_slopes, seq_len, seq_len)

        # Bias should be monotonically decreasing as we look further ahead
        result_np = np.array(result[0, 0])
        for i in range(seq_len):
            for j in range(i + 1, seq_len):
                # Further positions should have more negative bias
                assert result_np[i, j] < result_np[i, j - 1] + 1e-5


class TestValidateMetadata:
    """Test validate_metadata function."""

    def test_valid_prefill_metadata(self):
        """Test that valid prefill metadata passes validation."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[10, 20],
            max_seq_len=20,
        )
        # Should not raise
        validate_metadata(metadata)

    def test_empty_seq_lens_raises(self):
        """Test that empty seq_lens raises ValueError."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[],
            max_seq_len=0,
        )
        with pytest.raises(ValueError, match="seq_lens cannot be empty"):
            validate_metadata(metadata)

    def test_max_seq_len_mismatch_raises(self):
        """Test that incorrect max_seq_len raises ValueError."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[10, 20, 15],
            max_seq_len=25,  # Should be 20
        )
        with pytest.raises(ValueError, match="max_seq_len.*doesn't match"):
            validate_metadata(metadata)

    def test_decode_missing_context_lens_raises(self):
        """Test that decode metadata without context_lens raises."""
        with pytest.raises(ValueError, match="context_lens required"):
            AttentionMetadata(
                attn_type=AttentionType.DECODE,
                seq_lens=[5],
                max_seq_len=5,
                block_tables=[[0]],
            )

    def test_decode_context_lens_length_mismatch_raises(self):
        """Test that mismatched context_lens length raises."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[5, 10],
            max_seq_len=10,
            block_tables=[[0], [1, 2]],
            context_lens=[5],  # Should have 2 elements
        )
        with pytest.raises(ValueError, match="context_lens length.*doesn't match"):
            validate_metadata(metadata)

    def test_gqa_head_count_validation(self):
        """Test that GQA head count validation works."""
        # Valid: num_query_heads divisible by num_kv_heads
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[5],
            max_seq_len=5,
            num_query_heads=32,
            num_kv_heads=8,  # 32/8 = 4, valid
        )
        validate_metadata(metadata)  # Should not raise

        # Invalid: not divisible
        metadata_invalid = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[5],
            max_seq_len=5,
            num_query_heads=32,
            num_kv_heads=7,  # 32/7 not integer
        )
        with pytest.raises(ValueError, match="must be divisible"):
            validate_metadata(metadata_invalid)

    def test_head_dim_warning(self):
        """Test that non-standard head_dim produces warning."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[5],
            max_seq_len=5,
            head_dim=100,  # Not in standard sizes
        )
        with pytest.warns(UserWarning, match="may not be optimized"):
            validate_metadata(metadata)


class TestGetNumKVHeadsPerQueryHead:
    """Test get_num_kv_heads_per_query_head function."""

    def test_mha_returns_1(self):
        """Test Multi-Head Attention (MHA) returns 1."""
        result = get_num_kv_heads_per_query_head(
            num_query_heads=32, num_kv_heads=32
        )
        assert result == 1

    def test_gqa_returns_correct_ratio(self):
        """Test Grouped Query Attention returns correct ratio."""
        result = get_num_kv_heads_per_query_head(
            num_query_heads=32, num_kv_heads=8
        )
        assert result == 4

    def test_mqa_returns_num_heads(self):
        """Test Multi-Query Attention returns number of heads."""
        result = get_num_kv_heads_per_query_head(num_query_heads=32, num_kv_heads=1)
        assert result == 32

    def test_not_divisible_raises(self):
        """Test that non-divisible heads raises ValueError."""
        with pytest.raises(ValueError, match="must be divisible"):
            get_num_kv_heads_per_query_head(
                num_query_heads=32, num_kv_heads=7
            )


class TestCreateBlockTablesFromSeqLens:
    """Test create_block_tables_from_seq_lens function."""

    def test_single_sequence(self):
        """Test creating block tables for single sequence."""
        seq_lens = [32]
        block_size = 16
        num_blocks = 10

        block_tables = create_block_tables_from_seq_lens(
            seq_lens, block_size, num_blocks
        )

        # 32 tokens / 16 block_size = 2 blocks needed
        assert len(block_tables) == 1
        assert block_tables[0] == [0, 1]

    def test_multiple_sequences(self):
        """Test creating block tables for multiple sequences."""
        seq_lens = [16, 24, 8]
        block_size = 16
        num_blocks = 10

        block_tables = create_block_tables_from_seq_lens(
            seq_lens, block_size, num_blocks
        )

        assert len(block_tables) == 3
        # First sequence: 16 tokens = 1 block
        assert block_tables[0] == [0]
        # Second sequence: 24 tokens = 2 blocks
        assert block_tables[1] == [1, 2]
        # Third sequence: 8 tokens = 1 block
        assert block_tables[2] == [3]

    def test_sequence_not_aligned_to_block_size(self):
        """Test sequences that don't align to block size."""
        seq_lens = [17]  # Needs 2 blocks (17 / 16 = 1.06)
        block_size = 16
        num_blocks = 10

        block_tables = create_block_tables_from_seq_lens(
            seq_lens, block_size, num_blocks
        )

        assert block_tables[0] == [0, 1]

    def test_insufficient_blocks_raises(self):
        """Test that insufficient blocks raises ValueError."""
        seq_lens = [32, 32]  # Need 4 blocks total
        block_size = 16
        num_blocks = 3  # Not enough

        with pytest.raises(ValueError, match="Not enough blocks"):
            create_block_tables_from_seq_lens(seq_lens, block_size, num_blocks)

    def test_empty_sequences(self):
        """Test handling of empty sequence list."""
        seq_lens = []
        block_size = 16
        num_blocks = 10

        block_tables = create_block_tables_from_seq_lens(
            seq_lens, block_size, num_blocks
        )

        assert block_tables == []


class TestCreateSlotMapping:
    """Test create_slot_mapping function."""

    def test_single_sequence_single_block(self):
        """Test slot mapping for single sequence in one block."""
        seq_lens = [8]
        block_tables = [[0]]
        block_size = 16

        slot_mapping = create_slot_mapping(seq_lens, block_tables, block_size)

        # 8 tokens, all in block 0
        assert len(slot_mapping) == 8
        for i in range(8):
            assert slot_mapping[i] == (0, i)

    def test_single_sequence_multiple_blocks(self):
        """Test slot mapping for sequence spanning multiple blocks."""
        seq_lens = [24]
        block_tables = [[0, 1]]
        block_size = 16

        slot_mapping = create_slot_mapping(seq_lens, block_tables, block_size)

        assert len(slot_mapping) == 24
        # First 16 tokens in block 0
        for i in range(16):
            assert slot_mapping[i] == (0, i)
        # Remaining 8 tokens in block 1
        for i in range(16, 24):
            assert slot_mapping[i] == (1, i - 16)

    def test_multiple_sequences(self):
        """Test slot mapping for multiple sequences."""
        seq_lens = [16, 8]
        block_tables = [[0, 1], [2]]
        block_size = 16

        slot_mapping = create_slot_mapping(seq_lens, block_tables, block_size)

        assert len(slot_mapping) == 24  # 16 + 8

        # First sequence: 16 tokens in blocks 0, 1
        for i in range(16):
            if i < 16:
                assert slot_mapping[i] == (0, i)

        # Second sequence: 8 tokens in block 2
        for i in range(16, 24):
            assert slot_mapping[i] == (2, i - 16)

    def test_padding_positions(self):
        """Test that overflow positions get PAD_SLOT_ID."""
        seq_lens = [20]  # 20 tokens
        block_tables = [[0]]  # Only 1 block of size 16
        block_size = 16

        slot_mapping = create_slot_mapping(seq_lens, block_tables, block_size)

        # First 16 positions map to block 0
        for i in range(16):
            assert slot_mapping[i] == (0, i)

        # Remaining 4 positions should be padding
        for i in range(16, 20):
            assert slot_mapping[i] == (PAD_SLOT_ID, 0)

    def test_empty_sequences(self):
        """Test handling empty sequences."""
        seq_lens = []
        block_tables = []
        block_size = 16

        slot_mapping = create_slot_mapping(seq_lens, block_tables, block_size)

        assert slot_mapping == []


class TestPadSlotId:
    """Test PAD_SLOT_ID constant."""

    def test_pad_slot_id_is_negative(self):
        """Test that PAD_SLOT_ID is -1."""
        assert PAD_SLOT_ID == -1
