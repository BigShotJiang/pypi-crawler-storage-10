# SPDX-License-Identifier: Apache-2.0
"""Tests for logits processor."""

from __future__ import annotations

import mlx.core as mx
import pytest

from mlxllm.attention.layers.logits_processor import (
    FrequencyPenaltyLogitsProcessor,
    LogitsProcessor,
    PresencePenaltyLogitsProcessor,
    RepetitionPenaltyLogitsProcessor,
    TemperatureLogitsProcessor,
    TopKLogitsProcessor,
    TopPLogitsProcessor,
)


class TestLogitsProcessor:
    """Test logits processor."""

    def test_module_exists(self):
        """Test that logits_processor module can be imported."""
        try:
            from mlxllm.attention.layers import logits_processor  # noqa: F401

            assert True
        except ImportError:
            pytest.fail("logits_processor module should exist")

    def test_logits_processor_forward(self):
        """Test logits processor forward pass."""
        # Base LogitsProcessor should raise NotImplementedError
        processor = LogitsProcessor()
        logits = mx.random.normal((100,))

        with pytest.raises(NotImplementedError):
            processor(logits)

    def test_temperature_scaling(self):
        """Test temperature scaling."""
        # Create test logits
        logits = mx.array([1.0, 2.0, 3.0, 4.0])

        # Test temperature = 1.0 (no change)
        processor = TemperatureLogitsProcessor(temperature=1.0)
        result = processor(logits)
        assert mx.allclose(result, logits)

        # Test temperature = 2.0 (divide by 2)
        processor = TemperatureLogitsProcessor(temperature=2.0)
        result = processor(logits)
        expected = logits / 2.0
        assert mx.allclose(result, expected)

        # Test temperature = 0.5 (multiply by 2)
        processor = TemperatureLogitsProcessor(temperature=0.5)
        result = processor(logits)
        expected = logits / 0.5
        assert mx.allclose(result, expected)

        # Test invalid temperature
        with pytest.raises(ValueError):
            TemperatureLogitsProcessor(temperature=0.0)

        with pytest.raises(ValueError):
            TemperatureLogitsProcessor(temperature=-1.0)

    def test_top_k_filtering(self):
        """Test top-k filtering."""
        # Create test logits
        logits = mx.array([1.0, 5.0, 2.0, 8.0, 3.0])

        # Test top-k = 2
        processor = TopKLogitsProcessor(top_k=2)
        result = processor(logits)

        # Should keep only top 2 values (8.0 and 5.0)
        # Others should be -inf
        assert result[3] == 8.0  # Highest value
        assert result[1] == 5.0  # Second highest value
        assert mx.isinf(result[0]) and result[0] < 0  # Should be -inf
        assert mx.isinf(result[2]) and result[2] < 0  # Should be -inf
        assert mx.isinf(result[4]) and result[4] < 0  # Should be -inf

        # Test top-k larger than vocab size
        processor = TopKLogitsProcessor(top_k=10)
        result = processor(logits)
        assert mx.allclose(result, logits)

        # Test invalid top_k
        with pytest.raises(ValueError):
            TopKLogitsProcessor(top_k=0)

        with pytest.raises(ValueError):
            TopKLogitsProcessor(top_k=-1)

    def test_top_p_filtering(self):
        """Test top-p (nucleus) filtering."""
        # Create test logits with known probabilities
        # After softmax, we want controlled cumulative probabilities
        logits = mx.array([10.0, 5.0, 1.0, 0.5, 0.1])

        # Test top-p = 0.9
        processor = TopPLogitsProcessor(top_p=0.9)
        result = processor(logits)

        # Should keep tokens until cumulative probability exceeds 0.9
        # At least the highest probability token should be kept
        assert not mx.isinf(result[0])

        # Test top-p = 1.0 (keep all)
        processor = TopPLogitsProcessor(top_p=1.0)
        result = processor(logits)
        # All tokens should be kept (no -inf values)
        assert not mx.any(mx.isinf(result))

        # Test invalid top_p
        with pytest.raises(ValueError):
            TopPLogitsProcessor(top_p=0.0)

        with pytest.raises(ValueError):
            TopPLogitsProcessor(top_p=1.5)

        with pytest.raises(ValueError):
            TopPLogitsProcessor(top_p=-0.5)

    def test_repetition_penalty(self):
        """Test repetition penalty."""
        # Create test logits
        logits = mx.array([1.0, 2.0, 3.0, -1.0, -2.0])
        generated_tokens = [0, 2, 4]  # Tokens that have been generated

        # Test penalty = 1.2
        processor = RepetitionPenaltyLogitsProcessor(penalty=1.2)
        result = processor(logits, generated_tokens)

        # Token 0 (positive logit): should be divided by 1.2
        assert mx.allclose(result[0], mx.array(1.0 / 1.2))

        # Token 1 (not in generated): should be unchanged
        assert mx.allclose(result[1], mx.array(2.0))

        # Token 2 (positive logit): should be divided by 1.2
        assert mx.allclose(result[2], mx.array(3.0 / 1.2))

        # Token 4 (negative logit): should be multiplied by 1.2
        assert mx.allclose(result[4], mx.array(-2.0 * 1.2))

        # Test penalty = 1.0 (no change)
        processor = RepetitionPenaltyLogitsProcessor(penalty=1.0)
        result = processor(logits, generated_tokens)
        assert mx.allclose(result, logits)

        # Test with no generated tokens
        processor = RepetitionPenaltyLogitsProcessor(penalty=1.5)
        result = processor(logits, [])
        assert mx.allclose(result, logits)

        # Test invalid penalty
        with pytest.raises(ValueError):
            RepetitionPenaltyLogitsProcessor(penalty=0.0)

        with pytest.raises(ValueError):
            RepetitionPenaltyLogitsProcessor(penalty=-1.0)

    def test_frequency_penalty(self):
        """Test frequency penalty."""
        # Create test logits
        logits = mx.array([5.0, 4.0, 3.0, 2.0, 1.0])
        # Token 0 appears 3 times, token 2 appears 2 times, token 4 appears 1 time
        generated_tokens = [0, 0, 0, 2, 2, 4]

        # Test penalty = 0.5
        processor = FrequencyPenaltyLogitsProcessor(penalty=0.5)
        result = processor(logits, generated_tokens)

        # Token 0: penalty = 3 * 0.5 = 1.5
        assert mx.allclose(result[0], mx.array(5.0 - 1.5))

        # Token 1: not in generated, no penalty
        assert mx.allclose(result[1], mx.array(4.0))

        # Token 2: penalty = 2 * 0.5 = 1.0
        assert mx.allclose(result[2], mx.array(3.0 - 1.0))

        # Token 4: penalty = 1 * 0.5 = 0.5
        assert mx.allclose(result[4], mx.array(1.0 - 0.5))

        # Test penalty = 0.0 (no change)
        processor = FrequencyPenaltyLogitsProcessor(penalty=0.0)
        result = processor(logits, generated_tokens)
        assert mx.allclose(result, logits)

        # Test with no generated tokens
        processor = FrequencyPenaltyLogitsProcessor(penalty=1.0)
        result = processor(logits, [])
        assert mx.allclose(result, logits)

    def test_presence_penalty(self):
        """Test presence penalty."""
        # Create test logits
        logits = mx.array([5.0, 4.0, 3.0, 2.0, 1.0])
        # Tokens 0, 2, 4 have appeared (frequency doesn't matter)
        generated_tokens = [0, 0, 0, 2, 4]

        # Test penalty = 1.0
        processor = PresencePenaltyLogitsProcessor(penalty=1.0)
        result = processor(logits, generated_tokens)

        # Token 0: appeared, penalty = 1.0
        assert mx.allclose(result[0], mx.array(5.0 - 1.0))

        # Token 1: not appeared, no penalty
        assert mx.allclose(result[1], mx.array(4.0))

        # Token 2: appeared, penalty = 1.0
        assert mx.allclose(result[2], mx.array(3.0 - 1.0))

        # Token 3: not appeared, no penalty
        assert mx.allclose(result[3], mx.array(2.0))

        # Token 4: appeared, penalty = 1.0
        assert mx.allclose(result[4], mx.array(1.0 - 1.0))

        # Test penalty = 0.0 (no change)
        processor = PresencePenaltyLogitsProcessor(penalty=0.0)
        result = processor(logits, generated_tokens)
        assert mx.allclose(result, logits)

        # Test with no generated tokens
        processor = PresencePenaltyLogitsProcessor(penalty=1.0)
        result = processor(logits, [])
        assert mx.allclose(result, logits)
