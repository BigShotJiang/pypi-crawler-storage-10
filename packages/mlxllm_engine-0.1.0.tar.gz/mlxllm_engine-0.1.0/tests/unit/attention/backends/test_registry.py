# SPDX-License-Identifier: Apache-2.0
"""Tests for attention backend registry."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.attention.backends.abstract import AttentionBackend, AttentionMetadata
from mlxllm.attention.backends.registry import (
    _BACKEND_REGISTRY,
    create_backend,
    get_available_backends,
    get_backend,
    register_backend,
)


class MockBackend(AttentionBackend):
    """Mock backend for testing."""

    def __init__(self):
        self.name = "mock"

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        return query

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        return query

    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        pass

    def get_supported_head_sizes(self) -> list[int]:
        return [64, 128, 256]

    def get_name(self) -> str:
        return self.name

    @classmethod
    def is_available(cls) -> bool:
        return True


class UnavailableBackend(AttentionBackend):
    """Mock backend that's not available."""

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        return query

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        return query

    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        pass

    def get_supported_head_sizes(self) -> list[int]:
        return [128]

    def get_name(self) -> str:
        return "unavailable"

    @classmethod
    def is_available(cls) -> bool:
        return False


class TestBackendRegistry:
    """Test backend registration system."""

    def test_builtin_backends_registered(self):
        """Test that built-in backends are registered."""
        backends = get_available_backends()
        assert "metal" in backends
        assert "flash_metal" in backends

    def test_register_custom_backend(self):
        """Test registering a custom backend."""
        # Save original registry
        original_backends = _BACKEND_REGISTRY.copy()

        try:
            register_backend("custom_test", MockBackend)
            backends = get_available_backends()
            assert "custom_test" in backends
        finally:
            # Restore original registry
            _BACKEND_REGISTRY.clear()
            _BACKEND_REGISTRY.update(original_backends)

    def test_register_backend_must_inherit_from_attention_backend(self):
        """Test that registering non-backend class raises TypeError."""

        class NotABackend:
            pass

        with pytest.raises(TypeError, match="must inherit from AttentionBackend"):
            register_backend("invalid", NotABackend)  # type: ignore

    def test_get_backend_by_name(self):
        """Test retrieving backend by name."""
        backend_cls = get_backend("metal")
        assert issubclass(backend_cls, AttentionBackend)

    def test_get_backend_unknown_name_raises(self):
        """Test that getting unknown backend raises ValueError."""
        with pytest.raises(ValueError, match="Unknown attention backend"):
            get_backend("nonexistent_backend")

    def test_get_backend_error_message_lists_available(self):
        """Test that error message lists available backends."""
        with pytest.raises(ValueError) as exc_info:
            get_backend("invalid")

        error_msg = str(exc_info.value)
        assert "Available backends" in error_msg
        assert "metal" in error_msg

    def test_get_available_backends_returns_list(self):
        """Test that get_available_backends returns a list."""
        backends = get_available_backends()
        assert isinstance(backends, list)
        assert len(backends) > 0


class TestBackendCreation:
    """Test backend instance creation."""

    def test_create_metal_backend(self):
        """Test creating Metal backend instance."""
        backend = create_backend("metal")
        assert isinstance(backend, AttentionBackend)
        assert backend.get_name() == "metal"

    def test_create_flash_metal_backend(self):
        """Test creating Flash Metal backend instance."""
        backend = create_backend("flash_metal")
        assert isinstance(backend, AttentionBackend)
        assert backend.get_name() == "flash_metal"

    @pytest.mark.skipif(
        not hasattr(mx, "metal") or mx.metal.is_available is False,
        reason="Metal not available",
    )
    def test_create_backend_auto_selects_flash_metal(self):
        """Test that auto mode selects flash_metal on Apple Silicon."""
        backend = create_backend("auto")
        assert backend.get_name() in ["flash_metal", "metal"]

    def test_create_unavailable_backend_raises(self):
        """Test that creating unavailable backend raises RuntimeError."""
        # Save original registry
        original_backends = _BACKEND_REGISTRY.copy()

        try:
            # Register unavailable backend
            register_backend("unavailable_test", UnavailableBackend)

            with pytest.raises(RuntimeError, match="is not available"):
                create_backend("unavailable_test")
        finally:
            # Restore registry
            _BACKEND_REGISTRY.clear()
            _BACKEND_REGISTRY.update(original_backends)

    def test_create_backend_checks_availability(self):
        """Test that create_backend checks is_available()."""
        # Save original registry
        original_backends = _BACKEND_REGISTRY.copy()

        try:
            register_backend("mock_test", MockBackend)
            backend = create_backend("mock_test")
            assert backend.is_available()
        finally:
            _BACKEND_REGISTRY.clear()
            _BACKEND_REGISTRY.update(original_backends)


class TestBackendValidation:
    """Test backend validation and type checking."""

    def test_backend_has_required_methods(self):
        """Test that backends have all required methods."""
        backend = create_backend("metal")

        # Check all abstract methods are implemented
        assert callable(getattr(backend, "prefill_attention", None))
        assert callable(getattr(backend, "decode_attention", None))
        assert callable(getattr(backend, "update_kv_cache", None))
        assert callable(getattr(backend, "get_supported_head_sizes", None))
        assert callable(getattr(backend, "get_name", None))
        assert callable(getattr(backend.__class__, "is_available", None))

    def test_backend_get_supported_head_sizes_returns_list(self):
        """Test that get_supported_head_sizes returns list of ints."""
        backend = create_backend("metal")
        head_sizes = backend.get_supported_head_sizes()

        assert isinstance(head_sizes, list)
        assert len(head_sizes) > 0
        assert all(isinstance(size, int) for size in head_sizes)

    def test_backend_is_available_returns_bool(self):
        """Test that is_available returns boolean."""
        backend_cls = get_backend("metal")
        result = backend_cls.is_available()
        assert isinstance(result, bool)

    def test_metal_backend_supports_standard_head_sizes(self):
        """Test that Metal backend supports standard head sizes."""
        backend = create_backend("metal")
        head_sizes = backend.get_supported_head_sizes()

        # Should support common head dimensions
        common_sizes = {64, 128, 256}
        assert common_sizes.issubset(set(head_sizes))

    def test_backend_name_is_string(self):
        """Test that backend name is a string."""
        backend = create_backend("metal")
        name = backend.get_name()
        assert isinstance(name, str)
        assert len(name) > 0


class TestRegistryIsolation:
    """Test that registry changes don't affect other tests."""

    def test_registry_modifications_are_local(self):
        """Test that registry can be safely modified and restored."""
        original_backends = get_available_backends()

        # Save and modify registry
        original_registry = _BACKEND_REGISTRY.copy()

        try:
            register_backend("temp_backend", MockBackend)
            assert "temp_backend" in get_available_backends()
        finally:
            # Restore
            _BACKEND_REGISTRY.clear()
            _BACKEND_REGISTRY.update(original_registry)

        # Verify restoration
        restored_backends = get_available_backends()
        assert set(original_backends) == set(restored_backends)
        assert "temp_backend" not in restored_backends


class TestBackendAutoSelection:
    """Test automatic backend selection logic."""

    def test_auto_backend_selection(self):
        """Test that auto backend selection works."""
        try:
            backend = create_backend("auto")
            assert backend is not None
            assert isinstance(backend, AttentionBackend)
        except RuntimeError as e:
            # It's okay if no backend is available on this platform
            assert "No attention backend available" in str(e)

    def test_auto_prefers_flash_metal_over_metal(self):
        """Test that auto selection prefers flash_metal if available."""
        try:
            backend = create_backend("auto")
            # If Metal is available, flash_metal should be preferred
            if backend.get_name() in ["metal", "flash_metal"]:
                # This is expected - either is fine
                assert True
        except RuntimeError:
            # No Metal available, that's okay for this test
            pytest.skip("Metal not available on this platform")


class TestBackendLifecycle:
    """Test backend instantiation and lifecycle."""

    def test_backend_can_be_instantiated_multiple_times(self):
        """Test that same backend can be created multiple times."""
        backend1 = create_backend("metal")
        backend2 = create_backend("metal")

        assert backend1.get_name() == backend2.get_name()
        # They should be different instances
        assert backend1 is not backend2

    def test_backends_are_independent(self):
        """Test that different backend instances are independent."""
        # Save original registry
        original_backends = _BACKEND_REGISTRY.copy()

        try:
            register_backend("mock1", MockBackend)
            register_backend("mock2", MockBackend)

            backend1 = create_backend("mock1")
            backend2 = create_backend("mock2")

            # Different instances
            assert backend1 is not backend2
        finally:
            _BACKEND_REGISTRY.clear()
            _BACKEND_REGISTRY.update(original_backends)
