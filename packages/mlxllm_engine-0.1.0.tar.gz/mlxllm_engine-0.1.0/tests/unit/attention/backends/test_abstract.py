# SPDX-License-Identifier: Apache-2.0
"""Tests for attention backend abstract base classes."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.attention.backends.abstract import (
    AttentionBackend,
    AttentionMetadata,
    AttentionType,
)


class TestAttentionType:
    """Test AttentionType enum."""

    def test_attention_type_values(self):
        """Test that AttentionType has all required values."""
        assert AttentionType.PREFILL.value == "prefill"
        assert AttentionType.DECODE.value == "decode"
        assert AttentionType.CHUNKED_PREFILL.value == "chunked_prefill"

    def test_attention_type_members(self):
        """Test that all expected members exist."""
        members = {member.name for member in AttentionType}
        assert members == {"PREFILL", "DECODE", "CHUNKED_PREFILL"}


class TestAttentionMetadata:
    """Test AttentionMetadata dataclass."""

    def test_minimal_prefill_metadata(self):
        """Test creating metadata for prefill with minimal fields."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[10, 20],
            max_seq_len=20,
        )

        assert metadata.attn_type == AttentionType.PREFILL
        assert metadata.seq_lens == [10, 20]
        assert metadata.max_seq_len == 20
        assert metadata.block_tables is None
        assert metadata.context_lens is None

    def test_decode_metadata_with_required_fields(self):
        """Test creating metadata for decode with required fields."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.DECODE,
            seq_lens=[5, 10],
            max_seq_len=10,
            block_tables=[[0, 1], [2, 3, 4]],
            context_lens=[5, 10],
        )

        assert metadata.attn_type == AttentionType.DECODE
        assert metadata.block_tables == [[0, 1], [2, 3, 4]]
        assert metadata.context_lens == [5, 10]

    def test_decode_metadata_missing_context_lens_raises(self):
        """Test that decode metadata without context_lens raises ValueError."""
        with pytest.raises(ValueError, match="context_lens required"):
            AttentionMetadata(
                attn_type=AttentionType.DECODE,
                seq_lens=[5],
                max_seq_len=5,
                block_tables=[[0]],
            )

    def test_decode_metadata_missing_block_tables_raises(self):
        """Test that decode metadata without block_tables raises ValueError."""
        with pytest.raises(ValueError, match="block_tables required"):
            AttentionMetadata(
                attn_type=AttentionType.DECODE,
                seq_lens=[5],
                max_seq_len=5,
                context_lens=[5],
            )

    def test_metadata_with_all_optional_fields(self):
        """Test metadata with all optional fields populated."""
        attn_mask = mx.zeros((10, 10))
        alibi_slopes = mx.array([1.0, 0.5, 0.25, 0.125])

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[10],
            max_seq_len=10,
            block_tables=[[0, 1]],
            context_lens=[5],
            slot_mapping=[(0, 0), (0, 1)],
            attn_mask=attn_mask,
            num_query_heads=32,
            num_kv_heads=8,
            head_dim=128,
            block_size=16,
            scale=0.125,
            alibi_slopes=alibi_slopes,
        )

        assert metadata.num_query_heads == 32
        assert metadata.num_kv_heads == 8
        assert metadata.head_dim == 128
        assert metadata.block_size == 16
        assert metadata.scale == 0.125
        assert metadata.slot_mapping == [(0, 0), (0, 1)]
        assert mx.array_equal(metadata.attn_mask, attn_mask)
        assert mx.array_equal(metadata.alibi_slopes, alibi_slopes)

    def test_default_values(self):
        """Test that defaults are set correctly."""
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[5],
            max_seq_len=5,
        )

        assert metadata.num_query_heads == 0
        assert metadata.num_kv_heads == 0
        assert metadata.head_dim == 0
        assert metadata.block_size == 16
        assert metadata.scale == 1.0


class TestAttentionBackend:
    """Test AttentionBackend abstract base class."""

    def test_cannot_instantiate_abstract_backend(self):
        """Test that AttentionBackend cannot be instantiated directly."""
        with pytest.raises(TypeError):
            AttentionBackend()  # type: ignore

    def test_concrete_backend_must_implement_all_methods(self):
        """Test that concrete backend must implement all abstract methods."""

        class IncompleteBackend(AttentionBackend):
            """Incomplete backend missing some methods."""

            def get_name(self) -> str:
                return "incomplete"

        with pytest.raises(TypeError):
            IncompleteBackend()  # type: ignore

    def test_concrete_backend_with_all_methods(self):
        """Test creating a concrete backend with all required methods."""

        class CompleteBackend(AttentionBackend):
            """Complete backend implementation."""

            def prefill_attention(
                self,
                query: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                return query

            def decode_attention(
                self,
                query: mx.array,
                kv_cache: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                return query

            def update_kv_cache(
                self,
                kv_cache: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> None:
                pass

            def get_supported_head_sizes(self) -> list[int]:
                return [64, 128, 256]

            def get_name(self) -> str:
                return "complete"

            @classmethod
            def is_available(cls) -> bool:
                return True

        # Should be able to instantiate
        backend = CompleteBackend()
        assert backend.get_name() == "complete"
        assert backend.is_available()
        assert backend.get_supported_head_sizes() == [64, 128, 256]

    def test_backend_repr(self):
        """Test backend string representation."""

        class TestBackend(AttentionBackend):
            """Test backend for repr."""

            def prefill_attention(
                self,
                query: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                return query

            def decode_attention(
                self,
                query: mx.array,
                kv_cache: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                return query

            def update_kv_cache(
                self,
                kv_cache: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> None:
                pass

            def get_supported_head_sizes(self) -> list[int]:
                return [128]

            def get_name(self) -> str:
                return "test_backend"

            @classmethod
            def is_available(cls) -> bool:
                return True

        backend = TestBackend()
        repr_str = repr(backend)
        assert "TestBackend" in repr_str
        assert "test_backend" in repr_str

    def test_prefill_attention_not_implemented(self):
        """Test that unimplemented prefill_attention raises NotImplementedError."""

        class PartialBackend(AttentionBackend):
            """Backend with only some methods implemented."""

            def decode_attention(
                self,
                query: mx.array,
                kv_cache: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                return query

            def update_kv_cache(
                self,
                kv_cache: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> None:
                pass

            def get_supported_head_sizes(self) -> list[int]:
                return [128]

            def get_name(self) -> str:
                return "partial"

            @classmethod
            def is_available(cls) -> bool:
                return True

            def prefill_attention(
                self,
                query: mx.array,
                key: mx.array,
                value: mx.array,
                metadata: AttentionMetadata,
            ) -> mx.array:
                # Call parent to trigger NotImplementedError
                return super().prefill_attention(query, key, value, metadata)

        backend = PartialBackend()
        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[5],
            max_seq_len=5,
        )
        query = mx.zeros((1, 5, 8, 64))
        key = mx.zeros((1, 5, 8, 64))
        value = mx.zeros((1, 5, 8, 64))

        with pytest.raises(NotImplementedError):
            backend.prefill_attention(query, key, value, metadata)
