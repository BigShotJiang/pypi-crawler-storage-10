# SPDX-License-Identifier: Apache-2.0
"""Tests for encoder-only attention."""

from __future__ import annotations

import mlx.core as mx
import numpy as np

from mlxllm.attention.layers.encoder_only_attention import (
    EncoderOnlyAttention,
    EncoderAttentionConfig,
    BidirectionalAttentionWithALiBi,
    FlashEncoderAttention,
)


class TestEncoderAttentionConfig:
    """Test EncoderAttentionConfig."""

    def test_config_creation(self):
        """Test creating config with required fields."""
        config = EncoderAttentionConfig(
            num_heads=12,
            head_dim=64,
            hidden_size=768,
        )

        assert config.num_heads == 12
        assert config.head_dim == 64
        assert config.hidden_size == 768
        assert config.dropout == 0.1
        assert config.attention_bias is True

    def test_config_with_relative_position(self):
        """Test config with relative position embeddings."""
        config = EncoderAttentionConfig(
            num_heads=12,
            head_dim=64,
            hidden_size=768,
            use_relative_position=True,
        )

        assert config.use_relative_position is True


class TestEncoderOnlyAttentionInitialization:
    """Test EncoderOnlyAttention initialization."""

    def test_layer_creation(self):
        """Test creating encoder attention layer."""
        config = EncoderAttentionConfig(
            num_heads=12,
            head_dim=64,
            hidden_size=768,
        )

        layer = EncoderOnlyAttention(config)

        assert layer.num_heads == 12
        assert layer.head_dim == 64
        assert layer.hidden_size == 768
        assert layer.embed_dim == 12 * 64

    def test_layer_with_relative_position(self):
        """Test layer with relative position embeddings."""
        config = EncoderAttentionConfig(
            num_heads=12,
            head_dim=64,
            hidden_size=768,
            use_relative_position=True,
        )

        layer = EncoderOnlyAttention(config)

        assert layer.use_relative_position is True


class TestEncoderOnlyAttentionForward:
    """Test EncoderOnlyAttention forward pass."""

    def test_forward_basic(self):
        """Test basic bidirectional forward pass."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 2
        seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 512))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_forward_with_attention_mask(self):
        """Test forward pass with attention mask."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 1
        seq_len = 10

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        attention_mask = mx.ones((batch_size, seq_len))

        output = layer(hidden_states, attention_mask=attention_mask)

        assert output.shape == (batch_size, seq_len, 256)

    def test_forward_returns_attention_weights(self):
        """Test that attention weights can be returned."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 1
        seq_len = 10

        hidden_states = mx.random.normal((batch_size, seq_len, 256))

        output, attn_weights = layer(
            hidden_states, return_attention_weights=True
        )

        assert output.shape == (batch_size, seq_len, 256)
        assert attn_weights.shape == (batch_size, 4, seq_len, seq_len)

    def test_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 2
        seq_len = 15

        hidden_states = mx.random.normal((batch_size, seq_len, 512))

        output = layer(hidden_states)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestBidirectionalAttentionWithALiBi:
    """Test BidirectionalAttentionWithALiBi."""

    def test_layer_creation(self):
        """Test creating encoder attention with ALiBi."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        layer = BidirectionalAttentionWithALiBi(config)

        assert layer.num_heads == 8
        assert layer.alibi_slopes.shape == (8,)

    def test_forward_with_alibi(self):
        """Test forward pass with ALiBi bias."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = BidirectionalAttentionWithALiBi(config)

        batch_size = 2
        seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 256))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 256)

    def test_alibi_slopes_are_positive(self):
        """Test that ALiBi slopes are positive."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = BidirectionalAttentionWithALiBi(config)

        slopes_np = np.array(layer.alibi_slopes)
        assert np.all(slopes_np > 0)


class TestFlashEncoderAttention:
    """Test FlashEncoderAttention."""

    def test_layer_creation(self):
        """Test creating flash encoder attention."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        layer = FlashEncoderAttention(config)

        assert layer.num_heads == 8
        assert layer.head_dim == 64

    def test_forward_basic(self):
        """Test forward pass (may fall back to standard attention)."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = FlashEncoderAttention(config)

        batch_size = 2
        seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 256))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 256)

    def test_forward_with_mask(self):
        """Test forward with attention mask."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = FlashEncoderAttention(config)

        batch_size = 1
        seq_len = 10

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        attention_mask = mx.ones((batch_size, seq_len))

        output = layer(hidden_states, attention_mask=attention_mask)

        assert output.shape == (batch_size, seq_len, 256)


class TestEncoderAttentionEdgeCases:
    """Test edge cases for encoder attention."""

    def test_single_token(self):
        """Test with single token sequence."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 1
        seq_len = 1

        hidden_states = mx.random.normal((batch_size, seq_len, 512))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_long_sequence(self):
        """Test with long sequence."""
        config = EncoderAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 1
        seq_len = 512

        hidden_states = mx.random.normal((batch_size, seq_len, 512))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_large_batch(self):
        """Test with large batch size."""
        config = EncoderAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = EncoderOnlyAttention(config)

        batch_size = 16
        seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 256))

        output = layer(hidden_states)

        assert output.shape == (batch_size, seq_len, 256)
