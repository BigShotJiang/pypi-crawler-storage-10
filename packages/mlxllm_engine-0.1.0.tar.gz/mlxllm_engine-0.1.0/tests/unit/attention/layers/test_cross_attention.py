# SPDX-License-Identifier: Apache-2.0
"""Tests for cross-attention."""

from __future__ import annotations

import mlx.core as mx
import numpy as np

from mlxllm.attention.layers.cross_attention import (
    CrossAttention,
    CrossAttentionConfig,
    MultiModalCrossAttention,
    PerceiverCrossAttention,
)


class TestCrossAttentionConfig:
    """Test CrossAttentionConfig."""

    def test_config_creation(self):
        """Test creating config with required fields."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        assert config.num_heads == 8
        assert config.head_dim == 64
        assert config.hidden_size == 512
        assert config.encoder_hidden_size is None
        assert config.dropout == 0.0
        assert config.attention_bias is True

    def test_config_with_different_encoder_size(self):
        """Test config with different encoder hidden size."""
        config = CrossAttentionConfig(
            num_heads=16,
            head_dim=64,
            hidden_size=1024,
            encoder_hidden_size=768,
        )

        assert config.encoder_hidden_size == 768

    def test_config_with_custom_dropout(self):
        """Test config with custom dropout."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
            dropout=0.1,
        )

        assert config.dropout == 0.1


class TestCrossAttentionInitialization:
    """Test CrossAttention initialization."""

    def test_layer_creation(self):
        """Test creating cross-attention layer."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        layer = CrossAttention(config)

        assert layer.num_heads == 8
        assert layer.head_dim == 64
        assert layer.hidden_size == 512
        assert layer.encoder_hidden_size == 512

    def test_layer_with_different_encoder_size(self):
        """Test layer with different encoder hidden size."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
            encoder_hidden_size=768,
        )

        layer = CrossAttention(config)

        assert layer.encoder_hidden_size == 768

    def test_embed_dim_calculation(self):
        """Test that embed_dim is calculated correctly."""
        config = CrossAttentionConfig(
            num_heads=16,
            head_dim=64,
            hidden_size=1024,
        )

        layer = CrossAttention(config)

        assert layer.embed_dim == 16 * 64  # num_heads * head_dim


class TestCrossAttentionForward:
    """Test CrossAttention forward pass."""

    def test_forward_basic(self):
        """Test basic forward pass."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = CrossAttention(config)

        batch_size = 2
        seq_len = 10
        enc_seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 512))
        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 512))

        output = layer(hidden_states, encoder_hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_forward_with_encoder_mask(self):
        """Test forward pass with encoder attention mask."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = CrossAttention(config)

        batch_size = 1
        seq_len = 5
        enc_seq_len = 10

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 256))
        encoder_mask = mx.ones((batch_size, enc_seq_len))

        output = layer(
            hidden_states, encoder_hidden_states, encoder_attention_mask=encoder_mask
        )

        assert output.shape == (batch_size, seq_len, 256)

    def test_forward_different_encoder_size(self):
        """Test forward with different encoder hidden size."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
            encoder_hidden_size=768,
        )
        layer = CrossAttention(config)

        batch_size = 2
        seq_len = 10
        enc_seq_len = 15

        hidden_states = mx.random.normal((batch_size, seq_len, 512))
        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 768))

        output = layer(hidden_states, encoder_hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = CrossAttention(config)

        batch_size = 2
        seq_len = 10
        enc_seq_len = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 256))

        output = layer(hidden_states, encoder_hidden_states)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestMultiModalCrossAttention:
    """Test MultiModalCrossAttention."""

    def test_creation(self):
        """Test creating multimodal cross-attention."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        layer = MultiModalCrossAttention(config, num_modalities=2)

        assert layer.num_modalities == 2
        assert len(layer.cross_attentions) == 2

    def test_forward_multiple_modalities(self):
        """Test forward pass with multiple encoder modalities."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )

        layer = MultiModalCrossAttention(config, num_modalities=2)

        batch_size = 1
        seq_len = 10
        enc_seq_len_1 = 15
        enc_seq_len_2 = 20

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        encoder_states_1 = mx.random.normal((batch_size, enc_seq_len_1, 256))
        encoder_states_2 = mx.random.normal((batch_size, enc_seq_len_2, 256))

        output = layer(hidden_states, [encoder_states_1, encoder_states_2])

        assert output.shape == (batch_size, seq_len, 256)

    def test_forward_with_gating(self):
        """Test forward pass with gating mechanism."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )

        layer = MultiModalCrossAttention(config, num_modalities=2, use_gating=True)

        batch_size = 1
        seq_len = 10
        enc_seq_len = 15

        hidden_states = mx.random.normal((batch_size, seq_len, 256))
        encoder_states_1 = mx.random.normal((batch_size, enc_seq_len, 256))
        encoder_states_2 = mx.random.normal((batch_size, enc_seq_len, 256))

        output = layer(hidden_states, [encoder_states_1, encoder_states_2])

        assert output.shape == (batch_size, seq_len, 256)


class TestPerceiverCrossAttention:
    """Test PerceiverCrossAttention."""

    def test_creation(self):
        """Test creating perceiver cross-attention."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )

        layer = PerceiverCrossAttention(config, num_latents=128)

        assert layer.num_latents == 128
        assert layer.latent_queries.shape == (128, 512)

    def test_forward_compresses_sequence(self):
        """Test that perceiver compresses long sequences to latents."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )

        num_latents = 64
        layer = PerceiverCrossAttention(config, num_latents=num_latents)

        batch_size = 2
        enc_seq_len = 1000  # Long sequence

        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 256))

        output = layer(encoder_hidden_states)

        # Should compress to fixed number of latents
        assert output.shape == (batch_size, num_latents, 256)

    def test_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )

        layer = PerceiverCrossAttention(config, num_latents=32)

        batch_size = 2
        enc_seq_len = 100

        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 256))

        output = layer(encoder_hidden_states)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestCrossAttentionEdgeCases:
    """Test edge cases for cross-attention."""

    def test_single_token_query(self):
        """Test with single query token (decode scenario)."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = CrossAttention(config)

        batch_size = 1
        seq_len = 1  # Single token
        enc_seq_len = 100

        hidden_states = mx.random.normal((batch_size, seq_len, 512))
        encoder_hidden_states = mx.random.normal((batch_size, enc_seq_len, 512))

        output = layer(hidden_states, encoder_hidden_states)

        assert output.shape == (batch_size, seq_len, 512)

    def test_batch_size_one(self):
        """Test with batch size of 1."""
        config = CrossAttentionConfig(
            num_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        layer = CrossAttention(config)

        hidden_states = mx.random.normal((1, 10, 256))
        encoder_hidden_states = mx.random.normal((1, 20, 256))

        output = layer(hidden_states, encoder_hidden_states)

        assert output.shape == (1, 10, 256)

    def test_large_batch(self):
        """Test with larger batch size."""
        config = CrossAttentionConfig(
            num_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        layer = CrossAttention(config)

        batch_size = 16
        hidden_states = mx.random.normal((batch_size, 10, 512))
        encoder_hidden_states = mx.random.normal((batch_size, 20, 512))

        output = layer(hidden_states, encoder_hidden_states)

        assert output.shape == (batch_size, 10, 512)
