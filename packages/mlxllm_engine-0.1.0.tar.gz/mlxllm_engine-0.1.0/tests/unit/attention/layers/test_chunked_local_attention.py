# SPDX-License-Identifier: Apache-2.0
"""Tests for chunked local attention."""

from __future__ import annotations

import mlx.core as mx

from mlxllm.attention.backends.registry import create_backend
from mlxllm.attention.layers.chunked_local_attention import (
    ChunkedLocalAttention,
    ChunkedLocalAttentionConfig,
)


class TestChunkedLocalAttentionConfig:
    """Test ChunkedLocalAttentionConfig."""

    def test_config_creation(self):
        """Test creating config with required fields."""
        config = ChunkedLocalAttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )

        assert config.num_heads == 32
        assert config.num_kv_heads == 8
        assert config.head_dim == 128
        assert config.hidden_size == 4096
        assert config.window_size == 512  # Default
        assert config.chunk_size == 128  # Default

    def test_config_with_custom_window_size(self):
        """Test config with custom window size."""
        config = ChunkedLocalAttentionConfig(
            num_heads=32,
            num_kv_heads=32,
            head_dim=64,
            hidden_size=2048,
            window_size=1024,
        )

        assert config.window_size == 1024

    def test_config_with_custom_chunk_size(self):
        """Test config with custom chunk size."""
        config = ChunkedLocalAttentionConfig(
            num_heads=16,
            num_kv_heads=16,
            head_dim=64,
            hidden_size=1024,
            chunk_size=256,
        )

        assert config.chunk_size == 256


class TestChunkedLocalAttentionInitialization:
    """Test ChunkedLocalAttention initialization."""

    def test_layer_creation(self):
        """Test creating chunked local attention layer."""
        config = ChunkedLocalAttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = create_backend("metal")

        layer = ChunkedLocalAttention(config, backend)

        assert layer.num_heads == 8
        assert layer.num_kv_heads == 8
        assert layer.head_dim == 64
        assert layer.hidden_size == 512
        assert layer.window_size == 512
        assert layer.chunk_size == 128

    def test_projection_sizes(self):
        """Test that projection layers have correct sizes."""
        config = ChunkedLocalAttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=128,
            hidden_size=4096,
        )
        backend = create_backend("metal")

        layer = ChunkedLocalAttention(config, backend)

        q_size = config.num_heads * config.head_dim  # 32 * 128 = 4096
        kv_size = config.num_kv_heads * config.head_dim  # 8 * 128 = 1024

        assert layer.q_size == q_size
        assert layer.kv_size == kv_size

    def test_layer_with_gqa(self):
        """Test layer with Grouped Query Attention."""
        config = ChunkedLocalAttentionConfig(
            num_heads=32,
            num_kv_heads=8,  # GQA: 4 query heads per KV head
            head_dim=128,
            hidden_size=4096,
        )
        backend = create_backend("metal")

        layer = ChunkedLocalAttention(config, backend)

        assert layer.num_heads == 32
        assert layer.num_kv_heads == 8
        assert layer.num_heads % layer.num_kv_heads == 0


class TestChunkedLocalAttentionForward:
    """Test ChunkedLocalAttention forward pass."""

    def test_forward_short_sequence(self):
        """Test forward pass with short sequence (single chunk)."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
            chunk_size=128,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        # Short sequence that fits in one chunk
        batch_size = 2
        seq_len = 10
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)

    def test_forward_long_sequence(self):
        """Test forward pass with long sequence (multiple chunks)."""
        config = ChunkedLocalAttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
            chunk_size=64,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        # Long sequence requiring multiple chunks
        batch_size = 1
        seq_len = 200  # Requires multiple 64-token chunks
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)

    def test_forward_with_gqa(self):
        """Test forward pass with GQA."""
        config = ChunkedLocalAttentionConfig(
            num_heads=32,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=2048,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 1
        seq_len = 50
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)

    def test_forward_single_token(self):
        """Test forward pass with single token (decode scenario)."""
        config = ChunkedLocalAttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 1
        seq_len = 1
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.array([[0]])

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)


class TestChunkedLocalAttentionMasking:
    """Test local attention masking behavior."""

    def test_local_mask_creation(self):
        """Test that local mask is created correctly."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
            window_size=3,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        seq_len = 10
        mask = layer._create_local_mask(seq_len)

        # Mask should have correct shape
        assert mask.shape == (1, 1, seq_len, seq_len)

        # Check that positions beyond window are masked
        mask_2d = mx.reshape(mask, (seq_len, seq_len))

        # Position 5 should be able to attend to [2, 3, 4, 5]
        # but not to [0, 1] (beyond window) or [6+] (future)
        assert mask_2d[5, 0] == float("-inf")  # Beyond window
        assert mask_2d[5, 1] == float("-inf")  # Beyond window
        assert mask_2d[5, 2] == 0.0  # Within window
        assert mask_2d[5, 5] == 0.0  # Self
        assert mask_2d[5, 6] == float("-inf")  # Future

    def test_chunk_mask_creation(self):
        """Test chunk mask creation."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
            window_size=4,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        chunk_size = 5
        kv_size = 10
        q_offset = 10
        kv_offset = 5

        mask = layer._create_chunk_mask(chunk_size, kv_size, q_offset, kv_offset)

        assert mask.shape == (1, chunk_size, kv_size)

    def test_window_size_smaller_than_sequence(self):
        """Test that window size smaller than sequence is respected."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
            window_size=5,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 1
        seq_len = 20  # Longer than window
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        # Should still work with window smaller than sequence
        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)


class TestChunkedLocalAttentionEdgeCases:
    """Test edge cases for chunked local attention."""

    def test_sequence_exactly_chunk_size(self):
        """Test sequence length exactly equal to chunk size."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
            chunk_size=10,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 1
        seq_len = 10  # Exactly chunk_size
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)

    def test_batch_size_greater_than_one(self):
        """Test with multiple sequences in batch."""
        config = ChunkedLocalAttentionConfig(
            num_heads=8,
            num_kv_heads=8,
            head_dim=64,
            hidden_size=512,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 4
        seq_len = 50
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        assert output.shape == (batch_size, seq_len, config.hidden_size)

    def test_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        config = ChunkedLocalAttentionConfig(
            num_heads=4,
            num_kv_heads=4,
            head_dim=64,
            hidden_size=256,
        )
        backend = create_backend("metal")
        layer = ChunkedLocalAttention(config, backend)

        batch_size = 2
        seq_len = 20
        hidden_states = mx.random.normal((batch_size, seq_len, config.hidden_size))
        positions = mx.arange(seq_len)
        positions = mx.broadcast_to(
            mx.expand_dims(positions, 0),
            (batch_size, seq_len)
        )

        output = layer(hidden_states, positions)

        import numpy as np
        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))
