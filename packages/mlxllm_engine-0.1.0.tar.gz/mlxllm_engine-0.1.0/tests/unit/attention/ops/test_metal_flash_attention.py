# SPDX-License-Identifier: Apache-2.0
"""Tests for Metal flash attention operations."""

from __future__ import annotations

import mlx.core as mx
import numpy as np

from mlxllm.attention.ops.metal_flash_attention import (
    metal_flash_attention,
    metal_flash_attention_prefill,
)


class TestMetalFlashAttention:
    """Test metal_flash_attention function."""

    def test_flash_attention_shape(self):
        """Test that flash attention produces correct output shape."""
        batch_size = 2
        seq_len = 10
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_flash_attention_with_gqa(self):
        """Test flash attention with Grouped Query Attention."""
        batch_size = 2
        seq_len = 15
        num_heads = 32
        num_kv_heads = 8  # GQA
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_flash_attention_with_mqa(self):
        """Test flash attention with Multi-Query Attention."""
        batch_size = 1
        seq_len = 20
        num_heads = 32
        num_kv_heads = 1  # MQA
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_flash_attention_with_custom_scale(self):
        """Test flash attention with custom scale factor."""
        batch_size = 1
        seq_len = 10
        num_heads = 4
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        custom_scale = 0.25
        output = metal_flash_attention(query, key, value, scale=custom_scale)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_flash_attention_with_mask(self):
        """Test flash attention with custom attention mask."""
        batch_size = 1
        seq_len = 8
        num_heads = 4
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        # Create custom mask
        mask = mx.zeros((batch_size, num_heads, seq_len, seq_len))

        output = metal_flash_attention(query, key, value, mask=mask)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_flash_attention_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        batch_size = 2
        seq_len = 15
        num_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        output = metal_flash_attention(query, key, value)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))

    def test_flash_attention_single_token(self):
        """Test flash attention with single token (decode scenario)."""
        batch_size = 1
        seq_len = 1
        num_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)


class TestMetalFlashAttentionPrefill:
    """Test metal_flash_attention_prefill function."""

    def test_prefill_shape(self):
        """Test prefill attention output shape."""
        batch_size = 2
        seq_len = 100
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        output = metal_flash_attention_prefill(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_prefill_with_sliding_window(self):
        """Test prefill attention with sliding window."""
        batch_size = 1
        seq_len = 50
        num_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        sliding_window = 32
        output = metal_flash_attention_prefill(
            query, key, value, sliding_window=sliding_window
        )

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_prefill_with_gqa(self):
        """Test prefill with GQA."""
        batch_size = 1
        seq_len = 50
        num_heads = 32
        num_kv_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        output = metal_flash_attention_prefill(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)

    def test_prefill_long_sequence(self):
        """Test prefill with longer sequence."""
        batch_size = 1
        seq_len = 512
        num_heads = 8
        head_dim = 64

        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_heads, head_dim))

        output = metal_flash_attention_prefill(query, key, value)

        assert output.shape == (batch_size, seq_len, num_heads, head_dim)


class TestMetalFlashAttentionEdgeCases:
    """Test edge cases for Metal flash attention."""

    def test_batch_size_one(self):
        """Test with single batch."""
        query = mx.random.normal((1, 10, 8, 64))
        key = mx.random.normal((1, 10, 8, 64))
        value = mx.random.normal((1, 10, 8, 64))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (1, 10, 8, 64)

    def test_large_batch(self):
        """Test with large batch size."""
        batch_size = 32
        query = mx.random.normal((batch_size, 10, 8, 64))
        key = mx.random.normal((batch_size, 10, 8, 64))
        value = mx.random.normal((batch_size, 10, 8, 64))

        output = metal_flash_attention(query, key, value)

        assert output.shape == (batch_size, 10, 8, 64)

    def test_different_head_dims(self):
        """Test with various head dimensions."""
        for head_dim in [64, 80, 96, 128]:
            query = mx.random.normal((1, 10, 8, head_dim))
            key = mx.random.normal((1, 10, 8, head_dim))
            value = mx.random.normal((1, 10, 8, head_dim))

            output = metal_flash_attention(query, key, value)

            assert output.shape == (1, 10, 8, head_dim)
