# SPDX-License-Identifier: Apache-2.0
"""Tests for Metal unified attention (combines prefill and decode)."""

from __future__ import annotations

import mlx.core as mx
import pytest


class TestMetalUnifiedAttention:
    """Test unified attention that handles both prefill and decode."""

    def test_module_can_be_imported(self):
        """Test that module structure is correct."""
        # This ensures imports work
        try:
            from mlxllm.attention.ops import metal_unified_attention
            assert True
        except ImportError:
            pytest.skip("Metal unified attention not implemented yet")


class TestUnifiedAttentionPrefillMode:
    """Test unified attention in prefill mode."""

    def test_prefill_mode_basic(self):
        """Test basic prefill operation."""
        pytest.skip("Unified attention implementation pending")


class TestUnifiedAttentionDecodeMode:
    """Test unified attention in decode mode."""

    def test_decode_mode_basic(self):
        """Test basic decode operation."""
        pytest.skip("Unified attention implementation pending")
