# SPDX-License-Identifier: Apache-2.0
"""Tests for common attention operations."""

from __future__ import annotations

import mlx.core as mx
import numpy as np

from mlxllm.attention.ops.common import (
    apply_rotary_pos_emb,
    compute_positions,
    get_attention_mask,
    repeat_kv,
    scaled_dot_product_attention,
)


class TestApplyRotaryPosEmb:
    """Test Rotary Position Embedding (RoPE) application."""

    def test_rope_output_shapes(self):
        """Test that RoPE preserves tensor shapes."""
        batch, seq_len, num_heads, head_dim = 2, 10, 8, 64
        q = mx.random.normal((batch, seq_len, num_heads, head_dim))
        k = mx.random.normal((batch, seq_len, num_heads, head_dim))
        cos = mx.random.normal((seq_len, head_dim))
        sin = mx.random.normal((seq_len, head_dim))

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape

    def test_rope_with_position_ids(self):
        """Test RoPE with explicit position IDs."""
        batch, seq_len, num_heads, head_dim = 1, 5, 4, 64
        q = mx.random.normal((batch, seq_len, num_heads, head_dim))
        k = mx.random.normal((batch, seq_len, num_heads, head_dim))

        # Create cos/sin for longer sequence
        max_seq = 100
        cos = mx.random.normal((max_seq, head_dim))
        sin = mx.random.normal((max_seq, head_dim))

        # Use specific positions
        position_ids = mx.array([[10, 11, 12, 13, 14]])

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin, position_ids)

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape

    def test_rope_different_head_dims(self):
        """Test RoPE with various head dimensions."""
        for head_dim in [64, 80, 96, 128]:
            batch, seq_len, num_heads = 1, 10, 8
            q = mx.random.normal((batch, seq_len, num_heads, head_dim))
            k = mx.random.normal((batch, seq_len, num_heads, head_dim))
            cos = mx.random.normal((seq_len, head_dim))
            sin = mx.random.normal((seq_len, head_dim))

            q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

            assert q_rot.shape == (batch, seq_len, num_heads, head_dim)
            assert k_rot.shape == (batch, seq_len, num_heads, head_dim)

    def test_rope_rotation_property(self):
        """Test that RoPE applies rotation (values actually change)."""
        batch, seq_len, num_heads, head_dim = 1, 5, 4, 64
        q = mx.random.normal((batch, seq_len, num_heads, head_dim))
        k = mx.random.normal((batch, seq_len, num_heads, head_dim))
        cos = mx.ones((seq_len, head_dim)) * 0.9  # Non-identity rotation
        sin = mx.ones((seq_len, head_dim)) * 0.1

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

        # Rotated values should differ from original
        assert not mx.array_equal(q_rot, q)
        assert not mx.array_equal(k_rot, k)

    def test_rope_preserves_magnitude_approximately(self):
        """Test that RoPE approximately preserves vector magnitudes."""
        batch, seq_len, num_heads, head_dim = 1, 10, 4, 64
        q = mx.random.normal((batch, seq_len, num_heads, head_dim))
        k = mx.random.normal((batch, seq_len, num_heads, head_dim))

        # Create orthonormal rotation
        theta = mx.linspace(0, 2 * np.pi, seq_len)
        cos = mx.broadcast_to(mx.cos(theta).reshape(-1, 1), (seq_len, head_dim))
        sin = mx.broadcast_to(mx.sin(theta).reshape(-1, 1), (seq_len, head_dim))

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

        # Magnitudes should be similar (rotation preserves norm)
        q_norm_orig = mx.sqrt(mx.sum(q**2, axis=-1))
        q_norm_rot = mx.sqrt(mx.sum(q_rot**2, axis=-1))

        # Allow for small numerical differences
        assert mx.allclose(q_norm_orig, q_norm_rot, rtol=1e-4, atol=1e-4)


class TestScaledDotProductAttention:
    """Test scaled dot-product attention."""

    def test_attention_output_shape(self):
        """Test that attention produces correct output shape."""
        batch, num_heads, seq_len_q, head_dim = 2, 8, 10, 64
        seq_len_k = 10

        query = mx.random.normal((batch, num_heads, seq_len_q, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len_k, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len_k, head_dim))

        output = scaled_dot_product_attention(query, key, value)

        assert output.shape == (batch, num_heads, seq_len_q, head_dim)

    def test_attention_with_causal_mask(self):
        """Test attention with causal masking."""
        batch, num_heads, seq_len, head_dim = 1, 4, 5, 64

        query = mx.random.normal((batch, num_heads, seq_len, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len, head_dim))
        value = mx.ones((batch, num_heads, seq_len, head_dim))

        output = scaled_dot_product_attention(
            query, key, value, is_causal=True
        )

        assert output.shape == (batch, num_heads, seq_len, head_dim)

        # With causal mask, first token can only attend to itself
        # so output[0,0,0,:] should be close to value[0,0,0,:]
        # (This is approximate due to softmax normalization)

    def test_attention_with_custom_scale(self):
        """Test attention with custom scale factor."""
        batch, num_heads, seq_len, head_dim = 1, 2, 5, 64

        query = mx.random.normal((batch, num_heads, seq_len, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len, head_dim))

        custom_scale = 0.5
        output = scaled_dot_product_attention(
            query, key, value, scale=custom_scale
        )

        assert output.shape == (batch, num_heads, seq_len, head_dim)

    def test_attention_with_mask(self):
        """Test attention with explicit attention mask."""
        batch, num_heads, seq_len, head_dim = 1, 2, 4, 32

        query = mx.random.normal((batch, num_heads, seq_len, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len, head_dim))

        # Mask out upper triangle
        attn_mask = mx.triu(
            mx.full((seq_len, seq_len), float("-inf")), k=1
        )

        output = scaled_dot_product_attention(
            query, key, value, attn_mask=attn_mask
        )

        assert output.shape == (batch, num_heads, seq_len, head_dim)

    def test_attention_cross_attention(self):
        """Test cross-attention with different Q and KV sequence lengths."""
        batch, num_heads, seq_len_q, seq_len_k, head_dim = 1, 4, 10, 20, 64

        query = mx.random.normal((batch, num_heads, seq_len_q, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len_k, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len_k, head_dim))

        output = scaled_dot_product_attention(query, key, value)

        assert output.shape == (batch, num_heads, seq_len_q, head_dim)

    def test_attention_single_token(self):
        """Test attention with single query token (decode scenario)."""
        batch, num_heads, seq_len_k, head_dim = 1, 8, 100, 64

        query = mx.random.normal((batch, num_heads, 1, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len_k, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len_k, head_dim))

        output = scaled_dot_product_attention(query, key, value)

        assert output.shape == (batch, num_heads, 1, head_dim)

    def test_attention_values_are_finite(self):
        """Test that attention output contains no NaN or Inf."""
        batch, num_heads, seq_len, head_dim = 2, 4, 10, 64

        query = mx.random.normal((batch, num_heads, seq_len, head_dim))
        key = mx.random.normal((batch, num_heads, seq_len, head_dim))
        value = mx.random.normal((batch, num_heads, seq_len, head_dim))

        output = scaled_dot_product_attention(query, key, value)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestRepeatKV:
    """Test KV head repetition for Grouped Query Attention."""

    def test_repeat_kv_no_repeat(self):
        """Test that n_rep=1 returns unchanged tensor."""
        batch, seq_len, num_heads, head_dim = 2, 10, 8, 64
        hidden_states = mx.random.normal((batch, seq_len, num_heads, head_dim))

        result = repeat_kv(hidden_states, n_rep=1)

        assert mx.array_equal(result, hidden_states)

    def test_repeat_kv_2x(self):
        """Test repeating KV heads 2x."""
        batch, seq_len, num_kv_heads, head_dim = 1, 5, 4, 64
        hidden_states = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(hidden_states, n_rep=2)

        expected_shape = (batch, seq_len, num_kv_heads * 2, head_dim)
        assert result.shape == expected_shape

        # Verify repetition pattern
        for i in range(num_kv_heads):
            assert mx.array_equal(
                result[:, :, i * 2, :],
                hidden_states[:, :, i, :]
            )
            assert mx.array_equal(
                result[:, :, i * 2 + 1, :],
                hidden_states[:, :, i, :]
            )

    def test_repeat_kv_4x(self):
        """Test repeating KV heads 4x."""
        batch, seq_len, num_kv_heads, head_dim = 1, 10, 2, 128
        hidden_states = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(hidden_states, n_rep=4)

        assert result.shape == (batch, seq_len, num_kv_heads * 4, head_dim)

    def test_repeat_kv_mqa(self):
        """Test Multi-Query Attention (single KV head repeated many times)."""
        batch, seq_len, num_kv_heads, head_dim = 1, 8, 1, 64
        hidden_states = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

        result = repeat_kv(hidden_states, n_rep=32)

        assert result.shape == (batch, seq_len, 32, head_dim)

        # All heads should be identical
        for i in range(32):
            assert mx.array_equal(
                result[:, :, i, :],
                hidden_states[:, :, 0, :]
            )


class TestGetAttentionMask:
    """Test attention mask generation."""

    def test_causal_mask_shape(self):
        """Test causal mask has correct shape."""
        seq_len = 10
        mask = get_attention_mask(seq_len, is_causal=True)
        assert mask.shape == (seq_len, seq_len)

    def test_causal_mask_structure(self):
        """Test causal mask is lower triangular."""
        seq_len = 5
        mask = get_attention_mask(seq_len, is_causal=True)

        mask_np = np.array(mask)

        # Upper triangle should be -inf (can't attend to future)
        for i in range(seq_len):
            for j in range(i + 1, seq_len):
                assert mask_np[i, j] == float("-inf")

        # Lower triangle and diagonal should be 0 (can attend)
        for i in range(seq_len):
            for j in range(i + 1):
                assert mask_np[i, j] == 0.0

    def test_sliding_window_mask(self):
        """Test sliding window attention mask."""
        seq_len = 10
        window_size = 3
        mask = get_attention_mask(
            seq_len, sliding_window=window_size, is_causal=True
        )

        mask_np = np.array(mask)

        # Positions beyond window should be -inf
        # E.g., at position 5, can attend to [2,3,4,5] but not [0,1]
        assert mask_np[5, 0] == float("-inf")
        assert mask_np[5, 1] == float("-inf")
        assert mask_np[5, 2] == 0.0  # Within window

    def test_no_mask_when_not_causal_and_no_window(self):
        """Test that no mask is applied when not causal and no window."""
        seq_len = 5
        mask = get_attention_mask(seq_len, is_causal=False, sliding_window=None)

        # All positions should be 0 (no masking)
        assert mx.all(mask == 0)

    def test_bidirectional_with_window(self):
        """Test bidirectional attention with sliding window."""
        seq_len = 8
        window_size = 2
        mask = get_attention_mask(
            seq_len, sliding_window=window_size, is_causal=False
        )

        mask_np = np.array(mask)

        # Position 4 should attend to [2,3,4,5,6] (within window �2)
        # but not to [0,1,7]
        assert mask_np[4, 0] == float("-inf")
        assert mask_np[4, 1] == float("-inf")
        assert mask_np[4, 2] == 0.0
        assert mask_np[4, 7] == float("-inf")


class TestComputePositions:
    """Test position index computation."""

    def test_positions_from_zero(self):
        """Test computing positions starting from 0."""
        seq_len = 10
        positions = compute_positions(seq_len)

        expected = mx.arange(0, seq_len)
        assert mx.array_equal(positions, expected)

    def test_positions_with_past_kv(self):
        """Test computing positions with past KV cache."""
        seq_len = 5
        past_kv_len = 10

        positions = compute_positions(seq_len, past_kv_len)

        expected = mx.arange(10, 15)
        assert mx.array_equal(positions, expected)

    def test_positions_shape(self):
        """Test that positions have correct shape."""
        seq_len = 20
        positions = compute_positions(seq_len)

        assert positions.shape == (seq_len,)

    def test_positions_are_integers(self):
        """Test that positions are integer values."""
        seq_len = 10
        positions = compute_positions(seq_len)

        # Should be integer type
        assert positions.dtype in [mx.int32, mx.int64]

    def test_positions_are_sequential(self):
        """Test that positions are sequential with step=1."""
        seq_len = 100
        past_kv_len = 50
        positions = compute_positions(seq_len, past_kv_len)

        positions_np = np.array(positions)

        # Check sequential with diff=1
        diffs = np.diff(positions_np)
        assert np.all(diffs == 1)

    def test_positions_single_token(self):
        """Test position for single token (decode scenario)."""
        seq_len = 1
        past_kv_len = 100

        positions = compute_positions(seq_len, past_kv_len)

        assert positions.shape == (1,)
        assert positions[0] == 100
