# SPDX-License-Identifier: Apache-2.0
"""Tests for Metal decode attention operations."""

from __future__ import annotations

import mlx.core as mx
import numpy as np

from mlxllm.attention.ops.metal_decode_attention import metal_paged_attention


class TestMetalPagedAttention:
    """Test metal_paged_attention function."""

    def test_paged_attention_shape(self):
        """Test that paged attention produces correct output shape."""
        batch_size = 2
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 10

        query = mx.random.normal((batch_size, 1, num_heads, head_dim))
        kv_cache = mx.random.normal((num_blocks, 2, block_size, num_kv_heads, head_dim))
        block_tables = [[0, 1], [2, 3]]
        context_lens = [20, 25]

        output = metal_paged_attention(
            query, kv_cache, block_tables, context_lens, block_size
        )

        assert output.shape == (batch_size, 1, num_heads, head_dim)

    def test_paged_attention_with_gqa(self):
        """Test paged attention with GQA."""
        batch_size = 2
        num_heads = 32
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 10

        query = mx.random.normal((batch_size, 1, num_heads, head_dim))
        kv_cache = mx.random.normal((num_blocks, 2, block_size, num_kv_heads, head_dim))
        block_tables = [[0, 1], [2, 3]]
        context_lens = [20, 25]

        output = metal_paged_attention(
            query, kv_cache, block_tables, context_lens, block_size
        )

        assert output.shape == (batch_size, 1, num_heads, head_dim)

    def test_paged_attention_single_sequence(self):
        """Test with single sequence."""
        query = mx.random.normal((1, 1, 8, 64))
        kv_cache = mx.random.normal((5, 2, 16, 8, 64))
        block_tables = [[0, 1]]
        context_lens = [20]

        output = metal_paged_attention(query, kv_cache, block_tables, context_lens, 16)

        assert output.shape == (1, 1, 8, 64)

    def test_paged_attention_empty_context(self):
        """Test with empty context."""
        query = mx.random.normal((1, 1, 8, 64))
        kv_cache = mx.random.normal((5, 2, 16, 8, 64))
        block_tables = [[]]
        context_lens = [0]

        output = metal_paged_attention(query, kv_cache, block_tables, context_lens, 16)

        assert output.shape == (1, 1, 8, 64)

    def test_paged_attention_output_is_finite(self):
        """Test that output is finite."""
        query = mx.random.normal((2, 1, 8, 64))
        kv_cache = mx.random.normal((10, 2, 16, 8, 64))
        block_tables = [[0, 1], [2, 3]]
        context_lens = [20, 25]

        output = metal_paged_attention(query, kv_cache, block_tables, context_lens, 16)

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestMetalPagedAttentionEdgeCases:
    """Test edge cases."""

    def test_varying_context_lengths(self):
        """Test with varying context lengths."""
        query = mx.random.normal((3, 1, 8, 64))
        kv_cache = mx.random.normal((15, 2, 16, 8, 64))
        block_tables = [[0, 1], [2, 3, 4], [5]]
        context_lens = [10, 50, 5]

        output = metal_paged_attention(query, kv_cache, block_tables, context_lens, 16)

        assert output.shape == (3, 1, 8, 64)

    def test_invalid_blocks_skipped(self):
        """Test that invalid block IDs are skipped."""
        query = mx.random.normal((1, 1, 8, 64))
        kv_cache = mx.random.normal((5, 2, 16, 8, 64))
        block_tables = [[0, -1, 1]]  # -1 is invalid
        context_lens = [20]

        output = metal_paged_attention(query, kv_cache, block_tables, context_lens, 16)

        assert output.shape == (1, 1, 8, 64)
