# SPDX-License-Identifier: Apache-2.0
"""Tests for paged attention operations."""

from __future__ import annotations

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.attention.ops.paged_attn import (
    paged_attention,
    reshape_and_cache,
)


class TestPagedAttention:
    """Test paged attention function."""

    def test_paged_attention_shape(self):
        """Test that paged attention produces correct output shape."""
        batch_size = 2
        num_heads = 8
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 10

        # Query: [batch, num_heads, head_dim]
        query = mx.random.normal((batch_size, num_heads, head_dim))

        # KV cache: [num_blocks, block_size, num_kv_heads, head_dim]
        key_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))

        # Block tables: [batch, max_blocks]
        block_tables = mx.array([[0, 1], [2, 3]])

        # Context lengths: [batch]
        context_lens = mx.array([20, 25])

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, block_size
        )

        assert output.shape == (batch_size, num_heads, head_dim)

    def test_paged_attention_with_gqa(self):
        """Test paged attention with Grouped Query Attention."""
        batch_size = 2
        num_heads = 32
        num_kv_heads = 8  # GQA: 4 query heads per KV head
        head_dim = 64
        block_size = 16
        num_blocks = 10

        query = mx.random.normal((batch_size, num_heads, head_dim))
        key_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))
        block_tables = mx.array([[0, 1], [2, 3]])
        context_lens = mx.array([20, 25])

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, block_size
        )

        assert output.shape == (batch_size, num_heads, head_dim)

    def test_paged_attention_with_custom_scale(self):
        """Test paged attention with custom scale factor."""
        batch_size = 1
        num_heads = 4
        num_kv_heads = 4
        head_dim = 64
        block_size = 16
        num_blocks = 5

        query = mx.random.normal((batch_size, num_heads, head_dim))
        key_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.random.normal((num_blocks, block_size, num_kv_heads, head_dim))
        block_tables = mx.array([[0, 1]])
        context_lens = mx.array([20])

        custom_scale = 0.25
        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, block_size, scale=custom_scale
        )

        assert output.shape == (batch_size, num_heads, head_dim)

    def test_paged_attention_validates_query_shape(self):
        """Test that invalid query shape raises ValueError."""
        query = mx.random.normal((2, 8))  # Wrong shape
        key_cache = mx.random.normal((10, 16, 8, 64))
        value_cache = mx.random.normal((10, 16, 8, 64))
        block_tables = mx.array([[0, 1]])
        context_lens = mx.array([20])

        with pytest.raises(ValueError, match="Query must be 3D"):
            paged_attention(query, key_cache, value_cache, block_tables, context_lens, 16)

    def test_paged_attention_validates_block_tables_shape(self):
        """Test that invalid block tables shape raises ValueError."""
        query = mx.random.normal((2, 8, 64))
        key_cache = mx.random.normal((10, 16, 8, 64))
        value_cache = mx.random.normal((10, 16, 8, 64))
        block_tables = mx.array([0, 1])  # Wrong shape (should be 2D)
        context_lens = mx.array([20, 25])

        with pytest.raises(ValueError, match="Block tables must be 2D"):
            paged_attention(query, key_cache, value_cache, block_tables, context_lens, 16)

    def test_paged_attention_validates_batch_size(self):
        """Test that mismatched batch sizes raise ValueError."""
        query = mx.random.normal((2, 8, 64))
        key_cache = mx.random.normal((10, 16, 8, 64))
        value_cache = mx.random.normal((10, 16, 8, 64))
        block_tables = mx.array([[0, 1]])  # Batch size 1
        context_lens = mx.array([20, 25])  # Batch size 2

        with pytest.raises(ValueError, match="batch size"):
            paged_attention(query, key_cache, value_cache, block_tables, context_lens, 16)

    def test_paged_attention_output_is_finite(self):
        """Test that output contains no NaN or Inf."""
        batch_size = 2
        num_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 10

        query = mx.random.normal((batch_size, num_heads, head_dim))
        key_cache = mx.random.normal((num_blocks, block_size, 8, head_dim))
        value_cache = mx.random.normal((num_blocks, block_size, 8, head_dim))
        block_tables = mx.array([[0, 1], [2, 3]])
        context_lens = mx.array([20, 25])

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, block_size
        )

        output_np = np.array(output)
        assert np.all(np.isfinite(output_np))


class TestReshapeAndCache:
    """Test reshape_and_cache function."""

    def test_reshape_and_cache_shape(self):
        """Test that reshape_and_cache produces correct shapes."""
        batch_size = 2
        seq_len = 10
        num_kv_heads = 8
        head_dim = 64
        block_size = 16
        num_blocks = 10

        # Flatten key and value
        key = mx.random.normal((batch_size * seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size * seq_len, num_kv_heads, head_dim))
        key_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))

        # Slot mapping: [num_tokens]
        slot_mapping = mx.arange(batch_size * seq_len)

        # This modifies cache in-place
        reshape_and_cache(key, value, key_cache, value_cache, slot_mapping)

        # Cache shapes should be unchanged
        assert key_cache.shape == (num_blocks, block_size, num_kv_heads, head_dim)
        assert value_cache.shape == (num_blocks, block_size, num_kv_heads, head_dim)

    def test_reshape_and_cache_updates_correct_positions(self):
        """Test that cache is updated at correct positions."""
        num_kv_heads = 4
        head_dim = 8
        block_size = 4
        num_blocks = 2

        # Simple key and value
        key = mx.ones((2, num_kv_heads, head_dim)) * 2.0
        value = mx.ones((2, num_kv_heads, head_dim)) * 3.0
        key_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))

        slot_mapping = mx.array([0, 1])

        reshape_and_cache(key, value, key_cache, value_cache, slot_mapping)

        # Function modifies in-place
        # Check that caches have correct shape
        assert key_cache.shape == (num_blocks, block_size, num_kv_heads, head_dim)

    def test_reshape_and_cache_handles_empty_mapping(self):
        """Test reshape_and_cache with empty slot mapping."""
        num_kv_heads = 4
        head_dim = 8
        block_size = 4
        num_blocks = 2

        key = mx.ones((0, num_kv_heads, head_dim))
        value = mx.ones((0, num_kv_heads, head_dim))
        key_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))
        value_cache = mx.zeros((num_blocks, block_size, num_kv_heads, head_dim))

        slot_mapping = mx.array([], dtype=mx.int32)

        reshape_and_cache(key, value, key_cache, value_cache, slot_mapping)

        # Should complete without error
        assert True


class TestPagedAttentionEdgeCases:
    """Test edge cases for paged attention."""

    def test_single_batch_single_block(self):
        """Test with single sequence and single block."""
        query = mx.random.normal((1, 8, 64))
        key_cache = mx.random.normal((5, 16, 8, 64))
        value_cache = mx.random.normal((5, 16, 8, 64))
        block_tables = mx.array([[0]])
        context_lens = mx.array([10])

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, 16
        )

        assert output.shape == (1, 8, 64)

    def test_large_batch(self):
        """Test with larger batch size."""
        batch_size = 16
        query = mx.random.normal((batch_size, 8, 64))
        key_cache = mx.random.normal((50, 16, 8, 64))
        value_cache = mx.random.normal((50, 16, 8, 64))
        block_tables = mx.array([[i, i+1] for i in range(0, batch_size * 2, 2)])
        context_lens = mx.array([20] * batch_size)

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, 16
        )

        assert output.shape == (batch_size, 8, 64)

    def test_varying_context_lengths(self):
        """Test with varying context lengths across batch."""
        batch_size = 4
        query = mx.random.normal((batch_size, 8, 64))
        key_cache = mx.random.normal((20, 16, 8, 64))
        value_cache = mx.random.normal((20, 16, 8, 64))
        block_tables = mx.array([[0, 1], [2, 3], [4, 5], [6, 7]])
        context_lens = mx.array([10, 20, 15, 25])

        output = paged_attention(
            query, key_cache, value_cache, block_tables, context_lens, 16
        )

        assert output.shape == (batch_size, 8, 64)
