# SPDX-License-Identifier: Apache-2.0
"""Tests for generic attention state merging (non-Metal)."""

from __future__ import annotations

import mlx.core as mx
import numpy as np


class TestMergeAttnStates:
    """Test generic merge attention states."""

    def test_merge_exists(self):
        """Test that merge functionality exists."""
        # Generic merge operation
        state1 = mx.random.normal((2, 8, 10, 64))
        state2 = mx.random.normal((2, 8, 15, 64))
        
        # Can concatenate along sequence dimension
        merged = mx.concatenate([state1, state2], axis=2)
        assert merged.shape == (2, 8, 25, 64)


class TestMergeMultipleStates:
    """Test merging multiple attention states."""

    def test_merge_three_states(self):
        """Test merging three states."""
        states = [
            mx.random.normal((2, 8, 10, 64)),
            mx.random.normal((2, 8, 15, 64)),
            mx.random.normal((2, 8, 5, 64)),
        ]
        
        merged = mx.concatenate(states, axis=2)
        assert merged.shape == (2, 8, 30, 64)

    def test_merge_preserves_batch_and_heads(self):
        """Test that batch and head dimensions are preserved."""
        state1 = mx.random.normal((4, 16, 10, 64))
        state2 = mx.random.normal((4, 16, 20, 64))
        
        merged = mx.concatenate([state1, state2], axis=2)
        assert merged.shape[0] == 4  # Batch
        assert merged.shape[1] == 16  # Heads
        assert merged.shape[3] == 64  # Head dim
