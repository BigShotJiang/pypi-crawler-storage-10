# SPDX-License-Identifier: Apache-2.0
"""Tests for storage mediums for KV cache offloading."""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pytest

from mlxllm.kv_offload.mediums import (
    CPUMemoryMedium,
    CompressedMemoryMedium,
    DiskMedium,
    StorageMedium,
)


# ============================================================================
# StorageMedium Abstract Base Tests
# ============================================================================


@pytest.mark.unit
class TestStorageMedium:
    """Tests for StorageMedium abstract base class."""

    def test_cannot_instantiate_abstract_medium(self):
        """Test that abstract medium cannot be instantiated."""
        with pytest.raises(TypeError):
            StorageMedium()  # type: ignore

    def test_abstract_methods_defined(self):
        """Test that all abstract methods are defined."""
        abstract_methods = {
            "store",
            "load",
            "has",
            "delete",
            "get_size_bytes",
            "get_total_size_bytes",
            "clear",
        }

        # Get abstract methods from the class
        cls_abstract_methods = set()
        for name in dir(StorageMedium):
            attr = getattr(StorageMedium, name)
            if getattr(attr, "__isabstractmethod__", False):
                cls_abstract_methods.add(name)

        assert abstract_methods == cls_abstract_methods


# ============================================================================
# CPUMemoryMedium Tests
# ============================================================================


@pytest.mark.unit
class TestCPUMemoryMedium:
    """Tests for CPUMemoryMedium storage."""

    def test_initialization_default(self):
        """Test default initialization."""
        medium = CPUMemoryMedium()
        assert medium.max_memory_bytes == 16 * 1024**3
        assert len(medium.blocks) == 0

    def test_initialization_custom_max_memory(self):
        """Test initialization with custom max memory."""
        max_memory = 8 * 1024**3
        medium = CPUMemoryMedium(max_memory_bytes=max_memory)
        assert medium.max_memory_bytes == max_memory

    def test_store_and_load_block(self):
        """Test storing and loading a block."""
        medium = CPUMemoryMedium()
        data = np.random.randn(10, 20, 30).astype(np.float32)

        # Store
        medium.store(0, data)
        assert medium.has(0)

        # Load
        loaded = medium.load(0)
        assert loaded is not None
        assert np.array_equal(loaded, data)

    def test_store_multiple_blocks(self):
        """Test storing multiple blocks."""
        medium = CPUMemoryMedium()
        data1 = np.random.randn(10, 20).astype(np.float32)
        data2 = np.random.randn(15, 25).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        assert medium.has(0)
        assert medium.has(1)
        assert len(medium.blocks) == 2

    def test_load_nonexistent_block(self):
        """Test loading a block that doesn't exist."""
        medium = CPUMemoryMedium()
        loaded = medium.load(999)
        assert loaded is None

    def test_has_block(self):
        """Test checking if block exists."""
        medium = CPUMemoryMedium()
        data = np.random.randn(10, 20).astype(np.float32)

        assert not medium.has(0)
        medium.store(0, data)
        assert medium.has(0)

    def test_delete_block(self):
        """Test deleting a block."""
        medium = CPUMemoryMedium()
        data = np.random.randn(10, 20).astype(np.float32)

        medium.store(0, data)
        assert medium.has(0)

        medium.delete(0)
        assert not medium.has(0)
        assert len(medium.blocks) == 0

    def test_delete_nonexistent_block(self):
        """Test deleting a block that doesn't exist."""
        medium = CPUMemoryMedium()
        # Should not raise an error
        medium.delete(999)

    def test_get_size_bytes(self):
        """Test getting block size."""
        medium = CPUMemoryMedium()
        data = np.random.randn(100, 100).astype(np.float32)

        medium.store(0, data)
        size = medium.get_size_bytes(0)
        assert size == data.nbytes

    def test_get_size_bytes_nonexistent(self):
        """Test getting size of nonexistent block."""
        medium = CPUMemoryMedium()
        size = medium.get_size_bytes(999)
        assert size == 0

    def test_get_total_size_bytes_empty(self):
        """Test total size with no blocks."""
        medium = CPUMemoryMedium()
        assert medium.get_total_size_bytes() == 0

    def test_get_total_size_bytes_multiple_blocks(self):
        """Test total size with multiple blocks."""
        medium = CPUMemoryMedium()
        data1 = np.random.randn(100, 100).astype(np.float32)
        data2 = np.random.randn(50, 50).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        expected_size = data1.nbytes + data2.nbytes
        assert medium.get_total_size_bytes() == expected_size

    def test_clear(self):
        """Test clearing all blocks."""
        medium = CPUMemoryMedium()
        data1 = np.random.randn(10, 20).astype(np.float32)
        data2 = np.random.randn(15, 25).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        medium.clear()
        assert len(medium.blocks) == 0
        assert not medium.has(0)
        assert not medium.has(1)
        assert medium.get_total_size_bytes() == 0

    def test_memory_limit_exceeded(self):
        """Test that memory limit is enforced."""
        # Small memory limit
        medium = CPUMemoryMedium(max_memory_bytes=1024)
        # Large data exceeding limit
        large_data = np.random.randn(1000, 1000).astype(np.float32)

        with pytest.raises(MemoryError):
            medium.store(0, large_data)

    def test_memory_limit_multiple_blocks(self):
        """Test memory limit with multiple blocks."""
        # Very small limit: 100 KB
        medium = CPUMemoryMedium(max_memory_bytes=100 * 1024)

        # Each block is ~40 KB (100 * 100 * 4 bytes)
        data = np.random.randn(100, 100).astype(np.float32)

        # First block should succeed
        medium.store(0, data)

        # Second block should succeed
        medium.store(1, data)

        # Third should fail (would exceed 100 KB limit with ~120KB total)
        with pytest.raises(MemoryError):
            medium.store(2, data)

    def test_repr(self):
        """Test string representation."""
        medium = CPUMemoryMedium(max_memory_bytes=2 * 1024**3)
        data = np.random.randn(100, 100).astype(np.float32)
        medium.store(0, data)

        repr_str = repr(medium)
        assert "CPUMemoryMedium" in repr_str
        assert "blocks=1" in repr_str
        assert "GB" in repr_str


# ============================================================================
# DiskMedium Tests
# ============================================================================


@pytest.mark.unit
class TestDiskMedium:
    """Tests for DiskMedium storage."""

    def test_initialization_default(self):
        """Test default initialization."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            assert medium.cache_dir == Path(tmpdir)
            assert medium.cache_dir.exists()

    def test_initialization_creates_directory(self):
        """Test that initialization creates cache directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache_dir = Path(tmpdir) / "kv_cache"
            assert not cache_dir.exists()

            medium = DiskMedium(cache_dir=cache_dir)
            assert cache_dir.exists()

    def test_store_and_load_block(self):
        """Test storing and loading a block to disk."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data = np.random.randn(10, 20, 30).astype(np.float32)

            # Store
            medium.store(0, data)
            assert medium.has(0)

            # Verify file exists
            block_path = medium._get_block_path(0)
            assert block_path.exists()

            # Load
            loaded = medium.load(0)
            assert loaded is not None
            assert np.array_equal(loaded, data)

    def test_store_multiple_blocks(self):
        """Test storing multiple blocks."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data1 = np.random.randn(10, 20).astype(np.float32)
            data2 = np.random.randn(15, 25).astype(np.float32)

            medium.store(0, data1)
            medium.store(1, data2)

            assert medium.has(0)
            assert medium.has(1)

    def test_load_nonexistent_block(self):
        """Test loading a block that doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            loaded = medium.load(999)
            assert loaded is None

    def test_has_block(self):
        """Test checking if block exists."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data = np.random.randn(10, 20).astype(np.float32)

            assert not medium.has(0)
            medium.store(0, data)
            assert medium.has(0)

    def test_delete_block(self):
        """Test deleting a block."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data = np.random.randn(10, 20).astype(np.float32)

            medium.store(0, data)
            block_path = medium._get_block_path(0)
            assert block_path.exists()

            medium.delete(0)
            assert not medium.has(0)
            assert not block_path.exists()

    def test_delete_nonexistent_block(self):
        """Test deleting a block that doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            # Should not raise an error
            medium.delete(999)

    def test_get_size_bytes(self):
        """Test getting block file size."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data = np.random.randn(100, 100).astype(np.float32)

            medium.store(0, data)
            size = medium.get_size_bytes(0)
            # Size should be close to data size (may have .npy overhead)
            assert size > 0
            assert size >= data.nbytes

    def test_get_size_bytes_nonexistent(self):
        """Test getting size of nonexistent block."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            size = medium.get_size_bytes(999)
            assert size == 0

    def test_get_total_size_bytes(self):
        """Test getting total disk usage."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data1 = np.random.randn(100, 100).astype(np.float32)
            data2 = np.random.randn(50, 50).astype(np.float32)

            medium.store(0, data1)
            medium.store(1, data2)

            total_size = medium.get_total_size_bytes()
            assert total_size > 0
            assert total_size >= data1.nbytes + data2.nbytes

    def test_clear(self):
        """Test clearing all blocks."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data1 = np.random.randn(10, 20).astype(np.float32)
            data2 = np.random.randn(15, 25).astype(np.float32)

            medium.store(0, data1)
            medium.store(1, data2)

            medium.clear()
            assert not medium.has(0)
            assert not medium.has(1)
            assert medium.get_total_size_bytes() == 0

    def test_disk_limit_exceeded(self):
        """Test that disk limit is enforced."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Small disk limit
            medium = DiskMedium(cache_dir=tmpdir, max_disk_bytes=1024)
            # Large data exceeding limit
            large_data = np.random.randn(1000, 1000).astype(np.float32)

            with pytest.raises(IOError):
                medium.store(0, large_data)

    def test_cleanup(self):
        """Test cleanup method removes directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            cache_dir = Path(tmpdir) / "kv_cache"
            medium = DiskMedium(cache_dir=cache_dir)
            data = np.random.randn(10, 20).astype(np.float32)

            medium.store(0, data)
            assert cache_dir.exists()

            medium.cleanup()
            assert not cache_dir.exists()

    def test_repr(self):
        """Test string representation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            medium = DiskMedium(cache_dir=tmpdir)
            data = np.random.randn(100, 100).astype(np.float32)
            medium.store(0, data)

            repr_str = repr(medium)
            assert "DiskMedium" in repr_str
            assert "blocks=1" in repr_str
            assert "GB" in repr_str


# ============================================================================
# CompressedMemoryMedium Tests
# ============================================================================


@pytest.mark.unit
class TestCompressedMemoryMedium:
    """Tests for CompressedMemoryMedium storage."""

    def test_initialization_default(self):
        """Test default initialization."""
        medium = CompressedMemoryMedium()
        assert medium.max_memory_bytes == 16 * 1024**3
        assert medium.compression_level == 1
        assert len(medium.blocks) == 0

    def test_initialization_custom_params(self):
        """Test initialization with custom parameters."""
        medium = CompressedMemoryMedium(
            max_memory_bytes=8 * 1024**3,
            compression_level=5,
        )
        assert medium.max_memory_bytes == 8 * 1024**3
        assert medium.compression_level == 5

    def test_store_and_load_block(self):
        """Test storing and loading compressed block."""
        medium = CompressedMemoryMedium()
        data = np.random.randn(10, 20, 30).astype(np.float32)

        # Store
        medium.store(0, data)
        assert medium.has(0)

        # Load
        loaded = medium.load(0)
        assert loaded is not None
        assert np.array_equal(loaded, data)
        assert loaded.shape == data.shape
        assert loaded.dtype == data.dtype

    def test_compression_reduces_size(self):
        """Test that compression reduces memory usage."""
        medium = CompressedMemoryMedium(compression_level=9)

        # Create highly compressible data (all zeros)
        data = np.zeros((1000, 1000), dtype=np.float32)
        original_size = data.nbytes

        medium.store(0, data)
        compressed_size = medium.get_size_bytes(0)

        # Compressed size should be much smaller
        assert compressed_size < original_size

    def test_store_multiple_blocks(self):
        """Test storing multiple compressed blocks."""
        medium = CompressedMemoryMedium()
        data1 = np.random.randn(10, 20).astype(np.float32)
        data2 = np.random.randn(15, 25).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        assert medium.has(0)
        assert medium.has(1)
        assert len(medium.blocks) == 2

    def test_load_nonexistent_block(self):
        """Test loading a block that doesn't exist."""
        medium = CompressedMemoryMedium()
        loaded = medium.load(999)
        assert loaded is None

    def test_has_block(self):
        """Test checking if block exists."""
        medium = CompressedMemoryMedium()
        data = np.random.randn(10, 20).astype(np.float32)

        assert not medium.has(0)
        medium.store(0, data)
        assert medium.has(0)

    def test_delete_block(self):
        """Test deleting a compressed block."""
        medium = CompressedMemoryMedium()
        data = np.random.randn(10, 20).astype(np.float32)

        medium.store(0, data)
        assert medium.has(0)

        medium.delete(0)
        assert not medium.has(0)
        assert len(medium.blocks) == 0

    def test_get_size_bytes(self):
        """Test getting compressed block size."""
        medium = CompressedMemoryMedium()
        data = np.random.randn(100, 100).astype(np.float32)

        medium.store(0, data)
        size = medium.get_size_bytes(0)
        assert size > 0
        # Compressed size should be less than or equal to original
        assert size <= data.nbytes

    def test_get_size_bytes_nonexistent(self):
        """Test getting size of nonexistent block."""
        medium = CompressedMemoryMedium()
        size = medium.get_size_bytes(999)
        assert size == 0

    def test_get_total_size_bytes(self):
        """Test getting total compressed size."""
        medium = CompressedMemoryMedium()
        data1 = np.random.randn(100, 100).astype(np.float32)
        data2 = np.random.randn(50, 50).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        total_size = medium.get_total_size_bytes()
        assert total_size > 0

    def test_clear(self):
        """Test clearing all compressed blocks."""
        medium = CompressedMemoryMedium()
        data1 = np.random.randn(10, 20).astype(np.float32)
        data2 = np.random.randn(15, 25).astype(np.float32)

        medium.store(0, data1)
        medium.store(1, data2)

        medium.clear()
        assert len(medium.blocks) == 0
        assert len(medium.shapes) == 0
        assert len(medium.dtypes) == 0
        assert not medium.has(0)
        assert not medium.has(1)

    def test_memory_limit_exceeded(self):
        """Test that compressed memory limit is enforced."""
        # Small memory limit
        medium = CompressedMemoryMedium(max_memory_bytes=1024)
        # Large data that even compressed exceeds limit
        large_data = np.random.randn(10000, 10000).astype(np.float32)

        with pytest.raises(MemoryError):
            medium.store(0, large_data)

    def test_get_compression_ratio_empty(self):
        """Test compression ratio with no blocks."""
        medium = CompressedMemoryMedium()
        ratio = medium.get_compression_ratio()
        assert ratio == 1.0

    def test_get_compression_ratio_with_data(self):
        """Test compression ratio calculation."""
        medium = CompressedMemoryMedium(compression_level=9)

        # Highly compressible data
        data = np.zeros((1000, 1000), dtype=np.float32)
        medium.store(0, data)

        ratio = medium.get_compression_ratio()
        # Ratio should be much less than 1.0 for zeros
        assert 0.0 < ratio < 1.0

    def test_different_compression_levels(self):
        """Test that different compression levels affect size."""
        data = np.zeros((1000, 1000), dtype=np.float32)

        # Level 1 (fast)
        medium_fast = CompressedMemoryMedium(compression_level=1)
        medium_fast.store(0, data)
        size_fast = medium_fast.get_size_bytes(0)

        # Level 9 (best)
        medium_best = CompressedMemoryMedium(compression_level=9)
        medium_best.store(0, data)
        size_best = medium_best.get_size_bytes(0)

        # Best compression should be smaller or equal
        assert size_best <= size_fast

    def test_repr(self):
        """Test string representation."""
        medium = CompressedMemoryMedium(compression_level=5)
        data = np.random.randn(100, 100).astype(np.float32)
        medium.store(0, data)

        repr_str = repr(medium)
        assert "CompressedMemoryMedium" in repr_str
        assert "blocks=1" in repr_str
        assert "level=5" in repr_str
        assert "compression=" in repr_str
