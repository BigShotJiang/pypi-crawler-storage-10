# SPDX-License-Identifier: Apache-2.0
"""Tests for M4-specific KV cache offload optimizations."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from mlxllm.kv_offload.m4 import (
    M4UnifiedMemoryOptimizer,
    create_m4_offload_system,
)
from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend
from mlxllm.kv_offload.lru_manager import LRUOffloadManager
from mlxllm.kv_offload.spec import OffloadSpec


# ============================================================================
# create_m4_offload_system Tests
# ============================================================================


@pytest.mark.unit
class TestCreateM4OffloadSystem:
    """Tests for create_m4_offload_system function."""

    def test_create_system_default_spec(self):
        """Test system creation with default spec."""
        backend, manager = create_m4_offload_system()

        assert isinstance(backend, M4MetalOffloadBackend)
        assert isinstance(manager, LRUOffloadManager)

        # Check default values
        assert backend.max_cpu_memory_bytes == 16 * 1024**3
        assert manager.offload_threshold == 0.9
        assert manager.load_threshold == 0.8

    def test_create_system_custom_spec(self):
        """Test system creation with custom spec."""
        spec = OffloadSpec(
            enabled=True,
            max_offload_memory_gb=8.0,
            offload_threshold_ratio=0.85,
            load_threshold_ratio=0.75,
        )

        backend, manager = create_m4_offload_system(spec)

        assert backend.max_cpu_memory_bytes == 8 * 1024**3
        assert manager.offload_threshold == 0.85
        assert manager.load_threshold == 0.75

    def test_create_system_with_compression(self):
        """Test system creation with compression enabled."""
        spec = OffloadSpec(
            enabled=True,
            enable_compression=True,
        )

        backend, manager = create_m4_offload_system(spec)

        assert backend.enable_compression is True

    def test_create_system_validates_spec(self):
        """Test that invalid spec raises error."""
        spec = OffloadSpec(
            enabled=True,
            max_offload_memory_gb=-1.0,  # Invalid
        )

        with pytest.raises(ValueError):
            create_m4_offload_system(spec)

    def test_create_system_returns_tuple(self):
        """Test that function returns tuple of backend and manager."""
        result = create_m4_offload_system()

        assert isinstance(result, tuple)
        assert len(result) == 2


# ============================================================================
# M4UnifiedMemoryOptimizer Tests
# ============================================================================


@pytest.mark.unit
class TestM4UnifiedMemoryOptimizer:
    """Tests for M4UnifiedMemoryOptimizer class."""

    def test_initialization(self):
        """Test optimizer initialization."""
        optimizer = M4UnifiedMemoryOptimizer()

        assert optimizer.chip_variant == "M4"
        assert optimizer.gpu_cores > 0
        assert optimizer.memory_bandwidth_gbps > 0
        assert optimizer.total_memory_gb > 0

    def test_detect_apple_silicon(self):
        """Test Apple Silicon detection."""
        with patch("platform.system", return_value="Darwin"), patch(
            "platform.machine", return_value="arm64"
        ):
            optimizer = M4UnifiedMemoryOptimizer()
            assert optimizer.is_apple_silicon is True

    def test_detect_non_apple_silicon(self):
        """Test non-Apple Silicon detection."""
        with patch("platform.system", return_value="Linux"), patch(
            "platform.machine", return_value="x86_64"
        ):
            optimizer = M4UnifiedMemoryOptimizer()
            assert optimizer.is_apple_silicon is False

    def test_get_optimal_block_size_small_model(self):
        """Test optimal block size for small models."""
        optimizer = M4UnifiedMemoryOptimizer()

        block_size = optimizer.get_optimal_block_size(3.0)  # 3 GB model
        assert block_size == 16

    def test_get_optimal_block_size_medium_model(self):
        """Test optimal block size for medium models."""
        optimizer = M4UnifiedMemoryOptimizer()

        block_size = optimizer.get_optimal_block_size(7.0)  # 7 GB model
        assert block_size == 32

    def test_get_optimal_block_size_large_model(self):
        """Test optimal block size for large models."""
        optimizer = M4UnifiedMemoryOptimizer()

        block_size = optimizer.get_optimal_block_size(15.0)  # 15 GB model
        assert block_size == 64

    def test_get_optimal_offload_memory_small_model(self):
        """Test optimal offload memory for small models."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0  # Simulate M4 Max

        offload_gb = optimizer.get_optimal_offload_memory_gb(5.0)

        # Should be reasonable amount
        assert offload_gb >= 8.0
        assert offload_gb <= 16.0

    def test_get_optimal_offload_memory_large_model(self):
        """Test optimal offload memory for large models."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        offload_gb = optimizer.get_optimal_offload_memory_gb(20.0)

        # Should be smaller due to less available memory
        assert offload_gb >= 0
        assert offload_gb <= 16.0

    def test_estimate_transfer_time_small_block(self):
        """Test transfer time estimation for small blocks."""
        optimizer = M4UnifiedMemoryOptimizer()

        # 1 MB block
        transfer_time = optimizer.estimate_transfer_time_ms(
            1024 * 1024, "cpu_to_gpu"
        )

        assert transfer_time > 0
        # Should be very fast on unified memory
        assert transfer_time < 10.0  # Less than 10ms

    def test_estimate_transfer_time_large_block(self):
        """Test transfer time estimation for large blocks."""
        optimizer = M4UnifiedMemoryOptimizer()

        # 1 GB block
        transfer_time = optimizer.estimate_transfer_time_ms(
            1024**3, "cpu_to_gpu"
        )

        assert transfer_time > 0
        # Larger but still reasonable on unified memory
        assert transfer_time < 100.0  # Less than 100ms

    def test_estimate_transfer_time_both_directions(self):
        """Test that transfer time is similar in both directions."""
        optimizer = M4UnifiedMemoryOptimizer()

        block_size = 10 * 1024 * 1024  # 10 MB

        time_cpu_to_gpu = optimizer.estimate_transfer_time_ms(block_size, "cpu_to_gpu")
        time_gpu_to_cpu = optimizer.estimate_transfer_time_ms(block_size, "gpu_to_cpu")

        # On unified memory, should be similar
        assert abs(time_cpu_to_gpu - time_gpu_to_cpu) < 1.0

    def test_should_use_offloading_small_context(self):
        """Test offload decision for small context."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        should_offload = optimizer.should_use_offloading(
            model_size_gb=5.0,
            max_context_length=2048,
            batch_size=4,
        )

        # Should not need offloading
        assert should_offload is False

    def test_should_use_offloading_large_context(self):
        """Test offload decision for large context."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        should_offload = optimizer.should_use_offloading(
            model_size_gb=10.0,
            max_context_length=32768,
            batch_size=16,
        )

        # Should likely need offloading
        assert isinstance(should_offload, bool)

    def test_should_use_offloading_memory_constrained(self):
        """Test offload decision with limited memory."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 16.0  # Limited memory

        should_offload = optimizer.should_use_offloading(
            model_size_gb=8.0,
            max_context_length=16384,
            batch_size=8,
        )

        # Should likely need offloading
        assert isinstance(should_offload, bool)

    def test_get_recommended_spec_small_workload(self):
        """Test recommended spec for small workload."""
        optimizer = M4UnifiedMemoryOptimizer()

        spec = optimizer.get_recommended_spec(
            model_size_gb=3.0,
            max_context_length=2048,
            batch_size=4,
        )

        assert isinstance(spec, OffloadSpec)
        # Small workload might not need offloading
        assert isinstance(spec.enabled, bool)

    def test_get_recommended_spec_large_workload(self):
        """Test recommended spec for large workload."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=15.0,
            max_context_length=32768,
            batch_size=16,
        )

        assert isinstance(spec, OffloadSpec)
        # Large workload might need offloading
        assert isinstance(spec.enabled, bool)

    def test_recommended_spec_has_valid_parameters(self):
        """Test that recommended spec has valid parameters."""
        optimizer = M4UnifiedMemoryOptimizer()

        spec = optimizer.get_recommended_spec(
            model_size_gb=7.0,
            max_context_length=8192,
            batch_size=8,
        )

        # Should not raise
        spec.validate()

    def test_recommended_spec_compression_disabled(self):
        """Test that recommended spec disables compression."""
        optimizer = M4UnifiedMemoryOptimizer()

        spec = optimizer.get_recommended_spec(
            model_size_gb=5.0,
            max_context_length=4096,
            batch_size=4,
        )

        # Unified memory is fast enough, no compression needed
        assert spec.enable_compression is False

    def test_recommended_spec_prefetch_enabled(self):
        """Test that recommended spec enables prefetch."""
        optimizer = M4UnifiedMemoryOptimizer()

        spec = optimizer.get_recommended_spec(
            model_size_gb=5.0,
            max_context_length=4096,
            batch_size=4,
        )

        # Prefetch should be enabled for performance
        assert spec.enable_prefetch is True

    def test_repr(self):
        """Test string representation."""
        optimizer = M4UnifiedMemoryOptimizer()

        repr_str = repr(optimizer)
        assert "M4UnifiedMemoryOptimizer" in repr_str
        assert "chip=M4" in repr_str
        assert "gpu_cores=" in repr_str
        assert "bandwidth=" in repr_str
        assert "memory=" in repr_str


# ============================================================================
# M4 Optimizer Configuration Tests
# ============================================================================


@pytest.mark.unit
class TestM4OptimizerConfigurations:
    """Tests for different M4 optimizer configurations."""

    def test_optimizer_7b_model(self):
        """Test optimizer recommendations for 7B model."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=4.0,  # ~7B Q4 model
            max_context_length=8192,
            batch_size=8,
        )

        assert isinstance(spec, OffloadSpec)
        spec.validate()

    def test_optimizer_13b_model(self):
        """Test optimizer recommendations for 13B model."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=7.0,  # ~13B Q4 model
            max_context_length=8192,
            batch_size=8,
        )

        assert isinstance(spec, OffloadSpec)
        spec.validate()

    def test_optimizer_70b_model(self):
        """Test optimizer recommendations for 70B model."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=35.0,  # ~70B Q4 model
            max_context_length=4096,
            batch_size=4,
        )

        assert isinstance(spec, OffloadSpec)
        # Large model likely needs offloading
        spec.validate()


# ============================================================================
# Integration Tests
# ============================================================================


@pytest.mark.unit
class TestM4SystemIntegration:
    """Integration tests for M4 offload system."""

    def test_create_and_use_system(self):
        """Test creating and using M4 system."""
        backend, manager = create_m4_offload_system()

        # System should be ready to use
        assert backend.get_memory_usage() == 0
        assert len(manager.access_times) == 0

    def test_optimizer_with_custom_system(self):
        """Test using optimizer to create custom system."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=7.0,
            max_context_length=8192,
            batch_size=8,
        )

        backend, manager = create_m4_offload_system(spec)

        assert isinstance(backend, M4MetalOffloadBackend)
        assert isinstance(manager, LRUOffloadManager)

    def test_multiple_systems_independent(self):
        """Test that multiple systems are independent."""
        backend1, manager1 = create_m4_offload_system()
        backend2, manager2 = create_m4_offload_system()

        assert backend1 is not backend2
        assert manager1 is not manager2


# ============================================================================
# Platform-Specific Tests
# ============================================================================


@pytest.mark.unit
class TestM4PlatformDetection:
    """Tests for M4 platform detection."""

    def test_bandwidth_calculation_m4_max(self):
        """Test bandwidth calculation for M4 Max."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.memory_bandwidth_gbps = 400

        # 1 GB transfer should take ~2.5ms at 80% efficiency
        transfer_time = optimizer.estimate_transfer_time_ms(1024**3, "cpu_to_gpu")

        # Should be in reasonable range
        assert 1.0 < transfer_time < 10.0

    def test_memory_detection(self):
        """Test memory detection."""
        optimizer = M4UnifiedMemoryOptimizer()

        # Should detect some memory
        assert optimizer.total_memory_gb > 0

    def test_gpu_cores_detection(self):
        """Test GPU cores detection."""
        optimizer = M4UnifiedMemoryOptimizer()

        # Should detect some GPU cores
        assert optimizer.gpu_cores > 0


# ============================================================================
# Edge Cases
# ============================================================================


@pytest.mark.unit
class TestM4EdgeCases:
    """Tests for edge cases in M4 optimizer."""

    def test_zero_model_size(self):
        """Test with zero model size."""
        optimizer = M4UnifiedMemoryOptimizer()

        block_size = optimizer.get_optimal_block_size(0.0)
        assert block_size > 0

    def test_very_large_model(self):
        """Test with very large model."""
        optimizer = M4UnifiedMemoryOptimizer()
        optimizer.total_memory_gb = 30.0

        spec = optimizer.get_recommended_spec(
            model_size_gb=100.0,  # Exceeds total memory
            max_context_length=2048,
            batch_size=1,
        )

        # Should still return valid spec
        spec.validate()

    def test_zero_context_length(self):
        """Test with zero context length."""
        optimizer = M4UnifiedMemoryOptimizer()

        should_offload = optimizer.should_use_offloading(
            model_size_gb=5.0,
            max_context_length=0,
            batch_size=1,
        )

        assert isinstance(should_offload, bool)

    def test_zero_batch_size(self):
        """Test with zero batch size."""
        optimizer = M4UnifiedMemoryOptimizer()

        should_offload = optimizer.should_use_offloading(
            model_size_gb=5.0,
            max_context_length=2048,
            batch_size=0,
        )

        assert isinstance(should_offload, bool)
