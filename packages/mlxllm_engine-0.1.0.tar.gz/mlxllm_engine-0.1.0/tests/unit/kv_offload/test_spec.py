# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache offload specification."""

from __future__ import annotations

import pytest

from mlxllm.kv_offload.spec import (
    EvictionPolicy,
    OffloadMedium,
    OffloadPolicy,
    OffloadSpec,
)


# ============================================================================
# Enum Tests
# ============================================================================


@pytest.mark.unit
class TestOffloadMedium:
    """Tests for OffloadMedium enum."""

    def test_enum_values(self):
        """Test enum values exist."""
        assert OffloadMedium.CPU.value == "cpu"
        assert OffloadMedium.DISK.value == "disk"
        assert OffloadMedium.NETWORK.value == "network"

    def test_enum_members(self):
        """Test all enum members."""
        members = [m for m in OffloadMedium]
        assert len(members) == 3
        assert OffloadMedium.CPU in members
        assert OffloadMedium.DISK in members
        assert OffloadMedium.NETWORK in members


@pytest.mark.unit
class TestOffloadPolicy:
    """Tests for OffloadPolicy enum."""

    def test_enum_values(self):
        """Test enum values exist."""
        assert OffloadPolicy.NEVER.value == "never"
        assert OffloadPolicy.ON_DEMAND.value == "on_demand"
        assert OffloadPolicy.PROACTIVE.value == "proactive"
        assert OffloadPolicy.ALWAYS.value == "always"

    def test_enum_members(self):
        """Test all enum members."""
        members = [m for m in OffloadPolicy]
        assert len(members) == 4
        assert OffloadPolicy.NEVER in members
        assert OffloadPolicy.ON_DEMAND in members
        assert OffloadPolicy.PROACTIVE in members
        assert OffloadPolicy.ALWAYS in members


@pytest.mark.unit
class TestEvictionPolicy:
    """Tests for EvictionPolicy enum."""

    def test_enum_values(self):
        """Test enum values exist."""
        assert EvictionPolicy.LRU.value == "lru"
        assert EvictionPolicy.LFU.value == "lfu"
        assert EvictionPolicy.FIFO.value == "fifo"
        assert EvictionPolicy.RANDOM.value == "random"

    def test_enum_members(self):
        """Test all enum members."""
        members = [m for m in EvictionPolicy]
        assert len(members) == 4
        assert EvictionPolicy.LRU in members
        assert EvictionPolicy.LFU in members
        assert EvictionPolicy.FIFO in members
        assert EvictionPolicy.RANDOM in members


# ============================================================================
# OffloadSpec Tests
# ============================================================================


@pytest.mark.unit
class TestOffloadSpec:
    """Tests for OffloadSpec dataclass."""

    def test_default_initialization(self):
        """Test default spec initialization."""
        spec = OffloadSpec()

        assert spec.enabled is False
        assert spec.medium == OffloadMedium.CPU
        assert spec.policy == OffloadPolicy.ON_DEMAND
        assert spec.eviction_policy == EvictionPolicy.LRU
        assert spec.max_offload_memory_gb == 16.0
        assert spec.offload_threshold_ratio == 0.9
        assert spec.load_threshold_ratio == 0.8
        assert spec.enable_compression is False
        assert spec.compression_level == 1
        assert spec.enable_prefetch is True
        assert spec.prefetch_window == 2

    def test_custom_initialization(self):
        """Test spec with custom values."""
        spec = OffloadSpec(
            enabled=True,
            medium=OffloadMedium.DISK,
            policy=OffloadPolicy.PROACTIVE,
            eviction_policy=EvictionPolicy.LFU,
            max_offload_memory_gb=32.0,
            offload_threshold_ratio=0.85,
            load_threshold_ratio=0.75,
            enable_compression=True,
            compression_level=5,
            enable_prefetch=False,
            prefetch_window=4,
        )

        assert spec.enabled is True
        assert spec.medium == OffloadMedium.DISK
        assert spec.policy == OffloadPolicy.PROACTIVE
        assert spec.eviction_policy == EvictionPolicy.LFU
        assert spec.max_offload_memory_gb == 32.0
        assert spec.offload_threshold_ratio == 0.85
        assert spec.load_threshold_ratio == 0.75
        assert spec.enable_compression is True
        assert spec.compression_level == 5
        assert spec.enable_prefetch is False
        assert spec.prefetch_window == 4

    def test_validate_valid_spec(self):
        """Test validation of valid spec."""
        spec = OffloadSpec(
            enabled=True,
            max_offload_memory_gb=16.0,
            offload_threshold_ratio=0.9,
            load_threshold_ratio=0.8,
        )

        # Should not raise
        spec.validate()

    def test_validate_negative_max_memory(self):
        """Test validation fails for negative max memory."""
        spec = OffloadSpec(max_offload_memory_gb=-1.0)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "max_offload_memory_gb must be positive" in str(exc_info.value)

    def test_validate_zero_max_memory(self):
        """Test validation fails for zero max memory."""
        spec = OffloadSpec(max_offload_memory_gb=0.0)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "max_offload_memory_gb must be positive" in str(exc_info.value)

    def test_validate_offload_threshold_too_low(self):
        """Test validation fails for offload threshold <= 0."""
        spec = OffloadSpec(offload_threshold_ratio=0.0)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "offload_threshold_ratio must be in (0, 1]" in str(exc_info.value)

    def test_validate_offload_threshold_too_high(self):
        """Test validation fails for offload threshold > 1."""
        spec = OffloadSpec(offload_threshold_ratio=1.5)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "offload_threshold_ratio must be in (0, 1]" in str(exc_info.value)

    def test_validate_load_threshold_too_low(self):
        """Test validation fails for load threshold <= 0."""
        spec = OffloadSpec(load_threshold_ratio=0.0)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "load_threshold_ratio must be in (0, 1]" in str(exc_info.value)

    def test_validate_load_threshold_too_high(self):
        """Test validation fails for load threshold > 1."""
        spec = OffloadSpec(load_threshold_ratio=1.5)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "load_threshold_ratio must be in (0, 1]" in str(exc_info.value)

    def test_validate_load_threshold_exceeds_offload(self):
        """Test validation fails when load > offload threshold."""
        spec = OffloadSpec(
            offload_threshold_ratio=0.8,
            load_threshold_ratio=0.9,
        )

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "load_threshold_ratio must be <= offload_threshold_ratio" in str(
            exc_info.value
        )

    def test_validate_compression_level_too_low(self):
        """Test validation fails for compression level < 1."""
        spec = OffloadSpec(compression_level=0)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "compression_level must be in [1, 9]" in str(exc_info.value)

    def test_validate_compression_level_too_high(self):
        """Test validation fails for compression level > 9."""
        spec = OffloadSpec(compression_level=10)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "compression_level must be in [1, 9]" in str(exc_info.value)

    def test_validate_negative_prefetch_window(self):
        """Test validation fails for negative prefetch window."""
        spec = OffloadSpec(prefetch_window=-1)

        with pytest.raises(ValueError) as exc_info:
            spec.validate()

        assert "prefetch_window must be non-negative" in str(exc_info.value)

    def test_uses_cpu_property(self):
        """Test uses_cpu property."""
        spec_cpu = OffloadSpec(medium=OffloadMedium.CPU)
        spec_disk = OffloadSpec(medium=OffloadMedium.DISK)

        assert spec_cpu.uses_cpu is True
        assert spec_disk.uses_cpu is False

    def test_uses_disk_property(self):
        """Test uses_disk property."""
        spec_cpu = OffloadSpec(medium=OffloadMedium.CPU)
        spec_disk = OffloadSpec(medium=OffloadMedium.DISK)

        assert spec_cpu.uses_disk is False
        assert spec_disk.uses_disk is True

    def test_uses_network_property(self):
        """Test uses_network property."""
        spec_cpu = OffloadSpec(medium=OffloadMedium.CPU)
        spec_network = OffloadSpec(medium=OffloadMedium.NETWORK)

        assert spec_cpu.uses_network is False
        assert spec_network.uses_network is True

    def test_repr_disabled(self):
        """Test string representation when disabled."""
        spec = OffloadSpec(enabled=False)

        repr_str = repr(spec)
        assert "OffloadSpec(disabled)" == repr_str

    def test_repr_enabled(self):
        """Test string representation when enabled."""
        spec = OffloadSpec(
            enabled=True,
            medium=OffloadMedium.CPU,
            policy=OffloadPolicy.ON_DEMAND,
            eviction_policy=EvictionPolicy.LRU,
            max_offload_memory_gb=16.0,
            offload_threshold_ratio=0.9,
        )

        repr_str = repr(spec)
        assert "OffloadSpec(" in repr_str
        assert "medium=cpu" in repr_str
        assert "policy=on_demand" in repr_str
        assert "eviction=lru" in repr_str
        assert "max_memory=16.0GB" in repr_str
        assert "threshold=90%" in repr_str


# ============================================================================
# OffloadSpec Configuration Tests
# ============================================================================


@pytest.mark.unit
class TestOffloadSpecConfigurations:
    """Tests for common OffloadSpec configurations."""

    def test_minimal_configuration(self):
        """Test minimal valid configuration."""
        spec = OffloadSpec(
            enabled=True,
            max_offload_memory_gb=1.0,
            offload_threshold_ratio=0.9,
            load_threshold_ratio=0.8,
        )

        spec.validate()  # Should not raise

    def test_aggressive_offload_configuration(self):
        """Test aggressive offload configuration."""
        spec = OffloadSpec(
            enabled=True,
            policy=OffloadPolicy.PROACTIVE,
            offload_threshold_ratio=0.7,
            load_threshold_ratio=0.6,
            max_offload_memory_gb=32.0,
        )

        spec.validate()

    def test_conservative_offload_configuration(self):
        """Test conservative offload configuration."""
        spec = OffloadSpec(
            enabled=True,
            policy=OffloadPolicy.ON_DEMAND,
            offload_threshold_ratio=0.95,
            load_threshold_ratio=0.9,
            max_offload_memory_gb=8.0,
        )

        spec.validate()

    def test_disk_with_compression_configuration(self):
        """Test disk storage with compression."""
        spec = OffloadSpec(
            enabled=True,
            medium=OffloadMedium.DISK,
            enable_compression=True,
            compression_level=9,
            max_offload_memory_gb=100.0,
        )

        spec.validate()

    def test_cpu_with_prefetch_configuration(self):
        """Test CPU storage with prefetching."""
        spec = OffloadSpec(
            enabled=True,
            medium=OffloadMedium.CPU,
            enable_prefetch=True,
            prefetch_window=4,
        )

        spec.validate()

    def test_no_offload_configuration(self):
        """Test configuration with offloading disabled."""
        spec = OffloadSpec(
            enabled=False,
            policy=OffloadPolicy.NEVER,
        )

        spec.validate()


# ============================================================================
# Edge Cases
# ============================================================================


@pytest.mark.unit
class TestOffloadSpecEdgeCases:
    """Tests for edge cases in OffloadSpec."""

    def test_threshold_at_boundary(self):
        """Test thresholds at valid boundaries."""
        spec = OffloadSpec(
            offload_threshold_ratio=1.0,
            load_threshold_ratio=1.0,
        )

        spec.validate()  # Should not raise

    def test_equal_thresholds(self):
        """Test equal load and offload thresholds."""
        spec = OffloadSpec(
            offload_threshold_ratio=0.85,
            load_threshold_ratio=0.85,
        )

        spec.validate()  # Should not raise

    def test_compression_level_boundaries(self):
        """Test compression level at boundaries."""
        spec_min = OffloadSpec(compression_level=1)
        spec_max = OffloadSpec(compression_level=9)

        spec_min.validate()
        spec_max.validate()

    def test_zero_prefetch_window(self):
        """Test zero prefetch window."""
        spec = OffloadSpec(prefetch_window=0)

        spec.validate()  # Should not raise

    def test_very_large_memory(self):
        """Test very large max memory."""
        spec = OffloadSpec(max_offload_memory_gb=10000.0)

        spec.validate()

    def test_very_small_memory(self):
        """Test very small but positive max memory."""
        spec = OffloadSpec(max_offload_memory_gb=0.001)

        spec.validate()


# ============================================================================
# Property Tests
# ============================================================================


@pytest.mark.unit
class TestOffloadSpecProperties:
    """Tests for OffloadSpec properties."""

    def test_all_medium_properties(self):
        """Test all medium detection properties."""
        for medium in OffloadMedium:
            spec = OffloadSpec(medium=medium)

            if medium == OffloadMedium.CPU:
                assert spec.uses_cpu
                assert not spec.uses_disk
                assert not spec.uses_network
            elif medium == OffloadMedium.DISK:
                assert not spec.uses_cpu
                assert spec.uses_disk
                assert not spec.uses_network
            elif medium == OffloadMedium.NETWORK:
                assert not spec.uses_cpu
                assert not spec.uses_disk
                assert spec.uses_network

    def test_multiple_specs_independent(self):
        """Test that multiple specs are independent."""
        spec1 = OffloadSpec(enabled=True)
        spec2 = OffloadSpec(enabled=False)

        assert spec1.enabled != spec2.enabled

    def test_repr_format_consistency(self):
        """Test repr format is consistent."""
        specs = [
            OffloadSpec(enabled=False),
            OffloadSpec(enabled=True, medium=OffloadMedium.CPU),
            OffloadSpec(enabled=True, medium=OffloadMedium.DISK),
        ]

        for spec in specs:
            repr_str = repr(spec)
            assert isinstance(repr_str, str)
            assert "OffloadSpec" in repr_str
