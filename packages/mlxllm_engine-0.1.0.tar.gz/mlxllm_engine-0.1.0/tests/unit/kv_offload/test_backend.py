# SPDX-License-Identifier: Apache-2.0
"""Tests for generic KV cache offload backend."""

from __future__ import annotations

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.kv_offload.backend import GenericOffloadBackend
from mlxllm.kv_offload.mediums import (
    CPUMemoryMedium,
    DiskMedium,
    CompressedMemoryMedium,
)
from mlxllm.kv_offload.abstract import OffloadStats


# ============================================================================
# GenericOffloadBackend Tests
# ============================================================================


@pytest.mark.unit
class TestGenericOffloadBackend:
    """Tests for GenericOffloadBackend."""

    def test_initialization_default(self):
        """Test default initialization with CPU memory medium."""
        backend = GenericOffloadBackend()

        # Should use CPU memory medium by default
        assert isinstance(backend.storage, CPUMemoryMedium)
        assert isinstance(backend.stats, OffloadStats)

    def test_initialization_custom_max_memory(self):
        """Test initialization with custom max memory."""
        backend = GenericOffloadBackend(max_cpu_memory_gb=8.0)

        assert backend.storage.max_memory_bytes == 8 * 1024**3

    def test_initialization_with_custom_medium(self):
        """Test initialization with custom storage medium."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            disk_medium = DiskMedium(cache_dir=tmpdir)
            backend = GenericOffloadBackend(storage_medium=disk_medium)

            assert isinstance(backend.storage, DiskMedium)
            assert backend.storage.cache_dir.as_posix() == tmpdir

    def test_offload_block(self):
        """Test offloading a block."""
        backend = GenericOffloadBackend()

        # Create test data
        kv_data = mx.random.normal((2, 16, 8, 64))

        # Offload
        backend.offload_block(0, kv_data)

        # Verify block is stored
        assert backend.has_block(0)

        # Check stats
        stats = backend.get_stats()
        assert stats.num_offloaded_blocks == 1
        assert stats.bytes_offloaded > 0
        assert stats.offload_time_ms > 0

    def test_offload_multiple_blocks(self):
        """Test offloading multiple blocks."""
        backend = GenericOffloadBackend()

        kv_data1 = mx.random.normal((2, 16, 8, 64))
        kv_data2 = mx.random.normal((2, 16, 8, 64))
        kv_data3 = mx.random.normal((2, 16, 8, 64))

        backend.offload_block(0, kv_data1)
        backend.offload_block(1, kv_data2)
        backend.offload_block(2, kv_data3)

        assert backend.has_block(0)
        assert backend.has_block(1)
        assert backend.has_block(2)

        stats = backend.get_stats()
        assert stats.num_offloaded_blocks == 3

    def test_load_block(self):
        """Test loading a block."""
        backend = GenericOffloadBackend()

        # Create and offload test data
        original_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, original_data)

        # Load
        loaded_data = backend.load_block(0)

        assert loaded_data is not None
        assert loaded_data.shape == original_data.shape

        # Check stats
        stats = backend.get_stats()
        assert stats.num_loaded_blocks == 1
        assert stats.bytes_loaded > 0
        assert stats.load_time_ms > 0

    def test_load_nonexistent_block(self):
        """Test loading a block that doesn't exist."""
        backend = GenericOffloadBackend()

        loaded = backend.load_block(999)
        assert loaded is None

    def test_has_block(self):
        """Test checking if block exists."""
        backend = GenericOffloadBackend()

        assert not backend.has_block(0)

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        assert backend.has_block(0)

    def test_free_block(self):
        """Test freeing a block."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        assert backend.has_block(0)

        backend.free_block(0)
        assert not backend.has_block(0)

    def test_get_stats(self):
        """Test getting statistics."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        stats = backend.get_stats()
        assert isinstance(stats, OffloadStats)
        assert stats.num_offloaded_blocks == 1
        assert stats.bytes_offloaded > 0

    def test_reset_stats(self):
        """Test resetting statistics."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        # Reset
        backend.reset_stats()

        stats = backend.get_stats()
        assert stats.num_offloaded_blocks == 0
        assert stats.bytes_offloaded == 0
        assert stats.offload_time_ms == 0.0

    def test_get_memory_usage(self):
        """Test getting memory usage."""
        backend = GenericOffloadBackend()

        # Initially empty
        assert backend.get_memory_usage() == 0

        # Add some blocks
        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        memory_usage = backend.get_memory_usage()
        assert memory_usage > 0

    def test_clear(self):
        """Test clearing all blocks."""
        backend = GenericOffloadBackend()

        kv_data1 = mx.random.normal((2, 16, 8, 64))
        kv_data2 = mx.random.normal((2, 16, 8, 64))

        backend.offload_block(0, kv_data1)
        backend.offload_block(1, kv_data2)

        backend.clear()

        assert not backend.has_block(0)
        assert not backend.has_block(1)
        assert backend.get_memory_usage() == 0

    def test_get_num_blocks(self):
        """Test getting number of blocks."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)
        backend.offload_block(1, kv_data)

        # This is an estimate based on stats
        num_blocks = backend.get_num_blocks()
        assert num_blocks == 2

    def test_offload_load_cycle(self):
        """Test full offload-load cycle preserves data."""
        backend = GenericOffloadBackend()

        # Create test data
        original_data = mx.ones((2, 16, 8, 64))
        backend.offload_block(0, original_data)

        # Load back
        loaded_data = backend.load_block(0)

        assert loaded_data is not None
        assert loaded_data.shape == original_data.shape
        # Check data integrity
        assert mx.allclose(loaded_data, original_data)

    def test_memory_limit_enforcement(self):
        """Test that memory limit is enforced."""
        # Very small memory limit
        backend = GenericOffloadBackend(max_cpu_memory_gb=0.001)  # 1 MB

        # Try to offload large block
        large_data = mx.random.normal((100, 100, 100, 100))

        # Should not raise, but warning printed
        backend.offload_block(0, large_data)

        # Block should not be stored
        assert not backend.has_block(0)

    def test_with_disk_medium(self):
        """Test backend with disk storage medium."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            disk_medium = DiskMedium(cache_dir=tmpdir)
            backend = GenericOffloadBackend(storage_medium=disk_medium)

            kv_data = mx.random.normal((2, 16, 8, 64))
            backend.offload_block(0, kv_data)

            assert backend.has_block(0)

            loaded = backend.load_block(0)
            assert loaded is not None

    def test_with_compressed_medium(self):
        """Test backend with compressed storage medium."""
        compressed_medium = CompressedMemoryMedium(
            max_memory_bytes=1024**3,
            compression_level=5,
        )
        backend = GenericOffloadBackend(storage_medium=compressed_medium)

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        assert backend.has_block(0)

        loaded = backend.load_block(0)
        assert loaded is not None
        assert mx.allclose(loaded, kv_data)

    def test_offload_timing(self):
        """Test that timing is tracked for offload operations."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        stats = backend.get_stats()
        # Should have some time recorded
        assert stats.offload_time_ms > 0
        # Typically should be fast (< 100ms for small blocks)
        assert stats.offload_time_ms < 1000

    def test_load_timing(self):
        """Test that timing is tracked for load operations."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        # Reset to clear offload timing
        backend.reset_stats()

        backend.load_block(0)

        stats = backend.get_stats()
        assert stats.load_time_ms > 0

    def test_stats_accumulate(self):
        """Test that stats accumulate across operations."""
        backend = GenericOffloadBackend()

        kv_data = mx.random.normal((2, 16, 8, 64))

        # Multiple offloads
        backend.offload_block(0, kv_data)
        backend.offload_block(1, kv_data)

        stats = backend.get_stats()
        assert stats.num_offloaded_blocks == 2

        # Multiple loads
        backend.load_block(0)
        backend.load_block(1)

        stats = backend.get_stats()
        assert stats.num_loaded_blocks == 2

    def test_bandwidth_calculation(self):
        """Test bandwidth calculation in stats."""
        backend = GenericOffloadBackend()

        # Offload some data
        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        stats = backend.get_stats()

        # Should have non-zero bandwidth
        assert stats.avg_offload_bandwidth_gbps >= 0

    def test_repr(self):
        """Test string representation."""
        backend = GenericOffloadBackend(max_cpu_memory_gb=4.0)

        kv_data = mx.random.normal((2, 16, 8, 64))
        backend.offload_block(0, kv_data)

        repr_str = repr(backend)
        assert "GenericOffloadBackend" in repr_str
        assert "storage=" in repr_str
        assert "offloaded=1" in repr_str


# ============================================================================
# Integration Tests with Different Mediums
# ============================================================================


@pytest.mark.unit
class TestGenericBackendIntegration:
    """Integration tests for backend with various storage mediums."""

    def test_multiple_block_operations_cpu_medium(self):
        """Test multiple operations with CPU medium."""
        backend = GenericOffloadBackend(max_cpu_memory_gb=1.0)

        # Offload several blocks
        for i in range(5):
            kv_data = mx.random.normal((2, 16, 8, 64))
            backend.offload_block(i, kv_data)

        # Load some blocks
        for i in range(3):
            loaded = backend.load_block(i)
            assert loaded is not None

        # Free some blocks
        backend.free_block(0)
        backend.free_block(1)

        # Check state
        assert not backend.has_block(0)
        assert not backend.has_block(1)
        assert backend.has_block(2)
        assert backend.has_block(3)
        assert backend.has_block(4)

    def test_multiple_block_operations_disk_medium(self):
        """Test multiple operations with disk medium."""
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            disk_medium = DiskMedium(cache_dir=tmpdir)
            backend = GenericOffloadBackend(storage_medium=disk_medium)

            # Offload several blocks
            for i in range(5):
                kv_data = mx.random.normal((2, 16, 8, 64))
                backend.offload_block(i, kv_data)

            # Verify all blocks exist
            for i in range(5):
                assert backend.has_block(i)

            # Clear
            backend.clear()

            # Verify all blocks removed
            for i in range(5):
                assert not backend.has_block(i)

    def test_data_integrity_across_mediums(self):
        """Test data integrity across different storage mediums."""
        import tempfile

        original_data = mx.ones((2, 16, 8, 64))

        # Test CPU medium
        backend_cpu = GenericOffloadBackend()
        backend_cpu.offload_block(0, original_data)
        loaded_cpu = backend_cpu.load_block(0)
        assert mx.allclose(loaded_cpu, original_data)

        # Test Disk medium
        with tempfile.TemporaryDirectory() as tmpdir:
            backend_disk = GenericOffloadBackend(
                storage_medium=DiskMedium(cache_dir=tmpdir)
            )
            backend_disk.offload_block(0, original_data)
            loaded_disk = backend_disk.load_block(0)
            assert mx.allclose(loaded_disk, original_data)

        # Test Compressed medium
        backend_compressed = GenericOffloadBackend(
            storage_medium=CompressedMemoryMedium()
        )
        backend_compressed.offload_block(0, original_data)
        loaded_compressed = backend_compressed.load_block(0)
        assert mx.allclose(loaded_compressed, original_data)
