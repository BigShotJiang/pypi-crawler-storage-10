# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache offload abstract base classes."""

from __future__ import annotations

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.kv_offload.abstract import (
    KVOffloadBackend,
    KVOffloadManager,
    OffloadStats,
)


# ============================================================================
# OffloadStats Tests
# ============================================================================


@pytest.mark.unit
class TestOffloadStats:
    """Tests for OffloadStats dataclass."""

    def test_initialization_defaults(self):
        """Test default initialization of OffloadStats."""
        stats = OffloadStats()
        assert stats.num_offloaded_blocks == 0
        assert stats.num_loaded_blocks == 0
        assert stats.bytes_offloaded == 0
        assert stats.bytes_loaded == 0
        assert stats.offload_time_ms == 0.0
        assert stats.load_time_ms == 0.0

    def test_initialization_with_values(self):
        """Test initialization with custom values."""
        stats = OffloadStats(
            num_offloaded_blocks=10,
            num_loaded_blocks=5,
            bytes_offloaded=1024,
            bytes_loaded=512,
            offload_time_ms=100.0,
            load_time_ms=50.0,
        )
        assert stats.num_offloaded_blocks == 10
        assert stats.num_loaded_blocks == 5
        assert stats.bytes_offloaded == 1024
        assert stats.bytes_loaded == 512
        assert stats.offload_time_ms == 100.0
        assert stats.load_time_ms == 50.0

    def test_total_bytes_transferred(self):
        """Test total_bytes_transferred property."""
        stats = OffloadStats(
            bytes_offloaded=1024,
            bytes_loaded=512,
        )
        assert stats.total_bytes_transferred == 1536

    def test_total_time_ms(self):
        """Test total_time_ms property."""
        stats = OffloadStats(
            offload_time_ms=100.0,
            load_time_ms=50.0,
        )
        assert stats.total_time_ms == 150.0

    def test_avg_offload_bandwidth_gbps_zero_time(self):
        """Test avg_offload_bandwidth_gbps with zero time."""
        stats = OffloadStats(
            bytes_offloaded=1024,
            offload_time_ms=0.0,
        )
        assert stats.avg_offload_bandwidth_gbps == 0.0

    def test_avg_offload_bandwidth_gbps(self):
        """Test avg_offload_bandwidth_gbps calculation."""
        # 1 GB in 1000 ms = 1 GB/s
        stats = OffloadStats(
            bytes_offloaded=1024**3,
            offload_time_ms=1000.0,
        )
        assert stats.avg_offload_bandwidth_gbps == pytest.approx(1.0)

    def test_avg_load_bandwidth_gbps_zero_time(self):
        """Test avg_load_bandwidth_gbps with zero time."""
        stats = OffloadStats(
            bytes_loaded=1024,
            load_time_ms=0.0,
        )
        assert stats.avg_load_bandwidth_gbps == 0.0

    def test_avg_load_bandwidth_gbps(self):
        """Test avg_load_bandwidth_gbps calculation."""
        # 2 GB in 1000 ms = 2 GB/s
        stats = OffloadStats(
            bytes_loaded=2 * 1024**3,
            load_time_ms=1000.0,
        )
        assert stats.avg_load_bandwidth_gbps == pytest.approx(2.0)

    def test_mixed_operations_bandwidth(self):
        """Test bandwidth calculations with mixed offload/load operations."""
        # Offload: 1 GB in 500 ms = 2 GB/s
        # Load: 500 MB in 1000 ms = 0.5 GB/s
        stats = OffloadStats(
            bytes_offloaded=1024**3,
            offload_time_ms=500.0,
            bytes_loaded=512 * 1024**2,
            load_time_ms=1000.0,
        )
        assert stats.avg_offload_bandwidth_gbps == pytest.approx(2.0, rel=0.01)
        assert stats.avg_load_bandwidth_gbps == pytest.approx(0.5, rel=0.01)


# ============================================================================
# KVOffloadBackend Tests (Abstract)
# ============================================================================


@pytest.mark.unit
class TestKVOffloadBackend:
    """Tests for KVOffloadBackend abstract base class."""

    def test_cannot_instantiate_abstract_backend(self):
        """Test that abstract backend cannot be instantiated."""
        with pytest.raises(TypeError):
            KVOffloadBackend()  # type: ignore

    def test_abstract_methods_defined(self):
        """Test that all abstract methods are defined."""
        abstract_methods = {
            "offload_block",
            "load_block",
            "has_block",
            "free_block",
            "get_stats",
            "reset_stats",
            "get_memory_usage",
            "clear",
        }

        # Get abstract methods from the class
        cls_abstract_methods = set()
        for name in dir(KVOffloadBackend):
            attr = getattr(KVOffloadBackend, name)
            if getattr(attr, "__isabstractmethod__", False):
                cls_abstract_methods.add(name)

        assert abstract_methods == cls_abstract_methods


# ============================================================================
# KVOffloadManager Tests (Abstract)
# ============================================================================


@pytest.mark.unit
class TestKVOffloadManager:
    """Tests for KVOffloadManager abstract base class."""

    def test_cannot_instantiate_abstract_manager(self):
        """Test that abstract manager cannot be instantiated."""
        with pytest.raises(TypeError):
            KVOffloadManager()  # type: ignore

    def test_abstract_methods_defined(self):
        """Test that all abstract methods are defined."""
        abstract_methods = {
            "should_offload",
            "select_blocks_to_offload",
            "record_access",
        }

        # Get abstract methods from the class
        cls_abstract_methods = set()
        for name in dir(KVOffloadManager):
            attr = getattr(KVOffloadManager, name)
            if getattr(attr, "__isabstractmethod__", False):
                cls_abstract_methods.add(name)

        assert abstract_methods == cls_abstract_methods


# ============================================================================
# Mock Backend for Testing
# ============================================================================


class MockKVOffloadBackend(KVOffloadBackend):
    """Mock implementation for testing."""

    def __init__(self):
        self.blocks = {}
        self.stats = OffloadStats()

    def offload_block(self, block_id: int, kv_data: mx.array) -> None:
        self.blocks[block_id] = np.array(kv_data)
        self.stats.num_offloaded_blocks += 1
        self.stats.bytes_offloaded += self.blocks[block_id].nbytes

    def load_block(self, block_id: int) -> mx.array | None:
        if block_id not in self.blocks:
            return None
        self.stats.num_loaded_blocks += 1
        self.stats.bytes_loaded += self.blocks[block_id].nbytes
        return mx.array(self.blocks[block_id])

    def has_block(self, block_id: int) -> bool:
        return block_id in self.blocks

    def free_block(self, block_id: int) -> None:
        if block_id in self.blocks:
            del self.blocks[block_id]

    def get_stats(self) -> OffloadStats:
        return self.stats

    def reset_stats(self) -> None:
        self.stats = OffloadStats()

    def get_memory_usage(self) -> int:
        return sum(arr.nbytes for arr in self.blocks.values())

    def clear(self) -> None:
        self.blocks.clear()


@pytest.mark.unit
class TestMockBackendImplementation:
    """Tests for mock backend to verify interface works correctly."""

    def test_offload_and_load_block(self):
        """Test basic offload and load operations."""
        backend = MockKVOffloadBackend()

        # Create test data
        test_data = mx.ones((2, 16, 8, 64))

        # Offload
        backend.offload_block(0, test_data)
        assert backend.has_block(0)

        # Load
        loaded = backend.load_block(0)
        assert loaded is not None
        assert loaded.shape == test_data.shape

    def test_stats_tracking(self):
        """Test that stats are tracked correctly."""
        backend = MockKVOffloadBackend()
        test_data = mx.ones((2, 16, 8, 64))

        backend.offload_block(0, test_data)
        stats = backend.get_stats()

        assert stats.num_offloaded_blocks == 1
        assert stats.bytes_offloaded > 0

    def test_free_block(self):
        """Test freeing blocks."""
        backend = MockKVOffloadBackend()
        test_data = mx.ones((2, 16, 8, 64))

        backend.offload_block(0, test_data)
        assert backend.has_block(0)

        backend.free_block(0)
        assert not backend.has_block(0)

    def test_clear(self):
        """Test clearing all blocks."""
        backend = MockKVOffloadBackend()
        test_data = mx.ones((2, 16, 8, 64))

        backend.offload_block(0, test_data)
        backend.offload_block(1, test_data)

        backend.clear()
        assert not backend.has_block(0)
        assert not backend.has_block(1)


# ============================================================================
# Mock Manager for Testing
# ============================================================================


class MockKVOffloadManager(KVOffloadManager):
    """Mock implementation for testing."""

    def __init__(self):
        self.access_log = []

    def should_offload(self, num_free_gpu_blocks: int) -> bool:
        return num_free_gpu_blocks < 10

    def select_blocks_to_offload(
        self,
        block_access_times: dict[int, float],
        num_blocks_needed: int,
    ) -> list[int]:
        # Return oldest blocks
        sorted_blocks = sorted(block_access_times.items(), key=lambda x: x[1])
        return [block_id for block_id, _ in sorted_blocks[:num_blocks_needed]]

    def record_access(self, block_id: int, access_time: float) -> None:
        self.access_log.append((block_id, access_time))


@pytest.mark.unit
class TestMockManagerImplementation:
    """Tests for mock manager to verify interface works correctly."""

    def test_should_offload(self):
        """Test offload decision logic."""
        manager = MockKVOffloadManager()

        assert manager.should_offload(5) is True
        assert manager.should_offload(15) is False

    def test_select_blocks_to_offload(self):
        """Test block selection logic."""
        manager = MockKVOffloadManager()

        access_times = {
            0: 1.0,
            1: 2.0,
            2: 0.5,
            3: 3.0,
        }

        selected = manager.select_blocks_to_offload(access_times, 2)
        assert len(selected) == 2
        assert 2 in selected  # Oldest access
        assert 0 in selected  # Second oldest

    def test_record_access(self):
        """Test access recording."""
        manager = MockKVOffloadManager()

        manager.record_access(0, 1.0)
        manager.record_access(1, 2.0)

        assert len(manager.access_log) == 2
        assert manager.access_log[0] == (0, 1.0)
        assert manager.access_log[1] == (1, 2.0)
