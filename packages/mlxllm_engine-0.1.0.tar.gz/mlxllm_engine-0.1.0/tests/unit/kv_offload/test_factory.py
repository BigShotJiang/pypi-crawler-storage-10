# SPDX-License-Identifier: Apache-2.0
"""Tests for KV cache offload factory functions."""

from __future__ import annotations

import platform
from unittest.mock import patch

import pytest

from mlxllm.kv_offload.factory import create_offload_backend, create_offload_manager
from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend
from mlxllm.kv_offload.lru_manager import LRUOffloadManager
from mlxllm.kv_offload.abstract import KVOffloadBackend, KVOffloadManager


# ============================================================================
# create_offload_backend Tests
# ============================================================================


@pytest.mark.unit
class TestCreateOffloadBackend:
    """Tests for create_offload_backend factory function."""

    def test_create_backend_auto_apple_silicon(self):
        """Test auto backend creation on Apple Silicon."""
        with patch("platform.system", return_value="Darwin"), patch(
            "platform.machine", return_value="arm64"
        ):
            backend = create_offload_backend(backend_type="auto")

            assert isinstance(backend, M4MetalOffloadBackend)

    def test_create_backend_auto_other_platform(self):
        """Test auto backend creation on other platforms."""
        with patch("platform.system", return_value="Linux"), patch(
            "platform.machine", return_value="x86_64"
        ):
            backend = create_offload_backend(backend_type="auto")

            # Should still create M4Metal backend as fallback
            assert isinstance(backend, M4MetalOffloadBackend)

    def test_create_backend_m4metal_explicit(self):
        """Test explicit M4 Metal backend creation."""
        backend = create_offload_backend(backend_type="m4metal")

        assert isinstance(backend, M4MetalOffloadBackend)
        assert isinstance(backend, KVOffloadBackend)

    def test_create_backend_default_params(self):
        """Test backend creation with default parameters."""
        backend = create_offload_backend()

        assert isinstance(backend, M4MetalOffloadBackend)
        assert backend.max_cpu_memory_bytes == 16 * 1024**3  # 16 GB default

    def test_create_backend_custom_max_memory(self):
        """Test backend creation with custom max memory."""
        backend = create_offload_backend(
            backend_type="m4metal",
            max_cpu_memory_gb=8.0,
        )

        assert backend.max_cpu_memory_bytes == 8 * 1024**3

    def test_create_backend_with_compression_enabled(self):
        """Test backend creation with compression enabled."""
        backend = create_offload_backend(
            backend_type="m4metal",
            enable_compression=True,
        )

        assert backend.enable_compression is True

    def test_create_backend_with_compression_disabled(self):
        """Test backend creation with compression disabled."""
        backend = create_offload_backend(
            backend_type="m4metal",
            enable_compression=False,
        )

        assert backend.enable_compression is False

    def test_create_backend_unknown_type(self):
        """Test backend creation with unknown type."""
        with pytest.raises(ValueError) as exc_info:
            create_offload_backend(backend_type="unknown")

        assert "Unknown offload backend type" in str(exc_info.value)
        assert "unknown" in str(exc_info.value)

    def test_create_backend_custom_parameters(self):
        """Test backend creation with all custom parameters."""
        backend = create_offload_backend(
            backend_type="m4metal",
            max_cpu_memory_gb=4.0,
            enable_compression=True,
        )

        assert backend.max_cpu_memory_bytes == 4 * 1024**3
        assert backend.enable_compression is True

    def test_create_backend_interface_compliance(self):
        """Test that created backend implements correct interface."""
        backend = create_offload_backend()

        # Check that all required methods exist
        assert hasattr(backend, "offload_block")
        assert hasattr(backend, "load_block")
        assert hasattr(backend, "has_block")
        assert hasattr(backend, "free_block")
        assert hasattr(backend, "get_stats")
        assert hasattr(backend, "reset_stats")
        assert hasattr(backend, "get_memory_usage")
        assert hasattr(backend, "clear")


# ============================================================================
# create_offload_manager Tests
# ============================================================================


@pytest.mark.unit
class TestCreateOffloadManager:
    """Tests for create_offload_manager factory function."""

    def test_create_manager_default(self):
        """Test manager creation with default parameters."""
        manager = create_offload_manager()

        assert isinstance(manager, LRUOffloadManager)
        assert manager.offload_threshold == 0.9
        assert manager.load_threshold == 0.8

    def test_create_manager_lru_explicit(self):
        """Test explicit LRU manager creation."""
        manager = create_offload_manager(manager_type="lru")

        assert isinstance(manager, LRUOffloadManager)
        assert isinstance(manager, KVOffloadManager)

    def test_create_manager_custom_offload_threshold(self):
        """Test manager creation with custom offload threshold."""
        manager = create_offload_manager(
            manager_type="lru",
            offload_threshold=0.85,
        )

        assert manager.offload_threshold == 0.85

    def test_create_manager_custom_load_threshold(self):
        """Test manager creation with custom load threshold."""
        manager = create_offload_manager(
            manager_type="lru",
            load_threshold=0.75,
        )

        assert manager.load_threshold == 0.75

    def test_create_manager_custom_both_thresholds(self):
        """Test manager creation with both custom thresholds."""
        manager = create_offload_manager(
            manager_type="lru",
            offload_threshold=0.95,
            load_threshold=0.85,
        )

        assert manager.offload_threshold == 0.95
        assert manager.load_threshold == 0.85

    def test_create_manager_unknown_type(self):
        """Test manager creation with unknown type."""
        with pytest.raises(ValueError) as exc_info:
            create_offload_manager(manager_type="unknown")

        assert "Unknown offload manager type" in str(exc_info.value)
        assert "unknown" in str(exc_info.value)

    def test_create_manager_interface_compliance(self):
        """Test that created manager implements correct interface."""
        manager = create_offload_manager()

        # Check that all required methods exist
        assert hasattr(manager, "should_offload")
        assert hasattr(manager, "select_blocks_to_offload")
        assert hasattr(manager, "record_access")


# ============================================================================
# Integration Tests
# ============================================================================


@pytest.mark.unit
class TestFactoryIntegration:
    """Integration tests for factory functions."""

    def test_create_complete_offload_system(self):
        """Test creating complete offload system."""
        backend = create_offload_backend(
            backend_type="m4metal",
            max_cpu_memory_gb=8.0,
        )

        manager = create_offload_manager(
            manager_type="lru",
            offload_threshold=0.9,
        )

        # Both should work together
        assert isinstance(backend, KVOffloadBackend)
        assert isinstance(manager, KVOffloadManager)

    def test_create_system_with_defaults(self):
        """Test creating system with all defaults."""
        backend = create_offload_backend()
        manager = create_offload_manager()

        assert backend is not None
        assert manager is not None

    def test_backend_manager_interaction(self):
        """Test that backend and manager can interact."""
        backend = create_offload_backend()
        manager = create_offload_manager()

        # Manager should make decisions
        should_offload = manager.should_offload(5)
        assert isinstance(should_offload, bool)

        # Backend should be ready for operations
        assert backend.get_memory_usage() == 0

    def test_multiple_backend_instances(self):
        """Test creating multiple backend instances."""
        backend1 = create_offload_backend(max_cpu_memory_gb=4.0)
        backend2 = create_offload_backend(max_cpu_memory_gb=8.0)

        # Should be separate instances
        assert backend1 is not backend2
        assert backend1.max_cpu_memory_bytes != backend2.max_cpu_memory_bytes

    def test_multiple_manager_instances(self):
        """Test creating multiple manager instances."""
        manager1 = create_offload_manager(offload_threshold=0.85)
        manager2 = create_offload_manager(offload_threshold=0.95)

        # Should be separate instances
        assert manager1 is not manager2
        assert manager1.offload_threshold != manager2.offload_threshold


# ============================================================================
# Platform Detection Tests
# ============================================================================


@pytest.mark.unit
class TestPlatformDetection:
    """Tests for platform detection in factory."""

    def test_auto_backend_darwin_arm64(self):
        """Test auto detection on macOS ARM64."""
        with patch("platform.system", return_value="Darwin"), patch(
            "platform.machine", return_value="arm64"
        ):
            backend = create_offload_backend(backend_type="auto")
            assert isinstance(backend, M4MetalOffloadBackend)

    def test_auto_backend_darwin_x86(self):
        """Test auto detection on macOS x86."""
        with patch("platform.system", return_value="Darwin"), patch(
            "platform.machine", return_value="x86_64"
        ):
            backend = create_offload_backend(backend_type="auto")
            # Should still create M4Metal as fallback
            assert isinstance(backend, M4MetalOffloadBackend)

    def test_auto_backend_linux(self):
        """Test auto detection on Linux."""
        with patch("platform.system", return_value="Linux"), patch(
            "platform.machine", return_value="x86_64"
        ):
            backend = create_offload_backend(backend_type="auto")
            # Should create M4Metal as fallback
            assert isinstance(backend, M4MetalOffloadBackend)

    def test_auto_backend_windows(self):
        """Test auto detection on Windows."""
        with patch("platform.system", return_value="Windows"), patch(
            "platform.machine", return_value="AMD64"
        ):
            backend = create_offload_backend(backend_type="auto")
            # Should create M4Metal as fallback
            assert isinstance(backend, M4MetalOffloadBackend)


# ============================================================================
# Parameter Validation Tests
# ============================================================================


@pytest.mark.unit
class TestParameterValidation:
    """Tests for parameter validation in factory functions."""

    def test_backend_zero_memory(self):
        """Test backend creation with zero memory."""
        # Should not raise error, but might behave unexpectedly
        backend = create_offload_backend(max_cpu_memory_gb=0.0)
        assert backend.max_cpu_memory_bytes == 0

    def test_backend_large_memory(self):
        """Test backend creation with very large memory."""
        backend = create_offload_backend(max_cpu_memory_gb=1000.0)
        assert backend.max_cpu_memory_bytes == 1000 * 1024**3

    def test_manager_threshold_zero(self):
        """Test manager creation with zero thresholds."""
        manager = create_offload_manager(
            offload_threshold=0.0,
            load_threshold=0.0,
        )
        assert manager.offload_threshold == 0.0
        assert manager.load_threshold == 0.0

    def test_manager_threshold_one(self):
        """Test manager creation with threshold of 1.0."""
        manager = create_offload_manager(
            offload_threshold=1.0,
            load_threshold=1.0,
        )
        assert manager.offload_threshold == 1.0
        assert manager.load_threshold == 1.0
