# SPDX-License-Identifier: Apache-2.0
"""Unit tests for parameters module."""

from __future__ import annotations

import pytest
import mlx.core as mx
import mlx.nn as nn

from mlxllm.model_executor.parameters import (
    count_parameters,
    freeze_parameters,
    unfreeze_parameters,
    get_parameter_dtype,
    get_parameter_stats,
    get_memory_footprint,
    initialize_weights,
    print_parameter_summary,
)


class SimpleModel(nn.Module):
    """Simple model for testing."""

    def __init__(self, input_dim: int = 64, hidden_dim: int = 128, output_dim: int = 32):
        super().__init__()
        self.linear1 = nn.Linear(input_dim, hidden_dim, bias=True)
        self.linear2 = nn.Linear(hidden_dim, output_dim, bias=True)

    def __call__(self, x):
        x = self.linear1(x)
        x = nn.relu(x)
        x = self.linear2(x)
        return x


@pytest.mark.unit
class TestCountParameters:
    """Tests for count_parameters function."""

    def test_count_parameters_basic(self):
        """Test basic parameter counting."""
        model = SimpleModel(input_dim=64, hidden_dim=128, output_dim=32)

        count = count_parameters(model)

        # linear1: 64*128 + 128 = 8320
        # linear2: 128*32 + 32 = 4128
        # total: 12448
        expected = (64 * 128 + 128) + (128 * 32 + 32)
        assert count == expected

    def test_count_parameters_no_bias(self):
        """Test parameter counting without bias."""

        class NoBiasModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(10, 20, bias=False)

            def __call__(self, x):
                return self.linear(x)

        model = NoBiasModel()
        count = count_parameters(model)

        # Should only count weight matrix
        assert count == 10 * 20

    def test_count_parameters_single_layer(self):
        """Test counting with single layer."""

        class SingleLayer(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(50, 100)

            def __call__(self, x):
                return self.linear(x)

        model = SingleLayer()
        count = count_parameters(model)

        assert count == 50 * 100 + 100


@pytest.mark.unit
class TestFreezeUnfreeze:
    """Tests for freeze/unfreeze functions."""

    def test_freeze_parameters(self):
        """Test freezing parameters."""
        model = SimpleModel()

        # This should not raise an error
        freeze_parameters(model)

    def test_unfreeze_parameters(self):
        """Test unfreezing parameters."""
        model = SimpleModel()

        # This should not raise an error
        unfreeze_parameters(model)

    def test_freeze_then_unfreeze(self):
        """Test freeze followed by unfreeze."""
        model = SimpleModel()

        freeze_parameters(model)
        unfreeze_parameters(model)

        # Should complete without error


@pytest.mark.unit
class TestGetParameterDtype:
    """Tests for get_parameter_dtype function."""

    def test_get_parameter_dtype(self):
        """Test getting parameter dtype."""
        model = SimpleModel()

        dtype = get_parameter_dtype(model)

        # Should return a string representation
        assert isinstance(dtype, str)
        assert dtype in ["float32", "float16", "bfloat16", "unknown"]

    def test_get_parameter_dtype_empty_model(self):
        """Test dtype for model with no parameters."""

        class EmptyModel(nn.Module):
            def __call__(self, x):
                return x

        model = EmptyModel()
        dtype = get_parameter_dtype(model)

        assert dtype == "unknown"


@pytest.mark.unit
class TestGetParameterStats:
    """Tests for get_parameter_stats function."""

    def test_get_parameter_stats_basic(self):
        """Test basic parameter statistics."""
        model = SimpleModel(input_dim=64, hidden_dim=128, output_dim=32)

        stats = get_parameter_stats(model)

        assert "total_params" in stats
        assert "total_size_mb" in stats
        assert "dtype" in stats
        assert "param_shapes" in stats

        # Check values
        expected_params = (64 * 128 + 128) + (128 * 32 + 32)
        assert stats["total_params"] == expected_params
        assert stats["total_size_mb"] > 0
        assert isinstance(stats["param_shapes"], dict)

    def test_get_parameter_stats_shapes(self):
        """Test parameter shape tracking."""
        model = SimpleModel(input_dim=10, hidden_dim=20, output_dim=5)

        stats = get_parameter_stats(model)

        shapes = stats["param_shapes"]
        assert len(shapes) > 0

        # Check at least one shape is recorded
        for name, shape in shapes.items():
            assert isinstance(shape, list)
            assert len(shape) > 0

    def test_get_parameter_stats_size_calculation(self):
        """Test size calculation is reasonable."""
        model = SimpleModel()

        stats = get_parameter_stats(model)

        # Size should be positive and reasonable (less than 1GB for small model)
        assert 0 < stats["total_size_mb"] < 1000


@pytest.mark.unit
class TestGetMemoryFootprint:
    """Tests for get_memory_footprint function."""

    def test_memory_footprint_basic(self):
        """Test basic memory footprint estimation."""
        model = SimpleModel()

        memory = get_memory_footprint(model)

        assert "parameters" in memory
        assert "activations_estimate" in memory
        assert "total_estimate" in memory

        # All values should be positive
        assert memory["parameters"] > 0
        assert memory["activations_estimate"] > 0
        assert memory["total_estimate"] > 0

    def test_memory_footprint_total(self):
        """Test total memory is sum of components."""
        model = SimpleModel()

        memory = get_memory_footprint(model)

        # Total should approximately equal sum
        expected_total = memory["parameters"] + memory["activations_estimate"]
        assert abs(memory["total_estimate"] - expected_total) < 0.01

    def test_memory_footprint_activation_multiple(self):
        """Test activation estimate is reasonable multiple of params."""
        model = SimpleModel()

        memory = get_memory_footprint(model)

        # Activations should be 2-3x parameters (rough heuristic)
        ratio = memory["activations_estimate"] / memory["parameters"]
        assert 2.0 <= ratio <= 3.0


@pytest.mark.unit
class TestInitializeWeights:
    """Tests for initialize_weights function."""

    def test_initialize_weights_basic(self):
        """Test basic weight initialization."""
        model = SimpleModel()

        # This should not raise an error
        initialize_weights(model, std=0.02)

    def test_initialize_weights_custom_std(self):
        """Test weight initialization with custom std."""
        model = SimpleModel()

        # This should not raise an error
        initialize_weights(model, std=0.01)


@pytest.mark.unit
class TestPrintParameterSummary:
    """Tests for print_parameter_summary function."""

    def test_print_summary_basic(self, capsys):
        """Test basic parameter summary printing."""
        model = SimpleModel()

        print_parameter_summary(model)

        captured = capsys.readouterr()
        assert "Model Parameter Summary" in captured.out
        assert "Total Parameters:" in captured.out
        assert "Total Size:" in captured.out

    def test_print_summary_detailed(self, capsys):
        """Test detailed parameter summary."""
        model = SimpleModel()

        print_parameter_summary(model, detailed=True)

        captured = capsys.readouterr()
        assert "Model Parameter Summary" in captured.out
        assert "Detailed Parameter Shapes:" in captured.out

    def test_print_summary_memory_footprint(self, capsys):
        """Test memory footprint is printed."""
        model = SimpleModel()

        print_parameter_summary(model)

        captured = capsys.readouterr()
        assert "Memory Footprint Estimate:" in captured.out
        assert "Parameters:" in captured.out
        assert "Activations" in captured.out


@pytest.mark.unit
class TestParametersIntegration:
    """Integration tests for parameter utilities."""

    def test_full_workflow(self):
        """Test full workflow of parameter utilities."""
        model = SimpleModel()

        # Count parameters
        total = count_parameters(model)
        assert total > 0

        # Get stats
        stats = get_parameter_stats(model)
        assert stats["total_params"] == total

        # Get memory footprint
        memory = get_memory_footprint(model)
        assert memory["total_estimate"] > 0

        # Freeze and unfreeze
        freeze_parameters(model)
        unfreeze_parameters(model)

    def test_different_model_sizes(self):
        """Test with different model sizes."""
        small_model = SimpleModel(input_dim=10, hidden_dim=20, output_dim=5)
        large_model = SimpleModel(input_dim=100, hidden_dim=200, output_dim=50)

        small_count = count_parameters(small_model)
        large_count = count_parameters(large_model)

        # Large model should have more parameters
        assert large_count > small_count

        small_memory = get_memory_footprint(small_model)
        large_memory = get_memory_footprint(large_model)

        # Large model should use more memory
        assert large_memory["total_estimate"] > small_memory["total_estimate"]
