# SPDX-License-Identifier: Apache-2.0
"""Unit tests for model_executor utils module."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.utils import (
    set_default_dtype,
    get_default_dtype,
    set_random_seed,
    get_activation_checkpointing_enabled,
    set_activation_checkpointing,
    apply_rotary_pos_emb,
    repeat_kv,
    get_mask_from_lengths,
    scaled_dot_product_attention,
    get_model_config_dict,
)


@pytest.mark.unit
class TestDefaultDtype:
    """Tests for default dtype management."""

    def test_set_get_default_dtype(self):
        """Test setting and getting default dtype."""
        original = get_default_dtype()

        set_default_dtype(mx.float16)
        assert get_default_dtype() == mx.float16

        # Restore original
        set_default_dtype(original)

    def test_set_default_dtype_from_string(self):
        """Test setting dtype from string."""
        original = get_default_dtype()

        set_default_dtype("float16")
        assert get_default_dtype() == mx.float16

        set_default_dtype("bfloat16")
        assert get_default_dtype() == mx.bfloat16

        # Restore original
        set_default_dtype(original)

    def test_set_default_dtype_invalid_string(self):
        """Test setting invalid dtype string raises error."""
        with pytest.raises(ValueError, match="Unknown dtype string"):
            set_default_dtype("invalid_dtype")


@pytest.mark.unit
class TestRandomSeed:
    """Tests for random seed setting."""

    def test_set_random_seed(self):
        """Test setting random seed for reproducibility."""
        set_random_seed(42)

        # Generate some random numbers
        x1 = mx.random.normal((10,))

        set_random_seed(42)
        x2 = mx.random.normal((10,))

        # Should be the same with same seed
        assert mx.allclose(x1, x2)


@pytest.mark.unit
class TestActivationCheckpointing:
    """Tests for activation checkpointing."""

    def test_get_set_activation_checkpointing(self):
        """Test activation checkpointing flag."""
        original = get_activation_checkpointing_enabled()

        set_activation_checkpointing(True)
        assert get_activation_checkpointing_enabled() is True

        set_activation_checkpointing(False)
        assert get_activation_checkpointing_enabled() is False

        # Restore original
        set_activation_checkpointing(original)


@pytest.mark.unit
class TestApplyRotaryPosEmb:
    """Tests for rotary position embeddings."""

    def test_apply_rotary_pos_emb_basic(self):
        """Test basic rotary embedding application."""
        q = mx.random.normal((1, 8, 16, 64))
        k = mx.random.normal((1, 8, 16, 64))
        cos = mx.random.normal((16, 64))
        sin = mx.random.normal((16, 64))

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape

    def test_apply_rotary_pos_emb_3d(self):
        """Test rotary embedding with 3D cos/sin."""
        q = mx.random.normal((2, 8, 16, 64))
        k = mx.random.normal((2, 8, 16, 64))
        cos = mx.random.normal((2, 16, 64))
        sin = mx.random.normal((2, 16, 64))

        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape


@pytest.mark.unit
class TestRepeatKV:
    """Tests for repeat_kv utility."""

    def test_repeat_kv_basic(self):
        """Test basic KV repetition."""
        hidden = mx.random.normal((1, 8, 16, 64))
        output = repeat_kv(hidden, n_rep=4)

        assert output.shape == (1, 32, 16, 64)

    def test_repeat_kv_no_repeat(self):
        """Test repeat_kv with n_rep=1."""
        hidden = mx.random.normal((1, 8, 16, 64))
        output = repeat_kv(hidden, n_rep=1)

        assert output.shape == hidden.shape
        assert mx.array_equal(output, hidden)

    def test_repeat_kv_duplication(self):
        """Test values are correctly duplicated."""
        hidden = mx.random.normal((1, 2, 4, 8))
        output = repeat_kv(hidden, n_rep=3)

        assert output.shape == (1, 6, 4, 8)
        # First head repeated
        assert mx.allclose(output[0, 0], output[0, 1])
        assert mx.allclose(output[0, 0], output[0, 2])


@pytest.mark.unit
class TestGetMaskFromLengths:
    """Tests for mask generation from lengths."""

    def test_get_mask_from_lengths_basic(self):
        """Test basic mask generation."""
        lengths = mx.array([3, 5, 2])
        mask = get_mask_from_lengths(lengths, max_len=5)

        assert mask.shape == (3, 5)
        # Check specific values
        assert bool(mask[0, 0]) is True  # length 3: first 3 are True
        assert bool(mask[0, 2]) is True
        assert bool(mask[0, 3]) is False  # After length, False
        assert bool(mask[1, 4]) is True  # length 5: all True
        assert bool(mask[2, 1]) is True  # length 2: first 2 True
        assert bool(mask[2, 2]) is False

    def test_get_mask_from_lengths_auto_maxlen(self):
        """Test mask with automatic max_len."""
        lengths = mx.array([2, 4, 3])
        mask = get_mask_from_lengths(lengths)

        # Should use max(lengths) = 4
        assert mask.shape == (3, 4)


@pytest.mark.unit
class TestScaledDotProductAttention:
    """Tests for scaled dot-product attention."""

    def test_attention_basic(self):
        """Test basic attention."""
        q = mx.random.normal((1, 8, 16, 64))
        k = mx.random.normal((1, 8, 16, 64))
        v = mx.random.normal((1, 8, 16, 64))

        output = scaled_dot_product_attention(q, k, v)

        assert output.shape == q.shape

    def test_attention_causal(self):
        """Test causal attention."""
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        v = mx.random.normal((1, 4, 8, 32))

        output = scaled_dot_product_attention(q, k, v, is_causal=True)

        assert output.shape == q.shape

    def test_attention_with_mask(self):
        """Test attention with custom mask."""
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        v = mx.random.normal((1, 4, 8, 32))
        mask = mx.ones((1, 4, 8, 8)) * -1e9

        output = scaled_dot_product_attention(q, k, v, attn_mask=mask)

        assert output.shape == q.shape


@pytest.mark.unit
class TestGetModelConfigDict:
    """Tests for model config conversion."""

    def test_get_model_config_dict_from_dict(self):
        """Test conversion from dict."""
        config = {"param1": 1, "param2": "value"}
        result = get_model_config_dict(config)

        assert result == config

    def test_get_model_config_dict_from_object(self):
        """Test conversion from object."""

        class Config:
            def __init__(self):
                self.param1 = 1
                self.param2 = "value"

        config = Config()
        result = get_model_config_dict(config)

        assert "param1" in result
        assert result["param1"] == 1
        assert "param2" in result
        assert result["param2"] == "value"

    def test_get_model_config_dict_with_dict_method(self):
        """Test conversion from object with dict() method."""

        class PydanticLikeConfig:
            def dict(self):
                return {"param1": 1, "param2": "value"}

        config = PydanticLikeConfig()
        result = get_model_config_dict(config)

        assert result == {"param1": 1, "param2": "value"}


@pytest.mark.unit
class TestUtilsIntegration:
    """Integration tests for utils."""

    def test_full_workflow(self):
        """Test complete workflow of utilities."""
        # Set dtype
        set_default_dtype(mx.float32)
        assert get_default_dtype() == mx.float32

        # Set seed
        set_random_seed(42)

        # Generate data
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        v = mx.random.normal((1, 4, 8, 32))

        # Apply attention
        output = scaled_dot_product_attention(q, k, v)
        assert output.shape == q.shape

        # Test repeat_kv
        kv = mx.random.normal((1, 4, 8, 32))
        kv_repeated = repeat_kv(kv, n_rep=2)
        assert kv_repeated.shape == (1, 8, 8, 32)
