# SPDX-License-Identifier: Apache-2.0
"""Unit tests for worker module."""

from __future__ import annotations

from unittest.mock import Mock, patch, MagicMock

import pytest
import mlx.core as mx

from mlxllm.model_executor.worker import Worker
from mlxllm.config.model import ModelConfig
from mlxllm.config.cache import CacheConfig


@pytest.fixture
def mock_model_config():
    """Create a mock model config."""
    config = Mock(spec=ModelConfig)
    config.model_name = "test-model"
    config.num_hidden_layers = 12
    config.num_attention_heads = 12
    config.hidden_size = 768
    config.dtype = mx.float32
    return config


@pytest.fixture
def mock_cache_config():
    """Create a mock cache config."""
    config = Mock(spec=CacheConfig)
    config.block_size = 16
    config.num_gpu_blocks = 1024
    return config


@pytest.mark.unit
class TestWorkerInit:
    """Tests for Worker initialization."""

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_init_basic(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test basic worker initialization."""
        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        assert worker.model_config == mock_model_config
        assert worker.cache_config == mock_cache_config

        # Verify components were initialized
        mock_tokenizer_class.from_pretrained.assert_called_once_with("test-model")
        mock_kv_manager_class.assert_called_once()
        mock_executor_class.assert_called_once()

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_init_attributes(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test worker has correct attributes."""
        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        assert hasattr(worker, "model_config")
        assert hasattr(worker, "cache_config")
        assert hasattr(worker, "tokenizer")
        assert hasattr(worker, "kv_cache_manager")
        assert hasattr(worker, "executor")


@pytest.mark.unit
class TestWorkerExecuteBatch:
    """Tests for batch execution."""

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_execute_batch_prefill(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test batch execution in prefill mode."""
        # Setup mock executor
        mock_executor = Mock()
        mock_executor.execute_prefill.return_value = {
            "logits": mx.random.normal((2, 50000)),
        }
        mock_executor.sample_tokens.return_value = [1, 2]
        mock_executor_class.return_value = mock_executor

        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        sequence_groups = []
        result = worker.execute_batch(sequence_groups, is_prefill=True)

        assert "logits" in result
        assert "sampled_tokens" in result
        mock_executor.execute_prefill.assert_called_once_with(sequence_groups)
        mock_executor.sample_tokens.assert_called_once()

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_execute_batch_decode(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test batch execution in decode mode."""
        # Setup mock executor
        mock_executor = Mock()
        mock_executor.execute_decode.return_value = {
            "logits": mx.random.normal((2, 50000)),
        }
        mock_executor.sample_tokens.return_value = [3, 4]
        mock_executor_class.return_value = mock_executor

        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        sequence_groups = []
        result = worker.execute_batch(sequence_groups, is_prefill=False)

        assert "logits" in result
        assert "sampled_tokens" in result
        mock_executor.execute_decode.assert_called_once_with(sequence_groups)
        mock_executor.sample_tokens.assert_called_once()


@pytest.mark.unit
class TestWorkerLoadModel:
    """Tests for model loading."""

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_load_model(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test model loading."""
        mock_executor = Mock()
        mock_executor_class.return_value = mock_executor

        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        worker.load_model()

        mock_executor.load_model.assert_called_once()


@pytest.mark.unit
class TestWorkerGetStats:
    """Tests for statistics retrieval."""

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_get_stats(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test statistics retrieval."""
        # Setup mocks
        mock_executor = Mock()
        mock_executor.get_stats.return_value = {
            "num_prefill_tokens": 100,
            "num_decode_tokens": 50,
        }
        mock_executor_class.return_value = mock_executor

        mock_kv_manager = Mock()
        mock_kv_manager.num_blocks = 1024
        mock_kv_manager.free_blocks = list(range(100))
        mock_kv_manager_class.return_value = mock_kv_manager

        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        stats = worker.get_stats()

        assert "executor" in stats
        assert "kv_cache" in stats
        assert stats["kv_cache"]["num_blocks"] == 1024
        assert stats["kv_cache"]["num_free_blocks"] == 100


@pytest.mark.unit
class TestWorkerIntegration:
    """Integration tests for worker."""

    @patch("mlxllm.model_executor.worker.Tokenizer")
    @patch("mlxllm.model_executor.worker.KVCacheManager")
    @patch("mlxllm.model_executor.worker.ModelExecutor")
    def test_worker_workflow(
        self,
        mock_executor_class,
        mock_kv_manager_class,
        mock_tokenizer_class,
        mock_model_config,
        mock_cache_config,
    ):
        """Test complete worker workflow."""
        # Setup mocks
        mock_executor = Mock()
        mock_executor.execute_prefill.return_value = {"logits": mx.random.normal((1, 50000))}
        mock_executor.sample_tokens.return_value = [1]
        mock_executor.get_stats.return_value = {"num_prefill_tokens": 10}
        mock_executor_class.return_value = mock_executor

        mock_kv_manager = Mock()
        mock_kv_manager.num_blocks = 1024
        mock_kv_manager.free_blocks = []
        mock_kv_manager_class.return_value = mock_kv_manager

        # Create worker
        worker = Worker(
            model_config=mock_model_config,
            cache_config=mock_cache_config,
        )

        # Execute batch
        result = worker.execute_batch([], is_prefill=True)
        assert "logits" in result
        assert "sampled_tokens" in result

        # Get stats
        stats = worker.get_stats()
        assert "executor" in stats
        assert "kv_cache" in stats
