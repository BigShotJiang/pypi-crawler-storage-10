# SPDX-License-Identifier: Apache-2.0
"""Unit tests for custom_ops module."""

from __future__ import annotations

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.model_executor.custom_ops import (
    rms_norm,
    silu,
    swiglu,
    rotary_embedding,
    apply_rotary_emb,
    repeat_kv,
    fused_dense_gelu,
    scaled_dot_product_attention,
    causal_mask,
    flash_attention,
)


@pytest.mark.unit
class TestRMSNorm:
    """Tests for RMS normalization."""

    def test_rms_norm_basic(self):
        """Test basic RMS normalization."""
        x = mx.random.normal((2, 4, 8))
        weight = mx.ones((8,))

        output = rms_norm(x, weight)

        assert output.shape == x.shape
        assert output.dtype == x.dtype

    def test_rms_norm_with_eps(self):
        """Test RMS norm with custom epsilon."""
        x = mx.random.normal((2, 4, 8))
        weight = mx.ones((8,))

        output = rms_norm(x, weight, eps=1e-5)

        assert output.shape == x.shape

    def test_rms_norm_numerical_stability(self):
        """Test RMS norm with very small values."""
        x = mx.ones((2, 4, 8)) * 1e-10
        weight = mx.ones((8,))

        output = rms_norm(x, weight, eps=1e-6)

        assert not mx.any(mx.isnan(output))
        assert not mx.any(mx.isinf(output))

    def test_rms_norm_with_scaled_weight(self):
        """Test RMS norm with non-unit weights."""
        x = mx.random.normal((2, 4, 8))
        weight = mx.random.normal((8,)) * 0.5 + 1.0

        output = rms_norm(x, weight)

        assert output.shape == x.shape


@pytest.mark.unit
class TestSiLU:
    """Tests for SiLU activation."""

    def test_silu_basic(self):
        """Test basic SiLU activation."""
        x = mx.array([-1.0, 0.0, 1.0, 2.0])

        output = silu(x)

        assert output.shape == x.shape
        # SiLU(0) should be close to 0
        assert abs(float(output[1])) < 0.01

    def test_silu_positive_values(self):
        """Test SiLU with positive values."""
        x = mx.array([1.0, 2.0, 3.0])

        output = silu(x)

        # SiLU(x) ≈ x for large positive x
        assert float(output[-1]) > 2.5

    def test_silu_multidimensional(self):
        """Test SiLU with multi-dimensional input."""
        x = mx.random.normal((2, 3, 4))

        output = silu(x)

        assert output.shape == x.shape


@pytest.mark.unit
class TestSwiGLU:
    """Tests for SwiGLU activation."""

    def test_swiglu_basic(self):
        """Test basic SwiGLU."""
        gate = mx.random.normal((2, 8))
        x = mx.random.normal((2, 8))

        output = swiglu(gate, x)

        assert output.shape == x.shape

    def test_swiglu_zero_gate(self):
        """Test SwiGLU with zero gate."""
        gate = mx.zeros((2, 8))
        x = mx.ones((2, 8))

        output = swiglu(gate, x)

        # Should be close to zero when gate is zero
        assert float(mx.mean(mx.abs(output))) < 0.1


@pytest.mark.unit
class TestRotaryEmbedding:
    """Tests for rotary position embeddings."""

    def test_rotary_embedding_basic(self):
        """Test basic rotary embedding generation."""
        cos, sin = rotary_embedding(dim=128, max_position_embeddings=2048)

        assert cos.shape == (2048, 128)
        assert sin.shape == (2048, 128)

    def test_rotary_embedding_custom_base(self):
        """Test rotary embedding with custom base."""
        cos, sin = rotary_embedding(dim=64, max_position_embeddings=1024, base=100000.0)

        assert cos.shape == (1024, 64)
        assert sin.shape == (1024, 64)

    def test_rotary_embedding_range(self):
        """Test rotary embedding values are in valid range."""
        cos, sin = rotary_embedding(dim=32, max_position_embeddings=128)

        # Cosine and sine should be in [-1, 1]
        assert float(mx.max(cos)) <= 1.0
        assert float(mx.min(cos)) >= -1.0
        assert float(mx.max(sin)) <= 1.0
        assert float(mx.min(sin)) >= -1.0


@pytest.mark.unit
class TestApplyRotaryEmb:
    """Tests for applying rotary embeddings."""

    def test_apply_rotary_emb_basic(self):
        """Test basic rotary embedding application."""
        q = mx.random.normal((1, 8, 16, 64))
        k = mx.random.normal((1, 8, 16, 64))
        cos, sin = rotary_embedding(64, 2048)

        q_rot, k_rot = apply_rotary_emb(q, k, cos[:16], sin[:16])

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape

    def test_apply_rotary_emb_3d_inputs(self):
        """Test rotary embedding with 3D cos/sin."""
        q = mx.random.normal((2, 8, 16, 64))
        k = mx.random.normal((2, 8, 16, 64))
        cos = mx.random.normal((2, 16, 64))
        sin = mx.random.normal((2, 16, 64))

        q_rot, k_rot = apply_rotary_emb(q, k, cos, sin)

        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape

    def test_apply_rotary_emb_preserves_norm(self):
        """Test that rotary embedding approximately preserves norm."""
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        cos, sin = rotary_embedding(32, 128)

        original_norm = float(mx.sqrt(mx.sum(q * q)))
        q_rot, k_rot = apply_rotary_emb(q, k, cos[:8], sin[:8])
        rotated_norm = float(mx.sqrt(mx.sum(q_rot * q_rot)))

        # Norm should be approximately preserved
        assert abs(original_norm - rotated_norm) / original_norm < 0.1


@pytest.mark.unit
class TestRepeatKV:
    """Tests for repeat_kv for grouped query attention."""

    def test_repeat_kv_basic(self):
        """Test basic KV repetition."""
        kv = mx.random.normal((1, 8, 16, 64))

        output = repeat_kv(kv, n_rep=4)

        assert output.shape == (1, 32, 16, 64)

    def test_repeat_kv_no_repeat(self):
        """Test repeat_kv with n_rep=1."""
        kv = mx.random.normal((1, 8, 16, 64))

        output = repeat_kv(kv, n_rep=1)

        assert output.shape == kv.shape
        assert mx.array_equal(output, kv)

    def test_repeat_kv_values_duplicated(self):
        """Test that values are correctly duplicated."""
        kv = mx.random.normal((1, 2, 4, 8))

        output = repeat_kv(kv, n_rep=3)

        assert output.shape == (1, 6, 4, 8)
        # Check first head is repeated
        assert mx.allclose(output[0, 0], output[0, 1])
        assert mx.allclose(output[0, 0], output[0, 2])


@pytest.mark.unit
class TestFusedDenseGELU:
    """Tests for fused dense + GELU layer."""

    def test_fused_dense_gelu_basic(self):
        """Test basic fused dense GELU."""
        x = mx.random.normal((2, 8, 64))
        weight = mx.random.normal((128, 64))

        output = fused_dense_gelu(x, weight)

        assert output.shape == (2, 8, 128)

    def test_fused_dense_gelu_with_bias(self):
        """Test fused dense GELU with bias."""
        x = mx.random.normal((2, 8, 64))
        weight = mx.random.normal((128, 64))
        bias = mx.random.normal((128,))

        output = fused_dense_gelu(x, weight, bias)

        assert output.shape == (2, 8, 128)

    def test_fused_dense_gelu_without_bias(self):
        """Test fused dense GELU without bias."""
        x = mx.random.normal((2, 8, 64))
        weight = mx.random.normal((128, 64))

        output = fused_dense_gelu(x, weight, bias=None)

        assert output.shape == (2, 8, 128)


@pytest.mark.unit
class TestScaledDotProductAttention:
    """Tests for scaled dot-product attention."""

    def test_attention_basic(self):
        """Test basic attention computation."""
        q = mx.random.normal((1, 8, 16, 64))
        k = mx.random.normal((1, 8, 16, 64))
        v = mx.random.normal((1, 8, 16, 64))

        output = scaled_dot_product_attention(q, k, v)

        assert output.shape == q.shape

    def test_attention_with_mask(self):
        """Test attention with mask."""
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        v = mx.random.normal((1, 4, 8, 32))
        mask = mx.ones((1, 1, 8, 8)) * -float("inf")
        mask = mx.tril(mask)  # Causal mask

        output = scaled_dot_product_attention(q, k, v, attn_mask=mask)

        assert output.shape == q.shape

    def test_attention_with_custom_scale(self):
        """Test attention with custom scale."""
        q = mx.random.normal((1, 4, 8, 32))
        k = mx.random.normal((1, 4, 8, 32))
        v = mx.random.normal((1, 4, 8, 32))

        output = scaled_dot_product_attention(q, k, v, scale=0.1)

        assert output.shape == q.shape


@pytest.mark.unit
class TestCausalMask:
    """Tests for causal attention mask."""

    def test_causal_mask_shape(self):
        """Test causal mask shape."""
        mask = causal_mask(seq_len=10)

        assert mask.shape == (10, 10)

    def test_causal_mask_structure(self):
        """Test causal mask structure."""
        mask = causal_mask(seq_len=5)

        # Lower triangle should be 0, upper triangle should be -inf
        assert float(mask[0, 0]) == 0.0
        assert float(mask[1, 0]) == 0.0
        assert float(mask[0, 1]) == -float("inf")
        assert float(mask[1, 2]) == -float("inf")

    def test_causal_mask_dtype(self):
        """Test causal mask with different dtype."""
        mask = causal_mask(seq_len=5, dtype=mx.float16)

        assert mask.dtype == mx.float16


@pytest.mark.unit
class TestFlashAttention:
    """Tests for flash attention."""

    def test_flash_attention_basic(self):
        """Test basic flash attention."""
        q = mx.random.normal((1, 8, 32, 64))
        k = mx.random.normal((1, 8, 32, 64))
        v = mx.random.normal((1, 8, 32, 64))

        output = flash_attention(q, k, v)

        assert output.shape == q.shape

    def test_flash_attention_causal(self):
        """Test flash attention with causal mask."""
        q = mx.random.normal((1, 8, 32, 64))
        k = mx.random.normal((1, 8, 32, 64))
        v = mx.random.normal((1, 8, 32, 64))

        output = flash_attention(q, k, v, is_causal=True)

        assert output.shape == q.shape

    def test_flash_attention_no_nan(self):
        """Test flash attention produces valid outputs."""
        q = mx.random.normal((1, 4, 16, 32))
        k = mx.random.normal((1, 4, 16, 32))
        v = mx.random.normal((1, 4, 16, 32))

        output = flash_attention(q, k, v)

        assert not mx.any(mx.isnan(output))
        assert not mx.any(mx.isinf(output))
