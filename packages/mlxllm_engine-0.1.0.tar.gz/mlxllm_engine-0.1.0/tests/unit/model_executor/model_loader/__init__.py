# SPDX-License-Identifier: Apache-2.0
"""Tests for model loader components."""
