# SPDX-License-Identifier: Apache-2.0
"""Unit tests for model executor."""

from __future__ import annotations

from unittest.mock import Mock, patch, MagicMock

import pytest
import mlx.core as mx
import mlx.nn as nn

from mlxllm.model_executor.executor import ModelExecutor
from mlxllm.config.model import ModelConfig
from mlxllm.sequence import Sequence, SequenceGroup


@pytest.fixture
def mock_model_config():
    """Create a mock model config."""
    config = Mock(spec=ModelConfig)
    config.model_name = "test-model"
    config.num_hidden_layers = 12
    config.num_attention_heads = 12
    config.num_kv_heads = 12
    config.hidden_size = 768
    config.head_dim = 64
    config.dtype = mx.float32
    return config


@pytest.fixture
def mock_kv_cache_manager():
    """Create a mock KV cache manager."""
    manager = Mock()
    manager.get_kv_cache.return_value = mx.zeros((2, 4, 16, 64))
    return manager


@pytest.fixture
def mock_tokenizer():
    """Create a mock tokenizer."""
    tokenizer = Mock()
    tokenizer.vocab_size = 50000
    return tokenizer


@pytest.fixture
def model_executor(mock_model_config, mock_kv_cache_manager, mock_tokenizer):
    """Create a model executor for testing."""
    return ModelExecutor(
        model_config=mock_model_config,
        kv_cache_manager=mock_kv_cache_manager,
        tokenizer=mock_tokenizer,
    )


@pytest.mark.unit
class TestModelExecutorInit:
    """Tests for ModelExecutor initialization."""

    def test_init_basic(self, mock_model_config, mock_kv_cache_manager, mock_tokenizer):
        """Test basic initialization."""
        executor = ModelExecutor(
            model_config=mock_model_config,
            kv_cache_manager=mock_kv_cache_manager,
            tokenizer=mock_tokenizer,
        )

        assert executor.model_config == mock_model_config
        assert executor.kv_cache_manager == mock_kv_cache_manager
        assert executor.tokenizer == mock_tokenizer
        assert executor.model is None
        assert executor.num_prefill_tokens == 0
        assert executor.num_decode_tokens == 0

    def test_init_attributes(self, model_executor):
        """Test executor has correct attributes."""
        assert hasattr(model_executor, "model_config")
        assert hasattr(model_executor, "kv_cache_manager")
        assert hasattr(model_executor, "tokenizer")
        assert hasattr(model_executor, "model")
        assert hasattr(model_executor, "num_prefill_tokens")
        assert hasattr(model_executor, "num_decode_tokens")


@pytest.mark.unit
class TestModelExecutorLoadModel:
    """Tests for model loading."""

    @patch("mlxllm.model_executor.executor.load_model")
    def test_load_model_basic(self, mock_load_model, model_executor):
        """Test basic model loading."""
        mock_model = Mock(spec=nn.Module)
        mock_model.eval = Mock()
        mock_load_model.return_value = mock_model

        model_executor.load_model()

        assert model_executor.model is not None
        mock_load_model.assert_called_once()
        mock_model.eval.assert_called_once()

    @patch("mlxllm.model_executor.executor.load_model")
    def test_load_model_without_eval(self, mock_load_model, model_executor):
        """Test loading model without eval method."""
        mock_model = Mock()
        del mock_model.eval  # Remove eval attribute
        mock_load_model.return_value = mock_model

        model_executor.load_model()

        assert model_executor.model is not None


@pytest.mark.unit
class TestModelExecutorPrefill:
    """Tests for prefill execution."""

    def test_execute_prefill_lazy_load(self, model_executor):
        """Test that prefill loads model lazily."""
        with patch.object(model_executor, "load_model") as mock_load:
            with patch.object(model_executor, "_prepare_inputs") as mock_prepare:
                mock_prepare.return_value = (
                    mx.array([[1, 2, 3]]),
                    mx.array([[0, 1, 2]]),
                    [[0, 1]],  # block_tables
                    [3],  # seq_lens
                )

                mock_model = Mock()
                mock_model.return_value = mx.random.normal((1, 50000))
                model_executor.model = None

                with patch.object(model_executor, "model", mock_model):
                    sequence_groups = []
                    try:
                        model_executor.execute_prefill(sequence_groups)
                    except Exception:
                        pass

    def test_execute_prefill_statistics(self, model_executor):
        """Test that prefill updates statistics."""
        with patch.object(model_executor, "load_model"):
            with patch.object(model_executor, "_prepare_inputs") as mock_prepare:
                input_ids = mx.array([[1, 2, 3, 4, 5]])
                mock_prepare.return_value = (
                    input_ids,
                    mx.array([[0, 1, 2, 3, 4]]),
                    [[0, 1]],  # block_tables
                    [5],  # seq_lens
                )

                mock_model = Mock()
                mock_model.return_value = mx.random.normal((1, 50000))
                model_executor.model = mock_model

                initial_count = model_executor.num_prefill_tokens
                sequence_groups = []
                result = model_executor.execute_prefill(sequence_groups)

                # Check that statistics were updated
                assert model_executor.num_prefill_tokens > initial_count


@pytest.mark.unit
class TestModelExecutorDecode:
    """Tests for decode execution."""

    def test_execute_decode_lazy_load(self, model_executor):
        """Test that decode loads model lazily."""
        with patch.object(model_executor, "load_model") as mock_load:
            with patch.object(model_executor, "_prepare_inputs") as mock_prepare:
                mock_prepare.return_value = (
                    mx.array([[1]]),
                    mx.array([[5]]),
                    mx.array([[[0, 1]]]),
                )

                mock_model = Mock()
                mock_model.return_value = mx.random.normal((1, 50000))
                model_executor.model = None

                with patch.object(model_executor, "model", mock_model):
                    sequence_groups = []
                    try:
                        model_executor.execute_decode(sequence_groups)
                    except Exception:
                        pass


@pytest.mark.unit
class TestModelExecutorIntegration:
    """Integration tests for model executor."""

    def test_executor_workflow(self, model_executor):
        """Test basic executor workflow."""
        # Should initialize properly
        assert model_executor.model is None
        assert model_executor.num_prefill_tokens == 0
        assert model_executor.num_decode_tokens == 0

    def test_executor_with_config(self, mock_model_config, mock_kv_cache_manager, mock_tokenizer):
        """Test executor respects config."""
        executor = ModelExecutor(
            model_config=mock_model_config,
            kv_cache_manager=mock_kv_cache_manager,
            tokenizer=mock_tokenizer,
        )

        assert executor.model_config.model_name == "test-model"
        assert executor.model_config.num_hidden_layers == 12
