# SPDX-License-Identifier: Apache-2.0
"""Unit tests for multimodal fusion layers."""

from __future__ import annotations

import pytest
import mlx.core as mx


@pytest.mark.unit
class TestMultimodalFusion:
    """Tests for multimodal fusion layers."""

    def test_placeholder(self):
        """Placeholder test for multimodal fusion."""
        try:
            from mlxllm.model_executor.layers.multimodal_embedding.fusion import FusionLayer

            fusion = FusionLayer(
                hidden_size=768,
            )
            assert hasattr(fusion, "hidden_size")
        except Exception:
            pytest.skip("FusionLayer not fully implemented")
