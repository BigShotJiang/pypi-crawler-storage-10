# SPDX-License-Identifier: Apache-2.0
"""Unit tests for vision embedding layers."""

from __future__ import annotations

import pytest
import mlx.core as mx


@pytest.mark.unit
class TestVisionEmbedding:
    """Tests for vision embedding layers."""

    def test_placeholder(self):
        """Placeholder test for vision embeddings."""
        try:
            from mlxllm.model_executor.layers.multimodal_embedding.vision import VisionEmbedding

            embedding = VisionEmbedding(
                hidden_size=768,
                image_size=224,
            )
            assert hasattr(embedding, "hidden_size")
        except Exception:
            pytest.skip("VisionEmbedding not fully implemented")
