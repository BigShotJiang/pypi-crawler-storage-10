# SPDX-License-Identifier: Apache-2.0
"""Unit tests for audio embedding layers."""

from __future__ import annotations

import pytest
import mlx.core as mx


@pytest.mark.unit
class TestAudioEmbedding:
    """Tests for audio embedding layers."""

    def test_placeholder(self):
        """Placeholder test for audio embeddings."""
        try:
            from mlxllm.model_executor.layers.multimodal_embedding.audio import AudioEmbedding

            embedding = AudioEmbedding(
                hidden_size=768,
            )
            assert hasattr(embedding, "hidden_size")
        except Exception:
            pytest.skip("AudioEmbedding not fully implemented")
