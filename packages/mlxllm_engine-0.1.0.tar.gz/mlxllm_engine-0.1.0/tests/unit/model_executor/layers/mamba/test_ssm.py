# SPDX-License-Identifier: Apache-2.0
"""Unit tests for Mamba SSM (Selective State Space Model)."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.mamba.ssm import SelectiveSSM, S4Layer


@pytest.mark.unit
class TestSelectiveSSM:
    """Tests for SelectiveSSM."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            ssm = SelectiveSSM(
                hidden_size=768,
                state_size=16,
            )
            assert hasattr(ssm, "hidden_size")
        except Exception:
            pytest.skip("SelectiveSSM not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            ssm = SelectiveSSM(
                hidden_size=256,
                state_size=16,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output = ssm(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("SelectiveSSM not fully implemented")


@pytest.mark.unit
class TestSSMLayer:
    """Tests for SSMLayer."""

    def test_init_basic(self):
        """Test basic SSMLayer initialization."""
        try:
            layer = SSMLayer(
                hidden_size=768,
            )
            assert hasattr(layer, "hidden_size")
        except Exception:
            pytest.skip("SSMLayer not fully implemented")
