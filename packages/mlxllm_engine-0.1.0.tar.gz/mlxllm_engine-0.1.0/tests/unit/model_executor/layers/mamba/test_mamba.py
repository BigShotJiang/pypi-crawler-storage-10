# SPDX-License-Identifier: Apache-2.0
"""Unit tests for Mamba layer."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.mamba.mamba import MambaLayer, MambaBlock


@pytest.mark.unit
class TestMambaLayer:
    """Tests for MambaLayer."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            mamba = MambaLayer(
                hidden_size=768,
                state_size=16,
            )
            assert hasattr(mamba, "hidden_size")
        except Exception:
            pytest.skip("MambaLayer not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            mamba = MambaLayer(
                hidden_size=256,
                state_size=16,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output = mamba(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("MambaLayer not fully implemented")


@pytest.mark.unit
class TestMambaBlock:
    """Tests for MambaBlock."""

    def test_init_basic(self):
        """Test basic MambaBlock initialization."""
        try:
            block = MambaBlock(
                hidden_size=768,
            )
            assert hasattr(block, "hidden_size")
        except Exception:
            pytest.skip("MambaBlock not fully implemented")
