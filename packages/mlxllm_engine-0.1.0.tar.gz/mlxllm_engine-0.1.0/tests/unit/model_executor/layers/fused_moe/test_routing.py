# SPDX-License-Identifier: Apache-2.0
"""Unit tests for MoE routing mechanisms."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fused_moe.routing import (
    TopKRouter,
    SwitchRouter,
    ExpertChoiceRouter,
)


@pytest.mark.unit
class TestTopKRouter:
    """Tests for TopKRouter."""

    def test_init_basic(self):
        """Test basic initialization."""
        router = TopKRouter(
            hidden_size=768,
            num_experts=8,
            top_k=2,
        )
        assert router.hidden_size == 768
        assert router.num_experts == 8
        assert router.top_k == 2

    def test_forward_output_shapes(self):
        """Test forward pass output shapes."""
        router = TopKRouter(
            hidden_size=256,
            num_experts=4,
            top_k=2,
        )
        hidden_states = mx.random.normal((16, 256))  # 16 tokens

        router_logits, selected_experts, router_weights = router(hidden_states)

        assert router_logits.shape == (16, 4)  # (tokens, experts)
        assert selected_experts.shape == (16, 2)  # (tokens, top_k)
        assert router_weights.shape == (16, 2)  # (tokens, top_k)

    def test_router_weights_sum_to_one(self):
        """Test that router weights are normalized."""
        router = TopKRouter(
            hidden_size=128,
            num_experts=4,
            top_k=2,
        )
        hidden_states = mx.random.normal((8, 128))

        _, _, router_weights = router(hidden_states)

        # Weights should sum to 1 for each token
        weight_sums = mx.sum(router_weights, axis=-1)
        assert mx.allclose(weight_sums, mx.ones_like(weight_sums))

    def test_gate_layer_exists(self):
        """Test that gate layer is initialized."""
        router = TopKRouter(hidden_size=512, num_experts=8, top_k=3)
        assert hasattr(router, "gate")


@pytest.mark.unit
class TestSwitchRouter:
    """Tests for SwitchRouter (top-1)."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            router = SwitchRouter(
                hidden_size=768,
                num_experts=8,
            )
            assert router.hidden_size == 768
            assert router.num_experts == 8
        except Exception:
            pytest.skip("SwitchRouter not fully implemented")

    def test_forward_top1(self):
        """Test that SwitchRouter selects only one expert."""
        try:
            router = SwitchRouter(
                hidden_size=256,
                num_experts=4,
            )
            hidden_states = mx.random.normal((16, 256))

            router_logits, selected_experts, router_weights = router(hidden_states)

            # Should select only 1 expert per token
            assert selected_experts.shape == (16, 1) or selected_experts.shape == (16,)
        except Exception:
            pytest.skip("SwitchRouter not fully implemented")


@pytest.mark.unit
class TestExpertChoiceRouter:
    """Tests for ExpertChoiceRouter."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            router = ExpertChoiceRouter(
                hidden_size=768,
                num_experts=8,
                expert_capacity=16,
            )
            assert router.hidden_size == 768
            assert router.num_experts == 8
        except Exception:
            pytest.skip("ExpertChoiceRouter not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shapes."""
        try:
            router = ExpertChoiceRouter(
                hidden_size=256,
                num_experts=4,
                expert_capacity=8,
            )
            hidden_states = mx.random.normal((16, 256))

            output = router(hidden_states)
            # Output shape depends on implementation
            assert output is not None
        except Exception:
            pytest.skip("ExpertChoiceRouter not fully implemented")


@pytest.mark.unit
class TestRoutingIntegration:
    """Integration tests for routing."""

    def test_different_top_k_values(self):
        """Test TopKRouter with different k values."""
        for k in [1, 2, 4]:
            router = TopKRouter(
                hidden_size=128,
                num_experts=8,
                top_k=k,
            )
            hidden_states = mx.random.normal((10, 128))

            _, selected_experts, router_weights = router(hidden_states)

            assert selected_experts.shape == (10, k)
            assert router_weights.shape == (10, k)

    def test_different_num_experts(self):
        """Test with different number of experts."""
        for num_experts in [4, 8, 16]:
            router = TopKRouter(
                hidden_size=256,
                num_experts=num_experts,
                top_k=2,
            )
            hidden_states = mx.random.normal((8, 256))

            router_logits, _, _ = router(hidden_states)

            assert router_logits.shape == (8, num_experts)
