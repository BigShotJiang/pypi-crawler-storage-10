# SPDX-License-Identifier: Apache-2.0
"""Unit tests for Fused MoE layer."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fused_moe.fused_moe import FusedMoE, FusedMoELayer


@pytest.mark.unit
class TestFusedMoE:
    """Tests for FusedMoE."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            moe = FusedMoE(
                hidden_size=768,
                intermediate_size=3072,
                num_experts=8,
                num_experts_per_tok=2,
            )
            assert moe.hidden_size == 768
            assert moe.num_experts == 8
            assert moe.num_experts_per_tok == 2
        except Exception:
            pytest.skip("FusedMoE not fully implemented")

    def test_init_with_custom_params(self):
        """Test initialization with custom parameters."""
        try:
            moe = FusedMoE(
                hidden_size=512,
                intermediate_size=2048,
                num_experts=16,
                num_experts_per_tok=4,
                router_aux_loss_coef=0.01,
            )
            assert moe.num_experts == 16
            assert moe.router_aux_loss_coef == 0.01
        except Exception:
            pytest.skip("FusedMoE not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            moe = FusedMoE(
                hidden_size=256,
                intermediate_size=1024,
                num_experts=4,
                num_experts_per_tok=2,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output, router_logits = moe(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("FusedMoE not fully implemented")

    def test_router_and_experts_exist(self):
        """Test that router and experts are initialized."""
        try:
            moe = FusedMoE(
                hidden_size=512,
                intermediate_size=2048,
                num_experts=8,
            )
            assert hasattr(moe, "router")
            assert hasattr(moe, "experts")
        except Exception:
            pytest.skip("FusedMoE not fully implemented")


@pytest.mark.unit
class TestFusedMoELayer:
    """Tests for FusedMoELayer."""

    def test_init_basic(self):
        """Test basic FusedMoELayer initialization."""
        try:
            from mlxllm.model_executor.layers.fused_moe.fused_moe import FusedMoELayer

            layer = FusedMoELayer(
                hidden_size=768,
                intermediate_size=3072,
                num_experts=8,
            )
            assert hasattr(layer, "hidden_size")
        except (ImportError, AttributeError):
            pytest.skip("FusedMoELayer not fully implemented")
