# SPDX-License-Identifier: Apache-2.0
"""Tests for fused MoE (Mixture of Experts) layers."""
