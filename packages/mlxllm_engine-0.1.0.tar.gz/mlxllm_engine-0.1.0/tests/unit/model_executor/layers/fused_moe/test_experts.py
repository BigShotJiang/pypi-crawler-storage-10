# SPDX-License-Identifier: Apache-2.0
"""Unit tests for MoE expert networks."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fused_moe.experts import (
    FeedForwardExperts,
    SparseExperts,
)


@pytest.mark.unit
class TestFeedForwardExperts:
    """Tests for FeedForwardExperts."""

    def test_init_basic(self):
        """Test basic initialization."""
        experts = FeedForwardExperts(
            hidden_size=768,
            intermediate_size=3072,
            num_experts=8,
        )
        assert experts.hidden_size == 768
        assert experts.intermediate_size == 3072
        assert experts.num_experts == 8

    def test_init_with_activation(self):
        """Test initialization with different activations."""
        for activation in ["silu", "gelu", "relu"]:
            experts = FeedForwardExperts(
                hidden_size=256,
                intermediate_size=1024,
                num_experts=4,
                activation=activation,
            )
            assert hasattr(experts, "activation")

    def test_init_invalid_activation(self):
        """Test that invalid activation raises error."""
        with pytest.raises(ValueError, match="Unknown activation"):
            FeedForwardExperts(
                hidden_size=256,
                intermediate_size=1024,
                num_experts=4,
                activation="invalid",
            )

    def test_expert_parameters_exist(self):
        """Test that expert parameters are initialized."""
        experts = FeedForwardExperts(
            hidden_size=512,
            intermediate_size=2048,
            num_experts=8,
        )
        assert hasattr(experts, "w1")
        assert hasattr(experts, "w2")
        assert hasattr(experts, "w3")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        experts = FeedForwardExperts(
            hidden_size=256,
            intermediate_size=1024,
            num_experts=4,
        )
        hidden_states = mx.random.normal((16, 256))
        selected_experts = mx.array([[0, 1], [1, 2], [2, 3], [0, 3]] * 4)
        router_weights = mx.softmax(mx.random.normal((16, 2)), axis=-1)

        output = experts(hidden_states, selected_experts, router_weights)

        assert output.shape == hidden_states.shape

    def test_no_nan_output(self):
        """Test that output contains no NaN values."""
        experts = FeedForwardExperts(
            hidden_size=128,
            intermediate_size=512,
            num_experts=4,
        )
        hidden_states = mx.random.normal((8, 128))
        selected_experts = mx.array([[0, 1]] * 8)
        router_weights = mx.array([[0.6, 0.4]] * 8)

        output = experts(hidden_states, selected_experts, router_weights)

        assert not mx.any(mx.isnan(output))


@pytest.mark.unit
class TestSparseExperts:
    """Tests for SparseExperts."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            experts = SparseExperts(
                hidden_size=768,
                intermediate_size=3072,
                num_experts=8,
            )
            assert experts.hidden_size == 768
            assert experts.num_experts == 8
        except Exception:
            pytest.skip("SparseExperts not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            experts = SparseExperts(
                hidden_size=256,
                intermediate_size=1024,
                num_experts=4,
            )
            hidden_states = mx.random.normal((16, 256))
            selected_experts = mx.array([[0, 1]] * 16)
            router_weights = mx.array([[0.5, 0.5]] * 16)

            output = experts(hidden_states, selected_experts, router_weights)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("SparseExperts not fully implemented")


@pytest.mark.unit
class TestExpertsIntegration:
    """Integration tests for expert networks."""

    def test_different_num_experts(self):
        """Test with different numbers of experts."""
        for num_experts in [2, 4, 8]:
            experts = FeedForwardExperts(
                hidden_size=128,
                intermediate_size=512,
                num_experts=num_experts,
            )
            hidden_states = mx.random.normal((10, 128))
            selected_experts = mx.zeros((10, 2), dtype=mx.int32)
            router_weights = mx.array([[0.5, 0.5]] * 10)

            output = experts(hidden_states, selected_experts, router_weights)
            assert output.shape == hidden_states.shape

    def test_different_top_k(self):
        """Test with different top-k values."""
        experts = FeedForwardExperts(
            hidden_size=128,
            intermediate_size=512,
            num_experts=8,
        )
        hidden_states = mx.random.normal((10, 128))

        for top_k in [1, 2, 4]:
            selected_experts = mx.zeros((10, top_k), dtype=mx.int32)
            router_weights = mx.ones((10, top_k)) / top_k

            output = experts(hidden_states, selected_experts, router_weights)
            assert output.shape == hidden_states.shape
