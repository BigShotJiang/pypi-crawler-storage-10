# SPDX-License-Identifier: Apache-2.0
"""Unit tests for RWKV attention."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fla.rwkv import RWKVAttention, RWKVLayer


@pytest.mark.unit
class TestRWKVAttention:
    """Tests for RWKVAttention."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            rwkv = RWKVAttention(
                hidden_size=768,
                num_heads=12,
            )
            assert rwkv.hidden_size == 768
            assert rwkv.num_heads == 12
        except Exception:
            pytest.skip("RWKVAttention not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            rwkv = RWKVAttention(
                hidden_size=256,
                num_heads=8,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output = rwkv(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("RWKVAttention not fully implemented")


@pytest.mark.unit
class TestRWKVLayer:
    """Tests for RWKVLayer."""

    def test_init_basic(self):
        """Test basic RWKVLayer initialization."""
        try:
            layer = RWKVLayer(
                hidden_size=768,
                num_heads=12,
            )
            assert hasattr(layer, "hidden_size")
        except Exception:
            pytest.skip("RWKVLayer not fully implemented")
