# SPDX-License-Identifier: Apache-2.0
"""Unit tests for RetNet (Retentive Network)."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fla.retnet import MultiScaleRetention, RetNetLayer


@pytest.mark.unit
class TestMultiScaleRetention:
    """Tests for MultiScaleRetention."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            retention = MultiScaleRetention(
                hidden_size=768,
                num_heads=12,
            )
            assert retention.hidden_size == 768
            assert retention.num_heads == 12
        except Exception:
            pytest.skip("MultiScaleRetention not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            retention = MultiScaleRetention(
                hidden_size=256,
                num_heads=8,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output = retention(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("MultiScaleRetention not fully implemented")


@pytest.mark.unit
class TestRetNetLayer:
    """Tests for RetNetLayer."""

    def test_init_basic(self):
        """Test basic RetNetLayer initialization."""
        try:
            layer = RetNetLayer(
                hidden_size=768,
                num_heads=12,
            )
            assert hasattr(layer, "hidden_size")
        except Exception:
            pytest.skip("RetNetLayer not fully implemented")
