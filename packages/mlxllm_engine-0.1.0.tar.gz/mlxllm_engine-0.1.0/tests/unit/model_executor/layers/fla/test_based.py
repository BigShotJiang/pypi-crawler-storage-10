# SPDX-License-Identifier: Apache-2.0
"""Unit tests for Based attention."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fla.based import BasedAttention, BasedLayer


@pytest.mark.unit
class TestBasedAttention:
    """Tests for BasedAttention."""

    def test_init_basic(self):
        """Test basic initialization."""
        try:
            based = BasedAttention(
                hidden_size=768,
                num_heads=12,
            )
            assert based.hidden_size == 768
            assert based.num_heads == 12
        except Exception:
            pytest.skip("BasedAttention not fully implemented")

    def test_forward_shape(self):
        """Test forward pass output shape."""
        try:
            based = BasedAttention(
                hidden_size=256,
                num_heads=8,
            )
            hidden_states = mx.random.normal((2, 10, 256))
            output = based(hidden_states)
            assert output.shape == hidden_states.shape
        except Exception:
            pytest.skip("BasedAttention not fully implemented")


@pytest.mark.unit
class TestBasedLayer:
    """Tests for BasedLayer."""

    def test_init_basic(self):
        """Test basic BasedLayer initialization."""
        try:
            layer = BasedLayer(
                hidden_size=768,
                num_heads=12,
            )
            assert hasattr(layer, "hidden_size")
        except Exception:
            pytest.skip("BasedLayer not fully implemented")
