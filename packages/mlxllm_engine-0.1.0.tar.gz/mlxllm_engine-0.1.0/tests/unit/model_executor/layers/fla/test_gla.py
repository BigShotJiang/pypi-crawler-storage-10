# SPDX-License-Identifier: Apache-2.0
"""Unit tests for Gated Linear Attention (GLA)."""

from __future__ import annotations

import pytest
import mlx.core as mx

from mlxllm.model_executor.layers.fla.gla import GatedLinearAttention, GLALayer


@pytest.mark.unit
class TestGatedLinearAttention:
    """Tests for GatedLinearAttention layer."""

    def test_init_basic(self):
        """Test basic initialization."""
        gla = GatedLinearAttention(
            hidden_size=768,
            num_heads=12,
        )

        assert gla.hidden_size == 768
        assert gla.num_heads == 12
        assert gla.head_dim == 64

    def test_init_custom_expand_ratio(self):
        """Test initialization with custom expand ratio."""
        gla = GatedLinearAttention(
            hidden_size=512,
            num_heads=8,
            expand_ratio=3.0,
        )

        assert gla.gate_dim == int(512 * 3.0)

    def test_forward_shape(self):
        """Test forward pass output shape."""
        gla = GatedLinearAttention(
            hidden_size=256,
            num_heads=8,
        )

        hidden_states = mx.random.normal((2, 10, 256))
        output = gla(hidden_states)

        assert output.shape == hidden_states.shape

    def test_forward_with_mask(self):
        """Test forward pass with attention mask."""
        gla = GatedLinearAttention(
            hidden_size=128,
            num_heads=4,
        )

        hidden_states = mx.random.normal((1, 8, 128))
        mask = mx.ones((1, 1, 8, 8))
        output = gla(hidden_states, attention_mask=mask)

        assert output.shape == hidden_states.shape

    def test_projections_exist(self):
        """Test that all projections are initialized."""
        gla = GatedLinearAttention(
            hidden_size=512,
            num_heads=8,
        )

        assert hasattr(gla, "q_proj")
        assert hasattr(gla, "k_proj")
        assert hasattr(gla, "v_proj")
        assert hasattr(gla, "g_proj")
        assert hasattr(gla, "o_proj")

    def test_no_nan_output(self):
        """Test that output contains no NaN values."""
        gla = GatedLinearAttention(
            hidden_size=256,
            num_heads=8,
        )

        hidden_states = mx.random.normal((1, 16, 256))
        output = gla(hidden_states)

        assert not mx.any(mx.isnan(output))


@pytest.mark.unit
class TestGLALayer:
    """Tests for GLALayer (full transformer layer with GLA)."""

    def test_init_basic(self):
        """Test basic GLALayer initialization."""
        try:
            from mlxllm.model_executor.layers.fla.gla import GLALayer

            layer = GLALayer(
                hidden_size=768,
                num_heads=12,
            )

            assert hasattr(layer, "hidden_size")
        except (ImportError, AttributeError):
            pytest.skip("GLALayer not fully implemented")

    def test_forward_shape(self):
        """Test GLALayer forward pass."""
        try:
            from mlxllm.model_executor.layers.fla.gla import GLALayer

            layer = GLALayer(
                hidden_size=256,
                num_heads=8,
            )

            hidden_states = mx.random.normal((2, 10, 256))
            output = layer(hidden_states)

            assert output.shape == hidden_states.shape
        except (ImportError, AttributeError):
            pytest.skip("GLALayer not fully implemented")
