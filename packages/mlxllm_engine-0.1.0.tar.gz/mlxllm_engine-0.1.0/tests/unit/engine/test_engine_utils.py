# SPDX-License-Identifier: Apache-2.0
"""Tests for MLX-LLM engine utility functions."""

import time

import pytest

from mlxllm.engine.utils import (
    calculate_num_blocks,
    chunk_list,
    compute_memory_usage,
    format_bytes,
    generate_request_id,
    get_timestamp,
    is_power_of_2,
    merge_dicts,
    next_power_of_2,
)


class TestRequestID:
    """Test request ID generation."""

    def test_generate_request_id(self):
        """Test generating request ID."""
        request_id = generate_request_id()

        assert isinstance(request_id, str)
        assert request_id.startswith("req_")
        assert len(request_id) == 16  # "req_" (4) + 12 hex chars

    def test_unique_request_ids(self):
        """Test that generated IDs are unique."""
        ids = {generate_request_id() for _ in range(1000)}

        # All IDs should be unique
        assert len(ids) == 1000

    def test_request_id_format(self):
        """Test request ID format."""
        request_id = generate_request_id()

        # Should be alphanumeric + underscore
        prefix, suffix = request_id.split("_", 1)
        assert prefix == "req"
        assert len(suffix) == 12
        assert all(c in "0123456789abcdef" for c in suffix)


class TestTimestamp:
    """Test timestamp utilities."""

    def test_get_timestamp(self):
        """Test getting current timestamp."""
        ts = get_timestamp()

        assert isinstance(ts, float)
        assert ts > 0

    def test_timestamp_ordering(self):
        """Test timestamps are ordered."""
        ts1 = get_timestamp()
        time.sleep(0.01)  # Small delay
        ts2 = get_timestamp()

        assert ts2 > ts1

    def test_timestamp_precision(self):
        """Test timestamp has sub-second precision."""
        ts1 = get_timestamp()
        ts2 = get_timestamp()

        # Even with no sleep, timestamps should differ
        # (or at least be very close)
        diff = abs(ts2 - ts1)
        assert diff < 1.0  # Should be less than 1 second


class TestFormatBytes:
    """Test byte formatting."""

    def test_format_bytes_small(self):
        """Test formatting small byte values."""
        assert format_bytes(0) == "0.00 B"
        assert format_bytes(512) == "512.00 B"
        assert format_bytes(1023) == "1023.00 B"

    def test_format_bytes_kb(self):
        """Test formatting KB values."""
        assert format_bytes(1024) == "1.00 KB"
        assert format_bytes(1536) == "1.50 KB"
        assert format_bytes(2048) == "2.00 KB"

    def test_format_bytes_mb(self):
        """Test formatting MB values."""
        assert format_bytes(1024 * 1024) == "1.00 MB"
        assert format_bytes(int(1.5 * 1024 * 1024)) == "1.50 MB"

    def test_format_bytes_gb(self):
        """Test formatting GB values."""
        assert format_bytes(1024 * 1024 * 1024) == "1.00 GB"
        assert format_bytes(int(16.5 * 1024 * 1024 * 1024)) == "16.50 GB"

    def test_format_bytes_tb(self):
        """Test formatting TB values."""
        assert format_bytes(1024 * 1024 * 1024 * 1024) == "1.00 TB"

    def test_format_bytes_pb(self):
        """Test formatting PB values."""
        assert format_bytes(1024 * 1024 * 1024 * 1024 * 1024) == "1.00 PB"

    def test_format_bytes_negative(self):
        """Test formatting negative values."""
        result = format_bytes(-1024)
        assert "-1.00 KB" in result


class TestComputeMemoryUsage:
    """Test memory usage computation."""

    def test_compute_memory_fp16(self):
        """Test memory computation for FP16."""
        # 7B params * 2 bytes * 1.2 overhead
        memory = compute_memory_usage(7_000_000_000, dtype_bytes=2)
        expected = 7_000_000_000 * 2 * 1.2
        assert memory == int(expected)

    def test_compute_memory_fp32(self):
        """Test memory computation for FP32."""
        memory = compute_memory_usage(1_000_000_000, dtype_bytes=4)
        expected = 1_000_000_000 * 4 * 1.2
        assert memory == int(expected)

    def test_compute_memory_custom_overhead(self):
        """Test memory with custom overhead."""
        memory = compute_memory_usage(
            1_000_000_000,
            dtype_bytes=2,
            overhead_factor=1.5,
        )
        expected = 1_000_000_000 * 2 * 1.5
        assert memory == int(expected)

    def test_compute_memory_no_overhead(self):
        """Test memory with no overhead."""
        memory = compute_memory_usage(
            1_000_000_000,
            dtype_bytes=2,
            overhead_factor=1.0,
        )
        assert memory == 2_000_000_000

    def test_compute_memory_zero_params(self):
        """Test memory with zero parameters."""
        memory = compute_memory_usage(0)
        assert memory == 0


class TestMergeDicts:
    """Test dictionary merging."""

    def test_merge_dicts_basic(self):
        """Test basic dictionary merge."""
        base = {"a": 1, "b": 2}
        override = {"c": 3}

        result = merge_dicts(base, override)

        assert result == {"a": 1, "b": 2, "c": 3}
        # Original dicts should not be modified
        assert base == {"a": 1, "b": 2}
        assert override == {"c": 3}

    def test_merge_dicts_override(self):
        """Test override takes precedence."""
        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}

        result = merge_dicts(base, override)

        assert result == {"a": 1, "b": 3, "c": 4}

    def test_merge_dicts_empty_base(self):
        """Test merge with empty base."""
        result = merge_dicts({}, {"a": 1})
        assert result == {"a": 1}

    def test_merge_dicts_empty_override(self):
        """Test merge with empty override."""
        result = merge_dicts({"a": 1}, {})
        assert result == {"a": 1}

    def test_merge_dicts_both_empty(self):
        """Test merge with both empty."""
        result = merge_dicts({}, {})
        assert result == {}

    def test_merge_dicts_nested_values(self):
        """Test merge with nested values."""
        base = {"a": {"x": 1}, "b": [1, 2]}
        override = {"c": {"y": 2}}

        result = merge_dicts(base, override)

        assert result == {"a": {"x": 1}, "b": [1, 2], "c": {"y": 2}}


class TestChunkList:
    """Test list chunking."""

    def test_chunk_list_exact(self):
        """Test chunking with exact division."""
        lst = [1, 2, 3, 4, 5, 6]
        chunks = chunk_list(lst, 2)

        assert chunks == [[1, 2], [3, 4], [5, 6]]

    def test_chunk_list_remainder(self):
        """Test chunking with remainder."""
        lst = [1, 2, 3, 4, 5]
        chunks = chunk_list(lst, 2)

        assert chunks == [[1, 2], [3, 4], [5]]

    def test_chunk_list_size_one(self):
        """Test chunking with size 1."""
        lst = [1, 2, 3]
        chunks = chunk_list(lst, 1)

        assert chunks == [[1], [2], [3]]

    def test_chunk_list_size_larger_than_list(self):
        """Test chunk size larger than list."""
        lst = [1, 2, 3]
        chunks = chunk_list(lst, 10)

        assert chunks == [[1, 2, 3]]

    def test_chunk_list_empty(self):
        """Test chunking empty list."""
        chunks = chunk_list([], 2)
        assert chunks == []

    def test_chunk_list_single_element(self):
        """Test chunking single element."""
        chunks = chunk_list([1], 2)
        assert chunks == [[1]]


class TestCalculateNumBlocks:
    """Test block calculation."""

    def test_calculate_num_blocks_exact(self):
        """Test exact division."""
        assert calculate_num_blocks(64, 16) == 4
        assert calculate_num_blocks(32, 16) == 2

    def test_calculate_num_blocks_ceil(self):
        """Test ceiling division."""
        assert calculate_num_blocks(33, 16) == 3
        assert calculate_num_blocks(65, 16) == 5

    def test_calculate_num_blocks_one_block(self):
        """Test sequences smaller than block size."""
        assert calculate_num_blocks(1, 16) == 1
        assert calculate_num_blocks(15, 16) == 1

    def test_calculate_num_blocks_zero_length(self):
        """Test zero length sequence."""
        assert calculate_num_blocks(0, 16) == 0

    def test_calculate_num_blocks_large(self):
        """Test large sequence."""
        assert calculate_num_blocks(10000, 16) == 625


class TestPowerOf2:
    """Test power of 2 utilities."""

    def test_is_power_of_2_true(self):
        """Test valid powers of 2."""
        powers = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
        for p in powers:
            assert is_power_of_2(p), f"{p} should be power of 2"

    def test_is_power_of_2_false(self):
        """Test non-powers of 2."""
        non_powers = [0, 3, 5, 6, 7, 9, 10, 15, 17, 100, 1000]
        for p in non_powers:
            assert not is_power_of_2(p), f"{p} should not be power of 2"

    def test_is_power_of_2_negative(self):
        """Test negative numbers."""
        assert not is_power_of_2(-1)
        assert not is_power_of_2(-2)
        assert not is_power_of_2(-8)

    def test_next_power_of_2_exact(self):
        """Test next power of 2 for exact powers."""
        assert next_power_of_2(1) == 1
        assert next_power_of_2(2) == 2
        assert next_power_of_2(4) == 4
        assert next_power_of_2(8) == 8
        assert next_power_of_2(16) == 16

    def test_next_power_of_2_round_up(self):
        """Test next power of 2 for non-powers."""
        assert next_power_of_2(3) == 4
        assert next_power_of_2(5) == 8
        assert next_power_of_2(9) == 16
        assert next_power_of_2(17) == 32
        assert next_power_of_2(100) == 128

    def test_next_power_of_2_zero_negative(self):
        """Test next power of 2 for zero and negative."""
        assert next_power_of_2(0) == 1
        assert next_power_of_2(-1) == 1
        assert next_power_of_2(-10) == 1

    def test_next_power_of_2_large(self):
        """Test next power of 2 for large numbers."""
        assert next_power_of_2(1000) == 1024
        assert next_power_of_2(1024) == 1024
        assert next_power_of_2(1025) == 2048


class TestIntegration:
    """Integration tests for utility functions."""

    def test_memory_formatting(self):
        """Test computing and formatting memory together."""
        memory_bytes = compute_memory_usage(7_000_000_000, dtype_bytes=2)
        formatted = format_bytes(memory_bytes)

        assert "GB" in formatted

    def test_block_calculation_with_power_of_2(self):
        """Test block calculation with power-of-2 block size."""
        block_size = next_power_of_2(15)  # Should give 16
        num_blocks = calculate_num_blocks(100, block_size)

        assert block_size == 16
        assert num_blocks == 7  # ceil(100/16)

    def test_chunk_and_process(self):
        """Test chunking and processing pattern."""
        # Simulate chunking a batch
        token_ids = list(range(100))
        chunk_size = 32

        chunks = chunk_list(token_ids, chunk_size)
        num_chunks = calculate_num_blocks(len(token_ids), chunk_size)

        assert len(chunks) == num_chunks
        assert sum(len(chunk) for chunk in chunks) == len(token_ids)
