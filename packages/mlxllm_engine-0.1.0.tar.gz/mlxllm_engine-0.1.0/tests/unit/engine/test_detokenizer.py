# SPDX-License-Identifier: Apache-2.0
"""Tests for MLX-LLM detokenizer."""

from unittest.mock import MagicMock

import pytest

from mlxllm.engine.detokenizer import (
    BatchedDetokenizer,
    DecodedState,
    Detokenizer,
)


@pytest.fixture
def mock_tokenizer():
    """Create a mock tokenizer for testing."""
    tokenizer = MagicMock()

    # Mock decode method
    def mock_decode(token_ids, skip_special_tokens=True, clean_up_tokenization_spaces=True):
        # Simple mock: convert token IDs to string
        return " ".join(f"tok{tid}" for tid in token_ids)

    tokenizer.decode = MagicMock(side_effect=mock_decode)

    return tokenizer


class TestDecodedState:
    """Test DecodedState class."""

    def test_create_decoded_state(self):
        """Test creating DecodedState."""
        state = DecodedState()

        assert state.num_decoded_tokens == 0
        assert state.decoded_text == ""

    def test_update_state(self):
        """Test updating state."""
        state = DecodedState()

        state.num_decoded_tokens = 5
        state.decoded_text = "Hello world"

        assert state.num_decoded_tokens == 5
        assert state.decoded_text == "Hello world"


class TestDetokenizer:
    """Test Detokenizer class."""

    def test_create_detokenizer(self, mock_tokenizer):
        """Test creating Detokenizer."""
        detokenizer = Detokenizer(mock_tokenizer)

        assert detokenizer.tokenizer is mock_tokenizer
        assert len(detokenizer._decoded_cache) == 0

    def test_decode_incremental_first_call(self, mock_tokenizer):
        """Test incremental decoding on first call."""
        detokenizer = Detokenizer(mock_tokenizer)

        token_ids = [1, 2, 3]
        text = detokenizer.decode_incremental("req_1", token_ids)

        assert text == "tok1 tok2 tok3"
        assert "req_1" in detokenizer._decoded_cache

    def test_decode_incremental_subsequent_call(self, mock_tokenizer):
        """Test incremental decoding with new tokens."""
        detokenizer = Detokenizer(mock_tokenizer)

        # First call
        text1 = detokenizer.decode_incremental("req_1", [1, 2, 3])
        assert text1 == "tok1 tok2 tok3"

        # Second call with new token
        text2 = detokenizer.decode_incremental("req_1", [1, 2, 3, 4])

        # Should only decode new token (4)
        mock_tokenizer.decode.assert_called_with(
            [4],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )

    def test_decode_incremental_no_new_tokens(self, mock_tokenizer):
        """Test incremental decoding with no new tokens."""
        detokenizer = Detokenizer(mock_tokenizer)

        # First call
        detokenizer.decode_incremental("req_1", [1, 2, 3])

        # Second call with same tokens
        text = detokenizer.decode_incremental("req_1", [1, 2, 3])

        assert text == ""  # No new text

    def test_decode_incremental_multiple_requests(self, mock_tokenizer):
        """Test incremental decoding for multiple requests."""
        detokenizer = Detokenizer(mock_tokenizer)

        text1 = detokenizer.decode_incremental("req_1", [1, 2])
        text2 = detokenizer.decode_incremental("req_2", [3, 4])

        assert text1 == "tok1 tok2"
        assert text2 == "tok3 tok4"
        assert len(detokenizer._decoded_cache) == 2

    def test_decode_complete(self, mock_tokenizer):
        """Test complete sequence decoding."""
        detokenizer = Detokenizer(mock_tokenizer)

        token_ids = [1, 2, 3, 4, 5]
        text = detokenizer.decode_complete("req_1", token_ids)

        assert text == "tok1 tok2 tok3 tok4 tok5"
        mock_tokenizer.decode.assert_called_once_with(
            token_ids,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )

    def test_decode_complete_no_cache_update(self, mock_tokenizer):
        """Test complete decoding doesn't update cache."""
        detokenizer = Detokenizer(mock_tokenizer)

        detokenizer.decode_complete("req_1", [1, 2, 3])

        # Cache should not be created for complete decoding
        # (unless incremental was called first)

    def test_reset(self, mock_tokenizer):
        """Test resetting decoded state."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Create state
        detokenizer.decode_incremental("req_1", [1, 2, 3])
        assert "req_1" in detokenizer._decoded_cache

        # Reset
        detokenizer.reset("req_1")
        assert "req_1" not in detokenizer._decoded_cache

    def test_reset_nonexistent_request(self, mock_tokenizer):
        """Test resetting non-existent request."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Should not raise error
        detokenizer.reset("nonexistent")

    def test_decode_error_handling(self, mock_tokenizer):
        """Test error handling during decoding."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Make decode raise an error
        mock_tokenizer.decode.side_effect = ValueError("Decode error")

        # Should handle error gracefully
        text = detokenizer.decode_incremental("req_1", [1, 2, 3])

        # Should return empty string on error
        assert text == ""

    def test_is_incomplete_utf8(self, mock_tokenizer):
        """Test UTF-8 completeness check."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Valid UTF-8
        assert not detokenizer._is_incomplete_utf8("Hello")
        assert not detokenizer._is_incomplete_utf8("")

        # Note: It's hard to create invalid UTF-8 in Python strings
        # This test validates the method exists and handles valid UTF-8


class TestBatchedDetokenizer:
    """Test BatchedDetokenizer class."""

    def test_create_batched_detokenizer(self, mock_tokenizer):
        """Test creating BatchedDetokenizer."""
        batched = BatchedDetokenizer(mock_tokenizer)

        assert isinstance(batched.detokenizer, Detokenizer)
        assert batched.detokenizer.tokenizer is mock_tokenizer

    def test_decode_batch_incremental(self, mock_tokenizer):
        """Test batch incremental decoding."""
        batched = BatchedDetokenizer(mock_tokenizer)

        request_ids = ["req_1", "req_2", "req_3"]
        token_id_lists = [[1, 2], [3, 4], [5, 6]]

        texts = batched.decode_batch(request_ids, token_id_lists, incremental=True)

        assert len(texts) == 3
        assert texts[0] == "tok1 tok2"
        assert texts[1] == "tok3 tok4"
        assert texts[2] == "tok5 tok6"

    def test_decode_batch_complete(self, mock_tokenizer):
        """Test batch complete decoding."""
        batched = BatchedDetokenizer(mock_tokenizer)

        request_ids = ["req_1", "req_2"]
        token_id_lists = [[1, 2, 3], [4, 5, 6]]

        texts = batched.decode_batch(request_ids, token_id_lists, incremental=False)

        assert len(texts) == 2
        assert texts[0] == "tok1 tok2 tok3"
        assert texts[1] == "tok4 tok5 tok6"

    def test_decode_batch_empty(self, mock_tokenizer):
        """Test decoding empty batch."""
        batched = BatchedDetokenizer(mock_tokenizer)

        texts = batched.decode_batch([], [], incremental=True)

        assert texts == []

    def test_decode_batch_single_request(self, mock_tokenizer):
        """Test decoding single request in batch."""
        batched = BatchedDetokenizer(mock_tokenizer)

        texts = batched.decode_batch(["req_1"], [[1, 2, 3]], incremental=True)

        assert len(texts) == 1
        assert texts[0] == "tok1 tok2 tok3"

    def test_reset_batch(self, mock_tokenizer):
        """Test resetting batch of requests."""
        batched = BatchedDetokenizer(mock_tokenizer)

        # Create some state
        batched.decode_batch(["req_1", "req_2"], [[1, 2], [3, 4]], incremental=True)

        # Reset
        batched.reset_batch(["req_1", "req_2"])

        # Cache should be cleared
        assert "req_1" not in batched.detokenizer._decoded_cache
        assert "req_2" not in batched.detokenizer._decoded_cache

    def test_reset_batch_partial(self, mock_tokenizer):
        """Test resetting partial batch."""
        batched = BatchedDetokenizer(mock_tokenizer)

        # Create state for 3 requests
        batched.decode_batch(
            ["req_1", "req_2", "req_3"],
            [[1], [2], [3]],
            incremental=True,
        )

        # Reset only 2
        batched.reset_batch(["req_1", "req_2"])

        assert "req_1" not in batched.detokenizer._decoded_cache
        assert "req_2" not in batched.detokenizer._decoded_cache
        assert "req_3" in batched.detokenizer._decoded_cache


class TestDetokenizerStreamingScenario:
    """Test realistic streaming scenario."""

    def test_streaming_generation(self, mock_tokenizer):
        """Test streaming text generation scenario."""
        detokenizer = Detokenizer(mock_tokenizer)
        request_id = "req_stream"

        # Simulate streaming generation
        token_sequences = [
            [1],  # First token
            [1, 2],  # Second token
            [1, 2, 3],  # Third token
            [1, 2, 3, 4],  # Fourth token
        ]

        texts = []
        for tokens in token_sequences:
            text = detokenizer.decode_incremental(request_id, tokens)
            texts.append(text)

        # Each call should return only the new text
        # (in our mock, the full text is returned, so we verify calls)
        assert len(texts) == 4

    def test_multiple_concurrent_streams(self, mock_tokenizer):
        """Test multiple concurrent streaming requests."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Simulate 3 concurrent requests at different stages
        detokenizer.decode_incremental("req_1", [1, 2])
        detokenizer.decode_incremental("req_2", [3])
        detokenizer.decode_incremental("req_3", [4, 5, 6])

        # Continue all streams
        detokenizer.decode_incremental("req_1", [1, 2, 3])
        detokenizer.decode_incremental("req_2", [3, 4])
        detokenizer.decode_incremental("req_3", [4, 5, 6, 7])

        # All should have independent state
        assert len(detokenizer._decoded_cache) == 3

    def test_complete_after_incremental(self, mock_tokenizer):
        """Test calling complete after incremental."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Do incremental
        detokenizer.decode_incremental("req_1", [1, 2, 3])

        # Then complete
        text = detokenizer.decode_complete("req_1", [1, 2, 3, 4, 5])

        assert text == "tok1 tok2 tok3 tok4 tok5"


class TestDetokenizerEdgeCases:
    """Test edge cases for Detokenizer."""

    def test_empty_token_list(self, mock_tokenizer):
        """Test decoding empty token list."""
        detokenizer = Detokenizer(mock_tokenizer)

        text = detokenizer.decode_incremental("req_1", [])

        assert text == ""

    def test_single_token(self, mock_tokenizer):
        """Test decoding single token."""
        detokenizer = Detokenizer(mock_tokenizer)

        text = detokenizer.decode_incremental("req_1", [42])

        assert text == "tok42"

    def test_very_long_sequence(self, mock_tokenizer):
        """Test decoding very long sequence."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Large token sequence
        token_ids = list(range(1000))
        text = detokenizer.decode_complete("req_1", token_ids)

        # Should handle large sequences
        assert text is not None

    def test_special_token_ids(self, mock_tokenizer):
        """Test decoding with special token IDs."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Common special tokens (e.g., BOS=1, EOS=2, PAD=0)
        token_ids = [1, 100, 200, 2]
        text = detokenizer.decode_complete("req_1", token_ids)

        # Should call decode with skip_special_tokens=True
        assert text is not None

    def test_decode_with_byte_decoder_attribute(self, mock_tokenizer):
        """Test handling tokenizers with byte_decoder."""
        # Add byte_decoder attribute to mock
        mock_tokenizer.byte_decoder = {}

        detokenizer = Detokenizer(mock_tokenizer)

        # Should handle byte-level tokenizer logic
        text = detokenizer.decode_incremental("req_1", [1, 2, 3])

        assert text is not None


class TestDetokenizerStateManagement:
    """Test state management in Detokenizer."""

    def test_state_isolation(self, mock_tokenizer):
        """Test states are isolated between requests."""
        detokenizer = Detokenizer(mock_tokenizer)

        detokenizer.decode_incremental("req_1", [1, 2])
        detokenizer.decode_incremental("req_2", [3, 4])

        state1 = detokenizer._decoded_cache["req_1"]
        state2 = detokenizer._decoded_cache["req_2"]

        assert state1 is not state2
        assert state1.num_decoded_tokens == 2
        assert state2.num_decoded_tokens == 2

    def test_state_persistence(self, mock_tokenizer):
        """Test state persists across calls."""
        detokenizer = Detokenizer(mock_tokenizer)

        detokenizer.decode_incremental("req_1", [1, 2])

        # Check state
        state = detokenizer._decoded_cache["req_1"]
        assert state.num_decoded_tokens == 2

        # Add more tokens
        detokenizer.decode_incremental("req_1", [1, 2, 3, 4])

        # State should be updated
        assert state.num_decoded_tokens == 4

    def test_cache_size_with_many_requests(self, mock_tokenizer):
        """Test cache with many requests."""
        detokenizer = Detokenizer(mock_tokenizer)

        # Create many requests
        num_requests = 100
        for i in range(num_requests):
            detokenizer.decode_incremental(f"req_{i}", [i])

        assert len(detokenizer._decoded_cache) == num_requests

        # Reset all
        for i in range(num_requests):
            detokenizer.reset(f"req_{i}")

        assert len(detokenizer._decoded_cache) == 0
