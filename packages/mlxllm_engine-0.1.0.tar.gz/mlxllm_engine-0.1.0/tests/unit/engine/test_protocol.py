# SPDX-License-Identifier: Apache-2.0
"""Tests for MLX-LLM engine protocol definitions."""

import pytest

from mlxllm.engine.protocol import (
    AbortRequest,
    EmbedRequest,
    EmbedResponse,
    EngineRequest,
    EngineResponse,
    GenerateRequest,
    GenerateResponse,
    MetricsRequest,
    MetricsResponse,
    RequestType,
)
from mlxllm.sampling_params import SamplingParams


class TestRequestType:
    """Test RequestType enum."""

    def test_request_types(self):
        """Test request type values."""
        assert RequestType.GENERATE == "generate"
        assert RequestType.EMBED == "embed"
        assert RequestType.ABORT == "abort"
        assert RequestType.METRICS == "metrics"

    def test_request_type_is_string(self):
        """Test RequestType is a string enum."""
        assert isinstance(RequestType.GENERATE.value, str)


class TestEngineRequest:
    """Test base EngineRequest."""

    def test_create_engine_request(self):
        """Test creating base engine request."""
        request = EngineRequest(
            request_id="req_123",
            request_type=RequestType.GENERATE,
        )

        assert request.request_id == "req_123"
        assert request.request_type == RequestType.GENERATE

    def test_engine_request_fields(self):
        """Test EngineRequest has required fields."""
        request = EngineRequest(
            request_id="req_456",
            request_type=RequestType.EMBED,
        )

        assert hasattr(request, "request_id")
        assert hasattr(request, "request_type")


class TestGenerateRequest:
    """Test GenerateRequest."""

    def test_create_with_prompt(self):
        """Test creating GenerateRequest with text prompt."""
        request = GenerateRequest(
            request_id="req_123",
            request_type=RequestType.GENERATE,
            prompt="Hello, world!",
        )

        assert request.request_id == "req_123"
        assert request.prompt == "Hello, world!"
        assert request.prompt_token_ids is None
        assert isinstance(request.sampling_params, SamplingParams)

    def test_create_with_token_ids(self):
        """Test creating GenerateRequest with token IDs."""
        token_ids = [1, 2, 3, 4]
        request = GenerateRequest(
            request_id="req_456",
            request_type=RequestType.GENERATE,
            prompt_token_ids=token_ids,
        )

        assert request.prompt is None
        assert request.prompt_token_ids == token_ids

    def test_create_with_sampling_params(self):
        """Test creating GenerateRequest with custom sampling params."""
        sampling_params = SamplingParams(temperature=0.8, max_tokens=100)
        request = GenerateRequest(
            request_id="req_789",
            request_type=RequestType.GENERATE,
            prompt="Test",
            sampling_params=sampling_params,
        )

        assert request.sampling_params.temperature == 0.8
        assert request.sampling_params.max_tokens == 100

    def test_default_sampling_params(self):
        """Test default sampling params are created."""
        request = GenerateRequest(
            request_id="req_default",
            request_type=RequestType.GENERATE,
            prompt="Test",
        )

        assert request.sampling_params is not None
        assert isinstance(request.sampling_params, SamplingParams)

    def test_arrival_time(self):
        """Test arrival_time field."""
        request = GenerateRequest(
            request_id="req_time",
            request_type=RequestType.GENERATE,
            prompt="Test",
            arrival_time=12345.67,
        )

        assert request.arrival_time == 12345.67

    def test_prefix_pos(self):
        """Test prefix_pos for prefix caching."""
        request = GenerateRequest(
            request_id="req_prefix",
            request_type=RequestType.GENERATE,
            prompt="Test",
            prefix_pos=10,
        )

        assert request.prefix_pos == 10

    def test_validation_no_prompt(self):
        """Test validation fails when no prompt provided."""
        with pytest.raises(ValueError, match="Either prompt or prompt_token_ids"):
            GenerateRequest(
                request_id="req_invalid",
                request_type=RequestType.GENERATE,
            )

    def test_both_prompt_and_token_ids(self):
        """Test providing both prompt and token IDs (should be allowed)."""
        request = GenerateRequest(
            request_id="req_both",
            request_type=RequestType.GENERATE,
            prompt="Hello",
            prompt_token_ids=[1, 2, 3],
        )

        # Both should be set
        assert request.prompt == "Hello"
        assert request.prompt_token_ids == [1, 2, 3]


class TestEmbedRequest:
    """Test EmbedRequest."""

    def test_create_with_text_inputs(self):
        """Test creating EmbedRequest with text inputs."""
        request = EmbedRequest(
            request_id="req_embed_1",
            request_type=RequestType.EMBED,
            inputs=["Hello", "World"],
        )

        assert request.inputs == ["Hello", "World"]
        assert request.input_token_ids is None

    def test_create_with_token_ids(self):
        """Test creating EmbedRequest with token IDs."""
        token_ids = [[1, 2, 3], [4, 5, 6]]
        request = EmbedRequest(
            request_id="req_embed_2",
            request_type=RequestType.EMBED,
            input_token_ids=token_ids,
        )

        assert request.inputs is None
        assert request.input_token_ids == token_ids

    def test_pooling_params(self):
        """Test pooling_params field."""
        request = EmbedRequest(
            request_id="req_pool",
            request_type=RequestType.EMBED,
            inputs=["Test"],
            pooling_params={"method": "mean"},
        )

        assert request.pooling_params == {"method": "mean"}

    def test_validation_no_inputs(self):
        """Test validation fails when no inputs provided."""
        with pytest.raises(ValueError, match="Either inputs or input_token_ids"):
            EmbedRequest(
                request_id="req_invalid",
                request_type=RequestType.EMBED,
            )


class TestAbortRequest:
    """Test AbortRequest."""

    def test_create_abort_request(self):
        """Test creating AbortRequest."""
        request = AbortRequest(
            request_id="req_abort",
            request_type=RequestType.ABORT,
            abort_request_id="req_target",
        )

        assert request.request_id == "req_abort"
        assert request.abort_request_id == "req_target"

    def test_abort_different_ids(self):
        """Test abort request has different ID from target."""
        request = AbortRequest(
            request_id="req_abort_123",
            request_type=RequestType.ABORT,
            abort_request_id="req_target_456",
        )

        assert request.request_id != request.abort_request_id


class TestMetricsRequest:
    """Test MetricsRequest."""

    def test_create_metrics_request(self):
        """Test creating MetricsRequest."""
        request = MetricsRequest(
            request_id="req_metrics",
            request_type=RequestType.METRICS,
        )

        assert request.request_id == "req_metrics"
        assert request.include_stats is True

    def test_metrics_without_stats(self):
        """Test MetricsRequest without detailed stats."""
        request = MetricsRequest(
            request_id="req_metrics_2",
            request_type=RequestType.METRICS,
            include_stats=False,
        )

        assert request.include_stats is False


class TestEngineResponse:
    """Test base EngineResponse."""

    def test_create_successful_response(self):
        """Test creating successful response."""
        response = EngineResponse(
            request_id="req_123",
            success=True,
        )

        assert response.request_id == "req_123"
        assert response.success is True
        assert response.error is None

    def test_create_error_response(self):
        """Test creating error response."""
        response = EngineResponse(
            request_id="req_456",
            success=False,
            error="Something went wrong",
        )

        assert response.success is False
        assert response.error == "Something went wrong"


class TestGenerateResponse:
    """Test GenerateResponse."""

    def test_create_generate_response(self):
        """Test creating GenerateResponse."""
        outputs = [
            {"text": "Hello", "tokens": [1, 2, 3]},
            {"text": "World", "tokens": [4, 5, 6]},
        ]

        response = GenerateResponse(
            request_id="req_123",
            success=True,
            outputs=outputs,
            finished=True,
        )

        assert response.request_id == "req_123"
        assert response.success is True
        assert len(response.outputs) == 2
        assert response.finished is True

    def test_streaming_response(self):
        """Test streaming response (not finished)."""
        response = GenerateResponse(
            request_id="req_stream",
            success=True,
            outputs=[{"text": "Partial", "tokens": [1, 2]}],
            finished=False,
        )

        assert response.finished is False

    def test_error_generate_response(self):
        """Test error in GenerateResponse."""
        response = GenerateResponse(
            request_id="req_error",
            success=False,
            error="Generation failed",
            finished=True,
        )

        assert response.success is False
        assert response.error == "Generation failed"
        assert response.outputs is None


class TestEmbedResponse:
    """Test EmbedResponse."""

    def test_create_embed_response(self):
        """Test creating EmbedResponse."""
        embeddings = [
            [0.1, 0.2, 0.3],
            [0.4, 0.5, 0.6],
        ]

        response = EmbedResponse(
            request_id="req_embed",
            success=True,
            embeddings=embeddings,
        )

        assert response.request_id == "req_embed"
        assert response.success is True
        assert len(response.embeddings) == 2
        assert response.embeddings[0] == [0.1, 0.2, 0.3]

    def test_error_embed_response(self):
        """Test error in EmbedResponse."""
        response = EmbedResponse(
            request_id="req_embed_err",
            success=False,
            error="Embedding failed",
        )

        assert response.success is False
        assert response.embeddings is None


class TestMetricsResponse:
    """Test MetricsResponse."""

    def test_create_metrics_response(self):
        """Test creating MetricsResponse."""
        metrics = {
            "num_requests": 10,
            "num_sequences": 5,
            "memory_usage": 1024 * 1024 * 1024,
        }

        response = MetricsResponse(
            request_id="req_metrics",
            success=True,
            metrics=metrics,
        )

        assert response.success is True
        assert response.metrics["num_requests"] == 10

    def test_empty_metrics(self):
        """Test MetricsResponse with empty metrics."""
        response = MetricsResponse(
            request_id="req_metrics_empty",
            success=True,
            metrics={},
        )

        assert response.metrics == {}


class TestRequestResponseFlow:
    """Test request-response flow patterns."""

    def test_generate_request_response_flow(self):
        """Test complete generate request-response flow."""
        # Create request
        request = GenerateRequest(
            request_id="req_flow_1",
            request_type=RequestType.GENERATE,
            prompt="What is AI?",
            sampling_params=SamplingParams(temperature=0.7, max_tokens=50),
        )

        # Simulate successful response
        response = GenerateResponse(
            request_id=request.request_id,
            success=True,
            outputs=[{"text": "AI is...", "tokens": [1, 2, 3]}],
            finished=True,
        )

        assert request.request_id == response.request_id
        assert response.success is True

    def test_error_handling_flow(self):
        """Test error handling in request-response."""
        request = GenerateRequest(
            request_id="req_error_flow",
            request_type=RequestType.GENERATE,
            prompt="Test",
        )

        # Simulate error response
        error_response = GenerateResponse(
            request_id=request.request_id,
            success=False,
            error="Out of memory",
        )

        assert not error_response.success
        assert error_response.error == "Out of memory"

    def test_abort_flow(self):
        """Test abort request flow."""
        # Original request
        gen_request = GenerateRequest(
            request_id="req_original",
            request_type=RequestType.GENERATE,
            prompt="Long generation...",
        )

        # Abort the original request
        abort_request = AbortRequest(
            request_id="req_abort_cmd",
            request_type=RequestType.ABORT,
            abort_request_id=gen_request.request_id,
        )

        assert abort_request.abort_request_id == gen_request.request_id


class TestDataclassFeatures:
    """Test dataclass features of protocol classes."""

    def test_request_equality(self):
        """Test request equality."""
        request1 = GenerateRequest(
            request_id="req_1",
            request_type=RequestType.GENERATE,
            prompt="Test",
        )
        request2 = GenerateRequest(
            request_id="req_1",
            request_type=RequestType.GENERATE,
            prompt="Test",
        )

        # Dataclasses should be equal
        assert request1.request_id == request2.request_id
        assert request1.prompt == request2.prompt

    def test_response_repr(self):
        """Test response string representation."""
        response = EngineResponse(
            request_id="req_repr",
            success=True,
        )

        repr_str = repr(response)
        assert "EngineResponse" in repr_str
        assert "req_repr" in repr_str
