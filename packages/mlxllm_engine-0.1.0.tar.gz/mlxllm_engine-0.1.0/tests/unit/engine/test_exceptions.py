# SPDX-License-Identifier: Apache-2.0
"""Tests for MLX-LLM engine exceptions."""

import pytest

from mlxllm.engine.exceptions import (
    AttentionError,
    ConfigurationError,
    DeviceError,
    EngineError,
    EngineException,
    InvalidRequestError,
    KVCacheError,
    MLXLLMError,
    MetalError,
    ModelLoadError,
    OutOfMemoryError,
    QuantizationError,
    RequestAbortedError,
    SchedulingError,
    TimeoutError,
    TokenizationError,
)


class TestExceptionHierarchy:
    """Test exception class hierarchy."""

    def test_base_exception(self):
        """Test MLXLLMError is base exception."""
        exc = MLXLLMError("test error")
        assert isinstance(exc, Exception)
        assert str(exc) == "test error"

    def test_engine_error_hierarchy(self):
        """Test EngineError inherits from MLXLLMError."""
        exc = EngineError("engine error")
        assert isinstance(exc, MLXLLMError)
        assert isinstance(exc, Exception)
        assert str(exc) == "engine error"

    def test_engine_exception_alias(self):
        """Test EngineException is alias for EngineError."""
        assert EngineException is EngineError


class TestEngineErrors:
    """Test engine-related exceptions."""

    def test_model_load_error(self):
        """Test ModelLoadError."""
        exc = ModelLoadError("failed to load model")
        assert isinstance(exc, EngineError)
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "failed to load model"

    def test_out_of_memory_error(self):
        """Test OutOfMemoryError."""
        exc = OutOfMemoryError("OOM: 16GB required")
        assert isinstance(exc, EngineError)
        assert str(exc) == "OOM: 16GB required"

    def test_invalid_request_error(self):
        """Test InvalidRequestError."""
        exc = InvalidRequestError("invalid sampling params")
        assert isinstance(exc, EngineError)
        assert str(exc) == "invalid sampling params"

    def test_request_aborted_error(self):
        """Test RequestAbortedError."""
        exc = RequestAbortedError("request aborted by user")
        assert isinstance(exc, EngineError)
        assert str(exc) == "request aborted by user"

    def test_timeout_error(self):
        """Test TimeoutError."""
        exc = TimeoutError("request timed out after 60s")
        assert isinstance(exc, EngineError)
        assert str(exc) == "request timed out after 60s"

    def test_attention_error(self):
        """Test AttentionError."""
        exc = AttentionError("attention computation failed")
        assert isinstance(exc, EngineError)
        assert str(exc) == "attention computation failed"

    def test_kv_cache_error(self):
        """Test KVCacheError."""
        exc = KVCacheError("KV cache allocation failed")
        assert isinstance(exc, EngineError)
        assert str(exc) == "KV cache allocation failed"

    def test_scheduling_error(self):
        """Test SchedulingError."""
        exc = SchedulingError("scheduler deadlock detected")
        assert isinstance(exc, EngineError)
        assert str(exc) == "scheduler deadlock detected"


class TestDeviceErrors:
    """Test device-related exceptions."""

    def test_device_error(self):
        """Test DeviceError."""
        exc = DeviceError("device initialization failed")
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "device initialization failed"

    def test_metal_error(self):
        """Test MetalError."""
        exc = MetalError("Metal compute pipeline failed")
        assert isinstance(exc, DeviceError)
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "Metal compute pipeline failed"


class TestOtherErrors:
    """Test other exception types."""

    def test_configuration_error(self):
        """Test ConfigurationError."""
        exc = ConfigurationError("invalid config value")
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "invalid config value"

    def test_quantization_error(self):
        """Test QuantizationError."""
        exc = QuantizationError("quantization format mismatch")
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "quantization format mismatch"

    def test_tokenization_error(self):
        """Test TokenizationError."""
        exc = TokenizationError("tokenizer encoding failed")
        assert isinstance(exc, MLXLLMError)
        assert str(exc) == "tokenizer encoding failed"


class TestExceptionRaising:
    """Test raising and catching exceptions."""

    def test_raise_and_catch_mlxllm_error(self):
        """Test raising MLXLLMError."""
        with pytest.raises(MLXLLMError, match="test"):
            raise MLXLLMError("test")

    def test_raise_and_catch_engine_error(self):
        """Test raising EngineError."""
        with pytest.raises(EngineError, match="engine failed"):
            raise EngineError("engine failed")

    def test_catch_base_exception(self):
        """Test catching derived exception with base class."""
        with pytest.raises(MLXLLMError):
            raise EngineError("derived error")

    def test_catch_engine_exception_alias(self):
        """Test catching EngineError with EngineException alias."""
        with pytest.raises(EngineException):
            raise EngineError("test")

    def test_multiple_exception_types(self):
        """Test catching multiple exception types."""
        exceptions = [
            ModelLoadError("load"),
            OutOfMemoryError("oom"),
            InvalidRequestError("invalid"),
        ]

        for exc in exceptions:
            with pytest.raises(EngineError):
                raise exc


class TestExceptionWithContext:
    """Test exceptions with additional context."""

    def test_exception_with_multiline_message(self):
        """Test exception with multiline message."""
        message = """Model loading failed:
        - File not found: /path/to/model
        - Try checking the model path"""

        exc = ModelLoadError(message)
        assert isinstance(exc, EngineError)
        assert "File not found" in str(exc)

    def test_exception_with_formatting(self):
        """Test exception with formatted message."""
        model_name = "llama-7b"
        required_memory = 16.5

        exc = OutOfMemoryError(
            f"Model '{model_name}' requires {required_memory}GB, but only 8GB available"
        )
        assert "llama-7b" in str(exc)
        assert "16.5GB" in str(exc)

    def test_exception_chaining(self):
        """Test exception chaining with 'from' clause."""
        original_error = ValueError("invalid parameter")

        try:
            raise InvalidRequestError("Request validation failed") from original_error
        except InvalidRequestError as e:
            assert e.__cause__ is original_error
            assert isinstance(e.__cause__, ValueError)

    def test_exception_with_none_message(self):
        """Test exception with no message."""
        exc = EngineError()
        assert isinstance(exc, MLXLLMError)
        # Empty string or default representation is ok
        str(exc)  # Should not raise


class TestExceptionEquality:
    """Test exception equality and comparison."""

    def test_same_exception_type(self):
        """Test two exceptions of same type."""
        exc1 = EngineError("test")
        exc2 = EngineError("test")

        # Exceptions are not equal even with same message
        assert type(exc1) is type(exc2)
        assert str(exc1) == str(exc2)

    def test_different_exception_types(self):
        """Test different exception types."""
        exc1 = ModelLoadError("error")
        exc2 = OutOfMemoryError("error")

        assert type(exc1) is not type(exc2)
        assert isinstance(exc1, EngineError)
        assert isinstance(exc2, EngineError)
