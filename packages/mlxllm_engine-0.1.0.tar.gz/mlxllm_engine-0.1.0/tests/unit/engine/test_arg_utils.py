# SPDX-License-Identifier: Apache-2.0
"""Tests for MLX-LLM engine argument utilities."""

import pytest

from mlxllm.config import (
    CacheConfig,
    DeviceConfig,
    DType,
    MLXConfig,
    ModelConfig,
    QuantizationType,
    SchedulerConfig,
)
from mlxllm.engine.arg_utils import AsyncEngineArgs, EngineArgs


class TestEngineArgs:
    """Test EngineArgs dataclass."""

    def test_create_with_defaults(self):
        """Test creating EngineArgs with defaults."""
        args = EngineArgs(model="test-model")

        assert args.model == "test-model"
        assert args.quantization == "q4_0"
        assert args.dtype == "bfloat16"
        assert args.max_model_len == 8192
        assert args.max_num_seqs == 256
        assert args.block_size == 16
        assert args.enable_prefix_caching is True

    def test_create_with_custom_values(self):
        """Test creating EngineArgs with custom values."""
        args = EngineArgs(
            model="llama-7b",
            quantization="q8_0",
            dtype="float16",
            max_model_len=4096,
            max_num_seqs=128,
            block_size=32,
        )

        assert args.model == "llama-7b"
        assert args.quantization == "q8_0"
        assert args.dtype == "float16"
        assert args.max_model_len == 4096
        assert args.max_num_seqs == 128
        assert args.block_size == 32

    def test_memory_settings(self):
        """Test memory-related settings."""
        args = EngineArgs(
            model="test",
            max_memory_gb=16.0,
            memory_fraction=0.8,
        )

        assert args.max_memory_gb == 16.0
        assert args.memory_fraction == 0.8

    def test_cache_settings(self):
        """Test cache-related settings."""
        args = EngineArgs(
            model="test",
            num_gpu_blocks=1000,
            num_cpu_blocks=100,
            enable_prefix_caching=False,
            enable_chunked_prefill=False,
        )

        assert args.num_gpu_blocks == 1000
        assert args.num_cpu_blocks == 100
        assert args.enable_prefix_caching is False
        assert args.enable_chunked_prefill is False

    def test_mlx_optimization_settings(self):
        """Test MLX optimization settings."""
        args = EngineArgs(
            model="test",
            enable_zero_copy=False,
            enable_metal_cache=False,
            use_flash_attention=False,
        )

        assert args.enable_zero_copy is False
        assert args.enable_metal_cache is False
        assert args.use_flash_attention is False

    def test_scheduling_settings(self):
        """Test scheduling settings."""
        args = EngineArgs(
            model="test",
            scheduling_policy="priority",
            preemption_mode="recompute",
        )

        assert args.scheduling_policy == "priority"
        assert args.preemption_mode == "recompute"


class TestEngineArgsValidation:
    """Test EngineArgs validation."""

    def test_validation_negative_max_model_len(self):
        """Test validation fails for negative max_model_len."""
        with pytest.raises(ValueError, match="max_model_len must be positive"):
            EngineArgs(model="test", max_model_len=-1)

    def test_validation_zero_max_model_len(self):
        """Test validation fails for zero max_model_len."""
        with pytest.raises(ValueError, match="max_model_len must be positive"):
            EngineArgs(model="test", max_model_len=0)

    def test_validation_negative_max_num_seqs(self):
        """Test validation fails for negative max_num_seqs."""
        with pytest.raises(ValueError, match="max_num_seqs must be positive"):
            EngineArgs(model="test", max_num_seqs=-1)

    def test_validation_invalid_block_size(self):
        """Test validation fails for non-power-of-2 block size."""
        with pytest.raises(ValueError, match="block_size must be a power of 2"):
            EngineArgs(model="test", block_size=15)

        with pytest.raises(ValueError, match="block_size must be a power of 2"):
            EngineArgs(model="test", block_size=0)

    def test_validation_valid_block_sizes(self):
        """Test validation passes for valid block sizes."""
        valid_sizes = [1, 2, 4, 8, 16, 32, 64, 128]
        for size in valid_sizes:
            args = EngineArgs(model="test", block_size=size)
            assert args.block_size == size

    def test_validation_invalid_memory_fraction(self):
        """Test validation fails for invalid memory_fraction."""
        with pytest.raises(ValueError, match="memory_fraction must be in"):
            EngineArgs(model="test", memory_fraction=0.0)

        with pytest.raises(ValueError, match="memory_fraction must be in"):
            EngineArgs(model="test", memory_fraction=1.5)

    def test_validation_valid_memory_fraction(self):
        """Test validation passes for valid memory_fraction."""
        args = EngineArgs(model="test", memory_fraction=0.5)
        assert args.memory_fraction == 0.5


class TestEngineArgsConfigCreation:
    """Test creating config objects from EngineArgs."""

    def test_create_model_config(self):
        """Test creating ModelConfig."""
        args = EngineArgs(
            model="llama-7b",
            quantization="q4_0",
            dtype="bfloat16",
            max_model_len=4096,
        )

        model_config = args.create_model_config()

        assert isinstance(model_config, ModelConfig)
        assert model_config.model_name == "llama-7b"
        assert model_config.quantization == QuantizationType.Q4_0
        assert model_config.dtype == DType.BFLOAT16
        assert model_config.max_model_len == 4096

    def test_create_device_config(self):
        """Test creating DeviceConfig."""
        args = EngineArgs(
            model="test",
            max_memory_gb=16.0,
            memory_fraction=0.8,
        )

        device_config = args.create_device_config()

        assert isinstance(device_config, DeviceConfig)

    def test_create_cache_config(self):
        """Test creating CacheConfig."""
        args = EngineArgs(
            model="test",
            block_size=32,
            num_gpu_blocks=1000,
            enable_prefix_caching=True,
        )

        cache_config = args.create_cache_config()

        assert isinstance(cache_config, CacheConfig)
        assert cache_config.kv_cache.block_size == 32
        assert cache_config.kv_cache.num_gpu_blocks == 1000
        assert cache_config.kv_cache.enable_prefix_caching is True

    def test_create_scheduler_config(self):
        """Test creating SchedulerConfig."""
        args = EngineArgs(
            model="test",
            max_num_seqs=128,
            scheduling_policy="fcfs",
            preemption_mode="swap",
        )

        scheduler_config = args.create_scheduler_config()

        assert isinstance(scheduler_config, SchedulerConfig)
        assert scheduler_config.max_num_seqs == 128

    def test_create_mlx_config(self):
        """Test creating MLXConfig."""
        args = EngineArgs(
            model="test",
            enable_zero_copy=True,
            enable_metal_cache=True,
            use_flash_attention=True,
        )

        mlx_config = args.create_mlx_config()

        assert isinstance(mlx_config, MLXConfig)
        assert mlx_config.enable_zero_copy is True
        assert mlx_config.enable_metal_cache is True
        assert mlx_config.use_flash_attention is True


class TestEngineArgsFromDict:
    """Test creating EngineArgs from dictionary."""

    def test_from_dict_basic(self):
        """Test creating from basic dict."""
        config = {
            "model": "test-model",
            "quantization": "q8_0",
            "max_model_len": 2048,
        }

        args = EngineArgs.from_dict(config)

        assert args.model == "test-model"
        assert args.quantization == "q8_0"
        assert args.max_model_len == 2048

    def test_from_dict_all_fields(self):
        """Test creating from dict with all fields."""
        config = {
            "model": "llama-7b",
            "quantization": "q4_0",
            "dtype": "float16",
            "max_model_len": 4096,
            "max_num_seqs": 64,
            "block_size": 16,
            "enable_prefix_caching": False,
        }

        args = EngineArgs.from_dict(config)

        assert args.model == "llama-7b"
        assert args.quantization == "q4_0"
        assert args.dtype == "float16"
        assert args.max_model_len == 4096
        assert args.max_num_seqs == 64
        assert args.block_size == 16
        assert args.enable_prefix_caching is False

    def test_from_dict_partial(self):
        """Test creating from partial dict uses defaults."""
        config = {"model": "test"}

        args = EngineArgs.from_dict(config)

        assert args.model == "test"
        # Check defaults are used
        assert args.quantization == "q4_0"
        assert args.max_model_len == 8192


class TestAsyncEngineArgs:
    """Test AsyncEngineArgs."""

    def test_create_async_engine_args(self):
        """Test creating AsyncEngineArgs."""
        args = AsyncEngineArgs(model="test-model")

        # Should have all base EngineArgs fields
        assert args.model == "test-model"
        assert args.max_model_len == 8192

        # Should have async-specific fields
        assert args.worker_use_ray is False
        assert args.max_num_on_the_fly == 1
        assert args.engine_use_ray is False

    def test_async_specific_settings(self):
        """Test async-specific settings."""
        args = AsyncEngineArgs(
            model="test",
            worker_use_ray=True,
            max_num_on_the_fly=4,
            engine_use_ray=True,
            request_timeout=600.0,
        )

        assert args.worker_use_ray is True
        assert args.max_num_on_the_fly == 4
        assert args.engine_use_ray is True
        assert args.request_timeout == 600.0

    def test_async_logging_settings(self):
        """Test async logging settings."""
        args = AsyncEngineArgs(
            model="test",
            disable_log_requests=True,
            log_stats_interval=5.0,
        )

        assert args.disable_log_requests is True
        assert args.log_stats_interval == 5.0

    def test_async_inherits_validation(self):
        """Test AsyncEngineArgs inherits validation from EngineArgs."""
        with pytest.raises(ValueError, match="max_model_len must be positive"):
            AsyncEngineArgs(model="test", max_model_len=-1)

    def test_async_creates_configs(self):
        """Test AsyncEngineArgs can create configs."""
        args = AsyncEngineArgs(
            model="test",
            max_model_len=4096,
        )

        # Should be able to create all configs
        model_config = args.create_model_config()
        assert isinstance(model_config, ModelConfig)

        device_config = args.create_device_config()
        assert isinstance(device_config, DeviceConfig)


class TestEngineArgsIntegration:
    """Integration tests for EngineArgs."""

    def test_full_configuration_flow(self):
        """Test complete configuration flow."""
        # Create args
        args = EngineArgs(
            model="llama-7b",
            quantization="q4_0",
            dtype="bfloat16",
            max_model_len=4096,
            max_num_seqs=128,
            block_size=16,
            enable_prefix_caching=True,
            memory_fraction=0.8,
        )

        # Create all configs
        model_config = args.create_model_config()
        device_config = args.create_device_config()
        cache_config = args.create_cache_config()
        scheduler_config = args.create_scheduler_config()
        mlx_config = args.create_mlx_config()

        # Verify all configs created successfully
        assert isinstance(model_config, ModelConfig)
        assert isinstance(device_config, DeviceConfig)
        assert isinstance(cache_config, CacheConfig)
        assert isinstance(scheduler_config, SchedulerConfig)
        assert isinstance(mlx_config, MLXConfig)

        # Verify consistency
        assert model_config.max_model_len == 4096
        assert cache_config.kv_cache.block_size == 16
        assert scheduler_config.max_num_seqs == 128

    def test_quantization_types(self):
        """Test different quantization types."""
        quant_types = ["q4_0", "q4_1", "q8_0"]

        for quant in quant_types:
            args = EngineArgs(model="test", quantization=quant)
            model_config = args.create_model_config()

            assert model_config.quantization.value == quant

    def test_dtype_types(self):
        """Test different dtype values."""
        dtypes = ["float16", "bfloat16", "float32", "auto"]

        for dtype in dtypes:
            args = EngineArgs(model="test", dtype=dtype)
            model_config = args.create_model_config()

            assert model_config.dtype.value == dtype

    def test_round_trip_serialization(self):
        """Test args can be converted to dict and back."""
        original_args = EngineArgs(
            model="test-model",
            quantization="q4_0",
            max_model_len=2048,
            block_size=32,
        )

        # Convert to dict (using dataclass __dict__ or similar)
        config_dict = {
            "model": original_args.model,
            "quantization": original_args.quantization,
            "max_model_len": original_args.max_model_len,
            "block_size": original_args.block_size,
        }

        # Create new args from dict
        new_args = EngineArgs.from_dict(config_dict)

        # Verify fields match
        assert new_args.model == original_args.model
        assert new_args.quantization == original_args.quantization
        assert new_args.max_model_len == original_args.max_model_len
        assert new_args.block_size == original_args.block_size


class TestEngineArgsEdgeCases:
    """Test edge cases for EngineArgs."""

    def test_none_optional_values(self):
        """Test None for optional values."""
        args = EngineArgs(
            model="test",
            max_num_batched_tokens=None,
            num_gpu_blocks=None,
            num_cpu_blocks=None,
            max_memory_gb=None,
            seed=None,
            revision=None,
        )

        assert args.max_num_batched_tokens is None
        assert args.num_gpu_blocks is None
        assert args.num_cpu_blocks is None
        assert args.max_memory_gb is None
        assert args.seed is None
        assert args.revision is None

    def test_trust_remote_code(self):
        """Test trust_remote_code flag."""
        args = EngineArgs(model="test", trust_remote_code=True)

        model_config = args.create_model_config()
        assert model_config.trust_remote_code is True

    def test_disable_log_stats(self):
        """Test disable_log_stats flag."""
        args = EngineArgs(model="test", disable_log_stats=True)

        assert args.disable_log_stats is True
