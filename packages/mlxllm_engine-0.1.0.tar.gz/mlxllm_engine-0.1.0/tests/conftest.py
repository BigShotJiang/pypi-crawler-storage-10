# SPDX-License-Identifier: Apache-2.0
"""Pytest configuration and shared fixtures for MLX-LLM tests."""

from __future__ import annotations

from typing import Any

import pytest
import mlx.core as mx
import numpy as np

from mlxllm.attention.backends.abstract import (
    AttentionBackend,
    AttentionMetadata,
    AttentionType,
)


# ============================================================================
# Pytest Configuration
# ============================================================================

def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line(
        "markers", "unit: Unit tests (fast, no external dependencies)"
    )
    config.addinivalue_line(
        "markers", "integration: Integration tests with services"
    )
    config.addinivalue_line(
        "markers", "slow: Slow-running tests (>5 seconds)"
    )
    config.addinivalue_line(
        "markers", "requires_metal: Tests requiring Metal/Apple Silicon"
    )
    config.addinivalue_line(
        "markers", "requires_ollama: Tests requiring Ollama service"
    )

    # Load torch.ops.mlxllm operations for tests
    try:
        import torch
        import os

        # Find and load the mlxllm.so extension
        test_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(test_dir)
        mlxllm_so = os.path.join(project_root, 'csrc', 'mlxllm.so')

        if os.path.exists(mlxllm_so):
            torch.ops.load_library(mlxllm_so)
    except Exception:
        # If loading fails, tests that require torch ops will fail with appropriate errors
        pass


# ============================================================================
# Mock Backends
# ============================================================================

class MockAttentionBackend(AttentionBackend):
    """Mock attention backend for testing.

    Tracks method calls and returns simple outputs for validation.
    """

    def __init__(self):
        self.prefill_calls = 0
        self.decode_calls = 0
        self.update_calls = 0
        self.call_history = []

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """Mock prefill attention."""
        self.prefill_calls += 1
        self.call_history.append(("prefill", query.shape, key.shape, value.shape))
        # Return query as-is for testing
        return query

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """Mock decode attention."""
        self.decode_calls += 1
        self.call_history.append(("decode", query.shape, kv_cache.shape))
        return query

    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        """Mock KV cache update."""
        self.update_calls += 1
        self.call_history.append(("update_kv", key.shape, value.shape))

    def get_supported_head_sizes(self) -> list[int]:
        """Return standard head sizes."""
        return [64, 80, 96, 112, 128, 256]

    def get_name(self) -> str:
        """Return backend name."""
        return "mock"

    @classmethod
    def is_available(cls) -> bool:
        """Mock backend is always available."""
        return True

    def reset(self) -> None:
        """Reset call counters."""
        self.prefill_calls = 0
        self.decode_calls = 0
        self.update_calls = 0
        self.call_history = []


# ============================================================================
# Attention Fixtures
# ============================================================================

@pytest.fixture
def mock_attention_backend():
    """Provide a mock attention backend."""
    return MockAttentionBackend()


@pytest.fixture
def sample_attention_metadata_prefill():
    """Provide sample AttentionMetadata for prefill mode."""
    return AttentionMetadata(
        attn_type=AttentionType.PREFILL,
        seq_lens=[10, 20],
        max_seq_len=20,
        num_query_heads=32,
        num_kv_heads=8,
        head_dim=128,
        block_size=16,
        scale=0.125,
    )


@pytest.fixture
def sample_attention_metadata_decode():
    """Provide sample AttentionMetadata for decode mode."""
    return AttentionMetadata(
        attn_type=AttentionType.DECODE,
        seq_lens=[11, 21],
        max_seq_len=21,
        block_tables=[[0, 1], [2, 3, 4]],
        context_lens=[10, 20],
        slot_mapping=[(0, 10), (2, 4)],
        num_query_heads=32,
        num_kv_heads=8,
        head_dim=128,
        block_size=16,
        scale=0.125,
    )


@pytest.fixture
def sample_kv_cache():
    """Provide sample KV cache tensor."""
    num_blocks = 10
    block_size = 16
    num_kv_heads = 8
    head_dim = 128

    return mx.random.normal(
        (num_blocks, 2, block_size, num_kv_heads, head_dim)
    )


@pytest.fixture
def sample_query_key_value():
    """Provide sample Q, K, V tensors for attention."""
    batch, seq_len, num_heads, head_dim = 2, 10, 32, 128
    num_kv_heads = 8

    query = mx.random.normal((batch, seq_len, num_heads, head_dim))
    key = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))
    value = mx.random.normal((batch, seq_len, num_kv_heads, head_dim))

    return query, key, value


# ============================================================================
# Block and Memory Fixtures
# ============================================================================

@pytest.fixture
def sample_block_tables():
    """Provide sample block tables for paged attention."""
    return [
        [0, 1],      # Sequence 1: 2 blocks
        [2, 3, 4],   # Sequence 2: 3 blocks
        [5],         # Sequence 3: 1 block
    ]


@pytest.fixture
def sample_slot_mapping():
    """Provide sample slot mapping for KV cache updates."""
    # Maps token positions to (block_id, offset_in_block)
    slot_mapping = []
    for seq_idx in range(3):
        for pos in range(16):  # 16 tokens per sequence
            block_idx = pos // 16
            offset = pos % 16
            slot_mapping.append((seq_idx * 2 + block_idx, offset))
    return slot_mapping


# ============================================================================
# Token and Sequence Fixtures
# ============================================================================

@pytest.fixture
def sample_token_ids():
    """Provide sample token ID sequences."""
    return [
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],           # Sequence 1: 10 tokens
        [11, 12, 13, 14, 15, 16, 17, 18, 19, 20],  # Sequence 2: 10 tokens
        [21, 22, 23, 24, 25],                       # Sequence 3: 5 tokens
    ]


@pytest.fixture
def sample_positions():
    """Provide sample position indices."""
    return mx.arange(10)  # Positions 0-9


@pytest.fixture
def sample_hidden_states():
    """Provide sample hidden states tensor."""
    num_tokens = 30  # Total across all sequences
    hidden_size = 4096
    return mx.random.normal((num_tokens, hidden_size))


# ============================================================================
# Configuration Fixtures
# ============================================================================

@pytest.fixture
def standard_model_config():
    """Provide standard model configuration."""
    return {
        "num_heads": 32,
        "num_kv_heads": 8,
        "head_dim": 128,
        "hidden_size": 4096,
        "max_position_embeddings": 8192,
        "rope_theta": 10000.0,
        "vocab_size": 32000,
        "num_layers": 32,
    }


@pytest.fixture
def small_model_config():
    """Provide small model configuration for fast tests."""
    return {
        "num_heads": 8,
        "num_kv_heads": 8,
        "head_dim": 64,
        "hidden_size": 512,
        "max_position_embeddings": 2048,
        "rope_theta": 10000.0,
        "vocab_size": 8000,
        "num_layers": 8,
    }


# ============================================================================
# Cache Management Fixtures
# ============================================================================

@pytest.fixture
def mock_block_pool():
    """Provide mock block pool for testing."""
    class MockBlockPool:
        def __init__(self, num_blocks: int = 100, block_size: int = 16):
            self.num_blocks = num_blocks
            self.block_size = block_size
            self.allocated_blocks = set()
            self.free_blocks = set(range(num_blocks))

        def allocate(self) -> int:
            """Allocate a block."""
            if not self.free_blocks:
                raise RuntimeError("No free blocks")
            block_id = self.free_blocks.pop()
            self.allocated_blocks.add(block_id)
            return block_id

        def free(self, block_id: int) -> None:
            """Free a block."""
            if block_id in self.allocated_blocks:
                self.allocated_blocks.remove(block_id)
                self.free_blocks.add(block_id)

        def get_num_free_blocks(self) -> int:
            """Get number of free blocks."""
            return len(self.free_blocks)

    return MockBlockPool()


@pytest.fixture
def sample_prefix_cache_entries():
    """Provide sample prefix cache entries."""
    return [
        {
            "prefix_tokens": tuple(range(10)),
            "block_ids": [0, 1],
            "num_tokens": 10,
        },
        {
            "prefix_tokens": tuple(range(20)),
            "block_ids": [2, 3, 4],
            "num_tokens": 20,
        },
    ]


# ============================================================================
# Helper Fixtures
# ============================================================================

@pytest.fixture
def random_seed():
    """Set random seed for reproducible tests."""
    np.random.seed(42)
    mx.random.seed(42)
    yield
    # Reset after test
    mx.random.seed(None)


@pytest.fixture
def temp_kv_cache_file(tmp_path):
    """Provide temporary file for KV cache persistence tests."""
    cache_file = tmp_path / "kv_cache.bin"
    return cache_file


# ============================================================================
# Assertion Helpers
# ============================================================================

@pytest.fixture
def assert_shapes_equal():
    """Provide helper for asserting tensor shapes are equal."""
    def _assert_shapes_equal(tensor1: mx.array, tensor2: mx.array):
        assert tensor1.shape == tensor2.shape, (
            f"Shape mismatch: {tensor1.shape} != {tensor2.shape}"
        )
    return _assert_shapes_equal


@pytest.fixture
def assert_tensors_close():
    """Provide helper for asserting tensors are numerically close."""
    def _assert_tensors_close(
        tensor1: mx.array,
        tensor2: mx.array,
        rtol: float = 1e-5,
        atol: float = 1e-8,
    ):
        assert mx.allclose(tensor1, tensor2, rtol=rtol, atol=atol), (
            f"Tensors not close:\nMax diff: {mx.max(mx.abs(tensor1 - tensor2))}"
        )
    return _assert_tensors_close


# ============================================================================
# Platform Detection Fixtures
# ============================================================================

@pytest.fixture
def is_metal_available():
    """Check if Metal is available on this platform."""
    try:
        import platform
        is_darwin = platform.system() == "Darwin"
        is_arm64 = platform.machine() == "arm64"
        return is_darwin and is_arm64
    except Exception:
        return False


@pytest.fixture
def skip_if_no_metal(is_metal_available):
    """Skip test if Metal is not available."""
    if not is_metal_available:
        pytest.skip("Metal not available on this platform")


# ============================================================================
# Benchmark Fixtures
# ============================================================================

@pytest.fixture
def benchmark_timer():
    """Provide timer for benchmarking tests."""
    import time

    class Timer:
        def __init__(self):
            self.start_time = None
            self.elapsed = None

        def __enter__(self):
            self.start_time = time.perf_counter()
            return self

        def __exit__(self, *args):
            self.elapsed = time.perf_counter() - self.start_time

    return Timer


# ============================================================================
# Test Data Generators
# ============================================================================

@pytest.fixture
def generate_random_attention_data():
    """Generate random attention test data."""
    def _generate(
        batch_size: int = 2,
        seq_len: int = 10,
        num_heads: int = 8,
        num_kv_heads: int = 8,
        head_dim: int = 64,
    ) -> dict[str, Any]:
        """Generate random Q, K, V tensors and metadata."""
        query = mx.random.normal((batch_size, seq_len, num_heads, head_dim))
        key = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))
        value = mx.random.normal((batch_size, seq_len, num_kv_heads, head_dim))

        metadata = AttentionMetadata(
            attn_type=AttentionType.PREFILL,
            seq_lens=[seq_len] * batch_size,
            max_seq_len=seq_len,
            num_query_heads=num_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
        )

        return {
            "query": query,
            "key": key,
            "value": value,
            "metadata": metadata,
        }

    return _generate


@pytest.fixture
def generate_block_tables():
    """Generate block tables for sequences."""
    def _generate(
        seq_lens: list[int],
        block_size: int = 16,
    ) -> list[list[int]]:
        """Generate block tables for given sequence lengths."""
        block_tables = []
        next_block_id = 0

        for seq_len in seq_lens:
            num_blocks = (seq_len + block_size - 1) // block_size
            blocks = list(range(next_block_id, next_block_id + num_blocks))
            block_tables.append(blocks)
            next_block_id += num_blocks

        return block_tables

    return _generate


# ============================================================================
# Cleanup Fixtures
# ============================================================================

@pytest.fixture(autouse=True)
def cleanup_mlx_memory():
    """Cleanup MLX memory after each test."""
    yield
    # Force garbage collection to free MLX arrays
    import gc
    gc.collect()


# ============================================================================
# Logging Fixtures
# ============================================================================

@pytest.fixture
def capture_logs(caplog):
    """Capture logs with specific level."""
    import logging
    caplog.set_level(logging.DEBUG)
    return caplog
