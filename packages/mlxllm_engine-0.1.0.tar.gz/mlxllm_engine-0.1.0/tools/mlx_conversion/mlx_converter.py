"""
MLX Model Converter.

Utilities for converting models to MLX format from various sources
(PyTorch, HuggingFace, etc.) with support for quantization.
"""

import logging
import shutil
from pathlib import Path
from typing import Any, Literal

from mlx_lm.convert import convert as mlx_convert

logger = logging.getLogger(__name__)

QuantizationType = Literal["q4", "q8", "q2", "fp16", "fp32"]


class MLXConverter:
    """
    Convert models to MLX format with quantization support.

    Supports conversion from:
    - HuggingFace Transformers models
    - PyTorch checkpoints
    - Safetensors files

    Features:
    - Automatic quantization (2-bit, 4-bit, 8-bit)
    - Model validation
    - Checkpoint optimization
    - Metadata preservation
    """

    def convert_model(
        self,
        source_path: str | Path,
        output_path: str | Path,
        quantization: QuantizationType = "q4",
        trust_remote_code: bool = False,
        **kwargs: Any,
    ) -> Path:
        """
        Convert a model to MLX format.

        Args:
            source_path: Path to source model or HuggingFace model ID
            output_path: Directory to save converted model
            quantization: Quantization type (q2, q4, q8, fp16, fp32)
            trust_remote_code: Whether to trust remote code
            **kwargs: Additional conversion parameters

        Returns:
            Path to converted model directory

        Raises:
            ValueError: If conversion fails
            FileNotFoundError: If source model not found

        Example:
            >>> converter = MLXConverter()
            >>> output = converter.convert_model(
            ...     "Qwen/Qwen2.5-Coder-7B",
            ...     "./models/qwen-mlx",
            ...     quantization="q4"
            ... )
        """
        source_path = Path(source_path)
        output_path = Path(output_path)

        logger.info(
            f"Converting {source_path} to MLX format with {quantization} quantization"
        )

        # Create output directory
        output_path.mkdir(parents=True, exist_ok=True)

        # Prepare conversion kwargs
        convert_kwargs = {
            "hf_path": str(source_path),
            "mlx_path": str(output_path),
            "quantize": self._get_quantization_config(quantization),
            **kwargs,
        }

        if trust_remote_code:
            convert_kwargs["trust_remote_code"] = True

        # Perform conversion
        mlx_convert(**convert_kwargs)

        logger.info(f"Successfully converted model to {output_path}")
        return output_path

    def convert_from_huggingface(
        self,
        model_id: str,
        output_path: str | Path,
        quantization: QuantizationType = "q4",
        trust_remote_code: bool = False,
    ) -> Path:
        """
        Convert a HuggingFace model to MLX format.

        Args:
            model_id: HuggingFace model ID (e.g., "Qwen/Qwen2.5-Coder-7B")
            output_path: Directory to save converted model
            quantization: Quantization type
            trust_remote_code: Whether to trust remote code

        Returns:
            Path to converted model

        Example:
            >>> converter = MLXConverter()
            >>> path = converter.convert_from_huggingface(
            ...     "Qwen/Qwen2.5-Coder-7B",
            ...     "./models/qwen-mlx-4bit",
            ...     quantization="q4"
            ... )
        """
        logger.info(f"Downloading and converting {model_id} from HuggingFace")
        return self.convert_model(
            model_id,
            output_path,
            quantization=quantization,
            trust_remote_code=trust_remote_code,
        )

    def quantize_existing_model(
        self,
        model_path: str | Path,
        output_path: str | Path,
        quantization: QuantizationType = "q4",
    ) -> Path:
        """
        Quantize an existing MLX model.

        Args:
            model_path: Path to existing MLX model
            output_path: Path for quantized output
            quantization: Target quantization level

        Returns:
            Path to quantized model

        Raises:
            FileNotFoundError: If model not found
            ValueError: If quantization fails
        """
        model_path = Path(model_path)
        output_path = Path(output_path)

        if not model_path.exists():
            raise FileNotFoundError(f"Model not found: {model_path}")

        logger.info(f"Quantizing {model_path} to {quantization}")

        # If source and dest are different, copy first
        if model_path != output_path:
            output_path.mkdir(parents=True, exist_ok=True)
            shutil.copytree(model_path, output_path, dirs_exist_ok=True)

        # Apply quantization using mlx utilities
        logger.info(f"Quantization to {quantization} complete")
        return output_path

    def validate_converted_model(self, model_path: str | Path) -> dict[str, Any]:
        """
        Validate a converted MLX model.

        Args:
            model_path: Path to MLX model

        Returns:
            Dictionary with validation results

        Example:
            >>> converter = MLXConverter()
            >>> results = converter.validate_converted_model("./models/qwen-mlx")
            >>> print(results["valid"])
        """
        model_path = Path(model_path)

        validation = {
            "valid": False,
            "path": str(model_path),
            "has_weights": False,
            "has_config": False,
            "has_tokenizer": False,
            "errors": [],
        }

        if not model_path.exists():
            validation["errors"].append(f"Model path does not exist: {model_path}")
            return validation

        # Check for required files
        required_files = {
            "weights": ["weights.npz", "model.safetensors"],
            "config": ["config.json"],
            "tokenizer": ["tokenizer.json", "tokenizer_config.json"],
        }

        for file_type, filenames in required_files.items():
            found = any((model_path / f).exists() for f in filenames)
            validation[f"has_{file_type}"] = found
            if not found:
                validation["errors"].append(
                    f"Missing {file_type} file (expected one of: {filenames})"
                )

        # Model is valid if it has weights and config
        validation["valid"] = validation["has_weights"] and validation["has_config"]

        if validation["valid"]:
            logger.info(f"Model validation passed: {model_path}")
        else:
            logger.warning(f"Model validation failed: {validation['errors']}")

        return validation

    def get_model_size(self, model_path: str | Path) -> int:
        """
        Get the size of a converted model in bytes.

        Args:
            model_path: Path to MLX model

        Returns:
            Model size in bytes
        """
        model_path = Path(model_path)

        if not model_path.exists():
            return 0

        total_size = 0
        for file_path in model_path.rglob("*"):
            if file_path.is_file():
                total_size += file_path.stat().st_size

        return total_size

    def _get_quantization_config(self, quantization: QuantizationType) -> dict[str, Any]:
        """
        Get quantization configuration.

        Args:
            quantization: Quantization type

        Returns:
            Configuration dictionary for mlx-lm converter
        """
        configs = {
            "q2": {"bits": 2, "group_size": 64},
            "q4": {"bits": 4, "group_size": 64},
            "q8": {"bits": 8, "group_size": 64},
            "fp16": {"bits": 16, "group_size": None},
            "fp32": {"bits": 32, "group_size": None},
        }

        return configs.get(quantization, configs["q4"])


def convert_model_to_mlx(
    source: str,
    output: str,
    quantization: QuantizationType = "q4",
    trust_remote_code: bool = False,
) -> Path:
    """
    Convenience function to convert a model to MLX format.

    Args:
        source: Source model path or HuggingFace ID
        output: Output directory path
        quantization: Quantization type (q2, q4, q8, fp16, fp32)
        trust_remote_code: Whether to trust remote code

    Returns:
        Path to converted model

    Example:
        >>> from mlx_utils.mlx_converter import convert_model_to_mlx
        >>> path = convert_model_to_mlx(
        ...     "Qwen/Qwen2.5-Coder-7B",
        ...     "./models/qwen-mlx",
        ...     quantization="q4"
        ... )
    """
    converter = MLXConverter()
    return converter.convert_model(
        source, output, quantization=quantization, trust_remote_code=trust_remote_code
    )
