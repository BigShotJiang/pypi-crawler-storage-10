"""
MLX Model Benchmark.

Comprehensive benchmarking suite for MLX models including performance testing,
memory profiling, latency analysis, and comparative benchmarks across different
configurations and model variants.
"""

import json
import logging
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Literal

import mlx.core as mx
from mlx_lm.generate import generate, stream_generate
from mlx_lm.utils import load

logger = logging.getLogger(__name__)

BenchmarkType = Literal["throughput", "latency", "memory", "comprehensive"]


@dataclass
class BenchmarkConfig:
    """Configuration for benchmark runs."""

    # Test parameters
    prompt: str = "def fibonacci(n):"
    max_tokens: int = 100
    iterations: int = 20
    warmup_iterations: int = 3

    # Test types to run
    test_throughput: bool = True
    test_latency: bool = True
    test_memory: bool = True
    test_streaming: bool = True

    # Token length variations
    test_short_prompts: bool = True  # ~50 tokens
    test_medium_prompts: bool = True  # ~200 tokens
    test_long_prompts: bool = True  # ~500 tokens

    # Output options
    save_results: bool = True
    output_format: Literal["json", "markdown", "csv"] = "json"


@dataclass
class LatencyStats:
    """Latency statistics."""

    min_ms: float
    max_ms: float
    mean_ms: float
    median_ms: float
    p50_ms: float
    p90_ms: float
    p95_ms: float
    p99_ms: float
    std_dev_ms: float


@dataclass
class ThroughputStats:
    """Throughput statistics."""

    min_tokens_per_sec: float
    max_tokens_per_sec: float
    mean_tokens_per_sec: float
    median_tokens_per_sec: float
    total_tokens: int
    total_time_sec: float


@dataclass
class MemoryStats:
    """Memory usage statistics."""

    initial_mb: float
    peak_mb: float
    final_mb: float
    average_mb: float
    metal_peak_mb: float
    metal_average_mb: float


@dataclass
class StreamingStats:
    """Streaming performance statistics."""

    time_to_first_token_ms: float
    tokens_per_second: float
    total_tokens: int
    total_time_sec: float


@dataclass
class ComprehensiveBenchmarkResults:
    """Complete benchmark results."""

    model_path: str
    benchmark_config: BenchmarkConfig
    timestamp: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))

    # Performance metrics
    throughput: ThroughputStats | None = None
    latency: LatencyStats | None = None
    memory: MemoryStats | None = None
    streaming: StreamingStats | None = None

    # Model information
    model_info: dict[str, Any] = field(default_factory=dict)

    # System information
    system_info: dict[str, Any] = field(default_factory=dict)

    # Raw data
    raw_latencies: list[float] = field(default_factory=list)
    raw_throughputs: list[float] = field(default_factory=list)
    raw_memory_samples: list[float] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert results to dictionary."""
        result = {
            "model_path": self.model_path,
            "timestamp": self.timestamp,
            "benchmark_config": asdict(self.benchmark_config),
            "model_info": self.model_info,
            "system_info": self.system_info,
        }

        if self.throughput:
            result["throughput"] = asdict(self.throughput)
        if self.latency:
            result["latency"] = asdict(self.latency)
        if self.memory:
            result["memory"] = asdict(self.memory)
        if self.streaming:
            result["streaming"] = asdict(self.streaming)

        return result

    def to_json(self, indent: int = 2) -> str:
        """Convert results to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def save(self, output_path: str | Path) -> None:
        """Save results to file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with output_path.open("w") as f:
            f.write(self.to_json())

        logger.info(f"Benchmark results saved to {output_path}")


class MLXModelBenchmark:
    """
    Comprehensive benchmarking suite for MLX models.

    Provides various benchmark types including throughput, latency, memory,
    and streaming performance testing. Supports comparative benchmarks and
    statistical analysis.

    Example:
        >>> benchmark = MLXModelBenchmark("mlx-community/Qwen2.5-Coder-7B-4bit")
        >>> benchmark.load()
        >>> results = benchmark.run_comprehensive_benchmark()
        >>> print(f"Throughput: {results.throughput.mean_tokens_per_sec:.2f} tok/s")
        >>> benchmark.save_results(results, "benchmark_results.json")
    """

    def __init__(self, model_path: str | Path):
        """
        Initialize benchmark suite.

        Args:
            model_path: Path to model or HuggingFace model ID
        """
        self.model_path = str(model_path)
        self.model = None
        self.tokenizer = None
        self._loaded = False

        logger.info(f"Initialized benchmark suite for {self.model_path}")

    def load(self, **kwargs: Any) -> None:
        """
        Load model for benchmarking.

        Args:
            **kwargs: Additional arguments passed to mlx_lm.load
        """
        logger.info(f"Loading model from {self.model_path}")
        self.model, self.tokenizer = load(self.model_path, **kwargs)
        self._loaded = True
        logger.info("Model loaded successfully")

    def run_comprehensive_benchmark(
        self, config: BenchmarkConfig | None = None
    ) -> ComprehensiveBenchmarkResults:
        """
        Run comprehensive benchmark suite.

        Args:
            config: Benchmark configuration (uses defaults if None)

        Returns:
            ComprehensiveBenchmarkResults with all benchmark data

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> benchmark = MLXModelBenchmark("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> benchmark.load()
            >>> results = benchmark.run_comprehensive_benchmark()
            >>> print(results.to_json())
        """
        if not self._loaded or self.model is None or self.tokenizer is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        config = config or BenchmarkConfig()

        logger.info("Starting comprehensive benchmark")

        results = ComprehensiveBenchmarkResults(
            model_path=self.model_path,
            benchmark_config=config,
            model_info=self._get_model_info(),
            system_info=self._get_system_info(),
        )

        # Run warmup
        logger.info(f"Running {config.warmup_iterations} warmup iterations...")
        self._warmup(config)

        # Run individual benchmarks
        if config.test_throughput:
            logger.info("Testing throughput...")
            results.throughput, throughput_data = self._benchmark_throughput(config)
            results.raw_throughputs = throughput_data["throughputs"]

        if config.test_latency:
            logger.info("Testing latency...")
            results.latency, latency_data = self._benchmark_latency(config)
            results.raw_latencies = latency_data["latencies"]

        if config.test_memory:
            logger.info("Testing memory usage...")
            results.memory, memory_data = self._benchmark_memory(config)
            results.raw_memory_samples = memory_data["samples"]

        if config.test_streaming:
            logger.info("Testing streaming performance...")
            results.streaming = self._benchmark_streaming(config)

        logger.info("Comprehensive benchmark complete")
        return results

    def benchmark_throughput(
        self, iterations: int = 20, max_tokens: int = 100
    ) -> ThroughputStats:
        """
        Benchmark token generation throughput.

        Args:
            iterations: Number of test iterations
            max_tokens: Maximum tokens per iteration

        Returns:
            ThroughputStats with throughput metrics

        Example:
            >>> benchmark = MLXModelBenchmark("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> benchmark.load()
            >>> stats = benchmark.benchmark_throughput(iterations=20)
            >>> print(f"Mean: {stats.mean_tokens_per_sec:.2f} tok/s")
        """
        if not self._loaded:
            raise RuntimeError("Model not loaded. Call load() first.")

        config = BenchmarkConfig(iterations=iterations, max_tokens=max_tokens)
        stats, _ = self._benchmark_throughput(config)
        return stats

    def benchmark_latency(
        self, iterations: int = 20, max_tokens: int = 100
    ) -> LatencyStats:
        """
        Benchmark generation latency.

        Args:
            iterations: Number of test iterations
            max_tokens: Maximum tokens per iteration

        Returns:
            LatencyStats with latency percentiles

        Example:
            >>> benchmark = MLXModelBenchmark("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> benchmark.load()
            >>> stats = benchmark.benchmark_latency(iterations=20)
            >>> print(f"P95: {stats.p95_ms:.1f}ms")
        """
        if not self._loaded:
            raise RuntimeError("Model not loaded. Call load() first.")

        config = BenchmarkConfig(iterations=iterations, max_tokens=max_tokens)
        stats, _ = self._benchmark_latency(config)
        return stats

    def benchmark_memory(self, iterations: int = 10) -> MemoryStats:
        """
        Benchmark memory usage during generation.

        Args:
            iterations: Number of test iterations

        Returns:
            MemoryStats with memory usage data

        Example:
            >>> benchmark = MLXModelBenchmark("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> benchmark.load()
            >>> stats = benchmark.benchmark_memory(iterations=10)
            >>> print(f"Peak: {stats.peak_mb:.1f}MB")
        """
        if not self._loaded:
            raise RuntimeError("Model not loaded. Call load() first.")

        config = BenchmarkConfig(iterations=iterations)
        stats, _ = self._benchmark_memory(config)
        return stats

    def save_results(
        self, results: ComprehensiveBenchmarkResults, output_path: str | Path
    ) -> None:
        """
        Save benchmark results to file.

        Args:
            results: Benchmark results to save
            output_path: Output file path

        Example:
            >>> results = benchmark.run_comprehensive_benchmark()
            >>> benchmark.save_results(results, "results.json")
        """
        results.save(output_path)

    def _warmup(self, config: BenchmarkConfig) -> None:
        """Run warmup iterations."""
        for i in range(config.warmup_iterations):
            _ = generate(
                self.model,
                self.tokenizer,
                prompt=config.prompt,
                max_tokens=config.max_tokens,
            )
            logger.debug(f"Warmup {i + 1}/{config.warmup_iterations} complete")

    def _benchmark_throughput(
        self, config: BenchmarkConfig
    ) -> tuple[ThroughputStats, dict[str, Any]]:
        """Benchmark throughput."""
        throughputs = []
        total_tokens = 0
        total_time = 0.0

        for i in range(config.iterations):
            mx.metal.clear_cache()

            start = time.perf_counter()
            result = generate(
                self.model,
                self.tokenizer,
                prompt=config.prompt,
                max_tokens=config.max_tokens,
            )
            end = time.perf_counter()

            elapsed = end - start
            tokens = len(self.tokenizer.encode(result)) - len(
                self.tokenizer.encode(config.prompt)
            )

            throughput = tokens / elapsed if elapsed > 0 else 0
            throughputs.append(throughput)
            total_tokens += tokens
            total_time += elapsed

            if (i + 1) % 5 == 0:
                logger.debug(f"Throughput iteration {i + 1}/{config.iterations}")

        throughputs_sorted = sorted(throughputs)

        stats = ThroughputStats(
            min_tokens_per_sec=min(throughputs),
            max_tokens_per_sec=max(throughputs),
            mean_tokens_per_sec=sum(throughputs) / len(throughputs),
            median_tokens_per_sec=self._percentile(throughputs_sorted, 0.5),
            total_tokens=total_tokens,
            total_time_sec=total_time,
        )

        return stats, {"throughputs": throughputs}

    def _benchmark_latency(
        self, config: BenchmarkConfig
    ) -> tuple[LatencyStats, dict[str, Any]]:
        """Benchmark latency."""
        latencies = []

        for i in range(config.iterations):
            mx.metal.clear_cache()

            start = time.perf_counter()
            _ = generate(
                self.model,
                self.tokenizer,
                prompt=config.prompt,
                max_tokens=config.max_tokens,
            )
            end = time.perf_counter()

            latency_ms = (end - start) * 1000
            latencies.append(latency_ms)

            if (i + 1) % 5 == 0:
                logger.debug(f"Latency iteration {i + 1}/{config.iterations}")

        latencies_sorted = sorted(latencies)
        mean = sum(latencies) / len(latencies)
        variance = sum((x - mean) ** 2 for x in latencies) / len(latencies)
        std_dev = variance**0.5

        stats = LatencyStats(
            min_ms=min(latencies),
            max_ms=max(latencies),
            mean_ms=mean,
            median_ms=self._percentile(latencies_sorted, 0.5),
            p50_ms=self._percentile(latencies_sorted, 0.5),
            p90_ms=self._percentile(latencies_sorted, 0.9),
            p95_ms=self._percentile(latencies_sorted, 0.95),
            p99_ms=self._percentile(latencies_sorted, 0.99),
            std_dev_ms=std_dev,
        )

        return stats, {"latencies": latencies}

    def _benchmark_memory(
        self, config: BenchmarkConfig
    ) -> tuple[MemoryStats, dict[str, Any]]:
        """Benchmark memory usage."""
        initial_memory = self._get_active_memory() / (1024**2)
        memory_samples = []
        metal_samples = []

        for i in range(config.iterations):
            mx.metal.clear_cache()

            _ = generate(
                self.model,
                self.tokenizer,
                prompt=config.prompt,
                max_tokens=config.max_tokens,
            )

            memory_mb = self._get_active_memory() / (1024**2)
            metal_mb = mx.metal.get_active_memory() / (1024**2)

            memory_samples.append(memory_mb)
            metal_samples.append(metal_mb)

            if (i + 1) % 5 == 0:
                logger.debug(f"Memory iteration {i + 1}/{config.iterations}")

        final_memory = self._get_active_memory() / (1024**2)

        stats = MemoryStats(
            initial_mb=initial_memory,
            peak_mb=max(memory_samples),
            final_mb=final_memory,
            average_mb=sum(memory_samples) / len(memory_samples),
            metal_peak_mb=max(metal_samples),
            metal_average_mb=sum(metal_samples) / len(metal_samples),
        )

        return stats, {"samples": memory_samples}

    def _benchmark_streaming(self, config: BenchmarkConfig) -> StreamingStats:
        """Benchmark streaming performance."""
        mx.metal.clear_cache()

        tokens = []
        start_time = time.perf_counter()
        first_token_time = None

        for i, response in enumerate(
            stream_generate(
                self.model,
                self.tokenizer,
                prompt=config.prompt,
                max_tokens=config.max_tokens,
            )
        ):
            if i == 0:
                first_token_time = time.perf_counter() - start_time

            # Handle both string and GenerationResponse objects
            if hasattr(response, "text"):
                tokens.append(response.text)
            else:
                tokens.append(str(response))

        end_time = time.perf_counter()
        total_time = end_time - start_time

        stats = StreamingStats(
            time_to_first_token_ms=(first_token_time or 0) * 1000,
            tokens_per_second=len(tokens) / total_time if total_time > 0 else 0,
            total_tokens=len(tokens),
            total_time_sec=total_time,
        )

        return stats

    def _get_model_info(self) -> dict[str, Any]:
        """Get model information."""
        info = {"model_path": self.model_path}

        if self.model and hasattr(self.model, "config"):
            config = self.model.config
            info["model_type"] = getattr(config, "model_type", "unknown")
            info["hidden_size"] = getattr(config, "hidden_size", None)
            info["num_layers"] = getattr(config, "num_hidden_layers", None)
            info["vocab_size"] = getattr(config, "vocab_size", None)

        return info

    def _get_system_info(self) -> dict[str, Any]:
        """Get system information."""
        return {
            "metal_available": mx.metal.is_available(),
            "initial_memory_mb": self._get_active_memory() / (1024**2),
        }

    def _get_active_memory(self) -> int:
        """Get active memory in bytes."""
        if hasattr(mx, "get_active_memory"):
            return mx.get_active_memory()
        else:
            return mx.metal.get_active_memory()

    def _percentile(self, data: list[float], p: float) -> float:
        """Calculate percentile."""
        k = (len(data) - 1) * p
        f = int(k)
        c = int(k) + 1 if k != int(k) else int(k)
        if f == c:
            return data[f]
        return data[f] * (c - k) + data[c] * (k - f)

    def unload(self) -> None:
        """Unload model and free memory."""
        logger.info("Unloading model")
        self.model = None
        self.tokenizer = None
        self._loaded = False
        mx.metal.clear_cache()
        logger.info("Model unloaded, cache cleared")


def run_benchmark(
    model_path: str | Path,
    benchmark_type: BenchmarkType = "comprehensive",
    iterations: int = 20,
    output_path: str | Path | None = None,
) -> ComprehensiveBenchmarkResults | ThroughputStats | LatencyStats | MemoryStats:
    """
    Convenience function to run a benchmark.

    Args:
        model_path: Path to model or HuggingFace model ID
        benchmark_type: Type of benchmark to run
        iterations: Number of iterations
        output_path: Optional path to save results

    Returns:
        Benchmark results (type depends on benchmark_type)

    Example:
        >>> from mlx_utils.mlx_model_benchmark import run_benchmark
        >>> results = run_benchmark(
        ...     "mlx-community/Qwen2.5-Coder-7B-4bit",
        ...     benchmark_type="comprehensive",
        ...     output_path="results.json"
        ... )
        >>> print(f"Throughput: {results.throughput.mean_tokens_per_sec:.2f} tok/s")
    """
    benchmark = MLXModelBenchmark(model_path)
    benchmark.load()

    if benchmark_type == "comprehensive":
        results = benchmark.run_comprehensive_benchmark()
        if output_path:
            benchmark.save_results(results, output_path)
        benchmark.unload()
        return results
    elif benchmark_type == "throughput":
        results = benchmark.benchmark_throughput(iterations=iterations)
        benchmark.unload()
        return results
    elif benchmark_type == "latency":
        results = benchmark.benchmark_latency(iterations=iterations)
        benchmark.unload()
        return results
    elif benchmark_type == "memory":
        results = benchmark.benchmark_memory(iterations=iterations)
        benchmark.unload()
        return results
    else:
        benchmark.unload()
        raise ValueError(f"Unknown benchmark type: {benchmark_type}")


def compare_models(
    model_paths: list[str | Path],
    iterations: int = 20,
    output_path: str | Path | None = None,
) -> dict[str, ComprehensiveBenchmarkResults]:
    """
    Run comparative benchmarks across multiple models.

    Args:
        model_paths: List of model paths or HuggingFace IDs
        iterations: Number of iterations per model
        output_path: Optional path to save comparison results

    Returns:
        Dictionary mapping model paths to benchmark results

    Example:
        >>> from mlx_utils.mlx_model_benchmark import compare_models
        >>> results = compare_models([
        ...     "mlx-community/Qwen2.5-Coder-7B-4bit",
        ...     "mlx-community/Qwen2.5-Coder-7B-8bit",
        ... ])
        >>> for model, result in results.items():
        ...     print(f"{model}: {result.throughput.mean_tokens_per_sec:.2f} tok/s")
    """
    results = {}

    for model_path in model_paths:
        logger.info(f"Benchmarking {model_path}...")
        result = run_benchmark(model_path, "comprehensive", iterations=iterations)
        results[str(model_path)] = result

    if output_path:
        output_path = Path(output_path)
        comparison = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "models": {path: result.to_dict() for path, result in results.items()},
        }
        with output_path.open("w") as f:
            json.dump(comparison, f, indent=2)
        logger.info(f"Comparison results saved to {output_path}")

    return results
