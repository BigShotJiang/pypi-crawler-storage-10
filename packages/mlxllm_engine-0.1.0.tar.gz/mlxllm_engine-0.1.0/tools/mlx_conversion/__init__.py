"""
MLX Utilities.

Comprehensive utilities for working with MLX models on Apple Silicon.
Provides model conversion, optimization, metrics tracking, and diagnostics.

Modules:
    - mlx_converter: Model conversion and quantization
    - mlx_model_metrics: Performance metrics and monitoring
    - mlx_optimizer: Model optimization and memory management
    - mlx_probe_model: Model inspection and benchmarking

Example:
    >>> from mlx_utils import MLXConverter, MLXModelProbe, MLXOptimizer
    >>> # Convert a model
    >>> converter = MLXConverter()
    >>> converter.convert_from_huggingface(
    ...     "Qwen/Qwen2.5-Coder-7B",
    ...     "./models/qwen-mlx",
    ...     quantization="q4"
    ... )
    >>> # Probe and benchmark
    >>> probe = MLXModelProbe("./models/qwen-mlx")
    >>> probe.load()
    >>> results = probe.benchmark()
    >>> print(f"Speed: {results.avg_tokens_per_second:.2f} tok/s")
"""

from mlx_conversion.mlx_converter import (
    MLXConverter,
    QuantizationType,
    convert_model_to_mlx,
)
from mlx_conversion.mlx_model_benchmark import (
    BenchmarkConfig,
    BenchmarkType,
    ComprehensiveBenchmarkResults,
    LatencyStats,
    MemoryStats,
    MLXModelBenchmark,
    StreamingStats,
    ThroughputStats,
    compare_models,
    run_benchmark,
)
from mlx_conversion.mlx_model_metrics import (
    AggregateMetrics,
    InferenceContext,
    InferenceMetrics,
    MLXModelMetrics,
    create_metrics_tracker,
)
from mlx_conversion.mlx_optimizer import (
    MLXOptimizer,
    OptimizationConfig,
    OptimizationLevel,
    analyze_and_optimize,
    optimize_model,
)
from mlx_conversion.mlx_probe_model import (
    BenchmarkResults,
    MLXModelProbe,
    ModelArchitecture,
    ModelParameters,
    benchmark_model,
    probe_model,
)

__all__ = [
    # Converter
    "MLXConverter",
    "QuantizationType",
    "convert_model_to_mlx",
    # Metrics
    "MLXModelMetrics",
    "InferenceMetrics",
    "AggregateMetrics",
    "InferenceContext",
    "create_metrics_tracker",
    # Optimizer
    "MLXOptimizer",
    "OptimizationConfig",
    "OptimizationLevel",
    "optimize_model",
    "analyze_and_optimize",
    # Probe
    "MLXModelProbe",
    "ModelArchitecture",
    "ModelParameters",
    "BenchmarkResults",
    "probe_model",
    "benchmark_model",
    # Benchmark
    "MLXModelBenchmark",
    "BenchmarkConfig",
    "BenchmarkType",
    "ComprehensiveBenchmarkResults",
    "ThroughputStats",
    "LatencyStats",
    "MemoryStats",
    "StreamingStats",
    "run_benchmark",
    "compare_models",
]

__version__ = "0.1.0"
