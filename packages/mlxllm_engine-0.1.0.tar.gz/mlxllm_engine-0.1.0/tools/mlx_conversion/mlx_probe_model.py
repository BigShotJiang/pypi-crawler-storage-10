"""
MLX Model Probe.

Diagnostic and inspection utilities for MLX models including architecture
analysis, layer inspection, parameter counting, and performance benchmarking.
"""

import logging
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import mlx.core as mx
from mlx_lm.generate import generate, stream_generate
from mlx_lm.utils import load

logger = logging.getLogger(__name__)


@dataclass
class ModelArchitecture:
    """Model architecture information."""

    model_type: str
    hidden_size: int
    num_layers: int
    num_attention_heads: int
    vocab_size: int
    max_position_embeddings: int
    intermediate_size: int | None = None
    num_key_value_heads: int | None = None
    rope_theta: float | None = None
    additional_config: dict[str, Any] = field(default_factory=dict)


@dataclass
class ModelParameters:
    """Model parameter statistics."""

    total_params: int
    trainable_params: int
    non_trainable_params: int
    size_bytes: int
    size_mb: float
    size_gb: float
    param_breakdown: dict[str, int] = field(default_factory=dict)


@dataclass
class BenchmarkResults:
    """Benchmark test results."""

    # Performance metrics
    avg_tokens_per_second: float
    max_tokens_per_second: float
    min_tokens_per_second: float
    median_tokens_per_second: float

    # Timing metrics
    avg_latency_ms: float
    p50_latency_ms: float
    p95_latency_ms: float
    p99_latency_ms: float

    # Memory metrics
    peak_memory_mb: float
    avg_memory_mb: float

    # Test configuration
    num_iterations: int
    prompt_length: int
    max_tokens: int

    # Raw data
    all_speeds: list[float] = field(default_factory=list)
    all_latencies: list[float] = field(default_factory=list)


class MLXModelProbe:
    """
    Diagnostic and inspection tool for MLX models.

    Provides comprehensive model analysis including:
    - Architecture inspection
    - Parameter counting
    - Memory profiling
    - Performance benchmarking
    - Layer-by-layer analysis

    Example:
        >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
        >>> probe.load()
        >>> info = probe.get_model_info()
        >>> benchmark = probe.benchmark()
        >>> print(f"Speed: {benchmark.avg_tokens_per_second:.2f} tok/s")
    """

    def __init__(self, model_path: str | Path):
        """
        Initialize model probe.

        Args:
            model_path: Path to model or HuggingFace model ID
        """
        self.model_path = str(model_path)
        self.model = None
        self.tokenizer = None
        self._loaded = False

        logger.info(f"Initialized probe for {self.model_path}")

    def load(self, **kwargs: Any) -> None:
        """
        Load model for inspection.

        Args:
            **kwargs: Additional arguments passed to mlx_lm.load
        """
        logger.info(f"Loading model from {self.model_path}")
        self.model, self.tokenizer = load(self.model_path, **kwargs)
        self._loaded = True
        logger.info("Model loaded successfully")

    def get_architecture(self) -> ModelArchitecture:
        """
        Get model architecture information.

        Returns:
            ModelArchitecture with detailed configuration

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> arch = probe.get_architecture()
            >>> print(f"Layers: {arch.num_layers}")
        """
        if not self._loaded or self.model is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        config = self.model.config

        # Extract common architecture parameters
        arch = ModelArchitecture(
            model_type=getattr(config, "model_type", "unknown"),
            hidden_size=getattr(config, "hidden_size", 0),
            num_layers=getattr(config, "num_hidden_layers", 0),
            num_attention_heads=getattr(config, "num_attention_heads", 0),
            vocab_size=getattr(config, "vocab_size", 0),
            max_position_embeddings=getattr(config, "max_position_embeddings", 0),
            intermediate_size=getattr(config, "intermediate_size", None),
            num_key_value_heads=getattr(config, "num_key_value_heads", None),
            rope_theta=getattr(config, "rope_theta", None),
        )

        # Capture additional config as dict
        config_dict = {}
        for key in dir(config):
            if not key.startswith("_"):
                value = getattr(config, key)
                if not callable(value):
                    config_dict[key] = value

        arch.additional_config = config_dict

        logger.info(
            f"Architecture: {arch.model_type}, "
            f"{arch.num_layers} layers, "
            f"{arch.hidden_size} hidden size"
        )

        return arch

    def get_parameters(self) -> ModelParameters:
        """
        Get model parameter statistics.

        Returns:
            ModelParameters with detailed parameter counts

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> params = probe.get_parameters()
            >>> print(f"Total params: {params.total_params:,}")
        """
        if not self._loaded or self.model is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        # Count parameters
        total_params = 0
        param_breakdown = {}

        # Traverse model tree
        def count_params(module: Any, prefix: str = "") -> None:
            nonlocal total_params

            if hasattr(module, "parameters"):
                for name, param in module.parameters().items():
                    if hasattr(param, "shape"):
                        param_count = 1
                        for dim in param.shape:
                            param_count *= dim
                        total_params += param_count

                        full_name = f"{prefix}.{name}" if prefix else name
                        param_breakdown[full_name] = param_count

            # Recurse into child modules
            if hasattr(module, "__dict__"):
                for name, child in module.__dict__.items():
                    if not name.startswith("_") and hasattr(child, "parameters"):
                        child_prefix = f"{prefix}.{name}" if prefix else name
                        count_params(child, child_prefix)

        count_params(self.model)

        # Estimate size (assuming float16 by default)
        bytes_per_param = 2  # float16

        # Check if quantized
        model_name_lower = self.model_path.lower()
        if "4bit" in model_name_lower or "q4" in model_name_lower:
            bytes_per_param = 0.5  # 4-bit
        elif "8bit" in model_name_lower or "q8" in model_name_lower:
            bytes_per_param = 1  # 8-bit

        size_bytes = int(total_params * bytes_per_param)

        params = ModelParameters(
            total_params=total_params,
            trainable_params=total_params,  # Assume all trainable
            non_trainable_params=0,
            size_bytes=size_bytes,
            size_mb=size_bytes / (1024**2),
            size_gb=size_bytes / (1024**3),
            param_breakdown=param_breakdown,
        )

        logger.info(
            f"Parameters: {params.total_params:,} "
            f"({params.size_gb:.2f}GB estimated)"
        )

        return params

    def get_memory_usage(self) -> dict[str, Any]:
        """
        Get current memory usage.

        Returns:
            Dictionary with memory statistics

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> memory = probe.get_memory_usage()
            >>> print(f"Using {memory['active_memory_mb']:.1f}MB")
        """
        # Use newer API if available, fallback to deprecated
        if hasattr(mx, "get_active_memory"):
            active_memory = mx.get_active_memory()
        else:
            active_memory = mx.metal.get_active_memory()

        metal_memory = mx.metal.get_active_memory()

        return {
            "active_memory_bytes": active_memory,
            "active_memory_mb": active_memory / (1024**2),
            "active_memory_gb": active_memory / (1024**3),
            "metal_memory_bytes": metal_memory,
            "metal_memory_mb": metal_memory / (1024**2),
            "metal_available": mx.metal.is_available(),
        }

    def benchmark(
        self,
        prompt: str = "def fibonacci(n):",
        max_tokens: int = 100,
        iterations: int = 10,
        warmup: int = 2,
    ) -> BenchmarkResults:
        """
        Benchmark model inference performance.

        Args:
            prompt: Test prompt for generation
            max_tokens: Maximum tokens to generate per iteration
            iterations: Number of benchmark iterations
            warmup: Number of warmup iterations (not counted)

        Returns:
            BenchmarkResults with comprehensive performance metrics

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> results = probe.benchmark(iterations=20)
            >>> print(f"Avg: {results.avg_tokens_per_second:.2f} tok/s")
            >>> print(f"P95 latency: {results.p95_latency_ms:.1f}ms")
        """
        if not self._loaded or self.model is None or self.tokenizer is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        logger.info(
            f"Starting benchmark: {iterations} iterations, "
            f"{max_tokens} max tokens, {warmup} warmup"
        )

        # Warmup runs
        logger.info("Running warmup iterations...")
        for i in range(warmup):
            _ = generate(
                self.model,
                self.tokenizer,
                prompt=prompt,
                max_tokens=max_tokens,
            )
            logger.debug(f"Warmup {i + 1}/{warmup} complete")

        # Benchmark runs
        speeds = []
        latencies = []
        memory_samples = []

        logger.info("Running benchmark iterations...")
        for i in range(iterations):
            # Clear cache before each run
            mx.metal.clear_cache()

            start_time = time.perf_counter()

            result = generate(
                self.model,
                self.tokenizer,
                prompt=prompt,
                max_tokens=max_tokens,
            )

            end_time = time.perf_counter()
            latency = (end_time - start_time) * 1000  # Convert to ms

            # Estimate tokens generated (rough approximation)
            tokens_generated = len(self.tokenizer.encode(result)) - len(
                self.tokenizer.encode(prompt)
            )

            speed = tokens_generated / (latency / 1000) if latency > 0 else 0

            speeds.append(speed)
            latencies.append(latency)

            # Sample memory
            memory_mb = self.get_memory_usage()["active_memory_mb"]
            memory_samples.append(memory_mb)

            if (i + 1) % 5 == 0:
                logger.debug(f"Completed {i + 1}/{iterations} iterations")

        # Calculate statistics
        speeds_sorted = sorted(speeds)
        latencies_sorted = sorted(latencies)

        def percentile(data: list[float], p: float) -> float:
            """Calculate percentile."""
            k = (len(data) - 1) * p
            f = int(k)
            c = int(k) + 1 if k != int(k) else int(k)
            if f == c:
                return data[f]
            return data[f] * (c - k) + data[c] * (k - f)

        results = BenchmarkResults(
            # Speed metrics
            avg_tokens_per_second=sum(speeds) / len(speeds),
            max_tokens_per_second=max(speeds),
            min_tokens_per_second=min(speeds),
            median_tokens_per_second=percentile(speeds_sorted, 0.5),
            # Latency metrics
            avg_latency_ms=sum(latencies) / len(latencies),
            p50_latency_ms=percentile(latencies_sorted, 0.5),
            p95_latency_ms=percentile(latencies_sorted, 0.95),
            p99_latency_ms=percentile(latencies_sorted, 0.99),
            # Memory metrics
            peak_memory_mb=max(memory_samples),
            avg_memory_mb=sum(memory_samples) / len(memory_samples),
            # Configuration
            num_iterations=iterations,
            prompt_length=len(self.tokenizer.encode(prompt)),
            max_tokens=max_tokens,
            # Raw data
            all_speeds=speeds,
            all_latencies=latencies,
        )

        logger.info(
            f"Benchmark complete: {results.avg_tokens_per_second:.2f} tok/s avg, "
            f"P95 latency {results.p95_latency_ms:.1f}ms"
        )

        return results

    def test_generation(
        self, prompt: str = "def hello():", max_tokens: int = 50, stream: bool = False
    ) -> str | Iterator[str]:
        """
        Test model generation.

        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            stream: Whether to stream tokens

        Returns:
            Generated text (or iterator if streaming)

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> result = probe.test_generation("def fibonacci(n):")
            >>> print(result)
        """
        if not self._loaded or self.model is None or self.tokenizer is None:
            raise RuntimeError("Model not loaded. Call load() first.")

        logger.info(f"Testing generation (stream={stream})")

        if stream:
            return stream_generate(
                self.model, self.tokenizer, prompt=prompt, max_tokens=max_tokens
            )
        else:
            return generate(
                self.model, self.tokenizer, prompt=prompt, max_tokens=max_tokens
            )

    def get_model_info(self) -> dict[str, Any]:
        """
        Get comprehensive model information.

        Returns:
            Dictionary with all available model information

        Raises:
            RuntimeError: If model not loaded

        Example:
            >>> probe = MLXModelProbe("mlx-community/Qwen2.5-Coder-7B-4bit")
            >>> probe.load()
            >>> info = probe.get_model_info()
            >>> print(info["architecture"]["num_layers"])
        """
        if not self._loaded:
            raise RuntimeError("Model not loaded. Call load() first.")

        arch = self.get_architecture()
        params = self.get_parameters()
        memory = self.get_memory_usage()

        return {
            "model_path": self.model_path,
            "architecture": {
                "model_type": arch.model_type,
                "hidden_size": arch.hidden_size,
                "num_layers": arch.num_layers,
                "num_attention_heads": arch.num_attention_heads,
                "vocab_size": arch.vocab_size,
                "max_position_embeddings": arch.max_position_embeddings,
                "intermediate_size": arch.intermediate_size,
                "num_key_value_heads": arch.num_key_value_heads,
            },
            "parameters": {
                "total_params": params.total_params,
                "size_gb": params.size_gb,
                "size_mb": params.size_mb,
            },
            "memory": memory,
            "loaded": self._loaded,
        }

    def unload(self) -> None:
        """Unload model and free memory."""
        logger.info("Unloading model")
        self.model = None
        self.tokenizer = None
        self._loaded = False
        mx.metal.clear_cache()
        logger.info("Model unloaded, cache cleared")


def probe_model(model_path: str | Path) -> dict[str, Any]:
    """
    Convenience function to probe a model and get all information.

    Args:
        model_path: Path to model or HuggingFace model ID

    Returns:
        Dictionary with comprehensive model information

    Example:
        >>> from mlx_utils.mlx_probe_model import probe_model
        >>> info = probe_model("mlx-community/Qwen2.5-Coder-7B-4bit")
        >>> print(f"Layers: {info['architecture']['num_layers']}")
    """
    probe = MLXModelProbe(model_path)
    probe.load()
    info = probe.get_model_info()
    probe.unload()
    return info


def benchmark_model(
    model_path: str | Path,
    iterations: int = 10,
    max_tokens: int = 100,
) -> BenchmarkResults:
    """
    Convenience function to benchmark a model.

    Args:
        model_path: Path to model or HuggingFace model ID
        iterations: Number of benchmark iterations
        max_tokens: Maximum tokens per iteration

    Returns:
        BenchmarkResults with performance metrics

    Example:
        >>> from mlx_utils.mlx_probe_model import benchmark_model
        >>> results = benchmark_model(
        ...     "mlx-community/Qwen2.5-Coder-7B-4bit",
        ...     iterations=20
        ... )
        >>> print(f"Speed: {results.avg_tokens_per_second:.2f} tok/s")
    """
    probe = MLXModelProbe(model_path)
    probe.load()
    results = probe.benchmark(iterations=iterations, max_tokens=max_tokens)
    probe.unload()
    return results
