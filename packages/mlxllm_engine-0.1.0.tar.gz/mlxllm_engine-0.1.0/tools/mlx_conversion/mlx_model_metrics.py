"""
MLX Model Metrics.

Performance monitoring and profiling utilities for MLX models.
Tracks inference speed, memory usage, and other runtime metrics.
"""

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any

import mlx.core as mx

logger = logging.getLogger(__name__)


@dataclass
class InferenceMetrics:
    """Metrics for a single inference operation."""

    tokens_generated: int
    inference_time: float  # seconds
    tokens_per_second: float
    memory_used: int  # bytes
    metal_memory: int  # bytes
    prompt_length: int
    timestamp: float = field(default_factory=time.time)

    @property
    def memory_mb(self) -> float:
        """Memory usage in MB."""
        return self.memory_used / (1024 * 1024)

    @property
    def metal_memory_mb(self) -> float:
        """Metal memory usage in MB."""
        return self.metal_memory / (1024 * 1024)


@dataclass
class AggregateMetrics:
    """Aggregated metrics across multiple inferences."""

    total_inferences: int = 0
    total_tokens: int = 0
    total_time: float = 0.0
    avg_tokens_per_second: float = 0.0
    max_tokens_per_second: float = 0.0
    min_tokens_per_second: float = float("inf")
    avg_memory_mb: float = 0.0
    peak_memory_mb: float = 0.0
    errors: int = 0


class MLXModelMetrics:
    """
    Performance metrics tracker for MLX models.

    Tracks inference performance, memory usage, and other runtime statistics.
    Provides real-time monitoring and historical analysis capabilities.

    Features:
    - Token generation speed tracking
    - Memory usage monitoring (system and Metal)
    - Latency percentiles
    - Historical metrics with configurable window
    - Export to various formats (dict, JSON, etc.)

    Example:
        >>> metrics = MLXModelMetrics(model_name="qwen2.5-coder-7b")
        >>> with metrics.track_inference(prompt_tokens=50):
        ...     # Run inference
        ...     tokens = 100
        ...     metrics.record_tokens(tokens)
        >>> stats = metrics.get_statistics()
        >>> print(f"Avg speed: {stats['avg_tokens_per_second']:.2f} tok/s")
    """

    def __init__(
        self,
        model_name: str,
        history_size: int = 100,
        enable_profiling: bool = True,
    ):
        """
        Initialize metrics tracker.

        Args:
            model_name: Name of the model being tracked
            history_size: Number of recent metrics to keep
            enable_profiling: Whether to enable detailed profiling
        """
        self.model_name = model_name
        self.history_size = history_size
        self.enable_profiling = enable_profiling

        # Metrics storage
        self._history: deque[InferenceMetrics] = deque(maxlen=history_size)
        self._current_inference: dict[str, Any] = {}
        self._aggregate = AggregateMetrics()

        # Performance tracking
        self._start_time: float | None = None
        self._prompt_tokens: int = 0
        self._generated_tokens: int = 0

        logger.info(f"Initialized metrics tracker for {model_name}")

    def start_inference(self, prompt_tokens: int = 0) -> None:
        """
        Start tracking a new inference operation.

        Args:
            prompt_tokens: Number of tokens in the prompt
        """
        self._start_time = time.time()
        self._prompt_tokens = prompt_tokens
        self._generated_tokens = 0
        self._current_inference = {
            "prompt_tokens": prompt_tokens,
            "start_memory": self._get_memory_usage(),
        }

    def record_tokens(self, num_tokens: int) -> None:
        """
        Record tokens generated during current inference.

        Args:
            num_tokens: Number of tokens generated
        """
        self._generated_tokens = num_tokens

    def end_inference(self) -> InferenceMetrics:
        """
        End current inference and record metrics.

        Returns:
            Metrics for the completed inference

        Raises:
            RuntimeError: If no inference is in progress
        """
        if self._start_time is None:
            raise RuntimeError("No inference in progress")

        # Calculate metrics
        end_time = time.time()
        inference_time = end_time - self._start_time
        tokens_per_second = (
            self._generated_tokens / inference_time if inference_time > 0 else 0.0
        )

        memory = self._get_memory_usage()
        metal_memory = self._get_metal_memory()

        metrics = InferenceMetrics(
            tokens_generated=self._generated_tokens,
            inference_time=inference_time,
            tokens_per_second=tokens_per_second,
            memory_used=memory,
            metal_memory=metal_memory,
            prompt_length=self._prompt_tokens,
            timestamp=end_time,
        )

        # Update aggregate stats
        self._update_aggregates(metrics)

        # Store in history
        self._history.append(metrics)

        # Reset current tracking
        self._start_time = None
        self._current_inference = {}

        logger.debug(
            f"Inference complete: {tokens_per_second:.2f} tok/s, "
            f"{metrics.memory_mb:.1f} MB"
        )

        return metrics

    def track_inference(self, prompt_tokens: int = 0) -> "InferenceContext":
        """
        Context manager for tracking inference.

        Args:
            prompt_tokens: Number of tokens in the prompt

        Returns:
            Context manager for inference tracking

        Example:
            >>> with metrics.track_inference(prompt_tokens=50):
            ...     result = model.generate(prompt)
            ...     metrics.record_tokens(len(result))
        """
        return InferenceContext(self, prompt_tokens)

    def get_statistics(self) -> dict[str, Any]:
        """
        Get comprehensive statistics.

        Returns:
            Dictionary containing all metrics and statistics
        """
        recent_metrics = list(self._history)

        stats = {
            "model_name": self.model_name,
            "total_inferences": self._aggregate.total_inferences,
            "total_tokens": self._aggregate.total_tokens,
            "total_time": self._aggregate.total_time,
            "aggregate": {
                "avg_tokens_per_second": self._aggregate.avg_tokens_per_second,
                "max_tokens_per_second": self._aggregate.max_tokens_per_second,
                "min_tokens_per_second": (
                    self._aggregate.min_tokens_per_second
                    if self._aggregate.min_tokens_per_second != float("inf")
                    else 0.0
                ),
                "avg_memory_mb": self._aggregate.avg_memory_mb,
                "peak_memory_mb": self._aggregate.peak_memory_mb,
                "errors": self._aggregate.errors,
            },
            "recent": self._get_recent_stats(recent_metrics),
            "current_memory": {
                "memory_mb": self._get_memory_usage() / (1024 * 1024),
                "metal_memory_mb": self._get_metal_memory() / (1024 * 1024),
            },
        }

        return stats

    def get_recent_metrics(self, count: int | None = None) -> list[InferenceMetrics]:
        """
        Get recent inference metrics.

        Args:
            count: Number of recent metrics (None for all in history)

        Returns:
            List of recent metrics
        """
        metrics = list(self._history)
        if count is not None:
            return metrics[-count:]
        return metrics

    def reset(self) -> None:
        """Reset all metrics."""
        self._history.clear()
        self._aggregate = AggregateMetrics()
        self._current_inference = {}
        self._start_time = None
        logger.info(f"Reset metrics for {self.model_name}")

    def _update_aggregates(self, metrics: InferenceMetrics) -> None:
        """Update aggregate statistics with new metrics."""
        self._aggregate.total_inferences += 1
        self._aggregate.total_tokens += metrics.tokens_generated
        self._aggregate.total_time += metrics.inference_time

        # Update averages
        self._aggregate.avg_tokens_per_second = (
            self._aggregate.total_tokens / self._aggregate.total_time
            if self._aggregate.total_time > 0
            else 0.0
        )

        # Update extremes
        self._aggregate.max_tokens_per_second = max(
            self._aggregate.max_tokens_per_second, metrics.tokens_per_second
        )
        self._aggregate.min_tokens_per_second = min(
            self._aggregate.min_tokens_per_second, metrics.tokens_per_second
        )

        # Memory tracking
        self._aggregate.avg_memory_mb = (
            sum(m.memory_mb for m in self._history) / len(self._history)
            if self._history
            else 0.0
        )
        self._aggregate.peak_memory_mb = max(
            self._aggregate.peak_memory_mb, metrics.memory_mb
        )

    def _get_recent_stats(self, metrics: list[InferenceMetrics]) -> dict[str, Any]:
        """Calculate statistics for recent metrics."""
        if not metrics:
            return {
                "count": 0,
                "avg_tokens_per_second": 0.0,
                "avg_memory_mb": 0.0,
            }

        return {
            "count": len(metrics),
            "avg_tokens_per_second": sum(m.tokens_per_second for m in metrics)
            / len(metrics),
            "avg_memory_mb": sum(m.memory_mb for m in metrics) / len(metrics),
            "avg_inference_time": sum(m.inference_time for m in metrics)
            / len(metrics),
        }

    def _get_memory_usage(self) -> int:
        """Get current memory usage in bytes."""
        # Use newer API if available, fallback to deprecated
        if hasattr(mx, "get_active_memory"):
            return mx.get_active_memory()
        else:
            return mx.metal.get_active_memory()

    def _get_metal_memory(self) -> int:
        """Get Metal GPU memory usage in bytes."""
        return mx.metal.get_active_memory()


class InferenceContext:
    """Context manager for tracking inference operations."""

    def __init__(self, metrics: MLXModelMetrics, prompt_tokens: int):
        """
        Initialize inference context.

        Args:
            metrics: Metrics tracker instance
            prompt_tokens: Number of prompt tokens
        """
        self.metrics = metrics
        self.prompt_tokens = prompt_tokens

    def __enter__(self) -> "InferenceContext":
        """Start inference tracking."""
        self.metrics.start_inference(self.prompt_tokens)
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """End inference tracking."""
        if exc_type is None:
            self.metrics.end_inference()
        else:
            # Record error
            self.metrics._aggregate.errors += 1
            logger.error(f"Inference failed: {exc_val}")


def create_metrics_tracker(
    model_name: str, history_size: int = 100
) -> MLXModelMetrics:
    """
    Create a metrics tracker instance.

    Args:
        model_name: Name of the model to track
        history_size: Number of recent metrics to keep

    Returns:
        Metrics tracker instance

    Example:
        >>> tracker = create_metrics_tracker("qwen2.5-coder-7b")
        >>> with tracker.track_inference(prompt_tokens=50):
        ...     # Run inference
        ...     pass
    """
    return MLXModelMetrics(model_name=model_name, history_size=history_size)
