# SPDX-License-Identifier: Apache-2.0
"""
DoRA (Weight-Decomposed Low-Rank Adaptation) implementation for MLX-LLM.

DoRA decomposes the pre-trained weight into magnitude and direction components,
applying LoRA to the directional component while learning a separate magnitude vector.

Based on Apple's MLX-LM implementation with adaptations for mlxllm.
Reference: "DoRA: Weight-Decomposed Low-Rank Adaptation" (Liu et al., 2024)
"""

import math

import mlx.core as mx
import mlx.nn as nn


class DoRALinear(nn.Module):
    """
    DoRA linear layer for parameter-efficient fine-tuning.

    DoRA factorizes the adapted weight as:
        W' = m * (W + scale * B @ A) / ||W + scale * B @ A||
    where m is the learned magnitude and B @ A is the LoRA update.
    """

    @staticmethod
    def from_base(
        linear: nn.Linear,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Create a DoRA linear layer from an existing linear layer.

        Args:
            linear: Base linear layer to adapt.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor for the low-rank update.

        Returns:
            DoRALinear layer wrapping the base layer.
        """
        # Get dimensions from base linear layer
        output_dims, input_dims = linear.weight.shape
        if isinstance(linear, nn.QuantizedLinear):
            input_dims *= 32 // linear.bits

        dora_lin = DoRALinear(
            input_dims=input_dims,
            output_dims=output_dims,
            r=r,
            dropout=dropout,
            scale=scale,
        )
        dora_lin.set_linear(linear)
        return dora_lin

    def fuse(self, de_quantize: bool = False):
        """
        Fuse the DoRA adapter weights back into the base linear layer.

        Args:
            de_quantize: If True, dequantize the result if the base layer was quantized.

        Returns:
            Fused linear layer with DoRA weights merged.
        """
        linear = self.linear
        bias = "bias" in linear
        weight = self._dequantized_weight()

        # Use the same type as the linear weight
        dtype = weight.dtype

        output_dims, input_dims = weight.shape
        fused_linear = nn.Linear(input_dims, output_dims, bias=False)

        # Apply LoRA update
        lora_b = (self.scale * self.lora_b.T).astype(dtype)
        lora_a = self.lora_a.T.astype(dtype)
        weight = weight + lora_b @ lora_a

        # Apply magnitude scaling
        norm_scale = self.m / mx.linalg.norm(weight, axis=1)
        fused_linear.weight = norm_scale[:, None] * weight

        if bias:
            fused_linear.bias = linear.bias

        if self._is_quantized() and not de_quantize:
            fused_linear = nn.QuantizedLinear.from_linear(
                fused_linear,
                linear.group_size,
                linear.bits,
            )

        return fused_linear

    def __init__(
        self,
        input_dims: int,
        output_dims: int,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
        bias: bool = False,
    ):
        """
        Initialize a DoRA linear layer.

        Args:
            input_dims: Input dimension.
            output_dims: Output dimension.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor for the low-rank update.
            bias: Whether to include bias.
        """
        super().__init__()

        # Regular linear layer weights
        self.set_linear(nn.Linear(input_dims, output_dims, bias=bias))
        self.dropout = nn.Dropout(p=dropout)

        # Scale for low-rank update
        self.scale = scale

        # Low rank LoRA weights
        scale_init = 1 / math.sqrt(input_dims)
        self.lora_a = mx.random.uniform(
            low=-scale_init,
            high=scale_init,
            shape=(input_dims, r),
        )
        self.lora_b = mx.zeros(shape=(r, output_dims))

    def set_linear(self, linear):
        """
        Set the base linear layer and compute magnitude vector.

        Args:
            linear: Base linear layer.
        """
        self.linear = linear
        # Compute the magnitude (L2 norm) of each output dimension
        self.m = mx.linalg.norm(self._dequantized_weight().astype(mx.float32), axis=1)

    def _dequantized_weight(self):
        """
        Return the weight of linear layer, dequantizing if necessary.

        Returns:
            Dequantized weight tensor.
        """
        weight = self.linear.weight
        if self._is_quantized():
            weight = mx.dequantize(
                weight,
                self.linear.scales,
                self.linear.biases,
                self.linear.group_size,
                self.linear.bits,
            )
        return weight

    def _is_quantized(self):
        """Check if the base linear layer is quantized."""
        return isinstance(self.linear, nn.QuantizedLinear)

    def __call__(self, x):
        """
        Forward pass with DoRA adaptation.

        Args:
            x: Input tensor.

        Returns:
            Output tensor with DoRA adaptation applied.
        """
        # Get dequantized weight
        w = self._dequantized_weight()

        # Regular linear transformation (without bias for now)
        y = x @ w.T

        # LoRA low-rank transformation
        z = (self.dropout(x) @ self.lora_a) @ self.lora_b
        out = y + (self.scale * z).astype(x.dtype)

        # Compute the directional component of adapted weights
        adapted = w + (self.scale * self.lora_b.T) @ self.lora_a.T
        denom = mx.stop_gradient(mx.linalg.norm(adapted, axis=1))

        # Apply magnitude scaling: m / ||W'|| * output
        out = (self.m / denom).astype(x.dtype) * out

        # Add bias if present
        if "bias" in self.linear:
            out = out + self.linear.bias

        return out


class DoRAEmbedding(nn.Module):
    """
    DoRA embedding layer for parameter-efficient fine-tuning.

    Applies weight decomposition to embedding layers.
    """

    @staticmethod
    def from_base(
        embedding: nn.Embedding,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Create a DoRA embedding layer from an existing embedding layer.

        Args:
            embedding: Base embedding layer to adapt.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor.

        Returns:
            DoRAEmbedding layer wrapping the base layer.
        """
        num_embeddings, dims = embedding.weight.shape

        # TODO: Support quantized embeddings in DoRA
        if isinstance(embedding, nn.QuantizedEmbedding):
            raise ValueError("DoRAEmbedding does not yet support quantization.")

        dora_embedding = DoRAEmbedding(
            num_embeddings=num_embeddings,
            dims=dims,
            r=r,
            dropout=dropout,
            scale=scale,
        )
        dora_embedding.set_embedding(embedding)
        return dora_embedding

    def fuse(self, de_quantize: bool = False):
        """
        Fuse the DoRA adapter weights back into the base embedding layer.

        Args:
            de_quantize: Unused for embeddings (no quantization support yet).

        Returns:
            Fused embedding layer.
        """
        embedding = self.embedding
        weight = embedding.weight

        # Use the same type as the embedding weight
        dtype = weight.dtype

        num_embeddings, dims = weight.shape
        fused_embedding = nn.Embedding(num_embeddings, dims)

        # Apply LoRA update
        lora_a = (self.scale * self.lora_a).astype(dtype)
        lora_b = self.lora_b.astype(dtype)
        weight = weight + lora_a @ lora_b

        # Apply magnitude scaling
        norm_scale = self.m / mx.linalg.norm(weight, axis=1)
        fused_embedding.weight = norm_scale[:, None] * weight

        return fused_embedding

    def __init__(
        self,
        num_embeddings: int,
        dims: int,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Initialize a DoRA embedding layer.

        Args:
            num_embeddings: Number of embeddings.
            dims: Embedding dimension.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor.
        """
        super().__init__()

        # Regular embedding layer weights
        self.set_embedding(nn.Embedding(num_embeddings, dims))
        self.dropout = nn.Dropout(p=dropout)

        # Scale for low-rank update
        self.scale = scale

        # Low rank LoRA weights
        scale_init = 1 / math.sqrt(num_embeddings)
        self.lora_a = mx.random.uniform(
            low=-scale_init,
            high=scale_init,
            shape=(num_embeddings, r),
        )
        self.lora_b = mx.zeros(shape=(r, dims))

    def set_embedding(self, embedding: nn.Module):
        """
        Set the base embedding layer and compute magnitude vector.

        Args:
            embedding: Base embedding layer.
        """
        self.embedding = embedding
        # Compute magnitude for each embedding
        self.m = mx.linalg.norm(embedding.weight, axis=1)

    def __call__(self, x):
        """
        Forward pass with DoRA adaptation.

        Args:
            x: Input token indices.

        Returns:
            Embedded output with DoRA adaptation.
        """
        # Standard embedding lookup
        y = self.embedding(x)

        # LoRA adaptation
        z = self.scale * self.lora_a[x] @ self.lora_b
        out = y + self.dropout(z).astype(y.dtype)

        # Compute the norm of the adapted weights for the individual embeddings
        adapted = y + z
        denom = mx.stop_gradient(mx.linalg.norm(adapted, axis=-1))

        # Apply magnitude scaling
        out = (self.m[x] / denom)[..., None] * out

        return out

    def as_linear(self, x):
        """
        Use the embedding layer as a linear layer (for language model heads).

        Args:
            x: Input tensor.

        Returns:
            Output logits.
        """
        # Standard linear transformation using embedding weights
        y = self.embedding.as_linear(x)

        # LoRA adaptation
        z = (self.dropout(x) @ self.lora_b.T) @ self.lora_a.T
        out = y + (self.scale * z).astype(x.dtype)

        # Compute the norm of the adapted weights
        adapted = self.embedding.weight + (self.scale * self.lora_a) @ self.lora_b
        denom = mx.stop_gradient(mx.linalg.norm(adapted, axis=1))

        # Apply magnitude scaling
        out = (self.m / denom) * out

        return out
