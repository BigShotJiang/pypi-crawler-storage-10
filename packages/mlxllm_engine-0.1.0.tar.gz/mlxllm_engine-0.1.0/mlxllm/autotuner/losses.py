# SPDX-License-Identifier: Apache-2.0
"""
Custom loss functions with Metal optimization for MLX-LLM.

Provides KL divergence and Jensen-Shannon divergence losses with
custom Metal kernels for efficient computation on Apple Silicon.

Based on Apple's MLX-LM implementation.
"""

import mlx.core as mx
import mlx.nn as nn


def can_run_metal():
    """Check if Metal GPU acceleration is available."""
    return mx.default_device() == mx.gpu and mx.metal.is_available()


def kl_div_loss(logits_q, logits_p):
    """
    Compute KL divergence loss between two distributions.

    Uses optimized Metal kernel when available, falls back to MLX operations otherwise.

    Args:
        logits_q: Logits from student model (query distribution).
        logits_p: Logits from teacher model (reference distribution).

    Returns:
        KL divergence loss (scalar or per-example).
    """
    if can_run_metal() and _kl_forward_kernel is not None:
        return _kl_div_loss(logits_q, logits_p)
    else:
        # Fallback to standard MLX implementation
        return nn.losses.kl_div_loss(
            logits_q - mx.logsumexp(logits_q, axis=-1, keepdims=True),
            logits_p - mx.logsumexp(logits_p, axis=-1, keepdims=True),
            axis=-1,
            reduction="none",
        )


def js_div_loss(logits_q, logits_p):
    """
    Compute Jensen-Shannon divergence loss between two distributions.

    JS divergence is the symmetric version of KL divergence:
        JS(P||Q) = 0.5 * KL(P||M) + 0.5 * KL(Q||M)
    where M = 0.5 * (P + Q)

    Args:
        logits_q: Logits from first distribution.
        logits_p: Logits from second distribution.

    Returns:
        JS divergence loss.
    """
    if can_run_metal() and _js_forward_kernel is not None:
        return _js_div_loss(logits_q, logits_p)[0]
    else:
        # Fallback implementation
        logprobs_p = logits_p - mx.logsumexp(logits_p, axis=-1, keepdims=True)
        logprobs_q = logits_q - mx.logsumexp(logits_q, axis=-1, keepdims=True)

        # Compute log of mixture distribution M
        logprobs_m = (
            logprobs_p
            + mx.log(1 + mx.exp(logprobs_q - logprobs_p))
            - mx.log(2).astype(logits_q.dtype)
        )

        # Compute KL divergences
        kl_p = nn.losses.kl_div_loss(logprobs_m, logprobs_p, axis=-1, reduction="none")
        kl_q = nn.losses.kl_div_loss(logprobs_m, logprobs_q, axis=-1, reduction="none")

        return 0.5 * (kl_p + kl_q)


# Metal kernel implementations (only available when Metal is present)
_kl_forward_kernel = None
_kl_backward_kernel = None
_js_forward_kernel = None
_js_backward_kernel = None

try:
    if can_run_metal():
        # KL divergence forward kernel
        _kl_forward_kernel = mx.fast.metal_kernel(
            name="kl_forward",
            input_names=["logits_q", "logits_p"],
            output_names=["out"],
            source="""
            // Metal kernel for efficient KL divergence computation
            // Uses parallel reduction for log-sum-exp computation

            constexpr int M = 4;
            constexpr int block = 1024 * M;
            constexpr int full_blocks = V / block;
            constexpr int extra = V - full_blocks * block;

            threadgroup float shared[32 * 2];

            uint out_idx = threadgroup_position_in_grid.y;
            uint simd_lane_id = thread_index_in_simdgroup;
            uint simd_group_id = simdgroup_index_in_threadgroup;

            logits_q += out_idx * V;
            logits_p += out_idx * V;
            out += out_idx;

            float lse_q_minus_p;
            float lse_p;

            {
                float max_q = -1e30;
                float max_p = -1e30;
                float sum_exp_q = 0;
                float sum_exp_p = 0;

                int offset = thread_index_in_threadgroup * M;
                for (int i = 0; i < full_blocks; i++) {
                    float vals_q[M];
                    float vals_p[M];
                    for (int j=0; j<M; j++) {
                        vals_q[j] = logits_q[offset + j];
                        vals_p[j] = logits_p[offset + j];
                    }
                    float prev_max_q = max_q;
                    float prev_max_p = max_p;
                    for (int j=0; j<M; j++) {
                        max_q = max(max_q, vals_q[j]);
                        max_p = max(max_p, vals_p[j]);
                    }
                    sum_exp_q *= metal::fast::exp(prev_max_q - max_q);
                    sum_exp_p *= metal::fast::exp(prev_max_p - max_p);
                    for (int j=0; j<M; j++) {
                        sum_exp_q += metal::fast::exp(vals_q[j] - max_q);
                        sum_exp_p += metal::fast::exp(vals_p[j] - max_p);
                    }
                    offset += block;
                }

                if (extra > 0) {
                    float vals_q[M];
                    float vals_p[M];
                    for (int j=0; j < M; j++) {
                        vals_q[j] = (offset + j < V) ? logits_q[offset + j] : -1e30;
                        vals_p[j] = (offset + j < V) ? logits_p[offset + j] : -1e30;
                    }
                    float prev_max_q = max_q;
                    float prev_max_p = max_p;
                    for (int j=0; j<M; j++) {
                        max_q = max(max_q, vals_q[j]);
                        max_p = max(max_p, vals_p[j]);
                    }
                    sum_exp_q *= metal::fast::exp(prev_max_q - max_q);
                    sum_exp_p *= metal::fast::exp(prev_max_p - max_p);
                    for (int j=0; j<M; j++) {
                        sum_exp_q += metal::fast::exp(vals_q[j] - max_q);
                        sum_exp_p += metal::fast::exp(vals_p[j] - max_p);
                    }
                }

                // Share the maxs across the threadgroup
                float prev_max_q = max_q;
                float prev_max_p = max_p;
                max_q = simd_max(max_q);
                max_p = simd_max(max_p);
                if (simd_lane_id == 0) {
                    shared[simd_group_id * 2 + 0] = max_q;
                    shared[simd_group_id * 2 + 1] = max_p;
                }
                threadgroup_barrier(mem_flags::mem_threadgroup);
                max_q = shared[simd_lane_id * 2 + 0];
                max_p = shared[simd_lane_id * 2 + 1];
                max_q = simd_max(max_q);
                max_p = simd_max(max_p);

                // Share the sum_exp across the threadgroup
                sum_exp_q *= metal::fast::exp(prev_max_q - max_q);
                sum_exp_p *= metal::fast::exp(prev_max_p - max_p);
                sum_exp_q = simd_sum(sum_exp_q);
                sum_exp_p = simd_sum(sum_exp_p);
                if (simd_lane_id == 0) {
                    shared[simd_group_id * 2 + 0] = sum_exp_q;
                    shared[simd_group_id * 2 + 1] = sum_exp_p;
                }
                threadgroup_barrier(mem_flags::mem_threadgroup);
                sum_exp_q = shared[simd_lane_id * 2 + 0];
                sum_exp_p = shared[simd_lane_id * 2 + 1];
                sum_exp_q = simd_sum(sum_exp_q);
                sum_exp_p = simd_sum(sum_exp_p);

                lse_p = max_p + metal::fast::log(sum_exp_p);
                lse_q_minus_p = max_q + metal::fast::log(sum_exp_q) - lse_p;
            }

            threadgroup_barrier(mem_flags::mem_none);

            {
                float kl = 0;

                int offset = thread_index_in_threadgroup * M;
                for (int i = 0; i < full_blocks; i++) {
                    float vals_q[M];
                    float vals_p[M];
                    for (int j=0; j<M; j++) {
                        vals_q[j] = logits_q[offset + j];
                        vals_p[j] = logits_p[offset + j];
                    }

                    for (int j=0; j<M; j++) {
                        kl += metal::fast::exp(vals_p[j] - lse_p) * (vals_p[j] - vals_q[j] + lse_q_minus_p);
                    }

                    offset += block;
                }
                if (extra > 0) {
                    float vals_q[M];
                    float vals_p[M];
                    for (int j=0; j<M; j++) {
                        vals_q[j] = (offset + j < V) ? logits_q[offset + j] : -1e30;
                        vals_p[j] = (offset + j < V) ? logits_p[offset + j] : -1e30;
                    }

                    for (int j=0; j<M; j++) {
                        kl += metal::fast::exp(vals_p[j] - lse_p) * (vals_p[j] - vals_q[j] + lse_q_minus_p);
                    }
                }

                // Add the kl across the threadgroup
                kl = simd_sum(kl);
                if (simd_lane_id == 0) {
                    shared[simd_group_id] = kl;
                }
                threadgroup_barrier(mem_flags::mem_none);
                kl = shared[simd_lane_id];
                kl = simd_sum(kl);

                if (thread_index_in_threadgroup == 0) {
                    out[0] = static_cast<T>(kl);
                }
            }
            """,
            ensure_row_contiguous=True,
        )

        @mx.custom_function
        def _kl_div_loss(logits_q, logits_p):
            n_outs = logits_q.size // logits_q.shape[-1]
            dt = logits_q.dtype

            return _kl_forward_kernel(
                inputs=[logits_q, logits_p],
                output_shapes=[logits_q.shape[:-1]],
                output_dtypes=[dt],
                template=[("T", dt), ("V", logits_q.shape[-1])],
                grid=(1024, n_outs, 1),
                threadgroup=(1024, 1, 1),
            )[0]

        # Placeholder for JS divergence - would use similar Metal kernel approach
        # For now, we'll rely on the fallback implementation
        def _js_div_loss(logits_q, logits_p):
            """Fallback JS divergence (Metal kernel could be added later)."""
            logprobs_p = logits_p - mx.logsumexp(logits_p, axis=-1, keepdims=True)
            logprobs_q = logits_q - mx.logsumexp(logits_q, axis=-1, keepdims=True)
            logprobs_m = (
                logprobs_p
                + mx.log(1 + mx.exp(logprobs_q - logprobs_p))
                - mx.log(mx.array(2.0)).astype(logits_q.dtype)
            )
            kl_p = nn.losses.kl_div_loss(logprobs_m, logprobs_p, axis=-1, reduction="none")
            kl_q = nn.losses.kl_div_loss(logprobs_m, logprobs_q, axis=-1, reduction="none")
            return (0.5 * (kl_p + kl_q), mx.zeros_like(kl_q))

except Exception:
    # Metal kernels not available, will use fallback
    pass
