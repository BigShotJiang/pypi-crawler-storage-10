# SPDX-License-Identifier: Apache-2.0
"""
Training callbacks for MLX-LLM fine-tuning.

Supports Weights & Biases (wandb) and SwanLab integrations for experiment tracking.
Based on Apple's MLX-LM implementation.
"""

import os

try:
    import wandb
except ImportError:
    wandb = None

try:
    import swanlab
except ImportError:
    swanlab = None


class TrainingCallback:
    """Base class for training callbacks."""

    def on_train_loss_report(self, train_info: dict):
        """
        Called to report training loss at specified intervals.

        Args:
            train_info: Dictionary containing training metrics.
        """
        pass

    def on_val_loss_report(self, val_info: dict):
        """
        Called to report validation loss at specified intervals.

        Args:
            val_info: Dictionary containing validation metrics.
        """
        pass


class WandBCallback(TrainingCallback):
    """
    Weights & Biases callback for experiment tracking.

    Logs training and validation metrics to W&B.
    """

    def __init__(
        self,
        project_name: str,
        log_dir: str,
        config: dict,
        wrapped_callback: TrainingCallback = None,
    ):
        """
        Initialize W&B callback.

        Args:
            project_name: W&B project name.
            log_dir: Directory for logs.
            config: Training configuration to log.
            wrapped_callback: Optional callback to chain.
        """
        if wandb is None:
            raise ImportError(
                "wandb is not installed. Please install wandb via: pip install wandb"
            )
        self.wrapped_callback = wrapped_callback
        wandb.init(
            project=project_name,
            name=os.path.basename(log_dir),
            dir=log_dir,
            config=config,
        )

    def _convert_to_serializable(self, data: dict) -> dict:
        """
        Convert MLX arrays to serializable format.

        Args:
            data: Dictionary potentially containing MLX arrays.

        Returns:
            Dictionary with serializable values.
        """
        return {k: v.tolist() if hasattr(v, "tolist") else v for k, v in data.items()}

    def on_train_loss_report(self, train_info: dict):
        """
        Log training metrics to W&B.

        Args:
            train_info: Training metrics dictionary.
        """
        wandb.log(
            self._convert_to_serializable(train_info), step=train_info.get("iteration")
        )
        if self.wrapped_callback:
            self.wrapped_callback.on_train_loss_report(train_info)

    def on_val_loss_report(self, val_info: dict):
        """
        Log validation metrics to W&B.

        Args:
            val_info: Validation metrics dictionary.
        """
        wandb.log(
            self._convert_to_serializable(val_info), step=val_info.get("iteration")
        )
        if self.wrapped_callback:
            self.wrapped_callback.on_val_loss_report(val_info)


class SwanLabCallback(TrainingCallback):
    """
    SwanLab callback for experiment tracking.

    Logs training and validation metrics to SwanLab.
    """

    def __init__(
        self,
        project_name: str,
        log_dir: str,
        config: dict,
        wrapped_callback: TrainingCallback = None,
    ):
        """
        Initialize SwanLab callback.

        Args:
            project_name: SwanLab project name.
            log_dir: Directory for logs.
            config: Training configuration to log.
            wrapped_callback: Optional callback to chain.
        """
        if swanlab is None:
            raise ImportError(
                "swanlab is not installed. Please install swanlab via: pip install swanlab"
            )
        self.wrapped_callback = wrapped_callback
        swanlab.init(
            project=project_name,
            experiment_name=os.path.basename(log_dir),
            logdir=os.path.join(log_dir, "swanlog"),
            config=config,
        )

    def _convert_to_serializable(self, data: dict) -> dict:
        """
        Convert MLX arrays to serializable format.

        Args:
            data: Dictionary potentially containing MLX arrays.

        Returns:
            Dictionary with serializable values.
        """
        return {k: v.tolist() if hasattr(v, "tolist") else v for k, v in data.items()}

    def on_train_loss_report(self, train_info: dict):
        """
        Log training metrics to SwanLab.

        Args:
            train_info: Training metrics dictionary.
        """
        swanlab.log(
            self._convert_to_serializable(train_info), step=train_info.get("iteration")
        )
        if self.wrapped_callback:
            self.wrapped_callback.on_train_loss_report(train_info)

    def on_val_loss_report(self, val_info: dict):
        """
        Log validation metrics to SwanLab.

        Args:
            val_info: Validation metrics dictionary.
        """
        swanlab.log(
            self._convert_to_serializable(val_info), step=val_info.get("iteration")
        )
        if self.wrapped_callback:
            self.wrapped_callback.on_val_loss_report(val_info)


SUPPORT_CALLBACK = {
    "wandb": WandBCallback,
    "swanlab": SwanLabCallback,
}


def get_reporting_callbacks(
    report_to: str = None,
    project_name: str = None,
    log_dir: str = None,
    config: dict = None,
):
    """
    Create reporting callbacks from configuration.

    Args:
        report_to: Comma-separated list of callback types (wandb, swanlab).
        project_name: Project name for tracking.
        log_dir: Directory for logs.
        config: Configuration to log.

    Returns:
        Chained callback or None if no callbacks requested.
    """
    if report_to is None or report_to == "":
        return None

    report_to = [item.strip().lower() for item in report_to.split(",") if item.strip()]
    training_callback = None

    for callback in report_to:
        try:
            training_callback = SUPPORT_CALLBACK[callback](
                project_name=project_name,
                log_dir=log_dir,
                config=config,
                wrapped_callback=training_callback,
            )
        except KeyError as e:
            raise ValueError(
                f"{callback} callback doesn't exist. "
                f"Choose from {', '.join(SUPPORT_CALLBACK.keys())}"
            ) from e

    return training_callback
