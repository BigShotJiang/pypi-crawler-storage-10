# SPDX-License-Identifier: Apache-2.0
"""
LoRA (Low-Rank Adaptation) implementation for MLX-LLM.

Based on Apple's MLX-LM implementation with adaptations for mlxllm.
"""

import math

import mlx.core as mx
import mlx.nn as nn


class LoRALinear(nn.Module):
    """
    LoRA linear layer for parameter-efficient fine-tuning.

    LoRA decomposes the weight update matrix into two low-rank matrices A and B,
    where the adapted weight is W' = W + scale * B @ A.
    """

    @staticmethod
    def from_base(
        linear: nn.Linear,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Create a LoRA linear layer from an existing linear layer.

        Args:
            linear: Base linear layer to adapt.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability for LoRA layers.
            scale: Scaling factor for the low-rank update.

        Returns:
            LoRALinear layer wrapping the base layer.
        """
        # Get dimensions from base linear layer
        output_dims, input_dims = linear.weight.shape
        if isinstance(linear, nn.QuantizedLinear):
            input_dims = input_dims * 32 // linear.bits

        lora_lin = LoRALinear(
            input_dims=input_dims,
            output_dims=output_dims,
            r=r,
            dropout=dropout,
            scale=scale,
        )
        lora_lin.linear = linear
        return lora_lin

    def fuse(self, de_quantize: bool = False):
        """
        Fuse the LoRA adapter weights back into the base linear layer.

        Args:
            de_quantize: If True, dequantize the result if the base layer was quantized.

        Returns:
            Fused linear layer with LoRA weights merged.
        """
        linear = self.linear
        bias = "bias" in linear
        weight = linear.weight
        is_quantized = isinstance(linear, nn.QuantizedLinear)

        # Use the same type as the linear weight if not quantized
        dtype = weight.dtype

        if is_quantized:
            dtype = linear.scales.dtype
            weight = mx.dequantize(
                weight,
                linear.scales,
                linear.biases,
                linear.group_size,
                linear.bits,
            )

        output_dims, input_dims = weight.shape
        fused_linear = nn.Linear(input_dims, output_dims, bias=bias)

        # Compute the low-rank update: scale * B^T @ A^T
        delta = ((self.scale * self.lora_b.T) @ self.lora_a.T).astype(dtype)
        fused_linear.weight = weight + delta

        if bias:
            fused_linear.bias = linear.bias

        if is_quantized and not de_quantize:
            fused_linear = nn.QuantizedLinear.from_linear(
                fused_linear,
                linear.group_size,
                linear.bits,
            )

        return fused_linear

    def __init__(
        self,
        input_dims: int,
        output_dims: int,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
        bias: bool = False,
    ):
        """
        Initialize a LoRA linear layer.

        Args:
            input_dims: Input dimension.
            output_dims: Output dimension.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor for the low-rank update.
            bias: Whether to include bias.
        """
        super().__init__()

        # Regular linear layer weights
        self.linear = nn.Linear(input_dims, output_dims, bias=bias)

        self.dropout = nn.Dropout(p=dropout)

        # Scale for low-rank update
        self.scale = scale

        # Low rank LoRA weights
        # A is initialized with random values from uniform distribution
        scale_init = 1 / math.sqrt(input_dims)
        self.lora_a = mx.random.uniform(
            low=-scale_init,
            high=scale_init,
            shape=(input_dims, r),
        )
        # B is initialized with zeros (common LoRA initialization)
        self.lora_b = mx.zeros(shape=(r, output_dims))

    def __call__(self, x):
        """
        Forward pass with LoRA adaptation.

        Args:
            x: Input tensor.

        Returns:
            Output tensor with LoRA adaptation applied.
        """
        # Standard linear transformation
        y = self.linear(x)

        # LoRA low-rank transformation: scale * (x @ A) @ B
        z = (self.dropout(x) @ self.lora_a) @ self.lora_b

        return y + (self.scale * z).astype(x.dtype)


class LoRAEmbedding(nn.Module):
    """
    LoRA embedding layer for parameter-efficient fine-tuning.

    Applies low-rank adaptation to embedding layers.
    """

    @staticmethod
    def from_base(
        embedding: nn.Embedding,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Create a LoRA embedding layer from an existing embedding layer.

        Args:
            embedding: Base embedding layer to adapt.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor.

        Returns:
            LoRAEmbedding layer wrapping the base layer.
        """
        num_embeddings, dims = embedding.weight.shape
        if isinstance(embedding, nn.QuantizedEmbedding):
            dims = dims * 32 // embedding.bits

        lora_embedding = LoRAEmbedding(
            num_embeddings=num_embeddings,
            dims=dims,
            r=r,
            dropout=dropout,
            scale=scale,
        )
        lora_embedding.embedding = embedding
        return lora_embedding

    def fuse(self, de_quantize: bool = False):
        """
        Fuse the LoRA adapter weights back into the base embedding layer.

        Args:
            de_quantize: If True, dequantize the result if base was quantized.

        Returns:
            Fused embedding layer.
        """
        embedding = self.embedding
        weight = embedding.weight
        is_quantized = isinstance(embedding, nn.QuantizedEmbedding)

        # Use the same type as the linear weight if not quantized
        dtype = weight.dtype

        if is_quantized:
            dtype = embedding.scales.dtype
            weight = mx.dequantize(
                weight,
                embedding.scales,
                embedding.biases,
                embedding.group_size,
                embedding.bits,
            )

        num_embeddings, dims = weight.shape
        fused_embedding = nn.Embedding(num_embeddings, dims)

        # Compute low-rank update
        lora_a = (self.scale * self.lora_a).astype(dtype)
        lora_b = self.lora_b.astype(dtype)
        fused_embedding.weight = weight + lora_a @ lora_b

        if is_quantized and not de_quantize:
            fused_embedding = nn.QuantizedEmbedding.from_embedding(
                fused_embedding,
                embedding.group_size,
                embedding.bits,
            )

        return fused_embedding

    def __init__(
        self,
        num_embeddings: int,
        dims: int,
        r: int = 8,
        dropout: float = 0.0,
        scale: float = 20.0,
    ):
        """
        Initialize a LoRA embedding layer.

        Args:
            num_embeddings: Number of embeddings.
            dims: Embedding dimension.
            r: Rank of the low-rank decomposition.
            dropout: Dropout probability.
            scale: Scaling factor.
        """
        super().__init__()

        # Regular embedding layer
        self.embedding = nn.Embedding(num_embeddings, dims)
        self.dropout = nn.Dropout(p=dropout)

        # Scale for low-rank update
        self.scale = scale

        # Low rank LoRA weights
        scale_init = 1 / math.sqrt(num_embeddings)
        self.lora_a = mx.random.uniform(
            low=-scale_init,
            high=scale_init,
            shape=(num_embeddings, r),
        )
        self.lora_b = mx.zeros(shape=(r, dims))

    def __call__(self, x):
        """
        Forward pass with LoRA adaptation.

        Args:
            x: Input token indices.

        Returns:
            Embedded output with LoRA adaptation.
        """
        # Standard embedding lookup
        y = self.embedding(x)

        # LoRA adaptation: scale * (lora_a[x] @ lora_b)
        z = self.dropout(self.lora_a[x] @ self.lora_b)
        out = y + (self.scale * z).astype(y.dtype)

        return out

    def as_linear(self, x):
        """
        Use the embedding layer as a linear layer (for language model heads).

        Args:
            x: Input tensor.

        Returns:
            Output logits.
        """
        # Standard linear transformation using embedding weights
        y = self.embedding.as_linear(x)

        # LoRA adaptation
        z = (self.dropout(x) @ self.lora_b.T) @ self.lora_a.T

        return y + (self.scale * z).astype(x.dtype)
