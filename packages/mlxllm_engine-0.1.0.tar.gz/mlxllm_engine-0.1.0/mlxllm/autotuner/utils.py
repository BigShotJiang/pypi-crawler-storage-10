# SPDX-License-Identifier: Apache-2.0
"""
Utility functions for MLX-LLM fine-tuning.

Provides model conversion, adapter loading, and training utilities.
Based on Apple's MLX-LM implementation.
"""

import json
import types
from pathlib import Path
from typing import Dict

import mlx.core as mx
import mlx.nn as nn
import mlx.optimizers as opt
from mlx.utils import tree_flatten, tree_unflatten

from .dora import DoRAEmbedding, DoRALinear
from .lora import LoRAEmbedding, LoRALinear


def build_schedule(schedule_config: Dict):
    """
    Build a learning rate schedule from the given config.

    Args:
        schedule_config: Dictionary with schedule configuration.
            Expected keys:
                - name: Schedule type (e.g., 'cosine_decay', 'step_decay')
                - arguments: List of arguments for the schedule
                - warmup: (optional) Number of warmup steps
                - warmup_init: (optional) Initial learning rate for warmup

    Returns:
        Learning rate schedule function.
    """
    schedule_fn = getattr(opt.schedulers, schedule_config["name"])
    arguments = schedule_config["arguments"]
    initial_lr = arguments[0]
    bound_schedule_fn = schedule_fn(*arguments)

    if warmup_steps := schedule_config.get("warmup", 0):
        warmup_init = schedule_config.get("warmup_init", 0.0)
        warmup_fn = opt.schedulers.linear_schedule(
            warmup_init, initial_lr, warmup_steps
        )
        return opt.schedulers.join_schedules(
            [warmup_fn, bound_schedule_fn], [warmup_steps + 1]
        )
    else:
        return bound_schedule_fn


def linear_to_lora_layers(
    model: nn.Module,
    num_layers: int,
    config: Dict,
    use_dora: bool = False,
):
    """
    Convert some of the model's linear layers to LoRA layers.

    Args:
        model: The neural network model.
        num_layers: The number of blocks to convert to LoRA layers
            starting from the last layer.
        config: More configuration parameters for LoRA, including the
            rank, scale, and optional layer keys.
        use_dora: If True, uses DoRA instead of LoRA. Default: False.
    """

    def to_lora(layer):
        """Convert a single layer to LoRA/DoRA."""
        # Check if layer has custom to_lora method
        if not use_dora and hasattr(layer, "to_lora"):
            return layer.to_lora(
                r=config["rank"],
                scale=config["scale"],
                dropout=config["dropout"],
            )

        # Determine which LoRA class to use
        if isinstance(layer, (nn.Linear, nn.QuantizedLinear)):
            LoRALayer = DoRALinear if use_dora else LoRALinear
        elif isinstance(layer, (nn.Embedding, nn.QuantizedEmbedding)):
            LoRALayer = DoRAEmbedding if use_dora else LoRAEmbedding
        else:
            raise ValueError(
                f"Can't convert layer of type {type(layer).__name__} to LoRA"
            )

        return LoRALayer.from_base(
            layer,
            r=config["rank"],
            scale=config["scale"],
            dropout=config["dropout"],
        )

    # Get keys of layers to convert
    if (keys := config.get("keys", None)) is None:
        keys = set()

        def get_keys_for_lora(p, m):
            """Collect keys of convertible layers."""
            types_to_convert = (
                nn.Linear,
                nn.QuantizedLinear,
                nn.Embedding,
                nn.QuantizedEmbedding,
            )
            if hasattr(m, "to_lora") or isinstance(m, types_to_convert):
                keys.add(p)

        # Collect keys from model layers
        if hasattr(model, "layers"):
            for layer in model.layers:
                layer.apply_to_modules(get_keys_for_lora)

    # Convert layers to LoRA, starting from the last num_layers
    if hasattr(model, "layers"):
        for layer in model.layers[-max(num_layers, 0) :]:
            lora_layers = [(k, to_lora(m)) for k, m in layer.named_modules() if k in keys]
            if lora_layers:
                layer.update_modules(tree_unflatten(lora_layers))

    # Also convert any model-level layers (e.g., embeddings, lm_head)
    lora_modules = [(k, to_lora(m)) for k, m in model.named_modules() if k in keys]
    if lora_modules:
        model.update_modules(tree_unflatten(lora_modules))


def load_adapters(model: nn.Module, adapter_path: str) -> nn.Module:
    """
    Load fine-tuned adapters/layers from disk.

    Args:
        model: The neural network model.
        adapter_path: Path to the adapter configuration file.

    Returns:
        The updated model with LoRA layers applied.
    """
    adapter_path = Path(adapter_path)
    if not adapter_path.exists():
        raise FileNotFoundError(f"The adapter path does not exist: {adapter_path}")

    with open(adapter_path / "adapter_config.json", "r") as fid:
        config = types.SimpleNamespace(**json.load(fid))

    fine_tune_type = getattr(config, "fine_tune_type", "lora")

    if fine_tune_type != "full":
        linear_to_lora_layers(
            model,
            config.num_layers,
            config.lora_parameters,
            use_dora=(fine_tune_type == "dora"),
        )

    model.load_weights(str(adapter_path / "adapters.safetensors"), strict=False)
    return model


def dequantize(model: nn.Module) -> nn.Module:
    """
    Dequantize the quantized linear layers in the model.

    Args:
        model: The model with quantized linear layers.

    Returns:
        The model with dequantized layers.
    """
    dequantize_layers = []

    for name, module in model.named_modules():
        bias = "bias" in module

        if isinstance(module, nn.QuantizedLinear):
            cls = nn.Linear
            kwargs = {"bias": bias}
        elif isinstance(module, nn.QuantizedEmbedding):
            kwargs = {}
            cls = nn.Embedding
        else:
            continue

        weight = mx.dequantize(
            module.weight,
            module.scales,
            module.biases,
            module.group_size,
            module.bits,
        )
        args = weight.shape[::-1]
        m = cls(*args, **kwargs)

        if bias:
            m.bias = module.bias
        m.weight = weight

        dequantize_layers.append((name, m))

    if len(dequantize_layers) > 0:
        model.update_modules(tree_unflatten(dequantize_layers))

    return model


def remove_lora_layers(model: nn.Module) -> nn.Module:
    """
    Remove the LoRA layers from the model, reverting to base layers.

    Args:
        model: The model with LoRA layers.

    Returns:
        The model without LoRA layers.
    """
    reset_layers = []

    for name, module in model.named_modules():
        if isinstance(module, (LoRALinear, DoRALinear)):
            reset_layers.append((name, module.linear))
        elif isinstance(module, (LoRAEmbedding, DoRAEmbedding)):
            reset_layers.append((name, module.embedding))

    if len(reset_layers) > 0:
        model.update_modules(tree_unflatten(reset_layers))

    return model


def get_total_parameters(model):
    """
    Get the total number of parameters in the model.

    Accounts for quantized layers by computing actual parameter count.

    Args:
        model: The model to count parameters for.

    Returns:
        Total number of parameters.
    """
    leaf_modules = tree_flatten(
        model.leaf_modules(), is_leaf=lambda m: isinstance(m, nn.Module)
    )

    def nparams(m):
        """Count parameters in a module."""
        if hasattr(m, "bits"):
            # Quantized layer - compute actual parameter count
            n = 0 if not hasattr(m, "bias") else m.bias.size
            return n + m.weight.size * 32 // m.bits
        return sum(v.size for _, v in tree_flatten(m.parameters()))

    return sum(nparams(m) for _, m in leaf_modules)


def print_trainable_parameters(model):
    """
    Print statistics about trainable vs total parameters.

    Args:
        model: The model to analyze.
    """
    total_p = get_total_parameters(model) / 1e6
    trainable_p = (
        sum(v.size for _, v in tree_flatten(model.trainable_parameters())) / 1e6
    )

    print(
        f"Trainable parameters: {(trainable_p * 100 / total_p):.3f}% "
        f"({trainable_p:.3f}M/{total_p:.3f}M)"
    )
