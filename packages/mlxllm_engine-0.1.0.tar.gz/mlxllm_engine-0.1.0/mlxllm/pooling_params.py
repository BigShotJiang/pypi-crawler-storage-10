# SPDX-License-Identifier: Apache-2.0
"""Pooling parameters for embedding models in MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class PoolingType(str, Enum):
    """Type of pooling operation for embeddings."""

    MEAN = "mean"
    """Mean pooling across sequence."""

    MAX = "max"
    """Max pooling across sequence."""

    CLS = "cls"
    """Use [CLS] token embedding."""

    LAST = "last"
    """Use last token embedding."""


@dataclass
class PoolingParams:
    """
    Parameters for embedding pooling.

    Used for embedding models to specify how to pool token embeddings
    into a single sequence embedding.
    """

    pooling_type: PoolingType = PoolingType.MEAN
    """Type of pooling operation."""

    normalize: bool = True
    """Normalize embeddings to unit length."""

    add_special_tokens: bool = True
    """Add special tokens (e.g., [CLS], [SEP]) when encoding."""

    truncate: bool = True
    """Truncate sequences longer than max_length."""

    max_length: int | None = None
    """Maximum sequence length. None = use model default."""

    def validate(self) -> None:
        """Validate pooling parameters."""
        if self.max_length is not None and self.max_length <= 0:
            raise ValueError(
                f"max_length must be positive, got {self.max_length}"
            )

    @classmethod
    def from_defaults(
        cls,
        pooling_type: PoolingType = PoolingType.MEAN,
        normalize: bool = True,
    ) -> PoolingParams:
        """
        Create PoolingParams with default settings.

        Args:
            pooling_type: Type of pooling.
            normalize: Whether to normalize embeddings.

        Returns:
            PoolingParams instance.
        """
        return cls(
            pooling_type=pooling_type,
            normalize=normalize,
        )

    def __repr__(self) -> str:
        """String representation of pooling params."""
        return (
            f"PoolingParams(type={self.pooling_type.value}, "
            f"normalize={self.normalize})"
        )
