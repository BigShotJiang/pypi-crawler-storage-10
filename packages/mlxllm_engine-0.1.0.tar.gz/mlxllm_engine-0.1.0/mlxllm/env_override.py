# SPDX-License-Identifier: Apache-2.0
"""Runtime environment overrides for MLX-LLM.

This module allows programmatic override of environment variables at runtime,
useful for testing and dynamic configuration.
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Iterator


class EnvironmentOverride:
    """Manager for environment variable overrides."""

    def __init__(self):
        """Initialize environment override manager."""
        self._overrides: dict[str, str] = {}
        self._original_values: dict[str, str | None] = {}

    def set(self, name: str, value: Any) -> None:
        """
        Set an environment variable override.

        Args:
            name: Environment variable name.
            value: Value to set (will be converted to string).
        """
        # Store original value if not already stored
        if name not in self._original_values:
            self._original_values[name] = os.getenv(name)

        # Set override
        str_value = str(value)
        self._overrides[name] = str_value
        os.environ[name] = str_value

    def unset(self, name: str) -> None:
        """
        Remove an environment variable override.

        Args:
            name: Environment variable name.
        """
        if name in self._overrides:
            del self._overrides[name]

        # Restore original value
        if name in self._original_values:
            original = self._original_values[name]
            if original is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = original
            del self._original_values[name]

    def reset(self) -> None:
        """Reset all overrides to original values."""
        for name in list(self._overrides.keys()):
            self.unset(name)

    def get_overrides(self) -> dict[str, str]:
        """Get all active overrides."""
        return self._overrides.copy()


# Global environment override manager
_global_override = EnvironmentOverride()


def set_env_override(name: str, value: Any) -> None:
    """
    Set a global environment variable override.

    Args:
        name: Environment variable name.
        value: Value to set.
    """
    _global_override.set(name, value)


def unset_env_override(name: str) -> None:
    """
    Remove a global environment variable override.

    Args:
        name: Environment variable name.
    """
    _global_override.unset(name)


def reset_all_overrides() -> None:
    """Reset all global environment variable overrides."""
    _global_override.reset()


@contextmanager
def temporary_env_override(**kwargs: Any) -> Iterator[None]:
    """
    Context manager for temporary environment variable overrides.

    Args:
        **kwargs: Environment variables to override.

    Example:
        >>> with temporary_env_override(MLXLLM_LOG_LEVEL="DEBUG"):
        ...     # MLXLLM_LOG_LEVEL is "DEBUG" here
        ...     pass
        >>> # MLXLLM_LOG_LEVEL is restored here
    """
    override = EnvironmentOverride()

    try:
        # Set overrides
        for name, value in kwargs.items():
            override.set(name, value)

        yield

    finally:
        # Reset all overrides
        override.reset()
