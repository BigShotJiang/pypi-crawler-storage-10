# SPDX-License-Identifier: Apache-2.0
"""Logits processing and warping for MLX-LLM.

This module provides logits processors that modify the model's output distribution
before sampling. Processors can apply temperature scaling, top-p/top-k filtering,
repetition penalties, and other transformations.
"""

from __future__ import annotations

from typing import Protocol

import mlx.core as mx


class LogitsProcessor(Protocol):
    """Protocol for logits processors."""

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """
        Process logits before sampling.

        Args:
            input_ids: Previous token IDs (batch_size, seq_len).
            logits: Raw logits from model (batch_size, vocab_size).

        Returns:
            Processed logits (batch_size, vocab_size).
        """
        ...


class TemperatureLogitsProcessor:
    """Apply temperature scaling to logits."""

    def __init__(self, temperature: float = 1.0):
        """
        Initialize temperature processor.

        Args:
            temperature: Sampling temperature. Higher = more random.
        """
        if temperature <= 0:
            raise ValueError(f"temperature must be positive, got {temperature}")
        self.temperature = temperature

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply temperature scaling."""
        if self.temperature == 1.0:
            return logits
        return logits / self.temperature


class TopKLogitsProcessor:
    """Keep only top-k logits, set others to -inf."""

    def __init__(self, top_k: int):
        """
        Initialize top-k processor.

        Args:
            top_k: Number of top tokens to keep.
        """
        if top_k <= 0:
            raise ValueError(f"top_k must be positive, got {top_k}")
        self.top_k = top_k

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Filter to top-k logits."""
        # Get top-k values and indices
        top_k = min(self.top_k, logits.shape[-1])

        # Get the k-th largest value for each batch
        top_k_values = mx.topk(logits, k=top_k, axis=-1)[0]
        threshold = top_k_values[..., -1:]  # (batch_size, 1)

        # Mask out values below threshold
        mask = logits < threshold
        logits = mx.where(mask, mx.array(-float("inf")), logits)

        return logits


class TopPLogitsProcessor:
    """Nucleus sampling: keep smallest set of tokens with cumulative prob >= top_p."""

    def __init__(self, top_p: float, min_tokens_to_keep: int = 1):
        """
        Initialize top-p processor.

        Args:
            top_p: Cumulative probability threshold (0.0 to 1.0).
            min_tokens_to_keep: Always keep at least this many tokens.
        """
        if not 0 <= top_p <= 1:
            raise ValueError(f"top_p must be in [0, 1], got {top_p}")
        self.top_p = top_p
        self.min_tokens_to_keep = min_tokens_to_keep

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply nucleus sampling filter."""
        if self.top_p >= 1.0:
            return logits

        # Sort logits in descending order
        sorted_indices = mx.argsort(logits, axis=-1)[:, ::-1]
        sorted_logits = mx.take_along_axis(logits, sorted_indices, axis=-1)

        # Convert to probabilities
        sorted_probs = mx.softmax(sorted_logits, axis=-1)

        # Calculate cumulative probabilities
        cumulative_probs = mx.cumsum(sorted_probs, axis=-1)

        # Find tokens to remove (cumulative prob > top_p)
        # Keep at least min_tokens_to_keep
        sorted_indices_to_remove = cumulative_probs > self.top_p

        # Shift right to keep first token above threshold
        sorted_indices_to_remove = mx.concatenate([
            mx.zeros_like(sorted_indices_to_remove[:, :1]),
            sorted_indices_to_remove[:, :-1]
        ], axis=-1)

        # Always keep min_tokens_to_keep
        if self.min_tokens_to_keep > 1:
            sorted_indices_to_remove[:, :self.min_tokens_to_keep] = False

        # Scatter back to original order
        indices_to_remove = mx.zeros_like(logits, dtype=mx.bool_)
        batch_size, vocab_size = logits.shape

        for i in range(batch_size):
            indices_to_remove[i, sorted_indices[i]] = sorted_indices_to_remove[i]

        logits = mx.where(indices_to_remove, mx.array(-float("inf")), logits)

        return logits


class RepetitionPenaltyLogitsProcessor:
    """Apply penalty to tokens that have already appeared."""

    def __init__(self, penalty: float = 1.0):
        """
        Initialize repetition penalty processor.

        Args:
            penalty: Penalty factor. >1.0 penalizes, <1.0 encourages repetition.
        """
        if penalty <= 0:
            raise ValueError(f"penalty must be positive, got {penalty}")
        self.penalty = penalty

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply repetition penalty."""
        if self.penalty == 1.0:
            return logits

        batch_size, vocab_size = logits.shape

        # For each batch, penalize tokens that appeared in input
        for i in range(batch_size):
            unique_tokens = mx.unique(input_ids[i])

            # Apply penalty: divide positive logits, multiply negative logits
            for token in unique_tokens:
                if token < vocab_size:
                    score = logits[i, token]
                    logits[i, token] = score / self.penalty if score > 0 else score * self.penalty

        return logits


class FrequencyPenaltyLogitsProcessor:
    """Apply penalty based on token frequency in the generated sequence."""

    def __init__(self, penalty: float = 0.0):
        """
        Initialize frequency penalty processor.

        Args:
            penalty: Penalty strength. Positive values penalize frequent tokens.
        """
        self.penalty = penalty

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply frequency-based penalty."""
        if self.penalty == 0.0:
            return logits

        batch_size, vocab_size = logits.shape

        # Count token frequencies
        for i in range(batch_size):
            unique_tokens, counts = mx.unique(input_ids[i], return_counts=True)

            # Apply penalty proportional to frequency
            for token, count in zip(unique_tokens, counts):
                if token < vocab_size:
                    logits[i, token] -= float(count) * self.penalty

        return logits


class PresencePenaltyLogitsProcessor:
    """Apply fixed penalty to tokens that have appeared (regardless of frequency)."""

    def __init__(self, penalty: float = 0.0):
        """
        Initialize presence penalty processor.

        Args:
            penalty: Penalty strength. Positive values penalize any appearance.
        """
        self.penalty = penalty

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply presence penalty."""
        if self.penalty == 0.0:
            return logits

        batch_size, vocab_size = logits.shape

        # Apply fixed penalty to any token that appeared
        for i in range(batch_size):
            unique_tokens = mx.unique(input_ids[i])

            for token in unique_tokens:
                if token < vocab_size:
                    logits[i, token] -= self.penalty

        return logits


class MinTokensLogitsProcessor:
    """Prevent EOS token until minimum tokens are generated."""

    def __init__(self, min_tokens: int, eos_token_id: int):
        """
        Initialize min tokens processor.

        Args:
            min_tokens: Minimum number of tokens to generate.
            eos_token_id: Token ID for end-of-sequence.
        """
        self.min_tokens = min_tokens
        self.eos_token_id = eos_token_id

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Block EOS if min tokens not reached."""
        seq_len = input_ids.shape[1]

        if seq_len < self.min_tokens:
            # Set EOS logit to -inf
            logits[:, self.eos_token_id] = -float("inf")

        return logits


class LogitBiasLogitsProcessor:
    """Apply fixed bias to specific tokens."""

    def __init__(self, logit_bias: dict[int, float]):
        """
        Initialize logit bias processor.

        Args:
            logit_bias: Dictionary mapping token IDs to bias values.
        """
        self.logit_bias = logit_bias

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply logit biases."""
        if not self.logit_bias:
            return logits

        vocab_size = logits.shape[-1]

        for token_id, bias in self.logit_bias.items():
            if 0 <= token_id < vocab_size:
                logits[:, token_id] += bias

        return logits


class LogitsProcessorList:
    """Container for multiple logits processors applied in sequence."""

    def __init__(self, processors: list[LogitsProcessor] | None = None):
        """
        Initialize processor list.

        Args:
            processors: List of logits processors to apply.
        """
        self.processors = processors or []

    def __call__(
        self,
        input_ids: mx.array,
        logits: mx.array,
    ) -> mx.array:
        """Apply all processors in sequence."""
        for processor in self.processors:
            logits = processor(input_ids, logits)
        return logits

    def append(self, processor: LogitsProcessor) -> None:
        """Add a processor to the list."""
        self.processors.append(processor)

    def __len__(self) -> int:
        """Get number of processors."""
        return len(self.processors)

    def __iter__(self):
        """Iterate over processors."""
        return iter(self.processors)


def create_logits_processor_list(
    temperature: float = 1.0,
    top_k: int = -1,
    top_p: float = 1.0,
    repetition_penalty: float = 1.0,
    frequency_penalty: float = 0.0,
    presence_penalty: float = 0.0,
    min_tokens: int = 0,
    eos_token_id: int | None = None,
    logit_bias: dict[int, float] | None = None,
) -> LogitsProcessorList:
    """
    Create a LogitsProcessorList from sampling parameters.

    Args:
        temperature: Sampling temperature.
        top_k: Top-k filtering (-1 to disable).
        top_p: Nucleus sampling threshold (1.0 to disable).
        repetition_penalty: Repetition penalty factor.
        frequency_penalty: Frequency-based penalty.
        presence_penalty: Presence-based penalty.
        min_tokens: Minimum tokens before allowing EOS.
        eos_token_id: End-of-sequence token ID.
        logit_bias: Token-specific biases.

    Returns:
        LogitsProcessorList with configured processors.
    """
    processors = LogitsProcessorList()

    # Apply penalties first
    if repetition_penalty != 1.0:
        processors.append(RepetitionPenaltyLogitsProcessor(repetition_penalty))

    if frequency_penalty != 0.0:
        processors.append(FrequencyPenaltyLogitsProcessor(frequency_penalty))

    if presence_penalty != 0.0:
        processors.append(PresencePenaltyLogitsProcessor(presence_penalty))

    # Apply logit bias
    if logit_bias:
        processors.append(LogitBiasLogitsProcessor(logit_bias))

    # Apply min tokens constraint
    if min_tokens > 0 and eos_token_id is not None:
        processors.append(MinTokensLogitsProcessor(min_tokens, eos_token_id))

    # Apply filtering (order matters: top_k before top_p)
    if top_k > 0:
        processors.append(TopKLogitsProcessor(top_k))

    if top_p < 1.0:
        processors.append(TopPLogitsProcessor(top_p))

    # Apply temperature last (after filtering)
    if temperature != 1.0:
        processors.append(TemperatureLogitsProcessor(temperature))

    return processors
