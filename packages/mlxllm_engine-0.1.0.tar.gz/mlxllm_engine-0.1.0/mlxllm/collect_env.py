# SPDX-License-Identifier: Apache-2.0
"""Collect environment information for debugging MLX-LLM.

This module collects system, hardware, and software information useful for
debugging and issue reporting.
"""

from __future__ import annotations

import platform
import sys
from typing import Any

import mlx.core as mx


def collect_system_info() -> dict[str, Any]:
    """
    Collect system information.

    Returns:
        Dictionary with system information.
    """
    return {
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": sys.version,
        "python_implementation": platform.python_implementation(),
    }


def collect_mlx_info() -> dict[str, Any]:
    """
    Collect MLX/Metal information.

    Returns:
        Dictionary with MLX information.
    """
    info: dict[str, Any] = {
        "mlx_version": mx.__version__,
    }

    try:
        # Metal device info
        info["metal_available"] = hasattr(mx, "metal")

        if hasattr(mx, "metal"):
            info["active_memory_mb"] = mx.metal.get_active_memory() / (1024 * 1024)
            info["peak_memory_mb"] = mx.metal.get_peak_memory() / (1024 * 1024)
            info["cache_memory_mb"] = mx.metal.get_cache_memory() / (1024 * 1024)

    except Exception as e:
        info["metal_error"] = str(e)

    return info


def collect_env_vars() -> dict[str, str]:
    """
    Collect MLX-LLM environment variables.

    Returns:
        Dictionary of environment variables.
    """
    import os

    mlxllm_vars = {}
    for key, value in os.environ.items():
        if key.startswith("MLXLLM_"):
            mlxllm_vars[key] = value

    return mlxllm_vars


def collect_all_info() -> dict[str, Any]:
    """
    Collect all environment information.

    Returns:
        Dictionary with complete environment info.
    """
    return {
        "system": collect_system_info(),
        "mlx": collect_mlx_info(),
        "environment_variables": collect_env_vars(),
    }


def print_env_info() -> None:
    """Print all environment information in a readable format."""
    info = collect_all_info()

    print("=" * 60)
    print("MLX-LLM Environment Information")
    print("=" * 60)

    print("\n[System Information]")
    for key, value in info["system"].items():
        print(f"  {key}: {value}")

    print("\n[MLX Information]")
    for key, value in info["mlx"].items():
        print(f"  {key}: {value}")

    print("\n[Environment Variables]")
    if info["environment_variables"]:
        for key, value in info["environment_variables"].items():
            print(f"  {key}: {value}")
    else:
        print("  (none set)")

    print("=" * 60)


if __name__ == "__main__":
    print_env_info()
