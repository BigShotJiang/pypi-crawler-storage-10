# SPDX-License-Identifier: Apache-2.0
"""Tokenizer wrapper for MLX-LLM.

This module provides a unified tokenizer interface that wraps HuggingFace tokenizers
for use with MLX-LLM. It handles:
- Loading tokenizers from HuggingFace Hub or local paths
- Chat template application
- Special token handling
- Padding and truncation
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from transformers import AutoTokenizer

if TYPE_CHECKING:
    from transformers import PreTrainedTokenizerBase

logger = logging.getLogger(__name__)


class Tokenizer:
    """
    Unified tokenizer interface for MLX-LLM.

    Wraps HuggingFace tokenizers with MLX-LLM specific functionality.
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
    ) -> None:
        """
        Initialize tokenizer wrapper.

        Args:
            tokenizer: HuggingFace tokenizer instance.
        """
        self.tokenizer = tokenizer

        # Cache commonly used attributes
        self.vocab_size = len(tokenizer)
        self.bos_token_id = tokenizer.bos_token_id
        self.eos_token_id = tokenizer.eos_token_id
        self.pad_token_id = tokenizer.pad_token_id or tokenizer.eos_token_id

    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str | Path,
        **kwargs: Any,
    ) -> Tokenizer:
        """
        Load tokenizer from HuggingFace Hub or local path.

        Args:
            model_name_or_path: Model identifier or path to tokenizer.
            **kwargs: Additional arguments passed to AutoTokenizer.from_pretrained.

        Returns:
            Tokenizer instance.
        """
        logger.info(f"Loading tokenizer from {model_name_or_path}")

        # Set reasonable defaults
        kwargs.setdefault("trust_remote_code", True)
        kwargs.setdefault("use_fast", True)

        tokenizer = AutoTokenizer.from_pretrained(
            str(model_name_or_path),
            **kwargs,
        )

        return cls(tokenizer)

    def encode(
        self,
        text: str,
        add_special_tokens: bool = True,
    ) -> list[int]:
        """
        Encode text to token IDs.

        Args:
            text: Input text.
            add_special_tokens: Whether to add special tokens (BOS/EOS).

        Returns:
            List of token IDs.
        """
        return self.tokenizer.encode(
            text,
            add_special_tokens=add_special_tokens,
        )

    def decode(
        self,
        token_ids: list[int],
        skip_special_tokens: bool = True,
    ) -> str:
        """
        Decode token IDs to text.

        Args:
            token_ids: List of token IDs.
            skip_special_tokens: Whether to skip special tokens in output.

        Returns:
            Decoded text.
        """
        return self.tokenizer.decode(
            token_ids,
            skip_special_tokens=skip_special_tokens,
            clean_up_tokenization_spaces=True,
        )

    def apply_chat_template(
        self,
        messages: list[dict[str, str]],
        add_generation_prompt: bool = True,
    ) -> str:
        """
        Apply chat template to conversation messages.

        Args:
            messages: List of message dicts with "role" and "content" keys.
            add_generation_prompt: Whether to add generation prompt at end.

        Returns:
            Formatted chat prompt string.
        """
        if not hasattr(self.tokenizer, "chat_template") or self.tokenizer.chat_template is None:
            # Fallback for tokenizers without chat template
            logger.warning("Tokenizer has no chat template, using simple concatenation")
            return self._simple_chat_format(messages)

        return self.tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=add_generation_prompt,
            tokenize=False,
        )

    def _simple_chat_format(self, messages: list[dict[str, str]]) -> str:
        """
        Simple chat formatting fallback.

        Args:
            messages: List of message dicts.

        Returns:
            Formatted string.
        """
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            parts.append(f"{role}: {content}")

        return "\n".join(parts)

    def get_token_id(self, token: str) -> int | None:
        """
        Get token ID for a specific token string.

        Args:
            token: Token string.

        Returns:
            Token ID or None if not found.
        """
        return self.tokenizer.convert_tokens_to_ids(token)

    def __len__(self) -> int:
        """Get vocabulary size."""
        return self.vocab_size


class BatchTokenizer:
    """
    Batch tokenizer for efficient tokenization of multiple inputs.
    """

    def __init__(
        self,
        tokenizer: Tokenizer,
        max_length: int | None = None,
        padding: bool = True,
    ) -> None:
        """
        Initialize batch tokenizer.

        Args:
            tokenizer: Base tokenizer instance.
            max_length: Maximum sequence length (None for no limit).
            padding: Whether to pad sequences to same length.
        """
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.padding = padding

    def encode_batch(
        self,
        texts: list[str],
        add_special_tokens: bool = True,
    ) -> list[list[int]]:
        """
        Encode multiple texts to token IDs.

        Args:
            texts: List of input texts.
            add_special_tokens: Whether to add special tokens.

        Returns:
            List of token ID lists.
        """
        # Use HuggingFace batch encoding
        encoded = self.tokenizer.tokenizer(
            texts,
            add_special_tokens=add_special_tokens,
            padding=self.padding,
            max_length=self.max_length,
            truncation=self.max_length is not None,
            return_tensors=None,  # Return lists, not tensors
        )

        return encoded["input_ids"]

    def decode_batch(
        self,
        token_id_lists: list[list[int]],
        skip_special_tokens: bool = True,
    ) -> list[str]:
        """
        Decode multiple token ID sequences.

        Args:
            token_id_lists: List of token ID lists.
            skip_special_tokens: Whether to skip special tokens.

        Returns:
            List of decoded texts.
        """
        return [
            self.tokenizer.decode(token_ids, skip_special_tokens)
            for token_ids in token_id_lists
        ]
