"""
Central Operations Registry for MLX-LLM C++ Extensions.

This module provides a unified namespace for accessing all csrc operations,
making it easy to import commonly-used operations without needing to know
the specific submodule structure.

Example:
    >>> from mlxllm.csrc_ops import paged_attention_v1, moe_topk_softmax
    >>> from mlxllm.csrc_ops import get_metal_device_info
    >>>
    >>> # Check what's available
    >>> from mlxllm.csrc_ops import get_availability
    >>> availability = get_availability()
    >>> print(f"Attention available: {availability['attention']}")
"""

from typing import Dict
import warnings

# Try to import from each submodule
_available_modules = {}

# Attention operations
try:
    from csrc.attention import (
        paged_attention_v1,
        paged_attention_v2,
        reshape_and_cache,
        copy_blocks,
        swap_blocks,
        rotary_embedding,
        rms_norm,
        fused_add_rms_norm,
        silu_and_mul,
        gelu_and_mul,
        gelu_tanh_and_mul,
        is_available as attention_available,
    )
    _available_modules['attention'] = True
    _ATTENTION_OPS = [
        'paged_attention_v1', 'paged_attention_v2',
        'reshape_and_cache', 'copy_blocks', 'swap_blocks',
        'rotary_embedding',
        'rms_norm', 'fused_add_rms_norm',
        'silu_and_mul', 'gelu_and_mul', 'gelu_tanh_and_mul',
    ]
except ImportError as e:
    _available_modules['attention'] = False
    warnings.warn(f"Attention operations not available: {e}", ImportWarning)
    _ATTENTION_OPS = []

# MoE operations
try:
    from csrc.moe import (
        moe_topk_softmax,
        moe_grouped_topk,
        moe_permute,
        moe_unpermute,
        moe_align_block_size,
        moe_sum,
        moe_wna16_gemm,
        is_available as moe_available,
    )
    _available_modules['moe'] = True
    _MOE_OPS = [
        'moe_topk_softmax', 'moe_grouped_topk',
        'moe_permute', 'moe_unpermute',
        'moe_align_block_size', 'moe_sum',
        'moe_wna16_gemm',
    ]
except ImportError as e:
    _available_modules['moe'] = False
    warnings.warn(f"MoE operations not available: {e}", ImportWarning)
    _MOE_OPS = []

# All2All operations
try:
    from csrc.all2all import (
        All2AllCoordinator,
        IntranodeAll2All,
        is_available as all2all_available,
    )
    _available_modules['all2all'] = True
    _ALL2ALL_OPS = ['All2AllCoordinator', 'IntranodeAll2All']
except ImportError as e:
    _available_modules['all2all'] = False
    warnings.warn(f"All2All operations not available: {e}", ImportWarning)
    _ALL2ALL_OPS = []

# Core utilities
try:
    from csrc.core import (
        get_metal_device_info,
        is_metal_available,
        get_available_memory,
        check_tensor_valid,
        next_power_of_2,
        is_power_of_2,
        ceil_div,
        align_to,
        is_available as core_available,
    )
    _available_modules['core'] = True
    _CORE_OPS = [
        'get_metal_device_info', 'is_metal_available', 'get_available_memory',
        'check_tensor_valid',
        'next_power_of_2', 'is_power_of_2', 'ceil_div', 'align_to',
    ]
except ImportError as e:
    _available_modules['core'] = False
    warnings.warn(f"Core utilities not available: {e}", ImportWarning)
    _CORE_OPS = []

# CPU fallback operations
try:
    from csrc.cpu import (
        is_cpu_tensor,
        ensure_cpu,
        is_dnnl_available,
        is_available as cpu_available,
    )
    _available_modules['cpu'] = True
    _CPU_OPS = ['is_cpu_tensor', 'ensure_cpu', 'is_dnnl_available']
except ImportError as e:
    _available_modules['cpu'] = False
    warnings.warn(f"CPU operations not available: {e}", ImportWarning)
    _CPU_OPS = []

# Mamba SSM operations
try:
    from csrc.mamba.mamba_ssm import (
        selective_scan_fwd,
        is_selective_scan_supported,
        is_available as mamba_available,
    )
    _available_modules['mamba'] = True
    _MAMBA_OPS = ['selective_scan_fwd', 'is_selective_scan_supported']
except ImportError as e:
    _available_modules['mamba'] = False
    warnings.warn(f"Mamba SSM operations not available: {e}", ImportWarning)
    _MAMBA_OPS = []


def get_availability() -> Dict[str, bool]:
    """
    Get availability status of all operation categories.

    Returns:
        Dictionary mapping operation category to availability status

    Example:
        >>> from mlxllm.csrc_ops import get_availability
        >>> availability = get_availability()
        >>> if availability['attention']:
        ...     print("Attention operations are available")
    """
    return _available_modules.copy()


def get_available_operations() -> Dict[str, list]:
    """
    Get list of available operations for each category.

    Returns:
        Dictionary mapping category to list of available operation names

    Example:
        >>> from mlxllm.csrc_ops import get_available_operations
        >>> ops = get_available_operations()
        >>> print(f"Available attention ops: {ops['attention']}")
    """
    return {
        'attention': _ATTENTION_OPS if _available_modules.get('attention') else [],
        'moe': _MOE_OPS if _available_modules.get('moe') else [],
        'all2all': _ALL2ALL_OPS if _available_modules.get('all2all') else [],
        'core': _CORE_OPS if _available_modules.get('core') else [],
        'cpu': _CPU_OPS if _available_modules.get('cpu') else [],
        'mamba': _MAMBA_OPS if _available_modules.get('mamba') else [],
    }


def is_any_available() -> bool:
    """
    Check if any csrc operations are available.

    Returns:
        True if at least one operation category is available
    """
    return any(_available_modules.values())


def is_all_available() -> bool:
    """
    Check if all csrc operations are available.

    Returns:
        True if all operation categories are available
    """
    return all(_available_modules.values())


def print_availability_report():
    """
    Print a formatted report of operation availability.

    Example:
        >>> from mlxllm.csrc_ops import print_availability_report
        >>> print_availability_report()
        MLX-LLM C++ Operations Availability Report
        ==========================================
        ✓ Attention operations: Available
        ✓ MoE operations: Available
        ...
    """
    print("MLX-LLM C++ Operations Availability Report")
    print("=" * 50)

    for category, available in _available_modules.items():
        status = "✓ Available" if available else "✗ Not available"
        ops_count = len(get_available_operations()[category])
        print(f"{status:20s} {category:15s} ({ops_count} operations)")

    print("=" * 50)
    total_available = sum(1 for v in _available_modules.values() if v)
    total_categories = len(_available_modules)
    print(f"Total: {total_available}/{total_categories} categories available")


# Build __all__ dynamically based on what's available
__all__ = [
    'get_availability',
    'get_available_operations',
    'is_any_available',
    'is_all_available',
    'print_availability_report',
] + _ATTENTION_OPS + _MOE_OPS + _ALL2ALL_OPS + _CORE_OPS + _CPU_OPS + _MAMBA_OPS

__version__ = "0.1.0"
