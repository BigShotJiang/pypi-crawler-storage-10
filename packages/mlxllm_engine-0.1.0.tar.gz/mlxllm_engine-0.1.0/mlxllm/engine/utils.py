# SPDX-License-Identifier: Apache-2.0
"""Utility functions for MLX-LLM engine."""

from __future__ import annotations

import time
import uuid
from typing import Any


def generate_request_id() -> str:
    """
    Generate a unique request ID.

    Returns:
        Unique request ID string.
    """
    return f"req_{uuid.uuid4().hex[:12]}"


def get_timestamp() -> float:
    """
    Get current timestamp in seconds.

    Returns:
        Current time in seconds since epoch.
    """
    return time.time()


def format_bytes(num_bytes: int) -> str:
    """
    Format bytes into human-readable string.

    Args:
        num_bytes: Number of bytes.

    Returns:
        Formatted string (e.g., "1.5 GB").
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.2f} PB"


def compute_memory_usage(
    num_params: int,
    dtype_bytes: int = 2,
    overhead_factor: float = 1.2,
) -> int:
    """
    Compute estimated memory usage for a model.

    Args:
        num_params: Number of model parameters.
        dtype_bytes: Bytes per parameter (2 for fp16/bf16, 4 for fp32).
        overhead_factor: Overhead factor for activations, etc.

    Returns:
        Estimated memory in bytes.
    """
    return int(num_params * dtype_bytes * overhead_factor)


def merge_dicts(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """
    Merge two dictionaries, with override taking precedence.

    Args:
        base: Base dictionary.
        override: Override dictionary.

    Returns:
        Merged dictionary.
    """
    result = base.copy()
    result.update(override)
    return result


def chunk_list(lst: list[Any], chunk_size: int) -> list[list[Any]]:
    """
    Split list into chunks of specified size.

    Args:
        lst: List to chunk.
        chunk_size: Size of each chunk.

    Returns:
        List of chunks.
    """
    return [lst[i : i + chunk_size] for i in range(0, len(lst), chunk_size)]


def calculate_num_blocks(
    seq_len: int,
    block_size: int,
) -> int:
    """
    Calculate number of blocks needed for sequence.

    Args:
        seq_len: Sequence length in tokens.
        block_size: Block size in tokens.

    Returns:
        Number of blocks needed.
    """
    return (seq_len + block_size - 1) // block_size


def is_power_of_2(n: int) -> bool:
    """
    Check if number is a power of 2.

    Args:
        n: Number to check.

    Returns:
        True if power of 2, False otherwise.
    """
    return n > 0 and (n & (n - 1)) == 0


def next_power_of_2(n: int) -> int:
    """
    Get next power of 2 >= n.

    Args:
        n: Input number.

    Returns:
        Next power of 2.
    """
    if n <= 0:
        return 1

    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    n |= n >> 32
    return n + 1
