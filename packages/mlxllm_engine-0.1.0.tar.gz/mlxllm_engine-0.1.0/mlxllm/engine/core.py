# SPDX-License-Identifier: Apache-2.0
"""Engine core implementation for MLX-LLM.

This module implements the main inference engine that coordinates:
- Request scheduling
- KV cache management
- Model execution
- Output generation
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import mlx.core as mx

from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.core.sched.scheduler import Scheduler
from mlxllm.engine.exceptions import EngineException
from mlxllm.outputs import CompletionOutput, RequestOutput
from mlxllm.sequence import Sequence, SequenceGroup, SequenceStatus

if TYPE_CHECKING:
    from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
    from mlxllm.core.sched.output import SchedulerOutput
    from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


@dataclass
class EngineStats:
    """Statistics for the engine."""

    num_requests_total: int = 0
    num_requests_running: int = 0
    num_requests_waiting: int = 0
    num_requests_swapped: int = 0
    num_tokens_generated: int = 0
    cache_utilization: float = 0.0
    throughput_tokens_per_sec: float = 0.0


class EngineCore:
    """
    Core inference engine for MLX-LLM.

    Coordinates:
    - Request lifecycle management
    - Scheduling via V1 Scheduler
    - KV cache management
    - Model execution
    - Output generation

    This is the main orchestrator for the inference pipeline.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        cache_config: CacheConfig,
        scheduler_config: SchedulerConfig,
        model: Any = None,
    ) -> None:
        """
        Initialize engine core.

        Args:
            model_config: Model configuration.
            cache_config: Cache configuration.
            scheduler_config: Scheduler configuration.
            model: Pre-loaded model (optional).
        """
        self.model_config = model_config
        self.cache_config = cache_config
        self.scheduler_config = scheduler_config

        # Initialize KV cache manager
        num_layers = getattr(model_config, 'num_layers', None) or getattr(model_config, 'num_hidden_layers', 32)
        num_kv_heads = getattr(model_config, 'num_kv_heads', None) or getattr(model_config, 'num_key_value_heads', model_config.num_attention_heads)
        self.kv_cache = KVCacheManager(
            num_blocks=cache_config.num_gpu_blocks,
            block_size=cache_config.block_size,
            num_layers=num_layers,
            num_kv_heads=num_kv_heads,
            head_dim=model_config.hidden_size // model_config.num_attention_heads,
            dtype=mx.float16,
        )

        # Initialize scheduler
        self.scheduler = Scheduler(
            scheduler_config=scheduler_config,
            cache_config=cache_config,
            kv_cache_manager=self.kv_cache,
        )

        # Model (to be set externally or loaded)
        self.model = model

        # Request tracking
        self.requests: dict[str, SequenceGroup] = {}

        # Statistics
        self.stats = EngineStats()
        self._last_stats_time = time.time()
        self._tokens_since_last_stats = 0

        logger.info("EngineCore initialized")

    def add_request(
        self,
        request_id: str,
        prompt: str,
        prompt_token_ids: list[int],
        sampling_params: SamplingParams,
        arrival_time: float | None = None,
    ) -> None:
        """
        Add a new generation request.

        Args:
            request_id: Unique request ID.
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            arrival_time: Request arrival timestamp.
        """
        if request_id in self.requests:
            raise EngineException(f"Request {request_id} already exists")

        # Create sequence
        seq = Sequence(
            seq_id=0,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            block_table=None,
        )

        # Create sequence group
        seq_group = SequenceGroup(
            request_id=request_id,
            sequences=[seq],
            sampling_params=sampling_params,
            arrival_time=arrival_time or time.time(),
        )

        # Track request
        self.requests[request_id] = seq_group

        # Add to scheduler
        self.scheduler.add_request(seq_group)

        # Update stats
        self.stats.num_requests_total += 1

        logger.debug(f"Added request {request_id} with {len(prompt_token_ids)} tokens")

    def abort_request(self, request_id: str) -> None:
        """
        Abort a request.

        Args:
            request_id: ID of request to abort.
        """
        if request_id not in self.requests:
            logger.warning(f"Request {request_id} not found for abort")
            return

        # Remove from scheduler
        self.scheduler.abort_request(request_id)

        # Remove from tracking
        del self.requests[request_id]

        logger.debug(f"Aborted request {request_id}")

    def step(self) -> list[RequestOutput]:
        """
        Execute one inference step.

        Returns:
            List of request outputs for this step.
        """
        # Schedule requests
        scheduler_output = self.scheduler.schedule()

        # Execute if we have work
        outputs: list[RequestOutput] = []
        if scheduler_output.scheduled_groups:
            outputs = self._execute_model(scheduler_output)

        # Free finished requests
        self.scheduler.free_finished_requests()

        # Update statistics
        self._update_stats(len(outputs))

        return outputs

    def _execute_model(self, scheduler_output: SchedulerOutput) -> list[RequestOutput]:
        """
        Execute the model for scheduled requests.

        Args:
            scheduler_output: Scheduled groups from scheduler.

        Returns:
            List of request outputs.
        """
        if self.model is None:
            raise EngineException("Model not loaded")

        outputs: list[RequestOutput] = []

        # Process each scheduled group
        for scheduled_group in scheduler_output.scheduled_groups:
            seq_group = scheduled_group.seq_group
            is_prefill = scheduled_group.is_prefill
            chunk_size = scheduled_group.token_chunk_size

            # Get input tokens
            if is_prefill:
                # Prefill: use prompt tokens (or chunk)
                seq = seq_group.sequences[0]
                input_tokens = seq.prompt_token_ids[:chunk_size]
            else:
                # Decode: use last generated token
                input_tokens = []
                for seq in seq_group.sequences:
                    if seq.output_token_ids:
                        input_tokens.append(seq.output_token_ids[-1])
                    else:
                        # First decode step after prefill
                        input_tokens.append(seq.prompt_token_ids[-1])

            # Prepare input
            input_ids = mx.array(input_tokens, dtype=mx.int32)
            if input_ids.ndim == 1:
                input_ids = mx.expand_dims(input_ids, axis=0)

            # Forward pass (simplified - real implementation would use attention metadata)
            try:
                logits = self.model(input_ids)

                # Sample next token(s)
                next_tokens = self._sample(logits, seq_group.sampling_params)

                # Update sequences
                for i, seq in enumerate(seq_group.sequences):
                    if seq.status == SequenceStatus.RUNNING:
                        token_id = int(next_tokens[i] if len(next_tokens) > i else next_tokens[0])
                        seq.output_token_ids.append(token_id)

                        # Check if finished
                        if self._is_finished(seq, seq_group.sampling_params):
                            seq.status = SequenceStatus.FINISHED

                # Create output
                output = self._create_output(seq_group)
                outputs.append(output)

            except Exception as e:
                logger.error(f"Error executing model for {seq_group.request_id}: {e}")
                # Mark as failed
                for seq in seq_group.sequences:
                    seq.status = SequenceStatus.FINISHED

        return outputs

    def _sample(
        self,
        logits: mx.array,
        sampling_params: SamplingParams,
    ) -> mx.array:
        """
        Sample next tokens from logits.

        Args:
            logits: Model logits [batch, vocab_size].
            sampling_params: Sampling parameters.

        Returns:
            Sampled token IDs.
        """
        # Get last token logits
        if logits.ndim == 3:
            logits = logits[:, -1, :]

        # Apply temperature
        if sampling_params.temperature > 0:
            logits = logits / sampling_params.temperature

        # Top-p (nucleus) sampling
        if sampling_params.top_p < 1.0:
            # Sort logits
            sorted_indices = mx.argsort(logits, axis=-1)[:, ::-1]
            sorted_logits = mx.take_along_axis(logits, sorted_indices, axis=-1)

            # Compute cumulative probabilities
            probs = mx.softmax(sorted_logits, axis=-1)
            # cumulative_probs = mx.cumsum(probs, axis=-1)

            # Find cutoff
            # For simplicity, using greedy for now
            # TODO: Implement proper top-p sampling with cumulative probability filtering
            pass

        # Top-k sampling
        if sampling_params.top_k > 0:
            # Get top-k values
            top_k = min(sampling_params.top_k, logits.shape[-1])
            top_k_logits, top_k_indices = mx.topk(logits, k=top_k, axis=-1)

            # For simplicity, take argmax of top-k
            # TODO: Implement proper top-k sampling
            logits = top_k_logits

        # Greedy sampling (temperature == 0) or argmax
        if sampling_params.temperature == 0:
            next_tokens = mx.argmax(logits, axis=-1)
        else:
            # Sample from distribution
            probs = mx.softmax(logits, axis=-1)
            # For now, use argmax (TODO: implement proper sampling)
            next_tokens = mx.argmax(probs, axis=-1)

        return next_tokens

    def _is_finished(
        self,
        seq: Sequence,
        sampling_params: SamplingParams,
    ) -> bool:
        """
        Check if a sequence is finished.

        Args:
            seq: Sequence to check.
            sampling_params: Sampling parameters.

        Returns:
            True if sequence is finished.
        """
        # Check max tokens
        if sampling_params.max_tokens is not None:
            if len(seq.output_token_ids) >= sampling_params.max_tokens:
                return True

        # Check EOS token
        if seq.output_token_ids and seq.output_token_ids[-1] in sampling_params.stop_token_ids:
            return True

        return False

    def _create_output(self, seq_group: SequenceGroup) -> RequestOutput:
        """
        Create request output.

        Args:
            seq_group: Sequence group.

        Returns:
            Request output.
        """
        # Get first sequence (simplified - beam search would have multiple)
        seq = seq_group.sequences[0]

        # Create completion output
        completion = CompletionOutput(
            index=0,
            text="",  # Will be filled by detokenizer
            token_ids=seq.output_token_ids,
            cumulative_logprob=0.0,  # TODO: track logprobs
            logprobs=None,
            finish_reason="stop" if seq.status == SequenceStatus.FINISHED else None,
        )

        return RequestOutput(
            request_id=seq_group.request_id,
            prompt=seq.prompt,
            prompt_token_ids=seq.prompt_token_ids,
            outputs=[completion],
            finished=seq.status == SequenceStatus.FINISHED,
        )

    def _update_stats(self, num_outputs: int) -> None:
        """
        Update engine statistics.

        Args:
            num_outputs: Number of outputs generated this step.
        """
        # Update token count
        self._tokens_since_last_stats += num_outputs

        # Update running counts
        self.stats.num_requests_running = len(self.scheduler.running)
        self.stats.num_requests_waiting = len(self.scheduler.waiting)
        self.stats.num_requests_swapped = len(self.scheduler.swapped)

        # Update cache utilization
        free_blocks = self.kv_cache.get_num_free_blocks()
        total_blocks = self.kv_cache.num_blocks
        self.stats.cache_utilization = 1.0 - (free_blocks / total_blocks) if total_blocks > 0 else 0.0

        # Update throughput (every second)
        now = time.time()
        elapsed = now - self._last_stats_time
        if elapsed >= 1.0:
            self.stats.throughput_tokens_per_sec = self._tokens_since_last_stats / elapsed
            self._tokens_since_last_stats = 0
            self._last_stats_time = now

    def get_stats(self) -> EngineStats:
        """
        Get engine statistics.

        Returns:
            Current engine statistics.
        """
        return self.stats

    def has_unfinished_requests(self) -> bool:
        """
        Check if there are unfinished requests.

        Returns:
            True if there are pending requests.
        """
        return self.scheduler.get_num_unfinished_requests() > 0

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"EngineCore("
            f"model={self.model_config.model_name}, "
            f"requests={len(self.requests)}, "
            f"running={self.stats.num_requests_running}, "
            f"waiting={self.stats.num_requests_waiting})"
        )
