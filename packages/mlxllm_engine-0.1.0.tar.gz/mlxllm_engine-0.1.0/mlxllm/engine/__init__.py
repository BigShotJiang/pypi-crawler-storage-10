# SPDX-License-Identifier: Apache-2.0
"""Engine components for MLX-LLM."""

from mlxllm.engine.arg_utils import AsyncEngineArgs, EngineArgs
from mlxllm.engine.exceptions import (
    AttentionError,
    ConfigurationError,
    DeviceError,
    EngineError,
    InvalidRequestError,
    KVCacheError,
    MetalError,
    MLXLLMError,
    ModelLoadError,
    OutOfMemoryError,
    QuantizationError,
    RequestAbortedError,
    SchedulingError,
    TimeoutError,
    TokenizationError,
)
from mlxllm.engine.protocol import (
    AbortRequest,
    EmbedRequest,
    EmbedResponse,
    EngineRequest,
    EngineResponse,
    GenerateRequest,
    GenerateResponse,
    MetricsRequest,
    MetricsResponse,
    RequestType,
)
from mlxllm.engine.utils import (
    calculate_num_blocks,
    chunk_list,
    compute_memory_usage,
    format_bytes,
    generate_request_id,
    get_timestamp,
    is_power_of_2,
    merge_dicts,
    next_power_of_2,
)

__all__ = [
    # Engine args
    "AsyncEngineArgs",
    "EngineArgs",
    # Exceptions
    "AttentionError",
    "ConfigurationError",
    "DeviceError",
    "EngineError",
    "InvalidRequestError",
    "KVCacheError",
    "MetalError",
    "MLXLLMError",
    "ModelLoadError",
    "OutOfMemoryError",
    "QuantizationError",
    "RequestAbortedError",
    "SchedulingError",
    "TimeoutError",
    "TokenizationError",
    # Protocol
    "AbortRequest",
    "EmbedRequest",
    "EmbedResponse",
    "EngineRequest",
    "EngineResponse",
    "GenerateRequest",
    "GenerateResponse",
    "MetricsRequest",
    "MetricsResponse",
    "RequestType",
    # Utils
    "calculate_num_blocks",
    "chunk_list",
    "compute_memory_usage",
    "format_bytes",
    "generate_request_id",
    "get_timestamp",
    "is_power_of_2",
    "merge_dicts",
    "next_power_of_2",
]
