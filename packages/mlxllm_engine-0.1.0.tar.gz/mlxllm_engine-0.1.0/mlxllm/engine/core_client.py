# SPDX-License-Identifier: Apache-2.0
"""Client for communicating with EngineCore.

This module provides a client interface for remote communication
with the EngineCore, useful for distributed setups or process isolation.

For single-process M4 setup, this can be simplified.
"""

from __future__ import annotations

import logging
import uuid
from collections.abc import AsyncIterator, Iterator
from typing import TYPE_CHECKING

from mlxllm.engine.protocol import (
    AbortRequest,
    GenerateRequest,
    MetricsRequest,
)

if TYPE_CHECKING:
    from mlxllm.engine.core import EngineCore
    from mlxllm.outputs import RequestOutput
    from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


class EngineCoreClient:
    """
    Client for communicating with EngineCore.

    Provides a simplified interface for:
    - Submitting generation requests
    - Aborting requests
    - Retrieving metrics
    """

    def __init__(
        self,
        engine_core: EngineCore,
    ) -> None:
        """
        Initialize engine core client.

        Args:
            engine_core: EngineCore instance.
        """
        self.engine = engine_core

    def generate(
        self,
        prompt: str,
        prompt_token_ids: list[int],
        sampling_params: SamplingParams,
        request_id: str | None = None,
    ) -> Iterator[RequestOutput]:
        """
        Generate completion for a prompt.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Optional request ID (auto-generated if None).

        Yields:
            RequestOutput objects as generation progresses.
        """
        # Generate request ID if needed
        if request_id is None:
            request_id = str(uuid.uuid4())

        # Add request to engine
        self.engine.add_request(
            request_id=request_id,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
        )

        # Yield outputs as they become available
        while True:
            # Step the engine
            outputs = self.engine.step()

            # Find our request's output
            for output in outputs:
                if output.request_id == request_id:
                    yield output

                    # Stop if finished
                    if output.finished:
                        return

            # Check if request is still active
            if not self.engine.has_unfinished_requests():
                break

    def abort(self, request_id: str) -> None:
        """
        Abort a request.

        Args:
            request_id: ID of request to abort.
        """
        self.engine.abort_request(request_id)

    def get_metrics(self) -> dict:
        """
        Get engine metrics.

        Returns:
            Metrics dictionary.
        """
        stats = self.engine.get_stats()
        return {
            "num_requests_total": stats.num_requests_total,
            "num_requests_running": stats.num_requests_running,
            "num_requests_waiting": stats.num_requests_waiting,
            "num_requests_swapped": stats.num_requests_swapped,
            "cache_utilization": stats.cache_utilization,
            "throughput_tokens_per_sec": stats.throughput_tokens_per_sec,
        }


class AsyncEngineCoreClient:
    """
    Async client for communicating with EngineCore.

    Provides async interface for non-blocking operation.
    """

    def __init__(
        self,
        engine_core: EngineCore,
    ) -> None:
        """
        Initialize async engine core client.

        Args:
            engine_core: EngineCore instance.
        """
        self.engine = engine_core

    async def generate(
        self,
        prompt: str,
        prompt_token_ids: list[int],
        sampling_params: SamplingParams,
        request_id: str | None = None,
    ) -> AsyncIterator[RequestOutput]:
        """
        Generate completion asynchronously.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Optional request ID.

        Yields:
            RequestOutput objects as generation progresses.
        """
        # Generate request ID if needed
        if request_id is None:
            request_id = str(uuid.uuid4())

        # Add request to engine
        self.engine.add_request(
            request_id=request_id,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
        )

        # Yield outputs as they become available
        while True:
            # Step the engine (would be async in real implementation)
            outputs = self.engine.step()

            # Find our request's output
            for output in outputs:
                if output.request_id == request_id:
                    yield output

                    # Stop if finished
                    if output.finished:
                        return

            # Check if request is still active
            if not self.engine.has_unfinished_requests():
                break

    async def abort(self, request_id: str) -> None:
        """
        Abort a request asynchronously.

        Args:
            request_id: ID of request to abort.
        """
        self.engine.abort_request(request_id)

    async def get_metrics(self) -> dict:
        """
        Get engine metrics asynchronously.

        Returns:
            Metrics dictionary.
        """
        stats = self.engine.get_stats()
        return {
            "num_requests_total": stats.num_requests_total,
            "num_requests_running": stats.num_requests_running,
            "num_requests_waiting": stats.num_requests_waiting,
            "num_requests_swapped": stats.num_requests_swapped,
            "cache_utilization": stats.cache_utilization,
            "throughput_tokens_per_sec": stats.throughput_tokens_per_sec,
        }


class RemoteEngineCoreClient:
    """
    Remote client for communicating with EngineCore over network.

    Uses ZMQ or similar for inter-process communication.
    Useful for distributed setups or process isolation.
    """

    def __init__(
        self,
        address: str,
        port: int = 5555,
    ) -> None:
        """
        Initialize remote engine core client.

        Args:
            address: Server address.
            port: Server port.
        """
        self.address = address
        self.port = port
        self.endpoint = f"tcp://{address}:{port}"

        logger.info(f"RemoteEngineCoreClient connecting to {self.endpoint}")

        # TODO: Initialize ZMQ or gRPC connection

    def generate(
        self,
        prompt: str,
        prompt_token_ids: list[int],
        sampling_params: SamplingParams,
        request_id: str | None = None,
    ) -> Iterator[RequestOutput]:
        """
        Generate completion remotely.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Optional request ID.

        Yields:
            RequestOutput objects.
        """
        # Generate request ID
        if request_id is None:
            request_id = str(uuid.uuid4())

        # Create request
        _request = GenerateRequest(
            request_id=request_id,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
        )

        # TODO: Send _request over network and stream responses
        logger.warning("RemoteEngineCoreClient.generate not fully implemented")
        raise NotImplementedError("Remote generation not yet implemented")

    def abort(self, request_id: str) -> None:
        """
        Abort a remote request.

        Args:
            request_id: ID of request to abort.
        """
        _request = AbortRequest(request_id=request_id)

        # TODO: Send _request over network
        logger.warning("RemoteEngineCoreClient.abort not fully implemented")

    def get_metrics(self) -> dict:
        """
        Get remote engine metrics.

        Returns:
            Metrics dictionary.
        """
        _request = MetricsRequest()

        # TODO: Send _request over network and receive response
        logger.warning("RemoteEngineCoreClient.get_metrics not fully implemented")
        return {}
