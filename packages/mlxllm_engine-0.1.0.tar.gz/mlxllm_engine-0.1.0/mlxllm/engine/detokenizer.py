# SPDX-License-Identifier: Apache-2.0
"""Incremental detokenization for MLX-LLM.

This module implements efficient incremental detokenization that:
- Handles streaming text generation
- Properly handles byte-level tokenizers (UTF-8 boundaries)
- Avoids re-decoding entire sequences
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from transformers import PreTrainedTokenizerBase

logger = logging.getLogger(__name__)


class Detokenizer:
    """
    Incremental detokenizer for streaming text generation.

    Efficiently converts token IDs to text incrementally, handling:
    - UTF-8 byte boundaries
    - Special tokens
    - Streaming updates
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
    ) -> None:
        """
        Initialize detokenizer.

        Args:
            tokenizer: HuggingFace tokenizer instance.
        """
        self.tokenizer = tokenizer

        # Track decoded state per request
        self._decoded_cache: dict[str, DecodedState] = {}

    def decode_incremental(
        self,
        request_id: str,
        token_ids: list[int],
    ) -> str:
        """
        Decode tokens incrementally.

        Args:
            request_id: Unique request ID.
            token_ids: Complete list of token IDs so far.

        Returns:
            Newly decoded text (delta from last call).
        """
        # Get or create state
        if request_id not in self._decoded_cache:
            self._decoded_cache[request_id] = DecodedState()

        state = self._decoded_cache[request_id]

        # Check if we've already decoded these tokens
        if len(token_ids) <= state.num_decoded_tokens:
            return ""

        # Get new tokens
        new_tokens = token_ids[state.num_decoded_tokens :]

        # Decode new tokens
        try:
            # Decode with skip_special_tokens for cleaner output
            new_text = self.tokenizer.decode(
                new_tokens,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=True,
            )

            # Handle byte-level tokenizers (e.g., GPT-2, Llama)
            # These may produce partial UTF-8 sequences
            if hasattr(self.tokenizer, "byte_decoder"):
                # Check if we have incomplete UTF-8
                if self._is_incomplete_utf8(new_text):
                    # Wait for more tokens
                    return ""

            # Update state
            delta_text = new_text[len(state.decoded_text) :] if state.decoded_text else new_text
            state.decoded_text = new_text
            state.num_decoded_tokens = len(token_ids)

            return delta_text

        except Exception as e:
            logger.warning(f"Error decoding tokens for {request_id}: {e}")
            # Fall back to simple decode
            try:
                new_text = self.tokenizer.decode(new_tokens)
                state.num_decoded_tokens = len(token_ids)
                return new_text
            except Exception:
                return ""

    def decode_complete(
        self,
        request_id: str,
        token_ids: list[int],
    ) -> str:
        """
        Decode complete sequence.

        Args:
            request_id: Unique request ID.
            token_ids: Complete token ID sequence.

        Returns:
            Full decoded text.
        """
        try:
            text = self.tokenizer.decode(
                token_ids,
                skip_special_tokens=True,
                clean_up_tokenization_spaces=True,
            )
            return text
        except Exception as e:
            logger.error(f"Error decoding complete sequence for {request_id}: {e}")
            return ""

    def reset(self, request_id: str) -> None:
        """
        Reset decoding state for a request.

        Args:
            request_id: Request ID to reset.
        """
        if request_id in self._decoded_cache:
            del self._decoded_cache[request_id]

    def _is_incomplete_utf8(self, text: str) -> bool:
        """
        Check if text ends with incomplete UTF-8 sequence.

        Args:
            text: Text to check.

        Returns:
            True if incomplete UTF-8 at end.
        """
        if not text:
            return False

        # Try to encode and decode - incomplete UTF-8 will fail
        try:
            text.encode("utf-8")
            return False
        except UnicodeEncodeError:
            return True


class DecodedState:
    """State for incremental decoding."""

    def __init__(self) -> None:
        """Initialize state."""
        self.num_decoded_tokens: int = 0
        self.decoded_text: str = ""


class BatchedDetokenizer:
    """
    Batched detokenizer for multiple requests.

    Efficiently handles detokenization for many concurrent requests.
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
    ) -> None:
        """
        Initialize batched detokenizer.

        Args:
            tokenizer: HuggingFace tokenizer instance.
        """
        self.detokenizer = Detokenizer(tokenizer)

    def decode_batch(
        self,
        request_ids: list[str],
        token_id_lists: list[list[int]],
        incremental: bool = True,
    ) -> list[str]:
        """
        Decode a batch of token sequences.

        Args:
            request_ids: List of request IDs.
            token_id_lists: List of token ID lists.
            incremental: Whether to do incremental decoding.

        Returns:
            List of decoded texts (deltas if incremental).
        """
        results = []

        for request_id, token_ids in zip(request_ids, token_id_lists, strict=True):
            if incremental:
                text = self.detokenizer.decode_incremental(request_id, token_ids)
            else:
                text = self.detokenizer.decode_complete(request_id, token_ids)

            results.append(text)

        return results

    def reset_batch(self, request_ids: list[str]) -> None:
        """
        Reset state for multiple requests.

        Args:
            request_ids: Request IDs to reset.
        """
        for request_id in request_ids:
            self.detokenizer.reset(request_id)
