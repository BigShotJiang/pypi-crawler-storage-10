# SPDX-License-Identifier: Apache-2.0
"""Log probability computation and sampling for MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    from mlxllm.sampling_params import SamplingParams


@dataclass
class LogprobsData:
    """
    Container for log probability data.

    This stores both the selected token's logprob and top-k alternative logprobs
    for analysis and debugging.
    """

    token_id: int
    """The selected token ID."""

    logprob: float
    """Log probability of the selected token."""

    rank: int | None = None
    """Rank of the selected token in the probability distribution (0 = most probable)."""

    top_logprobs: dict[int, float] | None = None
    """Top-k alternative token log probabilities. {token_id: logprob}."""

    decoded_token: str | None = None
    """Decoded string representation of the token."""


def compute_logprobs(
    logits: mx.array,
    token_ids: mx.array | list[int],
    num_logprobs: int | None = None,
) -> list[LogprobsData]:
    """
    Compute log probabilities for selected tokens.

    Args:
        logits: Raw logits from model [batch_size, vocab_size] or [vocab_size].
        token_ids: Selected token IDs [batch_size] or single int.
        num_logprobs: Number of top log probabilities to return per token.
                      If None, only returns the selected token's logprob.

    Returns:
        List of LogprobsData, one per token.
    """
    # Ensure logits is 2D
    if logits.ndim == 1:
        logits = mx.expand_dims(logits, axis=0)
        is_single = True
    else:
        is_single = False

    # Ensure token_ids is a list
    if isinstance(token_ids, int):
        token_ids = [token_ids]
    elif isinstance(token_ids, mx.array):
        token_ids = token_ids.tolist()

    batch_size, vocab_size = logits.shape

    # Compute log probabilities (log softmax)
    log_probs = mx.log_softmax(logits, axis=-1)

    results = []

    for i, token_id in enumerate(token_ids):
        # Get logprob for selected token
        token_logprob = float(log_probs[i, token_id])

        logprob_data = LogprobsData(
            token_id=token_id,
            logprob=token_logprob,
        )

        # Compute top-k if requested
        if num_logprobs is not None and num_logprobs > 0:
            # Get top-k indices and values
            k = min(num_logprobs, vocab_size)
            top_indices = mx.argpartition(-log_probs[i], k)[:k]
            top_log_probs_vals = log_probs[i][top_indices]

            # Sort by logprob (descending)
            sorted_indices = mx.argsort(-top_log_probs_vals)
            sorted_top_indices = top_indices[sorted_indices]
            sorted_top_log_probs = top_log_probs_vals[sorted_indices]

            # Convert to dict
            top_logprobs_dict = {
                int(idx): float(lp)
                for idx, lp in zip(sorted_top_indices.tolist(), sorted_top_log_probs.tolist())
            }

            logprob_data.top_logprobs = top_logprobs_dict

            # Compute rank of selected token
            rank = 0
            for idx, lp in top_logprobs_dict.items():
                if idx == token_id:
                    break
                if lp > token_logprob:
                    rank += 1
            logprob_data.rank = rank

        results.append(logprob_data)

    return results[0] if is_single else results


def sample_with_logprobs(
    logits: mx.array,
    sampling_params: SamplingParams,
    return_logprobs: bool = False,
) -> tuple[mx.array, list[LogprobsData] | None]:
    """
    Sample tokens from logits and optionally compute log probabilities.

    Args:
        logits: Model logits [batch_size, vocab_size] or [vocab_size].
        sampling_params: Sampling configuration (temperature, top_p, top_k).
        return_logprobs: Whether to return log probability data.

    Returns:
        Tuple of (sampled_token_ids, logprobs_data).
        If return_logprobs is False, logprobs_data is None.
    """
    from mlxllm.model_executor.layers.logits_processor import apply_logits_processors

    # Apply temperature and logits processors
    processed_logits = apply_logits_processors(logits, sampling_params)

    # Sample from distribution
    if sampling_params.temperature == 0.0:
        # Greedy sampling
        sampled_ids = mx.argmax(processed_logits, axis=-1)
    else:
        # Stochastic sampling
        probs = mx.softmax(processed_logits, axis=-1)
        sampled_ids = mx.random.categorical(mx.log(probs), axis=-1)

    # Compute logprobs if requested
    logprobs_data = None
    if return_logprobs:
        num_logprobs = sampling_params.logprobs
        logprobs_data = compute_logprobs(
            logits=logits,
            token_ids=sampled_ids,
            num_logprobs=num_logprobs,
        )

    return sampled_ids, logprobs_data


def compute_prompt_logprobs(
    logits_sequence: list[mx.array],
    token_ids_sequence: list[int],
    num_logprobs: int | None = None,
) -> list[LogprobsData]:
    """
    Compute log probabilities for a sequence of prompt tokens.

    This is used to provide logprobs for the input prompt tokens,
    useful for understanding model confidence on the input.

    Args:
        logits_sequence: List of logits arrays, one per position [vocab_size].
        token_ids_sequence: List of token IDs corresponding to each position.
        num_logprobs: Number of top log probabilities to return per token.

    Returns:
        List of LogprobsData, one per prompt token.
    """
    if len(logits_sequence) != len(token_ids_sequence):
        raise ValueError(
            f"Length mismatch: {len(logits_sequence)} logits vs "
            f"{len(token_ids_sequence)} tokens"
        )

    results = []
    for logits, token_id in zip(logits_sequence, token_ids_sequence):
        logprob_data = compute_logprobs(
            logits=logits,
            token_ids=token_id,
            num_logprobs=num_logprobs,
        )
        # compute_logprobs returns a single item for single token
        if isinstance(logprob_data, list):
            logprob_data = logprob_data[0]
        results.append(logprob_data)

    return results


def format_logprobs_for_output(
    logprobs_data: list[LogprobsData] | None,
) -> list[dict[int, float]] | None:
    """
    Format LogprobsData into the output format expected by the API.

    Args:
        logprobs_data: List of LogprobsData objects.

    Returns:
        List of dicts mapping token_id to logprob, or None if input is None.
    """
    if logprobs_data is None:
        return None

    result = []
    for data in logprobs_data:
        if data.top_logprobs is not None:
            result.append(data.top_logprobs)
        else:
            # Only include the selected token
            result.append({data.token_id: data.logprob})

    return result


def add_token_to_logprobs(
    existing_logprobs: list[dict[int, float]] | None,
    new_logprob_data: LogprobsData,
) -> list[dict[int, float]]:
    """
    Append a new token's log probabilities to existing sequence.

    Args:
        existing_logprobs: Existing logprobs list (may be None).
        new_logprob_data: New token's logprob data to append.

    Returns:
        Updated logprobs list.
    """
    if existing_logprobs is None:
        existing_logprobs = []

    if new_logprob_data.top_logprobs is not None:
        existing_logprobs.append(new_logprob_data.top_logprobs)
    else:
        existing_logprobs.append({
            new_logprob_data.token_id: new_logprob_data.logprob
        })

    return existing_logprobs


def get_cumulative_logprob(
    logprobs: list[dict[int, float]] | None,
    token_ids: list[int] | None = None,
) -> float:
    """
    Compute cumulative log probability from a sequence.

    Args:
        logprobs: List of logprob dicts.
        token_ids: Optional list of token IDs to verify alignment.

    Returns:
        Sum of log probabilities.
    """
    if logprobs is None:
        return 0.0

    cumulative = 0.0
    for i, logprob_dict in enumerate(logprobs):
        if token_ids is not None and i < len(token_ids):
            # Use the specific token's logprob
            token_id = token_ids[i]
            if token_id in logprob_dict:
                cumulative += logprob_dict[token_id]
        else:
            # Use the first (highest) logprob
            if logprob_dict:
                cumulative += next(iter(logprob_dict.values()))

    return cumulative


def normalize_logprobs(
    logits: mx.array,
    temperature: float = 1.0,
) -> mx.array:
    """
    Normalize logits to log probabilities with optional temperature scaling.

    Args:
        logits: Raw logits [batch_size, vocab_size] or [vocab_size].
        temperature: Temperature for scaling (default 1.0).

    Returns:
        Log probabilities (log softmax of scaled logits).
    """
    if temperature != 1.0 and temperature > 0:
        logits = logits / temperature

    return mx.log_softmax(logits, axis=-1)


def get_top_k_logprobs(
    log_probs: mx.array,
    k: int,
) -> tuple[mx.array, mx.array]:
    """
    Get top-k log probabilities and their indices.

    Args:
        log_probs: Log probabilities [batch_size, vocab_size] or [vocab_size].
        k: Number of top items to return.

    Returns:
        Tuple of (top_k_indices, top_k_log_probs).
    """
    if log_probs.ndim == 1:
        log_probs = mx.expand_dims(log_probs, axis=0)

    batch_size, vocab_size = log_probs.shape
    k = min(k, vocab_size)

    # Use argpartition for efficiency (O(n) instead of O(n log n))
    top_k_indices = mx.argpartition(-log_probs, k, axis=-1)[:, :k]

    # Gather the actual log_probs
    batch_indices = mx.arange(batch_size)[:, None]
    top_k_log_probs = log_probs[batch_indices, top_k_indices]

    # Sort within top-k (descending)
    sorted_indices = mx.argsort(-top_k_log_probs, axis=-1)

    # Reorder based on sorted indices
    top_k_indices = mx.take_along_axis(top_k_indices, sorted_indices, axis=-1)
    top_k_log_probs = mx.take_along_axis(top_k_log_probs, sorted_indices, axis=-1)

    return top_k_indices, top_k_log_probs
