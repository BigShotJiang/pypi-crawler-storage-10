# SPDX-License-Identifier: Apache-2.0
"""Argument parsing and validation utilities for MLX-LLM engine."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mlxllm.config import (
    CacheConfig,
    DeviceConfig,
    MLXConfig,
    ModelConfig,
    SchedulerConfig,
)


@dataclass
class EngineArgs:
    """Arguments for creating an LLM engine."""

    # Model configuration
    model: str
    """Model name or path."""

    quantization: str = "q4_0"
    """Quantization type: 'none', 'q4_0', 'q4_1', 'q8_0'."""

    dtype: str = "bfloat16"
    """Data type: 'float16', 'bfloat16', 'float32', 'auto'."""

    trust_remote_code: bool = False
    """Trust remote code when loading model."""

    revision: str | None = None
    """Model revision (git branch/tag)."""

    # Context and generation
    max_model_len: int = 8192
    """Maximum context length."""

    max_num_seqs: int = 256
    """Maximum number of sequences in a batch."""

    max_num_batched_tokens: int | None = None
    """Maximum tokens in a batch. None = auto."""

    # KV cache
    block_size: int = 16
    """KV cache block size."""

    num_gpu_blocks: int | None = None
    """Number of GPU KV cache blocks. None = auto."""

    num_cpu_blocks: int | None = None
    """Number of CPU KV cache blocks. None = disabled."""

    enable_prefix_caching: bool = True
    """Enable prefix caching."""

    enable_chunked_prefill: bool = True
    """Enable chunked prefill."""

    # Device
    device: str = "auto"
    """Device type: 'auto', 'metal'."""

    max_memory_gb: float | None = None
    """Maximum memory to use in GB. None = auto."""

    memory_fraction: float = 0.7
    """Fraction of memory to use."""

    # MLX optimizations
    enable_zero_copy: bool = True
    """Enable zero-copy unified memory."""

    enable_metal_cache: bool = True
    """Enable Metal kernel caching."""

    use_flash_attention: bool = True
    """Use MLX flash attention."""

    # Scheduling
    scheduling_policy: str = "fcfs"
    """Scheduling policy: 'fcfs', 'priority', 'sjf'."""

    preemption_mode: str = "swap"
    """Preemption mode: 'recompute', 'swap', 'none'."""

    # Advanced
    seed: int | None = None
    """Random seed."""

    disable_log_stats: bool = False
    """Disable logging statistics."""

    def __post_init__(self) -> None:
        """Validate arguments."""
        if self.max_model_len <= 0:
            raise ValueError(
                f"max_model_len must be positive, got {self.max_model_len}"
            )

        if self.max_num_seqs <= 0:
            raise ValueError(
                f"max_num_seqs must be positive, got {self.max_num_seqs}"
            )

        if self.block_size <= 0 or (self.block_size & (self.block_size - 1)) != 0:
            raise ValueError(
                f"block_size must be a power of 2, got {self.block_size}"
            )

        if self.memory_fraction <= 0 or self.memory_fraction > 1:
            raise ValueError(
                f"memory_fraction must be in (0, 1], got {self.memory_fraction}"
            )

    def create_model_config(self) -> ModelConfig:
        """Create ModelConfig from engine args."""
        from mlxllm.config import DType, QuantizationType

        return ModelConfig(
            model_name=self.model,
            quantization=QuantizationType(self.quantization),
            dtype=DType(self.dtype),
            max_model_len=self.max_model_len,
            max_num_seqs=self.max_num_seqs,
            max_num_batched_tokens=self.max_num_batched_tokens,
            trust_remote_code=self.trust_remote_code,
            revision=self.revision,
        )

    def create_device_config(self) -> DeviceConfig:
        """Create DeviceConfig from engine args."""
        return DeviceConfig.from_auto_detect(
            max_memory_gb=self.max_memory_gb,
            memory_fraction=self.memory_fraction,
        )

    def create_cache_config(self) -> CacheConfig:
        """Create CacheConfig from engine args."""
        from mlxllm.config import CacheType, KVCacheConfig

        kv_cache = KVCacheConfig(
            block_size=self.block_size,
            num_gpu_blocks=self.num_gpu_blocks,
            num_cpu_blocks=self.num_cpu_blocks,
            cache_type=CacheType.PAGED,
            enable_prefix_caching=self.enable_prefix_caching,
            enable_chunked_prefill=self.enable_chunked_prefill,
        )

        return CacheConfig(kv_cache=kv_cache)

    def create_scheduler_config(self) -> SchedulerConfig:
        """Create SchedulerConfig from engine args."""
        from mlxllm.config import PreemptionMode, SchedulingPolicy

        return SchedulerConfig(
            max_num_seqs=self.max_num_seqs,
            max_num_batched_tokens=self.max_num_batched_tokens,
            policy=SchedulingPolicy(self.scheduling_policy),
            preemption_mode=PreemptionMode(self.preemption_mode),
            enable_prefix_caching=self.enable_prefix_caching,
            enable_chunked_prefill=self.enable_chunked_prefill,
        )

    def create_mlx_config(self) -> MLXConfig:
        """Create MLXConfig from engine args."""
        return MLXConfig(
            enable_zero_copy=self.enable_zero_copy,
            enable_metal_cache=self.enable_metal_cache,
            use_flash_attention=self.use_flash_attention,
        )

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> EngineArgs:
        """
        Create EngineArgs from dictionary.

        Args:
            config: Configuration dictionary.

        Returns:
            EngineArgs instance.
        """
        return cls(**config)


@dataclass
class AsyncEngineArgs(EngineArgs):
    """Arguments for creating an async LLM engine."""

    # Async-specific settings
    worker_use_ray: bool = False
    """Use Ray for distributed workers."""

    max_num_on_the_fly: int = 1
    """Maximum number of requests processed simultaneously."""

    engine_use_ray: bool = False
    """Run engine in Ray actor."""

    disable_log_requests: bool = False
    """Disable logging individual requests."""

    # Timeouts
    request_timeout: float = 3600.0
    """Request timeout in seconds."""

    log_stats_interval: float = 10.0
    """Interval for logging stats in seconds."""
