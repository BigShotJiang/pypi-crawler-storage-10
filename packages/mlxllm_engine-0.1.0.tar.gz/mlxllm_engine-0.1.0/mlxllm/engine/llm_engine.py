# SPDX-License-Identifier: Apache-2.0
"""Synchronous LLM Engine for MLX-LLM."""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from typing import TYPE_CHECKING

from mlxllm.engine.protocol import (
    GenerateRequest,
    RequestType,
)
from mlxllm.outputs import CompletionOutput, RequestOutput
from mlxllm.sampling_params import SamplingParams
from mlxllm.sequence import Sequence, SequenceGroup, SequenceStatus

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig
    from mlxllm.config.scheduler import SchedulerConfig

logger = logging.getLogger(__name__)


class LLMEngine:
    """
    Synchronous LLM inference engine.

    Provides a simple blocking API for text generation.
    For async/streaming, use AsyncLLMEngine.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        scheduler_config: SchedulerConfig,
        model_path: str,
        quantization: str | None = None,
    ) -> None:
        """
        Initialize LLM engine.

        Args:
            model_config: Model configuration.
            scheduler_config: Scheduler configuration.
            model_path: Path to model weights.
            quantization: Quantization mode (q4, q8, or None).
        """
        self.model_config = model_config
        self.scheduler_config = scheduler_config
        self.model_path = model_path
        self.quantization = quantization

        # Request tracking
        self.request_counter = 0
        self.pending_requests: dict[str, SequenceGroup] = {}
        self.running_requests: dict[str, SequenceGroup] = {}
        self.finished_requests: dict[str, RequestOutput] = {}

        # Initialize tokenizer (required)
        from mlxllm.tokenization import Tokenizer
        self.tokenizer = Tokenizer.from_pretrained(model_path)
        logger.info(f"Loaded tokenizer for model: {model_path}")

        # Initialize full infrastructure for real model execution (required)
        self.kv_cache_manager = None
        self.scheduler = None
        self.model_executor = None
        self.model_execution_failed = False  # Track if model execution has failed

        self._initialize_full_engine()
        logger.info(f"Successfully initialized full engine infrastructure")

        logger.info(f"Initialized LLMEngine with model: {model_path}")

    def generate(
        self,
        prompt: str | None = None,
        prompt_token_ids: list[int] | None = None,
        sampling_params: SamplingParams | None = None,
    ) -> RequestOutput:
        """
        Generate text synchronously.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.

        Returns:
            RequestOutput with generated text.
        """
        # Generate request ID
        request_id = f"req_{self.request_counter}"
        self.request_counter += 1

        # Create request
        if sampling_params is None:
            sampling_params = SamplingParams()

        request = GenerateRequest(
            request_id=request_id,
            request_type=RequestType.GENERATE,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
            arrival_time=time.time(),
        )

        # Process synchronously
        for output in self.generate_stream(request):
            if output.finished:
                return output

        raise RuntimeError("Generation did not complete")

    def generate_stream(
        self,
        request: GenerateRequest,
    ) -> Iterator[RequestOutput]:
        """
        Generate text with streaming.

        Args:
            request: Generation request.

        Yields:
            RequestOutput for each step.
        """
        # Create sequence group
        seq_group = self._create_sequence_group(request)
        self.pending_requests[request.request_id] = seq_group

        # Check if we have full infrastructure and haven't had execution failures
        has_full_infrastructure = (
            not self.model_execution_failed and
            self.scheduler is not None and
            self.model_executor is not None and
            self.tokenizer is not None
        )

        # If no infrastructure or execution failed, immediately return placeholder result
        if not has_full_infrastructure:
            outputs = self._step()
            for output in outputs:
                if output.request_id == request.request_id:
                    yield output
                    return

        # Process until finished (only if we have infrastructure)
        while request.request_id in self.pending_requests or \
              request.request_id in self.running_requests:

            # Step the engine
            outputs = self._step()

            # Yield outputs for this request
            for output in outputs:
                if output.request_id == request.request_id:
                    yield output

                    # Check if finished
                    if output.finished:
                        self.finished_requests[request.request_id] = output
                        if request.request_id in self.running_requests:
                            del self.running_requests[request.request_id]
                        if request.request_id in self.pending_requests:
                            del self.pending_requests[request.request_id]
                        return

    def _step(self) -> list[RequestOutput]:
        """
        Execute one step of generation.

        Returns:
            List of outputs for this step.
        """
        outputs = []

        # Move pending to running
        for req_id, seq_group in list(self.pending_requests.items()):
            self.running_requests[req_id] = seq_group
            del self.pending_requests[req_id]

        # Check if we have full infrastructure (scheduler, model_executor, tokenizer)
        has_full_infrastructure = (
            self.scheduler is not None and
            self.model_executor is not None and
            self.tokenizer is not None
        )

        if has_full_infrastructure:
            # Full implementation with real model execution
            # Type assertion: we've checked scheduler and model_executor are not None
            assert self.scheduler is not None
            assert self.model_executor is not None
            assert self.tokenizer is not None

            try:
                # Add requests to scheduler
                for seq_group in self.running_requests.values():
                    self.scheduler.add_request(seq_group)

                # Get scheduler's decision
                scheduler_output = self.scheduler.schedule()

                # Separate prefill and decode groups
                prefill_groups = [
                    sched_group.seq_group
                    for sched_group in scheduler_output.scheduled_groups
                    if sched_group.is_prefill
                ]
                decode_groups = [
                    sched_group.seq_group
                    for sched_group in scheduler_output.scheduled_groups
                    if not sched_group.is_prefill
                ]

                # Run model executor for prefill
                if prefill_groups:
                    result = self.model_executor.execute_prefill(
                        prefill_groups
                    )
                    logits = result["logits"]
                    sampled_tokens = self.model_executor.sample_tokens(
                        logits, prefill_groups
                    )

                    # Create outputs
                    for seq_group, token_id in zip(prefill_groups, sampled_tokens):
                        generated_text = self.tokenizer.decode([token_id])
                        seq = seq_group.sequences[0]
                        # Type assertion: seq.data is never None for valid sequences
                        assert seq.data is not None
                        prompt_text = self.tokenizer.decode(seq.data.prompt_token_ids)

                        output = RequestOutput(
                            request_id=seq_group.request_id,
                            prompt=prompt_text,
                            prompt_token_ids=seq.data.prompt_token_ids,
                            outputs=[
                                CompletionOutput(
                                    index=0,
                                    text=generated_text,
                                    token_ids=[token_id],
                                    cumulative_logprob=0.0,
                                    logprobs=None,
                                    finish_reason="length",
                                )
                            ],
                            finished=True,
                            metrics=None,
                        )
                        outputs.append(output)
                        seq.status = SequenceStatus.FINISHED_STOPPED

                # Run model executor for decode
                if decode_groups:
                    result = self.model_executor.execute_decode(
                        decode_groups
                    )
                    logits = result["logits"]
                    sampled_tokens = self.model_executor.sample_tokens(
                        logits, decode_groups
                    )

                    for seq_group, token_id in zip(decode_groups, sampled_tokens):
                        seq = seq_group.sequences[0]
                        # Type assertion: seq.data and sampling_params are never None for valid sequences
                        assert seq.data is not None
                        assert seq_group.sampling_params is not None

                        seq.data.output_token_ids.append(token_id)
                        generated_text = self.tokenizer.decode(seq.data.output_token_ids)

                        should_finish = (
                            token_id == self.tokenizer.eos_token_id or
                            len(seq.data.output_token_ids) >= seq_group.sampling_params.max_tokens
                        )

                        output = RequestOutput(
                            request_id=seq_group.request_id,
                            prompt=self.tokenizer.decode(seq.data.prompt_token_ids),
                            prompt_token_ids=seq.data.prompt_token_ids,
                            outputs=[
                                CompletionOutput(
                                    index=0,
                                    text=generated_text,
                                    token_ids=seq.data.output_token_ids,
                                    cumulative_logprob=0.0,
                                    logprobs=None,
                                    finish_reason="length" if should_finish else None,
                                )
                            ],
                            finished=should_finish,
                            metrics=None,
                        )
                        outputs.append(output)

                        if should_finish:
                            seq.status = SequenceStatus.FINISHED_STOPPED

                # Free finished requests
                self.scheduler.free_finished_requests()

            except Exception as e:
                import traceback
                logger.error(f"Model execution failed: {e}")
                logger.debug(f"Full traceback:\n{traceback.format_exc()}")
                raise RuntimeError(f"Model execution failed. Please implement the missing components.") from e

        if not has_full_infrastructure:
            # No fallback - require full implementation
            raise NotImplementedError(
                "Full model execution infrastructure is required. "
                "Please implement: scheduler, model_executor, and tokenizer. "
                "Missing components will cause this error."
            )

        return outputs

    def _create_sequence_group(
        self,
        request: GenerateRequest,
    ) -> SequenceGroup:
        """
        Create sequence group from request.

        Args:
            request: Generation request.

        Returns:
            SequenceGroup.
        """
        # Get tokens
        if request.prompt_token_ids is not None:
            prompt_token_ids = request.prompt_token_ids
        elif request.prompt is not None:
            # Tokenize using tokenizer (required)
            if self.tokenizer is None:
                raise RuntimeError("Tokenizer is required but not initialized")
            prompt_token_ids = self.tokenizer.encode(request.prompt)
        else:
            raise ValueError("Either prompt or prompt_token_ids required")

        # Create sequence data
        from mlxllm.sequence import SequenceData

        seq_data = SequenceData(
            prompt_token_ids=prompt_token_ids,
        )

        # Create sequence
        seq = Sequence(
            seq_id=f"{request.request_id}_0",
            request_id=request.request_id,
            data=seq_data,
        )
        seq.status = SequenceStatus.WAITING

        # Create sequence group
        seq_group = SequenceGroup(
            request_id=request.request_id,
            sequences=[seq],
            arrival_time=request.arrival_time or time.time(),
            sampling_params=request.sampling_params,
        )

        return seq_group

    def _load_model_config(self) -> None:
        """
        Load model configuration from HuggingFace/local path.

        Populates ModelConfig with architecture details from config.json.
        """
        import json
        from pathlib import Path
        from transformers import AutoConfig

        try:
            # Try to load config using transformers
            hf_config = AutoConfig.from_pretrained(
                self.model_path,
                trust_remote_code=self.model_config.trust_remote_code,
            )

            # Populate ModelConfig with architecture details
            self.model_config.vocab_size = getattr(hf_config, 'vocab_size', None)
            self.model_config.hidden_size = getattr(hf_config, 'hidden_size', None)
            self.model_config.num_layers = getattr(hf_config, 'num_hidden_layers', None)
            self.model_config.num_attention_heads = getattr(hf_config, 'num_attention_heads', None)
            self.model_config.num_kv_heads = getattr(hf_config, 'num_key_value_heads',
                                                      self.model_config.num_attention_heads)
            self.model_config.intermediate_size = getattr(hf_config, 'intermediate_size', None)
            self.model_config.rope_theta = getattr(hf_config, 'rope_theta', 10000.0)
            self.model_config.max_position_embeddings = getattr(hf_config, 'max_position_embeddings', 2048)

            # Calculate head_dim
            if self.model_config.hidden_size and self.model_config.num_attention_heads:
                self.model_config.head_dim = self.model_config.hidden_size // self.model_config.num_attention_heads

            # Set RMS norm epsilon if available
            self.model_config.rms_norm_eps = getattr(hf_config, 'rms_norm_eps', 1e-6)

            logger.info(f"Loaded model config: num_layers={self.model_config.num_layers}, "
                       f"hidden_size={self.model_config.hidden_size}, "
                       f"num_heads={self.model_config.num_attention_heads}")

        except Exception as e:
            logger.error(f"Failed to load model config: {e}")
            raise

    def _initialize_full_engine(self) -> None:
        """
        Initialize full engine infrastructure for real model execution.

        This creates:
        - KV cache manager
        - Scheduler
        - Model executor (and loads model)

        Raises:
            Exception: If initialization fails
        """
        from pathlib import Path

        from mlxllm.config import CacheConfig, KVCacheConfig
        from mlxllm.core.kv_cache_manager import KVCacheManager
        from mlxllm.core.sched.scheduler import Scheduler
        from mlxllm.model_executor.executor import ModelExecutor
        from mlxllm.models.download import ModelDownloader

        logger.info("Initializing full engine infrastructure...")

        # Download model if it's a HuggingFace ID (not a local path)
        if not Path(self.model_path).exists():
            logger.info(f"Model path not found locally: {self.model_path}")
            logger.info("Downloading model from HuggingFace...")
            downloader = ModelDownloader(use_progress_bar=True)
            model_dir = downloader.download_from_hub(self.model_path)
            self.model_path = str(model_dir)
            logger.info(f"Model downloaded to: {self.model_path}")
        else:
            logger.info(f"Using local model: {self.model_path}")

        # Load model configuration to populate architecture details
        logger.info(f"Loading model config from: {self.model_path}")
        self._load_model_config()

        # Update model config with path
        self.model_config.model_path = self.model_path

        # Create KV cache config
        kv_cache_config = KVCacheConfig(
            block_size=16,
            enable_prefix_caching=True,
        )
        cache_config = CacheConfig(kv_cache=kv_cache_config)

        # Initialize KV cache manager
        logger.info("Creating KV cache manager...")
        self.kv_cache_manager = KVCacheManager(
            cache_config=kv_cache_config,
            model_config=self.model_config,
        )

        # Initialize scheduler
        logger.info("Creating scheduler...")
        self.scheduler = Scheduler(
            scheduler_config=self.scheduler_config,
            cache_config=cache_config,
            kv_cache_manager=self.kv_cache_manager,
        )

        # Initialize model executor
        logger.info("Creating model executor...")
        self.model_executor = ModelExecutor(
            model_config=self.model_config,
            kv_cache_manager=self.kv_cache_manager,
            tokenizer=self.tokenizer,
        )

        # Load the model
        logger.info(f"Loading model from: {self.model_path}")
        self.model_executor.load_model()
        logger.info("Model loaded successfully!")

    def abort(self, request_id: str) -> None:
        """
        Abort a running request.

        Args:
            request_id: Request ID to abort.
        """
        if request_id in self.pending_requests:
            del self.pending_requests[request_id]
        if request_id in self.running_requests:
            del self.running_requests[request_id]

        logger.info(f"Aborted request: {request_id}")

    def get_num_unfinished_requests(self) -> int:
        """Get number of unfinished requests."""
        return len(self.pending_requests) + len(self.running_requests)

    def has_unfinished_requests(self) -> bool:
        """Check if there are unfinished requests."""
        return self.get_num_unfinished_requests() > 0


class EngineArgs:
    """Arguments for creating an LLMEngine."""

    def __init__(
        self,
        model: str,
        tokenizer: str | None = None,
        quantization: str | None = None,
        max_model_len: int | None = None,
        max_num_seqs: int = 256,
        block_size: int = 16,
        **kwargs,
    ) -> None:
        """
        Initialize engine arguments.

        Args:
            model: Model name or path.
            tokenizer: Tokenizer name or path.
            quantization: Quantization mode.
            max_model_len: Maximum model context length.
            max_num_seqs: Maximum number of sequences.
            block_size: KV cache block size.
            **kwargs: Additional arguments.
        """
        self.model = model
        self.tokenizer = tokenizer or model
        self.quantization = quantization
        self.max_model_len = max_model_len
        self.max_num_seqs = max_num_seqs
        self.block_size = block_size
        self.kwargs = kwargs

    def create_engine(self) -> LLMEngine:
        """
        Create LLMEngine from arguments.

        Returns:
            LLMEngine instance.
        """
        from mlxllm.config.model import ModelConfig
        from mlxllm.config.scheduler import SchedulerConfig

        # Create configs (placeholder)
        model_config = ModelConfig(
            model_name=self.model,
            max_model_len=self.max_model_len or 8192,
        )

        scheduler_config = SchedulerConfig(
            max_num_seqs=self.max_num_seqs,
        )

        return LLMEngine(
            model_config=model_config,
            scheduler_config=scheduler_config,
            model_path=self.model,
            quantization=self.quantization,
        )
