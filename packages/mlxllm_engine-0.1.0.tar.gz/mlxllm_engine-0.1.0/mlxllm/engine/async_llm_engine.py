# SPDX-License-Identifier: Apache-2.0
"""Asynchronous LLM Engine for MLX-LLM."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from mlxllm.engine.llm_engine import LLMEngine
from mlxllm.engine.protocol import (
    GenerateRequest,
    RequestType,
)
from mlxllm.outputs import RequestOutput
from mlxllm.sampling_params import SamplingParams

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig
    from mlxllm.config.scheduler import SchedulerConfig

logger = logging.getLogger(__name__)


class AsyncLLMEngine:
    """
    Asynchronous LLM inference engine.

    Wraps LLMEngine and provides async/await API with streaming support.
    Useful for building API servers with concurrent request handling.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        scheduler_config: SchedulerConfig,
        model_path: str,
        quantization: str | None = None,
    ) -> None:
        """
        Initialize async LLM engine.

        Args:
            model_config: Model configuration.
            scheduler_config: Scheduler configuration.
            model_path: Path to model weights.
            quantization: Quantization mode (q4, q8, or None).
        """
        # Create underlying sync engine
        self.engine = LLMEngine(
            model_config=model_config,
            scheduler_config=scheduler_config,
            model_path=model_path,
            quantization=quantization,
        )

        # Background task for processing
        self.background_task: asyncio.Task | None = None
        self.is_running = False

        # Request queue
        self.request_queue: asyncio.Queue = asyncio.Queue()
        self.response_queues: dict[str, asyncio.Queue] = {}

        logger.info("Initialized AsyncLLMEngine")

    async def start(self) -> None:
        """Start the background processing loop."""
        if self.is_running:
            logger.warning("AsyncLLMEngine already running")
            return

        self.is_running = True
        self.background_task = asyncio.create_task(self._background_loop())
        logger.info("Started AsyncLLMEngine background loop")

    async def stop(self) -> None:
        """Stop the background processing loop."""
        if not self.is_running:
            return

        self.is_running = False

        if self.background_task:
            self.background_task.cancel()
            try:
                await self.background_task
            except asyncio.CancelledError:
                pass

        logger.info("Stopped AsyncLLMEngine")

    async def generate(
        self,
        prompt: str | None = None,
        prompt_token_ids: list[int] | None = None,
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
    ) -> RequestOutput:
        """
        Generate text asynchronously.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Optional request ID.

        Returns:
            RequestOutput with generated text.
        """
        # Consume entire stream and return final output
        final_output = None
        async for output in self.generate_stream(
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
            request_id=request_id,
        ):
            final_output = output

        if final_output is None:
            raise RuntimeError("No output generated")

        return final_output

    async def generate_stream(
        self,
        prompt: str | None = None,
        prompt_token_ids: list[int] | None = None,
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
    ) -> AsyncIterator[RequestOutput]:
        """
        Generate text with streaming.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Optional request ID.

        Yields:
            RequestOutput for each generation step.
        """
        # Generate request ID if not provided
        if request_id is None:
            request_id = f"async_req_{time.time_ns()}"

        # Create request
        if sampling_params is None:
            sampling_params = SamplingParams()

        request = GenerateRequest(
            request_id=request_id,
            request_type=RequestType.GENERATE,
            prompt=prompt,
            prompt_token_ids=prompt_token_ids,
            sampling_params=sampling_params,
            arrival_time=time.time(),
        )

        # Create response queue for this request
        response_queue: asyncio.Queue = asyncio.Queue()
        self.response_queues[request_id] = response_queue

        # Submit request to background loop
        await self.request_queue.put(request)

        # Stream outputs
        try:
            while True:
                output = await response_queue.get()

                # Check for sentinel
                if output is None:
                    break

                yield output

                # Break if finished
                if output.finished:
                    break
        finally:
            # Cleanup
            if request_id in self.response_queues:
                del self.response_queues[request_id]

    async def abort(self, request_id: str) -> None:
        """
        Abort a running request.

        Args:
            request_id: Request ID to abort.
        """
        # Abort in sync engine
        await asyncio.to_thread(self.engine.abort, request_id)

        # Clear response queue
        if request_id in self.response_queues:
            del self.response_queues[request_id]

    async def _background_loop(self) -> None:
        """
        Background loop for processing requests.

        Runs the sync engine in a background thread and distributes
        outputs to the appropriate response queues.
        """
        logger.info("Starting background processing loop")

        try:
            while self.is_running:
                # Check for new requests
                try:
                    request = await asyncio.wait_for(
                        self.request_queue.get(),
                        timeout=0.1,
                    )
                except TimeoutError:
                    # No new requests, continue
                    if not self.engine.has_unfinished_requests():
                        continue
                else:
                    # Process new request in thread
                    await self._process_request(request)

                # Step the engine if there are requests
                if self.engine.has_unfinished_requests():
                    await self._step_engine()

        except asyncio.CancelledError:
            logger.info("Background loop cancelled")
            raise
        except Exception as e:
            logger.error(f"Error in background loop: {e}", exc_info=True)
            raise

    async def _process_request(self, request: GenerateRequest) -> None:
        """
        Process a new request.

        Args:
            request: Request to process.
        """
        # Add to engine (in thread to avoid blocking)
        await asyncio.to_thread(
            self._add_request_to_engine,
            request,
        )

    def _add_request_to_engine(self, request: GenerateRequest) -> None:
        """Add request to sync engine."""
        # Create sequence group and add to pending
        seq_group = self.engine._create_sequence_group(request)
        self.engine.pending_requests[request.request_id] = seq_group

    async def _step_engine(self) -> None:
        """Step the engine and distribute outputs."""
        # Run engine step in thread
        outputs = await asyncio.to_thread(self.engine._step)

        # Distribute outputs to response queues
        for output in outputs:
            if output.request_id in self.response_queues:
                queue = self.response_queues[output.request_id]
                await queue.put(output)

                # Send sentinel if finished
                if output.finished:
                    await queue.put(None)

    def get_num_unfinished_requests(self) -> int:
        """Get number of unfinished requests."""
        return self.engine.get_num_unfinished_requests()

    def has_unfinished_requests(self) -> bool:
        """Check if there are unfinished requests."""
        return self.engine.has_unfinished_requests()


class AsyncEngineArgs:
    """Arguments for creating an AsyncLLMEngine."""

    def __init__(
        self,
        model: str,
        tokenizer: str | None = None,
        quantization: str | None = None,
        max_model_len: int | None = None,
        max_num_seqs: int = 256,
        block_size: int = 16,
        **kwargs,
    ) -> None:
        """
        Initialize async engine arguments.

        Args:
            model: Model name or path.
            tokenizer: Tokenizer name or path.
            quantization: Quantization mode.
            max_model_len: Maximum model context length.
            max_num_seqs: Maximum number of sequences.
            block_size: KV cache block size.
            **kwargs: Additional arguments.
        """
        self.model = model
        self.tokenizer = tokenizer or model
        self.quantization = quantization
        self.max_model_len = max_model_len
        self.max_num_seqs = max_num_seqs
        self.block_size = block_size
        self.kwargs = kwargs

    async def create_engine(self) -> AsyncLLMEngine:
        """
        Create AsyncLLMEngine from arguments.

        Returns:
            AsyncLLMEngine instance.
        """
        from mlxllm.config.model import ModelConfig
        from mlxllm.config.scheduler import SchedulerConfig

        # Create configs
        model_config = ModelConfig(
            model_name=self.model,
            max_model_len=self.max_model_len or 8192,
        )

        scheduler_config = SchedulerConfig(
            max_num_seqs=self.max_num_seqs,
        )

        engine = AsyncLLMEngine(
            model_config=model_config,
            scheduler_config=scheduler_config,
            model_path=self.model,
            quantization=self.quantization,
        )

        # Start background loop
        await engine.start()

        return engine
