# SPDX-License-Identifier: Apache-2.0
"""Protocol definitions for engine communication in MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any, Protocol

from mlxllm.sampling_params import SamplingParams

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from mlxllm.config import ModelConfig
    from mlxllm.outputs import RequestOutput


class EngineClient(Protocol):
    """
    Protocol for engine client interface.

    This defines the expected interface for async engine clients
    (like AsyncLLMEngine) used by API servers.
    """

    async def generate(
        self,
        prompt: str | None = None,
        prompt_token_ids: list[int] | None = None,
        sampling_params: SamplingParams | None = None,
        request_id: str | None = None,
    ) -> AsyncIterator[RequestOutput]:
        """
        Generate text from prompt.

        Args:
            prompt: Text prompt.
            prompt_token_ids: Tokenized prompt.
            sampling_params: Sampling parameters.
            request_id: Request ID.

        Yields:
            RequestOutput: Streaming generation outputs.
        """
        ...

    async def abort(self, request_id: str) -> None:
        """
        Abort a running request.

        Args:
            request_id: ID of request to abort.
        """
        ...

    def get_model_config(self) -> ModelConfig:
        """
        Get model configuration.

        Returns:
            Model configuration.
        """
        ...


class RequestType(str, Enum):
    """Type of request to the engine."""

    GENERATE = "generate"
    """Text generation request."""

    EMBED = "embed"
    """Embedding generation request."""

    ABORT = "abort"
    """Abort request."""

    METRICS = "metrics"
    """Get metrics request."""


@dataclass
class EngineRequest:
    """Base request to the engine."""

    request_id: str
    """Unique request identifier."""

    request_type: RequestType
    """Type of request."""


@dataclass
class GenerateRequest(EngineRequest):
    """Request for text generation."""

    prompt: str | None = None
    """Text prompt."""

    prompt_token_ids: list[int] | None = None
    """Tokenized prompt (alternative to text prompt)."""

    sampling_params: SamplingParams | None = None
    """Sampling parameters for generation."""

    arrival_time: float | None = None
    """Time when request arrived (for scheduling)."""

    prefix_pos: int | None = None
    """Position in prompt where prefix caching can start."""

    def __post_init__(self) -> None:
        """Validate request."""
        if self.prompt is None and self.prompt_token_ids is None:
            raise ValueError("Either prompt or prompt_token_ids must be provided")

        if self.sampling_params is None:
            self.sampling_params = SamplingParams()


@dataclass
class EmbedRequest(EngineRequest):
    """Request for embedding generation."""

    inputs: list[str] | None = None
    """Text inputs for embedding."""

    input_token_ids: list[list[int]] | None = None
    """Tokenized inputs (alternative to text)."""

    pooling_params: Any | None = None
    """Pooling parameters."""

    def __post_init__(self) -> None:
        """Validate request."""
        if self.inputs is None and self.input_token_ids is None:
            raise ValueError("Either inputs or input_token_ids must be provided")


@dataclass
class AbortRequest(EngineRequest):
    """Request to abort a running request."""

    abort_request_id: str
    """ID of the request to abort."""


@dataclass
class MetricsRequest(EngineRequest):
    """Request for engine metrics."""

    include_stats: bool = True
    """Include detailed statistics."""


@dataclass
class EngineResponse:
    """Base response from the engine."""

    request_id: str
    """Request ID this response is for."""

    success: bool
    """Whether the request was successful."""

    error: str | None = None
    """Error message if success=False."""


@dataclass
class GenerateResponse(EngineResponse):
    """Response for text generation."""

    outputs: list[dict[str, Any]] | None = None
    """Generated outputs."""

    finished: bool = False
    """Whether generation is complete."""


@dataclass
class EmbedResponse(EngineResponse):
    """Response for embedding generation."""

    embeddings: list[list[float]] | None = None
    """Generated embeddings."""


@dataclass
class MetricsResponse(EngineResponse):
    """Response with engine metrics."""

    metrics: dict[str, Any] | None = None
    """Engine metrics."""
