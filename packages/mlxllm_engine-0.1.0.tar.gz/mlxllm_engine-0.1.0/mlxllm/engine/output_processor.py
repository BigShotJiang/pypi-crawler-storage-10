# SPDX-License-Identifier: Apache-2.0
"""Output processing for MLX-LLM.

This module processes raw model outputs into final user-facing results:
- Detokenization
- Log probability calculation
- Finish reason determination
- Output formatting
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from mlxllm.engine.detokenizer import Detokenizer
from mlxllm.outputs import CompletionOutput, RequestOutput

if TYPE_CHECKING:
    from transformers import PreTrainedTokenizerBase

    from mlxllm.sequence import Sequence, SequenceGroup

logger = logging.getLogger(__name__)


class OutputProcessor:
    """
    Processes model outputs into final user results.

    Handles:
    - Incremental detokenization
    - Log probability tracking
    - Finish reason detection
    - Output formatting
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        return_logprobs: bool = False,
    ) -> None:
        """
        Initialize output processor.

        Args:
            tokenizer: HuggingFace tokenizer.
            return_logprobs: Whether to return log probabilities.
        """
        self.tokenizer = tokenizer
        self.return_logprobs = return_logprobs

        # Initialize detokenizer
        self.detokenizer = Detokenizer(tokenizer)

    def process_outputs(
        self,
        sequence_groups: list[SequenceGroup],
        incremental: bool = True,
    ) -> list[RequestOutput]:
        """
        Process outputs for sequence groups.

        Args:
            sequence_groups: List of sequence groups to process.
            incremental: Whether to do incremental processing.

        Returns:
            List of request outputs.
        """
        results: list[RequestOutput] = []

        for seq_group in sequence_groups:
            output = self._process_sequence_group(seq_group, incremental)
            results.append(output)

        return results

    def _process_sequence_group(
        self,
        seq_group: SequenceGroup,
        incremental: bool,
    ) -> RequestOutput:
        """
        Process a single sequence group.

        Args:
            seq_group: Sequence group to process.
            incremental: Whether to do incremental processing.

        Returns:
            Request output.
        """
        # Get first sequence (simplified - beam search would have multiple)
        seq = seq_group.sequences[0]

        # Detokenize
        if incremental:
            # Incremental detokenization
            text_delta = self.detokenizer.decode_incremental(
                seq_group.request_id,
                seq.get_output_token_ids(),
            )
        else:
            # Full detokenization
            text_delta = self.detokenizer.decode_complete(
                seq_group.request_id,
                seq.get_output_token_ids(),
            )

        # Determine finish reason
        finish_reason = self._get_finish_reason(seq, seq_group)

        # Create completion output
        completion = CompletionOutput(
            index=0,
            text=text_delta,
            token_ids=seq.get_output_token_ids(),
            cumulative_logprob=seq.cumulative_logprob if hasattr(seq, "cumulative_logprob") else 0.0,
            logprobs=None,  # TODO: Add logprob support
            finish_reason=finish_reason,
        )

        # Create request output
        output = RequestOutput(
            request_id=seq_group.request_id,
            prompt=seq.prompt,
            prompt_token_ids=seq.prompt_token_ids,
            outputs=[completion],
            finished=finish_reason is not None,
        )

        # Reset detokenizer if finished
        if finish_reason is not None:
            self.detokenizer.reset(seq_group.request_id)

        return output

    def _get_finish_reason(
        self,
        seq: Sequence,
        seq_group: SequenceGroup,
    ) -> str | None:
        """
        Determine finish reason for a sequence.

        Args:
            seq: Sequence to check.
            seq_group: Parent sequence group.

        Returns:
            Finish reason string or None if not finished.
        """
        from mlxllm.sequence import SequenceStatus

        if seq.status != SequenceStatus.FINISHED:
            return None

        output_tokens = seq.get_output_token_ids()
        if not output_tokens:
            return "length"

        # Check if stopped by EOS token
        last_token = output_tokens[-1]
        if last_token == self.tokenizer.eos_token_id:
            return "stop"

        # Check custom stop tokens
        if seq_group.sampling_params is not None:
            stop_token_ids = seq_group.sampling_params.stop_token_ids
            if last_token in stop_token_ids:
                return "stop"

        # Check max tokens
        if seq_group.sampling_params is not None:
            max_tokens = seq_group.sampling_params.max_tokens
            if max_tokens is not None and len(output_tokens) >= max_tokens:
                return "length"

        # Default to stop
        return "stop"

    def cleanup_request(self, request_id: str) -> None:
        """
        Clean up resources for a request.

        Args:
            request_id: Request ID to clean up.
        """
        self.detokenizer.reset(request_id)


class StreamingOutputProcessor(OutputProcessor):
    """
    Output processor optimized for streaming generation.

    Maintains state for incremental updates and efficient streaming.
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        return_logprobs: bool = False,
    ) -> None:
        """
        Initialize streaming output processor.

        Args:
            tokenizer: HuggingFace tokenizer.
            return_logprobs: Whether to return log probabilities.
        """
        super().__init__(tokenizer, return_logprobs)

        # Track last output per request
        self._last_outputs: dict[str, RequestOutput] = {}

    def process_streaming(
        self,
        sequence_groups: list[SequenceGroup],
    ) -> list[RequestOutput]:
        """
        Process outputs for streaming.

        Args:
            sequence_groups: Sequence groups to process.

        Returns:
            List of incremental request outputs (deltas only).
        """
        results: list[RequestOutput] = []

        for seq_group in sequence_groups:
            # Process incrementally
            output = self._process_sequence_group(seq_group, incremental=True)

            # Store for next iteration
            self._last_outputs[seq_group.request_id] = output

            results.append(output)

            # Clean up if finished
            if output.finished:
                self.cleanup_request(seq_group.request_id)
                if seq_group.request_id in self._last_outputs:
                    del self._last_outputs[seq_group.request_id]

        return results

    def get_final_output(self, request_id: str) -> RequestOutput | None:
        """
        Get final complete output for a request.

        Args:
            request_id: Request ID.

        Returns:
            Final output or None if not found.
        """
        return self._last_outputs.get(request_id)
