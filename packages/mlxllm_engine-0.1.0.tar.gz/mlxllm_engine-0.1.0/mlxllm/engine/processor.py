# SPDX-License-Identifier: Apache-2.0
"""Input preprocessing for MLX-LLM.

This module handles preprocessing of user inputs:
- Tokenization
- Prompt formatting
- Input validation
- Chat template application
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from transformers import PreTrainedTokenizerBase

    from mlxllm.config import ModelConfig

logger = logging.getLogger(__name__)


class InputProcessor:
    """
    Processes user inputs for the engine.

    Handles:
    - Tokenization
    - Prompt formatting
    - Chat templates
    - Input validation
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        model_config: ModelConfig,
    ) -> None:
        """
        Initialize input processor.

        Args:
            tokenizer: HuggingFace tokenizer.
            model_config: Model configuration.
        """
        self.tokenizer = tokenizer
        self.model_config = model_config

    def process_text_prompt(
        self,
        prompt: str,
        max_length: int | None = None,
    ) -> tuple[str, list[int]]:
        """
        Process a text prompt.

        Args:
            prompt: Text prompt.
            max_length: Maximum token length (optional).

        Returns:
            Tuple of (formatted_prompt, token_ids).
        """
        # Tokenize
        token_ids = self.tokenizer.encode(prompt, add_special_tokens=True)

        # Validate length
        max_len = max_length or self.model_config.max_model_len
        if len(token_ids) > max_len:
            logger.warning(
                f"Prompt length {len(token_ids)} exceeds max {max_len}, truncating"
            )
            token_ids = token_ids[:max_len]

        return prompt, token_ids

    def process_chat_messages(
        self,
        messages: list[dict[str, str]],
        max_length: int | None = None,
    ) -> tuple[str, list[int]]:
        """
        Process chat messages using the model's chat template.

        Args:
            messages: List of message dicts with 'role' and 'content'.
            max_length: Maximum token length (optional).

        Returns:
            Tuple of (formatted_prompt, token_ids).
        """
        # Check if tokenizer has chat template
        if not hasattr(self.tokenizer, "apply_chat_template"):
            logger.warning("Tokenizer has no chat template, using simple formatting")
            return self._format_chat_simple(messages, max_length)

        try:
            # Apply chat template
            prompt = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )

            # Tokenize
            token_ids = self.tokenizer.encode(prompt, add_special_tokens=False)

            # Validate length
            max_len = max_length or self.model_config.max_model_len
            if len(token_ids) > max_len:
                logger.warning(
                    f"Chat prompt length {len(token_ids)} exceeds max {max_len}, truncating"
                )
                token_ids = token_ids[:max_len]

            return prompt, token_ids

        except Exception as e:
            logger.error(f"Error applying chat template: {e}")
            return self._format_chat_simple(messages, max_length)

    def _format_chat_simple(
        self,
        messages: list[dict[str, str]],
        max_length: int | None = None,
    ) -> tuple[str, list[int]]:
        """
        Simple chat formatting fallback.

        Args:
            messages: List of message dicts.
            max_length: Maximum token length.

        Returns:
            Tuple of (formatted_prompt, token_ids).
        """
        # Build simple prompt
        lines = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            lines.append(f"{role.capitalize()}: {content}")

        lines.append("Assistant:")
        prompt = "\n".join(lines)

        return self.process_text_prompt(prompt, max_length)

    def validate_prompt(
        self,
        token_ids: list[int],
    ) -> tuple[bool, str | None]:
        """
        Validate a tokenized prompt.

        Args:
            token_ids: Token IDs to validate.

        Returns:
            Tuple of (is_valid, error_message).
        """
        # Check empty
        if not token_ids:
            return False, "Empty prompt"

        # Check length
        if len(token_ids) > self.model_config.max_model_len:
            return (
                False,
                f"Prompt length {len(token_ids)} exceeds max {self.model_config.max_model_len}",
            )

        # Check for unknown tokens
        if hasattr(self.tokenizer, "unk_token_id"):
            unk_id = self.tokenizer.unk_token_id
            if unk_id is not None:
                unk_count = token_ids.count(unk_id)
                if unk_count > len(token_ids) * 0.1:  # More than 10% unknown
                    logger.warning(f"Prompt has {unk_count} unknown tokens")

        return True, None

    def get_special_token_ids(self) -> dict[str, int | None]:
        """
        Get special token IDs.

        Returns:
            Dict of special token names to IDs.
        """
        return {
            "bos": getattr(self.tokenizer, "bos_token_id", None),
            "eos": getattr(self.tokenizer, "eos_token_id", None),
            "pad": getattr(self.tokenizer, "pad_token_id", None),
            "unk": getattr(self.tokenizer, "unk_token_id", None),
        }


class BatchInputProcessor:
    """
    Batched input processor for efficient batch processing.
    """

    def __init__(
        self,
        tokenizer: PreTrainedTokenizerBase,
        model_config: ModelConfig,
    ) -> None:
        """
        Initialize batch input processor.

        Args:
            tokenizer: HuggingFace tokenizer.
            model_config: Model configuration.
        """
        self.processor = InputProcessor(tokenizer, model_config)

    def process_batch(
        self,
        prompts: list[str],
        max_length: int | None = None,
    ) -> list[tuple[str, list[int]]]:
        """
        Process a batch of prompts.

        Args:
            prompts: List of text prompts.
            max_length: Maximum token length.

        Returns:
            List of (formatted_prompt, token_ids) tuples.
        """
        results = []

        for prompt in prompts:
            result = self.processor.process_text_prompt(prompt, max_length)
            results.append(result)

        return results

    def process_chat_batch(
        self,
        message_lists: list[list[dict[str, str]]],
        max_length: int | None = None,
    ) -> list[tuple[str, list[int]]]:
        """
        Process a batch of chat message lists.

        Args:
            message_lists: List of message lists.
            max_length: Maximum token length.

        Returns:
            List of (formatted_prompt, token_ids) tuples.
        """
        results = []

        for messages in message_lists:
            result = self.processor.process_chat_messages(messages, max_length)
            results.append(result)

        return results
