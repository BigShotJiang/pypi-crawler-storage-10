# SPDX-License-Identifier: Apache-2.0
"""Exception definitions for MLX-LLM engine."""

from __future__ import annotations


class MLXLLMError(Exception):
    """Base exception for MLX-LLM."""

    pass


class EngineError(MLXLLMError):
    """Base exception for engine errors."""

    pass


class ModelLoadError(EngineError):
    """Error loading model."""

    pass


class OutOfMemoryError(EngineError):
    """Out of memory error."""

    pass


class InvalidRequestError(EngineError):
    """Invalid request error."""

    pass


class RequestAbortedError(EngineError):
    """Request was aborted."""

    pass


class TimeoutError(EngineError):
    """Request timed out."""

    pass


class ConfigurationError(MLXLLMError):
    """Configuration error."""

    pass


class DeviceError(MLXLLMError):
    """Device/hardware error."""

    pass


class MetalError(DeviceError):
    """Metal-specific error."""

    pass


class QuantizationError(MLXLLMError):
    """Quantization error."""

    pass


class TokenizationError(MLXLLMError):
    """Tokenization error."""

    pass


class AttentionError(EngineError):
    """Attention computation error."""

    pass


class KVCacheError(EngineError):
    """KV cache error."""

    pass


class SchedulingError(EngineError):
    """Scheduling error."""

    pass


# Alias for backward compatibility
EngineException = EngineError
