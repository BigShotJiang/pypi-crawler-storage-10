# SPDX-License-Identifier: Apache-2.0
"""Parallel sampling strategies for generating multiple sequences from a single prompt."""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    from mlxllm.sampling_params import SamplingParams
    from mlxllm.sequence import Sequence, SequenceGroup


@dataclass
class ParallelSamplingConfig:
    """
    Configuration for parallel sampling.

    Parallel sampling generates multiple sequences from the same prompt,
    either returning all of them (n sequences) or selecting the best
    based on cumulative log probability (best_of).
    """

    n: int = 1
    """Number of sequences to return."""

    best_of: int | None = None
    """Generate best_of sequences and return top n by score. None = return all n."""

    return_all: bool = False
    """Return all best_of sequences instead of just top n (for debugging)."""

    @classmethod
    def from_sampling_params(cls, sampling_params: SamplingParams) -> ParallelSamplingConfig:
        """
        Create config from sampling parameters.

        Args:
            sampling_params: Sampling parameters.

        Returns:
            ParallelSamplingConfig instance.
        """
        return cls(
            n=sampling_params.n,
            best_of=sampling_params.best_of,
        )

    @property
    def num_sequences_to_generate(self) -> int:
        """Get the number of sequences to generate."""
        if self.best_of is not None:
            return self.best_of
        return self.n

    def validate(self) -> None:
        """Validate parallel sampling configuration."""
        if self.n < 1:
            raise ValueError(f"n must be positive, got {self.n}")

        if self.best_of is not None and self.best_of < self.n:
            raise ValueError(
                f"best_of ({self.best_of}) must be >= n ({self.n})"
            )


def create_parallel_sequences(
    base_sequence: Sequence,
    num_sequences: int,
) -> list[Sequence]:
    """
    Create multiple parallel sequences from a base sequence.

    Each parallel sequence shares the same prompt but will have
    independent generation trajectories.

    Args:
        base_sequence: The base sequence to copy from.
        num_sequences: Number of parallel sequences to create.

    Returns:
        List of parallel sequences.
    """
    if num_sequences < 1:
        raise ValueError(f"num_sequences must be positive, got {num_sequences}")

    # If only one sequence needed, return the original
    if num_sequences == 1:
        return [base_sequence]

    # Create parallel copies
    sequences = []
    for i in range(num_sequences):
        # Deep copy the sequence data to ensure independence
        seq_copy = copy.deepcopy(base_sequence)

        # Update sequence ID to be unique
        seq_copy.seq_id = f"{base_sequence.seq_id}-{i}"

        sequences.append(seq_copy)

    return sequences


def select_best_sequences(
    sequences: list[Sequence],
    n: int,
    length_penalty: float = 1.0,
) -> list[Sequence]:
    """
    Select the top n sequences based on score.

    Score is computed as: cumulative_logprob / (sequence_length ** length_penalty)

    Args:
        sequences: List of sequences to select from.
        n: Number of sequences to select.
        length_penalty: Length penalty for scoring. >1.0 encourages longer sequences.

    Returns:
        Top n sequences sorted by score (descending).
    """
    if len(sequences) <= n:
        return sequences

    # Compute scores for each sequence
    scored_sequences = []
    for seq in sequences:
        # Get sequence length (total tokens including prompt)
        seq_len = seq.seq_len

        # Avoid division by zero
        if seq_len == 0:
            score = float('-inf')
        else:
            # Score = logprob / length^penalty
            # Higher cumulative logprob is better (less negative)
            score = seq.data.cumulative_logprob / (seq_len ** length_penalty)

        scored_sequences.append((score, seq))

    # Sort by score (descending - higher is better)
    scored_sequences.sort(key=lambda x: x[0], reverse=True)

    # Return top n sequences
    return [seq for _, seq in scored_sequences[:n]]


def sample_parallel(
    logits: mx.array,
    num_sequences: int,
    sampling_params: SamplingParams,
) -> mx.array:
    """
    Sample multiple tokens in parallel from the same logits.

    This is used for parallel sampling where we want independent
    samples from the same distribution.

    Args:
        logits: Model logits [vocab_size] or [batch_size, vocab_size].
        num_sequences: Number of parallel samples to draw.
        sampling_params: Sampling configuration.

    Returns:
        Sampled token IDs [num_sequences] or [batch_size, num_sequences].
    """
    from mlxllm.model_executor.layers.logits_processor import apply_logits_processors

    # Ensure logits is 2D
    if logits.ndim == 1:
        logits = mx.expand_dims(logits, axis=0)
        is_single = True
    else:
        is_single = False

    batch_size, vocab_size = logits.shape

    # Apply logits processors (temperature, top-k, top-p)
    processed_logits = apply_logits_processors(logits, sampling_params)

    # Expand for parallel sampling
    # Shape: [batch_size, num_sequences, vocab_size]
    expanded_logits = mx.repeat(
        mx.expand_dims(processed_logits, axis=1),
        num_sequences,
        axis=1
    )

    # Sample from distribution
    if sampling_params.temperature == 0.0:
        # Greedy sampling - all parallel sequences get the same token
        sampled_ids = mx.argmax(expanded_logits, axis=-1)
    else:
        # Stochastic sampling - each sequence gets independent sample
        probs = mx.softmax(expanded_logits, axis=-1)

        # Sample independently for each sequence
        sampled_ids = mx.random.categorical(
            mx.log(probs.reshape(-1, vocab_size)),
            axis=-1
        ).reshape(batch_size, num_sequences)

    # Remove batch dimension if input was single
    if is_single:
        sampled_ids = sampled_ids[0]

    return sampled_ids


def update_parallel_sequences(
    sequences: list[Sequence],
    sampled_token_ids: mx.array | list[int],
    logprobs: list[float] | None = None,
) -> None:
    """
    Update parallel sequences with newly sampled tokens.

    Args:
        sequences: List of sequences to update.
        sampled_token_ids: Sampled token IDs, one per sequence.
        logprobs: Optional log probabilities for each token.
    """
    if isinstance(sampled_token_ids, mx.array):
        sampled_token_ids = sampled_token_ids.tolist()

    if len(sampled_token_ids) != len(sequences):
        raise ValueError(
            f"Mismatch: {len(sampled_token_ids)} tokens for "
            f"{len(sequences)} sequences"
        )

    for i, (seq, token_id) in enumerate(zip(sequences, sampled_token_ids)):
        logprob = logprobs[i] if logprobs is not None else 0.0
        seq.data.append_token_id(token_id, logprob)


def merge_parallel_outputs(
    sequence_groups: list[SequenceGroup],
) -> SequenceGroup:
    """
    Merge multiple sequence groups into one with combined sequences.

    This is used when parallel sampling creates multiple sequence groups
    that need to be combined for output.

    Args:
        sequence_groups: List of sequence groups to merge.

    Returns:
        Merged sequence group containing all sequences.
    """
    if not sequence_groups:
        raise ValueError("Cannot merge empty list of sequence groups")

    if len(sequence_groups) == 1:
        return sequence_groups[0]

    # Use the first group as base
    base_group = sequence_groups[0]

    # Collect all sequences
    all_sequences = []
    for group in sequence_groups:
        all_sequences.extend(group.sequences)

    # Create merged group
    merged = copy.copy(base_group)
    merged.sequences = all_sequences

    return merged


class ParallelSamplingManager:
    """
    Manager for coordinating parallel sampling across multiple sequences.

    This class handles the orchestration of generating multiple sequences
    from the same prompt and selecting the best ones.
    """

    def __init__(self, config: ParallelSamplingConfig):
        """
        Initialize parallel sampling manager.

        Args:
            config: Parallel sampling configuration.
        """
        self.config = config
        self.config.validate()

    def should_use_parallel_sampling(self) -> bool:
        """Check if parallel sampling should be used."""
        return self.config.num_sequences_to_generate > 1

    def create_sequences(
        self,
        base_sequence: Sequence,
    ) -> list[Sequence]:
        """
        Create parallel sequences for generation.

        Args:
            base_sequence: Base sequence to copy from.

        Returns:
            List of parallel sequences.
        """
        return create_parallel_sequences(
            base_sequence,
            self.config.num_sequences_to_generate,
        )

    def select_final_sequences(
        self,
        sequences: list[Sequence],
        length_penalty: float = 1.0,
    ) -> list[Sequence]:
        """
        Select final sequences to return.

        Args:
            sequences: All generated sequences.
            length_penalty: Length penalty for scoring.

        Returns:
            Selected sequences (top n or all if return_all=True).
        """
        # If return_all is True, return everything
        if self.config.return_all:
            return sequences

        # If best_of was used, select top n by score
        if self.config.best_of is not None:
            return select_best_sequences(
                sequences,
                self.config.n,
                length_penalty,
            )

        # Otherwise, return first n sequences
        return sequences[:self.config.n]

    def sample_tokens(
        self,
        logits: mx.array,
        sampling_params: SamplingParams,
    ) -> mx.array:
        """
        Sample tokens for parallel sequences.

        Args:
            logits: Model logits.
            sampling_params: Sampling parameters.

        Returns:
            Sampled token IDs for each sequence.
        """
        return sample_parallel(
            logits,
            self.config.num_sequences_to_generate,
            sampling_params,
        )

    def __repr__(self) -> str:
        """String representation."""
        if self.config.best_of is not None:
            return (
                f"ParallelSamplingManager(generate={self.config.best_of}, "
                f"return={self.config.n})"
            )
        else:
            return f"ParallelSamplingManager(n={self.config.n})"


def get_parallel_sampling_config(
    sampling_params: SamplingParams,
) -> ParallelSamplingConfig | None:
    """
    Get parallel sampling configuration from sampling parameters.

    Args:
        sampling_params: Sampling parameters.

    Returns:
        ParallelSamplingConfig if parallel sampling is needed, None otherwise.
    """
    # Check if parallel sampling is needed
    if sampling_params.n <= 1 and sampling_params.best_of is None:
        return None

    return ParallelSamplingConfig.from_sampling_params(sampling_params)


def is_parallel_sampling_enabled(sampling_params: SamplingParams) -> bool:
    """
    Check if parallel sampling is enabled.

    Args:
        sampling_params: Sampling parameters.

    Returns:
        True if parallel sampling should be used.
    """
    return sampling_params.n > 1 or sampling_params.best_of is not None
