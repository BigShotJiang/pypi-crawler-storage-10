# SPDX-License-Identifier: Apache-2.0
"""Multi-worker coordinator for MLX-LLM.

This module coordinates multiple workers for distributed inference:
- Worker management
- Request distribution
- Result aggregation
- Load balancing

For M4 MacBook Pro, this is simplified for single-device operation.
Multi-chip support (M4 Max/Ultra) can be added later.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mlxllm.engine.core import EngineCore

logger = logging.getLogger(__name__)


class Coordinator:
    """
    Coordinator for multi-worker inference.

    For single-device M4 setup, this is a simple wrapper.
    Can be extended for multi-chip configurations.
    """

    def __init__(
        self,
        num_workers: int = 1,
    ) -> None:
        """
        Initialize coordinator.

        Args:
            num_workers: Number of worker processes (default 1 for M4).
        """
        self.num_workers = num_workers
        self.workers: list[EngineCore] = []

        logger.info(f"Coordinator initialized with {num_workers} workers")

    def add_worker(self, worker: EngineCore) -> None:
        """
        Add a worker to the coordinator.

        Args:
            worker: EngineCore worker instance.
        """
        if len(self.workers) >= self.num_workers:
            logger.warning(f"Maximum workers ({self.num_workers}) already added")
            return

        self.workers.append(worker)
        logger.debug(f"Added worker {len(self.workers)}/{self.num_workers}")

    def remove_worker(self, worker: EngineCore) -> None:
        """
        Remove a worker from the coordinator.

        Args:
            worker: Worker to remove.
        """
        if worker in self.workers:
            self.workers.remove(worker)
            logger.debug(f"Removed worker, {len(self.workers)} remaining")

    def get_worker(self, request_id: str | None = None) -> EngineCore | None:
        """
        Get a worker for a request.

        Args:
            request_id: Optional request ID for sticky routing.

        Returns:
            EngineCore worker or None if no workers available.
        """
        if not self.workers:
            logger.error("No workers available")
            return None

        # For single worker, always return it
        if len(self.workers) == 1:
            return self.workers[0]

        # For multiple workers, use simple round-robin
        # (Could implement more sophisticated load balancing)
        worker_idx = hash(request_id) % len(self.workers) if request_id else 0
        return self.workers[worker_idx]

    def broadcast_to_workers(self, method: str, *args, **kwargs) -> list:
        """
        Broadcast a method call to all workers.

        Args:
            method: Method name to call.
            *args: Positional arguments.
            **kwargs: Keyword arguments.

        Returns:
            List of results from each worker.
        """
        results = []

        for worker in self.workers:
            if hasattr(worker, method):
                result = getattr(worker, method)(*args, **kwargs)
                results.append(result)
            else:
                logger.warning(f"Worker does not have method: {method}")
                results.append(None)

        return results

    def get_worker_stats(self) -> list[dict]:
        """
        Get statistics from all workers.

        Returns:
            List of worker statistics dicts.
        """
        stats = []

        for i, worker in enumerate(self.workers):
            worker_stats = {
                "worker_id": i,
                "stats": worker.get_stats() if hasattr(worker, "get_stats") else {},
            }
            stats.append(worker_stats)

        return stats

    def shutdown(self) -> None:
        """Shutdown all workers."""
        logger.info("Shutting down coordinator and workers")
        self.workers.clear()

    def __repr__(self) -> str:
        """String representation."""
        return f"Coordinator(workers={len(self.workers)}/{self.num_workers})"


class SingleDeviceCoordinator(Coordinator):
    """
    Simplified coordinator for single-device operation.

    Optimized for M4 MacBook Pro with unified memory.
    """

    def __init__(self) -> None:
        """Initialize single-device coordinator."""
        super().__init__(num_workers=1)
        logger.info("SingleDeviceCoordinator initialized for M4 unified memory")

    def get_worker(self, request_id: str | None = None) -> EngineCore | None:
        """
        Get the single worker.

        Args:
            request_id: Ignored for single worker.

        Returns:
            The single worker or None.
        """
        return self.workers[0] if self.workers else None


class MultiChipCoordinator(Coordinator):
    """
    Coordinator for multi-chip Apple Silicon (M4 Max/Ultra).

    Distributes work across multiple GPU clusters.
    """

    def __init__(
        self,
        num_chips: int,
    ) -> None:
        """
        Initialize multi-chip coordinator.

        Args:
            num_chips: Number of chips (2 for M4 Max, 4 for M4 Ultra).
        """
        super().__init__(num_workers=num_chips)
        self.num_chips = num_chips

        logger.info(f"MultiChipCoordinator initialized for {num_chips} chips")

    def get_worker_for_chip(self, chip_id: int) -> EngineCore | None:
        """
        Get worker for specific chip.

        Args:
            chip_id: Chip ID (0-based).

        Returns:
            Worker for that chip or None.
        """
        if 0 <= chip_id < len(self.workers):
            return self.workers[chip_id]

        logger.error(f"Invalid chip_id: {chip_id}")
        return None

    def balance_load(self) -> None:
        """
        Balance load across chips.

        Redistributes requests based on worker utilization.
        """
        # Get stats from all workers
        stats = self.get_worker_stats()

        # Find imbalanced workers
        # (Simplified - real implementation would redistribute requests)
        for i, worker_stats in enumerate(stats):
            worker_info = worker_stats.get("stats", {})
            running = worker_info.get("num_requests_running", 0)
            waiting = worker_info.get("num_requests_waiting", 0)

            logger.debug(f"Chip {i}: running={running}, waiting={waiting}")

        # TODO: Implement actual load balancing logic
