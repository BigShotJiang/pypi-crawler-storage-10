# SPDX-License-Identifier: Apache-2.0
"""Log probability computation and utilities for MLX-LLM.

This module provides utilities for computing and managing log probabilities
during token generation, including prompt logprobs and output token logprobs.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import mlx.core as mx


@dataclass
class Logprob:
    """Log probability information for a single token."""

    logprob: float
    """Log probability of the token."""

    rank: int | None = None
    """Rank of this token in the distribution (1 = most likely)."""

    decoded_token: str | None = None
    """Decoded string representation of the token."""


@dataclass
class PromptLogprobs:
    """Log probabilities for prompt tokens."""

    token_ids: list[int]
    """Token IDs in the prompt."""

    token_logprobs: list[float | None]
    """Log probability for each token (None for first token)."""

    top_logprobs: list[dict[int, Logprob]] | None = None
    """Top-k log probabilities for each token position."""


def compute_logprobs(
    logits: mx.array,
    token_ids: mx.array,
    num_logprobs: int = 0,
) -> tuple[mx.array, list[dict[int, Logprob]] | None]:
    """
    Compute log probabilities for given tokens.

    Args:
        logits: Raw logits from model (batch_size, vocab_size) or (vocab_size,).
        token_ids: Token IDs to compute logprobs for (batch_size,) or scalar.
        num_logprobs: Number of top logprobs to return for each position.

    Returns:
        Tuple of:
            - Log probabilities for the given tokens
            - Top-k logprobs dict (if num_logprobs > 0), otherwise None
    """
    # Ensure logits is 2D (batch_size, vocab_size)
    if logits.ndim == 1:
        logits = mx.expand_dims(logits, axis=0)

    # Compute log probabilities
    log_probs = mx.log_softmax(logits, axis=-1)

    # Handle scalar token_ids
    if isinstance(token_ids, int):
        token_ids = mx.array([token_ids])
    elif token_ids.ndim == 0:
        token_ids = mx.expand_dims(token_ids, axis=0)

    # Get logprobs for specific tokens
    batch_size = log_probs.shape[0]
    batch_indices = mx.arange(batch_size)

    # Gather logprobs for the selected tokens
    selected_logprobs = log_probs[batch_indices, token_ids]

    # Optionally compute top-k logprobs
    top_logprobs_list = None
    if num_logprobs > 0:
        top_logprobs_list = []

        for i in range(batch_size):
            # Get top-k values and indices
            top_k = min(num_logprobs, log_probs.shape[-1])
            top_values, top_indices = mx.topk(log_probs[i], k=top_k)

            # Convert to dictionary
            top_dict = {}
            for rank, (idx, val) in enumerate(zip(top_indices, top_values), start=1):
                token_id = int(idx)
                logprob_val = float(val)
                top_dict[token_id] = Logprob(
                    logprob=logprob_val,
                    rank=rank,
                )

            top_logprobs_list.append(top_dict)

    return selected_logprobs, top_logprobs_list


def compute_prompt_logprobs(
    all_logits: list[mx.array],
    prompt_token_ids: list[int],
    num_logprobs: int = 0,
) -> PromptLogprobs:
    """
    Compute log probabilities for prompt tokens.

    Args:
        all_logits: List of logits for each prompt position.
        prompt_token_ids: Token IDs in the prompt.
        num_logprobs: Number of top logprobs to return per position.

    Returns:
        PromptLogprobs containing logprobs for all prompt tokens.
    """
    if not all_logits:
        return PromptLogprobs(
            token_ids=prompt_token_ids,
            token_logprobs=[None] * len(prompt_token_ids),
            top_logprobs=None,
        )

    token_logprobs: list[float | None] = [None]  # First token has no logprob
    top_logprobs_list: list[dict[int, Logprob]] = [{}]  # Empty for first token

    # Compute logprobs for tokens 1 onwards
    for i, (logits, token_id) in enumerate(zip(all_logits[:-1], prompt_token_ids[1:])):
        logprob, top_logprobs = compute_logprobs(
            logits,
            mx.array([token_id]),
            num_logprobs=num_logprobs,
        )

        token_logprobs.append(float(logprob[0]))

        if top_logprobs:
            top_logprobs_list.append(top_logprobs[0])
        else:
            top_logprobs_list.append({})

    return PromptLogprobs(
        token_ids=prompt_token_ids,
        token_logprobs=token_logprobs,
        top_logprobs=top_logprobs_list if num_logprobs > 0 else None,
    )


def get_token_logprob(
    logits: mx.array,
    token_id: int,
) -> float:
    """
    Get log probability for a specific token.

    Args:
        logits: Raw logits (vocab_size,) or (batch_size, vocab_size).
        token_id: Token ID to get logprob for.

    Returns:
        Log probability of the token.
    """
    if logits.ndim == 1:
        log_probs = mx.log_softmax(logits)
        return float(log_probs[token_id])
    else:
        # Assume batch_size=1
        log_probs = mx.log_softmax(logits[0])
        return float(log_probs[token_id])


def get_top_k_logprobs(
    logits: mx.array,
    k: int = 5,
) -> dict[int, float]:
    """
    Get top-k log probabilities.

    Args:
        logits: Raw logits (vocab_size,) or (batch_size, vocab_size).
        k: Number of top logprobs to return.

    Returns:
        Dictionary mapping token IDs to log probabilities.
    """
    if logits.ndim == 2:
        logits = logits[0]  # Assume batch_size=1

    log_probs = mx.log_softmax(logits)

    # Get top-k
    top_k = min(k, len(log_probs))
    top_values, top_indices = mx.topk(log_probs, k=top_k)

    # Convert to dict
    result = {}
    for idx, val in zip(top_indices, top_values):
        result[int(idx)] = float(val)

    return result


class LogprobsTracker:
    """
    Track log probabilities during generation.

    This class maintains log probabilities for both prompt and generated tokens,
    supporting streaming generation and incremental updates.
    """

    def __init__(self, num_logprobs: int = 0):
        """
        Initialize logprobs tracker.

        Args:
            num_logprobs: Number of top logprobs to track per token.
        """
        self.num_logprobs = num_logprobs
        self.token_logprobs: list[float] = []
        self.top_logprobs: list[dict[int, Logprob]] = []
        self.cumulative_logprob: float = 0.0

    def add_token_logprob(
        self,
        logits: mx.array,
        token_id: int,
    ) -> None:
        """
        Add log probability for a new token.

        Args:
            logits: Raw logits before sampling.
            token_id: Sampled token ID.
        """
        logprob, top_logprobs = compute_logprobs(
            logits,
            mx.array([token_id]),
            num_logprobs=self.num_logprobs,
        )

        token_logprob = float(logprob[0])
        self.token_logprobs.append(token_logprob)
        self.cumulative_logprob += token_logprob

        if top_logprobs:
            self.top_logprobs.append(top_logprobs[0])
        else:
            self.top_logprobs.append({})

    def get_logprobs(self) -> list[float]:
        """Get all token log probabilities."""
        return self.token_logprobs

    def get_top_logprobs(self) -> list[dict[int, Logprob]]:
        """Get top-k logprobs for all tokens."""
        return self.top_logprobs

    def get_cumulative_logprob(self) -> float:
        """Get cumulative log probability."""
        return self.cumulative_logprob

    def reset(self) -> None:
        """Reset all tracked logprobs."""
        self.token_logprobs.clear()
        self.top_logprobs.clear()
        self.cumulative_logprob = 0.0


def format_logprobs_for_output(
    token_ids: list[int],
    logprobs_tracker: LogprobsTracker,
    tokenizer: Any = None,
) -> list[dict[int, Any]]:
    """
    Format log probabilities for API output.

    Args:
        token_ids: Generated token IDs.
        logprobs_tracker: Tracker with accumulated logprobs.
        tokenizer: Optional tokenizer for decoding tokens.

    Returns:
        List of dicts with logprob information per token.
    """
    result = []

    token_logprobs = logprobs_tracker.get_logprobs()
    top_logprobs = logprobs_tracker.get_top_logprobs()

    for i, (token_id, logprob) in enumerate(zip(token_ids, token_logprobs)):
        entry: dict[int, Any] = {
            "token_id": token_id,
            "logprob": logprob,
        }

        if tokenizer is not None:
            entry["token"] = tokenizer.decode([token_id])

        if i < len(top_logprobs) and top_logprobs[i]:
            # Format top logprobs
            top_dict = {}
            for tid, lp in top_logprobs[i].items():
                top_dict[tid] = {
                    "logprob": lp.logprob,
                    "rank": lp.rank,
                }
                if tokenizer is not None:
                    top_dict[tid]["token"] = tokenizer.decode([tid])

            entry["top_logprobs"] = top_dict

        result.append(entry)

    return result
