# SPDX-License-Identifier: Apache-2.0
"""Backward compatibility linter for MLX-LLM.

This module provides utilities to check for breaking changes and deprecated
APIs, helping users migrate between versions.
"""

from __future__ import annotations

import warnings
from typing import Any, Callable


class DeprecationRegistry:
    """Registry for deprecated APIs and their replacements."""

    def __init__(self):
        """Initialize deprecation registry."""
        self._deprecated: dict[str, tuple[str, str]] = {}
        # Format: {old_name: (new_name, version_deprecated)}

    def register(
        self,
        old_name: str,
        new_name: str,
        version: str = "0.2.0",
    ) -> None:
        """
        Register a deprecated API.

        Args:
            old_name: Old API name.
            new_name: New API name.
            version: Version where deprecation occurred.
        """
        self._deprecated[old_name] = (new_name, version)

    def check(self, name: str) -> tuple[str, str] | None:
        """
        Check if an API is deprecated.

        Args:
            name: API name to check.

        Returns:
            Tuple of (new_name, version) if deprecated, None otherwise.
        """
        return self._deprecated.get(name)

    def warn_if_deprecated(self, name: str) -> None:
        """
        Issue a warning if API is deprecated.

        Args:
            name: API name to check.
        """
        deprecated_info = self.check(name)
        if deprecated_info:
            new_name, version = deprecated_info
            warnings.warn(
                f"'{name}' is deprecated since version {version}. "
                f"Use '{new_name}' instead.",
                DeprecationWarning,
                stacklevel=3,
            )


# Global registry
_global_deprecation_registry = DeprecationRegistry()


def deprecated(
    old_name: str,
    new_name: str,
    version: str = "0.2.0",
) -> Callable[[Callable], Callable]:
    """
    Decorator to mark a function as deprecated.

    Args:
        old_name: Old function name.
        new_name: New function name to use instead.
        version: Version where deprecation occurred.

    Returns:
        Decorator function.
    """

    def decorator(func: Callable) -> Callable:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            warnings.warn(
                f"'{old_name}' is deprecated since version {version}. "
                f"Use '{new_name}' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            return func(*args, **kwargs)

        return wrapper

    return decorator


def check_deprecated(name: str) -> None:
    """
    Check if an API is deprecated and warn if so.

    Args:
        name: API name to check.
    """
    _global_deprecation_registry.warn_if_deprecated(name)


# Register known deprecations
_global_deprecation_registry.register(
    "MLXEngine", "LLMEngine", "0.2.0"
)
