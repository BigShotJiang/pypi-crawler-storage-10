# SPDX-License-Identifier: Apache-2.0
"""CLI scripts and entry points for MLX-LLM.

This module provides command-line interfaces for running MLX-LLM inference,
benchmarking, and utilities.
"""

from __future__ import annotations

import argparse
import sys
from typing import Any


def main_generate() -> None:
    """Main entry point for text generation CLI."""
    parser = argparse.ArgumentParser(description="MLX-LLM Text Generation")
    parser.add_argument("--model", type=str, required=True, help="Model path or ID")
    parser.add_argument("--prompt", type=str, required=True, help="Input prompt")
    parser.add_argument("--max-tokens", type=int, default=100, help="Max tokens to generate")
    parser.add_argument("--temperature", type=float, default=0.7, help="Sampling temperature")
    parser.add_argument("--top-p", type=float, default=0.9, help="Nucleus sampling threshold")
    parser.add_argument("--quantization", type=str, default="", help="Quantization type")

    args = parser.parse_args()

    try:
        from mlxllm.engine.llm_engine import EngineArgs, LLMEngine
        from mlxllm.sampling_params import SamplingParams

        # Create engine
        engine_args = EngineArgs(
            model=args.model,
            quantization=args.quantization if args.quantization else None,
        )
        engine = engine_args.create_engine()

        # Generate
        sampling_params = SamplingParams(
            temperature=args.temperature,
            top_p=args.top_p,
            max_tokens=args.max_tokens,
        )

        outputs = engine.generate(prompts=[args.prompt], sampling_params=sampling_params)

        # Print result
        for output in outputs:
            print(f"\nPrompt: {args.prompt}")
            print(f"Generated: {output.outputs[0].text}")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def main_benchmark() -> None:
    """Main entry point for benchmarking CLI."""
    parser = argparse.ArgumentParser(description="MLX-LLM Benchmark")
    parser.add_argument("--model", type=str, required=True, help="Model path or ID")
    parser.add_argument("--num-prompts", type=int, default=10, help="Number of prompts")
    parser.add_argument("--prompt-len", type=int, default=128, help="Prompt length")
    parser.add_argument("--output-len", type=int, default=100, help="Output length")
    parser.add_argument("--quantization", type=str, default="", help="Quantization type")

    args = parser.parse_args()

    try:
        import time

        from mlxllm.engine.llm_engine import EngineArgs, LLMEngine
        from mlxllm.sampling_params import SamplingParams

        # Create engine
        engine_args = EngineArgs(
            model=args.model,
            quantization=args.quantization if args.quantization else None,
        )
        engine = engine_args.create_engine()

        # Generate dummy prompts
        prompts = [f"Test prompt {i}: " + "word " * args.prompt_len for i in range(args.num_prompts)]

        sampling_params = SamplingParams(
            temperature=0.7,
            max_tokens=args.output_len,
        )

        # Benchmark
        start_time = time.perf_counter()
        outputs = engine.generate(prompts=prompts, sampling_params=sampling_params)
        end_time = time.perf_counter()

        # Calculate metrics
        total_time = end_time - start_time
        total_tokens = sum(len(out.outputs[0].token_ids) for out in outputs)
        throughput = total_tokens / total_time

        print(f"\nBenchmark Results:")
        print(f"  Total Time: {total_time:.2f} sec")
        print(f"  Total Tokens: {total_tokens}")
        print(f"  Throughput: {throughput:.2f} tokens/sec")
        print(f"  Requests: {len(outputs)}")

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def main_env_info() -> None:
    """Main entry point for environment info CLI."""
    try:
        from mlxllm.collect_env import print_env_info

        print_env_info()

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python -m mlxllm.scripts <command>")
        print("Commands: generate, benchmark, env-info")
        sys.exit(1)

    command = sys.argv[1]
    sys.argv = sys.argv[1:]  # Remove command from args

    if command == "generate":
        main_generate()
    elif command == "benchmark":
        main_benchmark()
    elif command == "env-info":
        main_env_info()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
