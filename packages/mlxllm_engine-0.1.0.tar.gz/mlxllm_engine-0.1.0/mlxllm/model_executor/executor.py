# SPDX-License-Identifier: Apache-2.0
"""Model executor for MLX-LLM.

The model executor handles:
- Model initialization and loading
- Forward pass coordination
- KV cache updates
- Sampling
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

import mlx.core as mx
import mlx.nn as nn

# Import at module level so it can be patched in tests
from mlxllm.model_executor.model_loader import load_model

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.sequence import SequenceGroup
    from mlxllm.tokenization import Tokenizer

logger = logging.getLogger(__name__)


class ModelExecutor:
    """
    Executes model forward passes and manages model state.

    Handles:
    - Model initialization
    - Prefill and decode phases
    - KV cache coordination
    - Token sampling
    """

    def __init__(
        self,
        model_config: ModelConfig,
        kv_cache_manager: KVCacheManager,
        tokenizer: Tokenizer,
    ) -> None:
        """
        Initialize model executor.

        Args:
            model_config: Model configuration.
            kv_cache_manager: KV cache manager instance.
            tokenizer: Tokenizer instance.
        """
        self.model_config = model_config
        self.kv_cache_manager = kv_cache_manager
        self.tokenizer = tokenizer

        # Model will be loaded lazily
        self.model: nn.Module | None = None

        # Statistics
        self.num_prefill_tokens = 0
        self.num_decode_tokens = 0

    def load_model(self) -> None:
        """
        Load the model from disk.

        This uses the model loader to load weights and initialize the model.
        """
        logger.info(f"Loading model: {self.model_config.model_name}")

        # Load weights first if path specified (to detect bias before model creation)
        weights = None
        if self.model_config.model_path and isinstance(self.model_config.model_path, (str, bytes, os.PathLike)):
            from mlxllm.model_executor.model_loader.weight_utils import (
                load_safetensors_weights,
            )

            logger.info(f"Loading weights from: {self.model_config.model_path}")

            # Load and dequantize weights
            weights = load_safetensors_weights(
                self.model_config.model_path,
                dequantize=True,  # Dequantize quantized weights to FP16
            )

            # Auto-detect attention bias from weights
            has_attention_bias = any('.qkv_proj.bias' in k for k in weights.keys())
            if has_attention_bias and not getattr(self.model_config, 'attention_bias', False):
                logger.info("Detected attention bias in weights, updating model config")
                self.model_config.attention_bias = True

        # Create model architecture (now with correct bias setting)
        # Temporarily clear model_path to prevent load_model() from loading weights
        # (we'll load them manually below with strict=False)
        original_model_path = self.model_config.model_path
        self.model_config.model_path = None
        self.model = load_model(
            model_config=self.model_config,
        )
        self.model_config.model_path = original_model_path

        # Apply weights if loaded
        if weights is not None:
            logger.info(f"Applying {len(weights)} weight tensors to model")
            try:
                # Get model parameters to compare
                # MLX uses parameters() not named_parameters()
                from mlx.utils import tree_flatten
                model_params = dict(tree_flatten(self.model.parameters()))

                # Log weight mapping details
                logger.info(f"Model expects {len(model_params)} parameters")
                logger.info(f"Loaded {len(weights)} weight tensors")

                # Find mismatches
                loaded_keys = set(weights.keys())
                model_keys = set(model_params.keys())

                missing_in_weights = model_keys - loaded_keys
                extra_in_weights = loaded_keys - model_keys

                # Filter out parameters that are computed or optional
                optional_patterns = [
                    'rotary_emb.inv_freq',  # Computed from config
                    'rotary_emb.cos_cached',  # Computed caches
                    'rotary_emb.sin_cached',  # Computed caches
                    '.bias',  # Optional biases
                ]
                critical_missing = [
                    k for k in missing_in_weights
                    if not any(pattern in k for pattern in optional_patterns)
                ]

                if critical_missing:
                    logger.warning(f"Missing {len(critical_missing)} critical parameters in loaded weights:")
                    for i, key in enumerate(sorted(critical_missing)[:10]):
                        logger.warning(f"  - {key}")
                    if len(critical_missing) > 10:
                        logger.warning(f"  ... and {len(critical_missing) - 10} more")

                if len(missing_in_weights) > len(critical_missing):
                    logger.info(f"({len(missing_in_weights) - len(critical_missing)} optional/computed parameters not in weights - this is normal)")

                if extra_in_weights:
                    logger.warning(f"Found {len(extra_in_weights)} extra parameters not in model:")
                    for i, key in enumerate(sorted(extra_in_weights)[:10]):
                        logger.warning(f"  + {key}")
                    if len(extra_in_weights) > 10:
                        logger.warning(f"  ... and {len(extra_in_weights) - 10} more")

                # Use strict=False to allow model parameters not present in weights
                # (e.g., rotary_emb cached values, optional biases like o_proj.bias)
                logger.info(f"Calling model.update() with {len(weights)} weights and strict=False")
                self.model.update(weights, strict=False)
                logger.info("Weights loaded and applied successfully!")

                # Validate critical weights were loaded
                self._validate_model_weights()

            except Exception as e:
                logger.error(f"Failed to apply weights: {e}")
                logger.warning("Some weights may not match - continuing with partial load")
                # Continue anyway - the model might still partially work
                raise
        else:
            logger.warning(
                "No model_path specified - model initialized with random weights"
            )

        logger.info(f"Model loaded successfully: {type(self.model).__name__}")

        # Ensure model is in eval mode
        if hasattr(self.model, "eval"):
            self.model.eval()

    def _validate_model_weights(self) -> None:
        """
        Validate that critical model weights were loaded correctly.

        Raises:
            ValueError: If critical weights are missing.
        """
        logger.info("Validating model weights...")

        # Get all parameter names
        try:
            from mlx.utils import tree_flatten
            model_params = dict(tree_flatten(self.model.parameters()))
        except Exception as e:
            # Model might not have parameters, skip validation
            logger.warning(f"Could not get model parameters: {e}, skipping validation")
            return

        # Check critical weight keys
        # Note: Some keys may have nested structure (e.g., down_proj.linear.linear.weight)
        critical_keys = [
            "model.embed_tokens.weight",
            "model.layers.0.self_attn.qkv_proj",  # Check prefix (may be qkv_proj.weight or qkv_proj.linear.weight)
            "model.layers.0.mlp.gate_up_proj",  # Check prefix
            "model.layers.0.mlp.down_proj",  # Check prefix
        ]

        # Try to find lm_head (might be named differently)
        lm_head_found = any('lm_head' in k or 'head' in k for k in model_params.keys())

        missing_keys = []
        for key in critical_keys:
            # Check if key exists (exact match) or as a prefix (for nested structures)
            key_found = key in model_params or any(k.startswith(key + ".") for k in model_params)
            if not key_found:
                missing_keys.append(key)

        if missing_keys:
            logger.error(f"Missing critical weights: {missing_keys}")
            raise ValueError(f"Critical weights not loaded: {missing_keys}")

        if not lm_head_found:
            logger.warning("lm_head weight not found in model parameters")

        logger.info(f"✓ Validation passed: {len(model_params)} parameters loaded")
        logger.info(f"  Embedding: {'model.embed_tokens.weight' in model_params}")
        logger.info(f"  Attention: {sum(1 for k in model_params if 'self_attn' in k)} params")
        logger.info(f"  MLP: {sum(1 for k in model_params if 'mlp' in k)} params")

    def execute_prefill(
        self,
        sequence_groups: list[SequenceGroup],
    ) -> dict[str, Any]:
        """
        Execute prefill phase for sequence groups.

        Args:
            sequence_groups: Sequence groups to prefill.

        Returns:
            Dict with:
                - logits: Generated logits [batch_size, vocab_size]
                - kv_cache: Updated KV cache
        """
        if self.model is None:
            self.load_model()

        # Prepare inputs
        input_ids, positions, block_tables, seq_lens = self._prepare_inputs(
            sequence_groups,
            is_prefill=True,
        )

        # Create attention metadata
        attn_metadata = self._create_attention_metadata(
            block_tables=block_tables,
            seq_lens=seq_lens,
            is_prefill=True,
        )

        # Forward pass - use plural kv_caches and attn_metadata
        logits = self.model(
            input_ids=input_ids,
            positions=positions,
            kv_caches=None,  # Will be populated by model during forward
            attn_metadata=attn_metadata,
        )

        # Update statistics
        self.num_prefill_tokens += input_ids.size

        return {
            "logits": logits,
            "kv_cache": self.kv_cache_manager.get_kv_cache(),
        }

    def execute_decode(
        self,
        sequence_groups: list[SequenceGroup],
    ) -> dict[str, Any]:
        """
        Execute decode phase for sequence groups.

        Args:
            sequence_groups: Sequence groups to decode.

        Returns:
            Dict with:
                - logits: Generated logits [batch_size, vocab_size]
                - kv_cache: Updated KV cache
        """
        if self.model is None:
            self.load_model()

        # Prepare inputs
        input_ids, positions, block_tables, seq_lens = self._prepare_inputs(
            sequence_groups,
            is_prefill=False,
        )

        # Create attention metadata
        attn_metadata = self._create_attention_metadata(
            block_tables=block_tables,
            seq_lens=seq_lens,
            is_prefill=False,
        )

        # Forward pass - use plural kv_caches and attn_metadata
        logits = self.model(
            input_ids=input_ids,
            positions=positions,
            kv_caches=None,  # Will be populated by model during forward
            attn_metadata=attn_metadata,
        )

        # Update statistics
        self.num_decode_tokens += input_ids.size

        return {
            "logits": logits,
            "kv_cache": self.kv_cache_manager.get_kv_cache(),
        }

    def _prepare_inputs(
        self,
        sequence_groups: list[SequenceGroup],
        is_prefill: bool,
    ) -> tuple[mx.array, mx.array, list[list[int]], list[int]]:
        """
        Prepare model inputs from sequence groups.

        Args:
            sequence_groups: Sequence groups to prepare.
            is_prefill: Whether this is prefill phase.

        Returns:
            Tuple of (input_ids, positions, block_tables, seq_lens).
        """
        input_ids_list = []
        positions_list = []
        block_tables_list = []
        seq_lens_list = []

        for seq_group in sequence_groups:
            for seq in seq_group.sequences:
                if is_prefill:
                    # Prefill: use all prompt tokens
                    token_ids = seq.data.prompt_token_ids if hasattr(seq, 'data') else seq.token_ids
                    input_ids_list.extend(token_ids)
                    positions_list.extend(list(range(len(token_ids))))
                    seq_lens_list.append(len(token_ids))
                else:
                    # Decode: use only last token
                    token_ids = seq.data.get_token_ids() if hasattr(seq, 'data') else seq.token_ids
                    input_ids_list.append(token_ids[-1])
                    positions_list.append(len(token_ids) - 1)
                    seq_lens_list.append(len(token_ids))

                # Get block table for this sequence
                block_table = self.kv_cache_manager.get_block_table(seq.seq_id)
                block_tables_list.append(block_table)

        # Convert to MLX arrays
        input_ids = mx.array(input_ids_list, dtype=mx.int32)
        positions = mx.array(positions_list, dtype=mx.int32)

        return input_ids, positions, block_tables_list, seq_lens_list

    def _create_attention_metadata(
        self,
        block_tables: list[list[int]],
        seq_lens: list[int],
        is_prefill: bool,
    ) -> "AttentionMetadata":
        """
        Create AttentionMetadata from prepared inputs.

        Args:
            block_tables: Block tables for each sequence.
            seq_lens: Sequence lengths.
            is_prefill: Whether this is prefill phase.

        Returns:
            AttentionMetadata for attention computation.
        """
        from mlxllm.attention.backends.abstract import AttentionMetadata, AttentionType

        # Determine attention type
        attn_type = AttentionType.PREFILL if is_prefill else AttentionType.DECODE

        # For decode, context_lens is the full sequence length
        context_lens = seq_lens if not is_prefill else None

        # Calculate max sequence length
        max_seq_len = max(seq_lens) if seq_lens else 0

        # Create metadata
        metadata = AttentionMetadata(
            attn_type=attn_type,
            seq_lens=seq_lens,
            max_seq_len=max_seq_len,
            block_tables=block_tables if not is_prefill else None,
            context_lens=context_lens,
            num_query_heads=self.model_config.num_attention_heads or 0,
            num_kv_heads=self.model_config.num_kv_heads or self.model_config.num_attention_heads or 0,
            head_dim=self.model_config.head_dim or 0,
            block_size=16,  # Standard block size
            scale=1.0 / (self.model_config.head_dim ** 0.5) if self.model_config.head_dim else 1.0,
            is_prefill=is_prefill,
            batch_size=len(seq_lens),
        )

        return metadata

    def sample_tokens(
        self,
        logits: mx.array,
        sequence_groups: list[SequenceGroup],
    ) -> list[int]:
        """
        Sample next tokens from logits.

        Args:
            logits: Model output logits [batch_size, vocab_size].
            sequence_groups: Corresponding sequence groups.

        Returns:
            List of sampled token IDs.
        """
        sampled_tokens = []

        for i, seq_group in enumerate(sequence_groups):
            # Get sampling params
            sampling_params = seq_group.sampling_params

            # Get logits for this sequence
            seq_logits = logits[i]

            # Apply temperature
            if sampling_params.temperature > 0:
                seq_logits = seq_logits / sampling_params.temperature

            # Sample token
            if sampling_params.temperature == 0:
                # Greedy sampling
                token_id_array = mx.argmax(seq_logits)
                token_id = int(token_id_array.item())
            else:
                # Multinomial sampling
                probs = mx.softmax(seq_logits, axis=-1)
                token_id_array = mx.random.categorical(probs)
                token_id = int(token_id_array.item())

            # Validate token ID is in valid range
            if not (0 <= token_id < self.model_config.vocab_size):
                logger.error(
                    f"Invalid token_id: {token_id}, vocab_size: {self.model_config.vocab_size}. "
                    f"Using EOS token instead."
                )
                # Fall back to EOS token
                token_id = getattr(self.tokenizer, 'eos_token_id', 0) if self.tokenizer else 0

            sampled_tokens.append(token_id)

        return sampled_tokens

    def get_stats(self) -> dict[str, Any]:
        """
        Get executor statistics.

        Returns:
            Dict with statistics.
        """
        return {
            "num_prefill_tokens": self.num_prefill_tokens,
            "num_decode_tokens": self.num_decode_tokens,
            "total_tokens": self.num_prefill_tokens + self.num_decode_tokens,
        }
