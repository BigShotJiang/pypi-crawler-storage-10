# SPDX-License-Identifier: Apache-2.0
"""MLX-LLM model executor layers.

This package provides all the building blocks for transformer-based language models:
- Attention mechanisms (standard, MLA, lightning, etc.)
- Normalization layers (RMSNorm, LayerNorm)
- Activation functions (SiLU, GELU, SwiGLU, etc.)
- Linear layers with quantization support
- Position embeddings (RoPE)
- Pooling and resampling layers
- Specialized layers (Mamba, FusedMoE, multimodal)
"""

from __future__ import annotations

# Core layers
from .activation import (
    GELU,
    FastGELU,
    GeGLU,
    NewGELU,
    QuickGELU,
    ReLU,
    SiLU,
    SwiGLU,
    get_activation,
)
from .attention_layer_base import AttentionLayerBase, MultiHeadAttention
from .batch_invariant import (
    BatchInvariantLayerNorm,
    BatchInvariantLinear,
    BatchInvariantNorm,
    batch_invariant_dropout,
    ensure_batch_invariant,
)
from .layernorm import (
    FusedRMSNorm,
    GroupNorm,
    LayerNorm,
    RMSNorm,
    get_norm_layer,
)
from .lightning_attn import LightningAttention, LinearAttention
from .linear import (
    ColumnParallelLinear,
    LinearBase,
    MergedColumnParallelLinear,
    QKVParallelLinear,
    QuantizedLinear,
    RowParallelLinear,
    UnquantizedLinear,
)
from .logits_processor import (
    FrequencyPenaltyLogitsProcessor,
    LogitsProcessor,
    LogitsProcessorList,
    PresencePenaltyLogitsProcessor,
    RepetitionPenaltyLogitsProcessor,
    TemperatureLogitsProcessor,
    TopKLogitsProcessor,
    TopPLogitsProcessor,
)
from .mla import MLADecoderLayer, MultiHeadLatentAttention
from .pooler import (
    AdaptivePooler,
    AttentionPooler,
    BertPooler,
    Pooler,
    weighted_pooling,
)
from .resampler import (
    PerceiverResampler,
    Resampler,
    ResamplerLayer,
    SimpleResampler,
)
from .rotary_embedding import (
    DynamicRoPEScaling,
    LinearRoPEScaling,
    RotaryEmbedding,
    create_rotary_embedding,
)
from .utils import (
    apply_rotary_pos_emb,
    cast_if_needed,
    compute_position_ids,
    create_causal_mask,
    create_padding_mask,
    fused_add_rms_norm,
    get_activation_fn,
    get_dtype_from_str,
    repeat_kv,
    scaled_dot_product_attention,
    slice_tensor,
)
from .vocab_parallel_embedding import (
    Embedding,
    VocabParallelEmbedding,
    gather_from_shards,
)

__all__ = [
    # Activations
    "GELU",
    "FastGELU",
    "GeGLU",
    "NewGELU",
    "QuickGELU",
    "ReLU",
    "SiLU",
    "SwiGLU",
    "get_activation",
    # Attention
    "AttentionLayerBase",
    "MultiHeadAttention",
    "LightningAttention",
    "LinearAttention",
    "MultiHeadLatentAttention",
    "MLADecoderLayer",
    # Batch invariant
    "BatchInvariantLayerNorm",
    "BatchInvariantLinear",
    "BatchInvariantNorm",
    "batch_invariant_dropout",
    "ensure_batch_invariant",
    # Normalization
    "FusedRMSNorm",
    "GroupNorm",
    "LayerNorm",
    "RMSNorm",
    "get_norm_layer",
    # Linear
    "ColumnParallelLinear",
    "LinearBase",
    "MergedColumnParallelLinear",
    "QKVParallelLinear",
    "QuantizedLinear",
    "RowParallelLinear",
    "UnquantizedLinear",
    # Logits processing
    "FrequencyPenaltyLogitsProcessor",
    "LogitsProcessor",
    "LogitsProcessorList",
    "PresencePenaltyLogitsProcessor",
    "RepetitionPenaltyLogitsProcessor",
    "TemperatureLogitsProcessor",
    "TopKLogitsProcessor",
    "TopPLogitsProcessor",
    # Pooling
    "AdaptivePooler",
    "AttentionPooler",
    "BertPooler",
    "Pooler",
    "weighted_pooling",
    # Resampling
    "PerceiverResampler",
    "Resampler",
    "ResamplerLayer",
    "SimpleResampler",
    # Position embeddings
    "DynamicRoPEScaling",
    "LinearRoPEScaling",
    "RotaryEmbedding",
    "create_rotary_embedding",
    # Embeddings
    "Embedding",
    "VocabParallelEmbedding",
    "gather_from_shards",
    # Utilities
    "apply_rotary_pos_emb",
    "cast_if_needed",
    "compute_position_ids",
    "create_causal_mask",
    "create_padding_mask",
    "fused_add_rms_norm",
    "get_activation_fn",
    "get_dtype_from_str",
    "repeat_kv",
    "scaled_dot_product_attention",
    "slice_tensor",
]
