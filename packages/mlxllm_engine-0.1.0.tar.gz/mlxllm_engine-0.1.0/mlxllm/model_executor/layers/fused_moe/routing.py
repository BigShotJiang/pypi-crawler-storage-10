# SPDX-License-Identifier: Apache-2.0
"""Expert routing mechanisms for MoE layers.

Implements various routing strategies for distributing tokens to experts.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class TopKRouter(nn.Module):
    """
    Top-K expert router.

    Routes each token to the top-K experts based on learned routing weights.
    Used in Mixtral and most modern MoE models.
    """

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        top_k: int = 2,
        **kwargs: Any,
    ):
        """
        Initialize Top-K router.

        Args:
            hidden_size: Input dimension.
            num_experts: Number of experts.
            top_k: Number of experts to select per token.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.top_k = top_k

        # Router linear layer
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

    def __call__(
        self,
        hidden_states: mx.array,
    ) -> tuple[mx.array, mx.array, mx.array]:
        """
        Route tokens to top-K experts.

        Args:
            hidden_states: Input tensor (num_tokens, hidden_size).

        Returns:
            Tuple of (router_logits, selected_experts, router_weights):
            - router_logits: (num_tokens, num_experts)
            - selected_experts: (num_tokens, top_k) - expert indices
            - router_weights: (num_tokens, top_k) - normalized weights
        """
        # Compute routing logits
        router_logits = self.gate(hidden_states)  # (num_tokens, num_experts)

        # Get top-K experts (MLX uses topk, not top_k)
        top_k_indices = mx.argpartition(router_logits, kth=-self.top_k, axis=-1)[:, -self.top_k:]
        top_k_logits = mx.take_along_axis(router_logits, top_k_indices, axis=-1)

        # Softmax over top-K to get normalized weights
        router_weights = mx.softmax(top_k_logits, axis=-1)

        return router_logits, top_k_indices, router_weights


class SwitchRouter(nn.Module):
    """
    Switch router (top-1 routing).

    Routes each token to a single expert (k=1).
    Simpler and more efficient than top-K routing.

    Reference: "Switch Transformers: Scaling to Trillion Parameter Models"
    """

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        jitter_noise: float = 0.0,
        **kwargs: Any,
    ):
        """
        Initialize Switch router.

        Args:
            hidden_size: Input dimension.
            num_experts: Number of experts.
            jitter_noise: Amount of jitter noise for load balancing.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.jitter_noise = jitter_noise

        # Router linear layer
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

    def __call__(
        self,
        hidden_states: mx.array,
        training: bool = False,
    ) -> tuple[mx.array, mx.array, mx.array]:
        """
        Route tokens to single expert.

        Args:
            hidden_states: Input tensor (num_tokens, hidden_size).
            training: Whether in training mode (for jitter).

        Returns:
            Tuple of (router_logits, selected_experts, router_weights).
        """
        # Compute routing logits
        router_logits = self.gate(hidden_states)  # (num_tokens, num_experts)

        # Add jitter noise during training for load balancing
        if training and self.jitter_noise > 0:
            noise = mx.random.uniform(
                low=-self.jitter_noise,
                high=self.jitter_noise,
                shape=router_logits.shape,
            )
            router_logits = router_logits + noise

        # Select top-1 expert
        selected_experts = mx.argmax(router_logits, axis=-1, keepdims=True)

        # Get weights (softmax for consistency)
        router_probs = mx.softmax(router_logits, axis=-1)
        router_weights = mx.take_along_axis(
            router_probs,
            selected_experts,
            axis=-1,
        )

        return router_logits, selected_experts, router_weights


class ExpertChoiceRouter(nn.Module):
    """
    Expert-choice routing.

    Instead of tokens choosing experts, experts choose tokens.
    This ensures perfect load balancing across experts.

    Reference: "Expert Choice Routing"
    """

    def __init__(
        self,
        hidden_size: int,
        num_experts: int,
        tokens_per_expert: int = 128,
        **kwargs: Any,
    ):
        """
        Initialize Expert-choice router.

        Args:
            hidden_size: Input dimension.
            num_experts: Number of experts.
            tokens_per_expert: Number of tokens each expert processes.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_experts = num_experts
        self.tokens_per_expert = tokens_per_expert

        # Router linear layer
        self.gate = nn.Linear(hidden_size, num_experts, bias=False)

    def __call__(
        self,
        hidden_states: mx.array,
    ) -> tuple[mx.array, mx.array, mx.array]:
        """
        Route using expert-choice.

        Args:
            hidden_states: Input tensor (num_tokens, hidden_size).

        Returns:
            Tuple of (router_logits, token_to_expert, weights).
        """
        num_tokens = hidden_states.shape[0]

        # Compute routing scores
        router_logits = self.gate(hidden_states)  # (num_tokens, num_experts)

        # Transpose so experts choose tokens
        # (num_experts, num_tokens)
        expert_scores = mx.transpose(router_logits, (1, 0))

        # Each expert selects top tokens_per_expert tokens
        top_token_indices = mx.argpartition(expert_scores, kth=-self.tokens_per_expert, axis=-1)[:, -self.tokens_per_expert:]
        top_tokens_per_expert = mx.take_along_axis(expert_scores, top_token_indices, axis=-1)

        # Softmax to get weights
        expert_weights = mx.softmax(top_tokens_per_expert, axis=-1)

        # Create mapping from tokens to experts
        # This is a sparse assignment matrix
        token_to_expert = mx.zeros((num_tokens, self.num_experts))

        for expert_id in range(self.num_experts):
            token_ids = top_token_indices[expert_id]
            weights = expert_weights[expert_id]

            # Assign tokens to this expert
            for i, token_id in enumerate(token_ids):
                token_to_expert[token_id, expert_id] = weights[i]

        # Get selected experts per token (may be multiple)
        selected_experts = mx.argmax(token_to_expert, axis=-1, keepdims=True)
        router_weights = mx.max(token_to_expert, axis=-1, keepdims=True)

        return router_logits, selected_experts, router_weights
