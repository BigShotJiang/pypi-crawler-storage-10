# SPDX-License-Identifier: Apache-2.0
"""Expert networks for MoE layers.

Implements the actual expert computations with efficient batching.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class FeedForwardExperts(nn.Module):
    """
    Feedforward experts with shared architecture.

    Each expert is an independent FFN with the same structure
    but different parameters.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        activation: str = "silu",
        **kwargs: Any,
    ):
        """
        Initialize FFN experts.

        Args:
            hidden_size: Hidden dimension.
            intermediate_size: Intermediate FFN dimension.
            num_experts: Number of experts.
            activation: Activation function name.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_experts = num_experts

        # Create expert parameters
        # Shape: (num_experts, hidden_size, intermediate_size)
        self.w1 = mx.random.normal(
            (num_experts, hidden_size, intermediate_size),
            scale=0.02,
        )
        self.w2 = mx.random.normal(
            (num_experts, intermediate_size, hidden_size),
            scale=0.02,
        )

        # Gate weights (for gated FFN like SwiGLU)
        self.w3 = mx.random.normal(
            (num_experts, hidden_size, intermediate_size),
            scale=0.02,
        )

        # Activation function
        if activation == "silu":
            self.activation = nn.silu
        elif activation == "gelu":
            self.activation = nn.gelu
        elif activation == "relu":
            self.activation = nn.relu
        else:
            raise ValueError(f"Unknown activation: {activation}")

    def __call__(
        self,
        hidden_states: mx.array,
        selected_experts: mx.array,
        router_weights: mx.array,
    ) -> mx.array:
        """
        Process tokens through selected experts.

        Args:
            hidden_states: Input tensor (num_tokens, hidden_size).
            selected_experts: Expert indices (num_tokens, top_k).
            router_weights: Router weights (num_tokens, top_k).

        Returns:
            Output tensor (num_tokens, hidden_size).
        """
        num_tokens, hidden_size = hidden_states.shape
        top_k = selected_experts.shape[1]

        # Initialize output
        output = mx.zeros_like(hidden_states)

        # Process each top-K position
        for k in range(top_k):
            # Get expert IDs for this k
            expert_ids = selected_experts[:, k]  # (num_tokens,)
            weights = router_weights[:, k : k + 1]  # (num_tokens, 1)

            # Process each expert
            for expert_id in range(self.num_experts):
                # Find tokens routed to this expert
                mask = expert_ids == expert_id

                if not mx.any(mask):
                    continue

                # Get tokens for this expert
                # MLX doesn't support boolean indexing or argwhere yet
                # Use a loop to collect indices where mask is True
                indices_list = []
                for i in range(len(mask)):
                    if bool(mask[i]):
                        indices_list.append(i)

                if not indices_list:
                    continue

                indices = mx.array(indices_list, dtype=mx.int32)
                expert_input = hidden_states[indices]  # (num_expert_tokens, hidden)

                # FFN computation for this expert
                # Gated FFN (SwiGLU-style): gate(W1 @ x) * (W3 @ x)
                h1 = mx.matmul(expert_input, self.w1[expert_id])  # (N, intermediate)
                h3 = mx.matmul(expert_input, self.w3[expert_id])  # (N, intermediate)

                # Apply gating
                h = self.activation(h1) * h3

                # Project back
                expert_output = mx.matmul(h, self.w2[expert_id])  # (N, hidden)

                # Weight by router weight and accumulate
                expert_weights = weights[indices]
                weighted_output = expert_output * expert_weights

                # Scatter add to output using index assignment
                # Create update tensor for scatter
                for idx, token_idx in enumerate(indices):
                    output[int(token_idx)] = output[int(token_idx)] + weighted_output[idx]

        return output


class SparseExperts(nn.Module):
    """
    Sparse experts with conditional computation.

    Only computes experts that are actually selected,
    avoiding computation for unused experts.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int,
        **kwargs: Any,
    ):
        """
        Initialize sparse experts.

        Args:
            hidden_size: Hidden dimension.
            intermediate_size: Intermediate dimension.
            num_experts: Number of experts.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_experts = num_experts

        # Create individual expert modules
        self.experts = [
            self._create_expert(hidden_size, intermediate_size)
            for _ in range(num_experts)
        ]

    def _create_expert(
        self,
        hidden_size: int,
        intermediate_size: int,
    ) -> nn.Module:
        """Create a single expert FFN."""
        return nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.SiLU(),
            nn.Linear(intermediate_size, hidden_size),
        )

    def __call__(
        self,
        hidden_states: mx.array,
        selected_experts: mx.array,
        router_weights: mx.array,
    ) -> mx.array:
        """
        Process tokens through selected experts (sparse).

        Args:
            hidden_states: Input tensor (num_tokens, hidden_size).
            selected_experts: Expert indices (num_tokens, top_k).
            router_weights: Router weights (num_tokens, top_k).

        Returns:
            Output tensor (num_tokens, hidden_size).
        """
        num_tokens = hidden_states.shape[0]
        top_k = selected_experts.shape[1]

        # Initialize output
        output = mx.zeros_like(hidden_states)

        # Determine which experts are used
        unique_experts = set()
        for k in range(top_k):
            unique_experts.update(selected_experts[:, k].tolist())

        # Process only active experts
        for expert_id in unique_experts:
            expert = self.experts[expert_id]

            # Find all tokens routed to this expert (across all k)
            mask = mx.any(selected_experts == expert_id, axis=1)

            if not mx.any(mask):
                continue

            # Get tokens for this expert
            # MLX doesn't support boolean indexing or argwhere yet
            # Use a loop to collect indices where mask is True
            indices_list = []
            for i in range(len(mask)):
                if bool(mask[i]):
                    indices_list.append(i)

            if not indices_list:
                continue

            indices = mx.array(indices_list, dtype=mx.int32)
            expert_input = hidden_states[indices]

            # Compute expert output
            expert_output = expert(expert_input)

            # Get weights for this expert (may be from multiple k values)
            expert_weights = mx.zeros((num_tokens, 1))
            for k in range(top_k):
                k_mask = selected_experts[:, k] == expert_id
                expert_weights = mx.where(
                    mx.expand_dims(k_mask, -1),
                    expert_weights + router_weights[:, k : k + 1],
                    expert_weights,
                )

            # Extract weights for masked tokens
            expert_weights_masked = expert_weights[indices]

            # Weight and accumulate
            weighted_output = expert_output * expert_weights_masked

            # Scatter add to output using index assignment
            for idx, token_idx in enumerate(indices):
                output[int(token_idx)] = output[int(token_idx)] + weighted_output[idx]

        return output
