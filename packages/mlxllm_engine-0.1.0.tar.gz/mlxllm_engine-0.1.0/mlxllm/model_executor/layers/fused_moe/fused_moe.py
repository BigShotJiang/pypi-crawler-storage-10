# SPDX-License-Identifier: Apache-2.0
"""Fused Mixture of Experts implementation for MLX-LLM.

This module provides efficient MoE layers with top-K routing and load balancing.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .routing import TopKRouter
from .experts import FeedForwardExperts


class FusedMoE(nn.Module):
    """
    Fused Mixture of Experts layer.

    Efficiently routes tokens to top-K experts using sparse gating.
    Used in models like Mixtral and DeepSeek-MoE.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int = 8,
        num_experts_per_tok: int = 2,
        router_aux_loss_coef: float = 0.001,
        **kwargs: Any,
    ):
        """
        Initialize Fused MoE.

        Args:
            hidden_size: Hidden dimension size.
            intermediate_size: FFN intermediate dimension.
            num_experts: Total number of experts.
            num_experts_per_tok: Number of experts to activate per token (top-K).
            router_aux_loss_coef: Auxiliary loss coefficient for load balancing.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size
        self.num_experts = num_experts
        self.num_experts_per_tok = num_experts_per_tok
        self.router_aux_loss_coef = router_aux_loss_coef

        # Router (gating network)
        self.router = TopKRouter(
            hidden_size=hidden_size,
            num_experts=num_experts,
            top_k=num_experts_per_tok,
        )

        # Experts (shared-weight FFNs)
        self.experts = FeedForwardExperts(
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
            num_experts=num_experts,
        )

    def __call__(
        self,
        hidden_states: mx.array,
        **kwargs: Any,
    ) -> tuple[mx.array, mx.array]:
        """
        Forward pass for MoE.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            **kwargs: Additional arguments.

        Returns:
            Tuple of (output, router_logits).
        """
        batch_size, seq_len, hidden_size = hidden_states.shape

        # Reshape to (batch * seq_len, hidden_size) for routing
        hidden_states_flat = hidden_states.reshape(-1, hidden_size)

        # Route tokens to experts
        router_logits, selected_experts, router_weights = self.router(hidden_states_flat)

        # Process through experts
        expert_outputs = self.experts(
            hidden_states_flat,
            selected_experts,
            router_weights,
        )

        # Reshape back to (batch, seq_len, hidden_size)
        output = expert_outputs.reshape(batch_size, seq_len, hidden_size)

        return output, router_logits

    def compute_router_loss(self, router_logits: mx.array) -> mx.array:
        """
        Compute auxiliary load balancing loss.

        Args:
            router_logits: Router logits (num_tokens, num_experts).

        Returns:
            Load balancing loss.
        """
        # Convert logits to probabilities
        router_probs = mx.softmax(router_logits, axis=-1)

        # Compute mean probability per expert (load)
        expert_load = mx.mean(router_probs, axis=0)  # (num_experts,)

        # Compute coefficient of variation (CV) as load balancing metric
        # CV = std / mean, penalizes uneven load distribution
        mean_load = mx.mean(expert_load)
        std_load = mx.sqrt(mx.mean(mx.square(expert_load - mean_load)))
        cv_loss = std_load / (mean_load + 1e-6)

        return cv_loss * self.router_aux_loss_coef


class FusedMoELayer(nn.Module):
    """
    Complete MoE layer with attention and feedforward.

    This is a transformer block where the FFN is replaced by MoE.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        num_experts: int = 8,
        num_experts_per_tok: int = 2,
        num_heads: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize MoE layer.

        Args:
            hidden_size: Hidden dimension.
            num_heads: Number of attention heads.
            intermediate_size: MoE intermediate dimension.
            num_experts: Number of experts.
            num_experts_per_tok: Experts per token.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size

        # Default num_heads if not provided
        if num_heads is None:
            # Use common default: hidden_size // 64 (standard head_dim of 64)
            num_heads = max(1, hidden_size // 64)

        # Standard attention
        from ..attention_layer_base import MultiHeadAttention

        self.attention = MultiHeadAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            **kwargs,
        )

        # MoE instead of standard FFN
        self.moe = FusedMoE(
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
            num_experts=num_experts,
            num_experts_per_tok=num_experts_per_tok,
        )

        # Layer norms
        self.attn_norm = nn.RMSNorm(hidden_size)
        self.moe_norm = nn.RMSNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, mx.array]:
        """Forward pass for MoE layer."""
        # Attention with residual
        residual = hidden_states
        hidden_states = self.attn_norm(hidden_states)
        hidden_states, _ = self.attention(hidden_states, attention_mask=attention_mask)
        hidden_states = residual + hidden_states

        # MoE with residual
        residual = hidden_states
        hidden_states = self.moe_norm(hidden_states)
        hidden_states, router_logits = self.moe(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states, router_logits
