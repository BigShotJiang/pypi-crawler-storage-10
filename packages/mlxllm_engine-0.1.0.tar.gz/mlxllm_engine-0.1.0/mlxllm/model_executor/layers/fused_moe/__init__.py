# SPDX-License-Identifier: Apache-2.0
"""Fused Mixture of Experts (MoE) implementations for MLX-LLM.

This package provides efficient MoE layers with fused operations for better performance:
- Top-K expert routing
- Load balancing
- Expert parallelism
- Sparse and dense MoE variants

Used in models like Mixtral, DeepSeek-MoE, and Switch Transformers.
"""

from __future__ import annotations

from .fused_moe import FusedMoE, FusedMoELayer
from .routing import TopKRouter, SwitchRouter, ExpertChoiceRouter
from .experts import FeedForwardExperts, SparseExperts

__all__ = [
    "FusedMoE",
    "FusedMoELayer",
    "TopKRouter",
    "SwitchRouter",
    "ExpertChoiceRouter",
    "FeedForwardExperts",
    "SparseExperts",
]
