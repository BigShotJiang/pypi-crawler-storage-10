# SPDX-License-Identifier: Apache-2.0
"""
Vocabulary embedding layers with optional parallelism support.

This module provides embedding layers for language models, including support
for vocabulary parallelism (tensor parallelism across vocabulary dimension).
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn


__all__ = [
    "VocabParallelEmbedding",
    "Embedding",
]


class Embedding(nn.Module):
    """
    Standard embedding layer.

    Maps token IDs to dense vectors. This is a wrapper around MLX's
    embedding layer with additional features for LLM usage.
    """

    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        padding_idx: int | None = None,
    ):
        """Initialize embedding layer.

        Args:
            num_embeddings: Vocabulary size
            embedding_dim: Dimension of embedding vectors
            padding_idx: Optional padding token ID (not used in forward pass)
        """
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.padding_idx = padding_idx

        # Create embedding weight matrix
        self.weight = mx.random.normal(
            shape=(num_embeddings, embedding_dim),
            scale=0.02,  # Standard initialization scale
        )

    def __call__(self, input_ids: mx.array) -> mx.array:
        """Embed token IDs.

        Args:
            input_ids: Token IDs with shape [batch_size, seq_len] or [batch_size]

        Returns:
            Embeddings with shape [..., embedding_dim]
        """
        # Use MLX's gather operation for embedding lookup
        return self.weight[input_ids]

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}("
            f"num_embeddings={self.num_embeddings}, "
            f"embedding_dim={self.embedding_dim}"
            f")"
        )


class VocabParallelEmbedding(nn.Module):
    """
    Vocabulary-parallel embedding layer.

    This layer supports tensor parallelism by sharding the vocabulary dimension
    across multiple devices/processes. For single-device inference, it behaves
    like a standard embedding layer.

    In multi-device setups, each device handles a portion of the vocabulary:
    - Device 0: tokens [0, vocab_size/N)
    - Device 1: tokens [vocab_size/N, 2*vocab_size/N)
    - ...

    This reduces memory usage per device for large vocabulary sizes.
    """

    def __init__(
        self,
        num_embeddings: int,
        embedding_dim: int,
        padding_idx: int | None = None,
        num_shards: int = 1,
        shard_id: int = 0,
    ):
        """Initialize vocabulary-parallel embedding.

        Args:
            num_embeddings: Total vocabulary size (across all shards)
            embedding_dim: Dimension of embedding vectors
            padding_idx: Optional padding token ID
            num_shards: Number of vocabulary shards (for tensor parallelism)
            shard_id: ID of this shard (0 to num_shards-1)
        """
        super().__init__()
        self.num_embeddings = num_embeddings
        self.embedding_dim = embedding_dim
        self.padding_idx = padding_idx
        self.num_shards = num_shards
        self.shard_id = shard_id

        # Calculate shard boundaries
        if num_embeddings % num_shards != 0:
            raise ValueError(
                f"Vocabulary size {num_embeddings} must be divisible by "
                f"number of shards {num_shards}"
            )

        self.vocab_per_shard = num_embeddings // num_shards
        self.vocab_start_idx = shard_id * self.vocab_per_shard
        self.vocab_end_idx = (shard_id + 1) * self.vocab_per_shard

        # Create embedding weight for this shard only
        self.weight = mx.random.normal(
            shape=(self.vocab_per_shard, embedding_dim),
            scale=0.02,
        )

    def __call__(self, input_ids: mx.array) -> mx.array:
        """Embed token IDs using vocabulary parallelism.

        Args:
            input_ids: Token IDs with shape [batch_size, seq_len] or [batch_size]

        Returns:
            Embeddings with shape [..., embedding_dim]

        Notes:
            For single-shard (num_shards=1), behaves like standard embedding.
            For multi-shard, only tokens in this shard's range are embedded;
            out-of-range tokens get zero embeddings (to be summed across shards).
        """
        if self.num_shards == 1:
            # Fast path: single shard
            return self.weight[input_ids]

        # Multi-shard path: only embed tokens in this shard's range
        # Create mask for tokens in this shard
        in_shard_mask = (input_ids >= self.vocab_start_idx) & (
            input_ids < self.vocab_end_idx
        )

        # Convert to local indices (relative to this shard)
        local_ids = input_ids - self.vocab_start_idx

        # Clamp to valid range (out-of-range will be masked anyway)
        local_ids = mx.clip(local_ids, 0, self.vocab_per_shard - 1)

        # Embed using local indices
        embeddings = self.weight[local_ids]

        # Mask out embeddings for tokens not in this shard
        # Expand mask to match embedding dimension
        mask = mx.expand_dims(in_shard_mask, axis=-1).astype(embeddings.dtype)

        return embeddings * mask

    def __repr__(self) -> str:
        """String representation."""
        if self.num_shards == 1:
            return (
                f"{self.__class__.__name__}("
                f"num_embeddings={self.num_embeddings}, "
                f"embedding_dim={self.embedding_dim}"
                f")"
            )
        else:
            return (
                f"{self.__class__.__name__}("
                f"num_embeddings={self.num_embeddings}, "
                f"embedding_dim={self.embedding_dim}, "
                f"num_shards={self.num_shards}, "
                f"shard_id={self.shard_id}, "
                f"range=[{self.vocab_start_idx}, {self.vocab_end_idx})"
                f")"
            )


def gather_from_shards(
    embeddings_list: list[mx.array],
) -> mx.array:
    """
    Gather embeddings from multiple vocabulary shards.

    In tensor parallel inference, each device computes embeddings only for
    its vocabulary shard. This function combines them via sum (since each
    device masks out tokens not in its shard).

    Args:
        embeddings_list: List of embedding tensors from each shard,
                        each with shape [batch_size, seq_len, embedding_dim]

    Returns:
        Combined embeddings with same shape

    Example:
        >>> # Device 0 embeds tokens [0, 16384)
        >>> emb0 = vocab_emb_0(input_ids)  # [B, S, D]
        >>> # Device 1 embeds tokens [16384, 32768)
        >>> emb1 = vocab_emb_1(input_ids)  # [B, S, D]
        >>> # Combine
        >>> final_emb = gather_from_shards([emb0, emb1])
    """
    # Sum across shards (only one shard contributes per token)
    return mx.sum(mx.stack(embeddings_list, axis=0), axis=0)
