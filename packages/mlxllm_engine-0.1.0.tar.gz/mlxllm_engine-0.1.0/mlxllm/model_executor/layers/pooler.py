# SPDX-License-Identifier: Apache-2.0
"""Pooling layers for MLX-LLM model executor.

This module provides various pooling operations for converting sequences to
fixed-size representations, commonly used for embeddings and classification.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class Pooler(nn.Module):
    """
    Base pooler for converting sequence outputs to fixed representations.

    This is commonly used in models like BERT for sentence embeddings.
    """

    def __init__(self, hidden_size: int, pooling_type: str = "cls"):
        """
        Initialize pooler.

        Args:
            hidden_size: Hidden size dimension.
            pooling_type: Type of pooling (cls, mean, max, last).
        """
        super().__init__()
        self.hidden_size = hidden_size
        self.pooling_type = pooling_type

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Pool hidden states.

        Args:
            hidden_states: Sequence hidden states (batch_size, seq_len, hidden_size).
            attention_mask: Optional attention mask (batch_size, seq_len).

        Returns:
            Pooled output (batch_size, hidden_size).
        """
        if self.pooling_type == "cls":
            # Use first token ([CLS] token)
            return hidden_states[:, 0, :]

        elif self.pooling_type == "mean":
            # Mean pooling
            if attention_mask is not None:
                # Masked mean
                mask_expanded = mx.expand_dims(attention_mask, axis=-1)
                sum_hidden = mx.sum(hidden_states * mask_expanded, axis=1)
                sum_mask = mx.sum(mask_expanded, axis=1)
                return sum_hidden / (sum_mask + 1e-9)
            else:
                return mx.mean(hidden_states, axis=1)

        elif self.pooling_type == "max":
            # Max pooling
            if attention_mask is not None:
                # Masked max
                mask_expanded = mx.expand_dims(attention_mask, axis=-1)
                hidden_states = mx.where(
                    mask_expanded,
                    hidden_states,
                    mx.full_like(hidden_states, -float("inf")),
                )
            return mx.max(hidden_states, axis=1)

        elif self.pooling_type == "last":
            # Use last token
            if attention_mask is not None:
                # Find last non-masked token
                seq_lengths = mx.sum(attention_mask, axis=1).astype(mx.int32)
                batch_indices = mx.arange(hidden_states.shape[0])
                return hidden_states[batch_indices, seq_lengths - 1, :]
            else:
                return hidden_states[:, -1, :]

        else:
            raise ValueError(f"Unknown pooling type: {self.pooling_type}")


class BertPooler(nn.Module):
    """
    BERT-style pooler with tanh activation and dense layer.

    This takes the [CLS] token and applies a dense layer with tanh activation.
    """

    def __init__(self, hidden_size: int):
        """
        Initialize BERT pooler.

        Args:
            hidden_size: Hidden size dimension.
        """
        super().__init__()
        self.dense = nn.Linear(hidden_size, hidden_size)

    def __call__(self, hidden_states: mx.array) -> mx.array:
        """
        Pool using BERT-style pooler.

        Args:
            hidden_states: Sequence hidden states (batch_size, seq_len, hidden_size).

        Returns:
            Pooled output (batch_size, hidden_size).
        """
        # Take [CLS] token
        first_token = hidden_states[:, 0, :]

        # Apply dense layer and tanh
        pooled_output = self.dense(first_token)
        pooled_output = mx.tanh(pooled_output)

        return pooled_output


class AttentionPooler(nn.Module):
    """
    Attention-based pooling using learned queries.

    This uses a learnable query to attend over the sequence and produce
    a weighted average.
    """

    def __init__(self, hidden_size: int, num_queries: int = 1):
        """
        Initialize attention pooler.

        Args:
            hidden_size: Hidden size dimension.
            num_queries: Number of learnable queries (output size).
        """
        super().__init__()
        self.hidden_size = hidden_size
        self.num_queries = num_queries

        # Learnable queries
        self.query = mx.random.normal((num_queries, hidden_size))

        # Attention projection
        self.attention = nn.Linear(hidden_size, hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Pool using attention mechanism.

        Args:
            hidden_states: Sequence hidden states (batch_size, seq_len, hidden_size).
            attention_mask: Optional attention mask (batch_size, seq_len).

        Returns:
            Pooled output (batch_size, num_queries, hidden_size).
        """
        batch_size, seq_len, hidden_size = hidden_states.shape

        # Expand query for batch
        query = mx.broadcast_to(
            mx.expand_dims(self.query, axis=0),
            (batch_size, self.num_queries, hidden_size),
        )

        # Compute attention scores: query @ hidden_states^T
        scores = mx.matmul(query, mx.transpose(hidden_states, (0, 2, 1)))
        # (batch_size, num_queries, seq_len)

        # Apply attention mask
        if attention_mask is not None:
            mask_expanded = mx.expand_dims(attention_mask, axis=1)  # (batch, 1, seq)
            scores = mx.where(
                mask_expanded,
                scores,
                mx.full_like(scores, -float("inf")),
            )

        # Softmax
        attn_weights = mx.softmax(scores, axis=-1)

        # Weighted average: attn_weights @ hidden_states
        pooled = mx.matmul(attn_weights, hidden_states)
        # (batch_size, num_queries, hidden_size)

        # If single query, squeeze
        if self.num_queries == 1:
            pooled = mx.squeeze(pooled, axis=1)

        return pooled


class AdaptivePooler(nn.Module):
    """
    Adaptive pooler that chooses pooling based on sequence length.

    Uses different pooling strategies for short vs. long sequences.
    """

    def __init__(
        self,
        hidden_size: int,
        short_threshold: int = 128,
        short_pooling: str = "cls",
        long_pooling: str = "mean",
    ):
        """
        Initialize adaptive pooler.

        Args:
            hidden_size: Hidden size dimension.
            short_threshold: Threshold for considering a sequence short.
            short_pooling: Pooling type for short sequences.
            long_pooling: Pooling type for long sequences.
        """
        super().__init__()
        self.hidden_size = hidden_size
        self.short_threshold = short_threshold
        self.short_pooler = Pooler(hidden_size, short_pooling)
        self.long_pooler = Pooler(hidden_size, long_pooling)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Pool adaptively based on sequence length.

        Args:
            hidden_states: Sequence hidden states.
            attention_mask: Optional attention mask.

        Returns:
            Pooled output (batch_size, hidden_size).
        """
        seq_len = hidden_states.shape[1]

        if seq_len <= self.short_threshold:
            return self.short_pooler(hidden_states, attention_mask)
        else:
            return self.long_pooler(hidden_states, attention_mask)


def weighted_pooling(
    hidden_states: mx.array,
    weights: mx.array,
    attention_mask: mx.array | None = None,
) -> mx.array:
    """
    Weighted pooling with custom weights.

    Args:
        hidden_states: Sequence hidden states (batch_size, seq_len, hidden_size).
        weights: Pooling weights (batch_size, seq_len) or (seq_len,).
        attention_mask: Optional attention mask.

    Returns:
        Pooled output (batch_size, hidden_size).
    """
    # Expand weights if needed
    if weights.ndim == 1:
        weights = mx.expand_dims(weights, axis=0)

    # Apply attention mask to weights
    if attention_mask is not None:
        weights = weights * attention_mask

    # Normalize weights
    weights = weights / (mx.sum(weights, axis=1, keepdims=True) + 1e-9)

    # Weighted sum
    weights_expanded = mx.expand_dims(weights, axis=-1)
    pooled = mx.sum(hidden_states * weights_expanded, axis=1)

    return pooled
