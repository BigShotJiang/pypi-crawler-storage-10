# SPDX-License-Identifier: Apache-2.0
"""Mamba State Space Model layers for MLX-LLM.

Mamba is an efficient sequence modeling architecture based on selective state
space models (SSMs). It achieves linear complexity while maintaining strong
performance on long sequences.

Reference: "Mamba: Linear-Time Sequence Modeling with Selective State Spaces"
"""

from __future__ import annotations

from .mamba import MambaBlock, MambaLayer, MambaModel
from .ssm import SelectiveSSM, S4Layer

__all__ = [
    "MambaBlock",
    "MambaLayer",
    "MambaModel",
    "SelectiveSSM",
    "S4Layer",
]
