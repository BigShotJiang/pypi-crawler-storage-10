# SPDX-License-Identifier: Apache-2.0
"""Mamba blocks and layers for MLX-LLM.

Implements the core Mamba architecture with selective SSM.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .ssm import SelectiveSSM


class MambaBlock(nn.Module):
    """
    Mamba block with selective state space model.

    Core building block of the Mamba architecture.
    """

    def __init__(
        self,
        hidden_size: int,
        state_size: int = 16,
        conv_kernel: int = 4,
        expand: int = 2,
        dt_rank: str | int = "auto",
        **kwargs: Any,
    ):
        """
        Initialize Mamba block.

        Args:
            hidden_size: Hidden dimension size.
            state_size: SSM state dimension (N in paper).
            conv_kernel: Convolution kernel size.
            expand: Expansion factor for inner dimension.
            dt_rank: Rank of Delta projection. "auto" sets to ceil(hidden_size / 16).
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.state_size = state_size
        self.conv_kernel = conv_kernel
        self.expand = expand

        # Inner dimension (expanded)
        self.d_inner = int(hidden_size * expand)

        # Compute dt_rank
        if dt_rank == "auto":
            self.dt_rank = max(1, hidden_size // 16)
        else:
            self.dt_rank = dt_rank

        # Input projection (expand dimension)
        self.in_proj = nn.Linear(hidden_size, self.d_inner * 2, bias=False)

        # Depthwise convolution
        # In MLX, we'll simulate with linear layers
        self.conv1d = nn.Conv1d(
            self.d_inner,
            self.d_inner,
            kernel_size=conv_kernel,
            groups=self.d_inner,
            padding=(conv_kernel - 1) // 2,
        )

        # Selective SSM
        self.ssm = SelectiveSSM(
            d_model=self.d_inner,
            d_state=state_size,
            dt_rank=self.dt_rank,
        )

        # Output projection
        self.out_proj = nn.Linear(self.d_inner, hidden_size, bias=False)

    def __call__(
        self,
        hidden_states: mx.array,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for Mamba block.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch, seq_len, hidden_size).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Input projection and split
        x_and_res = self.in_proj(hidden_states)  # (B, L, 2*d_inner)
        x, res = mx.split(x_and_res, 2, axis=-1)

        # Transpose for conv1d: (B, L, D) -> (B, D, L)
        x = mx.transpose(x, (0, 2, 1))

        # Depthwise convolution
        x = self.conv1d(x)

        # Transpose back: (B, D, L) -> (B, L, D)
        x = mx.transpose(x, (0, 2, 1))

        # Activation
        x = nn.silu(x)

        # Selective SSM
        x = self.ssm(x)

        # Gated multiplication with residual
        x = x * nn.silu(res)

        # Output projection
        output = self.out_proj(x)

        return output


class MambaLayer(nn.Module):
    """
    Complete Mamba layer with normalization and residual connections.

    This is analogous to a transformer layer but uses Mamba blocks
    instead of attention.
    """

    def __init__(
        self,
        hidden_size: int,
        state_size: int = 16,
        **kwargs: Any,
    ):
        """
        Initialize Mamba layer.

        Args:
            hidden_size: Hidden dimension.
            state_size: SSM state dimension.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size

        # Mamba block
        self.mamba = MambaBlock(
            hidden_size=hidden_size,
            state_size=state_size,
            **kwargs,
        )

        # Normalization
        self.norm = nn.RMSNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        **kwargs: Any,
    ) -> mx.array:
        """Forward pass for Mamba layer."""
        # Mamba with residual
        residual = hidden_states
        hidden_states = self.norm(hidden_states)
        hidden_states = self.mamba(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states


class MambaModel(nn.Module):
    """
    Full Mamba model with multiple layers.

    Stack of Mamba layers for sequence modeling.
    """

    def __init__(
        self,
        vocab_size: int,
        hidden_size: int,
        num_layers: int,
        state_size: int = 16,
        **kwargs: Any,
    ):
        """
        Initialize Mamba model.

        Args:
            vocab_size: Vocabulary size.
            hidden_size: Hidden dimension.
            num_layers: Number of Mamba layers.
            state_size: SSM state dimension.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        # Embedding
        self.embedding = nn.Embedding(vocab_size, hidden_size)

        # Mamba layers
        self.layers = [
            MambaLayer(hidden_size=hidden_size, state_size=state_size, **kwargs)
            for _ in range(num_layers)
        ]

        # Final norm
        self.norm_f = nn.RMSNorm(hidden_size)

        # LM head
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)

    def __call__(
        self,
        input_ids: mx.array,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for Mamba model.

        Args:
            input_ids: Token IDs (batch, seq_len).
            **kwargs: Additional arguments.

        Returns:
            Logits (batch, seq_len, vocab_size).
        """
        # Embed tokens
        hidden_states = self.embedding(input_ids)

        # Process through Mamba layers
        for layer in self.layers:
            hidden_states = layer(hidden_states)

        # Final norm
        hidden_states = self.norm_f(hidden_states)

        # LM head
        logits = self.lm_head(hidden_states)

        return logits
