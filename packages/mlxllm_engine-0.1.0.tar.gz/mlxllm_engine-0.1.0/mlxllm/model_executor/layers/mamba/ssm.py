# SPDX-License-Identifier: Apache-2.0
"""State Space Model implementations for Mamba.

Core SSM computation with selective mechanism.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class SelectiveSSM(nn.Module):
    """
    Selective State Space Model.

    The core innovation of Mamba: input-dependent SSM parameters
    that allow selective information propagation.
    """

    def __init__(
        self,
        d_model: int,
        d_state: int = 16,
        dt_rank: int = 16,
        dt_min: float = 0.001,
        dt_max: float = 0.1,
        **kwargs: Any,
    ):
        """
        Initialize selective SSM.

        Args:
            d_model: Model dimension.
            d_state: State dimension (N).
            dt_rank: Rank of Delta projection.
            dt_min: Minimum value for Delta.
            dt_max: Maximum value for Delta.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.d_model = d_model
        self.d_state = d_state
        self.dt_rank = dt_rank
        self.dt_min = dt_min
        self.dt_max = dt_max

        # SSM parameters (input-dependent)
        # Project to Delta (time step), B (input matrix), C (output matrix)
        self.x_proj = nn.Linear(d_model, dt_rank + d_state * 2, bias=False)

        # Delta projection (from rank to d_model)
        self.dt_proj = nn.Linear(dt_rank, d_model, bias=True)

        # A parameter (state transition matrix)
        # Initialize with S4 initialization
        self.A_log = mx.log(
            mx.repeat(mx.arange(1, d_state + 1, dtype=mx.float32), d_model // d_state)
        )

        # D parameter (skip connection)
        self.D = mx.ones((d_model,))

    def __call__(
        self,
        x: mx.array,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for selective SSM.

        Args:
            x: Input tensor (batch, seq_len, d_model).
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch, seq_len, d_model).
        """
        batch_size, seq_len, d_model = x.shape

        # Compute input-dependent SSM parameters
        x_proj = self.x_proj(x)  # (B, L, dt_rank + 2*d_state)

        # Split into Delta, B, C
        delta, B, C = mx.split(
            x_proj,
            [self.dt_rank, self.dt_rank + self.d_state],
            axis=-1,
        )

        # Project Delta to full dimension and ensure positive
        delta = self.dt_proj(delta)  # (B, L, d_model)
        delta = nn.softplus(delta)  # Ensure positive

        # Discretize continuous parameters (Zero-Order Hold)
        A = -mx.exp(self.A_log)  # (d_model,)
        A_bar = mx.exp(mx.expand_dims(delta, -1) * mx.expand_dims(A, (0, 1)))

        # Expand B and C
        B = mx.expand_dims(B, -1)  # (B, L, d_state, 1)
        C = mx.expand_dims(C, -1)  # (B, L, d_state, 1)

        # Compute SSM (parallel scan approximation)
        # In practice, this uses a parallel associative scan
        # Here we provide a simplified sequential version
        y = self._ssm_scan(x, A_bar, B, C)

        # Add skip connection
        y = y + x * self.D

        return y

    def _ssm_scan(
        self,
        x: mx.array,
        A: mx.array,
        B: mx.array,
        C: mx.array,
    ) -> mx.array:
        """
        SSM scan (simplified sequential implementation).

        Args:
            x: Input (batch, seq_len, d_model).
            A: Discretized A (batch, seq_len, d_model).
            B: Input matrix (batch, seq_len, d_state, 1).
            C: Output matrix (batch, seq_len, d_state, 1).

        Returns:
            Output (batch, seq_len, d_model).
        """
        batch_size, seq_len, d_model = x.shape

        # Initialize state
        h = mx.zeros((batch_size, self.d_state, d_model))

        outputs = []

        # Sequential scan (in practice, use parallel scan)
        for t in range(seq_len):
            # Get params for this timestep
            x_t = x[:, t, :]  # (B, d_model)
            A_t = A[:, t, :]  # (B, d_model)
            B_t = mx.squeeze(B[:, t, :, :], axis=-1)  # (B, d_state)
            C_t = mx.squeeze(C[:, t, :, :], axis=-1)  # (B, d_state)

            # Update state: h = A * h + B * x
            h = A_t[:, None, :] * h + mx.expand_dims(B_t, -1) * mx.expand_dims(x_t, 1)

            # Compute output: y = C^T * h
            y_t = mx.sum(mx.expand_dims(C_t, -1) * h, axis=1)  # (B, d_model)

            outputs.append(y_t)

        # Stack outputs
        output = mx.stack(outputs, axis=1)  # (B, L, d_model)

        return output


class S4Layer(nn.Module):
    """
    Structured State Space (S4) layer.

    Original S4 without selective mechanism (for comparison).
    """

    def __init__(
        self,
        d_model: int,
        d_state: int = 64,
        **kwargs: Any,
    ):
        """
        Initialize S4 layer.

        Args:
            d_model: Model dimension.
            d_state: State dimension.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.d_model = d_model
        self.d_state = d_state

        # Learnable SSM parameters
        self.A_log = mx.log(
            mx.repeat(mx.arange(1, d_state + 1, dtype=mx.float32), d_model // d_state)
        )
        self.D = mx.ones((d_model,))

        # Input and output projections
        self.B = nn.Linear(1, d_model * d_state, bias=False)
        self.C = nn.Linear(1, d_model * d_state, bias=False)

    def __call__(self, x: mx.array, **kwargs: Any) -> mx.array:
        """
        Forward pass for S4.

        Args:
            x: Input tensor (batch, seq_len, d_model).
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch, seq_len, d_model).
        """
        # S4 computation (simplified)
        # In practice, uses FFT-based convolution for efficiency

        # Apply skip connection
        output = x * self.D

        return output
