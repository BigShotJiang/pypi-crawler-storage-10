# SPDX-License-Identifier: Apache-2.0
"""OCP Microscaling (MX) quantization scheme for Quark."""

from __future__ import annotations

from typing import Any

import mlx.core as mx

from .quark_scheme import QuarkSchemeBase


class QuarkOCPMXScheme(QuarkSchemeBase):
    """
    OCP Microscaling (MX) quantization scheme.

    Implements block-wise quantization with shared exponent,
    following the Open Compute Project MX format specification.

    Reference: https://www.opencompute.org/documents/ocp-microscaling-formats-mx-v1-0-spec-final-pdf
    """

    def __init__(self, block_size: int = 32, element_bits: int = 8):
        """
        Initialize OCP MX scheme.

        Args:
            block_size: Number of elements per block (typically 32).
            element_bits: Bits per element (4 or 8).
        """
        self.block_size = block_size
        self.element_bits = element_bits

    def quantize(
        self, tensor: mx.array
    ) -> tuple[mx.array, dict[str, Any]]:
        """
        Quantize using microscaling format.

        Each block of elements shares a common scale (exponent).
        """
        # Reshape into blocks
        original_shape = tensor.shape
        flat = tensor.flatten()

        # Pad to multiple of block_size
        pad_size = (self.block_size - flat.size % self.block_size) % self.block_size
        if pad_size > 0:
            flat = mx.concatenate([flat, mx.zeros(pad_size)])

        num_blocks = flat.size // self.block_size
        blocks = flat.reshape(num_blocks, self.block_size)

        # Compute per-block scales
        block_max = mx.max(mx.abs(blocks), axis=1, keepdims=True)
        scales = block_max / (2 ** (self.element_bits - 1) - 1)
        scales = mx.maximum(scales, 1e-8)

        # Quantize blocks
        quantized_blocks = mx.round(blocks / scales).astype(mx.int8)

        # Flatten back
        quantized = quantized_blocks.flatten()[: original_shape[0] * original_shape[1]]
        quantized = quantized.reshape(original_shape)

        scales = scales.flatten()

        params = {
            "scales": scales,
            "block_size": self.block_size,
            "original_size": flat.size - pad_size,
        }

        return quantized, params

    def dequantize(
        self, quantized: mx.array, params: dict[str, Any]
    ) -> mx.array:
        """Dequantize from microscaling format."""
        scales = params["scales"]
        block_size = params["block_size"]

        # Reshape into blocks
        original_shape = quantized.shape
        flat = quantized.flatten()

        num_blocks = flat.size // block_size
        blocks = flat.reshape(num_blocks, block_size).astype(mx.float32)

        # Apply per-block scales
        scales_expanded = mx.expand_dims(scales, -1)
        dequantized_blocks = blocks * scales_expanded

        # Flatten and reshape
        dequantized = dequantized_blocks.flatten()[: params["original_size"]]
        dequantized = dequantized.reshape(original_shape)

        return dequantized

    def get_dtype(self) -> mx.Dtype:
        """Get quantized dtype."""
        return mx.int8


__all__ = ["QuarkOCPMXScheme"]
