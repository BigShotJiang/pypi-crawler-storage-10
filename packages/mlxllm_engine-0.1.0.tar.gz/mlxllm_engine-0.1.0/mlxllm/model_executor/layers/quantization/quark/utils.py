# SPDX-License-Identifier: Apache-2.0
"""Utility functions for Quark quantization.

Provides helper functions for quantization and dequantization operations.
"""

from __future__ import annotations

import mlx.core as mx


def quantize_tensor(
    tensor: mx.array,
    bits: int = 8,
    symmetric: bool = True,
    per_channel: bool = False,
    axis: int = 0,
) -> tuple[mx.array, mx.array]:
    """
    Quantize a tensor to lower precision.

    Args:
        tensor: Input tensor to quantize.
        bits: Number of bits for quantization (4 or 8).
        symmetric: Whether to use symmetric quantization.
        per_channel: Whether to use per-channel quantization.
        axis: Axis for per-channel quantization (if per_channel=True).

    Returns:
        Tuple of (quantized_tensor, scale).
    """
    if bits not in [4, 8]:
        raise ValueError(f"bits must be 4 or 8, got {bits}")

    # Compute scale
    if per_channel:
        # Per-channel: compute scale for each channel along specified axis
        # The `axis` parameter specifies which axis to keep (not which to reduce)
        # We need to reduce over all OTHER axes
        # For 2D: if axis=0, reduce along axis=1; if axis=1, reduce along axis=0
        # For 3D: if axis=-1 or axis=2, reduce along axes (0,1) - but MLX only supports single axis
        #         so we'll just pass the axis directly for now and let it reduce along that axis
        #
        # Actually, per-channel typically means we reduce along all dims EXCEPT the specified one
        # For simplicity with 2D tensors (weights), we swap: axis=0 means reduce along 1
        ndim = len(tensor.shape)
        if ndim == 2:
            reduce_axis = 1 - axis  # For 2D: swap 0<->1
        else:
            # For higher dims, use all axes except the specified one
            # But MLX max/min only supports single axis, so we need a workaround
            # For per-token quantization on (batch, seq, features) with axis=-1,
            # we want to reduce over the features, which is axis=-1 itself
            # So actually the axis parameter might mean "reduce along this axis" not "keep this axis"
            # Let me just pass it through for non-2D
            reduce_axis = axis

        if symmetric:
            scale = mx.max(mx.abs(tensor), axis=reduce_axis, keepdims=True) / (
                2 ** (bits - 1) - 1
            )
        else:
            t_min = mx.min(tensor, axis=reduce_axis, keepdims=True)
            t_max = mx.max(tensor, axis=reduce_axis, keepdims=True)
            scale = (t_max - t_min) / (2**bits - 1)
    else:
        # Per-tensor: single scale for entire tensor
        if symmetric:
            scale = mx.max(mx.abs(tensor)) / (2 ** (bits - 1) - 1)
        else:
            t_min = mx.min(tensor)
            t_max = mx.max(tensor)
            scale = (t_max - t_min) / (2**bits - 1)

        # Ensure scale is at least 1D for consistent API
        scale = mx.expand_dims(scale, 0)

    scale = mx.maximum(scale, 1e-8)  # Prevent division by zero

    # Quantize
    if symmetric:
        quantized = mx.round(tensor / scale).astype(mx.int8)
    else:
        # For asymmetric, we need to store zero_point for dequantization
        if per_channel:
            zero_point = mx.round(-t_min / scale)
        else:
            zero_point = mx.round(-t_min / scale)
        quantized = mx.round(tensor / scale + zero_point).astype(mx.int8)

    return quantized, scale


def dequantize_tensor(
    quantized: mx.array,
    scale: mx.array,
    symmetric: bool = True,
    zero_point: mx.array | None = None,
) -> mx.array:
    """
    Dequantize a tensor back to floating point.

    Args:
        quantized: Quantized tensor (int8).
        scale: Scale factor used for quantization.
        symmetric: Whether symmetric quantization was used.
        zero_point: Zero point (for asymmetric quantization).

    Returns:
        Dequantized tensor (float32).
    """
    if symmetric:
        dequantized = quantized.astype(mx.float32) * scale
    else:
        if zero_point is None:
            raise ValueError("zero_point required for asymmetric dequantization")
        dequantized = (quantized.astype(mx.float32) - zero_point) * scale

    return dequantized


def compute_quantization_error(
    original: mx.array,
    quantized: mx.array,
    scale: mx.array,
) -> dict[str, float]:
    """
    Compute quantization error metrics.

    Args:
        original: Original tensor.
        quantized: Quantized tensor.
        scale: Scale factor.

    Returns:
        Dictionary with error metrics (MSE, RMSE, SNR).
    """
    dequantized = dequantize_tensor(quantized, scale)

    # Mean Squared Error
    mse = float(mx.mean((original - dequantized) ** 2))

    # Root Mean Squared Error
    rmse = float(mx.sqrt(mx.mean((original - dequantized) ** 2)))

    # Signal-to-Noise Ratio
    signal_power = float(mx.mean(original**2))
    noise_power = float(mx.mean((original - dequantized) ** 2))
    snr = 10 * mx.log10(signal_power / (noise_power + 1e-10))
    snr = float(snr)

    return {
        "mse": mse,
        "rmse": rmse,
        "snr_db": snr,
    }


__all__ = [
    "quantize_tensor",
    "dequantize_tensor",
    "compute_quantization_error",
]
