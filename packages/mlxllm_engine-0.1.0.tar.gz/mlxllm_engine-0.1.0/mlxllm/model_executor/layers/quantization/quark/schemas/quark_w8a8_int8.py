# SPDX-License-Identifier: Apache-2.0
"""W8A8 INT8 quantization scheme for Quark."""

from __future__ import annotations

from typing import Any

import mlx.core as mx

from .quark_scheme import QuarkSchemeBase


class QuarkW8A8Int8Scheme(QuarkSchemeBase):
    """
    W8A8 INT8 quantization scheme.

    8-bit integer quantization for both weights and activations.
    """

    def __init__(self, symmetric: bool = True, per_channel: bool = True):
        """
        Initialize W8A8 INT8 scheme.

        Args:
            symmetric: Whether to use symmetric quantization.
            per_channel: Whether to use per-channel quantization.
        """
        self.symmetric = symmetric
        self.per_channel = per_channel

    def quantize(
        self, tensor: mx.array
    ) -> tuple[mx.array, dict[str, Any]]:
        """Quantize to INT8."""
        if self.per_channel:
            # Per-channel quantization
            scale = mx.max(mx.abs(tensor), axis=0, keepdims=True) / 127.0
            scale = mx.maximum(scale, 1e-8)
        else:
            # Per-tensor quantization
            scale = mx.max(mx.abs(tensor)) / 127.0
            scale = mx.maximum(scale, 1e-8)

        quantized = mx.round(tensor / scale).astype(mx.int8)

        params = {"scale": scale, "symmetric": self.symmetric}

        return quantized, params

    def dequantize(
        self, quantized: mx.array, params: dict[str, Any]
    ) -> mx.array:
        """Dequantize from INT8."""
        scale = params["scale"]
        return quantized.astype(mx.float32) * scale

    def get_dtype(self) -> mx.Dtype:
        """Get quantized dtype."""
        return mx.int8


__all__ = ["QuarkW8A8Int8Scheme"]
