# SPDX-License-Identifier: Apache-2.0
"""Quark-inspired quantization framework for MLX-LLM.

Quark is originally a CUDA-based quantization framework. This module provides
MLX-compatible implementations of Quark's quantization schemes for Apple Silicon.

Supported schemes:
- W8A8 INT8: 8-bit weights and activations (integer)
- W8A8 FP8: 8-bit weights and activations (floating point)
- OCP MX: Open Compute Project Microscaling formats

For optimal performance on Apple Silicon, these implementations use MLX's
Metal backend instead of CUDA.
"""

from __future__ import annotations

from .base_config import QuarkConfig, QuarkScheme
from .quark import QuarkQuantizedLinear
from .quark_moe import QuarkQuantizedMoE
from .schemas import QuarkW8A8Int8Scheme, QuarkW8A8FP8Scheme, QuarkOCPMXScheme
from .utils import quantize_tensor, dequantize_tensor, compute_quantization_error

__all__ = [
    "QuarkConfig",
    "QuarkScheme",
    "QuarkQuantizedLinear",
    "QuarkQuantizedMoE",
    "QuarkW8A8Int8Scheme",
    "QuarkW8A8FP8Scheme",
    "QuarkOCPMXScheme",
    "quantize_tensor",
    "dequantize_tensor",
    "compute_quantization_error",
]
