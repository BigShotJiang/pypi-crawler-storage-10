# SPDX-License-Identifier: Apache-2.0
"""Base configuration for Quark-inspired quantization.

Provides configuration classes for Quark quantization schemes adapted for MLX.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


class QuarkScheme(str, Enum):
    """Quark quantization schemes."""

    W8A8_INT8 = "w8a8_int8"
    W8A8_FP8 = "w8a8_fp8"
    OCP_MX = "ocp_mx"


class QuarkConfig(BaseModel):
    """Configuration for Quark quantization."""

    scheme: QuarkScheme = Field(
        default=QuarkScheme.W8A8_INT8,
        description="Quark quantization scheme",
    )

    weight_bits: int = Field(
        default=8,
        ge=4,
        le=8,
        description="Number of bits for weight quantization",
    )

    activation_bits: int = Field(
        default=8,
        ge=4,
        le=8,
        description="Number of bits for activation quantization",
    )

    symmetric: bool = Field(
        default=True,
        description="Whether to use symmetric quantization",
    )

    per_channel: bool = Field(
        default=True,
        description="Whether to use per-channel quantization for weights",
    )

    per_token: bool = Field(
        default=True,
        description="Whether to use per-token quantization for activations",
    )

    calibration_mode: Literal["static", "dynamic"] = Field(
        default="dynamic",
        description="Calibration mode for quantization",
    )

    use_moe: bool = Field(
        default=False,
        description="Whether to use MoE (Mixture of Experts) quantization",
    )


__all__ = ["QuarkScheme", "QuarkConfig"]
