# SPDX-License-Identifier: Apache-2.0
"""Base schema for Quark quantization schemes."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import mlx.core as mx


class QuarkSchemeBase(ABC):
    """Base class for Quark quantization schemes."""

    @abstractmethod
    def quantize(self, tensor: mx.array) -> tuple[mx.array, dict[str, Any]]:
        """
        Quantize a tensor according to the scheme.

        Args:
            tensor: Input tensor.

        Returns:
            Tuple of (quantized_tensor, quantization_params).
        """
        pass

    @abstractmethod
    def dequantize(
        self, quantized: mx.array, params: dict[str, Any]
    ) -> mx.array:
        """
        Dequantize a tensor.

        Args:
            quantized: Quantized tensor.
            params: Quantization parameters.

        Returns:
            Dequantized tensor.
        """
        pass

    @abstractmethod
    def get_dtype(self) -> mx.Dtype:
        """Get the quantized data type."""
        pass


__all__ = ["QuarkSchemeBase"]
