# SPDX-License-Identifier: Apache-2.0
"""W8A8 FP8 quantization scheme for Quark."""

from __future__ import annotations

from typing import Any

import mlx.core as mx

from .quark_scheme import QuarkSchemeBase


class QuarkW8A8FP8Scheme(QuarkSchemeBase):
    """
    W8A8 FP8 quantization scheme.

    8-bit floating point quantization for both weights and activations.
    Note: MLX doesn't natively support FP8, so we simulate with scaled floats.
    """

    def __init__(self, per_channel: bool = True):
        """
        Initialize W8A8 FP8 scheme.

        Args:
            per_channel: Whether to use per-channel quantization.
        """
        self.per_channel = per_channel

    def quantize(
        self, tensor: mx.array
    ) -> tuple[mx.array, dict[str, Any]]:
        """
        Quantize to FP8 (simulated).

        Since MLX doesn't have native FP8, we use float16 with reduced range.
        """
        # Compute scale to fit into FP8 range (max ~240)
        if self.per_channel:
            max_val = mx.max(mx.abs(tensor), axis=0, keepdims=True)
        else:
            max_val = mx.max(mx.abs(tensor))

        scale = max_val / 240.0
        scale = mx.maximum(scale, 1e-8)

        # Quantize to FP8 (simulated with float16)
        # Note: We don't re-multiply by scale here to keep it as float16
        quantized = (tensor / scale).astype(mx.float16)

        params = {"scale": scale}

        return quantized, params

    def dequantize(
        self, quantized: mx.array, params: dict[str, Any]
    ) -> mx.array:
        """Dequantize from FP8 (already in float)."""
        return quantized.astype(mx.float32)

    def get_dtype(self) -> mx.Dtype:
        """Get quantized dtype."""
        return mx.float16


__all__ = ["QuarkW8A8FP8Scheme"]
