# SPDX-License-Identifier: Apache-2.0
"""Quark MoE (Mixture of Experts) quantization for MLX-LLM.

Provides quantization for MoE layers using Quark-style W8A8 quantization.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .base_config import QuarkConfig
from .quark import QuarkQuantizedLinear


class QuarkQuantizedMoE(nn.Module):
    """
    Quantized Mixture of Experts using Quark W8A8 quantization.

    Applies quantization to expert linear layers in MoE architectures.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        num_experts: int = 8,
        config: QuarkConfig | None = None,
        top_k: int = 2,
        **kwargs: Any,
    ):
        """
        Initialize quantized MoE layer.

        Args:
            input_size: Input dimension.
            output_size: Output dimension for each expert.
            num_experts: Number of expert networks (default: 8).
            config: Quark quantization config.
            top_k: Number of experts to route to per token.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.num_experts = num_experts
        self.input_size = input_size
        self.output_size = output_size
        self.top_k = top_k
        self.config = config or QuarkConfig()

        # Create quantized expert layers
        self.experts = [
            QuarkQuantizedLinear(
                input_size=input_size,
                output_size=output_size,
                config=self.config,
                bias=False,
            )
            for _ in range(num_experts)
        ]

        # Gating network (not quantized for accuracy)
        self.gate = nn.Linear(input_size, num_experts, bias=False)

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass with expert routing.

        Args:
            x: Input tensor (batch, seq_len, input_size).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        batch_size, seq_len, _ = x.shape

        # Compute gating scores
        gate_logits = self.gate(x)  # (batch, seq_len, num_experts)
        gate_scores = mx.softmax(gate_logits, axis=-1)

        # Select top-k experts
        # Note: MLX's topk only returns values, not indices
        # We need to use argsort to get indices
        sorted_indices = mx.argsort(gate_scores, axis=-1)
        top_k_indices = sorted_indices[..., -self.top_k:]  # Get last k (highest scores)

        # Gather top-k scores
        # Create indices for gathering
        batch_idx = mx.arange(batch_size)[:, None, None]
        seq_idx = mx.arange(seq_len)[None, :, None]
        top_k_scores = gate_scores[batch_idx, seq_idx, top_k_indices]

        # Normalize top-k scores
        top_k_scores = top_k_scores / mx.sum(top_k_scores, axis=-1, keepdims=True)

        # Compute expert outputs
        output = mx.zeros((batch_size, seq_len, self.output_size))

        for k in range(self.top_k):
            # Get expert indices for this k
            expert_ids = top_k_indices[:, :, k]  # (batch, seq_len)
            scores = top_k_scores[:, :, k : k + 1]  # (batch, seq_len, 1)

            # Process each expert
            for expert_id in range(self.num_experts):
                # Mask for tokens routed to this expert
                mask = (expert_ids == expert_id).astype(mx.float32)
                mask = mx.expand_dims(mask, -1)  # (batch, seq_len, 1)

                # Expert output
                expert_out = self.experts[expert_id](x)

                # Add weighted expert output
                output = output + expert_out * mask * scores

        return output

    def load_weights(
        self,
        gate_weights: mx.array,
        expert_weights: list[mx.array],
    ) -> None:
        """
        Load weights for all experts.

        Args:
            gate_weights: Gate network weights.
            expert_weights: List of weight arrays for each expert.
        """
        if len(expert_weights) != self.num_experts:
            raise ValueError(
                f"Expected {self.num_experts} expert weights, "
                f"got {len(expert_weights)}"
            )

        # Load gate weights
        self.gate.weight = gate_weights

        # Load expert weights
        for i, weights in enumerate(expert_weights):
            self.experts[i].load_weights(weights)

    def get_memory_footprint(self) -> dict[str, int]:
        """Get memory usage breakdown."""
        expert_mem = sum(
            expert.get_memory_footprint()["total"] for expert in self.experts
        )

        gate_mem = self.num_experts * self.input_size * 4  # float32

        return {
            "experts": expert_mem,
            "gate": gate_mem,
            "total": expert_mem + gate_mem,
        }


__all__ = ["QuarkQuantizedMoE"]
