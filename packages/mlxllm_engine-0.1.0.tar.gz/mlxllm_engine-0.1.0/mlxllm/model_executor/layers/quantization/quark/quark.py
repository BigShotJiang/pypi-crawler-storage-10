# SPDX-License-Identifier: Apache-2.0
"""Quark-inspired quantized linear layer for MLX-LLM.

Provides W8A8 (8-bit weights and activations) quantization adapted for MLX.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .base_config import QuarkConfig
from .utils import quantize_tensor, dequantize_tensor


class QuarkQuantizedLinear(nn.Module):
    """
    Quark-inspired W8A8 quantized linear layer for MLX.

    Implements 8-bit quantization for both weights and activations,
    adapted from Quark's CUDA implementation for Apple Silicon.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        config: QuarkConfig | None = None,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize Quark quantized linear layer.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            config: Quark quantization config.
            bias: Whether to use bias.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.input_size = input_size
        self.output_size = output_size
        self.config = config or QuarkConfig()

        # Quantized weights
        self.weight_quantized = None
        self.weight_scale = None

        # Bias (not quantized)
        self._bias = mx.zeros(output_size) if bias else None

        # Calibration stats (for static quantization)
        self.calibration_min = None
        self.calibration_max = None

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass with W8A8 quantization.

        Args:
            x: Input tensor (batch, seq_len, input_size).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        if self.weight_quantized is None:
            raise RuntimeError("Weights not loaded. Call load_weights() first.")

        # Quantize activations
        if self.config.per_token:
            x_quant, x_scale = quantize_tensor(
                x,
                bits=self.config.activation_bits,
                symmetric=self.config.symmetric,
                per_channel=True,
                axis=-1,
            )
        else:
            x_quant, x_scale = quantize_tensor(
                x,
                bits=self.config.activation_bits,
                symmetric=self.config.symmetric,
                per_channel=False,
            )

        # Dequantize for computation (MLX matmul expects float)
        x_dequant = dequantize_tensor(x_quant, x_scale, self.config.symmetric)
        w_dequant = dequantize_tensor(
            self.weight_quantized, self.weight_scale, self.config.symmetric
        )

        # Matrix multiplication
        output = mx.matmul(x_dequant, w_dequant.T)

        # Add bias
        if self._bias is not None:
            output = output + self._bias

        return output

    def load_weights(
        self,
        weights: mx.array,
        bias: mx.array | None = None,
    ) -> None:
        """
        Load and quantize weights.

        Args:
            weights: Full-precision weights (output_size, input_size).
            bias: Optional bias term.
        """
        if weights.shape != (self.output_size, self.input_size):
            raise ValueError(
                f"Expected weights shape ({self.output_size}, {self.input_size}), "
                f"got {weights.shape}"
            )

        # Quantize weights
        if self.config.per_channel:
            self.weight_quantized, self.weight_scale = quantize_tensor(
                weights,
                bits=self.config.weight_bits,
                symmetric=self.config.symmetric,
                per_channel=True,
                axis=0,  # Per output channel
            )
        else:
            self.weight_quantized, self.weight_scale = quantize_tensor(
                weights,
                bits=self.config.weight_bits,
                symmetric=self.config.symmetric,
                per_channel=False,
            )

        # Load bias
        if bias is not None:
            self._bias = bias

    def get_memory_footprint(self) -> dict[str, int]:
        """Get memory usage breakdown."""
        # Quantized weights (int8)
        weight_bytes = self.output_size * self.input_size

        # Scales (float32)
        if self.config.per_channel:
            scale_bytes = self.output_size * 4
        else:
            scale_bytes = 4

        # Bias
        bias_bytes = self.output_size * 4 if self._bias is not None else 0

        return {
            "weights": weight_bytes,
            "scales": scale_bytes,
            "bias": bias_bytes,
            "total": weight_bytes + scale_bytes + bias_bytes,
        }


__all__ = ["QuarkQuantizedLinear"]
