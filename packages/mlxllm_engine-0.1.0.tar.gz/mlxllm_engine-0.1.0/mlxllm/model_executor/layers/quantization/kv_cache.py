# SPDX-License-Identifier: Apache-2.0
"""KV Cache quantization for MLX-LLM.

Provides quantized KV cache to reduce memory usage during inference.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx


class KVCache:
    """
    Key-value cache for attention layers.

    Stores past keys and values for efficient autoregressive generation.
    """

    def __init__(
        self,
        max_batch_size: int = 1,
        max_seq_len: int = 2048,
        num_heads: int = 32,
        head_dim: int = 128,
        dtype: mx.Dtype = mx.float16,
    ):
        """
        Initialize KV cache.

        Args:
            max_batch_size: Maximum batch size.
            max_seq_len: Maximum sequence length.
            num_heads: Number of attention heads.
            head_dim: Dimension per head.
            dtype: Data type for cache.
        """
        self.max_batch_size = max_batch_size
        self.max_seq_len = max_seq_len
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.dtype = dtype

        # Initialize empty cache
        self.keys = mx.zeros(
            (max_batch_size, num_heads, max_seq_len, head_dim), dtype=dtype
        )
        self.values = mx.zeros(
            (max_batch_size, num_heads, max_seq_len, head_dim), dtype=dtype
        )

        self.current_length = 0

    def update(
        self,
        keys: mx.array,
        values: mx.array,
        start_pos: int = 0,
    ) -> tuple[mx.array, mx.array]:
        """
        Update cache with new keys and values.

        Args:
            keys: New keys (batch, num_heads, seq_len, head_dim).
            values: New values (batch, num_heads, seq_len, head_dim).
            start_pos: Starting position for new keys/values.

        Returns:
            Tuple of (all_keys, all_values) up to current position.
        """
        batch_size, num_heads, seq_len, head_dim = keys.shape

        # Update cache
        end_pos = start_pos + seq_len

        self.keys[:batch_size, :, start_pos:end_pos, :] = keys
        self.values[:batch_size, :, start_pos:end_pos, :] = values

        self.current_length = end_pos

        # Return all keys/values up to current position
        return (
            self.keys[:batch_size, :, :end_pos, :],
            self.values[:batch_size, :, :end_pos, :],
        )

    def reset(self):
        """Reset cache to empty state."""
        self.current_length = 0

    def get_memory_usage(self) -> int:
        """
        Get memory usage in bytes.

        Returns:
            Memory usage in bytes.
        """
        num_elements = self.keys.size + self.values.size
        bytes_per_element = 2 if self.dtype == mx.float16 else 4

        return num_elements * bytes_per_element


class QuantizedKVCache:
    """
    Quantized KV cache for reduced memory usage.

    Quantizes keys and values to lower precision (e.g., int8).
    """

    def __init__(
        self,
        max_batch_size: int = 1,
        max_seq_len: int = 2048,
        num_heads: int = 32,
        head_dim: int = 128,
        quantize_bits: int = 8,
    ):
        """
        Initialize quantized KV cache.

        Args:
            max_batch_size: Maximum batch size.
            max_seq_len: Maximum sequence length.
            num_heads: Number of attention heads.
            head_dim: Dimension per head.
            quantize_bits: Number of bits for quantization (4 or 8).
        """
        self.max_batch_size = max_batch_size
        self.max_seq_len = max_seq_len
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.quantize_bits = quantize_bits

        # Determine quantized dtype
        if quantize_bits == 8:
            self.quant_dtype = mx.int8
        elif quantize_bits == 4:
            # MLX doesn't have int4, use int8 and pack manually
            self.quant_dtype = mx.int8
        else:
            raise ValueError(f"Unsupported quantize_bits: {quantize_bits}")

        # Quantized cache
        self.keys = mx.zeros(
            (max_batch_size, num_heads, max_seq_len, head_dim), dtype=self.quant_dtype
        )
        self.values = mx.zeros(
            (max_batch_size, num_heads, max_seq_len, head_dim), dtype=self.quant_dtype
        )

        # Scale factors for dequantization
        self.key_scales = mx.ones((max_batch_size, num_heads, max_seq_len, 1))
        self.value_scales = mx.ones((max_batch_size, num_heads, max_seq_len, 1))

        self.current_length = 0

    def _quantize(self, tensor: mx.array) -> tuple[mx.array, mx.array]:
        """
        Quantize tensor to int8.

        Args:
            tensor: Input tensor.

        Returns:
            Tuple of (quantized_tensor, scale).
        """
        # Compute scale (per-token)
        scale = mx.max(mx.abs(tensor), axis=-1, keepdims=True) / 127.0

        # Quantize
        quantized = mx.round(tensor / (scale + 1e-8)).astype(self.quant_dtype)

        return quantized, scale

    def _dequantize(self, quantized: mx.array, scale: mx.array) -> mx.array:
        """
        Dequantize tensor.

        Args:
            quantized: Quantized tensor.
            scale: Scale factor.

        Returns:
            Dequantized tensor.
        """
        return quantized.astype(mx.float32) * scale

    def update(
        self,
        keys: mx.array,
        values: mx.array,
        start_pos: int = 0,
    ) -> tuple[mx.array, mx.array]:
        """
        Update cache with new keys and values (quantized).

        Args:
            keys: New keys (batch, num_heads, seq_len, head_dim).
            values: New values (batch, num_heads, seq_len, head_dim).
            start_pos: Starting position.

        Returns:
            Tuple of (dequantized_keys, dequantized_values).
        """
        batch_size, num_heads, seq_len, head_dim = keys.shape

        # Quantize
        keys_quant, key_scales = self._quantize(keys)
        values_quant, value_scales = self._quantize(values)

        # Update cache
        end_pos = start_pos + seq_len

        self.keys[:batch_size, :, start_pos:end_pos, :] = keys_quant
        self.values[:batch_size, :, start_pos:end_pos, :] = values_quant
        self.key_scales[:batch_size, :, start_pos:end_pos, :] = key_scales
        self.value_scales[:batch_size, :, start_pos:end_pos, :] = value_scales

        self.current_length = end_pos

        # Dequantize and return
        all_keys_quant = self.keys[:batch_size, :, :end_pos, :]
        all_values_quant = self.values[:batch_size, :, :end_pos, :]
        all_key_scales = self.key_scales[:batch_size, :, :end_pos, :]
        all_value_scales = self.value_scales[:batch_size, :, :end_pos, :]

        all_keys = self._dequantize(all_keys_quant, all_key_scales)
        all_values = self._dequantize(all_values_quant, all_value_scales)

        return all_keys, all_values

    def reset(self):
        """Reset cache."""
        self.current_length = 0

    def get_memory_usage(self) -> int:
        """Get memory usage in bytes."""
        # Quantized cache (int8) + scales (float32)
        quant_size = self.keys.size + self.values.size  # 1 byte per element
        scales_size = (self.key_scales.size + self.value_scales.size) * 4  # 4 bytes per float32

        return quant_size + scales_size
