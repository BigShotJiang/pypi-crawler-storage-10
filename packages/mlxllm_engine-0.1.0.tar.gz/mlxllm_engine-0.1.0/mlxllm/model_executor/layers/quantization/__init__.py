# SPDX-License-Identifier: Apache-2.0
"""Quantization layers for MLX-LLM.

Provides various quantization schemes and kernels optimized for Apple Silicon:

Mixed-Precision Kernels:
- MPLinearKernel: Base class for mixed-precision quantization
- MLXQuantizedLinear: General-purpose MLX quantization (4-bit, 8-bit)
- Dynamic4BitLinear: Dynamic 4-bit quantization
- MetalCutlassLinear: High-performance quantization using MetalCutlass

Scaled Matrix Multiplication:
- ScaledMMLinearKernel: Base class for scaled MM operations
- M4ScaledMMLinear: Metal-optimized scaled MM for Apple M4

KV Cache:
- KVCache: Standard key-value cache
- QuantizedKVCache: Quantized KV cache for reduced memory usage

Configuration:
- QuantizationConfig: Configuration for quantization schemes
"""

from __future__ import annotations

# KV Cache
from .kv_cache import KVCache, QuantizedKVCache

# Mixed-precision kernels
from .kernals.mixed_precision import (
    Dynamic4BitLinear,
    METALCUTLASS_AVAILABLE,
    MetalCutlassLinear,
    MLXQuantizedLinear,
    MPLinearKernel,
)

# Scaled MM kernels
from .kernals.scaled_mm import M4ScaledMMLinear, ScaledMMLinearKernel

__all__ = [
    # KV Cache
    "KVCache",
    "QuantizedKVCache",
    # Mixed-precision kernels
    "MPLinearKernel",
    "MLXQuantizedLinear",
    "Dynamic4BitLinear",
    "MetalCutlassLinear",
    "METALCUTLASS_AVAILABLE",
    # Scaled MM kernels
    "ScaledMMLinearKernel",
    "M4ScaledMMLinear",
]
