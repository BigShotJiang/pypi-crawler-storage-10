# SPDX-License-Identifier: Apache-2.0
"""Mamba quantization support for MLX-LLM.

Provides quantization for Mamba SSM (State Space Model) layers.
Mamba is an alternative to attention that uses selective state spaces.

Note: Full Mamba quantization implementation requires the Mamba architecture
to be implemented first. This module provides the interface.
"""

from __future__ import annotations

from .mamba_quant import QuantizedMambaLayer

__all__ = [
    "QuantizedMambaLayer",
]
