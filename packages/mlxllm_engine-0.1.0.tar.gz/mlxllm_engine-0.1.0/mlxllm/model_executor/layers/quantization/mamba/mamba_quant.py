# SPDX-License-Identifier: Apache-2.0
"""Quantized Mamba layer for MLX-LLM.

Provides quantization support for Mamba SSM (State Space Model) layers.
Mamba is a linear-time sequence modeling architecture that uses selective
state spaces as an alternative to attention.

Reference: "Mamba: Linear-Time Sequence Modeling with Selective State Spaces"
           (Gu & Dao, 2023)
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from ..kernals.mixed_precision import MPLinearKernel, MLXQuantizedLinear


class QuantizedMambaLayer(nn.Module):
    """
    Quantized Mamba SSM layer.

    Mamba uses selective state space models for sequence modeling.
    This implementation quantizes the projection layers to reduce memory usage.

    Architecture:
    1. Input projection (in_proj) - quantized
    2. Selective SSM operation - full precision
    3. Output projection (out_proj) - quantized

    Note: The SSM core computation remains in full precision for stability,
    while the linear projections are quantized for memory efficiency.
    """

    def __init__(
        self,
        d_model: int,
        d_state: int = 16,
        d_conv: int = 4,
        expand: int = 2,
        weight_bits: int = 4,
        activation_bits: int = 16,
        group_size: int = 128,
        use_metalcutlass: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize quantized Mamba layer.

        Args:
            d_model: Model dimension.
            d_state: SSM state dimension.
            d_conv: Convolution kernel size.
            expand: Expansion factor for hidden dimension.
            weight_bits: Quantization bits for weights.
            activation_bits: Quantization bits for activations.
            group_size: Group size for weight quantization.
            use_metalcutlass: Whether to use MetalCutlass backend.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.d_model = d_model
        self.d_state = d_state
        self.d_conv = d_conv
        self.expand = expand
        self.d_inner = d_model * expand

        # Import here to avoid circular dependency
        if use_metalcutlass:
            from ..kernals.mixed_precision import MetalCutlassLinear

            linear_cls = MetalCutlassLinear
        else:
            linear_cls = MLXQuantizedLinear

        # Quantized input projection
        self.in_proj = linear_cls(
            input_size=d_model,
            output_size=self.d_inner * 2,  # For gated activation
            weight_bits=weight_bits,
            activation_bits=activation_bits,
            group_size=group_size,
        )

        # Convolution for short-term context (not quantized)
        # MLX doesn't have Conv1d, use Linear approximation
        self.conv1d = nn.Linear(self.d_inner, self.d_inner, bias=True)

        # SSM parameters (full precision for stability)
        self.A = mx.random.normal((self.d_inner, d_state))  # State transition
        self.D = mx.ones(self.d_inner)  # Skip connection

        # Selective parameters (full precision)
        self.x_proj = nn.Linear(self.d_inner, d_state * 2, bias=False)
        self.dt_proj = nn.Linear(d_state, self.d_inner, bias=True)

        # Quantized output projection
        self.out_proj = linear_cls(
            input_size=self.d_inner,
            output_size=d_model,
            weight_bits=weight_bits,
            activation_bits=activation_bits,
            group_size=group_size,
        )

        # Activation function
        self.act = nn.SiLU()

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input tensor (batch, seq_len, d_model).

        Returns:
            Output tensor (batch, seq_len, d_model).
        """
        batch_size, seq_len, _ = x.shape

        # Quantized input projection
        x_proj = self.in_proj(x)

        # Split for gated activation
        x_gate, x_value = mx.split(x_proj, 2, axis=-1)

        # Apply convolution for short-term context
        x_conv = self.conv1d(x_gate)
        x_conv = self.act(x_conv)

        # Selective SSM
        x_ssm = self._selective_ssm(x_conv)

        # Gated activation
        x_out = x_ssm * self.act(x_value)

        # Quantized output projection
        output = self.out_proj(x_out)

        return output

    def _selective_ssm(self, x: mx.array) -> mx.array:
        """
        Selective state space model computation.

        This implements the core Mamba SSM operation with selection mechanism.

        Args:
            x: Input tensor (batch, seq_len, d_inner).

        Returns:
            Output tensor (batch, seq_len, d_inner).
        """
        batch_size, seq_len, d_inner = x.shape

        # Compute selective parameters
        x_dbl = self.x_proj(x)  # (batch, seq_len, d_state * 2)
        delta, B = mx.split(x_dbl, 2, axis=-1)  # (batch, seq_len, d_state) each

        # Compute delta (time step parameter)
        delta = self.dt_proj(delta)  # (batch, seq_len, d_inner)
        delta = nn.softplus(delta)

        # Discretize state space model
        # A: continuous state transition matrix
        # B: input-to-state matrix
        # Discretization: A_discrete = exp(delta * A)
        A_discrete = mx.exp(
            mx.expand_dims(delta, -1) * mx.expand_dims(self.A, 0)
        )  # (batch, seq_len, d_inner, d_state)

        # State space computation (simplified for demonstration)
        # Full implementation would use parallel scan or recurrent computation
        state = mx.zeros((batch_size, d_inner, self.d_state))
        outputs = []

        for t in range(seq_len):
            # Get current inputs
            x_t = x[:, t, :]  # (batch, d_inner)
            delta_t = delta[:, t, :]  # (batch, d_inner)
            B_t = B[:, t, :]  # (batch, d_state)
            A_t = A_discrete[:, t, :, :]  # (batch, d_inner, d_state)

            # Update state: s_t = A_t * s_{t-1} + B_t * x_t
            state = state * A_t[:, :, :] + mx.expand_dims(x_t, -1) * mx.expand_dims(
                B_t, 1
            )

            # Compute output: y_t = C_t * s_t + D * x_t
            # Here we use simple sum as C (more complex in full implementation)
            y_t = mx.sum(state, axis=-1) + self.D * x_t

            outputs.append(y_t)

        # Stack outputs
        output = mx.stack(outputs, axis=1)  # (batch, seq_len, d_inner)

        return output

    def load_weights(
        self,
        in_proj_weights: mx.array,
        out_proj_weights: mx.array,
        ssm_params: dict[str, mx.array] | None = None,
    ) -> None:
        """
        Load weights for the quantized Mamba layer.

        Args:
            in_proj_weights: Input projection weights.
            out_proj_weights: Output projection weights.
            ssm_params: Optional SSM parameters (A, D, etc.).
        """
        # Load quantized projections
        self.in_proj.load_weights(in_proj_weights)
        self.out_proj.load_weights(out_proj_weights)

        # Load SSM parameters if provided
        if ssm_params is not None:
            if "A" in ssm_params:
                self.A = ssm_params["A"]
            if "D" in ssm_params:
                self.D = ssm_params["D"]

    def get_memory_footprint(self) -> dict[str, int]:
        """
        Get memory usage breakdown.

        Returns:
            Dictionary with memory usage in bytes.
        """
        in_proj_mem = self.in_proj.get_memory_footprint()
        out_proj_mem = self.out_proj.get_memory_footprint()

        # SSM parameters (full precision)
        ssm_mem = (
            self.A.size * 4 + self.D.size * 4  # A matrix  # D vector
        )

        return {
            "in_proj": in_proj_mem["total"],
            "out_proj": out_proj_mem["total"],
            "ssm_params": ssm_mem,
            "total": in_proj_mem["total"] + out_proj_mem["total"] + ssm_mem,
        }


__all__ = ["QuantizedMambaLayer"]
