# SPDX-License-Identifier: Apache-2.0
"""Quantization configuration classes for MLX-LLM.

Provides Pydantic-based configuration for various quantization schemes.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class QuantizationMethod(str, Enum):
    """Supported quantization methods."""

    NONE = "none"
    MLX_QUANTIZED = "mlx_quantized"
    DYNAMIC_4BIT = "dynamic_4bit"
    METALCUTLASS = "metalcutlass"
    SCALED_MM = "scaled_mm"
    W8A8_INT8 = "w8a8_int8"
    W8A8_FP8 = "w8a8_fp8"


class QuantizationConfig(BaseModel):
    """Base configuration for quantization."""

    method: QuantizationMethod = Field(
        default=QuantizationMethod.NONE,
        description="Quantization method to use",
    )

    enabled: bool = Field(
        default=False,
        description="Whether quantization is enabled",
    )

    weight_bits: int = Field(
        default=4,
        ge=2,
        le=8,
        description="Number of bits for weight quantization (2-8)",
    )

    activation_bits: int = Field(
        default=16,
        ge=4,
        le=16,
        description="Number of bits for activation quantization (4-16)",
    )

    group_size: int = Field(
        default=128,
        ge=32,
        le=256,
        description="Group size for weight quantization",
    )

    @field_validator("weight_bits")
    @classmethod
    def validate_weight_bits(cls, v: int) -> int:
        """Validate weight bits are supported."""
        if v not in [2, 4, 8]:
            raise ValueError(f"weight_bits must be 2, 4, or 8, got {v}")
        return v

    @field_validator("group_size")
    @classmethod
    def validate_group_size(cls, v: int) -> int:
        """Validate group size is a power of 2."""
        if v & (v - 1) != 0:
            raise ValueError(f"group_size must be a power of 2, got {v}")
        return v

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return self.model_dump()


class MixedPrecisionConfig(QuantizationConfig):
    """Configuration for mixed-precision quantization."""

    method: QuantizationMethod = Field(
        default=QuantizationMethod.MLX_QUANTIZED,
        description="Mixed-precision quantization method",
    )

    use_bias: bool = Field(
        default=False,
        description="Whether to use bias in quantized layers",
    )

    dynamic_activation_quant: bool = Field(
        default=True,
        description="Whether to use dynamic activation quantization",
    )

    kernel_backend: Literal["mlx", "metalcutlass"] = Field(
        default="mlx",
        description="Backend to use for quantization kernels",
    )

    @field_validator("method")
    @classmethod
    def validate_method(cls, v: QuantizationMethod) -> QuantizationMethod:
        """Validate method is a mixed-precision method."""
        valid_methods = {
            QuantizationMethod.MLX_QUANTIZED,
            QuantizationMethod.DYNAMIC_4BIT,
            QuantizationMethod.METALCUTLASS,
        }
        if v not in valid_methods:
            raise ValueError(
                f"method must be one of {valid_methods}, got {v}"
            )
        return v


class ScaledMMConfig(QuantizationConfig):
    """Configuration for scaled matrix multiplication."""

    method: QuantizationMethod = Field(
        default=QuantizationMethod.SCALED_MM,
        description="Scaled MM quantization method",
    )

    use_int8: bool = Field(
        default=True,
        description="Whether to use int8 quantization",
    )

    per_channel_scales: bool = Field(
        default=True,
        description="Whether to use per-channel scales",
    )

    symmetric_quant: bool = Field(
        default=True,
        description="Whether to use symmetric quantization",
    )


class KVCacheQuantConfig(BaseModel):
    """Configuration for KV cache quantization."""

    enabled: bool = Field(
        default=False,
        description="Whether to quantize KV cache",
    )

    quantize_bits: int = Field(
        default=8,
        description="Number of bits for KV cache quantization (4 or 8)",
    )

    per_token_quant: bool = Field(
        default=True,
        description="Whether to use per-token quantization",
    )

    @field_validator("quantize_bits")
    @classmethod
    def validate_quantize_bits(cls, v: int) -> int:
        """Validate quantize bits."""
        if v not in [4, 8]:
            raise ValueError(f"quantize_bits must be 4 or 8, got {v}")
        return v


__all__ = [
    "QuantizationMethod",
    "QuantizationConfig",
    "MixedPrecisionConfig",
    "ScaledMMConfig",
    "KVCacheQuantConfig",
]
