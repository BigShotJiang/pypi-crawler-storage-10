# SPDX-License-Identifier: Apache-2.0
"""Mixed-precision linear kernel base class for MLX-LLM.

Provides the abstract interface for mixed-precision quantized linear layers.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import mlx.core as mx
import mlx.nn as nn


class MPLinearKernel(ABC, nn.Module):
    """
    Base class for mixed-precision linear kernels.

    Mixed-precision kernels use different quantization precisions for
    weights and activations to optimize the speed/accuracy trade-off.

    Common patterns:
    - W4A16: 4-bit weights, 16-bit activations
    - W8A8: 8-bit weights and activations (INT8)
    - W4A8: 4-bit weights, 8-bit activations
    - Dynamic quantization: Quantize activations at runtime
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        weight_bits: int = 4,
        activation_bits: int = 16,
        group_size: int = 128,
        **kwargs: Any,
    ):
        """
        Initialize mixed-precision linear kernel.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            weight_bits: Quantization bits for weights (4, 8).
            activation_bits: Quantization bits for activations (8, 16).
            group_size: Group size for weight quantization.
            **kwargs: Additional kernel-specific arguments.
        """
        super().__init__()

        self.input_size = input_size
        self.output_size = output_size
        self.weight_bits = weight_bits
        self.activation_bits = activation_bits
        self.group_size = group_size

    @abstractmethod
    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass with mixed-precision computation.

        Args:
            x: Input tensor (batch, seq_len, input_size).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        pass

    @abstractmethod
    def load_weights(self, weights: mx.array, scales: mx.array | None = None) -> None:
        """
        Load and quantize weights.

        Args:
            weights: Full-precision weights (output_size, input_size).
            scales: Optional pre-computed quantization scales.
        """
        pass

    def get_memory_footprint(self) -> dict[str, int]:
        """
        Get memory usage breakdown.

        Returns:
            Dictionary with memory usage in bytes for each component.
        """
        weight_elements = self.output_size * self.input_size
        weight_bytes_per_element = self.weight_bits / 8

        # Scale factors (per group)
        num_groups = (self.input_size + self.group_size - 1) // self.group_size
        scale_bytes = num_groups * self.output_size * 4  # float32 scales

        return {
            "weights": int(weight_elements * weight_bytes_per_element),
            "scales": scale_bytes,
            "total": int(weight_elements * weight_bytes_per_element + scale_bytes),
        }


__all__ = ["MPLinearKernel"]
