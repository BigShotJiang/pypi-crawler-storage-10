# SPDX-License-Identifier: Apache-2.0
"""Conch quantization kernel (CUDA-specific, not implemented for MLX).

Conch is a CUDA-based quantization library. This module exists for API
compatibility but is not implemented for Apple Silicon.

For MLX on Apple Silicon, use:
- MLXQuantizedLinear (marlin.py) - General-purpose MLX quantization
- Dynamic4BitLinear (dynamic_4bit.py) - Dynamic 4-bit quantization
- M4ScaledMMLinear (../scaled_mm/m4.py) - Scaled matrix multiplication

These provide Metal-optimized implementations for M4 hardware.
"""

from __future__ import annotations

# Not implemented for MLX - use MLX-native kernels instead
