# SPDX-License-Identifier: Apache-2.0
"""Scaled matrix multiplication kernel base class for MLX-LLM.

Provides the abstract interface for scaled matrix multiplication operations
optimized for different hardware backends.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import mlx.core as mx
import mlx.nn as nn


class ScaledMMLinearKernel(ABC, nn.Module):
    """
    Base class for scaled matrix multiplication linear kernels.

    Scaled MM computes: output = scale_out * (X @ W) * scale_x * scale_w
    where scales are applied efficiently during computation.

    This is useful for:
    - INT8/FP8 quantized inference
    - Mixed-precision training
    - Dynamic range optimization
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize scaled MM linear kernel.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            bias: Whether to use bias.
            **kwargs: Additional kernel-specific arguments.
        """
        super().__init__()

        self.input_size = input_size
        self.output_size = output_size
        self.bias_enabled = bias

    @abstractmethod
    def __call__(
        self,
        x: mx.array,
        weight: mx.array,
        scale_x: mx.array | None = None,
        scale_w: mx.array | None = None,
        scale_out: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass with scaled matrix multiplication.

        Args:
            x: Input tensor (batch, seq_len, input_size).
            weight: Weight tensor (output_size, input_size).
            scale_x: Scale for input (optional).
            scale_w: Scale for weights (optional).
            scale_out: Scale for output (optional).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        pass

    @abstractmethod
    def load_weights(
        self,
        weights: mx.array,
        scales: mx.array | None = None,
        bias: mx.array | None = None,
    ) -> None:
        """
        Load weights and optional scales.

        Args:
            weights: Weight tensor (output_size, input_size).
            scales: Optional weight scales.
            bias: Optional bias term.
        """
        pass

    def get_memory_footprint(self) -> dict[str, int]:
        """
        Get memory usage breakdown.

        Returns:
            Dictionary with memory usage in bytes for each component.
        """
        # Default implementation - override in subclasses
        weight_bytes = self.output_size * self.input_size * 4  # float32
        bias_bytes = self.output_size * 4 if self.bias_enabled else 0

        return {
            "weights": weight_bytes,
            "bias": bias_bytes,
            "total": weight_bytes + bias_bytes,
        }


__all__ = ["ScaledMMLinearKernel"]
