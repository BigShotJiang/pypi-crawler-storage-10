# SPDX-License-Identifier: Apache-2.0
"""Dynamic 4-bit quantization kernel for MLX.

Implements dynamic 4-bit weight quantization with runtime activation quantization
optimized for Apple Silicon using MLX's Metal backend.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .MPLinearKernel import MPLinearKernel


class Dynamic4BitLinear(MPLinearKernel):
    """
    Dynamic 4-bit quantized linear layer for MLX.

    Features:
    - 4-bit weight quantization with group-wise scales
    - Dynamic activation quantization at runtime
    - Optimized for Apple Silicon Metal backend
    - Minimal accuracy loss compared to FP16
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        weight_bits: int = 4,
        activation_bits: int = 16,
        group_size: int = 128,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize dynamic 4-bit linear kernel.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            weight_bits: Weight quantization bits (must be 4).
            activation_bits: Activation bits (8 for dynamic quant, 16 for FP16).
            group_size: Group size for weight quantization.
            bias: Whether to use bias.
            **kwargs: Additional arguments.
        """
        super().__init__(
            input_size=input_size,
            output_size=output_size,
            weight_bits=weight_bits,
            activation_bits=activation_bits,
            group_size=group_size,
            **kwargs,
        )

        if weight_bits != 4:
            raise ValueError(f"Dynamic4BitLinear requires 4-bit weights, got {weight_bits}")

        # Use MLX's native 4-bit quantized linear
        self.quantized_linear = nn.QuantizedLinear(
            input_size,
            output_size,
            bias=bias,
            bits=4,
            group_size=group_size,
        )

        self.dynamic_quant_enabled = activation_bits == 8
        self._bias = mx.zeros(output_size) if bias else None

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass with dynamic quantization.

        Args:
            x: Input tensor (batch, seq_len, input_size).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        # Apply dynamic activation quantization if enabled
        if self.dynamic_quant_enabled:
            x_quant, scale = self._dynamic_quantize_activations(x)
            # Dequantize before matmul (MLX quantized linear expects float)
            x = x_quant.astype(mx.float32) * scale

        # Use MLX's optimized 4-bit quantized matmul
        output = self.quantized_linear(x)

        return output

    def _dynamic_quantize_activations(
        self, x: mx.array
    ) -> tuple[mx.array, mx.array]:
        """
        Dynamically quantize activations to int8.

        Uses per-token quantization for better accuracy.

        Args:
            x: Input activations (batch, seq_len, input_size).

        Returns:
            Tuple of (quantized_x, scale).
        """
        # Compute per-token scale
        scale = mx.max(mx.abs(x), axis=-1, keepdims=True) / 127.0
        scale = mx.maximum(scale, 1e-8)  # Prevent division by zero

        # Quantize to int8
        x_quant = mx.round(x / scale).astype(mx.int8)

        return x_quant, scale

    def load_weights(
        self, weights: mx.array, scales: mx.array | None = None
    ) -> None:
        """
        Load and quantize weights to 4-bit.

        Args:
            weights: Full-precision weights (output_size, input_size).
            scales: Optional pre-computed scales (ignored, computed internally).
        """
        if weights.shape != (self.output_size, self.input_size):
            raise ValueError(
                f"Expected weights shape ({self.output_size}, {self.input_size}), "
                f"got {weights.shape}"
            )

        # Quantize weights using MLX's quantization
        quantized_weights, scales_internal, biases = mx.quantize(
            weights,
            bits=4,
            group_size=self.group_size,
        )

        # Set quantized parameters
        self.quantized_linear.weight = quantized_weights
        self.quantized_linear.scales = scales_internal
        self.quantized_linear.biases = biases

    def get_memory_footprint(self) -> dict[str, int]:
        """
        Get memory usage breakdown.

        Returns:
            Dictionary with memory usage in bytes.
        """
        # 4-bit weights: 0.5 bytes per element
        weight_elements = self.output_size * self.input_size
        weight_bytes = weight_elements // 2

        # Scale factors (per group)
        num_groups = (self.input_size + self.group_size - 1) // self.group_size
        scale_bytes = num_groups * self.output_size * 4  # float32 scales

        # Bias
        bias_bytes = self.output_size * 4 if self._bias is not None else 0

        return {
            "weights": weight_bytes,
            "scales": scale_bytes,
            "bias": bias_bytes,
            "total": weight_bytes + scale_bytes + bias_bytes,
        }


__all__ = ["Dynamic4BitLinear"]
