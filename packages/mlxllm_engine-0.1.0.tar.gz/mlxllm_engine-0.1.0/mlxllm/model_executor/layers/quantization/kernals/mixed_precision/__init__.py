# SPDX-License-Identifier: Apache-2.0
"""Mixed-precision quantization kernels for MLX-LLM.

Provides various mixed-precision quantization implementations optimized
for Apple Silicon using MLX's Metal backend.

Available Kernels:
- MLXQuantizedLinear: General-purpose MLX quantization (4-bit, 8-bit)
- Dynamic4BitLinear: Dynamic 4-bit quantization with runtime activation quant
- MetalCutlassLinear: High-performance quantization using MetalCutlass C extension

CUDA-Specific (Not Implemented for MLX):
- AllSpark, BitBLAS, Conch, CUTLASS, ExLlama, Machete
  These are CUDA-specific and not needed for Apple Silicon. Use the
  MLX-native kernels above instead.
"""

from __future__ import annotations

from .dynamic_4bit import Dynamic4BitLinear
from .marlin import MLXQuantizedLinear
from .metalcutlass import METALCUTLASS_AVAILABLE, MetalCutlassLinear
from .MPLinearKernel import MPLinearKernel

__all__ = [
    "MPLinearKernel",
    "MLXQuantizedLinear",
    "Dynamic4BitLinear",
    "MetalCutlassLinear",
    "METALCUTLASS_AVAILABLE",
]
