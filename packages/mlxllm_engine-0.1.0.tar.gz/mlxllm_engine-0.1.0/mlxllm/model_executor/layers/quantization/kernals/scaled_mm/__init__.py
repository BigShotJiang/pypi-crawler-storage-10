# SPDX-License-Identifier: Apache-2.0
"""Scaled matrix multiplication kernels for MLX-LLM.

Provides hardware-optimized scaled matrix multiplication implementations
for different backends.
"""

from __future__ import annotations

from .ScaledMMLinearKernel import ScaledMMLinearKernel
from .m4 import M4ScaledMMLinear

__all__ = [
    "ScaledMMLinearKernel",
    "M4ScaledMMLinear",
]
