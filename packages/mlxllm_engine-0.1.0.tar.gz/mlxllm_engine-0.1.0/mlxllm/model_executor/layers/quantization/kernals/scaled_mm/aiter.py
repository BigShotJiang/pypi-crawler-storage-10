# SPDX-License-Identifier: Apache-2.0
"""AIter scaled matrix multiplication (CUDA-specific, not implemented for MLX).

AIter is a CUDA library for optimized scaled matrix multiplication. This module
exists for API compatibility but is not implemented for Apple Silicon.

For MLX on Apple Silicon, use:
- M4ScaledMMLinear (m4.py) - Metal-optimized scaled MM for M4 hardware

This provides equivalent functionality using MLX's Metal backend.
"""

from __future__ import annotations

# Not implemented for MLX - use M4ScaledMMLinear instead
