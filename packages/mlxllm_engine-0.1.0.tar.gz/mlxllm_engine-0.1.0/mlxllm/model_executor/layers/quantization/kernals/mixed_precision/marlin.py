# SPDX-License-Identifier: Apache-2.0
"""MLX-native mixed-precision linear kernel using MLX quantization.

This replaces CUDA Marlin kernels with MLX's native Metal-accelerated quantization.
MLX provides optimized int4/int8 quantization kernels for Apple Silicon.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn

from .MPLinearKernel import MPLinearKernel


class MLXQuantizedLinear(MPLinearKernel):
    """
    MLX-native quantized linear kernel for Apple Silicon.

    Uses MLX's built-in QuantizedLinear which provides Metal-optimized
    kernels for 4-bit and 8-bit quantization.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        weight_bits: int = 4,
        activation_bits: int = 16,
        group_size: int = 128,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize MLX quantized linear kernel.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            weight_bits: Quantization bits for weights (4 or 8).
            activation_bits: Activation precision (8 or 16).
            group_size: Group size for weight quantization.
            bias: Whether to use bias term.
            **kwargs: Additional arguments.
        """
        super().__init__(
            input_size=input_size,
            output_size=output_size,
            weight_bits=weight_bits,
            activation_bits=activation_bits,
            group_size=group_size,
            **kwargs,
        )

        if weight_bits not in [4, 8]:
            raise ValueError(f"MLX supports 4 or 8 bit weights, got {weight_bits}")

        # Use MLX's native QuantizedLinear
        self.quantized_linear = nn.QuantizedLinear(
            input_size,
            output_size,
            bias=bias,
            bits=weight_bits,
            group_size=group_size,
        )

        self.activation_quant_enabled = activation_bits < 16
        self.activation_scale = None

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass with mixed-precision computation.

        Args:
            x: Input tensor (batch, seq_len, input_size).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        # Optionally quantize activations
        if self.activation_quant_enabled:
            x, self.activation_scale = self._quantize_activations(x)

        # Use MLX's optimized quantized matmul
        output = self.quantized_linear(x)

        return output

    def _quantize_activations(self, x: mx.array) -> tuple[mx.array, mx.array]:
        """
        Dynamically quantize activations to int8.

        Args:
            x: Input activations (fp16/fp32).

        Returns:
            Tuple of (quantized_x, scale).
        """
        # Per-token quantization
        scale = mx.max(mx.abs(x), axis=-1, keepdims=True) / 127.0
        scale = mx.maximum(scale, 1e-8)  # Avoid division by zero

        quantized = mx.round(x / scale).astype(mx.int8)

        return quantized, scale

    def load_weights(self, weights: mx.array, scales: mx.array | None = None) -> None:
        """
        Load and quantize weights using MLX quantization.

        Args:
            weights: Full-precision weights (output_size, input_size).
            scales: Optional pre-computed quantization scales (ignored, MLX computes internally).
        """
        if weights.shape != (self.output_size, self.input_size):
            raise ValueError(
                f"Expected weights shape ({self.output_size}, {self.input_size}), "
                f"got {weights.shape}"
            )

        # MLX's QuantizedLinear handles quantization internally
        # We need to quantize the weight and set it
        quantized_weights, scales_internal, biases = mx.quantize(
            weights,
            bits=self.weight_bits,
            group_size=self.group_size,
        )

        # Set quantized parameters
        self.quantized_linear.weight = quantized_weights
        self.quantized_linear.scales = scales_internal
        self.quantized_linear.biases = biases


__all__ = ["MLXQuantizedLinear"]
