# SPDX-License-Identifier: Apache-2.0
"""Metal-optimized scaled matrix multiplication for Apple Silicon (M4).

Implements scaled matrix multiplication using MLX's Metal backend,
optimized for Apple's M4 GPU and unified memory architecture.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx

from .ScaledMMLinearKernel import ScaledMMLinearKernel


class M4ScaledMMLinear(ScaledMMLinearKernel):
    """
    Metal-optimized scaled matrix multiplication for Apple M4.

    Uses MLX's Metal backend for hardware-accelerated scaled MM operations.
    Optimized for:
    - Unified memory architecture
    - Metal Performance Shaders (MPS)
    - AMX instructions for matrix operations
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = False,
        use_int8: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize M4 scaled MM linear kernel.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            bias: Whether to use bias.
            use_int8: Whether to use int8 quantization.
            **kwargs: Additional arguments.
        """
        super().__init__(
            input_size=input_size,
            output_size=output_size,
            bias=bias,
            **kwargs,
        )

        self.use_int8 = use_int8

        # Initialize weights and scales
        self.weight = mx.zeros((output_size, input_size))
        self.scale_w = mx.ones((output_size, 1))
        self.bias_term = mx.zeros(output_size) if bias else None

        # For int8 mode
        self.weight_quantized = None

    def __call__(
        self,
        x: mx.array,
        weight: mx.array | None = None,
        scale_x: mx.array | None = None,
        scale_w: mx.array | None = None,
        scale_out: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass with Metal-optimized scaled matrix multiplication.

        Args:
            x: Input tensor (batch, seq_len, input_size).
            weight: Optional weight override (uses self.weight if None).
            scale_x: Input scale (optional).
            scale_w: Weight scale (optional).
            scale_out: Output scale (optional).

        Returns:
            Output tensor (batch, seq_len, output_size).
        """
        # Use stored weight if not provided
        if weight is None:
            weight = self.weight_quantized if self.use_int8 else self.weight

        if scale_w is None:
            scale_w = self.scale_w

        # Perform scaled matrix multiplication
        if self.use_int8:
            # Int8 path: quantize input, perform int8 matmul, dequantize
            output = self._scaled_int8_matmul(x, weight, scale_x, scale_w)
        else:
            # Float path: apply scales directly
            output = self._scaled_float_matmul(x, weight, scale_x, scale_w)

        # Apply output scale if provided
        if scale_out is not None:
            output = output * scale_out

        # Add bias
        if self.bias_term is not None:
            output = output + self.bias_term

        return output

    def _scaled_float_matmul(
        self,
        x: mx.array,
        weight: mx.array,
        scale_x: mx.array | None,
        scale_w: mx.array,
    ) -> mx.array:
        """
        Scaled matmul in float precision.

        Computes: (scale_x * x) @ (scale_w * weight)^T
        """
        # Scale input if needed
        if scale_x is not None:
            x = x * scale_x

        # MLX's matmul is Metal-optimized
        output = mx.matmul(x, weight.T)

        # Apply weight scale
        output = output * scale_w.T

        return output

    def _scaled_int8_matmul(
        self,
        x: mx.array,
        weight_quantized: mx.array,
        scale_x: mx.array | None,
        scale_w: mx.array,
    ) -> mx.array:
        """
        Scaled matmul in int8 precision.

        Quantizes input to int8, performs int8 matmul, then dequantizes.
        """
        # Quantize input to int8
        if scale_x is None:
            # Dynamic quantization
            scale_x = mx.max(mx.abs(x), axis=-1, keepdims=True) / 127.0
            scale_x = mx.maximum(scale_x, 1e-8)

        x_quantized = mx.round(x / scale_x).astype(mx.int8)

        # Int8 matmul (MLX will use Metal's int8 kernels)
        output = mx.matmul(x_quantized.astype(mx.float32), weight_quantized.T)

        # Dequantize: apply both input and weight scales
        output = output * scale_x * scale_w.T

        return output

    def load_weights(
        self,
        weights: mx.array,
        scales: mx.array | None = None,
        bias: mx.array | None = None,
    ) -> None:
        """
        Load weights and optional scales.

        Args:
            weights: Weight tensor (output_size, input_size).
            scales: Optional weight scales (output_size, 1).
            bias: Optional bias term (output_size,).
        """
        if weights.shape != (self.output_size, self.input_size):
            raise ValueError(
                f"Expected weights shape ({self.output_size}, {self.input_size}), "
                f"got {weights.shape}"
            )

        self.weight = weights

        # Quantize weights if int8 mode
        if self.use_int8:
            if scales is None:
                # Compute scales per-output-channel
                scales = mx.max(mx.abs(weights), axis=1, keepdims=True) / 127.0
                scales = mx.maximum(scales, 1e-8)

            self.scale_w = scales
            self.weight_quantized = mx.round(weights / scales).astype(mx.int8)
        else:
            self.scale_w = scales if scales is not None else mx.ones((self.output_size, 1))

        # Load bias
        if bias is not None:
            if bias.shape != (self.output_size,):
                raise ValueError(
                    f"Expected bias shape ({self.output_size},), got {bias.shape}"
                )
            self.bias_term = bias

    def get_memory_footprint(self) -> dict[str, int]:
        """Get memory usage breakdown."""
        if self.use_int8:
            # Int8 weights + float32 scales
            weight_bytes = self.output_size * self.input_size  # 1 byte per int8
            scale_bytes = self.output_size * 4  # float32 scales
        else:
            # Float32 weights
            weight_bytes = self.output_size * self.input_size * 4
            scale_bytes = self.output_size * 4

        bias_bytes = self.output_size * 4 if self.bias_enabled else 0

        return {
            "weights": weight_bytes,
            "scales": scale_bytes,
            "bias": bias_bytes,
            "total": weight_bytes + scale_bytes + bias_bytes,
        }


__all__ = ["M4ScaledMMLinear"]
