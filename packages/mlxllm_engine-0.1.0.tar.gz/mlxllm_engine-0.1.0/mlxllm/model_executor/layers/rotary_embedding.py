# SPDX-License-Identifier: Apache-2.0
"""Rotary Position Embeddings (RoPE) for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass


class RotaryEmbedding(nn.Module):
    """
    Rotary Position Embedding (RoPE).

    Implements the rotary position encoding from "RoFormer: Enhanced Transformer
    with Rotary Position Embedding" (https://arxiv.org/abs/2104.09864).
    """

    def __init__(
        self,
        head_dim: int,
        max_position_embeddings: int = 8192,
        base: float = 10000.0,
        scaling: dict | None = None,
    ) -> None:
        """
        Initialize RoPE.

        Args:
            head_dim: Dimension of attention heads.
            max_position_embeddings: Maximum sequence length.
            base: Base for the frequency calculation.
            scaling: Optional scaling configuration (for extended context).
        """
        super().__init__()

        self.head_dim = head_dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.scaling = scaling

        # Apply scaling if provided
        if scaling is not None:
            scaling_type = scaling.get("type", "linear")
            scaling_factor = scaling.get("factor", 1.0)

            if scaling_type == "linear":
                self.base = base * scaling_factor
            elif scaling_type == "dynamic":
                # Dynamic scaling will be applied during forward
                self.scaling_factor = scaling_factor
            else:
                raise ValueError(f"Unknown RoPE scaling type: {scaling_type}")

        # Precompute frequency inverse (theta)
        # theta_i = base^(-2i/d) for i in [0, d/2)
        inv_freq = 1.0 / (
            self.base ** (mx.arange(0, head_dim, 2, dtype=mx.float32) / head_dim)
        )
        self.inv_freq = inv_freq

        # Precompute cos/sin for common sequence lengths
        # Default to 2048 if max_position_embeddings is not set
        max_len = max_position_embeddings if max_position_embeddings is not None else 2048
        self._precompute_freqs_cis(max_len)

    def _precompute_freqs_cis(self, max_len: int) -> None:
        """Precompute cos and sin frequencies."""
        # Position indices: [0, 1, 2, ..., max_len-1]
        positions = mx.arange(max_len, dtype=mx.float32)

        # Compute frequencies: outer product of positions and inv_freq
        # [max_len, 1] x [1, head_dim/2] -> [max_len, head_dim/2]
        freqs = mx.outer(positions, self.inv_freq)

        # Compute cos and sin
        # Duplicate each frequency for real/imaginary parts
        # [max_len, head_dim/2] -> [max_len, head_dim]
        cos = mx.repeat(mx.cos(freqs), 2, axis=-1)
        sin = mx.repeat(mx.sin(freqs), 2, axis=-1)

        self.cos_cached = cos
        self.sin_cached = sin

    def forward(
        self,
        positions: mx.array,
    ) -> tuple[mx.array, mx.array]:
        """
        Get cos and sin for given positions.

        Args:
            positions: Position indices [batch, seq_len] or [seq_len].

        Returns:
            Tuple of (cos, sin) each [batch, seq_len, head_dim] or [seq_len, head_dim].
        """
        # Flatten positions for indexing
        original_shape = positions.shape
        flat_positions = mx.reshape(positions, [-1])

        # Get max position
        max_pos = int(mx.max(flat_positions).item())

        # Extend cache if needed
        if max_pos >= len(self.cos_cached):
            self._precompute_freqs_cis(max_pos + 1)

        # Gather cos/sin for the requested positions
        cos = self.cos_cached[flat_positions]
        sin = self.sin_cached[flat_positions]

        # Reshape to original batch shape
        if len(original_shape) == 2:
            # [batch, seq_len]
            batch, seq_len = original_shape
            cos = mx.reshape(cos, [batch, seq_len, -1])
            sin = mx.reshape(sin, [batch, seq_len, -1])
        else:
            # [seq_len]
            seq_len = original_shape[0]
            cos = mx.reshape(cos, [seq_len, -1])
            sin = mx.reshape(sin, [seq_len, -1])

        return cos, sin

    def __call__(
        self,
        positions: mx.array,
    ) -> tuple[mx.array, mx.array]:
        """Call forward method."""
        return self.forward(positions)


class DynamicRoPEScaling(RotaryEmbedding):
    """
    RoPE with dynamic scaling for extended context.

    Dynamically adjusts the frequency based on the sequence length
    to support contexts longer than max_position_embeddings.
    """

    def __init__(
        self,
        head_dim: int,
        max_position_embeddings: int = 8192,
        base: float = 10000.0,
        scaling_factor: float = 1.0,
    ) -> None:
        """Initialize dynamic RoPE."""
        super().__init__(
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=base,
            scaling={"type": "dynamic", "factor": scaling_factor},
        )
        self.original_max_position_embeddings = max_position_embeddings

    def forward(
        self,
        positions: mx.array,
    ) -> tuple[mx.array, mx.array]:
        """Forward with dynamic scaling."""
        max_pos = int(mx.max(positions).item())

        # If beyond original max, apply dynamic scaling
        if max_pos >= self.original_max_position_embeddings:
            # Scale down the base to allow larger positions
            scale = max_pos / self.original_max_position_embeddings
            scaled_base = self.base * scale

            # Recompute inv_freq with scaled base
            inv_freq = 1.0 / (
                scaled_base ** (mx.arange(0, self.head_dim, 2, dtype=mx.float32) / self.head_dim)
            )

            # Compute frequencies
            flat_positions = mx.reshape(positions, [-1])
            freqs = mx.outer(flat_positions.astype(mx.float32), inv_freq)

            # Compute cos/sin
            cos = mx.repeat(mx.cos(freqs), 2, axis=-1)
            sin = mx.repeat(mx.sin(freqs), 2, axis=-1)

            # Reshape
            original_shape = positions.shape
            if len(original_shape) == 2:
                batch, seq_len = original_shape
                cos = mx.reshape(cos, [batch, seq_len, -1])
                sin = mx.reshape(sin, [batch, seq_len, -1])
            else:
                seq_len = original_shape[0]
                cos = mx.reshape(cos, [seq_len, -1])
                sin = mx.reshape(sin, [seq_len, -1])

            return cos, sin
        else:
            # Use standard RoPE for normal positions
            return super().forward(positions)


class LinearRoPEScaling(RotaryEmbedding):
    """
    RoPE with linear scaling.

    Multiplies all positions by a constant factor to compress
    the position space.
    """

    def __init__(
        self,
        head_dim: int,
        max_position_embeddings: int = 8192,
        base: float = 10000.0,
        scaling_factor: float = 1.0,
    ) -> None:
        """Initialize linear RoPE scaling."""
        # Linear scaling is applied by adjusting the base
        super().__init__(
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=base * scaling_factor,
            scaling=None,
        )
        self.scaling_factor = scaling_factor

    def forward(
        self,
        positions: mx.array,
    ) -> tuple[mx.array, mx.array]:
        """Forward with linear scaling."""
        # Scale positions down
        scaled_positions = positions / self.scaling_factor
        return super().forward(scaled_positions)


def create_rotary_embedding(
    head_dim: int,
    max_position_embeddings: int = 8192,
    base: float = 10000.0,
    scaling: dict | None = None,
) -> RotaryEmbedding:
    """
    Factory function to create the appropriate RoPE implementation.

    Args:
        head_dim: Attention head dimension.
        max_position_embeddings: Maximum sequence length.
        base: RoPE base frequency.
        scaling: Optional scaling config.

    Returns:
        RotaryEmbedding instance.
    """
    if scaling is None:
        return RotaryEmbedding(
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=base,
        )

    scaling_type = scaling.get("type", "linear")
    scaling_factor = scaling.get("factor", 1.0)

    if scaling_type == "linear":
        return LinearRoPEScaling(
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=base,
            scaling_factor=scaling_factor,
        )
    elif scaling_type == "dynamic":
        return DynamicRoPEScaling(
            head_dim=head_dim,
            max_position_embeddings=max_position_embeddings,
            base=base,
            scaling_factor=scaling_factor,
        )
    else:
        raise ValueError(f"Unknown RoPE scaling type: {scaling_type}")
