# SPDX-License-Identifier: Apache-2.0
"""Resampler layers for MLX-LLM model executor.

Resamplers are used to convert variable-length sequences to fixed-length
representations, commonly used in multimodal models to align different
modalities (e.g., image features to text sequence length).
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class Resampler(nn.Module):
    """
    Resampler using learned queries and cross-attention.

    This is similar to Perceiver architecture, using a fixed set of learnable
    queries to attend over variable-length input.
    """

    def __init__(
        self,
        num_queries: int,
        embed_dim: int,
        num_heads: int = 8,
        depth: int = 2,
        **kwargs: Any,
    ):
        """
        Initialize resampler.

        Args:
            num_queries: Number of output queries (output sequence length).
            embed_dim: Embedding dimension.
            num_heads: Number of attention heads.
            depth: Number of resampler layers.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.num_queries = num_queries
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.depth = depth

        # Learnable queries
        self.queries = mx.random.normal((num_queries, embed_dim)) * 0.02

        # Resampler layers (cross-attention + feedforward)
        self.layers = [
            ResamplerLayer(embed_dim, num_heads) for _ in range(depth)
        ]

    def __call__(
        self,
        x: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Resample input to fixed number of queries.

        Args:
            x: Input sequence (batch_size, seq_len, embed_dim).
            attention_mask: Optional attention mask (batch_size, seq_len).

        Returns:
            Resampled output (batch_size, num_queries, embed_dim).
        """
        batch_size = x.shape[0]

        # Expand queries for batch
        queries = mx.broadcast_to(
            mx.expand_dims(self.queries, axis=0),
            (batch_size, self.num_queries, self.embed_dim),
        )

        # Apply resampler layers
        for layer in self.layers:
            queries = layer(queries, x, attention_mask)

        return queries


class ResamplerLayer(nn.Module):
    """Single resampler layer with cross-attention and FFN."""

    def __init__(self, embed_dim: int, num_heads: int):
        """
        Initialize resampler layer.

        Args:
            embed_dim: Embedding dimension.
            num_heads: Number of attention heads.
        """
        super().__init__()

        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads

        # Cross-attention
        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)
        self.o_proj = nn.Linear(embed_dim, embed_dim)

        # Layer norms
        self.ln_q = nn.LayerNorm(embed_dim)
        self.ln_kv = nn.LayerNorm(embed_dim)

        # Feedforward
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.GELU(),
            nn.Linear(embed_dim * 4, embed_dim),
        )
        self.ln_ffn = nn.LayerNorm(embed_dim)

    def __call__(
        self,
        queries: mx.array,
        kv: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass for resampler layer.

        Args:
            queries: Query sequence (batch_size, num_queries, embed_dim).
            kv: Key-value sequence (batch_size, seq_len, embed_dim).
            attention_mask: Optional attention mask for kv.

        Returns:
            Updated queries (batch_size, num_queries, embed_dim).
        """
        # Cross-attention
        queries_norm = self.ln_q(queries)
        kv_norm = self.ln_kv(kv)

        attn_output = self._cross_attention(queries_norm, kv_norm, attention_mask)
        queries = queries + attn_output

        # Feedforward
        queries = queries + self.ffn(self.ln_ffn(queries))

        return queries

    def _cross_attention(
        self,
        queries: mx.array,
        kv: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """Compute cross-attention."""
        batch_size, num_queries, _ = queries.shape
        seq_len = kv.shape[1]

        # Project
        q = self.q_proj(queries)
        k = self.k_proj(kv)
        v = self.v_proj(kv)

        # Reshape to (batch, heads, seq, head_dim)
        q = q.reshape(batch_size, num_queries, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        q = mx.transpose(q, (0, 2, 1, 3))
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Scaled dot-product attention
        scores = mx.matmul(q, mx.transpose(k, (0, 1, 3, 2)))
        scores = scores / (self.head_dim ** 0.5)

        # Apply mask
        if attention_mask is not None:
            mask_expanded = mx.expand_dims(mx.expand_dims(attention_mask, 1), 1)
            scores = mx.where(
                mask_expanded,
                scores,
                mx.full_like(scores, -float("inf")),
            )

        # Softmax and apply to values
        attn_weights = mx.softmax(scores, axis=-1)
        output = mx.matmul(attn_weights, v)

        # Reshape back
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, num_queries, self.embed_dim)

        return self.o_proj(output)


class PerceiverResampler(nn.Module):
    """
    Perceiver-style resampler for multimodal alignment.

    Commonly used in models like Flamingo to compress image/video features
    to a fixed number of tokens.
    """

    def __init__(
        self,
        num_latents: int = 64,
        latent_dim: int = 768,
        input_dim: int | None = None,
        num_heads: int = 8,
        depth: int = 6,
    ):
        """
        Initialize Perceiver resampler.

        Args:
            num_latents: Number of latent queries.
            latent_dim: Latent dimension.
            input_dim: Input dimension (defaults to latent_dim).
            num_heads: Number of attention heads.
            depth: Number of Perceiver layers.
        """
        super().__init__()

        self.num_latents = num_latents
        self.latent_dim = latent_dim
        self.input_dim = input_dim or latent_dim

        # Learnable latent array
        self.latents = mx.random.normal((num_latents, latent_dim)) * 0.02

        # Input projection if dimensions don't match
        if self.input_dim != latent_dim:
            self.input_proj = nn.Linear(self.input_dim, latent_dim)
        else:
            self.input_proj = None

        # Perceiver blocks
        self.layers = [
            ResamplerLayer(latent_dim, num_heads) for _ in range(depth)
        ]

        # Output normalization
        self.ln_out = nn.LayerNorm(latent_dim)

    def __call__(self, x: mx.array, attention_mask: mx.array | None = None) -> mx.array:
        """
        Resample input using Perceiver.

        Args:
            x: Input sequence (batch_size, seq_len, input_dim).
            attention_mask: Optional attention mask.

        Returns:
            Latent representation (batch_size, num_latents, latent_dim).
        """
        batch_size = x.shape[0]

        # Project input if needed
        if self.input_proj is not None:
            x = self.input_proj(x)

        # Expand latents for batch
        latents = mx.broadcast_to(
            mx.expand_dims(self.latents, axis=0),
            (batch_size, self.num_latents, self.latent_dim),
        )

        # Process through layers
        for layer in self.layers:
            latents = layer(latents, x, attention_mask)

        # Output normalization
        return self.ln_out(latents)


class SimpleResampler(nn.Module):
    """
    Simple resampler using adaptive pooling.

    This is a lightweight alternative to attention-based resampling.
    """

    def __init__(self, output_size: int, input_dim: int, output_dim: int | None = None):
        """
        Initialize simple resampler.

        Args:
            output_size: Target sequence length.
            input_dim: Input dimension.
            output_dim: Output dimension (defaults to input_dim).
        """
        super().__init__()

        self.output_size = output_size
        self.input_dim = input_dim
        self.output_dim = output_dim or input_dim

        # Projection if dimensions differ
        if self.output_dim != input_dim:
            self.proj = nn.Linear(input_dim, self.output_dim)
        else:
            self.proj = None

    def __call__(self, x: mx.array) -> mx.array:
        """
        Resample to fixed size using adaptive pooling.

        Args:
            x: Input sequence (batch_size, seq_len, input_dim).

        Returns:
            Resampled output (batch_size, output_size, output_dim).
        """
        batch_size, seq_len, _ = x.shape

        # Simple strategy: interpolate or subsample
        if seq_len > self.output_size:
            # Subsample
            indices = mx.linspace(0, seq_len - 1, self.output_size).astype(mx.int32)
            x = x[:, indices, :]
        elif seq_len < self.output_size:
            # Repeat to fill
            repeats = self.output_size // seq_len
            remainder = self.output_size % seq_len
            x_repeated = mx.repeat(x, repeats, axis=1)
            if remainder > 0:
                x_repeated = mx.concatenate([x_repeated, x[:, :remainder, :]], axis=1)
            x = x_repeated

        # Project if needed
        if self.proj is not None:
            x = self.proj(x)

        return x
