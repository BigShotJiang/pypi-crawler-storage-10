# SPDX-License-Identifier: Apache-2.0
"""Lightning Attention for MLX-LLM model executor.

Lightning Attention is a fast attention variant that uses linear complexity
instead of quadratic complexity for long sequences.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class LightningAttention(nn.Module):
    """
    Lightning Attention layer with linear complexity.

    This implementation uses a kernel-based approach to achieve O(n) complexity
    instead of O(n^2) for standard attention.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        head_dim: int | None = None,
        bias: bool = False,
        kernel_size: int = 3,
        **kwargs: Any,
    ):
        """
        Initialize Lightning Attention.

        Args:
            hidden_size: Hidden size dimension.
            num_heads: Number of attention heads.
            head_dim: Dimension per head.
            bias: Whether to use bias in projections.
            kernel_size: Kernel size for local attention.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = head_dim if head_dim is not None else hidden_size // num_heads
        self.kernel_size = kernel_size

        # Validate
        if self.hidden_size % self.num_heads != 0:
            raise ValueError(
                f"hidden_size ({self.hidden_size}) must be divisible by "
                f"num_heads ({self.num_heads})"
            )

        # Projections
        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.k_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.v_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=bias)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=bias)

        # Local attention kernel (learnable)
        self.local_kernel = mx.ones((kernel_size,)) / kernel_size

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for Lightning Attention.

        Args:
            hidden_states: Input hidden states (batch_size, seq_len, hidden_size).
            attention_mask: Optional attention mask.
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch_size, seq_len, hidden_size).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project to Q, K, V
        query = self.q_proj(hidden_states)
        key = self.k_proj(hidden_states)
        value = self.v_proj(hidden_states)

        # Reshape to (batch, seq, heads, head_dim)
        query = query.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        key = key.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        value = value.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        # Transpose to (batch, heads, seq, head_dim)
        query = mx.transpose(query, (0, 2, 1, 3))
        key = mx.transpose(key, (0, 2, 1, 3))
        value = mx.transpose(value, (0, 2, 1, 3))

        # Lightning attention: use linear complexity approximation
        # Instead of full attention, use local + global components
        attn_output = self._lightning_attention(query, key, value, attention_mask)

        # Transpose back: (batch, heads, seq, head_dim) -> (batch, seq, heads, head_dim)
        attn_output = mx.transpose(attn_output, (0, 2, 1, 3))

        # Reshape: (batch, seq, heads, head_dim) -> (batch, seq, hidden)
        attn_output = attn_output.reshape(batch_size, seq_len, self.num_heads * self.head_dim)

        # Output projection
        output = self.o_proj(attn_output)

        return output

    def _lightning_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Compute lightning attention with linear complexity.

        Args:
            query: Query tensor (batch, heads, seq, head_dim).
            key: Key tensor (batch, heads, seq, head_dim).
            value: Value tensor (batch, heads, seq, head_dim).
            attention_mask: Optional attention mask.

        Returns:
            Attention output (batch, heads, seq, head_dim).
        """
        batch_size, num_heads, seq_len, head_dim = query.shape

        # Local attention: attend to nearby tokens
        local_output = self._local_attention(query, key, value)

        # Global attention: use aggregated representations
        global_output = self._global_attention(query, key, value)

        # Combine local and global (learnable combination would be better)
        output = 0.7 * local_output + 0.3 * global_output

        return output

    def _local_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
    ) -> mx.array:
        """
        Compute local attention within a window.

        Args:
            query: Query tensor.
            key: Key tensor.
            value: Value tensor.

        Returns:
            Local attention output.
        """
        batch_size, num_heads, seq_len, head_dim = query.shape

        # Simple local attention: convolve value with local kernel
        # This is a simplified version; full implementation would use
        # windowed dot-product attention

        # For now, just return value (placeholder for proper local attention)
        return value

    def _global_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
    ) -> mx.array:
        """
        Compute global attention using aggregated representations.

        Args:
            query: Query tensor.
            key: Key tensor.
            value: Value tensor.

        Returns:
            Global attention output.
        """
        # Aggregate key and value globally (mean pooling)
        global_key = mx.mean(key, axis=2, keepdims=True)  # (batch, heads, 1, head_dim)
        global_value = mx.mean(value, axis=2, keepdims=True)

        # Compute attention scores
        scores = mx.matmul(query, mx.transpose(global_key, (0, 1, 3, 2)))
        scores = scores / (self.head_dim ** 0.5)

        # Softmax
        attn_weights = mx.softmax(scores, axis=-1)

        # Apply to global value
        output = mx.matmul(attn_weights, global_value)

        return output


class LinearAttention(nn.Module):
    """
    Linear attention with feature maps.

    This uses feature maps to linearize the attention computation.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        feature_map: str = "elu",
        **kwargs: Any,
    ):
        """
        Initialize linear attention.

        Args:
            hidden_size: Hidden size.
            num_heads: Number of heads.
            feature_map: Feature map type (elu, relu).
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.feature_map = feature_map

        # Projections
        self.q_proj = nn.Linear(hidden_size, hidden_size)
        self.k_proj = nn.Linear(hidden_size, hidden_size)
        self.v_proj = nn.Linear(hidden_size, hidden_size)
        self.o_proj = nn.Linear(hidden_size, hidden_size)

    def __call__(self, hidden_states: mx.array, **kwargs: Any) -> mx.array:
        """Forward pass for linear attention."""
        batch_size, seq_len, _ = hidden_states.shape

        # Project
        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        # Apply feature map
        q = self._apply_feature_map(q)
        k = self._apply_feature_map(k)

        # Reshape
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        # Transpose
        q = mx.transpose(q, (0, 2, 1, 3))  # (B, H, L, D)
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Linear attention: phi(Q) @ (phi(K)^T @ V)
        # (B, H, L, D) @ (B, H, D, L) @ (B, H, L, D)
        kv = mx.matmul(mx.transpose(k, (0, 1, 3, 2)), v)  # (B, H, D, D)
        output = mx.matmul(q, kv)  # (B, H, L, D)

        # Transpose and reshape back
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, seq_len, self.hidden_size)

        # Output projection
        return self.o_proj(output)

    def _apply_feature_map(self, x: mx.array) -> mx.array:
        """Apply feature map to linearize attention."""
        if self.feature_map == "elu":
            return nn.elu(x) + 1.0
        elif self.feature_map == "relu":
            return nn.relu(x)
        else:
            return x
