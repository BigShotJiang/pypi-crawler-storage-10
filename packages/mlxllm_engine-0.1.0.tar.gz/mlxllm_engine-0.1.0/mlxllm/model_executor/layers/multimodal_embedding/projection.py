# SPDX-License-Identifier: Apache-2.0
"""Modality projection layers."""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class ModalityProjector(nn.Module):
    """Base class for modality projectors."""

    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim


class MLPProjector(ModalityProjector):
    """MLP-based projector for modality alignment."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int | None = None,
        num_layers: int = 2,
        **kwargs: Any,
    ):
        """Initialize MLP projector."""
        super().__init__(input_dim, output_dim)

        hidden_dim = hidden_dim or (input_dim + output_dim) // 2

        layers = []
        for i in range(num_layers):
            in_dim = input_dim if i == 0 else hidden_dim
            out_dim = output_dim if i == num_layers - 1 else hidden_dim

            layers.append(nn.Linear(in_dim, out_dim))

            if i < num_layers - 1:
                layers.append(nn.GELU())

        self.mlp = nn.Sequential(*layers)

    def __call__(self, x: mx.array) -> mx.array:
        """Project modality features."""
        return self.mlp(x)


class QFormerProjector(ModalityProjector):
    """Q-Former style projector with learned queries."""

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        num_queries: int = 32,
        num_layers: int = 2,
        **kwargs: Any,
    ):
        """Initialize Q-Former projector."""
        super().__init__(input_dim, output_dim)

        self.num_queries = num_queries

        # Learned queries
        self.queries = mx.random.normal((num_queries, output_dim)) * 0.02

        # Cross-attention layers
        from ..resampler import ResamplerLayer
        self.layers = [
            ResamplerLayer(output_dim, 8) for _ in range(num_layers)
        ]

        # Input projection
        self.input_proj = nn.Linear(input_dim, output_dim)

    def __call__(self, x: mx.array) -> mx.array:
        """Project using Q-Former."""
        batch_size = x.shape[0]

        # Project input
        x = self.input_proj(x)

        # Expand queries for batch
        queries = mx.broadcast_to(
            mx.expand_dims(self.queries, 0), (batch_size, self.num_queries, self.output_dim)
        )

        # Apply cross-attention layers
        for layer in self.layers:
            queries = layer(queries, x)

        return queries
