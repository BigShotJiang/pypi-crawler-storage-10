# SPDX-License-Identifier: Apache-2.0
"""Vision embedding layers for multimodal models.

Provides vision encoders for processing image inputs in multimodal LLMs.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class VisionEmbedding(nn.Module):
    """
    Basic vision embedding with patch extraction.

    Converts images to patch embeddings for transformer processing.
    """

    def __init__(
        self,
        image_size: int = 224,
        patch_size: int = 16,
        num_channels: int = 3,
        hidden_size: int = 768,
        **kwargs: Any,
    ):
        """
        Initialize vision embedding.

        Args:
            image_size: Input image size.
            patch_size: Size of each patch.
            num_channels: Number of image channels.
            hidden_size: Hidden dimension size.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.image_size = image_size
        self.patch_size = patch_size
        self.num_channels = num_channels
        self.hidden_size = hidden_size

        self.num_patches = (image_size // patch_size) ** 2

        # Patch embedding (conv2d with stride=patch_size)
        self.patch_embedding = nn.Conv2d(
            num_channels,
            hidden_size,
            kernel_size=patch_size,
            stride=patch_size,
        )

        # Class token
        self.cls_token = mx.random.normal((1, 1, hidden_size)) * 0.02

        # Position embeddings
        self.position_embeddings = mx.random.normal(
            (1, self.num_patches + 1, hidden_size)
        ) * 0.02

    def __call__(self, pixel_values: mx.array, **kwargs: Any) -> mx.array:
        """
        Embed images to patch tokens.

        Args:
            pixel_values: Image tensor (batch, channels, height, width).
            **kwargs: Additional arguments.

        Returns:
            Patch embeddings (batch, num_patches + 1, hidden_size).
        """
        batch_size = pixel_values.shape[0]

        # Extract patches
        patch_embeds = self.patch_embedding(pixel_values)  # (B, hidden, H', W')

        # Flatten: (B, hidden, H', W') -> (B, num_patches, hidden)
        patch_embeds = mx.reshape(
            mx.transpose(patch_embeds, (0, 2, 3, 1)),
            (batch_size, -1, self.hidden_size),
        )

        # Prepend class token
        cls_tokens = mx.broadcast_to(
            self.cls_token, (batch_size, 1, self.hidden_size)
        )
        embeddings = mx.concatenate([cls_tokens, patch_embeds], axis=1)

        # Add position embeddings
        embeddings = embeddings + self.position_embeddings

        return embeddings


class CLIPVisionEncoder(nn.Module):
    """
    CLIP-style vision encoder.

    Used in many multimodal LLMs like LLaVA.
    """

    def __init__(
        self,
        image_size: int = 224,
        patch_size: int = 16,
        hidden_size: int = 768,
        num_layers: int = 12,
        num_heads: int = 12,
        **kwargs: Any,
    ):
        """
        Initialize CLIP vision encoder.

        Args:
            image_size: Input image size.
            patch_size: Patch size.
            hidden_size: Hidden dimension.
            num_layers: Number of transformer layers.
            num_heads: Number of attention heads.
            **kwargs: Additional arguments.
        """
        super().__init__()

        # Vision embedding
        self.embeddings = VisionEmbedding(
            image_size=image_size,
            patch_size=patch_size,
            hidden_size=hidden_size,
        )

        # Transformer encoder
        self.encoder = nn.Sequential(*[
            CLIPEncoderLayer(hidden_size, num_heads)
            for _ in range(num_layers)
        ])

        # Post-layernorm
        self.post_layernorm = nn.LayerNorm(hidden_size)

    def __call__(self, pixel_values: mx.array, **kwargs: Any) -> mx.array:
        """
        Encode images.

        Args:
            pixel_values: Image tensor.
            **kwargs: Additional arguments.

        Returns:
            Encoded features.
        """
        # Embed
        hidden_states = self.embeddings(pixel_values)

        # Encode
        for layer in self.encoder:
            hidden_states = layer(hidden_states)

        # Post-norm
        hidden_states = self.post_layernorm(hidden_states)

        return hidden_states


class CLIPEncoderLayer(nn.Module):
    """Single CLIP encoder layer."""

    def __init__(self, hidden_size: int, num_heads: int):
        super().__init__()

        self.self_attn = nn.MultiHeadAttention(
            hidden_size, num_heads, bias=True
        )
        self.layer_norm1 = nn.LayerNorm(hidden_size)

        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, hidden_size * 4),
            nn.GELU(),
            nn.Linear(hidden_size * 4, hidden_size),
        )
        self.layer_norm2 = nn.LayerNorm(hidden_size)

    def __call__(self, hidden_states: mx.array) -> mx.array:
        # Attention
        residual = hidden_states
        hidden_states = self.layer_norm1(hidden_states)
        hidden_states = self.self_attn(hidden_states, hidden_states, hidden_states)
        hidden_states = residual + hidden_states

        # MLP
        residual = hidden_states
        hidden_states = self.layer_norm2(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states


class SigLIPVisionEncoder(nn.Module):
    """
    SigLIP vision encoder.

    Modern alternative to CLIP with sigmoid loss.
    """

    def __init__(
        self,
        image_size: int = 384,
        patch_size: int = 16,
        hidden_size: int = 1024,
        num_layers: int = 24,
        num_heads: int = 16,
        **kwargs: Any,
    ):
        """Initialize SigLIP encoder."""
        super().__init__()

        # Similar to CLIP but with different initialization
        self.embeddings = VisionEmbedding(
            image_size=image_size,
            patch_size=patch_size,
            hidden_size=hidden_size,
        )

        self.encoder = nn.Sequential(*[
            CLIPEncoderLayer(hidden_size, num_heads)
            for _ in range(num_layers)
        ])

        self.post_layernorm = nn.LayerNorm(hidden_size)

    def __call__(self, pixel_values: mx.array, **kwargs: Any) -> mx.array:
        """Encode images with SigLIP."""
        hidden_states = self.embeddings(pixel_values)

        for layer in self.encoder:
            hidden_states = layer(hidden_states)

        hidden_states = self.post_layernorm(hidden_states)

        return hidden_states
