# SPDX-License-Identifier: Apache-2.0
"""Audio embedding layers for multimodal models."""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class AudioEmbedding(nn.Module):
    """Basic audio embedding from spectrograms."""

    def __init__(
        self,
        num_mel_bins: int = 80,
        hidden_size: int = 768,
        max_length: int = 3000,
        **kwargs: Any,
    ):
        """Initialize audio embedding."""
        super().__init__()

        self.num_mel_bins = num_mel_bins
        self.hidden_size = hidden_size

        # Project mel spectrogram to hidden size
        self.projection = nn.Linear(num_mel_bins, hidden_size)

        # Position embeddings
        self.position_embeddings = mx.random.normal((1, max_length, hidden_size)) * 0.02

    def __call__(self, audio_features: mx.array, **kwargs: Any) -> mx.array:
        """
        Embed audio features.

        Args:
            audio_features: Mel spectrogram (batch, time, num_mel_bins).

        Returns:
            Audio embeddings (batch, time, hidden_size).
        """
        batch_size, seq_len, _ = audio_features.shape

        # Project
        embeddings = self.projection(audio_features)

        # Add position embeddings
        embeddings = embeddings + self.position_embeddings[:, :seq_len, :]

        return embeddings


class WhisperAudioEncoder(nn.Module):
    """Whisper-style audio encoder."""

    def __init__(
        self,
        num_mel_bins: int = 80,
        hidden_size: int = 512,
        num_layers: int = 6,
        **kwargs: Any,
    ):
        """Initialize Whisper encoder."""
        super().__init__()

        self.embedding = AudioEmbedding(num_mel_bins, hidden_size)

        # Transformer layers
        self.layers = [
            nn.TransformerEncoderLayer(hidden_size, 8, hidden_size * 4)
            for _ in range(num_layers)
        ]

        self.ln_post = nn.LayerNorm(hidden_size)

    def __call__(self, audio_features: mx.array, **kwargs: Any) -> mx.array:
        """Encode audio."""
        hidden_states = self.embedding(audio_features)

        for layer in self.layers:
            hidden_states = layer(hidden_states)

        return self.ln_post(hidden_states)
