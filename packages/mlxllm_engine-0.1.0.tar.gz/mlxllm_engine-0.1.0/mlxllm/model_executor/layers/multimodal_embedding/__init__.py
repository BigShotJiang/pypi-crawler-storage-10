# SPDX-License-Identifier: Apache-2.0
"""Multimodal embedding layers for MLX-LLM.

Provides embeddings and projections for multimodal models that process
multiple modalities (text, images, audio, video).

Includes:
- Vision encoders and projectors
- Audio embeddings
- Cross-modal attention
- Modality fusion
"""

from __future__ import annotations

from .vision import VisionEmbedding, CLIPVisionEncoder, SigLIPVisionEncoder
from .audio import AudioEmbedding, WhisperAudioEncoder
from .projection import ModalityProjector, MLPProjector, QFormerProjector
from .fusion import ModalityFusion, CrossModalAttention

__all__ = [
    "VisionEmbedding",
    "CLIPVisionEncoder",
    "SigLIPVisionEncoder",
    "AudioEmbedding",
    "WhisperAudioEncoder",
    "ModalityProjector",
    "MLPProjector",
    "QFormerProjector",
    "ModalityFusion",
    "CrossModalAttention",
]
