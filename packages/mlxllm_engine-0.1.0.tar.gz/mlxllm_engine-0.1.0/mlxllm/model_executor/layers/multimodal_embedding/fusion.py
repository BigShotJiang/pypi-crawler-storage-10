# SPDX-License-Identifier: Apache-2.0
"""Modality fusion layers."""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class CrossModalAttention(nn.Module):
    """Cross-modal attention for fusing different modalities."""

    def __init__(
        self,
        query_dim: int,
        context_dim: int,
        num_heads: int = 8,
        **kwargs: Any,
    ):
        """Initialize cross-modal attention."""
        super().__init__()

        self.num_heads = num_heads
        self.head_dim = query_dim // num_heads

        self.q_proj = nn.Linear(query_dim, query_dim)
        self.k_proj = nn.Linear(context_dim, query_dim)
        self.v_proj = nn.Linear(context_dim, query_dim)
        self.o_proj = nn.Linear(query_dim, query_dim)

    def __call__(
        self,
        query: mx.array,
        context: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """
        Cross-modal attention.

        Args:
            query: Query modality (batch, q_len, query_dim).
            context: Context modality (batch, c_len, context_dim).
            attention_mask: Optional mask.

        Returns:
            Fused features (batch, q_len, query_dim).
        """
        batch_size, q_len, _ = query.shape
        c_len = context.shape[1]

        # Project
        q = self.q_proj(query)
        k = self.k_proj(context)
        v = self.v_proj(context)

        # Reshape for multi-head
        q = q.reshape(batch_size, q_len, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, c_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, c_len, self.num_heads, self.head_dim)

        q = mx.transpose(q, (0, 2, 1, 3))
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Attention
        scores = mx.matmul(q, mx.transpose(k, (0, 1, 3, 2))) / (self.head_dim ** 0.5)

        if attention_mask is not None:
            scores = scores + attention_mask

        attn_weights = mx.softmax(scores, axis=-1)
        output = mx.matmul(attn_weights, v)

        # Reshape and project
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, q_len, -1)
        output = self.o_proj(output)

        return output


class ModalityFusion(nn.Module):
    """Fusion layer for combining multiple modalities."""

    def __init__(
        self,
        hidden_size: int,
        num_modalities: int = 2,
        fusion_method: str = "concat",
        **kwargs: Any,
    ):
        """
        Initialize modality fusion.

        Args:
            hidden_size: Hidden dimension.
            num_modalities: Number of modalities to fuse.
            fusion_method: Fusion method ('concat', 'add', 'attention').
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_modalities = num_modalities
        self.fusion_method = fusion_method

        if fusion_method == "concat":
            self.projection = nn.Linear(hidden_size * num_modalities, hidden_size)
        elif fusion_method == "attention":
            self.attention_weights = nn.Linear(hidden_size, 1, bias=False)

    def __call__(self, *modality_features: mx.array) -> mx.array:
        """
        Fuse modality features.

        Args:
            *modality_features: Tuple of modality tensors.

        Returns:
            Fused features.
        """
        if self.fusion_method == "concat":
            # Concatenate and project
            fused = mx.concatenate(modality_features, axis=-1)
            return self.projection(fused)

        elif self.fusion_method == "add":
            # Simple addition
            return sum(modality_features)

        elif self.fusion_method == "attention":
            # Attention-weighted fusion
            stacked = mx.stack(modality_features, axis=-2)  # (..., num_mod, hidden)

            # Compute attention scores
            scores = self.attention_weights(stacked)  # (..., num_mod, 1)
            weights = mx.softmax(scores, axis=-2)

            # Weighted sum
            fused = mx.sum(stacked * weights, axis=-2)

            return fused

        else:
            raise ValueError(f"Unknown fusion method: {self.fusion_method}")
