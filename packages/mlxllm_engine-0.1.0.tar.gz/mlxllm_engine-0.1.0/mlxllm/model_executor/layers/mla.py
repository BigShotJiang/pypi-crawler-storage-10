# SPDX-License-Identifier: Apache-2.0
"""Multi-head Latent Attention (MLA) for MLX-LLM model executor.

MLA is an efficient attention mechanism used in models like DeepSeek-V2 that
reduces the KV cache size by projecting keys and values to a lower-dimensional
latent space.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class MultiHeadLatentAttention(nn.Module):
    """
    Multi-head Latent Attention (MLA) layer.

    MLA reduces memory consumption by:
    1. Projecting K/V to a lower-dimensional latent space
    2. Sharing latent representations across heads
    3. Reconstructing per-head K/V on the fly

    This is particularly useful for long-context models where KV cache
    can be a bottleneck.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        latent_dim: int | None = None,
        head_dim: int | None = None,
        bias: bool = False,
        rope_theta: float = 10000.0,
        **kwargs: Any,
    ):
        """
        Initialize MLA layer.

        Args:
            hidden_size: Hidden size dimension.
            num_heads: Number of query heads.
            num_kv_heads: Number of KV heads (for GQA).
            latent_dim: Latent dimension for KV compression.
            head_dim: Dimension per head.
            bias: Whether to use bias in projections.
            rope_theta: RoPE theta parameter.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = head_dim if head_dim is not None else hidden_size // num_heads

        # Latent dimension (typically much smaller than hidden_size)
        # Default to 1/4 of hidden_size for significant compression
        self.latent_dim = latent_dim if latent_dim is not None else hidden_size // 4

        self.rope_theta = rope_theta

        # Validate configuration
        if self.hidden_size % self.num_heads != 0:
            raise ValueError(
                f"hidden_size ({self.hidden_size}) must be divisible by "
                f"num_heads ({self.num_heads})"
            )

        self.num_queries_per_kv = self.num_heads // self.num_kv_heads
        self.scaling = self.head_dim ** -0.5

        # Query projection (standard)
        self.q_proj = nn.Linear(
            hidden_size,
            num_heads * self.head_dim,
            bias=bias,
        )

        # Latent space projections (compressed)
        # Input -> Latent
        self.kv_a_proj_with_mqa = nn.Linear(
            hidden_size,
            self.latent_dim + self.num_kv_heads * self.head_dim,  # Latent + RoPE portion
            bias=bias,
        )

        # Latent -> K (per-head reconstruction)
        self.kv_b_proj = nn.Linear(
            self.latent_dim,
            self.num_kv_heads * self.head_dim,
            bias=False,
        )

        # Output projection
        self.o_proj = nn.Linear(
            num_heads * self.head_dim,
            hidden_size,
            bias=bias,
        )

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        position_ids: mx.array | None = None,
        kv_cache: Any | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """
        Forward pass for MLA.

        Args:
            hidden_states: Input hidden states (batch_size, seq_len, hidden_size).
            attention_mask: Optional attention mask.
            position_ids: Position IDs for RoPE.
            kv_cache: KV cache state.
            **kwargs: Additional arguments.

        Returns:
            Tuple of (output, updated_kv_cache).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project query (standard)
        query = self.q_proj(hidden_states)
        query = query.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        query = mx.transpose(query, (0, 2, 1, 3))  # (B, H, L, D)

        # Project to compressed latent + RoPE portion
        kv_latent = self.kv_a_proj_with_mqa(hidden_states)

        # Split into latent and RoPE components
        latent = kv_latent[..., : self.latent_dim]  # (B, L, latent_dim)
        rope_kv = kv_latent[..., self.latent_dim :]  # (B, L, num_kv_heads * head_dim)

        # Reconstruct K/V from latent
        key = self.kv_b_proj(latent)  # (B, L, num_kv_heads * head_dim)
        value = key  # In MLA, K and V share the same projection

        # Add RoPE component to key
        rope_kv = rope_kv.reshape(batch_size, seq_len, self.num_kv_heads, self.head_dim)
        key = key.reshape(batch_size, seq_len, self.num_kv_heads, self.head_dim)
        key = key + rope_kv  # Additive RoPE component

        # Reshape K/V
        key = mx.transpose(key, (0, 2, 1, 3))  # (B, KV_H, L, D)
        value = value.reshape(batch_size, seq_len, self.num_kv_heads, self.head_dim)
        value = mx.transpose(value, (0, 2, 1, 3))

        # Repeat KV heads if needed (GQA)
        if self.num_queries_per_kv > 1:
            key = self._repeat_kv(key, self.num_queries_per_kv)
            value = self._repeat_kv(value, self.num_queries_per_kv)

        # Scaled dot-product attention
        attn_weights = mx.matmul(query, mx.transpose(key, (0, 1, 3, 2))) * self.scaling

        # Apply attention mask
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        # Softmax
        attn_weights = mx.softmax(attn_weights, axis=-1)

        # Apply attention to values
        attn_output = mx.matmul(attn_weights, value)

        # Merge heads
        attn_output = mx.transpose(attn_output, (0, 2, 1, 3))
        attn_output = attn_output.reshape(batch_size, seq_len, self.num_heads * self.head_dim)

        # Output projection
        output = self.o_proj(attn_output)

        # Note: In a full implementation, would store compressed latent in KV cache
        # instead of full K/V, saving significant memory

        return output, kv_cache

    def _repeat_kv(self, x: mx.array, n_rep: int) -> mx.array:
        """Repeat KV heads for grouped query attention."""
        if n_rep == 1:
            return x

        batch_size, num_kv_heads, seq_len, head_dim = x.shape

        x = mx.expand_dims(x, axis=2)
        x = mx.repeat(x, n_rep, axis=2)

        return x.reshape(batch_size, num_kv_heads * n_rep, seq_len, head_dim)

    def get_kv_cache_size_reduction(self) -> float:
        """
        Get the KV cache size reduction factor.

        Returns:
            Reduction factor (> 1.0 means compression).
        """
        # Original KV cache size per head
        original_size = 2 * self.num_kv_heads * self.head_dim  # K + V

        # Compressed size (latent only, no separate K/V storage)
        compressed_size = self.latent_dim

        return original_size / compressed_size


class MLADecoderLayer(nn.Module):
    """
    Transformer decoder layer using Multi-head Latent Attention.

    This is a complete decoder block with MLA and feedforward network.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        intermediate_size: int,
        num_kv_heads: int | None = None,
        latent_dim: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize MLA decoder layer.

        Args:
            hidden_size: Hidden size.
            num_heads: Number of attention heads.
            intermediate_size: FFN intermediate size.
            num_kv_heads: Number of KV heads.
            latent_dim: Latent dimension for MLA.
            **kwargs: Additional arguments.
        """
        super().__init__()

        # MLA attention
        self.self_attn = MultiHeadLatentAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            num_kv_heads=num_kv_heads,
            latent_dim=latent_dim,
            **kwargs,
        )

        # Feedforward network
        self.mlp = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.SiLU(),
            nn.Linear(intermediate_size, hidden_size),
        )

        # Layer norms
        self.input_layernorm = nn.RMSNorm(hidden_size)
        self.post_attention_layernorm = nn.RMSNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        position_ids: mx.array | None = None,
        kv_cache: Any | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """Forward pass for MLA decoder layer."""
        residual = hidden_states

        # Self-attention
        hidden_states = self.input_layernorm(hidden_states)
        hidden_states, kv_cache = self.self_attn(
            hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            kv_cache=kv_cache,
        )
        hidden_states = residual + hidden_states

        # Feedforward
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states, kv_cache
