# SPDX-License-Identifier: Apache-2.0
"""
Logits processing and sampling for language model generation.

This module provides utilities for processing logits (raw model outputs)
and sampling tokens, including temperature scaling, top-p/top-k filtering,
and repetition penalties.
"""

from __future__ import annotations

import mlx.core as mx


__all__ = [
    "LogitsProcessor",
    "TemperatureLogitsProcessor",
    "TopKLogitsProcessor",
    "TopPLogitsProcessor",
    "RepetitionPenaltyLogitsProcessor",
    "FrequencyPenaltyLogitsProcessor",
    "PresencePenaltyLogitsProcessor",
]


class LogitsProcessor:
    """
    Base class for logits processors.

    Logits processors modify the raw logits from the model before sampling.
    They can apply transformations like temperature scaling, filtering, or penalties.
    """

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Process logits.

        Args:
            logits: Raw logits from model with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: Previously generated tokens (for repetition penalties)

        Returns:
            Processed logits with same shape
        """
        raise NotImplementedError


class TemperatureLogitsProcessor(LogitsProcessor):
    """
    Apply temperature scaling to logits.

    Temperature controls randomness:
    - temperature < 1.0: More deterministic (sharper distribution)
    - temperature = 1.0: No change
    - temperature > 1.0: More random (flatter distribution)
    - temperature � 0: Argmax sampling (greedy)
    """

    def __init__(self, temperature: float = 1.0):
        """Initialize temperature processor.

        Args:
            temperature: Temperature value (must be > 0)
        """
        if temperature <= 0:
            raise ValueError(f"Temperature must be > 0, got {temperature}")

        self.temperature = temperature

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Apply temperature scaling.

        Args:
            logits: Raw logits
            generated_tokens: Unused

        Returns:
            Temperature-scaled logits
        """
        if self.temperature == 1.0:
            return logits

        return logits / self.temperature


class TopKLogitsProcessor(LogitsProcessor):
    """
    Filter logits to keep only top-k highest probability tokens.

    Sets logits for all other tokens to -inf, effectively removing them
    from consideration during sampling.
    """

    def __init__(self, top_k: int, filter_value: float = -float("inf")):
        """Initialize top-k processor.

        Args:
            top_k: Number of top tokens to keep (must be > 0)
            filter_value: Value to set for filtered tokens (default: -inf)
        """
        if top_k <= 0:
            raise ValueError(f"top_k must be > 0, got {top_k}")

        self.top_k = top_k
        self.filter_value = filter_value

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Filter to top-k tokens.

        Args:
            logits: Raw logits with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: Unused

        Returns:
            Filtered logits with same shape
        """
        # Get top-k values and indices
        top_k = min(self.top_k, logits.shape[-1])

        # Find the k-th largest value (threshold)
        # Sort in descending order and take k-th element
        sorted_logits = mx.sort(logits, axis=-1)[::-1]
        threshold = sorted_logits[..., top_k - 1:top_k]

        # Create mask for values below threshold
        mask = logits < threshold

        # Set values below threshold to filter_value
        return mx.where(mask, self.filter_value, logits)


class TopPLogitsProcessor(LogitsProcessor):
    """
    Filter logits using nucleus (top-p) sampling.

    Keeps the smallest set of tokens whose cumulative probability exceeds p.
    This dynamically adjusts the number of tokens based on the distribution.
    """

    def __init__(self, top_p: float, filter_value: float = -float("inf")):
        """Initialize top-p processor.

        Args:
            top_p: Cumulative probability threshold (0 < top_p <= 1)
            filter_value: Value to set for filtered tokens (default: -inf)
        """
        if not 0 < top_p <= 1:
            raise ValueError(f"top_p must be in (0, 1], got {top_p}")

        self.top_p = top_p
        self.filter_value = filter_value

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Filter using nucleus sampling.

        Args:
            logits: Raw logits with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: Unused

        Returns:
            Filtered logits with same shape
        """
        # Sort logits in descending order
        sorted_indices = mx.argsort(logits, axis=-1)[::-1]
        sorted_logits = mx.take_along_axis(logits, sorted_indices, axis=-1)

        # Convert to probabilities
        sorted_probs = mx.softmax(sorted_logits, axis=-1)

        # Compute cumulative probabilities
        cumulative_probs = mx.cumsum(sorted_probs, axis=-1)

        # Create mask for tokens to remove (cumulative prob > top_p)
        # Keep at least one token
        sorted_indices_to_remove = cumulative_probs > self.top_p

        # Shift right to keep first token above threshold
        sorted_indices_to_remove = mx.concatenate(
            [
                mx.zeros_like(sorted_indices_to_remove[..., :1]),
                sorted_indices_to_remove[..., :-1],
            ],
            axis=-1,
        )

        # Scatter mask back to original order
        indices_to_remove = mx.zeros_like(logits, dtype=mx.bool_)
        indices_to_remove = mx.put_along_axis(
            indices_to_remove,
            sorted_indices,
            sorted_indices_to_remove,
            axis=-1,
        )

        # Apply filter
        return mx.where(indices_to_remove, self.filter_value, logits)


class RepetitionPenaltyLogitsProcessor(LogitsProcessor):
    """
    Apply repetition penalty to previously generated tokens.

    Reduces probability of tokens that have already been generated,
    encouraging diversity in the output.

    Penalty is applied multiplicatively:
    - If logit > 0: logit = logit / penalty
    - If logit < 0: logit = logit * penalty
    """

    def __init__(self, penalty: float = 1.0):
        """Initialize repetition penalty processor.

        Args:
            penalty: Penalty factor (> 1 penalizes repetition, < 1 encourages it)
        """
        if penalty <= 0:
            raise ValueError(f"Penalty must be > 0, got {penalty}")

        self.penalty = penalty

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Apply repetition penalty.

        Args:
            logits: Raw logits with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: List of previously generated token IDs

        Returns:
            Penalized logits with same shape
        """
        if self.penalty == 1.0 or not generated_tokens:
            return logits

        # Get unique tokens that have been generated
        unique_tokens = list(set(generated_tokens))

        # Extract logits for these tokens
        token_logits = logits[..., unique_tokens]

        # Apply penalty (divide if positive, multiply if negative)
        penalized_logits = mx.where(
            token_logits > 0,
            token_logits / self.penalty,
            token_logits * self.penalty,
        )

        # Update logits
        logits = logits.copy()
        for i, token_id in enumerate(unique_tokens):
            logits[..., token_id] = penalized_logits[..., i]

        return logits


class FrequencyPenaltyLogitsProcessor(LogitsProcessor):
    """
    Apply frequency-based penalty to tokens.

    Penalizes tokens based on how many times they've appeared in the output.
    Unlike repetition penalty, this is additive and scales with frequency.

    penalty_value = -frequency * penalty
    """

    def __init__(self, penalty: float = 0.0):
        """Initialize frequency penalty processor.

        Args:
            penalty: Penalty factor (> 0 penalizes frequent tokens)
        """
        self.penalty = penalty

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Apply frequency penalty.

        Args:
            logits: Raw logits with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: List of previously generated token IDs

        Returns:
            Penalized logits with same shape
        """
        if self.penalty == 0.0 or not generated_tokens:
            return logits

        # Count token frequencies
        token_counts: dict[int, int] = {}
        for token in generated_tokens:
            token_counts[token] = token_counts.get(token, 0) + 1

        # Apply penalty based on frequency
        logits = logits.copy()
        for token_id, count in token_counts.items():
            logits[..., token_id] = logits[..., token_id] - (count * self.penalty)

        return logits


class PresencePenaltyLogitsProcessor(LogitsProcessor):
    """
    Apply presence-based penalty to tokens.

    Penalizes tokens that have appeared at all in the output, regardless
    of frequency. This is a binary penalty (either present or not).

    penalty_value = -penalty (if token has appeared at least once)
    """

    def __init__(self, penalty: float = 0.0):
        """Initialize presence penalty processor.

        Args:
            penalty: Penalty factor (> 0 penalizes tokens that have appeared)
        """
        self.penalty = penalty

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Apply presence penalty.

        Args:
            logits: Raw logits with shape [vocab_size] or [batch, vocab_size]
            generated_tokens: List of previously generated token IDs

        Returns:
            Penalized logits with same shape
        """
        if self.penalty == 0.0 or not generated_tokens:
            return logits

        # Get unique tokens that have appeared
        unique_tokens = list(set(generated_tokens))

        # Apply penalty to all tokens that have appeared
        logits = logits.copy()
        for token_id in unique_tokens:
            logits[..., token_id] = logits[..., token_id] - self.penalty

        return logits


class LogitsProcessorList:
    """
    List of logits processors that are applied sequentially.

    This allows combining multiple processors (e.g., temperature + top-p + repetition).
    """

    def __init__(self, processors: list[LogitsProcessor] | None = None):
        """Initialize processor list.

        Args:
            processors: List of logits processors to apply in order
        """
        self.processors = processors or []

    def __call__(
        self,
        logits: mx.array,
        generated_tokens: list[int] | None = None,
    ) -> mx.array:
        """Apply all processors sequentially.

        Args:
            logits: Raw logits
            generated_tokens: Previously generated tokens

        Returns:
            Processed logits after applying all processors
        """
        for processor in self.processors:
            logits = processor(logits, generated_tokens)

        return logits

    def append(self, processor: LogitsProcessor) -> None:
        """Add a processor to the list.

        Args:
            processor: Processor to add
        """
        self.processors.append(processor)

    def __len__(self) -> int:
        """Get number of processors."""
        return len(self.processors)

    def __repr__(self) -> str:
        """String representation."""
        return f"LogitsProcessorList({self.processors})"
