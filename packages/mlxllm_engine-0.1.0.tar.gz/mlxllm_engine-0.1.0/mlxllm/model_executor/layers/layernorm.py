# SPDX-License-Identifier: Apache-2.0
"""Normalization layers for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass


class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization.

    Used in Llama, Mistral, Qwen, and other modern LLMs.
    More efficient than LayerNorm as it doesn't center the activations.

    RMSNorm(x) = x / RMS(x) * weight
    where RMS(x) = sqrt(mean(x^2) + eps)
    """

    def __init__(
        self,
        hidden_size: int,
        eps: float = 1e-6,
    ) -> None:
        """
        Initialize RMSNorm.

        Args:
            hidden_size: Size of the hidden dimension.
            eps: Epsilon for numerical stability.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.eps = eps

        # Learnable scale parameter
        self.weight = mx.ones((hidden_size,))

    def forward(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input tensor [..., hidden_size].

        Returns:
            Normalized tensor [..., hidden_size].
        """
        # Compute RMS: sqrt(mean(x^2) + eps)
        variance = mx.mean(mx.square(x), axis=-1, keepdims=True)
        x = x * mx.rsqrt(variance + self.eps)

        # Apply learned scaling
        return x * self.weight

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class LayerNorm(nn.Module):
    """
    Standard Layer Normalization.

    LayerNorm(x) = (x - mean(x)) / sqrt(var(x) + eps) * weight + bias
    """

    def __init__(
        self,
        hidden_size: int,
        eps: float = 1e-5,
        elementwise_affine: bool = True,
    ) -> None:
        """
        Initialize LayerNorm.

        Args:
            hidden_size: Size of the hidden dimension.
            eps: Epsilon for numerical stability.
            elementwise_affine: Whether to learn affine parameters.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.eps = eps
        self.elementwise_affine = elementwise_affine

        if elementwise_affine:
            self.weight = mx.ones((hidden_size,))
            self.bias = mx.zeros((hidden_size,))

    def forward(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input tensor [..., hidden_size].

        Returns:
            Normalized tensor [..., hidden_size].
        """
        # Compute mean and variance
        mean = mx.mean(x, axis=-1, keepdims=True)
        variance = mx.var(x, axis=-1, keepdims=True)

        # Normalize
        x = (x - mean) * mx.rsqrt(variance + self.eps)

        # Apply affine transform if enabled
        if self.elementwise_affine:
            x = x * self.weight + self.bias

        return x

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class GroupNorm(nn.Module):
    """
    Group Normalization.

    Divides channels into groups and normalizes within each group.
    """

    def __init__(
        self,
        num_groups: int,
        num_channels: int,
        eps: float = 1e-5,
        affine: bool = True,
    ) -> None:
        """
        Initialize GroupNorm.

        Args:
            num_groups: Number of groups.
            num_channels: Number of channels.
            eps: Epsilon for numerical stability.
            affine: Whether to learn affine parameters.
        """
        super().__init__()

        if num_channels % num_groups != 0:
            raise ValueError(
                f"num_channels ({num_channels}) must be divisible by "
                f"num_groups ({num_groups})"
            )

        self.num_groups = num_groups
        self.num_channels = num_channels
        self.eps = eps
        self.affine = affine

        if affine:
            self.weight = mx.ones((num_channels,))
            self.bias = mx.zeros((num_channels,))

    def forward(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input tensor [batch, ..., num_channels].

        Returns:
            Normalized tensor [batch, ..., num_channels].
        """
        original_shape = x.shape
        batch_size = original_shape[0]

        # Reshape to [batch, num_groups, group_size, ...]
        group_size = self.num_channels // self.num_groups

        # Flatten spatial dimensions
        x = mx.reshape(x, [batch_size, self.num_groups, group_size, -1])

        # Compute mean and variance per group
        mean = mx.mean(x, axis=(2, 3), keepdims=True)
        variance = mx.var(x, axis=(2, 3), keepdims=True)

        # Normalize
        x = (x - mean) * mx.rsqrt(variance + self.eps)

        # Reshape back
        x = mx.reshape(x, original_shape)

        # Apply affine transform if enabled
        if self.affine:
            x = x * self.weight + self.bias

        return x

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class FusedRMSNorm(RMSNorm):
    """
    Fused RMSNorm for better performance.

    Uses MLX's optimized operations for common RMSNorm patterns.
    """

    def __init__(
        self,
        hidden_size: int,
        eps: float = 1e-6,
    ) -> None:
        """Initialize fused RMSNorm."""
        super().__init__(hidden_size, eps)

    def forward(self, x: mx.array) -> mx.array:
        """Forward with fused operations."""
        # MLX will automatically fuse these operations
        variance = mx.mean(mx.square(x), axis=-1, keepdims=True)
        return x * mx.rsqrt(variance + self.eps) * self.weight


def get_norm_layer(
    norm_type: str,
    hidden_size: int,
    eps: float = 1e-6,
    **kwargs,
) -> nn.Module:
    """
    Get normalization layer by type.

    Args:
        norm_type: Type of normalization ('rmsnorm', 'layernorm', etc.).
        hidden_size: Hidden dimension size.
        eps: Epsilon for numerical stability.
        **kwargs: Additional arguments for specific norm types.

    Returns:
        Normalization module.
    """
    norm_type = norm_type.lower()

    if norm_type == "rmsnorm":
        return RMSNorm(hidden_size, eps)
    elif norm_type == "fused_rmsnorm":
        return FusedRMSNorm(hidden_size, eps)
    elif norm_type == "layernorm":
        return LayerNorm(hidden_size, eps, **kwargs)
    elif norm_type == "groupnorm":
        num_groups = kwargs.get("num_groups", 32)
        return GroupNorm(num_groups, hidden_size, eps)
    else:
        raise ValueError(
            f"Unknown norm type: {norm_type}. "
            f"Available: rmsnorm, fused_rmsnorm, layernorm, groupnorm"
        )
