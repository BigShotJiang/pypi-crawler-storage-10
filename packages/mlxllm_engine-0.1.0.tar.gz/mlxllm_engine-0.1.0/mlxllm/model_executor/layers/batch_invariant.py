# SPDX-License-Identifier: Apache-2.0
"""Batch-invariant operations for MLX-LLM model executor.

This module provides operations that are invariant to batch size, useful for
ensuring consistent behavior across different batch sizes.
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn


class BatchInvariantNorm(nn.Module):
    """
    Batch-invariant normalization layer.

    This normalization layer produces the same output regardless of batch size,
    which is useful for ensuring consistent behavior during inference.
    """

    def __init__(self, normalized_shape: int | tuple[int, ...], eps: float = 1e-5):
        """
        Initialize batch-invariant normalization.

        Args:
            normalized_shape: Shape to normalize over.
            eps: Epsilon for numerical stability.
        """
        super().__init__()
        self.normalized_shape = (
            (normalized_shape,) if isinstance(normalized_shape, int) else normalized_shape
        )
        self.eps = eps

    def __call__(self, x: mx.array) -> mx.array:
        """
        Apply batch-invariant normalization.

        Args:
            x: Input tensor.

        Returns:
            Normalized tensor.
        """
        # Compute mean and variance over normalized dimensions
        # Exclude batch dimension (0)
        axes = list(range(1, len(x.shape)))

        mean = mx.mean(x, axis=axes, keepdims=True)
        variance = mx.var(x, axis=axes, keepdims=True)

        # Normalize
        normalized = (x - mean) / mx.sqrt(variance + self.eps)

        return normalized


class BatchInvariantLinear(nn.Module):
    """
    Batch-invariant linear layer.

    Standard linear layer that ensures consistent output regardless of batch size.
    """

    def __init__(self, input_dim: int, output_dim: int, bias: bool = True):
        """
        Initialize batch-invariant linear layer.

        Args:
            input_dim: Input dimension.
            output_dim: Output dimension.
            bias: Whether to include bias.
        """
        super().__init__()
        self.linear = nn.Linear(input_dim, output_dim, bias=bias)

    def __call__(self, x: mx.array) -> mx.array:
        """
        Apply linear transformation.

        Args:
            x: Input tensor (*, input_dim).

        Returns:
            Output tensor (*, output_dim).
        """
        return self.linear(x)


def batch_invariant_dropout(x: mx.array, p: float = 0.5, training: bool = True) -> mx.array:
    """
    Apply dropout in a batch-invariant manner.

    Args:
        x: Input tensor.
        p: Dropout probability.
        training: Whether in training mode.

    Returns:
        Tensor with dropout applied.
    """
    if not training or p == 0.0:
        return x

    # Create dropout mask that's the same for all batch items
    # (for true batch invariance)
    shape = x.shape[1:]  # Exclude batch dimension
    mask = mx.random.bernoulli(1 - p, shape=shape)

    # Broadcast mask across batch
    mask = mx.expand_dims(mask, axis=0)
    mask = mx.broadcast_to(mask, x.shape)

    # Apply dropout
    return mx.where(mask, x / (1 - p), mx.zeros_like(x))


class BatchInvariantLayerNorm(nn.Module):
    """
    Layer normalization that's invariant to batch size.

    This is essentially standard LayerNorm but emphasized for batch invariance.
    """

    def __init__(
        self,
        normalized_shape: int | tuple[int, ...],
        eps: float = 1e-5,
        affine: bool = True,
    ):
        """
        Initialize batch-invariant layer norm.

        Args:
            normalized_shape: Shape to normalize over.
            eps: Epsilon for numerical stability.
            affine: Whether to include learnable affine parameters.
        """
        super().__init__()
        self.normalized_shape = (
            (normalized_shape,) if isinstance(normalized_shape, int) else normalized_shape
        )
        self.eps = eps
        self.affine = affine

        if affine:
            # Learnable scale and shift
            self.weight = mx.ones(self.normalized_shape)
            self.bias = mx.zeros(self.normalized_shape)

    def __call__(self, x: mx.array) -> mx.array:
        """
        Apply layer normalization.

        Args:
            x: Input tensor.

        Returns:
            Normalized tensor.
        """
        # Normalize over last len(normalized_shape) dimensions
        num_dims = len(self.normalized_shape)
        axes = list(range(-num_dims, 0))

        mean = mx.mean(x, axis=axes, keepdims=True)
        variance = mx.var(x, axis=axes, keepdims=True)

        # Normalize
        normalized = (x - mean) / mx.sqrt(variance + self.eps)

        # Apply affine transformation if enabled
        if self.affine:
            normalized = normalized * self.weight + self.bias

        return normalized


def ensure_batch_invariant(x: mx.array, reference_batch_size: int = 1) -> mx.array:
    """
    Ensure tensor is batch-invariant by checking against reference.

    Args:
        x: Input tensor.
        reference_batch_size: Expected batch size.

    Returns:
        Input tensor (raises if batch size doesn't match).

    Raises:
        ValueError: If batch size doesn't match reference.
    """
    if x.shape[0] != reference_batch_size:
        raise ValueError(
            f"Expected batch size {reference_batch_size}, got {x.shape[0]}"
        )
    return x
