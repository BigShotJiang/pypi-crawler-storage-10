# SPDX-License-Identifier: Apache-2.0
"""Utility functions for model executor layers in MLX-LLM."""

from __future__ import annotations

from typing import Any

import mlx.core as mx


def get_activation_fn(activation: str):
    """
    Get activation function by name.

    Args:
        activation: Activation function name.

    Returns:
        Activation function.
    """
    from mlx import nn

    activation_map = {
        "relu": nn.relu,
        "gelu": nn.gelu,
        "silu": nn.silu,
        "tanh": mx.tanh,
        "sigmoid": mx.sigmoid,
        "swish": nn.silu,  # Swish is same as SiLU
        "elu": nn.elu,
        "leaky_relu": nn.leaky_relu,
    }

    if activation.lower() not in activation_map:
        raise ValueError(f"Unknown activation: {activation}")

    return activation_map[activation.lower()]


def create_causal_mask(seq_len: int, dtype: mx.Dtype = mx.float32) -> mx.array:
    """
    Create causal attention mask.

    Args:
        seq_len: Sequence length.
        dtype: Data type for mask.

    Returns:
        Causal mask (seq_len, seq_len) with -inf for masked positions.
    """
    # Create lower triangular mask (1s below diagonal, 0s above)
    mask = mx.tril(mx.ones((seq_len, seq_len)))

    # Convert to attention mask (-inf for masked, 0 for unmasked)
    mask = mx.where(mask == 0, -float("inf"), 0.0)

    return mask.astype(dtype)


def create_padding_mask(
    seq_lengths: mx.array,
    max_len: int | None = None,
) -> mx.array:
    """
    Create padding mask from sequence lengths.

    Args:
        seq_lengths: Sequence lengths (batch_size,).
        max_len: Maximum sequence length (defaults to max of seq_lengths).

    Returns:
        Padding mask (batch_size, max_len) with 1 for valid, 0 for padding.
    """
    if max_len is None:
        max_len = int(mx.max(seq_lengths))

    batch_size = seq_lengths.shape[0]

    # Create range tensor
    positions = mx.arange(max_len)
    positions = mx.broadcast_to(
        mx.expand_dims(positions, axis=0),
        (batch_size, max_len),
    )

    # Compare with sequence lengths
    seq_lengths_expanded = mx.expand_dims(seq_lengths, axis=1)
    mask = positions < seq_lengths_expanded

    return mask.astype(mx.float32)


def apply_rotary_pos_emb(
    q: mx.array,
    k: mx.array,
    cos: mx.array,
    sin: mx.array,
) -> tuple[mx.array, mx.array]:
    """
    Apply rotary position embeddings to query and key.

    Args:
        q: Query tensor (..., seq_len, head_dim).
        k: Key tensor (..., seq_len, head_dim).
        cos: Cosine values (seq_len, head_dim).
        sin: Sine values (seq_len, head_dim).

    Returns:
        Tuple of (rotated_q, rotated_k).
    """
    # Split into first and second half
    head_dim = q.shape[-1]
    q1, q2 = mx.split(q, 2, axis=-1)
    k1, k2 = mx.split(k, 2, axis=-1)

    # Apply rotation
    q_rotated = mx.concatenate([
        q1 * cos - q2 * sin,
        q1 * sin + q2 * cos,
    ], axis=-1)

    k_rotated = mx.concatenate([
        k1 * cos - k2 * sin,
        k1 * sin + k2 * cos,
    ], axis=-1)

    return q_rotated, k_rotated


def fused_add_rms_norm(
    x: mx.array,
    residual: mx.array,
    weight: mx.array,
    eps: float = 1e-6,
) -> tuple[mx.array, mx.array]:
    """
    Fused residual addition and RMSNorm.

    Args:
        x: Input tensor.
        residual: Residual to add.
        weight: RMSNorm weight.
        eps: Epsilon for numerical stability.

    Returns:
        Tuple of (normalized_output, new_residual).
    """
    # Add residual
    new_residual = x + residual

    # RMSNorm
    variance = mx.mean(mx.square(new_residual), axis=-1, keepdims=True)
    normalized = new_residual / mx.sqrt(variance + eps)
    output = normalized * weight

    return output, new_residual


def repeat_kv(x: mx.array, n_rep: int) -> mx.array:
    """
    Repeat key/value heads for grouped query attention.

    Args:
        x: Input tensor (batch, num_kv_heads, seq_len, head_dim).
        n_rep: Number of repetitions per head.

    Returns:
        Repeated tensor (batch, num_kv_heads * n_rep, seq_len, head_dim).
    """
    if n_rep == 1:
        return x

    batch, num_kv_heads, seq_len, head_dim = x.shape

    # Expand and repeat
    x = mx.expand_dims(x, axis=2)  # (batch, num_kv_heads, 1, seq_len, head_dim)
    x = mx.repeat(x, n_rep, axis=2)  # (batch, num_kv_heads, n_rep, seq_len, head_dim)

    # Reshape
    return x.reshape(batch, num_kv_heads * n_rep, seq_len, head_dim)


def scaled_dot_product_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    attn_mask: mx.array | None = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
) -> mx.array:
    """
    Scaled dot-product attention.

    Args:
        query: Query tensor (batch, num_heads, seq_len_q, head_dim).
        key: Key tensor (batch, num_heads, seq_len_k, head_dim).
        value: Value tensor (batch, num_heads, seq_len_v, head_dim).
        attn_mask: Optional attention mask.
        dropout_p: Dropout probability.
        is_causal: Whether to use causal masking.

    Returns:
        Attention output (batch, num_heads, seq_len_q, head_dim).
    """
    head_dim = query.shape[-1]
    scale = head_dim ** -0.5

    # Compute attention scores
    attn_weights = mx.matmul(query, mx.transpose(key, (0, 1, 3, 2))) * scale

    # Apply causal mask if needed
    if is_causal:
        seq_len = query.shape[2]
        causal_mask = create_causal_mask(seq_len)
        attn_weights = attn_weights + causal_mask

    # Apply attention mask
    if attn_mask is not None:
        attn_weights = attn_weights + attn_mask

    # Softmax
    attn_weights = mx.softmax(attn_weights, axis=-1)

    # Apply dropout (if training)
    if dropout_p > 0.0:
        # Note: MLX doesn't have built-in dropout, would need custom implementation
        pass

    # Apply attention to values
    output = mx.matmul(attn_weights, value)

    return output


def compute_position_ids(
    attention_mask: mx.array,
    past_length: int = 0,
) -> mx.array:
    """
    Compute position IDs from attention mask.

    Args:
        attention_mask: Attention mask (batch_size, seq_len).
        past_length: Length of past key-values.

    Returns:
        Position IDs (batch_size, seq_len).
    """
    # Cumulative sum of mask gives position IDs
    position_ids = mx.cumsum(attention_mask, axis=1) - 1 + past_length

    return position_ids.astype(mx.int32)


def slice_tensor(x: mx.array, start: int, length: int, axis: int = 0) -> mx.array:
    """
    Slice tensor along specified axis.

    Args:
        x: Input tensor.
        start: Start index.
        length: Length to slice.
        axis: Axis to slice along.

    Returns:
        Sliced tensor.
    """
    # Create slice objects
    slices = [slice(None)] * len(x.shape)
    slices[axis] = slice(start, start + length)

    return x[tuple(slices)]


def get_dtype_from_str(dtype_str: str) -> mx.Dtype:
    """
    Get MLX dtype from string.

    Args:
        dtype_str: Data type string.

    Returns:
        MLX dtype.
    """
    dtype_map = {
        "float32": mx.float32,
        "float16": mx.float16,
        "bfloat16": mx.bfloat16,
        "int32": mx.int32,
        "int64": mx.int64,
        "int16": mx.int16,
        "int8": mx.int8,
        "uint8": mx.uint8,
        "bool": mx.bool_,
    }

    if dtype_str not in dtype_map:
        raise ValueError(f"Unknown dtype: {dtype_str}")

    return dtype_map[dtype_str]


def cast_if_needed(x: mx.array, target_dtype: mx.Dtype) -> mx.array:
    """
    Cast tensor to target dtype if needed.

    Args:
        x: Input tensor.
        target_dtype: Target data type.

    Returns:
        Casted tensor.
    """
    if x.dtype != target_dtype:
        return x.astype(target_dtype)
    return x
