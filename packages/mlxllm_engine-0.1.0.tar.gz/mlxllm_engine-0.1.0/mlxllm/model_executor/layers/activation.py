# SPDX-License-Identifier: Apache-2.0
"""
Activation functions for neural networks.

This module provides MLX implementations of common activation functions used in
modern LLMs, including SiLU, GELU variants, and gated linear units (GLUs).
"""

from __future__ import annotations

from typing import Literal

import mlx.core as mx
import mlx.nn as nn

__all__ = [
    "SiLU",
    "GELU",
    "GeGLU",
    "SwiGLU",
    "get_activation",
]


class SiLU(nn.Module):
    """
    Sigmoid Linear Unit (SiLU) activation function.

    Also known as Swish: f(x) = x * sigmoid(x)
    Used in models like Llama, Mistral, etc.
    """

    def __call__(self, x: mx.array) -> mx.array:
        """Apply SiLU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        return x * mx.sigmoid(x)


class GELU(nn.Module):
    """
    Gaussian Error Linear Unit (GELU) activation function.

    Supports multiple approximation methods:
    - 'none': Exact computation (slower)
    - 'tanh': Fast approximation using tanh
    - 'fast': Faster approximation
    - 'quick': Quickest approximation
    """

    def __init__(
        self,
        approximate: Literal["none", "tanh", "fast", "quick"] = "none",
    ):
        """Initialize GELU.

        Args:
            approximate: Approximation method to use
        """
        super().__init__()
        self.approximate = approximate

    def __call__(self, x: mx.array) -> mx.array:
        """Apply GELU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        if self.approximate == "none":
            # Exact GELU: x * �(x) where � is CDF of standard normal
            return 0.5 * x * (1.0 + mx.erf(x / mx.sqrt(2.0)))

        elif self.approximate == "tanh":
            # Approximation: 0.5 * x * (1 + tanh(sqrt(2/�) * (x + 0.044715 * x^3)))
            sqrt_2_over_pi = mx.sqrt(2.0 / mx.pi)
            inner = sqrt_2_over_pi * (x + 0.044715 * mx.power(x, 3))
            return 0.5 * x * (1.0 + mx.tanh(inner))

        elif self.approximate in ("fast", "quick"):
            # Fast approximation: x * sigmoid(1.702 * x)
            return x * mx.sigmoid(1.702 * x)

        else:
            raise ValueError(
                f"Invalid approximation method: {self.approximate}. "
                f"Must be one of: 'none', 'tanh', 'fast', 'quick'"
            )


class GeGLU(nn.Module):
    """
    GELU Gated Linear Unit.

    Applies GELU activation to the gate tensor and multiplies
    with the value tensor: GELU(gate) * value

    Used in some transformer variants (e.g., T5, ALBERT).
    """

    def __init__(self, approximate: str = "none"):
        """Initialize GeGLU.

        Args:
            approximate: GELU approximation method
        """
        super().__init__()
        self.gelu = GELU(approximate=approximate)

    def __call__(self, gate: mx.array, value: mx.array) -> mx.array:
        """Apply GeGLU.

        Args:
            gate: Gate tensor to apply GELU activation
            value: Value tensor to multiply with activated gate

        Returns:
            Gated tensor: GELU(gate) * value
        """
        # Apply GELU gating: GELU(gate) * value
        return self.gelu(gate) * value


class SwiGLU(nn.Module):
    """
    SiLU Gated Linear Unit (SwiGLU).

    Applies SiLU activation to the gate tensor and multiplies
    with the value tensor: SiLU(gate) * value

    Used in Llama, Mistral, Qwen2, and other modern LLMs.
    This is the most common GLU variant in current models.
    """

    def __init__(self):
        """Initialize SwiGLU."""
        super().__init__()
        self.silu = SiLU()

    def __call__(self, gate: mx.array, value: mx.array) -> mx.array:
        """Apply SwiGLU.

        Args:
            gate: Gate tensor to apply SiLU activation
            value: Value tensor to multiply with activated gate

        Returns:
            Gated tensor: SiLU(gate) * value
        """
        # Apply SiLU gating: SiLU(gate) * value
        return self.silu(gate) * value


class NewGELU(nn.Module):
    """
    New GELU activation (OpenAI GPT-2 variant).

    This is the 'new' GELU approximation used in GPT-2.
    Slightly different from the standard tanh approximation.
    """

    def __call__(self, x: mx.array) -> mx.array:
        """Apply New GELU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        # 0.5 * x * (1 + tanh(sqrt(2/�) * (x + 0.044715 * x^3)))
        sqrt_2_over_pi = mx.sqrt(2.0 / mx.pi)
        inner = sqrt_2_over_pi * (x + 0.044715 * mx.power(x, 3))
        return 0.5 * x * (1.0 + mx.tanh(inner))


class FastGELU(nn.Module):
    """
    Fast GELU activation.

    Faster approximation using sigmoid: x * sigmoid(1.702 * x)
    Used when speed is critical and slight accuracy loss is acceptable.
    """

    def __call__(self, x: mx.array) -> mx.array:
        """Apply Fast GELU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        return x * mx.sigmoid(1.702 * x)


class QuickGELU(nn.Module):
    """
    Quick GELU activation (CLIP variant).

    Even faster approximation: x * sigmoid(1.702 * x)
    Same as FastGELU but with slightly different constant.
    """

    def __call__(self, x: mx.array) -> mx.array:
        """Apply Quick GELU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        return x * mx.sigmoid(1.702 * x)


class ReLU(nn.Module):
    """
    Rectified Linear Unit (ReLU).

    f(x) = max(0, x)
    Classic activation function, less common in modern LLMs.
    """

    def __call__(self, x: mx.array) -> mx.array:
        """Apply ReLU activation.

        Args:
            x: Input tensor

        Returns:
            Activated tensor
        """
        return mx.maximum(0, x)


# Activation function registry
_ACTIVATION_REGISTRY = {
    "silu": SiLU,
    "swish": SiLU,  # Alias
    "gelu": GELU,
    "gelu_new": NewGELU,
    "gelu_fast": FastGELU,
    "gelu_quick": QuickGELU,
    "gelu_tanh": lambda: GELU(approximate="tanh"),
    "geglu": GeGLU,
    "swiglu": SwiGLU,
    "relu": ReLU,
}


def get_activation(name: str) -> nn.Module:
    """
    Get activation function by name.

    Args:
        name: Activation function name (case-insensitive)

    Returns:
        Activation module instance

    Raises:
        ValueError: If activation name is not recognized

    Examples:
        >>> act = get_activation("silu")
        >>> act = get_activation("gelu_fast")
        >>> act = get_activation("swiglu")
    """
    name_lower = name.lower()

    if name_lower not in _ACTIVATION_REGISTRY:
        available = ", ".join(sorted(_ACTIVATION_REGISTRY.keys()))
        raise ValueError(
            f"Unknown activation function: '{name}'. "
            f"Available: {available}"
        )

    activation_cls = _ACTIVATION_REGISTRY[name_lower]

    # Handle callables (like lambda functions)
    if callable(activation_cls) and not isinstance(activation_cls, type):
        return activation_cls()

    return activation_cls()
