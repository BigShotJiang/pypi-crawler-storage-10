# SPDX-License-Identifier: Apache-2.0
"""Base attention layer for MLX-LLM model executor.

This module provides the abstract base class for all attention layer implementations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import mlx.core as mx
import mlx.nn as nn


class AttentionLayerBase(nn.Module, ABC):
    """
    Abstract base class for attention layers.

    All attention implementations should inherit from this class and implement
    the forward method.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        head_dim: int | None = None,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize attention layer base.

        Args:
            hidden_size: Hidden size dimension.
            num_heads: Number of attention heads.
            num_kv_heads: Number of key-value heads (for GQA/MQA).
            head_dim: Dimension per head (default: hidden_size // num_heads).
            bias: Whether to use bias in linear layers.
            **kwargs: Additional arguments.
        """
        super().__init__()
        
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = head_dim if head_dim is not None else hidden_size // num_heads
        self.bias = bias

        # Validate configuration
        if self.hidden_size % self.num_heads != 0:
            raise ValueError(
                f"hidden_size ({self.hidden_size}) must be divisible by "
                f"num_heads ({self.num_heads})"
            )

        if self.num_heads % self.num_kv_heads != 0:
            raise ValueError(
                f"num_heads ({self.num_heads}) must be divisible by "
                f"num_kv_heads ({self.num_kv_heads})"
            )

        self.num_queries_per_kv = self.num_heads // self.num_kv_heads
        self.scaling = self.head_dim ** -0.5

    @abstractmethod
    def __call__(
        self,
        hidden_states: mx.array,
        kv_cache: Any | None = None,
        attention_mask: mx.array | None = None,
        position_ids: mx.array | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """
        Forward pass for attention layer.

        Args:
            hidden_states: Input hidden states (batch_size, seq_len, hidden_size).
            kv_cache: Key-value cache state.
            attention_mask: Attention mask (batch_size, seq_len, seq_len).
            position_ids: Position IDs for tokens.
            **kwargs: Additional arguments.

        Returns:
            Tuple of (output, updated_kv_cache).
        """
        pass

    def _split_heads(self, x: mx.array, num_heads: int) -> mx.array:
        """
        Split hidden dimension into heads.

        Args:
            x: Input tensor (batch_size, seq_len, hidden_size).
            num_heads: Number of heads.

        Returns:
            Reshaped tensor (batch_size, num_heads, seq_len, head_dim).
        """
        batch_size, seq_len, hidden_size = x.shape
        head_dim = hidden_size // num_heads

        # Reshape: (batch, seq, hidden) -> (batch, seq, heads, head_dim)
        x = x.reshape(batch_size, seq_len, num_heads, head_dim)
        
        # Transpose: (batch, seq, heads, head_dim) -> (batch, heads, seq, head_dim)
        return mx.transpose(x, (0, 2, 1, 3))

    def _merge_heads(self, x: mx.array) -> mx.array:
        """
        Merge heads back into hidden dimension.

        Args:
            x: Input tensor (batch_size, num_heads, seq_len, head_dim).

        Returns:
            Merged tensor (batch_size, seq_len, hidden_size).
        """
        batch_size, num_heads, seq_len, head_dim = x.shape

        # Transpose: (batch, heads, seq, head_dim) -> (batch, seq, heads, head_dim)
        x = mx.transpose(x, (0, 2, 1, 3))

        # Reshape: (batch, seq, heads, head_dim) -> (batch, seq, hidden)
        return x.reshape(batch_size, seq_len, num_heads * head_dim)

    def _repeat_kv(self, x: mx.array, num_queries_per_kv: int) -> mx.array:
        """
        Repeat key/value heads for grouped query attention.

        Args:
            x: Key or value tensor (batch_size, num_kv_heads, seq_len, head_dim).
            num_queries_per_kv: Number of query heads per KV head.

        Returns:
            Repeated tensor (batch_size, num_heads, seq_len, head_dim).
        """
        if num_queries_per_kv == 1:
            return x

        batch_size, num_kv_heads, seq_len, head_dim = x.shape

        # Repeat: (batch, kv_heads, seq, head_dim) -> (batch, kv_heads, rep, seq, head_dim)
        x = mx.expand_dims(x, axis=2)
        x = mx.repeat(x, num_queries_per_kv, axis=2)

        # Reshape: -> (batch, num_heads, seq, head_dim)
        return x.reshape(batch_size, num_kv_heads * num_queries_per_kv, seq_len, head_dim)


class MultiHeadAttention(AttentionLayerBase):
    """
    Standard multi-head attention implementation.

    This is a concrete implementation for reference and testing.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int | None = None,
        **kwargs: Any,
    ):
        """Initialize multi-head attention."""
        super().__init__(hidden_size, num_heads, num_kv_heads, **kwargs)

        # Query, key, value projections
        self.q_proj = nn.Linear(
            hidden_size,
            num_heads * self.head_dim,
            bias=self.bias,
        )
        self.k_proj = nn.Linear(
            hidden_size,
            self.num_kv_heads * self.head_dim,
            bias=self.bias,
        )
        self.v_proj = nn.Linear(
            hidden_size,
            self.num_kv_heads * self.head_dim,
            bias=self.bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            num_heads * self.head_dim,
            hidden_size,
            bias=self.bias,
        )

    def __call__(
        self,
        hidden_states: mx.array,
        kv_cache: Any | None = None,
        attention_mask: mx.array | None = None,
        position_ids: mx.array | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """Forward pass for multi-head attention."""
        batch_size, seq_len, _ = hidden_states.shape

        # Project to Q, K, V
        query = self.q_proj(hidden_states)
        key = self.k_proj(hidden_states)
        value = self.v_proj(hidden_states)

        # Split heads
        query = self._split_heads(query, self.num_heads)
        key = self._split_heads(key, self.num_kv_heads)
        value = self._split_heads(value, self.num_kv_heads)

        # Repeat KV heads if needed (GQA/MQA)
        if self.num_queries_per_kv > 1:
            key = self._repeat_kv(key, self.num_queries_per_kv)
            value = self._repeat_kv(value, self.num_queries_per_kv)

        # Scaled dot-product attention
        # Q @ K^T / sqrt(d_k)
        attn_weights = mx.matmul(query, mx.transpose(key, (0, 1, 3, 2))) * self.scaling

        # Apply attention mask if provided
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask

        # Softmax
        attn_weights = mx.softmax(attn_weights, axis=-1)

        # Attention @ V
        attn_output = mx.matmul(attn_weights, value)

        # Merge heads
        attn_output = self._merge_heads(attn_output)

        # Output projection
        output = self.o_proj(attn_output)

        return output, kv_cache
