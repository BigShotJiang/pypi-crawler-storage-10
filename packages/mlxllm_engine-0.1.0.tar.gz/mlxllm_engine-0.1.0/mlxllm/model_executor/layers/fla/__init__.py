# SPDX-License-Identifier: Apache-2.0
"""Fast Linear Attention (FLA) implementations for MLX-LLM.

This package provides efficient linear attention mechanisms with O(n) complexity
instead of O(n^2), enabling processing of longer sequences.

Supported architectures:
- GLA (Gated Linear Attention)
- RetNet (Retentive Network)
- RWKV (Receptance Weighted Key Value)
- Based (Linear Attention with Learned Kernel)
"""

from __future__ import annotations

from .gla import GatedLinearAttention, GLALayer
from .retnet import MultiScaleRetention, RetNetLayer
from .rwkv import RWKVAttention, RWKVLayer
from .based import BasedAttention, BasedLayer

__all__ = [
    "GatedLinearAttention",
    "GLALayer",
    "MultiScaleRetention",
    "RetNetLayer",
    "RWKVAttention",
    "RWKVLayer",
    "BasedAttention",
    "BasedLayer",
]
