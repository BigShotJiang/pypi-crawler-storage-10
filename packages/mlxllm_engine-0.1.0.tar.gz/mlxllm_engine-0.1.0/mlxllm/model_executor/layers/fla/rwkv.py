# SPDX-License-Identifier: Apache-2.0
"""RWKV (Receptance Weighted Key Value) for MLX-LLM.

RWKV is an RNN-style architecture that achieves transformer-level performance
with O(1) inference complexity and linear memory usage.

Reference: "RWKV: Reinventing RNNs for the Transformer Era"
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class RWKVAttention(nn.Module):
    """
    RWKV attention mechanism.

    Uses time-mixing with receptance, weight, key, and value vectors
    to achieve linear complexity.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 1,  # RWKV typically uses single head
        **kwargs: Any,
    ):
        """
        Initialize RWKV attention.

        Args:
            hidden_size: Hidden dimension size.
            num_heads: Number of heads (typically 1 for RWKV).
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        # Time-mixing parameters
        self.time_mix_k = mx.ones((hidden_size,))
        self.time_mix_v = mx.ones((hidden_size,))
        self.time_mix_r = mx.ones((hidden_size,))

        # Projections
        self.key = nn.Linear(hidden_size, hidden_size, bias=False)
        self.value = nn.Linear(hidden_size, hidden_size, bias=False)
        self.receptance = nn.Linear(hidden_size, hidden_size, bias=False)
        self.output = nn.Linear(hidden_size, hidden_size, bias=False)

        # Time decay
        self.time_decay = mx.ones((hidden_size,))
        self.time_first = mx.ones((hidden_size,))

    def __call__(
        self,
        hidden_states: mx.array,
        state: mx.array | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, mx.array]:
        """
        Forward pass for RWKV attention.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            state: Previous RNN state.
            **kwargs: Additional arguments.

        Returns:
            Tuple of (output, updated_state).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Initialize state if needed
        if state is None:
            state = mx.zeros((batch_size, self.hidden_size, self.head_dim))

        outputs = []

        # Process sequence step by step (inherently sequential)
        for t in range(seq_len):
            x_t = hidden_states[:, t, :]  # (batch, hidden)

            # Time-mixing with previous token
            if t == 0:
                x_prev = mx.zeros_like(x_t)
            else:
                x_prev = hidden_states[:, t - 1, :]

            # Mix current and previous tokens
            xk = x_t * self.time_mix_k + x_prev * (1 - self.time_mix_k)
            xv = x_t * self.time_mix_v + x_prev * (1 - self.time_mix_v)
            xr = x_t * self.time_mix_r + x_prev * (1 - self.time_mix_r)

            # Compute R, K, V
            r = mx.sigmoid(self.receptance(xr))
            k = self.key(xk)
            v = self.value(xv)

            # RWKV formula with time decay
            # This is a simplified version; full version has more sophisticated state updates
            wkv = state + mx.exp(self.time_first + k) * v
            state = mx.exp(-mx.exp(self.time_decay)) * state + mx.exp(k) * v

            # Output for this timestep
            output_t = r * wkv
            outputs.append(output_t)

        # Stack outputs
        output = mx.stack(outputs, axis=1)  # (batch, seq, hidden)

        # Output projection
        output = self.output(output)

        return output, state


class RWKVLayer(nn.Module):
    """
    Complete RWKV layer with time-mixing and channel-mixing.

    RWKV alternates between time-mixing (attention-like) and
    channel-mixing (FFN-like) operations.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize RWKV layer.

        Args:
            hidden_size: Hidden dimension.
            intermediate_size: Channel-mixing intermediate size.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        intermediate_size = intermediate_size or hidden_size * 4

        # Time-mixing (attention-like)
        self.time_mixing = RWKVAttention(hidden_size=hidden_size, **kwargs)

        # Channel-mixing (FFN-like)
        self.channel_mixing = RWKVChannelMixing(
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
        )

        # Layer norms
        self.ln1 = nn.LayerNorm(hidden_size)
        self.ln2 = nn.LayerNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        state: tuple[mx.array, mx.array] | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, tuple[mx.array, mx.array]]:
        """Forward pass for RWKV layer."""
        if state is None:
            time_state = None
            channel_state = None
        else:
            time_state, channel_state = state

        # Time-mixing with residual
        residual = hidden_states
        hidden_states = self.ln1(hidden_states)
        hidden_states, time_state = self.time_mixing(hidden_states, time_state)
        hidden_states = residual + hidden_states

        # Channel-mixing with residual
        residual = hidden_states
        hidden_states = self.ln2(hidden_states)
        hidden_states, channel_state = self.channel_mixing(hidden_states, channel_state)
        hidden_states = residual + hidden_states

        return hidden_states, (time_state, channel_state)


class RWKVChannelMixing(nn.Module):
    """
    RWKV channel-mixing (FFN-like) module.

    Similar structure to time-mixing but operates on channels.
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int = 3072,
    ):
        """
        Initialize channel-mixing.

        Args:
            hidden_size: Hidden dimension.
            intermediate_size: Intermediate dimension.
        """
        super().__init__()

        self.hidden_size = hidden_size

        # Time-mixing parameters for channel mixing
        self.time_mix_k = mx.ones((hidden_size,))
        self.time_mix_r = mx.ones((hidden_size,))

        # Projections
        self.key = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.receptance = nn.Linear(hidden_size, hidden_size, bias=False)
        self.value = nn.Linear(intermediate_size, hidden_size, bias=False)

    def __call__(
        self,
        hidden_states: mx.array,
        state: mx.array | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, mx.array]:
        """Forward pass for channel-mixing."""
        batch_size, seq_len, _ = hidden_states.shape

        outputs = []

        # Process sequence step by step
        for t in range(seq_len):
            x_t = hidden_states[:, t, :]

            # Time-mixing with previous token
            if t == 0:
                x_prev = mx.zeros_like(x_t)
            else:
                x_prev = hidden_states[:, t - 1, :]

            # Mix current and previous
            xk = x_t * self.time_mix_k + x_prev * (1 - self.time_mix_k)
            xr = x_t * self.time_mix_r + x_prev * (1 - self.time_mix_r)

            # Compute output
            r = mx.sigmoid(self.receptance(xr))
            k = mx.square(nn.relu(self.key(xk)))  # Squared ReLU
            output_t = r * self.value(k)

            outputs.append(output_t)

        # Stack outputs
        output = mx.stack(outputs, axis=1)

        return output, state
