# SPDX-License-Identifier: Apache-2.0
"""Based Linear Attention for MLX-LLM.

Based is a linear attention mechanism with learned feature maps that
achieves strong performance while maintaining O(n) complexity.

Reference: "Based: Simple Linear Attention Language Models Balance the Recall-Throughput Tradeoff"
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class BasedAttention(nn.Module):
    """
    Based linear attention with Taylor series feature maps.

    Uses learned polynomial feature maps to approximate attention
    while maintaining linear complexity.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        feature_dim: int | None = None,
        polynomial_order: int = 3,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize Based attention.

        Args:
            hidden_size: Hidden dimension size.
            num_heads: Number of attention heads.
            feature_dim: Feature map dimension (defaults to head_dim).
            polynomial_order: Order of polynomial feature map.
            bias: Whether to use bias.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.feature_dim = feature_dim or self.head_dim
        self.polynomial_order = polynomial_order

        if hidden_size % num_heads != 0:
            raise ValueError(
                f"hidden_size ({hidden_size}) must be divisible by "
                f"num_heads ({num_heads})"
            )

        # Projections
        self.q_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.k_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.v_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        # Feature map parameters (learnable)
        self.feature_map_q = nn.Linear(self.head_dim, self.feature_dim, bias=False)
        self.feature_map_k = nn.Linear(self.head_dim, self.feature_dim, bias=False)

        # Output projection
        self.o_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for Based attention.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            attention_mask: Optional attention mask.
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch, seq_len, hidden_size).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project Q, K, V
        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        # Reshape for multi-head
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        # Transpose to (batch, heads, seq, head_dim)
        q = mx.transpose(q, (0, 2, 1, 3))
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Apply learned feature maps
        q_features = self._apply_feature_map(q, self.feature_map_q)
        k_features = self._apply_feature_map(k, self.feature_map_k)

        # Linear attention: phi(Q) @ (phi(K)^T @ V)
        # (B, H, L, F) @ (B, H, F, D)
        kv = mx.matmul(mx.transpose(k_features, (0, 1, 3, 2)), v)  # (B, H, F, D)
        output = mx.matmul(q_features, kv)  # (B, H, L, D)

        # Normalization (important for stability)
        k_sum = mx.sum(k_features, axis=2, keepdims=True)  # (B, H, 1, F)
        normalizer = mx.matmul(q_features, mx.transpose(k_sum, (0, 1, 3, 2)))  # (B, H, L, 1)
        output = output / (normalizer + 1e-6)

        # Transpose back and reshape
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, seq_len, self.hidden_size)

        # Output projection
        output = self.o_proj(output)

        return output

    def _apply_feature_map(self, x: mx.array, proj: nn.Linear) -> mx.array:
        """
        Apply polynomial feature map.

        Args:
            x: Input tensor (batch, heads, seq, head_dim).
            proj: Feature map projection.

        Returns:
            Feature mapped tensor (batch, heads, seq, feature_dim).
        """
        batch_size, num_heads, seq_len, head_dim = x.shape

        # Reshape for projection
        x_flat = x.reshape(-1, head_dim)
        features = proj(x_flat)
        features = features.reshape(batch_size, num_heads, seq_len, self.feature_dim)

        # Apply Taylor series approximation (polynomial features)
        # phi(x) = [1, x, x^2/2, x^3/6, ...]
        output = features

        # Add higher-order terms (simplified Taylor series)
        if self.polynomial_order > 1:
            output = output + mx.square(features) / 2.0

        if self.polynomial_order > 2:
            output = output + mx.power(features, 3) / 6.0

        # ReLU to ensure non-negativity (important for linear attention)
        output = nn.relu(output)

        return output


class BasedLayer(nn.Module):
    """
    Complete Based layer with attention and feedforward.

    This is a transformer-style block using Based linear attention.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        intermediate_size: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize Based layer.

        Args:
            hidden_size: Hidden dimension.
            num_heads: Number of attention heads.
            intermediate_size: FFN intermediate size.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        intermediate_size = intermediate_size or hidden_size * 4

        # Based attention
        self.attention = BasedAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            **kwargs,
        )

        # Feedforward network (GLU variant for better performance)
        self.ffn_gate = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.ffn_up = nn.Linear(hidden_size, intermediate_size, bias=False)
        self.ffn_down = nn.Linear(intermediate_size, hidden_size, bias=False)

        # Layer norms
        self.attn_norm = nn.RMSNorm(hidden_size)
        self.ffn_norm = nn.RMSNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """Forward pass for Based layer."""
        # Attention with residual
        residual = hidden_states
        hidden_states = self.attn_norm(hidden_states)
        hidden_states = self.attention(hidden_states, attention_mask)
        hidden_states = residual + hidden_states

        # FFN with residual (GLU)
        residual = hidden_states
        hidden_states = self.ffn_norm(hidden_states)

        gate = nn.silu(self.ffn_gate(hidden_states))
        up = self.ffn_up(hidden_states)
        hidden_states = self.ffn_down(gate * up)

        hidden_states = residual + hidden_states

        return hidden_states
