# SPDX-License-Identifier: Apache-2.0
"""Retentive Network (RetNet) for MLX-LLM.

RetNet is a sequence modeling architecture that achieves O(1) inference complexity
through retention mechanisms instead of attention.

Reference: "Retentive Network: A Successor to Transformer for Large Language Models"
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class MultiScaleRetention(nn.Module):
    """
    Multi-scale retention mechanism.

    Retention replaces attention with a recurrent formulation that
    allows O(1) complexity during inference (constant memory).
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize multi-scale retention.

        Args:
            hidden_size: Hidden dimension size.
            num_heads: Number of retention heads.
            bias: Whether to use bias.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        if hidden_size % num_heads != 0:
            raise ValueError(
                f"hidden_size ({hidden_size}) must be divisible by "
                f"num_heads ({num_heads})"
            )

        # Projections (Q, K, V)
        self.q_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.k_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.v_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        # Gate for controlling retention
        self.g_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        # Output projection
        self.o_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        # Decay rates for each head (learnable)
        # Different heads have different temporal scales
        self.gamma = mx.array(
            [1.0 - 2.0 ** (-(5.0 + i)) for i in range(num_heads)]
        )

    def __call__(
        self,
        hidden_states: mx.array,
        retention_mask: mx.array | None = None,
        past_key_value: Any | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """
        Forward pass for retention.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            retention_mask: Optional retention mask.
            past_key_value: Past KV state for recurrent inference.
            **kwargs: Additional arguments.

        Returns:
            Tuple of (output, updated_kv_state).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project Q, K, V
        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        # Project gate
        g = self.g_proj(hidden_states)
        g = nn.silu(g)

        # Reshape for multi-head
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        # Transpose to (batch, heads, seq, head_dim)
        q = mx.transpose(q, (0, 2, 1, 3))
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Compute retention
        # Use parallel form for training (O(n^2) but parallelizable)
        # In inference, can use recurrent form (O(1) per step)
        output = self._parallel_retention(q, k, v)

        # Transpose back and reshape
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, seq_len, self.hidden_size)

        # Apply gating
        output = output * g

        # Output projection
        output = self.o_proj(output)

        return output, past_key_value

    def _parallel_retention(
        self,
        q: mx.array,
        k: mx.array,
        v: mx.array,
    ) -> mx.array:
        """
        Parallel retention computation (for training).

        Args:
            q: Query tensor (batch, heads, seq, head_dim).
            k: Key tensor (batch, heads, seq, head_dim).
            v: Value tensor (batch, heads, seq, head_dim).

        Returns:
            Retention output (batch, heads, seq, head_dim).
        """
        batch_size, num_heads, seq_len, head_dim = q.shape

        # Compute retention matrix with decay
        # D[i, j] = gamma^(i-j) if i >= j, else 0
        positions = mx.arange(seq_len)
        decay_matrix = mx.where(
            mx.expand_dims(positions, 1) >= mx.expand_dims(positions, 0),
            mx.power(
                mx.expand_dims(mx.expand_dims(self.gamma, -1), -1),
                mx.expand_dims(positions, 1) - mx.expand_dims(positions, 0),
            ),
            0.0,
        )

        # Compute Q @ K^T
        scores = mx.matmul(q, mx.transpose(k, (0, 1, 3, 2)))

        # Apply decay
        scores = scores * mx.expand_dims(decay_matrix, 0)

        # Normalize
        scores = scores / mx.sqrt(mx.array(head_dim, dtype=scores.dtype))

        # Apply to values
        output = mx.matmul(scores, v)

        return output


class RetNetLayer(nn.Module):
    """
    Complete RetNet layer with retention and feedforward.

    This is a transformer-style block using retention instead of attention.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        intermediate_size: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize RetNet layer.

        Args:
            hidden_size: Hidden dimension.
            num_heads: Number of retention heads.
            intermediate_size: FFN intermediate size.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        intermediate_size = intermediate_size or hidden_size * 4

        # Retention mechanism
        self.retention = MultiScaleRetention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            **kwargs,
        )

        # Feedforward network
        self.ffn = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.GELU(),
            nn.Linear(intermediate_size, hidden_size),
        )

        # Layer norms
        self.retention_norm = nn.LayerNorm(hidden_size)
        self.ffn_norm = nn.LayerNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        retention_mask: mx.array | None = None,
        past_key_value: Any | None = None,
        **kwargs: Any,
    ) -> tuple[mx.array, Any]:
        """Forward pass for RetNet layer."""
        # Retention with residual
        residual = hidden_states
        hidden_states = self.retention_norm(hidden_states)
        hidden_states, past_key_value = self.retention(
            hidden_states, retention_mask, past_key_value
        )
        hidden_states = residual + hidden_states

        # FFN with residual
        residual = hidden_states
        hidden_states = self.ffn_norm(hidden_states)
        hidden_states = self.ffn(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states, past_key_value
