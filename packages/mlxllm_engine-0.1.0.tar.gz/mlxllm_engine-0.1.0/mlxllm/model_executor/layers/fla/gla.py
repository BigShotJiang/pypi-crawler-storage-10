# SPDX-License-Identifier: Apache-2.0
"""Gated Linear Attention (GLA) for MLX-LLM.

GLA combines gating mechanisms with linear attention for efficient
sequence modeling with O(n) complexity.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


class GatedLinearAttention(nn.Module):
    """
    Gated Linear Attention layer.

    Uses gating to control information flow in linear attention,
    providing better performance than vanilla linear attention.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        expand_ratio: float = 2.0,
        bias: bool = False,
        **kwargs: Any,
    ):
        """
        Initialize GLA.

        Args:
            hidden_size: Hidden dimension size.
            num_heads: Number of attention heads.
            expand_ratio: Expansion ratio for gate dimension.
            bias: Whether to use bias in projections.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.gate_dim = int(hidden_size * expand_ratio)

        # Projections
        self.q_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.k_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.v_proj = nn.Linear(hidden_size, hidden_size, bias=bias)
        self.g_proj = nn.Linear(hidden_size, self.gate_dim, bias=bias)

        # Output projection
        self.o_proj = nn.Linear(hidden_size, hidden_size, bias=bias)

        # Gate activation
        self.gate_fn = nn.silu

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """
        Forward pass for GLA.

        Args:
            hidden_states: Input tensor (batch, seq_len, hidden_size).
            attention_mask: Optional attention mask.
            **kwargs: Additional arguments.

        Returns:
            Output tensor (batch, seq_len, hidden_size).
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project Q, K, V
        q = self.q_proj(hidden_states)
        k = self.k_proj(hidden_states)
        v = self.v_proj(hidden_states)

        # Project gate
        g = self.g_proj(hidden_states)
        g = self.gate_fn(g)

        # Reshape for multi-head
        q = q.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        k = k.reshape(batch_size, seq_len, self.num_heads, self.head_dim)
        v = v.reshape(batch_size, seq_len, self.num_heads, self.head_dim)

        # Transpose to (batch, heads, seq, head_dim)
        q = mx.transpose(q, (0, 2, 1, 3))
        k = mx.transpose(k, (0, 2, 1, 3))
        v = mx.transpose(v, (0, 2, 1, 3))

        # Linear attention: O(n) complexity
        # Compute K^T @ V first (d x d matrix)
        kv = mx.matmul(mx.transpose(k, (0, 1, 3, 2)), v)  # (B, H, D, D)

        # Then Q @ (K^T @ V)
        output = mx.matmul(q, kv)  # (B, H, L, D)

        # Transpose back and reshape
        output = mx.transpose(output, (0, 2, 1, 3))
        output = output.reshape(batch_size, seq_len, self.hidden_size)

        # Apply gating
        if g.shape[-1] == output.shape[-1]:
            output = output * g
        else:
            # Project gate to match output dimension
            output = output * g[..., : self.hidden_size]

        # Output projection
        output = self.o_proj(output)

        return output


class GLALayer(nn.Module):
    """
    Complete GLA layer with feedforward network.

    This is a transformer-style block using GLA instead of standard attention.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int = 8,
        intermediate_size: int | None = None,
        **kwargs: Any,
    ):
        """
        Initialize GLA layer.

        Args:
            hidden_size: Hidden dimension.
            num_heads: Number of attention heads.
            intermediate_size: FFN intermediate size.
            **kwargs: Additional arguments.
        """
        super().__init__()

        self.hidden_size = hidden_size
        intermediate_size = intermediate_size or hidden_size * 4

        # GLA attention
        self.attention = GatedLinearAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            **kwargs,
        )

        # Feedforward network
        self.ffn = nn.Sequential(
            nn.Linear(hidden_size, intermediate_size),
            nn.SiLU(),
            nn.Linear(intermediate_size, hidden_size),
        )

        # Layer norms
        self.attn_norm = nn.RMSNorm(hidden_size)
        self.ffn_norm = nn.RMSNorm(hidden_size)

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        **kwargs: Any,
    ) -> mx.array:
        """Forward pass for GLA layer."""
        # Attention with residual
        residual = hidden_states
        hidden_states = self.attn_norm(hidden_states)
        hidden_states = self.attention(hidden_states, attention_mask)
        hidden_states = residual + hidden_states

        # FFN with residual
        residual = hidden_states
        hidden_states = self.ffn_norm(hidden_states)
        hidden_states = self.ffn(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states
