# SPDX-License-Identifier: Apache-2.0
"""Linear layers with quantization support for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass


class LinearBase(nn.Module):
    """Base class for linear layers."""

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = True,
    ) -> None:
        """Initialize linear layer."""
        super().__init__()
        self.input_size = input_size
        self.output_size = output_size
        self.bias_enabled = bias


class UnquantizedLinear(LinearBase):
    """Standard unquantized linear layer."""

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = True,
    ) -> None:
        """Initialize unquantized linear."""
        super().__init__(input_size, output_size, bias)

        self.linear = nn.Linear(input_size, output_size, bias=bias)

    def forward(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.linear(x)

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class QuantizedLinear(LinearBase):
    """
    Quantized linear layer.

    Supports MLX quantization formats (Q4, Q8) for memory-efficient inference.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = True,
        bits: int = 4,
        group_size: int = 64,
    ) -> None:
        """
        Initialize quantized linear.

        Args:
            input_size: Input dimension.
            output_size: Output dimension.
            bias: Whether to use bias.
            bits: Quantization bits (4 or 8).
            group_size: Group size for quantization.
        """
        super().__init__(input_size, output_size, bias)

        self.bits = bits
        self.group_size = group_size

        # Use MLX quantized linear
        self.linear = nn.QuantizedLinear(
            input_size,
            output_size,
            bias=bias,
            bits=bits,
            group_size=group_size,
        )

    def forward(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.linear(x)

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class ColumnParallelLinear(LinearBase):
    """
    Column-parallel linear layer.

    For single-device, this is equivalent to a standard linear layer.
    On multi-device, the output dimension is split across devices.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = True,
        gather_output: bool = True,
        quantized: bool = False,
        bits: int = 4,
    ) -> None:
        """Initialize column-parallel linear."""
        super().__init__(input_size, output_size, bias)

        self.gather_output = gather_output

        if quantized:
            self.linear = QuantizedLinear(
                input_size,
                output_size,
                bias=bias,
                bits=bits,
            )
        else:
            self.linear = UnquantizedLinear(
                input_size,
                output_size,
                bias=bias,
            )

    def forward(self, x: mx.array) -> mx.array:
        """Forward pass."""
        output = self.linear(x)

        # In single-device mode, gather_output has no effect
        # In multi-device mode, this would gather across devices
        return output

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class RowParallelLinear(LinearBase):
    """
    Row-parallel linear layer.

    For single-device, this is equivalent to a standard linear layer.
    On multi-device, the input dimension is split across devices.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        bias: bool = True,
        input_is_parallel: bool = True,
        quantized: bool = False,
        bits: int = 4,
    ) -> None:
        """Initialize row-parallel linear."""
        super().__init__(input_size, output_size, bias)

        self.input_is_parallel = input_is_parallel

        if quantized:
            self.linear = QuantizedLinear(
                input_size,
                output_size,
                bias=bias,
                bits=bits,
            )
        else:
            self.linear = UnquantizedLinear(
                input_size,
                output_size,
                bias=bias,
            )

    def forward(self, x: mx.array) -> mx.array:
        """Forward pass."""
        # In single-device mode, input_is_parallel has no effect
        # In multi-device mode, this would handle split inputs
        output = self.linear(x)
        return output

    def __call__(self, x: mx.array) -> mx.array:
        """Forward pass."""
        return self.forward(x)


class QKVParallelLinear(LinearBase):
    """
    Specialized layer for computing Q, K, V in one shot.

    More efficient than three separate linear layers.
    """

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        bias: bool = False,
        quantized: bool = False,
        bits: int = 4,
    ) -> None:
        """
        Initialize QKV parallel linear.

        Args:
            hidden_size: Hidden size.
            num_heads: Number of query heads.
            num_kv_heads: Number of key/value heads.
            head_dim: Head dimension.
            bias: Whether to use bias.
            quantized: Whether to quantize.
            bits: Quantization bits.
        """
        total_size = (num_heads + 2 * num_kv_heads) * head_dim
        super().__init__(hidden_size, total_size, bias)

        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim

        if quantized:
            self.linear = QuantizedLinear(
                hidden_size,
                total_size,
                bias=bias,
                bits=bits,
            )
        else:
            self.linear = UnquantizedLinear(
                hidden_size,
                total_size,
                bias=bias,
            )

    def forward(self, x: mx.array) -> tuple[mx.array, mx.array, mx.array]:
        """
        Forward pass returning Q, K, V.

        Args:
            x: Input [batch, seq_len, hidden_size].

        Returns:
            Tuple of (Q, K, V).
        """
        qkv = self.linear(x)

        # Split into Q, K, V
        q_size = self.num_heads * self.head_dim
        kv_size = self.num_kv_heads * self.head_dim

        q, k, v = mx.split(
            qkv,
            [q_size, q_size + kv_size],
            axis=-1,
        )

        return q, k, v

    def __call__(self, x: mx.array) -> tuple[mx.array, mx.array, mx.array]:
        """Forward pass."""
        return self.forward(x)


class MergedColumnParallelLinear(LinearBase):
    """
    Merged column-parallel linear for multiple outputs.

    Used for gate-up projection in MLP layers.
    """

    def __init__(
        self,
        input_size: int,
        output_sizes: list[int],
        bias: bool = False,
        quantized: bool = False,
        bits: int = 4,
    ) -> None:
        """
        Initialize merged column-parallel linear.

        Args:
            input_size: Input size.
            output_sizes: List of output sizes for each split.
            bias: Whether to use bias.
            quantized: Whether to quantize.
            bits: Quantization bits.
        """
        total_output_size = sum(output_sizes)
        super().__init__(input_size, total_output_size, bias)

        self.output_sizes = output_sizes

        if quantized:
            self.linear = QuantizedLinear(
                input_size,
                total_output_size,
                bias=bias,
                bits=bits,
            )
        else:
            self.linear = UnquantizedLinear(
                input_size,
                total_output_size,
                bias=bias,
            )

    def forward(self, x: mx.array) -> list[mx.array]:
        """
        Forward pass returning multiple outputs.

        Args:
            x: Input [batch, seq_len, input_size].

        Returns:
            List of outputs, one for each output_size.
        """
        output = self.linear(x)

        # Split into multiple outputs
        split_points = []
        cumsum = 0
        for size in self.output_sizes[:-1]:
            cumsum += size
            split_points.append(cumsum)

        outputs = mx.split(output, split_points, axis=-1)

        return list(outputs)

    def __call__(self, x: mx.array) -> list[mx.array]:
        """Forward pass."""
        return self.forward(x)
