# SPDX-License-Identifier: Apache-2.0
"""Llama model implementation for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

from mlxllm.attention.layer import Attention, AttentionConfig
from mlxllm.model_executor.layers.activation import SwiGLU
from mlxllm.model_executor.layers.layernorm import RMSNorm
from mlxllm.model_executor.layers.linear import (
    ColumnParallelLinear,
    RowParallelLinear,
)

if TYPE_CHECKING:
    from mlxllm.attention.backends.abstract import AttentionBackend, AttentionMetadata
    from mlxllm.config.model import ModelConfig


class LlamaMLP(nn.Module):
    """
    Llama MLP (Feed-Forward Network).

    Uses SwiGLU activation: SiLU(gate) * up
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        quantized: bool = False,
    ) -> None:
        """
        Initialize Llama MLP.

        Args:
            hidden_size: Hidden dimension.
            intermediate_size: Intermediate (FFN) dimension.
            quantized: Whether to use quantized linear layers.
        """
        super().__init__()

        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size

        # Gate and up projections (merged for efficiency)
        self.gate_up_proj = ColumnParallelLinear(
            hidden_size,
            2 * intermediate_size,
            bias=False,
            quantized=quantized,
        )

        # Down projection
        self.down_proj = RowParallelLinear(
            intermediate_size,
            hidden_size,
            bias=False,
            quantized=quantized,
        )

        # Activation
        self.act = SwiGLU()

    def forward(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input [num_tokens, hidden_size].

        Returns:
            Output [num_tokens, hidden_size].
        """
        # Gate and up projection
        gate_up = self.gate_up_proj(x)

        # Split into gate and up
        gate, up = mx.split(gate_up, 2, axis=-1)

        # Apply SwiGLU: SiLU(gate) * up
        x = self.act(gate, up)

        # Down projection
        x = self.down_proj(x)

        return x


class LlamaDecoderLayer(nn.Module):
    """
    Llama decoder layer.

    Consists of:
    1. Self-attention with RMSNorm
    2. MLP with RMSNorm
    """

    def __init__(
        self,
        config: ModelConfig,
        attention_backend: AttentionBackend,
        layer_idx: int,
    ) -> None:
        """
        Initialize decoder layer.

        Args:
            config: Model configuration.
            attention_backend: Attention backend.
            layer_idx: Layer index.
        """
        super().__init__()

        self.layer_idx = layer_idx
        self.hidden_size = config.hidden_size

        # Attention
        # Support both num_kv_heads (ModelConfig) and num_key_value_heads (HF config)
        num_kv_heads = getattr(config, 'num_kv_heads', None) or getattr(config, 'num_key_value_heads', config.num_attention_heads)

        # Some models (like Qwen2.5) use attention bias
        attention_bias = getattr(config, 'attention_bias', False)

        attn_config = AttentionConfig(
            num_heads=config.num_attention_heads,
            num_kv_heads=num_kv_heads,
            head_dim=config.hidden_size // config.num_attention_heads,
            hidden_size=config.hidden_size,
            max_position_embeddings=config.max_position_embeddings,
            rope_theta=config.rope_theta,
            attention_bias=attention_bias,
        )

        self.self_attn = Attention(
            config=attn_config,
            backend=attention_backend,
            layer_idx=layer_idx,
        )

        # MLP
        self.mlp = LlamaMLP(
            hidden_size=config.hidden_size,
            intermediate_size=config.intermediate_size,
            quantized=False,  # Will be set by loader
        )

        # Layer norms
        self.input_layernorm = RMSNorm(
            config.hidden_size,
            eps=config.rms_norm_eps,
        )

        self.post_attention_layernorm = RMSNorm(
            config.hidden_size,
            eps=config.rms_norm_eps,
        )

    def forward(
        self,
        hidden_states: mx.array,
        positions: mx.array,
        kv_cache: mx.array | None,
        attn_metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Forward pass.

        Args:
            hidden_states: Input [num_tokens, hidden_size].
            positions: Token positions [num_tokens].
            kv_cache: KV cache for this layer.
            attn_metadata: Attention metadata.

        Returns:
            Output [num_tokens, hidden_size].
        """
        # Self-attention with residual
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)

        hidden_states = self.self_attn.forward(
            hidden_states=hidden_states,
            positions=positions,
            kv_cache=kv_cache,
            metadata=attn_metadata,
        )

        hidden_states = residual + hidden_states

        # MLP with residual
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp.forward(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states


class LlamaModel(nn.Module):
    """
    Llama transformer model (without LM head).
    """

    def __init__(
        self,
        config: ModelConfig,
        attention_backend: AttentionBackend,
    ) -> None:
        """
        Initialize Llama model.

        Args:
            config: Model configuration.
            attention_backend: Attention backend.
        """
        super().__init__()

        self.config = config
        self.vocab_size = config.vocab_size
        self.hidden_size = config.hidden_size

        # Embeddings
        self.embed_tokens = nn.Embedding(config.vocab_size, config.hidden_size)

        # Decoder layers
        # Support both num_layers (ModelConfig) and num_hidden_layers (HF config)
        num_layers = getattr(config, 'num_layers', None) or getattr(config, 'num_hidden_layers', 32)
        self.layers = [
            LlamaDecoderLayer(config, attention_backend, i)
            for i in range(num_layers)
        ]

        # Final norm
        self.norm = RMSNorm(config.hidden_size, eps=config.rms_norm_eps)

    def forward(
        self,
        input_ids: mx.array,
        positions: mx.array,
        kv_caches: list[mx.array] | None,
        attn_metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Forward pass.

        Args:
            input_ids: Input token IDs [num_tokens].
            positions: Token positions [num_tokens].
            kv_caches: KV caches for all layers.
            attn_metadata: Attention metadata.

        Returns:
            Hidden states [num_tokens, hidden_size].
        """
        # Embeddings
        hidden_states = self.embed_tokens(input_ids)

        # Decoder layers
        for i, layer in enumerate(self.layers):
            kv_cache = kv_caches[i] if kv_caches else None
            hidden_states = layer.forward(
                hidden_states=hidden_states,
                positions=positions,
                kv_cache=kv_cache,
                attn_metadata=attn_metadata,
            )

        # Final norm
        hidden_states = self.norm(hidden_states)

        return hidden_states


class LlamaForCausalLM(nn.Module):
    """
    Llama model for causal language modeling.

    Includes the language modeling head for token prediction.
    """

    def __init__(
        self,
        config: ModelConfig,
        attention_backend: AttentionBackend | None = None,
    ) -> None:
        """
        Initialize Llama for causal LM.

        Args:
            config: Model configuration.
            attention_backend: Attention backend (auto-selected if None).
        """
        super().__init__()

        self.config = config

        # Auto-select attention backend if not provided
        if attention_backend is None:
            from mlxllm.attention.selector import get_attention_backend

            attention_backend = get_attention_backend()

        # Model
        self.model = LlamaModel(config, attention_backend)

        # LM head (tied with embeddings in Llama)
        self.lm_head = nn.Linear(
            config.hidden_size,
            config.vocab_size,
            bias=False,
        )

    def forward(
        self,
        input_ids: mx.array,
        positions: mx.array,
        kv_caches: list[mx.array] | None = None,
        attn_metadata: AttentionMetadata | None = None,
    ) -> mx.array:
        """
        Forward pass.

        Args:
            input_ids: Input token IDs [num_tokens].
            positions: Token positions [num_tokens].
            kv_caches: KV caches for all layers.
            attn_metadata: Attention metadata.

        Returns:
            Logits [num_tokens, vocab_size].
        """
        # Get hidden states from model
        hidden_states = self.model.forward(
            input_ids=input_ids,
            positions=positions,
            kv_caches=kv_caches,
            attn_metadata=attn_metadata,
        )

        # Compute logits
        logits = self.lm_head(hidden_states)

        return logits

    def __call__(
        self,
        input_ids: mx.array,
        positions: mx.array,
        kv_caches: list[mx.array] | None = None,
        attn_metadata: AttentionMetadata | None = None,
    ) -> mx.array:
        """Forward pass."""
        return self.forward(input_ids, positions, kv_caches, attn_metadata)
