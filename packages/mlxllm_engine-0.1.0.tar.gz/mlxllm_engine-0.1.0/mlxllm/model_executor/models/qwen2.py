# SPDX-License-Identifier: Apache-2.0
"""Qwen2 model implementation for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.model_executor.models.llama import (
    LlamaDecoderLayer,
    LlamaForCausalLM,
    LlamaMLP,
    LlamaModel,
)

if TYPE_CHECKING:
    from mlxllm.attention.backends.abstract import AttentionBackend
    from mlxllm.config.model import ModelConfig


class Qwen2ForCausalLM(LlamaForCausalLM):
    """
    Qwen2 model for causal language modeling.

    Qwen2 uses the same architecture as Llama, so we can directly inherit.
    The main differences are in hyperparameters (vocab size, layer count, etc.)
    which are handled by the config.
    """

    def __init__(
        self,
        config: ModelConfig,
        attention_backend: AttentionBackend | None = None,
    ) -> None:
        """
        Initialize Qwen2 for causal LM.

        Args:
            config: Model configuration.
            attention_backend: Attention backend (auto-selected if None).
        """
        # Qwen2 architecture is identical to Llama
        super().__init__(config, attention_backend)


# Export the same components as Llama for consistency
Qwen2Model = LlamaModel
Qwen2DecoderLayer = LlamaDecoderLayer
Qwen2MLP = LlamaMLP
