# SPDX-License-Identifier: Apache-2.0
"""
Model executor utilities.

This module provides utility functions for model execution, including
tensor manipulation, model configuration helpers, and performance utilities.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx


__all__ = [
    "set_default_dtype",
    "get_default_dtype",
    "set_random_seed",
    "get_activation_checkpointing_enabled",
    "set_activation_checkpointing",
]


# Global state for default dtype
_DEFAULT_DTYPE = mx.float32

# Global state for activation checkpointing
_ACTIVATION_CHECKPOINTING = False


def set_default_dtype(dtype: mx.Dtype | str) -> None:
    """
    Set the default dtype for model weights.

    Args:
        dtype: Target dtype (mx.float32, mx.float16, mx.bfloat16, or string)

    Example:
        >>> set_default_dtype(mx.float16)
        >>> set_default_dtype("bfloat16")
    """
    global _DEFAULT_DTYPE

    if isinstance(dtype, str):
        dtype_map = {
            "float32": mx.float32,
            "float16": mx.float16,
            "bfloat16": mx.bfloat16,
            "int8": mx.int8,
            "int32": mx.int32,
        }
        if dtype not in dtype_map:
            raise ValueError(
                f"Unknown dtype string: {dtype}. "
                f"Available: {list(dtype_map.keys())}"
            )
        dtype = dtype_map[dtype]

    _DEFAULT_DTYPE = dtype


def get_default_dtype() -> mx.Dtype:
    """
    Get the current default dtype for model weights.

    Returns:
        Current default dtype

    Example:
        >>> dtype = get_default_dtype()
        >>> print(dtype)
    """
    return _DEFAULT_DTYPE


def set_random_seed(seed: int) -> None:
    """
    Set random seed for reproducibility.

    Args:
        seed: Random seed value

    Example:
        >>> set_random_seed(42)
    """
    mx.random.seed(seed)


def get_activation_checkpointing_enabled() -> bool:
    """
    Check if activation checkpointing is enabled.

    Returns:
        True if activation checkpointing is enabled

    Example:
        >>> enabled = get_activation_checkpointing_enabled()
    """
    return _ACTIVATION_CHECKPOINTING


def set_activation_checkpointing(enabled: bool) -> None:
    """
    Enable or disable activation checkpointing.

    Activation checkpointing trades compute for memory by recomputing
    activations during backward pass instead of storing them.

    Args:
        enabled: Whether to enable activation checkpointing

    Example:
        >>> set_activation_checkpointing(True)  # Save memory
        >>> set_activation_checkpointing(False)  # Save compute
    """
    global _ACTIVATION_CHECKPOINTING
    _ACTIVATION_CHECKPOINTING = enabled


def apply_rotary_pos_emb(
    q: mx.array,
    k: mx.array,
    cos: mx.array,
    sin: mx.array,
    position_ids: mx.array | None = None,
) -> tuple[mx.array, mx.array]:
    """
    Apply rotary position embeddings to query and key tensors.

    This is a helper function that applies RoPE (Rotary Position Embeddings)
    to the query and key tensors.

    Args:
        q: Query tensor [batch, heads, seq_len, head_dim]
        k: Key tensor [batch, heads, seq_len, head_dim]
        cos: Cosine values [seq_len, head_dim] or [batch, seq_len, head_dim]
        sin: Sine values [seq_len, head_dim] or [batch, seq_len, head_dim]
        position_ids: Optional position IDs [batch, seq_len]

    Returns:
        Tuple of (rotated_q, rotated_k)

    Example:
        >>> q_rotated, k_rotated = apply_rotary_pos_emb(q, k, cos, sin)
    """
    # This is typically handled by the RotaryEmbedding layer
    # This is a utility wrapper for convenience

    # Reshape for broadcasting
    if cos.ndim == 2:
        # [seq_len, head_dim] -> [1, 1, seq_len, head_dim]
        cos = mx.expand_dims(mx.expand_dims(cos, 0), 0)
        sin = mx.expand_dims(mx.expand_dims(sin, 0), 0)
    elif cos.ndim == 3:
        # [batch, seq_len, head_dim] -> [batch, 1, seq_len, head_dim]
        cos = mx.expand_dims(cos, 1)
        sin = mx.expand_dims(sin, 1)

    # Split q and k into halves for rotation
    q_half1, q_half2 = mx.split(q, 2, axis=-1)
    k_half1, k_half2 = mx.split(k, 2, axis=-1)

    # Split cos and sin into halves to match split q/k dimensions
    cos_half1, cos_half2 = mx.split(cos, 2, axis=-1)
    sin_half1, sin_half2 = mx.split(sin, 2, axis=-1)

    # Apply rotation using RoPE formula
    # Original RoPE: [x1, x2] * [[cos, -sin], [sin, cos]]
    q_rotated = mx.concatenate(
        [
            q_half1 * cos_half1 - q_half2 * sin_half1,
            q_half1 * sin_half2 + q_half2 * cos_half2,
        ],
        axis=-1,
    )

    k_rotated = mx.concatenate(
        [
            k_half1 * cos_half1 - k_half2 * sin_half1,
            k_half1 * sin_half2 + k_half2 * cos_half2,
        ],
        axis=-1,
    )

    return q_rotated, k_rotated


def repeat_kv(
    hidden_states: mx.array,
    n_rep: int,
) -> mx.array:
    """
    Repeat key/value tensors for grouped query attention (GQA).

    This is used to expand KV heads to match the number of query heads
    in grouped query attention.

    Args:
        hidden_states: Input tensor [batch, num_kv_heads, seq_len, head_dim]
        n_rep: Number of repetitions (num_q_heads // num_kv_heads)

    Returns:
        Repeated tensor [batch, num_q_heads, seq_len, head_dim]

    Example:
        >>> # GQA: 32 query heads, 8 KV heads -> repeat 4 times
        >>> k_expanded = repeat_kv(k, n_rep=4)
    """
    if n_rep == 1:
        return hidden_states

    batch, num_kv_heads, seq_len, head_dim = hidden_states.shape

    # Expand and reshape
    hidden_states = mx.expand_dims(hidden_states, axis=2)  # [B, KV, 1, S, D]
    hidden_states = mx.tile(hidden_states, [1, 1, n_rep, 1, 1])  # [B, KV, n_rep, S, D]
    hidden_states = mx.reshape(
        hidden_states,
        (batch, num_kv_heads * n_rep, seq_len, head_dim),
    )

    return hidden_states


def get_mask_from_lengths(
    lengths: mx.array,
    max_len: int | None = None,
) -> mx.array:
    """
    Create attention mask from sequence lengths.

    Args:
        lengths: Sequence lengths [batch_size]
        max_len: Maximum sequence length (defaults to max(lengths))

    Returns:
        Boolean mask [batch_size, max_len] where True = valid position

    Example:
        >>> lengths = mx.array([3, 5, 2])
        >>> mask = get_mask_from_lengths(lengths, max_len=5)
        >>> # mask = [[1,1,1,0,0], [1,1,1,1,1], [1,1,0,0,0]]
    """
    if max_len is None:
        max_len = int(mx.max(lengths))

    batch_size = lengths.shape[0]

    # Create range tensor
    ids = mx.arange(max_len)  # [max_len]
    ids = mx.expand_dims(ids, 0)  # [1, max_len]
    ids = mx.tile(ids, [batch_size, 1])  # [batch_size, max_len]

    # Expand lengths for broadcasting
    lengths = mx.expand_dims(lengths, -1)  # [batch_size, 1]

    # Create mask
    mask = ids < lengths

    return mask


def scaled_dot_product_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    attn_mask: mx.array | None = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
) -> mx.array:
    """
    Compute scaled dot-product attention.

    This is a basic implementation. For production, use MLX's optimized
    implementation: mlx.fast.scaled_dot_product_attention()

    Args:
        query: Query tensor [batch, heads, seq_q, head_dim]
        key: Key tensor [batch, heads, seq_k, head_dim]
        value: Value tensor [batch, heads, seq_k, head_dim]
        attn_mask: Optional attention mask [batch, heads, seq_q, seq_k]
        dropout_p: Dropout probability (not implemented in inference)
        is_causal: Whether to apply causal mask

    Returns:
        Attention output [batch, heads, seq_q, head_dim]

    Example:
        >>> out = scaled_dot_product_attention(q, k, v, is_causal=True)
    """
    # Compute attention scores
    head_dim = query.shape[-1]
    scale = 1.0 / mx.sqrt(float(head_dim))

    # Q @ K^T
    attn_scores = mx.matmul(query, mx.swapaxes(key, -2, -1)) * scale

    # Apply causal mask if needed
    if is_causal:
        seq_q, seq_k = query.shape[-2], key.shape[-2]
        causal_mask = mx.triu(
            mx.ones((seq_q, seq_k), dtype=mx.bool_),
            k=1,
        )
        attn_scores = mx.where(causal_mask, -1e9, attn_scores)

    # Apply attention mask
    if attn_mask is not None:
        attn_scores = attn_scores + attn_mask

    # Softmax
    attn_weights = mx.softmax(attn_scores, axis=-1)

    # Apply dropout (skip in inference)
    if dropout_p > 0.0 and not mx.is_training():
        # Dropout not typically used in inference
        pass

    # Weighted sum of values
    output = mx.matmul(attn_weights, value)

    return output


def get_model_config_dict(config: Any) -> dict[str, Any]:
    """
    Convert a config object to a dictionary.

    Args:
        config: Config object (dataclass, Pydantic model, or dict)

    Returns:
        Dictionary representation of config

    Example:
        >>> config_dict = get_model_config_dict(model_config)
    """
    if isinstance(config, dict):
        return config

    if hasattr(config, "dict"):
        # Pydantic model
        return config.dict()

    if hasattr(config, "__dict__"):
        # Dataclass or regular object
        return vars(config)

    raise ValueError(f"Cannot convert config of type {type(config)} to dict")
