# SPDX-License-Identifier: Apache-2.0
"""Online quantization for MLX models.

Implements runtime quantization for reducing memory usage and improving inference speed.
"""

from __future__ import annotations

import logging
from typing import Any

import mlx.core as mx
import mlx.nn as nn

logger = logging.getLogger(__name__)


class QuantizationConfig:
    """Configuration for quantization."""

    def __init__(
        self,
        bits: int = 4,
        group_size: int = 64,
        scheme: str = "symmetric",
    ) -> None:
        """
        Initialize quantization config.

        Args:
            bits: Number of bits (4 or 8).
            group_size: Group size for quantization.
            scheme: Quantization scheme ('symmetric' or 'asymmetric').
        """
        self.bits = bits
        self.group_size = group_size
        self.scheme = scheme

        if bits not in [4, 8]:
            raise ValueError(f"Unsupported bits: {bits}. Must be 4 or 8.")


def quantize_weight(
    weight: mx.array,
    bits: int = 4,
    group_size: int = 64,
) -> tuple[mx.array, mx.array, mx.array]:
    """
    Quantize a single weight tensor.

    Args:
        weight: Weight tensor to quantize [out_features, in_features].
        bits: Number of bits (4 or 8).
        group_size: Group size for quantization.

    Returns:
        Tuple of (quantized_weight, scales, zeros).
    """
    out_features, in_features = weight.shape

    # Reshape into groups
    num_groups = (in_features + group_size - 1) // group_size
    padded_in_features = num_groups * group_size

    # Pad if necessary
    if padded_in_features > in_features:
        padding = padded_in_features - in_features
        weight = mx.pad(weight, [(0, 0), (0, padding)])

    # Reshape to [out_features, num_groups, group_size]
    weight_grouped = weight.reshape(out_features, num_groups, group_size)

    # Compute min and max per group
    w_min = mx.min(weight_grouped, axis=2, keepdims=True)
    w_max = mx.max(weight_grouped, axis=2, keepdims=True)

    # Compute scale and zero point
    max_int = 2**bits - 1
    scales = (w_max - w_min) / max_int
    zeros = -w_min / scales

    # Quantize
    quantized = mx.round((weight_grouped - w_min) / scales)
    quantized = mx.clip(quantized, 0, max_int)

    # Convert to appropriate int type
    if bits == 4:
        # Pack two 4-bit values into one uint8
        quantized = quantized.astype(mx.uint8)
    else:
        quantized = quantized.astype(mx.uint8)

    # Reshape back
    quantized = quantized.reshape(out_features, padded_in_features)
    scales = scales.squeeze(2)  # [out_features, num_groups]
    zeros = zeros.squeeze(2)  # [out_features, num_groups]

    return quantized, scales, zeros


def dequantize_weight(
    quantized: mx.array,
    scales: mx.array,
    zeros: mx.array,
    bits: int = 4,
    group_size: int = 64,
    original_shape: tuple[int, int] | None = None,
) -> mx.array:
    """
    Dequantize a weight tensor.

    Args:
        quantized: Quantized weight.
        scales: Scales per group.
        zeros: Zero points per group.
        bits: Number of bits used.
        group_size: Group size.
        original_shape: Original weight shape (for unpadding).

    Returns:
        Dequantized weight.
    """
    out_features, padded_in_features = quantized.shape
    num_groups = padded_in_features // group_size

    # Reshape
    quantized_grouped = quantized.reshape(out_features, num_groups, group_size)
    scales_expanded = scales.reshape(out_features, num_groups, 1)
    zeros_expanded = zeros.reshape(out_features, num_groups, 1)

    # Dequantize
    dequantized = quantized_grouped.astype(mx.float32) * scales_expanded + (
        -zeros_expanded * scales_expanded
    )

    # Reshape back
    dequantized = dequantized.reshape(out_features, padded_in_features)

    # Unpad if necessary
    if original_shape is not None:
        _, in_features = original_shape
        dequantized = dequantized[:, :in_features]

    return dequantized


class QuantizedLinear(nn.Module):
    """Quantized linear layer."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        quantized_weight: mx.array,
        scales: mx.array,
        zeros: mx.array,
        bias: mx.array | None = None,
        bits: int = 4,
        group_size: int = 64,
    ) -> None:
        """
        Initialize quantized linear layer.

        Args:
            in_features: Input features.
            out_features: Output features.
            quantized_weight: Quantized weight.
            scales: Scales per group.
            zeros: Zero points per group.
            bias: Optional bias.
            bits: Number of bits.
            group_size: Group size.
        """
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.bits = bits
        self.group_size = group_size

        self.quantized_weight = quantized_weight
        self.scales = scales
        self.zeros = zeros
        self.bias = bias

    def __call__(self, x: mx.array) -> mx.array:
        """
        Forward pass.

        Args:
            x: Input tensor [..., in_features].

        Returns:
            Output tensor [..., out_features].
        """
        # Dequantize on the fly
        weight = dequantize_weight(
            self.quantized_weight,
            self.scales,
            self.zeros,
            bits=self.bits,
            group_size=self.group_size,
            original_shape=(self.out_features, self.in_features),
        )

        # Standard linear
        output = mx.matmul(x, weight.T)

        if self.bias is not None:
            output = output + self.bias

        return output


def quantize_linear_layer(
    layer: nn.Linear,
    config: QuantizationConfig,
) -> QuantizedLinear:
    """
    Quantize a linear layer.

    Args:
        layer: Linear layer to quantize.
        config: Quantization configuration.

    Returns:
        Quantized linear layer.
    """
    weight = layer.weight

    quantized_weight, scales, zeros = quantize_weight(
        weight,
        bits=config.bits,
        group_size=config.group_size,
    )

    bias = layer.bias if hasattr(layer, "bias") else None

    return QuantizedLinear(
        in_features=layer.weight.shape[1],
        out_features=layer.weight.shape[0],
        quantized_weight=quantized_weight,
        scales=scales,
        zeros=zeros,
        bias=bias,
        bits=config.bits,
        group_size=config.group_size,
    )


def quantize_model(
    model: nn.Module,
    config: QuantizationConfig,
    skip_modules: list[str] | None = None,
) -> nn.Module:
    """
    Quantize all linear layers in a model.

    Args:
        model: Model to quantize.
        config: Quantization configuration.
        skip_modules: Names of modules to skip.

    Returns:
        Quantized model.
    """
    if skip_modules is None:
        skip_modules = []

    logger.info(f"Quantizing model to {config.bits}-bit...")

    quantized_layers = 0

    def _quantize_recursive(module: nn.Module, prefix: str = "") -> None:
        nonlocal quantized_layers

        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name

            # Skip if in skip list
            if any(skip in full_name for skip in skip_modules):
                continue

            # Quantize linear layers
            if isinstance(child, nn.Linear):
                quantized = quantize_linear_layer(child, config)
                setattr(module, name, quantized)
                quantized_layers += 1
            else:
                # Recurse
                _quantize_recursive(child, full_name)

    _quantize_recursive(model)

    logger.info(f"Quantized {quantized_layers} layers")

    return model


def estimate_quantization_savings(
    model: nn.Module,
    config: QuantizationConfig,
) -> dict[str, Any]:
    """
    Estimate memory savings from quantization.

    Args:
        model: Model to analyze.
        config: Quantization configuration.

    Returns:
        Dict with memory statistics.
    """
    total_params = 0
    quantizable_params = 0

    for name, param in model.named_parameters():
        if isinstance(param, mx.array):
            total_params += param.size

            # Check if this is a linear layer weight
            if "weight" in name and param.ndim == 2:
                quantizable_params += param.size

    # Calculate sizes
    original_size = total_params * 4  # float32 = 4 bytes
    quantized_linear_size = (
        quantizable_params * config.bits // 8
    )  # Quantized weights
    non_quantized_size = (total_params - quantizable_params) * 4  # Other params
    final_size = quantized_linear_size + non_quantized_size

    # Add overhead for scales and zeros
    num_groups = (quantizable_params + config.group_size - 1) // config.group_size
    overhead = num_groups * 2 * 4  # 2 float32 values per group
    final_size += overhead

    return {
        "original_size_mb": original_size / (1024**2),
        "quantized_size_mb": final_size / (1024**2),
        "savings_mb": (original_size - final_size) / (1024**2),
        "compression_ratio": original_size / final_size,
        "total_params": total_params,
        "quantizable_params": quantizable_params,
    }
