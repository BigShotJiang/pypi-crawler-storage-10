# SPDX-License-Identifier: Apache-2.0
"""Default model loader for MLX-LLM."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

from mlxllm.model_executor.model_loader.base_loader import SafetensorsLoader

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig

logger = logging.getLogger(__name__)


class DefaultModelLoader(SafetensorsLoader):
    """
    Default model loader.

    Automatically detects model architecture and loads weights.
    Supports common architectures: Llama, Mistral, Qwen, etc.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        quantization: str | None = None,
    ) -> None:
        """
        Initialize default loader.

        Args:
            model_config: Model configuration.
            quantization: Quantization mode (q4, q8, or None).
        """
        super().__init__(model_config)
        self.quantization = quantization

    def create_model(self) -> nn.Module:
        """
        Create model based on architecture type.

        Returns:
            Model instance.
        """
        model_type = self._detect_model_type()

        logger.info(f"Creating model of type: {model_type}")

        # Import and create appropriate model
        if model_type in ["llama", "mistral"]:
            from mlxllm.model_executor.models.llama import LlamaForCausalLM

            return LlamaForCausalLM(self.model_config)

        elif model_type == "qwen2":
            from mlxllm.model_executor.models.qwen2 import Qwen2ForCausalLM

            return Qwen2ForCausalLM(self.model_config)

        elif model_type == "deepseek":
            from mlxllm.model_executor.models.deepseek import DeepSeekForCausalLM

            return DeepSeekForCausalLM(self.model_config)

        else:
            raise ValueError(f"Unsupported model type: {model_type}")

    def load_weights(self, model_path: str | Path) -> dict[str, mx.array]:
        """
        Load and optionally quantize weights.

        Args:
            model_path: Path to model.

        Returns:
            Weight dictionary.
        """
        # Load weights
        weights = super().load_weights(model_path)

        # Apply quantization if requested
        if self.quantization is not None:
            weights = self._quantize_weights(weights)

        return weights

    def _detect_model_type(self) -> str:
        """
        Detect model type from config.

        Returns:
            Model type string.
        """
        model_name = self.model_config.model_name.lower()

        if "llama" in model_name:
            return "llama"
        elif "mistral" in model_name:
            return "mistral"
        elif "qwen" in model_name:
            return "qwen2"
        elif "deepseek" in model_name:
            return "deepseek"
        else:
            # Default to llama architecture
            logger.warning(
                f"Unknown model type for {model_name}, defaulting to llama"
            )
            return "llama"

    def _quantize_weights(self, weights: dict[str, mx.array]) -> dict[str, mx.array]:
        """
        Quantize weights.

        Args:
            weights: Full precision weights.

        Returns:
            Quantized weights.
        """
        from mlxllm.model_executor.model_loader.weight_utils import quantize_weights

        # Parse quantization config
        bits = 4 if self.quantization == "q4" else 8
        group_size = 64

        logger.info(f"Quantizing weights to {bits}-bit")

        return quantize_weights(weights, bits=bits, group_size=group_size)
