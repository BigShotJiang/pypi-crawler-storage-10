# SPDX-License-Identifier: Apache-2.0
"""Model loader module for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.nn as nn

from mlxllm.model_executor.model_loader.default_loader import DefaultModelLoader

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig

__all__ = [
    "DefaultModelLoader",
    "load_model",
]


def load_model(
    model_config: ModelConfig,
    quantization: str | None = None,
) -> nn.Module:
    """
    Convenience function to load a model.

    Args:
        model_config: Model configuration.
        quantization: Optional quantization mode (q4, q8).

    Returns:
        Loaded model instance.
    """
    loader = DefaultModelLoader(
        model_config=model_config,
        quantization=quantization,
    )

    model = loader.create_model()

    # Load weights if model path is specified
    if hasattr(model_config, "model_path") and model_config.model_path:
        weights = loader.load_weights(model_config.model_path)
        model.load_weights(list(weights.items()))

    return model
