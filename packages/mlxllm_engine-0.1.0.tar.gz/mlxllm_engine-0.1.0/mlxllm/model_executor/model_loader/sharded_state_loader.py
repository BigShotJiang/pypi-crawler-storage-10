# SPDX-License-Identifier: Apache-2.0
"""Sharded state loader for large models.

Loads models that are split across multiple files (sharded checkpoints).
"""

from __future__ import annotations

import logging
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn

from mlxllm.model_executor.model_loader.base_loader import SafetensorsLoader

logger = logging.getLogger(__name__)


class ShardedStateLoader(SafetensorsLoader):
    """
    Loader for sharded model checkpoints.

    Handles models split across multiple files:
    - model-00001-of-00005.safetensors
    - model-00002-of-00005.safetensors
    - etc.
    """

    def load_weights(self, model_path: str | Path) -> dict[str, mx.array]:
        """
        Load weights from sharded checkpoint.

        Args:
            model_path: Path to model directory containing shards.

        Returns:
            Combined weight dictionary.
        """
        model_path = Path(model_path)

        if not model_path.is_dir():
            raise ValueError(f"Expected directory for sharded model, got {model_path}")

        # Find all shard files
        shard_files = sorted(model_path.glob("model-*.safetensors"))

        if not shard_files:
            # Try alternative patterns
            shard_files = sorted(model_path.glob("*.safetensors"))

        if not shard_files:
            raise ValueError(f"No shard files found in {model_path}")

        logger.info(f"Found {len(shard_files)} shard files")

        # Load and combine shards
        combined_weights = {}

        for shard_file in shard_files:
            logger.info(f"Loading shard: {shard_file.name}")

            # Load this shard
            shard_weights = super().load_weights(shard_file)

            # Merge into combined weights
            combined_weights.update(shard_weights)

        logger.info(f"Loaded {len(combined_weights)} parameters from {len(shard_files)} shards")

        return combined_weights

    def create_model(self) -> nn.Module:
        """Create model - delegated to default loader."""
        from mlxllm.model_executor.model_loader.default_loader import DefaultModelLoader

        loader = DefaultModelLoader(self.model_config)
        return loader.create_model()
