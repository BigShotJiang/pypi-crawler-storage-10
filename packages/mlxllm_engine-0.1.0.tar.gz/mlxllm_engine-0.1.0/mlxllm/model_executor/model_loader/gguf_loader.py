# SPDX-License-Identifier: Apache-2.0
"""GGUF model loader for MLX-LLM.

GGUF is the file format used by llama.cpp. This loader provides
support for loading GGUF-quantized models.
"""

from __future__ import annotations

import logging
from pathlib import Path

import mlx.core as mx
import mlx.nn as nn

from mlxllm.model_executor.model_loader.base_loader import BaseModelLoader

logger = logging.getLogger(__name__)


class GGUFLoader(BaseModelLoader):
    """
    Loader for GGUF format models.

    GGUF supports various quantization schemes (Q4_0, Q4_1, Q5_0, Q5_1, Q8_0, etc.).
    """

    def load_weights(self, model_path: str | Path) -> dict[str, mx.array]:
        """
        Load weights from GGUF file.

        Args:
            model_path: Path to .gguf file.

        Returns:
            Dictionary of weights.

        Raises:
            NotImplementedError: GGUF loading not yet fully implemented.
        """
        model_path = Path(model_path)

        if not model_path.suffix == ".gguf":
            raise ValueError(f"Expected .gguf file, got {model_path.suffix}")

        logger.warning(
            "GGUF loading is not fully implemented yet. "
            "Please convert GGUF models to safetensors format."
        )

        raise NotImplementedError(
            "GGUF loading is planned for future release. "
            "For now, please use safetensors format."
        )

    def create_model(self) -> nn.Module:
        """Create model - delegated to architecture-specific loader."""
        from mlxllm.model_executor.model_loader.default_loader import DefaultModelLoader

        loader = DefaultModelLoader(self.model_config)
        return loader.create_model()
