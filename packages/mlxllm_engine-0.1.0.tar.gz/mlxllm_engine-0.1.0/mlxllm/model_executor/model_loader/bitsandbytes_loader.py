# SPDX-License-Identifier: Apache-2.0
"""BitsAndBytes quantization loader for MLX-LLM.

Note: BitsAndBytes is CUDA-specific. For MLX on Apple Silicon,
use MLX's native quantization instead.

This is a placeholder for cross-platform compatibility.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def load_bitsandbytes_model(*args, **kwargs):
    """
    Placeholder for BitsAndBytes model loading.

    BitsAndBytes requires CUDA and is not supported on Apple Silicon.
    Use MLX quantization instead.

    Raises:
        NotImplementedError: BitsAndBytes not supported on MLX.
    """
    raise NotImplementedError(
        "BitsAndBytes quantization is not supported on MLX (Apple Silicon). "
        "Please use MLX's native quantization (q4, q8) instead."
    )
