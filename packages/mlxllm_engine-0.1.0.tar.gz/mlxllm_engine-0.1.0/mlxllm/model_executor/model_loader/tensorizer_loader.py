# SPDX-License-Identifier: Apache-2.0
"""Tensorizer loader for fast model loading.

Tensorizer is a fast serialization format for PyTorch tensors.
For MLX, we use native formats (safetensors, MLX arrays).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def load_tensorizer_model(*args, **kwargs):
    """
    Placeholder for Tensorizer model loading.

    Tensorizer is primarily for PyTorch. For MLX, use safetensors instead.

    Raises:
        NotImplementedError: Tensorizer not supported on MLX.
    """
    raise NotImplementedError(
        "Tensorizer is not supported on MLX. "
        "Please use safetensors format for fast loading."
    )
