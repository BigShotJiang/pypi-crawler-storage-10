# SPDX-License-Identifier: Apache-2.0
"""Base model loader for MLX-LLM."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig

logger = logging.getLogger(__name__)


class BaseModelLoader(ABC):
    """
    Abstract base class for model loaders.

    Handles loading model weights and creating model instances.
    """

    def __init__(self, model_config: ModelConfig) -> None:
        """
        Initialize model loader.

        Args:
            model_config: Model configuration.
        """
        self.model_config = model_config

    @abstractmethod
    def load_weights(self, model_path: str | Path) -> dict[str, mx.array]:
        """
        Load model weights from disk.

        Args:
            model_path: Path to model directory or file.

        Returns:
            Dictionary mapping parameter names to arrays.
        """
        pass

    @abstractmethod
    def create_model(self) -> nn.Module:
        """
        Create model instance.

        Returns:
            Model module.
        """
        pass

    def load_model(self, model_path: str | Path) -> nn.Module:
        """
        Load complete model (weights + architecture).

        Args:
            model_path: Path to model.

        Returns:
            Loaded model.
        """
        logger.info(f"Loading model from {model_path}")

        # Create model architecture
        model = self.create_model()

        # Load weights
        weights = self.load_weights(model_path)

        # Apply weights to model
        model = self._apply_weights(model, weights)

        logger.info(f"Successfully loaded model from {model_path}")
        return model

    def _apply_weights(
        self,
        model: nn.Module,
        weights: dict[str, mx.array],
    ) -> nn.Module:
        """
        Apply loaded weights to model.

        Args:
            model: Model instance.
            weights: Weight dictionary.

        Returns:
            Model with loaded weights.
        """
        # Update model parameters
        model.update(weights)
        return model

    def get_memory_footprint(self, weights: dict[str, mx.array]) -> int:
        """
        Calculate memory footprint of weights.

        Args:
            weights: Weight dictionary.

        Returns:
            Memory size in bytes.
        """
        total_bytes = 0

        for weight in weights.values():
            num_elements = 1
            for dim in weight.shape:
                num_elements *= dim
            total_bytes += num_elements * weight.itemsize

        return total_bytes


class SafetensorsLoader(BaseModelLoader):
    """Loader for safetensors format."""

    def load_weights(self, model_path: str | Path) -> dict[str, mx.array]:
        """Load weights from safetensors."""
        from mlxllm.model_executor.model_loader.weight_utils import (
            load_safetensors_weights,
        )

        return load_safetensors_weights(model_path)

    def create_model(self) -> nn.Module:
        """Create model - to be implemented by subclasses."""
        raise NotImplementedError(
            "SafetensorsLoader.create_model() must be implemented by subclass"
        )
