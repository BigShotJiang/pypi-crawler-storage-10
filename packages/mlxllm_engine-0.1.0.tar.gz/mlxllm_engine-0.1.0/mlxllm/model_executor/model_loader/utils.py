# SPDX-License-Identifier: Apache-2.0
"""Utility functions for model loading."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import mlx.core as mx
import mlx.nn as nn

logger = logging.getLogger(__name__)


def filter_weights(
    weights: dict[str, Any],
    prefix: str | None = None,
    remove_prefix: bool = True,
) -> dict[str, Any]:
    """
    Filter weights by prefix.

    Args:
        weights: Weight dictionary.
        prefix: Prefix to filter by.
        remove_prefix: Whether to remove the prefix from keys.

    Returns:
        Filtered weight dictionary.
    """
    if prefix is None:
        return weights

    filtered = {}
    for key, value in weights.items():
        if key.startswith(prefix):
            new_key = key[len(prefix) :] if remove_prefix else key
            filtered[new_key] = value

    return filtered


def download_from_hub(
    model_name: str,
    cache_dir: str | Path | None = None,
) -> Path:
    """
    Download model from HuggingFace Hub.

    Args:
        model_name: HuggingFace model identifier.
        cache_dir: Optional cache directory.

    Returns:
        Path to downloaded model.
    """
    try:
        from huggingface_hub import snapshot_download

        logger.info(f"Downloading model from HuggingFace Hub: {model_name}")

        path = snapshot_download(
            repo_id=model_name,
            cache_dir=cache_dir,
            allow_patterns=["*.safetensors", "*.json", "tokenizer.model"],
        )

        logger.info(f"Model downloaded to: {path}")
        return Path(path)

    except ImportError:
        raise ImportError(
            "huggingface_hub is required for downloading models. "
            "Install with: pip install huggingface_hub"
        )


def init_empty_weights(model: nn.Module) -> None:
    """
    Initialize model with empty weights (for lazy loading).

    Args:
        model: Model to initialize.
    """
    for name, param in model.named_parameters():
        if isinstance(param, mx.array):
            # Replace with empty array of same shape
            setattr(model, name, mx.zeros_like(param))


def get_model_memory_footprint(weights: dict[str, mx.array]) -> int:
    """
    Calculate total memory footprint of model weights.

    Args:
        weights: Weight dictionary.

    Returns:
        Memory usage in bytes.
    """
    total_bytes = 0
    for weight in weights.values():
        # Check if weight has nbytes attribute (MLX arrays have this)
        if hasattr(weight, 'nbytes'):
            total_bytes += weight.nbytes

    return total_bytes


def format_memory_size(bytes: int) -> str:
    """
    Format memory size for display.

    Args:
        bytes: Size in bytes.

    Returns:
        Formatted string (e.g., "1.5 GB").
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if bytes < 1024:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024
    return f"{bytes:.2f} PB"


def verify_model_weights(
    model: nn.Module,
    weights: dict[str, mx.array],
) -> tuple[list[str], list[str]]:
    """
    Verify that model weights match expected parameters.

    Args:
        model: Model instance.
        weights: Weight dictionary.

    Returns:
        Tuple of (missing_keys, unexpected_keys).
    """
    model_params = {name for name, _ in model.named_parameters()}
    weight_keys = set(weights.keys())

    missing_keys = list(model_params - weight_keys)
    unexpected_keys = list(weight_keys - model_params)

    if missing_keys:
        logger.warning(f"Missing keys in weights: {missing_keys}")
    if unexpected_keys:
        logger.warning(f"Unexpected keys in weights: {unexpected_keys}")

    return missing_keys, unexpected_keys


def convert_dtype(
    weights: dict[str, mx.array],
    target_dtype: mx.Dtype,
) -> dict[str, mx.array]:
    """
    Convert all weights to target dtype.

    Args:
        weights: Weight dictionary.
        target_dtype: Target dtype (e.g., mx.float16).

    Returns:
        Converted weight dictionary.
    """
    converted = {}
    for key, weight in weights.items():
        if isinstance(weight, mx.array):
            converted[key] = weight.astype(target_dtype)
        else:
            converted[key] = weight

    return converted


def split_weights_by_device(
    weights: dict[str, mx.array],
    num_devices: int = 1,
) -> list[dict[str, mx.array]]:
    """
    Split weights across multiple devices (for distributed inference).

    Args:
        weights: Weight dictionary.
        num_devices: Number of devices to split across.

    Returns:
        List of weight dictionaries per device.
    """
    if num_devices == 1:
        return [weights]

    # Simple round-robin splitting
    device_weights = [{} for _ in range(num_devices)]

    for i, (key, weight) in enumerate(weights.items()):
        device_idx = i % num_devices
        device_weights[device_idx][key] = weight

    return device_weights


def load_checkpoint_sharded(
    checkpoint_dir: str | Path,
    pattern: str = "*.safetensors",
) -> dict[str, mx.array]:
    """
    Load sharded checkpoint from directory.

    Args:
        checkpoint_dir: Directory containing sharded checkpoint files.
        pattern: File pattern to match.

    Returns:
        Combined weight dictionary.
    """
    checkpoint_dir = Path(checkpoint_dir)
    checkpoint_files = sorted(checkpoint_dir.glob(pattern))

    if not checkpoint_files:
        raise FileNotFoundError(
            f"No checkpoint files found in {checkpoint_dir} matching {pattern}"
        )

    logger.info(f"Loading {len(checkpoint_files)} checkpoint shards...")

    combined_weights = {}

    for checkpoint_file in checkpoint_files:
        logger.debug(f"Loading shard: {checkpoint_file}")
        # Load using mx.load (assumes safetensors format)
        shard_weights = mx.load(str(checkpoint_file))
        combined_weights.update(shard_weights)

    logger.info(f"Loaded {len(combined_weights)} parameters from shards")

    return combined_weights
