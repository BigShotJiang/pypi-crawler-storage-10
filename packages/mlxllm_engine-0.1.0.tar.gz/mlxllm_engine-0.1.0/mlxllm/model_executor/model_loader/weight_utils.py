# SPDX-License-Identifier: Apache-2.0
"""Weight utilities for model loading in MLX-LLM."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def dequantize_mlx_weights(weights: dict[str, mx.array]) -> dict[str, mx.array]:
    """
    Dequantize MLX quantized weights to FP16.

    MLX quantized weights have format:
    - weight: uint32 packed bits
    - scales: float16 scaling factors
    - biases: float16 bias values

    This converts them back to regular float16 weights.

    Args:
        weights: Dictionary with quantized weights.

    Returns:
        Dictionary with dequantized float16 weights.
    """
    dequantized = {}
    processed_keys = set()

    for key in weights.keys():
        # Skip if already processed as part of a quantized group
        if key in processed_keys:
            continue

        # Check if this is a quantized weight
        if key.endswith('.weight') and f"{key.rsplit('.weight', 1)[0]}.scales" in weights:
            base_name = key.rsplit('.weight', 1)[0]
            weight_key = f"{base_name}.weight"
            scales_key = f"{base_name}.scales"
            biases_key = f"{base_name}.biases"

            if weight_key in weights and scales_key in weights and biases_key in weights:
                # This is a quantized weight - dequantize it
                w_quant = weights[weight_key]
                scales = weights[scales_key]
                biases = weights[biases_key]

                # Dequantize using MLX's built-in dequantize
                try:
                    w_float = mx.dequantize(w_quant, scales, biases, group_size=64, bits=4)
                    dequantized[f"{base_name}.weight"] = w_float

                    # Mark these keys as processed
                    processed_keys.add(weight_key)
                    processed_keys.add(scales_key)
                    processed_keys.add(biases_key)

                    logger.debug(f"Dequantized {base_name}.weight: {w_quant.shape} -> {w_float.shape}")
                except Exception as e:
                    logger.warning(f"Failed to dequantize {base_name}: {e}, keeping original")
                    dequantized[key] = weights[key]
                    processed_keys.add(key)
            else:
                # Missing some quantization components, keep as-is
                dequantized[key] = weights[key]
                processed_keys.add(key)
        else:
            # Not a quantized weight (e.g., layernorm, embeddings) - keep as-is
            if not any(key.endswith(suffix) for suffix in ['.scales', '.biases']):
                dequantized[key] = weights[key]
            processed_keys.add(key)

    logger.info(f"Dequantized weights: {len(weights)} -> {len(dequantized)} parameters")
    return dequantized


def fuse_qkv_weights(weights: dict[str, mx.array]) -> dict[str, mx.array]:
    """
    Fuse separate Q/K/V projection weights into a single qkv_proj weight.

    Some models (like Qwen2.5) use separate q_proj, k_proj, v_proj,
    but our Attention layer uses a fused qkv_proj.

    Args:
        weights: Dictionary with separate Q/K/V weights.

    Returns:
        Dictionary with fused qkv_proj weights.
    """
    fused = {}
    processed_keys = set()

    # Sort keys to ensure we process q_proj before k_proj and v_proj
    for key in sorted(weights.keys()):
        if key in processed_keys:
            continue

        # Skip K, V, and Q bias/weight projections - they'll all be fused when we encounter Q weight
        if any(pattern in key for pattern in [".self_attn.k_proj.", ".self_attn.v_proj.", ".self_attn.q_proj.bias"]):
            continue

        # Check if this is a Q weight projection that triggers fusion
        if ".self_attn.q_proj.weight" in key:
            base_name = key.replace(".self_attn.q_proj.weight", "")
            q_key = f"{base_name}.self_attn.q_proj.weight"
            k_key = f"{base_name}.self_attn.k_proj.weight"
            v_key = f"{base_name}.self_attn.v_proj.weight"

            # Check if all three exist
            if q_key in weights and k_key in weights and v_key in weights:
                q_weight = weights[q_key]
                k_weight = weights[k_key]
                v_weight = weights[v_key]

                # Fuse: [q_size, hidden] + [k_size, hidden] + [v_size, hidden]
                # -> [q_size + k_size + v_size, hidden]
                qkv_weight = mx.concatenate([q_weight, k_weight, v_weight], axis=0)
                fused[f"{base_name}.self_attn.qkv_proj.weight"] = qkv_weight

                # Mark as processed
                processed_keys.add(q_key)
                processed_keys.add(k_key)
                processed_keys.add(v_key)

                logger.debug(f"Fused QKV for {base_name}: {q_weight.shape} + {k_weight.shape} + {v_weight.shape} -> {qkv_weight.shape}")

                # Handle biases if they exist
                q_bias_key = f"{base_name}.self_attn.q_proj.bias"
                k_bias_key = f"{base_name}.self_attn.k_proj.bias"
                v_bias_key = f"{base_name}.self_attn.v_proj.bias"

                if q_bias_key in weights and k_bias_key in weights and v_bias_key in weights:
                    q_bias = weights[q_bias_key]
                    k_bias = weights[k_bias_key]
                    v_bias = weights[v_bias_key]

                    qkv_bias = mx.concatenate([q_bias, k_bias, v_bias], axis=0)
                    fused[f"{base_name}.self_attn.qkv_proj.bias"] = qkv_bias

                    processed_keys.add(q_bias_key)
                    processed_keys.add(k_bias_key)
                    processed_keys.add(v_bias_key)
            else:
                # Missing some components, keep as-is
                fused[key] = weights[key]
                processed_keys.add(key)
        else:
            # Not a Q/K/V weight, keep as-is
            fused[key] = weights[key]
            processed_keys.add(key)

    logger.info(f"Fused QKV weights: {len(weights)} -> {len(fused)} parameters")
    return fused


def fuse_gate_up_weights(weights: dict[str, mx.array]) -> dict[str, mx.array]:
    """
    Fuse separate gate_proj + up_proj weights into gate_up_proj.

    Some models (like Qwen2.5) use separate gate_proj and up_proj,
    but our LlamaMLP uses a fused gate_up_proj.

    Args:
        weights: Dictionary with separate gate/up weights.

    Returns:
        Dictionary with fused gate_up_proj weights.
    """
    fused = {}
    processed_keys = set()

    # Sort keys to ensure consistent processing
    for key in sorted(weights.keys()):
        if key in processed_keys:
            continue

        # Skip up_proj - it will be fused when we encounter gate_proj
        if ".mlp.up_proj." in key:
            continue

        # Check if this is a gate projection that can be fused
        if ".mlp.gate_proj.weight" in key:
            base_name = key.replace(".mlp.gate_proj.weight", "")
            gate_key = f"{base_name}.mlp.gate_proj.weight"
            up_key = f"{base_name}.mlp.up_proj.weight"

            # Check if both exist
            if gate_key in weights and up_key in weights:
                gate_weight = weights[gate_key]
                up_weight = weights[up_key]

                # Fuse: [gate_size, hidden] + [up_size, hidden]
                # -> [gate_size + up_size, hidden]
                gate_up_weight = mx.concatenate([gate_weight, up_weight], axis=0)
                # Note: ColumnParallelLinear has nested structure: gate_up_proj.linear.linear.weight
                fused[f"{base_name}.mlp.gate_up_proj.linear.linear.weight"] = gate_up_weight

                # Mark as processed
                processed_keys.add(gate_key)
                processed_keys.add(up_key)

                logger.debug(f"Fused gate/up for {base_name}: {gate_weight.shape} + {up_weight.shape} -> {gate_up_weight.shape}")
            else:
                # Missing up_proj, keep as-is
                fused[key] = weights[key]
                processed_keys.add(key)
        else:
            # Not a gate/up weight, keep as-is
            fused[key] = weights[key]
            processed_keys.add(key)

    logger.info(f"Fused gate/up weights: {len(weights)} -> {len(fused)} parameters")
    return fused


def fix_mlp_down_proj_paths(weights: dict[str, mx.array]) -> dict[str, mx.array]:
    """
    Fix down_proj weight paths to match RowParallelLinear nested structure.

    RowParallelLinear wraps UnquantizedLinear which wraps nn.Linear, so the
    actual parameter path is down_proj.linear.linear.weight not just down_proj.weight.

    Args:
        weights: Dictionary with down_proj weights.

    Returns:
        Dictionary with corrected down_proj paths.
    """
    fixed = {}

    for key, value in weights.items():
        # Fix down_proj.weight -> down_proj.linear.linear.weight
        if ".mlp.down_proj.weight" in key:
            base_name = key.replace(".mlp.down_proj.weight", "")
            fixed_key = f"{base_name}.mlp.down_proj.linear.linear.weight"
            fixed[fixed_key] = value
            logger.debug(f"Fixed down_proj path: {key} -> {fixed_key}")
        else:
            # Keep as-is
            fixed[key] = value

    logger.info(f"Fixed down_proj paths: {len(weights)} parameters")
    return fixed


def load_safetensors_weights(
    model_path: str | Path,
    dequantize: bool = True,
) -> dict[str, mx.array]:
    """
    Load weights from safetensors format.

    Args:
        model_path: Path to model directory or .safetensors file.
        dequantize: Whether to dequantize MLX quantized weights to FP16.

    Returns:
        Dictionary mapping parameter names to arrays.
    """
    model_path = Path(model_path)

    # Find safetensors files
    if model_path.is_file():
        safetensors_files = [model_path]
    else:
        safetensors_files = sorted(model_path.glob("*.safetensors"))
        # Filter out index files
        safetensors_files = [f for f in safetensors_files if 'index' not in f.name]

    if not safetensors_files:
        raise FileNotFoundError(f"No .safetensors files found in {model_path}")

    # Use MLX's built-in loader which handles safetensors natively
    if len(safetensors_files) == 1:
        logger.info(f"Loading weights from {safetensors_files[0]}")
        weights = mx.load(str(safetensors_files[0]))
    else:
        # Multiple files - load and merge
        weights = {}
        for file_path in safetensors_files:
            logger.info(f"Loading weights from {file_path}")
            file_weights = mx.load(str(file_path))
            weights.update(file_weights)

    logger.info(f"Loaded {len(weights)} weight tensors")

    # Dequantize if requested and quantized weights detected
    has_quantized = any('scales' in k or 'biases' in k for k in weights.keys())
    if dequantize and has_quantized:
        logger.info("Detected quantized weights, dequantizing to FP16...")
        weights = dequantize_mlx_weights(weights)

    # Fuse Q/K/V weights if they're separate
    has_separate_qkv = any('.q_proj.weight' in k for k in weights.keys())
    if has_separate_qkv:
        logger.info("Detected separate Q/K/V projections, fusing into qkv_proj...")
        weights = fuse_qkv_weights(weights)

    # Fuse gate/up weights if they're separate
    has_separate_gate_up = any('.gate_proj.weight' in k for k in weights.keys())
    if has_separate_gate_up:
        logger.info("Detected separate gate/up projections, fusing into gate_up_proj...")
        weights = fuse_gate_up_weights(weights)

    # Fix down_proj paths to match RowParallelLinear nested structure
    has_down_proj = any('.mlp.down_proj.weight' in k for k in weights.keys())
    if has_down_proj:
        logger.info("Fixing down_proj paths to match RowParallelLinear structure...")
        weights = fix_mlp_down_proj_paths(weights)

    return weights


def load_weights_auto(
    model_path: str | Path,
) -> dict[str, mx.array]:
    """
    Auto-detect and load weights.

    Args:
        model_path: Path to model directory or file.

    Returns:
        Dictionary mapping parameter names to arrays.
    """
    model_path = Path(model_path)

    # Try safetensors first
    if model_path.is_file():
        if model_path.suffix == ".safetensors":
            return load_safetensors_weights(model_path)
    else:
        # Directory: prefer safetensors
        if any(model_path.glob("*.safetensors")):
            return load_safetensors_weights(model_path)

    raise ValueError(f"No supported weight files found in {model_path}")


def quantize_weights(
    weights: dict[str, mx.array],
    bits: int = 4,
    group_size: int = 64,
) -> dict[str, Any]:
    """
    Quantize weights to lower precision.

    Args:
        weights: Float weights.
        bits: Target bits (4 or 8).
        group_size: Quantization group size.

    Returns:
        Quantized weights dictionary.
    """
    logger.info(f"Quantizing weights to {bits}-bit with group_size={group_size}")

    quantized_weights = {}

    for name, weight in weights.items():
        # Only quantize linear layer weights (2D tensors)
        if len(weight.shape) == 2 and "weight" in name:
            # Use MLX quantization
            quantized = nn.quantize(weight, bits=bits, group_size=group_size)
            quantized_weights[name] = quantized
            logger.debug(f"Quantized {name}: {weight.shape} -> {bits}-bit")
        else:
            # Keep as-is for non-linear weights (embeddings, norms, etc.)
            quantized_weights[name] = weight

    return quantized_weights


def get_weight_memory_size(
    weights: dict[str, mx.array],
) -> int:
    """
    Calculate total memory size of weights in bytes.

    Args:
        weights: Weight dictionary.

    Returns:
        Total size in bytes.
    """
    total_bytes = 0

    for weight in weights.values():
        # Calculate size: num_elements * bytes_per_element
        num_elements = 1
        for dim in weight.shape:
            num_elements *= dim

        # Get dtype size
        dtype_size = weight.itemsize

        total_bytes += num_elements * dtype_size

    return total_bytes
