# SPDX-License-Identifier: Apache-2.0
"""Worker for model execution.

The worker coordinates:
- Model executor
- KV cache manager
- Tokenizer
- Batch processing
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

# Import at module level so they can be patched in tests
from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.model_executor.executor import ModelExecutor
from mlxllm.tokenization import Tokenizer

if TYPE_CHECKING:
    from mlxllm.config.cache import CacheConfig
    from mlxllm.config.model import ModelConfig
    from mlxllm.sequence import SequenceGroup

logger = logging.getLogger(__name__)


class Worker:
    """
    Worker that coordinates model execution components.

    The worker manages:
    - Model executor initialization
    - KV cache manager
    - Batch execution
    """

    def __init__(
        self,
        model_config: ModelConfig,
        cache_config: CacheConfig,
    ) -> None:
        """
        Initialize worker.

        Args:
            model_config: Model configuration.
            cache_config: KV cache configuration.
        """
        self.model_config = model_config
        self.cache_config = cache_config

        logger.info("Initializing worker components...")

        # Initialize tokenizer
        self.tokenizer = Tokenizer.from_pretrained(
            model_config.model_name,
        )

        # Initialize KV cache manager
        self.kv_cache_manager = KVCacheManager(
            num_layers=model_config.num_hidden_layers,
            num_heads=model_config.num_attention_heads,
            head_dim=model_config.hidden_size // model_config.num_attention_heads,
            block_size=cache_config.block_size,
            num_gpu_blocks=cache_config.num_gpu_blocks,
            dtype=model_config.dtype,
        )

        # Initialize model executor
        self.executor = ModelExecutor(
            model_config=model_config,
            kv_cache_manager=self.kv_cache_manager,
            tokenizer=self.tokenizer,
        )

        logger.info("Worker initialized successfully")

    def execute_batch(
        self,
        sequence_groups: list[SequenceGroup],
        is_prefill: bool,
    ) -> dict[str, Any]:
        """
        Execute a batch of sequences.

        Args:
            sequence_groups: Sequence groups to execute.
            is_prefill: Whether this is prefill phase.

        Returns:
            Dict with execution results:
                - logits: Generated logits
                - sampled_tokens: Sampled tokens
        """
        # Execute forward pass
        if is_prefill:
            results = self.executor.execute_prefill(sequence_groups)
        else:
            results = self.executor.execute_decode(sequence_groups)

        # Sample tokens
        sampled_tokens = self.executor.sample_tokens(
            logits=results["logits"],
            sequence_groups=sequence_groups,
        )

        return {
            "logits": results["logits"],
            "sampled_tokens": sampled_tokens,
        }

    def load_model(self) -> None:
        """Load the model."""
        self.executor.load_model()

    def get_stats(self) -> dict[str, Any]:
        """
        Get worker statistics.

        Returns:
            Dict with stats from executor and KV cache.
        """
        return {
            "executor": self.executor.get_stats(),
            "kv_cache": {
                "num_blocks": self.kv_cache_manager.num_blocks,
                "num_free_blocks": len(self.kv_cache_manager.free_blocks),
            },
        }
