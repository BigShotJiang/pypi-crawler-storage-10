# SPDX-License-Identifier: Apache-2.0
"""
Model parameter utilities and management.

This module provides utilities for managing model parameters, including
parameter freezing, initialization, and statistics.
"""

from __future__ import annotations

from typing import Any

import mlx.core as mx
import mlx.nn as nn


__all__ = [
    "count_parameters",
    "freeze_parameters",
    "unfreeze_parameters",
    "get_parameter_dtype",
    "get_parameter_stats",
]


def count_parameters(
    module: nn.Module,
    trainable_only: bool = False,
) -> int:
    """
    Count the number of parameters in a module.

    Args:
        module: Module to count parameters for
        trainable_only: If True, only count trainable parameters

    Returns:
        Total number of parameters

    Example:
        >>> model = LlamaForCausalLM(config)
        >>> total_params = count_parameters(model)
        >>> print(f"Total parameters: {total_params:,}")
    """
    total = 0

    # Get all parameters
    params = module.parameters()

    for _, param in params.items():
        # Skip non-trainable if requested
        if trainable_only and hasattr(param, 'requires_grad') and not param.requires_grad:
            continue

        # Count elements - MLX arrays have .size as total element count
        if isinstance(param, mx.array):
            total += param.size
        elif isinstance(param, dict):
            # Handle nested dicts (like in some model structures)
            for v in param.values():
                if isinstance(v, mx.array):
                    total += v.size
        else:
            # Fallback: compute from shape
            size = 1
            for dim in param.shape:
                size *= dim
            total += size

    return total


def freeze_parameters(module: nn.Module) -> None:
    """
    Freeze all parameters in a module (disable gradients).

    Args:
        module: Module to freeze

    Example:
        >>> # Freeze embedding layer
        >>> freeze_parameters(model.embed_tokens)
    """
    params = module.parameters()

    for _, param in params.items():
        # MLX doesn't have requires_grad, but we can mark it
        # This is a placeholder for future gradient handling
        if hasattr(param, "requires_grad"):
            param.requires_grad = False


def unfreeze_parameters(module: nn.Module) -> None:
    """
    Unfreeze all parameters in a module (enable gradients).

    Args:
        module: Module to unfreeze

    Example:
        >>> # Unfreeze all parameters for fine-tuning
        >>> unfreeze_parameters(model)
    """
    params = module.parameters()

    for _, param in params.items():
        # MLX doesn't have requires_grad, but we can mark it
        if hasattr(param, "requires_grad"):
            param.requires_grad = True


def get_parameter_dtype(module: nn.Module) -> str:
    """
    Get the dtype of parameters in a module.

    Args:
        module: Module to check

    Returns:
        String representation of dtype (e.g., "float32", "float16")

    Example:
        >>> dtype = get_parameter_dtype(model)
        >>> print(f"Model dtype: {dtype}")
    """
    params = module.parameters()

    # Get first parameter's dtype
    for _, param in params.items():
        if isinstance(param, mx.array):
            dtype_str = str(param.dtype)
            # Remove mlx.core. prefix if present
            return dtype_str.replace("mlx.core.", "")
        elif isinstance(param, dict):
            # Handle nested dicts
            for v in param.values():
                if isinstance(v, mx.array):
                    dtype_str = str(v.dtype)
                    return dtype_str.replace("mlx.core.", "")
        elif hasattr(param, 'dtype'):
            dtype_str = str(param.dtype)
            return dtype_str.replace("mlx.core.", "")

    return "unknown"


def get_parameter_stats(module: nn.Module) -> dict[str, Any]:
    """
    Get statistics about parameters in a module.

    Args:
        module: Module to analyze

    Returns:
        Dictionary with parameter statistics:
        - total_params: Total number of parameters
        - total_size_mb: Total size in megabytes
        - dtype: Parameter dtype
        - param_shapes: Dictionary of parameter names to shapes

    Example:
        >>> stats = get_parameter_stats(model)
        >>> print(f"Model size: {stats['total_size_mb']:.2f} MB")
        >>> print(f"Total params: {stats['total_params']:,}")
    """
    params = module.parameters()

    total_params = 0
    total_bytes = 0
    param_shapes = {}
    dtype = None

    for param_name, param in params.items():
        # Count parameters
        if isinstance(param, mx.array):
            num_params = param.size
            param_dtype = str(param.dtype)
            param_shape = list(param.shape)
        elif isinstance(param, dict):
            # Handle nested dicts - sum all arrays
            num_params = 0
            param_shape = []
            param_dtype = None
            for v in param.values():
                if isinstance(v, mx.array):
                    num_params += v.size
                    if param_dtype is None:
                        param_dtype = str(v.dtype)
                    param_shape.append(list(v.shape))
        else:
            # Fallback
            num_params = 1
            for dim in param.shape:
                num_params *= dim
            param_dtype = str(param.dtype) if hasattr(param, 'dtype') else 'unknown'
            param_shape = list(param.shape)

        total_params += num_params

        # Calculate bytes (depends on dtype)
        if dtype is None:
            dtype = param_dtype

        # Estimate bytes per element
        if "float32" in str(param_dtype):
            bytes_per_elem = 4
        elif "float16" in str(param_dtype) or "bfloat16" in str(param_dtype):
            bytes_per_elem = 2
        elif "int8" in str(param_dtype):
            bytes_per_elem = 1
        elif "int32" in str(param_dtype):
            bytes_per_elem = 4
        else:
            bytes_per_elem = 4  # Default assumption

        total_bytes += num_params * bytes_per_elem

        # Store shape
        param_shapes[param_name] = param_shape

    # Normalize dtype string
    if dtype:
        dtype = dtype.replace("mlx.core.", "")

    return {
        "total_params": total_params,
        "total_size_mb": total_bytes / (1024 * 1024),
        "dtype": dtype or "unknown",
        "param_shapes": param_shapes,
    }


def get_memory_footprint(module: nn.Module) -> dict[str, float]:
    """
    Estimate memory footprint of a module.

    Args:
        module: Module to analyze

    Returns:
        Dictionary with memory estimates in MB:
        - parameters: Memory for parameters
        - activations_estimate: Rough estimate for activations
        - total_estimate: Total estimated memory

    Example:
        >>> memory = get_memory_footprint(model)
        >>> print(f"Estimated memory: {memory['total_estimate']:.2f} MB")
    """
    stats = get_parameter_stats(module)

    param_size_mb = stats["total_size_mb"]

    # Rough estimate: activations are typically 2-3x parameter size during inference
    # This is a very rough heuristic
    activation_estimate_mb = param_size_mb * 2.5

    return {
        "parameters": param_size_mb,
        "activations_estimate": activation_estimate_mb,
        "total_estimate": param_size_mb + activation_estimate_mb,
    }


def initialize_weights(
    module: nn.Module,
    std: float = 0.02,
) -> None:
    """
    Initialize weights using normal distribution.

    Args:
        module: Module to initialize
        std: Standard deviation for normal distribution

    Example:
        >>> model = LlamaForCausalLM(config)
        >>> initialize_weights(model, std=0.02)
    """
    params = module.parameters()

    for param_name, param in params.items():
        # Only initialize weight matrices, not biases
        if "weight" in param_name.lower():
            # Initialize from normal distribution
            new_param = mx.random.normal(shape=param.shape, scale=std)

            # Replace parameter (this is a simplified approach)
            # In practice, you'd need to update the module's attribute
            if hasattr(module, param_name):
                setattr(module, param_name, new_param)


def print_parameter_summary(module: nn.Module, detailed: bool = False) -> None:
    """
    Print a summary of module parameters.

    Args:
        module: Module to summarize
        detailed: If True, print detailed per-parameter info

    Example:
        >>> print_parameter_summary(model)
        >>> print_parameter_summary(model, detailed=True)
    """
    stats = get_parameter_stats(module)

    print("=" * 60)
    print("Model Parameter Summary")
    print("=" * 60)
    print(f"Total Parameters: {stats['total_params']:,}")
    print(f"Total Size: {stats['total_size_mb']:.2f} MB")
    print(f"Data Type: {stats['dtype']}")
    print("=" * 60)

    if detailed:
        print("\nDetailed Parameter Shapes:")
        print("-" * 60)
        for param_name, shape in stats["param_shapes"].items():
            # Handle nested shapes (from dict parameters)
            if isinstance(shape, list) and len(shape) > 0 and isinstance(shape[0], list):
                # Nested list - sum all sub-shapes
                num_params = 0
                for sub_shape in shape:
                    sub_params = 1
                    for dim in sub_shape:
                        sub_params *= dim
                    num_params += sub_params
            else:
                # Simple shape - multiply dimensions
                num_params = 1
                for dim in shape:
                    num_params *= dim
            print(f"{param_name:50s} {str(shape):20s} ({num_params:,} params)")
        print("-" * 60)

    memory = get_memory_footprint(module)
    print("\nMemory Footprint Estimate:")
    print(f"  Parameters: {memory['parameters']:.2f} MB")
    print(f"  Activations (est.): {memory['activations_estimate']:.2f} MB")
    print(f"  Total (est.): {memory['total_estimate']:.2f} MB")
    print("=" * 60)
