# SPDX-License-Identifier: Apache-2.0
"""Custom MLX operations for model execution.

This module provides optimized custom operations for MLX that may not be
available in the standard MLX library, or provides specialized implementations
for better performance.
"""

from __future__ import annotations

import mlx.core as mx
import mlx.nn as nn


__all__ = [
    "rms_norm",
    "silu",
    "swiglu",
    "rotary_embedding",
    "apply_rotary_emb",
    "repeat_kv",
    "fused_dense_gelu",
]


def rms_norm(
    x: mx.array,
    weight: mx.array,
    eps: float = 1e-6,
) -> mx.array:
    """
    Root Mean Square Layer Normalization.

    Args:
        x: Input tensor [..., hidden_size]
        weight: Scale weights [hidden_size]
        eps: Epsilon for numerical stability

    Returns:
        Normalized tensor [..., hidden_size]

    Example:
        >>> x = mx.random.normal((2, 10, 768))
        >>> weight = mx.ones((768,))
        >>> normalized = rms_norm(x, weight)
    """
    # Compute RMS
    variance = mx.mean(mx.square(x), axis=-1, keepdims=True)
    inv_rms = mx.rsqrt(variance + eps)

    # Scale
    return x * inv_rms * weight


def silu(x: mx.array) -> mx.array:
    """
    SiLU (Swish) activation function.

    SiLU(x) = x * sigmoid(x)

    Args:
        x: Input tensor

    Returns:
        Activated tensor

    Example:
        >>> x = mx.array([-1.0, 0.0, 1.0])
        >>> activated = silu(x)
    """
    return x * mx.sigmoid(x)


def swiglu(gate: mx.array, x: mx.array) -> mx.array:
    """
    SwiGLU activation (Gated Linear Unit with SiLU).

    SwiGLU(gate, x) = SiLU(gate) * x

    Args:
        gate: Gate values
        x: Input values

    Returns:
        Gated output

    Example:
        >>> gate = mx.random.normal((2, 128))
        >>> x = mx.random.normal((2, 128))
        >>> output = swiglu(gate, x)
    """
    return silu(gate) * x


def rotary_embedding(
    dim: int,
    max_position_embeddings: int = 2048,
    base: float = 10000.0,
) -> tuple[mx.array, mx.array]:
    """
    Precompute rotary position embeddings (RoPE).

    Args:
        dim: Dimension (must be even)
        max_position_embeddings: Maximum sequence length
        base: Base for frequency calculation

    Returns:
        Tuple of (cos, sin) each [max_position_embeddings, dim]

    Example:
        >>> cos, sin = rotary_embedding(dim=128, max_position_embeddings=2048)
    """
    # Compute frequency inverse
    inv_freq = 1.0 / (base ** (mx.arange(0, dim, 2).astype(mx.float32) / dim))

    # Position indices
    position = mx.arange(max_position_embeddings, dtype=mx.float32)

    # Compute outer product
    freqs = mx.outer(position, inv_freq)

    # Duplicate for cos/sin
    emb = mx.concatenate([freqs, freqs], axis=-1)

    # Compute cos and sin
    cos = mx.cos(emb)
    sin = mx.sin(emb)

    return cos, sin


def apply_rotary_emb(
    q: mx.array,
    k: mx.array,
    cos: mx.array,
    sin: mx.array,
    position_ids: mx.array | None = None,
) -> tuple[mx.array, mx.array]:
    """
    Apply rotary position embeddings to query and key.

    Args:
        q: Query [batch, num_heads, seq_len, head_dim]
        k: Key [batch, num_heads, seq_len, head_dim]
        cos: Cosine values [seq_len, head_dim] or [batch, seq_len, head_dim]
        sin: Sine values [seq_len, head_dim] or [batch, seq_len, head_dim]
        position_ids: Optional position IDs [batch, seq_len]

    Returns:
        Tuple of (q_rotated, k_rotated)

    Example:
        >>> q = mx.random.normal((1, 32, 10, 128))
        >>> k = mx.random.normal((1, 32, 10, 128))
        >>> cos, sin = rotary_embedding(128, 2048)
        >>> q_rot, k_rot = apply_rotary_emb(q, k, cos[:10], sin[:10])
    """
    # Ensure cos/sin have correct shape
    if cos.ndim == 2:
        # [seq_len, head_dim] -> [1, 1, seq_len, head_dim]
        cos = mx.expand_dims(mx.expand_dims(cos, 0), 0)
        sin = mx.expand_dims(mx.expand_dims(sin, 0), 0)
    elif cos.ndim == 3:
        # [batch, seq_len, head_dim] -> [batch, 1, seq_len, head_dim]
        cos = mx.expand_dims(cos, 1)
        sin = mx.expand_dims(sin, 1)

    # Split into first and second halves
    q_half_dim = q.shape[-1] // 2
    q1 = q[..., :q_half_dim]
    q2 = q[..., q_half_dim:]

    k_half_dim = k.shape[-1] // 2
    k1 = k[..., :k_half_dim]
    k2 = k[..., k_half_dim:]

    # Also split cos/sin
    cos1 = cos[..., :q_half_dim]
    cos2 = cos[..., q_half_dim:]
    sin1 = sin[..., :q_half_dim]
    sin2 = sin[..., q_half_dim:]

    # Apply rotation
    # q_rot = [q1*cos - q2*sin, q1*sin + q2*cos]
    q_rotated = mx.concatenate(
        [
            q1 * cos1 - q2 * sin1,
            q1 * sin2 + q2 * cos2,
        ],
        axis=-1,
    )

    k_rotated = mx.concatenate(
        [
            k1 * cos1 - k2 * sin1,
            k1 * sin2 + k2 * cos2,
        ],
        axis=-1,
    )

    return q_rotated, k_rotated


def repeat_kv(hidden_states: mx.array, n_rep: int) -> mx.array:
    """
    Repeat key/value heads for grouped query attention (GQA).

    Args:
        hidden_states: [batch, num_kv_heads, seq_len, head_dim]
        n_rep: Number of repetitions (num_q_heads // num_kv_heads)

    Returns:
        [batch, num_q_heads, seq_len, head_dim]

    Example:
        >>> kv = mx.random.normal((1, 8, 10, 128))
        >>> kv_expanded = repeat_kv(kv, n_rep=4)  # 8 -> 32 heads
        >>> print(kv_expanded.shape)  # (1, 32, 10, 128)
    """
    if n_rep == 1:
        return hidden_states

    batch, num_kv_heads, slen, head_dim = hidden_states.shape

    # Expand dimension
    hidden_states = mx.expand_dims(hidden_states, 2)  # [B, KV, 1, S, D]

    # Repeat
    hidden_states = mx.tile(hidden_states, [1, 1, n_rep, 1, 1])  # [B, KV, n_rep, S, D]

    # Reshape
    hidden_states = mx.reshape(
        hidden_states,
        (batch, num_kv_heads * n_rep, slen, head_dim),
    )

    return hidden_states


def fused_dense_gelu(
    x: mx.array,
    weight: mx.array,
    bias: mx.array | None = None,
) -> mx.array:
    """
    Fused dense layer + GELU activation.

    More efficient than separate operations due to kernel fusion.

    Args:
        x: Input [batch, seq_len, in_features]
        weight: Weight matrix [out_features, in_features]
        bias: Optional bias [out_features]

    Returns:
        Output [batch, seq_len, out_features]

    Example:
        >>> x = mx.random.normal((2, 10, 768))
        >>> weight = mx.random.normal((3072, 768))
        >>> bias = mx.zeros((3072,))
        >>> output = fused_dense_gelu(x, weight, bias)
    """
    # Dense
    output = mx.matmul(x, weight.T)

    if bias is not None:
        output = output + bias

    # GELU
    output = nn.gelu(output)

    return output


def scaled_dot_product_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    attn_mask: mx.array | None = None,
    scale: float | None = None,
) -> mx.array:
    """
    Optimized scaled dot-product attention.

    This is a custom implementation that may be faster than the generic version
    for specific use cases.

    Args:
        query: [batch, num_heads, seq_q, head_dim]
        key: [batch, num_heads, seq_k, head_dim]
        value: [batch, num_heads, seq_k, head_dim]
        attn_mask: Optional mask [batch, 1, seq_q, seq_k]
        scale: Optional scale factor (default: 1/sqrt(head_dim))

    Returns:
        [batch, num_heads, seq_q, head_dim]

    Example:
        >>> q = mx.random.normal((1, 32, 10, 128))
        >>> k = mx.random.normal((1, 32, 10, 128))
        >>> v = mx.random.normal((1, 32, 10, 128))
        >>> output = scaled_dot_product_attention(q, k, v)
    """
    if scale is None:
        scale = 1.0 / mx.sqrt(float(query.shape[-1]))

    # Compute attention scores
    attn_weights = mx.matmul(query, mx.swapaxes(key, -2, -1)) * scale

    # Apply mask if provided
    if attn_mask is not None:
        attn_weights = attn_weights + attn_mask

    # Softmax
    attn_weights = mx.softmax(attn_weights, axis=-1)

    # Apply to values
    output = mx.matmul(attn_weights, value)

    return output


def causal_mask(seq_len: int, dtype: mx.Dtype = mx.float32) -> mx.array:
    """
    Create causal attention mask.

    Args:
        seq_len: Sequence length
        dtype: Output data type

    Returns:
        Causal mask [seq_len, seq_len] with -inf for masked positions

    Example:
        >>> mask = causal_mask(5)
        >>> # mask[i, j] = -inf if j > i, else 0
    """
    # Create lower triangular matrix
    mask = mx.tril(mx.ones((seq_len, seq_len), dtype=dtype))

    # Convert to attention mask (0 for valid, -inf for masked)
    mask = mx.where(mask == 0, -float("inf"), 0.0)

    return mask.astype(dtype)


def flash_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    is_causal: bool = False,
) -> mx.array:
    """
    Flash Attention implementation for MLX.

    Note: This is a simplified version. For production, use MLX's optimized
    implementation when available.

    Args:
        query: [batch, num_heads, seq_q, head_dim]
        key: [batch, num_heads, seq_k, head_dim]
        value: [batch, num_heads, seq_k, head_dim]
        is_causal: Whether to apply causal mask

    Returns:
        [batch, num_heads, seq_q, head_dim]

    Example:
        >>> q = mx.random.normal((1, 32, 1024, 128))
        >>> k = mx.random.normal((1, 32, 1024, 128))
        >>> v = mx.random.normal((1, 32, 1024, 128))
        >>> output = flash_attention(q, k, v, is_causal=True)
    """
    # For now, use standard attention with optional causal mask
    mask = None
    if is_causal:
        seq_len = query.shape[-2]
        mask = causal_mask(seq_len, dtype=query.dtype)
        # Add batch and head dimensions
        mask = mx.expand_dims(mx.expand_dims(mask, 0), 0)

    return scaled_dot_product_attention(query, key, value, attn_mask=mask)
