# SPDX-License-Identifier: Apache-2.0
"""High-level inference API for MLX-LLM.

This module provides a simplified, high-level API for LLM inference,
wrapping the lower-level engine APIs for ease of use.
"""

from __future__ import annotations

from typing import Any, Iterator

from mlxllm.engine.async_llm_engine import AsyncEngineArgs, AsyncLLMEngine
from mlxllm.engine.llm_engine import EngineArgs, LLMEngine
from mlxllm.outputs import RequestOutput
from mlxllm.sampling_params import SamplingParams


class MLXInferenceEngine:
    """
    High-level inference engine for MLX-LLM.

    This class provides a simplified interface for text generation with
    sensible defaults and automatic configuration.
    """

    def __init__(
        self,
        model: str,
        quantization: str | None = None,
        max_model_len: int | None = None,
        gpu_memory_fraction: float = 0.9,
        enable_prefix_caching: bool = True,
        **kwargs: Any,
    ):
        """
        Initialize MLX inference engine.

        Args:
            model: Model path or HuggingFace model ID.
            quantization: Quantization type (q4, q8, fp16, bf16).
            max_model_len: Maximum model context length.
            gpu_memory_fraction: Fraction of GPU memory to use.
            enable_prefix_caching: Enable prefix caching.
            **kwargs: Additional engine arguments.
        """
        self.model = model
        self.quantization = quantization

        # Create engine args
        engine_args = EngineArgs(
            model=model,
            quantization=quantization,
            max_model_len=max_model_len,
            gpu_memory_fraction=gpu_memory_fraction,
            enable_prefix_caching=enable_prefix_caching,
            **kwargs,
        )

        # Create sync engine
        self.engine = engine_args.create_engine()

    def generate(
        self,
        prompt: str | list[str],
        max_tokens: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        top_k: int = -1,
        **kwargs: Any,
    ) -> list[str]:
        """
        Generate text from prompt(s).

        Args:
            prompt: Input prompt or list of prompts.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.
            top_p: Nucleus sampling threshold.
            top_k: Top-k filtering.
            **kwargs: Additional sampling parameters.

        Returns:
            List of generated texts.
        """
        # Convert single prompt to list
        prompts = [prompt] if isinstance(prompt, str) else prompt

        # Create sampling params
        sampling_params = SamplingParams(
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            **kwargs,
        )

        # Generate
        outputs = self.engine.generate(
            prompts=prompts,
            sampling_params=sampling_params,
        )

        # Extract generated texts
        return [output.outputs[0].text for output in outputs]

    def generate_stream(
        self,
        prompt: str,
        max_tokens: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        **kwargs: Any,
    ) -> Iterator[str]:
        """
        Generate text from prompt with streaming.

        Args:
            prompt: Input prompt.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.
            top_p: Nucleus sampling threshold.
            **kwargs: Additional sampling parameters.

        Yields:
            Generated text chunks.
        """
        sampling_params = SamplingParams(
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            **kwargs,
        )

        for output in self.engine.generate_stream(
            prompt=prompt,
            sampling_params=sampling_params,
        ):
            if output.outputs:
                yield output.outputs[0].text

    def chat(
        self,
        messages: list[dict[str, str]],
        max_tokens: int = 100,
        temperature: float = 0.7,
        **kwargs: Any,
    ) -> str:
        """
        Chat completion (requires model with chat template).

        Args:
            messages: List of chat messages.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.
            **kwargs: Additional sampling parameters.

        Returns:
            Generated response.
        """
        # Format messages using model's chat template
        # This would need tokenizer integration
        # For now, simple concatenation
        prompt = "\n".join(f"{msg['role']}: {msg['content']}" for msg in messages)
        prompt += "\nassistant:"

        results = self.generate(
            prompt=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )

        return results[0]


class AsyncMLXInferenceEngine:
    """
    High-level async inference engine for MLX-LLM.

    This class provides an asynchronous interface for text generation.
    """

    def __init__(
        self,
        model: str,
        quantization: str | None = None,
        max_model_len: int | None = None,
        gpu_memory_fraction: float = 0.9,
        enable_prefix_caching: bool = True,
        **kwargs: Any,
    ):
        """
        Initialize async MLX inference engine.

        Args:
            model: Model path or HuggingFace model ID.
            quantization: Quantization type.
            max_model_len: Maximum model context length.
            gpu_memory_fraction: Fraction of GPU memory to use.
            enable_prefix_caching: Enable prefix caching.
            **kwargs: Additional engine arguments.
        """
        self.model = model
        self.quantization = quantization

        # Create async engine args
        engine_args = AsyncEngineArgs(
            model=model,
            quantization=quantization,
            max_model_len=max_model_len,
            gpu_memory_fraction=gpu_memory_fraction,
            enable_prefix_caching=enable_prefix_caching,
            **kwargs,
        )

        # Create async engine
        self.engine: AsyncLLMEngine | None = None
        self._engine_args = engine_args

    async def start(self) -> None:
        """Start the async engine."""
        self.engine = await self._engine_args.create_engine()

    async def generate(
        self,
        prompt: str | list[str],
        max_tokens: int = 100,
        temperature: float = 0.7,
        top_p: float = 0.9,
        **kwargs: Any,
    ) -> list[str]:
        """
        Generate text from prompt(s) asynchronously.

        Args:
            prompt: Input prompt or list of prompts.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.
            top_p: Nucleus sampling threshold.
            **kwargs: Additional sampling parameters.

        Returns:
            List of generated texts.
        """
        if self.engine is None:
            await self.start()

        # Convert single prompt to list
        prompts = [prompt] if isinstance(prompt, str) else prompt

        # Create sampling params
        sampling_params = SamplingParams(
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            **kwargs,
        )

        # Generate
        outputs = await self.engine.generate(
            prompts=prompts,
            sampling_params=sampling_params,
        )

        # Extract generated texts
        return [output.outputs[0].text for output in outputs]

    async def generate_stream(
        self,
        prompt: str,
        max_tokens: int = 100,
        temperature: float = 0.7,
        **kwargs: Any,
    ):
        """
        Generate text from prompt with streaming asynchronously.

        Args:
            prompt: Input prompt.
            max_tokens: Maximum tokens to generate.
            temperature: Sampling temperature.
            **kwargs: Additional sampling parameters.

        Yields:
            Generated text chunks.
        """
        if self.engine is None:
            await self.start()

        sampling_params = SamplingParams(
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )

        async for output in self.engine.generate_stream(
            prompt=prompt,
            sampling_params=sampling_params,
        ):
            if output.outputs:
                yield output.outputs[0].text


# Convenience functions
def generate(
    model: str,
    prompt: str | list[str],
    max_tokens: int = 100,
    **kwargs: Any,
) -> list[str]:
    """
    Quick generate function (creates engine on first call).

    Args:
        model: Model path or ID.
        prompt: Input prompt or list of prompts.
        max_tokens: Maximum tokens to generate.
        **kwargs: Additional parameters.

    Returns:
        List of generated texts.
    """
    engine = MLXInferenceEngine(model=model)
    return engine.generate(prompt=prompt, max_tokens=max_tokens, **kwargs)
