#!/usr/bin/env python3
"""
Basic test script for MLX-LLM implementation.

This script validates that all core components are properly implemented
and can work together.
"""

import sys
from pathlib import Path

# Add parent directory to path to find mlxllm
sys.path.insert(0, str(Path(__file__).parent.parent))


def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")

    # Core configuration
    from mlxllm.config import (
        CacheConfig,
        DeviceConfig,
        ModelConfig,
        SchedulerConfig,
    )
    print("✓ Config modules imported")

    # Type system
    from mlxllm.outputs import CompletionOutput, RequestOutput
    from mlxllm.sampling_params import SamplingParams
    from mlxllm.sequence import Sequence, SequenceGroup
    from mlxllm.tasks import TaskType  # Task class doesn't exist, only TaskType
    print("✓ Type system imported")

    # Engine
    from mlxllm.engine.exceptions import EngineError
    from mlxllm.engine.protocol import GenerateRequest, GenerateResponse
    from mlxllm.engine.utils import calculate_num_blocks
    print("✓ Engine modules imported")

    # Scheduler
    from mlxllm.core.sched.scheduler import Scheduler
    from mlxllm.core.sched.output import SchedulerOutput
    print("✓ Scheduler imported")

    # KV Cache
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.core.block_pool import BlockPool
    print("✓ KV cache modules imported")

    # Attention
    from mlxllm.attention.layer import Attention
    from mlxllm.attention.selector import AttentionBackendSelector
    print("✓ Attention modules imported")

    # Model layers
    from mlxllm.model_executor.layers.linear import UnquantizedLinear
    from mlxllm.model_executor.layers.activation import SiLU, SwiGLU
    from mlxllm.model_executor.layers.layernorm import RMSNorm
    from mlxllm.model_executor.layers.rotary_embedding import RotaryEmbedding
    print("✓ Model layers imported")

    # Model implementations
    from mlxllm.model_executor.models.llama import LlamaForCausalLM
    from mlxllm.model_executor.models.qwen2 import Qwen2ForCausalLM
    print("✓ Model implementations imported")

    # Model loading
    from mlxllm.model_executor.model_loader.default_loader import DefaultModelLoader
    print("✓ Model loader imported")

    # Tokenization
    from mlxllm.tokenization.tokenizer import Tokenizer
    print("✓ Tokenization imported")

    # Engines
    from mlxllm.engine.llm_engine import LLMEngine, EngineArgs
    from mlxllm.engine.async_llm_engine import AsyncLLMEngine, AsyncEngineArgs
    print("✓ LLM engines imported")

    # Processing
    from mlxllm.engine.processor import InputProcessor
    from mlxllm.engine.detokenizer import Detokenizer
    from mlxllm.engine.output_processor import OutputProcessor
    print("✓ Processing modules imported")

    # Executor
    from mlxllm.model_executor.executor import ModelExecutor
    from mlxllm.model_executor.worker import Worker
    print("✓ Executor and worker imported")

    print("\n✅ All imports successful!\n")
    # All imports succeeded, test passes
    assert True


def test_device_detection():
    """Test device detection."""
    print("Testing device detection...")

    from mlxllm.config.device import DeviceConfig

    # Use from_auto_detect() to create DeviceConfig
    device = DeviceConfig.from_auto_detect()
    print(f"  Chip: {device.device_info.chip_name}")
    print(f"  Memory: {device.device_info.unified_memory_gb}GB")
    print(f"  GPU cores: {device.device_info.num_gpu_cores}")
    print(f"  MLX available: {device.device_info.supports_mlx}")

    if device.device_info.supports_mlx:
        print("✓ Metal device detected")
    else:
        print("⚠ Metal not available")

    # Assert device config was created successfully
    assert device is not None
    assert device.device_info is not None
    assert device.device_info.chip_name is not None


def test_config_creation():
    """Test configuration creation."""
    print("\nTesting configuration creation...")

    from mlxllm.config import (
        DeviceConfig,
        ModelConfig,
        SchedulerConfig,
    )

    # Create configs
    device_config = DeviceConfig.from_auto_detect()
    model_config = ModelConfig(
        model_name="test-model",
        max_model_len=2048,
    )
    scheduler_config = SchedulerConfig(
        max_num_batched_tokens=2048,
    )

    print(f"  Model: {model_config.model_name}")
    print(f"  Max length: {model_config.max_model_len}")
    print(f"  Scheduler policy: {scheduler_config.policy}")

    print("✓ Configurations created successfully")

    # Assert all configs were created
    assert device_config is not None
    assert model_config.model_name == "test-model"
    assert model_config.max_model_len == 2048


def test_sampling_params():
    """Test sampling parameters."""
    print("\nTesting sampling parameters...")

    from mlxllm.sampling_params import SamplingParams

    # Create sampling params
    params = SamplingParams(
        temperature=0.7,
        top_p=0.9,
        top_k=50,
        max_tokens=100,
    )

    print(f"  Temperature: {params.temperature}")
    print(f"  Top-p: {params.top_p}")
    print(f"  Top-k: {params.top_k}")
    print(f"  Max tokens: {params.max_tokens}")

    print("✓ Sampling parameters created")

    # Assert params are correct
    assert params.temperature == 0.7
    assert params.top_p == 0.9
    assert params.top_k == 50
    assert params.max_tokens == 100


def test_sequence():
    """Test sequence creation."""
    print("\nTesting sequence creation...")

    from mlxllm.sequence import Sequence, SequenceGroup, SequenceData
    from mlxllm.sampling_params import SamplingParams

    # Create sequence data first
    seq_data = SequenceData(prompt_token_ids=[1, 2, 3, 4, 5])

    # Create sequence
    seq = Sequence(
        seq_id="seq-1",
        request_id="test-request",
        data=seq_data,
    )

    # Create sequence group
    params = SamplingParams(max_tokens=10)
    seq_group = SequenceGroup(
        request_id="test-request",
        sequences=[seq],
        sampling_params=params,
    )

    print(f"  Sequence ID: {seq.seq_id}")
    print(f"  Sequence length: {seq.seq_len}")
    print(f"  Request ID: {seq_group.request_id}")

    print("✓ Sequence and SequenceGroup created")

    # Assert sequence properties
    assert seq.seq_id == "seq-1"
    assert seq.seq_len == 5
    assert seq_group.request_id == "test-request"
    assert len(seq_group.sequences) == 1


def test_kv_cache():
    """Test KV cache manager."""
    print("\nTesting KV cache manager...")

    from mlxllm.config.cache import CacheConfig, KVCacheConfig
    from mlxllm.config.model import ModelConfig
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.sequence import Sequence, SequenceData

    # Create KV cache config
    kv_cache_config = KVCacheConfig(block_size=16, num_gpu_blocks=100)
    cache_config = CacheConfig(kv_cache=kv_cache_config)

    # Create model config
    model_config = ModelConfig(
        model_name="test-model",
        max_model_len=2048,
        num_layers=32,
        num_attention_heads=32,
        head_dim=128,
    )

    # Create cache manager
    kv_cache = KVCacheManager(
        cache_config=kv_cache_config,
        model_config=model_config,
    )

    # Test allocation with a sequence
    initial_free = kv_cache.get_num_free_blocks()
    print(f"  Initial free blocks: {initial_free}")

    # Create a test sequence
    seq_data = SequenceData(prompt_token_ids=[1, 2, 3, 4, 5])
    seq = Sequence(seq_id="seq-1", request_id="req-1", data=seq_data)

    # Allocate blocks for sequence
    success = kv_cache.allocate_sequence(seq)
    assert success, "Block allocation failed"
    num_allocated_blocks = len(seq.block_ids)
    print(f"  Allocated blocks for sequence, {num_allocated_blocks} blocks")
    print(f"  Free blocks after allocation: {kv_cache.get_num_free_blocks()}")

    # Assert blocks were allocated
    assert num_allocated_blocks > 0, "No blocks were allocated"

    # Test freeing
    kv_cache.free_sequence(seq)
    final_free = kv_cache.get_num_free_blocks()
    print(f"  After free: {final_free} free blocks")

    print("✓ KV cache manager working")

    # Assert cache operations work
    assert final_free == initial_free, "Free blocks should return to initial count after freeing"


def test_scheduler():
    """Test scheduler."""
    print("\nTesting scheduler...")

    from mlxllm.config.cache import CacheConfig, KVCacheConfig
    from mlxllm.config.model import ModelConfig
    from mlxllm.config.scheduler import SchedulerConfig
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.core.sched.scheduler import Scheduler
    from mlxllm.sampling_params import SamplingParams
    from mlxllm.sequence import Sequence, SequenceGroup, SequenceData

    # Create configs
    scheduler_config = SchedulerConfig()
    kv_cache_config = KVCacheConfig(block_size=16, num_gpu_blocks=100)
    cache_config = CacheConfig(kv_cache=kv_cache_config)

    # Create model config
    model_config = ModelConfig(
        model_name="test-model",
        max_model_len=2048,
        num_layers=32,
        num_attention_heads=32,
        head_dim=128,
    )

    # Create KV cache
    kv_cache = KVCacheManager(
        cache_config=kv_cache_config,
        model_config=model_config,
    )

    # Create scheduler
    scheduler = Scheduler(
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        kv_cache_manager=kv_cache,
    )

    # Create a test request
    seq_data = SequenceData(prompt_token_ids=[1, 2, 3])
    seq = Sequence(seq_id="seq-1", request_id="req-1", data=seq_data)
    params = SamplingParams(max_tokens=10)
    seq_group = SequenceGroup(
        request_id="req-1",
        sequences=[seq],
        sampling_params=params,
    )

    # Add request
    scheduler.add_request(seq_group)
    print(f"  Added request: {seq_group.request_id}")

    # Schedule
    output = scheduler.schedule()
    print(f"  Scheduled groups: {len(output.scheduled_groups)}")
    print(f"  Prefill groups: {output.num_prefill_groups}")
    print(f"  Decode groups: {output.num_decode_groups}")

    print("✓ Scheduler working")

    # Assert scheduler worked
    assert output is not None
    assert hasattr(output, 'scheduled_groups')
    assert len(output.scheduled_groups) >= 0


def main():
    """Run all tests."""
    print("=" * 60)
    print("MLX-LLM Basic Implementation Tests")
    print("=" * 60)
    print()

    results = []

    # Run tests
    results.append(("Imports", test_imports()))
    results.append(("Device Detection", test_device_detection()))
    results.append(("Configuration", test_config_creation()))
    results.append(("Sampling Params", test_sampling_params()))
    results.append(("Sequence", test_sequence()))
    results.append(("KV Cache", test_kv_cache()))
    results.append(("Scheduler", test_scheduler()))

    # Summary
    print()
    print("=" * 60)
    print("Test Summary")
    print("=" * 60)

    passed = sum(1 for _, result in results if result)
    total = len(results)

    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")

    print()
    print(f"Passed: {passed}/{total} ({100*passed//total}%)")

    if passed == total:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
