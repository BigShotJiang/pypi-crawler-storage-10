# SPDX-License-Identifier: Apache-2.0
"""Version information for MLX-LLM."""

__version__ = "0.1.0"
__version_tuple__ = (0, 1, 0)

# Build metadata
__build__ = "dev"
__mlx_version_required__ = "0.19.0"
__python_version_required__ = "3.11"
