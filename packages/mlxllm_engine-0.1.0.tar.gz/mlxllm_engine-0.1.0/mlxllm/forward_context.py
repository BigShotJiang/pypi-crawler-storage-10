# SPDX-License-Identifier: Apache-2.0
"""Forward pass context management for MLX-LLM.

This module provides context managers and utilities for managing state during
model forward passes, including KV cache, attention masks, and position IDs.
"""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Iterator

import mlx.core as mx


@dataclass
class ForwardContext:
    """Context for a model forward pass."""

    # Input information
    input_ids: mx.array
    """Input token IDs."""

    position_ids: mx.array | None = None
    """Position IDs for tokens."""

    # KV cache
    kv_cache: Any | None = None
    """KV cache state."""

    # Attention
    attention_mask: mx.array | None = None
    """Attention mask."""

    # Metadata
    is_prefill: bool = True
    """Whether this is a prefill pass (vs decode)."""

    batch_size: int = 1
    """Batch size."""

    seq_len: int = 0
    """Sequence length."""

    # Additional state
    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional metadata."""

    def __post_init__(self):
        """Initialize computed fields."""
        if self.seq_len == 0:
            self.seq_len = self.input_ids.shape[-1]
        if self.batch_size == 1 and len(self.input_ids.shape) > 1:
            self.batch_size = self.input_ids.shape[0]


class ForwardContextManager:
    """Manage forward pass contexts."""

    def __init__(self):
        """Initialize context manager."""
        self._stack: list[ForwardContext] = []

    @contextmanager
    def context(self, ctx: ForwardContext) -> Iterator[ForwardContext]:
        """
        Create a forward pass context.

        Args:
            ctx: Forward context.

        Yields:
            The forward context.
        """
        self._stack.append(ctx)
        try:
            yield ctx
        finally:
            self._stack.pop()

    def current(self) -> ForwardContext | None:
        """Get the current forward context."""
        return self._stack[-1] if self._stack else None

    def clear(self) -> None:
        """Clear all contexts."""
        self._stack.clear()


# Global context manager
_global_context_manager = ForwardContextManager()


def get_current_context() -> ForwardContext | None:
    """Get the current global forward context."""
    return _global_context_manager.current()


@contextmanager
def forward_context(
    input_ids: mx.array,
    is_prefill: bool = True,
    kv_cache: Any | None = None,
    **kwargs: Any,
) -> Iterator[ForwardContext]:
    """
    Context manager for forward passes.

    Args:
        input_ids: Input token IDs.
        is_prefill: Whether this is prefill.
        kv_cache: KV cache state.
        **kwargs: Additional context arguments.

    Yields:
        Forward context.
    """
    ctx = ForwardContext(
        input_ids=input_ids,
        is_prefill=is_prefill,
        kv_cache=kv_cache,
        **kwargs,
    )

    with _global_context_manager.context(ctx):
        yield ctx
