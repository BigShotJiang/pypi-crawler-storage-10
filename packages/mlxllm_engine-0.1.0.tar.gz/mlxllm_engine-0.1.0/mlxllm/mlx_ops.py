"""MLX Operations Loader for MLX-LLM.

This module loads the mlxllm_ops C++ extension (built with nanobind)
and provides Python wrappers for device management, profiling, and
Metal utilities.

Unlike the old torch_ops.py, this module does NOT expose tensor operations.
All tensor operations should be implemented using mlx.core directly in Python.
"""

import sys
from typing import Dict, Any, Optional
import warnings

try:
    import mlxllm_ops
    _MLXLLM_OPS_AVAILABLE = True
except ImportError as e:
    _MLXLLM_OPS_AVAILABLE = False
    _MLXLLM_OPS_IMPORT_ERROR = str(e)

try:
    import mlx.core as mx
    _MLX_AVAILABLE = True
except ImportError:
    _MLX_AVAILABLE = False


def _check_ops_available():
    """Check if mlxllm_ops extension is available and raise helpful error."""
    if not _MLXLLM_OPS_AVAILABLE:
        raise ImportError(
            f"mlxllm_ops C++ extension not available: {_MLXLLM_OPS_IMPORT_ERROR}\n\n"
            "This likely means the C++ extensions were not built. To build them:\n"
            "  1. Install nanobind: pip install nanobind\n"
            "  2. Rebuild mlxllm: pip install -e .\n"
            "  3. Or build manually: cd build && cmake .. && make && make install"
        )


def _check_mlx_available():
    """Check if MLX is available."""
    if not _MLX_AVAILABLE:
        raise ImportError(
            "MLX not available. Install with: pip install mlx\n"
            "MLX is required for MLX-LLM to function."
        )


# ============================================================================
# Module Information
# ============================================================================

def get_version() -> str:
    """Get MLX-LLM version string."""
    _check_ops_available()
    return mlxllm_ops.get_version()


def get_backend() -> str:
    """Get backend name (Metal or CPU)."""
    _check_ops_available()
    return mlxllm_ops.get_backend()


def get_build_info() -> str:
    """Get build type (Debug or Release)."""
    _check_ops_available()
    return mlxllm_ops.get_build_info()


def get_build_config() -> Dict[str, Any]:
    """Get detailed build configuration.

    Returns:
        dict: Build configuration including version, backend, compiler info,
              platform, architecture, and feature flags.
    """
    _check_ops_available()
    return dict(mlxllm_ops.get_build_config())


def has_metal_support() -> bool:
    """Check if Metal backend is available."""
    _check_ops_available()
    return mlxllm_ops.has_metal_support()


def has_cpu_support() -> bool:
    """Check if CPU backend is available."""
    _check_ops_available()
    return mlxllm_ops.has_cpu_support()


# ============================================================================
# Device Management
# ============================================================================

def initialize_device() -> None:
    """Initialize Metal device and resources.

    This should be called once at startup to ensure Metal is properly initialized.
    Raises RuntimeError if Metal device cannot be created.
    """
    _check_ops_available()
    mlxllm_ops.initialize_device()


def synchronize() -> None:
    """Synchronize all pending Metal operations.

    Blocks until all GPU work is complete. Useful for accurate timing measurements.
    """
    _check_ops_available()
    mlxllm_ops.synchronize()


def get_device_name() -> str:
    """Get current device name.

    Returns:
        str: Device name (e.g., "Apple M4 Max" or "CPU")
    """
    _check_ops_available()
    return mlxllm_ops.get_device_name()


def get_device_memory_info() -> Dict[str, Any]:
    """Get device memory information.

    Returns:
        dict: Memory info including:
            - total_memory: Total device memory in bytes
            - available_memory: Available memory in bytes
            - unified_memory: Whether unified memory is used
            - device_name: Name of the device
            - supports_family_apple7: GPU family support (macOS 12.0+)
            - supports_family_apple8: GPU family support (macOS 13.0+)
    """
    _check_ops_available()
    return dict(mlxllm_ops.get_device_memory_info())


# ============================================================================
# Performance Profiling
# ============================================================================

def set_profiling_enabled(enabled: bool) -> None:
    """Enable or disable Metal performance profiling.

    Args:
        enabled: Whether to enable profiling
    """
    _check_ops_available()
    mlxllm_ops.set_profiling_enabled(enabled)


def get_profiling_stats() -> Dict[str, Any]:
    """Get profiling statistics.

    Returns:
        dict: Profiling stats including:
            - enabled: Whether profiling is enabled
            - total_kernels_launched: Number of kernels launched
            - total_compute_time_ms: Total compute time in milliseconds
            - total_memory_transfers: Number of memory transfers
            - total_bytes_transferred: Total bytes transferred
    """
    _check_ops_available()
    return dict(mlxllm_ops.get_profiling_stats())


def reset_profiling_stats() -> None:
    """Reset all profiling statistics to zero."""
    _check_ops_available()
    mlxllm_ops.reset_profiling_stats()


# ============================================================================
# Error Handling and Debugging
# ============================================================================

def set_error_mode(mode: str) -> None:
    """Set error handling mode.

    Args:
        mode: Error mode - 'strict' (throw exceptions), 'warn' (print warnings),
              or 'ignore' (silent).
    """
    _check_ops_available()
    if mode not in ('strict', 'warn', 'ignore'):
        raise ValueError(f"Invalid error mode: {mode}. Must be 'strict', 'warn', or 'ignore'")
    mlxllm_ops.set_error_mode(mode)


def get_error_mode() -> str:
    """Get current error handling mode."""
    _check_ops_available()
    return mlxllm_ops.get_error_mode()


def set_debug_mode(enabled: bool) -> None:
    """Enable or disable debug mode.

    Args:
        enabled: Whether to enable verbose debug logging
    """
    _check_ops_available()
    mlxllm_ops.set_debug_mode(enabled)


def get_debug_mode() -> bool:
    """Check if debug mode is enabled."""
    _check_ops_available()
    return mlxllm_ops.get_debug_mode()


def get_last_error() -> str:
    """Get last error message."""
    _check_ops_available()
    return mlxllm_ops.get_last_error()


# ============================================================================
# Global Configuration
# ============================================================================

def set_config(config: Dict[str, Any]) -> None:
    """Set global configuration options.

    Args:
        config: Configuration dictionary with keys:
            - num_threads (int): Number of CPU threads
            - cache_block_size (int): KV cache block size
            - enable_prefix_caching (bool): Enable prefix caching
    """
    _check_ops_available()
    mlxllm_ops.set_config(config)


def get_config() -> Dict[str, Any]:
    """Get global configuration options.

    Returns:
        dict: Current configuration
    """
    _check_ops_available()
    return dict(mlxllm_ops.get_config())


# ============================================================================
# Metal Capture Utilities
# ============================================================================

def start_metal_capture(path: str) -> None:
    """Start Metal GPU trace capture.

    Args:
        path: Output path for .gputrace file

    Note:
        Only available on macOS. Use with Xcode Instruments for performance analysis.
    """
    _check_ops_available()
    if not path.endswith('.gputrace'):
        warnings.warn(
            f"Metal capture path should end with .gputrace, got: {path}",
            UserWarning
        )
    mlxllm_ops.start_metal_capture(path)


def stop_metal_capture() -> None:
    """Stop Metal GPU trace capture."""
    _check_ops_available()
    mlxllm_ops.stop_metal_capture()


def is_metal_capturing() -> bool:
    """Check if Metal capture is currently active."""
    _check_ops_available()
    return mlxllm_ops.is_metal_capturing()


# ============================================================================
# Module Constants
# ============================================================================

if _MLXLLM_OPS_AVAILABLE:
    __version__ = mlxllm_ops.__version__
    __backend__ = mlxllm_ops.__backend__
    __build_type__ = mlxllm_ops.__build_type__

    DEFAULT_BLOCK_SIZE = mlxllm_ops.DEFAULT_BLOCK_SIZE
    MAX_SEQ_LEN = mlxllm_ops.MAX_SEQ_LEN
    MAX_BATCH_SIZE = mlxllm_ops.MAX_BATCH_SIZE
else:
    __version__ = "0.0.0"
    __backend__ = "unavailable"
    __build_type__ = "unknown"

    DEFAULT_BLOCK_SIZE = 16
    MAX_SEQ_LEN = 32768
    MAX_BATCH_SIZE = 512


# ============================================================================
# Module Initialization
# ============================================================================

def _init_module():
    """Initialize the module and perform startup checks."""
    if not _MLXLLM_OPS_AVAILABLE:
        warnings.warn(
            "mlxllm_ops C++ extension not available. "
            "Device management and profiling features will not work. "
            f"Error: {_MLXLLM_OPS_IMPORT_ERROR}",
            ImportWarning
        )

    if not _MLX_AVAILABLE:
        warnings.warn(
            "MLX not available. MLX-LLM requires MLX to be installed.",
            ImportWarning
        )


# Run initialization
_init_module()


# ============================================================================
# Backward Compatibility (Deprecation Layer)
# ============================================================================

def _deprecated_torch_ops_warning():
    """Warn about deprecated torch_ops usage."""
    warnings.warn(
        "torch_ops module is deprecated. MLX-LLM now uses pure MLX operations. "
        "Please update your code to use mlx.core directly for tensor operations, "
        "and mlxllm.mlx_ops for device management.",
        DeprecationWarning,
        stacklevel=3
    )


# Expose a compatibility shim for old torch_ops imports
# This will be removed in a future version
class _TorchOpsCompatibilityShim:
    """Compatibility shim for old torch_ops imports (deprecated)."""

    def __getattr__(self, name):
        _deprecated_torch_ops_warning()
        # Try to get from mlxllm_ops if available
        if _MLXLLM_OPS_AVAILABLE and hasattr(mlxllm_ops, name):
            return getattr(mlxllm_ops, name)
        raise AttributeError(
            f"torch_ops.{name} is no longer available. "
            "Please use mlx.core for tensor operations."
        )


__all__ = [
    # Version and info
    'get_version',
    'get_backend',
    'get_build_info',
    'get_build_config',
    'has_metal_support',
    'has_cpu_support',
    # Device management
    'initialize_device',
    'synchronize',
    'get_device_name',
    'get_device_memory_info',
    # Profiling
    'set_profiling_enabled',
    'get_profiling_stats',
    'reset_profiling_stats',
    # Error handling
    'set_error_mode',
    'get_error_mode',
    'set_debug_mode',
    'get_debug_mode',
    'get_last_error',
    # Configuration
    'set_config',
    'get_config',
    # Metal capture
    'start_metal_capture',
    'stop_metal_capture',
    'is_metal_capturing',
    # Constants
    '__version__',
    '__backend__',
    '__build_type__',
    'DEFAULT_BLOCK_SIZE',
    'MAX_SEQ_LEN',
    'MAX_BATCH_SIZE',
]
