# SPDX-License-Identifier: Apache-2.0
"""Scalar type definitions and MLX dtype mappings."""

from typing import Union

try:
    import mlx.core as mx

    MLX_AVAILABLE = True
except ImportError:
    MLX_AVAILABLE = False
    mx = None

# Type aliases
DtypeLike = Union[str, "mx.Dtype"]

# MLX dtype mappings
DTYPE_MAP = {
    "float16": "float16",
    "fp16": "float16",
    "bfloat16": "bfloat16",
    "bf16": "bfloat16",
    "float32": "float32",
    "fp32": "float32",
    "int8": "int8",
    "int16": "int16",
    "int32": "int32",
    "int64": "int64",
    "uint8": "uint8",
    "uint16": "uint16",
    "uint32": "uint32",
    "uint64": "uint64",
    "bool": "bool_",
}


def get_mlx_dtype(dtype: DtypeLike) -> "mx.Dtype":
    """
    Get MLX dtype from string or MLX dtype.

    Args:
        dtype: String dtype name or MLX dtype.

    Returns:
        MLX dtype.

    Raises:
        ValueError: If dtype is not supported.
    """
    if not MLX_AVAILABLE:
        raise RuntimeError("MLX is not available")

    if isinstance(dtype, str):
        dtype_str = DTYPE_MAP.get(dtype.lower(), dtype)
        return getattr(mx, dtype_str)

    return dtype


def dtype_size_bytes(dtype: DtypeLike) -> int:
    """
    Get size in bytes for a dtype.

    Args:
        dtype: String dtype name or MLX dtype.

    Returns:
        Size in bytes.
    """
    if MLX_AVAILABLE:
        mlx_dtype = get_mlx_dtype(dtype)
        return mlx_dtype.size
    else:
        # Fallback for when MLX not available
        size_map = {
            "float16": 2,
            "bfloat16": 2,
            "float32": 4,
            "int8": 1,
            "int16": 2,
            "int32": 4,
            "int64": 8,
            "uint8": 1,
            "uint16": 2,
            "uint32": 4,
            "uint64": 8,
            "bool": 1,
        }

        if isinstance(dtype, str):
            dtype = DTYPE_MAP.get(dtype.lower(), dtype)

        return size_map.get(dtype, 4)  # Default to 4 bytes


def is_quantized_dtype(dtype: DtypeLike) -> bool:
    """
    Check if dtype represents quantized weights.

    Args:
        dtype: String dtype name or MLX dtype.

    Returns:
        True if quantized, False otherwise.
    """
    if isinstance(dtype, str):
        dtype_lower = dtype.lower()
        return any(
            q in dtype_lower for q in ["q4", "q8", "int4", "int8", "quantized"]
        )

    return False
