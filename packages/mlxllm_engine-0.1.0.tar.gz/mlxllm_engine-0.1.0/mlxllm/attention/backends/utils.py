# SPDX-License-Identifier: Apache-2.0
"""Attention backend utilities for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    from mlxllm.attention.backends.abstract import AttentionMetadata

# Sentinel value for padding in slot mappings
PAD_SLOT_ID = -1


def compute_attention_scale(head_dim: int, scale: float | None = None) -> float:
    """
    Compute attention scaling factor.

    Args:
        head_dim: Dimension of attention head.
        scale: Optional custom scale. If None, uses 1/sqrt(head_dim).

    Returns:
        Attention scale factor.
    """
    if scale is not None:
        return scale
    return 1.0 / (head_dim**0.5)


def repeat_kv(x: mx.array, n_rep: int) -> mx.array:
    """
    Repeat key/value tensors for Grouped Query Attention (GQA).

    This is used when num_query_heads > num_kv_heads (GQA/MQA).
    Each KV head is repeated n_rep times to match query heads.

    Args:
        x: Input tensor [batch, seq_len, num_kv_heads, head_dim].
        n_rep: Number of repetitions.

    Returns:
        Repeated tensor [batch, seq_len, num_kv_heads * n_rep, head_dim].
    """
    if n_rep == 1:
        return x

    batch, seq_len, num_kv_heads, head_dim = x.shape

    # Expand and reshape to repeat each KV head n_rep times
    # [batch, seq_len, num_kv_heads, 1, head_dim] -> [batch, seq_len, num_kv_heads, n_rep, head_dim]
    x = mx.expand_dims(x, axis=3)
    x = mx.broadcast_to(x, [batch, seq_len, num_kv_heads, n_rep, head_dim])

    # Merge num_kv_heads and n_rep dimensions
    x = mx.reshape(x, [batch, seq_len, num_kv_heads * n_rep, head_dim])

    return x


def create_causal_mask(
    seq_len: int, dtype: mx.Dtype = mx.float32
) -> mx.array:
    """
    Create causal attention mask.

    Args:
        seq_len: Sequence length.
        dtype: Data type for mask.

    Returns:
        Causal mask [seq_len, seq_len] with -inf for masked positions.
    """
    # Create lower triangular matrix
    mask = mx.tril(mx.ones([seq_len, seq_len], dtype=dtype))

    # Convert to attention mask: 0 -> -inf, 1 -> 0
    mask = mx.where(mask == 0, float("-inf"), 0.0)

    return mask.astype(dtype)


def create_alibi_slopes(num_heads: int) -> mx.array:
    """
    Create ALiBi (Attention with Linear Biases) slopes.

    ALiBi is used in models like BLOOM and MPT for length extrapolation.

    Args:
        num_heads: Number of attention heads.

    Returns:
        ALiBi slopes [num_heads].
    """
    import math

    # Calculate slopes: powers of 2^(-8/n) where n is number of heads
    def get_slopes(n: int) -> list[float]:
        def get_slopes_power_of_2(n: int) -> list[float]:
            start = 2 ** (-(2 ** -(math.log2(n) - 3)))
            ratio = start
            return [start * ratio**i for i in range(n)]

        # If n is power of 2, use direct formula
        if math.log2(n).is_integer():
            return get_slopes_power_of_2(n)

        # Otherwise, interpolate
        closest_power_of_2 = 2 ** math.floor(math.log2(n))
        slopes = (
            get_slopes_power_of_2(closest_power_of_2)
            + get_slopes_power_of_2(2 * closest_power_of_2)[0::2][
                : n - closest_power_of_2
            ]
        )
        return slopes

    slopes = get_slopes(num_heads)
    return mx.array(slopes, dtype=mx.float32)


def apply_alibi_bias(
    attn_scores: mx.array,
    alibi_slopes: mx.array,
    seq_len_q: int,
    seq_len_k: int,
) -> mx.array:
    """
    Apply ALiBi bias to attention scores.

    Args:
        attn_scores: Attention scores [batch, num_heads, seq_len_q, seq_len_k].
        alibi_slopes: ALiBi slopes [num_heads] (positive values like 0.5, 0.25, ...).
        seq_len_q: Query sequence length.
        seq_len_k: Key sequence length.

    Returns:
        Attention scores with ALiBi bias applied.
    """
    # Create position distance matrix
    # distance[i,j] = k_pos[j] - q_pos[i]
    # Negative for past (key earlier than query), positive for future (key later than query)
    q_positions = mx.arange(seq_len_q, dtype=mx.float32).reshape(-1, 1)
    k_positions = mx.arange(seq_len_k, dtype=mx.float32).reshape(1, -1)
    distance = k_positions - q_positions

    # Apply slopes * distance:
    # For past (distance < 0): slopes * negative = negative (penalty for distant past)
    # For future (distance > 0): slopes * positive = positive (but will be masked by causal mask)
    # Wait, we want future to be NEGATIVE! So we need to negate.
    # Actually: -slopes * distance
    # For past (distance < 0): -slopes * negative = positive
    # For future (distance > 0): -slopes * positive = negative ✓
    # For diagonal (distance = 0): bias = 0 ✓
    alibi_bias = (-alibi_slopes).reshape(-1, 1, 1) * distance.reshape(
        1, seq_len_q, seq_len_k
    )

    # Add bias to attention scores
    # attn_scores: [batch, num_heads, seq_len_q, seq_len_k]
    # alibi_bias: [num_heads, seq_len_q, seq_len_k]
    return attn_scores + alibi_bias


def validate_metadata(metadata: AttentionMetadata) -> None:
    """
    Validate attention metadata for consistency.

    Args:
        metadata: Attention metadata to validate.

    Raises:
        ValueError: If metadata is invalid.
    """
    from mlxllm.attention.backends.abstract import AttentionType

    # Check sequence lengths match
    if len(metadata.seq_lens) == 0:
        raise ValueError("seq_lens cannot be empty")

    if metadata.max_seq_len != max(metadata.seq_lens):
        raise ValueError(
            f"max_seq_len {metadata.max_seq_len} doesn't match actual max "
            f"{max(metadata.seq_lens)}"
        )

    # Validate decode-specific metadata
    if metadata.attn_type == AttentionType.DECODE:
        if metadata.context_lens is None:
            raise ValueError("context_lens required for decode attention")

        if metadata.block_tables is None:
            raise ValueError("block_tables required for decode attention")

        if len(metadata.context_lens) != len(metadata.seq_lens):
            raise ValueError(
                f"context_lens length {len(metadata.context_lens)} doesn't match "
                f"seq_lens length {len(metadata.seq_lens)}"
            )

        if len(metadata.block_tables) != len(metadata.seq_lens):
            raise ValueError(
                f"block_tables length {len(metadata.block_tables)} doesn't match "
                f"seq_lens length {len(metadata.seq_lens)}"
            )

    # Validate head dimensions
    if metadata.num_query_heads > 0 and metadata.num_kv_heads > 0:
        if metadata.num_query_heads % metadata.num_kv_heads != 0:
            raise ValueError(
                f"num_query_heads {metadata.num_query_heads} must be divisible by "
                f"num_kv_heads {metadata.num_kv_heads} for GQA"
            )

    if metadata.head_dim > 0 and metadata.head_dim not in [
        64,
        80,
        96,
        112,
        128,
        256,
    ]:
        import warnings

        warnings.warn(
            f"head_dim {metadata.head_dim} may not be optimized. "
            "Recommended sizes: 64, 80, 96, 112, 128, 256"
        )


def get_num_kv_heads_per_query_head(
    num_query_heads: int, num_kv_heads: int
) -> int:
    """
    Calculate number of KV heads per query head for GQA.

    Args:
        num_query_heads: Number of query heads.
        num_kv_heads: Number of key/value heads.

    Returns:
        Number of query heads per KV head.

    Raises:
        ValueError: If heads are not evenly divisible.
    """
    if num_query_heads % num_kv_heads != 0:
        raise ValueError(
            f"num_query_heads ({num_query_heads}) must be divisible by "
            f"num_kv_heads ({num_kv_heads})"
        )

    return num_query_heads // num_kv_heads


def create_block_tables_from_seq_lens(
    seq_lens: list[int], block_size: int, num_blocks: int
) -> list[list[int]]:
    """
    Create block tables for paged attention from sequence lengths.

    Args:
        seq_lens: List of sequence lengths.
        block_size: Size of each block.
        num_blocks: Total number of available blocks.

    Returns:
        Block tables where block_tables[i] is list of block IDs for sequence i.

    Raises:
        ValueError: If not enough blocks available.
    """
    block_tables = []
    next_block_id = 0

    for seq_len in seq_lens:
        # Calculate number of blocks needed for this sequence
        num_blocks_needed = (seq_len + block_size - 1) // block_size

        if next_block_id + num_blocks_needed > num_blocks:
            raise ValueError(
                f"Not enough blocks: need {next_block_id + num_blocks_needed}, "
                f"have {num_blocks}"
            )

        # Assign contiguous blocks
        block_ids = list(range(next_block_id, next_block_id + num_blocks_needed))
        block_tables.append(block_ids)

        next_block_id += num_blocks_needed

    return block_tables


def create_slot_mapping(
    seq_lens: list[int], block_tables: list[list[int]], block_size: int
) -> list[tuple[int, int]]:
    """
    Create slot mapping for KV cache updates.

    Maps each token position to (block_id, offset_in_block).

    Args:
        seq_lens: List of sequence lengths.
        block_tables: Block tables for each sequence.
        block_size: Size of each block.

    Returns:
        List of (block_id, offset) tuples for each token position.
    """
    slot_mapping = []

    for seq_idx, seq_len in enumerate(seq_lens):
        blocks = block_tables[seq_idx]

        for pos in range(seq_len):
            block_idx = pos // block_size
            offset = pos % block_size

            if block_idx >= len(blocks):
                # Padding position
                slot_mapping.append((PAD_SLOT_ID, 0))
            else:
                block_id = blocks[block_idx]
                slot_mapping.append((block_id, offset))

    return slot_mapping


__all__ = [
    "PAD_SLOT_ID",
    "compute_attention_scale",
    "repeat_kv",
    "create_causal_mask",
    "create_alibi_slopes",
    "apply_alibi_bias",
    "validate_metadata",
    "get_num_kv_heads_per_query_head",
    "create_block_tables_from_seq_lens",
    "create_slot_mapping",
]
