# SPDX-License-Identifier: Apache-2.0
"""Attention backend registry for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.attention.backends.abstract import AttentionBackend

if TYPE_CHECKING:
    pass


# Registry of available backends (populated lazily to avoid circular imports)
_BACKEND_REGISTRY: dict[str, type[AttentionBackend]] = {}
_REGISTRY_INITIALIZED = False


def _ensure_registry_initialized() -> None:
    """Lazily initialize the backend registry to avoid circular imports."""
    global _REGISTRY_INITIALIZED

    if _REGISTRY_INITIALIZED:
        return

    # Import backends only when first accessed
    from mlxllm.attention.ops.metal_unified_attention import (
        MetalAttentionBackend,
        MetalFlashAttentionBackend,
    )

    _BACKEND_REGISTRY["metal"] = MetalAttentionBackend
    _BACKEND_REGISTRY["flash_metal"] = MetalFlashAttentionBackend
    _REGISTRY_INITIALIZED = True


def register_backend(name: str, backend_cls: type[AttentionBackend]) -> None:
    """
    Register a custom attention backend.

    Args:
        name: Backend name.
        backend_cls: Backend class (must inherit from AttentionBackend).
    """
    if not issubclass(backend_cls, AttentionBackend):
        raise TypeError("Backend class must inherit from AttentionBackend")

    _BACKEND_REGISTRY[name] = backend_cls


def get_backend(name: str) -> type[AttentionBackend]:
    """
    Get attention backend by name.

    Args:
        name: Backend name.

    Returns:
        Backend class.

    Raises:
        ValueError: If backend not found.
    """
    _ensure_registry_initialized()

    if name not in _BACKEND_REGISTRY:
        available = ", ".join(_BACKEND_REGISTRY.keys())
        raise ValueError(
            f"Unknown attention backend: {name}. Available backends: {available}"
        )

    return _BACKEND_REGISTRY[name]


def get_available_backends() -> list[str]:
    """
    Get list of available backend names.

    Returns:
        List of backend names.
    """
    _ensure_registry_initialized()
    return list(_BACKEND_REGISTRY.keys())


def create_backend(name: str = "auto") -> AttentionBackend:
    """
    Create attention backend instance.

    Args:
        name: Backend name or "auto" for automatic selection.

    Returns:
        Attention backend instance.
    """
    _ensure_registry_initialized()

    if name == "auto":
        # Auto-select best available backend
        from mlxllm.attention.ops.metal_unified_attention import (
            MetalFlashAttentionBackend,
            MetalAttentionBackend,
        )

        if MetalFlashAttentionBackend.is_available():
            name = "flash_metal"
        elif MetalAttentionBackend.is_available():
            name = "metal"
        else:
            raise RuntimeError("No attention backend available on this platform")

    backend_cls = get_backend(name)

    if not backend_cls.is_available():
        raise RuntimeError(f"Backend {name} is not available on this platform")

    return backend_cls()
