"""Metal backend for attention operations.

This backend uses Metal-accelerated C++ operations for maximum performance
on Apple Silicon devices.
"""

from typing import List, Optional, Tuple, Type
from enum import Enum

import mlx.core as mx
import mlx.nn as nn

from mlxllm.attention.backends.abstract import AttentionBackend, AttentionMetadata, AttentionType
from mlxllm.attention.backends.registry import register_backend
from mlxllm import metal_ops


class MetalAttentionBackend(AttentionBackend):
    """Metal-accelerated attention backend for Apple Silicon.

    This backend leverages Metal shaders and optimized C++ kernels for
    high-performance attention computation on M-series chips.
    """

    @staticmethod
    def get_name() -> str:
        """Return backend name."""
        return "metal"

    @classmethod
    def is_available(cls) -> bool:
        """Check if Metal backend is available."""
        try:
            return metal_ops.is_metal_available()
        except ImportError:
            return False

    @staticmethod
    def get_supported_head_sizes() -> List[int]:
        """Return list of supported head sizes."""
        # Metal backend supports common transformer head sizes
        return [64, 80, 96, 112, 128, 192, 256]

    @classmethod
    def get_kv_cache_dtype(cls) -> Optional[mx.Dtype]:
        """Return KV cache data type if different from model dtype."""
        # Use float16 for KV cache on Metal for memory efficiency
        return mx.float16

    @classmethod
    def get_impl_cls(cls) -> Type["MetalAttentionImpl"]:
        """Return implementation class."""
        return MetalAttentionImpl

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """Prefill attention computation (for prompt processing)."""
        return self.forward(query, key, value, None, metadata)

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: Optional[Tuple[mx.array, mx.array]],
        metadata: AttentionMetadata,
    ) -> mx.array:
        """Decode attention computation (for token generation)."""
        # For decode, we typically have a single query token
        # Extract key and value from kv_cache tuple if provided
        key_cache = kv_cache[0] if kv_cache is not None else None
        value_cache = kv_cache[1] if kv_cache is not None else None
        # Use the cached keys and values
        batch_size, num_heads, _, head_dim = query.shape

        # This is a simplified implementation
        # In production, you'd use paged attention for decode
        return self.forward(query, key_cache, value_cache, None, metadata)

    def update_kv_cache(
        self,
        key: mx.array,
        value: mx.array,
        kv_cache: Tuple[mx.array, mx.array],
        attn_metadata: AttentionMetadata,
    ) -> Tuple[mx.array, mx.array]:
        """Update KV cache with new key/value pairs."""
        key_cache, value_cache = kv_cache

        # Simple concatenation for now
        # In production, you'd use block-wise updates
        updated_key = mx.concatenate([key_cache, key], axis=2)
        updated_value = mx.concatenate([value_cache, value], axis=2)

        return updated_key, updated_value

    def forward(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        kv_cache: Optional[Tuple[mx.array, mx.array]],
        attn_metadata: AttentionMetadata,
        k_scale: float = 1.0,
        v_scale: float = 1.0,
        attn_bias: Optional[mx.array] = None,
    ) -> mx.array:
        """Forward pass using Metal-accelerated operations.

        Args:
            query: Query tensor [batch_size, num_heads, seq_len, head_dim]
            key: Key tensor [batch_size, num_kv_heads, seq_len, head_dim]
            value: Value tensor [batch_size, num_kv_heads, seq_len, head_dim]
            kv_cache: Optional KV cache tuple
            attn_metadata: Attention metadata
            k_scale: Key scaling factor
            v_scale: Value scaling factor
            attn_bias: Optional attention bias

        Returns:
            Attention output [batch_size, num_heads, seq_len, head_dim]
        """
        batch_size, num_heads, seq_len, head_dim = query.shape
        num_kv_heads = key.shape[1] if key.ndim > 1 else attn_metadata.num_kv_heads

        # Use metadata if dimensions not available from tensors
        if attn_metadata.num_query_heads > 0:
            num_heads = attn_metadata.num_query_heads
        if attn_metadata.head_dim > 0:
            head_dim = attn_metadata.head_dim

        # Handle grouped query attention
        if num_kv_heads != num_heads:
            # Repeat KV heads for GQA
            key = self._repeat_kv(key, num_heads // num_kv_heads)
            value = self._repeat_kv(value, num_heads // num_kv_heads)

        # Apply scaling if needed
        if k_scale != 1.0:
            key = key * k_scale
        if v_scale != 1.0:
            value = value * v_scale

        # Use scale from metadata or compute it
        scale_value = attn_metadata.scale if attn_metadata.scale != 1.0 else 1.0 / mx.sqrt(float(head_dim))
        # Ensure scale is a float, not an mx.array
        if isinstance(scale_value, mx.array):
            scale = float(scale_value.item())
        else:
            scale = float(scale_value)

        # Determine if this is causal attention based on attention type
        is_causal = attn_metadata.attn_type in (AttentionType.DECODE, AttentionType.PREFILL)

        # Check if we should use flash attention
        if self._should_use_flash_attention(attn_metadata.max_seq_len):
            # Use flash attention for long sequences
            output = metal_ops.flash_attention(
                query=query,
                key=key,
                value=value,
                is_causal=is_causal,
                scale=scale,
            )
        else:
            # Use standard scaled dot product attention
            output = self._scaled_dot_product_attention(
                query=query,
                key=key,
                value=value,
                attn_mask=attn_metadata.attn_mask,
                is_causal=is_causal,
                scale=scale,
                alibi_slopes=attn_metadata.alibi_slopes,
            )

        return output

    def _repeat_kv(self, hidden_states: mx.array, n_rep: int) -> mx.array:
        """Repeat key/value heads for grouped query attention."""
        if n_rep == 1:
            return hidden_states

        batch, num_kv_heads, seq_len, head_dim = hidden_states.shape

        # Expand and repeat
        hidden_states = mx.expand_dims(hidden_states, 2)
        hidden_states = mx.tile(hidden_states, [1, 1, n_rep, 1, 1])
        hidden_states = mx.reshape(
            hidden_states,
            (batch, num_kv_heads * n_rep, seq_len, head_dim),
        )

        return hidden_states

    def _should_use_flash_attention(self, seq_len: int) -> bool:
        """Determine whether to use flash attention based on sequence length."""
        # Use flash attention for sequences longer than 512
        # This threshold can be tuned based on benchmarking
        return seq_len > 512

    def _scaled_dot_product_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        attn_mask: Optional[mx.array],
        is_causal: bool,
        scale: float,
        alibi_slopes: Optional[mx.array] = None,
    ) -> mx.array:
        """Standard scaled dot product attention with optional ALiBi."""
        # Compute attention scores
        scores = mx.matmul(query, mx.swapaxes(key, -2, -1)) * scale

        # Apply ALiBi positional bias if provided
        if alibi_slopes is not None:
            batch_size, num_heads, seq_len_q, _ = query.shape
            seq_len_k = key.shape[-2]

            # Create position indices
            positions_q = mx.arange(seq_len_q, dtype=mx.float32)
            positions_k = mx.arange(seq_len_k, dtype=mx.float32)

            # Compute relative positions matrix
            relative_positions = positions_q[:, None] - positions_k[None, :]

            # Apply ALiBi slopes to relative positions
            # alibi_slopes shape: [num_heads] or [batch, num_heads]
            if alibi_slopes.ndim == 1:
                alibi_slopes = alibi_slopes[None, :, None, None]
            elif alibi_slopes.ndim == 2:
                alibi_slopes = alibi_slopes[:, :, None, None]

            alibi_bias = alibi_slopes * relative_positions[None, None, :, :]
            scores = scores + alibi_bias

        # Apply causal mask if needed
        if is_causal:
            seq_len_q = query.shape[-2]
            seq_len_k = key.shape[-2]

            # Create causal mask for potentially different query and key lengths
            causal_mask = mx.tril(mx.ones((seq_len_q, seq_len_k)))
            causal_mask = mx.where(causal_mask == 0, -float("inf"), 0.0)

            # Add batch and head dimensions
            causal_mask = mx.expand_dims(mx.expand_dims(causal_mask, 0), 0)
            scores = scores + causal_mask

        # Apply custom attention mask if provided
        if attn_mask is not None:
            scores = scores + attn_mask

        # Softmax
        attn_weights = mx.softmax(scores, axis=-1)

        # Apply dropout if needed (during training)
        # attn_weights = mx.dropout(attn_weights, p=dropout_p) if training else attn_weights

        # Apply to values
        output = mx.matmul(attn_weights, value)

        return output


class MetalAttentionImpl:
    """Implementation class for Metal attention operations.

    This class can be used for more advanced Metal-specific optimizations.
    """

    def __init__(self):
        """Initialize Metal attention implementation."""
        # Check Metal availability
        if not metal_ops.is_metal_available():
            raise RuntimeError("Metal backend not available")

        # Initialize profiling if needed
        self.profiling_enabled = False

    def enable_profiling(self):
        """Enable Metal profiling."""
        metal_ops.set_profiling_enabled(True)
        self.profiling_enabled = True

    def disable_profiling(self):
        """Disable Metal profiling."""
        metal_ops.set_profiling_enabled(False)
        self.profiling_enabled = False

    def get_profiling_stats(self) -> dict:
        """Get Metal profiling statistics."""
        if self.profiling_enabled:
            return metal_ops.get_profiling_stats()
        return {}

    def paged_attention(
        self,
        query: mx.array,
        key_cache: mx.array,
        value_cache: mx.array,
        block_tables: mx.array,
        seq_lens: mx.array,
        num_kv_heads: int,
        scale: float,
        block_size: int = 16,
        alibi_slopes: Optional[mx.array] = None,
    ) -> mx.array:
        """Paged attention using Metal kernels.

        This is for vLLM-style paged attention with block-wise KV cache.
        """
        return metal_ops.paged_attention_v1(
            query=query,
            key_cache=key_cache,
            value_cache=value_cache,
            block_tables=block_tables,
            seq_lens=seq_lens,
            scale=scale,
            num_kv_heads=num_kv_heads,
            block_size=block_size,
            alibi_slopes=alibi_slopes,
        )


# Register the Metal backend
register_backend("metal", MetalAttentionBackend)


__all__ = ["MetalAttentionBackend", "MetalAttentionImpl"]