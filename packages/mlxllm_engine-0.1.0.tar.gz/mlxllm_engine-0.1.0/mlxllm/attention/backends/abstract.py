# SPDX-License-Identifier: Apache-2.0
"""Abstract attention backend interface for MLX-LLM."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import mlx.core as mx


class AttentionType(Enum):
    """Attention computation type."""

    PREFILL = "prefill"  # Initial prompt processing
    DECODE = "decode"  # Token-by-token generation
    CHUNKED_PREFILL = "chunked_prefill"  # Chunked prompt processing


@dataclass
class AttentionMetadata:
    """
    Metadata for attention computation.

    Contains all information needed to execute attention:
    - Sequence information (lengths, block tables)
    - Attention masks
    - KV cache information
    """

    # Attention type
    attn_type: AttentionType

    # Sequence lengths
    seq_lens: list[int]  # Length of each sequence
    max_seq_len: int  # Maximum sequence length in batch

    # Block tables for paged attention
    # block_tables[i] = list of block IDs for sequence i
    block_tables: list[list[int]] | None = None

    # Context lengths (for decode)
    # context_lens[i] = number of tokens already computed for sequence i
    context_lens: list[int] | None = None

    # Slot mapping for KV cache updates
    # Maps token position to (block_id, offset_in_block)
    slot_mapping: list[tuple[int, int]] | None = None

    # Attention mask (optional, for custom masking)
    attn_mask: mx.array | None = None

    # Number of query heads and KV heads (for GQA/MQA)
    num_query_heads: int = 0
    num_kv_heads: int = 0

    # Head dimension
    head_dim: int = 0

    # Block size for paged attention
    block_size: int = 16

    # Scaling factor for attention scores
    scale: float = 1.0

    # Alibi slopes (for models using ALiBi positional encoding)
    alibi_slopes: mx.array | None = None

    # Convenience flags (can be set or derived from attn_type)
    is_prefill: bool = False
    batch_size: int = 0

    def __post_init__(self) -> None:
        """Validate metadata after initialization."""
        if self.attn_type == AttentionType.DECODE:
            if self.context_lens is None:
                raise ValueError("context_lens required for decode attention")
            if self.block_tables is None:
                raise ValueError("block_tables required for decode attention")


class AttentionBackend(ABC):
    """
    Abstract base class for attention backends.

    Attention backends implement the actual attention computation
    using platform-specific optimizations (Metal, CUDA, etc.).
    """

    @abstractmethod
    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Compute attention for prefill phase.

        Args:
            query: Query tensor [batch_size, seq_len, num_heads, head_dim].
            key: Key tensor [batch_size, seq_len, num_kv_heads, head_dim].
            value: Value tensor [batch_size, seq_len, num_kv_heads, head_dim].
            metadata: Attention metadata.

        Returns:
            Attention output [batch_size, seq_len, num_heads, head_dim].
        """
        raise NotImplementedError

    @abstractmethod
    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Compute attention for decode phase using paged KV cache.

        Args:
            query: Query tensor [batch_size, 1, num_heads, head_dim].
            kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
            metadata: Attention metadata with block tables.

        Returns:
            Attention output [batch_size, 1, num_heads, head_dim].
        """
        raise NotImplementedError

    @abstractmethod
    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        """
        Update KV cache with new key/value tensors.

        Args:
            kv_cache: KV cache to update [num_blocks, 2, block_size, num_kv_heads, head_dim].
            key: New keys [batch_size, seq_len, num_kv_heads, head_dim].
            value: New values [batch_size, seq_len, num_kv_heads, head_dim].
            metadata: Attention metadata with slot mapping.
        """
        raise NotImplementedError

    @abstractmethod
    def get_supported_head_sizes(self) -> list[int]:
        """
        Get list of supported head dimensions.

        Returns:
            List of supported head sizes (e.g., [64, 128, 256]).
        """
        raise NotImplementedError

    @abstractmethod
    def get_name(self) -> str:
        """
        Get backend name.

        Returns:
            Backend name (e.g., "metal", "flash_metal").
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def is_available(cls) -> bool:
        """
        Check if backend is available on current platform.

        Returns:
            True if backend can be used.
        """
        raise NotImplementedError

    def __repr__(self) -> str:
        """String representation."""
        return f"{self.__class__.__name__}(name={self.get_name()})"
