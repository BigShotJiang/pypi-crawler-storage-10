# SPDX-License-Identifier: Apache-2.0
"""KV cache sharing utilities for MLX-LLM.

Implements prefix caching and KV cache sharing optimizations
for efficient handling of repeated prompts.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


@dataclass
class KVCacheBlock:
    """Represents a block of cached KV states."""

    block_id: int
    token_ids: list[int]
    key: mx.array  # [block_size, num_kv_heads, head_dim]
    value: mx.array  # [block_size, num_kv_heads, head_dim]
    ref_count: int = 1
    last_accessed: float = field(default_factory=lambda: 0.0)

    def get_hash(self) -> int:
        """Get hash of token sequence for this block."""
        return hash(tuple(self.token_ids))


@dataclass
class PrefixCacheEntry:
    """Entry in the prefix cache."""

    prefix_tokens: tuple[int, ...]
    block_ids: list[int]  # List of KV cache block IDs
    num_tokens: int
    ref_count: int = 1
    last_accessed: float = field(default_factory=lambda: 0.0)


class KVCacheSharingManager:
    """
    Manages KV cache sharing and prefix caching.

    This enables efficient reuse of KV cache for repeated prompts
    (e.g., system prompts, few-shot examples).
    """

    def __init__(
        self,
        block_size: int = 16,
        max_cache_blocks: int = 1024,
    ) -> None:
        """
        Initialize KV cache sharing manager.

        Args:
            block_size: Size of each cache block (number of tokens).
            max_cache_blocks: Maximum number of blocks to cache.
        """
        self.block_size = block_size
        self.max_cache_blocks = max_cache_blocks

        # Prefix cache: maps prefix tokens to cache entry
        self.prefix_cache: dict[tuple[int, ...], PrefixCacheEntry] = {}

        # Block storage: maps block_id to KVCacheBlock
        self.blocks: dict[int, KVCacheBlock] = {}

        # Block hash index for deduplication
        self.block_hash_index: dict[int, list[int]] = {}

        # Next available block ID
        self._next_block_id = 0

        # Statistics
        self.cache_hits = 0
        self.cache_misses = 0

    def find_prefix_match(
        self,
        token_ids: list[int],
        min_prefix_length: int = 8,
    ) -> tuple[list[int], int] | None:
        """
        Find longest matching prefix in cache.

        Args:
            token_ids: Input token sequence.
            min_prefix_length: Minimum prefix length to consider.

        Returns:
            Tuple of (matched_block_ids, num_matched_tokens) or None.
        """
        # Try progressively shorter prefixes
        for prefix_len in range(len(token_ids), min_prefix_length - 1, -1):
            prefix = tuple(token_ids[:prefix_len])

            if prefix in self.prefix_cache:
                entry = self.prefix_cache[prefix]
                self.cache_hits += 1
                entry.ref_count += 1
                return entry.block_ids, entry.num_tokens

        self.cache_misses += 1
        return None

    def add_prefix(
        self,
        token_ids: list[int],
        key_states: mx.array,
        value_states: mx.array,
    ) -> list[int]:
        """
        Add a new prefix to the cache.

        Args:
            token_ids: Token sequence.
            key_states: Key states [seq_len, num_kv_heads, head_dim].
            value_states: Value states [seq_len, num_kv_heads, head_dim].

        Returns:
            List of block IDs for this prefix.
        """
        seq_len = len(token_ids)
        num_blocks = (seq_len + self.block_size - 1) // self.block_size

        block_ids = []

        for i in range(num_blocks):
            start_idx = i * self.block_size
            end_idx = min((i + 1) * self.block_size, seq_len)

            # Extract block tokens and states
            block_tokens = token_ids[start_idx:end_idx]
            block_key = key_states[start_idx:end_idx]
            block_value = value_states[start_idx:end_idx]

            # Check if this block already exists (deduplication)
            block_hash = hash(tuple(block_tokens))
            existing_block_id = self._find_duplicate_block(block_hash, block_tokens)

            if existing_block_id is not None:
                # Reuse existing block
                block_ids.append(existing_block_id)
                self.blocks[existing_block_id].ref_count += 1
            else:
                # Create new block
                block_id = self._allocate_block()
                block = KVCacheBlock(
                    block_id=block_id,
                    token_ids=block_tokens,
                    key=block_key,
                    value=block_value,
                )

                self.blocks[block_id] = block
                block_ids.append(block_id)

                # Add to hash index
                if block_hash not in self.block_hash_index:
                    self.block_hash_index[block_hash] = []
                self.block_hash_index[block_hash].append(block_id)

        # Add to prefix cache
        prefix = tuple(token_ids)
        self.prefix_cache[prefix] = PrefixCacheEntry(
            prefix_tokens=prefix,
            block_ids=block_ids,
            num_tokens=seq_len,
        )

        return block_ids

    def get_blocks(self, block_ids: list[int]) -> tuple[mx.array, mx.array]:
        """
        Retrieve KV states for given block IDs.

        Args:
            block_ids: List of block IDs.

        Returns:
            Tuple of (keys, values) concatenated across blocks.
        """
        if not block_ids:
            raise ValueError("No block IDs provided")

        keys = []
        values = []

        for block_id in block_ids:
            if block_id not in self.blocks:
                raise ValueError(f"Block {block_id} not found in cache")

            block = self.blocks[block_id]
            keys.append(block.key)
            values.append(block.value)

        # Concatenate along sequence dimension
        combined_keys = mx.concatenate(keys, axis=0)
        combined_values = mx.concatenate(values, axis=0)

        return combined_keys, combined_values

    def release_blocks(self, block_ids: list[int]) -> None:
        """
        Release reference to blocks.

        Args:
            block_ids: List of block IDs to release.
        """
        for block_id in block_ids:
            if block_id in self.blocks:
                block = self.blocks[block_id]
                block.ref_count -= 1

                # Remove block if no longer referenced
                if block.ref_count <= 0:
                    self._free_block(block_id)

    def evict_lru(self, num_blocks: int = 1) -> int:
        """
        Evict least recently used blocks.

        Args:
            num_blocks: Number of blocks to evict.

        Returns:
            Number of blocks actually evicted.
        """
        # Sort blocks by last accessed time
        evictable_blocks = [
            (block.last_accessed, block_id)
            for block_id, block in self.blocks.items()
            if block.ref_count == 0
        ]

        evictable_blocks.sort()

        evicted = 0
        for _, block_id in evictable_blocks[:num_blocks]:
            self._free_block(block_id)
            evicted += 1

        return evicted

    def get_cache_stats(self) -> dict[str, int | float]:
        """Get cache statistics."""
        total_requests = self.cache_hits + self.cache_misses
        hit_rate = self.cache_hits / total_requests if total_requests > 0 else 0.0

        return {
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "hit_rate": hit_rate,
            "num_cached_blocks": len(self.blocks),
            "num_cached_prefixes": len(self.prefix_cache),
            "total_refs": sum(b.ref_count for b in self.blocks.values()),
        }

    def _allocate_block(self) -> int:
        """Allocate a new block ID."""
        # If at capacity, evict LRU blocks
        if len(self.blocks) >= self.max_cache_blocks:
            self.evict_lru(num_blocks=1)

        block_id = self._next_block_id
        self._next_block_id += 1
        return block_id

    def _free_block(self, block_id: int) -> None:
        """Free a block."""
        if block_id not in self.blocks:
            return

        block = self.blocks[block_id]

        # Remove from hash index
        block_hash = block.get_hash()
        if block_hash in self.block_hash_index:
            self.block_hash_index[block_hash].remove(block_id)
            if not self.block_hash_index[block_hash]:
                del self.block_hash_index[block_hash]

        # Remove block
        del self.blocks[block_id]

    def _find_duplicate_block(
        self,
        block_hash: int,
        token_ids: list[int],
    ) -> int | None:
        """
        Find existing block with same tokens.

        Args:
            block_hash: Hash of token sequence.
            token_ids: Token sequence.

        Returns:
            Block ID if found, None otherwise.
        """
        if block_hash not in self.block_hash_index:
            return None

        # Check all blocks with this hash
        for block_id in self.block_hash_index[block_hash]:
            block = self.blocks[block_id]
            if block.token_ids == token_ids:
                return block_id

        return None


def compute_prefix_overlap(
    tokens_a: list[int],
    tokens_b: list[int],
) -> int:
    """
    Compute length of common prefix between two token sequences.

    Args:
        tokens_a: First token sequence.
        tokens_b: Second token sequence.

    Returns:
        Length of common prefix.
    """
    min_len = min(len(tokens_a), len(tokens_b))

    overlap = 0
    for i in range(min_len):
        if tokens_a[i] == tokens_b[i]:
            overlap += 1
        else:
            break

    return overlap


def merge_kv_caches(
    kv_cache_a: mx.array,
    kv_cache_b: mx.array,
    split_point: int,
) -> mx.array:
    """
    Merge two KV caches at a split point.

    Useful for combining cached prefix with new generation.

    Args:
        kv_cache_a: First KV cache [seq_len_a, num_heads, head_dim].
        kv_cache_b: Second KV cache [seq_len_b, num_heads, head_dim].
        split_point: Position to split (tokens from A up to this point, then all of B).

    Returns:
        Merged KV cache.
    """
    # Take prefix from cache A (up to split_point)
    prefix = kv_cache_a[:split_point]

    # Take all of cache B (B represents new/continuation content)
    suffix = kv_cache_b

    # Concatenate
    merged = mx.concatenate([prefix, suffix], axis=0)

    return merged
