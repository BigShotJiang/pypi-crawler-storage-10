# SPDX-License-Identifier: Apache-2.0
"""Flash Attention utilities for MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


@dataclass
class FlashAttentionConfig:
    """Configuration for Flash Attention."""

    block_size_q: int = 128
    block_size_k: int = 128
    num_splits: int = 1
    use_causal_mask: bool = True
    scale: float | None = None


def flash_attention_prefill(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    config: FlashAttentionConfig | None = None,
    attn_mask: mx.array | None = None,
) -> mx.array:
    """
    Flash attention optimized prefill.

    Uses MLX's fast.scaled_dot_product_attention when available,
    otherwise falls back to chunked computation.

    Args:
        query: Query [batch, seq_len_q, num_heads, head_dim].
        key: Key [batch, seq_len_k, num_kv_heads, head_dim].
        value: Value [batch, seq_len_k, num_kv_heads, head_dim].
        config: Flash attention configuration.
        attn_mask: Optional attention mask.

    Returns:
        Attention output [batch, seq_len_q, num_heads, head_dim].
    """
    if config is None:
        config = FlashAttentionConfig()

    batch_size, seq_len_q, num_heads, head_dim = query.shape
    _, seq_len_k, num_kv_heads, _ = key.shape

    # Compute scale
    scale = config.scale
    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    # Handle GQA/MQA: repeat KV heads if needed
    if num_kv_heads != num_heads:
        from mlxllm.attention.ops.common import repeat_kv
        n_rep = num_heads // num_kv_heads
        key = repeat_kv(key, n_rep)
        value = repeat_kv(value, n_rep)

    # Transpose for attention: [batch, seq, heads, dim] -> [batch, heads, seq, dim]
    query = mx.transpose(query, [0, 2, 1, 3])
    key = mx.transpose(key, [0, 2, 1, 3])
    value = mx.transpose(value, [0, 2, 1, 3])

    # Try to use MLX fast attention if available
    try:
        import mlx.fast as mlx_fast

        output = mlx_fast.scaled_dot_product_attention(
            query, key, value,
            scale=scale,
            mask=attn_mask,
        )
    except (ImportError, AttributeError):
        # Fallback to standard attention
        from mlxllm.attention.ops.common import scaled_dot_product_attention

        output = scaled_dot_product_attention(
            query, key, value,
            attn_mask=attn_mask,
            is_causal=config.use_causal_mask,
            scale=scale,
        )

    # Transpose back: [batch, heads, seq, dim] -> [batch, seq, heads, dim]
    output = mx.transpose(output, [0, 2, 1, 3])

    return output


def chunked_flash_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    chunk_size: int = 512,
    scale: float | None = None,
) -> mx.array:
    """
    Flash attention with chunked computation for long sequences.

    This splits long sequences into chunks to reduce memory usage.

    Args:
        query: Query [batch, seq_len_q, num_heads, head_dim].
        key: Key [batch, seq_len_k, num_kv_heads, head_dim].
        value: Value [batch, seq_len_k, num_kv_heads, head_dim].
        chunk_size: Size of each chunk (default 512 tokens).
        scale: Attention scale factor.

    Returns:
        Attention output [batch, seq_len_q, num_heads, head_dim].
    """
    batch_size, seq_len_q, num_heads, head_dim = query.shape
    seq_len_k = key.shape[1]

    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    # If sequence fits in one chunk, use standard flash attention
    if seq_len_q <= chunk_size and seq_len_k <= chunk_size:
        config = FlashAttentionConfig(scale=scale)
        return flash_attention_prefill(query, key, value, config=config)

    # Split query into chunks
    num_chunks = (seq_len_q + chunk_size - 1) // chunk_size
    outputs = []

    for i in range(num_chunks):
        start_idx = i * chunk_size
        end_idx = min((i + 1) * chunk_size, seq_len_q)

        # Extract query chunk
        query_chunk = query[:, start_idx:end_idx, :, :]

        # Compute attention for this chunk (attending to all keys)
        config = FlashAttentionConfig(scale=scale)
        output_chunk = flash_attention_prefill(
            query_chunk, key, value,
            config=config
        )

        outputs.append(output_chunk)

    # Concatenate chunks
    output = mx.concatenate(outputs, axis=1)

    return output


def compute_alibi_bias(
    seq_len_q: int,
    seq_len_k: int,
    num_heads: int,
    alibi_slopes: mx.array | None = None,
) -> mx.array:
    """
    Compute ALiBi (Attention with Linear Biases) bias.

    Used in models like BLOOM, MPT.

    Args:
        seq_len_q: Query sequence length.
        seq_len_k: Key sequence length.
        num_heads: Number of attention heads.
        alibi_slopes: Optional pre-computed slopes [num_heads].

    Returns:
        ALiBi bias [1, num_heads, seq_len_q, seq_len_k].
    """
    if alibi_slopes is None:
        # Compute slopes: geometric sequence (positive values)
        # For num_heads=8: [2^-1, 2^-2, 2^-3, ..., 2^-8] = [0.5, 0.25, 0.125, ...]
        alibi_slopes = mx.power(
            2.0,
            -mx.arange(1, num_heads + 1, dtype=mx.float32)
        )

    # Position distance matrix
    # [seq_len_q, seq_len_k]
    # distance[i,j] = k_pos[j] - q_pos[i]
    # Negative for past (key earlier than query), positive for future (key later than query)
    q_positions = mx.arange(seq_len_q)[:, None]
    k_positions = mx.arange(seq_len_k)[None, :]
    distance = k_positions - q_positions

    # Apply negative slopes to penalize distance
    # (-slopes) * distance:
    #   - When distance < 0 (past): negative * negative = positive
    #   - When distance > 0 (future): negative * positive = negative ✓
    #   - When distance = 0 (diagonal): bias = 0 ✓
    # [1, num_heads, seq_len_q, seq_len_k]
    alibi_bias = mx.expand_dims(distance, axis=(0, 1)) * mx.reshape(
        -alibi_slopes, [1, num_heads, 1, 1]
    )

    return alibi_bias


def get_optimal_block_size(
    seq_len: int,
    max_block_size: int = 128,
    min_block_size: int = 16,
) -> int:
    """
    Determine optimal block size for flash attention.

    Args:
        seq_len: Sequence length.
        max_block_size: Maximum allowed block size.
        min_block_size: Minimum allowed block size.

    Returns:
        Optimal block size (power of 2).
    """
    # Start with max block size
    block_size = max_block_size

    # If sequence is smaller, reduce block size
    while block_size > min_block_size and seq_len < block_size * 2:
        block_size //= 2

    return block_size


def prepare_flash_attention_mask(
    seq_len_q: int,
    seq_len_k: int,
    is_causal: bool = True,
    sliding_window: int | None = None,
) -> mx.array | None:
    """
    Prepare attention mask for flash attention.

    Args:
        seq_len_q: Query sequence length.
        seq_len_k: Key sequence length.
        is_causal: Whether to use causal mask.
        sliding_window: Optional sliding window size.

    Returns:
        Attention mask [seq_len_q, seq_len_k] or None.
    """
    if not is_causal and sliding_window is None:
        return None

    from mlxllm.attention.ops.common import get_attention_mask

    return get_attention_mask(
        seq_len=max(seq_len_q, seq_len_k),
        sliding_window=sliding_window,
        is_causal=is_causal,
    )[:seq_len_q, :seq_len_k]


def compute_attention_stats(
    attention_weights: mx.array,
) -> dict[str, float]:
    """
    Compute statistics about attention patterns.

    Useful for debugging and analysis.

    Args:
        attention_weights: Attention weights [batch, num_heads, seq_len_q, seq_len_k].

    Returns:
        Dictionary of statistics.
    """
    # Compute entropy (measure of attention distribution)
    # Higher entropy = more diffuse attention
    epsilon = 1e-10
    log_weights = mx.log(attention_weights + epsilon)
    entropy = -mx.sum(attention_weights * log_weights, axis=-1)

    # Average across batch and heads
    avg_entropy = float(mx.mean(entropy))

    # Compute sparsity (fraction of near-zero weights)
    threshold = 0.01
    sparsity = float(mx.mean((attention_weights < threshold).astype(mx.float32)))

    # Maximum attention weight per position
    max_attention = float(mx.max(attention_weights))

    # Average attention to most recent token (for causal models)
    last_token_attn = float(mx.mean(attention_weights[:, :, :, -1]))

    return {
        "avg_entropy": avg_entropy,
        "sparsity": sparsity,
        "max_attention": max_attention,
        "last_token_attention": last_token_attn,
    }
