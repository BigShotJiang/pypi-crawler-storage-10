# SPDX-License-Identifier: Apache-2.0
"""Encoder-only attention for MLX-LLM.

Implements bidirectional attention for encoder-only models like BERT, RoBERTa.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass


@dataclass
class EncoderAttentionConfig:
    """Configuration for encoder-only attention."""

    num_heads: int
    head_dim: int
    hidden_size: int
    dropout: float = 0.1
    attention_bias: bool = True
    use_relative_position: bool = False
    max_position_embeddings: int = 512


class EncoderOnlyAttention(nn.Module):
    """
    Bidirectional self-attention for encoder-only models.

    Unlike decoder attention (causal), this allows each token to attend
    to all other tokens in both directions. Used in:
    - BERT, RoBERTa (masked language modeling)
    - DeBERTa (with relative positions)
    - Encoder stack of encoder-decoder models

    Key differences from decoder attention:
    1. No causal mask (bidirectional)
    2. No KV cache (all tokens processed together)
    3. Often uses absolute position embeddings
    """

    def __init__(
        self,
        config: EncoderAttentionConfig,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize encoder attention layer.

        Args:
            config: Encoder attention configuration.
            layer_idx: Layer index in the model.
        """
        super().__init__()

        self.num_heads = config.num_heads
        self.head_dim = config.head_dim
        self.hidden_size = config.hidden_size
        self.layer_idx = layer_idx

        self.embed_dim = self.num_heads * self.head_dim
        self.scale = 1.0 / (self.head_dim ** 0.5)
        self.dropout = config.dropout

        # QKV projection (can be done as single matrix multiply)
        self.qkv_proj = nn.Linear(
            self.hidden_size,
            3 * self.embed_dim,
            bias=config.attention_bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            self.embed_dim,
            self.hidden_size,
            bias=config.attention_bias,
        )

        self.use_relative_position = config.use_relative_position

        # Relative position embeddings (DeBERTa-style)
        if self.use_relative_position:
            self.max_distance = 128
            # Bidirectional: distances from -max_distance to +max_distance
            self.relative_positions_embeddings = mx.random.normal(
                [2 * self.max_distance + 1, self.head_dim]
            )

    def forward(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        return_attention_weights: bool = False,
    ) -> mx.array | tuple[mx.array, mx.array]:
        """
        Forward pass for encoder attention.

        Args:
            hidden_states: Input [batch, seq_len, hidden_size].
            attention_mask: Optional mask [batch, seq_len] (1=keep, 0=mask).
            return_attention_weights: Whether to return attention weights.

        Returns:
            Output [batch, seq_len, hidden_size] or tuple with attention weights.
        """
        batch_size, seq_len, _ = hidden_states.shape

        # Project to QKV
        qkv = self.qkv_proj(hidden_states)

        # Split and reshape
        # [batch, seq_len, 3 * embed_dim] -> 3 x [batch, seq_len, num_heads, head_dim]
        qkv = mx.reshape(qkv, [batch_size, seq_len, 3, self.num_heads, self.head_dim])
        query, key, value = mx.split(qkv, 3, axis=2)

        # Remove extra dimension from split
        query = mx.squeeze(query, 2)
        key = mx.squeeze(key, 2)
        value = mx.squeeze(value, 2)

        # Transpose for attention: [batch, seq_len, num_heads, head_dim]
        #                        -> [batch, num_heads, seq_len, head_dim]
        query = mx.transpose(query, [0, 2, 1, 3])
        key = mx.transpose(key, [0, 2, 1, 3])
        value = mx.transpose(value, [0, 2, 1, 3])

        # Compute attention scores
        # [batch, num_heads, seq_len, seq_len]
        attention_scores = mx.matmul(
            query,
            mx.transpose(key, [0, 1, 3, 2])
        ) * self.scale

        # Add relative position bias if enabled
        if self.use_relative_position:
            position_bias = self._compute_relative_position_bias(seq_len)
            attention_scores = attention_scores + position_bias

        # Apply attention mask if provided
        if attention_mask is not None:
            # Expand mask: [batch, seq_len] -> [batch, 1, 1, seq_len]
            if len(attention_mask.shape) == 2:
                attention_mask = mx.expand_dims(
                    mx.expand_dims(attention_mask, 1), 1
                )
            # Convert to additive mask: 0 -> -inf, 1 -> 0
            attention_mask = (1.0 - attention_mask) * float("-inf")
            attention_scores = attention_scores + attention_mask

        # Softmax
        attention_probs = mx.softmax(attention_scores, axis=-1)

        # Dropout (no-op during inference)
        if self.dropout > 0.0:
            # Dropout not applied during inference
            pass

        # Apply attention to values
        # [batch, num_heads, seq_len, seq_len] @ [batch, num_heads, seq_len, head_dim]
        # -> [batch, num_heads, seq_len, head_dim]
        attention_output = mx.matmul(attention_probs, value)

        # Transpose back: [batch, num_heads, seq_len, head_dim]
        #              -> [batch, seq_len, num_heads, head_dim]
        attention_output = mx.transpose(attention_output, [0, 2, 1, 3])

        # Reshape: [batch, seq_len, num_heads, head_dim] -> [batch, seq_len, embed_dim]
        attention_output = mx.reshape(
            attention_output,
            [batch_size, seq_len, self.embed_dim]
        )

        # Project output
        output = self.o_proj(attention_output)

        if return_attention_weights:
            return output, attention_probs
        return output

    def _compute_relative_position_bias(self, seq_len: int) -> mx.array:
        """
        Compute relative position bias (DeBERTa-style).

        Args:
            seq_len: Sequence length.

        Returns:
            Position bias [1, num_heads, seq_len, seq_len].
        """
        # Position indices
        positions = mx.arange(seq_len)

        # Distance matrix: positions[i] - positions[j]
        # [seq_len, seq_len]
        distances = positions[:, None] - positions[None, :]

        # Clip distances to [-max_distance, max_distance]
        distances = mx.clip(distances, -self.max_distance, self.max_distance)

        # Shift to positive indices [0, 2*max_distance]
        indices = distances + self.max_distance

        # Look up embeddings
        # [seq_len, seq_len, head_dim]
        position_embeddings = self.relative_positions_embeddings[indices]

        # Expand for heads: [1, 1, seq_len, seq_len]
        # In practice, this would be projected per head, but simplified here
        position_bias = mx.mean(position_embeddings, axis=-1, keepdims=True)
        position_bias = mx.transpose(position_bias, [2, 0, 1])
        position_bias = mx.expand_dims(position_bias, 0)

        return position_bias

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        return_attention_weights: bool = False,
    ) -> mx.array | tuple[mx.array, mx.array]:
        """Call forward method."""
        return self.forward(hidden_states, attention_mask, return_attention_weights)


class BidirectionalAttentionWithALiBi(nn.Module):
    """
    Encoder attention with ALiBi (Attention with Linear Biases).

    ALiBi allows models to extrapolate to longer sequences than seen
    during training by using linearly decaying biases based on distance.
    """

    def __init__(
        self,
        config: EncoderAttentionConfig,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize encoder attention with ALiBi.

        Args:
            config: Encoder attention configuration.
            layer_idx: Layer index.
        """
        super().__init__()

        self.num_heads = config.num_heads
        self.head_dim = config.head_dim
        self.hidden_size = config.hidden_size

        self.embed_dim = self.num_heads * self.head_dim
        self.scale = 1.0 / (self.head_dim ** 0.5)

        # QKV projection
        self.qkv_proj = nn.Linear(
            self.hidden_size,
            3 * self.embed_dim,
            bias=config.attention_bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            self.embed_dim,
            self.hidden_size,
            bias=config.attention_bias,
        )

        # Compute ALiBi slopes
        self.alibi_slopes = self._get_alibi_slopes()

    def _get_alibi_slopes(self) -> mx.array:
        """
        Compute ALiBi slopes for each head.

        Returns:
            Slopes [num_heads] as geometric sequence.
        """
        # For bidirectional attention, use symmetric slopes
        n = self.num_heads
        # Geometric sequence: [2^-1, 2^-2, ..., 2^-n]
        slopes = mx.power(2.0, -mx.arange(1, n + 1, dtype=mx.float32))
        return slopes

    def forward(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass with ALiBi.

        Args:
            hidden_states: Input [batch, seq_len, hidden_size].
            attention_mask: Optional mask [batch, seq_len].

        Returns:
            Output [batch, seq_len, hidden_size].
        """
        batch_size, seq_len, _ = hidden_states.shape

        # QKV projection and split
        qkv = self.qkv_proj(hidden_states)
        qkv = mx.reshape(qkv, [batch_size, seq_len, 3, self.num_heads, self.head_dim])
        query, key, value = mx.split(qkv, 3, axis=2)

        query = mx.squeeze(query, 2)
        key = mx.squeeze(key, 2)
        value = mx.squeeze(value, 2)

        # Transpose
        query = mx.transpose(query, [0, 2, 1, 3])
        key = mx.transpose(key, [0, 2, 1, 3])
        value = mx.transpose(value, [0, 2, 1, 3])

        # Attention scores
        attention_scores = mx.matmul(
            query,
            mx.transpose(key, [0, 1, 3, 2])
        ) * self.scale

        # Add ALiBi bias
        alibi_bias = self._compute_alibi_bias(seq_len)
        attention_scores = attention_scores + alibi_bias

        # Apply mask
        if attention_mask is not None:
            if len(attention_mask.shape) == 2:
                attention_mask = mx.expand_dims(
                    mx.expand_dims(attention_mask, 1), 1
                )
            attention_mask = (1.0 - attention_mask) * float("-inf")
            attention_scores = attention_scores + attention_mask

        # Softmax and apply
        attention_probs = mx.softmax(attention_scores, axis=-1)
        attention_output = mx.matmul(attention_probs, value)

        # Reshape and project
        attention_output = mx.transpose(attention_output, [0, 2, 1, 3])
        attention_output = mx.reshape(
            attention_output,
            [batch_size, seq_len, self.embed_dim]
        )
        output = self.o_proj(attention_output)

        return output

    def _compute_alibi_bias(self, seq_len: int) -> mx.array:
        """
        Compute ALiBi bias for bidirectional attention.

        Args:
            seq_len: Sequence length.

        Returns:
            ALiBi bias [1, num_heads, seq_len, seq_len].
        """
        # Position distance matrix (absolute distance for bidirectional)
        positions = mx.arange(seq_len)
        distance = mx.abs(positions[:, None] - positions[None, :])

        # Apply slopes: [1, num_heads, seq_len, seq_len]
        alibi_bias = -distance * mx.reshape(
            self.alibi_slopes, [1, self.num_heads, 1, 1]
        )

        return alibi_bias

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(hidden_states, attention_mask)


class FlashEncoderAttention(nn.Module):
    """
    Encoder attention optimized with flash attention.

    Uses MLX's fast.scaled_dot_product_attention for efficiency.
    """

    def __init__(
        self,
        config: EncoderAttentionConfig,
        layer_idx: int = 0,
    ) -> None:
        """Initialize flash encoder attention."""
        super().__init__()

        self.num_heads = config.num_heads
        self.head_dim = config.head_dim
        self.hidden_size = config.hidden_size

        self.embed_dim = self.num_heads * self.head_dim
        self.scale = 1.0 / (self.head_dim ** 0.5)

        # QKV projection
        self.qkv_proj = nn.Linear(
            self.hidden_size,
            3 * self.embed_dim,
            bias=config.attention_bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            self.embed_dim,
            self.hidden_size,
            bias=config.attention_bias,
        )

    def forward(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass with flash attention.

        Args:
            hidden_states: Input [batch, seq_len, hidden_size].
            attention_mask: Optional mask [batch, seq_len].

        Returns:
            Output [batch, seq_len, hidden_size].
        """
        batch_size, seq_len, _ = hidden_states.shape

        # QKV projection
        qkv = self.qkv_proj(hidden_states)
        qkv = mx.reshape(qkv, [batch_size, seq_len, 3, self.num_heads, self.head_dim])
        query, key, value = mx.split(qkv, 3, axis=2)

        query = mx.squeeze(query, 2)
        key = mx.squeeze(key, 2)
        value = mx.squeeze(value, 2)

        # Transpose for flash attention
        query = mx.transpose(query, [0, 2, 1, 3])
        key = mx.transpose(key, [0, 2, 1, 3])
        value = mx.transpose(value, [0, 2, 1, 3])

        # Try flash attention
        try:
            import mlx.fast as mlx_fast

            # Convert mask if needed
            mask = None
            if attention_mask is not None:
                mask = mx.expand_dims(mx.expand_dims(attention_mask, 1), 1)

            output = mlx_fast.scaled_dot_product_attention(
                query, key, value,
                scale=self.scale,
                mask=mask,
            )
        except (ImportError, AttributeError):
            # Fallback to standard attention
            scores = mx.matmul(
                query, mx.transpose(key, [0, 1, 3, 2])
            ) * self.scale

            if attention_mask is not None:
                mask = mx.expand_dims(mx.expand_dims(attention_mask, 1), 1)
                mask = (1.0 - mask) * float("-inf")
                scores = scores + mask

            probs = mx.softmax(scores, axis=-1)
            output = mx.matmul(probs, value)

        # Reshape and project
        output = mx.transpose(output, [0, 2, 1, 3])
        output = mx.reshape(output, [batch_size, seq_len, self.embed_dim])
        output = self.o_proj(output)

        return output

    def __call__(
        self,
        hidden_states: mx.array,
        attention_mask: mx.array | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(hidden_states, attention_mask)
