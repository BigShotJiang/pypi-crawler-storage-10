# SPDX-License-Identifier: Apache-2.0
"""Cross-attention for MLX-LLM.

Implements cross-attention between decoder and encoder hidden states.
Used in encoder-decoder models and multimodal models.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    pass


@dataclass
class CrossAttentionConfig:
    """Configuration for cross-attention."""

    num_heads: int
    head_dim: int
    hidden_size: int
    encoder_hidden_size: int | None = None  # If different from decoder
    dropout: float = 0.0
    attention_bias: bool = True
    use_relative_attention: bool = False


class CrossAttention(nn.Module):
    """
    Cross-attention layer for attending to encoder outputs.

    Used in:
    - Encoder-decoder models (T5, BART, etc.)
    - Multimodal models (CLIP, LLaVA, etc.)
    - Vision-language models

    The decoder queries attend to encoder keys/values.
    """

    def __init__(
        self,
        config: CrossAttentionConfig,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize cross-attention layer.

        Args:
            config: Cross-attention configuration.
            layer_idx: Layer index in the model.
        """
        super().__init__()

        self.num_heads = config.num_heads
        self.head_dim = config.head_dim
        self.hidden_size = config.hidden_size
        self.encoder_hidden_size = config.encoder_hidden_size or config.hidden_size
        self.layer_idx = layer_idx

        self.embed_dim = self.num_heads * self.head_dim
        self.scale = 1.0 / (self.head_dim ** 0.5)

        # Query projection (from decoder hidden states)
        self.q_proj = nn.Linear(
            self.hidden_size,
            self.embed_dim,
            bias=config.attention_bias,
        )

        # Key and value projections (from encoder hidden states)
        self.k_proj = nn.Linear(
            self.encoder_hidden_size,
            self.embed_dim,
            bias=config.attention_bias,
        )

        self.v_proj = nn.Linear(
            self.encoder_hidden_size,
            self.embed_dim,
            bias=config.attention_bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            self.embed_dim,
            self.hidden_size,
            bias=config.attention_bias,
        )

        self.dropout = config.dropout
        self.use_relative_attention = config.use_relative_attention

    def forward(
        self,
        hidden_states: mx.array,
        encoder_hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        encoder_attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Forward pass for cross-attention.

        Args:
            hidden_states: Decoder hidden states [batch, seq_len, hidden_size].
            encoder_hidden_states: Encoder hidden states [batch, enc_seq_len, enc_hidden_size].
            attention_mask: Optional decoder attention mask.
            encoder_attention_mask: Optional encoder attention mask.

        Returns:
            Output [batch, seq_len, hidden_size].
        """
        batch_size, seq_len, _ = hidden_states.shape
        enc_seq_len = encoder_hidden_states.shape[1]

        # Project queries from decoder
        query = self.q_proj(hidden_states)

        # Project keys and values from encoder
        key = self.k_proj(encoder_hidden_states)
        value = self.v_proj(encoder_hidden_states)

        # Reshape for multi-head attention
        # [batch, seq_len, embed_dim] -> [batch, seq_len, num_heads, head_dim]
        query = mx.reshape(query, [batch_size, seq_len, self.num_heads, self.head_dim])
        key = mx.reshape(key, [batch_size, enc_seq_len, self.num_heads, self.head_dim])
        value = mx.reshape(value, [batch_size, enc_seq_len, self.num_heads, self.head_dim])

        # Transpose for attention computation
        # [batch, seq_len, num_heads, head_dim] -> [batch, num_heads, seq_len, head_dim]
        query = mx.transpose(query, [0, 2, 1, 3])
        key = mx.transpose(key, [0, 2, 1, 3])
        value = mx.transpose(value, [0, 2, 1, 3])

        # Compute attention scores
        # [batch, num_heads, seq_len, head_dim] @ [batch, num_heads, head_dim, enc_seq_len]
        # -> [batch, num_heads, seq_len, enc_seq_len]
        attention_scores = mx.matmul(
            query,
            mx.transpose(key, [0, 1, 3, 2])
        ) * self.scale

        # Apply encoder attention mask if provided
        if encoder_attention_mask is not None:
            # Expand mask for heads: [batch, 1, 1, enc_seq_len]
            if len(encoder_attention_mask.shape) == 2:
                encoder_attention_mask = mx.expand_dims(
                    mx.expand_dims(encoder_attention_mask, 1), 1
                )
            # Convert from attention_mask (0/1) to additive mask (-inf/0)
            encoder_attention_mask = (1.0 - encoder_attention_mask) * float("-inf")
            attention_scores = attention_scores + encoder_attention_mask

        # Softmax over encoder sequence
        attention_probs = mx.softmax(attention_scores, axis=-1)

        # Apply dropout during training (no-op during inference)
        if self.dropout > 0.0:
            # Dropout not applied during inference
            pass

        # Apply attention to values
        # [batch, num_heads, seq_len, enc_seq_len] @ [batch, num_heads, enc_seq_len, head_dim]
        # -> [batch, num_heads, seq_len, head_dim]
        attention_output = mx.matmul(attention_probs, value)

        # Transpose back
        # [batch, num_heads, seq_len, head_dim] -> [batch, seq_len, num_heads, head_dim]
        attention_output = mx.transpose(attention_output, [0, 2, 1, 3])

        # Reshape to concatenate heads
        # [batch, seq_len, num_heads, head_dim] -> [batch, seq_len, embed_dim]
        attention_output = mx.reshape(
            attention_output,
            [batch_size, seq_len, self.embed_dim]
        )

        # Project output
        output = self.o_proj(attention_output)

        return output

    def __call__(
        self,
        hidden_states: mx.array,
        encoder_hidden_states: mx.array,
        attention_mask: mx.array | None = None,
        encoder_attention_mask: mx.array | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(hidden_states, encoder_hidden_states, attention_mask, encoder_attention_mask)


class MultiModalCrossAttention(nn.Module):
    """
    Cross-attention optimized for multimodal models.

    Supports features like:
    - Multiple encoder modalities (text, image, audio)
    - Gated cross-attention
    - Learnable queries (perceiver-style)
    """

    def __init__(
        self,
        config: CrossAttentionConfig,
        num_modalities: int = 1,
        use_gating: bool = False,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize multimodal cross-attention.

        Args:
            config: Cross-attention configuration.
            num_modalities: Number of encoder modalities.
            use_gating: Whether to use gated attention.
            layer_idx: Layer index.
        """
        super().__init__()

        self.num_modalities = num_modalities
        self.use_gating = use_gating

        # Create separate cross-attention for each modality
        self.cross_attentions = [
            CrossAttention(config, layer_idx=layer_idx)
            for _ in range(num_modalities)
        ]

        # Gating mechanism (if enabled)
        if use_gating:
            self.gate = nn.Linear(config.hidden_size, num_modalities)

        # Fusion layer for combining modalities
        if num_modalities > 1:
            self.fusion = nn.Linear(
                config.hidden_size * num_modalities,
                config.hidden_size,
            )

    def forward(
        self,
        hidden_states: mx.array,
        encoder_hidden_states_list: list[mx.array],
        encoder_attention_masks: list[mx.array | None] | None = None,
    ) -> mx.array:
        """
        Forward pass with multiple encoder modalities.

        Args:
            hidden_states: Decoder hidden states [batch, seq_len, hidden_size].
            encoder_hidden_states_list: List of encoder hidden states for each modality.
            encoder_attention_masks: Optional list of encoder attention masks.

        Returns:
            Output [batch, seq_len, hidden_size].
        """
        if len(encoder_hidden_states_list) != self.num_modalities:
            raise ValueError(
                f"Expected {self.num_modalities} encoder inputs, "
                f"got {len(encoder_hidden_states_list)}"
            )

        if encoder_attention_masks is None:
            encoder_attention_masks = [None] * self.num_modalities

        # Compute cross-attention for each modality
        outputs = []
        for encoder_states, mask, cross_attn in zip(
            encoder_hidden_states_list, encoder_attention_masks, self.cross_attentions, strict=True
        ):
            output = cross_attn(
                hidden_states,
                encoder_states,
                encoder_attention_mask=mask,
            )
            outputs.append(output)

        # Combine modalities
        if self.num_modalities == 1:
            combined = outputs[0]
        else:
            if self.use_gating:
                # Gated combination
                gate_logits = self.gate(hidden_states)  # [batch, seq_len, num_modalities]
                gate_weights = mx.softmax(gate_logits, axis=-1)

                # Weighted sum
                combined = sum(
                    mx.expand_dims(gate_weights[..., i], -1) * out
                    for i, out in enumerate(outputs)
                )
            else:
                # Concatenate and fuse
                concatenated = mx.concatenate(outputs, axis=-1)
                combined = self.fusion(concatenated)

        return combined

    def __call__(
        self,
        hidden_states: mx.array,
        encoder_hidden_states_list: list[mx.array],
        encoder_attention_masks: list[mx.array | None] | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(hidden_states, encoder_hidden_states_list, encoder_attention_masks)


class PerceiverCrossAttention(nn.Module):
    """
    Perceiver-style cross-attention with learnable queries.

    Used in models like Perceiver IO, Flamingo for compressing
    long encoder sequences into a fixed-size latent representation.
    """

    def __init__(
        self,
        config: CrossAttentionConfig,
        num_latents: int = 256,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize perceiver cross-attention.

        Args:
            config: Cross-attention configuration.
            num_latents: Number of learnable latent queries.
            layer_idx: Layer index.
        """
        super().__init__()

        self.num_latents = num_latents
        self.hidden_size = config.hidden_size

        # Learnable latent queries
        # [num_latents, hidden_size]
        self.latent_queries = mx.random.normal([num_latents, config.hidden_size])

        # Cross-attention from latents to encoder
        self.cross_attention = CrossAttention(config, layer_idx=layer_idx)

    def forward(
        self,
        encoder_hidden_states: mx.array,
        encoder_attention_mask: mx.array | None = None,
    ) -> mx.array:
        """
        Compress encoder states using learnable queries.

        Args:
            encoder_hidden_states: Encoder hidden states [batch, seq_len, hidden_size].
            encoder_attention_mask: Optional encoder attention mask.

        Returns:
            Compressed latent representation [batch, num_latents, hidden_size].
        """
        batch_size = encoder_hidden_states.shape[0]

        # Expand latents for batch
        # [num_latents, hidden_size] -> [batch, num_latents, hidden_size]
        latents = mx.broadcast_to(
            mx.expand_dims(self.latent_queries, 0),
            [batch_size, self.num_latents, self.hidden_size]
        )

        # Cross-attend from latents to encoder
        output = self.cross_attention(
            hidden_states=latents,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
        )

        return output

    def __call__(
        self,
        encoder_hidden_states: mx.array,
        encoder_attention_mask: mx.array | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(encoder_hidden_states, encoder_attention_mask)
