# SPDX-License-Identifier: Apache-2.0
"""Chunked local attention for MLX-LLM.

Implements local/windowed attention patterns for efficient processing
of very long sequences.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import mlx.core as mx
import mlx.nn as nn

if TYPE_CHECKING:
    from mlxllm.attention.backends.abstract import AttentionBackend, AttentionMetadata


@dataclass
class ChunkedLocalAttentionConfig:
    """Configuration for chunked local attention."""

    num_heads: int
    num_kv_heads: int
    head_dim: int
    hidden_size: int
    window_size: int = 512  # Local attention window
    chunk_size: int = 128  # Chunk size for processing
    max_position_embeddings: int = 8192
    rope_theta: float = 10000.0
    rope_scaling: dict | None = None
    attention_bias: bool = False


class ChunkedLocalAttention(nn.Module):
    """
    Chunked local attention layer.

    This implements local/windowed attention where each token can only
    attend to tokens within a fixed window. Useful for:
    - Very long sequences (>32K tokens)
    - Models with sliding window attention (e.g., Mistral)
    - Reducing computational complexity from O(n^2) to O(n*window)

    The implementation processes the sequence in chunks for memory efficiency.
    """

    def __init__(
        self,
        config: ChunkedLocalAttentionConfig,
        backend: AttentionBackend,
        layer_idx: int = 0,
    ) -> None:
        """
        Initialize chunked local attention layer.

        Args:
            config: Attention configuration.
            backend: Attention backend.
            layer_idx: Layer index in the model.
        """
        super().__init__()

        self.num_heads = config.num_heads
        self.num_kv_heads = config.num_kv_heads
        self.head_dim = config.head_dim
        self.hidden_size = config.hidden_size
        self.window_size = config.window_size
        self.chunk_size = config.chunk_size
        self.layer_idx = layer_idx
        self.backend = backend

        # Calculate dimensions
        self.q_size = self.num_heads * self.head_dim
        self.kv_size = self.num_kv_heads * self.head_dim

        # QKV projection
        self.qkv_proj = nn.Linear(
            self.hidden_size,
            self.q_size + 2 * self.kv_size,
            bias=config.attention_bias,
        )

        # Output projection
        self.o_proj = nn.Linear(
            self.q_size,
            self.hidden_size,
            bias=config.attention_bias,
        )

        # Rotary embeddings
        from mlxllm.model_executor.layers.rotary_embedding import RotaryEmbedding

        self.rotary_emb = RotaryEmbedding(
            head_dim=self.head_dim,
            max_position_embeddings=config.max_position_embeddings,
            base=config.rope_theta,
            scaling=config.rope_scaling,
        )

        self.scale = 1.0 / (self.head_dim ** 0.5)

    def forward(
        self,
        hidden_states: mx.array,
        positions: mx.array,
        kv_cache: mx.array | None = None,
        metadata: AttentionMetadata | None = None,
    ) -> mx.array:
        """
        Forward pass with chunked local attention.

        Args:
            hidden_states: Input [num_tokens, hidden_size] or [batch, seq_len, hidden_size].
            positions: Token positions [num_tokens] or [batch, seq_len].
            kv_cache: Optional KV cache for decode.
            metadata: Optional attention metadata.

        Returns:
            Output [num_tokens, hidden_size] or [batch, seq_len, hidden_size].
        """
        input_shape = hidden_states.shape
        is_batched = len(input_shape) == 3

        if is_batched:
            batch_size, seq_len, _ = input_shape
            # Flatten for processing
            hidden_states = mx.reshape(hidden_states, [-1, self.hidden_size])
            positions = mx.reshape(positions, [-1])
            num_tokens = batch_size * seq_len
        else:
            num_tokens = input_shape[0]
            seq_len = num_tokens

        # QKV projection
        qkv = self.qkv_proj(hidden_states)

        # Split into Q, K, V
        q, k, v = mx.split(
            qkv,
            [self.q_size, self.q_size + self.kv_size],
            axis=-1,
        )

        # Reshape to separate heads
        q = mx.reshape(q, [num_tokens, self.num_heads, self.head_dim])
        k = mx.reshape(k, [num_tokens, self.num_kv_heads, self.head_dim])
        v = mx.reshape(v, [num_tokens, self.num_kv_heads, self.head_dim])

        # Apply rotary embeddings
        cos, sin = self.rotary_emb(positions)
        q, k = self._apply_rotary(q, k, cos, sin)

        # Compute local attention
        if seq_len <= self.chunk_size:
            # Sequence fits in one chunk, use direct computation
            attn_output = self._local_attention_single_chunk(q, k, v)
        else:
            # Use chunked computation for long sequences
            attn_output = self._local_attention_chunked(q, k, v, seq_len)

        # Reshape and project output
        attn_output = mx.reshape(attn_output, [num_tokens, self.q_size])
        output = self.o_proj(attn_output)

        # Restore original shape if batched
        if is_batched:
            output = mx.reshape(output, [batch_size, seq_len, self.hidden_size])

        return output

    def _local_attention_single_chunk(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
    ) -> mx.array:
        """
        Compute local attention for a single chunk.

        Args:
            query: Query [num_tokens, num_heads, head_dim].
            key: Key [num_tokens, num_kv_heads, head_dim].
            value: Value [num_tokens, num_kv_heads, head_dim].

        Returns:
            Attention output [num_tokens, num_heads, head_dim].
        """
        num_tokens = query.shape[0]

        # Handle GQA/MQA
        if self.num_kv_heads != self.num_heads:
            from mlxllm.attention.ops.common import repeat_kv
            n_rep = self.num_heads // self.num_kv_heads
            # repeat_kv expects [batch, seq_len, num_kv_heads, head_dim]
            # We have [num_tokens, num_kv_heads, head_dim], so reshape to [1, num_tokens, num_kv_heads, head_dim]
            key = mx.expand_dims(key, 0)
            value = mx.expand_dims(value, 0)
            key = repeat_kv(key, n_rep)
            value = repeat_kv(value, n_rep)
            # Reshape back to [num_tokens, num_heads, head_dim]
            key = mx.squeeze(key, 0)
            value = mx.squeeze(value, 0)

        # Transpose for attention: [tokens, heads, dim] -> [1, heads, tokens, dim]
        query = mx.expand_dims(mx.transpose(query, [1, 0, 2]), 0)
        key = mx.expand_dims(mx.transpose(key, [1, 0, 2]), 0)
        value = mx.expand_dims(mx.transpose(value, [1, 0, 2]), 0)

        # Compute attention scores
        scores = mx.matmul(query, mx.transpose(key, [0, 1, 3, 2])) * self.scale

        # Apply local window mask
        mask = self._create_local_mask(num_tokens)
        scores = scores + mask

        # Softmax and apply to values
        attn_weights = mx.softmax(scores, axis=-1)
        output = mx.matmul(attn_weights, value)

        # Transpose back: [1, heads, tokens, dim] -> [tokens, heads, dim]
        output = mx.transpose(mx.squeeze(output, 0), [1, 0, 2])

        return output

    def _local_attention_chunked(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        seq_len: int,
    ) -> mx.array:
        """
        Compute local attention with chunking for long sequences.

        Args:
            query: Query [num_tokens, num_heads, head_dim].
            key: Key [num_tokens, num_kv_heads, head_dim].
            value: Value [num_tokens, num_kv_heads, head_dim].
            seq_len: Sequence length.

        Returns:
            Attention output [num_tokens, num_heads, head_dim].
        """
        num_chunks = (seq_len + self.chunk_size - 1) // self.chunk_size
        outputs = []

        for i in range(num_chunks):
            q_start = i * self.chunk_size
            q_end = min((i + 1) * self.chunk_size, seq_len)

            # Extract query chunk
            q_chunk = query[q_start:q_end]

            # Determine KV range (include local window)
            kv_start = max(0, q_start - self.window_size)
            kv_end = min(seq_len, q_end + self.window_size)

            # Extract KV chunks
            k_chunk = key[kv_start:kv_end]
            v_chunk = value[kv_start:kv_end]

            # Compute attention for this chunk
            chunk_output = self._compute_chunk_attention(
                q_chunk, k_chunk, v_chunk,
                q_offset=q_start,
                kv_offset=kv_start,
            )

            outputs.append(chunk_output)

        # Concatenate chunks
        output = mx.concatenate(outputs, axis=0)

        return output

    def _compute_chunk_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        q_offset: int,
        kv_offset: int,
    ) -> mx.array:
        """
        Compute attention for a single chunk.

        Args:
            query: Query chunk [chunk_size, num_heads, head_dim].
            key: Key chunk (with window) [window_size, num_kv_heads, head_dim].
            value: Value chunk (with window) [window_size, num_kv_heads, head_dim].
            q_offset: Query position offset in sequence.
            kv_offset: KV position offset in sequence.

        Returns:
            Attention output [chunk_size, num_heads, head_dim].
        """
        chunk_size = query.shape[0]
        kv_size = key.shape[0]

        # Handle GQA/MQA
        if self.num_kv_heads != self.num_heads:
            from mlxllm.attention.ops.common import repeat_kv
            n_rep = self.num_heads // self.num_kv_heads
            # repeat_kv expects [batch, seq_len, num_kv_heads, head_dim]
            # We have [tokens, num_kv_heads, head_dim], so reshape to [1, tokens, num_kv_heads, head_dim]
            key = mx.expand_dims(key, 0)
            value = mx.expand_dims(value, 0)
            key = repeat_kv(key, n_rep)
            value = repeat_kv(value, n_rep)
            # Reshape back to [tokens, num_heads, head_dim]
            key = mx.squeeze(key, 0)
            value = mx.squeeze(value, 0)

        # Transpose: [tokens, heads, dim] -> [heads, tokens, dim]
        query = mx.transpose(query, [1, 0, 2])
        key = mx.transpose(key, [1, 0, 2])
        value = mx.transpose(value, [1, 0, 2])

        # Compute scores
        scores = mx.matmul(query, mx.transpose(key, [0, 2, 1])) * self.scale

        # Apply local mask
        mask = self._create_chunk_mask(chunk_size, kv_size, q_offset, kv_offset)
        scores = scores + mask

        # Attention
        attn_weights = mx.softmax(scores, axis=-1)
        output = mx.matmul(attn_weights, value)

        # Transpose back: [heads, tokens, dim] -> [tokens, heads, dim]
        output = mx.transpose(output, [1, 0, 2])

        return output

    def _create_local_mask(self, seq_len: int) -> mx.array:
        """
        Create local attention mask.

        Args:
            seq_len: Sequence length.

        Returns:
            Mask [1, 1, seq_len, seq_len].
        """
        # Position indices
        positions = mx.arange(seq_len)
        distance = positions[:, None] - positions[None, :]

        # Mask: -inf for positions outside window or in future
        mask = mx.where(
            (distance < 0) | (distance > self.window_size),
            float("-inf"),
            0.0
        )

        # Add batch and head dimensions
        mask = mx.reshape(mask, [1, 1, seq_len, seq_len])

        return mask

    def _create_chunk_mask(
        self,
        chunk_size: int,
        kv_size: int,
        q_offset: int,
        kv_offset: int,
    ) -> mx.array:
        """
        Create mask for chunk attention.

        Args:
            chunk_size: Query chunk size.
            kv_size: KV chunk size (including window).
            q_offset: Query position offset.
            kv_offset: KV position offset.

        Returns:
            Mask [1, chunk_size, kv_size].
        """
        # Absolute positions
        q_positions = mx.arange(q_offset, q_offset + chunk_size)
        kv_positions = mx.arange(kv_offset, kv_offset + kv_size)

        # Distance matrix
        distance = q_positions[:, None] - kv_positions[None, :]

        # Mask: -inf for future or outside window
        mask = mx.where(
            (distance < 0) | (distance > self.window_size),
            float("-inf"),
            0.0
        )

        # Add head dimension
        mask = mx.expand_dims(mask, 0)

        return mask

    def _apply_rotary(
        self,
        q: mx.array,
        k: mx.array,
        cos: mx.array,
        sin: mx.array,
    ) -> tuple[mx.array, mx.array]:
        """Apply rotary embeddings."""
        from mlxllm.attention.ops.common import apply_rotary_pos_emb

        # q, k: [num_tokens, num_heads, head_dim]
        # Need to reshape to [batch=1, seq_len=num_tokens, num_heads, head_dim]
        num_tokens = q.shape[0]
        num_heads = q.shape[1]
        num_kv_heads = k.shape[1]
        head_dim = q.shape[2]

        q = mx.reshape(q, [1, num_tokens, num_heads, head_dim])
        k = mx.reshape(k, [1, num_tokens, num_kv_heads, head_dim])

        q, k = apply_rotary_pos_emb(q, k, cos, sin)

        # Reshape back to [num_tokens, num_heads, head_dim]
        q = mx.reshape(q, [num_tokens, num_heads, head_dim])
        k = mx.reshape(k, [num_tokens, num_kv_heads, head_dim])

        return q, k

    def __call__(
        self,
        hidden_states: mx.array,
        positions: mx.array,
        kv_cache: mx.array | None = None,
        metadata: AttentionMetadata | None = None,
    ) -> mx.array:
        """Call forward method."""
        return self.forward(hidden_states, positions, kv_cache, metadata)
