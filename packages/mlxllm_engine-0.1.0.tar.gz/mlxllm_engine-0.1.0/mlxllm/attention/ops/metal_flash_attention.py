# SPDX-License-Identifier: Apache-2.0
"""Metal-accelerated flash attention for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def metal_flash_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    scale: float | None = None,
    mask: mx.array | None = None,
) -> mx.array:
    """
    Metal-accelerated flash attention.

    Uses MLX's optimized attention implementation which leverages Metal
    for efficient computation on Apple Silicon.

    Args:
        query: Query tensor [batch, seq_len, num_heads, head_dim].
        key: Key tensor [batch, seq_len, num_kv_heads, head_dim].
        value: Value tensor [batch, seq_len, num_kv_heads, head_dim].
        scale: Attention scale factor. If None, uses 1/sqrt(head_dim).
        mask: Optional attention mask [batch, num_heads, seq_len, seq_len].

    Returns:
        Attention output [batch, seq_len, num_heads, head_dim].
    """
    batch_size, seq_len, num_heads, head_dim = query.shape
    _, _, num_kv_heads, _ = key.shape

    # Calculate scale if not provided
    if scale is None:
        scale = 1.0 / (head_dim**0.5)

    # Handle Grouped Query Attention (GQA) / Multi-Query Attention (MQA)
    if num_kv_heads != num_heads:
        # Repeat KV heads to match query heads
        num_groups = num_heads // num_kv_heads
        # [batch, seq_len, num_kv_heads, head_dim] -> [batch, seq_len, num_heads, head_dim]
        key = mx.repeat(key, num_groups, axis=2)
        value = mx.repeat(value, num_groups, axis=2)

    # Transpose for attention computation
    # [batch, seq_len, num_heads, head_dim] -> [batch, num_heads, seq_len, head_dim]
    query = mx.transpose(query, [0, 2, 1, 3])
    key = mx.transpose(key, [0, 2, 1, 3])
    value = mx.transpose(value, [0, 2, 1, 3])

    # Compute attention scores: Q @ K^T
    # [batch, num_heads, seq_len, head_dim] @ [batch, num_heads, head_dim, seq_len]
    # -> [batch, num_heads, seq_len, seq_len]
    scores = mx.matmul(query, mx.transpose(key, [0, 1, 3, 2])) * scale

    # Apply mask if provided
    if mask is not None:
        scores = scores + mask

    # Apply causal mask for autoregressive generation
    # This prevents attending to future tokens
    causal_mask = mx.triu(mx.full((seq_len, seq_len), float("-inf")), k=1)
    scores = scores + causal_mask

    # Apply softmax
    attn_weights = mx.softmax(scores, axis=-1)

    # Compute attention output: softmax(scores) @ V
    # [batch, num_heads, seq_len, seq_len] @ [batch, num_heads, seq_len, head_dim]
    # -> [batch, num_heads, seq_len, head_dim]
    output = mx.matmul(attn_weights, value)

    # Transpose back to original format
    # [batch, num_heads, seq_len, head_dim] -> [batch, seq_len, num_heads, head_dim]
    output = mx.transpose(output, [0, 2, 1, 3])

    return output


def metal_flash_attention_prefill(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    scale: float | None = None,
    sliding_window: int | None = None,
) -> mx.array:
    """
    Flash attention optimized for prefill phase.

    Args:
        query: Query [batch, seq_len, num_heads, head_dim].
        key: Key [batch, seq_len, num_kv_heads, head_dim].
        value: Value [batch, seq_len, num_kv_heads, head_dim].
        scale: Attention scale.
        sliding_window: Optional sliding window size for local attention.

    Returns:
        Attention output [batch, seq_len, num_heads, head_dim].
    """
    # For prefill, use standard flash attention
    # Sliding window can be implemented with a custom mask
    mask = None
    if sliding_window is not None:
        seq_len = query.shape[1]
        # Create sliding window mask
        # Only attend to [pos - window, pos]
        positions = mx.arange(seq_len)
        distance = positions[:, None] - positions[None, :]
        mask = mx.where(distance > sliding_window, float("-inf"), 0.0)

    return metal_flash_attention(query, key, value, scale=scale, mask=mask)


def metal_flash_attention_varlen(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    cu_seqlens_q: list[int],
    cu_seqlens_k: list[int],
    max_seqlen_q: int,
    max_seqlen_k: int,
    scale: float | None = None,
) -> mx.array:
    """
    Flash attention for variable-length sequences (batched).

    Args:
        query: Concatenated queries [total_q_tokens, num_heads, head_dim].
        key: Concatenated keys [total_k_tokens, num_kv_heads, head_dim].
        value: Concatenated values [total_k_tokens, num_kv_heads, head_dim].
        cu_seqlens_q: Cumulative sequence lengths for queries.
        cu_seqlens_k: Cumulative sequence lengths for keys.
        max_seqlen_q: Maximum query sequence length.
        max_seqlen_k: Maximum key sequence length.
        scale: Attention scale.

    Returns:
        Attention output [total_q_tokens, num_heads, head_dim].
    """
    head_dim = query.shape[2]

    if scale is None:
        scale = 1.0 / (head_dim**0.5)

    # Split concatenated tensors into individual sequences
    num_seqs = len(cu_seqlens_q) - 1
    outputs = []

    for i in range(num_seqs):
        # Extract sequence i
        q_start, q_end = cu_seqlens_q[i], cu_seqlens_q[i + 1]
        k_start, k_end = cu_seqlens_k[i], cu_seqlens_k[i + 1]

        seq_query = query[q_start:q_end]  # [seq_len_q, num_heads, head_dim]
        seq_key = key[k_start:k_end]  # [seq_len_k, num_kv_heads, head_dim]
        seq_value = value[k_start:k_end]  # [seq_len_k, num_kv_heads, head_dim]

        # Add batch dimension
        seq_query = mx.expand_dims(seq_query, 0)
        seq_key = mx.expand_dims(seq_key, 0)
        seq_value = mx.expand_dims(seq_value, 0)

        # Rearrange to [batch, seq_len, num_heads, head_dim]
        seq_query = mx.transpose(seq_query, [0, 1, 2, 3])
        seq_key = mx.transpose(seq_key, [0, 1, 2, 3])
        seq_value = mx.transpose(seq_value, [0, 1, 2, 3])

        # Compute attention for this sequence
        seq_output = metal_flash_attention(
            seq_query, seq_key, seq_value, scale=scale, mask=None
        )

        # Remove batch dim and transpose back
        seq_output = mx.squeeze(seq_output, 0)  # [seq_len, num_heads, head_dim]

        outputs.append(seq_output)

    # Concatenate outputs
    output = mx.concatenate(outputs, axis=0)

    return output
