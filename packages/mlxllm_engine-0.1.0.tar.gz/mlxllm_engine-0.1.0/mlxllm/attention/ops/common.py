# SPDX-License-Identifier: Apache-2.0
"""Common attention utilities for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def apply_rotary_pos_emb(
    q: mx.array,
    k: mx.array,
    cos: mx.array,
    sin: mx.array,
    position_ids: mx.array | None = None,
) -> tuple[mx.array, mx.array]:
    """
    Apply Rotary Position Embedding (RoPE) to query and key tensors.

    Args:
        q: Query [batch, seq_len, num_heads, head_dim].
        k: Key [batch, seq_len, num_kv_heads, head_dim].
        cos: Cosine values [seq_len, head_dim].
        sin: Sine values [seq_len, head_dim].
        position_ids: Optional position indices [batch, seq_len].

    Returns:
        Tuple of (rotated_q, rotated_k).
    """
    # If position_ids provided, gather cos/sin for those positions
    if position_ids is not None:
        # Flatten position_ids for gather
        flat_pos = mx.reshape(position_ids, [-1])
        cos = cos[flat_pos]
        sin = sin[flat_pos]
        # Reshape back
        batch_size, seq_len = position_ids.shape
        cos = mx.reshape(cos, [batch_size, seq_len, -1])
        sin = mx.reshape(sin, [batch_size, seq_len, -1])
    else:
        # No position_ids, cos/sin should already be [seq_len, head_dim]
        # Expand to [1, seq_len, head_dim] for batching
        if len(cos.shape) == 2:
            cos = mx.expand_dims(cos, 0)
            sin = mx.expand_dims(sin, 0)

    # Reshape for broadcasting: [batch, seq_len, 1, head_dim]
    cos = mx.expand_dims(cos, 2)
    sin = mx.expand_dims(sin, 2)

    # Split head_dim into two halves for rotation
    # q, k: [batch, seq_len, num_heads, head_dim]
    head_dim = q.shape[-1]
    half_dim = head_dim // 2

    # Split into first and second halves
    q1, q2 = q[..., :half_dim], q[..., half_dim:]
    k1, k2 = k[..., :half_dim], k[..., half_dim:]

    # Split cos/sin as well (only use first half_dim elements, repeated)
    # cos/sin from RoPE are [batch, seq_len, 1, head_dim] where head_dim has repeated values
    cos_half = cos[..., :half_dim]
    sin_half = sin[..., :half_dim]

    # Apply rotation:
    # [x1, x2] -> [x1*cos - x2*sin, x1*sin + x2*cos]
    q_rotated = mx.concatenate(
        [q1 * cos_half - q2 * sin_half,
         q1 * sin_half + q2 * cos_half],
        axis=-1
    )
    k_rotated = mx.concatenate(
        [k1 * cos_half - k2 * sin_half,
         k1 * sin_half + k2 * cos_half],
        axis=-1
    )

    return q_rotated, k_rotated


def scaled_dot_product_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    attn_mask: mx.array | None = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
    scale: float | None = None,
) -> mx.array:
    """
    Scaled dot-product attention.

    This is a basic implementation that can be used as a fallback
    when specialized kernels are not available.

    Args:
        query: Query [batch, num_heads, seq_len_q, head_dim].
        key: Key [batch, num_heads, seq_len_k, head_dim].
        value: Value [batch, num_heads, seq_len_k, head_dim].
        attn_mask: Optional attention mask.
        dropout_p: Dropout probability (not used in inference).
        is_causal: Whether to apply causal mask.
        scale: Attention scale factor.

    Returns:
        Attention output [batch, num_heads, seq_len_q, head_dim].
    """
    batch_size, num_heads, seq_len_q, head_dim = query.shape
    seq_len_k = key.shape[2]

    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    # Compute attention scores: Q @ K^T
    # [batch, num_heads, seq_len_q, seq_len_k]
    scores = mx.matmul(query, mx.transpose(key, [0, 1, 3, 2])) * scale

    # Apply attention mask if provided
    if attn_mask is not None:
        scores = scores + attn_mask

    # Apply causal mask if requested
    if is_causal:
        causal_mask = mx.triu(
            mx.full((seq_len_q, seq_len_k), float("-inf")),
            k=1
        )
        scores = scores + causal_mask

    # Apply softmax
    attn_weights = mx.softmax(scores, axis=-1)

    # Apply dropout (no-op during inference)
    if dropout_p > 0.0 and not mx.is_training():
        # Dropout not applied during inference
        pass

    # Compute output: attention_weights @ V
    output = mx.matmul(attn_weights, value)

    return output


def repeat_kv(hidden_states: mx.array, n_rep: int) -> mx.array:
    """
    Repeat KV heads for Grouped Query Attention (GQA).

    This is used when num_kv_heads < num_query_heads.

    Args:
        hidden_states: KV tensor [batch, seq_len, num_kv_heads, head_dim].
        n_rep: Number of repetitions (num_query_heads // num_kv_heads).

    Returns:
        Expanded tensor [batch, seq_len, num_query_heads, head_dim].
    """
    if n_rep == 1:
        return hidden_states

    batch, seq_len, num_kv_heads, head_dim = hidden_states.shape

    # Repeat along the num_heads dimension
    # [batch, seq_len, num_kv_heads, head_dim]
    # -> [batch, seq_len, num_kv_heads, n_rep, head_dim]
    # -> [batch, seq_len, num_kv_heads * n_rep, head_dim]
    hidden_states = mx.expand_dims(hidden_states, 3)
    hidden_states = mx.repeat(hidden_states, n_rep, axis=3)
    hidden_states = mx.reshape(
        hidden_states,
        [batch, seq_len, num_kv_heads * n_rep, head_dim]
    )

    return hidden_states


def get_attention_mask(
    seq_len: int,
    sliding_window: int | None = None,
    is_causal: bool = True,
) -> mx.array:
    """
    Generate attention mask.

    Args:
        seq_len: Sequence length.
        sliding_window: Optional sliding window size.
        is_causal: Whether to use causal (autoregressive) mask.

    Returns:
        Attention mask [seq_len, seq_len].
    """
    if not is_causal and sliding_window is None:
        # No mask needed
        return mx.zeros((seq_len, seq_len))

    # Create position indices
    positions = mx.arange(seq_len)
    # Distance matrix: positions[i] - positions[j]
    # Positive means j is before i (past), negative means j is after i (future)
    distance = positions[:, None] - positions[None, :]

    mask = mx.zeros((seq_len, seq_len))

    # Apply causal mask (can't attend to future: distance < 0)
    if is_causal:
        mask = mx.where(distance < 0, float("-inf"), mask)

    # Apply sliding window mask (can't attend beyond window in past)
    # For sliding window, we mask positions where |distance| > window
    if sliding_window is not None:
        # Mask if distance is too far in the past (positive and > window)
        # OR if distance is in the future (negative) when bidirectional
        if not is_causal:
            # Bidirectional: mask based on absolute distance
            abs_distance = mx.abs(distance)
            mask = mx.where(abs_distance > sliding_window, float("-inf"), mask)
        else:
            # Causal: only mask past positions beyond window (distance > window)
            mask = mx.where(distance > sliding_window, float("-inf"), mask)

    return mask


def compute_positions(
    seq_len: int,
    past_kv_len: int = 0,
) -> mx.array:
    """
    Compute position indices for attention.

    Args:
        seq_len: Current sequence length.
        past_kv_len: Length of past KV cache.

    Returns:
        Position indices [seq_len].
    """
    return mx.arange(past_kv_len, past_kv_len + seq_len)
