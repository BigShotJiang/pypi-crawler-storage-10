# SPDX-License-Identifier: Apache-2.0
"""Chunked prefill with paged decode for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    from mlxllm.attention.backends.abstract import AttentionMetadata


def chunked_prefill_paged_decode_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    kv_cache: mx.array | None,
    metadata: AttentionMetadata,
) -> mx.array:
    """
    Hybrid attention supporting both chunked prefill and paged decode.

    This function handles mixed batches where some sequences are in prefill
    (processing input prompts) and others are in decode (generating tokens).

    Args:
        query: Query [total_tokens, num_heads, head_dim].
        key: Key [prefill_tokens, num_kv_heads, head_dim].
        value: Value [prefill_tokens, num_kv_heads, head_dim].
        kv_cache: Optional KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
        metadata: Attention metadata with prefill/decode split info.

    Returns:
        Attention output [total_tokens, num_heads, head_dim].
    """
    from mlxllm.attention.ops.metal_flash_attention import metal_flash_attention
    from mlxllm.attention.ops.metal_decode_attention import metal_paged_attention

    # Split query into prefill and decode portions
    num_prefill_tokens = metadata.num_prefill_tokens if metadata.num_prefill_tokens else 0
    num_decode_tokens = metadata.num_decode_tokens if metadata.num_decode_tokens else 0

    total_tokens = query.shape[0]
    if total_tokens != num_prefill_tokens + num_decode_tokens:
        raise ValueError(
            f"Total tokens {total_tokens} != "
            f"prefill {num_prefill_tokens} + decode {num_decode_tokens}"
        )

    outputs = []

    # Process prefill portion
    if num_prefill_tokens > 0:
        prefill_query = query[:num_prefill_tokens]
        prefill_key = key
        prefill_value = value

        # Reshape for flash attention: [tokens, heads, dim] -> [batch, seq, heads, dim]
        # Assume single sequence for simplicity (can be extended for batched prefill)
        prefill_query = mx.expand_dims(prefill_query, 0)
        prefill_key = mx.expand_dims(prefill_key, 0)
        prefill_value = mx.expand_dims(prefill_value, 0)

        # Transpose to [batch, seq, heads, dim]
        prefill_query = mx.transpose(prefill_query, [0, 1, 2, 3])
        prefill_key = mx.transpose(prefill_key, [0, 1, 2, 3])
        prefill_value = mx.transpose(prefill_value, [0, 1, 2, 3])

        # Run flash attention for prefill
        prefill_output = metal_flash_attention(
            query=prefill_query,
            key=prefill_key,
            value=prefill_value,
            scale=metadata.scale,
            mask=metadata.attn_mask,
        )

        # Reshape back: [batch, seq, heads, dim] -> [tokens, heads, dim]
        prefill_output = mx.squeeze(prefill_output, 0)
        outputs.append(prefill_output)

    # Process decode portion
    if num_decode_tokens > 0:
        decode_query = query[num_prefill_tokens:]

        if kv_cache is None:
            raise ValueError("KV cache required for decode phase")

        # Reshape for paged attention: [tokens, heads, dim] -> [batch, 1, heads, dim]
        decode_query = mx.reshape(
            decode_query,
            [num_decode_tokens, 1, decode_query.shape[1], decode_query.shape[2]]
        )

        # Run paged attention for decode
        decode_output = metal_paged_attention(
            query=decode_query,
            kv_cache=kv_cache,
            block_tables=metadata.block_tables,
            context_lens=metadata.context_lens,
            block_size=metadata.block_size,
            scale=metadata.scale,
        )

        # Reshape: [batch, 1, heads, dim] -> [tokens, heads, dim]
        decode_output = mx.reshape(
            decode_output,
            [num_decode_tokens, decode_output.shape[2], decode_output.shape[3]]
        )
        outputs.append(decode_output)

    # Concatenate outputs
    if len(outputs) == 0:
        raise ValueError("No outputs to concatenate")

    output = mx.concatenate(outputs, axis=0)

    return output


def chunk_prefill_tokens(
    tokens: mx.array,
    chunk_size: int,
) -> list[mx.array]:
    """
    Split prefill tokens into chunks for processing.

    This prevents OOM on very long prompts by processing them in chunks.

    Args:
        tokens: Input tokens [seq_len].
        chunk_size: Maximum chunk size.

    Returns:
        List of token chunks.
    """
    seq_len = tokens.shape[0]

    if seq_len <= chunk_size:
        return [tokens]

    chunks = []
    for i in range(0, seq_len, chunk_size):
        end = min(i + chunk_size, seq_len)
        chunks.append(tokens[i:end])

    return chunks


def merge_chunked_outputs(
    chunks: list[mx.array],
) -> mx.array:
    """
    Merge outputs from chunked prefill.

    Args:
        chunks: List of output chunks [chunk_len, num_heads, head_dim].

    Returns:
        Merged output [total_len, num_heads, head_dim].
    """
    if len(chunks) == 0:
        raise ValueError("No chunks to merge")

    if len(chunks) == 1:
        return chunks[0]

    return mx.concatenate(chunks, axis=0)
