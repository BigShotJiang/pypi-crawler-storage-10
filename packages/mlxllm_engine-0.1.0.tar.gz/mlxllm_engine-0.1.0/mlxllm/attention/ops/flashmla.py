# SPDX-License-Identifier: Apache-2.0
"""
Flash Multi-Latent Attention (MLA) for DeepSeek models.

Multi-Latent Attention is a specialized attention mechanism used in DeepSeek-R1
that compresses KV cache using low-rank projections to reduce memory usage.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def flash_mla_attention(
    query: mx.array,
    compressed_kv: mx.array,
    kv_proj_up: mx.array,
    kv_proj_down: mx.array,
    attn_mask: mx.array | None = None,
    scale: float | None = None,
) -> mx.array:
    """
    Flash Multi-Latent Attention computation.

    MLA compresses the KV cache by projecting K and V through low-rank matrices:
    - Compressed: C = down_proj(concat(K, V))  [compressed_dim << 2*head_dim]
    - Reconstruct: K, V = split(up_proj(C))

    This reduces KV cache memory from O(num_heads * 2 * head_dim) to O(compressed_dim).

    Args:
        query: Query tensor [batch, num_heads, seq_len, head_dim].
        compressed_kv: Compressed KV latents [batch, cache_len, compressed_dim].
        kv_proj_up: Upward projection to reconstruct KV [compressed_dim, 2*num_kv_heads*head_dim].
        kv_proj_down: Not used in forward pass (only for compression).
        attn_mask: Optional attention mask.
        scale: Attention scale factor (default: 1/sqrt(head_dim)).

    Returns:
        Attention output [batch, num_heads, seq_len, head_dim].
    """
    batch_size, num_heads, seq_len_q, head_dim = query.shape
    cache_len, compressed_dim = compressed_kv.shape[1:3]

    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    # Decompress KV: [batch, cache_len, compressed_dim] @ [compressed_dim, 2*kv_dim]
    # -> [batch, cache_len, 2*kv_dim]
    decompressed_kv = mx.matmul(compressed_kv, kv_proj_up)

    # Split into K and V
    kv_dim = decompressed_kv.shape[-1] // 2
    key = decompressed_kv[..., :kv_dim]
    value = decompressed_kv[..., kv_dim:]

    # Reshape to [batch, cache_len, num_kv_heads, head_dim]
    num_kv_heads = kv_dim // head_dim
    key = mx.reshape(key, [batch_size, cache_len, num_kv_heads, head_dim])
    value = mx.reshape(value, [batch_size, cache_len, num_kv_heads, head_dim])

    # Repeat KV heads if using GQA (num_heads > num_kv_heads)
    if num_heads > num_kv_heads:
        n_rep = num_heads // num_kv_heads
        key = mx.repeat(mx.expand_dims(key, 3), n_rep, axis=3)
        value = mx.repeat(mx.expand_dims(value, 3), n_rep, axis=3)
        key = mx.reshape(key, [batch_size, cache_len, num_heads, head_dim])
        value = mx.reshape(value, [batch_size, cache_len, num_heads, head_dim])

    # Transpose for attention: [batch, num_heads, seq_len, head_dim]
    key = mx.transpose(key, [0, 2, 1, 3])
    value = mx.transpose(value, [0, 2, 1, 3])

    # Compute attention scores: Q @ K^T
    # [batch, num_heads, seq_len_q, cache_len]
    scores = mx.matmul(query, mx.transpose(key, [0, 1, 3, 2])) * scale

    # Apply attention mask if provided
    if attn_mask is not None:
        scores = scores + attn_mask

    # Softmax
    attn_weights = mx.softmax(scores, axis=-1)

    # Compute output: attn_weights @ V
    output = mx.matmul(attn_weights, value)

    return output


def compress_kv_for_mla(
    key: mx.array,
    value: mx.array,
    kv_proj_down: mx.array,
) -> mx.array:
    """
    Compress key and value tensors for MLA.

    Args:
        key: Key tensor [batch, seq_len, num_kv_heads, head_dim].
        value: Value tensor [batch, seq_len, num_kv_heads, head_dim].
        kv_proj_down: Downward projection [2*num_kv_heads*head_dim, compressed_dim].

    Returns:
        Compressed KV latents [batch, seq_len, compressed_dim].
    """
    batch_size, seq_len, num_kv_heads, head_dim = key.shape

    # Flatten KV: [batch, seq_len, num_kv_heads * head_dim]
    key_flat = mx.reshape(key, [batch_size, seq_len, num_kv_heads * head_dim])
    value_flat = mx.reshape(value, [batch_size, seq_len, num_kv_heads * head_dim])

    # Concatenate K and V: [batch, seq_len, 2 * num_kv_heads * head_dim]
    kv_concat = mx.concatenate([key_flat, value_flat], axis=-1)

    # Project down: [batch, seq_len, compressed_dim]
    compressed_kv = mx.matmul(kv_concat, kv_proj_down)

    return compressed_kv


def update_mla_cache(
    compressed_kv_cache: mx.array,
    new_compressed_kv: mx.array,
    cache_position: int,
) -> mx.array:
    """
    Update the compressed KV cache with new compressed KV latents.

    Args:
        compressed_kv_cache: Existing cache [batch, max_cache_len, compressed_dim].
        new_compressed_kv: New compressed KV [batch, new_seq_len, compressed_dim].
        cache_position: Position to insert new KV.

    Returns:
        Updated cache [batch, max_cache_len, compressed_dim].
    """
    batch_size, max_cache_len, compressed_dim = compressed_kv_cache.shape
    new_seq_len = new_compressed_kv.shape[1]

    # Create indices for update
    end_position = cache_position + new_seq_len

    # Update the cache at the specified positions
    # This is a simplified version - in practice, you'd use scatter/index update
    updated_cache = mx.array(compressed_kv_cache)
    updated_cache[:, cache_position:end_position, :] = new_compressed_kv

    return updated_cache


def get_mla_compression_ratio(
    num_kv_heads: int,
    head_dim: int,
    compressed_dim: int,
) -> float:
    """
    Calculate the memory compression ratio for MLA.

    Args:
        num_kv_heads: Number of KV heads.
        head_dim: Head dimension.
        compressed_dim: Compressed latent dimension.

    Returns:
        Compression ratio (original_size / compressed_size).
    """
    original_kv_dim = 2 * num_kv_heads * head_dim  # K + V
    compression_ratio = original_kv_dim / compressed_dim
    return compression_ratio


class MLAConfig:
    """Configuration for Multi-Latent Attention."""

    def __init__(
        self,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        compressed_dim: int,
        rope_theta: float = 10000.0,
    ):
        """
        Initialize MLA config.

        Args:
            num_heads: Number of query heads.
            num_kv_heads: Number of key/value heads (for GQA).
            head_dim: Dimension per head.
            compressed_dim: Compressed latent dimension.
            rope_theta: RoPE theta parameter.
        """
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.compressed_dim = compressed_dim
        self.rope_theta = rope_theta

        # Calculate dimensions
        self.kv_dim = num_kv_heads * head_dim
        self.total_kv_dim = 2 * self.kv_dim  # K + V

        # Compression ratio
        self.compression_ratio = self.total_kv_dim / compressed_dim

    def validate(self) -> None:
        """Validate MLA configuration."""
        if self.compressed_dim >= self.total_kv_dim:
            raise ValueError(
                f"compressed_dim ({self.compressed_dim}) should be < "
                f"total_kv_dim ({self.total_kv_dim}) for compression"
            )

        if self.num_heads % self.num_kv_heads != 0:
            raise ValueError(
                f"num_heads ({self.num_heads}) must be divisible by "
                f"num_kv_heads ({self.num_kv_heads})"
            )

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"MLAConfig(heads={self.num_heads}, kv_heads={self.num_kv_heads}, "
            f"head_dim={self.head_dim}, compressed_dim={self.compressed_dim}, "
            f"ratio={self.compression_ratio:.2f}x)"
        )
