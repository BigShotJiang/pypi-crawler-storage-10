# SPDX-License-Identifier: Apache-2.0
"""Unified Metal attention backend for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

from mlxllm.attention.backends.abstract import (
    AttentionBackend,
    AttentionMetadata,
)
from mlxllm.attention.ops.metal_decode_attention import (
    metal_paged_attention,
    metal_update_kv_cache,
)
from mlxllm.attention.ops.metal_flash_attention import (
    metal_flash_attention,
    metal_flash_attention_prefill,
)

if TYPE_CHECKING:
    pass


class MetalAttentionBackend(AttentionBackend):
    """
    Unified Metal attention backend.

    Provides both prefill and decode attention using Metal-accelerated
    operations optimized for Apple Silicon.
    """

    def __init__(self) -> None:
        """Initialize Metal attention backend."""
        self.supported_head_sizes = [64, 80, 96, 112, 128, 256]

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Compute attention for prefill phase.

        Args:
            query: Query [batch, seq_len, num_heads, head_dim].
            key: Key [batch, seq_len, num_kv_heads, head_dim].
            value: Value [batch, seq_len, num_kv_heads, head_dim].
            metadata: Attention metadata.

        Returns:
            Attention output [batch, seq_len, num_heads, head_dim].
        """
        # Use flash attention for prefill
        return metal_flash_attention_prefill(
            query=query,
            key=key,
            value=value,
            scale=metadata.scale,
            sliding_window=None,
        )

    def decode_attention(
        self,
        query: mx.array,
        kv_cache: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """
        Compute attention for decode phase using paged KV cache.

        Args:
            query: Query [batch, 1, num_heads, head_dim].
            kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
            metadata: Attention metadata with block tables.

        Returns:
            Attention output [batch, 1, num_heads, head_dim].
        """
        if metadata.block_tables is None:
            raise ValueError("block_tables required for decode attention")

        if metadata.context_lens is None:
            raise ValueError("context_lens required for decode attention")

        # Use paged attention for decode
        return metal_paged_attention(
            query=query,
            kv_cache=kv_cache,
            block_tables=metadata.block_tables,
            context_lens=metadata.context_lens,
            block_size=metadata.block_size,
            scale=metadata.scale,
        )

    def update_kv_cache(
        self,
        kv_cache: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> None:
        """
        Update KV cache with new keys/values.

        Args:
            kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
            key: Keys [batch, seq_len, num_kv_heads, head_dim].
            value: Values [batch, seq_len, num_kv_heads, head_dim].
            metadata: Attention metadata with slot mapping.
        """
        if metadata.slot_mapping is None:
            raise ValueError("slot_mapping required for KV cache update")

        metal_update_kv_cache(
            kv_cache=kv_cache,
            key=key,
            value=value,
            slot_mapping=metadata.slot_mapping,
        )

    def get_supported_head_sizes(self) -> list[int]:
        """Get supported head dimensions."""
        return self.supported_head_sizes

    def get_name(self) -> str:
        """Get backend name."""
        return "metal"

    @classmethod
    def is_available(cls) -> bool:
        """Check if Metal backend is available."""
        try:
            # Metal is available if MLX is installed and we're on Apple Silicon
            import platform

            return platform.system() == "Darwin" and platform.machine() == "arm64"
        except ImportError:
            return False


class MetalFlashAttentionBackend(MetalAttentionBackend):
    """
    Metal Flash Attention backend.

    Optimized for prefill with flash attention, falls back to
    standard paged attention for decode.
    """

    def get_name(self) -> str:
        """Get backend name."""
        return "flash_metal"

    def prefill_attention(
        self,
        query: mx.array,
        key: mx.array,
        value: mx.array,
        metadata: AttentionMetadata,
    ) -> mx.array:
        """Use flash attention for prefill."""
        return metal_flash_attention(
            query=query,
            key=key,
            value=value,
            scale=metadata.scale,
            mask=metadata.attn_mask,
        )
