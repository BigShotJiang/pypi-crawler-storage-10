# SPDX-License-Identifier: Apache-2.0
"""
ROCm AITemplate paged attention operations.

Note: ROCm is AMD's GPU compute platform. This file provides stubs
for API compatibility, but MLX uses Apple's Metal instead.
"""

from __future__ import annotations


# ROCm-specific operations are not implemented for MLX/Metal
# MLX runs on Apple Silicon using Metal Performance Shaders (MPS)

def rocm_aiter_paged_attn_not_supported():
    """
    ROCm operations are not supported on Metal/MLX.

    MLX is designed for Apple Silicon and uses Metal acceleration.
    For AMD GPUs, use the original vLLM with ROCm support.
    """
    raise NotImplementedError(
        "ROCm operations are not supported in MLX-LLM. "
        "MLX is designed for Apple Silicon with Metal acceleration. "
        "For AMD GPU support, please use vLLM with ROCm."
    )


# Placeholder for API compatibility
class ROCmPagedAttention:
    """Stub class for ROCm paged attention operations."""

    def __init__(self, *args, **kwargs):
        """Initialize ROCm paged attention (not supported)."""
        rocm_aiter_paged_attn_not_supported()
