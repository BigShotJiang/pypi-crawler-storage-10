# SPDX-License-Identifier: Apache-2.0
"""
Pallas KV cache update operations.

Note: Pallas is JAX's kernel language, which is not applicable to MLX.
This file provides stubs for API compatibility.
"""

from __future__ import annotations

import mlx.core as mx


def pallas_kv_cache_update(
    key_cache: mx.array,
    value_cache: mx.array,
    new_key: mx.array,
    new_value: mx.array,
    cache_positions: mx.array,
) -> tuple[mx.array, mx.array]:
    """
    Update KV cache using Pallas kernels (stub for MLX).

    Pallas is specific to JAX. For MLX, we use standard MLX operations.

    Args:
        key_cache: Existing key cache.
        value_cache: Existing value cache.
        new_key: New keys to insert.
        new_value: New values to insert.
        cache_positions: Positions to update.

    Returns:
        Updated (key_cache, value_cache).
    """
    # MLX doesn't use Pallas - use standard indexing
    # This is a fallback implementation
    batch_size = new_key.shape[0]
    seq_len = new_key.shape[2]

    for b in range(batch_size):
        for i in range(seq_len):
            pos = int(cache_positions[b, i])
            key_cache[b, :, pos, :] = new_key[b, :, i, :]
            value_cache[b, :, pos, :] = new_value[b, :, i, :]

    return key_cache, value_cache


# Note: Pallas-specific operations are not implemented for MLX
# MLX uses Metal Performance Shaders (MPS) for GPU acceleration instead
