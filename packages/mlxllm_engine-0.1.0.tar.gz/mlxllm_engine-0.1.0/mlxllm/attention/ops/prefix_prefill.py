# SPDX-License-Identifier: Apache-2.0
"""
Prefix caching and prefill operations.

Prefix caching allows sharing KV cache for common prompt prefixes,
reducing redundant computation for repeated prompts.
"""

from __future__ import annotations

import mlx.core as mx


def prefix_prefill_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
    prefix_cache: tuple[mx.array, mx.array] | None = None,
    prefix_length: int = 0,
    scale: float | None = None,
) -> tuple[mx.array, tuple[mx.array, mx.array]]:
    """
    Attention with prefix caching.

    If a prefix cache is provided, it's reused for the prefix portion,
    and only the new tokens are computed.

    Args:
        query: Query tensor [batch, num_heads, seq_len, head_dim].
        key: Key tensor [batch, num_heads, seq_len, head_dim].
        value: Value tensor [batch, num_heads, seq_len, head_dim].
        prefix_cache: Optional cached (K, V) for prefix.
        prefix_length: Length of the prefix to reuse from cache.
        scale: Attention scale factor.

    Returns:
        Tuple of (attention_output, updated_cache).
    """
    batch_size, num_heads, seq_len, head_dim = query.shape

    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    # Combine prefix cache with new KV if available
    if prefix_cache is not None and prefix_length > 0:
        prefix_key, prefix_value = prefix_cache

        # Only use the prefix portion
        prefix_key = prefix_key[:, :, :prefix_length, :]
        prefix_value = prefix_value[:, :, :prefix_length, :]

        # Concatenate prefix with new KV
        full_key = mx.concatenate([prefix_key, key], axis=2)
        full_value = mx.concatenate([prefix_value, value], axis=2)
    else:
        full_key = key
        full_value = value

    # Standard attention computation
    scores = mx.matmul(query, mx.transpose(full_key, [0, 1, 3, 2])) * scale

    # Causal masking
    seq_len_kv = full_key.shape[2]
    if seq_len < seq_len_kv:
        # Create causal mask only for the query positions
        mask = mx.triu(
            mx.full((seq_len, seq_len_kv), float("-inf")),
            k=1
        )
        scores = scores + mask

    attn_weights = mx.softmax(scores, axis=-1)
    output = mx.matmul(attn_weights, full_value)

    # Update cache with full KV
    updated_cache = (full_key, full_value)

    return output, updated_cache


def compute_prefix_hash(
    token_ids: list[int],
) -> int:
    """
    Compute a hash for a token sequence prefix.

    This is used to identify matching prefixes for cache reuse.

    Args:
        token_ids: List of token IDs.

    Returns:
        Hash value for the sequence.
    """
    # Simple hash - in production, use a more robust hashing scheme
    return hash(tuple(token_ids))


def find_common_prefix_length(
    tokens_a: list[int],
    tokens_b: list[int],
) -> int:
    """
    Find the length of the common prefix between two token sequences.

    Args:
        tokens_a: First token sequence.
        tokens_b: Second token sequence.

    Returns:
        Length of common prefix.
    """
    min_len = min(len(tokens_a), len(tokens_b))

    for i in range(min_len):
        if tokens_a[i] != tokens_b[i]:
            return i

    return min_len


class PrefixCache:
    """
    Cache for storing and reusing prompt prefixes.

    This allows multiple requests with similar prefixes to share
    the computed KV cache, reducing redundant computation.
    """

    def __init__(self, max_cache_size: int = 100):
        """
        Initialize prefix cache.

        Args:
            max_cache_size: Maximum number of prefixes to cache.
        """
        self.max_cache_size = max_cache_size
        self.cache: dict[int, tuple[list[int], tuple[mx.array, mx.array]]] = {}
        self.access_order: list[int] = []

    def get(
        self,
        token_ids: list[int],
    ) -> tuple[tuple[mx.array, mx.array], int] | None:
        """
        Get cached KV for a token sequence.

        Args:
            token_ids: Token sequence to look up.

        Returns:
            Tuple of ((key_cache, value_cache), prefix_length) if found, None otherwise.
        """
        # Try to find an exact or prefix match
        for cached_hash, (cached_tokens, cached_kv) in self.cache.items():
            prefix_len = find_common_prefix_length(token_ids, cached_tokens)

            if prefix_len > 0:
                # Update access order for LRU
                if cached_hash in self.access_order:
                    self.access_order.remove(cached_hash)
                self.access_order.append(cached_hash)

                return cached_kv, prefix_len

        return None

    def put(
        self,
        token_ids: list[int],
        kv_cache: tuple[mx.array, mx.array],
    ) -> None:
        """
        Store KV cache for a token sequence.

        Args:
            token_ids: Token sequence.
            kv_cache: (key_cache, value_cache) tuple.
        """
        cache_hash = compute_prefix_hash(token_ids)

        # Evict oldest if cache is full
        if len(self.cache) >= self.max_cache_size:
            oldest_hash = self.access_order.pop(0)
            del self.cache[oldest_hash]

        self.cache[cache_hash] = (token_ids.copy(), kv_cache)
        self.access_order.append(cache_hash)

    def clear(self) -> None:
        """Clear all cached prefixes."""
        self.cache.clear()
        self.access_order.clear()

    def __len__(self) -> int:
        """Get number of cached prefixes."""
        return len(self.cache)
