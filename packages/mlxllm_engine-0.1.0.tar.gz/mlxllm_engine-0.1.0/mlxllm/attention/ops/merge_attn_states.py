# SPDX-License-Identifier: Apache-2.0
"""Merge attention states from multiple sources."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def merge_attention_states(
    prefill_output: mx.array | None,
    decode_output: mx.array | None,
    prefill_lens: mx.array | None,
    decode_lens: mx.array | None,
) -> mx.array:
    """
    Merge attention outputs from prefill and decode phases.

    This is used in chunked prefill where some sequences are in prefill
    and others are in decode simultaneously.

    Args:
        prefill_output: Prefill attention output [num_prefill_tokens, num_heads, head_dim].
        decode_output: Decode attention output [num_decode_tokens, num_heads, head_dim].
        prefill_lens: Sequence lengths for prefill [num_prefill_seqs].
        decode_lens: Sequence lengths for decode [num_decode_seqs].

    Returns:
        Merged output [total_tokens, num_heads, head_dim].
    """
    # If only one type of output, return it directly
    if prefill_output is None and decode_output is None:
        raise ValueError("At least one of prefill_output or decode_output must be provided")

    if prefill_output is None:
        return decode_output

    if decode_output is None:
        return prefill_output

    # Concatenate outputs
    merged = mx.concatenate([prefill_output, decode_output], axis=0)

    return merged


def split_attention_states(
    output: mx.array,
    num_prefill_tokens: int,
    num_decode_tokens: int,
) -> tuple[mx.array | None, mx.array | None]:
    """
    Split merged attention output back into prefill and decode.

    Args:
        output: Merged output [total_tokens, num_heads, head_dim].
        num_prefill_tokens: Number of prefill tokens.
        num_decode_tokens: Number of decode tokens.

    Returns:
        Tuple of (prefill_output, decode_output).
    """
    total_tokens = output.shape[0]

    if total_tokens != num_prefill_tokens + num_decode_tokens:
        raise ValueError(
            f"Total tokens {total_tokens} != "
            f"prefill {num_prefill_tokens} + decode {num_decode_tokens}"
        )

    if num_prefill_tokens == 0:
        return None, output

    if num_decode_tokens == 0:
        return output, None

    # Split at the boundary
    prefill_output = output[:num_prefill_tokens]
    decode_output = output[num_prefill_tokens:]

    return prefill_output, decode_output


def gather_attention_output(
    output: mx.array,
    indices: mx.array,
) -> mx.array:
    """
    Gather attention output using indices.

    Used to reorder outputs when sequences are processed out of order.

    Args:
        output: Attention output [num_tokens, num_heads, head_dim].
        indices: Gather indices [num_output_tokens].

    Returns:
        Gathered output [num_output_tokens, num_heads, head_dim].
    """
    return output[indices]


def scatter_attention_output(
    output: mx.array,
    indices: mx.array,
    total_size: int,
) -> mx.array:
    """
    Scatter attention output to specific positions.

    Args:
        output: Attention output [num_tokens, num_heads, head_dim].
        indices: Scatter indices [num_tokens].
        total_size: Total size of output tensor.

    Returns:
        Scattered output [total_size, num_heads, head_dim].
    """
    num_heads, head_dim = output.shape[1], output.shape[2]

    # Initialize output tensor
    scattered = mx.zeros((total_size, num_heads, head_dim), dtype=output.dtype)

    # Scatter values
    # Note: MLX doesn't have native scatter, so we use indexing
    for i, idx in enumerate(indices):
        scattered[int(idx)] = output[i]

    return scattered
