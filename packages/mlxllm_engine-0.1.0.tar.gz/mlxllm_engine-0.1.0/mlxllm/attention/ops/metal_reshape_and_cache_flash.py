# SPDX-License-Identifier: Apache-2.0
"""
Metal-optimized reshaping and caching operations for flash attention.

These operations handle the reshaping of attention tensors and updating
the KV cache efficiently using Metal acceleration.
"""

from __future__ import annotations

import mlx.core as mx


def metal_reshape_and_cache_flash(
    key: mx.array,
    value: mx.array,
    kv_cache: tuple[mx.array, mx.array] | None = None,
    cache_position: int | None = None,
) -> tuple[mx.array, mx.array, tuple[mx.array, mx.array]]:
    """
    Reshape K/V tensors and update KV cache for flash attention.

    Args:
        key: Key tensor [batch, seq_len, num_kv_heads, head_dim].
        value: Value tensor [batch, seq_len, num_kv_heads, head_dim].
        kv_cache: Optional (key_cache, value_cache) tuple.
        cache_position: Position to insert new KV in cache.

    Returns:
        Tuple of (reshaped_key, reshaped_value, updated_cache).
    """
    batch_size, seq_len, num_kv_heads, head_dim = key.shape

    # Reshape for flash attention: [batch, num_kv_heads, seq_len, head_dim]
    key_reshaped = mx.transpose(key, [0, 2, 1, 3])
    value_reshaped = mx.transpose(value, [0, 2, 1, 3])

    # Update cache if provided
    if kv_cache is not None:
        key_cache, value_cache = kv_cache

        if cache_position is not None:
            # Update cache at specific position
            end_position = cache_position + seq_len
            key_cache[:, :, cache_position:end_position, :] = key_reshaped
            value_cache[:, :, cache_position:end_position, :] = value_reshaped
        else:
            # Append to cache
            key_cache = mx.concatenate([key_cache, key_reshaped], axis=2)
            value_cache = mx.concatenate([value_cache, value_reshaped], axis=2)

        updated_cache = (key_cache, value_cache)
    else:
        # Initialize new cache
        updated_cache = (key_reshaped, value_reshaped)

    return key_reshaped, value_reshaped, updated_cache


def reshape_qkv_for_flash_attention(
    query: mx.array,
    key: mx.array,
    value: mx.array,
) -> tuple[mx.array, mx.array, mx.array]:
    """
    Reshape Q, K, V tensors for flash attention computation.

    Flash attention expects inputs in [batch, num_heads, seq_len, head_dim] format.

    Args:
        query: Query [batch, seq_len, num_heads, head_dim].
        key: Key [batch, seq_len, num_kv_heads, head_dim].
        value: Value [batch, seq_len, num_kv_heads, head_dim].

    Returns:
        Tuple of (q, k, v) in flash attention format.
    """
    # Transpose: [batch, seq_len, num_heads, head_dim] -> [batch, num_heads, seq_len, head_dim]
    q = mx.transpose(query, [0, 2, 1, 3])
    k = mx.transpose(key, [0, 2, 1, 3])
    v = mx.transpose(value, [0, 2, 1, 3])

    return q, k, v


def reshape_flash_attention_output(
    output: mx.array,
) -> mx.array:
    """
    Reshape flash attention output back to standard format.

    Args:
        output: Flash attention output [batch, num_heads, seq_len, head_dim].

    Returns:
        Reshaped output [batch, seq_len, num_heads, head_dim].
    """
    # Transpose back: [batch, num_heads, seq_len, head_dim] -> [batch, seq_len, num_heads, head_dim]
    return mx.transpose(output, [0, 2, 1, 3])


def update_kv_cache_inplace(
    key_cache: mx.array,
    value_cache: mx.array,
    new_key: mx.array,
    new_value: mx.array,
    positions: mx.array,
) -> tuple[mx.array, mx.array]:
    """
    Update KV cache in-place at specified positions.

    Args:
        key_cache: Existing key cache [batch, num_heads, max_seq_len, head_dim].
        value_cache: Existing value cache [batch, num_heads, max_seq_len, head_dim].
        new_key: New keys to insert [batch, num_heads, new_seq_len, head_dim].
        new_value: New values to insert [batch, num_heads, new_seq_len, head_dim].
        positions: Positions to update [batch, new_seq_len].

    Returns:
        Updated (key_cache, value_cache).
    """
    batch_size, num_heads, new_seq_len, head_dim = new_key.shape

    # For simplicity, we update sequentially
    # In a real implementation, you'd use scatter/gather operations
    for b in range(batch_size):
        for i in range(new_seq_len):
            pos = int(positions[b, i])
            key_cache[b, :, pos, :] = new_key[b, :, i, :]
            value_cache[b, :, pos, :] = new_value[b, :, i, :]

    return key_cache, value_cache


def allocate_kv_cache(
    batch_size: int,
    num_kv_heads: int,
    max_seq_len: int,
    head_dim: int,
    dtype: mx.Dtype = mx.float16,
) -> tuple[mx.array, mx.array]:
    """
    Allocate empty KV cache tensors.

    Args:
        batch_size: Batch size.
        num_kv_heads: Number of KV heads.
        max_seq_len: Maximum sequence length to cache.
        head_dim: Head dimension.
        dtype: Data type for cache.

    Returns:
        Tuple of (key_cache, value_cache).
    """
    shape = (batch_size, num_kv_heads, max_seq_len, head_dim)
    key_cache = mx.zeros(shape, dtype=dtype)
    value_cache = mx.zeros(shape, dtype=dtype)
    return key_cache, value_cache


def get_cache_length(kv_cache: tuple[mx.array, mx.array] | None) -> int:
    """
    Get the current length of the KV cache.

    Args:
        kv_cache: (key_cache, value_cache) tuple or None.

    Returns:
        Cache length (0 if no cache).
    """
    if kv_cache is None:
        return 0
    key_cache, _ = kv_cache
    return key_cache.shape[2]  # seq_len dimension
