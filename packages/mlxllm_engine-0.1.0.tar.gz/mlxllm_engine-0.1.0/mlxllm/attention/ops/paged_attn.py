# SPDX-License-Identifier: Apache-2.0
"""Paged attention operations for MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def paged_attention(
    query: mx.array,
    key_cache: mx.array,
    value_cache: mx.array,
    block_tables: mx.array,
    context_lens: mx.array,
    block_size: int,
    scale: float | None = None,
) -> mx.array:
    """
    Paged attention with block-based KV cache.

    This is a high-level wrapper around metal_paged_attention that provides
    additional validation and preprocessing.

    Args:
        query: Query [batch, num_heads, head_dim].
        key_cache: Key cache [num_blocks, block_size, num_kv_heads, head_dim].
        value_cache: Value cache [num_blocks, block_size, num_kv_heads, head_dim].
        block_tables: Block table [batch, max_blocks] mapping sequence to blocks.
        context_lens: Context lengths [batch].
        block_size: Number of tokens per block.
        scale: Attention scale factor.

    Returns:
        Attention output [batch, num_heads, head_dim].
    """
    from mlxllm.attention.ops.metal_decode_attention import metal_paged_attention

    # Validate inputs first
    if len(query.shape) != 3:
        raise ValueError(f"Query must be 3D [batch, num_heads, head_dim], got {query.shape}")

    batch_size, num_heads, head_dim = query.shape

    if scale is None:
        scale = 1.0 / (head_dim ** 0.5)

    if len(block_tables.shape) != 2:
        raise ValueError(f"Block tables must be 2D [batch, max_blocks], got {block_tables.shape}")

    if len(context_lens.shape) != 1:
        raise ValueError(f"Context lengths must be 1D [batch], got {context_lens.shape}")

    if block_tables.shape[0] != batch_size:
        raise ValueError(
            f"Block tables batch size {block_tables.shape[0]} != query batch size {batch_size}"
        )

    if context_lens.shape[0] != batch_size:
        raise ValueError(
            f"Context lengths size {context_lens.shape[0]} != query batch size {batch_size}"
        )

    # Combine key and value caches
    # [num_blocks, 2, block_size, num_kv_heads, head_dim]
    num_blocks = key_cache.shape[0]
    num_kv_heads = key_cache.shape[2]

    kv_cache = mx.zeros(
        (num_blocks, 2, block_size, num_kv_heads, head_dim),
        dtype=key_cache.dtype
    )
    kv_cache[:, 0, :, :, :] = key_cache
    kv_cache[:, 1, :, :, :] = value_cache

    # Add sequence dimension for compatibility
    query = mx.expand_dims(query, 1)  # [batch, 1, num_heads, head_dim]

    # Call Metal paged attention
    output = metal_paged_attention(
        query=query,
        kv_cache=kv_cache,
        block_tables=block_tables,
        context_lens=context_lens,
        block_size=block_size,
        scale=scale,
    )

    # Remove sequence dimension
    output = mx.squeeze(output, 1)  # [batch, num_heads, head_dim]

    return output


def reshape_and_cache(
    key: mx.array,
    value: mx.array,
    key_cache: mx.array,
    value_cache: mx.array,
    slot_mapping: mx.array,
) -> None:
    """
    Reshape keys/values and update cache.

    Args:
        key: Keys [num_tokens, num_kv_heads, head_dim].
        value: Values [num_tokens, num_kv_heads, head_dim].
        key_cache: Key cache [num_blocks, block_size, num_kv_heads, head_dim].
        value_cache: Value cache [num_blocks, block_size, num_kv_heads, head_dim].
        slot_mapping: Slot indices [num_tokens].
    """
    from mlxllm.attention.ops.metal_decode_attention import metal_reshape_and_cache

    # Stack key_cache and value_cache into a single kv_cache
    # [num_blocks, block_size, num_kv_heads, head_dim] -> [num_blocks, 2, block_size, num_kv_heads, head_dim]
    kv_cache = mx.stack([key_cache, value_cache], axis=1)

    metal_reshape_and_cache(
        key=key,
        value=value,
        kv_cache=kv_cache,
        slot_mapping=slot_mapping,
    )


def update_kv_cache(
    kv_cache: mx.array,
    key: mx.array,
    value: mx.array,
    slot_mapping: mx.array,
) -> None:
    """
    Update KV cache with new keys/values.

    Args:
        kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
        key: Keys [num_tokens, num_kv_heads, head_dim].
        value: Values [num_tokens, num_kv_heads, head_dim].
        slot_mapping: Slot indices [num_tokens].
    """
    from mlxllm.attention.ops.metal_decode_attention import metal_update_kv_cache

    metal_update_kv_cache(
        kv_cache=kv_cache,
        key=key,
        value=value,
        slot_mapping=slot_mapping,
    )
