# SPDX-License-Identifier: Apache-2.0
"""Attention operations for MLX-LLM."""

from mlxllm.attention.ops.metal_decode_attention import (
    metal_paged_attention,
    metal_reshape_and_cache,
    metal_update_kv_cache,
)
from mlxllm.attention.ops.metal_flash_attention import (
    metal_flash_attention,
    metal_flash_attention_prefill,
    metal_flash_attention_varlen,
)
from mlxllm.attention.ops.metal_unified_attention import (
    MetalAttentionBackend,
    MetalFlashAttentionBackend,
)

__all__ = [
    # Flash attention ops
    "metal_flash_attention",
    "metal_flash_attention_prefill",
    "metal_flash_attention_varlen",
    # Paged attention ops
    "metal_paged_attention",
    "metal_update_kv_cache",
    "metal_reshape_and_cache",
    # Unified backends
    "MetalAttentionBackend",
    "MetalFlashAttentionBackend",
]
