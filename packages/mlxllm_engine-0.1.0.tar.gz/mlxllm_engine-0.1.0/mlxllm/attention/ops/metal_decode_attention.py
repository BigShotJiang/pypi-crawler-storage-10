# SPDX-License-Identifier: Apache-2.0
"""Metal-accelerated paged attention for decode phase in MLX-LLM."""

from __future__ import annotations

from typing import TYPE_CHECKING

import mlx.core as mx

if TYPE_CHECKING:
    pass


def metal_paged_attention(
    query: mx.array,
    kv_cache: mx.array,
    block_tables: list[list[int]],
    context_lens: list[int],
    block_size: int = 16,
    scale: float | None = None,
) -> mx.array:
    """
    Metal-accelerated paged attention for decode phase.

    Uses block-based KV cache to efficiently handle variable-length sequences.

    Args:
        query: Query tensor [batch_size, 1, num_heads, head_dim].
        kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
        block_tables: Block table for each sequence. block_tables[i] contains
            the list of block IDs allocated to sequence i.
        context_lens: Context length (number of cached tokens) for each sequence.
        block_size: Number of tokens per block.
        scale: Attention scale factor. If None, uses 1/sqrt(head_dim).

    Returns:
        Attention output [batch_size, 1, num_heads, head_dim].
    """
    batch_size, _, num_heads, head_dim = query.shape
    num_kv_heads = kv_cache.shape[3]

    if scale is None:
        scale = 1.0 / (head_dim**0.5)

    # Handle GQA/MQA by computing number of groups
    num_groups = num_heads // num_kv_heads

    outputs = []

    for i in range(batch_size):
        # Get query for this sequence
        seq_query = query[i : i + 1]  # [1, 1, num_heads, head_dim]

        # Get block table and context length
        seq_blocks = block_tables[i]
        seq_len = int(context_lens[i])

        if len(seq_blocks) == 0 or seq_len == 0:
            # No context - return zeros
            outputs.append(mx.zeros_like(seq_query))
            continue

        # Gather keys and values from blocks
        keys_list = []
        values_list = []

        for block_id in seq_blocks:
            if block_id < 0:
                # Invalid block - skip
                continue

            # Get K, V from cache
            # kv_cache[block_id, 0] = keys [block_size, num_kv_heads, head_dim]
            # kv_cache[block_id, 1] = values [block_size, num_kv_heads, head_dim]
            block_keys = kv_cache[block_id, 0]  # [block_size, num_kv_heads, head_dim]
            block_values = kv_cache[block_id, 1]  # [block_size, num_kv_heads, head_dim]

            keys_list.append(block_keys)
            values_list.append(block_values)

        # Concatenate all blocks
        # [num_blocks * block_size, num_kv_heads, head_dim]
        all_keys = mx.concatenate(keys_list, axis=0)
        all_values = mx.concatenate(values_list, axis=0)

        # Trim to actual context length
        all_keys = all_keys[:seq_len]  # [seq_len, num_kv_heads, head_dim]
        all_values = all_values[:seq_len]  # [seq_len, num_kv_heads, head_dim]

        # Handle GQA/MQA - repeat KV heads to match query heads
        if num_groups > 1:
            # [seq_len, num_kv_heads, head_dim] -> [seq_len, num_heads, head_dim]
            all_keys = mx.repeat(all_keys, num_groups, axis=1)
            all_values = mx.repeat(all_values, num_groups, axis=1)

        # Transpose for attention
        # Query: [1, 1, num_heads, head_dim] -> [1, num_heads, 1, head_dim]
        seq_query = mx.transpose(seq_query, [0, 2, 1, 3])

        # Keys: [seq_len, num_heads, head_dim] -> [1, num_heads, seq_len, head_dim]
        all_keys = mx.expand_dims(all_keys, 0)
        all_keys = mx.transpose(all_keys, [0, 2, 1, 3])

        # Values: [seq_len, num_heads, head_dim] -> [1, num_heads, seq_len, head_dim]
        all_values = mx.expand_dims(all_values, 0)
        all_values = mx.transpose(all_values, [0, 2, 1, 3])

        # Compute attention scores: Q @ K^T
        # [1, num_heads, 1, head_dim] @ [1, num_heads, head_dim, seq_len]
        # -> [1, num_heads, 1, seq_len]
        scores = mx.matmul(seq_query, mx.transpose(all_keys, [0, 1, 3, 2])) * scale

        # Apply softmax
        attn_weights = mx.softmax(scores, axis=-1)

        # Compute output: attn @ V
        # [1, num_heads, 1, seq_len] @ [1, num_heads, seq_len, head_dim]
        # -> [1, num_heads, 1, head_dim]
        seq_output = mx.matmul(attn_weights, all_values)

        # Transpose back: [1, num_heads, 1, head_dim] -> [1, 1, num_heads, head_dim]
        seq_output = mx.transpose(seq_output, [0, 2, 1, 3])

        outputs.append(seq_output)

    # Concatenate all sequences
    output = mx.concatenate(outputs, axis=0)

    return output


def metal_update_kv_cache(
    kv_cache: mx.array,
    key: mx.array,
    value: mx.array,
    slot_mapping: list[tuple[int, int]],
) -> None:
    """
    Update KV cache with new keys and values.

    Args:
        kv_cache: KV cache to update [num_blocks, 2, block_size, num_kv_heads, head_dim].
        key: New keys [batch_size, seq_len, num_kv_heads, head_dim].
        value: New values [batch_size, seq_len, num_kv_heads, head_dim].
        slot_mapping: Maps each token position to (block_id, offset_in_block).
    """
    batch_size, seq_len, num_kv_heads, head_dim = key.shape

    # Flatten batch and sequence dimensions
    keys_flat = mx.reshape(key, [-1, num_kv_heads, head_dim])
    values_flat = mx.reshape(value, [-1, num_kv_heads, head_dim])

    # Update each position
    for token_idx, (block_id, offset) in enumerate(slot_mapping):
        if block_id < 0:
            # Invalid block - skip
            continue

        # Update cache at [block_id, 0/1, offset, :, :]
        kv_cache[block_id, 0, offset] = keys_flat[token_idx]
        kv_cache[block_id, 1, offset] = values_flat[token_idx]


def metal_reshape_and_cache(
    key: mx.array,
    value: mx.array,
    kv_cache: mx.array,
    slot_mapping: mx.array,
) -> None:
    """
    Reshape and cache key/value tensors.

    Optimized version that uses array indexing for batch updates.

    Args:
        key: Keys [num_tokens, num_kv_heads, head_dim].
        value: Values [num_tokens, num_kv_heads, head_dim].
        kv_cache: KV cache [num_blocks, 2, block_size, num_kv_heads, head_dim].
        slot_mapping: Flat slot indices [num_tokens] where slot = block_id * block_size + offset.
    """
    num_tokens = key.shape[0]
    block_size = kv_cache.shape[2]

    # Compute block IDs and offsets
    block_ids = slot_mapping // block_size
    offsets = slot_mapping % block_size

    # Update cache (simplified - actual implementation would use scatter)
    for i in range(num_tokens):
        block_id = int(block_ids[i])
        offset = int(offsets[i])

        if block_id >= 0:
            kv_cache[block_id, 0, offset] = key[i]
            kv_cache[block_id, 1, offset] = value[i]
