# SPDX-License-Identifier: Apache-2.0
"""Sampling parameters for text generation in MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class SamplingParams:
    """
    Parameters for sampling during text generation.

    This class controls how tokens are sampled from the model's output distribution.
    """

    # Basic sampling
    temperature: float = 1.0
    """Temperature for sampling. Higher = more random, lower = more deterministic."""

    top_p: float = 1.0
    """Nucleus sampling threshold. Sample from smallest set of tokens with cumulative probability >= top_p."""

    top_k: int = -1
    """Top-k sampling. Sample from top k tokens. -1 = disabled."""

    # Generation control
    max_tokens: int | None = 16
    """Maximum number of tokens to generate. None = unlimited (until EOS)."""

    min_tokens: int = 0
    """Minimum number of tokens to generate before allowing EOS."""

    # Stopping criteria
    stop: list[str] | None = None
    """List of strings that stop generation when encountered."""

    stop_token_ids: list[int] | None = None
    """List of token IDs that stop generation."""

    include_stop_str_in_output: bool = False
    """Include the stop string in the output."""

    # Advanced sampling
    presence_penalty: float = 0.0
    """Penalty for tokens that have appeared (regardless of frequency). Range: [-2.0, 2.0]."""

    frequency_penalty: float = 0.0
    """Penalty based on token frequency in the generated text. Range: [-2.0, 2.0]."""

    repetition_penalty: float = 1.0
    """Penalty for repeating tokens. 1.0 = no penalty, >1.0 = penalize."""

    # Logprobs
    logprobs: int | None = None
    """Number of log probabilities to return per token. None = disabled."""

    prompt_logprobs: int | None = None
    """Number of log probabilities for prompt tokens. None = disabled."""

    # Beam search
    n: int = 1
    """Number of sequences to generate (for parallel sampling or beam search)."""

    best_of: int | None = None
    """Generate best_of sequences and return top n. None = disabled."""

    use_beam_search: bool = False
    """Use beam search instead of sampling."""

    length_penalty: float = 1.0
    """Length penalty for beam search. >1.0 encourages longer sequences."""

    early_stopping: bool = False
    """Stop beam search when at least n sequences are done."""

    # Special tokens
    skip_special_tokens: bool = True
    """Skip special tokens in output text."""

    spaces_between_special_tokens: bool = True
    """Add spaces between special tokens."""

    # Structured output
    guided_json: dict[str, Any] | None = None
    """JSON schema for guided generation."""

    guided_regex: str | None = None
    """Regex pattern for guided generation."""

    guided_grammar: str | None = None
    """Grammar for guided generation (e.g., BNF)."""

    # Advanced
    seed: int | None = None
    """Random seed for reproducible generation."""

    logit_bias: dict[int, float] | None = None
    """Logit bias for specific tokens. {token_id: bias}."""

    def validate(self) -> None:
        """Validate sampling parameters."""
        if self.temperature < 0:
            raise ValueError(f"temperature must be non-negative, got {self.temperature}")

        if self.top_p < 0 or self.top_p > 1:
            raise ValueError(f"top_p must be in [0, 1], got {self.top_p}")

        if self.top_k < -1 or self.top_k == 0:
            raise ValueError(f"top_k must be -1 or positive, got {self.top_k}")

        if self.max_tokens is not None and self.max_tokens < 1:
            raise ValueError(f"max_tokens must be positive, got {self.max_tokens}")

        if self.min_tokens < 0:
            raise ValueError(f"min_tokens must be non-negative, got {self.min_tokens}")

        if self.presence_penalty < -2.0 or self.presence_penalty > 2.0:
            raise ValueError(
                f"presence_penalty must be in [-2.0, 2.0], got {self.presence_penalty}"
            )

        if self.frequency_penalty < -2.0 or self.frequency_penalty > 2.0:
            raise ValueError(
                f"frequency_penalty must be in [-2.0, 2.0], got {self.frequency_penalty}"
            )

        if self.repetition_penalty < 0:
            raise ValueError(
                f"repetition_penalty must be non-negative, got {self.repetition_penalty}"
            )

        if self.n < 1:
            raise ValueError(f"n must be positive, got {self.n}")

        if self.best_of is not None and self.best_of < self.n:
            raise ValueError(f"best_of ({self.best_of}) must be >= n ({self.n})")

        if self.length_penalty < 0:
            raise ValueError(
                f"length_penalty must be non-negative, got {self.length_penalty}"
            )

        # Validate that beam search and sampling parameters are compatible
        if self.use_beam_search:
            if self.temperature != 1.0:
                raise ValueError("temperature must be 1.0 when using beam search")
            if self.top_p != 1.0:
                raise ValueError("top_p must be 1.0 when using beam search")
            if self.top_k != -1:
                raise ValueError("top_k must be -1 when using beam search")

    @classmethod
    def from_defaults(
        cls,
        temperature: float = 1.0,
        top_p: float = 1.0,
        max_tokens: int | None = 16,
        **kwargs,
    ) -> SamplingParams:
        """
        Create SamplingParams with custom defaults.

        Args:
            temperature: Sampling temperature.
            top_p: Nucleus sampling threshold.
            max_tokens: Maximum tokens to generate.
            **kwargs: Additional parameters.

        Returns:
            SamplingParams instance.
        """
        return cls(
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            **kwargs,
        )

    def __repr__(self) -> str:
        """String representation of sampling params."""
        parts = []
        if self.temperature != 1.0:
            parts.append(f"temp={self.temperature}")
        if self.top_p != 1.0:
            parts.append(f"top_p={self.top_p}")
        if self.top_k != -1:
            parts.append(f"top_k={self.top_k}")
        if self.max_tokens is not None:
            parts.append(f"max={self.max_tokens}")

        params_str = ", ".join(parts) if parts else "defaults"
        return f"SamplingParams({params_str})"
