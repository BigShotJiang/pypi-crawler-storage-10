# SPDX-License-Identifier: Apache-2.0
"""Chat utilities for MLX-LLM entry points."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Literal, TypeAlias, TypedDict, Union

logger = logging.getLogger(__name__)

# Type definitions for chat messages
ChatTemplateContentFormatOption = Literal["auto", "string", "openai"]


class ChatCompletionContentPartTextParam(TypedDict, total=False):
    """Text content part."""

    text: str
    type: Literal["text"]


class ImageURL(TypedDict, total=False):
    """Image URL."""

    url: str
    detail: Literal["auto", "low", "high"] | None


class ChatCompletionContentPartImageParam(TypedDict, total=False):
    """Image content part."""

    image_url: ImageURL
    type: Literal["image_url"]


class AudioURL(TypedDict, total=False):
    """Audio URL."""

    url: str


class ChatCompletionContentPartAudioParam(TypedDict, total=False):
    """Audio content part."""

    audio_url: AudioURL
    type: Literal["audio_url"]


class VideoURL(TypedDict, total=False):
    """Video URL."""

    url: str


class ChatCompletionContentPartVideoParam(TypedDict, total=False):
    """Video content part."""

    video_url: VideoURL
    type: Literal["video_url"]


# Union of all content part types
ChatCompletionContentPartParam: TypeAlias = Union[
    ChatCompletionContentPartTextParam,
    ChatCompletionContentPartImageParam,
    ChatCompletionContentPartAudioParam,
    ChatCompletionContentPartVideoParam,
    str,  # Simple text string
]


class ChatCompletionMessageParam(TypedDict, total=False):
    """Chat completion message parameter."""

    role: str
    content: str | List[ChatCompletionContentPartParam]
    name: str | None
    tool_calls: List[Dict[str, Any]] | None
    tool_call_id: str | None


class ConversationMessage(TypedDict, total=False):
    """Conversation message."""

    role: str
    content: str
    name: str | None
    tool_calls: List[Dict[str, Any]] | None


def load_chat_template(
    chat_template: Path | str | None,
) -> str | None:
    """
    Load chat template from file or string.

    Args:
        chat_template: Path to template file or template string.

    Returns:
        Chat template string, or None if not provided.
    """
    if chat_template is None:
        return None

    # If it's a path that exists, read it
    if isinstance(chat_template, (Path, str)):
        path = Path(chat_template)
        if path.exists() and path.is_file():
            try:
                return path.read_text(encoding="utf-8")
            except Exception as e:
                logger.warning(f"Failed to read chat template from {path}: {e}")
                return None

    # Otherwise treat as template string
    return str(chat_template)


def resolve_chat_template_content_format(
    content_format: ChatTemplateContentFormatOption,
    model_config: Any | None = None,
) -> str:
    """
    Resolve chat template content format.

    Args:
        content_format: Content format option.
        model_config: Optional model configuration.

    Returns:
        Resolved format string.
    """
    if content_format == "auto":
        # Auto-detect based on model
        # For now, default to "openai"
        return "openai"
    return content_format


def resolve_hf_chat_template(
    tokenizer: Any,
    chat_template: str | None = None,
    tools: List[Dict[str, Any]] | None = None,
    model_config: Any | None = None,
) -> str | None:
    """
    Resolve HuggingFace chat template.

    Args:
        tokenizer: HuggingFace tokenizer.
        chat_template: Optional custom chat template.
        tools: Optional tool definitions.
        model_config: Optional model configuration.

    Returns:
        Resolved chat template string.
    """
    if chat_template:
        return chat_template

    # Try to get from tokenizer
    if hasattr(tokenizer, "chat_template"):
        return tokenizer.chat_template

    # Fallback to default
    logger.warning("No chat template found, using default")
    return None


def resolve_mistral_chat_template(
    chat_template: str | None = None,
) -> str | None:
    """
    Resolve Mistral chat template.

    Args:
        chat_template: Optional custom chat template.

    Returns:
        Resolved Mistral chat template string.
    """
    if chat_template:
        logger.info("Using custom chat template for Mistral model")
        return chat_template

    # Mistral uses a specific format
    logger.info("Using default Mistral chat template")
    return None


def apply_hf_chat_template(
    tokenizer: Any,
    messages: List[ChatCompletionMessageParam],
    chat_template: str | None = None,
    add_generation_prompt: bool = True,
    tools: List[Dict[str, Any]] | None = None,
    documents: List[Dict[str, Any]] | None = None,
    **kwargs: Any,
) -> str:
    """
    Apply HuggingFace chat template to messages.

    Args:
        tokenizer: HuggingFace tokenizer with chat template.
        messages: List of chat messages.
        chat_template: Optional custom chat template.
        add_generation_prompt: Whether to add generation prompt.
        tools: Optional tool definitions.
        documents: Optional document context.
        **kwargs: Additional arguments for apply_chat_template.

    Returns:
        Formatted prompt string.
    """
    # Convert messages to standard format
    formatted_messages = []
    for msg in messages:
        formatted_msg = {"role": msg["role"]}

        # Handle content
        content = msg.get("content")
        if isinstance(content, str):
            formatted_msg["content"] = content
        elif isinstance(content, list):
            # Extract text from content parts
            text_parts = []
            for part in content:
                if isinstance(part, str):
                    text_parts.append(part)
                elif isinstance(part, dict):
                    if part.get("type") == "text":
                        text_parts.append(part.get("text", ""))
            formatted_msg["content"] = " ".join(text_parts)
        else:
            formatted_msg["content"] = ""

        # Add other fields
        if "name" in msg:
            formatted_msg["name"] = msg["name"]
        if "tool_calls" in msg:
            formatted_msg["tool_calls"] = msg["tool_calls"]
        if "tool_call_id" in msg:
            formatted_msg["tool_call_id"] = msg["tool_call_id"]

        formatted_messages.append(formatted_msg)

    # Apply chat template using tokenizer
    try:
        if hasattr(tokenizer, "apply_chat_template"):
            # Check if this is our Tokenizer wrapper or a HuggingFace tokenizer
            # Our wrapper only accepts (messages, add_generation_prompt)
            # HuggingFace tokenizer accepts more parameters
            try:
                # Try with minimal parameters (works for both)
                prompt = tokenizer.apply_chat_template(
                    formatted_messages,
                    add_generation_prompt=add_generation_prompt,
                )
                return prompt
            except TypeError as e:
                # If that failed, try the HuggingFace signature with full params
                if "tokenizer" in str(type(tokenizer)).lower() and hasattr(tokenizer, "tokenizer"):
                    # This is our wrapper, use the underlying tokenizer
                    template_kwargs = {
                        "add_generation_prompt": add_generation_prompt,
                        "tokenize": False,
                    }
                    if tools is not None:
                        template_kwargs["tools"] = tools
                    if documents is not None:
                        template_kwargs["documents"] = documents

                    prompt = tokenizer.tokenizer.apply_chat_template(
                        formatted_messages,
                        **template_kwargs,
                        **kwargs,
                    )
                    return prompt
                else:
                    raise
        else:
            # Fallback: simple concatenation
            logger.warning("Tokenizer has no apply_chat_template method, using fallback")
            return _simple_chat_format(formatted_messages, add_generation_prompt)
    except Exception as e:
        logger.error(f"Failed to apply chat template: {e}")
        return _simple_chat_format(formatted_messages, add_generation_prompt)


def apply_mistral_chat_template(
    tokenizer: Any,
    messages: List[ChatCompletionMessageParam],
    chat_template: str | None = None,
    add_generation_prompt: bool = True,
    **kwargs: Any,
) -> str:
    """
    Apply Mistral chat template to messages.

    Args:
        tokenizer: Mistral tokenizer.
        messages: List of chat messages.
        chat_template: Optional custom chat template.
        add_generation_prompt: Whether to add generation prompt.
        **kwargs: Additional arguments.

    Returns:
        Formatted prompt string.
    """
    # Mistral uses special tokens
    # Format: <s>[INST] {user message} [/INST] {assistant message}</s>
    # For MLX-LLM, we'll use the generic HF approach for now
    return apply_hf_chat_template(
        tokenizer,
        messages,
        chat_template,
        add_generation_prompt,
        **kwargs,
    )


def _simple_chat_format(
    messages: List[Dict[str, Any]],
    add_generation_prompt: bool = True,
) -> str:
    """
    Simple fallback chat format.

    Args:
        messages: List of message dictionaries.
        add_generation_prompt: Whether to add generation prompt.

    Returns:
        Simple formatted prompt string.
    """
    parts = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            parts.append(f"System: {content}\n\n")
        elif role == "user":
            parts.append(f"User: {content}\n\n")
        elif role == "assistant":
            parts.append(f"Assistant: {content}\n\n")
        else:
            parts.append(f"{role.capitalize()}: {content}\n\n")

    if add_generation_prompt:
        parts.append("Assistant: ")

    return "".join(parts)


def parse_chat_messages(
    messages: List[ChatCompletionMessageParam],
    model_config: Any | None = None,
) -> tuple[List[ConversationMessage], List[Any]]:
    """
    Parse chat messages and extract multi-modal content.

    Args:
        messages: List of chat messages.
        model_config: Optional model configuration.

    Returns:
        Tuple of (parsed messages, multi-modal data).
    """
    parsed_messages = []
    multimodal_data = []

    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content")

        # Handle simple string content
        if isinstance(content, str):
            parsed_messages.append({
                "role": role,
                "content": content,
                "name": msg.get("name"),
                "tool_calls": msg.get("tool_calls"),
            })
            continue

        # Handle list of content parts
        if isinstance(content, list):
            text_parts = []
            for part in content:
                if isinstance(part, str):
                    text_parts.append(part)
                elif isinstance(part, dict):
                    part_type = part.get("type", "text")

                    if part_type == "text":
                        text_parts.append(part.get("text", ""))
                    elif part_type == "image_url":
                        # Extract image URL
                        image_url = part.get("image_url", {})
                        if isinstance(image_url, dict):
                            url = image_url.get("url", "")
                        else:
                            url = str(image_url)
                        multimodal_data.append({"type": "image", "url": url})
                        text_parts.append("<image>")
                    elif part_type == "audio_url":
                        # Extract audio URL
                        audio_url = part.get("audio_url", {})
                        if isinstance(audio_url, dict):
                            url = audio_url.get("url", "")
                        else:
                            url = str(audio_url)
                        multimodal_data.append({"type": "audio", "url": url})
                        text_parts.append("<audio>")
                    elif part_type == "video_url":
                        # Extract video URL
                        video_url = part.get("video_url", {})
                        if isinstance(video_url, dict):
                            url = video_url.get("url", "")
                        else:
                            url = str(video_url)
                        multimodal_data.append({"type": "video", "url": url})
                        text_parts.append("<video>")

            parsed_messages.append({
                "role": role,
                "content": " ".join(text_parts),
                "name": msg.get("name"),
                "tool_calls": msg.get("tool_calls"),
            })
        else:
            # Fallback
            parsed_messages.append({
                "role": role,
                "content": str(content) if content else "",
                "name": msg.get("name"),
                "tool_calls": msg.get("tool_calls"),
            })

    return parsed_messages, multimodal_data


def parse_chat_messages_futures(
    messages: List[ChatCompletionMessageParam],
    model_config: Any | None = None,
) -> Any:
    """
    Parse chat messages with future/async support.

    Args:
        messages: List of chat messages.
        model_config: Optional model configuration.

    Returns:
        Parsed messages (possibly as a Future).
    """
    # For now, just call synchronous version
    # TODO: Add async/futures support if needed
    return parse_chat_messages(messages, model_config)


def extract_tool_calls(message: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract tool calls from a message.

    Args:
        message: Message dictionary.

    Returns:
        List of tool call dictionaries.
    """
    tool_calls = message.get("tool_calls", [])
    if not tool_calls:
        return []

    extracted = []
    for tool_call in tool_calls:
        if isinstance(tool_call, dict):
            extracted.append({
                "id": tool_call.get("id", ""),
                "type": tool_call.get("type", "function"),
                "function": tool_call.get("function", {}),
            })

    return extracted


def format_tool_response(
    tool_call_id: str,
    result: Any,
) -> ChatCompletionMessageParam:
    """
    Format a tool response as a chat message.

    Args:
        tool_call_id: ID of the tool call.
        result: Tool execution result.

    Returns:
        Chat message with tool response.
    """
    return {
        "role": "tool",
        "content": str(result),
        "tool_call_id": tool_call_id,
    }


def validate_chat_messages(messages: List[ChatCompletionMessageParam]) -> None:
    """
    Validate chat messages.

    Args:
        messages: List of chat messages.

    Raises:
        ValueError: If messages are invalid.
    """
    if not messages:
        raise ValueError("At least one message is required")

    for i, msg in enumerate(messages):
        if "role" not in msg:
            raise ValueError(f"Message {i} missing required field 'role'")

        role = msg["role"]
        if role not in ("system", "user", "assistant", "tool"):
            raise ValueError(f"Message {i} has invalid role: {role}")

        if "content" not in msg and "tool_calls" not in msg:
            raise ValueError(
                f"Message {i} must have either 'content' or 'tool_calls'"
            )


def count_message_tokens(
    messages: List[ChatCompletionMessageParam],
    tokenizer: Any | None = None,
) -> int:
    """
    Count tokens in chat messages.

    Args:
        messages: List of chat messages.
        tokenizer: Optional tokenizer for accurate counting.

    Returns:
        Estimated token count.
    """
    if tokenizer and hasattr(tokenizer, "encode"):
        # Use actual tokenizer
        total_tokens = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total_tokens += len(tokenizer.encode(content))
            elif isinstance(content, list):
                # Count text parts
                for part in content:
                    if isinstance(part, str):
                        total_tokens += len(tokenizer.encode(part))
                    elif isinstance(part, dict) and part.get("type") == "text":
                        total_tokens += len(tokenizer.encode(part.get("text", "")))
        return total_tokens
    else:
        # Rough estimate: ~4 characters per token
        total_chars = 0
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                for part in content:
                    if isinstance(part, str):
                        total_chars += len(part)
                    elif isinstance(part, dict) and part.get("type") == "text":
                        total_chars += len(part.get("text", ""))
        return total_chars // 4
