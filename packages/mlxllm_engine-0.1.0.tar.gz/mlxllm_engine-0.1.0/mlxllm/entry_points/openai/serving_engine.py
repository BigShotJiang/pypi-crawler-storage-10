# SPDX-License-Identifier: Apache-2.0
"""Base serving class for OpenAI-compatible API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, List, Optional

from mlxllm.entry_points.openai.protocol import ErrorInfo, ErrorResponse, UsageInfo
from mlxllm.sampling_params import SamplingParams

if TYPE_CHECKING:
    from mlxllm.config import ModelConfig
    from mlxllm.engine.protocol import EngineClient

logger = logging.getLogger(__name__)


class OpenAIServing:
    """
    Base class for OpenAI-compatible API serving.

    All serving classes (chat, completion, embedding, etc.) inherit from this
    and share common functionality like request validation, error handling,
    and token counting.
    """

    def __init__(
        self,
        engine_client: EngineClient,
        model_config: ModelConfig,
        served_model_names: List[str],
        response_role: str = "assistant",
    ) -> None:
        """
        Initialize serving base.

        Args:
            engine_client: Async engine client for generation.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            response_role: Default role for responses (usually "assistant").
        """
        self.engine_client = engine_client
        self.model_config = model_config
        self.served_model_names = served_model_names
        self.response_role = response_role
        self.max_model_len = getattr(model_config, "max_model_len", 2048)

        logger.info(
            f"Initialized {self.__class__.__name__} with models: {served_model_names}"
        )

    def create_error_response(
        self,
        message: str,
        err_type: str = "BadRequestError",
        status_code: int = 400,
    ) -> ErrorResponse:
        """
        Create an error response.

        Args:
            message: Error message.
            err_type: Error type.
            status_code: HTTP status code.

        Returns:
            ErrorResponse object.
        """
        return ErrorResponse(
            error=ErrorInfo(
                message=message,
                type=err_type,
                code=str(status_code),
            )
        )

    def _validate_model(self, model: str) -> Optional[ErrorResponse]:
        """
        Validate that the requested model is served.

        Args:
            model: Model name from request.

        Returns:
            ErrorResponse if invalid, None if valid.
        """
        if model not in self.served_model_names:
            return self.create_error_response(
                message=f"Model '{model}' not found. Available models: {self.served_model_names}",
                err_type="NotFoundError",
                status_code=404,
            )
        return None

    def _validate_prompt_length(
        self,
        prompt_length: int,
        max_tokens: Optional[int] = None,
    ) -> Optional[ErrorResponse]:
        """
        Validate prompt length against model limits.

        Args:
            prompt_length: Length of prompt in tokens.
            max_tokens: Maximum tokens to generate.

        Returns:
            ErrorResponse if invalid, None if valid.
        """
        if prompt_length >= self.max_model_len:
            return self.create_error_response(
                message=f"Prompt length ({prompt_length}) exceeds maximum model length ({self.max_model_len})",
                err_type="InvalidRequestError",
                status_code=400,
            )

        if max_tokens is not None:
            if prompt_length + max_tokens > self.max_model_len:
                return self.create_error_response(
                    message=f"Prompt length ({prompt_length}) + max_tokens ({max_tokens}) "
                    f"exceeds maximum model length ({self.max_model_len})",
                    err_type="InvalidRequestError",
                    status_code=400,
                )

        return None

    def create_sampling_params(
        self,
        temperature: float = 1.0,
        top_p: float = 1.0,
        max_tokens: Optional[int] = None,
        stop: Optional[List[str]] = None,
        presence_penalty: float = 0.0,
        frequency_penalty: float = 0.0,
        seed: Optional[int] = None,
        logprobs: bool = False,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> SamplingParams:
        """
        Create sampling parameters from request.

        Args:
            temperature: Sampling temperature.
            top_p: Nucleus sampling threshold.
            max_tokens: Maximum tokens to generate.
            stop: Stop sequences.
            presence_penalty: Presence penalty.
            frequency_penalty: Frequency penalty.
            seed: Random seed.
            logprobs: Whether to return log probabilities.
            top_logprobs: Number of top log probs to return.
            **kwargs: Additional parameters.

        Returns:
            SamplingParams object.
        """
        # Ensure max_tokens doesn't exceed model limit
        if max_tokens is None:
            max_tokens = self.max_model_len // 2  # Default to half

        max_tokens = min(max_tokens, self.max_model_len)

        # Convert stop to list if string
        if isinstance(stop, str):
            stop = [stop]

        return SamplingParams(
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            stop=stop,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            logprobs=logprobs,
            # top_logprobs parameter not in base SamplingParams
            # Will be added if needed
        )

    def create_usage_info(
        self,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> UsageInfo:
        """
        Create usage information.

        Args:
            prompt_tokens: Number of prompt tokens.
            completion_tokens: Number of completion tokens.

        Returns:
            UsageInfo object.
        """
        return UsageInfo(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
        )

    async def _tokenize(self, text: str) -> List[int]:
        """
        Tokenize text.

        Args:
            text: Text to tokenize.

        Returns:
            List of token IDs.
        """
        # Get tokenizer from engine
        tokenizer = await self.engine_client.get_tokenizer()
        if hasattr(tokenizer, "encode"):
            return tokenizer.encode(text)
        else:
            # Fallback: rough estimate
            return [0] * (len(text) // 4)

    async def _detokenize(self, token_ids: List[int]) -> str:
        """
        Detokenize token IDs.

        Args:
            token_ids: List of token IDs.

        Returns:
            Decoded text.
        """
        tokenizer = await self.engine_client.get_tokenizer()
        if hasattr(tokenizer, "decode"):
            return tokenizer.decode(token_ids)
        else:
            return f"<{len(token_ids)} tokens>"

    def _get_model_name(self, request_model: str) -> str:
        """
        Get the actual model name for the request.

        Args:
            request_model: Model name from request.

        Returns:
            Actual model name to use.
        """
        # If exact match, use it
        if request_model in self.served_model_names:
            return request_model

        # Otherwise return first served model
        return self.served_model_names[0] if self.served_model_names else request_model

    def _check_engine_health(self) -> Optional[ErrorResponse]:
        """
        Check if engine is healthy.

        Returns:
            ErrorResponse if unhealthy, None if healthy.
        """
        if not hasattr(self.engine_client, "is_running"):
            return None

        if not self.engine_client.is_running:
            return self.create_error_response(
                message="Engine is not running",
                err_type="ServiceUnavailableError",
                status_code=503,
            )

        if hasattr(self.engine_client, "errored") and self.engine_client.errored:
            return self.create_error_response(
                message="Engine has encountered an error",
                err_type="InternalServerError",
                status_code=500,
            )

        return None
