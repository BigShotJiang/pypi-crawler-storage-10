# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible scoring endpoint implementation."""

from __future__ import annotations

import time
from typing import List

from mlxllm.engine.protocol import EngineClient
from mlxllm.entry_points.openai.protocol import (
    ErrorResponse,
    ScoreRequest,
    ScoreResponse,
    UsageInfo,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing
from mlxllm.entry_points.score_utils import (
    compute_pairwise_scores,
    rank_documents,
)


class OpenAIServingScore(OpenAIServing):
    """
    OpenAI-compatible scoring serving handler.

    Handles semantic similarity scoring and document ranking tasks.
    """

    def __init__(
        self,
        engine_client: EngineClient,
        model_config,
        served_model_names: List[str],
        *,
        response_role: str = "assistant",
    ):
        """
        Initialize scoring serving handler.

        Args:
            engine_client: Engine client for inference.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            response_role: Role for responses (default: "assistant").
        """
        super().__init__(
            engine_client=engine_client,
            model_config=model_config,
            served_model_names=served_model_names,
            response_role=response_role,
        )

    async def create_score(
        self,
        request: ScoreRequest,
        request_id: str,
    ) -> ScoreResponse | ErrorResponse:
        """
        Create similarity scores between queries and documents.

        Args:
            request: Score request.
            request_id: Unique request identifier.

        Returns:
            Score response or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        # Validate inputs
        if not request.query:
            return self.create_error_response(
                message="Query is required",
                err_type="invalid_request_error",
                status_code=400,
            )

        if not request.documents:
            return self.create_error_response(
                message="Documents are required",
                err_type="invalid_request_error",
                status_code=400,
            )

        try:
            # Handle single query or multiple queries
            queries = request.query if isinstance(request.query, list) else [request.query]

            # Generate embeddings for queries
            query_embeddings = []
            total_prompt_tokens = 0

            for query in queries:
                query_token_ids = await self._tokenize(query)
                total_prompt_tokens += len(query_token_ids)

                # Validate prompt length
                error_check_ret = self._validate_prompt_length(
                    len(query_token_ids),
                    max_tokens=0,  # No generation needed for embeddings
                )
                if error_check_ret is not None:
                    return error_check_ret

                # Get embedding
                outputs = await self.engine_client.encode(
                    inputs=[query],
                    pooling_type=request.pooling_type or "mean",
                    request_id=f"{request_id}_query_{len(query_embeddings)}",
                )

                if not outputs or not outputs[0].outputs:
                    return self.create_error_response(
                        message="Failed to generate query embedding",
                        err_type="internal_server_error",
                        status_code=500,
                    )

                query_embeddings.append(outputs[0].outputs[0].embedding)

            # Generate embeddings for documents
            document_embeddings = []

            for doc in request.documents:
                doc_token_ids = await self._tokenize(doc)
                total_prompt_tokens += len(doc_token_ids)

                error_check_ret = self._validate_prompt_length(
                    len(doc_token_ids),
                    max_tokens=0,
                )
                if error_check_ret is not None:
                    return error_check_ret

                outputs = await self.engine_client.encode(
                    inputs=[doc],
                    pooling_type=request.pooling_type or "mean",
                    request_id=f"{request_id}_doc_{len(document_embeddings)}",
                )

                if not outputs or not outputs[0].outputs:
                    return self.create_error_response(
                        message="Failed to generate document embedding",
                        err_type="internal_server_error",
                        status_code=500,
                    )

                document_embeddings.append(outputs[0].outputs[0].embedding)

            # Compute scores
            if request.return_documents:
                # Rank documents for each query
                results = []
                for query, query_emb in zip(queries, query_embeddings):
                    ranked = rank_documents(
                        query_embedding=query_emb,
                        document_embeddings=document_embeddings,
                        documents=request.documents,
                        top_k=request.top_k or len(request.documents),
                    )
                    results.extend(ranked)
            else:
                # Compute pairwise scores
                results = compute_pairwise_scores(
                    queries=queries,
                    documents=request.documents,
                    embeddings_queries=query_embeddings,
                    embeddings_docs=document_embeddings,
                )

            # Create usage info
            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=0,
                total_tokens=total_prompt_tokens,
            )

            # Create response
            return ScoreResponse(
                id=request_id,
                object="score",
                created=int(time.time()),
                model=request.model,
                results=results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Scoring error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )

    async def create_rerank(
        self,
        request: ScoreRequest,
        request_id: str,
    ) -> ScoreResponse | ErrorResponse:
        """
        Rerank documents based on relevance to query.

        This is similar to scoring but optimized for ranking tasks.

        Args:
            request: Score request with query and documents.
            request_id: Unique request identifier.

        Returns:
            Score response with ranked documents or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        if not request.query or not request.documents:
            return self.create_error_response(
                message="Query and documents are required",
                err_type="invalid_request_error",
                status_code=400,
            )

        # Ensure single query for reranking
        query = request.query if isinstance(request.query, str) else request.query[0]

        try:
            # Get query embedding
            query_token_ids = await self._tokenize(query)
            total_prompt_tokens = len(query_token_ids)

            outputs = await self.engine_client.encode(
                inputs=[query],
                pooling_type=request.pooling_type or "mean",
                request_id=f"{request_id}_query",
            )

            if not outputs or not outputs[0].outputs:
                return self.create_error_response(
                    message="Failed to generate query embedding",
                    err_type="internal_server_error",
                    status_code=500,
                )

            query_embedding = outputs[0].outputs[0].embedding

            # Get document embeddings
            document_embeddings = []

            for i, doc in enumerate(request.documents):
                doc_token_ids = await self._tokenize(doc)
                total_prompt_tokens += len(doc_token_ids)

                outputs = await self.engine_client.encode(
                    inputs=[doc],
                    pooling_type=request.pooling_type or "mean",
                    request_id=f"{request_id}_doc_{i}",
                )

                if outputs and outputs[0].outputs:
                    document_embeddings.append(outputs[0].outputs[0].embedding)

            # Rank documents
            ranked_results = rank_documents(
                query_embedding=query_embedding,
                document_embeddings=document_embeddings,
                documents=request.documents,
                top_k=request.top_k or len(request.documents),
            )

            # Create usage info
            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=0,
                total_tokens=total_prompt_tokens,
            )

            # Create response
            return ScoreResponse(
                id=request_id,
                object="rerank",
                created=int(time.time()),
                model=request.model,
                results=ranked_results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Reranking error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )
