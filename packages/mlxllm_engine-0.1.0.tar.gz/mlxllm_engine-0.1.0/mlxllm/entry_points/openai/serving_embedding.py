# SPDX-License-Identifier: Apache-2.0
"""Embedding serving for OpenAI-compatible API."""

from __future__ import annotations

import logging

from mlxllm.entry_points.openai.protocol import (
    EmbeddingData,
    EmbeddingRequest,
    EmbeddingResponse,
    ErrorResponse,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing

logger = logging.getLogger(__name__)


class OpenAIServingEmbedding(OpenAIServing):
    """Handles embedding endpoints."""

    async def create_embedding(
        self,
        request: EmbeddingRequest,
        request_id: str,
    ) -> EmbeddingResponse | ErrorResponse:
        """
        Create embeddings.

        Args:
            request: Embedding request.
            request_id: Unique request ID.

        Returns:
            EmbeddingResponse or ErrorResponse.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            return error

        # Check engine health
        error = self._check_engine_health()
        if error:
            return error

        try:
            # Handle input (can be string or list)
            if isinstance(request.input, str):
                inputs = [request.input]
            elif isinstance(request.input, list):
                if all(isinstance(i, str) for i in request.input):
                    inputs = request.input
                else:
                    # Token IDs
                    return self.create_error_response(
                        message="Token ID inputs not yet supported for embeddings",
                        err_type="InvalidRequestError",
                        status_code=400,
                    )
            else:
                inputs = [str(request.input)]

            # Generate embeddings for each input
            embeddings_data = []
            total_tokens = 0

            for idx, text in enumerate(inputs):
                # Tokenize
                token_ids = await self._tokenize(text)
                total_tokens += len(token_ids)

                # TODO: Generate actual embeddings via engine
                # For now, create placeholder embeddings
                embedding_dim = getattr(self.model_config, "hidden_size", 768)
                embedding = [0.0] * embedding_dim

                # If dimensions specified, truncate/pad
                if request.dimensions and request.dimensions != embedding_dim:
                    if request.dimensions < len(embedding):
                        embedding = embedding[: request.dimensions]
                    else:
                        embedding.extend([0.0] * (request.dimensions - len(embedding)))

                embeddings_data.append(
                    EmbeddingData(
                        embedding=embedding,
                        index=idx,
                    )
                )

            # Create response
            response = EmbeddingResponse(
                model=self._get_model_name(request.model),
                data=embeddings_data,
                usage=self.create_usage_info(
                    prompt_tokens=total_tokens,
                    completion_tokens=0,
                ),
            )

            return response

        except Exception as e:
            logger.error(f"Embedding error: {e}", exc_info=True)
            return self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )
