# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible pooling endpoint implementation."""

from __future__ import annotations

import time
from typing import List

from mlxllm.engine.protocol import EngineClient
from mlxllm.entry_points.openai.protocol import (
    ErrorResponse,
    PoolingRequest,
    PoolingResponse,
    PoolingResult,
    UsageInfo,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing


class OpenAIServingPooling(OpenAIServing):
    """
    OpenAI-compatible pooling serving handler.

    Handles different pooling strategies for extracting representations
    from token embeddings (mean, max, cls, last token, etc.).
    """

    def __init__(
        self,
        engine_client: EngineClient,
        model_config,
        served_model_names: List[str],
        *,
        response_role: str = "assistant",
    ):
        """
        Initialize pooling serving handler.

        Args:
            engine_client: Engine client for inference.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            response_role: Role for responses (default: "assistant").
        """
        super().__init__(
            engine_client=engine_client,
            model_config=model_config,
            served_model_names=served_model_names,
            response_role=response_role,
        )

    async def create_pooling(
        self,
        request: PoolingRequest,
        request_id: str,
    ) -> PoolingResponse | ErrorResponse:
        """
        Create pooled representations from input text.

        Args:
            request: Pooling request.
            request_id: Unique request identifier.

        Returns:
            Pooling response or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        # Validate input
        if not request.input:
            return self.create_error_response(
                message="Input text is required",
                err_type="invalid_request_error",
                status_code=400,
            )

        # Handle single input or list of inputs
        inputs = request.input if isinstance(request.input, list) else [request.input]

        # Validate pooling type
        valid_pooling_types = ["mean", "max", "cls", "last", "first"]
        pooling_type = request.pooling_type or "mean"
        if pooling_type not in valid_pooling_types:
            return self.create_error_response(
                message=f"Invalid pooling type: {pooling_type}. Must be one of: {', '.join(valid_pooling_types)}",
                err_type="invalid_request_error",
                status_code=400,
            )

        try:
            results = []
            total_prompt_tokens = 0

            for idx, text in enumerate(inputs):
                # Tokenize input
                token_ids = await self._tokenize(text)
                total_prompt_tokens += len(token_ids)

                # Validate prompt length
                error_check_ret = self._validate_prompt_length(
                    len(token_ids),
                    max_tokens=0,  # No generation needed
                )
                if error_check_ret is not None:
                    return error_check_ret

                # Get pooled representation
                outputs = await self.engine_client.encode(
                    inputs=[text],
                    pooling_type=pooling_type,
                    request_id=f"{request_id}_{idx}",
                )

                if not outputs or not outputs[0].outputs:
                    return self.create_error_response(
                        message="Failed to generate pooled representation",
                        err_type="internal_server_error",
                        status_code=500,
                    )

                output = outputs[0].outputs[0]
                embedding = output.embedding

                # Apply normalization if requested
                if request.normalize:
                    import math
                    norm = math.sqrt(sum(x * x for x in embedding))
                    if norm > 0:
                        embedding = [x / norm for x in embedding]

                # Truncate to requested dimensions if specified
                if request.dimensions and request.dimensions < len(embedding):
                    embedding = embedding[:request.dimensions]

                results.append(
                    PoolingResult(
                        index=idx,
                        embedding=embedding,
                        pooling_type=pooling_type,
                    )
                )

            # Create usage info
            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=0,
                total_tokens=total_prompt_tokens,
            )

            # Create response
            return PoolingResponse(
                id=request_id,
                object="pooling",
                created=int(time.time()),
                model=request.model,
                data=results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Pooling error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )

    async def create_multi_pooling(
        self,
        request: PoolingRequest,
        request_id: str,
    ) -> PoolingResponse | ErrorResponse:
        """
        Create multiple pooled representations using different strategies.

        This returns pooled embeddings for all requested pooling types.

        Args:
            request: Pooling request (pooling_type can be a list).
            request_id: Unique request identifier.

        Returns:
            Pooling response with multiple pooling results or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        if not request.input:
            return self.create_error_response(
                message="Input text is required",
                err_type="invalid_request_error",
                status_code=400,
            )

        inputs = request.input if isinstance(request.input, list) else [request.input]

        # Determine pooling types to use
        if isinstance(request.pooling_type, list):
            pooling_types = request.pooling_type
        else:
            pooling_types = [request.pooling_type or "mean"]

        valid_pooling_types = ["mean", "max", "cls", "last", "first"]
        for pt in pooling_types:
            if pt not in valid_pooling_types:
                return self.create_error_response(
                    message=f"Invalid pooling type: {pt}",
                    err_type="invalid_request_error",
                    status_code=400,
                )

        try:
            results = []
            total_prompt_tokens = 0

            for idx, text in enumerate(inputs):
                token_ids = await self._tokenize(text)
                total_prompt_tokens += len(token_ids)

                error_check_ret = self._validate_prompt_length(
                    len(token_ids),
                    max_tokens=0,
                )
                if error_check_ret is not None:
                    return error_check_ret

                # Generate pooled representation for each pooling type
                for pooling_type in pooling_types:
                    outputs = await self.engine_client.encode(
                        inputs=[text],
                        pooling_type=pooling_type,
                        request_id=f"{request_id}_{idx}_{pooling_type}",
                    )

                    if outputs and outputs[0].outputs:
                        output = outputs[0].outputs[0]
                        embedding = output.embedding

                        if request.normalize:
                            import math
                            norm = math.sqrt(sum(x * x for x in embedding))
                            if norm > 0:
                                embedding = [x / norm for x in embedding]

                        if request.dimensions and request.dimensions < len(embedding):
                            embedding = embedding[:request.dimensions]

                        results.append(
                            PoolingResult(
                                index=idx,
                                embedding=embedding,
                                pooling_type=pooling_type,
                            )
                        )

            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=0,
                total_tokens=total_prompt_tokens,
            )

            return PoolingResponse(
                id=request_id,
                object="pooling.multi",
                created=int(time.time()),
                model=request.model,
                data=results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Multi-pooling error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )
