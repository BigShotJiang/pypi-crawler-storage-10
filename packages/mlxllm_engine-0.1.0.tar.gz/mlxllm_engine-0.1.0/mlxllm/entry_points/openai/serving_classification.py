# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible classification endpoint implementation."""

from __future__ import annotations

import time
from typing import Dict, List

from mlxllm.engine.protocol import EngineClient
from mlxllm.entry_points.openai.protocol import (
    ClassificationRequest,
    ClassificationResponse,
    ClassificationResult,
    ErrorResponse,
    UsageInfo,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing
from mlxllm.sampling_params import SamplingParams


class OpenAIServingClassification(OpenAIServing):
    """
    OpenAI-compatible classification serving handler.

    Handles text classification tasks where the model assigns labels/categories
    to input text.
    """

    def __init__(
        self,
        engine_client: EngineClient,
        model_config,
        served_model_names: List[str],
        *,
        response_role: str = "assistant",
    ):
        """
        Initialize classification serving handler.

        Args:
            engine_client: Engine client for inference.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            response_role: Role for responses (default: "assistant").
        """
        super().__init__(
            engine_client=engine_client,
            model_config=model_config,
            served_model_names=served_model_names,
            response_role=response_role,
        )

    async def create_classification(
        self,
        request: ClassificationRequest,
        request_id: str,
    ) -> ClassificationResponse | ErrorResponse:
        """
        Create classification for input text.

        Args:
            request: Classification request.
            request_id: Unique request identifier.

        Returns:
            Classification response or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        # Validate input
        if not request.input:
            return self.create_error_response(
                message="Input text is required",
                err_type="invalid_request_error",
                status_code=400,
            )

        # Handle single input or list of inputs
        inputs = request.input if isinstance(request.input, list) else [request.input]

        try:
            # Process each input
            results = []
            total_prompt_tokens = 0
            total_completion_tokens = 0

            for text in inputs:
                # Create classification prompt
                # Format: "Classify the following text into one of these categories: {labels}\nText: {text}\nCategory:"
                labels_str = ", ".join(request.labels) if request.labels else "positive, negative, neutral"
                prompt = f"Classify the following text into one of these categories: {labels_str}\nText: {text}\nCategory:"

                # Tokenize prompt
                prompt_token_ids = await self._tokenize(prompt)
                total_prompt_tokens += len(prompt_token_ids)

                # Validate prompt length
                error_check_ret = self._validate_prompt_length(
                    len(prompt_token_ids),
                    max_tokens=10,  # Classification output is very short
                )
                if error_check_ret is not None:
                    return error_check_ret

                # Create sampling params for classification
                sampling_params = SamplingParams(
                    temperature=0.0,  # Deterministic for classification
                    max_tokens=10,
                    top_p=1.0,
                    stop=["\n", ".", ","],  # Stop at first label
                )

                # Generate classification
                outputs = await self.engine_client.generate(
                    prompt=prompt,
                    sampling_params=sampling_params,
                    request_id=f"{request_id}_{len(results)}",
                )

                if not outputs or not outputs[0].outputs:
                    return self.create_error_response(
                        message="Failed to generate classification",
                        err_type="internal_server_error",
                        status_code=500,
                    )

                # Extract classification label
                output = outputs[0].outputs[0]
                label = output.text.strip()

                # Calculate confidence (using logprobs if available)
                confidence = 1.0
                if output.logprobs:
                    # Average logprob as confidence proxy
                    avg_logprob = sum(output.logprobs) / len(output.logprobs)
                    confidence = min(1.0, max(0.0, avg_logprob + 1.0))

                total_completion_tokens += len(output.token_ids)

                results.append(
                    ClassificationResult(
                        text=text,
                        label=label,
                        confidence=confidence,
                    )
                )

            # Create usage info
            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=total_completion_tokens,
                total_tokens=total_prompt_tokens + total_completion_tokens,
            )

            # Create response
            return ClassificationResponse(
                id=request_id,
                object="classification",
                created=int(time.time()),
                model=request.model,
                results=results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Classification error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )

    async def create_zero_shot_classification(
        self,
        request: ClassificationRequest,
        request_id: str,
    ) -> ClassificationResponse | ErrorResponse:
        """
        Create zero-shot classification using natural language labels.

        This method uses the model's understanding of label meanings rather than
        requiring fine-tuning on specific labels.

        Args:
            request: Classification request.
            request_id: Unique request identifier.

        Returns:
            Classification response or error.
        """
        error_check_ret = self._validate_model(request.model)
        if error_check_ret is not None:
            return error_check_ret

        if not request.input or not request.labels:
            return self.create_error_response(
                message="Input text and labels are required",
                err_type="invalid_request_error",
                status_code=400,
            )

        inputs = request.input if isinstance(request.input, list) else [request.input]

        try:
            results = []
            total_prompt_tokens = 0
            total_completion_tokens = 0

            for text in inputs:
                # For each label, compute similarity/relevance score
                label_scores: Dict[str, float] = {}

                for label in request.labels:
                    # Create entailment prompt
                    prompt = f"""Given the text: "{text}"
Does this text relate to or describe "{label}"? Answer yes or no.
Answer:"""

                    prompt_token_ids = await self._tokenize(prompt)
                    total_prompt_tokens += len(prompt_token_ids)

                    sampling_params = SamplingParams(
                        temperature=0.0,
                        max_tokens=5,
                        top_p=1.0,
                        logprobs=1,
                    )

                    outputs = await self.engine_client.generate(
                        prompt=prompt,
                        sampling_params=sampling_params,
                        request_id=f"{request_id}_{len(results)}_{label}",
                    )

                    if outputs and outputs[0].outputs:
                        output = outputs[0].outputs[0]
                        response_text = output.text.strip().lower()
                        total_completion_tokens += len(output.token_ids)

                        # Score based on yes/no response
                        if "yes" in response_text:
                            score = 0.8
                        elif "no" in response_text:
                            score = 0.2
                        else:
                            score = 0.5

                        # Adjust by logprobs if available
                        if output.logprobs:
                            avg_logprob = sum(output.logprobs) / len(output.logprobs)
                            score *= min(1.0, max(0.1, avg_logprob + 1.5))

                        label_scores[label] = score

                # Select label with highest score
                if label_scores:
                    best_label = max(label_scores.items(), key=lambda x: x[1])
                    results.append(
                        ClassificationResult(
                            text=text,
                            label=best_label[0],
                            confidence=best_label[1],
                        )
                    )

            usage = UsageInfo(
                prompt_tokens=total_prompt_tokens,
                completion_tokens=total_completion_tokens,
                total_tokens=total_prompt_tokens + total_completion_tokens,
            )

            return ClassificationResponse(
                id=request_id,
                object="classification.zero_shot",
                created=int(time.time()),
                model=request.model,
                results=results,
                usage=usage,
            )

        except Exception as e:
            return self.create_error_response(
                message=f"Zero-shot classification error: {str(e)}",
                err_type="internal_server_error",
                status_code=500,
            )
