# SPDX-License-Identifier: Apache-2.0
"""CLI argument definitions for MLX-LLM OpenAI server."""

from __future__ import annotations

import argparse
from typing import Any


def make_arg_parser(parser: argparse.ArgumentParser) -> argparse.ArgumentParser:
    """
    Add arguments for OpenAI-compatible API server.

    Args:
        parser: Argument parser to add arguments to.

    Returns:
        Parser with added arguments.
    """
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path (HuggingFace or local)",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        default=None,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        default=None,
        help="Model revision (branch, tag, or commit)",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code from HuggingFace",
    )

    # Server arguments
    parser.add_argument(
        "--protocol",
        type=str,
        default="openai",
        choices=["openai", "anthropic"],
        help="API protocol to use (default: openai)",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind the server to",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind the server to",
    )
    parser.add_argument(
        "--ssl-keyfile",
        type=str,
        default=None,
        help="Path to SSL key file",
    )
    parser.add_argument(
        "--ssl-certfile",
        type=str,
        default=None,
        help="Path to SSL certificate file",
    )
    parser.add_argument(
        "--ssl-ca-certs",
        type=str,
        default=None,
        help="Path to SSL CA certificates file",
    )

    # Model configuration
    parser.add_argument(
        "--max-model-len",
        type=int,
        default=None,
        help="Maximum context length",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        default=None,
        choices=["q4_0", "q4_1", "q8_0"],
        help="Quantization method",
    )

    # Scheduling arguments
    parser.add_argument(
        "--max-num-seqs",
        type=int,
        default=256,
        help="Maximum number of sequences to batch",
    )
    parser.add_argument(
        "--max-num-batched-tokens",
        type=int,
        default=None,
        help="Maximum number of batched tokens",
    )

    # Memory arguments
    parser.add_argument(
        "--gpu-memory-utilization",
        type=float,
        default=0.9,
        help="Fraction of GPU memory to use (0.0-1.0)",
    )
    parser.add_argument(
        "--block-size",
        type=int,
        default=16,
        help="KV cache block size",
    )

    # Serving arguments
    parser.add_argument(
        "--served-model-name",
        type=str,
        default=None,
        action="append",
        help="Model name(s) to serve (can be specified multiple times)",
    )
    parser.add_argument(
        "--chat-template",
        type=str,
        default=None,
        help="Path to chat template file or template string",
    )
    parser.add_argument(
        "--response-role",
        type=str,
        default="assistant",
        help="Role for assistant responses",
    )

    # API features
    parser.add_argument(
        "--enable-cors",
        action="store_true",
        help="Enable CORS middleware",
    )
    parser.add_argument(
        "--allowed-origins",
        type=str,
        default=["*"],
        nargs="+",
        help="Allowed origins for CORS",
    )
    parser.add_argument(
        "--allowed-methods",
        type=str,
        default=["*"],
        nargs="+",
        help="Allowed methods for CORS",
    )
    parser.add_argument(
        "--allowed-headers",
        type=str,
        default=["*"],
        nargs="+",
        help="Allowed headers for CORS",
    )

    # Logging arguments
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level",
    )
    parser.add_argument(
        "--log-requests",
        action="store_true",
        help="Log all requests",
    )

    # Engine arguments
    parser.add_argument(
        "--seed",
        type=int,
        default=0,
        help="Random seed for sampling",
    )
    parser.add_argument(
        "--disable-log-stats",
        action="store_true",
        help="Disable periodic statistics logging",
    )

    # LoRA arguments
    parser.add_argument(
        "--lora-modules",
        type=str,
        default=None,
        nargs="+",
        help='LoRA modules in format "name=path"',
    )

    # Tool server arguments
    parser.add_argument(
        "--enable-tool-server",
        action="store_true",
        help="Enable tool server",
    )
    parser.add_argument(
        "--tool-server-port",
        type=int,
        default=8001,
        help="Port for tool server",
    )

    return parser


def validate_parsed_serve_args(args: Any) -> None:
    """
    Validate parsed serve arguments.

    Args:
        args: Parsed arguments.

    Raises:
        ValueError: If arguments are invalid.
    """
    # Validate port
    if args.port < 1 or args.port > 65535:
        raise ValueError(f"Invalid port: {args.port}")

    # Validate gpu_memory_utilization
    if args.gpu_memory_utilization < 0.0 or args.gpu_memory_utilization > 1.0:
        raise ValueError(
            f"gpu_memory_utilization must be between 0.0 and 1.0, got {args.gpu_memory_utilization}"
        )

    # Validate block_size
    if args.block_size < 1:
        raise ValueError(f"block_size must be >= 1, got {args.block_size}")

    # Validate max_num_seqs
    if args.max_num_seqs < 1:
        raise ValueError(f"max_num_seqs must be >= 1, got {args.max_num_seqs}")

    # If SSL is enabled, ensure both key and cert are provided
    if args.ssl_keyfile and not args.ssl_certfile:
        raise ValueError("ssl_certfile must be provided if ssl_keyfile is set")
    if args.ssl_certfile and not args.ssl_keyfile:
        raise ValueError("ssl_keyfile must be provided if ssl_certfile is set")

    # Parse LoRA modules
    if args.lora_modules:
        parsed_lora_modules = []
        for lora_spec in args.lora_modules:
            if "=" not in lora_spec:
                raise ValueError(
                    f"Invalid LoRA module specification: {lora_spec}. "
                    'Expected format: "name=path"'
                )
            name, path = lora_spec.split("=", 1)
            parsed_lora_modules.append({"name": name.strip(), "path": path.strip()})
        args.lora_modules = parsed_lora_modules

    # Set served model name if not provided
    if not args.served_model_name:
        # Extract model name from path
        model_name = args.model.split("/")[-1]
        args.served_model_name = [model_name]
