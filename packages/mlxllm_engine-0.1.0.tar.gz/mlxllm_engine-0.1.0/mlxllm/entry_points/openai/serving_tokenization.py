# SPDX-License-Identifier: Apache-2.0
"""Tokenization serving for OpenAI-compatible API."""

from __future__ import annotations

import logging

from mlxllm.entry_points.openai.protocol import (
    DetokenizeRequest,
    DetokenizeResponse,
    ErrorResponse,
    TokenizeRequest,
    TokenizeResponse,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing

logger = logging.getLogger(__name__)


class OpenAIServingTokenization(OpenAIServing):
    """Handles tokenization and detokenization endpoints."""

    async def tokenize(
        self,
        request: TokenizeRequest,
        request_id: str,
    ) -> TokenizeResponse | ErrorResponse:
        """
        Tokenize text.

        Args:
            request: Tokenization request.
            request_id: Unique request ID.

        Returns:
            TokenizeResponse or ErrorResponse.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            return error

        try:
            # Handle prompt (can be string or list)
            if isinstance(request.prompt, str):
                text = request.prompt
            elif isinstance(request.prompt, list):
                # Join multiple strings
                text = " ".join(str(p) for p in request.prompt)
            else:
                text = str(request.prompt)

            # Tokenize
            token_ids = await self._tokenize(text)

            # Create response
            response = TokenizeResponse(
                tokens=token_ids,
                count=len(token_ids),
                max_model_len=self.max_model_len,
            )

            return response

        except Exception as e:
            logger.error(f"Tokenization error: {e}", exc_info=True)
            return self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )

    async def detokenize(
        self,
        request: DetokenizeRequest,
        request_id: str,
    ) -> DetokenizeResponse | ErrorResponse:
        """
        Detokenize token IDs.

        Args:
            request: Detokenization request.
            request_id: Unique request ID.

        Returns:
            DetokenizeResponse or ErrorResponse.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            return error

        try:
            # Detokenize
            text = await self._detokenize(request.tokens)

            # Create response
            response = DetokenizeResponse(text=text)

            return response

        except Exception as e:
            logger.error(f"Detokenization error: {e}", exc_info=True)
            return self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )
