# SPDX-License-Identifier: Apache-2.0
"""OpenAI API protocol models for MLX-LLM."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


# === Base Models ===

class UsageInfo(BaseModel):
    """Token usage information."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ErrorInfo(BaseModel):
    """Error information."""

    message: str
    type: str
    param: Optional[str] = None
    code: Optional[str] = None


class ErrorResponse(BaseModel):
    """Error response."""

    error: ErrorInfo


# === Chat Completion Models ===

class ChatMessage(BaseModel):
    """Chat message."""

    role: str
    content: Optional[str] = None
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None


class ChatCompletionRequest(BaseModel):
    """Chat completion request."""

    model: str
    messages: List[ChatMessage]
    temperature: Optional[float] = 1.0
    top_p: Optional[float] = 1.0
    n: Optional[int] = 1
    max_tokens: Optional[int] = None
    max_completion_tokens: Optional[int] = None
    stop: Optional[Union[str, List[str]]] = None
    stream: Optional[bool] = False
    presence_penalty: Optional[float] = 0.0
    frequency_penalty: Optional[float] = 0.0
    logit_bias: Optional[Dict[str, float]] = None
    user: Optional[str] = None
    tools: Optional[List[Dict[str, Any]]] = None
    tool_choice: Optional[Union[str, Dict[str, Any]]] = None
    response_format: Optional[Dict[str, Any]] = None
    seed: Optional[int] = None
    logprobs: Optional[bool] = False
    top_logprobs: Optional[int] = None


class ChatCompletionResponseChoice(BaseModel):
    """Chat completion response choice."""

    index: int
    message: ChatMessage
    finish_reason: Optional[str] = None
    logprobs: Optional[Dict[str, Any]] = None


class ChatCompletionResponse(BaseModel):
    """Chat completion response."""

    id: str
    object: str = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionResponseChoice]
    usage: Optional[UsageInfo] = None
    system_fingerprint: Optional[str] = None


class ChatCompletionStreamResponseDelta(BaseModel):
    """Delta for streaming chat completion."""

    role: Optional[str] = None
    content: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None


class ChatCompletionStreamResponseChoice(BaseModel):
    """Streaming chat completion choice."""

    index: int
    delta: ChatCompletionStreamResponseDelta
    finish_reason: Optional[str] = None
    logprobs: Optional[Dict[str, Any]] = None


class ChatCompletionStreamResponse(BaseModel):
    """Streaming chat completion response."""

    id: str
    object: str = "chat.completion.chunk"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[ChatCompletionStreamResponseChoice]
    usage: Optional[UsageInfo] = None


# === Completion Models ===

class CompletionRequest(BaseModel):
    """Text completion request."""

    model: str
    prompt: Union[str, List[str], List[int], List[List[int]]]
    suffix: Optional[str] = None
    temperature: Optional[float] = 1.0
    top_p: Optional[float] = 1.0
    n: Optional[int] = 1
    max_tokens: Optional[int] = 16
    stop: Optional[Union[str, List[str]]] = None
    stream: Optional[bool] = False
    logprobs: Optional[int] = None
    echo: Optional[bool] = False
    presence_penalty: Optional[float] = 0.0
    frequency_penalty: Optional[float] = 0.0
    best_of: Optional[int] = None
    logit_bias: Optional[Dict[str, float]] = None
    user: Optional[str] = None
    seed: Optional[int] = None


class CompletionResponseChoice(BaseModel):
    """Completion response choice."""

    index: int
    text: str
    logprobs: Optional[Dict[str, Any]] = None
    finish_reason: Optional[str] = None


class CompletionResponse(BaseModel):
    """Completion response."""

    id: str
    object: str = "text_completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[CompletionResponseChoice]
    usage: Optional[UsageInfo] = None


class CompletionStreamResponse(BaseModel):
    """Streaming completion response."""

    id: str
    object: str = "text_completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[CompletionResponseChoice]


# === Embedding Models ===

class EmbeddingRequest(BaseModel):
    """Embedding request."""

    model: str
    input: Union[str, List[str], List[int], List[List[int]]]
    encoding_format: Optional[str] = "float"
    dimensions: Optional[int] = None
    user: Optional[str] = None


class EmbeddingData(BaseModel):
    """Embedding data."""

    object: str = "embedding"
    embedding: List[float]
    index: int


class EmbeddingResponse(BaseModel):
    """Embedding response."""

    object: str = "list"
    data: List[EmbeddingData]
    model: str
    usage: UsageInfo


# === Model Listing Models ===

class ModelCard(BaseModel):
    """Model information card."""

    id: str
    object: str = "model"
    created: int = Field(default_factory=lambda: int(time.time()))
    owned_by: str = "mlxllm"
    permission: List[Dict[str, Any]] = Field(default_factory=list)


class ModelList(BaseModel):
    """List of available models."""

    object: str = "list"
    data: List[ModelCard]


# === Tokenization Models ===

class TokenizeRequest(BaseModel):
    """Tokenization request."""

    model: str
    prompt: Union[str, List[str]]
    add_special_tokens: Optional[bool] = True


class TokenizeResponse(BaseModel):
    """Tokenization response."""

    tokens: List[int]
    count: int
    max_model_len: int


class DetokenizeRequest(BaseModel):
    """Detokenization request."""

    model: str
    tokens: List[int]


class DetokenizeResponse(BaseModel):
    """Detokenization response."""

    text: str


# === Classification Models ===

class ClassificationRequest(BaseModel):
    """Classification request."""

    model: str
    input: Union[str, List[str]]


class ClassificationResponse(BaseModel):
    """Classification response."""

    id: str
    object: str = "classification"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    predictions: List[Dict[str, Any]]


# === Scoring Models ===

class ScoreRequest(BaseModel):
    """Scoring/ranking request."""

    model: str
    query: Union[str, List[str]]
    documents: List[str]


class ScoreResponse(BaseModel):
    """Scoring response."""

    id: str
    object: str = "score"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    scores: List[float]


# === Pooling Models ===

class PoolingRequest(BaseModel):
    """Pooling request."""

    model: str
    input: Union[str, List[str]]
    pooling_type: Optional[str] = "mean"


class PoolingResponse(BaseModel):
    """Pooling response."""

    id: str
    object: str = "pooling"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    data: List[Dict[str, Any]]
    usage: Optional[UsageInfo] = None


# === Batch Processing Models ===

class BatchRequest(BaseModel):
    """Batch processing request."""

    input_file_id: str
    endpoint: str
    completion_window: str


class BatchResponse(BaseModel):
    """Batch processing response."""

    id: str
    object: str = "batch"
    endpoint: str
    errors: Optional[List[Dict[str, Any]]] = None
    input_file_id: str
    completion_window: str
    status: str
    output_file_id: Optional[str] = None
    error_file_id: Optional[str] = None
    created_at: int = Field(default_factory=lambda: int(time.time()))
    in_progress_at: Optional[int] = None
    expires_at: Optional[int] = None
    completed_at: Optional[int] = None
    failed_at: Optional[int] = None
    expired_at: Optional[int] = None
    cancelled_at: Optional[int] = None


# === Streaming Options ===

class StreamOptions(BaseModel):
    """Streaming options."""

    include_usage: Optional[bool] = False
    continuous_usage_stats: Optional[bool] = False


# === Embedding Chat/Completion Request Models ===

class EmbeddingChatRequest(ChatCompletionRequest):
    """Chat request that returns embeddings."""

    pass


class EmbeddingCompletionRequest(CompletionRequest):
    """Completion request that returns embeddings."""

    pass


class TokenizeChatRequest(ChatCompletionRequest):
    """Chat request that returns tokens."""

    pass


class TokenizeCompletionRequest(CompletionRequest):
    """Completion request that returns tokens."""

    pass


# === Transcription Models (Audio) ===

class TranscriptionRequest(BaseModel):
    """Audio transcription request."""

    file: Any  # File upload
    model: str
    language: Optional[str] = None
    prompt: Optional[str] = None
    response_format: Optional[str] = "json"
    temperature: Optional[float] = 0.0


class TranscriptionResponse(BaseModel):
    """Transcription response."""

    text: str


class TranslationRequest(BaseModel):
    """Audio translation request."""

    file: Any  # File upload
    model: str
    prompt: Optional[str] = None
    response_format: Optional[str] = "json"
    temperature: Optional[float] = 0.0


class TranslationResponse(BaseModel):
    """Translation response."""

    text: str


# === Response Formatting Models ===

class ResponsesRequest(BaseModel):
    """Request for formatted responses."""

    model: str
    messages: List[ChatMessage]
    response_format: Dict[str, Any]


class ResponsesResponse(BaseModel):
    """Formatted responses."""

    id: str
    object: str = "responses"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[Dict[str, Any]]


class StreamingResponsesResponse(BaseModel):
    """Streaming formatted responses."""

    id: str
    object: str = "responses.chunk"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: List[Dict[str, Any]]


# === LoRA Models ===

class LoadLoRAAdapterRequest(BaseModel):
    """Load LoRA adapter request."""

    lora_name: str
    lora_path: str


class UnloadLoRAAdapterRequest(BaseModel):
    """Unload LoRA adapter request."""

    lora_name: str


# === I/O Processor Models ===

class IOProcessorRequest(BaseModel):
    """I/O processor request."""

    model: str
    processor_type: str
    input_data: Dict[str, Any]


class IOProcessorResponse(BaseModel):
    """I/O processor response."""

    output_data: Dict[str, Any]


# === Pooling/Embedding Bytes Response ===

class EmbeddingBytesResponse(BaseModel):
    """Embedding response with bytes encoding."""

    object: str = "list"
    data: List[Dict[str, Any]]
    model: str
    usage: UsageInfo


class PoolingBytesResponse(BaseModel):
    """Pooling response with bytes encoding."""

    object: str = "list"
    data: List[Dict[str, Any]]
    model: str
    usage: UsageInfo


# === Rerank Models ===

class RerankRequest(BaseModel):
    """Reranking request."""

    model: str
    query: str
    documents: List[str]
    top_n: Optional[int] = None


class RerankResponse(BaseModel):
    """Reranking response."""

    id: str
    object: str = "rerank"
    model: str
    results: List[Dict[str, Any]]
    usage: Optional[UsageInfo] = None
