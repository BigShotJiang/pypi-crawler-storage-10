# SPDX-License-Identifier: Apache-2.0
"""Model management for OpenAI-compatible API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional

from pydantic import BaseModel

from mlxllm.entry_points.openai.protocol import ModelCard, ModelList
from mlxllm.entry_points.openai.serving_engine import OpenAIServing

if TYPE_CHECKING:
    from mlxllm.config import ModelConfig
    from mlxllm.engine.protocol import EngineClient

logger = logging.getLogger(__name__)


class LoRAModulePath(BaseModel):
    """LoRA module path specification."""

    name: str
    path: str


class BaseModelPath(BaseModel):
    """Base model path specification."""

    name: str
    model_path: str


class OpenAIServingModels(OpenAIServing):
    """Handles model listing and management endpoints."""

    def __init__(
        self,
        engine_client: EngineClient,
        model_config: ModelConfig,
        served_model_names: List[str],
        lora_modules: Optional[List[LoRAModulePath]] = None,
    ) -> None:
        """
        Initialize model serving.

        Args:
            engine_client: Async engine client.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            lora_modules: Optional LoRA modules.
        """
        super().__init__(
            engine_client=engine_client,
            model_config=model_config,
            served_model_names=served_model_names,
        )
        self.lora_modules = lora_modules or []
        self.loaded_loras = {}

    async def list_models(self) -> ModelList:
        """
        List all available models.

        Returns:
            ModelList with all served models.
        """
        model_cards = []

        # Add base models
        for model_name in self.served_model_names:
            model_cards.append(
                ModelCard(
                    id=model_name,
                    owned_by="mlxllm",
                    permission=[],
                )
            )

        # Add LoRA models
        for lora in self.lora_modules:
            model_cards.append(
                ModelCard(
                    id=f"{self.served_model_names[0]}:{lora.name}",
                    owned_by="mlxllm",
                    permission=[],
                )
            )

        return ModelList(data=model_cards)

    async def get_model_info(self, model_name: str) -> Optional[ModelCard]:
        """
        Get information about a specific model.

        Args:
            model_name: Name of the model.

        Returns:
            ModelCard if found, None otherwise.
        """
        if model_name in self.served_model_names:
            return ModelCard(
                id=model_name,
                owned_by="mlxllm",
                permission=[],
            )

        # Check LoRA models
        for lora in self.lora_modules:
            lora_model_name = f"{self.served_model_names[0]}:{lora.name}"
            if model_name == lora_model_name:
                return ModelCard(
                    id=lora_model_name,
                    owned_by="mlxllm",
                    permission=[],
                )

        return None

    async def load_lora_adapter(
        self,
        lora_name: str,
        lora_path: str,
    ) -> bool:
        """
        Load a LoRA adapter.

        Args:
            lora_name: Name for the LoRA adapter.
            lora_path: Path to LoRA weights.

        Returns:
            True if successful, False otherwise.
        """
        try:
            # TODO: Implement actual LoRA loading via engine
            logger.info(f"Loading LoRA adapter: {lora_name} from {lora_path}")
            self.loaded_loras[lora_name] = lora_path

            # Add to lora_modules list
            lora_module = LoRAModulePath(name=lora_name, path=lora_path)
            if lora_module not in self.lora_modules:
                self.lora_modules.append(lora_module)

            logger.info(f"Successfully loaded LoRA: {lora_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to load LoRA {lora_name}: {e}")
            return False

    async def unload_lora_adapter(self, lora_name: str) -> bool:
        """
        Unload a LoRA adapter.

        Args:
            lora_name: Name of the LoRA adapter to unload.

        Returns:
            True if successful, False otherwise.
        """
        try:
            if lora_name not in self.loaded_loras:
                logger.warning(f"LoRA {lora_name} not loaded")
                return False

            # TODO: Implement actual LoRA unloading via engine
            logger.info(f"Unloading LoRA adapter: {lora_name}")
            del self.loaded_loras[lora_name]

            # Remove from lora_modules list
            self.lora_modules = [
                lora for lora in self.lora_modules if lora.name != lora_name
            ]

            logger.info(f"Successfully unloaded LoRA: {lora_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to unload LoRA {lora_name}: {e}")
            return False

    def get_loaded_loras(self) -> List[str]:
        """
        Get list of currently loaded LoRA adapters.

        Returns:
            List of LoRA adapter names.
        """
        return list(self.loaded_loras.keys())
