# SPDX-License-Identifier: Apache-2.0
"""OpenAI-compatible API server for MLX-LLM."""

from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from mlxllm.config import ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.entry_points.openai.protocol import (
    ChatCompletionRequest,
    CompletionRequest,
    DetokenizeRequest,
    EmbeddingRequest,
    ErrorResponse,
    ModelList,
    TokenizeRequest,
)
from mlxllm.entry_points.openai.serving_chat import OpenAIServingChat
from mlxllm.entry_points.openai.serving_completion import OpenAIServingCompletion
from mlxllm.entry_points.openai.serving_embedding import OpenAIServingEmbedding
from mlxllm.entry_points.openai.serving_models import OpenAIServingModels
from mlxllm.entry_points.openai.serving_tokenization import OpenAIServingTokenization
from mlxllm.entry_points.utils import with_cancellation

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """FastAPI lifespan manager."""
    try:
        # Startup
        logger.info("Starting MLX-LLM OpenAI API server")

        # Engine is already initialized and stored in app.state.engine_client
        # No additional startup needed

        yield

    finally:
        # Shutdown
        logger.info("Shutting down MLX-LLM OpenAI API server")
        # Cleanup if needed


def create_app(
    engine_client: Any,
    model_config: ModelConfig,
    served_model_names: list[str],
    response_role: str = "assistant",
    chat_template: str | None = None,
    lora_modules: list[Any] | None = None,
    enable_cors: bool = False,
    allowed_origins: list[str] | None = None,
    allowed_methods: list[str] | None = None,
    allowed_headers: list[str] | None = None,
) -> FastAPI:
    """
    Create OpenAI-compatible FastAPI application.

    Args:
        engine_client: Async engine client.
        model_config: Model configuration.
        served_model_names: List of model names to serve.
        response_role: Role for assistant responses.
        chat_template: Optional custom chat template.
        lora_modules: Optional LoRA modules.
        enable_cors: Enable CORS middleware.
        allowed_origins: Allowed origins for CORS.
        allowed_methods: Allowed methods for CORS.
        allowed_headers: Allowed headers for CORS.

    Returns:
        FastAPI application instance.
    """
    app = FastAPI(
        title="MLX-LLM OpenAI API",
        description="OpenAI-compatible API for MLX-LLM",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Store engine client in app state
    app.state.engine_client = engine_client
    app.state.log_stats = True

    # Add CORS middleware if enabled
    if enable_cors:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allowed_origins or ["*"],
            allow_credentials=True,
            allow_methods=allowed_methods or ["*"],
            allow_headers=allowed_headers or ["*"],
        )

    # Initialize serving classes
    serving_chat = OpenAIServingChat(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
        response_role=response_role,
        chat_template=chat_template,
    )

    serving_completion = OpenAIServingCompletion(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
    )

    serving_embedding = OpenAIServingEmbedding(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
    )

    serving_tokenization = OpenAIServingTokenization(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
    )

    serving_models = OpenAIServingModels(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
        lora_modules=lora_modules,
    )

    # === Routes ===

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "MLX-LLM OpenAI-compatible API",
            "version": "0.1.0",
            "models": served_model_names,
        }

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        engine_running = hasattr(engine_client, "is_running") and engine_client.is_running
        return {
            "status": "healthy" if engine_running else "degraded",
            "engine_running": engine_running,
        }

    @app.get("/v1/models")
    async def list_models() -> ModelList:
        """List available models."""
        return await serving_models.list_models()

    @app.post("/v1/chat/completions")
    @with_cancellation
    async def create_chat_completion(
        request: ChatCompletionRequest,
        raw_request: Request,
    ):
        """Create chat completion."""
        request_id = f"chatcmpl-{id(request)}"

        if request.stream:
            # Streaming response
            generator = serving_chat.create_chat_completion_stream(request, request_id)
            return StreamingResponse(
                generator,
                media_type="text/event-stream",
            )
        else:
            # Non-streaming response
            result = await serving_chat.create_chat_completion(request, request_id)
            if isinstance(result, ErrorResponse):
                return JSONResponse(
                    content=result.model_dump(),
                    status_code=400,
                )
            return result

    @app.post("/v1/completions")
    @with_cancellation
    async def create_completion(
        request: CompletionRequest,
        raw_request: Request,
    ):
        """Create text completion."""
        request_id = f"cmpl-{id(request)}"

        if request.stream:
            # Streaming response
            generator = serving_completion.create_completion_stream(request, request_id)
            return StreamingResponse(
                generator,
                media_type="text/event-stream",
            )
        else:
            # Non-streaming response
            result = await serving_completion.create_completion(request, request_id)
            if isinstance(result, ErrorResponse):
                return JSONResponse(
                    content=result.model_dump(),
                    status_code=400,
                )
            return result

    @app.post("/v1/embeddings")
    @with_cancellation
    async def create_embedding(
        request: EmbeddingRequest,
        raw_request: Request,
    ):
        """Create embeddings."""
        request_id = f"emb-{id(request)}"
        result = await serving_embedding.create_embedding(request, request_id)
        if isinstance(result, ErrorResponse):
            return JSONResponse(
                content=result.model_dump(),
                status_code=400,
            )
        return result

    @app.post("/v1/tokenize")
    @with_cancellation
    async def tokenize(
        request: TokenizeRequest,
        raw_request: Request,
    ):
        """Tokenize text."""
        request_id = f"tok-{id(request)}"
        result = await serving_tokenization.tokenize(request, request_id)
        if isinstance(result, ErrorResponse):
            return JSONResponse(
                content=result.model_dump(),
                status_code=400,
            )
        return result

    @app.post("/v1/detokenize")
    @with_cancellation
    async def detokenize(
        request: DetokenizeRequest,
        raw_request: Request,
    ):
        """Detokenize tokens."""
        request_id = f"detok-{id(request)}"
        result = await serving_tokenization.detokenize(request, request_id)
        if isinstance(result, ErrorResponse):
            return JSONResponse(
                content=result.model_dump(),
                status_code=400,
            )
        return result

    return app


async def run_server(
    model: str,
    host: str = "0.0.0.0",
    port: int = 8000,
    **kwargs: Any,
):
    """
    Run the OpenAI API server.

    Args:
        model: Model name or path.
        host: Host to bind to.
        port: Port to bind to.
        **kwargs: Additional server configuration.
    """
    from mlxllm.entry_points.launcher import serve_http

    # Create configurations
    model_config = ModelConfig(
        model_name=model,
        max_model_len=kwargs.get("max_model_len", 2048),
        trust_remote_code=kwargs.get("trust_remote_code", False),
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=kwargs.get("max_num_seqs", 256),
        max_num_batched_tokens=kwargs.get("max_num_batched_tokens", 2048),
    )

    # Initialize engine
    logger.info(f"Initializing engine with model: {model}")
    engine_client = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        model_path=model,
        quantization=kwargs.get("quantization"),
    )

    # Create app
    served_model_names = kwargs.get("served_model_name", [model.split("/")[-1]])
    app = create_app(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
        response_role=kwargs.get("response_role", "assistant"),
        chat_template=kwargs.get("chat_template"),
        lora_modules=kwargs.get("lora_modules"),
        enable_cors=kwargs.get("enable_cors", False),
        allowed_origins=kwargs.get("allowed_origins"),
        allowed_methods=kwargs.get("allowed_methods"),
        allowed_headers=kwargs.get("allowed_headers"),
    )

    logger.info(f"Starting server on {host}:{port}")

    # Serve
    await serve_http(
        app=app,
        host=host,
        port=port,
        log_level=kwargs.get("log_level", "info"),
        ssl_keyfile=kwargs.get("ssl_keyfile"),
        ssl_certfile=kwargs.get("ssl_certfile"),
        ssl_ca_certs=kwargs.get("ssl_ca_certs"),
    )


if __name__ == "__main__":
    import sys

    print("MLX-LLM OpenAI API Server")
    print("For production use, use: mlxllm serve")
    print()

    if len(sys.argv) < 2:
        print("Usage: python -m mlxllm.entry_points.openai.api_server <model>")
        sys.exit(1)

    model = sys.argv[1]
    asyncio.run(run_server(model))
