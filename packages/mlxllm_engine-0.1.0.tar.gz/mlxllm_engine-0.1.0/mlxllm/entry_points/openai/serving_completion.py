# SPDX-License-Identifier: Apache-2.0
"""Text completion serving for OpenAI-compatible API."""

from __future__ import annotations

import logging
from typing import AsyncIterator

from mlxllm.entry_points.openai.protocol import (
    CompletionRequest,
    CompletionResponse,
    CompletionResponseChoice,
    CompletionStreamResponse,
    ErrorResponse,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing
from mlxllm.outputs import RequestOutput

logger = logging.getLogger(__name__)


class OpenAIServingCompletion(OpenAIServing):
    """Handles text completion endpoints."""

    async def create_completion(
        self,
        request: CompletionRequest,
        request_id: str,
    ) -> CompletionResponse | ErrorResponse:
        """
        Create a text completion (non-streaming).

        Args:
            request: Completion request.
            request_id: Unique request ID.

        Returns:
            CompletionResponse or ErrorResponse.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            return error

        # Check engine health
        error = self._check_engine_health()
        if error:
            return error

        try:
            # Handle prompt (can be string or list)
            if isinstance(request.prompt, str):
                prompts = [request.prompt]
            elif isinstance(request.prompt, list):
                if all(isinstance(p, str) for p in request.prompt):
                    prompts = request.prompt
                else:
                    # Token IDs
                    return self.create_error_response(
                        message="Token ID prompts not yet supported",
                        err_type="InvalidRequestError",
                        status_code=400,
                    )
            else:
                prompts = [str(request.prompt)]

            # For now, handle single prompt
            prompt = prompts[0]

            # Count prompt tokens
            prompt_tokens = len(await self._tokenize(prompt))

            # Validate prompt length
            error = self._validate_prompt_length(prompt_tokens, request.max_tokens)
            if error:
                return error

            # Create sampling params
            sampling_params = self.create_sampling_params(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                max_tokens=request.max_tokens or 16,
                stop=request.stop,
                presence_penalty=request.presence_penalty or 0.0,
                frequency_penalty=request.frequency_penalty or 0.0,
                seed=request.seed,
                logprobs=request.logprobs is not None,
            )

            # Generate
            output: RequestOutput = await self.engine_client.generate(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            )

            # Extract completion text
            if output.outputs:
                completion_text = output.outputs[0].text
                finish_reason = getattr(output.outputs[0], "finish_reason", "stop")
                completion_tokens = len(output.outputs[0].token_ids)
            else:
                completion_text = ""
                finish_reason = "error"
                completion_tokens = 0

            # Handle echo
            if request.echo:
                completion_text = prompt + completion_text

            # Create response
            response = CompletionResponse(
                id=request_id,
                model=self._get_model_name(request.model),
                choices=[
                    CompletionResponseChoice(
                        index=0,
                        text=completion_text,
                        finish_reason=finish_reason,
                    )
                ],
                usage=self.create_usage_info(prompt_tokens, completion_tokens),
            )

            return response

        except Exception as e:
            logger.error(f"Completion error: {e}", exc_info=True)
            return self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )

    async def create_completion_stream(
        self,
        request: CompletionRequest,
        request_id: str,
    ) -> AsyncIterator[str]:
        """
        Create a streaming text completion.

        Args:
            request: Completion request.
            request_id: Unique request ID.

        Yields:
            Server-sent event strings.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            yield f"data: {error.model_dump_json()}\n\n"
            return

        # Check engine health
        error = self._check_engine_health()
        if error:
            yield f"data: {error.model_dump_json()}\n\n"
            return

        try:
            # Handle prompt
            if isinstance(request.prompt, str):
                prompt = request.prompt
            elif isinstance(request.prompt, list) and all(
                isinstance(p, str) for p in request.prompt
            ):
                prompt = request.prompt[0]
            else:
                error_response = self.create_error_response(
                    message="Invalid prompt format for streaming",
                    err_type="InvalidRequestError",
                    status_code=400,
                )
                yield f"data: {error_response.model_dump_json()}\n\n"
                return

            # Create sampling params
            sampling_params = self.create_sampling_params(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                max_tokens=request.max_tokens or 16,
                stop=request.stop,
                presence_penalty=request.presence_penalty or 0.0,
                frequency_penalty=request.frequency_penalty or 0.0,
                seed=request.seed,
            )

            # Handle echo
            if request.echo:
                # Send prompt first
                echo_chunk = CompletionStreamResponse(
                    id=request_id,
                    model=self._get_model_name(request.model),
                    choices=[
                        CompletionResponseChoice(
                            index=0,
                            text=prompt,
                            finish_reason=None,
                        )
                    ],
                )
                yield f"data: {echo_chunk.model_dump_json()}\n\n"

            # Generate stream
            previous_text = ""
            async for output in self.engine_client.generate_stream(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            ):
                # Extract new text
                if output.outputs:
                    current_text = output.outputs[0].text
                    new_text = current_text[len(previous_text) :]
                    previous_text = current_text

                    # Create streaming chunk
                    chunk = CompletionStreamResponse(
                        id=request_id,
                        model=self._get_model_name(request.model),
                        choices=[
                            CompletionResponseChoice(
                                index=0,
                                text=new_text,
                                finish_reason=None,
                            )
                        ],
                    )

                    yield f"data: {chunk.model_dump_json()}\n\n"

            # Send final chunk
            final_chunk = CompletionStreamResponse(
                id=request_id,
                model=self._get_model_name(request.model),
                choices=[
                    CompletionResponseChoice(
                        index=0,
                        text="",
                        finish_reason="stop",
                    )
                ],
            )
            yield f"data: {final_chunk.model_dump_json()}\n\n"
            yield "data: [DONE]\n\n"

        except Exception as e:
            logger.error(f"Streaming completion error: {e}", exc_info=True)
            error_response = self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )
            yield f"data: {error_response.model_dump_json()}\n\n"
