# SPDX-License-Identifier: Apache-2.0
"""Chat completion serving for OpenAI-compatible API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, AsyncIterator, List

from mlxllm.entry_points.chat_utils import (
    apply_hf_chat_template,
    parse_chat_messages,
    validate_chat_messages,
)
from mlxllm.entry_points.openai.protocol import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionResponseChoice,
    ChatCompletionStreamResponse,
    ChatCompletionStreamResponseChoice,
    ChatCompletionStreamResponseDelta,
    ChatMessage,
    ErrorResponse,
)
from mlxllm.entry_points.openai.serving_engine import OpenAIServing
from mlxllm.outputs import RequestOutput

if TYPE_CHECKING:
    from mlxllm.config import ModelConfig
    from mlxllm.engine.protocol import EngineClient

logger = logging.getLogger(__name__)


class OpenAIServingChat(OpenAIServing):
    """Handles chat completion endpoints."""

    def __init__(
        self,
        engine_client: EngineClient,
        model_config: ModelConfig,
        served_model_names: List[str],
        response_role: str = "assistant",
        chat_template: str | None = None,
    ) -> None:
        """
        Initialize chat serving.

        Args:
            engine_client: Async engine client.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
            response_role: Role for assistant responses.
            chat_template: Optional custom chat template.
        """
        super().__init__(
            engine_client=engine_client,
            model_config=model_config,
            served_model_names=served_model_names,
            response_role=response_role,
        )
        self.chat_template = chat_template

    async def create_chat_completion(
        self,
        request: ChatCompletionRequest,
        request_id: str,
    ) -> ChatCompletionResponse | ErrorResponse:
        """
        Create a chat completion (non-streaming).

        Args:
            request: Chat completion request.
            request_id: Unique request ID.

        Returns:
            ChatCompletionResponse or ErrorResponse.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            return error

        # Check engine health
        error = self._check_engine_health()
        if error:
            return error

        try:
            # Validate and parse messages
            validate_chat_messages(request.messages)
            parsed_messages, _ = parse_chat_messages(
                request.messages, self.model_config
            )

            # Apply chat template
            tokenizer = await self.engine_client.get_tokenizer()
            prompt = apply_hf_chat_template(
                tokenizer,
                request.messages,
                chat_template=self.chat_template,
                add_generation_prompt=True,
            )

            # Count prompt tokens
            prompt_tokens = len(await self._tokenize(prompt))

            # Validate prompt length
            error = self._validate_prompt_length(
                prompt_tokens, request.max_tokens or request.max_completion_tokens
            )
            if error:
                return error

            # Create sampling params
            sampling_params = self.create_sampling_params(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                max_tokens=request.max_tokens or request.max_completion_tokens,
                stop=request.stop,
                presence_penalty=request.presence_penalty or 0.0,
                frequency_penalty=request.frequency_penalty or 0.0,
                seed=request.seed,
                logprobs=request.logprobs or False,
                top_logprobs=request.top_logprobs,
            )

            # Generate
            output: RequestOutput = await self.engine_client.generate(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            )

            # Extract completion text
            if output.outputs:
                completion_text = output.outputs[0].text
                finish_reason = getattr(output.outputs[0], "finish_reason", "stop")
                completion_tokens = len(output.outputs[0].token_ids)
            else:
                completion_text = ""
                finish_reason = "error"
                completion_tokens = 0

            # Create response
            response = ChatCompletionResponse(
                id=request_id,
                model=self._get_model_name(request.model),
                choices=[
                    ChatCompletionResponseChoice(
                        index=0,
                        message=ChatMessage(
                            role=self.response_role,
                            content=completion_text,
                        ),
                        finish_reason=finish_reason,
                    )
                ],
                usage=self.create_usage_info(prompt_tokens, completion_tokens),
            )

            return response

        except Exception as e:
            logger.error(f"Chat completion error: {e}", exc_info=True)
            return self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )

    async def create_chat_completion_stream(
        self,
        request: ChatCompletionRequest,
        request_id: str,
    ) -> AsyncIterator[str]:
        """
        Create a streaming chat completion.

        Args:
            request: Chat completion request.
            request_id: Unique request ID.

        Yields:
            Server-sent event strings.
        """
        # Validate model
        error = self._validate_model(request.model)
        if error:
            yield f"data: {error.model_dump_json()}\n\n"
            return

        # Check engine health
        error = self._check_engine_health()
        if error:
            yield f"data: {error.model_dump_json()}\n\n"
            return

        try:
            # Validate and parse messages
            validate_chat_messages(request.messages)

            # Apply chat template
            tokenizer = await self.engine_client.get_tokenizer()
            prompt = apply_hf_chat_template(
                tokenizer,
                request.messages,
                chat_template=self.chat_template,
                add_generation_prompt=True,
            )

            # Create sampling params
            sampling_params = self.create_sampling_params(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                max_tokens=request.max_tokens or request.max_completion_tokens,
                stop=request.stop,
                presence_penalty=request.presence_penalty or 0.0,
                frequency_penalty=request.frequency_penalty or 0.0,
                seed=request.seed,
            )

            # Generate stream
            previous_text = ""
            async for output in self.engine_client.generate_stream(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            ):
                # Extract new text
                if output.outputs:
                    current_text = output.outputs[0].text
                    new_text = current_text[len(previous_text):]
                    previous_text = current_text

                    # Create streaming chunk
                    chunk = ChatCompletionStreamResponse(
                        id=request_id,
                        model=self._get_model_name(request.model),
                        choices=[
                            ChatCompletionStreamResponseChoice(
                                index=0,
                                delta=ChatCompletionStreamResponseDelta(
                                    role=self.response_role if not previous_text else None,
                                    content=new_text,
                                ),
                                finish_reason=None,
                            )
                        ],
                    )

                    yield f"data: {chunk.model_dump_json()}\n\n"

            # Send final chunk with finish_reason
            final_chunk = ChatCompletionStreamResponse(
                id=request_id,
                model=self._get_model_name(request.model),
                choices=[
                    ChatCompletionStreamResponseChoice(
                        index=0,
                        delta=ChatCompletionStreamResponseDelta(),
                        finish_reason="stop",
                    )
                ],
            )
            yield f"data: {final_chunk.model_dump_json()}\n\n"
            yield "data: [DONE]\n\n"

        except Exception as e:
            logger.error(f"Streaming chat completion error: {e}", exc_info=True)
            error_response = self.create_error_response(
                message=str(e),
                err_type="InternalServerError",
                status_code=500,
            )
            yield f"data: {error_response.model_dump_json()}\n\n"
