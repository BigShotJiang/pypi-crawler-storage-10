# SPDX-License-Identifier: Apache-2.0
"""
Batch processing CLI for MLX-LLM.

This module provides functionality to run batch inference from JSONL files,
similar to OpenAI's batch API format.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Any, Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


class BatchProcessor:
    """
    Process batch inference requests from JSONL files.

    This class handles loading batch requests, processing them through the
    LLM engine, and writing results to an output file.
    """

    def __init__(
        self,
        model: str,
        input_file: Path,
        output_file: Path,
        max_concurrent: int = 100,
        tokenizer: Optional[str] = None,
        quantization: Optional[str] = None,
        max_model_len: Optional[int] = None,
        max_num_seqs: int = 256,
        block_size: int = 16,
    ):
        """
        Initialize batch processor.

        Args:
            model: Model name or path.
            input_file: Input JSONL file with requests.
            output_file: Output JSONL file for results.
            max_concurrent: Maximum concurrent requests.
            tokenizer: Optional tokenizer path.
            quantization: Optional quantization type.
            max_model_len: Optional maximum model length.
            max_num_seqs: Maximum number of sequences.
            block_size: Block size for paged attention.
        """
        self.model = model
        self.input_file = input_file
        self.output_file = output_file
        self.max_concurrent = max_concurrent

        # Create configurations
        self.model_config = ModelConfig(
            model_name=model,
            tokenizer=tokenizer,
            max_model_len=max_model_len,
        )

        self.scheduler_config = SchedulerConfig(
            max_num_seqs=max_num_seqs,
        )

        self.cache_config = CacheConfig(
            block_size=block_size,
        )

        # Initialize engine (will be done in async context)
        self.engine: Optional[AsyncLLMEngine] = None

    async def initialize(self) -> None:
        """Initialize the async LLM engine."""
        logger.info(f"Initializing engine with model: {self.model}")
        self.engine = AsyncLLMEngine(
            model_config=self.model_config,
            scheduler_config=self.scheduler_config,
            cache_config=self.cache_config,
            model_path=self.model,
        )
        logger.info("Engine initialized successfully")

    def load_requests(self) -> list[dict[str, Any]]:
        """
        Load batch requests from JSONL file.

        Returns:
            List of request dictionaries.

        Raises:
            FileNotFoundError: If input file does not exist.
            ValueError: If input file format is invalid.
        """
        if not self.input_file.exists():
            raise FileNotFoundError(f"Input file not found: {self.input_file}")

        requests = []
        with open(self.input_file, "r") as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue

                try:
                    request = json.loads(line)
                    # Add line number as custom_id if not present
                    if "custom_id" not in request:
                        request["custom_id"] = f"request-{line_num}"
                    requests.append(request)
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON on line {line_num}: {e}")
                    raise ValueError(f"Invalid JSON format on line {line_num}")

        logger.info(f"Loaded {len(requests)} requests from {self.input_file}")
        return requests

    async def process_request(
        self,
        request: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Process a single batch request.

        Args:
            request: Request dictionary with 'custom_id' and request data.

        Returns:
            Result dictionary with 'custom_id' and response data.
        """
        custom_id = request.get("custom_id", "unknown")

        try:
            # Extract request parameters
            # Support both OpenAI batch format and simplified format
            if "body" in request:
                # OpenAI batch API format
                body = request["body"]
                prompt = body.get("prompt") or body.get("messages", [{"role": "user", "content": ""}])[0]["content"]
                max_tokens = body.get("max_tokens", 128)
                temperature = body.get("temperature", 1.0)
                top_p = body.get("top_p", 1.0)
            else:
                # Simplified format
                prompt = request.get("prompt", "")
                max_tokens = request.get("max_tokens", 128)
                temperature = request.get("temperature", 1.0)
                top_p = request.get("top_p", 1.0)

            # Create sampling parameters
            sampling_params = SamplingParams(
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
            )

            # Generate response
            logger.debug(f"Processing request {custom_id}")

            # Use the engine to generate
            output_text = ""
            async for output in self.engine.generate(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=custom_id,
            ):
                if output.outputs:
                    output_text = output.outputs[0].text

            # Format result
            result = {
                "custom_id": custom_id,
                "response": {
                    "status": "completed",
                    "text": output_text,
                    "model": self.model,
                },
            }

            logger.debug(f"Completed request {custom_id}")
            return result

        except Exception as e:
            logger.error(f"Error processing request {custom_id}: {e}", exc_info=True)
            return {
                "custom_id": custom_id,
                "response": {
                    "status": "failed",
                    "error": str(e),
                },
            }

    async def process_batch(self) -> int:
        """
        Process all batch requests.

        Returns:
            Number of successfully processed requests.
        """
        # Load requests
        try:
            requests = self.load_requests()
        except Exception as e:
            logger.error(f"Failed to load requests: {e}")
            return 0

        if not requests:
            logger.warning("No requests to process")
            return 0

        # Process requests with concurrency limit
        logger.info(f"Processing {len(requests)} requests (max concurrent: {self.max_concurrent})")

        # Create output file
        self.output_file.parent.mkdir(parents=True, exist_ok=True)

        successful = 0
        failed = 0

        # Process in batches
        with open(self.output_file, "w") as out_f:
            for i in range(0, len(requests), self.max_concurrent):
                batch = requests[i:i + self.max_concurrent]
                logger.info(f"Processing batch {i // self.max_concurrent + 1} ({len(batch)} requests)")

                # Process batch concurrently
                tasks = [self.process_request(req) for req in batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # Write results
                for result in results:
                    if isinstance(result, Exception):
                        logger.error(f"Request failed with exception: {result}")
                        failed += 1
                    else:
                        out_f.write(json.dumps(result) + "\n")
                        if result.get("response", {}).get("status") == "completed":
                            successful += 1
                        else:
                            failed += 1

        logger.info(f"Batch processing complete: {successful} successful, {failed} failed")
        logger.info(f"Results written to: {self.output_file}")

        return successful

    async def run(self) -> int:
        """
        Run the batch processor.

        Returns:
            Exit code (0 for success, 1 for errors).
        """
        try:
            await self.initialize()
            successful = await self.process_batch()
            return 0 if successful > 0 else 1
        except Exception as e:
            logger.error(f"Batch processing failed: {e}", exc_info=True)
            return 1


def run_batch(args: argparse.Namespace) -> int:
    """
    Run batch processing from command-line arguments.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    # Setup logging
    log_level = getattr(logging, args.log_level.upper(), logging.INFO)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    logger.info("Starting batch processing")

    # Create processor
    processor = BatchProcessor(
        model=args.model,
        input_file=Path(args.input_file),
        output_file=Path(args.output_file),
        max_concurrent=args.max_concurrent,
        tokenizer=args.tokenizer,
        quantization=args.quantization,
        max_model_len=args.max_model_len,
        max_num_seqs=args.max_num_seqs,
        block_size=args.block_size,
    )

    # Run processor
    return asyncio.run(processor.run())


def add_batch_args(parser: argparse.ArgumentParser) -> None:
    """
    Add batch processing arguments to parser.

    Args:
        parser: ArgumentParser to add arguments to.
    """
    # Input/output
    parser.add_argument(
        "--input-file",
        type=str,
        required=True,
        help="Input JSONL file with batch requests",
    )
    parser.add_argument(
        "--output-file",
        type=str,
        required=True,
        help="Output JSONL file for results",
    )

    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16", "fp32"],
        help="Quantization type",
    )

    # Engine configuration
    parser.add_argument(
        "--max-model-len",
        type=int,
        help="Maximum sequence length",
    )
    parser.add_argument(
        "--max-num-seqs",
        type=int,
        default=256,
        help="Maximum number of sequences (default: 256)",
    )
    parser.add_argument(
        "--block-size",
        type=int,
        default=16,
        help="Block size for paged attention (default: 16)",
    )

    # Batch configuration
    parser.add_argument(
        "--max-concurrent",
        type=int,
        default=100,
        help="Maximum concurrent requests (default: 100)",
    )

    # Logging
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def main(argv: Optional[list[str]] = None) -> int:
    """
    Main entry point for batch processing CLI.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    parser = argparse.ArgumentParser(
        prog="mlxllm-batch",
        description="Batch processing for MLX-LLM",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example JSONL input format:

  {"custom_id": "req-1", "prompt": "Hello, world!"}
  {"custom_id": "req-2", "prompt": "What is MLX?", "max_tokens": 256}

Or OpenAI batch API format:

  {"custom_id": "req-1", "body": {"prompt": "Hello, world!", "max_tokens": 100}}

Usage:
  mlxllm-batch --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit \\
      --input-file requests.jsonl --output-file results.jsonl
        """,
    )

    add_batch_args(parser)
    args = parser.parse_args(argv)

    return run_batch(args)


if __name__ == "__main__":
    sys.exit(main())
