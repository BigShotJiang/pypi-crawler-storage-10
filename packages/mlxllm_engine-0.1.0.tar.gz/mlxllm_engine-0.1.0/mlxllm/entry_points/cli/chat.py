# SPDX-License-Identifier: Apache-2.0
"""Chat command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from typing import Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


class ChatSession:
    """Interactive chat session manager."""

    def __init__(
        self,
        engine: AsyncLLMEngine,
        sampling_params: SamplingParams,
        system_prompt: Optional[str] = None,
    ):
        """
        Initialize chat session.

        Args:
            engine: LLM engine for generation.
            sampling_params: Sampling parameters.
            system_prompt: Optional system prompt.
        """
        self.engine = engine
        self.sampling_params = sampling_params
        self.system_prompt = system_prompt
        self.history: list[dict[str, str]] = []

        if system_prompt:
            self.history.append({"role": "system", "content": system_prompt})

    def format_chat_prompt(self, user_message: str) -> str:
        """
        Format chat history into a prompt.

        Args:
            user_message: Latest user message.

        Returns:
            Formatted prompt string.
        """
        # Add user message to history
        self.history.append({"role": "user", "content": user_message})

        # Simple chat format (can be improved with proper chat templates)
        prompt_parts = []

        for message in self.history:
            role = message["role"]
            content = message["content"]

            if role == "system":
                prompt_parts.append(f"System: {content}")
            elif role == "user":
                prompt_parts.append(f"User: {content}")
            elif role == "assistant":
                prompt_parts.append(f"Assistant: {content}")

        prompt_parts.append("Assistant:")
        return "\n\n".join(prompt_parts)

    async def send_message(self, user_message: str) -> str:
        """
        Send a message and get response.

        Args:
            user_message: User's message.

        Returns:
            Assistant's response.
        """
        # Format prompt with history
        prompt = self.format_chat_prompt(user_message)

        # Generate response
        output_text = ""
        print("Assistant: ", end="", flush=True)

        async for output in self.engine.generate(
            prompt=prompt,
            sampling_params=self.sampling_params,
            request_id=f"chat-{len(self.history)}",
        ):
            if output.outputs:
                new_text = output.outputs[0].text
                # Print incremental text
                incremental = new_text[len(output_text):]
                if incremental:
                    print(incremental, end="", flush=True)
                output_text = new_text

        print()  # Newline after response

        # Add assistant response to history
        self.history.append({"role": "assistant", "content": output_text})

        return output_text

    def run_interactive(self) -> None:
        """Run interactive chat loop."""
        print("\n" + "=" * 70)
        print("MLX-LLM Interactive Chat")
        print("=" * 70)
        print("Type your messages and press Enter to send.")
        print("Commands:")
        print("  /clear  - Clear chat history")
        print("  /exit   - Exit chat")
        print("  /help   - Show this help message")
        print("=" * 70 + "\n")

        if self.system_prompt:
            print(f"System: {self.system_prompt}\n")

        while True:
            try:
                # Get user input
                user_input = input("You: ").strip()

                if not user_input:
                    continue

                # Handle commands
                if user_input.startswith("/"):
                    command = user_input[1:].lower()

                    if command == "exit" or command == "quit":
                        print("\nGoodbye!")
                        break

                    elif command == "clear":
                        # Clear history but keep system prompt
                        if self.system_prompt:
                            self.history = [{"role": "system", "content": self.system_prompt}]
                        else:
                            self.history = []
                        print("Chat history cleared.\n")
                        continue

                    elif command == "help":
                        print("\nCommands:")
                        print("  /clear  - Clear chat history")
                        print("  /exit   - Exit chat")
                        print("  /help   - Show this help message\n")
                        continue

                    else:
                        print(f"Unknown command: /{command}\n")
                        continue

                # Send message and get response
                asyncio.run(self.send_message(user_input))
                print()

            except KeyboardInterrupt:
                print("\n\nGoodbye!")
                break

            except EOFError:
                print("\n\nGoodbye!")
                break

            except Exception as e:
                logger.error(f"Error during chat: {e}", exc_info=True)
                print(f"\nError: {e}\n")


async def initialize_chat(
    model: str,
    sampling_params: SamplingParams,
    tokenizer: Optional[str] = None,
    quantization: Optional[str] = None,
    max_model_len: Optional[int] = None,
    system_prompt: Optional[str] = None,
) -> ChatSession:
    """
    Initialize chat session.

    Args:
        model: Model name or path.
        sampling_params: Sampling parameters.
        tokenizer: Optional tokenizer path.
        quantization: Optional quantization type.
        max_model_len: Optional maximum model length.
        system_prompt: Optional system prompt.

    Returns:
        Initialized ChatSession.
    """
    # Create configurations
    model_config = ModelConfig(
        model_name=model,
        tokenizer=tokenizer,
        max_model_len=max_model_len,
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=1,  # Single conversation
    )

    cache_config = CacheConfig(
        block_size=16,
    )

    # Initialize engine
    logger.info(f"Loading model: {model}")
    engine = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        model_path=model,
        quantization=quantization,
    )

    logger.info("Model loaded. Starting chat session...\n")

    # Create chat session
    return ChatSession(
        engine=engine,
        sampling_params=sampling_params,
        system_prompt=system_prompt,
    )


def run_chat(args: argparse.Namespace) -> int:
    """
    Run the chat command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        # Create sampling parameters
        sampling_params = SamplingParams(
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            top_p=args.top_p,
            top_k=args.top_k,
            presence_penalty=args.presence_penalty,
            frequency_penalty=args.frequency_penalty,
            stop=args.stop,
            seed=args.seed,
        )

        # Initialize chat session
        chat_session = asyncio.run(
            initialize_chat(
                model=args.model,
                sampling_params=sampling_params,
                tokenizer=args.tokenizer,
                quantization=args.quantization,
                max_model_len=args.max_model_len,
                system_prompt=args.system_prompt,
            )
        )

        # Run interactive chat
        chat_session.run_interactive()

        return 0

    except KeyboardInterrupt:
        print("\n\nGoodbye!")
        return 0

    except Exception as e:
        logger.error(f"Chat session failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_chat(argparse.Namespace()))
