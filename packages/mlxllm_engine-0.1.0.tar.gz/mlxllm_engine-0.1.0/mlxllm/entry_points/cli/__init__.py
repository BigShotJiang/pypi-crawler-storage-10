# SPDX-License-Identifier: Apache-2.0
"""CLI entry points for MLX-LLM."""

from __future__ import annotations

from mlxllm.entry_points.cli.main import main
from mlxllm.entry_points.cli.types import (
    APIProtocol,
    BenchmarkArgs,
    ChatArgs,
    CLICommand,
    ConvertArgs,
    EmbedArgs,
    GenerateArgs,
    LogLevel,
    QuantizationType,
    ServeArgs,
    TokenizeArgs,
)

__all__ = [
    "main",
    "CLICommand",
    "LogLevel",
    "QuantizationType",
    "APIProtocol",
    "ServeArgs",
    "GenerateArgs",
    "ChatArgs",
    "EmbedArgs",
    "TokenizeArgs",
    "ConvertArgs",
    "BenchmarkArgs",
]
