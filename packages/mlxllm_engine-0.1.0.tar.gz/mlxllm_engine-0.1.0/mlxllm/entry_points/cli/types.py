# SPDX-License-Identifier: Apache-2.0
"""CLI type definitions and utilities for MLX-LLM."""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Union


class CLICommand(str, Enum):
    """Available CLI commands."""

    SERVE = "serve"
    GENERATE = "generate"
    CHAT = "chat"
    EMBED = "embed"
    TOKENIZE = "tokenize"
    CONVERT = "convert"
    BENCHMARK = "benchmark"
    MODELS = "models"


class LogLevel(str, Enum):
    """Logging levels."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class QuantizationType(str, Enum):
    """Supported quantization types."""

    Q4_0 = "q4_0"
    Q4_1 = "q4_1"
    Q8_0 = "q8_0"
    FP16 = "fp16"
    FP32 = "fp32"


class APIProtocol(str, Enum):
    """Supported API protocols."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"


@dataclass
class ServeArgs:
    """Arguments for the serve command."""

    # Model configuration
    model: str
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False
    quantization: Optional[QuantizationType] = None

    # Server configuration
    host: str = "0.0.0.0"
    port: int = 8000
    protocol: APIProtocol = APIProtocol.OPENAI
    enable_cors: bool = False
    allowed_origins: List[str] = field(default_factory=list)
    allowed_methods: List[str] = field(default_factory=list)
    allowed_headers: List[str] = field(default_factory=list)

    # SSL/TLS
    ssl_keyfile: Optional[Path] = None
    ssl_certfile: Optional[Path] = None
    ssl_ca_certs: Optional[Path] = None
    enable_ssl_refresh: bool = False

    # Model serving
    served_model_name: List[str] = field(default_factory=list)
    response_role: str = "assistant"
    chat_template: Optional[str] = None
    lora_modules: List[Dict[str, str]] = field(default_factory=list)

    # Engine configuration
    max_model_len: Optional[int] = None
    max_num_seqs: int = 256
    max_num_batched_tokens: Optional[int] = None
    block_size: int = 16

    # Memory configuration
    gpu_memory_utilization: float = 0.9
    swap_space: float = 4.0  # GiB
    enable_prefix_caching: bool = False
    disable_sliding_window: bool = False

    # Scheduler configuration
    scheduler_policy: str = "fcfs"
    max_paddings: int = 256

    # Logging
    log_level: LogLevel = LogLevel.INFO
    log_requests: bool = False
    log_stats: bool = True

    # Development
    reload: bool = False
    watchdog_enabled: bool = True

    def __post_init__(self):
        """Validate and set defaults."""
        if not self.allowed_origins and self.enable_cors:
            self.allowed_origins = ["*"]
        if not self.allowed_methods and self.enable_cors:
            self.allowed_methods = ["*"]
        if not self.allowed_headers and self.enable_cors:
            self.allowed_headers = ["*"]
        if not self.served_model_name:
            self.served_model_name = [self.model.split("/")[-1]]


@dataclass
class GenerateArgs:
    """Arguments for the generate command."""

    model: str
    prompt: str
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False
    quantization: Optional[QuantizationType] = None

    # Generation parameters
    max_tokens: int = 128
    temperature: float = 1.0
    top_p: float = 1.0
    top_k: int = -1
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0
    stop: Optional[List[str]] = None
    seed: Optional[int] = None

    # Output options
    output_file: Optional[Path] = None
    stream: bool = False
    log_level: LogLevel = LogLevel.INFO


@dataclass
class ChatArgs:
    """Arguments for the chat command."""

    model: str
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False
    quantization: Optional[QuantizationType] = None

    # Chat configuration
    chat_template: Optional[str] = None
    system_prompt: Optional[str] = None

    # Generation parameters
    max_tokens: int = 128
    temperature: float = 1.0
    top_p: float = 1.0
    top_k: int = -1
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0
    stop: Optional[List[str]] = None
    seed: Optional[int] = None

    # Output options
    log_level: LogLevel = LogLevel.INFO


@dataclass
class EmbedArgs:
    """Arguments for the embed command."""

    model: str
    input: Union[str, List[str]]
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False
    quantization: Optional[QuantizationType] = None

    # Embedding options
    encoding_format: str = "float"
    dimensions: Optional[int] = None

    # Output options
    output_file: Optional[Path] = None
    log_level: LogLevel = LogLevel.INFO


@dataclass
class TokenizeArgs:
    """Arguments for the tokenize command."""

    model: str
    text: str
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False

    # Tokenization options
    add_special_tokens: bool = True
    show_ids: bool = True
    show_text: bool = False

    # Output options
    output_file: Optional[Path] = None
    log_level: LogLevel = LogLevel.INFO


@dataclass
class ConvertArgs:
    """Arguments for the convert command."""

    model: str
    output_dir: Path
    quantization: Optional[QuantizationType] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False

    # Conversion options
    force: bool = False
    upload_to_hf: bool = False
    hf_repo_id: Optional[str] = None

    # Output options
    log_level: LogLevel = LogLevel.INFO


@dataclass
class BenchmarkArgs:
    """Arguments for the benchmark command."""

    model: str
    tokenizer: Optional[str] = None
    revision: Optional[str] = None
    trust_remote_code: bool = False
    quantization: Optional[QuantizationType] = None

    # Benchmark configuration
    num_prompts: int = 100
    prompt_length: int = 128
    output_length: int = 128
    batch_size: int = 1

    # Engine configuration
    max_model_len: Optional[int] = None
    max_num_seqs: int = 256
    block_size: int = 16
    gpu_memory_utilization: float = 0.9

    # Output options
    output_file: Optional[Path] = None
    log_level: LogLevel = LogLevel.INFO


def parse_key_value_arg(value: str) -> tuple[str, str]:
    """
    Parse key=value argument.

    Args:
        value: String in format "key=value".

    Returns:
        Tuple of (key, value).

    Raises:
        argparse.ArgumentTypeError: If format is invalid.
    """
    if "=" not in value:
        raise argparse.ArgumentTypeError(
            f"Invalid format: {value}. Expected format: key=value"
        )
    key, val = value.split("=", 1)
    return key.strip(), val.strip()


def parse_lora_modules(value: str) -> Dict[str, str]:
    """
    Parse LoRA module specification.

    Args:
        value: String in format "name=path" or "name=path,base_model_name=name".

    Returns:
        Dictionary with LoRA module specification.
    """
    parts = value.split(",")
    result = {}

    for part in parts:
        key, val = parse_key_value_arg(part)
        result[key] = val

    if "name" not in result or "path" not in result:
        raise argparse.ArgumentTypeError(
            f"LoRA module must specify 'name' and 'path': {value}"
        )

    return result


def validate_file_path(path: str) -> Path:
    """
    Validate that a file path exists.

    Args:
        path: Path to validate.

    Returns:
        Path object.

    Raises:
        argparse.ArgumentTypeError: If file does not exist.
    """
    p = Path(path)
    if not p.exists():
        raise argparse.ArgumentTypeError(f"File not found: {path}")
    if not p.is_file():
        raise argparse.ArgumentTypeError(f"Not a file: {path}")
    return p


def validate_dir_path(path: str) -> Path:
    """
    Validate that a directory path exists or can be created.

    Args:
        path: Path to validate.

    Returns:
        Path object.

    Raises:
        argparse.ArgumentTypeError: If directory cannot be created.
    """
    p = Path(path)
    if p.exists() and not p.is_dir():
        raise argparse.ArgumentTypeError(f"Not a directory: {path}")
    return p


def validate_port(value: str) -> int:
    """
    Validate port number.

    Args:
        value: Port number as string.

    Returns:
        Port number as integer.

    Raises:
        argparse.ArgumentTypeError: If port is invalid.
    """
    try:
        port = int(value)
        if not (1 <= port <= 65535):
            raise ValueError
        return port
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid port: {value}. Must be between 1 and 65535."
        )


def validate_positive_int(value: str) -> int:
    """
    Validate positive integer.

    Args:
        value: Integer as string.

    Returns:
        Integer value.

    Raises:
        argparse.ArgumentTypeError: If value is not positive.
    """
    try:
        val = int(value)
        if val <= 0:
            raise ValueError
        return val
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid value: {value}. Must be a positive integer."
        )


def validate_non_negative_float(value: str) -> float:
    """
    Validate non-negative float.

    Args:
        value: Float as string.

    Returns:
        Float value.

    Raises:
        argparse.ArgumentTypeError: If value is negative.
    """
    try:
        val = float(value)
        if val < 0:
            raise ValueError
        return val
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid value: {value}. Must be a non-negative number."
        )


def validate_probability(value: str) -> float:
    """
    Validate probability value (0.0 to 1.0).

    Args:
        value: Probability as string.

    Returns:
        Float value.

    Raises:
        argparse.ArgumentTypeError: If value is not in valid range.
    """
    try:
        val = float(value)
        if not (0.0 <= val <= 1.0):
            raise ValueError
        return val
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"Invalid probability: {value}. Must be between 0.0 and 1.0."
        )
