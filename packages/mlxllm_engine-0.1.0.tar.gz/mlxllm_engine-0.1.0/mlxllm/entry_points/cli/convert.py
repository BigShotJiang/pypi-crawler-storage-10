# SPDX-License-Identifier: Apache-2.0
"""Convert command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def run_convert(args: argparse.Namespace) -> int:
    """
    Run the convert command.

    Converts HuggingFace models to MLX format with optional quantization.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        from mlxllm.models.convert import ModelConverter

        logger.info(f"Converting model: {args.model}")
        logger.info(f"Output directory: {args.output_dir}")

        if args.quantization:
            logger.info(f"Quantization: {args.quantization}")

        # Check if output directory exists
        output_path = Path(args.output_dir)
        if output_path.exists() and not args.force:
            logger.error(
                f"Output directory already exists: {output_path}\n"
                "Use --force to overwrite."
            )
            return 1

        # Create converter
        converter = ModelConverter()

        # Convert model
        result_path = converter.convert_to_mlx(
            source=args.model,
            output_dir=output_path,
            quantization=args.quantization,
            revision=args.revision,
            trust_remote_code=args.trust_remote_code,
        )

        logger.info(f"Model converted successfully!")
        logger.info(f"Output: {result_path}")

        # Upload to HuggingFace Hub if requested
        if args.upload_to_hf:
            if not args.hf_repo_id:
                logger.error("--hf-repo-id must be specified with --upload-to-hf")
                return 1

            logger.info(f"Uploading to HuggingFace Hub: {args.hf_repo_id}")

            try:
                from huggingface_hub import HfApi

                api = HfApi()
                api.upload_folder(
                    folder_path=str(result_path),
                    repo_id=args.hf_repo_id,
                    repo_type="model",
                )

                logger.info(f"Model uploaded successfully to: {args.hf_repo_id}")
                logger.info(f"View at: https://huggingface.co/{args.hf_repo_id}")

            except ImportError:
                logger.error(
                    "huggingface_hub is required for uploading. "
                    "Install with: pip install huggingface_hub"
                )
                return 1
            except Exception as e:
                logger.error(f"Upload failed: {e}", exc_info=True)
                return 1

        return 0

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Conversion failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_convert(argparse.Namespace()))
