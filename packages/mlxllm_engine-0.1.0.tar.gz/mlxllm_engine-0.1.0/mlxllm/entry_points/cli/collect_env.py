# SPDX-License-Identifier: Apache-2.0
"""Collect environment information for debugging MLX-LLM."""

from __future__ import annotations

import platform
import subprocess
import sys
from pathlib import Path
from typing import Optional


def get_mlxllm_version() -> str:
    """Get MLX-LLM version."""
    try:
        from mlxllm import __version__
        return __version__
    except (ImportError, AttributeError):
        return "unknown"


def get_python_version() -> str:
    """Get Python version."""
    return sys.version.replace("\n", " ")


def get_platform_info() -> dict[str, str]:
    """Get platform information."""
    return {
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
    }


def get_package_version(package_name: str) -> str:
    """
    Get version of an installed package.

    Args:
        package_name: Name of the package.

    Returns:
        Version string or "not installed".
    """
    try:
        import importlib.metadata
        return importlib.metadata.version(package_name)
    except Exception:
        return "not installed"


def get_git_info() -> Optional[dict[str, str]]:
    """
    Get git information if repository is a git repo.

    Returns:
        Dictionary with git info or None if not a git repo.
    """
    try:
        # Try to find the git repository root
        repo_root = Path(__file__).parent.parent.parent.parent
        git_dir = repo_root / ".git"

        if not git_dir.exists():
            return None

        # Get commit hash
        commit_result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        commit_hash = commit_result.stdout.strip() if commit_result.returncode == 0 else "unknown"

        # Get branch name
        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        branch = branch_result.stdout.strip() if branch_result.returncode == 0 else "unknown"

        # Check if there are uncommitted changes
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        has_changes = bool(status_result.stdout.strip()) if status_result.returncode == 0 else False

        return {
            "commit": commit_hash[:8] if len(commit_hash) >= 8 else commit_hash,
            "branch": branch,
            "dirty": "yes" if has_changes else "no",
        }
    except Exception:
        return None


def get_mlx_info() -> dict[str, str]:
    """
    Get MLX backend information.

    Returns:
        Dictionary with MLX info.
    """
    info = {}

    try:
        import mlx
        info["mlx_version"] = mlx.__version__

        # Get Metal device info if available
        try:
            import mlx.core as mx
            info["mlx_backend"] = "Metal"
            info["mlx_device"] = str(mx.default_device())

            # Try to get memory info
            try:
                mem_info = mx.metal.get_active_memory()
                info["mlx_active_memory_mb"] = f"{mem_info / 1024 / 1024:.2f}"
            except Exception:
                pass
        except Exception:
            info["mlx_backend"] = "CPU (fallback)"
    except ImportError:
        info["mlx_version"] = "not installed"

    return info


def collect_env_info() -> dict[str, any]:
    """
    Collect comprehensive environment information.

    Returns:
        Dictionary containing all environment info.
    """
    env_info = {
        "mlxllm_version": get_mlxllm_version(),
        "python_version": get_python_version(),
        "platform": get_platform_info(),
    }

    # Add git info if available
    git_info = get_git_info()
    if git_info:
        env_info["git"] = git_info

    # Add MLX info
    env_info["mlx"] = get_mlx_info()

    # Add important dependencies
    env_info["dependencies"] = {
        "numpy": get_package_version("numpy"),
        "transformers": get_package_version("transformers"),
        "torch": get_package_version("torch"),
        "safetensors": get_package_version("safetensors"),
        "huggingface-hub": get_package_version("huggingface-hub"),
        "fastapi": get_package_version("fastapi"),
        "uvicorn": get_package_version("uvicorn"),
        "pydantic": get_package_version("pydantic"),
    }

    return env_info


def format_env_info(env_info: dict[str, any]) -> str:
    """
    Format environment information as a readable string.

    Args:
        env_info: Dictionary with environment information.

    Returns:
        Formatted string.
    """
    lines = [
        "=" * 70,
        "MLX-LLM Environment Information",
        "=" * 70,
        "",
        f"MLX-LLM version: {env_info['mlxllm_version']}",
        f"Python version: {env_info['python_version']}",
        "",
        "Platform:",
        f"  System: {env_info['platform']['system']}",
        f"  Release: {env_info['platform']['release']}",
        f"  Machine: {env_info['platform']['machine']}",
        f"  Processor: {env_info['platform']['processor']}",
        "",
    ]

    # Add git info if available
    if "git" in env_info:
        lines.extend([
            "Git:",
            f"  Branch: {env_info['git']['branch']}",
            f"  Commit: {env_info['git']['commit']}",
            f"  Dirty: {env_info['git']['dirty']}",
            "",
        ])

    # Add MLX info
    lines.extend([
        "MLX:",
        f"  Version: {env_info['mlx']['mlx_version']}",
    ])

    if "mlx_backend" in env_info["mlx"]:
        lines.append(f"  Backend: {env_info['mlx']['mlx_backend']}")

    if "mlx_device" in env_info["mlx"]:
        lines.append(f"  Device: {env_info['mlx']['mlx_device']}")

    if "mlx_active_memory_mb" in env_info["mlx"]:
        lines.append(f"  Active memory: {env_info['mlx']['mlx_active_memory_mb']} MB")

    lines.append("")

    # Add dependencies
    lines.extend([
        "Dependencies:",
    ])

    for pkg, version in env_info["dependencies"].items():
        lines.append(f"  {pkg}: {version}")

    lines.extend([
        "",
        "=" * 70,
    ])

    return "\n".join(lines)


def main() -> int:
    """
    Main entry point for collect_env command.

    Returns:
        Exit code (0 for success).
    """
    env_info = collect_env_info()
    print(format_env_info(env_info))
    return 0


if __name__ == "__main__":
    sys.exit(main())
