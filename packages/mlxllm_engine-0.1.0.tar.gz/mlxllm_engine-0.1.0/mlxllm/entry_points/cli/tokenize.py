# SPDX-License-Identifier: Apache-2.0
"""Tokenize command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def tokenize_text(
    model: str,
    text: str,
    tokenizer: Optional[str] = None,
    revision: Optional[str] = None,
    trust_remote_code: bool = False,
    add_special_tokens: bool = True,
) -> dict:
    """
    Tokenize text and return token information.

    Args:
        model: Model name or path.
        text: Text to tokenize.
        tokenizer: Optional tokenizer path.
        revision: Optional model revision.
        trust_remote_code: Whether to trust remote code.
        add_special_tokens: Whether to add special tokens.

    Returns:
        Dictionary with tokenization results.
    """
    from mlxllm.tokenization.tokenizer import get_tokenizer

    logger.info(f"Loading tokenizer from: {tokenizer or model}")

    # Get tokenizer
    tokenizer_obj = get_tokenizer(
        tokenizer_name=tokenizer or model,
        revision=revision,
        trust_remote_code=trust_remote_code,
    )

    # Tokenize
    token_ids = tokenizer_obj.encode(text, add_special_tokens=add_special_tokens)

    # Decode individual tokens
    tokens = []
    for token_id in token_ids:
        token_text = tokenizer_obj.decode([token_id])
        tokens.append({
            "id": int(token_id),
            "text": token_text,
        })

    result = {
        "text": text,
        "tokens": tokens,
        "num_tokens": len(token_ids),
        "token_ids": [int(tid) for tid in token_ids],
    }

    return result


def format_tokenization_output(
    result: dict,
    show_ids: bool = True,
    show_text: bool = False,
) -> str:
    """
    Format tokenization results for display.

    Args:
        result: Tokenization results.
        show_ids: Whether to show token IDs.
        show_text: Whether to show decoded text for each token.

    Returns:
        Formatted string.
    """
    lines = [
        "=" * 70,
        "Tokenization Results",
        "=" * 70,
        f"Input: {result['text'][:100]}{'...' if len(result['text']) > 100 else ''}",
        f"Number of tokens: {result['num_tokens']}",
        "",
    ]

    if show_ids or show_text:
        lines.append("Tokens:")
        lines.append("")

        for i, token in enumerate(result["tokens"]):
            token_info = []

            if show_ids:
                token_info.append(f"ID: {token['id']:6d}")

            if show_text:
                # Escape special characters for display
                text_display = repr(token["text"])[1:-1]  # Remove quotes from repr
                token_info.append(f"Text: {text_display}")

            if token_info:
                lines.append(f"  [{i:4d}] " + " | ".join(token_info))

        lines.append("")

    lines.append("=" * 70)

    return "\n".join(lines)


def run_tokenize(args: argparse.Namespace) -> int:
    """
    Run the tokenize command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        # Tokenize text
        result = tokenize_text(
            model=args.model,
            text=args.text,
            tokenizer=args.tokenizer,
            revision=args.revision,
            trust_remote_code=args.trust_remote_code,
            add_special_tokens=not args.no_special_tokens,
        )

        # Write output
        if args.output_file:
            # Write JSON to file
            output_path = Path(args.output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                json.dump(result, f, indent=2)
            logger.info(f"Output written to: {output_path}")

            # Also print summary to console
            print(f"Tokenized {result['num_tokens']} tokens")
            print(f"Output saved to: {output_path}")
        else:
            # Format and print to console
            output = format_tokenization_output(
                result,
                show_ids=not args.no_ids,
                show_text=args.show_text,
            )
            print(output)

        return 0

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Tokenization failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_tokenize(argparse.Namespace()))
