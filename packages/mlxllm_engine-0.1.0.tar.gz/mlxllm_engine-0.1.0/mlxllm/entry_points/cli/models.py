# SPDX-License-Identifier: Apache-2.0
"""CLI commands for model management."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from mlxllm.models import (
    ModelManager,
    download_model,
    get_model_info,
    list_available_models,
    validate_model,
)
from mlxllm.models.convert import ModelConverter


def run_models_list(args: argparse.Namespace) -> int:
    """
    List cached models.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    models = list_available_models(filter_by=args.filter)

    if not models:
        print("No models found in cache.")
        print(f"\nUse 'mlxllm models download <model_id>' to download a model.")
        return 0

    print(f"Found {len(models)} model(s) in cache:\n")

    for model in models:
        print(f"Model: {model.model_id}")
        print(f"  Type: {model.model_type.value}")
        print(f"  Path: {model.cache_path}")
        print(f"  Memory: {model.memory_footprint_mb:.1f} MB")
        print(f"  Layers: {model.num_layers}")
        print(f"  Hidden size: {model.hidden_size}")

        if model.quantization:
            print(f"  Quantization: {model.quantization.value}")

        if model.last_accessed:
            print(f"  Last accessed: {model.last_accessed.strftime('%Y-%m-%d %H:%M')}")

        print()

    return 0


def run_models_download(args: argparse.Namespace) -> int:
    """
    Download a model.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    print(f"Downloading model: {args.model_id}")

    if args.quantization:
        print(f"Quantization: {args.quantization}")

    try:
        model_info = download_model(
            model_id=args.model_id,
            quantization=args.quantization,
            revision=args.revision,
            force=args.force,
        )

        print(f"\n✓ Successfully downloaded model")
        print(f"  Model ID: {model_info.model_id}")
        print(f"  Type: {model_info.model_type.value}")
        print(f"  Path: {model_info.cache_path}")
        print(f"  Memory: {model_info.memory_footprint_mb:.1f} MB")
        print(f"  Layers: {model_info.num_layers}")

        return 0

    except Exception as e:
        print(f"\n✗ Download failed: {e}", file=sys.stderr)
        return 1


def run_models_info(args: argparse.Namespace) -> int:
    """
    Show model information.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    model_info = get_model_info(args.model_id, revision=args.revision)

    if model_info is None:
        print(f"Model not found in cache: {args.model_id}")
        print(f"\nUse 'mlxllm models download {args.model_id}' to download it.")
        return 1

    print(f"Model Information:\n")
    print(f"  Model ID: {model_info.model_id}")
    print(f"  Type: {model_info.model_type.value}")
    print(f"  Revision: {model_info.revision}")
    print(f"  Path: {model_info.cache_path}")
    print()

    print(f"Architecture:")
    print(f"  Vocabulary size: {model_info.vocab_size:,}")
    print(f"  Hidden size: {model_info.hidden_size:,}")
    print(f"  Number of layers: {model_info.num_layers}")
    print(f"  Attention heads: {model_info.num_attention_heads}")

    if model_info.num_kv_heads:
        print(f"  KV heads: {model_info.num_kv_heads}")

    if model_info.intermediate_size:
        print(f"  Intermediate size: {model_info.intermediate_size:,}")

    print()

    print(f"Memory:")
    print(f"  Model footprint: {model_info.memory_footprint_mb:.1f} MB")

    if model_info.quantization:
        print(f"  Quantization: {model_info.quantization.value}")

    # Estimate memory usage
    mem_1_seq = model_info.estimate_memory_usage(batch_size=1, sequence_length=2048)
    mem_8_seq = model_info.estimate_memory_usage(batch_size=8, sequence_length=2048)

    print(f"  Estimated usage (1 seq, 2048 tokens): {mem_1_seq:.1f} MB")
    print(f"  Estimated usage (8 seq, 2048 tokens): {mem_8_seq:.1f} MB")

    print()

    if model_info.supported_features:
        print(f"Supported features:")
        for feature in model_info.supported_features:
            print(f"  • {feature}")
        print()

    if model_info.download_date:
        print(f"Downloaded: {model_info.download_date.strftime('%Y-%m-%d %H:%M')}")

    if model_info.last_accessed:
        print(f"Last accessed: {model_info.last_accessed.strftime('%Y-%m-%d %H:%M')}")

    return 0


def run_models_remove(args: argparse.Namespace) -> int:
    """
    Remove a model from cache.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    if not args.yes:
        response = input(f"Remove model '{args.model_id}' from cache? [y/N] ")
        if response.lower() not in ["y", "yes"]:
            print("Cancelled.")
            return 0

    manager = ModelManager()
    success = manager.remove_model(args.model_id, revision=args.revision)

    if success:
        print(f"✓ Removed model: {args.model_id}")
        return 0
    else:
        print(f"✗ Failed to remove model: {args.model_id}", file=sys.stderr)
        return 1


def run_models_validate(args: argparse.Namespace) -> int:
    """
    Validate model compatibility.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    print(f"Validating model: {args.model_id}\n")

    result = validate_model(
        model_id=args.model_id,
        auto_download=args.auto_download,
    )

    print(result)

    return 0 if result.is_valid else 1


def run_models_convert(args: argparse.Namespace) -> int:
    """
    Convert model to MLX format.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    print(f"Converting model: {args.model_id}")
    print(f"Output directory: {args.output_dir}")

    if args.quantization:
        print(f"Quantization: {args.quantization}")

    try:
        converter = ModelConverter()

        output_path = converter.convert_to_mlx(
            source=args.model_id,
            output_dir=Path(args.output_dir),
            quantization=args.quantization or "q4_0",
            optimize=not args.no_optimize,
            trust_remote_code=args.trust_remote_code,
        )

        print(f"\n✓ Successfully converted model")
        print(f"  Output: {output_path}")

        return 0

    except Exception as e:
        print(f"\n✗ Conversion failed: {e}", file=sys.stderr)
        return 1


def run_models_cache_info(args: argparse.Namespace) -> int:
    """
    Show cache information.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    manager = ModelManager()

    cache_size_gb = manager.get_cache_size()
    models = manager.list_cached_models()

    print(f"Cache Directory: {manager.cache_dir}")
    print(f"Total size: {cache_size_gb:.2f} GB")
    print(f"Number of models: {len(models)}")

    return 0


def run_models_cache_clear(args: argparse.Namespace) -> int:
    """
    Clear model cache.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code.
    """
    if not args.yes:
        manager = ModelManager()
        cache_size_gb = manager.get_cache_size()

        response = input(
            f"Clear entire cache ({cache_size_gb:.2f} GB)? This cannot be undone. [y/N] "
        )
        if response.lower() not in ["y", "yes"]:
            print("Cancelled.")
            return 0

    manager = ModelManager()
    success = manager.clear_cache(confirm=True)

    if success:
        print("✓ Cache cleared")
        return 0
    else:
        print("✗ Failed to clear cache", file=sys.stderr)
        return 1


def add_models_subparser(subparsers) -> None:
    """
    Add models subcommand with all sub-subcommands.

    Args:
        subparsers: Subparser object from argparse.
    """
    models_parser = subparsers.add_parser(
        "models",
        help="Model management commands",
        description="Manage models: download, list, validate, convert, etc.",
    )

    models_subparsers = models_parser.add_subparsers(
        dest="models_command",
        help="Available model commands",
        required=True,
    )

    # List command
    list_parser = models_subparsers.add_parser(
        "list",
        help="List cached models",
    )
    list_parser.add_argument(
        "--filter",
        type=str,
        help="Filter models by name",
    )

    # Download command
    download_parser = models_subparsers.add_parser(
        "download",
        help="Download a model",
    )
    download_parser.add_argument(
        "model_id",
        type=str,
        help="HuggingFace model identifier",
    )
    download_parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0"],
        help="Quantization type",
    )
    download_parser.add_argument(
        "--revision",
        type=str,
        default="main",
        help="Git revision (default: main)",
    )
    download_parser.add_argument(
        "--force",
        action="store_true",
        help="Force re-download even if cached",
    )

    # Info command
    info_parser = models_subparsers.add_parser(
        "info",
        help="Show model information",
    )
    info_parser.add_argument(
        "model_id",
        type=str,
        help="HuggingFace model identifier",
    )
    info_parser.add_argument(
        "--revision",
        type=str,
        default="main",
        help="Git revision (default: main)",
    )

    # Remove command
    remove_parser = models_subparsers.add_parser(
        "remove",
        help="Remove a model from cache",
    )
    remove_parser.add_argument(
        "model_id",
        type=str,
        help="HuggingFace model identifier",
    )
    remove_parser.add_argument(
        "--revision",
        type=str,
        default="main",
        help="Git revision (default: main)",
    )
    remove_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompt",
    )

    # Validate command
    validate_parser = models_subparsers.add_parser(
        "validate",
        help="Validate model compatibility",
    )
    validate_parser.add_argument(
        "model_id",
        type=str,
        help="HuggingFace model identifier",
    )
    validate_parser.add_argument(
        "--auto-download",
        action="store_true",
        help="Download model if not cached",
    )

    # Convert command
    convert_parser = models_subparsers.add_parser(
        "convert",
        help="Convert model to MLX format",
    )
    convert_parser.add_argument(
        "model_id",
        type=str,
        help="HuggingFace model identifier or local path",
    )
    convert_parser.add_argument(
        "output_dir",
        type=str,
        help="Output directory",
    )
    convert_parser.add_argument(
        "--quantization",
        type=str,
        default="q4_0",
        help="Quantization type (default: q4_0)",
    )
    convert_parser.add_argument(
        "--no-optimize",
        action="store_true",
        help="Skip optimization step",
    )
    convert_parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code",
    )

    # Cache info command
    cache_info_parser = models_subparsers.add_parser(
        "cache-info",
        help="Show cache information",
    )

    # Cache clear command
    cache_clear_parser = models_subparsers.add_parser(
        "cache-clear",
        help="Clear model cache",
    )
    cache_clear_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip confirmation prompt",
    )
