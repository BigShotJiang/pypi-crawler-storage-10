# SPDX-License-Identifier: Apache-2.0
"""Serve command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import asyncio
import logging
from pathlib import Path
from typing import Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.entry_points.cli.types import APIProtocol

logger = logging.getLogger(__name__)


def run_serve(args: argparse.Namespace) -> int:
    """
    Run the serve command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    logger.info("Starting MLX-LLM server...")

    # Determine which protocol to use
    protocol = getattr(args, "protocol", "openai")

    try:
        if protocol == APIProtocol.OPENAI.value:
            return asyncio.run(run_openai_server(args))
        elif protocol == APIProtocol.ANTHROPIC.value:
            return asyncio.run(run_anthropic_server(args))
        else:
            logger.error(f"Unknown protocol: {protocol}")
            return 1
    except Exception as e:
        logger.error(f"Failed to start server: {e}", exc_info=True)
        return 1


async def run_openai_server(args: argparse.Namespace) -> int:
    """
    Run OpenAI-compatible API server.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    from mlxllm.entry_points.openai.api_server import create_app
    from mlxllm.entry_points.launcher import serve_http

    # Validate arguments
    _validate_serve_args(args)

    # Create configurations
    model_config = ModelConfig(
        model_name=args.model,
        tokenizer=args.tokenizer,
        revision=args.revision,
        trust_remote_code=args.trust_remote_code,
        max_model_len=args.max_model_len,
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=args.max_num_seqs,
        max_num_batched_tokens=args.max_num_batched_tokens or (args.max_model_len or 2048),
        policy=args.scheduler_policy,
        max_paddings=args.max_paddings,
    )

    cache_config = CacheConfig(
        block_size=args.block_size,
        gpu_memory_utilization=args.gpu_memory_utilization,
        swap_space_gb=args.swap_space,
        enable_prefix_caching=args.enable_prefix_caching,
    )

    # Initialize engine
    logger.info(f"Initializing engine with model: {args.model}")
    engine_client = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        model_path=args.model,
        quantization=args.quantization,
    )

    # Parse served model names
    served_model_names = args.served_model_name or [args.model.split("/")[-1]]

    # Parse LoRA modules
    lora_modules = []
    if hasattr(args, "lora_modules") and args.lora_modules:
        for lora_str in args.lora_modules:
            # Expected format: "name=my_lora,path=/path/to/lora"
            lora_dict = {}
            for part in lora_str.split(","):
                if "=" in part:
                    key, value = part.split("=", 1)
                    lora_dict[key.strip()] = value.strip()
            if "name" in lora_dict and "path" in lora_dict:
                lora_modules.append(lora_dict)

    # Create FastAPI app
    app = create_app(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
        response_role=args.response_role,
        chat_template=args.chat_template,
        lora_modules=lora_modules,
        enable_cors=args.enable_cors,
        allowed_origins=args.allowed_origins,
        allowed_methods=args.allowed_methods,
        allowed_headers=args.allowed_headers,
    )

    # Prepare SSL configuration
    ssl_keyfile = Path(args.ssl_keyfile) if args.ssl_keyfile else None
    ssl_certfile = Path(args.ssl_certfile) if args.ssl_certfile else None
    ssl_ca_certs = Path(args.ssl_ca_certs) if args.ssl_ca_certs else None

    logger.info(f"Starting server on {args.host}:{args.port}")
    logger.info(f"Serving models: {served_model_names}")
    logger.info(f"OpenAI API endpoint: http://{args.host}:{args.port}/v1")

    # Serve HTTP
    await serve_http(
        app=app,
        host=args.host,
        port=args.port,
        log_level=args.log_level,
        ssl_keyfile=ssl_keyfile,
        ssl_certfile=ssl_certfile,
        ssl_ca_certs=ssl_ca_certs,
        enable_ssl_refresh=args.enable_ssl_refresh,
        watchdog_enabled=args.watchdog_enabled,
    )

    return 0


async def run_anthropic_server(args: argparse.Namespace) -> int:
    """
    Run Anthropic-compatible API server.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    # TODO: Implement Anthropic API server
    logger.error("Anthropic API server not yet implemented")
    return 1


def _validate_serve_args(args: argparse.Namespace) -> None:
    """
    Validate serve command arguments.

    Args:
        args: Parsed command-line arguments.

    Raises:
        ValueError: If arguments are invalid.
    """
    # Validate host and port
    if not args.host:
        raise ValueError("Host must be specified")

    if not (1 <= args.port <= 65535):
        raise ValueError(f"Invalid port: {args.port}. Must be between 1 and 65535.")

    # Validate memory utilization
    if not (0.0 < args.gpu_memory_utilization <= 1.0):
        raise ValueError(
            f"Invalid GPU memory utilization: {args.gpu_memory_utilization}. "
            "Must be between 0.0 and 1.0."
        )

    # Validate swap space
    if args.swap_space < 0:
        raise ValueError(
            f"Invalid swap space: {args.swap_space}. Must be non-negative."
        )

    # Validate block size
    if args.block_size <= 0:
        raise ValueError(f"Invalid block size: {args.block_size}. Must be positive.")

    # Validate max_num_seqs
    if args.max_num_seqs <= 0:
        raise ValueError(
            f"Invalid max_num_seqs: {args.max_num_seqs}. Must be positive."
        )

    # Validate SSL configuration
    if args.ssl_keyfile and not args.ssl_certfile:
        raise ValueError("SSL certificate file must be specified with SSL key file")

    if args.ssl_certfile and not args.ssl_keyfile:
        raise ValueError("SSL key file must be specified with SSL certificate file")

    if args.ssl_keyfile:
        keyfile = Path(args.ssl_keyfile)
        if not keyfile.exists():
            raise ValueError(f"SSL key file not found: {args.ssl_keyfile}")
        if not keyfile.is_file():
            raise ValueError(f"SSL key file is not a file: {args.ssl_keyfile}")

    if args.ssl_certfile:
        certfile = Path(args.ssl_certfile)
        if not certfile.exists():
            raise ValueError(f"SSL certificate file not found: {args.ssl_certfile}")
        if not certfile.is_file():
            raise ValueError(f"SSL certificate file is not a file: {args.ssl_certfile}")

    if args.ssl_ca_certs:
        ca_certs = Path(args.ssl_ca_certs)
        if not ca_certs.exists():
            raise ValueError(f"SSL CA certificates file not found: {args.ssl_ca_certs}")
        if not ca_certs.is_file():
            raise ValueError(
                f"SSL CA certificates file is not a file: {args.ssl_ca_certs}"
            )

    # Validate CORS configuration
    if args.allowed_origins and not args.enable_cors:
        logger.warning(
            "CORS origins specified but CORS is not enabled. "
            "Use --enable-cors to enable CORS."
        )

    # Validate chat template
    if args.chat_template:
        template_path = Path(args.chat_template)
        if template_path.exists() and not template_path.is_file():
            raise ValueError(f"Chat template is not a file: {args.chat_template}")

    # Validate quantization
    valid_quantizations = ["q4_0", "q4_1", "q8_0", "fp16", "fp32"]
    if args.quantization and args.quantization not in valid_quantizations:
        raise ValueError(
            f"Invalid quantization: {args.quantization}. "
            f"Must be one of: {', '.join(valid_quantizations)}"
        )

    logger.info("Server arguments validated successfully")


def _setup_server_logging(log_level: str, log_requests: bool) -> None:
    """
    Setup logging for the server.

    Args:
        log_level: Logging level.
        log_requests: Whether to log all requests.
    """
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL,
    }

    level = level_map.get(log_level.lower(), logging.INFO)

    # Configure root logger
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Configure request logging
    if log_requests:
        request_logger = logging.getLogger("mlxllm.entry_points")
        request_logger.setLevel(logging.DEBUG)

    # Reduce verbosity of some noisy loggers
    logging.getLogger("uvicorn").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING if not log_requests else logging.INFO)


def print_server_info(
    host: str,
    port: int,
    served_model_names: list[str],
    protocol: str = "openai",
) -> None:
    """
    Print server startup information.

    Args:
        host: Server host.
        port: Server port.
        served_model_names: List of served model names.
        protocol: API protocol (openai or anthropic).
    """
    protocol_upper = protocol.upper()

    print("\n" + "=" * 70)
    print(f"MLX-LLM Server ({protocol_upper} API)")
    print("=" * 70)
    print(f"Server URL: http://{host}:{port}")
    print(f"API Endpoint: http://{host}:{port}/v1")
    print(f"Health Check: http://{host}:{port}/health")
    print(f"Models: {', '.join(served_model_names)}")
    print("=" * 70)
    print("\nExample usage:")

    if protocol == "openai":
        print(f"""
# Chat completion
curl http://{host}:{port}/v1/chat/completions \\
  -H "Content-Type: application/json" \\
  -d '{{
    "model": "{served_model_names[0]}",
    "messages": [{{"role": "user", "content": "Hello!"}}],
    "max_tokens": 100
  }}'

# Text completion
curl http://{host}:{port}/v1/completions \\
  -H "Content-Type: application/json" \\
  -d '{{
    "model": "{served_model_names[0]}",
    "prompt": "Once upon a time",
    "max_tokens": 100
  }}'
        """)

    print("\nPress Ctrl+C to stop the server")
    print("=" * 70 + "\n")


def _parse_lora_modules_from_args(
    lora_modules_args: Optional[list[str]],
) -> list[dict[str, str]]:
    """
    Parse LoRA modules from command-line arguments.

    Args:
        lora_modules_args: List of LoRA module strings.

    Returns:
        List of LoRA module dictionaries.
    """
    if not lora_modules_args:
        return []

    lora_modules = []
    for lora_str in lora_modules_args:
        # Expected format: "name=my_lora,path=/path/to/lora"
        lora_dict = {}
        for part in lora_str.split(","):
            if "=" in part:
                key, value = part.split("=", 1)
                lora_dict[key.strip()] = value.strip()

        if "name" in lora_dict and "path" in lora_dict:
            lora_modules.append(lora_dict)
        else:
            logger.warning(
                f"Invalid LoRA module specification (missing name or path): {lora_str}"
            )

    return lora_modules
