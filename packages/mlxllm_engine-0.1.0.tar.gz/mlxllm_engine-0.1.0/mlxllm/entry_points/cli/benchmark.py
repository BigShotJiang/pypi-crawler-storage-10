# SPDX-License-Identifier: Apache-2.0
"""Benchmark command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import random
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


@dataclass
class BenchmarkResults:
    """Results from a benchmark run."""

    # Configuration
    num_prompts: int
    prompt_length: int
    output_length: int
    batch_size: int

    # Timing results
    total_time: float
    total_tokens: int
    prompt_tokens: int
    completion_tokens: int

    # Throughput metrics
    throughput_tokens_per_sec: float
    throughput_requests_per_sec: float

    # Latency metrics
    mean_latency: float
    median_latency: float
    p95_latency: float
    p99_latency: float

    # Individual request latencies
    latencies: list[float]

    def to_dict(self) -> dict:
        """Convert results to dictionary."""
        return {
            "configuration": {
                "num_prompts": self.num_prompts,
                "prompt_length": self.prompt_length,
                "output_length": self.output_length,
                "batch_size": self.batch_size,
            },
            "timing": {
                "total_time": self.total_time,
                "total_tokens": self.total_tokens,
                "prompt_tokens": self.prompt_tokens,
                "completion_tokens": self.completion_tokens,
            },
            "throughput": {
                "tokens_per_sec": self.throughput_tokens_per_sec,
                "requests_per_sec": self.throughput_requests_per_sec,
            },
            "latency": {
                "mean": self.mean_latency,
                "median": self.median_latency,
                "p95": self.p95_latency,
                "p99": self.p99_latency,
            },
        }

    def format_report(self) -> str:
        """Format results as a readable report."""
        lines = [
            "=" * 70,
            "MLX-LLM Benchmark Results",
            "=" * 70,
            "",
            "Configuration:",
            f"  Number of prompts: {self.num_prompts}",
            f"  Prompt length: {self.prompt_length} tokens",
            f"  Output length: {self.output_length} tokens",
            f"  Batch size: {self.batch_size}",
            "",
            "Timing:",
            f"  Total time: {self.total_time:.2f} seconds",
            f"  Total tokens: {self.total_tokens:,}",
            f"    Prompt tokens: {self.prompt_tokens:,}",
            f"    Completion tokens: {self.completion_tokens:,}",
            "",
            "Throughput:",
            f"  Tokens/second: {self.throughput_tokens_per_sec:.2f}",
            f"  Requests/second: {self.throughput_requests_per_sec:.2f}",
            "",
            "Latency (per request):",
            f"  Mean: {self.mean_latency * 1000:.2f} ms",
            f"  Median: {self.median_latency * 1000:.2f} ms",
            f"  P95: {self.p95_latency * 1000:.2f} ms",
            f"  P99: {self.p99_latency * 1000:.2f} ms",
            "",
            "=" * 70,
        ]

        return "\n".join(lines)


async def run_benchmark_requests(
    engine: AsyncLLMEngine,
    prompts: list[str],
    sampling_params: SamplingParams,
    batch_size: int,
) -> tuple[float, list[float]]:
    """
    Run benchmark requests through the engine.

    Args:
        engine: LLM engine.
        prompts: List of prompts to process.
        sampling_params: Sampling parameters.
        batch_size: Batch size for processing.

    Returns:
        Tuple of (total_time, latencies).
    """
    latencies = []
    start_time = time.time()

    # Process in batches
    for i in range(0, len(prompts), batch_size):
        batch = prompts[i:i + batch_size]

        # Process batch concurrently
        tasks = []
        for j, prompt in enumerate(batch):
            request_id = f"bench-{i + j}"
            tasks.append(process_single_request(engine, prompt, sampling_params, request_id))

        # Wait for batch to complete
        batch_latencies = await asyncio.gather(*tasks)
        latencies.extend(batch_latencies)

        logger.debug(f"Completed batch {i // batch_size + 1}/{(len(prompts) + batch_size - 1) // batch_size}")

    total_time = time.time() - start_time

    return total_time, latencies


async def process_single_request(
    engine: AsyncLLMEngine,
    prompt: str,
    sampling_params: SamplingParams,
    request_id: str,
) -> float:
    """
    Process a single request and measure latency.

    Args:
        engine: LLM engine.
        prompt: Input prompt.
        sampling_params: Sampling parameters.
        request_id: Request ID.

    Returns:
        Request latency in seconds.
    """
    start_time = time.time()

    # Generate response
    async for output in engine.generate(
        prompt=prompt,
        sampling_params=sampling_params,
        request_id=request_id,
    ):
        pass  # Just consume the output

    latency = time.time() - start_time
    return latency


def generate_random_prompts(
    num_prompts: int,
    prompt_length: int,
    vocab_size: int = 50000,
) -> list[str]:
    """
    Generate random prompts for benchmarking.

    Args:
        num_prompts: Number of prompts to generate.
        prompt_length: Target length in tokens (approximate).
        vocab_size: Vocabulary size for random token generation.

    Returns:
        List of generated prompts.
    """
    prompts = []

    for i in range(num_prompts):
        # Generate random "words" to approximate tokens
        # Assuming ~4 characters per token on average
        num_words = prompt_length // 2  # Rough approximation
        words = [f"word{random.randint(0, vocab_size)}" for _ in range(num_words)]
        prompt = " ".join(words)
        prompts.append(prompt)

    return prompts


async def run_benchmark_async(
    model: str,
    num_prompts: int,
    prompt_length: int,
    output_length: int,
    batch_size: int,
    tokenizer: Optional[str] = None,
    quantization: Optional[str] = None,
    max_model_len: Optional[int] = None,
    max_num_seqs: int = 256,
    block_size: int = 16,
    gpu_memory_utilization: float = 0.9,
) -> BenchmarkResults:
    """
    Run benchmark.

    Args:
        model: Model name or path.
        num_prompts: Number of prompts to benchmark.
        prompt_length: Length of each prompt in tokens.
        output_length: Target output length in tokens.
        batch_size: Batch size for inference.
        tokenizer: Optional tokenizer path.
        quantization: Optional quantization type.
        max_model_len: Optional maximum model length.
        max_num_seqs: Maximum number of sequences.
        block_size: Block size for paged attention.
        gpu_memory_utilization: GPU memory utilization.

    Returns:
        BenchmarkResults.
    """
    # Create configurations
    model_config = ModelConfig(
        model_name=model,
        tokenizer=tokenizer,
        max_model_len=max_model_len,
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=max_num_seqs,
    )

    cache_config = CacheConfig(
        block_size=block_size,
        gpu_memory_utilization=gpu_memory_utilization,
    )

    # Initialize engine
    logger.info(f"Initializing engine with model: {model}")
    engine = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        model_path=model,
        quantization=quantization,
    )

    logger.info("Engine initialized")

    # Generate prompts
    logger.info(f"Generating {num_prompts} random prompts...")
    prompts = generate_random_prompts(num_prompts, prompt_length)

    # Create sampling parameters
    sampling_params = SamplingParams(
        max_tokens=output_length,
        temperature=1.0,
    )

    # Run benchmark
    logger.info("Starting benchmark...")
    total_time, latencies = await run_benchmark_requests(
        engine=engine,
        prompts=prompts,
        sampling_params=sampling_params,
        batch_size=batch_size,
    )

    logger.info("Benchmark complete")

    # Calculate metrics
    total_tokens = num_prompts * (prompt_length + output_length)
    prompt_tokens = num_prompts * prompt_length
    completion_tokens = num_prompts * output_length

    throughput_tokens_per_sec = total_tokens / total_time
    throughput_requests_per_sec = num_prompts / total_time

    sorted_latencies = sorted(latencies)
    mean_latency = sum(latencies) / len(latencies)
    median_latency = sorted_latencies[len(sorted_latencies) // 2]
    p95_latency = sorted_latencies[int(len(sorted_latencies) * 0.95)]
    p99_latency = sorted_latencies[int(len(sorted_latencies) * 0.99)]

    return BenchmarkResults(
        num_prompts=num_prompts,
        prompt_length=prompt_length,
        output_length=output_length,
        batch_size=batch_size,
        total_time=total_time,
        total_tokens=total_tokens,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        throughput_tokens_per_sec=throughput_tokens_per_sec,
        throughput_requests_per_sec=throughput_requests_per_sec,
        mean_latency=mean_latency,
        median_latency=median_latency,
        p95_latency=p95_latency,
        p99_latency=p99_latency,
        latencies=latencies,
    )


def run_benchmark(args: argparse.Namespace) -> int:
    """
    Run the benchmark command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        # Run benchmark
        results = asyncio.run(
            run_benchmark_async(
                model=args.model,
                num_prompts=args.num_prompts,
                prompt_length=args.prompt_length,
                output_length=args.output_length,
                batch_size=args.batch_size,
                tokenizer=args.tokenizer,
                quantization=args.quantization,
                max_model_len=args.max_model_len,
                max_num_seqs=args.max_num_seqs,
                block_size=args.block_size,
                gpu_memory_utilization=args.gpu_memory_utilization,
            )
        )

        # Print results
        print()
        print(results.format_report())

        # Write to file if requested
        if args.output_file:
            output_path = Path(args.output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                json.dump(results.to_dict(), f, indent=2)
            logger.info(f"Results written to: {output_path}")

        return 0

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Benchmark failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_benchmark(argparse.Namespace()))
