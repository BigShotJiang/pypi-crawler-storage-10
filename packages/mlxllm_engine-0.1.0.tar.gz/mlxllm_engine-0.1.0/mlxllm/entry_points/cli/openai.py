# SPDX-License-Identifier: Apache-2.0
"""
OpenAI CLI compatibility layer.

This module provides a wrapper that allows MLX-LLM to be used as a drop-in
replacement for the OpenAI CLI tool for local inference.
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from mlxllm.entry_points.cli.main import main as mlxllm_main


def create_openai_compatibility_parser() -> argparse.ArgumentParser:
    """
    Create argument parser for OpenAI CLI compatibility.

    Returns:
        ArgumentParser instance.
    """
    parser = argparse.ArgumentParser(
        prog="openai-mlx",
        description="OpenAI CLI compatibility layer for MLX-LLM",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
This tool provides basic compatibility with OpenAI CLI commands for local inference.

Examples:
  # Start API server (similar to OpenAI compatible server)
  openai-mlx api --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit

  # Chat completion
  openai-mlx chat --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit

For full MLX-LLM features, use 'mlxllm' command instead.
        """,
    )

    subparsers = parser.add_subparsers(
        dest="command",
        help="Available commands",
        required=True,
    )

    # API server command
    api_parser = subparsers.add_parser(
        "api",
        help="Start API server",
        description="Start an OpenAI-compatible API server",
    )
    api_parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    api_parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Server host (default: 0.0.0.0)",
    )
    api_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Server port (default: 8000)",
    )
    api_parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )

    # Chat command
    chat_parser = subparsers.add_parser(
        "chat",
        help="Interactive chat",
        description="Start an interactive chat session",
    )
    chat_parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    chat_parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Sampling temperature (default: 1.0)",
    )
    chat_parser.add_argument(
        "--max-tokens",
        type=int,
        default=128,
        help="Maximum tokens to generate (default: 128)",
    )
    chat_parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )

    # Completion command
    completion_parser = subparsers.add_parser(
        "complete",
        help="Text completion",
        description="Generate text completion from a prompt",
    )
    completion_parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    completion_parser.add_argument(
        "--prompt",
        type=str,
        required=True,
        help="Input prompt",
    )
    completion_parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Sampling temperature (default: 1.0)",
    )
    completion_parser.add_argument(
        "--max-tokens",
        type=int,
        default=128,
        help="Maximum tokens to generate (default: 128)",
    )
    completion_parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )

    return parser


def translate_openai_args_to_mlxllm(args: argparse.Namespace) -> list[str]:
    """
    Translate OpenAI CLI arguments to MLX-LLM arguments.

    Args:
        args: Parsed OpenAI CLI arguments.

    Returns:
        List of MLX-LLM CLI arguments.
    """
    mlxllm_args = []

    if args.command == "api":
        # Translate 'api' command to 'serve'
        mlxllm_args.extend([
            "serve",
            "--model", args.model,
            "--host", args.host,
            "--port", str(args.port),
            "--log-level", args.log_level,
        ])

    elif args.command == "chat":
        # Translate 'chat' command
        mlxllm_args.extend([
            "chat",
            "--model", args.model,
            "--temperature", str(args.temperature),
            "--max-tokens", str(args.max_tokens),
            "--log-level", args.log_level,
        ])

    elif args.command == "complete":
        # Translate 'complete' command to 'generate'
        mlxllm_args.extend([
            "generate",
            "--model", args.model,
            "--prompt", args.prompt,
            "--temperature", str(args.temperature),
            "--max-tokens", str(args.max_tokens),
            "--log-level", args.log_level,
        ])

    return mlxllm_args


def main(argv: Optional[list[str]] = None) -> int:
    """
    Main entry point for OpenAI CLI compatibility.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    # Parse OpenAI-style arguments
    parser = create_openai_compatibility_parser()
    args = parser.parse_args(argv)

    # Translate to MLX-LLM arguments
    mlxllm_args = translate_openai_args_to_mlxllm(args)

    # Call MLX-LLM main with translated arguments
    return mlxllm_main(mlxllm_args)


if __name__ == "__main__":
    sys.exit(main())
