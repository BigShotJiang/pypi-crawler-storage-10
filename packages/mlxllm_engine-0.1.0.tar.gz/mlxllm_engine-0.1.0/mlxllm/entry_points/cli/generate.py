# SPDX-License-Identifier: Apache-2.0
"""Generate command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path
from typing import Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


async def generate_text(
    model: str,
    prompt: str,
    sampling_params: SamplingParams,
    tokenizer: Optional[str] = None,
    quantization: Optional[str] = None,
    max_model_len: Optional[int] = None,
    stream: bool = False,
) -> str:
    """
    Generate text from a prompt.

    Args:
        model: Model name or path.
        prompt: Input prompt.
        sampling_params: Sampling parameters for generation.
        tokenizer: Optional tokenizer path.
        quantization: Optional quantization type.
        max_model_len: Optional maximum model length.
        stream: Whether to stream output.

    Returns:
        Generated text.
    """
    # Create configurations
    model_config = ModelConfig(
        model_name=model,
        tokenizer=tokenizer,
        max_model_len=max_model_len,
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=1,  # Single request for CLI
    )

    cache_config = CacheConfig(
        block_size=16,
    )

    # Initialize engine
    logger.info(f"Loading model: {model}")
    engine = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        model_path=model,
        quantization=quantization,
    )

    logger.info("Generating response...")

    # Generate text
    output_text = ""
    async for output in engine.generate(
        prompt=prompt,
        sampling_params=sampling_params,
        request_id="cli-generate",
    ):
        if output.outputs:
            new_text = output.outputs[0].text
            if stream:
                # Print incremental text
                incremental = new_text[len(output_text):]
                if incremental:
                    print(incremental, end="", flush=True)
            output_text = new_text

    if stream:
        print()  # Newline after streaming

    return output_text


def run_generate(args: argparse.Namespace) -> int:
    """
    Run the generate command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        # Create sampling parameters
        sampling_params = SamplingParams(
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            top_p=args.top_p,
            top_k=args.top_k,
            presence_penalty=args.presence_penalty,
            frequency_penalty=args.frequency_penalty,
            stop=args.stop,
            seed=args.seed,
        )

        # Generate text
        output = asyncio.run(
            generate_text(
                model=args.model,
                prompt=args.prompt,
                sampling_params=sampling_params,
                tokenizer=args.tokenizer,
                quantization=args.quantization,
                max_model_len=args.max_model_len,
                stream=args.stream,
            )
        )

        # Write output
        if args.output_file:
            output_path = Path(args.output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                f.write(output)
            logger.info(f"Output written to: {output_path}")
        elif not args.stream:
            # Only print if not streaming (already printed during streaming)
            print(output)

        return 0

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Generation failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_generate(argparse.Namespace()))
