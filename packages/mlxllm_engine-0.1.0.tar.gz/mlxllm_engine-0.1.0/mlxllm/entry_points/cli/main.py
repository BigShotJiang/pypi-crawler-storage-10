# SPDX-License-Identifier: Apache-2.0
"""Main CLI entry point for MLX-LLM."""

from __future__ import annotations

import argparse
import logging
import sys
from typing import Optional

from mlxllm.entry_points.cli.types import CLICommand
from mlxllm.entry_points.utils import cli_env_setup

logger = logging.getLogger(__name__)


def setup_logging(log_level: str = "info") -> None:
    """
    Setup logging configuration.

    Args:
        log_level: Logging level (debug, info, warning, error, critical).
    """
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL,
    }

    level = level_map.get(log_level.lower(), logging.INFO)

    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def create_parser() -> argparse.ArgumentParser:
    """
    Create the main argument parser with all subcommands.

    Returns:
        ArgumentParser instance.
    """
    parser = argparse.ArgumentParser(
        prog="mlxllm",
        description="MLX-LLM: High-performance LLM inference on Apple Silicon",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start OpenAI-compatible API server
  mlxllm serve --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit

  # Generate text from a prompt
  mlxllm generate --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit \\
      --prompt "Write a Python function to compute Fibonacci numbers"

  # Interactive chat
  mlxllm chat --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit

  # Generate embeddings
  mlxllm embed --model mlx-community/bge-base-en-v1.5 \\
      --input "Hello, world!"

  # Tokenize text
  mlxllm tokenize --model mlx-community/Qwen2.5-Coder-7B-Instruct-4bit \\
      --text "Hello, world!"

For more information, see: https://github.com/yourusername/mlx-llm
        """,
    )

    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )

    # Create subparsers for commands
    subparsers = parser.add_subparsers(
        dest="command",
        help="Available commands",
        required=True,
    )

    # Serve command
    from mlxllm.entry_points.openai.cli_args import make_arg_parser as make_serve_parser

    serve_parser = subparsers.add_parser(
        CLICommand.SERVE.value,
        help="Start API server",
        description="Start an OpenAI-compatible API server for model inference",
    )
    make_serve_parser(serve_parser)

    # Generate command
    generate_parser = subparsers.add_parser(
        CLICommand.GENERATE.value,
        help="Generate text from prompt",
        description="Generate text completions from a prompt",
    )
    _add_generate_args(generate_parser)

    # Chat command
    chat_parser = subparsers.add_parser(
        CLICommand.CHAT.value,
        help="Interactive chat",
        description="Start an interactive chat session",
    )
    _add_chat_args(chat_parser)

    # Embed command
    embed_parser = subparsers.add_parser(
        CLICommand.EMBED.value,
        help="Generate embeddings",
        description="Generate embeddings for text inputs",
    )
    _add_embed_args(embed_parser)

    # Tokenize command
    tokenize_parser = subparsers.add_parser(
        CLICommand.TOKENIZE.value,
        help="Tokenize text",
        description="Tokenize text and display token IDs",
    )
    _add_tokenize_args(tokenize_parser)

    # Convert command
    convert_parser = subparsers.add_parser(
        CLICommand.CONVERT.value,
        help="Convert model to MLX format",
        description="Convert HuggingFace models to MLX format with optional quantization",
    )
    _add_convert_args(convert_parser)

    # Benchmark command
    benchmark_parser = subparsers.add_parser(
        CLICommand.BENCHMARK.value,
        help="Benchmark model performance",
        description="Run performance benchmarks on a model",
    )
    _add_benchmark_args(benchmark_parser)

    # Models command (model management)
    from mlxllm.entry_points.cli.models import add_models_subparser

    add_models_subparser(subparsers)

    return parser


def _add_generate_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for generate command."""
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--prompt",
        type=str,
        required=True,
        help="Input prompt for generation",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading model",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16", "fp32"],
        help="Quantization type",
    )

    # Generation arguments
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=128,
        help="Maximum tokens to generate (default: 128)",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Sampling temperature (default: 1.0)",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=1.0,
        help="Nucleus sampling threshold (default: 1.0)",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=-1,
        help="Top-k sampling (default: -1, disabled)",
    )
    parser.add_argument(
        "--presence-penalty",
        type=float,
        default=0.0,
        help="Presence penalty (default: 0.0)",
    )
    parser.add_argument(
        "--frequency-penalty",
        type=float,
        default=0.0,
        help="Frequency penalty (default: 0.0)",
    )
    parser.add_argument(
        "--stop",
        type=str,
        action="append",
        help="Stop sequences (can be specified multiple times)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="Random seed for reproducibility",
    )

    # Output arguments
    parser.add_argument(
        "--output-file",
        type=str,
        help="Write output to file instead of stdout",
    )
    parser.add_argument(
        "--stream",
        action="store_true",
        help="Stream output token by token",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def _add_chat_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for chat command."""
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading model",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16", "fp32"],
        help="Quantization type",
    )

    # Chat arguments
    parser.add_argument(
        "--chat-template",
        type=str,
        help="Custom chat template path or name",
    )
    parser.add_argument(
        "--system-prompt",
        type=str,
        help="System prompt for the conversation",
    )

    # Generation arguments
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=128,
        help="Maximum tokens to generate (default: 128)",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=1.0,
        help="Sampling temperature (default: 1.0)",
    )
    parser.add_argument(
        "--top-p",
        type=float,
        default=1.0,
        help="Nucleus sampling threshold (default: 1.0)",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=-1,
        help="Top-k sampling (default: -1, disabled)",
    )
    parser.add_argument(
        "--presence-penalty",
        type=float,
        default=0.0,
        help="Presence penalty (default: 0.0)",
    )
    parser.add_argument(
        "--frequency-penalty",
        type=float,
        default=0.0,
        help="Frequency penalty (default: 0.0)",
    )
    parser.add_argument(
        "--stop",
        type=str,
        action="append",
        help="Stop sequences (can be specified multiple times)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="Random seed for reproducibility",
    )

    # Output arguments
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def _add_embed_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for embed command."""
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Input text for embedding",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading model",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16", "fp32"],
        help="Quantization type",
    )

    # Embedding arguments
    parser.add_argument(
        "--encoding-format",
        type=str,
        default="float",
        choices=["float", "base64"],
        help="Encoding format for embeddings (default: float)",
    )
    parser.add_argument(
        "--dimensions",
        type=int,
        help="Target embedding dimensions (truncate/pad if needed)",
    )

    # Output arguments
    parser.add_argument(
        "--output-file",
        type=str,
        help="Write embeddings to file (JSON format)",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def _add_tokenize_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for tokenize command."""
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--text",
        type=str,
        required=True,
        help="Text to tokenize",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading tokenizer",
    )

    # Tokenization arguments
    parser.add_argument(
        "--no-special-tokens",
        action="store_true",
        help="Don't add special tokens",
    )
    parser.add_argument(
        "--show-text",
        action="store_true",
        help="Show decoded text for each token",
    )
    parser.add_argument(
        "--no-ids",
        action="store_true",
        help="Don't show token IDs",
    )

    # Output arguments
    parser.add_argument(
        "--output-file",
        type=str,
        help="Write tokens to file (JSON format)",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def _add_convert_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for convert command."""
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="HuggingFace model name or path",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        required=True,
        help="Output directory for converted model",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16"],
        help="Quantization type (default: no quantization)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading model",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing output directory",
    )
    parser.add_argument(
        "--upload-to-hf",
        action="store_true",
        help="Upload converted model to HuggingFace Hub",
    )
    parser.add_argument(
        "--hf-repo-id",
        type=str,
        help="HuggingFace repository ID for upload",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def _add_benchmark_args(parser: argparse.ArgumentParser) -> None:
    """Add arguments for benchmark command."""
    # Model arguments
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="Model name or path",
    )
    parser.add_argument(
        "--tokenizer",
        type=str,
        help="Tokenizer name or path (defaults to model path)",
    )
    parser.add_argument(
        "--revision",
        type=str,
        help="Model revision to use",
    )
    parser.add_argument(
        "--trust-remote-code",
        action="store_true",
        help="Trust remote code when loading model",
    )
    parser.add_argument(
        "--quantization",
        type=str,
        choices=["q4_0", "q4_1", "q8_0", "fp16", "fp32"],
        help="Quantization type",
    )

    # Benchmark arguments
    parser.add_argument(
        "--num-prompts",
        type=int,
        default=100,
        help="Number of prompts to benchmark (default: 100)",
    )
    parser.add_argument(
        "--prompt-length",
        type=int,
        default=128,
        help="Length of each prompt in tokens (default: 128)",
    )
    parser.add_argument(
        "--output-length",
        type=int,
        default=128,
        help="Target output length in tokens (default: 128)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=1,
        help="Batch size for inference (default: 1)",
    )

    # Engine arguments
    parser.add_argument(
        "--max-model-len",
        type=int,
        help="Maximum sequence length",
    )
    parser.add_argument(
        "--max-num-seqs",
        type=int,
        default=256,
        help="Maximum number of sequences (default: 256)",
    )
    parser.add_argument(
        "--block-size",
        type=int,
        default=16,
        help="Block size for paged attention (default: 16)",
    )
    parser.add_argument(
        "--gpu-memory-utilization",
        type=float,
        default=0.9,
        help="GPU memory utilization (default: 0.9)",
    )

    # Output arguments
    parser.add_argument(
        "--output-file",
        type=str,
        help="Write benchmark results to file (JSON format)",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="info",
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )


def main(argv: Optional[list[str]] = None) -> int:
    """
    Main CLI entry point.

    Args:
        argv: Command-line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    # Setup environment for multiprocessing
    cli_env_setup()

    # Parse arguments
    parser = create_parser()
    args = parser.parse_args(argv)

    # Setup logging
    log_level = getattr(args, "log_level", "info")
    setup_logging(log_level)

    logger.info(f"MLX-LLM CLI - Command: {args.command}")

    try:
        # Dispatch to appropriate command handler
        if args.command == CLICommand.SERVE.value:
            from mlxllm.entry_points.cli.serve import run_serve

            return run_serve(args)

        elif args.command == CLICommand.GENERATE.value:
            from mlxllm.entry_points.cli.generate import run_generate

            return run_generate(args)

        elif args.command == CLICommand.CHAT.value:
            from mlxllm.entry_points.cli.chat import run_chat

            return run_chat(args)

        elif args.command == CLICommand.EMBED.value:
            from mlxllm.entry_points.cli.embed import run_embed

            return run_embed(args)

        elif args.command == CLICommand.TOKENIZE.value:
            from mlxllm.entry_points.cli.tokenize import run_tokenize

            return run_tokenize(args)

        elif args.command == CLICommand.CONVERT.value:
            from mlxllm.entry_points.cli.convert import run_convert

            return run_convert(args)

        elif args.command == CLICommand.BENCHMARK.value:
            from mlxllm.entry_points.cli.benchmark import run_benchmark

            return run_benchmark(args)

        elif args.command == CLICommand.MODELS.value:
            from mlxllm.entry_points.cli.models import (
                run_models_cache_clear,
                run_models_cache_info,
                run_models_convert,
                run_models_download,
                run_models_info,
                run_models_list,
                run_models_remove,
                run_models_validate,
            )

            # Dispatch to appropriate models subcommand
            if args.models_command == "list":
                return run_models_list(args)
            elif args.models_command == "download":
                return run_models_download(args)
            elif args.models_command == "info":
                return run_models_info(args)
            elif args.models_command == "remove":
                return run_models_remove(args)
            elif args.models_command == "validate":
                return run_models_validate(args)
            elif args.models_command == "convert":
                return run_models_convert(args)
            elif args.models_command == "cache-info":
                return run_models_cache_info(args)
            elif args.models_command == "cache-clear":
                return run_models_cache_clear(args)
            else:
                logger.error(f"Unknown models subcommand: {args.models_command}")
                return 1

        else:
            logger.error(f"Unknown command: {args.command}")
            return 1

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130  # Standard exit code for Ctrl+C

    except Exception as e:
        logger.error(f"Error: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
