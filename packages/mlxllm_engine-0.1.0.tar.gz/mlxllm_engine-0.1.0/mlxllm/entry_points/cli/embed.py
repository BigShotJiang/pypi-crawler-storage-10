# SPDX-License-Identifier: Apache-2.0
"""Embed command implementation for MLX-LLM CLI."""

from __future__ import annotations

import argparse
import asyncio
import base64
import json
import logging
import sys
from pathlib import Path
from typing import Optional

from mlxllm.config import CacheConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine

logger = logging.getLogger(__name__)


async def generate_embedding(
    model: str,
    input_text: str,
    tokenizer: Optional[str] = None,
    quantization: Optional[str] = None,
    max_model_len: Optional[int] = None,
    encoding_format: str = "float",
    dimensions: Optional[int] = None,
) -> dict:
    """
    Generate embeddings for input text.

    Args:
        model: Model name or path.
        input_text: Input text to embed.
        tokenizer: Optional tokenizer path.
        quantization: Optional quantization type.
        max_model_len: Optional maximum model length.
        encoding_format: Encoding format (float or base64).
        dimensions: Target embedding dimensions.

    Returns:
        Dictionary with embedding data.
    """
    # Create configurations
    model_config = ModelConfig(
        model_name=model,
        tokenizer=tokenizer,
        max_model_len=max_model_len,
        task="embed",  # Set task to embedding
    )

    scheduler_config = SchedulerConfig(
        max_num_seqs=1,
    )

    cache_config = CacheConfig(
        block_size=16,
    )

    # Initialize engine
    logger.info(f"Loading model: {model}")
    engine = AsyncLLMEngine(
        model_config=model_config,
        scheduler_config=scheduler_config,
        cache_config=cache_config,
        model_path=model,
        quantization=quantization,
    )

    logger.info("Generating embedding...")

    # Generate embedding
    # Note: This is a simplified implementation
    # The actual embedding generation depends on the model architecture
    try:
        # Use the engine's embedding capability
        embedding = await engine.encode(input_text)

        # Truncate or pad if dimensions specified
        if dimensions is not None and len(embedding) != dimensions:
            if len(embedding) > dimensions:
                embedding = embedding[:dimensions]
            else:
                # Pad with zeros
                embedding = embedding + [0.0] * (dimensions - len(embedding))

        # Format based on encoding_format
        if encoding_format == "base64":
            # Convert to base64
            import numpy as np
            embedding_array = np.array(embedding, dtype=np.float32)
            embedding_bytes = embedding_array.tobytes()
            embedding_encoded = base64.b64encode(embedding_bytes).decode("utf-8")
            embedding_data = embedding_encoded
        else:
            # Return as list of floats
            embedding_data = embedding

        result = {
            "object": "embedding",
            "embedding": embedding_data,
            "model": model,
            "encoding_format": encoding_format,
            "dimensions": len(embedding),
        }

        return result

    except Exception as e:
        logger.error(f"Embedding generation failed: {e}", exc_info=True)
        raise


def run_embed(args: argparse.Namespace) -> int:
    """
    Run the embed command.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    try:
        # Generate embedding
        result = asyncio.run(
            generate_embedding(
                model=args.model,
                input_text=args.input,
                tokenizer=args.tokenizer,
                quantization=args.quantization,
                max_model_len=args.max_model_len,
                encoding_format=args.encoding_format,
                dimensions=args.dimensions,
            )
        )

        # Format output
        output = json.dumps(result, indent=2)

        # Write output
        if args.output_file:
            output_path = Path(args.output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "w") as f:
                f.write(output)
            logger.info(f"Output written to: {output_path}")
        else:
            print(output)

        return 0

    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        return 130

    except Exception as e:
        logger.error(f"Embedding generation failed: {e}", exc_info=True)
        return 1


if __name__ == "__main__":
    sys.exit(run_embed(argparse.Namespace()))
