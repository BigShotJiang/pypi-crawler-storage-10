# SPDX-License-Identifier: Apache-2.0
"""Conversation context management for MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConversationMessage:
    """A single message in a conversation."""

    role: str
    content: str
    name: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None


@dataclass
class ConversationContext:
    """
    Manages multi-turn conversation state.

    Handles message history, context window management, and token tracking.
    """

    messages: list[ConversationMessage] = field(default_factory=list)
    max_context_length: int = 2048
    system_message: str | None = None

    def add_message(
        self,
        role: str,
        content: str,
        name: str | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
        tool_call_id: str | None = None,
    ) -> None:
        """
        Add a message to the conversation.

        Args:
            role: Message role (user, assistant, system, tool).
            content: Message content.
            name: Optional name of the speaker.
            tool_calls: Optional tool calls in the message.
            tool_call_id: Optional tool call ID for tool responses.
        """
        msg = ConversationMessage(
            role=role,
            content=content,
            name=name,
            tool_calls=tool_calls,
            tool_call_id=tool_call_id,
        )
        self.messages.append(msg)

    def get_messages(self) -> list[ConversationMessage]:
        """Get all messages in the conversation."""
        return self.messages

    def get_last_n_messages(self, n: int) -> list[ConversationMessage]:
        """
        Get the last N messages.

        Args:
            n: Number of messages to retrieve.

        Returns:
            Last N messages from the conversation.
        """
        return self.messages[-n:] if n > 0 else []

    def clear(self) -> None:
        """Clear all messages from the conversation."""
        self.messages.clear()

    def to_openai_format(self) -> list[dict[str, Any]]:
        """
        Convert messages to OpenAI chat format.

        Returns:
            List of message dictionaries in OpenAI format.
        """
        openai_messages = []

        # Add system message if present
        if self.system_message:
            openai_messages.append({"role": "system", "content": self.system_message})

        # Convert conversation messages
        for msg in self.messages:
            message_dict: dict[str, Any] = {
                "role": msg.role,
                "content": msg.content,
            }

            if msg.name:
                message_dict["name"] = msg.name

            if msg.tool_calls:
                message_dict["tool_calls"] = msg.tool_calls

            if msg.tool_call_id:
                message_dict["tool_call_id"] = msg.tool_call_id

            openai_messages.append(message_dict)

        return openai_messages

    def from_openai_format(self, messages: list[dict[str, Any]]) -> None:
        """
        Load messages from OpenAI chat format.

        Args:
            messages: List of message dictionaries in OpenAI format.
        """
        self.clear()

        for msg_dict in messages:
            role = msg_dict.get("role", "user")
            content = msg_dict.get("content", "")

            # Extract system message
            if role == "system" and not self.system_message:
                self.system_message = content
                continue

            self.add_message(
                role=role,
                content=content,
                name=msg_dict.get("name"),
                tool_calls=msg_dict.get("tool_calls"),
                tool_call_id=msg_dict.get("tool_call_id"),
            )

    def estimate_token_count(self, tokenizer=None) -> int:
        """
        Estimate total token count for the conversation.

        Args:
            tokenizer: Optional tokenizer for accurate counting.

        Returns:
            Estimated token count.
        """
        if tokenizer:
            # Use actual tokenizer if provided
            total_tokens = 0
            for msg in self.messages:
                total_tokens += len(tokenizer.encode(msg.content))
            return total_tokens
        else:
            # Rough estimate: ~4 characters per token
            total_chars = sum(len(msg.content) for msg in self.messages)
            return total_chars // 4

    def truncate_to_fit(self, max_tokens: int, tokenizer=None) -> None:
        """
        Truncate messages to fit within token limit.

        Removes oldest messages first, preserving system message.

        Args:
            max_tokens: Maximum number of tokens.
            tokenizer: Optional tokenizer for accurate counting.
        """
        while self.estimate_token_count(tokenizer) > max_tokens and len(self.messages) > 1:
            # Remove oldest message (keep at least one)
            self.messages.pop(0)

    def __len__(self) -> int:
        """Return number of messages in the conversation."""
        return len(self.messages)

    def __repr__(self) -> str:
        """String representation of the context."""
        return f"ConversationContext(messages={len(self.messages)}, max_length={self.max_context_length})"
