# SPDX-License-Identifier: Apache-2.0
"""Constants for MLX-LLM entry points."""

# HTTP header size limits for h11 parser
# These prevent memory exhaustion attacks via large headers
H11_MAX_HEADER_COUNT_DEFAULT = 100
H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT = 16 * 1024  # 16 KB
