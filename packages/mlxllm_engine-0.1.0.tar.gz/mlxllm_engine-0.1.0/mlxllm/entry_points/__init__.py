# SPDX-License-Identifier: Apache-2.0
"""Entry points for MLX-LLM."""

from __future__ import annotations

from mlxllm.entry_points.llm import LLM

__all__ = ["LLM"]
