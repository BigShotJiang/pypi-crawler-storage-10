# SPDX-License-Identifier: Apache-2.0
"""High-level LLM interface for MLX-LLM."""

from __future__ import annotations

import logging
from typing import Any, List, Optional, Union

from mlxllm.config import CacheConfig, DeviceConfig, ModelConfig, SchedulerConfig
from mlxllm.engine.llm_engine import LLMEngine
from mlxllm.entry_points.chat_utils import (
    ChatCompletionMessageParam,
    apply_hf_chat_template,
    parse_chat_messages,
    validate_chat_messages,
)
from mlxllm.outputs import RequestOutput
from mlxllm.sampling_params import SamplingParams

logger = logging.getLogger(__name__)


class LLM:
    """
    An LLM for generating texts from given prompts and sampling parameters.

    This class includes a tokenizer, a language model (possibly distributed),
    and GPU memory space allocated for intermediate states (aka KV cache).
    Given a batch of prompts and sampling parameters, this class generates
    texts from the model using intelligent batching and efficient memory
    management.

    This class is intended to be used for offline inference. For online
    serving, use the AsyncLLMEngine class or the API server instead.

    Example:
        ```python
        from mlxllm import LLM, SamplingParams

        # Initialize LLM
        llm = LLM(
            model="mlx-community/Qwen2.5-Coder-7B-Instruct-4bit",
            max_model_len=8192,
        )

        # Generate text
        prompts = ["Hello, how are you?", "What is MLX?"]
        sampling_params = SamplingParams(temperature=0.7, max_tokens=100)

        outputs = llm.generate(prompts, sampling_params)
        for output in outputs:
            print(f"Prompt: {output.prompt}")
            print(f"Generated: {output.outputs[0].text}")
        ```
    """

    def __init__(
        self,
        model: str,
        tokenizer: Optional[str] = None,
        max_model_len: Optional[int] = None,
        max_num_seqs: int = 256,
        gpu_memory_utilization: float = 0.9,
        quantization: Optional[str] = None,
        trust_remote_code: bool = False,
        seed: int = 0,
        **kwargs: Any,
    ) -> None:
        """
        Initialize LLM.

        Args:
            model: Model name or path (HuggingFace or local).
            tokenizer: Tokenizer name or path (defaults to model path).
            max_model_len: Maximum context length.
            max_num_seqs: Maximum number of sequences to batch.
            gpu_memory_utilization: Fraction of GPU memory to use.
            quantization: Quantization method (q4_0, q4_1, q8_0).
            trust_remote_code: Trust remote code from HuggingFace.
            seed: Random seed for sampling.
            **kwargs: Additional configuration arguments.
        """
        self.model_path = model
        self.tokenizer_path = tokenizer or model

        # Create configurations
        self.model_config = ModelConfig(
            model_name=model,
            max_model_len=max_model_len or 2048,
            trust_remote_code=trust_remote_code,
        )

        self.device_config = DeviceConfig.from_auto_detect(
            memory_fraction=gpu_memory_utilization,
        )

        self.cache_config = CacheConfig(
            block_size=16,
        )

        self.scheduler_config = SchedulerConfig(
            max_num_seqs=max_num_seqs,
            max_num_batched_tokens=max_model_len or 2048,
        )

        # Initialize tokenizer
        try:
            from mlxllm.tokenization import Tokenizer
            self.tokenizer = Tokenizer.from_pretrained(self.tokenizer_path)
            logger.info(f"Loaded tokenizer from: {self.tokenizer_path}")
        except Exception as e:
            logger.warning(f"Failed to load tokenizer: {e}")
            self.tokenizer = None

        # Initialize engine
        self.engine = LLMEngine(
            model_config=self.model_config,
            scheduler_config=self.scheduler_config,
            model_path=self.model_path,
            quantization=quantization,
        )

        self.seed = seed
        logger.info(f"Initialized LLM with model: {model}")

    def generate(
        self,
        prompts: Union[str, List[str]],
        sampling_params: Optional[SamplingParams] = None,
    ) -> List[RequestOutput]:
        """
        Generate text for the given prompts.

        Args:
            prompts: Single prompt string or list of prompt strings.
            sampling_params: Sampling parameters for generation.

        Returns:
            List of RequestOutput objects with generated text.

        Example:
            ```python
            outputs = llm.generate(
                ["Hello", "Hi there"],
                SamplingParams(temperature=0.7, max_tokens=100)
            )
            ```
        """
        # Ensure prompts is a list
        if isinstance(prompts, str):
            prompts = [prompts]

        # Use default sampling params if not provided
        if sampling_params is None:
            sampling_params = SamplingParams()

        # Generate for each prompt using sync engine
        outputs = []
        for prompt in prompts:
            output = self.engine.generate(
                prompt=prompt,
                sampling_params=sampling_params,
            )
            outputs.append(output)

        return outputs

    def chat(
        self,
        messages: List[ChatCompletionMessageParam],
        sampling_params: Optional[SamplingParams] = None,
        add_generation_prompt: bool = True,
    ) -> RequestOutput:
        """
        Generate a chat completion.

        Args:
            messages: List of chat messages in OpenAI format.
            sampling_params: Sampling parameters for generation.
            add_generation_prompt: Add generation prompt to the end.

        Returns:
            RequestOutput with generated response.

        Example:
            ```python
            messages = [
                {"role": "user", "content": "Hello!"},
            ]
            output = llm.chat(messages)
            print(output.outputs[0].text)
            ```
        """
        # Validate messages
        validate_chat_messages(messages)

        # Parse messages and extract multi-modal content
        parsed_messages, multimodal_data = parse_chat_messages(
            messages, self.model_config
        )

        # Apply chat template
        if self.tokenizer:
            prompt = apply_hf_chat_template(
                self.tokenizer,
                messages,
                add_generation_prompt=add_generation_prompt,
            )
        else:
            # Fallback: simple format
            prompt = self._simple_chat_format(parsed_messages, add_generation_prompt)

        # Generate
        outputs = self.generate(prompt, sampling_params)
        return outputs[0] if outputs else None

    def encode(
        self,
        prompts: Union[str, List[str]],
    ) -> List[List[float]]:
        """
        Encode text into embeddings.

        Args:
            prompts: Single prompt string or list of prompt strings.

        Returns:
            List of embedding vectors.

        Example:
            ```python
            embeddings = llm.encode(["Hello", "World"])
            print(len(embeddings))  # 2
            print(len(embeddings[0]))  # embedding dimension
            ```
        """
        # Ensure prompts is a list
        if isinstance(prompts, str):
            prompts = [prompts]

        # TODO: Implement embedding generation
        # For now, return placeholder
        logger.warning("Embedding generation not yet fully implemented")

        # Return dummy embeddings for now
        embedding_dim = 768
        return [[0.0] * embedding_dim for _ in prompts]

    def _simple_chat_format(
        self,
        messages: List[dict],
        add_generation_prompt: bool = True,
    ) -> str:
        """
        Simple fallback chat format.

        Args:
            messages: List of parsed messages.
            add_generation_prompt: Add generation prompt.

        Returns:
            Formatted prompt string.
        """
        parts = []

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            if role == "system":
                parts.append(f"System: {content}\n\n")
            elif role == "user":
                parts.append(f"User: {content}\n\n")
            elif role == "assistant":
                parts.append(f"Assistant: {content}\n\n")
            else:
                parts.append(f"{role.capitalize()}: {content}\n\n")

        if add_generation_prompt:
            parts.append("Assistant: ")

        return "".join(parts)

    async def generate_async(
        self,
        prompt: str,
        sampling_params: Optional[SamplingParams] = None,
    ) -> RequestOutput:
        """
        Generate text asynchronously (single prompt).

        Args:
            prompt: Text prompt.
            sampling_params: Sampling parameters.

        Returns:
            RequestOutput with generated text.
        """
        import asyncio

        if sampling_params is None:
            sampling_params = SamplingParams()

        # Run sync engine in thread pool
        output = await asyncio.to_thread(
            self.engine.generate,
            prompt=prompt,
            sampling_params=sampling_params,
        )
        return output

    async def chat_async(
        self,
        messages: List[ChatCompletionMessageParam],
        sampling_params: Optional[SamplingParams] = None,
        add_generation_prompt: bool = True,
    ) -> RequestOutput:
        """
        Generate a chat completion asynchronously.

        Args:
            messages: List of chat messages.
            sampling_params: Sampling parameters.
            add_generation_prompt: Add generation prompt.

        Returns:
            RequestOutput with generated response.
        """
        # Validate and parse messages
        validate_chat_messages(messages)
        parsed_messages, _ = parse_chat_messages(messages, self.model_config)

        # Apply chat template
        if self.tokenizer:
            prompt = apply_hf_chat_template(
                self.tokenizer,
                messages,
                add_generation_prompt=add_generation_prompt,
            )
        else:
            prompt = self._simple_chat_format(parsed_messages, add_generation_prompt)

        # Generate
        return await self.generate_async(prompt, sampling_params)

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        # Cleanup if needed
        pass

    def __repr__(self) -> str:
        """String representation."""
        return f"LLM(model={self.model_path})"
