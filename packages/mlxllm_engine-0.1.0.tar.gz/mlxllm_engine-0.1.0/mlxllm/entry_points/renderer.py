# SPDX-License-Identifier: Apache-2.0
"""Response rendering for MLX-LLM entry points."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class RenderConfig:
    """Configuration for response rendering."""

    include_stop_str_in_output: bool = False
    skip_special_tokens: bool = True
    spaces_between_special_tokens: bool = True


class BaseRenderer(ABC):
    """Abstract base class for response renderers."""

    def __init__(self, config: RenderConfig | None = None) -> None:
        """
        Initialize renderer.

        Args:
            config: Rendering configuration.
        """
        self.config = config or RenderConfig()

    @abstractmethod
    def render(self, output: Any) -> str:
        """
        Render output to string.

        Args:
            output: Output object to render.

        Returns:
            Rendered string.
        """
        pass

    @abstractmethod
    def render_stream(self, output: Any) -> str:
        """
        Render streaming output chunk.

        Args:
            output: Output chunk to render.

        Returns:
            Rendered string chunk.
        """
        pass


class CompletionRenderer(BaseRenderer):
    """Renderer for text completion outputs."""

    def __init__(
        self,
        config: RenderConfig | None = None,
        tokenizer: Any | None = None,
    ) -> None:
        """
        Initialize completion renderer.

        Args:
            config: Rendering configuration.
            tokenizer: Optional tokenizer for decoding.
        """
        super().__init__(config)
        self.tokenizer = tokenizer

    def render(self, output: Any) -> str:
        """
        Render completion output.

        Args:
            output: RequestOutput or CompletionOutput.

        Returns:
            Rendered text.
        """
        # Handle different output types
        if hasattr(output, "outputs"):
            # RequestOutput with multiple completions
            completions = output.outputs
            if completions:
                return self._render_completion(completions[0])
            return ""
        elif hasattr(output, "text"):
            # CompletionOutput
            return self._render_completion(output)
        else:
            # Fallback to string conversion
            return str(output)

    def render_stream(self, output: Any) -> str:
        """
        Render streaming completion chunk.

        Args:
            output: Output chunk with new tokens.

        Returns:
            Newly generated text.
        """
        if hasattr(output, "outputs") and output.outputs:
            completion = output.outputs[0]
            if hasattr(completion, "text"):
                return completion.text
        return ""

    def _render_completion(self, completion: Any) -> str:
        """
        Render a single completion.

        Args:
            completion: CompletionOutput object.

        Returns:
            Rendered text.
        """
        if hasattr(completion, "text"):
            text = completion.text
        else:
            text = str(completion)

        # Apply stop string handling
        if not self.config.include_stop_str_in_output:
            # Remove stop string if present
            if hasattr(completion, "stop_reason") and completion.stop_reason:
                if hasattr(completion, "stop_string") and completion.stop_string:
                    text = text.rstrip(completion.stop_string)

        return text

    def decode_tokens(self, token_ids: list[int]) -> str:
        """
        Decode token IDs to text.

        Args:
            token_ids: List of token IDs.

        Returns:
            Decoded text.
        """
        if self.tokenizer:
            return self.tokenizer.decode(
                token_ids,
                skip_special_tokens=self.config.skip_special_tokens,
            )
        else:
            # Fallback: return token IDs as string
            return f"<tokens: {token_ids}>"


class EmbeddingRenderer(BaseRenderer):
    """Renderer for embedding outputs."""

    def render(self, output: Any) -> str:
        """
        Render embedding output.

        Args:
            output: Embedding output.

        Returns:
            String representation of embeddings.
        """
        if hasattr(output, "outputs") and output.outputs:
            embeddings = output.outputs[0]
            if hasattr(embeddings, "embedding"):
                emb = embeddings.embedding
                if hasattr(emb, "shape"):
                    return f"<embedding: shape={emb.shape}>"
                return f"<embedding: len={len(emb)}>"
        return "<embedding>"

    def render_stream(self, output: Any) -> str:
        """Embeddings don't stream."""
        return self.render(output)


class ClassificationRenderer(BaseRenderer):
    """Renderer for classification outputs."""

    def render(self, output: Any) -> str:
        """
        Render classification output.

        Args:
            output: Classification output.

        Returns:
            String representation of classification.
        """
        if hasattr(output, "outputs") and output.outputs:
            classification = output.outputs[0]
            if hasattr(classification, "label"):
                return f"Label: {classification.label}"
            if hasattr(classification, "probs"):
                probs = classification.probs
                return f"Probabilities: {probs}"
        return "<classification>"

    def render_stream(self, output: Any) -> str:
        """Classifications don't stream."""
        return self.render(output)


def create_renderer(
    task_type: str,
    config: RenderConfig | None = None,
    tokenizer: Any | None = None,
) -> BaseRenderer:
    """
    Create a renderer for the given task type.

    Args:
        task_type: Type of task (generate, embed, classify).
        config: Rendering configuration.
        tokenizer: Optional tokenizer.

    Returns:
        Appropriate renderer instance.

    Raises:
        ValueError: If task type is unknown.
    """
    task_type = task_type.lower()

    if task_type in ("generate", "completion", "chat"):
        return CompletionRenderer(config, tokenizer)
    elif task_type in ("embed", "embedding"):
        return EmbeddingRenderer(config)
    elif task_type in ("classify", "classification"):
        return ClassificationRenderer(config)
    else:
        raise ValueError(f"Unknown task type: {task_type}")
