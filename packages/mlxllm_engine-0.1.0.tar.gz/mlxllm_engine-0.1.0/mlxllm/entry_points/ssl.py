# SPDX-License-Identifier: Apache-2.0
"""SSL certificate refresh utilities for MLX-LLM."""

from __future__ import annotations

import logging
import ssl
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ssl import SSLContext

logger = logging.getLogger(__name__)


class SSLCertRefresher:
    """
    Automatically refreshes SSL certificates.

    Monitors certificate files and reloads them when they change.
    Useful for automatic certificate rotation (e.g., Let's Encrypt).
    """

    def __init__(
        self,
        ssl_context: SSLContext | None,
        key_path: str | Path | None,
        cert_path: str | Path | None,
        ca_path: str | Path | None = None,
        refresh_interval: float = 3600.0,  # 1 hour
    ) -> None:
        """
        Initialize SSL certificate refresher.

        Args:
            ssl_context: SSL context to update.
            key_path: Path to private key file.
            cert_path: Path to certificate file.
            ca_path: Optional path to CA certificate file.
            refresh_interval: Seconds between refresh checks.
        """
        self.ssl_context = ssl_context
        self.key_path = Path(key_path) if key_path else None
        self.cert_path = Path(cert_path) if cert_path else None
        self.ca_path = Path(ca_path) if ca_path else None
        self.refresh_interval = refresh_interval

        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._last_modified: dict[str, float] = {}

        # Track initial modification times
        self._update_modification_times()

        # Start refresh thread
        self.start()

    def _update_modification_times(self) -> None:
        """Update tracked modification times for certificate files."""
        if self.key_path and self.key_path.exists():
            self._last_modified["key"] = self.key_path.stat().st_mtime

        if self.cert_path and self.cert_path.exists():
            self._last_modified["cert"] = self.cert_path.stat().st_mtime

        if self.ca_path and self.ca_path.exists():
            self._last_modified["ca"] = self.ca_path.stat().st_mtime

    def _check_for_changes(self) -> bool:
        """
        Check if any certificate files have changed.

        Returns:
            True if changes detected, False otherwise.
        """
        changed = False

        if self.key_path and self.key_path.exists():
            current_mtime = self.key_path.stat().st_mtime
            if current_mtime != self._last_modified.get("key"):
                logger.info("SSL key file changed, will refresh")
                changed = True

        if self.cert_path and self.cert_path.exists():
            current_mtime = self.cert_path.stat().st_mtime
            if current_mtime != self._last_modified.get("cert"):
                logger.info("SSL certificate file changed, will refresh")
                changed = True

        if self.ca_path and self.ca_path.exists():
            current_mtime = self.ca_path.stat().st_mtime
            if current_mtime != self._last_modified.get("ca"):
                logger.info("SSL CA certificate file changed, will refresh")
                changed = True

        return changed

    def _refresh_certificates(self) -> None:
        """Reload SSL certificates into the context."""
        if not self.ssl_context:
            logger.warning("No SSL context to refresh")
            return

        try:
            # Create new SSL context
            new_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)

            # Load certificate chain
            if self.cert_path and self.key_path:
                new_context.load_cert_chain(
                    certfile=str(self.cert_path),
                    keyfile=str(self.key_path),
                )
                logger.info("Reloaded SSL certificate and key")

            # Load CA certificates
            if self.ca_path:
                new_context.load_verify_locations(cafile=str(self.ca_path))
                logger.info("Reloaded CA certificates")

            # Update context settings
            self.ssl_context.load_cert_chain = new_context.load_cert_chain
            self.ssl_context.load_verify_locations = new_context.load_verify_locations

            # Update modification times
            self._update_modification_times()

            logger.info("SSL certificates refreshed successfully")

        except Exception as e:
            logger.error(f"Failed to refresh SSL certificates: {e}")

    def _refresh_loop(self) -> None:
        """Background thread that periodically checks for certificate changes."""
        logger.info(
            f"SSL certificate refresh thread started "
            f"(interval: {self.refresh_interval}s)"
        )

        while not self._stop_event.is_set():
            # Wait for interval or stop event
            if self._stop_event.wait(timeout=self.refresh_interval):
                break

            # Check for changes
            if self._check_for_changes():
                self._refresh_certificates()

        logger.info("SSL certificate refresh thread stopped")

    def start(self) -> None:
        """Start the certificate refresh background thread."""
        if self._thread is not None and self._thread.is_alive():
            logger.warning("SSL certificate refresher already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._refresh_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the certificate refresh background thread."""
        if self._thread is None or not self._thread.is_alive():
            return

        logger.info("Stopping SSL certificate refresher")
        self._stop_event.set()

        # Wait for thread to finish (with timeout)
        self._thread.join(timeout=5.0)

        if self._thread.is_alive():
            logger.warning("SSL certificate refresh thread did not stop cleanly")
