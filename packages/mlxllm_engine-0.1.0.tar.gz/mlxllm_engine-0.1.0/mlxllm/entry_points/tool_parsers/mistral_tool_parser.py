# SPDX-License-Identifier: Apache-2.0
"""Mistral-style tool parser implementation."""

from __future__ import annotations

import json
import re
from typing import List, Optional, Sequence

from mlxllm.entry_points.tool import Tool, ToolCall
from mlxllm.entry_points.tool_parsers.abstract_tool_parser import (
    ToolParser,
    register_tool_parser,
)


class MistralToolParser(ToolParser):
    """
    Tool parser for Mistral-style function calling format.

    Mistral uses a bracket-based format:
    ```
    [TOOL_CALLS] [{"name": "tool_name", "arguments": {"arg1": "value1"}}]
    ```
    """

    def extract_tool_calls(
        self,
        model_output: str,
        tools: Sequence[Tool],
    ) -> List[ToolCall]:
        """
        Extract tool calls from model output.

        Looks for the [TOOL_CALLS] marker followed by JSON array.

        Args:
            model_output: Raw text output from the model.
            tools: Available tools.

        Returns:
            List of extracted tool calls.
        """
        tool_calls = []

        # Pattern: [TOOL_CALLS] followed by JSON array
        tool_calls_pattern = r'\[TOOL_CALLS\]\s*(\[.*?\])'
        match = re.search(tool_calls_pattern, model_output, re.DOTALL)

        if match:
            calls_json = match.group(1).strip()
            try:
                calls_data = self.parse_json_arguments(calls_json)

                if isinstance(calls_data, list):
                    for idx, call_data in enumerate(calls_data):
                        if isinstance(call_data, dict) and "name" in call_data:
                            tool_call = ToolCall(
                                id=call_data.get("id", f"call_{idx}"),
                                name=call_data["name"],
                                arguments=call_data.get("arguments", {}),
                            )
                            if self.validate_tool_call(tool_call, tools):
                                tool_calls.append(tool_call)
                elif isinstance(calls_data, dict) and "name" in calls_data:
                    # Single tool call
                    tool_call = ToolCall(
                        id=calls_data.get("id", "call_0"),
                        name=calls_data["name"],
                        arguments=calls_data.get("arguments", {}),
                    )
                    if self.validate_tool_call(tool_call, tools):
                        tool_calls.append(tool_call)

            except ValueError:
                pass

        return tool_calls

    def format_tools_for_prompt(
        self,
        tools: Sequence[Tool],
    ) -> str:
        """
        Format tool definitions for inclusion in the prompt.

        Args:
            tools: Available tools.

        Returns:
            Formatted string representation of tools.
        """
        if not tools:
            return ""

        tool_defs = []
        for tool in tools:
            tool_def = {
                "type": "function",
                "function": {
                    "name": tool.name,
                    "description": tool.description,
                },
            }
            if tool.parameters:
                tool_def["function"]["parameters"] = tool.parameters

            tool_defs.append(tool_def)

        tools_json = json.dumps(tool_defs, indent=2)

        prompt = f"""[AVAILABLE_TOOLS] {tools_json} [/AVAILABLE_TOOLS]

To use a tool, respond with:
[TOOL_CALLS] [{{"name": "tool_name", "arguments": {{"arg1": "value1"}}}}]

You can call multiple tools by including multiple objects in the array.
"""
        return prompt

    def format_tool_call_for_prompt(
        self,
        tool_call: ToolCall,
        tool_result: Optional[str] = None,
    ) -> str:
        """
        Format a tool call (and optionally its result) for the prompt.

        Args:
            tool_call: The tool call to format.
            tool_result: Optional result from executing the tool.

        Returns:
            Formatted string representation.
        """
        call_data = {
            "name": tool_call.name,
            "arguments": tool_call.arguments,
        }
        formatted = f"[TOOL_CALLS] [{json.dumps(call_data)}]"

        if tool_result is not None:
            result_data = {
                "name": tool_call.name,
                "content": tool_result,
            }
            formatted += f"\n[TOOL_RESULTS] {json.dumps(result_data)} [/TOOL_RESULTS]"

        return formatted

    def supports_parallel_tool_calls(self) -> bool:
        """Whether this parser supports parallel tool calls."""
        return True

    def supports_streaming_tool_calls(self) -> bool:
        """Whether this parser supports streaming tool calls."""
        return False  # Mistral typically doesn't stream tool calls

    def get_tool_call_prefix(self) -> Optional[str]:
        """Get the prefix that indicates a tool call is starting."""
        return "[TOOL_CALLS]"

    def get_tool_call_suffix(self) -> Optional[str]:
        """Get the suffix that indicates a tool call has ended."""
        return None  # No explicit suffix


# Register the parser
register_tool_parser("mistral", MistralToolParser)
register_tool_parser("mixtral", MistralToolParser)
