# SPDX-License-Identifier: Apache-2.0
"""OpenAI-style tool parser implementation."""

from __future__ import annotations

import json
import re
from typing import List, Optional, Sequence

from mlxllm.entry_points.tool import Tool, ToolCall
from mlxllm.entry_points.tool_parsers.abstract_tool_parser import (
    ToolParser,
    register_tool_parser,
)


class OpenAIToolParser(ToolParser):
    """
    Tool parser for OpenAI-style function calling format.

    OpenAI uses a specific JSON format for tool calls:
    ```
    <function=tool_name>{"arg1": "value1", "arg2": "value2"}</function>
    ```

    Or in some variants:
    ```json
    {
      "name": "tool_name",
      "arguments": {"arg1": "value1"}
    }
    ```
    """

    def extract_tool_calls(
        self,
        model_output: str,
        tools: Sequence[Tool],
    ) -> List[ToolCall]:
        """
        Extract tool calls from model output.

        Looks for patterns like:
        - <function=name>JSON</function>
        - <tool_call>JSON</tool_call>
        - Plain JSON with "name" and "arguments" keys

        Args:
            model_output: Raw text output from the model.
            tools: Available tools.

        Returns:
            List of extracted tool calls.
        """
        tool_calls = []

        # Pattern 1: <function=name>JSON</function>
        function_pattern = r'<function=([^>]+)>(.*?)</function>'
        for match in re.finditer(function_pattern, model_output, re.DOTALL):
            name = match.group(1).strip()
            args_json = match.group(2).strip()

            try:
                arguments = self.parse_json_arguments(args_json)
                tool_call = ToolCall(
                    id=f"call_{len(tool_calls)}",
                    name=name,
                    arguments=arguments,
                )
                if self.validate_tool_call(tool_call, tools):
                    tool_calls.append(tool_call)
            except ValueError:
                continue

        # Pattern 2: <tool_call>JSON</tool_call>
        if not tool_calls:
            tool_call_pattern = r'<tool_call>(.*?)</tool_call>'
            for match in re.finditer(tool_call_pattern, model_output, re.DOTALL):
                call_json = match.group(1).strip()

                try:
                    call_data = self.parse_json_arguments(call_json)
                    if "name" in call_data:
                        tool_call = ToolCall(
                            id=call_data.get("id", f"call_{len(tool_calls)}"),
                            name=call_data["name"],
                            arguments=call_data.get("arguments", {}),
                        )
                        if self.validate_tool_call(tool_call, tools):
                            tool_calls.append(tool_call)
                except ValueError:
                    continue

        # Pattern 3: Plain JSON with structured format
        if not tool_calls:
            json_str = self.extract_json_from_text(model_output)
            if json_str:
                try:
                    data = self.parse_json_arguments(json_str)
                    if isinstance(data, dict) and "name" in data:
                        tool_call = ToolCall(
                            id=data.get("id", f"call_{len(tool_calls)}"),
                            name=data["name"],
                            arguments=data.get("arguments", data.get("parameters", {})),
                        )
                        if self.validate_tool_call(tool_call, tools):
                            tool_calls.append(tool_call)
                    elif isinstance(data, list):
                        # Multiple tool calls
                        for item in data:
                            if isinstance(item, dict) and "name" in item:
                                tool_call = ToolCall(
                                    id=item.get("id", f"call_{len(tool_calls)}"),
                                    name=item["name"],
                                    arguments=item.get("arguments", item.get("parameters", {})),
                                )
                                if self.validate_tool_call(tool_call, tools):
                                    tool_calls.append(tool_call)
                except ValueError:
                    pass

        return tool_calls

    def format_tools_for_prompt(
        self,
        tools: Sequence[Tool],
    ) -> str:
        """
        Format tool definitions for inclusion in the prompt.

        Args:
            tools: Available tools.

        Returns:
            Formatted string representation of tools.
        """
        if not tools:
            return ""

        tool_defs = []
        for tool in tools:
            tool_def = {
                "name": tool.name,
                "description": tool.description,
            }
            if tool.parameters:
                tool_def["parameters"] = tool.parameters

            tool_defs.append(tool_def)

        tools_json = json.dumps(tool_defs, indent=2)

        prompt = f"""You have access to the following functions:

{tools_json}

To use a function, respond with:
<function=function_name>{{"arg1": "value1", "arg2": "value2"}}</function>

You can make multiple function calls by using multiple <function> tags.
"""
        return prompt

    def format_tool_call_for_prompt(
        self,
        tool_call: ToolCall,
        tool_result: Optional[str] = None,
    ) -> str:
        """
        Format a tool call (and optionally its result) for the prompt.

        Args:
            tool_call: The tool call to format.
            tool_result: Optional result from executing the tool.

        Returns:
            Formatted string representation.
        """
        args_json = json.dumps(tool_call.arguments)
        formatted = f"<function={tool_call.name}>{args_json}</function>"

        if tool_result is not None:
            formatted += f"\n<function_result>{tool_result}</function_result>"

        return formatted

    def supports_parallel_tool_calls(self) -> bool:
        """Whether this parser supports parallel tool calls."""
        return True

    def supports_streaming_tool_calls(self) -> bool:
        """Whether this parser supports streaming tool calls."""
        return True

    def get_tool_call_prefix(self) -> Optional[str]:
        """Get the prefix that indicates a tool call is starting."""
        return "<function="

    def get_tool_call_suffix(self) -> Optional[str]:
        """Get the suffix that indicates a tool call has ended."""
        return "</function>"


# Register the parser
register_tool_parser("openai", OpenAIToolParser)
register_tool_parser("gpt", OpenAIToolParser)
register_tool_parser("chatgpt", OpenAIToolParser)
