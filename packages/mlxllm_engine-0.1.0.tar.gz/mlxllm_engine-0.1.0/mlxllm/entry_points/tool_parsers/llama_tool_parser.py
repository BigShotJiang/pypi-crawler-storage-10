# SPDX-License-Identifier: Apache-2.0
"""Llama-style tool parser implementation."""

from __future__ import annotations

import json
import re
from typing import List, Optional, Sequence

from mlxllm.entry_points.tool import Tool, ToolCall
from mlxllm.entry_points.tool_parsers.abstract_tool_parser import (
    ToolParser,
    register_tool_parser,
)


class LlamaToolParser(ToolParser):
    """
    Tool parser for Llama-style function calling format.

    Llama models (especially Llama 3.x) use a Python function call format:
    ```
    <|python_tag|>tool_name(arg1="value1", arg2="value2")
    ```

    Or in some cases:
    ```
    {'name': 'tool_name', 'parameters': {'arg1': 'value1'}}
    ```
    """

    def extract_tool_calls(
        self,
        model_output: str,
        tools: Sequence[Tool],
    ) -> List[ToolCall]:
        """
        Extract tool calls from model output.

        Looks for Python-style function calls or JSON format.

        Args:
            model_output: Raw text output from the model.
            tools: Available tools.

        Returns:
            List of extracted tool calls.
        """
        tool_calls = []

        # Pattern 1: Python-style function calls
        # Example: tool_name(arg1="value1", arg2=123)
        python_pattern = r'(\w+)\s*\((.*?)\)'
        for match in re.finditer(python_pattern, model_output):
            name = match.group(1).strip()
            args_str = match.group(2).strip()

            # Check if this is a valid tool name
            tool_names = [tool.name for tool in tools]
            if name not in tool_names:
                continue

            try:
                # Parse Python-style arguments
                arguments = self._parse_python_arguments(args_str)
                tool_call = ToolCall(
                    id=f"call_{len(tool_calls)}",
                    name=name,
                    arguments=arguments,
                )
                if self.validate_tool_call(tool_call, tools):
                    tool_calls.append(tool_call)
            except (ValueError, SyntaxError):
                continue

        # Pattern 2: JSON format with 'name' and 'parameters'
        if not tool_calls:
            json_str = self.extract_json_from_text(model_output)
            if json_str:
                try:
                    data = self.parse_json_arguments(json_str)
                    if isinstance(data, dict) and "name" in data:
                        tool_call = ToolCall(
                            id=data.get("id", f"call_{len(tool_calls)}"),
                            name=data["name"],
                            arguments=data.get("parameters", data.get("arguments", {})),
                        )
                        if self.validate_tool_call(tool_call, tools):
                            tool_calls.append(tool_call)
                    elif isinstance(data, list):
                        for item in data:
                            if isinstance(item, dict) and "name" in item:
                                tool_call = ToolCall(
                                    id=item.get("id", f"call_{len(tool_calls)}"),
                                    name=item["name"],
                                    arguments=item.get("parameters", item.get("arguments", {})),
                                )
                                if self.validate_tool_call(tool_call, tools):
                                    tool_calls.append(tool_call)
                except ValueError:
                    pass

        return tool_calls

    def _parse_python_arguments(self, args_str: str) -> dict:
        """
        Parse Python-style keyword arguments into a dictionary.

        Args:
            args_str: Argument string like 'arg1="value1", arg2=123'.

        Returns:
            Dictionary of parsed arguments.

        Raises:
            ValueError: If parsing fails.
        """
        if not args_str.strip():
            return {}

        # Use eval with restricted namespace for safety
        # This is a simple parser - in production, consider using ast.parse
        try:
            # Convert to dictionary format
            dict_str = "{" + args_str + "}"
            # Replace = with : for JSON-like format
            dict_str = re.sub(r'(\w+)\s*=', r'"\1":', dict_str)
            result = json.loads(dict_str)
            return result
        except (json.JSONDecodeError, SyntaxError):
            # Fallback: simple regex parsing
            result = {}
            arg_pattern = r'(\w+)\s*=\s*(["\'])(.*?)\2|(\w+)\s*=\s*(\d+\.?\d*)'
            for match in re.finditer(arg_pattern, args_str):
                if match.group(1):  # String argument
                    key = match.group(1)
                    value = match.group(3)
                    result[key] = value
                elif match.group(4):  # Numeric argument
                    key = match.group(4)
                    value = match.group(5)
                    try:
                        result[key] = int(value) if '.' not in value else float(value)
                    except ValueError:
                        result[key] = value

            return result

    def format_tools_for_prompt(
        self,
        tools: Sequence[Tool],
    ) -> str:
        """
        Format tool definitions for inclusion in the prompt.

        Args:
            tools: Available tools.

        Returns:
            Formatted string representation of tools.
        """
        if not tools:
            return ""

        tool_descriptions = []
        for tool in tools:
            # Format parameters
            params_str = ""
            if tool.parameters and "properties" in tool.parameters:
                params = []
                for param_name, param_info in tool.parameters["properties"].items():
                    param_type = param_info.get("type", "any")
                    param_desc = param_info.get("description", "")
                    params.append(f"{param_name}: {param_type} - {param_desc}")
                params_str = "\n  ".join(params)

            tool_desc = f"""def {tool.name}(...):
    \"\"\"
    {tool.description}

    Parameters:
    {params_str}
    \"\"\"
    pass
"""
            tool_descriptions.append(tool_desc)

        all_tools = "\n\n".join(tool_descriptions)

        prompt = f"""You have access to the following functions:

{all_tools}

To use a function, call it like this:
function_name(arg1="value1", arg2=123)

You can call multiple functions sequentially.
"""
        return prompt

    def format_tool_call_for_prompt(
        self,
        tool_call: ToolCall,
        tool_result: Optional[str] = None,
    ) -> str:
        """
        Format a tool call (and optionally its result) for the prompt.

        Args:
            tool_call: The tool call to format.
            tool_result: Optional result from executing the tool.

        Returns:
            Formatted string representation.
        """
        # Format arguments as Python kwargs
        args_parts = []
        for key, value in tool_call.arguments.items():
            if isinstance(value, str):
                args_parts.append(f'{key}="{value}"')
            else:
                args_parts.append(f'{key}={value}')

        args_str = ", ".join(args_parts)
        formatted = f"{tool_call.name}({args_str})"

        if tool_result is not None:
            formatted += f"\n# Result: {tool_result}"

        return formatted

    def supports_parallel_tool_calls(self) -> bool:
        """Whether this parser supports parallel tool calls."""
        return False  # Llama typically executes sequentially

    def supports_streaming_tool_calls(self) -> bool:
        """Whether this parser supports streaming tool calls."""
        return False

    def get_tool_call_prefix(self) -> Optional[str]:
        """Get the prefix that indicates a tool call is starting."""
        return None  # No specific prefix

    def get_tool_call_suffix(self) -> Optional[str]:
        """Get the suffix that indicates a tool call has ended."""
        return None  # No specific suffix


# Register the parser
register_tool_parser("llama", LlamaToolParser)
register_tool_parser("llama3", LlamaToolParser)
register_tool_parser("llama-3", LlamaToolParser)
