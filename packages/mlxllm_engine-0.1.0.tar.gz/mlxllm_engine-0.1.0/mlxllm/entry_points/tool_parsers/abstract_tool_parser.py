# SPDX-License-Identifier: Apache-2.0
"""Abstract base class for tool parsers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Sequence

from mlxllm.entry_points.tool import Tool, ToolCall


class ToolParser(ABC):
    """
    Abstract base class for parsing and formatting tool/function calls.

    Different model families have different formats for tool calling.
    This class provides an interface that must be implemented for each format.
    """

    @abstractmethod
    def extract_tool_calls(
        self,
        model_output: str,
        tools: Sequence[Tool],
    ) -> List[ToolCall]:
        """
        Extract tool calls from model output.

        Args:
            model_output: Raw text output from the model.
            tools: Available tools.

        Returns:
            List of extracted tool calls.
        """
        pass

    @abstractmethod
    def format_tools_for_prompt(
        self,
        tools: Sequence[Tool],
    ) -> str:
        """
        Format tool definitions for inclusion in the prompt.

        Args:
            tools: Available tools.

        Returns:
            Formatted string representation of tools.
        """
        pass

    @abstractmethod
    def format_tool_call_for_prompt(
        self,
        tool_call: ToolCall,
        tool_result: Optional[str] = None,
    ) -> str:
        """
        Format a tool call (and optionally its result) for the prompt.

        Args:
            tool_call: The tool call to format.
            tool_result: Optional result from executing the tool.

        Returns:
            Formatted string representation.
        """
        pass

    def supports_parallel_tool_calls(self) -> bool:
        """
        Whether this parser supports parallel tool calls.

        Returns:
            True if parallel tool calls are supported.
        """
        return False

    def supports_streaming_tool_calls(self) -> bool:
        """
        Whether this parser supports streaming tool calls.

        Returns:
            True if streaming tool calls are supported.
        """
        return False

    def get_tool_call_prefix(self) -> Optional[str]:
        """
        Get the prefix that indicates a tool call is starting.

        Returns:
            Prefix string or None if no specific prefix.
        """
        return None

    def get_tool_call_suffix(self) -> Optional[str]:
        """
        Get the suffix that indicates a tool call has ended.

        Returns:
            Suffix string or None if no specific suffix.
        """
        return None

    def validate_tool_call(
        self,
        tool_call: ToolCall,
        tools: Sequence[Tool],
    ) -> bool:
        """
        Validate that a tool call is well-formed and references a valid tool.

        Args:
            tool_call: The tool call to validate.
            tools: Available tools.

        Returns:
            True if valid, False otherwise.
        """
        # Check if tool name exists
        tool_names = [tool.name for tool in tools]
        if tool_call.name not in tool_names:
            return False

        # Get the tool definition
        tool = next((t for t in tools if t.name == tool_call.name), None)
        if not tool:
            return False

        # Validate required parameters are present
        if tool.parameters:
            required_params = tool.parameters.get("required", [])
            provided_params = set(tool_call.arguments.keys())

            for required in required_params:
                if required not in provided_params:
                    return False

        return True

    def parse_json_arguments(self, json_str: str) -> Dict:
        """
        Parse JSON string into dictionary of arguments.

        Args:
            json_str: JSON string to parse.

        Returns:
            Dictionary of parsed arguments.

        Raises:
            ValueError: If JSON is invalid.
        """
        import json

        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON: {e}")

    def extract_json_from_text(self, text: str) -> Optional[str]:
        """
        Extract JSON object or array from text.

        This looks for JSON-like structures enclosed in braces or brackets.

        Args:
            text: Text potentially containing JSON.

        Returns:
            Extracted JSON string or None if not found.
        """
        import re

        # Try to find JSON object
        obj_match = re.search(r'\{[^{}]*\}', text)
        if obj_match:
            return obj_match.group(0)

        # Try to find JSON array
        arr_match = re.search(r'\[[^\[\]]*\]', text)
        if arr_match:
            return arr_match.group(0)

        return None


class ToolParserRegistry:
    """
    Registry for tool parsers.

    Allows registering and retrieving tool parsers by name or model family.
    """

    def __init__(self):
        """Initialize the registry."""
        self._parsers: Dict[str, type[ToolParser]] = {}

    def register(
        self,
        name: str,
        parser_class: type[ToolParser],
    ) -> None:
        """
        Register a tool parser.

        Args:
            name: Name or model family (e.g., "openai", "mistral", "llama").
            parser_class: Parser class to register.
        """
        self._parsers[name] = parser_class

    def get(
        self,
        name: str,
    ) -> Optional[type[ToolParser]]:
        """
        Get a tool parser class by name.

        Args:
            name: Name or model family.

        Returns:
            Parser class or None if not found.
        """
        return self._parsers.get(name)

    def list_parsers(self) -> List[str]:
        """
        List all registered parser names.

        Returns:
            List of parser names.
        """
        return list(self._parsers.keys())


# Global registry instance
_registry = ToolParserRegistry()


def register_tool_parser(name: str, parser_class: type[ToolParser]) -> None:
    """
    Register a tool parser in the global registry.

    Args:
        name: Name or model family.
        parser_class: Parser class to register.
    """
    _registry.register(name, parser_class)


def get_tool_parser(name: str) -> Optional[type[ToolParser]]:
    """
    Get a tool parser class from the global registry.

    Args:
        name: Name or model family.

    Returns:
        Parser class or None if not found.
    """
    return _registry.get(name)


def list_tool_parsers() -> List[str]:
    """
    List all registered tool parser names.

    Returns:
        List of parser names.
    """
    return _registry.list_parsers()
