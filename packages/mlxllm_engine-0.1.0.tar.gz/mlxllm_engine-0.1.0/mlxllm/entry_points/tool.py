# SPDX-License-Identifier: Apache-2.0
"""Tool definitions and parsing for MLX-LLM."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


@dataclass
class ToolParameter:
    """Tool parameter definition."""

    name: str
    type: str
    description: str | None = None
    required: bool = False
    enum: List[str] | None = None
    default: Any = None


@dataclass
class Tool:
    """Tool definition."""

    name: str
    description: str
    parameters: List[ToolParameter]

    def to_openai_format(self) -> Dict[str, Any]:
        """
        Convert to OpenAI function calling format.

        Returns:
            Tool definition in OpenAI format.
        """
        properties = {}
        required = []

        for param in self.parameters:
            param_def: Dict[str, Any] = {
                "type": param.type,
            }

            if param.description:
                param_def["description"] = param.description

            if param.enum:
                param_def["enum"] = param.enum

            if param.default is not None:
                param_def["default"] = param.default

            properties[param.name] = param_def

            if param.required:
                required.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        }

    @classmethod
    def from_openai_format(cls, tool_def: Dict[str, Any]) -> Tool:
        """
        Create Tool from OpenAI function calling format.

        Args:
            tool_def: Tool definition in OpenAI format.

        Returns:
            Tool instance.
        """
        function = tool_def.get("function", {})
        name = function.get("name", "")
        description = function.get("description", "")

        parameters = []
        params_def = function.get("parameters", {})
        properties = params_def.get("properties", {})
        required_params = set(params_def.get("required", []))

        for param_name, param_info in properties.items():
            parameters.append(
                ToolParameter(
                    name=param_name,
                    type=param_info.get("type", "string"),
                    description=param_info.get("description"),
                    required=param_name in required_params,
                    enum=param_info.get("enum"),
                    default=param_info.get("default"),
                )
            )

        return cls(
            name=name,
            description=description,
            parameters=parameters,
        )


@dataclass
class ToolCall:
    """Tool call instance."""

    id: str
    name: str
    arguments: Dict[str, Any]

    def to_openai_format(self) -> Dict[str, Any]:
        """
        Convert to OpenAI tool call format.

        Returns:
            Tool call in OpenAI format.
        """
        return {
            "id": self.id,
            "type": "function",
            "function": {
                "name": self.name,
                "arguments": json.dumps(self.arguments),
            },
        }

    @classmethod
    def from_openai_format(cls, tool_call: Dict[str, Any]) -> ToolCall:
        """
        Create ToolCall from OpenAI format.

        Args:
            tool_call: Tool call in OpenAI format.

        Returns:
            ToolCall instance.
        """
        function = tool_call.get("function", {})
        arguments_str = function.get("arguments", "{}")

        try:
            arguments = json.loads(arguments_str)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse tool arguments: {arguments_str}")
            arguments = {}

        return cls(
            id=tool_call.get("id", ""),
            name=function.get("name", ""),
            arguments=arguments,
        )


def parse_tool_calls(message: Dict[str, Any]) -> List[ToolCall]:
    """
    Parse tool calls from a message.

    Args:
        message: Message with tool calls.

    Returns:
        List of ToolCall instances.
    """
    tool_calls_data = message.get("tool_calls", [])
    if not tool_calls_data:
        return []

    tool_calls = []
    for tc in tool_calls_data:
        try:
            tool_calls.append(ToolCall.from_openai_format(tc))
        except Exception as e:
            logger.warning(f"Failed to parse tool call: {e}")

    return tool_calls


def format_tool_response(
    tool_call_id: str,
    result: Any,
) -> Dict[str, Any]:
    """
    Format a tool result as a message.

    Args:
        tool_call_id: ID of the tool call.
        result: Tool execution result.

    Returns:
        Message dictionary with tool response.
    """
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": json.dumps(result) if not isinstance(result, str) else result,
    }
