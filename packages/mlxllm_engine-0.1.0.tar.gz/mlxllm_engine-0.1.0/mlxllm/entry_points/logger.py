# SPDX-License-Identifier: Apache-2.0
"""Request logging for MLX-LLM entry points."""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mlxllm.outputs import RequestOutput

logger = logging.getLogger(__name__)


class RequestLogger:
    """Logs request timing, token usage, and errors."""

    def __init__(self, enable_debug: bool = False) -> None:
        """
        Initialize request logger.

        Args:
            enable_debug: Enable debug-level logging.
        """
        self.enable_debug = enable_debug
        self.requests: dict[str, dict[str, Any]] = {}

    def log_request_start(
        self,
        request_id: str,
        prompt: str | None = None,
        prompt_token_ids: list[int] | None = None,
    ) -> None:
        """
        Log request start.

        Args:
            request_id: Unique request identifier.
            prompt: Text prompt (optional).
            prompt_token_ids: Token IDs (optional).
        """
        start_time = time.time()

        self.requests[request_id] = {
            "start_time": start_time,
            "prompt": prompt,
            "prompt_length": len(prompt_token_ids) if prompt_token_ids else None,
        }

        if self.enable_debug:
            logger.debug(f"Request {request_id} started at {start_time:.3f}")

    def log_request_end(
        self,
        request_id: str,
        output: RequestOutput | None = None,
        error: Exception | None = None,
    ) -> None:
        """
        Log request completion.

        Args:
            request_id: Unique request identifier.
            output: Request output (if successful).
            error: Exception (if failed).
        """
        if request_id not in self.requests:
            logger.warning(f"Request {request_id} not found in logger")
            return

        end_time = time.time()
        req_data = self.requests[request_id]
        duration = end_time - req_data["start_time"]

        if error:
            logger.error(
                f"Request {request_id} failed after {duration:.3f}s: {error}"
            )
        elif output:
            prompt_tokens = req_data.get("prompt_length", 0)
            completion_tokens = sum(
                len(comp.token_ids) for comp in output.outputs
            )
            total_tokens = prompt_tokens + completion_tokens

            logger.info(
                f"Request {request_id} completed in {duration:.3f}s: "
                f"{prompt_tokens} prompt + {completion_tokens} completion "
                f"= {total_tokens} tokens"
            )

            if self.enable_debug:
                logger.debug(f"Request {request_id} output: {output}")
        else:
            logger.info(f"Request {request_id} completed in {duration:.3f}s")

        # Clean up
        del self.requests[request_id]

    def get_active_requests(self) -> list[str]:
        """Get list of currently active request IDs."""
        return list(self.requests.keys())

    def clear(self) -> None:
        """Clear all logged requests."""
        self.requests.clear()
