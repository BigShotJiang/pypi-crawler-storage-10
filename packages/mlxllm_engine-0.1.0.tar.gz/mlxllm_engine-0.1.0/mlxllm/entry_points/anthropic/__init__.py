# SPDX-License-Identifier: Apache-2.0
"""Anthropic API compatibility layer for MLX-LLM."""

from mlxllm.entry_points.anthropic.api_server import (
    create_anthropic_app,
    run_anthropic_server,
)
from mlxllm.entry_points.anthropic.protocol import (
    AnthropicCompletionRequest,
    AnthropicCompletionResponse,
    AnthropicErrorResponse,
    AnthropicMessagesRequest,
    AnthropicMessagesResponse,
    AnthropicStreamEvent,
    AnthropicUsage,
    ContentBlock,
    Message,
    Tool,
    anthropic_to_openai_message,
    openai_to_anthropic_message,
)
from mlxllm.entry_points.anthropic.serving_messages import AnthropicServingMessages

__all__ = [
    "create_anthropic_app",
    "run_anthropic_server",
    "AnthropicMessagesRequest",
    "AnthropicMessagesResponse",
    "AnthropicCompletionRequest",
    "AnthropicCompletionResponse",
    "AnthropicStreamEvent",
    "AnthropicErrorResponse",
    "AnthropicUsage",
    "Message",
    "ContentBlock",
    "Tool",
    "AnthropicServingMessages",
    "anthropic_to_openai_message",
    "openai_to_anthropic_message",
]
