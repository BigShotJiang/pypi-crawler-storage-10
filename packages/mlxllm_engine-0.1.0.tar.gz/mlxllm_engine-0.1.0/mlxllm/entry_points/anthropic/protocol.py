# SPDX-License-Identifier: Apache-2.0
"""Anthropic API protocol models."""

from __future__ import annotations

from typing import List, Literal, Optional, Union

from pydantic import BaseModel, Field


class AnthropicUsage(BaseModel):
    """Token usage information."""

    input_tokens: int
    output_tokens: int


class ContentBlock(BaseModel):
    """Content block in a message."""

    type: Literal["text", "image", "tool_use", "tool_result"]
    text: Optional[str] = None
    source: Optional[dict] = None  # For image content
    id: Optional[str] = None  # For tool_use
    name: Optional[str] = None  # For tool_use
    input: Optional[dict] = None  # For tool_use
    tool_use_id: Optional[str] = None  # For tool_result
    content: Optional[Union[str, List[dict]]] = None  # For tool_result
    is_error: Optional[bool] = None  # For tool_result


class Message(BaseModel):
    """A message in the conversation."""

    role: Literal["user", "assistant"]
    content: Union[str, List[ContentBlock]]


class Tool(BaseModel):
    """Tool definition."""

    name: str
    description: str
    input_schema: dict


class AnthropicMessagesRequest(BaseModel):
    """Anthropic Messages API request."""

    model: str
    messages: List[Message]
    system: Optional[str] = None
    max_tokens: int = Field(default=1024, ge=1)
    temperature: Optional[float] = Field(default=1.0, ge=0.0, le=2.0)
    top_p: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    top_k: Optional[int] = Field(default=None, ge=0)
    stop_sequences: Optional[List[str]] = None
    stream: bool = False
    metadata: Optional[dict] = None
    tools: Optional[List[Tool]] = None
    tool_choice: Optional[Union[str, dict]] = None


class AnthropicMessagesResponse(BaseModel):
    """Anthropic Messages API response."""

    id: str
    type: Literal["message"] = "message"
    role: Literal["assistant"] = "assistant"
    content: List[ContentBlock]
    model: str
    stop_reason: Optional[Literal["end_turn", "max_tokens", "stop_sequence", "tool_use"]] = None
    stop_sequence: Optional[str] = None
    usage: AnthropicUsage


class AnthropicStreamEvent(BaseModel):
    """Anthropic streaming event."""

    type: Literal[
        "message_start",
        "message_delta",
        "message_stop",
        "content_block_start",
        "content_block_delta",
        "content_block_stop",
        "ping",
    ]
    message: Optional[AnthropicMessagesResponse] = None
    delta: Optional[dict] = None
    index: Optional[int] = None
    content_block: Optional[ContentBlock] = None
    usage: Optional[AnthropicUsage] = None


class AnthropicErrorResponse(BaseModel):
    """Anthropic error response."""

    type: Literal["error"] = "error"
    error: dict


# Request models for other endpoints
class AnthropicCompletionRequest(BaseModel):
    """Legacy Anthropic Text Completion API request."""

    model: str
    prompt: str
    max_tokens_to_sample: int = Field(default=1024, ge=1)
    temperature: Optional[float] = Field(default=1.0, ge=0.0, le=2.0)
    top_p: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    top_k: Optional[int] = Field(default=None, ge=0)
    stop_sequences: Optional[List[str]] = None
    stream: bool = False
    metadata: Optional[dict] = None


class AnthropicCompletionResponse(BaseModel):
    """Legacy Anthropic Text Completion API response."""

    type: Literal["completion"] = "completion"
    id: str
    completion: str
    stop_reason: Optional[str] = None
    model: str
    usage: AnthropicUsage


# Helper models for conversion
class ConversationContext(BaseModel):
    """Internal conversation context for tracking state."""

    messages: List[Message]
    system: Optional[str] = None
    metadata: Optional[dict] = None


def openai_to_anthropic_message(
    role: str,
    content: str,
    tool_calls: Optional[List[dict]] = None,
) -> Message:
    """
    Convert OpenAI message format to Anthropic format.

    Args:
        role: Message role (user, assistant, system).
        content: Message content.
        tool_calls: Tool calls if any.

    Returns:
        Anthropic Message object.
    """
    # Map roles
    anthropic_role = "assistant" if role == "assistant" else "user"

    # Handle content
    if tool_calls:
        # Convert tool calls to content blocks
        blocks: List[ContentBlock] = []

        # Add text content if present
        if content:
            blocks.append(ContentBlock(type="text", text=content))

        # Add tool use blocks
        for tool_call in tool_calls:
            blocks.append(
                ContentBlock(
                    type="tool_use",
                    id=tool_call.get("id"),
                    name=tool_call.get("function", {}).get("name"),
                    input=tool_call.get("function", {}).get("arguments", {}),
                )
            )

        return Message(role=anthropic_role, content=blocks)
    else:
        return Message(role=anthropic_role, content=content)


def anthropic_to_openai_message(message: Message) -> dict:
    """
    Convert Anthropic message format to OpenAI format.

    Args:
        message: Anthropic Message object.

    Returns:
        OpenAI message dictionary.
    """
    result = {"role": message.role, "content": ""}

    if isinstance(message.content, str):
        result["content"] = message.content
    else:
        # Handle content blocks
        text_parts = []
        tool_calls = []

        for block in message.content:
            if block.type == "text" and block.text:
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append(
                    {
                        "id": block.id,
                        "type": "function",
                        "function": {
                            "name": block.name,
                            "arguments": block.input or {},
                        },
                    }
                )

        result["content"] = " ".join(text_parts)

        if tool_calls:
            result["tool_calls"] = tool_calls

    return result
