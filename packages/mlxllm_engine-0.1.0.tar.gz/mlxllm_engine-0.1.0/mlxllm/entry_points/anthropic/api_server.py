# SPDX-License-Identifier: Apache-2.0
"""Anthropic-compatible API server implementation."""

from __future__ import annotations

import uuid
from typing import List

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse

from mlxllm.config import ModelConfig
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.engine.protocol import EngineClient
from mlxllm.entry_points.anthropic.protocol import (
    AnthropicCompletionRequest,
    AnthropicErrorResponse,
    AnthropicMessagesRequest,
)
from mlxllm.entry_points.anthropic.serving_messages import AnthropicServingMessages


def create_anthropic_app(
    engine_client: EngineClient,
    model_config: ModelConfig,
    served_model_names: List[str],
    *,
    enable_cors: bool = False,
    allowed_origins: List[str] = None,
    allowed_methods: List[str] = None,
    allowed_headers: List[str] = None,
) -> FastAPI:
    """
    Create Anthropic-compatible API server.

    Args:
        engine_client: Engine client for inference.
        model_config: Model configuration.
        served_model_names: List of model names to serve.
        enable_cors: Whether to enable CORS.
        allowed_origins: Allowed CORS origins.
        allowed_methods: Allowed CORS methods.
        allowed_headers: Allowed CORS headers.

    Returns:
        FastAPI application instance.
    """
    app = FastAPI(
        title="MLX-LLM Anthropic API",
        description="Anthropic-compatible API server powered by MLX-LLM",
        version="0.1.0",
    )

    # Add CORS middleware
    if enable_cors:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=allowed_origins or ["*"],
            allow_credentials=True,
            allow_methods=allowed_methods or ["*"],
            allow_headers=allowed_headers or ["*"],
        )

    # Initialize serving handlers
    messages_handler = AnthropicServingMessages(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
    )

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "MLX-LLM Anthropic API",
            "version": "0.1.0",
            "endpoints": [
                "/v1/messages",
                "/v1/complete",
            ],
        }

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "ok"}

    @app.post("/v1/messages")
    async def create_messages(request: Request):
        """
        Create a message completion (Anthropic Messages API).

        This is the primary endpoint for chat-style interactions.
        """
        try:
            # Parse request
            body = await request.json()
            messages_request = AnthropicMessagesRequest(**body)

            # Generate request ID
            request_id = f"msg_{uuid.uuid4().hex}"

            # Handle streaming
            if messages_request.stream:
                return StreamingResponse(
                    messages_handler.create_messages_stream(
                        request=messages_request,
                        request_id=request_id,
                    ),
                    media_type="text/event-stream",
                )

            # Non-streaming response
            response = await messages_handler.create_messages(
                request=messages_request,
                request_id=request_id,
            )

            if isinstance(response, AnthropicErrorResponse):
                return JSONResponse(
                    status_code=400,
                    content=response.model_dump(),
                )

            return JSONResponse(content=response.model_dump())

        except Exception as e:
            error_response = AnthropicErrorResponse(
                error={
                    "type": "invalid_request_error",
                    "message": f"Invalid request: {str(e)}",
                }
            )
            return JSONResponse(
                status_code=400,
                content=error_response.model_dump(),
            )

    @app.post("/v1/complete")
    async def create_completion(request: Request):
        """
        Create a text completion (Legacy Anthropic Completion API).

        This endpoint is for backward compatibility with the older
        text completion API.
        """
        try:
            # Parse request
            body = await request.json()
            _ = AnthropicCompletionRequest(**body)  # Validate request format

            # TODO: Implement legacy completion endpoint
            # For now, return error
            error_response = AnthropicErrorResponse(
                error={
                    "type": "not_implemented_error",
                    "message": "Legacy completion API not yet implemented. Please use /v1/messages instead.",
                }
            )
            return JSONResponse(
                status_code=501,
                content=error_response.model_dump(),
            )

        except Exception as e:
            error_response = AnthropicErrorResponse(
                error={
                    "type": "invalid_request_error",
                    "message": f"Invalid request: {str(e)}",
                }
            )
            return JSONResponse(
                status_code=400,
                content=error_response.model_dump(),
            )

    return app


async def run_anthropic_server(
    model: str,
    host: str = "0.0.0.0",
    port: int = 8000,
    **kwargs,
) -> None:
    """
    Run Anthropic-compatible API server.

    Args:
        model: Model name or path.
        host: Server host.
        port: Server port.
        **kwargs: Additional configuration options.
    """
    from mlxllm.entry_points.launcher import serve_http

    # Create model configuration
    model_config = ModelConfig(
        model_name=model,
        tokenizer=kwargs.get("tokenizer"),
        revision=kwargs.get("revision"),
        trust_remote_code=kwargs.get("trust_remote_code", False),
        max_model_len=kwargs.get("max_model_len"),
    )

    # Initialize engine
    engine_client = AsyncLLMEngine(
        model_config=model_config,
        model_path=model,
        quantization=kwargs.get("quantization"),
    )

    # Parse served model names
    served_model_names = kwargs.get("served_model_names") or [model.split("/")[-1]]

    # Create FastAPI app
    app = create_anthropic_app(
        engine_client=engine_client,
        model_config=model_config,
        served_model_names=served_model_names,
        enable_cors=kwargs.get("enable_cors", False),
        allowed_origins=kwargs.get("allowed_origins"),
        allowed_methods=kwargs.get("allowed_methods"),
        allowed_headers=kwargs.get("allowed_headers"),
    )

    # Serve HTTP
    await serve_http(
        app=app,
        host=host,
        port=port,
        log_level=kwargs.get("log_level", "info"),
        ssl_keyfile=kwargs.get("ssl_keyfile"),
        ssl_certfile=kwargs.get("ssl_certfile"),
        ssl_ca_certs=kwargs.get("ssl_ca_certs"),
        enable_ssl_refresh=kwargs.get("enable_ssl_refresh", False),
        watchdog_enabled=kwargs.get("watchdog_enabled", True),
    )
