# SPDX-License-Identifier: Apache-2.0
"""Anthropic Messages API serving implementation."""

from __future__ import annotations

from typing import AsyncIterator, List

from mlxllm.engine.protocol import EngineClient
from mlxllm.entry_points.anthropic.protocol import (
    AnthropicErrorResponse,
    AnthropicMessagesRequest,
    AnthropicMessagesResponse,
    AnthropicStreamEvent,
    AnthropicUsage,
    ContentBlock,
    anthropic_to_openai_message,
)
from mlxllm.entry_points.chat_utils import parse_chat_messages
from mlxllm.sampling_params import SamplingParams


class AnthropicServingMessages:
    """
    Anthropic Messages API serving handler.

    Implements the Anthropic Messages API for chat completions with support
    for streaming, tools, and multi-modal content.
    """

    def __init__(
        self,
        engine_client: EngineClient,
        model_config,
        served_model_names: List[str],
    ):
        """
        Initialize Anthropic Messages serving handler.

        Args:
            engine_client: Engine client for inference.
            model_config: Model configuration.
            served_model_names: List of model names to serve.
        """
        self.engine_client = engine_client
        self.model_config = model_config
        self.served_model_names = served_model_names

    def _validate_model(self, model: str) -> AnthropicErrorResponse | None:
        """
        Validate that the requested model is served.

        Args:
            model: Model name from request.

        Returns:
            Error response if model is invalid, None otherwise.
        """
        if model not in self.served_model_names:
            return AnthropicErrorResponse(
                error={
                    "type": "invalid_request_error",
                    "message": f"Model '{model}' not found. Available models: {', '.join(self.served_model_names)}",
                }
            )
        return None

    async def create_messages(
        self,
        request: AnthropicMessagesRequest,
        request_id: str,
    ) -> AnthropicMessagesResponse | AnthropicErrorResponse:
        """
        Create a message completion.

        Args:
            request: Anthropic Messages request.
            request_id: Unique request identifier.

        Returns:
            Messages response or error.
        """
        # Validate model
        error_check = self._validate_model(request.model)
        if error_check is not None:
            return error_check

        try:
            # Convert Anthropic messages to OpenAI format
            openai_messages = []

            # Add system message if present
            if request.system:
                openai_messages.append({"role": "system", "content": request.system})

            # Convert messages
            for msg in request.messages:
                openai_messages.append(anthropic_to_openai_message(msg))

            # Parse messages
            prompt, multimodal_inputs = parse_chat_messages(
                messages=openai_messages,
                model_config=self.model_config,
            )

            # Create sampling params
            sampling_params = SamplingParams(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                top_k=request.top_k or -1,
                max_tokens=request.max_tokens,
                stop=request.stop_sequences or [],
            )

            # Generate response
            outputs = await self.engine_client.generate(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            )

            if not outputs or not outputs[0].outputs:
                return AnthropicErrorResponse(
                    error={
                        "type": "internal_server_error",
                        "message": "Failed to generate response",
                    }
                )

            # Extract output
            output = outputs[0].outputs[0]
            text = output.text

            # Determine stop reason
            stop_reason = "end_turn"
            if output.finish_reason == "length":
                stop_reason = "max_tokens"
            elif output.finish_reason == "stop":
                stop_reason = "stop_sequence"

            # Create content blocks
            content_blocks = [ContentBlock(type="text", text=text)]

            # Handle tool calls if present
            # TODO: Implement tool calling support

            # Create usage info
            usage = AnthropicUsage(
                input_tokens=len(outputs[0].prompt_token_ids),
                output_tokens=len(output.token_ids),
            )

            # Create response
            return AnthropicMessagesResponse(
                id=request_id,
                content=content_blocks,
                model=request.model,
                stop_reason=stop_reason,
                usage=usage,
            )

        except Exception as e:
            return AnthropicErrorResponse(
                error={
                    "type": "internal_server_error",
                    "message": f"Error generating response: {str(e)}",
                }
            )

    async def create_messages_stream(
        self,
        request: AnthropicMessagesRequest,
        request_id: str,
    ) -> AsyncIterator[str]:
        """
        Create a streaming message completion.

        Args:
            request: Anthropic Messages request.
            request_id: Unique request identifier.

        Yields:
            Server-Sent Event formatted strings.
        """
        # Validate model
        error_check = self._validate_model(request.model)
        if error_check is not None:
            yield f"event: error\ndata: {error_check.model_dump_json()}\n\n"
            return

        try:
            # Convert messages
            openai_messages = []
            if request.system:
                openai_messages.append({"role": "system", "content": request.system})

            for msg in request.messages:
                openai_messages.append(anthropic_to_openai_message(msg))

            # Parse messages
            prompt, multimodal_inputs = parse_chat_messages(
                messages=openai_messages,
                model_config=self.model_config,
            )

            # Create sampling params
            sampling_params = SamplingParams(
                temperature=request.temperature or 1.0,
                top_p=request.top_p or 1.0,
                top_k=request.top_k or -1,
                max_tokens=request.max_tokens,
                stop=request.stop_sequences or [],
            )

            # Send message_start event
            message_start = AnthropicStreamEvent(
                type="message_start",
                message=AnthropicMessagesResponse(
                    id=request_id,
                    content=[],
                    model=request.model,
                    usage=AnthropicUsage(input_tokens=0, output_tokens=0),
                ),
            )
            yield f"event: message_start\ndata: {message_start.model_dump_json()}\n\n"

            # Send content_block_start
            block_start = AnthropicStreamEvent(
                type="content_block_start",
                index=0,
                content_block=ContentBlock(type="text", text=""),
            )
            yield f"event: content_block_start\ndata: {block_start.model_dump_json()}\n\n"

            # Stream generation
            output_tokens = 0
            async for output in self.engine_client.generate_stream(
                prompt=prompt,
                sampling_params=sampling_params,
                request_id=request_id,
            ):
                if output.outputs:
                    text_delta = output.outputs[0].text
                    output_tokens += len(output.outputs[0].token_ids)

                    # Send content_block_delta
                    delta_event = AnthropicStreamEvent(
                        type="content_block_delta",
                        index=0,
                        delta={"type": "text_delta", "text": text_delta},
                    )
                    yield f"event: content_block_delta\ndata: {delta_event.model_dump_json()}\n\n"

            # Send content_block_stop
            block_stop = AnthropicStreamEvent(
                type="content_block_stop",
                index=0,
            )
            yield f"event: content_block_stop\ndata: {block_stop.model_dump_json()}\n\n"

            # Send message_stop
            message_stop = AnthropicStreamEvent(
                type="message_stop",
            )
            yield f"event: message_stop\ndata: {message_stop.model_dump_json()}\n\n"

        except Exception as e:
            error_response = AnthropicErrorResponse(
                error={
                    "type": "internal_server_error",
                    "message": f"Streaming error: {str(e)}",
                }
            )
            yield f"event: error\ndata: {error_response.model_dump_json()}\n\n"
