# SPDX-License-Identifier: Apache-2.0
"""HTTP server launcher for MLX-LLM."""

from __future__ import annotations

import asyncio
import logging
import signal
import socket
from http import HTTPStatus
from typing import Any

from fastapi import FastAPI, Request, Response

try:
    import uvicorn
    UVICORN_AVAILABLE = True
except ImportError:
    UVICORN_AVAILABLE = False
    uvicorn = None

from mlxllm.entry_points.constants import (
    H11_MAX_HEADER_COUNT_DEFAULT,
    H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT,
)

logger = logging.getLogger(__name__)


async def serve_http(
    app: FastAPI,
    sock: socket.socket | None = None,
    enable_ssl_refresh: bool = False,
    **uvicorn_kwargs: Any,
):
    """
    Start a FastAPI app using Uvicorn.

    Supports http header limits via h11_max_incomplete_event_size and
    h11_max_header_count.

    Args:
        app: FastAPI application instance.
        sock: Optional pre-bound socket.
        enable_ssl_refresh: Enable SSL certificate refresh.
        **uvicorn_kwargs: Additional Uvicorn configuration options.
    """
    if not UVICORN_AVAILABLE:
        raise ImportError("uvicorn is required for HTTP server. Install with: pip install uvicorn")

    logger.info("Available routes are:")
    for route in app.routes:
        methods = getattr(route, "methods", None)
        path = getattr(route, "path", None)

        if methods is None or path is None:
            continue

        logger.info("Route: %s, Methods: %s", path, ", ".join(methods))

    # Extract header limit options if present
    h11_max_incomplete_event_size = uvicorn_kwargs.pop(
        "h11_max_incomplete_event_size", None
    )
    h11_max_header_count = uvicorn_kwargs.pop("h11_max_header_count", None)

    # Set safe defaults if not provided
    if h11_max_incomplete_event_size is None:
        h11_max_incomplete_event_size = H11_MAX_INCOMPLETE_EVENT_SIZE_DEFAULT
    if h11_max_header_count is None:
        h11_max_header_count = H11_MAX_HEADER_COUNT_DEFAULT

    config = uvicorn.Config(app, **uvicorn_kwargs)
    # Set header limits
    config.h11_max_incomplete_event_size = h11_max_incomplete_event_size
    config.h11_max_header_count = h11_max_header_count
    config.load()
    server = uvicorn.Server(config)
    _add_shutdown_handlers(app, server)

    loop = asyncio.get_running_loop()

    watchdog_task = loop.create_task(watchdog_loop(server, app.state.engine_client))
    server_task = loop.create_task(server.serve(sockets=[sock] if sock else None))

    ssl_cert_refresher = None
    if enable_ssl_refresh:
        try:
            from mlxllm.entry_points.ssl import SSLCertRefresher
            ssl_cert_refresher = SSLCertRefresher(
                ssl_context=config.ssl,
                key_path=config.ssl_keyfile,
                cert_path=config.ssl_certfile,
                ca_path=config.ssl_ca_certs,
            )
        except ImportError:
            logger.warning("SSL certificate refresh requested but ssl module not available")

    def signal_handler() -> None:
        # prevents the uvicorn signal handler to exit early
        server_task.cancel()
        watchdog_task.cancel()
        if ssl_cert_refresher:
            ssl_cert_refresher.stop()

    async def dummy_shutdown() -> None:
        pass

    loop.add_signal_handler(signal.SIGINT, signal_handler)
    loop.add_signal_handler(signal.SIGTERM, signal_handler)

    try:
        await server_task
        return dummy_shutdown()
    except asyncio.CancelledError:
        port = uvicorn_kwargs.get("port", 8000)
        logger.info(f"Server on port {port} cancelled, shutting down")
        return server.shutdown()
    finally:
        watchdog_task.cancel()


async def watchdog_loop(server: Any, engine: Any):
    """
    Watchdog task that runs in the background.

    Checks for error state in the engine. Needed to trigger shutdown
    if an exception arises in StreamingResponse() generator.

    Args:
        server: Uvicorn server instance.
        engine: Engine client.
    """
    MLXLLM_WATCHDOG_TIME_S = 5.0
    while True:
        await asyncio.sleep(MLXLLM_WATCHDOG_TIME_S)
        terminate_if_errored(server, engine)


def terminate_if_errored(server: Any, engine: Any):
    """
    Terminate server if engine has errored.

    Args:
        server: Uvicorn server instance.
        engine: Engine client.
    """
    # Check if engine has errored and is not running
    engine_errored = (
        hasattr(engine, "errored") and engine.errored and
        hasattr(engine, "is_running") and not engine.is_running
    )

    if engine_errored:
        logger.error("Engine has errored and stopped, shutting down server")
        server.should_exit = True


def _add_shutdown_handlers(app: FastAPI, server: Any) -> None:
    """
    Add exception handlers for graceful shutdown.

    MLX-LLM AsyncLLMEngine catches exceptions and returns error types.
    We register @app.exception_handlers to return nice responses to
    the end user if they occur and shut down if needed.

    Args:
        app: FastAPI application.
        server: Uvicorn server instance.
    """

    @app.exception_handler(RuntimeError)
    async def runtime_exception_handler(request: Request, exc: RuntimeError):
        """Handle runtime errors."""
        logger.error(f"Runtime error: {exc}")
        terminate_if_errored(
            server=server,
            engine=getattr(request.app.state, "engine_client", None),
        )
        return Response(
            content=str(exc),
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle general exceptions."""
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return Response(
            content=f"Internal server error: {exc}",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
        )
