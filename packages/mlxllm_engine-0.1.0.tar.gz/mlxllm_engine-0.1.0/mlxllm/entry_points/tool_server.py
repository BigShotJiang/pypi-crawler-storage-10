# SPDX-License-Identifier: Apache-2.0
"""Tool server FastAPI application for MLX-LLM."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from mlxllm.entry_points.tool import Tool

logger = logging.getLogger(__name__)


# Request/Response models
class ToolExecutionRequest(BaseModel):
    """Request to execute a tool."""

    tool_name: str
    arguments: Dict[str, Any]


class ToolExecutionResponse(BaseModel):
    """Response from tool execution."""

    result: Any
    error: str | None = None


class ToolListResponse(BaseModel):
    """Response with list of available tools."""

    tools: List[Dict[str, Any]]


def create_demo_tool_server() -> FastAPI:
    """
    Create a demo tool server FastAPI app.

    Provides basic demonstration tools for testing.

    Returns:
        FastAPI application instance.
    """
    app = FastAPI(
        title="MLX-LLM Tool Server (Demo)",
        description="Demo tool server with built-in tools",
        version="0.1.0",
    )

    # Store tools in app state
    app.state.tools: Dict[str, Tool] = {}

    @app.on_event("startup")
    async def startup_event():
        """Initialize demo tools on startup."""
        from mlxllm.entry_points.tool import Tool, ToolParameter

        # Register calculator tool
        calculator = Tool(
            name="calculator",
            description="Perform basic arithmetic calculations",
            parameters=[
                ToolParameter(
                    name="operation",
                    type="string",
                    description="Operation to perform (add, subtract, multiply, divide)",
                    required=True,
                    enum=["add", "subtract", "multiply", "divide"],
                ),
                ToolParameter(
                    name="a",
                    type="number",
                    description="First number",
                    required=True,
                ),
                ToolParameter(
                    name="b",
                    type="number",
                    description="Second number",
                    required=True,
                ),
            ],
        )
        app.state.tools["calculator"] = calculator

        # Register weather tool
        weather = Tool(
            name="get_weather",
            description="Get current weather for a location",
            parameters=[
                ToolParameter(
                    name="location",
                    type="string",
                    description="City name or coordinates",
                    required=True,
                ),
                ToolParameter(
                    name="units",
                    type="string",
                    description="Temperature units",
                    required=False,
                    enum=["celsius", "fahrenheit"],
                    default="celsius",
                ),
            ],
        )
        app.state.tools["get_weather"] = weather

        logger.info("Initialized demo tool server with 2 tools")

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "MLX-LLM Tool Server",
            "version": "0.1.0",
            "tools": len(app.state.tools),
        }

    @app.get("/tools", response_model=ToolListResponse)
    async def list_tools():
        """
        List all available tools.

        Returns:
            List of tool definitions in OpenAI format.
        """
        tools = [tool.to_openai_format() for tool in app.state.tools.values()]
        return ToolListResponse(tools=tools)

    @app.post("/execute", response_model=ToolExecutionResponse)
    async def execute_tool(request: ToolExecutionRequest):
        """
        Execute a tool.

        Args:
            request: Tool execution request.

        Returns:
            Tool execution result.
        """
        tool_name = request.tool_name
        arguments = request.arguments

        if tool_name not in app.state.tools:
            raise HTTPException(status_code=404, detail=f"Tool not found: {tool_name}")

        try:
            if tool_name == "calculator":
                result = _execute_calculator(arguments)
            elif tool_name == "get_weather":
                result = _execute_weather(arguments)
            else:
                result = {"error": f"Tool execution not implemented: {tool_name}"}

            return ToolExecutionResponse(result=result)
        except Exception as e:
            logger.error(f"Tool execution error: {e}")
            return ToolExecutionResponse(result=None, error=str(e))

    return app


def create_mcp_tool_server(mcp_endpoint: str | None = None) -> FastAPI:
    """
    Create an MCP (Model Context Protocol) tool server FastAPI app.

    Args:
        mcp_endpoint: Optional MCP server endpoint URL.

    Returns:
        FastAPI application instance.
    """
    app = FastAPI(
        title="MLX-LLM Tool Server (MCP)",
        description="MCP-based tool server",
        version="0.1.0",
    )

    app.state.mcp_endpoint = mcp_endpoint
    app.state.tools: Dict[str, Tool] = {}

    @app.on_event("startup")
    async def startup_event():
        """Initialize MCP connection on startup."""
        if not app.state.mcp_endpoint:
            logger.warning("No MCP endpoint configured")
            return

        logger.info(f"Connecting to MCP server: {app.state.mcp_endpoint}")
        # TODO: Connect to MCP server and fetch available tools
        logger.warning("MCP tool server not fully implemented yet")

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "MLX-LLM Tool Server (MCP)",
            "version": "0.1.0",
            "mcp_endpoint": app.state.mcp_endpoint,
        }

    @app.get("/tools", response_model=ToolListResponse)
    async def list_tools():
        """List all available tools from MCP."""
        # TODO: Fetch from MCP server
        tools = [tool.to_openai_format() for tool in app.state.tools.values()]
        return ToolListResponse(tools=tools)

    @app.post("/execute", response_model=ToolExecutionResponse)
    async def execute_tool(request: ToolExecutionRequest):
        """Execute a tool via MCP."""
        if not app.state.mcp_endpoint:
            raise HTTPException(status_code=503, detail="MCP endpoint not configured")

        # TODO: Forward to MCP server
        logger.warning("MCP tool execution not implemented yet")
        return ToolExecutionResponse(
            result=None,
            error="MCP tool execution not implemented",
        )

    return app


# Helper functions for demo tools
def _execute_calculator(args: Dict[str, Any]) -> Dict[str, Any]:
    """Execute calculator tool."""
    operation = args.get("operation")
    a = args.get("a", 0)
    b = args.get("b", 0)

    try:
        if operation == "add":
            result = a + b
        elif operation == "subtract":
            result = a - b
        elif operation == "multiply":
            result = a * b
        elif operation == "divide":
            if b == 0:
                return {"error": "Division by zero"}
            result = a / b
        else:
            return {"error": f"Unknown operation: {operation}"}

        return {"result": result}
    except Exception as e:
        return {"error": str(e)}


def _execute_weather(args: Dict[str, Any]) -> Dict[str, Any]:
    """Execute weather tool (mock implementation)."""
    location = args.get("location", "")
    units = args.get("units", "celsius")

    # Mock weather data
    return {
        "location": location,
        "temperature": 22 if units == "celsius" else 72,
        "units": units,
        "conditions": "Partly cloudy",
        "humidity": 65,
    }


# Convenience function to run the server
async def run_tool_server(
    server_type: str = "demo",
    host: str = "0.0.0.0",
    port: int = 8001,
    mcp_endpoint: str | None = None,
):
    """
    Run the tool server.

    Args:
        server_type: Type of server ("demo" or "mcp").
        host: Host to bind to.
        port: Port to bind to.
        mcp_endpoint: MCP endpoint (for MCP server type).
    """
    from mlxllm.entry_points.launcher import serve_http

    if server_type == "demo":
        app = create_demo_tool_server()
    elif server_type == "mcp":
        app = create_mcp_tool_server(mcp_endpoint)
    else:
        raise ValueError(f"Unknown server type: {server_type}")

    logger.info(f"Starting {server_type} tool server on {host}:{port}")

    # Mock engine for tool server (tools don't need the LLM engine)
    class MockEngine:
        is_running = True
        errored = False

    app.state.engine_client = MockEngine()

    await serve_http(
        app=app,
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    import asyncio

    print("MLX-LLM Tool Server")
    print("Starting demo tool server on http://127.0.0.1:8001")
    print()

    try:
        asyncio.run(run_tool_server(server_type="demo", host="127.0.0.1", port=8001))
    except KeyboardInterrupt:
        print("\nShutting down...")
