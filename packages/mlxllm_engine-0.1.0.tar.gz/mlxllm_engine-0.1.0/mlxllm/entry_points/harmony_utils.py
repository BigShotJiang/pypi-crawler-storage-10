# SPDX-License-Identifier: Apache-2.0
"""OpenAI Harmony utilities for MLX-LLM entry points."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, TypedDict, Union

logger = logging.getLogger(__name__)


class HarmonyMessage(TypedDict, total=False):
    """Harmony message format."""

    role: str
    content: str | List[Dict[str, Any]]
    name: str | None
    tool_calls: List[Dict[str, Any]] | None
    tool_call_id: str | None


def convert_openai_to_harmony(
    messages: List[Dict[str, Any]]
) -> List[HarmonyMessage]:
    """
    Convert OpenAI messages to Harmony format.

    Args:
        messages: List of OpenAI format messages.

    Returns:
        List of Harmony format messages.
    """
    harmony_messages = []

    for msg in messages:
        harmony_msg: HarmonyMessage = {
            "role": msg.get("role", "user"),
        }

        # Handle content
        content = msg.get("content")
        if content is not None:
            harmony_msg["content"] = content

        # Handle other fields
        if "name" in msg:
            harmony_msg["name"] = msg["name"]

        if "tool_calls" in msg:
            harmony_msg["tool_calls"] = msg["tool_calls"]

        if "tool_call_id" in msg:
            harmony_msg["tool_call_id"] = msg["tool_call_id"]

        harmony_messages.append(harmony_msg)

    return harmony_messages


def convert_harmony_to_openai(
    messages: List[HarmonyMessage]
) -> List[Dict[str, Any]]:
    """
    Convert Harmony messages to OpenAI format.

    Args:
        messages: List of Harmony format messages.

    Returns:
        List of OpenAI format messages.
    """
    openai_messages = []

    for msg in messages:
        openai_msg: Dict[str, Any] = {
            "role": msg.get("role", "user"),
        }

        # Handle content
        content = msg.get("content")
        if content is not None:
            openai_msg["content"] = content

        # Handle other fields
        if "name" in msg:
            openai_msg["name"] = msg["name"]

        if "tool_calls" in msg:
            openai_msg["tool_calls"] = msg["tool_calls"]

        if "tool_call_id" in msg:
            openai_msg["tool_call_id"] = msg["tool_call_id"]

        openai_messages.append(openai_msg)

    return openai_messages


def parse_harmony_message(
    message: Any,
) -> HarmonyMessage:
    """
    Parse a message object into Harmony format.

    Args:
        message: Message object (could be dict, custom object, etc.).

    Returns:
        Parsed Harmony message.
    """
    if isinstance(message, dict):
        return convert_dict_to_harmony(message)
    elif hasattr(message, "model_dump"):
        # Pydantic model
        return convert_dict_to_harmony(message.model_dump())
    elif hasattr(message, "to_dict"):
        # Custom object with to_dict method
        return convert_dict_to_harmony(message.to_dict())
    else:
        # Fallback: assume it's a dictionary-like object
        return {
            "role": getattr(message, "role", "user"),
            "content": getattr(message, "content", ""),
        }


def convert_dict_to_harmony(data: Dict[str, Any]) -> HarmonyMessage:
    """
    Convert dictionary to Harmony message format.

    Args:
        data: Dictionary with message data.

    Returns:
        Harmony message.
    """
    harmony_msg: HarmonyMessage = {
        "role": data.get("role", "user"),
    }

    if "content" in data:
        harmony_msg["content"] = data["content"]

    if "name" in data:
        harmony_msg["name"] = data["name"]

    if "tool_calls" in data:
        harmony_msg["tool_calls"] = data["tool_calls"]

    if "tool_call_id" in data:
        harmony_msg["tool_call_id"] = data["tool_call_id"]

    return harmony_msg


def validate_harmony_message(message: HarmonyMessage) -> None:
    """
    Validate Harmony message format.

    Args:
        message: Harmony message to validate.

    Raises:
        ValueError: If message is invalid.
    """
    if "role" not in message:
        raise ValueError("Harmony message must have 'role' field")

    role = message["role"]
    if role not in ("system", "user", "assistant", "tool"):
        raise ValueError(f"Invalid role: {role}")

    if "content" not in message and "tool_calls" not in message:
        raise ValueError("Harmony message must have 'content' or 'tool_calls'")


def merge_harmony_messages(
    messages1: List[HarmonyMessage],
    messages2: List[HarmonyMessage],
) -> List[HarmonyMessage]:
    """
    Merge two lists of Harmony messages.

    Args:
        messages1: First list of messages.
        messages2: Second list of messages.

    Returns:
        Merged list of messages.
    """
    merged = []

    # Add all messages from first list
    merged.extend(messages1)

    # Add messages from second list that don't duplicate
    # (based on role and content)
    for msg2 in messages2:
        is_duplicate = False
        for msg1 in messages1:
            if (
                msg1.get("role") == msg2.get("role")
                and msg1.get("content") == msg2.get("content")
            ):
                is_duplicate = True
                break

        if not is_duplicate:
            merged.append(msg2)

    return merged


def extract_text_from_harmony(message: HarmonyMessage) -> str:
    """
    Extract plain text content from Harmony message.

    Args:
        message: Harmony message.

    Returns:
        Text content as string.
    """
    content = message.get("content", "")

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        text_parts = []
        for part in content:
            if isinstance(part, str):
                text_parts.append(part)
            elif isinstance(part, dict):
                if part.get("type") == "text":
                    text_parts.append(part.get("text", ""))
                elif part.get("type") in ("image_url", "audio_url", "video_url"):
                    # Add placeholder for non-text content
                    text_parts.append(f"[{part.get('type')}]")

        return " ".join(text_parts)

    return str(content)


def create_harmony_system_message(content: str) -> HarmonyMessage:
    """
    Create a system message in Harmony format.

    Args:
        content: System message content.

    Returns:
        Harmony system message.
    """
    return {
        "role": "system",
        "content": content,
    }


def create_harmony_user_message(
    content: str | List[Dict[str, Any]],
    name: str | None = None,
) -> HarmonyMessage:
    """
    Create a user message in Harmony format.

    Args:
        content: User message content.
        name: Optional user name.

    Returns:
        Harmony user message.
    """
    msg: HarmonyMessage = {
        "role": "user",
        "content": content,
    }

    if name:
        msg["name"] = name

    return msg


def create_harmony_assistant_message(
    content: str,
    name: str | None = None,
    tool_calls: List[Dict[str, Any]] | None = None,
) -> HarmonyMessage:
    """
    Create an assistant message in Harmony format.

    Args:
        content: Assistant message content.
        name: Optional assistant name.
        tool_calls: Optional tool calls.

    Returns:
        Harmony assistant message.
    """
    msg: HarmonyMessage = {
        "role": "assistant",
        "content": content,
    }

    if name:
        msg["name"] = name

    if tool_calls:
        msg["tool_calls"] = tool_calls

    return msg


def create_harmony_tool_message(
    tool_call_id: str,
    content: str,
) -> HarmonyMessage:
    """
    Create a tool message in Harmony format.

    Args:
        tool_call_id: ID of the tool call this responds to.
        content: Tool response content.

    Returns:
        Harmony tool message.
    """
    return {
        "role": "tool",
        "content": content,
        "tool_call_id": tool_call_id,
    }


def harmony_messages_to_prompt(
    messages: List[HarmonyMessage],
    system_prompt: str | None = None,
) -> str:
    """
    Convert Harmony messages to a simple prompt string.

    Args:
        messages: List of Harmony messages.
        system_prompt: Optional system prompt to prepend.

    Returns:
        Formatted prompt string.
    """
    parts = []

    if system_prompt:
        parts.append(f"System: {system_prompt}\n\n")

    for msg in messages:
        role = msg.get("role", "user")
        content = extract_text_from_harmony(msg)

        if role == "system":
            parts.append(f"System: {content}\n\n")
        elif role == "user":
            parts.append(f"User: {content}\n\n")
        elif role == "assistant":
            parts.append(f"Assistant: {content}\n\n")
        elif role == "tool":
            parts.append(f"Tool: {content}\n\n")
        else:
            parts.append(f"{role.capitalize()}: {content}\n\n")

    return "".join(parts).strip()


def count_harmony_message_tokens(
    messages: List[HarmonyMessage],
    tokenizer: Any | None = None,
) -> int:
    """
    Count tokens in Harmony messages.

    Args:
        messages: List of Harmony messages.
        tokenizer: Optional tokenizer for accurate counting.

    Returns:
        Estimated token count.
    """
    if tokenizer and hasattr(tokenizer, "encode"):
        total_tokens = 0
        for msg in messages:
            text = extract_text_from_harmony(msg)
            total_tokens += len(tokenizer.encode(text))
        return total_tokens
    else:
        # Rough estimate: ~4 characters per token
        total_chars = sum(
            len(extract_text_from_harmony(msg)) for msg in messages
        )
        return total_chars // 4
