# SPDX-License-Identifier: Apache-2.0
"""Basic API server for MLX-LLM (demo/reference implementation)."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse

logger = logging.getLogger(__name__)


def create_app(engine_client: Any) -> FastAPI:
    """
    Create a basic FastAPI app with AsyncEngine.

    This is a simple demo server with a single /generate endpoint.
    Not recommended for production - use openai/api_server.py instead.

    Args:
        engine_client: Async engine client.

    Returns:
        FastAPI application instance.
    """
    app = FastAPI(
        title="MLX-LLM API Server",
        description="Basic demo API server for MLX-LLM",
        version="0.1.0",
    )

    # Store engine client in app state
    app.state.engine_client = engine_client

    @app.get("/")
    async def root():
        """Root endpoint."""
        return {
            "message": "MLX-LLM API Server",
            "version": "0.1.0",
            "endpoints": ["/health", "/generate"],
        }

    @app.get("/health")
    async def health():
        """Health check endpoint."""
        engine_running = hasattr(engine_client, "is_running") and engine_client.is_running
        return {
            "status": "healthy" if engine_running else "degraded",
            "engine_running": engine_running,
        }

    @app.post("/generate")
    async def generate(request: Request):
        """
        Generate text endpoint.

        Request body:
        {
            "prompt": "Text prompt",
            "max_tokens": 100,
            "temperature": 0.7,
            "stream": false
        }
        """
        try:
            body = await request.json()
        except Exception as e:
            return JSONResponse(
                status_code=400,
                content={"error": f"Invalid JSON: {e}"},
            )

        prompt = body.get("prompt", "")
        if not prompt:
            return JSONResponse(
                status_code=400,
                content={"error": "prompt is required"},
            )

        max_tokens = body.get("max_tokens", 100)
        temperature = body.get("temperature", 0.7)
        stream = body.get("stream", False)

        # Create sampling params
        from mlxllm.sampling_params import SamplingParams

        sampling_params = SamplingParams(
            max_tokens=max_tokens,
            temperature=temperature,
        )

        if stream:
            # Streaming response
            async def stream_generator():
                try:
                    async for output in engine_client.generate(
                        prompt=prompt,
                        sampling_params=sampling_params,
                    ):
                        # Extract text from output
                        if hasattr(output, "outputs") and output.outputs:
                            text = output.outputs[0].text
                            chunk = {
                                "text": text,
                                "finished": output.finished,
                            }
                            yield f"data: {chunk}\n\n"

                    yield "data: [DONE]\n\n"
                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                    yield f"data: {{\"error\": \"{e}\"}}\n\n"

            return StreamingResponse(
                stream_generator(),
                media_type="text/event-stream",
            )
        else:
            # Non-streaming response
            try:
                output = await engine_client.generate(
                    prompt=prompt,
                    sampling_params=sampling_params,
                )

                # Extract text from final output
                if hasattr(output, "outputs") and output.outputs:
                    generated_text = output.outputs[0].text
                else:
                    generated_text = str(output)

                return {
                    "prompt": prompt,
                    "text": generated_text,
                    "finish_reason": getattr(output, "finish_reason", "stop"),
                }
            except Exception as e:
                logger.error(f"Generation error: {e}")
                return JSONResponse(
                    status_code=500,
                    content={"error": str(e)},
                )

    return app


async def run_server(
    engine_client: Any,
    host: str = "0.0.0.0",
    port: int = 8000,
):
    """
    Run the API server.

    Args:
        engine_client: Async engine client.
        host: Host to bind to.
        port: Port to bind to.
    """
    from mlxllm.entry_points.launcher import serve_http

    app = create_app(engine_client)

    logger.info(f"Starting MLX-LLM API server on {host}:{port}")

    await serve_http(
        app=app,
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    # Simple test/demo mode
    print("MLX-LLM Basic API Server (Demo)")
    print("For production use, use: mlxllm serve")
    print()
    print("This demo requires an initialized AsyncLLMEngine.")
    print("Starting in mock mode for testing...")

    # Mock engine for testing
    class MockEngine:
        is_running = True

        async def generate(self, prompt, sampling_params):
            """Mock generate method."""
            await asyncio.sleep(0.1)

            class MockOutput:
                finished = True
                finish_reason = "stop"

                class MockCompletion:
                    text = f"Mock response to: {prompt}"

                outputs = [MockCompletion()]

            return MockOutput()

    async def main():
        engine = MockEngine()
        await run_server(engine, host="127.0.0.1", port=8000)

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nShutting down...")
