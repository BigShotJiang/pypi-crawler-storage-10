# SPDX-License-Identifier: Apache-2.0
"""Scoring utilities for MLX-LLM entry points."""

from __future__ import annotations

import logging
from typing import Any, TypedDict

try:
    import mlx.core as mx
    MLX_AVAILABLE = True
except ImportError:
    MLX_AVAILABLE = False
    mx = None

logger = logging.getLogger(__name__)


class ScoreContentPartParam(TypedDict, total=False):
    """Content part for scoring requests."""

    text: str
    type: str


class ScoreMultiModalParam(TypedDict, total=False):
    """Multi-modal parameters for scoring."""

    image_url: str | None
    audio_url: str | None
    video_url: str | None


def _cosine_similarity(
    embedding1: Any,  # mx.array or list
    embedding2: Any,  # mx.array or list
) -> float:
    """
    Compute cosine similarity between two embeddings.

    Args:
        embedding1: First embedding vector.
        embedding2: Second embedding vector.

    Returns:
        Cosine similarity score in range [-1, 1].
    """
    if MLX_AVAILABLE and isinstance(embedding1, mx.array):
        # Use MLX for computation
        dot_product = mx.sum(embedding1 * embedding2)
        norm1 = mx.sqrt(mx.sum(embedding1 * embedding1))
        norm2 = mx.sqrt(mx.sum(embedding2 * embedding2))
        similarity = dot_product / (norm1 * norm2 + 1e-10)
        return float(similarity)
    else:
        # Fallback to Python list operations
        if not isinstance(embedding1, list):
            embedding1 = list(embedding1)
        if not isinstance(embedding2, list):
            embedding2 = list(embedding2)

        dot_product = sum(a * b for a, b in zip(embedding1, embedding2))
        norm1 = sum(a * a for a in embedding1) ** 0.5
        norm2 = sum(b * b for b in embedding2) ** 0.5
        similarity = dot_product / (norm1 * norm2 + 1e-10)
        return similarity


def _validate_score_input_lens(
    queries: list[str],
    documents: list[str],
) -> None:
    """
    Validate that queries and documents have compatible lengths.

    Args:
        queries: List of query strings.
        documents: List of document strings.

    Raises:
        ValueError: If lengths are incompatible.
    """
    if not queries:
        raise ValueError("At least one query is required")

    if not documents:
        raise ValueError("At least one document is required")

    # Either one query for many documents, or equal number of queries and documents
    if len(queries) != 1 and len(queries) != len(documents):
        raise ValueError(
            f"Number of queries ({len(queries)}) must be 1 or equal to "
            f"number of documents ({len(documents)})"
        )


def compress_token_type_ids(
    token_type_ids: list[int],
) -> str:
    """
    Compress token type IDs to a compact string representation.

    Useful for reducing payload size when sending token types.

    Args:
        token_type_ids: List of token type IDs.

    Returns:
        Compressed string representation.

    Example:
        [0, 0, 0, 1, 1, 2, 2, 2] -> "3x0,2x1,3x2"
    """
    if not token_type_ids:
        return ""

    compressed_parts = []
    current_type = token_type_ids[0]
    count = 1

    for type_id in token_type_ids[1:]:
        if type_id == current_type:
            count += 1
        else:
            compressed_parts.append(f"{count}x{current_type}")
            current_type = type_id
            count = 1

    # Add the last run
    compressed_parts.append(f"{count}x{current_type}")

    return ",".join(compressed_parts)


def decompress_token_type_ids(compressed: str) -> list[int]:
    """
    Decompress token type IDs from compact string representation.

    Args:
        compressed: Compressed string representation.

    Returns:
        List of token type IDs.

    Example:
        "3x0,2x1,3x2" -> [0, 0, 0, 1, 1, 2, 2, 2]
    """
    if not compressed:
        return []

    token_types = []
    for part in compressed.split(","):
        count_str, type_str = part.split("x")
        count = int(count_str)
        type_id = int(type_str)
        token_types.extend([type_id] * count)

    return token_types


def get_score_prompt(
    query: str,
    document: str,
    instruction: str | None = None,
) -> str:
    """
    Create a scoring prompt for query-document pairs.

    Args:
        query: Query string.
        document: Document string.
        instruction: Optional instruction for scoring task.

    Returns:
        Formatted prompt string.
    """
    if instruction:
        return f"{instruction}\n\nQuery: {query}\n\nDocument: {document}\n\nRelevance:"
    else:
        return f"Query: {query}\n\nDocument: {document}\n\nRelevance:"


def compute_pairwise_scores(
    queries: list[str],
    documents: list[str],
    embeddings_queries: list[Any],
    embeddings_docs: list[Any],
) -> list[list[float]]:
    """
    Compute pairwise similarity scores between queries and documents.

    Args:
        queries: List of query strings.
        documents: List of document strings.
        embeddings_queries: Embeddings for queries.
        embeddings_docs: Embeddings for documents.

    Returns:
        2D list of scores, where scores[i][j] is similarity between
        query i and document j.
    """
    _validate_score_input_lens(queries, documents)

    scores = []
    for query_emb in embeddings_queries:
        query_scores = []
        for doc_emb in embeddings_docs:
            similarity = _cosine_similarity(query_emb, doc_emb)
            query_scores.append(similarity)
        scores.append(query_scores)

    return scores


def rank_documents(
    query_embedding: Any,
    document_embeddings: list[Any],
    documents: list[str],
    top_k: int | None = None,
) -> list[tuple[str, float]]:
    """
    Rank documents by relevance to a query.

    Args:
        query_embedding: Query embedding vector.
        document_embeddings: List of document embedding vectors.
        documents: List of document strings.
        top_k: Optional number of top results to return.

    Returns:
        List of (document, score) tuples, sorted by descending score.
    """
    if len(document_embeddings) != len(documents):
        raise ValueError(
            f"Number of embeddings ({len(document_embeddings)}) must match "
            f"number of documents ({len(documents)})"
        )

    # Compute similarities
    scores = [
        _cosine_similarity(query_embedding, doc_emb)
        for doc_emb in document_embeddings
    ]

    # Pair documents with scores and sort
    doc_score_pairs = list(zip(documents, scores))
    doc_score_pairs.sort(key=lambda x: x[1], reverse=True)

    # Return top-k if specified
    if top_k is not None and top_k > 0:
        return doc_score_pairs[:top_k]

    return doc_score_pairs
