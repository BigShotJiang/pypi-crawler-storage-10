# SPDX-License-Identifier: Apache-2.0
"""Model configuration for MLX-LLM."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class QuantizationType(str, Enum):
    """Quantization types supported by MLX."""

    NONE = "none"
    """No quantization (fp16 or bf16)."""

    Q4_0 = "q4_0"
    """4-bit quantization (MLX q4_0 format)."""

    Q4_1 = "q4_1"
    """4-bit quantization with better accuracy (MLX q4_1 format)."""

    Q8_0 = "q8_0"
    """8-bit quantization."""

    @property
    def bits(self) -> int:
        """Get number of bits for quantization."""
        if self == QuantizationType.NONE:
            return 16
        elif self == QuantizationType.Q8_0:
            return 8
        else:  # Q4_0 or Q4_1
            return 4


class DType(str, Enum):
    """Data types for model weights and activations."""

    FLOAT16 = "float16"
    """16-bit floating point."""

    BFLOAT16 = "bfloat16"
    """Brain float 16 (better for training/inference)."""

    FLOAT32 = "float32"
    """32-bit floating point (higher precision, more memory)."""

    AUTO = "auto"
    """Automatically select based on model."""


class ModelType(str, Enum):
    """Model architecture types."""

    LLAMA = "llama"
    """Llama/Llama2/Llama3 architecture."""

    QWEN2 = "qwen2"
    """Qwen2/Qwen2.5 architecture."""

    DEEPSEEK = "deepseek"
    """DeepSeek architecture."""


@dataclass
class ModelConfig:
    """Configuration for model architecture and loading."""

    model_name: str
    """Model name or HuggingFace model ID."""

    model_type: Optional[ModelType] = None
    """Model architecture type. If None, inferred from model name."""

    model_path: Optional[str] = None
    """Local path to model. If None, downloads from HuggingFace."""

    # Architecture parameters
    vocab_size: Optional[int] = None
    """Vocabulary size. If None, loaded from config."""

    hidden_size: Optional[int] = None
    """Hidden dimension. If None, loaded from config."""

    num_layers: Optional[int] = None
    """Number of transformer layers. If None, loaded from config."""

    num_attention_heads: Optional[int] = None
    """Number of attention heads. If None, loaded from config."""

    num_kv_heads: Optional[int] = None
    """Number of KV heads for GQA/MQA. If None, equals num_attention_heads."""

    head_dim: Optional[int] = None
    """Head dimension. If None, computed as hidden_size / num_attention_heads."""

    intermediate_size: Optional[int] = None
    """FFN intermediate size. If None, loaded from config."""

    # Context and sequence parameters
    max_model_len: int = 8192
    """Maximum context length supported by model."""

    max_position_embeddings: Optional[int] = None
    """Maximum position embeddings (legacy). Usually equals max_model_len."""

    max_num_seqs: int = 256
    """Maximum number of sequences in a batch."""

    max_num_batched_tokens: Optional[int] = None
    """Maximum tokens in a batch. If None, computed from max_model_len."""

    # Quantization
    quantization: QuantizationType = QuantizationType.Q4_0
    """Quantization type for model weights."""

    dtype: DType = DType.BFLOAT16
    """Data type for non-quantized weights and activations."""

    # Model loading
    trust_remote_code: bool = False
    """Trust remote code when loading model (required for some models)."""

    revision: Optional[str] = None
    """Model revision (git branch/tag) to load."""

    # Attention configuration
    rope_theta: float = 10000.0
    """RoPE theta parameter."""

    rope_scaling: Optional[dict] = None
    """RoPE scaling configuration for extended context."""

    rms_norm_eps: float = 1e-6
    """RMS normalization epsilon value."""

    # Multimodal
    is_multimodal: bool = False
    """Whether model supports multimodal inputs (vision, audio)."""

    # MoE configuration
    is_moe: bool = False
    """Whether model uses Mixture of Experts."""

    num_experts: Optional[int] = None
    """Number of experts (for MoE models)."""

    num_experts_per_token: Optional[int] = None
    """Number of experts activated per token (for MoE)."""

    def validate(self) -> None:
        """Validate model configuration."""
        if not self.model_name:
            raise ValueError("model_name must be specified")

        if self.max_model_len <= 0:
            raise ValueError(
                f"max_model_len must be positive, got {self.max_model_len}"
            )

        if self.max_num_seqs <= 0:
            raise ValueError(
                f"max_num_seqs must be positive, got {self.max_num_seqs}"
            )

        if self.rope_theta <= 0:
            raise ValueError(f"rope_theta must be positive, got {self.rope_theta}")

        # Validate MoE config
        if self.is_moe:
            if self.num_experts is None or self.num_experts <= 0:
                raise ValueError(
                    f"num_experts must be positive for MoE, got {self.num_experts}"
                )
            if (
                self.num_experts_per_token is None
                or self.num_experts_per_token <= 0
            ):
                raise ValueError(
                    f"num_experts_per_token must be positive for MoE, "
                    f"got {self.num_experts_per_token}"
                )
            if self.num_experts_per_token > self.num_experts:
                raise ValueError(
                    f"num_experts_per_token ({self.num_experts_per_token}) cannot "
                    f"exceed num_experts ({self.num_experts})"
                )

    def estimate_memory_usage(self) -> float:
        """
        Estimate model memory usage in GB.

        Returns:
            Estimated memory in GB.
        """
        if self.hidden_size is None or self.num_layers is None:
            # Cannot estimate without architecture info
            return 0.0

        # Rough estimation based on parameters
        # Each layer has: attention weights + FFN weights
        # Attention: 4 * hidden_size^2 (Q, K, V, O projections)
        # FFN: 2 * hidden_size * intermediate_size

        params_per_layer = 4 * (self.hidden_size**2)
        if self.intermediate_size is not None:
            params_per_layer += 2 * self.hidden_size * self.intermediate_size
        else:
            # Default assumption: intermediate_size = 4 * hidden_size
            params_per_layer += 8 * (self.hidden_size**2)

        total_params = params_per_layer * self.num_layers

        # Add embedding parameters
        if self.vocab_size is not None:
            total_params += self.vocab_size * self.hidden_size

        # Calculate memory based on quantization
        bytes_per_param = self.quantization.bits / 8

        # Add 20% overhead for activations and other buffers
        total_bytes = total_params * bytes_per_param * 1.2

        return total_bytes / (1024**3)  # Convert to GB

    @classmethod
    def from_model_name(
        cls,
        model_name: str,
        quantization: QuantizationType = QuantizationType.Q4_0,
        max_model_len: int = 8192,
        **kwargs,
    ) -> "ModelConfig":
        """
        Create ModelConfig from model name with sensible defaults.

        Args:
            model_name: Model name or HuggingFace ID.
            quantization: Quantization type.
            max_model_len: Maximum context length.
            **kwargs: Additional config parameters.

        Returns:
            ModelConfig.
        """
        return cls(
            model_name=model_name,
            quantization=quantization,
            max_model_len=max_model_len,
            **kwargs,
        )

    def __str__(self) -> str:
        """String representation of model config."""
        quant_str = f"{self.quantization.value}"
        return (
            f"ModelConfig({self.model_name}, "
            f"quant={quant_str}, "
            f"max_len={self.max_model_len})"
        )
