# SPDX-License-Identifier: Apache-2.0
"""Cache configuration for KV cache management in MLX-LLM."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class CacheType(str, Enum):
    """Type of KV cache implementation."""

    AUTO = "auto"
    """Automatically select based on model and device."""

    PAGED = "paged"
    """Paged attention with block-based KV cache (like PagedAttention)."""

    CONTIGUOUS = "contiguous"
    """Contiguous KV cache (simpler, less memory efficient)."""

    STREAMING = "streaming"
    """Streaming KV cache for very long contexts."""


class EvictionPolicy(str, Enum):
    """Policy for evicting KV cache blocks when memory is full."""

    LRU = "lru"
    """Least Recently Used."""

    FIFO = "fifo"
    """First In First Out."""

    LFU = "lfu"
    """Least Frequently Used."""


@dataclass
class KVCacheConfig:
    """Configuration for KV cache management."""

    block_size: int = 16
    """Size of each KV cache block in tokens. Must be power of 2."""

    num_gpu_blocks: Optional[int] = None
    """Number of KV cache blocks on GPU. If None, auto-calculated."""

    num_cpu_blocks: Optional[int] = None
    """Number of KV cache blocks offloaded to CPU memory. If None, disabled."""

    cache_type: CacheType = CacheType.PAGED
    """Type of KV cache implementation."""

    eviction_policy: EvictionPolicy = EvictionPolicy.LRU
    """Eviction policy when cache is full."""

    enable_prefix_caching: bool = True
    """Enable prefix caching for repeated prompts."""

    max_num_blocks_per_seq: Optional[int] = None
    """Maximum number of blocks per sequence. If None, unlimited."""

    swap_space_gb: float = 4.0
    """Swap space in GB for offloading (M4 unified memory optimization)."""

    enable_chunked_prefill: bool = True
    """Enable chunked prefill for long prompts (reduces memory spikes)."""

    prefill_chunk_size: int = 512
    """Chunk size for prefill in tokens."""

    def validate(self) -> None:
        """Validate KV cache configuration."""
        # Block size must be power of 2
        if self.block_size <= 0 or (self.block_size & (self.block_size - 1)) != 0:
            raise ValueError(
                f"block_size must be a power of 2, got {self.block_size}"
            )

        # Block size should be reasonable
        if self.block_size < 4 or self.block_size > 128:
            raise ValueError(
                f"block_size should be in [4, 128], got {self.block_size}"
            )

        # Num blocks must be positive if specified
        if self.num_gpu_blocks is not None and self.num_gpu_blocks <= 0:
            raise ValueError(
                f"num_gpu_blocks must be positive, got {self.num_gpu_blocks}"
            )

        if self.num_cpu_blocks is not None and self.num_cpu_blocks < 0:
            raise ValueError(
                f"num_cpu_blocks must be non-negative, got {self.num_cpu_blocks}"
            )

        # Swap space must be non-negative
        if self.swap_space_gb < 0:
            raise ValueError(
                f"swap_space_gb must be non-negative, got {self.swap_space_gb}"
            )

        # Prefill chunk size must be positive
        if self.prefill_chunk_size <= 0:
            raise ValueError(
                f"prefill_chunk_size must be positive, got {self.prefill_chunk_size}"
            )

    def estimate_memory_usage(
        self,
        num_layers: int,
        num_kv_heads: int,
        head_dim: int,
        dtype_bytes: int = 2,
    ) -> float:
        """
        Estimate memory usage for KV cache in GB.

        Args:
            num_layers: Number of transformer layers.
            num_kv_heads: Number of KV heads (for GQA/MQA).
            head_dim: Head dimension.
            dtype_bytes: Bytes per element (2 for fp16/bf16, 1 for int8).

        Returns:
            Estimated memory in GB.
        """
        if self.num_gpu_blocks is None:
            return 0.0

        # Memory per block: 2 (k+v) * num_layers * num_kv_heads * head_dim * block_size * dtype_bytes
        bytes_per_block = (
            2 * num_layers * num_kv_heads * head_dim * self.block_size * dtype_bytes
        )

        # Total memory for GPU blocks
        total_bytes = bytes_per_block * self.num_gpu_blocks

        # Add CPU blocks if enabled
        if self.num_cpu_blocks is not None:
            total_bytes += bytes_per_block * self.num_cpu_blocks

        return total_bytes / (1024**3)  # Convert to GB

    def __str__(self) -> str:
        """String representation of KV cache config."""
        return (
            f"KVCacheConfig(block_size={self.block_size}, "
            f"gpu_blocks={self.num_gpu_blocks}, "
            f"type={self.cache_type.value})"
        )


@dataclass
class CacheConfig:
    """General cache configuration (includes KV cache and other caching)."""

    kv_cache: KVCacheConfig | None = None
    """KV cache configuration."""

    # Legacy parameters for backward compatibility
    block_size: Optional[int] = None
    """Block size (legacy). Use kv_cache.block_size instead."""

    num_gpu_blocks: Optional[int] = None
    """Number of GPU blocks (legacy). Use kv_cache.num_gpu_blocks instead."""

    num_cpu_blocks: Optional[int] = None
    """Number of CPU blocks (legacy). Use kv_cache.num_cpu_blocks instead."""

    enable_embedding_cache: bool = True
    """Cache encoder embeddings for multimodal models."""

    embedding_cache_size_mb: int = 512
    """Size of embedding cache in MB."""

    enable_model_cache: bool = True
    """Cache compiled Metal kernels and model artifacts."""

    cache_dir: Optional[str] = None
    """Directory for persistent caching. If None, uses system default."""

    def __post_init__(self):
        """Initialize kv_cache from legacy parameters if needed."""
        # If kv_cache is not provided but legacy parameters are, create KVCacheConfig
        if self.kv_cache is None:
            self.kv_cache = KVCacheConfig(
                block_size=self.block_size if self.block_size is not None else 16,
                num_gpu_blocks=self.num_gpu_blocks,
                num_cpu_blocks=self.num_cpu_blocks,
            )

    @classmethod
    def from_defaults(
        cls,
        block_size: int = 16,
        cache_type: CacheType = CacheType.PAGED,
    ) -> "CacheConfig":
        """
        Create CacheConfig with default settings.

        Args:
            block_size: KV cache block size.
            cache_type: Type of KV cache.

        Returns:
            CacheConfig with defaults.
        """
        kv_cache = KVCacheConfig(
            block_size=block_size,
            cache_type=cache_type,
        )

        return cls(kv_cache=kv_cache)

    def validate(self) -> None:
        """Validate cache configuration."""
        self.kv_cache.validate()

        if self.embedding_cache_size_mb < 0:
            raise ValueError(
                f"embedding_cache_size_mb must be non-negative, "
                f"got {self.embedding_cache_size_mb}"
            )

    def __str__(self) -> str:
        """String representation of cache config."""
        return f"CacheConfig(kv={self.kv_cache}, embedding_cache={self.enable_embedding_cache})"
