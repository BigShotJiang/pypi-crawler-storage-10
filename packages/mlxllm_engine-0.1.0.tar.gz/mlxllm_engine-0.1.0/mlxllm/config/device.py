# SPDX-License-Identifier: Apache-2.0
"""Device configuration and Metal device detection for MLX-LLM."""

import platform
from dataclasses import dataclass
from typing import Optional

try:
    import mlx.core as mx

    MLX_AVAILABLE = True
except ImportError:
    MLX_AVAILABLE = False
    mx = None


@dataclass
class MetalDeviceInfo:
    """Information about the Metal device (Apple Silicon chip)."""

    chip_name: str
    """Name of the Apple Silicon chip (e.g., 'M4', 'M4 Pro', 'M4 Max')."""

    num_gpu_cores: int
    """Number of GPU cores available."""

    unified_memory_gb: float
    """Total unified memory in GB."""

    max_recommended_buffer_gb: float
    """Maximum recommended buffer size for Metal operations in GB."""

    supports_mlx: bool
    """Whether MLX is available and functional."""

    @classmethod
    def detect(cls) -> "MetalDeviceInfo":
        """
        Detect Metal device information from the system.

        Returns:
            MetalDeviceInfo with detected system capabilities.
        """
        # Detect chip name from platform
        chip_name = cls._detect_chip_name()
        num_gpu_cores = cls._detect_gpu_cores(chip_name)
        unified_memory_gb = cls._detect_unified_memory()
        max_recommended_buffer_gb = unified_memory_gb * 0.7  # 70% of total memory

        return cls(
            chip_name=chip_name,
            num_gpu_cores=num_gpu_cores,
            unified_memory_gb=unified_memory_gb,
            max_recommended_buffer_gb=max_recommended_buffer_gb,
            supports_mlx=MLX_AVAILABLE,
        )

    @staticmethod
    def _detect_chip_name() -> str:
        """Detect Apple Silicon chip name."""
        try:
            import subprocess

            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True,
                text=True,
                check=True,
            )
            brand = result.stdout.strip()

            # Parse chip name (e.g., "Apple M4 Pro")
            if "M4" in brand:
                if "Max" in brand:
                    return "M4 Max"
                elif "Pro" in brand:
                    return "M4 Pro"
                elif "Ultra" in brand:
                    return "M4 Ultra"
                return "M4"
            elif "M3" in brand:
                if "Max" in brand:
                    return "M3 Max"
                elif "Pro" in brand:
                    return "M3 Pro"
                return "M3"
            elif "M2" in brand:
                if "Max" in brand:
                    return "M2 Max"
                elif "Pro" in brand:
                    return "M2 Pro"
                elif "Ultra" in brand:
                    return "M2 Ultra"
                return "M2"
            elif "M1" in brand:
                if "Max" in brand:
                    return "M1 Max"
                elif "Pro" in brand:
                    return "M1 Pro"
                elif "Ultra" in brand:
                    return "M1 Ultra"
                return "M1"

            return "Unknown"
        except Exception:
            return platform.processor() or "Unknown"

    @staticmethod
    def _detect_gpu_cores(chip_name: str) -> int:
        """Estimate GPU cores based on chip name."""
        # Known GPU core counts
        gpu_cores_map = {
            "M4": 10,
            "M4 Pro": 20,
            "M4 Max": 40,
            "M4 Ultra": 80,
            "M3": 10,
            "M3 Pro": 18,
            "M3 Max": 40,
            "M2": 10,
            "M2 Pro": 19,
            "M2 Max": 38,
            "M2 Ultra": 76,
            "M1": 8,
            "M1 Pro": 16,
            "M1 Max": 32,
            "M1 Ultra": 64,
        }
        return gpu_cores_map.get(chip_name, 10)

    @staticmethod
    def _detect_unified_memory() -> float:
        """Detect unified memory in GB."""
        try:
            import subprocess

            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True,
                text=True,
                check=True,
            )
            memory_bytes = int(result.stdout.strip())
            return memory_bytes / (1024**3)  # Convert to GB
        except Exception:
            return 16.0  # Default assumption

    def __str__(self) -> str:
        """String representation of device info."""
        return (
            f"MetalDevice(chip={self.chip_name}, "
            f"gpu_cores={self.num_gpu_cores}, "
            f"memory={self.unified_memory_gb:.1f}GB, "
            f"mlx={'✓' if self.supports_mlx else '✗'})"
        )


@dataclass
class DeviceConfig:
    """Configuration for device management in MLX-LLM."""

    device_info: MetalDeviceInfo
    """Information about the Metal device."""

    device_id: int = 0
    """Device ID (always 0 for Metal, included for API compatibility)."""

    max_memory_gb: Optional[float] = None
    """Maximum memory to use in GB. If None, uses max_recommended_buffer_gb."""

    memory_fraction: float = 0.7
    """Fraction of total memory to use for model and KV cache (0.0-1.0)."""

    enable_unified_memory: bool = True
    """Enable unified memory optimizations (zero-copy CPU/GPU)."""

    @classmethod
    def from_auto_detect(
        cls,
        max_memory_gb: Optional[float] = None,
        memory_fraction: float = 0.7,
    ) -> "DeviceConfig":
        """
        Create DeviceConfig by auto-detecting system capabilities.

        Args:
            max_memory_gb: Maximum memory to use. If None, auto-detected.
            memory_fraction: Fraction of memory to use.

        Returns:
            DeviceConfig with detected settings.
        """
        device_info = MetalDeviceInfo.detect()

        if max_memory_gb is None:
            max_memory_gb = device_info.unified_memory_gb * memory_fraction

        return cls(
            device_info=device_info,
            max_memory_gb=max_memory_gb,
            memory_fraction=memory_fraction,
        )

    @property
    def available_memory_gb(self) -> float:
        """Get available memory in GB after accounting for OS overhead."""
        if self.max_memory_gb is not None:
            return self.max_memory_gb
        return self.device_info.unified_memory_gb * self.memory_fraction

    def validate(self) -> None:
        """Validate device configuration."""
        if not self.device_info.supports_mlx:
            raise RuntimeError(
                "MLX is not available. Install with: pip install mlx mlx-lm"
            )

        if self.memory_fraction < 0.0 or self.memory_fraction > 1.0:
            raise ValueError(
                f"memory_fraction must be in [0.0, 1.0], got {self.memory_fraction}"
            )

        if (
            self.max_memory_gb is not None
            and self.max_memory_gb > self.device_info.unified_memory_gb
        ):
            raise ValueError(
                f"max_memory_gb ({self.max_memory_gb}) exceeds "
                f"available memory ({self.device_info.unified_memory_gb}GB)"
            )

    def __str__(self) -> str:
        """String representation of device config."""
        return (
            f"DeviceConfig({self.device_info.chip_name}, "
            f"available={self.available_memory_gb:.1f}GB)"
        )
