# SPDX-License-Identifier: Apache-2.0
"""Configuration system for MLX-LLM.

This module provides configuration classes for all aspects of the MLX-LLM engine,
including device management, cache configuration, model settings, and scheduling.
"""

from mlxllm.config.cache import CacheConfig, CacheType, EvictionPolicy, KVCacheConfig
from mlxllm.config.device import DeviceConfig, MetalDeviceInfo
from mlxllm.config.mlx import MLXConfig
from mlxllm.config.model import DType, ModelConfig, ModelType, QuantizationType
from mlxllm.config.scheduler import (
    PreemptionMode,
    SchedulerConfig,
    SchedulingPolicy,
)

__all__ = [
    # Main configs
    "CacheConfig",
    "DeviceConfig",
    "KVCacheConfig",
    "MetalDeviceInfo",
    "MLXConfig",
    "ModelConfig",
    "SchedulerConfig",
    # Enums
    "CacheType",
    "DType",
    "EvictionPolicy",
    "ModelType",
    "PreemptionMode",
    "QuantizationType",
    "SchedulingPolicy",
]
