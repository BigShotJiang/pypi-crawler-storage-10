# SPDX-License-Identifier: Apache-2.0
"""MLX-specific configuration for Metal operations and optimizations."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class MLXConfig:
    """Configuration for MLX-specific optimizations and Metal operations."""

    # Metal buffer management
    max_buffer_size_mb: int = 512
    """Maximum size of individual Metal buffers in MB."""

    enable_metal_cache: bool = True
    """Enable Metal kernel compilation caching."""

    # Unified memory optimizations
    enable_zero_copy: bool = True
    """Enable zero-copy operations for unified memory."""

    enable_lazy_loading: bool = True
    """Enable lazy loading of model weights (reduces init memory)."""

    # Performance tuning
    metal_num_threads: Optional[int] = None
    """Number of Metal threads. If None, auto-detected."""

    enable_metal_graph: bool = True
    """Enable Metal Performance Shaders graph optimization."""

    # Quantization
    quantization_group_size: int = 64
    """Group size for quantization (affects quality/speed tradeoff)."""

    enable_quantized_cache: bool = True
    """Enable quantized KV cache (reduces memory, slight accuracy loss)."""

    # Attention optimizations
    use_flash_attention: bool = True
    """Use MLX flash attention implementation."""

    attention_score_threshold: Optional[float] = None
    """Threshold for sparse attention (None = dense attention)."""

    # Memory management
    enable_swap: bool = True
    """Enable swapping to system RAM when GPU memory full."""

    swap_threshold_gb: float = 1.0
    """Start swapping when available GPU memory < threshold (GB)."""

    # Compilation
    enable_jit: bool = True
    """Enable JIT compilation for MLX operations."""

    compile_timeout_seconds: int = 300
    """Timeout for Metal kernel compilation."""

    # Debugging
    enable_metal_debug: bool = False
    """Enable Metal debugging and validation layers (slow)."""

    verbose: bool = False
    """Enable verbose logging of MLX operations."""

    def validate(self) -> None:
        """Validate MLX configuration."""
        if self.max_buffer_size_mb <= 0:
            raise ValueError(
                f"max_buffer_size_mb must be positive, got {self.max_buffer_size_mb}"
            )

        if self.quantization_group_size <= 0:
            raise ValueError(
                f"quantization_group_size must be positive, "
                f"got {self.quantization_group_size}"
            )

        if self.swap_threshold_gb < 0:
            raise ValueError(
                f"swap_threshold_gb must be non-negative, "
                f"got {self.swap_threshold_gb}"
            )

        if self.compile_timeout_seconds <= 0:
            raise ValueError(
                f"compile_timeout_seconds must be positive, "
                f"got {self.compile_timeout_seconds}"
            )

        if (
            self.attention_score_threshold is not None
            and self.attention_score_threshold <= 0
        ):
            raise ValueError(
                f"attention_score_threshold must be positive, "
                f"got {self.attention_score_threshold}"
            )

    @classmethod
    def from_defaults(cls, enable_optimizations: bool = True) -> "MLXConfig":
        """
        Create MLXConfig with default settings.

        Args:
            enable_optimizations: Enable all optimizations (recommended for M4).

        Returns:
            MLXConfig with defaults.
        """
        return cls(
            enable_metal_cache=enable_optimizations,
            enable_zero_copy=enable_optimizations,
            enable_lazy_loading=enable_optimizations,
            enable_metal_graph=enable_optimizations,
            use_flash_attention=enable_optimizations,
        )

    def __str__(self) -> str:
        """String representation of MLX config."""
        opts = []
        if self.enable_zero_copy:
            opts.append("zero-copy")
        if self.use_flash_attention:
            opts.append("flash-attn")
        if self.enable_quantized_cache:
            opts.append("quant-cache")

        opts_str = ",".join(opts) if opts else "none"
        return f"MLXConfig(opts=[{opts_str}])"
