# SPDX-License-Identifier: Apache-2.0
"""Scheduler configuration for request scheduling and batching in MLX-LLM."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class SchedulingPolicy(str, Enum):
    """Policy for scheduling requests."""

    FCFS = "fcfs"
    """First Come First Served (FIFO)."""

    PRIORITY = "priority"
    """Priority-based scheduling."""

    SJF = "sjf"
    """Shortest Job First (based on estimated output length)."""


class PreemptionMode(str, Enum):
    """Preemption mode for handling memory pressure."""

    RECOMPUTE = "recompute"
    """Preempt and recompute from scratch when memory available."""

    SWAP = "swap"
    """Swap KV cache to CPU/disk."""

    NONE = "none"
    """No preemption (fails on OOM)."""


@dataclass
class SchedulerConfig:
    """Configuration for request scheduler."""

    # Batch constraints
    max_num_seqs: int = 256
    """Maximum number of sequences in a batch."""

    max_num_sequences: Optional[int] = None
    """Legacy alias for max_num_seqs."""

    max_num_batched_tokens: Optional[int] = None
    """Maximum total tokens in a batch. If None, no limit."""

    max_model_len: Optional[int] = None
    """Maximum model context length (for validation)."""

    max_paddings: int = 0
    """Maximum number of padding tokens in a batch (0 = no padding)."""

    def __post_init__(self):
        """Handle legacy parameters."""
        # Support max_num_sequences as alias for max_num_seqs
        if self.max_num_sequences is not None:
            self.max_num_seqs = self.max_num_sequences

    # Scheduling policy
    policy: SchedulingPolicy = SchedulingPolicy.FCFS
    """Scheduling policy for ordering requests."""

    # Preemption
    preemption_mode: PreemptionMode = PreemptionMode.SWAP
    """How to handle memory pressure (preemption)."""

    # Continuous batching
    enable_chunked_prefill: bool = True
    """Enable chunked prefill (process long prefills in chunks)."""

    max_num_on_the_fly: int = 1
    """Max number of requests processed simultaneously per iteration."""

    # Prefix caching
    enable_prefix_caching: bool = True
    """Enable automatic prefix caching for repeated prompts."""

    disable_sliding_window: bool = False
    """Disable sliding window attention (for models that support it)."""

    # Performance tuning
    delay_factor: float = 0.0
    """Delay factor for batching (wait for more requests). 0.0 = no delay."""

    # Speculative decoding
    num_speculative_tokens: int = 0
    """Number of tokens to speculatively decode (0 = disabled)."""

    # Lookahead scheduling
    num_lookahead_slots: int = 0
    """Number of lookahead slots for scheduling (0 = disabled)."""

    def validate(self) -> None:
        """Validate scheduler configuration."""
        if self.max_num_seqs <= 0:
            raise ValueError(
                f"max_num_seqs must be positive, got {self.max_num_seqs}"
            )

        if self.max_num_batched_tokens is not None and self.max_num_batched_tokens <= 0:
            raise ValueError(
                f"max_num_batched_tokens must be positive, "
                f"got {self.max_num_batched_tokens}"
            )

        if self.max_paddings < 0:
            raise ValueError(f"max_paddings must be non-negative, got {self.max_paddings}")

        if self.delay_factor < 0.0 or self.delay_factor > 1.0:
            raise ValueError(
                f"delay_factor must be in [0.0, 1.0], got {self.delay_factor}"
            )

        if self.num_speculative_tokens < 0:
            raise ValueError(
                f"num_speculative_tokens must be non-negative, "
                f"got {self.num_speculative_tokens}"
            )

        if self.num_lookahead_slots < 0:
            raise ValueError(
                f"num_lookahead_slots must be non-negative, "
                f"got {self.num_lookahead_slots}"
            )

        if self.max_num_on_the_fly <= 0:
            raise ValueError(
                f"max_num_on_the_fly must be positive, "
                f"got {self.max_num_on_the_fly}"
            )

    @classmethod
    def from_defaults(
        cls,
        max_num_seqs: int = 256,
        max_num_batched_tokens: Optional[int] = None,
    ) -> "SchedulerConfig":
        """
        Create SchedulerConfig with default settings.

        Args:
            max_num_seqs: Maximum sequences in batch.
            max_num_batched_tokens: Maximum tokens in batch.

        Returns:
            SchedulerConfig with defaults.
        """
        return cls(
            max_num_seqs=max_num_seqs,
            max_num_batched_tokens=max_num_batched_tokens,
        )

    def __str__(self) -> str:
        """String representation of scheduler config."""
        return (
            f"SchedulerConfig(max_seqs={self.max_num_seqs}, "
            f"policy={self.policy.value}, "
            f"preemption={self.preemption_mode.value})"
        )
