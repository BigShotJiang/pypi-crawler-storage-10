# SPDX-License-Identifier: Apache-2.0
"""Input preprocessing for MLX-LLM."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional

from mlxllm.inputs.data import (
    ProcessorInputs,
    SingletonPrompt,
    TextPrompt,
    TokenInputs,
    TokensPrompt,
    get_cache_salt,
    is_text_prompt,
    is_tokens_prompt,
    token_inputs,
)
from mlxllm.inputs.parse import get_prompt_type, validate_prompt

if TYPE_CHECKING:
    from mlxllm.config.model import ModelConfig

logger = logging.getLogger(__name__)


# Type alias for tokenizer (avoid hard dependency on transformers)
try:
    from transformers import PreTrainedTokenizer, PreTrainedTokenizerFast

    AnyTokenizer = PreTrainedTokenizer | PreTrainedTokenizerFast
except ImportError:
    AnyTokenizer = Any  # type: ignore


class InputPreprocessor:
    """
    Preprocesses prompts into model-ready inputs.

    This class handles:
    - Tokenization of text prompts
    - Truncation of long sequences
    - Cache salt propagation
    - Input validation

    Args:
        model_config: Model configuration.
        tokenizer: HuggingFace tokenizer instance.
    """

    def __init__(
        self,
        model_config: ModelConfig,
        tokenizer: Optional[AnyTokenizer] = None,
    ) -> None:
        """
        Initialize the input preprocessor.

        Args:
            model_config: Model configuration.
            tokenizer: Tokenizer for text processing.
        """
        self.model_config = model_config
        self.tokenizer = tokenizer

        # Cache max length from config
        self.max_model_len = model_config.max_model_len

        logger.debug(
            f"Initialized InputPreprocessor with max_model_len={self.max_model_len}"
        )

    # ==========================================================================
    # Tokenization
    # ==========================================================================

    def _tokenize_prompt(
        self,
        prompt: str,
        add_special_tokens: bool = True,
    ) -> list[int]:
        """
        Tokenize a text prompt.

        Args:
            prompt: Text to tokenize.
            add_special_tokens: Whether to add special tokens (BOS, EOS).

        Returns:
            List of token IDs.

        Raises:
            ValueError: If tokenizer is not available.
        """
        if self.tokenizer is None:
            raise ValueError(
                "Tokenizer is required for text prompts. "
                "Either provide prompt_token_ids or initialize with a tokenizer."
            )

        # Tokenize using HuggingFace tokenizer
        token_ids = self.tokenizer.encode(
            prompt,
            add_special_tokens=add_special_tokens,
        )

        logger.debug(
            f"Tokenized prompt of length {len(prompt)} chars "
            f"into {len(token_ids)} tokens"
        )

        return token_ids

    def _truncate_inputs(
        self,
        token_ids: list[int],
        max_length: Optional[int] = None,
        truncation_side: str = "right",
    ) -> list[int]:
        """
        Truncate token sequence to maximum length.

        Args:
            token_ids: Token IDs to truncate.
            max_length: Maximum length. If None, uses model_config.max_model_len.
            truncation_side: Which side to truncate ("left" or "right").

        Returns:
            Truncated token IDs.
        """
        if max_length is None:
            max_length = self.max_model_len

        if len(token_ids) <= max_length:
            return token_ids

        if truncation_side == "right":
            truncated = token_ids[:max_length]
        elif truncation_side == "left":
            truncated = token_ids[-max_length:]
        else:
            raise ValueError(
                f"Invalid truncation_side: {truncation_side}. "
                "Expected 'left' or 'right'"
            )

        logger.warning(
            f"Truncated input from {len(token_ids)} to {max_length} tokens "
            f"(side={truncation_side})"
        )

        return truncated

    # ==========================================================================
    # Input Processing
    # ==========================================================================

    def _process_text(
        self,
        prompt: TextPrompt,
        add_special_tokens: bool = True,
        truncate: bool = True,
    ) -> TokenInputs:
        """
        Process a text prompt into token inputs.

        Args:
            prompt: Text prompt to process.
            add_special_tokens: Whether to add special tokens.
            truncate: Whether to truncate to max length.

        Returns:
            TokenInputs with processed tokens.
        """
        # Tokenize the text
        text = prompt["prompt"]
        token_ids = self._tokenize_prompt(text, add_special_tokens=add_special_tokens)

        # Truncate if needed
        if truncate:
            token_ids = self._truncate_inputs(token_ids)

        # Get cache salt
        cache_salt = get_cache_salt(prompt)

        return token_inputs(prompt_token_ids=token_ids, cache_salt=cache_salt)

    def _process_tokens(
        self,
        prompt: TokensPrompt,
        truncate: bool = True,
    ) -> TokenInputs:
        """
        Process a pre-tokenized prompt.

        Args:
            prompt: Token prompt to process.
            truncate: Whether to truncate to max length.

        Returns:
            TokenInputs with processed tokens.
        """
        token_ids = prompt["prompt_token_ids"]

        # Truncate if needed
        if truncate:
            token_ids = self._truncate_inputs(token_ids)

        # Get cache salt
        cache_salt = get_cache_salt(prompt)

        return token_inputs(prompt_token_ids=token_ids, cache_salt=cache_salt)

    def _process_prompt(
        self,
        prompt: SingletonPrompt,
        add_special_tokens: bool = True,
        truncate: bool = True,
    ) -> TokenInputs:
        """
        Process a single prompt into token inputs.

        Args:
            prompt: Input prompt (text or tokens).
            add_special_tokens: Whether to add special tokens (for text prompts).
            truncate: Whether to truncate to max length.

        Returns:
            TokenInputs ready for model execution.

        Raises:
            ValueError: If prompt type is invalid.
        """
        # Validate prompt structure
        validate_prompt(prompt)

        # Route to appropriate processor
        if is_text_prompt(prompt):
            return self._process_text(
                prompt,  # type: ignore
                add_special_tokens=add_special_tokens,
                truncate=truncate,
            )
        elif is_tokens_prompt(prompt):
            return self._process_tokens(
                prompt,  # type: ignore
                truncate=truncate,
            )
        else:
            raise ValueError(f"Unknown prompt type: {get_prompt_type(prompt)}")

    # ==========================================================================
    # Public API
    # ==========================================================================

    def preprocess(
        self,
        prompt: SingletonPrompt,
        add_special_tokens: bool = True,
        truncate: bool = True,
    ) -> ProcessorInputs:
        """
        Preprocess a prompt into model-ready inputs.

        This is the main entry point for input preprocessing.

        Args:
            prompt: Input prompt (text or tokens).
            add_special_tokens: Whether to add special tokens (for text prompts).
            truncate: Whether to truncate to max length.

        Returns:
            ProcessorInputs ready for model execution.

        Examples:
            >>> preprocessor = InputPreprocessor(model_config, tokenizer)
            >>> # Text prompt
            >>> inputs = preprocessor.preprocess({"prompt": "Hello world"})
            >>> inputs["prompt_token_ids"]
            [1, 10994, 1917, 2]

            >>> # Pre-tokenized prompt
            >>> inputs = preprocessor.preprocess({"prompt_token_ids": [1, 10994, 1917, 2]})
            >>> inputs["prompt_token_ids"]
            [1, 10994, 1917, 2]
        """
        return self._process_prompt(
            prompt,
            add_special_tokens=add_special_tokens,
            truncate=truncate,
        )

    def preprocess_batch(
        self,
        prompts: list[SingletonPrompt],
        add_special_tokens: bool = True,
        truncate: bool = True,
    ) -> list[ProcessorInputs]:
        """
        Preprocess a batch of prompts.

        Args:
            prompts: List of input prompts.
            add_special_tokens: Whether to add special tokens (for text prompts).
            truncate: Whether to truncate to max length.

        Returns:
            List of ProcessorInputs ready for model execution.

        Examples:
            >>> preprocessor = InputPreprocessor(model_config, tokenizer)
            >>> prompts = [
            ...     {"prompt": "Hello world"},
            ...     {"prompt_token_ids": [1, 2, 3]},
            ... ]
            >>> batch = preprocessor.preprocess_batch(prompts)
            >>> len(batch)
            2
        """
        return [
            self.preprocess(
                prompt,
                add_special_tokens=add_special_tokens,
                truncate=truncate,
            )
            for prompt in prompts
        ]


# ==============================================================================
# Convenience Functions
# ==============================================================================


def create_preprocessor(
    model_config: ModelConfig,
    tokenizer: Optional[AnyTokenizer] = None,
) -> InputPreprocessor:
    """
    Create an input preprocessor.

    Args:
        model_config: Model configuration.
        tokenizer: Optional tokenizer instance.

    Returns:
        InputPreprocessor instance.
    """
    return InputPreprocessor(model_config, tokenizer)


def preprocess_prompt(
    prompt: SingletonPrompt,
    model_config: ModelConfig,
    tokenizer: Optional[AnyTokenizer] = None,
    add_special_tokens: bool = True,
    truncate: bool = True,
) -> ProcessorInputs:
    """
    Preprocess a single prompt (convenience function).

    Args:
        prompt: Input prompt.
        model_config: Model configuration.
        tokenizer: Optional tokenizer instance.
        add_special_tokens: Whether to add special tokens.
        truncate: Whether to truncate to max length.

    Returns:
        ProcessorInputs ready for model execution.
    """
    preprocessor = InputPreprocessor(model_config, tokenizer)
    return preprocessor.preprocess(
        prompt,
        add_special_tokens=add_special_tokens,
        truncate=truncate,
    )


def preprocess_batch(
    prompts: list[SingletonPrompt],
    model_config: ModelConfig,
    tokenizer: Optional[AnyTokenizer] = None,
    add_special_tokens: bool = True,
    truncate: bool = True,
) -> list[ProcessorInputs]:
    """
    Preprocess a batch of prompts (convenience function).

    Args:
        prompts: List of input prompts.
        model_config: Model configuration.
        tokenizer: Optional tokenizer instance.
        add_special_tokens: Whether to add special tokens.
        truncate: Whether to truncate to max length.

    Returns:
        List of ProcessorInputs ready for model execution.
    """
    preprocessor = InputPreprocessor(model_config, tokenizer)
    return preprocessor.preprocess_batch(
        prompts,
        add_special_tokens=add_special_tokens,
        truncate=truncate,
    )
