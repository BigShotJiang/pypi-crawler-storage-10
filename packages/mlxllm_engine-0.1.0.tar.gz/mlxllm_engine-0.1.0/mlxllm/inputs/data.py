# SPDX-License-Identifier: Apache-2.0
"""Input data structures for MLX-LLM."""

from __future__ import annotations

from typing import Any, TypedDict

try:
    from typing import NotRequired  # Python 3.11+
except ImportError:
    from typing_extensions import NotRequired


# ==============================================================================
# Input Prompt Types (User-Facing)
# ==============================================================================


class TextPrompt(TypedDict):
    """
    Text prompt input.

    The most common input type - raw text that needs tokenization.
    """

    prompt: str
    """The text to tokenize."""

    cache_salt: NotRequired[str | None]
    """Optional prefix caching salt for cache key generation."""


class TokensPrompt(TypedDict):
    """
    Pre-tokenized prompt input.

    Use this when you already have token IDs and want to skip tokenization.
    """

    prompt_token_ids: list[int]
    """Pre-tokenized token IDs."""

    prompt: NotRequired[str | None]
    """Optional original text (for debugging/logging)."""

    cache_salt: NotRequired[str | None]
    """Optional prefix caching salt."""


# Single prompt input can be text or tokens
SingletonPrompt = TextPrompt | TokensPrompt


# ==============================================================================
# Processed Input Types (Internal)
# ==============================================================================


class TokenInputs(TypedDict):
    """
    Processed token inputs ready for model execution.

    This is the output of preprocessing - standardized token representation.
    """

    type: str  # Always "token"
    """Type discriminant for union types."""

    prompt_token_ids: list[int]
    """Token IDs for the prompt."""

    cache_salt: NotRequired[str | None]
    """Caching metadata."""


# For MLX-LLM, we primarily use decoder-only models
DecoderOnlyInputs = TokenInputs

# Alias for processor output
ProcessorInputs = DecoderOnlyInputs


# ==============================================================================
# Helper Constructors
# ==============================================================================


def token_inputs(
    prompt_token_ids: list[int],
    cache_salt: str | None = None,
) -> TokenInputs:
    """
    Create TokenInputs with proper type annotation.

    Args:
        prompt_token_ids: Token IDs for the prompt.
        cache_salt: Optional caching salt.

    Returns:
        TokenInputs dictionary.
    """
    result: TokenInputs = {
        "type": "token",
        "prompt_token_ids": prompt_token_ids,
    }
    if cache_salt is not None:
        result["cache_salt"] = cache_salt
    return result


# ==============================================================================
# Type Guards
# ==============================================================================


def is_text_prompt(prompt: Any) -> bool:
    """Check if prompt is a TextPrompt."""
    return isinstance(prompt, dict) and "prompt" in prompt and isinstance(prompt["prompt"], str)


def is_tokens_prompt(prompt: Any) -> bool:
    """Check if prompt is a TokensPrompt."""
    return isinstance(prompt, dict) and "prompt_token_ids" in prompt


def is_token_inputs(inputs: Any) -> bool:
    """Check if inputs is TokenInputs."""
    return (
        isinstance(inputs, dict)
        and inputs.get("type") == "token"
        and "prompt_token_ids" in inputs
    )


# ==============================================================================
# Utility Functions
# ==============================================================================


def get_prompt_text(prompt: SingletonPrompt) -> str | None:
    """
    Extract text from a prompt if available.

    Args:
        prompt: Input prompt.

    Returns:
        Text string if available, None otherwise.
    """
    if is_text_prompt(prompt):
        return prompt["prompt"]  # type: ignore
    elif is_tokens_prompt(prompt):
        return prompt.get("prompt")  # type: ignore
    return None


def get_prompt_token_ids(prompt: SingletonPrompt) -> list[int] | None:
    """
    Extract token IDs from a prompt if available.

    Args:
        prompt: Input prompt.

    Returns:
        Token IDs if available, None otherwise.
    """
    if is_tokens_prompt(prompt):
        return prompt["prompt_token_ids"]  # type: ignore
    return None


def get_cache_salt(prompt: SingletonPrompt) -> str | None:
    """
    Extract cache salt from a prompt.

    Args:
        prompt: Input prompt.

    Returns:
        Cache salt if available, None otherwise.
    """
    if isinstance(prompt, dict):
        return prompt.get("cache_salt")  # type: ignore
    return None
