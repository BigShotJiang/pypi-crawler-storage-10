# SPDX-License-Identifier: Apache-2.0
"""
Input processing module for MLX-LLM.

This module provides data structures and utilities for processing input prompts
into model-ready format. It handles:

- Text prompts (strings that need tokenization)
- Token prompts (pre-tokenized input)
- Batch processing
- Truncation and validation
- Cache key generation

Example Usage:
    >>> from mlxllm.inputs import TextPrompt, InputPreprocessor
    >>> from mlxllm.config import ModelConfig
    >>> from transformers import AutoTokenizer
    >>>
    >>> # Create text prompt
    >>> prompt: TextPrompt = {"prompt": "Hello world"}
    >>>
    >>> # Preprocess with tokenizer
    >>> config = ModelConfig(model_name="gpt2", max_model_len=2048)
    >>> tokenizer = AutoTokenizer.from_pretrained("gpt2")
    >>> preprocessor = InputPreprocessor(config, tokenizer)
    >>> inputs = preprocessor.preprocess(prompt)
    >>> print(inputs["prompt_token_ids"])
    [15496, 995]

Input Types:
    - TextPrompt: Raw text that needs tokenization
    - TokensPrompt: Pre-tokenized input (list of token IDs)
    - TokenInputs: Processed input ready for model execution

The preprocessing pipeline:
    1. Parse: Identify input type (text or tokens)
    2. Tokenize: Convert text to tokens (if needed)
    3. Truncate: Ensure length <= max_model_len
    4. Package: Create TokenInputs with metadata
"""

from __future__ import annotations

# Data structures
from mlxllm.inputs.data import (
    DecoderOnlyInputs,
    ProcessorInputs,
    SingletonPrompt,
    TextPrompt,
    TokenInputs,
    TokensPrompt,
    get_cache_salt,
    get_prompt_text,
    get_prompt_token_ids,
    is_text_prompt,
    is_token_inputs,
    is_tokens_prompt,
    token_inputs,
)

# Parsing utilities
from mlxllm.inputs.parse import (
    get_prompt_type,
    normalize_prompt,
    parse_raw_prompts,
    validate_prompt,
    validate_prompts,
)

# Preprocessing
from mlxllm.inputs.preprocess import (
    InputPreprocessor,
    create_preprocessor,
    preprocess_batch,
    preprocess_prompt,
)

__all__ = [
    # Data structures
    "TextPrompt",
    "TokensPrompt",
    "SingletonPrompt",
    "TokenInputs",
    "DecoderOnlyInputs",
    "ProcessorInputs",
    # Data utilities
    "token_inputs",
    "is_text_prompt",
    "is_tokens_prompt",
    "is_token_inputs",
    "get_prompt_text",
    "get_prompt_token_ids",
    "get_cache_salt",
    # Parsing
    "parse_raw_prompts",
    "get_prompt_type",
    "validate_prompt",
    "validate_prompts",
    "normalize_prompt",
    # Preprocessing
    "InputPreprocessor",
    "create_preprocessor",
    "preprocess_prompt",
    "preprocess_batch",
]
