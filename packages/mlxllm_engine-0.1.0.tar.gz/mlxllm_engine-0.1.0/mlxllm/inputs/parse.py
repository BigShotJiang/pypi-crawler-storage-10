# SPDX-License-Identifier: Apache-2.0
"""Input parsing utilities for MLX-LLM."""

from __future__ import annotations

from typing import Any

from mlxllm.inputs.data import (
    SingletonPrompt,
    TextPrompt,
    TokensPrompt,
    is_text_prompt,
    is_tokens_prompt,
)


# ==============================================================================
# Raw Prompt Parsing
# ==============================================================================


def parse_raw_prompts(
    prompt: str | list[str] | list[int] | list[list[int]],
) -> list[SingletonPrompt]:
    """
    Parse raw prompt inputs into standardized prompt format.

    This handles the common cases of input data:
    - Single string: "Hello world"
    - List of strings: ["Hello", "World"]
    - Single token sequence: [1, 2, 3]
    - List of token sequences: [[1, 2], [3, 4]]

    Args:
        prompt: Raw prompt input in various formats.

    Returns:
        List of SingletonPrompt dictionaries.

    Raises:
        ValueError: If prompt format is invalid.

    Examples:
        >>> parse_raw_prompts("Hello world")
        [{"prompt": "Hello world"}]

        >>> parse_raw_prompts(["Hello", "World"])
        [{"prompt": "Hello"}, {"prompt": "World"}]

        >>> parse_raw_prompts([1, 2, 3])
        [{"prompt_token_ids": [1, 2, 3]}]

        >>> parse_raw_prompts([[1, 2], [3, 4]])
        [{"prompt_token_ids": [1, 2]}, {"prompt_token_ids": [3, 4]}]
    """
    # Case 1: Single string
    if isinstance(prompt, str):
        text_prompt: TextPrompt = {"prompt": prompt}
        return [text_prompt]

    # Case 2: List (need to determine what kind)
    if isinstance(prompt, list):
        if not prompt:
            raise ValueError("Empty prompt list is not allowed")

        first_elem = prompt[0]

        # Case 2a: List of strings
        if isinstance(first_elem, str):
            if not all(isinstance(p, str) for p in prompt):
                raise ValueError("All elements must be strings if first element is a string")
            result: list[SingletonPrompt] = []
            for text in prompt:
                text_prompt_item: TextPrompt = {"prompt": text}  # type: ignore
                result.append(text_prompt_item)
            return result

        # Case 2b: List of integers (single token sequence)
        if isinstance(first_elem, int):
            if not all(isinstance(t, int) for t in prompt):
                raise ValueError("All elements must be integers if first element is an integer")
            tokens_prompt: TokensPrompt = {"prompt_token_ids": prompt}  # type: ignore
            return [tokens_prompt]

        # Case 2c: List of lists (multiple token sequences)
        if isinstance(first_elem, list):
            if not all(isinstance(seq, list) for seq in prompt):
                raise ValueError("All elements must be lists if first element is a list")

            result_tokens: list[SingletonPrompt] = []
            for seq in prompt:
                if not all(isinstance(t, int) for t in seq):  # type: ignore
                    raise ValueError("All token IDs must be integers")
                tokens_prompt_item: TokensPrompt = {"prompt_token_ids": seq}  # type: ignore
                result_tokens.append(tokens_prompt_item)
            return result_tokens

        raise ValueError(
            f"Invalid prompt list element type: {type(first_elem).__name__}. "
            "Expected str, int, or list[int]"
        )

    raise ValueError(
        f"Invalid prompt type: {type(prompt).__name__}. "
        "Expected str, list[str], list[int], or list[list[int]]"
    )


# ==============================================================================
# Prompt Type Detection
# ==============================================================================


def get_prompt_type(prompt: SingletonPrompt) -> str:
    """
    Determine the type of a prompt.

    Args:
        prompt: Input prompt.

    Returns:
        Prompt type string: "text" or "tokens".

    Raises:
        ValueError: If prompt type cannot be determined.
    """
    if is_text_prompt(prompt):
        return "text"
    elif is_tokens_prompt(prompt):
        return "tokens"
    else:
        raise ValueError(f"Unable to determine prompt type from: {prompt}")


def validate_prompt(prompt: SingletonPrompt) -> None:
    """
    Validate a prompt structure.

    Args:
        prompt: Input prompt to validate.

    Raises:
        ValueError: If prompt is invalid.
    """
    if not isinstance(prompt, dict):
        raise ValueError(f"Prompt must be a dictionary, got {type(prompt).__name__}")

    # Check that it has at least one required field
    if not is_text_prompt(prompt) and not is_tokens_prompt(prompt):
        raise ValueError(
            "Prompt must have either 'prompt' (str) or 'prompt_token_ids' (list[int])"
        )

    # Validate text prompt
    if is_text_prompt(prompt):
        text = prompt["prompt"]  # type: ignore
        if not isinstance(text, str):
            raise ValueError(f"'prompt' must be a string, got {type(text).__name__}")
        if not text:
            raise ValueError("'prompt' cannot be empty string")

    # Validate tokens prompt
    if is_tokens_prompt(prompt):
        token_ids = prompt["prompt_token_ids"]  # type: ignore
        if not isinstance(token_ids, list):
            raise ValueError(
                f"'prompt_token_ids' must be a list, got {type(token_ids).__name__}"
            )
        if not token_ids:
            raise ValueError("'prompt_token_ids' cannot be empty list")
        if not all(isinstance(tid, int) for tid in token_ids):
            raise ValueError("All elements in 'prompt_token_ids' must be integers")

    # Validate cache_salt if present
    if "cache_salt" in prompt:
        cache_salt = prompt.get("cache_salt")  # type: ignore
        if cache_salt is not None and not isinstance(cache_salt, str):
            raise ValueError(
                f"'cache_salt' must be a string or None, got {type(cache_salt).__name__}"
            )


# ==============================================================================
# Batch Processing
# ==============================================================================


def validate_prompts(prompts: list[SingletonPrompt]) -> None:
    """
    Validate a batch of prompts.

    Args:
        prompts: List of prompts to validate.

    Raises:
        ValueError: If any prompt is invalid.
    """
    if not isinstance(prompts, list):
        raise ValueError(f"Prompts must be a list, got {type(prompts).__name__}")

    if not prompts:
        raise ValueError("Prompts list cannot be empty")

    for i, prompt in enumerate(prompts):
        try:
            validate_prompt(prompt)
        except ValueError as e:
            raise ValueError(f"Invalid prompt at index {i}: {e}") from e


def normalize_prompt(prompt: Any) -> SingletonPrompt:
    """
    Normalize various prompt formats to SingletonPrompt.

    Args:
        prompt: Prompt in various formats (str, list[int], dict).

    Returns:
        Normalized SingletonPrompt.

    Raises:
        ValueError: If prompt format is unsupported.
    """
    # Already a dict prompt
    if isinstance(prompt, dict):
        validate_prompt(prompt)
        return prompt  # type: ignore

    # String prompt
    if isinstance(prompt, str):
        text_prompt: TextPrompt = {"prompt": prompt}
        return text_prompt

    # Token IDs prompt
    if isinstance(prompt, list) and prompt and all(isinstance(t, int) for t in prompt):
        tokens_prompt: TokensPrompt = {"prompt_token_ids": prompt}
        return tokens_prompt

    raise ValueError(
        f"Cannot normalize prompt of type {type(prompt).__name__}. "
        "Expected str, list[int], or dict with 'prompt' or 'prompt_token_ids'"
    )
