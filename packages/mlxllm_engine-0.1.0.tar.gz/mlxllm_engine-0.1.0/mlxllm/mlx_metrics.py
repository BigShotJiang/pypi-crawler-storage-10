# SPDX-License-Identifier: Apache-2.0
"""Performance metrics tracking for MLX-LLM.

This module provides utilities for tracking and reporting performance metrics
including throughput, latency, memory usage, and token statistics.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import mlx.core as mx


@dataclass
class PerformanceMetrics:
    """Performance metrics for inference."""

    # Throughput metrics
    total_tokens_generated: int = 0
    """Total number of tokens generated."""

    total_requests_processed: int = 0
    """Total number of requests completed."""

    # Latency metrics (in seconds)
    total_time: float = 0.0
    """Total inference time."""

    total_prefill_time: float = 0.0
    """Total time spent in prefill phase."""

    total_decode_time: float = 0.0
    """Total time spent in decode phase."""

    # Token timing
    time_to_first_token: list[float] = field(default_factory=list)
    """Time to first token for each request."""

    inter_token_latency: list[float] = field(default_factory=list)
    """Inter-token latency measurements."""

    # Memory metrics
    peak_memory_mb: float = 0.0
    """Peak memory usage in MB."""

    kv_cache_usage_mb: float = 0.0
    """KV cache memory usage in MB."""

    @property
    def throughput_tokens_per_sec(self) -> float:
        """Get throughput in tokens per second."""
        if self.total_time <= 0:
            return 0.0
        return self.total_tokens_generated / self.total_time

    @property
    def average_ttft(self) -> float:
        """Get average time to first token."""
        if not self.time_to_first_token:
            return 0.0
        return sum(self.time_to_first_token) / len(self.time_to_first_token)

    @property
    def average_inter_token_latency(self) -> float:
        """Get average inter-token latency."""
        if not self.inter_token_latency:
            return 0.0
        return sum(self.inter_token_latency) / len(self.inter_token_latency)

    @property
    def p50_ttft(self) -> float:
        """Get P50 time to first token."""
        if not self.time_to_first_token:
            return 0.0
        sorted_ttft = sorted(self.time_to_first_token)
        return sorted_ttft[len(sorted_ttft) // 2]

    @property
    def p99_ttft(self) -> float:
        """Get P99 time to first token."""
        if not self.time_to_first_token:
            return 0.0
        sorted_ttft = sorted(self.time_to_first_token)
        idx = int(len(sorted_ttft) * 0.99)
        return sorted_ttft[min(idx, len(sorted_ttft) - 1)]

    def to_dict(self) -> dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "total_tokens_generated": self.total_tokens_generated,
            "total_requests_processed": self.total_requests_processed,
            "throughput_tokens_per_sec": self.throughput_tokens_per_sec,
            "total_time_sec": self.total_time,
            "prefill_time_sec": self.total_prefill_time,
            "decode_time_sec": self.total_decode_time,
            "average_ttft_sec": self.average_ttft,
            "p50_ttft_sec": self.p50_ttft,
            "p99_ttft_sec": self.p99_ttft,
            "average_inter_token_latency_sec": self.average_inter_token_latency,
            "peak_memory_mb": self.peak_memory_mb,
            "kv_cache_usage_mb": self.kv_cache_usage_mb,
        }


class MetricsTracker:
    """Track performance metrics during inference."""

    def __init__(self):
        """Initialize metrics tracker."""
        self.metrics = PerformanceMetrics()
        self._request_start_times: dict[str, float] = {}
        self._request_first_token_times: dict[str, float] = {}
        self._request_last_token_times: dict[str, float] = {}

    def start_request(self, request_id: str) -> None:
        """Mark the start of a request."""
        self._request_start_times[request_id] = time.perf_counter()

    def record_first_token(self, request_id: str) -> None:
        """Record time of first token for a request."""
        if request_id not in self._request_start_times:
            return

        current_time = time.perf_counter()
        self._request_first_token_times[request_id] = current_time

        # Calculate TTFT
        ttft = current_time - self._request_start_times[request_id]
        self.metrics.time_to_first_token.append(ttft)
        self._request_last_token_times[request_id] = current_time

    def record_token(self, request_id: str) -> None:
        """Record generation of a token."""
        current_time = time.perf_counter()

        # Calculate inter-token latency
        if request_id in self._request_last_token_times:
            inter_token = current_time - self._request_last_token_times[request_id]
            self.metrics.inter_token_latency.append(inter_token)

        self._request_last_token_times[request_id] = current_time
        self.metrics.total_tokens_generated += 1

    def finish_request(self, request_id: str, num_tokens: int) -> None:
        """Mark completion of a request."""
        if request_id not in self._request_start_times:
            return

        # Update metrics
        self.metrics.total_requests_processed += 1

        # Clean up tracking
        self._request_start_times.pop(request_id, None)
        self._request_first_token_times.pop(request_id, None)
        self._request_last_token_times.pop(request_id, None)

    def record_prefill_time(self, duration: float) -> None:
        """Record time spent in prefill phase."""
        self.metrics.total_prefill_time += duration
        self.metrics.total_time += duration

    def record_decode_time(self, duration: float) -> None:
        """Record time spent in decode phase."""
        self.metrics.total_decode_time += duration
        self.metrics.total_time += duration

    def update_memory_usage(self, peak_mb: float, kv_cache_mb: float) -> None:
        """Update memory usage metrics."""
        self.metrics.peak_memory_mb = max(self.metrics.peak_memory_mb, peak_mb)
        self.metrics.kv_cache_usage_mb = kv_cache_mb

    def get_metrics(self) -> PerformanceMetrics:
        """Get current metrics."""
        return self.metrics

    def reset(self) -> None:
        """Reset all metrics."""
        self.metrics = PerformanceMetrics()
        self._request_start_times.clear()
        self._request_first_token_times.clear()
        self._request_last_token_times.clear()


def get_metal_memory_usage() -> float:
    """
    Get current Metal GPU memory usage in MB.

    Returns:
        Memory usage in megabytes.
    """
    try:
        # MLX memory stats
        stats = mx.metal.get_active_memory()
        return stats / (1024 * 1024)  # Convert to MB
    except Exception:
        return 0.0


def print_metrics_summary(metrics: PerformanceMetrics) -> None:
    """
    Print a formatted summary of performance metrics.

    Args:
        metrics: Performance metrics to display.
    """
    print("\n=== Performance Metrics ===")
    print(f"Throughput: {metrics.throughput_tokens_per_sec:.2f} tokens/sec")
    print(f"Total Tokens: {metrics.total_tokens_generated}")
    print(f"Total Requests: {metrics.total_requests_processed}")
    print(f"\nLatency:")
    print(f"  Average TTFT: {metrics.average_ttft * 1000:.2f} ms")
    print(f"  P50 TTFT: {metrics.p50_ttft * 1000:.2f} ms")
    print(f"  P99 TTFT: {metrics.p99_ttft * 1000:.2f} ms")
    print(f"  Avg Inter-token: {metrics.average_inter_token_latency * 1000:.2f} ms")
    print(f"\nTime Breakdown:")
    print(f"  Total: {metrics.total_time:.2f} sec")
    print(f"  Prefill: {metrics.total_prefill_time:.2f} sec")
    print(f"  Decode: {metrics.total_decode_time:.2f} sec")
    print(f"\nMemory:")
    print(f"  Peak: {metrics.peak_memory_mb:.2f} MB")
    print(f"  KV Cache: {metrics.kv_cache_usage_mb:.2f} MB")
    print("=" * 30)
