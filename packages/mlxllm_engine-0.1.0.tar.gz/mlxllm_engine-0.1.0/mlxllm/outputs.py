# SPDX-License-Identifier: Apache-2.0
"""Output data structures for MLX-LLM requests."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class CompletionOutput:
    """Output for a single completion sequence."""

    index: int
    """Index of this completion in the request."""

    text: str
    """Generated text."""

    token_ids: list[int]
    """Generated token IDs."""

    cumulative_logprob: float
    """Cumulative log probability of the sequence."""

    logprobs: list[dict[int, float]] | None = None
    """Log probabilities for each token. {token_id: logprob}."""

    finish_reason: str | None = None
    """Reason for completion: 'stop', 'length', 'abort', etc."""

    stop_reason: str | int | None = None
    """Specific stop string or token ID that triggered completion."""

    def __repr__(self) -> str:
        """String representation."""
        text_preview = self.text[:50] + "..." if len(self.text) > 50 else self.text
        return (
            f"CompletionOutput(index={self.index}, "
            f"text='{text_preview}', "
            f"tokens={len(self.token_ids)}, "
            f"finish={self.finish_reason})"
        )


@dataclass
class RequestOutput:
    """Output for a single request (may have multiple completions)."""

    request_id: str
    """Unique request identifier."""

    prompt: str | None = None
    """Input prompt text."""

    prompt_token_ids: list[int] | None = None
    """Input prompt token IDs."""

    prompt_logprobs: list[dict[int, float]] | None = None
    """Log probabilities for prompt tokens (if requested)."""

    outputs: list[CompletionOutput] = field(default_factory=list)
    """List of completion outputs."""

    finished: bool = False
    """Whether all completions are finished."""

    metrics: dict[str, Any] | None = None
    """Performance metrics (latency, throughput, etc.)."""

    @property
    def num_outputs(self) -> int:
        """Number of completion outputs."""
        return len(self.outputs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"RequestOutput(id={self.request_id}, "
            f"outputs={self.num_outputs}, "
            f"finished={self.finished})"
        )


@dataclass
class EmbeddingOutput:
    """Output for an embedding request."""

    index: int
    """Index of this embedding in the request."""

    embedding: list[float]
    """Embedding vector."""

    def __repr__(self) -> str:
        """String representation."""
        return f"EmbeddingOutput(index={self.index}, dim={len(self.embedding)})"


@dataclass
class EmbeddingRequestOutput:
    """Output for an embedding request."""

    request_id: str
    """Unique request identifier."""

    outputs: list[EmbeddingOutput]
    """List of embeddings."""

    finished: bool = True
    """Whether embedding computation is finished."""

    @property
    def num_outputs(self) -> int:
        """Number of embeddings."""
        return len(self.outputs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"EmbeddingRequestOutput(id={self.request_id}, "
            f"outputs={self.num_outputs})"
        )


@dataclass
class PoolingOutput:
    """Output for a pooling request (sentence embeddings)."""

    index: int
    """Index of this output in the request."""

    embedding: list[float]
    """Pooled embedding vector."""

    def __repr__(self) -> str:
        """String representation."""
        return f"PoolingOutput(index={self.index}, dim={len(self.embedding)})"


@dataclass
class PoolingRequestOutput:
    """Output for a pooling request."""

    request_id: str
    """Unique request identifier."""

    outputs: list[PoolingOutput]
    """List of pooled embeddings."""

    finished: bool = True
    """Whether pooling is finished."""

    @property
    def num_outputs(self) -> int:
        """Number of pooled embeddings."""
        return len(self.outputs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"PoolingRequestOutput(id={self.request_id}, "
            f"outputs={self.num_outputs})"
        )


@dataclass
class ClassificationOutput:
    """Output for a classification request."""

    index: int
    """Index of this output in the request."""

    label: str
    """Predicted label."""

    score: float
    """Confidence score for the label."""

    logits: list[float] | None = None
    """Raw logits for all classes (if requested)."""

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"ClassificationOutput(index={self.index}, "
            f"label={self.label}, "
            f"score={self.score:.4f})"
        )


@dataclass
class ClassificationRequestOutput:
    """Output for a classification request."""

    request_id: str
    """Unique request identifier."""

    outputs: list[ClassificationOutput]
    """List of classification outputs."""

    finished: bool = True
    """Whether classification is finished."""

    @property
    def num_outputs(self) -> int:
        """Number of classification outputs."""
        return len(self.outputs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"ClassificationRequestOutput(id={self.request_id}, "
            f"outputs={self.num_outputs})"
        )


@dataclass
class ScoringOutput:
    """Output for a scoring request (e.g., reranking)."""

    index: int
    """Index of this output in the request."""

    score: float
    """Relevance score."""

    def __repr__(self) -> str:
        """String representation."""
        return f"ScoringOutput(index={self.index}, score={self.score:.4f})"


@dataclass
class ScoringRequestOutput:
    """Output for a scoring request."""

    request_id: str
    """Unique request identifier."""

    outputs: list[ScoringOutput]
    """List of scores."""

    finished: bool = True
    """Whether scoring is finished."""

    @property
    def num_outputs(self) -> int:
        """Number of scores."""
        return len(self.outputs)

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"ScoringRequestOutput(id={self.request_id}, "
            f"outputs={self.num_outputs})"
        )
