# SPDX-License-Identifier: Apache-2.0
"""MLX-LLM: High-performance LLM inference optimized for Apple Silicon.

MLX-LLM is a vLLM-style inference engine built on MLX/Metal for native
acceleration on M-series chips. It features:

- Paged attention with prefix caching
- Continuous batching for high throughput
- Quantization support (Q4_0, Q4_1, Q8_0)
- Zero-copy unified memory operations
- Metal-optimized kernels

Example:
    >>> from mlxllm import LLMEngine, SamplingParams
    >>>
    >>> # Create engine
    >>> engine = LLMEngine(
    ...     model="mlx-community/Qwen2.5-Coder-7B-4bit",
    ...     max_model_len=8192,
    ... )
    >>>
    >>> # Generate text
    >>> sampling_params = SamplingParams(temperature=0.7, max_tokens=100)
    >>> outputs = engine.generate("def fibonacci(n):", sampling_params)
    >>> print(outputs[0].text)
"""

# Load MLX operations module - provides device management and utilities
# For tensor operations, use mlx.core directly in Python
try:
    import mlxllm.mlx_ops  # noqa: F401
except ImportError as e:
    import warnings
    warnings.warn(
        f"Failed to import mlxllm.mlx_ops: {e}\n"
        "Device management features may not be available. "
        "Ensure nanobind is installed and C++ extensions are built.",
        ImportWarning
    )

from mlxllm.config import (
    CacheConfig,
    CacheType,
    DeviceConfig,
    DType,
    EvictionPolicy,
    KVCacheConfig,
    MetalDeviceInfo,
    MLXConfig,
    ModelConfig,
    PreemptionMode,
    QuantizationType,
    SchedulerConfig,
    SchedulingPolicy,
)
from mlxllm.engine import AsyncEngineArgs, EngineArgs
from mlxllm.engine.async_llm_engine import AsyncLLMEngine
from mlxllm.engine.llm_engine import LLMEngine
from mlxllm.entry_points.llm import LLM
from mlxllm.inputs import (
    DecoderOnlyInputs,
    InputPreprocessor,
    ProcessorInputs,
    SingletonPrompt,
    TextPrompt,
    TokenInputs,
    TokensPrompt,
    create_preprocessor,
    get_cache_salt,
    get_prompt_text,
    get_prompt_token_ids,
    is_text_prompt,
    is_token_inputs,
    is_tokens_prompt,
    normalize_prompt,
    parse_raw_prompts,
    preprocess_batch,
    preprocess_prompt,
    token_inputs,
    validate_prompt,
    validate_prompts,
)
from mlxllm.outputs import (
    ClassificationOutput,
    ClassificationRequestOutput,
    CompletionOutput,
    EmbeddingOutput,
    EmbeddingRequestOutput,
    PoolingOutput,
    PoolingRequestOutput,
    RequestOutput,
    ScoringOutput,
    ScoringRequestOutput,
)
from mlxllm.pooling_params import PoolingParams, PoolingType
from mlxllm.sampling_params import SamplingParams
from mlxllm.sequence import Sequence, SequenceData, SequenceGroup, SequenceStatus
from mlxllm.tasks import TaskType

__version__ = "0.1.0"

__all__ = [
    # Version
    "__version__",
    # High-level API
    "LLM",
    # Engines
    "LLMEngine",
    "AsyncLLMEngine",
    "EngineArgs",
    "AsyncEngineArgs",
    # Config
    "CacheConfig",
    "CacheType",
    "DeviceConfig",
    "DType",
    "EvictionPolicy",
    "KVCacheConfig",
    "MetalDeviceInfo",
    "MLXConfig",
    "ModelConfig",
    "PreemptionMode",
    "QuantizationType",
    "SchedulerConfig",
    "SchedulingPolicy",
    # Inputs
    "TextPrompt",
    "TokensPrompt",
    "SingletonPrompt",
    "TokenInputs",
    "DecoderOnlyInputs",
    "ProcessorInputs",
    "InputPreprocessor",
    "create_preprocessor",
    "preprocess_prompt",
    "preprocess_batch",
    "parse_raw_prompts",
    "normalize_prompt",
    "validate_prompt",
    "validate_prompts",
    "token_inputs",
    "is_text_prompt",
    "is_tokens_prompt",
    "is_token_inputs",
    "get_prompt_text",
    "get_prompt_token_ids",
    "get_cache_salt",
    # Outputs
    "ClassificationOutput",
    "ClassificationRequestOutput",
    "CompletionOutput",
    "EmbeddingOutput",
    "EmbeddingRequestOutput",
    "PoolingOutput",
    "PoolingRequestOutput",
    "RequestOutput",
    "ScoringOutput",
    "ScoringRequestOutput",
    # Parameters
    "PoolingParams",
    "PoolingType",
    "SamplingParams",
    # Sequence
    "Sequence",
    "SequenceData",
    "SequenceGroup",
    "SequenceStatus",
    # Tasks
    "TaskType",
]
