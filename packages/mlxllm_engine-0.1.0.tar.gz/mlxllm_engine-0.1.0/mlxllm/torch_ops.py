"""
Torch operations loader for mlxllm.

This module ensures that torch.ops.mlxllm.* operations are registered by loading
the compiled C++ extension. Import this module before using any torch.ops.mlxllm operations.

Example:
    >>> import mlxllm.torch_ops  # Registers torch.ops.mlxllm operations
    >>> import torch
    >>> torch.ops.mlxllm.silu_and_mul(output, input)
"""

import torch

# Load the mlxllm torch extension library
# This registers all torch.ops.mlxllm.* operations
try:
    # Try to import the extension module directly
    import csrc.mlxllm as _mlxllm_ops_module
    _TORCH_OPS_LOADED = True
except ImportError:
    # If direct import fails, try loading as a shared library
    try:
        import os
        import sys

        # Find the mlxllm.so file
        csrc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'csrc')
        mlxllm_so = os.path.join(csrc_path, 'mlxllm.so')

        if os.path.exists(mlxllm_so):
            torch.ops.load_library(mlxllm_so)
            _TORCH_OPS_LOADED = True
        else:
            _TORCH_OPS_LOADED = False
            import warnings
            warnings.warn(
                f"mlxllm torch operations not found at {mlxllm_so}. "
                "torch.ops.mlxllm.* operations will not be available. "
                "Build the C++ extensions with: cd build && cmake .. && make && make install",
                RuntimeWarning
            )
    except Exception as e:
        _TORCH_OPS_LOADED = False
        import warnings
        warnings.warn(
            f"Failed to load mlxllm torch operations: {e}. "
            "torch.ops.mlxllm.* operations will not be available.",
            RuntimeWarning
        )


def is_available() -> bool:
    """Check if torch.ops.mlxllm operations are available."""
    return _TORCH_OPS_LOADED


def list_operations():
    """List all available torch.ops.mlxllm operations."""
    if not _TORCH_OPS_LOADED:
        return []

    return [op for op in dir(torch.ops.mlxllm) if not op.startswith('_')]


__all__ = ['is_available', 'list_operations']
