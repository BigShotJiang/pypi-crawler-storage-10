# SPDX-License-Identifier: Apache-2.0
"""Unified multimodal processing pipeline for MLX-LLM."""

from __future__ import annotations

from typing import Any

import mlx.core as mx

from mlxllm.multimodal.audio import AudioProcessor
from mlxllm.multimodal.image import ImageProcessor
from mlxllm.multimodal.inputs import ModalityType, MultimodalInput
from mlxllm.multimodal.video import VideoProcessor


class MultimodalProcessor:
    """Unified processor for all modalities."""

    def __init__(self):
        """Initialize multimodal processor."""
        self.image_processor = ImageProcessor()
        self.video_processor = VideoProcessor()
        self.audio_processor = AudioProcessor()

    def process(self, inputs: list[MultimodalInput]) -> dict[str, Any]:
        """
        Process multimodal inputs.

        Args:
            inputs: List of multimodal inputs.

        Returns:
            Dictionary of processed inputs by modality.
        """
        processed = {
            "text": [],
            "image_embeddings": [],
            "video_embeddings": [],
            "audio_embeddings": [],
        }

        for input_item in inputs:
            if input_item.modality == ModalityType.TEXT:
                processed["text"].append(input_item.data)

            elif input_item.modality == ModalityType.IMAGE:
                image_processed = self.image_processor.preprocess(input_item.data)
                processed["image_embeddings"].append(image_processed)

            elif input_item.modality == ModalityType.VIDEO:
                video_processed = self.video_processor.preprocess(input_item.data)
                processed["video_embeddings"].append(video_processed)

            elif input_item.modality == ModalityType.AUDIO:
                audio_processed = self.audio_processor.preprocess(input_item.data)
                processed["audio_embeddings"].append(audio_processed)

        return processed

    def merge_embeddings(
        self,
        text_embeds: mx.array,
        image_embeds: list[mx.array] | None = None,
        video_embeds: list[mx.array] | None = None,
        audio_embeds: list[mx.array] | None = None,
    ) -> mx.array:
        """
        Merge embeddings from different modalities.

        Args:
            text_embeds: Text embeddings.
            image_embeds: Image embeddings.
            video_embeds: Video embeddings.
            audio_embeds: Audio embeddings.

        Returns:
            Merged embeddings.
        """
        all_embeds = [text_embeds]

        if image_embeds:
            all_embeds.extend(image_embeds)

        if video_embeds:
            all_embeds.extend(video_embeds)

        if audio_embeds:
            all_embeds.extend(audio_embeds)

        # Concatenate along sequence dimension
        return mx.concatenate(all_embeds, axis=1) if len(all_embeds) > 1 else text_embeds
