# SPDX-License-Identifier: Apache-2.0
"""Caching for multimodal embeddings in MLX-LLM."""

from __future__ import annotations

from typing import Any

import mlx.core as mx


class MultimodalCache:
    """Cache for preprocessed multimodal data."""

    def __init__(self, max_size: int = 1000):
        """
        Initialize multimodal cache.

        Args:
            max_size: Maximum number of cached items.
        """
        self.max_size = max_size
        self._cache: dict[str, mx.array] = {}
        self._access_order: list[str] = []

    def get(self, key: str) -> mx.array | None:
        """
        Get cached embedding.

        Args:
            key: Cache key.

        Returns:
            Cached embedding or None.
        """
        if key in self._cache:
            # Update access order (LRU)
            self._access_order.remove(key)
            self._access_order.append(key)
            return self._cache[key]
        return None

    def put(self, key: str, embedding: mx.array) -> None:
        """
        Put embedding in cache.

        Args:
            key: Cache key.
            embedding: Embedding to cache.
        """
        # Evict if necessary
        if len(self._cache) >= self.max_size and key not in self._cache:
            oldest_key = self._access_order.pop(0)
            del self._cache[oldest_key]

        # Add to cache
        self._cache[key] = embedding

        # Update access order
        if key in self._access_order:
            self._access_order.remove(key)
        self._access_order.append(key)

    def clear(self) -> None:
        """Clear all cached embeddings."""
        self._cache.clear()
        self._access_order.clear()
