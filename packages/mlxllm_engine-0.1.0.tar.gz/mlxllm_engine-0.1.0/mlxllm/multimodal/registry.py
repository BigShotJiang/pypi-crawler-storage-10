# SPDX-License-Identifier: Apache-2.0
"""Registry for multimodal processors in MLX-LLM."""

from __future__ import annotations

from typing import Any, Callable

from mlxllm.multimodal.inputs import ModalityType


class MultimodalRegistry:
    """Registry for multimodal processors."""

    def __init__(self):
        """Initialize multimodal registry."""
        self._processors: dict[ModalityType, Callable] = {}

    def register(self, modality: ModalityType, processor: Callable) -> None:
        """
        Register a processor for a modality.

        Args:
            modality: Modality type.
            processor: Processor function or class.
        """
        self._processors[modality] = processor

    def get(self, modality: ModalityType) -> Callable | None:
        """
        Get processor for a modality.

        Args:
            modality: Modality type.

        Returns:
            Processor or None if not found.
        """
        return self._processors.get(modality)

    def has(self, modality: ModalityType) -> bool:
        """
        Check if modality has a processor.

        Args:
            modality: Modality type.

        Returns:
            True if processor exists, False otherwise.
        """
        return modality in self._processors

    def list_modalities(self) -> list[ModalityType]:
        """
        List all registered modalities.

        Returns:
            List of modality types.
        """
        return list(self._processors.keys())


# Global registry
_global_registry = MultimodalRegistry()


def register_modality_processor(modality: ModalityType, processor: Callable) -> None:
    """
    Register a global modality processor.

    Args:
        modality: Modality type.
        processor: Processor function or class.
    """
    _global_registry.register(modality, processor)


def get_modality_processor(modality: ModalityType) -> Callable | None:
    """
    Get a registered modality processor.

    Args:
        modality: Modality type.

    Returns:
        Processor or None if not found.
    """
    return _global_registry.get(modality)
