# SPDX-License-Identifier: Apache-2.0
"""Content hashing for multimodal data in MLX-LLM."""

from __future__ import annotations

import hashlib

import mlx.core as mx


def hash_array(array: mx.array) -> str:
    """
    Hash an MLX array.

    Args:
        array: MLX array to hash.

    Returns:
        Hash string.
    """
    # Convert to bytes
    array_bytes = bytes(array)

    # Compute SHA256 hash
    return hashlib.sha256(array_bytes).hexdigest()


def hash_image(image: mx.array) -> str:
    """
    Hash an image array.

    Args:
        image: Image array.

    Returns:
        Hash string.
    """
    return hash_array(image)


def hash_video(video: mx.array) -> str:
    """
    Hash a video array.

    Args:
        video: Video frames array.

    Returns:
        Hash string.
    """
    return hash_array(video)


def hash_audio(audio: mx.array) -> str:
    """
    Hash an audio array.

    Args:
        audio: Audio waveform array.

    Returns:
        Hash string.
    """
    return hash_array(audio)


def hash_multimodal_input(inputs: list) -> str:
    """
    Hash a list of multimodal inputs.

    Args:
        inputs: List of multimodal inputs.

    Returns:
        Combined hash string.
    """
    hasher = hashlib.sha256()

    for input_item in inputs:
        if hasattr(input_item, "data"):
            if isinstance(input_item.data, mx.array):
                hasher.update(hash_array(input_item.data).encode())
            elif isinstance(input_item.data, str):
                hasher.update(input_item.data.encode())

    return hasher.hexdigest()
