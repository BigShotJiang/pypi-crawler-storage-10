# SPDX-License-Identifier: Apache-2.0
"""Utility functions for multimodal processing in MLX-LLM."""

from __future__ import annotations

import mlx.core as mx


def resize_image(image: mx.array, height: int, width: int) -> mx.array:
    """
    Resize image (simple implementation).

    Args:
        image: Input image (H, W, C).
        height: Target height.
        width: Target width.

    Returns:
        Resized image.
    """
    # Placeholder - proper resize would use interpolation
    h, w = image.shape[:2]

    if h == height and w == width:
        return image

    # Simple center crop/pad
    result = image
    if h > height:
        start_h = (h - height) // 2
        result = result[start_h : start_h + height, :, :]
    elif h < height:
        pad_h = height - h
        result = mx.pad(result, [(pad_h // 2, pad_h - pad_h // 2), (0, 0), (0, 0)])

    if w > width:
        start_w = (w - width) // 2
        result = result[:, start_w : start_w + width, :]
    elif w < width:
        pad_w = width - w
        result = mx.pad(result, [(0, 0), (pad_w // 2, pad_w - pad_w // 2), (0, 0)])

    return result


def normalize_image(
    image: mx.array,
    mean: tuple[float, float, float],
    std: tuple[float, float, float],
) -> mx.array:
    """
    Normalize image with mean and std.

    Args:
        image: Input image (H, W, C) in range [0, 1].
        mean: Mean values for each channel.
        std: Std values for each channel.

    Returns:
        Normalized image.
    """
    mean_array = mx.array(mean).reshape(1, 1, 3)
    std_array = mx.array(std).reshape(1, 1, 3)

    return (image - mean_array) / std_array


def denormalize_image(
    image: mx.array,
    mean: tuple[float, float, float],
    std: tuple[float, float, float],
) -> mx.array:
    """
    Denormalize image.

    Args:
        image: Normalized image (H, W, C).
        mean: Mean values used for normalization.
        std: Std values used for normalization.

    Returns:
        Denormalized image.
    """
    mean_array = mx.array(mean).reshape(1, 1, 3)
    std_array = mx.array(std).reshape(1, 1, 3)

    return image * std_array + mean_array


def pad_to_multiple(array: mx.array, multiple: int, axis: int = 0) -> mx.array:
    """
    Pad array to be a multiple of a given size.

    Args:
        array: Input array.
        multiple: Multiple to pad to.
        axis: Axis to pad along.

    Returns:
        Padded array.
    """
    size = array.shape[axis]
    remainder = size % multiple

    if remainder == 0:
        return array

    pad_size = multiple - remainder
    pad_shape = [(0, 0)] * len(array.shape)
    pad_shape[axis] = (0, pad_size)

    return mx.pad(array, pad_shape)
