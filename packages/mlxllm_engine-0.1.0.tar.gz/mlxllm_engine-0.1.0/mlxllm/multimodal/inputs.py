# SPDX-License-Identifier: Apache-2.0
"""Multimodal input data structures for MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

import mlx.core as mx


class ModalityType(str, Enum):
    """Types of modalities."""

    TEXT = "text"
    IMAGE = "image"
    VIDEO = "video"
    AUDIO = "audio"


@dataclass
class MultimodalInput:
    """Base class for multimodal inputs."""

    modality: ModalityType
    """Type of modality."""

    data: Any
    """Raw input data."""

    metadata: dict[str, Any] | None = None
    """Additional metadata."""


@dataclass
class ImageInput(MultimodalInput):
    """Image input."""

    image: mx.array
    """Image tensor (H, W, C)."""

    modality: ModalityType = ModalityType.IMAGE

    def __post_init__(self):
        """Initialize data field."""
        self.data = self.image


@dataclass
class VideoInput(MultimodalInput):
    """Video input."""

    frames: mx.array
    """Video frames tensor (T, H, W, C)."""

    fps: float = 30.0
    """Frames per second."""

    modality: ModalityType = ModalityType.VIDEO

    def __post_init__(self):
        """Initialize data field."""
        self.data = self.frames


@dataclass
class AudioInput(MultimodalInput):
    """Audio input."""

    waveform: mx.array
    """Audio waveform (T, C)."""

    sample_rate: int = 16000
    """Sample rate in Hz."""

    modality: ModalityType = ModalityType.AUDIO

    def __post_init__(self):
        """Initialize data field."""
        self.data = self.waveform


@dataclass
class TextInput(MultimodalInput):
    """Text input."""

    text: str
    """Text content."""

    modality: ModalityType = ModalityType.TEXT

    def __post_init__(self):
        """Initialize data field."""
        self.data = self.text
