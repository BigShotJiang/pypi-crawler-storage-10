# SPDX-License-Identifier: Apache-2.0
"""Performance profiling for multimodal operations in MLX-LLM."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class MultimodalProfile:
    """Profile data for multimodal operations."""

    image_preprocess_time: float = 0.0
    """Time spent preprocessing images."""

    video_preprocess_time: float = 0.0
    """Time spent preprocessing videos."""

    audio_preprocess_time: float = 0.0
    """Time spent preprocessing audio."""

    encoding_time: float = 0.0
    """Time spent encoding multimodal data."""

    total_images: int = 0
    """Total images processed."""

    total_videos: int = 0
    """Total videos processed."""

    total_audio: int = 0
    """Total audio clips processed."""

    def to_dict(self) -> dict[str, float | int]:
        """Convert to dictionary."""
        return {
            "image_preprocess_time": self.image_preprocess_time,
            "video_preprocess_time": self.video_preprocess_time,
            "audio_preprocess_time": self.audio_preprocess_time,
            "encoding_time": self.encoding_time,
            "total_images": self.total_images,
            "total_videos": self.total_videos,
            "total_audio": self.total_audio,
        }


class MultimodalProfiler:
    """Profiler for multimodal operations."""

    def __init__(self):
        """Initialize profiler."""
        self.profile = MultimodalProfile()
        self._start_times: dict[str, float] = {}

    def start(self, operation: str) -> None:
        """Start timing an operation."""
        self._start_times[operation] = time.perf_counter()

    def end(self, operation: str) -> float:
        """
        End timing an operation.

        Returns:
            Duration in seconds.
        """
        if operation not in self._start_times:
            return 0.0

        duration = time.perf_counter() - self._start_times[operation]
        del self._start_times[operation]

        return duration

    def record_image_preprocess(self, duration: float) -> None:
        """Record image preprocessing time."""
        self.profile.image_preprocess_time += duration
        self.profile.total_images += 1

    def record_video_preprocess(self, duration: float) -> None:
        """Record video preprocessing time."""
        self.profile.video_preprocess_time += duration
        self.profile.total_videos += 1

    def record_audio_preprocess(self, duration: float) -> None:
        """Record audio preprocessing time."""
        self.profile.audio_preprocess_time += duration
        self.profile.total_audio += 1

    def get_profile(self) -> MultimodalProfile:
        """Get current profile."""
        return self.profile

    def reset(self) -> None:
        """Reset profiler."""
        self.profile = MultimodalProfile()
        self._start_times.clear()
