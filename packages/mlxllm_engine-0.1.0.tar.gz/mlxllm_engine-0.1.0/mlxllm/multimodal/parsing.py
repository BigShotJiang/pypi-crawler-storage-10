# SPDX-License-Identifier: Apache-2.0
"""Parsing of multimodal inputs for MLX-LLM."""

from __future__ import annotations

from typing import Any

from mlxllm.multimodal.inputs import (
    AudioInput,
    ImageInput,
    ModalityType,
    MultimodalInput,
    TextInput,
    VideoInput,
)


def parse_multimodal_input(data: Any) -> list[MultimodalInput]:
    """
    Parse mixed multimodal input.

    Args:
        data: Input data (can be text, image, video, audio, or mixed).

    Returns:
        List of multimodal inputs.
    """
    if isinstance(data, str):
        return [TextInput(text=data)]

    elif isinstance(data, dict):
        # Parse dictionary with modality keys
        inputs = []

        if "text" in data:
            inputs.append(TextInput(text=data["text"]))

        if "image" in data:
            inputs.append(ImageInput(image=data["image"]))

        if "video" in data:
            inputs.append(VideoInput(frames=data["video"]))

        if "audio" in data:
            inputs.append(AudioInput(waveform=data["audio"]))

        return inputs

    elif isinstance(data, list):
        # Parse list of inputs
        inputs = []
        for item in data:
            inputs.extend(parse_multimodal_input(item))
        return inputs

    else:
        raise ValueError(f"Unsupported input type: {type(data)}")


def format_multimodal_prompt(inputs: list[MultimodalInput]) -> str:
    """
    Format multimodal inputs as a prompt.

    Args:
        inputs: List of multimodal inputs.

    Returns:
        Formatted prompt string.
    """
    parts = []

    for input_item in inputs:
        if input_item.modality == ModalityType.TEXT:
            parts.append(input_item.data)
        elif input_item.modality == ModalityType.IMAGE:
            parts.append("<image>")
        elif input_item.modality == ModalityType.VIDEO:
            parts.append("<video>")
        elif input_item.modality == ModalityType.AUDIO:
            parts.append("<audio>")

    return " ".join(parts)
