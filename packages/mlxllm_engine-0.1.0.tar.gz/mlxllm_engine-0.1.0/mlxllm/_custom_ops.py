# SPDX-License-Identifier: Apache-2.0
"""Custom MLX operations registry for MLX-LLM.

This module provides a registry for custom Metal operations and kernels
that extend MLX functionality for LLM inference.
"""

from __future__ import annotations

from typing import Any, Callable


class CustomOpRegistry:
    """Registry for custom MLX operations."""

    def __init__(self):
        """Initialize custom operation registry."""
        self._ops: dict[str, Callable] = {}

    def register(self, name: str, op: Callable) -> None:
        """
        Register a custom operation.

        Args:
            name: Operation name.
            op: Operation function.
        """
        self._ops[name] = op

    def get(self, name: str) -> Callable | None:
        """
        Get a registered operation.

        Args:
            name: Operation name.

        Returns:
            Operation function or None if not found.
        """
        return self._ops.get(name)

    def has(self, name: str) -> bool:
        """
        Check if an operation is registered.

        Args:
            name: Operation name.

        Returns:
            True if operation exists, False otherwise.
        """
        return name in self._ops

    def list_ops(self) -> list[str]:
        """
        List all registered operations.

        Returns:
            List of operation names.
        """
        return list(self._ops.keys())


# Global registry
_global_registry = CustomOpRegistry()


def register_custom_op(name: str, op: Callable) -> None:
    """
    Register a custom operation globally.

    Args:
        name: Operation name.
        op: Operation function.
    """
    _global_registry.register(name, op)


def get_custom_op(name: str) -> Callable | None:
    """
    Get a registered custom operation.

    Args:
        name: Operation name.

    Returns:
        Operation function or None if not found.
    """
    return _global_registry.get(name)


def has_custom_op(name: str) -> bool:
    """
    Check if a custom operation exists.

    Args:
        name: Operation name.

    Returns:
        True if operation exists, False otherwise.
    """
    return _global_registry.has(name)


def list_custom_ops() -> list[str]:
    """
    List all registered custom operations.

    Returns:
        List of operation names.
    """
    return _global_registry.list_ops()
