# SPDX-License-Identifier: Apache-2.0
"""Beam search decoding for MLX-LLM.

This module implements beam search, a search algorithm that maintains multiple
candidate sequences and selects the most likely ones based on cumulative log
probabilities.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import mlx.core as mx


@dataclass
class BeamHypothesis:
    """A single hypothesis in beam search."""

    token_ids: list[int]
    """Token IDs in this hypothesis."""

    log_prob: float
    """Cumulative log probability of the sequence."""

    def __lt__(self, other: BeamHypothesis) -> bool:
        """Compare based on log probability."""
        return self.log_prob < other.log_prob

    def __eq__(self, other: Any) -> bool:
        """Check equality based on tokens and log prob."""
        if not isinstance(other, BeamHypothesis):
            return False
        return self.token_ids == other.token_ids and self.log_prob == other.log_prob

    @property
    def length(self) -> int:
        """Get sequence length."""
        return len(self.token_ids)


@dataclass
class BeamSearchScorer:
    """
    Scorer for beam search that tracks hypotheses and manages beam selection.

    This class implements length penalty and early stopping logic for beam search.
    """

    batch_size: int
    """Number of independent sequences in batch."""

    num_beams: int
    """Number of beams to maintain per sequence."""

    length_penalty: float = 1.0
    """Length penalty factor. >1.0 encourages longer sequences."""

    early_stopping: bool = False
    """Stop when num_beams complete hypotheses are found."""

    max_length: int = 1000
    """Maximum sequence length."""

    # Internal state
    _done: list[bool] = field(default_factory=list)
    """Track which sequences are done."""

    _beam_hyps: list[list[BeamHypothesis]] = field(default_factory=list)
    """Store completed hypotheses for each batch item."""

    _beam_scores: list[list[float]] = field(default_factory=list)
    """Store scores for each beam."""

    def __post_init__(self):
        """Initialize internal state."""
        self._done = [False] * self.batch_size
        self._beam_hyps = [[] for _ in range(self.batch_size)]
        self._beam_scores = [[-float("inf")] * self.num_beams for _ in range(self.batch_size)]

    def is_done(self) -> bool:
        """Check if beam search is complete."""
        return all(self._done)

    def process(
        self,
        batch_idx: int,
        next_scores: mx.array,
        next_tokens: mx.array,
        next_indices: mx.array,
        eos_token_id: int,
        cur_len: int,
    ) -> tuple[mx.array, mx.array, mx.array]:
        """
        Process one step of beam search.

        Args:
            batch_idx: Index of the batch item.
            next_scores: Scores for next tokens (num_beams * vocab_size,).
            next_tokens: Token IDs for next tokens.
            next_indices: Beam indices for next tokens.
            eos_token_id: End-of-sequence token ID.
            cur_len: Current sequence length.

        Returns:
            Tuple of (filtered_scores, filtered_tokens, filtered_indices).
        """
        # Keep track of which beams are finalized
        beam_idx = 0
        for beam_token_rank, (token_id, score, beam_id) in enumerate(
            zip(next_tokens, next_scores, next_indices)
        ):
            token_id = int(token_id)
            score = float(score)
            beam_id = int(beam_id)

            # Check if this is EOS token
            if token_id == eos_token_id:
                # Add hypothesis to completed list
                is_beam_token_worse_than_top_num_beams = (
                    beam_token_rank >= self.num_beams
                )
                if is_beam_token_worse_than_top_num_beams:
                    continue

                # Apply length penalty
                length_penalty_score = score / (cur_len ** self.length_penalty)

                # Add completed hypothesis
                self._beam_hyps[batch_idx].append(
                    BeamHypothesis(
                        token_ids=[],  # Will be filled by caller
                        log_prob=length_penalty_score,
                    )
                )
            else:
                # Continue beam
                self._beam_scores[batch_idx][beam_idx] = score
                beam_idx += 1

                if beam_idx >= self.num_beams:
                    break

        # Check if we're done with this batch item
        if len(self._beam_hyps[batch_idx]) >= self.num_beams:
            if self.early_stopping:
                self._done[batch_idx] = True
            else:
                # Check if current beams are worse than completed hypotheses
                worst_hyp_score = min(h.log_prob for h in self._beam_hyps[batch_idx])
                best_beam_score = max(self._beam_scores[batch_idx])

                if worst_hyp_score > best_beam_score / (cur_len ** self.length_penalty):
                    self._done[batch_idx] = True

        return next_scores[:beam_idx], next_tokens[:beam_idx], next_indices[:beam_idx]

    def finalize(
        self,
        input_ids: mx.array,
        final_beam_scores: mx.array,
        eos_token_id: int,
        pad_token_id: int,
    ) -> mx.array:
        """
        Finalize beam search and return best hypotheses.

        Args:
            input_ids: Current token IDs (batch_size * num_beams, seq_len).
            final_beam_scores: Scores for final beams (batch_size * num_beams,).
            eos_token_id: End-of-sequence token ID.
            pad_token_id: Padding token ID.

        Returns:
            Best sequences (batch_size, num_beams, seq_len).
        """
        batch_size = self.batch_size
        num_beams = self.num_beams

        # Collect all hypotheses
        for batch_idx in range(batch_size):
            # Add current beams to hypotheses
            for beam_idx in range(num_beams):
                global_idx = batch_idx * num_beams + beam_idx
                seq = input_ids[global_idx]
                score = float(final_beam_scores[global_idx])

                # Apply length penalty
                cur_len = len(seq)
                length_penalty_score = score / (cur_len ** self.length_penalty)

                self._beam_hyps[batch_idx].append(
                    BeamHypothesis(
                        token_ids=seq.tolist(),
                        log_prob=length_penalty_score,
                    )
                )

            # Sort and select top beams
            self._beam_hyps[batch_idx].sort(reverse=True)  # Highest score first
            self._beam_hyps[batch_idx] = self._beam_hyps[batch_idx][:num_beams]

        # Build output sequences
        max_len = max(
            max(len(hyp.token_ids) for hyp in hyps)
            for hyps in self._beam_hyps
        )

        # Initialize output with padding
        output = mx.full(
            (batch_size, num_beams, max_len),
            pad_token_id,
            dtype=mx.int32,
        )

        # Fill in sequences
        for batch_idx in range(batch_size):
            for beam_idx, hyp in enumerate(self._beam_hyps[batch_idx]):
                seq_len = len(hyp.token_ids)
                output[batch_idx, beam_idx, :seq_len] = mx.array(hyp.token_ids)

        return output


def beam_search_step(
    logits: mx.array,
    beam_scores: mx.array,
    num_beams: int,
    eos_token_id: int,
    vocab_size: int,
) -> tuple[mx.array, mx.array, mx.array]:
    """
    Perform one step of beam search.

    Args:
        logits: Model logits (batch_size * num_beams, vocab_size).
        beam_scores: Current beam scores (batch_size * num_beams,).
        num_beams: Number of beams.
        eos_token_id: End-of-sequence token ID.
        vocab_size: Vocabulary size.

    Returns:
        Tuple of (next_beam_scores, next_beam_tokens, next_beam_indices).
    """
    # Compute log probabilities
    log_probs = mx.log_softmax(logits, axis=-1)

    # Add beam scores (batch_size * num_beams, 1) + (batch_size * num_beams, vocab_size)
    next_scores = beam_scores[:, None] + log_probs

    # Reshape to (batch_size, num_beams * vocab_size)
    batch_size = next_scores.shape[0] // num_beams
    next_scores = mx.reshape(next_scores, (batch_size, num_beams * vocab_size))

    # Get top-2*num_beams scores
    top_k = min(2 * num_beams, num_beams * vocab_size)
    next_scores_flat, next_tokens_flat = mx.topk(next_scores, k=top_k, axis=-1)

    # Compute beam indices and token indices
    next_beam_indices = next_tokens_flat // vocab_size
    next_tokens = next_tokens_flat % vocab_size

    return next_scores_flat, next_tokens, next_beam_indices


def select_beams(
    input_ids: mx.array,
    beam_indices: mx.array,
    num_beams: int,
) -> mx.array:
    """
    Select sequences based on beam indices.

    Args:
        input_ids: Current sequences (batch_size * num_beams, seq_len).
        beam_indices: Indices of beams to select (batch_size, num_beams).
        num_beams: Number of beams.

    Returns:
        Selected sequences (batch_size * num_beams, seq_len).
    """
    batch_size = beam_indices.shape[0]

    # Compute global indices
    global_indices = []
    for batch_idx in range(batch_size):
        for beam_idx in beam_indices[batch_idx]:
            global_idx = batch_idx * num_beams + beam_idx
            global_indices.append(int(global_idx))

    # Select sequences
    selected = input_ids[global_indices]

    return selected


class BeamSearchGenerator:
    """
    Complete beam search generator.

    This class manages the full beam search process, coordinating hypothesis
    scoring, beam selection, and early stopping.
    """

    def __init__(
        self,
        num_beams: int = 4,
        length_penalty: float = 1.0,
        early_stopping: bool = False,
        max_length: int = 1000,
    ):
        """
        Initialize beam search generator.

        Args:
            num_beams: Number of beams to maintain.
            length_penalty: Length penalty factor.
            early_stopping: Enable early stopping.
            max_length: Maximum sequence length.
        """
        self.num_beams = num_beams
        self.length_penalty = length_penalty
        self.early_stopping = early_stopping
        self.max_length = max_length

    def generate(
        self,
        model: Any,
        input_ids: mx.array,
        eos_token_id: int,
        pad_token_id: int,
        max_new_tokens: int = 100,
    ) -> mx.array:
        """
        Generate sequences using beam search.

        Args:
            model: Language model with forward() method.
            input_ids: Initial token IDs (batch_size, seq_len).
            eos_token_id: End-of-sequence token ID.
            pad_token_id: Padding token ID.
            max_new_tokens: Maximum new tokens to generate.

        Returns:
            Generated sequences (batch_size, num_beams, seq_len).
        """
        batch_size = input_ids.shape[0]
        vocab_size = model.vocab_size

        # Initialize beam scorer
        scorer = BeamSearchScorer(
            batch_size=batch_size,
            num_beams=self.num_beams,
            length_penalty=self.length_penalty,
            early_stopping=self.early_stopping,
            max_length=self.max_length,
        )

        # Expand input to num_beams
        input_ids = mx.repeat(input_ids, self.num_beams, axis=0)

        # Initialize beam scores
        beam_scores = mx.zeros((batch_size * self.num_beams,))
        beam_scores[self.num_beams::self.num_beams] = -float("inf")  # Only first beam active

        # Generation loop
        for step in range(max_new_tokens):
            if scorer.is_done():
                break

            # Forward pass
            logits = model.forward(input_ids)

            # Beam search step
            next_scores, next_tokens, next_indices = beam_search_step(
                logits[:, -1, :],  # Only last token logits
                beam_scores,
                self.num_beams,
                eos_token_id,
                vocab_size,
            )

            # Process for each batch item
            for batch_idx in range(batch_size):
                scores = next_scores[batch_idx]
                tokens = next_tokens[batch_idx]
                indices = next_indices[batch_idx]

                # Filter beams
                filtered_scores, filtered_tokens, filtered_indices = scorer.process(
                    batch_idx, scores, tokens, indices, eos_token_id, input_ids.shape[1]
                )

            # Select beams and append new tokens
            selected_input = select_beams(input_ids, next_indices, self.num_beams)
            input_ids = mx.concatenate([selected_input, next_tokens[:, None]], axis=-1)

            # Update beam scores
            beam_scores = next_scores.flatten()

        # Finalize and return best sequences
        output = scorer.finalize(input_ids, beam_scores, eos_token_id, pad_token_id)

        return output
