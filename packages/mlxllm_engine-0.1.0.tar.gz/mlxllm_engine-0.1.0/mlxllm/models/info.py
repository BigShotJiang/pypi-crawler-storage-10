# SPDX-License-Identifier: Apache-2.0
"""Model information and metadata structures."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from mlxllm.config.model import ModelType, QuantizationType


@dataclass
class ModelInfo:
    """
    Complete model information and metadata.

    This class contains all relevant information about a model including
    its specifications, cache location, and metadata.
    """

    model_id: str
    """HuggingFace model identifier (e.g., 'Qwen/Qwen2.5-Coder-7B')."""

    model_type: ModelType
    """Model architecture type (llama, qwen2, deepseek, etc.)."""

    cache_path: Path
    """Local path where model is cached."""

    config: Dict[str, Any]
    """Raw configuration from config.json."""

    # Model specifications
    vocab_size: int
    """Vocabulary size."""

    hidden_size: int
    """Hidden dimension size."""

    num_layers: int
    """Number of transformer layers."""

    num_attention_heads: int
    """Number of attention heads."""

    num_kv_heads: Optional[int] = None
    """Number of KV heads for GQA/MQA (None means same as attention heads)."""

    head_dim: Optional[int] = None
    """Head dimension (None means hidden_size / num_attention_heads)."""

    intermediate_size: Optional[int] = None
    """FFN intermediate size."""

    # Quantization and memory
    quantization: Optional[QuantizationType] = None
    """Quantization type if model is quantized."""

    memory_footprint_mb: float = 0.0
    """Estimated memory footprint in MB."""

    # Supported features
    supported_features: List[str] = field(default_factory=list)
    """List of supported features (e.g., 'flash_attention', 'rope_scaling')."""

    # Cache metadata
    download_date: Optional[datetime] = None
    """When the model was downloaded."""

    last_accessed: Optional[datetime] = None
    """When the model was last accessed."""

    revision: str = "main"
    """Git revision (branch, tag, or commit hash)."""

    # Additional metadata
    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional metadata."""

    @classmethod
    def from_path(cls, path: Path) -> ModelInfo:
        """
        Load ModelInfo from a local path.

        Args:
            path: Path to model directory.

        Returns:
            ModelInfo instance.

        Raises:
            FileNotFoundError: If config.json not found.
            ValueError: If config is invalid.
        """
        path = Path(path)

        # Load config.json
        config_path = path / "config.json"
        if not config_path.exists():
            raise FileNotFoundError(f"config.json not found in {path}")

        with open(config_path, "r") as f:
            config = json.load(f)

        # Load metadata if available
        metadata_path = path / "mlxllm_metadata.json"
        metadata = {}
        if metadata_path.exists():
            with open(metadata_path, "r") as f:
                metadata = json.load(f)

        # Extract model specifications
        model_type = cls._detect_model_type(config)
        vocab_size = config.get("vocab_size", 0)
        hidden_size = config.get("hidden_size", 0)
        num_layers = config.get("num_hidden_layers", config.get("num_layers", 0))
        num_attention_heads = config.get("num_attention_heads", 0)
        num_kv_heads = config.get("num_key_value_heads")
        head_dim = config.get("head_dim")
        intermediate_size = config.get("intermediate_size")

        # Detect quantization
        quantization = cls._detect_quantization(path, config)

        # Calculate memory footprint
        memory_footprint_mb = cls._estimate_memory_footprint(
            path, vocab_size, hidden_size, num_layers, quantization
        )

        # Extract features
        supported_features = cls._extract_features(config)

        # Parse timestamps
        download_date = None
        last_accessed = None
        if "download_date" in metadata:
            download_date = datetime.fromisoformat(metadata["download_date"])
        if "last_accessed" in metadata:
            last_accessed = datetime.fromisoformat(metadata["last_accessed"])

        return cls(
            model_id=metadata.get("model_id", path.name),
            model_type=model_type,
            cache_path=path,
            config=config,
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            num_attention_heads=num_attention_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            intermediate_size=intermediate_size,
            quantization=quantization,
            memory_footprint_mb=memory_footprint_mb,
            supported_features=supported_features,
            download_date=download_date,
            last_accessed=last_accessed,
            revision=metadata.get("revision", "main"),
            metadata=metadata,
        )

    @classmethod
    def from_huggingface(cls, model_id: str, revision: str = "main") -> ModelInfo:
        """
        Create ModelInfo from a HuggingFace model ID (without downloading).

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision.

        Returns:
            ModelInfo instance with remote information.

        Raises:
            ValueError: If model info cannot be fetched.
        """
        from huggingface_hub import hf_hub_download

        # Download only config.json
        config_path = hf_hub_download(
            repo_id=model_id,
            filename="config.json",
            revision=revision,
        )

        with open(config_path, "r") as f:
            config = json.load(f)

        model_type = cls._detect_model_type(config)

        return cls(
            model_id=model_id,
            model_type=model_type,
            cache_path=Path(config_path).parent,
            config=config,
            vocab_size=config.get("vocab_size", 0),
            hidden_size=config.get("hidden_size", 0),
            num_layers=config.get("num_hidden_layers", config.get("num_layers", 0)),
            num_attention_heads=config.get("num_attention_heads", 0),
            num_kv_heads=config.get("num_key_value_heads"),
            head_dim=config.get("head_dim"),
            intermediate_size=config.get("intermediate_size"),
            revision=revision,
        )

    def save_metadata(self) -> None:
        """Save metadata to cache directory."""
        metadata_path = self.cache_path / "mlxllm_metadata.json"

        metadata = {
            "model_id": self.model_id,
            "model_type": self.model_type.value if isinstance(self.model_type, ModelType) else self.model_type,
            "revision": self.revision,
            "download_date": self.download_date.isoformat() if self.download_date else None,
            "last_accessed": datetime.now().isoformat(),
            "quantization": self.quantization.value if self.quantization else None,
            "memory_footprint_mb": self.memory_footprint_mb,
            **self.metadata,
        }

        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)

    def is_compatible(self) -> bool:
        """
        Check if model is compatible with MLX-LLM.

        Returns:
            True if compatible, False otherwise.
        """
        # Check if model type is supported
        supported_types = {ModelType.LLAMA, ModelType.QWEN2, ModelType.DEEPSEEK}
        if self.model_type not in supported_types:
            return False

        # Check if required files exist
        required_files = ["config.json"]
        for file in required_files:
            if not (self.cache_path / file).exists():
                return False

        # Check for model weights
        has_weights = bool(list(self.cache_path.glob("*.safetensors")))
        if not has_weights:
            return False

        return True

    def estimate_memory_usage(
        self,
        batch_size: int = 1,
        sequence_length: int = 2048,
    ) -> float:
        """
        Estimate memory usage during inference.

        Args:
            batch_size: Batch size for inference.
            sequence_length: Sequence length.

        Returns:
            Estimated memory usage in MB.
        """
        # Base model memory
        base_memory = self.memory_footprint_mb

        # KV cache memory (approximate)
        # kv_cache = batch_size * sequence_length * num_layers * hidden_size * 2 (k + v) * bytes_per_element
        bytes_per_element = 2 if self.quantization in [None, QuantizationType.Q8_0] else 1
        kv_cache_mb = (
            batch_size
            * sequence_length
            * self.num_layers
            * self.hidden_size
            * 2
            * bytes_per_element
            / (1024 * 1024)
        )

        # Activation memory (rough estimate)
        activation_mb = batch_size * sequence_length * self.hidden_size * 4 / (1024 * 1024)

        return base_memory + kv_cache_mb + activation_mb

    @staticmethod
    def _detect_model_type(config: Dict[str, Any]) -> ModelType:
        """Detect model type from config."""
        model_type_str = config.get("model_type", "").lower()

        if "llama" in model_type_str or "mistral" in model_type_str:
            return ModelType.LLAMA
        elif "qwen" in model_type_str or "qwen2" in model_type_str:
            return ModelType.QWEN2
        elif "deepseek" in model_type_str:
            return ModelType.DEEPSEEK
        else:
            # Try to infer from architectures field
            architectures = config.get("architectures", [])
            if architectures:
                arch = architectures[0].lower()
                if "llama" in arch or "mistral" in arch:
                    return ModelType.LLAMA
                elif "qwen" in arch:
                    return ModelType.QWEN2
                elif "deepseek" in arch:
                    return ModelType.DEEPSEEK

        return ModelType.LLAMA  # Default fallback

    @staticmethod
    def _detect_quantization(path: Path, config: Dict[str, Any]) -> Optional[QuantizationType]:
        """Detect quantization type from model files and config."""
        # Check config for quantization info
        if "quantization_config" in config:
            quant_config = config["quantization_config"]
            bits = quant_config.get("bits", 0)
            if bits == 4:
                return QuantizationType.Q4_0
            elif bits == 8:
                return QuantizationType.Q8_0

        # Check filename patterns
        model_files = list(path.glob("*.safetensors"))
        for file in model_files:
            filename = file.name.lower()
            if "q4" in filename or "4bit" in filename:
                return QuantizationType.Q4_0
            elif "q8" in filename or "8bit" in filename:
                return QuantizationType.Q8_0

        return None

    @staticmethod
    def _estimate_memory_footprint(
        path: Path,
        vocab_size: int,
        hidden_size: int,
        num_layers: int,
        quantization: Optional[QuantizationType],
    ) -> float:
        """Estimate memory footprint from model files."""
        # Try to get actual file sizes
        total_bytes = 0
        for file in path.glob("*.safetensors"):
            total_bytes += file.stat().st_size

        if total_bytes > 0:
            return total_bytes / (1024 * 1024)  # Convert to MB

        # Fallback: estimate from model specs
        # Rough estimate: vocab_size * hidden_size + num_layers * (hidden_size^2 * multiple)
        bytes_per_param = 2  # fp16 default
        if quantization == QuantizationType.Q4_0 or quantization == QuantizationType.Q4_1:
            bytes_per_param = 0.5
        elif quantization == QuantizationType.Q8_0:
            bytes_per_param = 1

        # Very rough estimate
        total_params = vocab_size * hidden_size + num_layers * hidden_size * hidden_size * 12
        total_mb = total_params * bytes_per_param / (1024 * 1024)

        return total_mb

    @staticmethod
    def _extract_features(config: Dict[str, Any]) -> List[str]:
        """Extract supported features from config."""
        features = []

        if config.get("use_flash_attention"):
            features.append("flash_attention")
        if config.get("rope_scaling"):
            features.append("rope_scaling")
        if config.get("sliding_window"):
            features.append("sliding_window")
        if config.get("use_cache", True):
            features.append("kv_cache")

        return features


@dataclass
class ValidationResult:
    """
    Model validation results.

    Contains validation status, warnings, errors, and recommendations.
    """

    is_valid: bool
    """Whether model passed validation."""

    warnings: List[str] = field(default_factory=list)
    """List of warning messages."""

    errors: List[str] = field(default_factory=list)
    """List of error messages."""

    recommendations: Dict[str, Any] = field(default_factory=dict)
    """Recommended settings for optimal performance."""

    def add_warning(self, message: str) -> None:
        """Add a warning message."""
        self.warnings.append(message)

    def add_error(self, message: str) -> None:
        """Add an error message."""
        self.errors.append(message)
        self.is_valid = False

    def add_recommendation(self, key: str, value: Any) -> None:
        """Add a recommendation."""
        self.recommendations[key] = value

    def __str__(self) -> str:
        """String representation of validation result."""
        lines = []
        if self.is_valid:
            lines.append("✓ Model validation passed")
        else:
            lines.append("✗ Model validation failed")

        if self.errors:
            lines.append("\nErrors:")
            for error in self.errors:
                lines.append(f"  • {error}")

        if self.warnings:
            lines.append("\nWarnings:")
            for warning in self.warnings:
                lines.append(f"  ⚠ {warning}")

        if self.recommendations:
            lines.append("\nRecommendations:")
            for key, value in self.recommendations.items():
                lines.append(f"  • {key}: {value}")

        return "\n".join(lines)
