# SPDX-License-Identifier: Apache-2.0
"""High-level model management for downloading, caching, and loading models."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Optional

from mlxllm.config.model import ModelConfig
from mlxllm.models.config_helper import ModelConfigHelper
from mlxllm.models.download import ModelDownloader
from mlxllm.models.info import ModelInfo, ValidationResult

logger = logging.getLogger(__name__)


class ModelManager:
    """
    High-level model management for downloading, caching, and loading models.

    Features:
    - Automatic model detection and configuration
    - Smart caching with versioning
    - Progress tracking with callbacks
    - Validation and compatibility checks
    - Retry logic with exponential backoff

    Example:
        >>> manager = ModelManager()
        >>> model_info = manager.download_model(
        ...     "Qwen/Qwen2.5-Coder-7B",
        ...     quantization="q4_0",
        ... )
        >>> print(f"Model cached at: {model_info.cache_path}")
    """

    def __init__(
        self,
        cache_dir: Optional[Path] = None,
        max_retries: int = 3,
    ):
        """
        Initialize model manager.

        Args:
            cache_dir: Cache directory (None = use default ~/.cache/mlxllm/models).
            max_retries: Maximum number of retry attempts for downloads.
        """
        if cache_dir is None:
            cache_dir = Path.home() / ".cache" / "mlxllm" / "models"

        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.downloader = ModelDownloader(max_retries=max_retries)
        self.config_helper = ModelConfigHelper()

        logger.info(f"ModelManager initialized with cache: {self.cache_dir}")

    def download_model(
        self,
        model_id: str,
        quantization: Optional[str] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        progress_callback: Optional[Callable] = None,
        **kwargs,
    ) -> ModelInfo:
        """
        Download model from HuggingFace Hub.

        This method:
        1. Checks if model is already cached
        2. Downloads model with progress tracking
        3. Validates downloaded model
        4. Creates and saves ModelInfo metadata

        Args:
            model_id: HuggingFace model identifier.
            quantization: Optional quantization type (q4_0, q8_0, etc.).
            revision: Git revision (branch, tag, or commit).
            force_download: Force re-download even if cached.
            progress_callback: Optional callback for progress updates.
            **kwargs: Additional download arguments.

        Returns:
            ModelInfo instance with model metadata.

        Raises:
            RuntimeError: If download or validation fails.

        Example:
            >>> manager = ModelManager()
            >>> model_info = manager.download_model(
            ...     "mlx-community/Qwen2.5-Coder-7B-Instruct-4bit"
            ... )
        """
        revision = revision or "main"

        # Check if already cached (unless force_download)
        if not force_download:
            cached_path = self._get_cache_path(model_id, revision)
            if cached_path.exists():
                logger.info(f"Model already cached at: {cached_path}")
                try:
                    model_info = ModelInfo.from_path(cached_path)
                    model_info.last_accessed = datetime.now()
                    model_info.save_metadata()
                    return model_info
                except Exception as e:
                    logger.warning(f"Failed to load cached model info: {e}")

        # Download model
        logger.info(f"Downloading model: {model_id}")

        try:
            download_path = self.downloader.download_from_hub(
                model_id=model_id,
                revision=revision,
                cache_dir=self.cache_dir,
                progress_callback=progress_callback,
                **kwargs,
            )

            # Verify download
            if not self.downloader.verify_download(download_path):
                raise RuntimeError(f"Model validation failed: {download_path}")

            # Create ModelInfo
            model_info = ModelInfo.from_path(download_path)
            model_info.model_id = model_id
            model_info.revision = revision
            model_info.download_date = datetime.now()
            model_info.last_accessed = datetime.now()

            # Save metadata
            model_info.save_metadata()

            logger.info(f"Successfully downloaded and cached model: {model_id}")

            return model_info

        except Exception as e:
            logger.error(f"Failed to download model: {e}")
            raise RuntimeError(f"Model download failed: {e}") from e

    def get_model_info(self, model_id: str, revision: str = "main") -> Optional[ModelInfo]:
        """
        Get information about a cached model.

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision.

        Returns:
            ModelInfo if model is cached, None otherwise.

        Example:
            >>> info = manager.get_model_info("Qwen/Qwen2.5-Coder-7B")
            >>> if info:
            ...     print(f"Memory: {info.memory_footprint_mb} MB")
        """
        cache_path = self._get_cache_path(model_id, revision)

        if not cache_path.exists():
            return None

        try:
            model_info = ModelInfo.from_path(cache_path)
            model_info.last_accessed = datetime.now()
            model_info.save_metadata()
            return model_info
        except Exception as e:
            logger.error(f"Failed to load model info: {e}")
            return None

    def list_cached_models(self) -> List[ModelInfo]:
        """
        List all models in cache.

        Returns:
            List of ModelInfo for cached models.

        Example:
            >>> models = manager.list_cached_models()
            >>> for model in models:
            ...     print(f"{model.model_id}: {model.memory_footprint_mb} MB")
        """
        models = []

        # Scan cache directory
        for model_dir in self.cache_dir.iterdir():
            if not model_dir.is_dir():
                continue

            # Check for models in subdirectories (HF cache structure)
            for subdir in model_dir.rglob("*"):
                if subdir.is_dir() and (subdir / "config.json").exists():
                    try:
                        model_info = ModelInfo.from_path(subdir)
                        models.append(model_info)
                    except Exception as e:
                        logger.debug(f"Failed to load model from {subdir}: {e}")

        return models

    def load_model_for_inference(
        self,
        model_id: str,
        auto_download: bool = True,
        **engine_kwargs,
    ):
        """
        Prepare a complete inference engine for a model.

        This method:
        1. Downloads model if not cached (if auto_download=True)
        2. Auto-configures model settings
        3. Creates AsyncLLMEngine

        Args:
            model_id: HuggingFace model identifier.
            auto_download: Automatically download if not cached.
            **engine_kwargs: Additional engine configuration.

        Returns:
            AsyncLLMEngine instance ready for inference.

        Raises:
            RuntimeError: If model cannot be loaded.

        Example:
            >>> engine = manager.load_model_for_inference(
            ...     "mlx-community/Qwen2.5-Coder-7B-Instruct-4bit",
            ...     max_batch_size=32,
            ... )
            >>> response = await engine.generate("Hello!")
        """
        from mlxllm.engine.async_llm_engine import AsyncLLMEngine

        # Get or download model
        model_info = self.get_model_info(model_id)

        if model_info is None:
            if auto_download:
                logger.info(f"Model not cached, downloading: {model_id}")
                model_info = self.download_model(model_id)
            else:
                raise RuntimeError(f"Model not found in cache: {model_id}")

        # Auto-configure
        model_config = self.config_helper.auto_configure_from_hf(
            model_id=model_id,
            cache_path=model_info.cache_path,
            **engine_kwargs,
        )

        # Get recommended settings
        recommendations = self.config_helper.get_recommended_settings(model_info)

        # Apply recommendations if not overridden
        for key, value in recommendations.items():
            if key not in engine_kwargs:
                engine_kwargs[key] = value

        # Create engine
        logger.info(f"Creating inference engine for: {model_id}")

        engine = AsyncLLMEngine(
            model_config=model_config,
            model_path=str(model_info.cache_path),
            **engine_kwargs,
        )

        return engine

    def validate_model_compatibility(
        self,
        model_id: str,
        auto_download: bool = False,
    ) -> ValidationResult:
        """
        Validate that a model is compatible with MLX-LLM.

        Args:
            model_id: HuggingFace model identifier.
            auto_download: Download model if not cached.

        Returns:
            ValidationResult with status and messages.

        Example:
            >>> result = manager.validate_model_compatibility("Qwen/Qwen2.5-Coder-7B")
            >>> if result.is_valid:
            ...     print("✓ Model is compatible")
            >>> else:
            ...     print(f"✗ Errors: {result.errors}")
        """
        # Get model info
        model_info = self.get_model_info(model_id)

        if model_info is None:
            if auto_download:
                try:
                    model_info = self.download_model(model_id)
                except Exception as e:
                    result = ValidationResult(is_valid=False)
                    result.add_error(f"Failed to download model: {e}")
                    return result
            else:
                result = ValidationResult(is_valid=False)
                result.add_error("Model not found in cache. Use auto_download=True to download.")
                return result

        # Check compatibility
        result = ValidationResult(is_valid=True)

        if not model_info.is_compatible():
            result.add_error("Model is not compatible with MLX-LLM")

        # Check for required files
        required_files = ["config.json"]
        for file in required_files:
            if not (model_info.cache_path / file).exists():
                result.add_error(f"Missing required file: {file}")

        # Check for model weights
        weight_files = list(model_info.cache_path.glob("*.safetensors"))
        if not weight_files:
            result.add_error("No model weight files found")
        else:
            result.add_recommendation("weight_files", len(weight_files))

        # Validate configuration
        try:
            config = self.config_helper.auto_configure_from_hf(
                model_id=model_id,
                cache_path=model_info.cache_path,
            )

            config_validation = self.config_helper.validate_config(config)

            # Merge validation results
            result.warnings.extend(config_validation.warnings)
            result.errors.extend(config_validation.errors)
            result.recommendations.update(config_validation.recommendations)

            if not config_validation.is_valid:
                result.is_valid = False

        except Exception as e:
            result.add_error(f"Failed to validate configuration: {e}")

        return result

    def remove_model(self, model_id: str, revision: str = "main") -> bool:
        """
        Remove a model from cache.

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision.

        Returns:
            True if model was removed, False if not found.

        Example:
            >>> manager.remove_model("old-model")
        """
        import shutil

        cache_path = self._get_cache_path(model_id, revision)

        if not cache_path.exists():
            logger.warning(f"Model not found in cache: {model_id}")
            return False

        try:
            shutil.rmtree(cache_path)
            logger.info(f"Removed model from cache: {model_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove model: {e}")
            return False

    def get_cache_size(self) -> float:
        """
        Get total size of model cache.

        Returns:
            Total size in GB.

        Example:
            >>> size_gb = manager.get_cache_size()
            >>> print(f"Cache size: {size_gb:.2f} GB")
        """
        total_bytes = 0

        for file in self.cache_dir.rglob("*"):
            if file.is_file():
                total_bytes += file.stat().st_size

        return total_bytes / (1024**3)

    def clear_cache(self, confirm: bool = False) -> bool:
        """
        Clear entire model cache.

        Args:
            confirm: Must be True to actually clear cache.

        Returns:
            True if cache was cleared.

        Example:
            >>> manager.clear_cache(confirm=True)
        """
        import shutil

        if not confirm:
            logger.warning("clear_cache requires confirm=True")
            return False

        try:
            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            logger.info("Cache cleared")
            return True
        except Exception as e:
            logger.error(f"Failed to clear cache: {e}")
            return False

    def _get_cache_path(self, model_id: str, revision: str) -> Path:
        """Get cache path for a model."""
        # Sanitize model_id for use as directory name
        safe_model_id = model_id.replace("/", "--")
        return self.cache_dir / safe_model_id / revision


def get_global_manager() -> ModelManager:
    """
    Get global ModelManager instance.

    Returns:
        Singleton ModelManager instance.

    Example:
        >>> manager = get_global_manager()
        >>> models = manager.list_cached_models()
    """
    global _global_manager

    if "_global_manager" not in globals():
        _global_manager = ModelManager()

    return _global_manager
