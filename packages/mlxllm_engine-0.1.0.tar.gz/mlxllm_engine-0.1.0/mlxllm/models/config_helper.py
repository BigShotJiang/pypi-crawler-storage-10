# SPDX-License-Identifier: Apache-2.0
"""Automatic model configuration detection and setup."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

import mlx.core as mx

from mlxllm.config.model import DType, ModelConfig, ModelType, QuantizationType
from mlxllm.models.info import ModelInfo, ValidationResult

logger = logging.getLogger(__name__)


class ModelConfigHelper:
    """
    Automatic model configuration detection and setup.

    Provides utilities to automatically create optimal ModelConfig
    from HuggingFace models with minimal user input.
    """

    def __init__(self):
        """Initialize configuration helper."""
        pass

    def auto_configure_from_hf(
        self,
        model_id: str,
        cache_path: Optional[Path] = None,
        **overrides,
    ) -> ModelConfig:
        """
        Automatically create ModelConfig from HuggingFace model.

        This method:
        1. Loads config.json from the model
        2. Detects model type automatically
        3. Sets optimal defaults for MLX
        4. Applies user overrides

        Args:
            model_id: HuggingFace model identifier.
            cache_path: Path to cached model (if already downloaded).
            **overrides: User overrides for config values.

        Returns:
            Configured ModelConfig instance.

        Example:
            >>> helper = ModelConfigHelper()
            >>> config = helper.auto_configure_from_hf(
            ...     "Qwen/Qwen2.5-Coder-7B",
            ...     max_model_len=32768,
            ...     quantization="q4_0",
            ... )
        """
        # Load config from path or download
        if cache_path:
            config_path = cache_path / "config.json"
            with open(config_path, "r") as f:
                hf_config = json.load(f)
        else:
            # Download just the config
            from huggingface_hub import hf_hub_download

            config_path = hf_hub_download(
                repo_id=model_id,
                filename="config.json",
            )
            with open(config_path, "r") as f:
                hf_config = json.load(f)

        # Detect model type
        model_type = self.detect_model_type(hf_config)

        # Extract configuration parameters
        vocab_size = hf_config.get("vocab_size")
        hidden_size = hf_config.get("hidden_size")
        num_layers = hf_config.get("num_hidden_layers", hf_config.get("num_layers"))
        num_attention_heads = hf_config.get("num_attention_heads")
        num_kv_heads = hf_config.get("num_key_value_heads")
        intermediate_size = hf_config.get("intermediate_size")

        # Determine max_model_len
        max_model_len = hf_config.get("max_position_embeddings", 8192)
        if "max_sequence_length" in hf_config:
            max_model_len = hf_config["max_sequence_length"]

        # Parse quantization if specified
        quantization_str = overrides.pop("quantization", None)
        quantization = None
        if quantization_str:
            try:
                quantization = QuantizationType(quantization_str)
            except ValueError:
                logger.warning(f"Invalid quantization: {quantization_str}")

        # Determine dtype
        dtype_str = overrides.pop("dtype", None)
        if dtype_str:
            try:
                dtype = DType(dtype_str)
            except ValueError:
                dtype = DType.AUTO
        else:
            dtype = DType.AUTO

        # Create ModelConfig
        config = ModelConfig(
            model_name=model_id,
            model_type=model_type,
            model_path=str(cache_path) if cache_path else None,
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            num_attention_heads=num_attention_heads,
            num_kv_heads=num_kv_heads,
            intermediate_size=intermediate_size,
            max_model_len=overrides.pop("max_model_len", max_model_len),
            dtype=dtype,
            quantization=quantization,
            **overrides,  # Apply any remaining overrides
        )

        logger.info(f"Auto-configured model: {model_type.value}, {num_layers} layers")

        return config

    def detect_model_type(self, config: Dict[str, Any]) -> ModelType:
        """
        Detect model type from HuggingFace config.

        Args:
            config: HuggingFace config dictionary.

        Returns:
            Detected ModelType.
        """
        model_type_str = config.get("model_type", "").lower()

        # Check model_type field
        if "llama" in model_type_str or "mistral" in model_type_str:
            return ModelType.LLAMA
        elif "qwen" in model_type_str or "qwen2" in model_type_str:
            return ModelType.QWEN2
        elif "deepseek" in model_type_str:
            return ModelType.DEEPSEEK

        # Check architectures field
        architectures = config.get("architectures", [])
        if architectures:
            arch = architectures[0].lower()
            if "llama" in arch or "mistral" in arch:
                return ModelType.LLAMA
            elif "qwen" in arch:
                return ModelType.QWEN2
            elif "deepseek" in arch:
                return ModelType.DEEPSEEK

        logger.warning(f"Unknown model type, defaulting to LLAMA")
        return ModelType.LLAMA

    def get_recommended_settings(
        self,
        model_info: ModelInfo,
        available_memory_gb: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Recommend optimal settings based on model and hardware.

        Args:
            model_info: Model information.
            available_memory_gb: Available memory in GB (auto-detect if None).

        Returns:
            Dictionary of recommended settings.

        Example:
            >>> settings = helper.get_recommended_settings(model_info)
            >>> print(settings)
            {
                'max_batch_size': 32,
                'max_num_seqs': 256,
                'gpu_memory_utilization': 0.9,
                'quantization': 'q4_0',
                'block_size': 16,
            }
        """
        if available_memory_gb is None:
            # Auto-detect available memory
            try:
                available_memory_gb = mx.metal.get_active_memory() / (1024**3)
            except Exception:
                # Fallback to conservative estimate
                available_memory_gb = 16.0  # Assume 16GB available

        model_size_gb = model_info.memory_footprint_mb / 1024

        recommendations = {}

        # Recommend quantization if model is large
        if model_size_gb > available_memory_gb * 0.6:
            if model_info.quantization is None:
                recommendations["quantization"] = "q4_0"
                recommendations["note"] = "Model is large, quantization recommended"

        # Recommend batch size based on available memory
        if model_size_gb < available_memory_gb * 0.3:
            recommendations["max_batch_size"] = 64
            recommendations["max_num_seqs"] = 512
        elif model_size_gb < available_memory_gb * 0.5:
            recommendations["max_batch_size"] = 32
            recommendations["max_num_seqs"] = 256
        else:
            recommendations["max_batch_size"] = 16
            recommendations["max_num_seqs"] = 128

        # Recommend GPU memory utilization
        if model_size_gb < available_memory_gb * 0.4:
            recommendations["gpu_memory_utilization"] = 0.95
        else:
            recommendations["gpu_memory_utilization"] = 0.85

        # Block size recommendation
        recommendations["block_size"] = 16  # Standard for most models

        # Context length recommendations
        if model_info.hidden_size >= 4096:  # Large models
            recommendations["max_model_len"] = 8192
        elif model_info.hidden_size >= 2048:  # Medium models
            recommendations["max_model_len"] = 16384
        else:  # Small models
            recommendations["max_model_len"] = 32768

        return recommendations

    def validate_config(self, config: ModelConfig) -> ValidationResult:
        """
        Validate ModelConfig for correctness and compatibility.

        Args:
            config: Model configuration to validate.

        Returns:
            ValidationResult with status and messages.
        """
        result = ValidationResult(is_valid=True)

        # Check required fields
        if not config.model_name:
            result.add_error("model_name is required")

        if not config.vocab_size or config.vocab_size <= 0:
            result.add_error(f"Invalid vocab_size: {config.vocab_size}")

        if not config.hidden_size or config.hidden_size <= 0:
            result.add_error(f"Invalid hidden_size: {config.hidden_size}")

        if not config.num_layers or config.num_layers <= 0:
            result.add_error(f"Invalid num_layers: {config.num_layers}")

        # Check max_model_len
        if config.max_model_len <= 0:
            result.add_error(f"Invalid max_model_len: {config.max_model_len}")
        elif config.max_model_len > 128000:
            result.add_warning(
                f"Very large max_model_len ({config.max_model_len}), may cause memory issues"
            )

        # Check quantization compatibility
        if config.quantization:
            if config.quantization not in [
                QuantizationType.Q4_0,
                QuantizationType.Q4_1,
                QuantizationType.Q8_0,
            ]:
                result.add_warning(
                    f"Quantization {config.quantization} may not be fully supported"
                )

        # Memory estimation
        try:
            estimated_memory_gb = self._estimate_model_memory(config)

            try:
                available_memory_gb = mx.metal.get_active_memory() / (1024**3)

                if estimated_memory_gb > available_memory_gb * 0.8:
                    result.add_warning(
                        f"Model may require {estimated_memory_gb:.1f}GB, "
                        f"but only {available_memory_gb:.1f}GB available. "
                        "Consider using quantization."
                    )
                    result.add_recommendation("quantization", "q4_0")

            except Exception:
                # Can't check available memory
                pass

        except Exception as e:
            result.add_warning(f"Could not estimate memory requirements: {e}")

        return result

    def _estimate_model_memory(self, config: ModelConfig) -> float:
        """
        Estimate model memory requirements.

        Args:
            config: Model configuration.

        Returns:
            Estimated memory in GB.
        """
        # Rough estimation
        # Parameters: embedding + layers
        num_params = config.vocab_size * config.hidden_size
        num_params += config.num_layers * config.hidden_size * config.hidden_size * 12

        # Bytes per parameter
        if config.quantization == QuantizationType.Q4_0 or config.quantization == QuantizationType.Q4_1:
            bytes_per_param = 0.5
        elif config.quantization == QuantizationType.Q8_0:
            bytes_per_param = 1.0
        else:
            bytes_per_param = 2.0  # fp16 default

        total_gb = num_params * bytes_per_param / (1024**3)
        return total_gb


def create_config_from_path(model_path: Path, **overrides) -> ModelConfig:
    """
    Convenience function to create ModelConfig from a local path.

    Args:
        model_path: Path to model directory.
        **overrides: Configuration overrides.

    Returns:
        ModelConfig instance.

    Example:
        >>> config = create_config_from_path(
        ...     Path("/path/to/model"),
        ...     max_model_len=16384,
        ... )
    """
    helper = ModelConfigHelper()

    # Load config from path
    config_path = model_path / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"config.json not found in {model_path}")

    with open(config_path, "r") as f:
        hf_config = json.load(f)

    model_type = helper.detect_model_type(hf_config)

    return ModelConfig(
        model_name=model_path.name,
        model_type=model_type,
        model_path=str(model_path),
        vocab_size=hf_config.get("vocab_size"),
        hidden_size=hf_config.get("hidden_size"),
        num_layers=hf_config.get("num_hidden_layers", hf_config.get("num_layers")),
        num_attention_heads=hf_config.get("num_attention_heads"),
        num_kv_heads=hf_config.get("num_key_value_heads"),
        intermediate_size=hf_config.get("intermediate_size"),
        max_model_len=hf_config.get("max_position_embeddings", 8192),
        **overrides,
    )
