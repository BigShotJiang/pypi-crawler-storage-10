# SPDX-License-Identifier: Apache-2.0
"""Model management and loading utilities for MLX-LLM."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Tuple

import mlx.nn as nn

from mlxllm.models.config_helper import ModelConfigHelper, create_config_from_path
from mlxllm.models.download import ModelDownloader, download_model_quick
from mlxllm.models.info import ModelInfo, ValidationResult
from mlxllm.models.manager import ModelManager, get_global_manager
from mlxllm.tokenization.tokenizer import Tokenizer

__all__ = [
    # Classes
    "ModelManager",
    "ModelInfo",
    "ValidationResult",
    "ModelConfigHelper",
    "ModelDownloader",
    # High-level functions
    "load_model_from_hub",
    "prepare_model_for_inference",
    "list_available_models",
    "get_model_info",
    "download_model",
    # Utilities
    "download_model_quick",
    "create_config_from_path",
    "get_global_manager",
]


def load_model_from_hub(
    model_id: str,
    quantization: Optional[str] = None,
    revision: str = "main",
    cache_dir: Optional[Path] = None,
    trust_remote_code: bool = False,
) -> Tuple[nn.Module, Tokenizer]:
    """
    One-line function to download and load a model with tokenizer.

    This is the simplest way to get started with MLX-LLM. It handles:
    - Downloading the model if not cached
    - Loading model weights
    - Loading tokenizer
    - Applying quantization if requested

    Args:
        model_id: HuggingFace model identifier.
        quantization: Optional quantization (q4_0, q8_0, etc.).
        revision: Git revision (branch, tag, or commit).
        cache_dir: Optional cache directory.
        trust_remote_code: Whether to trust remote code.

    Returns:
        Tuple of (model, tokenizer).

    Example:
        >>> model, tokenizer = load_model_from_hub(
        ...     "mlx-community/Qwen2.5-Coder-7B-Instruct-4bit"
        ... )
        >>> tokens = tokenizer.encode("Hello, world!")
        >>> output = model(tokens)
    """
    from mlxllm.model_executor.model_loader import load_model

    manager = ModelManager(cache_dir=cache_dir)

    # Download model if needed
    model_info = manager.get_model_info(model_id, revision)
    if model_info is None:
        model_info = manager.download_model(
            model_id=model_id,
            quantization=quantization,
            revision=revision,
        )

    # Create model config
    config_helper = ModelConfigHelper()
    model_config = config_helper.auto_configure_from_hf(
        model_id=model_id,
        cache_path=model_info.cache_path,
        quantization=quantization,
        trust_remote_code=trust_remote_code,
    )

    # Load model
    model = load_model(
        model_config=model_config,
        quantization=quantization,
    )

    # Load tokenizer
    tokenizer = Tokenizer.from_pretrained(
        str(model_info.cache_path),
        trust_remote_code=trust_remote_code,
    )

    return model, tokenizer


def prepare_model_for_inference(
    model_id_or_path: str,
    auto_download: bool = True,
    **kwargs,
):
    """
    Prepare a complete inference engine.

    This function creates a ready-to-use AsyncLLMEngine with optimal
    settings for the given model and hardware.

    Args:
        model_id_or_path: HuggingFace model ID or local path.
        auto_download: Automatically download if not cached.
        **kwargs: Additional engine configuration options:
            - quantization: Quantization type
            - max_batch_size: Maximum batch size
            - max_model_len: Maximum context length
            - gpu_memory_utilization: GPU memory fraction
            - And more...

    Returns:
        AsyncLLMEngine instance ready for inference.

    Example:
        >>> engine = prepare_model_for_inference(
        ...     "Qwen/Qwen2.5-Coder-7B",
        ...     quantization="q4_0",
        ...     max_batch_size=32,
        ... )
        >>> response = await engine.generate("Write a hello world program")
    """
    # Check if path or model ID
    path = Path(model_id_or_path)

    if path.exists() and path.is_dir():
        # Local path
        manager = ModelManager()
        model_info = ModelInfo.from_path(path)

        config_helper = ModelConfigHelper()
        model_config = config_helper.auto_configure_from_hf(
            model_id=model_info.model_id,
            cache_path=path,
            **kwargs,
        )

        from mlxllm.engine.async_llm_engine import AsyncLLMEngine

        return AsyncLLMEngine(
            model_config=model_config,
            model_path=str(path),
            **kwargs,
        )
    else:
        # HuggingFace model ID
        manager = get_global_manager()
        return manager.load_model_for_inference(
            model_id=model_id_or_path,
            auto_download=auto_download,
            **kwargs,
        )


def list_available_models(
    filter_by: Optional[str] = None,
    cache_dir: Optional[Path] = None,
) -> List[ModelInfo]:
    """
    List models available in cache or on HuggingFace.

    Args:
        filter_by: Optional filter string (matches model_id).
        cache_dir: Optional cache directory.

    Returns:
        List of ModelInfo for available models.

    Example:
        >>> models = list_available_models(filter_by="qwen")
        >>> for model in models:
        ...     print(f"{model.model_id}: {model.memory_footprint_mb:.1f} MB")
    """
    manager = ModelManager(cache_dir=cache_dir)
    models = manager.list_cached_models()

    if filter_by:
        filter_lower = filter_by.lower()
        models = [m for m in models if filter_lower in m.model_id.lower()]

    return models


def get_model_info(
    model_id: str,
    revision: str = "main",
    cache_dir: Optional[Path] = None,
) -> Optional[ModelInfo]:
    """
    Get detailed information about a model.

    Args:
        model_id: HuggingFace model identifier.
        revision: Git revision.
        cache_dir: Optional cache directory.

    Returns:
        ModelInfo if model is available, None otherwise.

    Example:
        >>> info = get_model_info("mlx-community/Qwen2.5-Coder-7B-Instruct-4bit")
        >>> if info:
        ...     print(f"Model type: {info.model_type}")
        ...     print(f"Memory: {info.memory_footprint_mb} MB")
        ...     print(f"Layers: {info.num_layers}")
    """
    manager = ModelManager(cache_dir=cache_dir)
    return manager.get_model_info(model_id, revision)


def download_model(
    model_id: str,
    quantization: Optional[str] = None,
    revision: str = "main",
    cache_dir: Optional[Path] = None,
    force: bool = False,
) -> ModelInfo:
    """
    Download a model from HuggingFace Hub.

    Args:
        model_id: HuggingFace model identifier.
        quantization: Optional quantization type.
        revision: Git revision.
        cache_dir: Optional cache directory.
        force: Force re-download even if cached.

    Returns:
        ModelInfo with model metadata.

    Example:
        >>> info = download_model(
        ...     "Qwen/Qwen2.5-Coder-7B",
        ...     quantization="q4_0",
        ... )
        >>> print(f"Downloaded to: {info.cache_path}")
    """
    manager = ModelManager(cache_dir=cache_dir)
    return manager.download_model(
        model_id=model_id,
        quantization=quantization,
        revision=revision,
        force_download=force,
    )


def validate_model(
    model_id: str,
    auto_download: bool = False,
    cache_dir: Optional[Path] = None,
) -> ValidationResult:
    """
    Validate that a model is compatible with MLX-LLM.

    Args:
        model_id: HuggingFace model identifier.
        auto_download: Download model if not cached.
        cache_dir: Optional cache directory.

    Returns:
        ValidationResult with validation status and messages.

    Example:
        >>> result = validate_model("Qwen/Qwen2.5-Coder-7B")
        >>> print(result)  # Prints formatted validation report
        >>> if result.is_valid:
        ...     print("✓ Model is ready to use")
    """
    manager = ModelManager(cache_dir=cache_dir)
    return manager.validate_model_compatibility(
        model_id=model_id,
        auto_download=auto_download,
    )


# Convenience shortcuts
def quick_load(model_id: str, **kwargs) -> Tuple[nn.Module, Tokenizer]:
    """
    Quick shortcut for load_model_from_hub.

    Example:
        >>> model, tokenizer = quick_load("mlx-community/Qwen2.5-Coder-7B-Instruct-4bit")
    """
    return load_model_from_hub(model_id, **kwargs)


def quick_engine(model_id: str, **kwargs):
    """
    Quick shortcut for prepare_model_for_inference.

    Example:
        >>> engine = quick_engine("Qwen/Qwen2.5-Coder-7B", quantization="q4_0")
    """
    return prepare_model_for_inference(model_id, **kwargs)
