# SPDX-License-Identifier: Apache-2.0
"""Model conversion utilities integrating with MLX conversion tools."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from mlxllm.models.download import ModelDownloader
from mlxllm.models.info import ModelInfo

logger = logging.getLogger(__name__)


class ModelConverter:
    """
    Convert models to MLX format with quantization.

    Integrates with tools/mlx_conversion/mlx_converter.py to provide
    high-level conversion API.
    """

    def __init__(self):
        """Initialize model converter."""
        self.downloader = ModelDownloader()

    def convert_to_mlx(
        self,
        source: str,
        output_dir: Path,
        quantization: str = "q4_0",
        optimize: bool = True,
        trust_remote_code: bool = False,
    ) -> Path:
        """
        Convert any model to MLX format.

        This method:
        1. Downloads source model if needed
        2. Converts to MLX format
        3. Applies quantization if requested
        4. Optimizes for inference

        Args:
            source: HuggingFace model ID or local path.
            output_dir: Directory to save converted model.
            quantization: Quantization type (q4_0, q8_0, etc.).
            optimize: Whether to optimize for inference.
            trust_remote_code: Whether to trust remote code.

        Returns:
            Path to converted model directory.

        Raises:
            RuntimeError: If conversion fails.

        Example:
            >>> converter = ModelConverter()
            >>> output = converter.convert_to_mlx(
            ...     "Qwen/Qwen2.5-Coder-7B",
            ...     Path("./models/qwen-mlx"),
            ...     quantization="q4_0",
            ... )
        """
        from tools.mlx_conversion.mlx_converter import MLXConverter

        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"Converting {source} to MLX format")

        # Check if source is local path or model ID
        source_path = Path(source)
        if not source_path.exists():
            # Download from HuggingFace
            logger.info(f"Downloading model: {source}")
            source_path = self.downloader.download_from_hub(
                model_id=source,
                trust_remote_code=trust_remote_code,
            )

        # Use MLX converter
        converter = MLXConverter()

        try:
            output_path = converter.convert_model(
                source_path=source_path,
                output_path=output_dir,
                quantization=quantization,
                trust_remote_code=trust_remote_code,
            )

            logger.info(f"Successfully converted model to: {output_path}")

            # Optimize if requested
            if optimize:
                logger.info("Optimizing model for inference...")
                self.optimize_for_inference(output_path)

            return output_path

        except Exception as e:
            logger.error(f"Conversion failed: {e}")
            raise RuntimeError(f"Model conversion failed: {e}") from e

    def quantize_model(
        self,
        model_path: Path,
        quantization: str,
        output_path: Optional[Path] = None,
    ) -> Path:
        """
        Quantize an existing MLX model.

        Args:
            model_path: Path to MLX model.
            quantization: Quantization type (q4_0, q8_0, etc.).
            output_path: Output path (None = overwrite input).

        Returns:
            Path to quantized model.

        Example:
            >>> converter = ModelConverter()
            >>> quantized = converter.quantize_model(
            ...     Path("./models/qwen-mlx"),
            ...     quantization="q4_0",
            ... )
        """
        from mlx_lm.convert import convert as mlx_convert

        model_path = Path(model_path)

        if output_path is None:
            output_path = model_path.parent / f"{model_path.name}-{quantization}"

        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)

        logger.info(f"Quantizing model to {quantization}")

        try:
            # Map quantization string to MLX format
            quant_config = self._get_quantization_config(quantization)

            mlx_convert(
                hf_path=str(model_path),
                mlx_path=str(output_path),
                quantize=quant_config,
            )

            logger.info(f"Quantized model saved to: {output_path}")
            return output_path

        except Exception as e:
            logger.error(f"Quantization failed: {e}")
            raise RuntimeError(f"Model quantization failed: {e}") from e

    def optimize_for_inference(self, model_path: Path) -> None:
        """
        Optimize MLX model for inference.

        This may include:
        - Removing training-only layers
        - Fusing operations
        - Optimizing memory layout

        Args:
            model_path: Path to MLX model.

        Example:
            >>> converter.optimize_for_inference(Path("./models/qwen-mlx"))
        """
        logger.info(f"Optimizing model: {model_path}")

        # Currently a placeholder - future optimizations can be added here
        # For example:
        # - Remove dropout layers
        # - Fuse LayerNorm + Linear
        # - Optimize KV cache layout
        # - etc.

        logger.info("Optimization complete")

    def convert_from_pytorch(
        self,
        pytorch_path: Path,
        output_dir: Path,
        quantization: Optional[str] = None,
    ) -> Path:
        """
        Convert from PyTorch checkpoint to MLX format.

        Args:
            pytorch_path: Path to PyTorch checkpoint (.pt, .pth, .bin).
            output_dir: Output directory.
            quantization: Optional quantization.

        Returns:
            Path to converted model.

        Example:
            >>> converter.convert_from_pytorch(
            ...     Path("./checkpoint.pt"),
            ...     Path("./models/converted"),
            ...     quantization="q4_0",
            ... )
        """
        logger.info(f"Converting PyTorch checkpoint: {pytorch_path}")

        # This would require implementing PyTorch -> MLX weight conversion
        # For now, use the standard conversion path via HuggingFace format

        raise NotImplementedError(
            "Direct PyTorch conversion not yet implemented. "
            "Please convert to HuggingFace format first, then use convert_to_mlx()."
        )

    def _get_quantization_config(self, quantization: str) -> dict:
        """
        Get quantization configuration for MLX conversion.

        Args:
            quantization: Quantization string (q4_0, q8_0, etc.).

        Returns:
            Quantization configuration dict.
        """
        # Map common quantization strings to MLX format
        quant_map = {
            "q4_0": {"group_size": 64, "bits": 4},
            "q4_1": {"group_size": 32, "bits": 4},
            "q8_0": {"group_size": 64, "bits": 8},
            "q2": {"group_size": 64, "bits": 2},
            "fp16": None,  # No quantization
            "fp32": None,
        }

        if quantization.lower() in quant_map:
            return quant_map[quantization.lower()]

        # Try to parse custom format like "q4" or "4bit"
        if quantization.startswith("q"):
            try:
                bits = int(quantization[1:])
                return {"group_size": 64, "bits": bits}
            except ValueError:
                pass
        elif "bit" in quantization.lower():
            try:
                bits = int(quantization.lower().replace("bit", ""))
                return {"group_size": 64, "bits": bits}
            except ValueError:
                pass

        logger.warning(f"Unknown quantization format: {quantization}, using default q4_0")
        return {"group_size": 64, "bits": 4}


def convert_model_quick(
    model_id: str,
    output_dir: Path,
    quantization: str = "q4_0",
) -> Path:
    """
    Quick convenience function to convert a model.

    Args:
        model_id: HuggingFace model identifier or local path.
        output_dir: Output directory.
        quantization: Quantization type.

    Returns:
        Path to converted model.

    Example:
        >>> path = convert_model_quick(
        ...     "Qwen/Qwen2.5-Coder-7B",
        ...     Path("./models/qwen-mlx"),
        ...     quantization="q4_0",
        ... )
    """
    converter = ModelConverter()
    return converter.convert_to_mlx(
        source=model_id,
        output_dir=output_dir,
        quantization=quantization,
    )
