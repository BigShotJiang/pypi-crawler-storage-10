# SPDX-License-Identifier: Apache-2.0
"""Model download utilities with progress tracking and retry logic."""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Callable, List, Optional

logger = logging.getLogger(__name__)


class ProgressTracker:
    """
    Track download progress for multiple files.

    Provides progress updates and summary display for downloading
    multiple files (e.g., sharded models).
    """

    def __init__(self, use_rich: bool = True):
        """
        Initialize progress tracker.

        Args:
            use_rich: Whether to use rich progress bars (if available).
        """
        self.use_rich = use_rich
        self.files = {}
        self.total_bytes = 0
        self.downloaded_bytes = 0

        # Try to import rich for better progress display
        self.rich_available = False
        if use_rich:
            try:
                from rich.progress import Progress, BarColumn, DownloadColumn, TransferSpeedColumn, TimeRemainingColumn
                self.rich_available = True
                self._progress = Progress(
                    "[progress.description]{task.description}",
                    BarColumn(),
                    DownloadColumn(),
                    TransferSpeedColumn(),
                    TimeRemainingColumn(),
                )
            except ImportError:
                logger.debug("rich library not available, using basic progress")

    def start(self):
        """Start progress tracking."""
        if self.rich_available and hasattr(self, '_progress'):
            self._progress.start()

    def stop(self):
        """Stop progress tracking."""
        if self.rich_available and hasattr(self, '_progress'):
            self._progress.stop()

    def add_file(self, filename: str, total_size: int):
        """
        Add a file to track.

        Args:
            filename: Name of file being downloaded.
            total_size: Total size in bytes.
        """
        self.files[filename] = {
            "total": total_size,
            "downloaded": 0,
            "task_id": None,
        }
        self.total_bytes += total_size

        if self.rich_available and hasattr(self, '_progress'):
            task_id = self._progress.add_task(
                f"[cyan]{filename}",
                total=total_size,
            )
            self.files[filename]["task_id"] = task_id

    def update(self, filename: str, downloaded: int, total: int):
        """
        Update progress for a file.

        Args:
            filename: Name of file being downloaded.
            downloaded: Bytes downloaded so far.
            total: Total bytes.
        """
        if filename not in self.files:
            self.add_file(filename, total)

        old_downloaded = self.files[filename]["downloaded"]
        delta = downloaded - old_downloaded

        self.files[filename]["downloaded"] = downloaded
        self.downloaded_bytes += delta

        if self.rich_available and hasattr(self, '_progress'):
            task_id = self.files[filename].get("task_id")
            if task_id is not None:
                self._progress.update(task_id, completed=downloaded)
        else:
            # Simple text progress
            percent = (downloaded / total * 100) if total > 0 else 0
            print(f"\r{filename}: {percent:.1f}% ({downloaded}/{total} bytes)", end="")

    def complete(self, filename: str):
        """
        Mark a file as complete.

        Args:
            filename: Name of file that completed.
        """
        if filename in self.files:
            self.files[filename]["downloaded"] = self.files[filename]["total"]

            if self.rich_available and hasattr(self, '_progress'):
                task_id = self.files[filename].get("task_id")
                if task_id is not None:
                    self._progress.update(task_id, completed=self.files[filename]["total"])

    def display_summary(self):
        """Display download summary."""
        total_mb = self.total_bytes / (1024 * 1024)
        downloaded_mb = self.downloaded_bytes / (1024 * 1024)

        print(f"\nDownload Summary:")
        print(f"  Total files: {len(self.files)}")
        print(f"  Total size: {total_mb:.2f} MB")
        print(f"  Downloaded: {downloaded_mb:.2f} MB")


class ModelDownloader:
    """
    Robust model downloader with progress tracking and retry logic.

    Features:
    - Progress tracking with rich/tqdm
    - Retry with exponential backoff
    - Resume capability for interrupted downloads
    - Parallel downloads for sharded models
    """

    def __init__(
        self,
        max_retries: int = 3,
        timeout: int = 300,
        use_progress_bar: bool = True,
    ):
        """
        Initialize model downloader.

        Args:
            max_retries: Maximum number of retry attempts.
            timeout: Timeout in seconds for downloads.
            use_progress_bar: Whether to show progress bars.
        """
        self.max_retries = max_retries
        self.timeout = timeout
        self.use_progress_bar = use_progress_bar

    def download_from_hub(
        self,
        model_id: str,
        revision: Optional[str] = None,
        cache_dir: Optional[Path] = None,
        allow_patterns: Optional[List[str]] = None,
        ignore_patterns: Optional[List[str]] = None,
        progress_callback: Optional[Callable] = None,
    ) -> Path:
        """
        Download model from HuggingFace Hub with retry logic.

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision (branch, tag, or commit).
            cache_dir: Cache directory (None = default HF cache).
            allow_patterns: List of file patterns to download.
            ignore_patterns: List of file patterns to ignore.
            progress_callback: Optional callback for progress updates.

        Returns:
            Path to downloaded model directory.

        Raises:
            RuntimeError: If download fails after retries.
        """
        from huggingface_hub import snapshot_download
        from huggingface_hub.utils import HfHubHTTPError

        logger.info(f"Downloading model: {model_id}")

        # Default file patterns optimized for MLX-LLM
        if allow_patterns is None:
            allow_patterns = [
                "*.safetensors",
                "*.json",
                "*.py",
                "tokenizer.model",
                "*.tiktoken",
                "*.txt",
                "*.jinja",
            ]

        attempt = 0
        last_error = None

        while attempt < self.max_retries:
            try:
                # Download with progress tracking
                if self.use_progress_bar:
                    logger.info(f"Download attempt {attempt + 1}/{self.max_retries}")

                path = snapshot_download(
                    repo_id=model_id,
                    revision=revision,
                    cache_dir=str(cache_dir) if cache_dir else None,
                    allow_patterns=allow_patterns,
                    ignore_patterns=ignore_patterns,
                    resume_download=True,  # Enable resume
                    local_files_only=False,
                )

                logger.info(f"Successfully downloaded model to: {path}")
                return Path(path)

            except HfHubHTTPError as e:
                last_error = e
                logger.warning(f"Download attempt {attempt + 1} failed: {e}")

                if attempt < self.max_retries - 1:
                    # Exponential backoff
                    wait_time = 2 ** attempt
                    logger.info(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)

                attempt += 1

            except Exception as e:
                last_error = e
                logger.error(f"Unexpected error during download: {e}")
                raise RuntimeError(f"Failed to download model: {e}") from e

        # All retries exhausted
        raise RuntimeError(
            f"Failed to download model after {self.max_retries} attempts. "
            f"Last error: {last_error}"
        )

    def download_with_progress(
        self,
        model_id: str,
        revision: Optional[str] = None,
        cache_dir: Optional[Path] = None,
        **kwargs,
    ) -> Path:
        """
        Download with rich progress bar display.

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision.
            cache_dir: Cache directory.
            **kwargs: Additional arguments for download_from_hub.

        Returns:
            Path to downloaded model.
        """
        tracker = ProgressTracker(use_rich=True)
        tracker.start()

        try:
            path = self.download_from_hub(
                model_id=model_id,
                revision=revision,
                cache_dir=cache_dir,
                progress_callback=lambda status: tracker.update(
                    status.get("filename", "unknown"),
                    status.get("downloaded", 0),
                    status.get("total", 0),
                ),
                **kwargs,
            )

            tracker.display_summary()
            return path

        finally:
            tracker.stop()

    def verify_download(self, path: Path) -> bool:
        """
        Verify downloaded model files are complete and valid.

        Args:
            path: Path to model directory.

        Returns:
            True if verification passed, False otherwise.
        """
        logger.info(f"Verifying download: {path}")

        # Check for required files
        required_files = ["config.json"]
        for file in required_files:
            if not (path / file).exists():
                logger.error(f"Required file missing: {file}")
                return False

        # Check for model weights
        weight_files = list(path.glob("*.safetensors"))
        if not weight_files:
            logger.error("No model weight files found (.safetensors)")
            return False

        logger.info(f"Verification passed: found {len(weight_files)} weight files")
        return True

    def resume_download(
        self,
        model_id: str,
        cache_dir: Optional[Path] = None,
        **kwargs,
    ) -> Path:
        """
        Resume an interrupted download.

        Args:
            model_id: HuggingFace model identifier.
            cache_dir: Cache directory.
            **kwargs: Additional arguments.

        Returns:
            Path to downloaded model.
        """
        logger.info(f"Resuming download for: {model_id}")

        # Enable resume in download
        return self.download_from_hub(
            model_id=model_id,
            cache_dir=cache_dir,
            **kwargs,
        )

    def get_model_size(self, model_id: str, revision: str = "main") -> int:
        """
        Get total size of model files without downloading.

        Args:
            model_id: HuggingFace model identifier.
            revision: Git revision.

        Returns:
            Total size in bytes.
        """
        from huggingface_hub import HfApi

        api = HfApi()

        try:
            model_info = api.model_info(model_id, revision=revision)

            total_size = 0
            if hasattr(model_info, "siblings") and model_info.siblings:
                for sibling in model_info.siblings:
                    if sibling.rfilename.endswith((".safetensors", ".json")):
                        total_size += sibling.size if hasattr(sibling, "size") else 0

            return total_size

        except Exception as e:
            logger.warning(f"Could not get model size: {e}")
            return 0


def download_model_quick(
    model_id: str,
    cache_dir: Optional[Path] = None,
    quantization: Optional[str] = None,
) -> Path:
    """
    Quick convenience function to download a model.

    Args:
        model_id: HuggingFace model identifier.
        cache_dir: Optional cache directory.
        quantization: Optional quantization type (appended to model search).

    Returns:
        Path to downloaded model.

    Example:
        >>> path = download_model_quick("Qwen/Qwen2.5-Coder-7B")
        >>> path = download_model_quick("Qwen/Qwen2.5-Coder-7B", quantization="4bit")
    """
    downloader = ModelDownloader()

    # Try to find quantized variant if requested
    if quantization:
        # Try common naming patterns
        quantized_ids = [
            f"{model_id}-{quantization}",
            f"{model_id.rstrip('/')}-{quantization}",
            f"mlx-community/{model_id.split('/')[-1]}-{quantization}",
        ]

        for qid in quantized_ids:
            try:
                return downloader.download_from_hub(qid, cache_dir=cache_dir)
            except Exception:
                continue

    # Fall back to original model ID
    return downloader.download_from_hub(model_id, cache_dir=cache_dir)
