# SPDX-License-Identifier: Apache-2.0
"""Environment variable configuration for MLX-LLM.

This module defines environment variables that can be used to configure
MLX-LLM behavior at runtime.
"""

from __future__ import annotations

import os
from typing import Any


def get_env_bool(name: str, default: bool = False) -> bool:
    """
    Get boolean environment variable.

    Args:
        name: Environment variable name.
        default: Default value if not set.

    Returns:
        Boolean value.
    """
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in ("1", "true", "yes", "on")


def get_env_int(name: str, default: int = 0) -> int:
    """
    Get integer environment variable.

    Args:
        name: Environment variable name.
        default: Default value if not set.

    Returns:
        Integer value.
    """
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def get_env_float(name: str, default: float = 0.0) -> float:
    """
    Get float environment variable.

    Args:
        name: Environment variable name.
        default: Default value if not set.

    Returns:
        Float value.
    """
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


# Model configuration
MLXLLM_MODEL_PATH = os.getenv("MLXLLM_MODEL_PATH", "")
"""Path to model directory or HuggingFace model ID."""

MLXLLM_QUANTIZATION = os.getenv("MLXLLM_QUANTIZATION", "")
"""Quantization type (q4, q8, fp16, bf16, etc.)."""

MLXLLM_MAX_MODEL_LEN = get_env_int("MLXLLM_MAX_MODEL_LEN", 8192)
"""Maximum model context length."""

# Device configuration
MLXLLM_DEVICE = os.getenv("MLXLLM_DEVICE", "auto")
"""Device to use (auto, gpu, cpu)."""

MLXLLM_GPU_MEMORY_FRACTION = get_env_float("MLXLLM_GPU_MEMORY_FRACTION", 0.9)
"""Fraction of GPU memory to use for model and KV cache."""

# Scheduler configuration
MLXLLM_MAX_NUM_SEQS = get_env_int("MLXLLM_MAX_NUM_SEQS", 256)
"""Maximum number of sequences to process concurrently."""

MLXLLM_MAX_NUM_BATCHED_TOKENS = get_env_int("MLXLLM_MAX_NUM_BATCHED_TOKENS", 2048)
"""Maximum number of tokens per batch."""

MLXLLM_SCHEDULING_POLICY = os.getenv("MLXLLM_SCHEDULING_POLICY", "fcfs")
"""Scheduling policy (fcfs, priority, sjf)."""

# KV cache configuration
MLXLLM_BLOCK_SIZE = get_env_int("MLXLLM_BLOCK_SIZE", 16)
"""Block size for paged KV cache."""

MLXLLM_ENABLE_PREFIX_CACHING = get_env_bool("MLXLLM_ENABLE_PREFIX_CACHING", True)
"""Enable prefix caching for repeated prompts."""

# Performance configuration
MLXLLM_ENABLE_CHUNKED_PREFILL = get_env_bool("MLXLLM_ENABLE_CHUNKED_PREFILL", True)
"""Enable chunked prefill for long contexts."""

MLXLLM_MAX_PREFILL_TOKENS = get_env_int("MLXLLM_MAX_PREFILL_TOKENS", 512)
"""Maximum tokens per prefill chunk."""

# Logging and debugging
MLXLLM_LOG_LEVEL = os.getenv("MLXLLM_LOG_LEVEL", "INFO")
"""Logging level (DEBUG, INFO, WARNING, ERROR)."""

MLXLLM_ENABLE_METRICS = get_env_bool("MLXLLM_ENABLE_METRICS", True)
"""Enable performance metrics tracking."""

MLXLLM_ENABLE_TRACING = get_env_bool("MLXLLM_ENABLE_TRACING", False)
"""Enable distributed tracing."""

# Engine configuration
MLXLLM_ENGINE_USE_ASYNC = get_env_bool("MLXLLM_ENGINE_USE_ASYNC", True)
"""Use async engine by default."""

MLXLLM_DISABLE_LOG_STATS = get_env_bool("MLXLLM_DISABLE_LOG_STATS", False)
"""Disable logging of statistics."""


def get_all_env_vars() -> dict[str, Any]:
    """
    Get all MLX-LLM environment variables.

    Returns:
        Dictionary of environment variable names and values.
    """
    return {
        "MLXLLM_MODEL_PATH": MLXLLM_MODEL_PATH,
        "MLXLLM_QUANTIZATION": MLXLLM_QUANTIZATION,
        "MLXLLM_MAX_MODEL_LEN": MLXLLM_MAX_MODEL_LEN,
        "MLXLLM_DEVICE": MLXLLM_DEVICE,
        "MLXLLM_GPU_MEMORY_FRACTION": MLXLLM_GPU_MEMORY_FRACTION,
        "MLXLLM_MAX_NUM_SEQS": MLXLLM_MAX_NUM_SEQS,
        "MLXLLM_MAX_NUM_BATCHED_TOKENS": MLXLLM_MAX_NUM_BATCHED_TOKENS,
        "MLXLLM_SCHEDULING_POLICY": MLXLLM_SCHEDULING_POLICY,
        "MLXLLM_BLOCK_SIZE": MLXLLM_BLOCK_SIZE,
        "MLXLLM_ENABLE_PREFIX_CACHING": MLXLLM_ENABLE_PREFIX_CACHING,
        "MLXLLM_ENABLE_CHUNKED_PREFILL": MLXLLM_ENABLE_CHUNKED_PREFILL,
        "MLXLLM_MAX_PREFILL_TOKENS": MLXLLM_MAX_PREFILL_TOKENS,
        "MLXLLM_LOG_LEVEL": MLXLLM_LOG_LEVEL,
        "MLXLLM_ENABLE_METRICS": MLXLLM_ENABLE_METRICS,
        "MLXLLM_ENABLE_TRACING": MLXLLM_ENABLE_TRACING,
        "MLXLLM_ENGINE_USE_ASYNC": MLXLLM_ENGINE_USE_ASYNC,
        "MLXLLM_DISABLE_LOG_STATS": MLXLLM_DISABLE_LOG_STATS,
    }
