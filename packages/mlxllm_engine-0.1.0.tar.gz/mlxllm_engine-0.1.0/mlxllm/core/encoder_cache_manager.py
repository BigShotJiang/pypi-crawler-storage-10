# SPDX-License-Identifier: Apache-2.0
"""Encoder cache manager for multimodal model embeddings."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mlxllm.config import CacheConfig


class EncoderCacheManager:
    """
    Cache manager for encoder outputs in multimodal models.

    For models with separate encoders (e.g., vision, audio), this manager
    caches the encoder outputs to avoid recomputation for repeated inputs.
    """

    def __init__(
        self,
        cache_config: CacheConfig,
        max_cache_size_mb: int = 512,
    ):
        """
        Initialize encoder cache manager.

        Args:
            cache_config: Cache configuration.
            max_cache_size_mb: Maximum cache size in MB.
        """
        self.cache_config = cache_config
        self.max_cache_size_mb = max_cache_size_mb
        self.max_cache_size_bytes = max_cache_size_mb * 1024 * 1024

        # Cache: input_hash -> (embedding, size_bytes)
        self.cache: dict[int, tuple[Any, int]] = {}

        # Track cache size
        self.current_size_bytes = 0

        # Cache hits/misses for monitoring
        self.hits = 0
        self.misses = 0

    def get(self, input_hash: int) -> Any | None:
        """
        Get cached encoder output.

        Args:
            input_hash: Hash of the input.

        Returns:
            Cached embedding or None if not found.
        """
        if not self.cache_config.enable_embedding_cache:
            return None

        result = self.cache.get(input_hash)

        if result is not None:
            self.hits += 1
            return result[0]

        self.misses += 1
        return None

    def put(self, input_hash: int, embedding: Any, size_bytes: int) -> None:
        """
        Cache encoder output.

        Args:
            input_hash: Hash of the input.
            embedding: Encoder embedding to cache.
            size_bytes: Size of embedding in bytes.
        """
        if not self.cache_config.enable_embedding_cache:
            return

        # Check if we need to evict
        while (
            self.current_size_bytes + size_bytes > self.max_cache_size_bytes
            and self.cache
        ):
            # Evict oldest entry (FIFO)
            oldest_hash = next(iter(self.cache))
            _, evicted_size = self.cache.pop(oldest_hash)
            self.current_size_bytes -= evicted_size

        # Add to cache
        self.cache[input_hash] = (embedding, size_bytes)
        self.current_size_bytes += size_bytes

    def remove(self, input_hash: int) -> None:
        """
        Remove entry from cache.

        Args:
            input_hash: Hash of the input to remove.
        """
        if input_hash in self.cache:
            _, size_bytes = self.cache.pop(input_hash)
            self.current_size_bytes -= size_bytes

    def clear(self) -> None:
        """Clear all cached embeddings."""
        self.cache.clear()
        self.current_size_bytes = 0
        self.hits = 0
        self.misses = 0

    @property
    def size_mb(self) -> float:
        """Get current cache size in MB."""
        return self.current_size_bytes / (1024 * 1024)

    @property
    def utilization(self) -> float:
        """Get cache utilization (0.0-1.0)."""
        return self.current_size_bytes / self.max_cache_size_bytes

    @property
    def hit_rate(self) -> float:
        """Get cache hit rate (0.0-1.0)."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"EncoderCacheManager(size={self.size_mb:.1f}MB, "
            f"entries={len(self.cache)}, "
            f"hit_rate={self.hit_rate:.1%})"
        )
