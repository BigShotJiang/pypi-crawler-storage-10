# SPDX-License-Identifier: Apache-2.0
"""Request queue implementations for different scheduling policies."""

from __future__ import annotations

import heapq
from abc import ABC, abstractmethod
from collections import deque
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mlxllm.sequence import SequenceGroup


class RequestQueue(ABC):
    """Abstract base class for request queues."""

    @abstractmethod
    def push(self, seq_group: SequenceGroup) -> None:
        """Add a sequence group to the queue."""
        pass

    @abstractmethod
    def pop(self) -> SequenceGroup | None:
        """Remove and return the next sequence group."""
        pass

    @abstractmethod
    def remove(self, request_id: str) -> bool:
        """Remove a specific request from the queue."""
        pass

    @abstractmethod
    def __len__(self) -> int:
        """Get number of items in queue."""
        pass

    @abstractmethod
    def __contains__(self, request_id: str) -> bool:
        """Check if request is in queue."""
        pass

    def is_empty(self) -> bool:
        """Check if queue is empty."""
        return len(self) == 0


class FCFSQueue(RequestQueue):
    """First-Come-First-Served (FIFO) queue."""

    def __init__(self):
        """Initialize FCFS queue."""
        self.queue: deque[SequenceGroup] = deque()
        self.request_ids: set[str] = set()

    def push(self, seq_group: SequenceGroup) -> None:
        """Add sequence group to end of queue."""
        self.queue.append(seq_group)
        self.request_ids.add(seq_group.request_id)

    def pop(self) -> SequenceGroup | None:
        """Remove and return first sequence group."""
        if not self.queue:
            return None

        seq_group = self.queue.popleft()
        self.request_ids.discard(seq_group.request_id)
        return seq_group

    def remove(self, request_id: str) -> bool:
        """Remove specific request from queue."""
        if request_id not in self.request_ids:
            return False

        # Find and remove the request
        for i, seq_group in enumerate(self.queue):
            if seq_group.request_id == request_id:
                del self.queue[i]
                self.request_ids.discard(request_id)
                return True

        return False

    def __len__(self) -> int:
        """Get queue length."""
        return len(self.queue)

    def __contains__(self, request_id: str) -> bool:
        """Check if request is in queue."""
        return request_id in self.request_ids

    def __iter__(self):
        """Iterate over queue."""
        return iter(self.queue)


class PriorityQueue(RequestQueue):
    """Priority-based queue (higher priority first)."""

    def __init__(self):
        """Initialize priority queue."""
        # Heap of (-priority, arrival_time, seq_group)
        # Negative priority for max-heap behavior
        self.heap: list[tuple[int, float, SequenceGroup]] = []
        self.request_ids: set[str] = set()
        self.counter = 0  # For stable sorting

    def push(self, seq_group: SequenceGroup) -> None:
        """Add sequence group with priority."""
        # Use negative priority for max-heap
        # Use arrival time as tiebreaker (earlier is better)
        priority = -seq_group.sequences[0].priority
        arrival_time = seq_group.arrival_time

        heapq.heappush(self.heap, (priority, arrival_time, seq_group))
        self.request_ids.add(seq_group.request_id)

    def pop(self) -> SequenceGroup | None:
        """Remove and return highest priority sequence group."""
        if not self.heap:
            return None

        _, _, seq_group = heapq.heappop(self.heap)
        self.request_ids.discard(seq_group.request_id)
        return seq_group

    def remove(self, request_id: str) -> bool:
        """Remove specific request from queue."""
        if request_id not in self.request_ids:
            return False

        # Find and remove from heap
        for i, (_, _, seq_group) in enumerate(self.heap):
            if seq_group.request_id == request_id:
                self.heap[i] = self.heap[-1]
                self.heap.pop()
                if i < len(self.heap):
                    heapq.heapify(self.heap)
                self.request_ids.discard(request_id)
                return True

        return False

    def __len__(self) -> int:
        """Get queue length."""
        return len(self.heap)

    def __contains__(self, request_id: str) -> bool:
        """Check if request is in queue."""
        return request_id in self.request_ids

    def __iter__(self):
        """Iterate over queue (not in priority order)."""
        return (seq_group for _, _, seq_group in self.heap)


class SJFQueue(RequestQueue):
    """Shortest-Job-First queue (shortest estimated output first)."""

    def __init__(self):
        """Initialize SJF queue."""
        # Heap of (estimated_length, arrival_time, seq_group)
        self.heap: list[tuple[int, float, SequenceGroup]] = []
        self.request_ids: set[str] = set()

    def push(self, seq_group: SequenceGroup) -> None:
        """Add sequence group with estimated length."""
        # Estimate based on max_tokens parameter
        estimated_length = self._estimate_length(seq_group)
        arrival_time = seq_group.arrival_time

        heapq.heappush(self.heap, (estimated_length, arrival_time, seq_group))
        self.request_ids.add(seq_group.request_id)

    def pop(self) -> SequenceGroup | None:
        """Remove and return shortest job."""
        if not self.heap:
            return None

        _, _, seq_group = heapq.heappop(self.heap)
        self.request_ids.discard(seq_group.request_id)
        return seq_group

    def remove(self, request_id: str) -> bool:
        """Remove specific request from queue."""
        if request_id not in self.request_ids:
            return False

        # Find and remove from heap
        for i, (_, _, seq_group) in enumerate(self.heap):
            if seq_group.request_id == request_id:
                self.heap[i] = self.heap[-1]
                self.heap.pop()
                if i < len(self.heap):
                    heapq.heapify(self.heap)
                self.request_ids.discard(request_id)
                return True

        return False

    def _estimate_length(self, seq_group: SequenceGroup) -> int:
        """Estimate output length for SJF scheduling."""
        # Get max_tokens from sampling params if available
        if seq_group.sampling_params is not None:
            max_tokens = seq_group.sampling_params.max_tokens
            if max_tokens is not None:
                return max_tokens

        # Default estimate
        return 100

    def __len__(self) -> int:
        """Get queue length."""
        return len(self.heap)

    def __contains__(self, request_id: str) -> bool:
        """Check if request is in queue."""
        return request_id in self.request_ids

    def __iter__(self):
        """Iterate over queue (not in SJF order)."""
        return (seq_group for _, _, seq_group in self.heap)


def create_request_queue(policy: str) -> RequestQueue:
    """
    Create a request queue based on scheduling policy.

    Args:
        policy: Scheduling policy ('fcfs', 'priority', 'sjf').

    Returns:
        RequestQueue instance.

    Raises:
        ValueError: If policy is not recognized.
    """
    policy = policy.lower()

    if policy == "fcfs":
        return FCFSQueue()
    elif policy == "priority":
        return PriorityQueue()
    elif policy == "sjf":
        return SJFQueue()
    else:
        raise ValueError(
            f"Unknown scheduling policy: {policy}. "
            f"Supported policies: fcfs, priority, sjf"
        )
