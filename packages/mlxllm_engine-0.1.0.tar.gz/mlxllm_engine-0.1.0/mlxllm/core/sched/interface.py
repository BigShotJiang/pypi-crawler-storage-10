# SPDX-License-Identifier: Apache-2.0
"""Scheduler interface for MLX-LLM."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mlxllm.core.sched.output import SchedulerOutput
    from mlxllm.sequence import SequenceGroup


class SchedulerInterface(ABC):
    """Abstract interface for request schedulers."""

    @abstractmethod
    def add_request(self, seq_group: SequenceGroup) -> None:
        """
        Add a new request to the scheduler.

        Args:
            seq_group: Sequence group to schedule.
        """
        pass

    @abstractmethod
    def abort_request(self, request_id: str) -> None:
        """
        Abort a request.

        Args:
            request_id: ID of request to abort.
        """
        pass

    @abstractmethod
    def schedule(self) -> SchedulerOutput:
        """
        Schedule requests for execution.

        Returns:
            SchedulerOutput with selected requests and metadata.
        """
        pass

    @abstractmethod
    def free_finished_requests(self) -> None:
        """Free resources for finished requests."""
        pass

    @abstractmethod
    def get_num_unfinished_requests(self) -> int:
        """
        Get number of unfinished requests.

        Returns:
            Count of unfinished requests.
        """
        pass
