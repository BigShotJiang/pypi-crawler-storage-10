# SPDX-License-Identifier: Apache-2.0
"""Main scheduler implementation for MLX-LLM."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

from mlxllm.core.sched.interface import SchedulerInterface
from mlxllm.core.sched.output import ScheduledSequenceGroup, SchedulerOutput
from mlxllm.core.sched.request_queue import create_request_queue
from mlxllm.sequence import SequenceStatus

if TYPE_CHECKING:
    from mlxllm.config import CacheConfig, SchedulerConfig
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.sequence import SequenceGroup


class Scheduler(SchedulerInterface):
    """
    Main scheduler for MLX-LLM.

    Implements continuous batching with:
    - Dynamic request scheduling
    - Block allocation and management
    - Preemption (recompute/swap)
    - M4-optimized batching
    """

    def __init__(
        self,
        scheduler_config: SchedulerConfig,
        cache_config: CacheConfig,
        kv_cache_manager: KVCacheManager,
    ):
        """
        Initialize scheduler.

        Args:
            scheduler_config: Scheduler configuration.
            cache_config: Cache configuration.
            kv_cache_manager: KV cache manager for block allocation.
        """
        self.scheduler_config = scheduler_config
        self.cache_config = cache_config
        self.kv_cache = kv_cache_manager

        # Request queues
        self.waiting = create_request_queue(scheduler_config.policy)
        self.running: list[SequenceGroup] = []
        self.swapped: list[SequenceGroup] = []

        # Metrics
        self.num_scheduled = 0
        self.num_preempted = 0
        self.num_swapped_in = 0
        self.num_swapped_out = 0

    def add_request(self, seq_group: SequenceGroup) -> None:
        """
        Add a new request to the scheduler.

        Args:
            seq_group: Sequence group to schedule.
        """
        self.waiting.push(seq_group)

    def abort_request(self, request_id: str) -> None:
        """
        Abort a request.

        Args:
            request_id: ID of request to abort.
        """
        # Remove from waiting queue
        if self.waiting.remove(request_id):
            return

        # Remove from running
        for i, seq_group in enumerate(self.running):
            if seq_group.request_id == request_id:
                # Free blocks
                for seq in seq_group.sequences:
                    if seq.block_table is not None:
                        for block_id in seq.block_table:
                            self.kv_cache.free(block_id)
                self.running.pop(i)
                return

        # Remove from swapped
        for i, seq_group in enumerate(self.swapped):
            if seq_group.request_id == request_id:
                self.swapped.pop(i)
                return

    def schedule(self) -> SchedulerOutput:
        """
        Schedule requests for execution.

        Returns:
            SchedulerOutput with selected requests and metadata.
        """
        output = SchedulerOutput()

        # Step 1: Try to swap in requests from CPU
        output = self._schedule_swapped(output)

        # Step 2: Schedule running requests (decode phase)
        output = self._schedule_running(output)

        # Step 3: Schedule new requests (prefill phase)
        output = self._schedule_waiting(output)

        # Step 4: Handle preemption if needed
        if self._needs_preemption():
            output = self._preempt_requests(output)

        return output

    def free_finished_requests(self) -> None:
        """Free resources for finished requests."""
        i = 0
        while i < len(self.running):
            seq_group = self.running[i]

            # Check if all sequences are finished
            all_finished = all(
                seq.status == SequenceStatus.FINISHED for seq in seq_group.sequences
            )

            if all_finished:
                # Free blocks
                for seq in seq_group.sequences:
                    if seq.block_table is not None:
                        for block_id in seq.block_table:
                            self.kv_cache.free(block_id)

                # Remove from running
                self.running.pop(i)
            else:
                i += 1

    def get_num_unfinished_requests(self) -> int:
        """
        Get number of unfinished requests.

        Returns:
            Count of unfinished requests.
        """
        return len(self.waiting) + len(self.running) + len(self.swapped)

    def _schedule_swapped(self, output: SchedulerOutput) -> SchedulerOutput:
        """
        Try to swap in requests from CPU to GPU.

        Args:
            output: Current scheduler output.

        Returns:
            Updated scheduler output.
        """
        if not self.swapped:
            return output

        # Try to swap in as many as possible
        i = 0
        while i < len(self.swapped):
            seq_group = self.swapped[i]

            # Check if we can swap in
            if not self._can_swap_in(seq_group):
                break

            # Allocate blocks on GPU
            blocks_to_swap: dict[int, int] = {}
            for seq in seq_group.sequences:
                if seq.cpu_block_table is not None:
                    gpu_blocks = []
                    for cpu_block_id in seq.cpu_block_table:
                        gpu_block_id = self.kv_cache.allocate()
                        if gpu_block_id is None:
                            # Failed to allocate - free what we allocated and stop
                            for bid in gpu_blocks:
                                self.kv_cache.free(bid)
                            return output

                        gpu_blocks.append(gpu_block_id)
                        blocks_to_swap[cpu_block_id] = gpu_block_id

                    seq.block_table = gpu_blocks
                    seq.cpu_block_table = None

            # Move to running
            self.swapped.pop(i)
            self.running.append(seq_group)
            output.swapped_in_groups.append(seq_group)
            output.blocks_to_swap_in.update(blocks_to_swap)
            self.num_swapped_in += 1

        return output

    def _schedule_running(self, output: SchedulerOutput) -> SchedulerOutput:
        """
        Schedule running requests (decode phase).

        Args:
            output: Current scheduler output.

        Returns:
            Updated scheduler output.
        """
        for seq_group in self.running:
            # Skip if already finished
            if all(seq.status == SequenceStatus.FINISHED for seq in seq_group.sequences):
                continue

            # Check if we can allocate new blocks if needed
            needs_new_block = self._needs_new_block(seq_group)

            if needs_new_block and not self._can_allocate_blocks(seq_group, 1):
                # Cannot allocate - will handle in preemption
                output.ignored_groups.append(seq_group)
                continue

            # Allocate new blocks if needed
            if needs_new_block:
                for seq in seq_group.sequences:
                    if seq.status == SequenceStatus.RUNNING:
                        new_block = self.kv_cache.allocate()
                        if new_block is not None:
                            if seq.block_table is None:
                                seq.block_table = []
                            seq.block_table.append(new_block)

            # Add to output (decode with 1 token per sequence)
            scheduled = ScheduledSequenceGroup(
                seq_group=seq_group,
                token_chunk_size=1,
                is_prefill=False,
            )
            output.scheduled_groups.append(scheduled)
            output.num_decode_groups += 1
            output.num_batched_tokens += len(seq_group.sequences)

        return output

    def _schedule_waiting(self, output: SchedulerOutput) -> SchedulerOutput:
        """
        Schedule waiting requests (prefill phase).

        Args:
            output: Current scheduler output.

        Returns:
            Updated scheduler output.
        """
        # Check if we have budget for more tokens
        while not self.waiting.is_empty():
            seq_group = self.waiting.pop()
            if seq_group is None:
                break

            # Get prompt length
            prompt_len = seq_group.sequences[0].seq_len

            # Check token budget
            if self.scheduler_config.max_num_batched_tokens is not None and \
               output.num_batched_tokens + prompt_len > self.scheduler_config.max_num_batched_tokens:
                # Put back and stop
                self.waiting.push(seq_group)
                break

            # Check if we can allocate blocks
            num_blocks_needed = self._get_num_blocks_needed(seq_group)
            if not self._can_allocate_blocks(seq_group, num_blocks_needed):
                # Cannot allocate - put back and stop
                self.waiting.push(seq_group)
                break

            # Allocate blocks for each sequence
            for seq in seq_group.sequences:
                if not self.kv_cache.allocate_sequence(seq):
                    # Failed to allocate - this shouldn't happen as we checked can_allocate
                    # Put back and stop
                    self.waiting.push(seq_group)
                    break

            # Determine chunk size (chunked prefill)
            if self.scheduler_config.max_num_batched_tokens is not None:
                chunk_size = min(
                    prompt_len,
                    self.scheduler_config.max_num_batched_tokens - output.num_batched_tokens,
                )
            else:
                chunk_size = prompt_len

            # Add to running and output
            self.running.append(seq_group)
            scheduled = ScheduledSequenceGroup(
                seq_group=seq_group,
                token_chunk_size=chunk_size,
                is_prefill=True,
            )
            output.scheduled_groups.append(scheduled)
            output.num_prefill_groups += 1
            output.num_batched_tokens += chunk_size
            self.num_scheduled += 1

        return output

    def _preempt_requests(self, output: SchedulerOutput) -> SchedulerOutput:
        """
        Preempt requests to free memory.

        Args:
            output: Current scheduler output.

        Returns:
            Updated scheduler output.
        """
        # Preempt lowest priority running requests
        # Sort by priority (lowest first)
        preempt_candidates = sorted(
            self.running,
            key=lambda sg: sg.sequences[0].priority if sg.sequences else 0,
        )

        for seq_group in preempt_candidates:
            if not self._needs_preemption():
                break

            # Choose preemption mode
            if self.scheduler_config.preemption_mode == "recompute":
                # Free all blocks
                for seq in seq_group.sequences:
                    if seq.block_table is not None:
                        for block_id in seq.block_table:
                            self.kv_cache.free(block_id)
                        seq.block_table = None

                # Move back to waiting
                self.running.remove(seq_group)
                self.waiting.push(seq_group)
                output.preempted_groups.append(seq_group)

            elif self.scheduler_config.preemption_mode == "swap":
                # Swap blocks to CPU
                blocks_to_swap: dict[int, int] = {}
                for seq in seq_group.sequences:
                    if seq.block_table is not None:
                        cpu_blocks = []
                        for gpu_block_id in seq.block_table:
                            # Allocate CPU block (using negative IDs)
                            cpu_block_id = -(len(blocks_to_swap) + 1)
                            blocks_to_swap[gpu_block_id] = cpu_block_id
                            cpu_blocks.append(cpu_block_id)

                        seq.cpu_block_table = cpu_blocks
                        # Free GPU blocks
                        for block_id in seq.block_table:
                            self.kv_cache.free(block_id)
                        seq.block_table = None

                # Move to swapped
                self.running.remove(seq_group)
                self.swapped.append(seq_group)
                output.swapped_out_groups.append(seq_group)
                output.blocks_to_swap_out.update(blocks_to_swap)
                self.num_swapped_out += 1

            self.num_preempted += 1

        return output

    def _needs_preemption(self) -> bool:
        """
        Check if preemption is needed.

        Returns:
            True if memory is low and preemption needed.
        """
        # Preempt if less than 10% blocks available
        free_blocks = self.kv_cache.get_num_free_blocks()
        total_blocks = self.kv_cache.gpu_pool.num_blocks
        utilization = 1.0 - (free_blocks / total_blocks) if total_blocks > 0 else 1.0

        return utilization > 0.9

    def _can_swap_in(self, seq_group: SequenceGroup) -> bool:
        """
        Check if we can swap in a request.

        Args:
            seq_group: Sequence group to check.

        Returns:
            True if swap-in is possible.
        """
        # Count blocks needed
        num_blocks = 0
        for seq in seq_group.sequences:
            if seq.cpu_block_table is not None:
                num_blocks += len(seq.cpu_block_table)

        return self.kv_cache.get_num_free_blocks() >= num_blocks

    def _can_allocate_blocks(
        self,
        seq_group: SequenceGroup,
        num_blocks: int,
    ) -> bool:
        """
        Check if we can allocate blocks.

        Args:
            seq_group: Sequence group.
            num_blocks: Number of blocks needed per sequence.

        Returns:
            True if allocation is possible.
        """
        total_blocks_needed = num_blocks * len(seq_group.sequences)
        return self.kv_cache.get_num_free_blocks() >= total_blocks_needed

    def _needs_new_block(self, seq_group: SequenceGroup) -> bool:
        """
        Check if sequence group needs a new block.

        Args:
            seq_group: Sequence group to check.

        Returns:
            True if new block is needed.
        """
        for seq in seq_group.sequences:
            if seq.status != SequenceStatus.RUNNING:
                continue

            seq_len = seq.seq_len
            if seq.block_table is None:
                return True

            # Check if current block is full
            num_blocks = len(seq.block_table)
            capacity = num_blocks * self.cache_config.kv_cache.block_size

            if seq_len >= capacity:
                return True

        return False

    def _get_num_blocks_needed(self, seq_group: SequenceGroup) -> int:
        """
        Get number of blocks needed for a sequence group.

        Args:
            seq_group: Sequence group.

        Returns:
            Number of blocks needed.
        """
        # Get prompt length
        prompt_len = seq_group.sequences[0].seq_len

        # Account for potential output tokens
        max_output_tokens = (
            seq_group.sampling_params.max_tokens
            if seq_group.sampling_params is not None
            and seq_group.sampling_params.max_tokens is not None
            else self.scheduler_config.max_model_len
        )

        total_len = prompt_len + max_output_tokens

        # Calculate blocks needed
        block_size = self.cache_config.kv_cache.block_size
        num_blocks = (total_len + block_size - 1) // block_size

        return num_blocks

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"Scheduler("
            f"waiting={len(self.waiting)}, "
            f"running={len(self.running)}, "
            f"swapped={len(self.swapped)}, "
            f"scheduled={self.num_scheduled}, "
            f"preempted={self.num_preempted})"
        )
