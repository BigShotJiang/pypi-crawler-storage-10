# SPDX-License-Identifier: Apache-2.0
"""Scheduler output data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mlxllm.sequence import SequenceGroup


class SchedulerOutputType(str, Enum):
    """Type of scheduler output."""

    PREFILL = "prefill"
    """Prefill phase (processing prompt)."""

    DECODE = "decode"
    """Decode phase (generating tokens)."""

    MIXED = "mixed"
    """Mixed batch (both prefill and decode)."""


@dataclass
class ScheduledSequenceGroup:
    """A sequence group that has been scheduled for execution."""

    seq_group: SequenceGroup
    """The sequence group."""

    token_chunk_size: int
    """Number of tokens to process for this group."""

    is_prefill: bool
    """Whether this is a prefill operation."""


@dataclass
class SchedulerOutput:
    """Output from the scheduler containing batched requests."""

    scheduled_groups: list[ScheduledSequenceGroup] = field(default_factory=list)
    """Groups scheduled for execution."""

    num_batched_tokens: int = 0
    """Total number of tokens in the batch."""

    num_prefill_groups: int = 0
    """Number of groups in prefill phase."""

    num_decode_groups: int = 0
    """Number of groups in decode phase."""

    ignored_groups: list[SequenceGroup] = field(default_factory=list)
    """Groups that couldn't be scheduled (e.g., OOM)."""

    preempted_groups: list[SequenceGroup] = field(default_factory=list)
    """Groups that were preempted."""

    swapped_in_groups: list[SequenceGroup] = field(default_factory=list)
    """Groups that were swapped in from CPU."""

    swapped_out_groups: list[SequenceGroup] = field(default_factory=list)
    """Groups that were swapped out to CPU."""

    blocks_to_swap_in: dict[int, int] = field(default_factory=dict)
    """Mapping of block IDs to swap from CPU to GPU."""

    blocks_to_swap_out: dict[int, int] = field(default_factory=dict)
    """Mapping of block IDs to swap from GPU to CPU."""

    blocks_to_copy: dict[int, list[int]] = field(default_factory=dict)
    """Blocks to copy for sequence forking (beam search)."""

    @property
    def is_empty(self) -> bool:
        """Check if output is empty."""
        return len(self.scheduled_groups) == 0

    @property
    def output_type(self) -> SchedulerOutputType:
        """Get output type (prefill, decode, or mixed)."""
        if self.num_prefill_groups > 0 and self.num_decode_groups > 0:
            return SchedulerOutputType.MIXED
        elif self.num_prefill_groups > 0:
            return SchedulerOutputType.PREFILL
        else:
            return SchedulerOutputType.DECODE

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"SchedulerOutput("
            f"groups={len(self.scheduled_groups)}, "
            f"tokens={self.num_batched_tokens}, "
            f"prefill={self.num_prefill_groups}, "
            f"decode={self.num_decode_groups})"
        )
