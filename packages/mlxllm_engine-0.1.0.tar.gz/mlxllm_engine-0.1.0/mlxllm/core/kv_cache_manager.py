# SPDX-License-Identifier: Apache-2.0
"""KV cache manager for coordinating block allocation and sequence management."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.core.block_pool import Block, BlockPool
from mlxllm.core.kv_cache_utils import (
    BlockHasher,
    calculate_num_blocks,
    compute_num_blocks_from_memory,
)

if TYPE_CHECKING:
    from mlxllm.config import KVCacheConfig, ModelConfig
    from mlxllm.sequence import Sequence


class KVCacheManager:
    """
    Main KV cache manager coordinating block allocation and sequence management.

    This manager handles:
    - Block allocation for sequences
    - Prefix caching (sharing blocks for common prefixes)
    - Block deallocation when sequences finish
    - Memory pressure handling
    """

    def __init__(
        self,
        cache_config: KVCacheConfig,
        model_config: ModelConfig,
    ):
        """
        Initialize KV cache manager.

        Args:
            cache_config: KV cache configuration.
            model_config: Model configuration.
        """
        self.cache_config = cache_config
        self.model_config = model_config

        # Extract model parameters
        self.num_layers = model_config.num_layers or 0
        self.num_kv_heads = model_config.num_kv_heads or model_config.num_attention_heads or 0
        self.head_dim = model_config.head_dim or 0

        if self.num_layers == 0 or self.num_kv_heads == 0 or self.head_dim == 0:
            raise ValueError(
                "Model config must specify num_layers, num_kv_heads (or num_attention_heads), "
                "and head_dim"
            )

        # Get dtype size
        from mlxllm.scalar_types import dtype_size_bytes
        # Handle both string and DType enum
        dtype_str = model_config.dtype.value if hasattr(model_config.dtype, 'value') else model_config.dtype
        dtype_bytes = dtype_size_bytes(dtype_str)

        # Determine number of blocks
        if cache_config.num_gpu_blocks is not None:
            num_gpu_blocks = cache_config.num_gpu_blocks
        else:
            # Auto-calculate based on available memory
            num_gpu_blocks = self._auto_calculate_num_blocks(dtype_bytes)

        # Create Metal block pool
        self.gpu_pool = BlockPool(
            num_blocks=num_gpu_blocks,
            block_size=cache_config.block_size,
            num_layers=self.num_layers,
            num_kv_heads=self.num_kv_heads,
            head_dim=self.head_dim,
            dtype=dtype_str,
            device="metal",
        )

        # Create CPU block pool for offloading (if enabled)
        self.cpu_pool: BlockPool | None = None
        if cache_config.num_cpu_blocks is not None and cache_config.num_cpu_blocks > 0:
            self.cpu_pool = BlockPool(
                num_blocks=cache_config.num_cpu_blocks,
                block_size=cache_config.block_size,
                num_layers=self.num_layers,
                num_kv_heads=self.num_kv_heads,
                head_dim=self.head_dim,
                dtype=dtype_str,
                device="cpu",
            )

        # Block hasher for prefix caching
        self.block_hasher = BlockHasher(cache_config.block_size)

        # Track sequence to blocks mapping
        self.seq_to_blocks: dict[str, list[Block]] = {}

    def _auto_calculate_num_blocks(self, dtype_bytes: int) -> int:
        """
        Auto-calculate number of GPU blocks based on available memory.

        Args:
            dtype_bytes: Bytes per element.

        Returns:
            Number of blocks.
        """
        # Calculate based on swap_space_gb from cache config
        # This represents the memory budget for KV cache
        kv_cache_memory_gb = self.cache_config.swap_space_gb

        # If swap space is 0, use a reasonable default based on typical M4 setup
        if kv_cache_memory_gb <= 0:
            # For 30GB M4: assume 20GB available, allocate 4GB to KV cache
            kv_cache_memory_gb = 4.0

        memory_bytes = int(kv_cache_memory_gb * 1024**3)

        num_blocks = compute_num_blocks_from_memory(
            memory_bytes=memory_bytes,
            block_size=self.cache_config.block_size,
            num_layers=self.num_layers,
            num_kv_heads=self.num_kv_heads,
            head_dim=self.head_dim,
            dtype_bytes=dtype_bytes,
        )

        # Ensure at least 16 blocks (minimum viable)
        # 16 blocks * 16 tokens/block = 256 tokens minimum
        return max(num_blocks, 16)

    def can_allocate(self, num_blocks: int) -> bool:
        """
        Check if we can allocate the requested number of blocks.

        Args:
            num_blocks: Number of blocks needed.

        Returns:
            True if allocation is possible, False otherwise.
        """
        return self.gpu_pool.num_free_blocks >= num_blocks

    def allocate(self) -> int | None:
        """
        Allocate a single block.

        Returns:
            Block ID if successful, None if OOM.
        """
        block = self.gpu_pool.allocate_block()
        return block.block_id if block is not None else None

    def free(self, block_id: int) -> None:
        """
        Free a single block by ID.

        Args:
            block_id: Block ID to free.
        """
        self.gpu_pool.free_block_by_id(block_id)

    def allocate_sequence(self, sequence: Sequence) -> bool:
        """
        Allocate blocks for a sequence.

        Args:
            sequence: Sequence to allocate blocks for.

        Returns:
            True if allocation successful, False if OOM.
        """
        seq_len = sequence.seq_len
        num_blocks_needed = calculate_num_blocks(seq_len, self.cache_config.block_size)

        # Check if we can allocate
        if not self.can_allocate(num_blocks_needed):
            return False

        # Try prefix caching if enabled
        allocated_blocks: list[Block] = []

        if self.cache_config.enable_prefix_caching:
            # Try to find cached blocks
            token_ids = sequence.data.all_token_ids

            for block_idx in range(num_blocks_needed):
                block_hash = self.block_hasher.hash_block(token_ids, block_idx)
                cached_block = self.gpu_pool.get_cached_block(block_hash)

                if cached_block is not None:
                    # Found cached block, share it
                    allocated_blocks.append(cached_block)
                else:
                    # Need to allocate new block
                    new_block = self.gpu_pool.allocate_block()
                    if new_block is None:
                        # OOM - free allocated blocks and fail
                        self._free_blocks(allocated_blocks)
                        return False

                    allocated_blocks.append(new_block)

                    # Add to prefix cache
                    self.gpu_pool.cache_block(block_hash, new_block)
        else:
            # No prefix caching - allocate all blocks
            for _ in range(num_blocks_needed):
                block = self.gpu_pool.allocate_block()
                if block is None:
                    # OOM - free allocated blocks and fail
                    self._free_blocks(allocated_blocks)
                    return False

                allocated_blocks.append(block)

        # Store blocks for sequence
        self.seq_to_blocks[sequence.seq_id] = allocated_blocks

        # Update sequence block IDs
        sequence.block_ids = [block.block_id for block in allocated_blocks]

        return True

    def append_token_slots(self, sequence: Sequence) -> bool:
        """
        Allocate additional blocks if sequence grows beyond current allocation.

        Args:
            sequence: Sequence that may need more blocks.

        Returns:
            True if successful, False if OOM.
        """
        seq_len = sequence.seq_len
        num_blocks_needed = calculate_num_blocks(seq_len, self.cache_config.block_size)

        current_blocks = self.seq_to_blocks.get(sequence.seq_id, [])
        num_current_blocks = len(current_blocks)

        if num_blocks_needed <= num_current_blocks:
            # Already have enough blocks
            return True

        # Need more blocks
        num_new_blocks = num_blocks_needed - num_current_blocks

        if not self.can_allocate(num_new_blocks):
            return False

        # Allocate new blocks
        new_blocks: list[Block] = []
        for _ in range(num_new_blocks):
            block = self.gpu_pool.allocate_block()
            if block is None:
                # OOM - free newly allocated blocks
                self._free_blocks(new_blocks)
                return False

            new_blocks.append(block)

        # Add to sequence blocks
        current_blocks.extend(new_blocks)
        self.seq_to_blocks[sequence.seq_id] = current_blocks

        # Update sequence block IDs
        sequence.block_ids = [block.block_id for block in current_blocks]

        return True

    def get_block_table(self, seq_id: str) -> list[int]:
        """
        Get the block table (list of block IDs) for a sequence.

        Args:
            seq_id: Sequence ID.

        Returns:
            List of block IDs allocated to this sequence.
        """
        blocks = self.seq_to_blocks.get(seq_id, [])
        return [block.block_id for block in blocks]

    def free_sequence(self, sequence: Sequence) -> None:
        """
        Free all blocks for a sequence.

        Args:
            sequence: Sequence to free blocks for.
        """
        blocks = self.seq_to_blocks.get(sequence.seq_id)
        if blocks is None:
            return

        # Free all blocks
        self._free_blocks(blocks)

        # Remove from tracking
        del self.seq_to_blocks[sequence.seq_id]
        sequence.block_ids.clear()

    def _free_blocks(self, blocks: list[Block]) -> None:
        """
        Free a list of blocks.

        Args:
            blocks: Blocks to free.
        """
        for block in blocks:
            self.gpu_pool.free_block(block)

    def get_num_free_blocks(self) -> int:
        """Get number of free GPU blocks."""
        return self.gpu_pool.num_free_blocks

    def get_num_allocated_blocks(self) -> int:
        """Get number of allocated GPU blocks."""
        return self.gpu_pool.num_allocated_blocks

    def get_utilization(self) -> float:
        """Get GPU pool utilization (0.0-1.0)."""
        return self.gpu_pool.utilization

    def get_memory_usage(self) -> int:
        """
        Get total memory usage in bytes.

        Returns:
            Memory usage in bytes.
        """
        total = self.gpu_pool.get_memory_usage()

        if self.cpu_pool is not None:
            total += self.cpu_pool.get_memory_usage()

        return total

    def get_kv_cache(self) -> list | None:
        """
        Get KV cache tensors for all layers.

        Returns:
            List of KV cache arrays per layer, or None if no blocks allocated.
            Each array has shape [2, num_blocks * block_size, num_kv_heads, head_dim]
            where 2 represents K and V caches.
        """
        # Return the GPU pool's blocks (the actual cache data)
        # The model will index into this using the block tables from AttentionMetadata
        if self.gpu_pool.num_allocated_blocks == 0:
            return None

        # Collect all allocated block data
        # In a real implementation, we'd return a view or reference to the block pool
        # For now, return None to signal the model should use block table indexing
        return None

    def reset(self) -> None:
        """Reset cache manager to initial state."""
        self.gpu_pool.reset()

        if self.cpu_pool is not None:
            self.cpu_pool.reset()

        self.seq_to_blocks.clear()
        self.block_hasher.clear_cache()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"KVCacheManager(gpu_blocks={self.gpu_pool.num_blocks}, "
            f"free={self.get_num_free_blocks()}, "
            f"utilization={self.get_utilization():.1%})"
        )
