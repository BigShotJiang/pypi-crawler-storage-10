# SPDX-License-Identifier: Apache-2.0
"""Single-type KV cache manager for homogeneous request batches."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.core.kv_cache_manager import KVCacheManager

if TYPE_CHECKING:
    from mlxllm.config import KVCacheConfig, ModelConfig
    from mlxllm.sequence import Sequence


class SingleTypeKVCacheManager(KVCacheManager):
    """
    KV cache manager optimized for single request type (e.g., all generation).

    This manager assumes all sequences are of the same type, allowing for
    optimizations like uniform block allocation patterns and simplified
    memory management.
    """

    def __init__(
        self,
        cache_config: KVCacheConfig,
        model_config: ModelConfig,
    ):
        """
        Initialize single-type KV cache manager.

        Args:
            cache_config: KV cache configuration.
            model_config: Model configuration.
        """
        super().__init__(cache_config, model_config)

        # Track if all sequences are using same pattern
        self.uniform_allocation = True

        # Common block size for all sequences (if uniform)
        self.common_num_blocks: int | None = None

    def allocate_sequence(self, sequence: Sequence) -> bool:
        """
        Allocate blocks for a sequence with single-type optimization.

        Args:
            sequence: Sequence to allocate blocks for.

        Returns:
            True if allocation successful, False if OOM.
        """
        success = super().allocate_sequence(sequence)

        if success and self.uniform_allocation:
            # Track if allocation pattern is uniform
            num_blocks = len(self.seq_to_blocks[sequence.seq_id])

            if self.common_num_blocks is None:
                self.common_num_blocks = num_blocks
            elif self.common_num_blocks != num_blocks:
                # Pattern is no longer uniform
                self.uniform_allocation = False
                self.common_num_blocks = None

        return success

    def can_allocate_batch(self, num_sequences: int, seq_len: int) -> bool:
        """
        Check if we can allocate for an entire batch of uniform sequences.

        Args:
            num_sequences: Number of sequences in batch.
            seq_len: Length of each sequence.

        Returns:
            True if batch can be allocated, False otherwise.
        """
        from mlxllm.core.kv_cache_utils import calculate_num_blocks

        blocks_per_seq = calculate_num_blocks(seq_len, self.cache_config.block_size)
        total_blocks_needed = blocks_per_seq * num_sequences

        return self.can_allocate(total_blocks_needed)

    def get_uniform_block_count(self) -> int | None:
        """
        Get common block count if allocation is uniform.

        Returns:
            Number of blocks per sequence if uniform, None otherwise.
        """
        return self.common_num_blocks if self.uniform_allocation else None

    def reset(self) -> None:
        """Reset manager and uniform allocation tracking."""
        super().reset()
        self.uniform_allocation = True
        self.common_num_blocks = None
