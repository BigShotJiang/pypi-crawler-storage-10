# SPDX-License-Identifier: Apache-2.0
"""KV cache coordinator for managing offloading and multi-pool coordination."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.kv_offload.abstract import KVOffloadBackend, KVOffloadManager

if TYPE_CHECKING:
    from mlxllm.core.kv_cache_manager import KVCacheManager
    from mlxllm.sequence import Sequence


class KVCacheCoordinator:
    """
    Coordinates KV cache between GPU and offload storage.

    This coordinator sits above the KVCacheManager and handles:
    - Offloading blocks to CPU/disk when GPU memory is full
    - Loading blocks back to GPU when needed
    - Coordinating eviction policies
    - Managing memory pressure
    """

    def __init__(
        self,
        cache_manager: KVCacheManager,
        offload_backend: KVOffloadBackend | None = None,
        offload_manager: KVOffloadManager | None = None,
    ):
        """
        Initialize KV cache coordinator.

        Args:
            cache_manager: Main KV cache manager.
            offload_backend: Offload backend (no offloading if None).
            offload_manager: Offload manager (no offloading if None).
        """
        self.cache_manager = cache_manager
        self.offload_backend = offload_backend
        self.offload_manager = offload_manager

        # Track which blocks are offloaded
        self.offloaded_blocks: set[int] = set()

        # Enable offloading only if both backend and manager are provided
        self.offloading_enabled = (
            offload_backend is not None and offload_manager is not None
        )

    def should_offload(self) -> bool:
        """
        Check if offloading should occur.

        Returns:
            True if offloading is needed.
        """
        if not self.offloading_enabled:
            return False

        # Get number of free GPU blocks
        num_free_blocks = self.cache_manager.gpu_pool.get_num_free_blocks()

        # Ask manager if we should offload
        return self.offload_manager.should_offload(num_free_blocks)

    def offload_blocks(self, num_blocks: int) -> int:
        """
        Offload least recently used blocks to free GPU memory.

        Args:
            num_blocks: Number of blocks to offload.

        Returns:
            Number of blocks actually offloaded.
        """
        if not self.offloading_enabled:
            return 0

        # Get block access times from cache manager
        block_access_times = self._get_block_access_times()

        # Ask manager which blocks to offload
        blocks_to_offload = self.offload_manager.select_blocks_to_offload(
            block_access_times, num_blocks
        )

        # Offload selected blocks
        num_offloaded = 0
        for block_id in blocks_to_offload:
            if self._offload_block(block_id):
                num_offloaded += 1

        return num_offloaded

    def _offload_block(self, block_id: int) -> bool:
        """
        Offload a single block.

        Args:
            block_id: Block ID to offload.

        Returns:
            True if offload succeeded.
        """
        if not self.offloading_enabled:
            return False

        # Get block from GPU pool
        block = self.cache_manager.gpu_pool.get_block_by_id(block_id)
        if block is None:
            return False

        # Get block data
        kv_data = block.kv_data
        if kv_data is None:
            return False

        # Offload to backend
        try:
            self.offload_backend.offload_block(block_id, kv_data)
            self.offloaded_blocks.add(block_id)

            # Free block from GPU pool
            self.cache_manager.gpu_pool.free_block(block)

            return True

        except Exception as e:
            print(f"Failed to offload block {block_id}: {e}")
            return False

    def load_block(self, block_id: int) -> bool:
        """
        Load offloaded block back to GPU.

        Args:
            block_id: Block ID to load.

        Returns:
            True if load succeeded.
        """
        if not self.offloading_enabled:
            return False

        if block_id not in self.offloaded_blocks:
            return False

        # Load from backend
        try:
            kv_data = self.offload_backend.load_block(block_id)
            if kv_data is None:
                return False

            # Allocate GPU block
            gpu_block = self.cache_manager.gpu_pool.allocate_block()
            if gpu_block is None:
                # No space - need to offload first
                if self.offload_blocks(1) > 0:
                    gpu_block = self.cache_manager.gpu_pool.allocate_block()

                if gpu_block is None:
                    return False

            # Copy data to GPU block
            gpu_block.kv_data = kv_data

            # Remove from offloaded set
            self.offloaded_blocks.remove(block_id)

            # Free from offload storage
            self.offload_backend.free_block(block_id)

            return True

        except Exception as e:
            print(f"Failed to load block {block_id}: {e}")
            return False

    def _get_block_access_times(self) -> dict[int, float]:
        """
        Get access times for all allocated blocks.

        Returns:
            Map of block_id -> last_access_time.
        """
        import time

        # This is a simplified version
        # In practice, would track actual access times
        block_times = {}
        current_time = time.time()

        for block in self.cache_manager.gpu_pool.blocks:
            if block.ref_count > 0:
                # Use ref count as proxy for access time
                # More refs = more recent
                block_times[block.block_id] = current_time - (1.0 / block.ref_count)

        return block_times

    def allocate_blocks_for_sequence(
        self,
        seq: Sequence,
        num_blocks: int,
    ) -> list[int]:
        """
        Allocate blocks for sequence, offloading if needed.

        Args:
            seq: Sequence requesting blocks.
            num_blocks: Number of blocks needed.

        Returns:
            List of allocated block IDs.
        """
        allocated_blocks = []

        for _ in range(num_blocks):
            # Try to allocate from GPU pool
            block = self.cache_manager.gpu_pool.allocate_block()

            if block is None:
                # Out of memory - offload some blocks
                if self.should_offload():
                    num_offloaded = self.offload_blocks(num_blocks)
                    if num_offloaded > 0:
                        block = self.cache_manager.gpu_pool.allocate_block()

            if block is None:
                # Still no space - allocation failed
                # Free any blocks we allocated
                for block_id in allocated_blocks:
                    self.cache_manager.gpu_pool.free_block_by_id(block_id)
                return []

            allocated_blocks.append(block.block_id)

        return allocated_blocks

    def get_offload_stats(self) -> dict:
        """
        Get offloading statistics.

        Returns:
            Dictionary of statistics.
        """
        if not self.offloading_enabled:
            return {
                "enabled": False,
            }

        stats = self.offload_backend.get_stats()

        return {
            "enabled": True,
            "num_offloaded_blocks": len(self.offloaded_blocks),
            "total_offloaded": stats.num_offloaded_blocks,
            "total_loaded": stats.num_loaded_blocks,
            "bytes_offloaded": stats.bytes_offloaded,
            "bytes_loaded": stats.bytes_loaded,
            "offload_time_ms": stats.offload_time_ms,
            "load_time_ms": stats.load_time_ms,
            "avg_offload_bandwidth_gbps": stats.avg_offload_bandwidth_gbps,
            "avg_load_bandwidth_gbps": stats.avg_load_bandwidth_gbps,
            "cpu_memory_usage_bytes": self.offload_backend.get_memory_usage(),
        }

    def clear_offloaded_blocks(self) -> None:
        """Clear all offloaded blocks."""
        if self.offloading_enabled:
            self.offload_backend.clear()
            self.offloaded_blocks.clear()

    def __repr__(self) -> str:
        """String representation."""
        if not self.offloading_enabled:
            return "KVCacheCoordinator(offloading=disabled)"

        return (
            f"KVCacheCoordinator("
            f"offloading=enabled, "
            f"offloaded_blocks={len(self.offloaded_blocks)}, "
            f"backend={self.offload_backend.__class__.__name__}, "
            f"manager={self.offload_manager.__class__.__name__})"
        )
