# SPDX-License-Identifier: Apache-2.0
"""Core KV cache and scheduling components for MLX-LLM."""

from mlxllm.core.block_pool import Block, BlockPool
from mlxllm.core.kv_cache_manager import KVCacheManager
from mlxllm.core.kv_cache_utils import (
    BlockHasher,
    calculate_num_blocks,
    compute_kv_cache_memory,
    compute_num_blocks_from_memory,
    format_memory_size,
    get_block_hashes,
    hash_block_tokens,
    hash_tokens,
)

__all__ = [
    # Block management
    "Block",
    "BlockPool",
    # KV cache
    "KVCacheManager",
    # Utilities
    "BlockHasher",
    "calculate_num_blocks",
    "compute_kv_cache_memory",
    "compute_num_blocks_from_memory",
    "format_memory_size",
    "get_block_hashes",
    "hash_block_tokens",
    "hash_tokens",
]
