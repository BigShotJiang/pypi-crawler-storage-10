# SPDX-License-Identifier: Apache-2.0
"""Block pool for KV cache memory management in MLX-LLM.

This module implements a memory pool for KV cache blocks, similar to virtual memory
page tables. Blocks are allocated on-demand and can be shared for prefix caching.
"""

from __future__ import annotations

try:
    import mlx.core as mx

    MLX_AVAILABLE = True
except ImportError:
    MLX_AVAILABLE = False
    mx = None


class Block:
    """
    A single KV cache block.

    Each block stores KV cache for a fixed number of tokens (block_size).
    Blocks can be shared across sequences for prefix caching.
    """

    def __init__(
        self,
        block_id: int,
        block_size: int,
        device: str = "metal",
    ):
        """
        Initialize a KV cache block.

        Args:
            block_id: Unique block identifier.
            block_size: Number of tokens this block can hold.
            device: Device where block is allocated ('metal' or 'cpu').
        """
        self.block_id = block_id
        self.block_size = block_size
        self.device = device

        # Reference counting for sharing
        self.ref_count = 0

        # Actual KV cache data (allocated lazily)
        self.data = None

        # Alias for compatibility with coordinator
        self.kv_data = None

    def allocate(
        self,
        num_layers: int,
        num_kv_heads: int,
        head_dim: int,
        dtype: str = "bfloat16",
    ) -> None:
        """
        Allocate memory for the block.

        Args:
            num_layers: Number of transformer layers.
            num_kv_heads: Number of KV heads (for GQA/MQA).
            head_dim: Head dimension.
            dtype: Data type for KV cache.
        """
        if not MLX_AVAILABLE:
            raise RuntimeError("MLX is not available")

        if self.data is not None:
            return  # Already allocated

        # Shape: [num_layers, 2, block_size, num_kv_heads, head_dim]
        # 2 for K and V
        shape = (num_layers, 2, self.block_size, num_kv_heads, head_dim)

        if self.device == "metal":
            # Allocate on Metal (unified memory)
            self.data = mx.zeros(shape, dtype=getattr(mx, dtype))
        else:
            # Allocate on CPU (for offloading)
            # In MLX, all memory is unified, so we just mark it as CPU-accessible
            self.data = mx.zeros(shape, dtype=getattr(mx, dtype))

        # Set kv_data alias
        self.kv_data = self.data

    def free(self) -> None:
        """Free the block's memory."""
        self.data = None
        self.kv_data = None
        self.ref_count = 0

    def increment_ref(self) -> None:
        """Increment reference count (block is shared)."""
        self.ref_count += 1

    def decrement_ref(self) -> int:
        """
        Decrement reference count.

        Returns:
            New reference count.
        """
        self.ref_count = max(0, self.ref_count - 1)
        return self.ref_count

    @property
    def is_free(self) -> bool:
        """Check if block is free (no references)."""
        return self.ref_count == 0

    def __repr__(self) -> str:
        """String representation."""
        return f"Block(id={self.block_id}, refs={self.ref_count}, device={self.device})"


class BlockPool:
    """
    Pool of KV cache blocks with allocation and deallocation.

    Manages a fixed pool of blocks for KV cache storage. Supports:
    - Block allocation and deallocation
    - Reference counting for prefix caching
    - Separate pools for Metal and CPU (for offloading)
    """

    def __init__(
        self,
        num_blocks: int,
        block_size: int,
        num_layers: int,
        num_kv_heads: int,
        head_dim: int,
        dtype: str = "bfloat16",
        device: str = "metal",
    ):
        """
        Initialize block pool.

        Args:
            num_blocks: Total number of blocks in pool.
            block_size: Tokens per block.
            num_layers: Number of transformer layers.
            num_kv_heads: Number of KV heads.
            head_dim: Head dimension.
            dtype: Data type for KV cache.
            device: Device for blocks ('metal' or 'cpu').
        """
        self.num_blocks = num_blocks
        self.block_size = block_size
        self.num_layers = num_layers
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.dtype = dtype
        self.device = device

        # Create all blocks
        self.blocks: list[Block] = [
            Block(block_id=i, block_size=block_size, device=device)
            for i in range(num_blocks)
        ]

        # Free block queue (available blocks)
        self.free_blocks: set[int] = set(range(num_blocks))

        # Track block usage
        self.allocated_blocks: set[int] = set()

        # Prefix caching: hash -> block_id
        self.prefix_hash_to_block: dict[int, int] = {}

        # Block to prefix hash (reverse mapping)
        self.block_to_prefix_hash: dict[int, int] = {}

    def allocate_block(self) -> Block | None:
        """
        Allocate a free block.

        Returns:
            Allocated block, or None if no blocks available.
        """
        if not self.free_blocks:
            return None

        # Get a free block
        block_id = self.free_blocks.pop()
        block = self.blocks[block_id]

        # Allocate memory if needed
        if block.data is None:
            block.allocate(
                self.num_layers,
                self.num_kv_heads,
                self.head_dim,
                self.dtype,
            )

        # Mark as allocated
        block.increment_ref()
        self.allocated_blocks.add(block_id)

        return block

    def free_block(self, block: Block) -> None:
        """
        Free a block (decrement ref count).

        Args:
            block: Block to free.
        """
        new_ref_count = block.decrement_ref()

        if new_ref_count == 0:
            # Block is truly free, return to pool
            self.free_blocks.add(block.block_id)
            self.allocated_blocks.discard(block.block_id)

            # Remove from prefix cache if present
            if block.block_id in self.block_to_prefix_hash:
                prefix_hash = self.block_to_prefix_hash[block.block_id]
                del self.prefix_hash_to_block[prefix_hash]
                del self.block_to_prefix_hash[block.block_id]

    def get_block(self, block_id: int) -> Block:
        """
        Get block by ID.

        Args:
            block_id: Block identifier.

        Returns:
            Block instance.
        """
        return self.blocks[block_id]

    def get_block_by_id(self, block_id: int) -> Block | None:
        """
        Get block by ID with bounds checking.

        Args:
            block_id: Block identifier.

        Returns:
            Block instance or None if invalid ID.
        """
        if 0 <= block_id < len(self.blocks):
            return self.blocks[block_id]
        return None

    def free_block_by_id(self, block_id: int) -> None:
        """
        Free a block by ID.

        Args:
            block_id: Block identifier to free.
        """
        if 0 <= block_id < len(self.blocks):
            block = self.blocks[block_id]
            self.free_block(block)

    def get_num_free_blocks(self) -> int:
        """
        Get number of free blocks.

        Returns:
            Number of free blocks.
        """
        return self.num_free_blocks

    def share_block(self, block: Block) -> None:
        """
        Share a block (increment ref count).

        Args:
            block: Block to share.
        """
        block.increment_ref()

    def get_cached_block(self, prefix_hash: int) -> Block | None:
        """
        Get block from prefix cache.

        Args:
            prefix_hash: Hash of the prefix tokens.

        Returns:
            Cached block, or None if not found.
        """
        block_id = self.prefix_hash_to_block.get(prefix_hash)
        if block_id is None:
            return None

        block = self.blocks[block_id]
        # Increment ref count for sharing
        self.share_block(block)
        return block

    def cache_block(self, prefix_hash: int, block: Block) -> None:
        """
        Add block to prefix cache.

        Args:
            prefix_hash: Hash of the prefix tokens.
            block: Block to cache.
        """
        self.prefix_hash_to_block[prefix_hash] = block.block_id
        self.block_to_prefix_hash[block.block_id] = prefix_hash

    @property
    def num_free_blocks(self) -> int:
        """Get number of free blocks."""
        return len(self.free_blocks)

    @property
    def num_allocated_blocks(self) -> int:
        """Get number of allocated blocks."""
        return len(self.allocated_blocks)

    @property
    def utilization(self) -> float:
        """Get pool utilization (0.0 - 1.0)."""
        return self.num_allocated_blocks / self.num_blocks

    def get_memory_usage(self) -> int:
        """
        Get total memory usage in bytes.

        Returns:
            Memory usage in bytes.
        """
        from mlxllm.scalar_types import dtype_size_bytes

        bytes_per_element = dtype_size_bytes(self.dtype)

        # Each block: num_layers * 2 (K+V) * block_size * num_kv_heads * head_dim
        bytes_per_block = (
            self.num_layers
            * 2
            * self.block_size
            * self.num_kv_heads
            * self.head_dim
            * bytes_per_element
        )

        return bytes_per_block * self.num_allocated_blocks

    def reset(self) -> None:
        """Reset pool to initial state."""
        for block in self.blocks:
            block.free()

        self.free_blocks = set(range(self.num_blocks))
        self.allocated_blocks.clear()
        self.prefix_hash_to_block.clear()
        self.block_to_prefix_hash.clear()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"BlockPool(total={self.num_blocks}, "
            f"free={self.num_free_blocks}, "
            f"allocated={self.num_allocated_blocks}, "
            f"utilization={self.utilization:.1%})"
        )
