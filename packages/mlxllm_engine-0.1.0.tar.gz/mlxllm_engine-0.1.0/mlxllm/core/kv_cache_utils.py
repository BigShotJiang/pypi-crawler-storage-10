# SPDX-License-Identifier: Apache-2.0
"""KV cache utilities for hashing, block management, and memory calculations."""

from __future__ import annotations

import hashlib


def hash_tokens(token_ids: list[int]) -> int:
    """
    Hash a sequence of token IDs for prefix caching.

    Args:
        token_ids: List of token IDs to hash.

    Returns:
        Integer hash value.
    """
    # Convert token IDs to bytes and hash
    # Token IDs can be > 255, so convert each to 4-byte integer
    token_bytes = b''.join(tok.to_bytes(4, byteorder='big', signed=False) for tok in token_ids)
    hash_obj = hashlib.sha256(token_bytes)
    # Return first 8 bytes as integer
    return int.from_bytes(hash_obj.digest()[:8], byteorder="big")


def hash_block_tokens(
    token_ids: list[int],
    block_size: int,
    block_idx: int,
) -> int:
    """
    Hash tokens for a specific block (for prefix caching).

    Args:
        token_ids: Full sequence of token IDs.
        block_size: Size of each block.
        block_idx: Index of the block to hash.

    Returns:
        Hash value for the block.
    """
    start_idx = block_idx * block_size
    end_idx = min(start_idx + block_size, len(token_ids))

    block_tokens = token_ids[start_idx:end_idx]
    return hash_tokens(block_tokens)


def calculate_num_blocks(seq_len: int, block_size: int) -> int:
    """
    Calculate number of blocks needed for a sequence.

    Args:
        seq_len: Sequence length in tokens.
        block_size: Block size in tokens.

    Returns:
        Number of blocks needed.
    """
    return (seq_len + block_size - 1) // block_size


def get_block_token_range(
    block_idx: int,
    block_size: int,
    seq_len: int,
) -> tuple[int, int]:
    """
    Get token range for a block.

    Args:
        block_idx: Index of the block.
        block_size: Size of each block.
        seq_len: Total sequence length.

    Returns:
        Tuple of (start_idx, end_idx) for tokens in this block.
    """
    start_idx = block_idx * block_size
    end_idx = min(start_idx + block_size, seq_len)
    return start_idx, end_idx


def compute_kv_cache_memory(
    num_blocks: int,
    block_size: int,
    num_layers: int,
    num_kv_heads: int,
    head_dim: int,
    dtype_bytes: int = 2,
) -> int:
    """
    Compute KV cache memory usage in bytes.

    Args:
        num_blocks: Number of KV cache blocks.
        block_size: Tokens per block.
        num_layers: Number of transformer layers.
        num_kv_heads: Number of KV heads (for GQA/MQA).
        head_dim: Head dimension.
        dtype_bytes: Bytes per element (2 for fp16/bf16, 4 for fp32).

    Returns:
        Total memory usage in bytes.
    """
    # Each block: 2 (K+V) * num_layers * block_size * num_kv_heads * head_dim
    bytes_per_block = (
        2 * num_layers * block_size * num_kv_heads * head_dim * dtype_bytes
    )

    return num_blocks * bytes_per_block


def compute_num_blocks_from_memory(
    memory_bytes: int,
    block_size: int,
    num_layers: int,
    num_kv_heads: int,
    head_dim: int,
    dtype_bytes: int = 2,
) -> int:
    """
    Compute number of blocks that fit in given memory.

    Args:
        memory_bytes: Available memory in bytes.
        block_size: Tokens per block.
        num_layers: Number of transformer layers.
        num_kv_heads: Number of KV heads.
        head_dim: Head dimension.
        dtype_bytes: Bytes per element.

    Returns:
        Number of blocks that fit in memory.
    """
    bytes_per_block = (
        2 * num_layers * block_size * num_kv_heads * head_dim * dtype_bytes
    )

    return int(memory_bytes / bytes_per_block)


def get_block_hashes(
    token_ids: list[int],
    block_size: int,
) -> list[int]:
    """
    Get hash for each block in the sequence.

    Args:
        token_ids: Full sequence of token IDs.
        block_size: Block size.

    Returns:
        List of hashes, one per block.
    """
    num_blocks = calculate_num_blocks(len(token_ids), block_size)

    hashes = []
    for block_idx in range(num_blocks):
        block_hash = hash_block_tokens(token_ids, block_size, block_idx)
        hashes.append(block_hash)

    return hashes


class BlockHasher:
    """Helper class for hashing blocks with caching."""

    def __init__(self, block_size: int):
        """
        Initialize block hasher.

        Args:
            block_size: Size of each block.
        """
        self.block_size = block_size
        self._cache: dict[tuple[int, ...], int] = {}

    def hash_block(self, token_ids: list[int], block_idx: int) -> int:
        """
        Hash a specific block with caching.

        Args:
            token_ids: Full sequence of token IDs.
            block_idx: Index of the block.

        Returns:
            Hash value.
        """
        start_idx = block_idx * self.block_size
        end_idx = min(start_idx + self.block_size, len(token_ids))

        block_tokens = tuple(token_ids[start_idx:end_idx])

        # Check cache
        if block_tokens in self._cache:
            return self._cache[block_tokens]

        # Compute hash
        hash_val = hash_tokens(list(block_tokens))
        self._cache[block_tokens] = hash_val

        return hash_val

    def clear_cache(self) -> None:
        """Clear hash cache."""
        self._cache.clear()


def format_memory_size(num_bytes: int) -> str:
    """
    Format memory size as human-readable string.

    Args:
        num_bytes: Memory size in bytes.

    Returns:
        Formatted string (e.g., "1.5 GB").
    """
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if abs(num_bytes) < 1024.0:
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.2f} PB"
