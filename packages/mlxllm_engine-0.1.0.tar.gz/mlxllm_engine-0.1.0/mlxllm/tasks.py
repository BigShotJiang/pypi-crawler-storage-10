# SPDX-License-Identifier: Apache-2.0
"""Task types and definitions for MLX-LLM."""

from __future__ import annotations

from enum import Enum


class TaskType(str, Enum):
    """Types of tasks supported by MLX-LLM."""

    GENERATE = "generate"
    """Text generation / completion task."""

    EMBED = "embed"
    """Embedding generation task."""

    CLASSIFY = "classify"
    """Classification task."""

    SCORE = "score"
    """Scoring / ranking task."""

    POOL = "pool"
    """Pooling task (sentence embeddings)."""

    @property
    def is_generation(self) -> bool:
        """Check if task is a generation task."""
        return self == TaskType.GENERATE

    @property
    def is_embedding(self) -> bool:
        """Check if task is an embedding task."""
        return self in (TaskType.EMBED, TaskType.POOL)

    @property
    def is_classification(self) -> bool:
        """Check if task is a classification task."""
        return self == TaskType.CLASSIFY

    @property
    def is_scoring(self) -> bool:
        """Check if task is a scoring task."""
        return self == TaskType.SCORE


# Task categories for model selection and optimization
GENERATION_TASKS = {TaskType.GENERATE}
EMBEDDING_TASKS = {TaskType.EMBED, TaskType.POOL}
CLASSIFICATION_TASKS = {TaskType.CLASSIFY}
SCORING_TASKS = {TaskType.SCORE}

# Tasks that don't require generation (single forward pass)
SINGLE_PASS_TASKS = {
    TaskType.EMBED,
    TaskType.POOL,
    TaskType.CLASSIFY,
    TaskType.SCORE,
}

# Tasks that require autoregressive generation
AUTOREGRESSIVE_TASKS = {TaskType.GENERATE}


def get_task_type(task: str | TaskType) -> TaskType:
    """
    Get TaskType from string or TaskType.

    Args:
        task: Task type as string or enum.

    Returns:
        TaskType enum.

    Raises:
        ValueError: If task type is invalid.
    """
    if isinstance(task, TaskType):
        return task

    try:
        return TaskType(task.lower())
    except ValueError as e:
        valid_tasks = ", ".join(t.value for t in TaskType)
        raise ValueError(
            f"Invalid task type: {task}. Valid types: {valid_tasks}"
        ) from e


def is_generation_task(task: str | TaskType) -> bool:
    """Check if task requires autoregressive generation."""
    task_type = get_task_type(task)
    return task_type in AUTOREGRESSIVE_TASKS


def is_single_pass_task(task: str | TaskType) -> bool:
    """Check if task requires only a single forward pass."""
    task_type = get_task_type(task)
    return task_type in SINGLE_PASS_TASKS


def requires_sampling(task: str | TaskType) -> bool:
    """Check if task requires sampling from output distribution."""
    task_type = get_task_type(task)
    return task_type in AUTOREGRESSIVE_TASKS
