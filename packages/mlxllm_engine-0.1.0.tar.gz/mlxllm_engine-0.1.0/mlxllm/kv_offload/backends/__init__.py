# SPDX-License-Identifier: Apache-2.0
"""KV cache offload backends."""

from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend

__all__ = ["M4MetalOffloadBackend"]
