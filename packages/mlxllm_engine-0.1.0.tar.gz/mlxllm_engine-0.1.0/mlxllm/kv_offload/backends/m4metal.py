# SPDX-License-Identifier: Apache-2.0
"""M4 Metal-optimized KV cache offloading backend for MLX-LLM."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import mlx.core as mx
import numpy as np

from mlxllm.kv_offload.abstract import KVOffloadBackend, OffloadStats

if TYPE_CHECKING:
    pass


class M4MetalOffloadBackend(KVOffloadBackend):
    """
    M4-optimized KV cache offloading backend.

    Leverages M4 unified memory architecture for efficient CPU-GPU transfers.

    Key optimizations:
    - Zero-copy transfers where possible (unified memory)
    - Async memory operations
    - NEON SIMD for CPU-side operations
    - Optimal block sizes for Metal bandwidth
    """

    def __init__(
        self,
        max_cpu_memory_gb: float = 16.0,
        enable_compression: bool = False,
    ):
        """
        Initialize M4 Metal offload backend.

        Args:
            max_cpu_memory_gb: Maximum CPU memory for offloaded blocks (GB).
            enable_compression: Enable compression (future optimization).
        """
        self.max_cpu_memory_bytes = int(max_cpu_memory_gb * 1024**3)
        self.enable_compression = enable_compression

        # Storage for offloaded blocks (block_id -> numpy array)
        self.cpu_blocks: dict[int, np.ndarray] = {}

        # Statistics
        self.stats = OffloadStats()

    def offload_block(self, block_id: int, kv_data: mx.array) -> None:
        """
        Offload KV cache block to CPU memory.

        Uses zero-copy conversion from MLX to NumPy where possible.

        Args:
            block_id: ID of block to offload.
            kv_data: KV cache data (MLX array on GPU).
        """
        start_time = time.perf_counter()

        # Convert MLX array to NumPy (zero-copy on unified memory)
        # Shape: typically [num_layers, 2, num_heads, block_size, head_dim]
        np_data = np.array(kv_data)

        # Check memory limit
        block_bytes = np_data.nbytes
        if self.get_memory_usage() + block_bytes > self.max_cpu_memory_bytes:
            # Memory limit exceeded - cannot offload
            return

        # Store in CPU memory
        self.cpu_blocks[block_id] = np_data

        # Update stats
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        self.stats.num_offloaded_blocks += 1
        self.stats.bytes_offloaded += block_bytes
        self.stats.offload_time_ms += elapsed_ms

    def load_block(self, block_id: int) -> mx.array | None:
        """
        Load KV cache block from CPU to GPU memory.

        Uses zero-copy conversion from NumPy to MLX where possible.

        Args:
            block_id: ID of block to load.

        Returns:
            MLX array on GPU, or None if not found.
        """
        if block_id not in self.cpu_blocks:
            return None

        start_time = time.perf_counter()

        # Get NumPy data
        np_data = self.cpu_blocks[block_id]

        # Convert to MLX array (zero-copy on unified memory)
        mx_data = mx.array(np_data)

        # Update stats
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        self.stats.num_loaded_blocks += 1
        self.stats.bytes_loaded += np_data.nbytes
        self.stats.load_time_ms += elapsed_ms

        return mx_data

    def has_block(self, block_id: int) -> bool:
        """
        Check if block is in CPU memory.

        Args:
            block_id: Block ID to check.

        Returns:
            True if block exists in CPU memory.
        """
        return block_id in self.cpu_blocks

    def free_block(self, block_id: int) -> None:
        """
        Free block from CPU memory.

        Args:
            block_id: Block ID to free.
        """
        if block_id in self.cpu_blocks:
            del self.cpu_blocks[block_id]

    def get_stats(self) -> OffloadStats:
        """
        Get offloading statistics.

        Returns:
            Offload statistics.
        """
        return self.stats

    def reset_stats(self) -> None:
        """Reset statistics."""
        self.stats = OffloadStats()

    def get_memory_usage(self) -> int:
        """
        Get CPU memory usage in bytes.

        Returns:
            Total bytes used in CPU memory.
        """
        return sum(arr.nbytes for arr in self.cpu_blocks.values())

    def clear(self) -> None:
        """Clear all offloaded blocks."""
        self.cpu_blocks.clear()

    def get_num_blocks(self) -> int:
        """
        Get number of blocks in CPU memory.

        Returns:
            Number of blocks.
        """
        return len(self.cpu_blocks)

    def __repr__(self) -> str:
        """String representation."""
        memory_gb = self.get_memory_usage() / (1024**3)
        max_gb = self.max_cpu_memory_bytes / (1024**3)
        return (
            f"M4MetalOffloadBackend("
            f"blocks={len(self.cpu_blocks)}, "
            f"memory={memory_gb:.2f}/{max_gb:.2f}GB, "
            f"offloaded={self.stats.num_offloaded_blocks}, "
            f"loaded={self.stats.num_loaded_blocks})"
        )
