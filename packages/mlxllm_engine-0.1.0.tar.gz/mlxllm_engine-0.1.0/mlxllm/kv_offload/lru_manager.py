# SPDX-License-Identifier: Apache-2.0
"""LRU-based KV cache offload manager for MLX-LLM."""

from __future__ import annotations

from collections import OrderedDict
from typing import TYPE_CHECKING

from mlxllm.kv_offload.abstract import KVOffloadManager

if TYPE_CHECKING:
    pass


class LRUOffloadManager(KVOffloadManager):
    """
    LRU (Least Recently Used) offload manager.

    Offloads blocks that haven't been accessed recently when
    memory pressure is high.
    """

    def __init__(
        self,
        offload_threshold_ratio: float = 0.9,
        load_threshold_ratio: float = 0.8,
    ):
        """
        Initialize LRU offload manager.

        Args:
            offload_threshold_ratio: Trigger offloading when GPU memory
                utilization exceeds this ratio (default 0.9 = 90%).
            load_threshold_ratio: Stop offloading when GPU memory
                utilization falls below this ratio (default 0.8 = 80%).
        """
        self.offload_threshold = offload_threshold_ratio
        self.load_threshold = load_threshold_ratio

        # Track block access times (LRU order)
        # Most recently used is at the end
        self.access_times: OrderedDict[int, float] = OrderedDict()

    def should_offload(self, num_free_gpu_blocks: int) -> bool:
        """
        Check if offloading should occur based on memory pressure.

        Args:
            num_free_gpu_blocks: Number of free GPU blocks.

        Returns:
            True if offloading should happen.
        """
        # This is a simplified check - in practice would need total blocks
        # For now, just check if we have very few free blocks
        return num_free_gpu_blocks < 10

    def select_blocks_to_offload(
        self,
        block_access_times: dict[int, float],
        num_blocks_needed: int,
    ) -> list[int]:
        """
        Select least recently used blocks to offload.

        Args:
            block_access_times: Map of block_id -> last_access_time.
            num_blocks_needed: Number of blocks to free.

        Returns:
            List of block IDs to offload (LRU first).
        """
        # Update access times
        for block_id, access_time in block_access_times.items():
            if block_id in self.access_times:
                # Move to end (most recent)
                self.access_times.move_to_end(block_id)
                self.access_times[block_id] = access_time
            else:
                self.access_times[block_id] = access_time

        # Get LRU blocks (from beginning of OrderedDict)
        lru_blocks = []
        for block_id in self.access_times:
            if len(lru_blocks) >= num_blocks_needed:
                break
            lru_blocks.append(block_id)

        return lru_blocks

    def record_access(self, block_id: int, access_time: float) -> None:
        """
        Record access to a block.

        Args:
            block_id: Block ID that was accessed.
            access_time: Timestamp of access.
        """
        if block_id in self.access_times:
            # Move to end (most recent)
            self.access_times.move_to_end(block_id)

        self.access_times[block_id] = access_time

    def remove_block(self, block_id: int) -> None:
        """
        Remove block from tracking.

        Args:
            block_id: Block ID to remove.
        """
        if block_id in self.access_times:
            del self.access_times[block_id]

    def get_lru_block(self) -> int | None:
        """
        Get least recently used block ID.

        Returns:
            Block ID of LRU block, or None if empty.
        """
        if not self.access_times:
            return None

        # First item is LRU
        return next(iter(self.access_times))

    def get_mru_block(self) -> int | None:
        """
        Get most recently used block ID.

        Returns:
            Block ID of MRU block, or None if empty.
        """
        if not self.access_times:
            return None

        # Last item is MRU
        return next(reversed(self.access_times))

    def clear(self) -> None:
        """Clear all tracking data."""
        self.access_times.clear()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"LRUOffloadManager("
            f"tracked_blocks={len(self.access_times)}, "
            f"offload_threshold={self.offload_threshold:.1%}, "
            f"load_threshold={self.load_threshold:.1%})"
        )
