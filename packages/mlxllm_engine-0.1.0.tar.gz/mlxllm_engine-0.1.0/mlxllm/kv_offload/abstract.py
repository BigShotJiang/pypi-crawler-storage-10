# SPDX-License-Identifier: Apache-2.0
"""Abstract base classes for KV cache offloading in MLX-LLM."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import mlx.core as mx


@dataclass
class OffloadStats:
    """Statistics for KV cache offloading operations."""

    num_offloaded_blocks: int = 0
    num_loaded_blocks: int = 0
    bytes_offloaded: int = 0
    bytes_loaded: int = 0
    offload_time_ms: float = 0.0
    load_time_ms: float = 0.0

    @property
    def total_bytes_transferred(self) -> int:
        """Total bytes transferred (offload + load)."""
        return self.bytes_offloaded + self.bytes_loaded

    @property
    def total_time_ms(self) -> float:
        """Total time spent in offload/load operations."""
        return self.offload_time_ms + self.load_time_ms

    @property
    def avg_offload_bandwidth_gbps(self) -> float:
        """Average offload bandwidth in GB/s."""
        if self.offload_time_ms == 0:
            return 0.0
        bytes_per_second = self.bytes_offloaded / (self.offload_time_ms / 1000.0)
        return bytes_per_second / (1024**3)

    @property
    def avg_load_bandwidth_gbps(self) -> float:
        """Average load bandwidth in GB/s."""
        if self.load_time_ms == 0:
            return 0.0
        bytes_per_second = self.bytes_loaded / (self.load_time_ms / 1000.0)
        return bytes_per_second / (1024**3)


class KVOffloadBackend(ABC):
    """
    Abstract base class for KV cache offloading backends.

    Offloading backends manage the transfer of KV cache blocks
    between GPU (Metal) and CPU memory.
    """

    @abstractmethod
    def offload_block(self, block_id: int, kv_data: mx.array) -> None:
        """
        Offload a KV cache block to CPU memory.

        Args:
            block_id: ID of the block to offload.
            kv_data: KV cache data (MLX array on GPU).
        """
        raise NotImplementedError

    @abstractmethod
    def load_block(self, block_id: int) -> mx.array | None:
        """
        Load a KV cache block from CPU memory to GPU.

        Args:
            block_id: ID of the block to load.

        Returns:
            KV cache data (MLX array on GPU), or None if not found.
        """
        raise NotImplementedError

    @abstractmethod
    def has_block(self, block_id: int) -> bool:
        """
        Check if a block is in CPU memory.

        Args:
            block_id: ID of the block to check.

        Returns:
            True if block is in CPU memory.
        """
        raise NotImplementedError

    @abstractmethod
    def free_block(self, block_id: int) -> None:
        """
        Free a block from CPU memory.

        Args:
            block_id: ID of the block to free.
        """
        raise NotImplementedError

    @abstractmethod
    def get_stats(self) -> OffloadStats:
        """
        Get offloading statistics.

        Returns:
            Offload statistics.
        """
        raise NotImplementedError

    @abstractmethod
    def reset_stats(self) -> None:
        """Reset offloading statistics."""
        raise NotImplementedError

    @abstractmethod
    def get_memory_usage(self) -> int:
        """
        Get CPU memory usage in bytes.

        Returns:
            Bytes used in CPU memory.
        """
        raise NotImplementedError

    @abstractmethod
    def clear(self) -> None:
        """Clear all offloaded blocks."""
        raise NotImplementedError


class KVOffloadManager(ABC):
    """
    Abstract base class for KV cache offload managers.

    Offload managers decide which blocks to offload/load based on
    memory pressure and access patterns.
    """

    @abstractmethod
    def should_offload(self, num_free_gpu_blocks: int) -> bool:
        """
        Determine if offloading should occur.

        Args:
            num_free_gpu_blocks: Number of free GPU blocks.

        Returns:
            True if offloading should happen.
        """
        raise NotImplementedError

    @abstractmethod
    def select_blocks_to_offload(
        self,
        block_access_times: dict[int, float],
        num_blocks_needed: int,
    ) -> list[int]:
        """
        Select blocks to offload to CPU.

        Args:
            block_access_times: Map of block_id -> last_access_time.
            num_blocks_needed: Number of blocks to free.

        Returns:
            List of block IDs to offload.
        """
        raise NotImplementedError

    @abstractmethod
    def record_access(self, block_id: int, access_time: float) -> None:
        """
        Record access to a block.

        Args:
            block_id: ID of accessed block.
            access_time: Timestamp of access.
        """
        raise NotImplementedError
