# SPDX-License-Identifier: Apache-2.0
"""KV cache offloading for MLX-LLM."""

from mlxllm.kv_offload.abstract import (
    KVOffloadBackend,
    KVOffloadManager,
    OffloadStats,
)
from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend
from mlxllm.kv_offload.factory import create_offload_backend, create_offload_manager
from mlxllm.kv_offload.lru_manager import LRUOffloadManager

__all__ = [
    "KVOffloadBackend",
    "KVOffloadManager",
    "OffloadStats",
    "M4MetalOffloadBackend",
    "LRUOffloadManager",
    "create_offload_backend",
    "create_offload_manager",
]
