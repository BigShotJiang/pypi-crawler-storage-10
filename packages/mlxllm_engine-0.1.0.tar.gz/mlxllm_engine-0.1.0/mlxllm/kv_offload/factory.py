# SPDX-License-Identifier: Apache-2.0
"""Factory for creating KV cache offload backends."""

from __future__ import annotations

import platform
from typing import TYPE_CHECKING

from mlxllm.kv_offload.abstract import KVOffloadBackend, KVOffloadManager
from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend
from mlxllm.kv_offload.lru_manager import LRUOffloadManager

if TYPE_CHECKING:
    pass


def create_offload_backend(
    backend_type: str = "auto",
    max_cpu_memory_gb: float = 16.0,
    enable_compression: bool = False,
) -> KVOffloadBackend:
    """
    Create KV cache offload backend.

    Args:
        backend_type: Backend type ("auto", "m4metal").
        max_cpu_memory_gb: Maximum CPU memory for offloaded blocks.
        enable_compression: Enable compression for offloaded blocks.

    Returns:
        KV cache offload backend.

    Raises:
        ValueError: If backend type is unknown or unsupported on platform.
    """
    # Auto-detect backend based on platform
    if backend_type == "auto":
        system = platform.system()
        machine = platform.machine()

        if system == "Darwin" and machine == "arm64":
            # Apple Silicon - use M4 Metal backend
            backend_type = "m4metal"
        else:
            # Fallback to M4 Metal (will work on any MLX-supported platform)
            backend_type = "m4metal"

    # Create backend
    if backend_type == "m4metal":
        return M4MetalOffloadBackend(
            max_cpu_memory_gb=max_cpu_memory_gb,
            enable_compression=enable_compression,
        )
    else:
        raise ValueError(
            f"Unknown offload backend type: {backend_type}. "
            f"Supported: 'm4metal', 'auto'"
        )


def create_offload_manager(
    manager_type: str = "lru",
    offload_threshold: float = 0.9,
    load_threshold: float = 0.8,
) -> KVOffloadManager:
    """
    Create KV cache offload manager.

    Args:
        manager_type: Manager type ("lru").
        offload_threshold: GPU memory utilization threshold for offloading.
        load_threshold: GPU memory utilization threshold for stopping offload.

    Returns:
        KV cache offload manager.

    Raises:
        ValueError: If manager type is unknown.
    """
    if manager_type == "lru":
        return LRUOffloadManager(
            offload_threshold_ratio=offload_threshold,
            load_threshold_ratio=load_threshold,
        )
    else:
        raise ValueError(
            f"Unknown offload manager type: {manager_type}. " f"Supported: 'lru'"
        )
