# SPDX-License-Identifier: Apache-2.0
"""M4 CPU-GPU Metal worker for KV cache offloading."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import mlx.core as mx

from mlxllm.kv_offload.worker.worker import OffloadWorker, WorkerStatus

if TYPE_CHECKING:
    import numpy as np


class M4CPUGPUMetalWorker(OffloadWorker):
    """
    M4-optimized offload worker using unified memory architecture.

    Key optimizations:
    - Zero-copy CPU�GPU transfers via unified memory
    - Metal-optimized memory operations
    - Minimal overhead for transfers
    - Leverages M4 memory bandwidth (400GB/s on M4 Max)
    """

    def __init__(self, max_cpu_memory_gb: float = 16.0):
        """
        Initialize M4 CPU-GPU Metal worker.

        Args:
            max_cpu_memory_gb: Maximum CPU memory to use (GB).
        """
        super().__init__()
        self.max_cpu_memory_bytes = int(max_cpu_memory_gb * 1024**3)

        # Storage for offloaded blocks (block_id -> numpy array)
        self.cpu_blocks: dict[int, np.ndarray] = {}

    def offload_block(
        self,
        block_id: int,
        kv_data: mx.array,
    ) -> bool:
        """
        Offload KV cache block from GPU to CPU memory.

        Uses zero-copy conversion from MLX to NumPy on unified memory.

        Args:
            block_id: Block ID.
            kv_data: KV cache data (MLX array on GPU).

        Returns:
            True if offload succeeded.
        """
        try:
            self.status = WorkerStatus.OFFLOADING
            start_time = time.perf_counter()

            # Convert MLX array to NumPy (zero-copy on unified memory)
            import numpy as np

            np_data: np.ndarray = np.array(kv_data)

            # Check memory limit
            block_bytes = np_data.nbytes
            current_usage = self.get_memory_usage_bytes()

            if current_usage + block_bytes > self.max_cpu_memory_bytes:
                # Memory limit exceeded
                self.status = WorkerStatus.IDLE
                return False

            # Store in CPU memory
            self.cpu_blocks[block_id] = np_data

            # Update stats
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            self.stats.num_offload_ops += 1
            self.stats.total_offload_time_ms += elapsed_ms

            self.status = WorkerStatus.IDLE
            return True

        except Exception as e:
            self.status = WorkerStatus.ERROR
            self.stats.num_errors += 1
            print(f"Error offloading block {block_id}: {e}")
            return False

    def load_block(self, block_id: int) -> mx.array | None:
        """
        Load KV cache block from CPU memory to GPU.

        Uses zero-copy conversion from NumPy to MLX on unified memory.

        Args:
            block_id: Block ID.

        Returns:
            KV cache data (MLX array), or None if not found.
        """
        if block_id not in self.cpu_blocks:
            return None

        try:
            self.status = WorkerStatus.LOADING
            start_time = time.perf_counter()

            # Get NumPy data
            np_data = self.cpu_blocks[block_id]

            # Convert to MLX array (zero-copy on unified memory)
            mx_data = mx.array(np_data)

            # Update stats
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            self.stats.num_load_ops += 1
            self.stats.total_load_time_ms += elapsed_ms

            self.status = WorkerStatus.IDLE
            return mx_data

        except Exception as e:
            self.status = WorkerStatus.ERROR
            self.stats.num_errors += 1
            print(f"Error loading block {block_id}: {e}")
            return None

    def has_block(self, block_id: int) -> bool:
        """
        Check if block is in CPU memory.

        Args:
            block_id: Block ID.

        Returns:
            True if block exists.
        """
        return block_id in self.cpu_blocks

    def free_block(self, block_id: int) -> None:
        """
        Free block from CPU memory.

        Args:
            block_id: Block ID to free.
        """
        if block_id in self.cpu_blocks:
            del self.cpu_blocks[block_id]

    def get_memory_usage_bytes(self) -> int:
        """
        Get current CPU memory usage.

        Returns:
            Memory usage in bytes.
        """
        return sum(arr.nbytes for arr in self.cpu_blocks.values())

    def clear_all(self) -> None:
        """Clear all offloaded blocks."""
        self.cpu_blocks.clear()

    def get_num_blocks(self) -> int:
        """
        Get number of blocks in CPU memory.

        Returns:
            Number of blocks.
        """
        return len(self.cpu_blocks)

    def get_block_size_bytes(self, block_id: int) -> int:
        """
        Get size of specific block.

        Args:
            block_id: Block ID.

        Returns:
            Block size in bytes, or 0 if not found.
        """
        if block_id in self.cpu_blocks:
            return self.cpu_blocks[block_id].nbytes
        return 0

    def get_memory_usage_ratio(self) -> float:
        """
        Get memory usage as ratio of max.

        Returns:
            Usage ratio [0, 1].
        """
        if self.max_cpu_memory_bytes == 0:
            return 0.0
        return self.get_memory_usage_bytes() / self.max_cpu_memory_bytes

    def estimate_transfer_time_ms(self, block_size_bytes: int) -> float:
        """
        Estimate transfer time for given block size.

        Args:
            block_size_bytes: Block size in bytes.

        Returns:
            Estimated transfer time in milliseconds.
        """
        # M4 Max unified memory bandwidth: ~400 GB/s
        # Assume 80% efficiency
        bandwidth_gbps = 400 * 0.8
        bytes_per_ms = bandwidth_gbps * 1024**3 / 1000

        transfer_time_ms = block_size_bytes / bytes_per_ms

        # Add minimal overhead (unified memory is very fast)
        overhead_ms = 0.01  # ~10 microseconds

        return transfer_time_ms + overhead_ms

    def __repr__(self) -> str:
        """String representation."""
        memory_gb = self.get_memory_usage_bytes() / (1024**3)
        max_gb = self.max_cpu_memory_bytes / (1024**3)
        usage_pct = self.get_memory_usage_ratio() * 100

        return (
            f"M4CPUGPUMetalWorker("
            f"status={self.status.value}, "
            f"blocks={len(self.cpu_blocks)}, "
            f"memory={memory_gb:.2f}/{max_gb:.2f}GB ({usage_pct:.1f}%), "
            f"offloaded={self.stats.num_offload_ops}, "
            f"loaded={self.stats.num_load_ops}, "
            f"avg_offload={self.stats.avg_offload_time_ms:.2f}ms, "
            f"avg_load={self.stats.avg_load_time_ms:.2f}ms)"
        )
