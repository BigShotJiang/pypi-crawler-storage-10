# SPDX-License-Identifier: Apache-2.0
"""Base worker class for KV cache offloading."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import mlx.core as mx


class WorkerStatus(Enum):
    """Status of offload worker."""

    IDLE = "idle"
    OFFLOADING = "offloading"
    LOADING = "loading"
    ERROR = "error"


@dataclass
class WorkerStats:
    """Statistics for offload worker."""

    num_offload_ops: int = 0
    num_load_ops: int = 0
    total_offload_time_ms: float = 0.0
    total_load_time_ms: float = 0.0
    num_errors: int = 0

    @property
    def avg_offload_time_ms(self) -> float:
        """Average offload time."""
        if self.num_offload_ops == 0:
            return 0.0
        return self.total_offload_time_ms / self.num_offload_ops

    @property
    def avg_load_time_ms(self) -> float:
        """Average load time."""
        if self.num_load_ops == 0:
            return 0.0
        return self.total_load_time_ms / self.num_load_ops


class OffloadWorker(ABC):
    """
    Abstract base class for KV cache offload workers.

    Workers handle the actual transfer of data between GPU and CPU/storage.
    Different implementations can optimize for specific hardware configurations.
    """

    def __init__(self):
        """Initialize offload worker."""
        self.status = WorkerStatus.IDLE
        self.stats = WorkerStats()

    @abstractmethod
    def offload_block(
        self,
        block_id: int,
        kv_data: mx.array,
    ) -> bool:
        """
        Offload KV cache block from GPU to CPU/storage.

        Args:
            block_id: Block ID.
            kv_data: KV cache data (MLX array on GPU).

        Returns:
            True if offload succeeded.
        """
        raise NotImplementedError

    @abstractmethod
    def load_block(self, block_id: int) -> mx.array | None:
        """
        Load KV cache block from CPU/storage to GPU.

        Args:
            block_id: Block ID.

        Returns:
            KV cache data (MLX array), or None if not found.
        """
        raise NotImplementedError

    @abstractmethod
    def has_block(self, block_id: int) -> bool:
        """
        Check if block is available in CPU/storage.

        Args:
            block_id: Block ID.

        Returns:
            True if block is available.
        """
        raise NotImplementedError

    @abstractmethod
    def free_block(self, block_id: int) -> None:
        """
        Free block from CPU/storage.

        Args:
            block_id: Block ID to free.
        """
        raise NotImplementedError

    @abstractmethod
    def get_memory_usage_bytes(self) -> int:
        """
        Get current memory usage in bytes.

        Returns:
            Memory usage in bytes.
        """
        raise NotImplementedError

    @abstractmethod
    def clear_all(self) -> None:
        """Clear all offloaded blocks."""
        raise NotImplementedError

    def get_status(self) -> WorkerStatus:
        """
        Get current worker status.

        Returns:
            Worker status.
        """
        return self.status

    def get_stats(self) -> WorkerStats:
        """
        Get worker statistics.

        Returns:
            Worker statistics.
        """
        return self.stats

    def reset_stats(self) -> None:
        """Reset worker statistics."""
        self.stats = WorkerStats()

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"{self.__class__.__name__}("
            f"status={self.status.value}, "
            f"offloaded={self.stats.num_offload_ops}, "
            f"loaded={self.stats.num_load_ops}, "
            f"errors={self.stats.num_errors})"
        )


class AsyncOffloadWorker(OffloadWorker):
    """
    Asynchronous offload worker.

    Handles offloading operations asynchronously to avoid blocking
    the main inference loop.
    """

    def __init__(self):
        """Initialize async offload worker."""
        super().__init__()
        self._pending_offloads: list[tuple[int, mx.array]] = []
        self._pending_loads: list[int] = []

    @abstractmethod
    async def offload_block_async(
        self,
        block_id: int,
        kv_data: mx.array,
    ) -> bool:
        """
        Offload block asynchronously.

        Args:
            block_id: Block ID.
            kv_data: KV cache data.

        Returns:
            True if offload succeeded.
        """
        raise NotImplementedError

    @abstractmethod
    async def load_block_async(self, block_id: int) -> mx.array | None:
        """
        Load block asynchronously.

        Args:
            block_id: Block ID.

        Returns:
            KV cache data, or None if not found.
        """
        raise NotImplementedError

    def queue_offload(self, block_id: int, kv_data: mx.array) -> None:
        """
        Queue block for offloading.

        Args:
            block_id: Block ID.
            kv_data: KV cache data.
        """
        self._pending_offloads.append((block_id, kv_data))

    def queue_load(self, block_id: int) -> None:
        """
        Queue block for loading.

        Args:
            block_id: Block ID.
        """
        self._pending_loads.append(block_id)

    def get_queue_sizes(self) -> tuple[int, int]:
        """
        Get sizes of pending queues.

        Returns:
            Tuple of (num_pending_offloads, num_pending_loads).
        """
        return len(self._pending_offloads), len(self._pending_loads)

    def clear_queues(self) -> None:
        """Clear all pending operations."""
        self._pending_offloads.clear()
        self._pending_loads.clear()
