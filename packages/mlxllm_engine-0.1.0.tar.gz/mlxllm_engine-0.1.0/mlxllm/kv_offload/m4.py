# SPDX-License-Identifier: Apache-2.0
"""M4-specific optimizations for KV cache offloading."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mlxllm.kv_offload.backends.m4metal import M4MetalOffloadBackend
from mlxllm.kv_offload.lru_manager import LRUOffloadManager
from mlxllm.kv_offload.spec import OffloadSpec

if TYPE_CHECKING:
    from mlxllm.kv_offload.abstract import KVOffloadBackend, KVOffloadManager


def create_m4_offload_system(
    spec: OffloadSpec | None = None,
) -> tuple[KVOffloadBackend, KVOffloadManager]:
    """
    Create M4-optimized offload system.

    This function creates a complete offloading system optimized for
    M4 MacBook Pro unified memory architecture.

    Args:
        spec: Offload specification (default if None).

    Returns:
        Tuple of (backend, manager).

    Example:
        >>> spec = OffloadSpec(
        ...     enabled=True,
        ...     max_offload_memory_gb=16.0,
        ...     offload_threshold_ratio=0.9
        ... )
        >>> backend, manager = create_m4_offload_system(spec)
        >>> # Use in KV cache manager
    """
    if spec is None:
        spec = OffloadSpec(
            enabled=True,
            max_offload_memory_gb=16.0,
            offload_threshold_ratio=0.9,
            load_threshold_ratio=0.8,
        )

    # Validate spec
    spec.validate()

    # Create M4 Metal backend
    backend = M4MetalOffloadBackend(
        max_cpu_memory_gb=spec.max_offload_memory_gb,
        enable_compression=spec.enable_compression,
    )

    # Create LRU manager
    manager = LRUOffloadManager(
        offload_threshold_ratio=spec.offload_threshold_ratio,
        load_threshold_ratio=spec.load_threshold_ratio,
    )

    return backend, manager


class M4UnifiedMemoryOptimizer:
    """
    M4 unified memory optimizer for KV cache offloading.

    Provides M4-specific optimizations:
    - Zero-copy CPU-GPU transfers
    - NEON SIMD optimizations
    - Metal-optimized block sizes
    - Unified memory bandwidth optimization
    """

    def __init__(self):
        """Initialize M4 optimizer."""
        self._detect_m4_capabilities()

    def _detect_m4_capabilities(self) -> None:
        """Detect M4 chip capabilities."""
        import platform

        self.is_apple_silicon = (
            platform.system() == "Darwin" and platform.machine() == "arm64"
        )

        # Detect specific M4 variant
        # This would need more sophisticated detection in practice
        self.chip_variant = "M4"  # M4, M4 Pro, M4 Max, M4 Ultra

        # Estimated specs (would be detected dynamically)
        self.gpu_cores = 40  # M4 Max
        self.memory_bandwidth_gbps = 400  # GB/s for M4 Max
        self.total_memory_gb = 30

    def get_optimal_block_size(self, model_size_gb: float) -> int:
        """
        Get optimal block size for model.

        Args:
            model_size_gb: Model size in GB.

        Returns:
            Optimal block size (number of tokens).
        """
        # Larger models benefit from larger blocks
        if model_size_gb < 5:
            return 16  # 7B Q4 models
        elif model_size_gb < 10:
            return 32  # 13B Q4 models
        else:
            return 64  # 70B Q4 models

    def get_optimal_offload_memory_gb(self, model_size_gb: float) -> float:
        """
        Get optimal offload memory size.

        Args:
            model_size_gb: Model size in GB.

        Returns:
            Optimal CPU memory for offloading (GB).
        """
        # Reserve memory based on model size
        # Larger models need more offload capacity
        available = self.total_memory_gb - model_size_gb - 4  # 4GB for OS
        return max(8.0, min(16.0, available))

    def estimate_transfer_time_ms(
        self,
        block_size_bytes: int,
        direction: str = "cpu_to_gpu",
    ) -> float:
        """
        Estimate transfer time for block.

        Args:
            block_size_bytes: Block size in bytes.
            direction: Transfer direction ("cpu_to_gpu" or "gpu_to_cpu").

        Returns:
            Estimated transfer time in milliseconds.
        """
        # M4 unified memory has very high bandwidth
        # Estimate ~80% efficiency
        effective_bandwidth_gbps = self.memory_bandwidth_gbps * 0.8
        bytes_per_ms = effective_bandwidth_gbps * 1024**3 / 1000

        transfer_time_ms = block_size_bytes / bytes_per_ms

        # Add overhead (very small on unified memory)
        overhead_ms = 0.01  # ~10 microseconds

        return transfer_time_ms + overhead_ms

    def should_use_offloading(
        self,
        model_size_gb: float,
        max_context_length: int,
        batch_size: int,
    ) -> bool:
        """
        Determine if offloading should be enabled.

        Args:
            model_size_gb: Model size in GB.
            max_context_length: Maximum context length.
            batch_size: Batch size.

        Returns:
            True if offloading is recommended.
        """
        # Estimate KV cache size
        # Rough estimate: 2 * num_layers * hidden_size * context * batch * 2 bytes
        # For 7B model: ~32 layers, 4096 hidden, 2 bytes per element
        kv_cache_gb = (
            2 * 32 * 4096 * max_context_length * batch_size * 2 / (1024**3)
        )

        total_memory_needed = model_size_gb + kv_cache_gb + 2  # 2GB buffer

        # Enable offloading if we're close to memory limit
        return total_memory_needed > self.total_memory_gb * 0.8

    def get_recommended_spec(
        self,
        model_size_gb: float,
        max_context_length: int = 8192,
        batch_size: int = 8,
    ) -> OffloadSpec:
        """
        Get recommended offload specification.

        Args:
            model_size_gb: Model size in GB.
            max_context_length: Maximum context length.
            batch_size: Batch size.

        Returns:
            Recommended OffloadSpec.
        """
        enabled = self.should_use_offloading(
            model_size_gb, max_context_length, batch_size
        )

        return OffloadSpec(
            enabled=enabled,
            max_offload_memory_gb=self.get_optimal_offload_memory_gb(model_size_gb),
            offload_threshold_ratio=0.9,
            load_threshold_ratio=0.8,
            enable_compression=False,  # Unified memory is fast enough
            enable_prefetch=True,
            prefetch_window=2,
        )

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"M4UnifiedMemoryOptimizer("
            f"chip={self.chip_variant}, "
            f"gpu_cores={self.gpu_cores}, "
            f"bandwidth={self.memory_bandwidth_gbps}GB/s, "
            f"memory={self.total_memory_gb}GB)"
        )
