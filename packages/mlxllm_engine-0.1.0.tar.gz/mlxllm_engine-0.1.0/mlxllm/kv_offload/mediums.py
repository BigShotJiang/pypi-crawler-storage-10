# SPDX-License-Identifier: Apache-2.0
"""Storage medium implementations for KV cache offloading."""

from __future__ import annotations

import io
import os
import tempfile
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    pass


class StorageMedium(ABC):
    """
    Abstract base class for storage mediums.

    Storage mediums handle the actual storage and retrieval of
    offloaded KV cache blocks.
    """

    @abstractmethod
    def store(self, block_id: int, data: np.ndarray) -> None:
        """
        Store block data.

        Args:
            block_id: Block ID.
            data: NumPy array to store.
        """
        raise NotImplementedError

    @abstractmethod
    def load(self, block_id: int) -> np.ndarray | None:
        """
        Load block data.

        Args:
            block_id: Block ID.

        Returns:
            NumPy array, or None if not found.
        """
        raise NotImplementedError

    @abstractmethod
    def has(self, block_id: int) -> bool:
        """
        Check if block exists.

        Args:
            block_id: Block ID.

        Returns:
            True if block exists.
        """
        raise NotImplementedError

    @abstractmethod
    def delete(self, block_id: int) -> None:
        """
        Delete block.

        Args:
            block_id: Block ID to delete.
        """
        raise NotImplementedError

    @abstractmethod
    def get_size_bytes(self, block_id: int) -> int:
        """
        Get size of stored block in bytes.

        Args:
            block_id: Block ID.

        Returns:
            Size in bytes, or 0 if not found.
        """
        raise NotImplementedError

    @abstractmethod
    def get_total_size_bytes(self) -> int:
        """
        Get total size of all stored blocks.

        Returns:
            Total size in bytes.
        """
        raise NotImplementedError

    @abstractmethod
    def clear(self) -> None:
        """Clear all stored blocks."""
        raise NotImplementedError


class CPUMemoryMedium(StorageMedium):
    """
    CPU memory storage medium.

    Stores blocks directly in CPU RAM using NumPy arrays.
    Fastest access but limited by RAM capacity.
    """

    def __init__(self, max_memory_bytes: int = 16 * 1024**3):
        """
        Initialize CPU memory medium.

        Args:
            max_memory_bytes: Maximum memory to use (bytes).
        """
        self.max_memory_bytes = max_memory_bytes
        self.blocks: dict[int, np.ndarray] = {}

    def store(self, block_id: int, data: np.ndarray) -> None:
        """Store block in CPU memory."""
        # Check memory limit
        if self.get_total_size_bytes() + data.nbytes > self.max_memory_bytes:
            raise MemoryError(
                f"CPU memory limit exceeded: "
                f"{self.get_total_size_bytes() + data.nbytes} > "
                f"{self.max_memory_bytes}"
            )

        self.blocks[block_id] = data.copy()

    def load(self, block_id: int) -> np.ndarray | None:
        """Load block from CPU memory."""
        return self.blocks.get(block_id)

    def has(self, block_id: int) -> bool:
        """Check if block exists."""
        return block_id in self.blocks

    def delete(self, block_id: int) -> None:
        """Delete block from CPU memory."""
        if block_id in self.blocks:
            del self.blocks[block_id]

    def get_size_bytes(self, block_id: int) -> int:
        """Get block size in bytes."""
        if block_id in self.blocks:
            return self.blocks[block_id].nbytes
        return 0

    def get_total_size_bytes(self) -> int:
        """Get total size of all blocks."""
        return sum(arr.nbytes for arr in self.blocks.values())

    def clear(self) -> None:
        """Clear all blocks."""
        self.blocks.clear()

    def __repr__(self) -> str:
        """String representation."""
        size_gb = self.get_total_size_bytes() / (1024**3)
        max_gb = self.max_memory_bytes / (1024**3)
        return (
            f"CPUMemoryMedium("
            f"blocks={len(self.blocks)}, "
            f"size={size_gb:.2f}/{max_gb:.2f}GB)"
        )


class DiskMedium(StorageMedium):
    """
    Disk storage medium.

    Stores blocks as .npy files on disk (SSD/NVMe).
    Slower than CPU memory but much larger capacity.
    """

    def __init__(
        self,
        cache_dir: str | Path | None = None,
        max_disk_bytes: int = 100 * 1024**3,  # 100GB default
    ):
        """
        Initialize disk storage medium.

        Args:
            cache_dir: Directory for cache files (temp dir if None).
            max_disk_bytes: Maximum disk space to use (bytes).
        """
        if cache_dir is None:
            cache_dir = Path(tempfile.gettempdir()) / "mlxllm_kv_cache"
        else:
            cache_dir = Path(cache_dir)

        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.max_disk_bytes = max_disk_bytes

    def _get_block_path(self, block_id: int) -> Path:
        """Get file path for block."""
        return self.cache_dir / f"block_{block_id}.npy"

    def store(self, block_id: int, data: np.ndarray) -> None:
        """Store block to disk."""
        # Check disk limit
        if self.get_total_size_bytes() + data.nbytes > self.max_disk_bytes:
            raise IOError(
                f"Disk space limit exceeded: "
                f"{self.get_total_size_bytes() + data.nbytes} > "
                f"{self.max_disk_bytes}"
            )

        block_path = self._get_block_path(block_id)
        np.save(block_path, data)

    def load(self, block_id: int) -> np.ndarray | None:
        """Load block from disk."""
        block_path = self._get_block_path(block_id)
        if not block_path.exists():
            return None

        return np.load(block_path)

    def has(self, block_id: int) -> bool:
        """Check if block exists on disk."""
        return self._get_block_path(block_id).exists()

    def delete(self, block_id: int) -> None:
        """Delete block from disk."""
        block_path = self._get_block_path(block_id)
        if block_path.exists():
            block_path.unlink()

    def get_size_bytes(self, block_id: int) -> int:
        """Get block file size."""
        block_path = self._get_block_path(block_id)
        if block_path.exists():
            return block_path.stat().st_size
        return 0

    def get_total_size_bytes(self) -> int:
        """Get total size of all block files."""
        total = 0
        for block_file in self.cache_dir.glob("block_*.npy"):
            total += block_file.stat().st_size
        return total

    def clear(self) -> None:
        """Clear all block files."""
        for block_file in self.cache_dir.glob("block_*.npy"):
            block_file.unlink()

    def cleanup(self) -> None:
        """Remove cache directory."""
        if self.cache_dir.exists():
            for block_file in self.cache_dir.glob("block_*.npy"):
                block_file.unlink()
            self.cache_dir.rmdir()

    def __repr__(self) -> str:
        """String representation."""
        size_gb = self.get_total_size_bytes() / (1024**3)
        max_gb = self.max_disk_bytes / (1024**3)
        num_blocks = len(list(self.cache_dir.glob("block_*.npy")))
        return (
            f"DiskMedium("
            f"blocks={num_blocks}, "
            f"size={size_gb:.2f}/{max_gb:.2f}GB, "
            f"dir={self.cache_dir})"
        )


class CompressedMemoryMedium(StorageMedium):
    """
    Compressed CPU memory storage medium.

    Stores blocks compressed in CPU RAM.
    Trades CPU time for memory space.
    """

    def __init__(
        self,
        max_memory_bytes: int = 16 * 1024**3,
        compression_level: int = 1,
    ):
        """
        Initialize compressed memory medium.

        Args:
            max_memory_bytes: Maximum memory to use (bytes).
            compression_level: Compression level (1-9).
        """
        self.max_memory_bytes = max_memory_bytes
        self.compression_level = compression_level
        self.blocks: dict[int, bytes] = {}
        self.shapes: dict[int, tuple] = {}
        self.dtypes: dict[int, np.dtype] = {}

        # Try to import zlib for compression
        try:
            import zlib

            self.zlib = zlib
        except ImportError:
            raise ImportError("zlib required for compressed storage")

    def store(self, block_id: int, data: np.ndarray) -> None:
        """Store compressed block."""
        # Compress data
        data_bytes = data.tobytes()
        compressed = self.zlib.compress(data_bytes, level=self.compression_level)

        # Check memory limit
        if self.get_total_size_bytes() + len(compressed) > self.max_memory_bytes:
            raise MemoryError("Compressed memory limit exceeded")

        self.blocks[block_id] = compressed
        self.shapes[block_id] = data.shape
        self.dtypes[block_id] = data.dtype

    def load(self, block_id: int) -> np.ndarray | None:
        """Load and decompress block."""
        if block_id not in self.blocks:
            return None

        # Decompress
        compressed = self.blocks[block_id]
        decompressed = self.zlib.decompress(compressed)

        # Reconstruct array
        shape = self.shapes[block_id]
        dtype = self.dtypes[block_id]
        return np.frombuffer(decompressed, dtype=dtype).reshape(shape)

    def has(self, block_id: int) -> bool:
        """Check if block exists."""
        return block_id in self.blocks

    def delete(self, block_id: int) -> None:
        """Delete compressed block."""
        if block_id in self.blocks:
            del self.blocks[block_id]
            del self.shapes[block_id]
            del self.dtypes[block_id]

    def get_size_bytes(self, block_id: int) -> int:
        """Get compressed block size."""
        if block_id in self.blocks:
            return len(self.blocks[block_id])
        return 0

    def get_total_size_bytes(self) -> int:
        """Get total compressed size."""
        return sum(len(data) for data in self.blocks.values())

    def clear(self) -> None:
        """Clear all blocks."""
        self.blocks.clear()
        self.shapes.clear()
        self.dtypes.clear()

    def get_compression_ratio(self) -> float:
        """
        Get average compression ratio.

        Returns:
            Ratio of compressed size to original size.
        """
        if not self.blocks:
            return 1.0

        compressed_size = self.get_total_size_bytes()
        original_size = sum(
            np.prod(shape) * np.dtype(dtype).itemsize
            for shape, dtype in zip(self.shapes.values(), self.dtypes.values())
        )

        return compressed_size / original_size if original_size > 0 else 1.0

    def __repr__(self) -> str:
        """String representation."""
        size_gb = self.get_total_size_bytes() / (1024**3)
        max_gb = self.max_memory_bytes / (1024**3)
        ratio = self.get_compression_ratio()
        return (
            f"CompressedMemoryMedium("
            f"blocks={len(self.blocks)}, "
            f"size={size_gb:.2f}/{max_gb:.2f}GB, "
            f"compression={ratio:.2%}, "
            f"level={self.compression_level})"
        )
