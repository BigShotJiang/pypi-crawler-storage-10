# SPDX-License-Identifier: Apache-2.0
"""Backend base class for KV cache offloading with storage medium support."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import mlx.core as mx

from mlxllm.kv_offload.abstract import KVOffloadBackend, OffloadStats
from mlxllm.kv_offload.mediums import CPUMemoryMedium, StorageMedium

if TYPE_CHECKING:
    import numpy as np


class GenericOffloadBackend(KVOffloadBackend):
    """
    Generic KV cache offloading backend with pluggable storage mediums.

    This backend supports different storage mediums (CPU memory, disk, etc.)
    and provides a flexible interface for offloading KV cache blocks.
    """

    def __init__(
        self,
        storage_medium: StorageMedium | None = None,
        max_cpu_memory_gb: float = 16.0,
    ):
        """
        Initialize generic offload backend.

        Args:
            storage_medium: Storage medium to use (CPU memory if None).
            max_cpu_memory_gb: Maximum CPU memory (only used if medium is None).
        """
        if storage_medium is None:
            # Default to CPU memory
            storage_medium = CPUMemoryMedium(
                max_memory_bytes=int(max_cpu_memory_gb * 1024**3)
            )

        self.storage = storage_medium
        self.stats = OffloadStats()

    def offload_block(self, block_id: int, kv_data: mx.array) -> None:
        """
        Offload KV cache block to storage medium.

        Args:
            block_id: ID of block to offload.
            kv_data: KV cache data (MLX array on GPU).
        """
        start_time = time.perf_counter()

        # Convert MLX array to NumPy
        import numpy as np

        np_data: np.ndarray = np.array(kv_data)

        # Store in medium
        try:
            self.storage.store(block_id, np_data)

            # Update stats
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            self.stats.num_offloaded_blocks += 1
            self.stats.bytes_offloaded += np_data.nbytes
            self.stats.offload_time_ms += elapsed_ms

        except (MemoryError, OSError) as e:
            # Storage full or error - log but don't crash
            print(f"Warning: Failed to offload block {block_id}: {e}")

    def load_block(self, block_id: int) -> mx.array | None:
        """
        Load KV cache block from storage medium to GPU.

        Args:
            block_id: ID of block to load.

        Returns:
            MLX array on GPU, or None if not found.
        """
        start_time = time.perf_counter()

        # Load from medium
        np_data = self.storage.load(block_id)
        if np_data is None:
            return None

        # Convert to MLX array
        mx_data = mx.array(np_data)

        # Update stats
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        self.stats.num_loaded_blocks += 1
        self.stats.bytes_loaded += np_data.nbytes
        self.stats.load_time_ms += elapsed_ms

        return mx_data

    def has_block(self, block_id: int) -> bool:
        """
        Check if block is in storage.

        Args:
            block_id: Block ID to check.

        Returns:
            True if block exists.
        """
        return self.storage.has(block_id)

    def free_block(self, block_id: int) -> None:
        """
        Free block from storage.

        Args:
            block_id: Block ID to free.
        """
        self.storage.delete(block_id)

    def get_stats(self) -> OffloadStats:
        """
        Get offloading statistics.

        Returns:
            Offload statistics.
        """
        return self.stats

    def reset_stats(self) -> None:
        """Reset statistics."""
        self.stats = OffloadStats()

    def get_memory_usage(self) -> int:
        """
        Get storage memory usage in bytes.

        Returns:
            Bytes used in storage.
        """
        return self.storage.get_total_size_bytes()

    def clear(self) -> None:
        """Clear all offloaded blocks."""
        self.storage.clear()

    def get_num_blocks(self) -> int:
        """
        Get number of blocks in storage.

        Returns:
            Number of blocks.
        """
        # Count blocks by checking storage
        # This is medium-specific, so we'll estimate
        return self.stats.num_offloaded_blocks - self.stats.num_loaded_blocks

    def __repr__(self) -> str:
        """String representation."""
        memory_gb = self.get_memory_usage() / (1024**3)
        return (
            f"GenericOffloadBackend("
            f"storage={self.storage.__class__.__name__}, "
            f"memory={memory_gb:.2f}GB, "
            f"offloaded={self.stats.num_offloaded_blocks}, "
            f"loaded={self.stats.num_loaded_blocks})"
        )
