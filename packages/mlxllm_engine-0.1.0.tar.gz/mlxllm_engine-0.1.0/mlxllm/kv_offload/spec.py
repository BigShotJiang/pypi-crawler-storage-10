# SPDX-License-Identifier: Apache-2.0
"""KV cache offload specification for MLX-LLM."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


class OffloadMedium(Enum):
    """Storage medium for offloaded KV cache blocks."""

    CPU = "cpu"  # CPU RAM
    DISK = "disk"  # SSD/NVMe
    NETWORK = "network"  # Remote storage


class OffloadPolicy(Enum):
    """Policy for when to offload KV cache blocks."""

    NEVER = "never"  # No offloading
    ON_DEMAND = "on_demand"  # Offload when GPU memory is full
    PROACTIVE = "proactive"  # Offload based on predicted need
    ALWAYS = "always"  # Always offload after use


class EvictionPolicy(Enum):
    """Policy for selecting which blocks to offload."""

    LRU = "lru"  # Least Recently Used
    LFU = "lfu"  # Least Frequently Used
    FIFO = "fifo"  # First In First Out
    RANDOM = "random"  # Random selection


@dataclass
class OffloadSpec:
    """
    Specification for KV cache offloading.

    Defines how and when KV cache blocks should be offloaded from GPU to
    alternative storage mediums (CPU, disk, network).
    """

    enabled: bool = False
    """Enable KV cache offloading."""

    medium: OffloadMedium = OffloadMedium.CPU
    """Storage medium for offloaded blocks."""

    policy: OffloadPolicy = OffloadPolicy.ON_DEMAND
    """When to offload blocks."""

    eviction_policy: EvictionPolicy = EvictionPolicy.LRU
    """Which blocks to evict first."""

    max_offload_memory_gb: float = 16.0
    """Maximum memory to use for offloaded blocks (GB)."""

    offload_threshold_ratio: float = 0.9
    """GPU memory utilization threshold for triggering offload."""

    load_threshold_ratio: float = 0.8
    """GPU memory utilization threshold for stopping offload."""

    enable_compression: bool = False
    """Enable compression for offloaded blocks."""

    compression_level: int = 1
    """Compression level (1-9, higher = more compression, slower)."""

    enable_prefetch: bool = True
    """Enable prefetching of blocks likely to be accessed."""

    prefetch_window: int = 2
    """Number of blocks to prefetch ahead."""

    def validate(self) -> None:
        """
        Validate offload specification.

        Raises:
            ValueError: If specification is invalid.
        """
        if self.max_offload_memory_gb <= 0:
            raise ValueError("max_offload_memory_gb must be positive")

        if not (0.0 < self.offload_threshold_ratio <= 1.0):
            raise ValueError("offload_threshold_ratio must be in (0, 1]")

        if not (0.0 < self.load_threshold_ratio <= 1.0):
            raise ValueError("load_threshold_ratio must be in (0, 1]")

        if self.load_threshold_ratio > self.offload_threshold_ratio:
            raise ValueError(
                "load_threshold_ratio must be <= offload_threshold_ratio"
            )

        if self.compression_level < 1 or self.compression_level > 9:
            raise ValueError("compression_level must be in [1, 9]")

        if self.prefetch_window < 0:
            raise ValueError("prefetch_window must be non-negative")

    @property
    def uses_cpu(self) -> bool:
        """Check if offloading uses CPU memory."""
        return self.medium == OffloadMedium.CPU

    @property
    def uses_disk(self) -> bool:
        """Check if offloading uses disk storage."""
        return self.medium == OffloadMedium.DISK

    @property
    def uses_network(self) -> bool:
        """Check if offloading uses network storage."""
        return self.medium == OffloadMedium.NETWORK

    def __repr__(self) -> str:
        """String representation."""
        if not self.enabled:
            return "OffloadSpec(disabled)"

        return (
            f"OffloadSpec("
            f"medium={self.medium.value}, "
            f"policy={self.policy.value}, "
            f"eviction={self.eviction_policy.value}, "
            f"max_memory={self.max_offload_memory_gb}GB, "
            f"threshold={self.offload_threshold_ratio:.0%})"
        )
