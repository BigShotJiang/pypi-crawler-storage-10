# SPDX-License-Identifier: Apache-2.0
"""Connection management for distributed MLX-LLM inference.

This module handles connections between engine processes and workers for
distributed inference scenarios.
"""

from __future__ import annotations

import socket
from dataclasses import dataclass
from typing import Any


@dataclass
class ConnectionConfig:
    """Configuration for distributed connections."""

    host: str = "localhost"
    """Host address."""

    port: int = 5000
    """Port number."""

    timeout: float = 30.0
    """Connection timeout in seconds."""

    max_retries: int = 3
    """Maximum connection retry attempts."""


def get_free_port() -> int:
    """
    Find a free port on localhost.

    Returns:
        Available port number.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        s.listen(1)
        port = s.getsockname()[1]
    return port


def check_port_available(port: int, host: str = "localhost") -> bool:
    """
    Check if a port is available.

    Args:
        port: Port number to check.
        host: Host address.

    Returns:
        True if port is available, False otherwise.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


class ConnectionManager:
    """Manage connections for distributed inference."""

    def __init__(self, config: ConnectionConfig | None = None):
        """
        Initialize connection manager.

        Args:
            config: Connection configuration.
        """
        self.config = config or ConnectionConfig()
        self._connections: dict[str, Any] = {}

    def register_connection(self, name: str, connection: Any) -> None:
        """
        Register a named connection.

        Args:
            name: Connection name/identifier.
            connection: Connection object.
        """
        self._connections[name] = connection

    def get_connection(self, name: str) -> Any | None:
        """
        Get a registered connection.

        Args:
            name: Connection name/identifier.

        Returns:
            Connection object or None if not found.
        """
        return self._connections.get(name)

    def remove_connection(self, name: str) -> None:
        """
        Remove a registered connection.

        Args:
            name: Connection name/identifier.
        """
        self._connections.pop(name, None)

    def close_all(self) -> None:
        """Close all registered connections."""
        for conn in self._connections.values():
            if hasattr(conn, "close"):
                try:
                    conn.close()
                except Exception:
                    pass
        self._connections.clear()
