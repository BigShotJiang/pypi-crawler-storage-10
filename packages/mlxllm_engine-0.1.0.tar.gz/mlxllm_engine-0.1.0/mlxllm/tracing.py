# SPDX-License-Identifier: Apache-2.0
"""Distributed tracing for MLX-LLM using OpenTelemetry.

This module provides optional OpenTelemetry tracing integration for performance
monitoring and debugging.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Iterator


class Tracer:
    """Simple tracer for MLX-LLM operations."""

    def __init__(self, enabled: bool = False):
        """
        Initialize tracer.

        Args:
            enabled: Whether tracing is enabled.
        """
        self.enabled = enabled
        self._spans: list[dict[str, Any]] = []

    @contextmanager
    def span(self, name: str, **attributes: Any) -> Iterator[dict[str, Any]]:
        """
        Create a tracing span.

        Args:
            name: Span name.
            **attributes: Span attributes.

        Yields:
            Span dictionary for adding attributes.
        """
        if not self.enabled:
            yield {}
            return

        import time

        span_data = {
            "name": name,
            "start_time": time.perf_counter(),
            "attributes": attributes,
        }

        try:
            yield span_data
        finally:
            span_data["end_time"] = time.perf_counter()
            span_data["duration"] = span_data["end_time"] - span_data["start_time"]
            self._spans.append(span_data)

    def get_spans(self) -> list[dict[str, Any]]:
        """Get all recorded spans."""
        return self._spans.copy()

    def clear(self) -> None:
        """Clear all recorded spans."""
        self._spans.clear()


# Global tracer instance
_global_tracer = Tracer(enabled=False)


def get_tracer() -> Tracer:
    """Get the global tracer instance."""
    return _global_tracer


def enable_tracing() -> None:
    """Enable global tracing."""
    _global_tracer.enabled = True


def disable_tracing() -> None:
    """Disable global tracing."""
    _global_tracer.enabled = False
