# SPDX-License-Identifier: Apache-2.0
"""Sequence data structures for request tracking in MLX-LLM."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class SequenceStatus(str, Enum):
    """Status of a sequence during its lifecycle."""

    WAITING = "waiting"
    """Sequence is waiting to be scheduled."""

    RUNNING = "running"
    """Sequence is being processed (prefill or decode)."""

    SWAPPED = "swapped"
    """Sequence KV cache has been swapped to CPU."""

    FINISHED_STOPPED = "finished_stopped"
    """Sequence finished normally (EOS or max tokens)."""

    FINISHED_LENGTH_CAPPED = "finished_length_capped"
    """Sequence finished because it hit max_tokens limit."""

    FINISHED_ABORTED = "finished_aborted"
    """Sequence was aborted by user or error."""

    FINISHED_IGNORED = "finished_ignored"
    """Sequence was ignored (e.g., filtered)."""

    # Alias for backward compatibility
    FINISHED = "finished_stopped"
    """Alias for FINISHED_STOPPED."""

    @property
    def is_finished(self) -> bool:
        """Check if sequence is in a finished state."""
        return self.name.startswith("FINISHED")


@dataclass
class SequenceData:
    """Data for a single sequence (prompt + generated tokens)."""

    prompt_token_ids: list[int]
    """Input prompt tokens."""

    output_token_ids: list[int] = field(default_factory=list)
    """Generated output tokens."""

    cumulative_logprob: float = 0.0
    """Cumulative log probability of the sequence."""

    num_computed_tokens: int = 0
    """Number of tokens already computed (prefill progress)."""

    @property
    def prompt_length(self) -> int:
        """Get length of prompt in tokens."""
        return len(self.prompt_token_ids)

    @property
    def output_length(self) -> int:
        """Get length of generated output in tokens."""
        return len(self.output_token_ids)

    @property
    def total_length(self) -> int:
        """Get total sequence length (prompt + output)."""
        return self.prompt_length + self.output_length

    @property
    def all_token_ids(self) -> list[int]:
        """Get all tokens (prompt + output)."""
        return self.prompt_token_ids + self.output_token_ids

    def append_token_id(self, token_id: int, logprob: float = 0.0) -> None:
        """
        Append a generated token to the sequence.

        Args:
            token_id: Token ID to append.
            logprob: Log probability of the token.
        """
        self.output_token_ids.append(token_id)
        self.cumulative_logprob += logprob

    def get_last_token_id(self) -> int | None:
        """Get the last token ID (from output or prompt)."""
        if self.output_token_ids:
            return self.output_token_ids[-1]
        elif self.prompt_token_ids:
            return self.prompt_token_ids[-1]
        return None


@dataclass
class Sequence:
    """
    A sequence represents a single prompt and its generated outputs.

    This is the core data structure for tracking request state during inference.
    """

    seq_id: str
    """Unique sequence identifier."""

    request_id: str = ""
    """Request ID (multiple sequences can belong to same request for beam search)."""

    data: SequenceData | None = None
    """Sequence data (tokens and probabilities)."""

    # Convenience parameters for backward compatibility
    prompt: str | None = None
    """Prompt text (for convenience - not used during execution)."""

    prompt_token_ids: list[int] | None = None
    """Prompt token IDs (alternative to providing data)."""

    block_ids: list[int] = field(default_factory=list)
    """KV cache block IDs allocated for this sequence."""

    block_table: list[int] | None = None
    """Block table for KV cache (GPU blocks)."""

    cpu_block_table: list[int] | None = None
    """Block table for KV cache on CPU (when swapped)."""

    status: SequenceStatus = SequenceStatus.WAITING
    """Current status of the sequence."""

    arrival_time: float = field(default_factory=time.time)
    """Time when sequence arrived (for scheduling)."""

    priority: int = 0
    """Priority for scheduling (higher = more important)."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional metadata for the sequence."""

    def __post_init__(self):
        """Initialize sequence data from convenience parameters if needed."""
        # If data is not provided but prompt_token_ids is, create SequenceData
        if self.data is None:
            if self.prompt_token_ids is not None:
                self.data = SequenceData(prompt_token_ids=self.prompt_token_ids)
            else:
                self.data = SequenceData(prompt_token_ids=[])

        # Set request_id to seq_id if not provided (for single-sequence requests)
        if not self.request_id:
            self.request_id = self.seq_id

    @property
    def is_finished(self) -> bool:
        """Check if sequence is finished."""
        return self.status.is_finished

    @property
    def seq_len(self) -> int:
        """Get current sequence length."""
        return self.data.total_length

    @property
    def num_blocks(self) -> int:
        """Get number of KV cache blocks allocated."""
        return len(self.block_ids)

    def get_num_new_tokens(self) -> int:
        """Get number of new tokens to process (not yet computed)."""
        return self.seq_len - self.data.num_computed_tokens

    def mark_finished(self, status: SequenceStatus) -> None:
        """
        Mark sequence as finished with the given status.

        Args:
            status: Final status for the sequence.
        """
        if not status.is_finished:
            raise ValueError(f"Status {status} is not a finished status")
        self.status = status

    def __repr__(self) -> str:
        """String representation of sequence."""
        return (
            f"Sequence(id={self.seq_id}, "
            f"req={self.request_id}, "
            f"len={self.seq_len}, "
            f"status={self.status.value})"
        )


@dataclass
class SequenceGroup:
    """
    A group of sequences that share the same request.

    Used for beam search or parallel sampling where multiple sequences
    are generated from the same prompt.
    """

    request_id: str
    """Unique request identifier."""

    sequences: list[Sequence]
    """List of sequences in this group."""

    arrival_time: float = field(default_factory=time.time)
    """Time when request arrived."""

    sampling_params: Any | None = None
    """Sampling parameters for generation."""

    prompt_logprobs: list[dict[int, float]] | None = None
    """Log probabilities for prompt tokens (if requested)."""

    def get_seqs(self, status: SequenceStatus | None = None) -> list[Sequence]:
        """
        Get sequences with optional status filtering.

        Args:
            status: If provided, only return sequences with this status.

        Returns:
            List of sequences.
        """
        if status is None:
            return self.sequences

        return [seq for seq in self.sequences if seq.status == status]

    @property
    def num_seqs(self) -> int:
        """Get number of sequences in group."""
        return len(self.sequences)

    @property
    def is_finished(self) -> bool:
        """Check if all sequences are finished."""
        return all(seq.is_finished for seq in self.sequences)

    def get_max_num_blocks(self) -> int:
        """Get maximum number of blocks used by any sequence."""
        if not self.sequences:
            return 0
        return max(seq.num_blocks for seq in self.sequences)

    def __repr__(self) -> str:
        """String representation of sequence group."""
        return (
            f"SequenceGroup(req={self.request_id}, "
            f"num_seqs={self.num_seqs}, "
            f"finished={self.is_finished})"
        )
