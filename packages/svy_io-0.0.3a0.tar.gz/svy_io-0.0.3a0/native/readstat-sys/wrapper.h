// native/readstat-sys/wrapper.h
#include <readstat.h>
