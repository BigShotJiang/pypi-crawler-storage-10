"""
Database-specific fixes.
"""
