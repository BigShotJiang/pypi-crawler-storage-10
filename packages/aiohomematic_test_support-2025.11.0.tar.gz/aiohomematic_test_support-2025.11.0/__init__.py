__version__ = "2025.11.0"
"""Module to support aiohomematic testing with a local client."""
