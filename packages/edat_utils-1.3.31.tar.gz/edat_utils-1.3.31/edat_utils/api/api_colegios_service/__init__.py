from .service import ApiColegiosTecnicosService
