# Rocket Package

A simple Python package demonstrating how to create and distribute a custom module.

## Features

- Move rockets in 2D space
- Compare rocket positions
- Calculate distance between rockets

## Installation

```bash
pip install rocket
```
