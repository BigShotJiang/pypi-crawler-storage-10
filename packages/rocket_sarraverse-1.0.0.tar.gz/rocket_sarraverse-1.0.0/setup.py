from setuptools import setup, find_packages

setup(
    name='rocket-sarraverse',  # ✅ unique name
    version='1.0.0',
    author='sarraverse',
    author_email='ks.zerguerras@esi-sba.dz',
    packages=find_packages(),
    url='https://pypi.org/project/rocket-sarraverse/',
    license='MIT',
    description='A simple rocket simulation package that calculates distances and compares objects.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type="text/markdown",
    install_requires=[],  # ✅ empty list (you had 'rocket' which was wrong)
)
