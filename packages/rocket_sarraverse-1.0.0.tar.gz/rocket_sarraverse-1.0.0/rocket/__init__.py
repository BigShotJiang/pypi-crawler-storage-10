# rocket/rocket/__init__.py
from .rocket import Rocket
