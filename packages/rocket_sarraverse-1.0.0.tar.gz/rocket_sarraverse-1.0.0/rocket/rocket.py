# rocket/rocket/rocket.py

import math

class Rocket:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def __eq__(self, other):
        if not isinstance(other, Rocket):
            return False
        return self.x == other.x and self.y == other.y

    def get_distance(self, other):
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
