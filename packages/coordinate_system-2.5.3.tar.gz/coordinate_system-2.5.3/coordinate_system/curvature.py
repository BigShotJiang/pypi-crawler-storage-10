"""
High-Precision Discrete Curvature Computation Module
====================================================

This module provides optimized discrete curvature computation methods
based on traditional differential geometry with high-order finite differences.

Features:
- Gaussian curvature K
- Mean curvature H
- Principal curvatures k1, k2
- Principal directions
- Convergence analysis
- Richardson extrapolation
- Intrinsic Gradient Operator method (NEW)

Methods Available:
1. Classical Method: First/Second Fundamental Forms + 5-point finite differences
   - Precision: O(h⁴) convergence, typical error < 0.001%

2. Intrinsic Gradient Operator Method: G_μ = (c(u+h) - c(u))/h
   - Based on coordinate system changes analysis
   - Numerically stable and geometrically intuitive

Author: PanGuoJun
Version: 2.4.0
Date: 2025-10-30
"""

import numpy as np
from typing import Tuple, Optional, Dict, List, Callable, Union
from .differential_geometry import Surface
from .coordinate_system import coord3, vec3
from .differential_geometry import (
    MetricTensor,
    IntrinsicGradientOperator,
    IntrinsicGradientCurvatureCalculator,
    compute_curvature_tensor as compute_curvature_tensor_lie,
    compute_all_curvatures as compute_all_curvatures_intrinsic
)


# ========== High-Order Finite Difference Operators ==========

def derivative_5pt(f: Callable[[float], np.ndarray], x: float, h: float) -> np.ndarray:
    """
    5-point finite difference formula for first derivative

    Formula: f'(x) ≈ [-f(x+2h) + 8f(x+h) - 8f(x-h) + f(x-2h)] / (12h)
    Truncation error: O(h⁴)

    Args:
        f: Function to differentiate
        x: Point to evaluate
        h: Step size

    Returns:
        Derivative value (can be scalar or vector)
    """
    return (-f(x + 2*h) + 8*f(x + h) - 8*f(x - h) + f(x - 2*h)) / (12*h)


def derivative_2nd_5pt(f: Callable[[float], np.ndarray], x: float, h: float) -> np.ndarray:
    """
    5-point finite difference formula for second derivative

    Formula: f''(x) ≈ [-f(x+2h) + 16f(x+h) - 30f(x) + 16f(x-h) - f(x-2h)] / (12h²)
    Truncation error: O(h⁴)

    Args:
        f: Function to differentiate
        x: Point to evaluate
        h: Step size

    Returns:
        Second derivative value
    """
    return (-f(x + 2*h) + 16*f(x + h) - 30*f(x) + 16*f(x - h) - f(x - 2*h)) / (12*h*h)


def richardson_extrapolation(f_h: float, f_2h: float, order: int = 4) -> float:
    """
    Richardson extrapolation for accelerating convergence

    Formula: f_extrapolated = (2^p × f_h - f_2h) / (2^p - 1)

    Args:
        f_h: Result with step size h
        f_2h: Result with step size 2h
        order: Convergence order (default: 4 for O(h⁴))

    Returns:
        Extrapolated result with higher precision
    """
    return (2**order * f_h - f_2h) / (2**order - 1)


# ========== Curvature Computation Class ==========

class CurvatureCalculator:
    """
    High-precision discrete curvature calculator

    Uses traditional differential geometry approach:
    1. Compute first fundamental form (metric tensor) g
    2. Compute second fundamental form (shape operator) h
    3. Extract curvatures: K = det(h)/det(g), H = tr(g⁻¹h)/2
    4. Compute principal curvatures from eigenvalues of g⁻¹h

    Numerical method: 5-point finite differences (O(h⁴) accuracy)
    """

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        """
        Initialize curvature calculator

        Args:
            surface: Surface object to analyze
            step_size: Finite difference step size (default: 1e-3)
                      Recommended range: 5e-4 to 2e-3
                      Note: Smaller values (< 5e-4) may cause numerical instability
        """
        self.surface = surface
        self.h = step_size

    def _compute_derivatives(self, u: float, v: float) -> Dict[str, np.ndarray]:
        """
        Compute all required derivatives using 5-point differences

        Returns:
            Dictionary containing r_u, r_v, r_uu, r_vv, r_uv
        """
        # First derivatives
        r_u = derivative_5pt(lambda uu: self._position_array(uu, v), u, self.h)
        r_v = derivative_5pt(lambda vv: self._position_array(u, vv), v, self.h)

        # Second derivatives
        r_uu = derivative_2nd_5pt(lambda uu: self._position_array(uu, v), u, self.h)
        r_vv = derivative_2nd_5pt(lambda vv: self._position_array(u, vv), v, self.h)
        r_uv = derivative_5pt(
            lambda vv: derivative_5pt(
                lambda uu: self._position_array(uu, vv), u, self.h
            ), v, self.h
        )

        return {
            'r_u': r_u,
            'r_v': r_v,
            'r_uu': r_uu,
            'r_vv': r_vv,
            'r_uv': r_uv
        }

    def _position_array(self, u: float, v: float) -> np.ndarray:
        """Convert vec3 position to numpy array"""
        pos = self.surface.position(u, v)
        return np.array([pos.x, pos.y, pos.z])

    def compute_fundamental_forms(self, u: float, v: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute first and second fundamental forms

        Args:
            u, v: Parameter coordinates

        Returns:
            Tuple of (g, h, n) where:
            - g: 2×2 first fundamental form (metric tensor)
            - h: 2×2 second fundamental form (shape operator)
            - n: Unit normal vector (3D array)
        """
        derivs = self._compute_derivatives(u, v)
        r_u = derivs['r_u']
        r_v = derivs['r_v']
        r_uu = derivs['r_uu']
        r_vv = derivs['r_vv']
        r_uv = derivs['r_uv']

        # First fundamental form
        E = np.dot(r_u, r_u)
        F = np.dot(r_u, r_v)
        G = np.dot(r_v, r_v)
        g = np.array([[E, F], [F, G]])

        # Normal vector
        n_vec = np.cross(r_u, r_v)
        n_norm = np.linalg.norm(n_vec)
        if n_norm > 1e-14:
            n = n_vec / n_norm
        else:
            n = np.array([0., 0., 1.])

        # Second fundamental form
        L = np.dot(r_uu, n)
        M = np.dot(r_uv, n)
        N = np.dot(r_vv, n)
        h = np.array([[L, M], [M, N]])

        return g, h, n

    def compute_gaussian_curvature(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature K at a point

        Formula: K = det(h) / det(g) = (LN - M²) / (EG - F²)

        Args:
            u, v: Parameter coordinates

        Returns:
            Gaussian curvature K

        Example:
            >>> from coordinate_system import Sphere
            >>> from coordinate_system.curvature import CurvatureCalculator
            >>> import math
            >>>
            >>> sphere = Sphere(radius=2.0)
            >>> calc = CurvatureCalculator(sphere)
            >>> K = calc.compute_gaussian_curvature(math.pi/4, math.pi/6)
            >>> print(f"K = {K:.6f}, Expected = 0.250000")
        """
        g, h, _ = self.compute_fundamental_forms(u, v)

        det_g = np.linalg.det(g)
        det_h = np.linalg.det(h)

        if abs(det_g) < 1e-14:
            return 0.0

        return det_h / det_g

    def compute_mean_curvature(self, u: float, v: float) -> float:
        """
        Compute mean curvature H at a point

        Formula: H = tr(g⁻¹h) / 2 = (EN - 2FM + GL) / (2(EG - F²))

        Args:
            u, v: Parameter coordinates

        Returns:
            Mean curvature H
        """
        g, h, _ = self.compute_fundamental_forms(u, v)

        det_g = np.linalg.det(g)
        if abs(det_g) < 1e-14:
            return 0.0

        # tr(g⁻¹h) = tr(adj(g)h) / det(g)
        # For 2×2: tr(g⁻¹h) = (g₂₂h₁₁ - 2g₁₂h₁₂ + g₁₁h₂₂) / det(g)
        trace_term = g[1,1]*h[0,0] - 2*g[0,1]*h[0,1] + g[0,0]*h[1,1]

        return trace_term / (2 * det_g)

    def compute_principal_curvatures(self, u: float, v: float) -> Tuple[float, float, np.ndarray, np.ndarray]:
        """
        Compute principal curvatures and principal directions

        Method: Eigenvalue decomposition of shape operator S = g⁻¹h

        Args:
            u, v: Parameter coordinates

        Returns:
            Tuple of (k1, k2, dir1, dir2) where:
            - k1: Maximum principal curvature
            - k2: Minimum principal curvature
            - dir1: Principal direction for k1 (3D unit vector)
            - dir2: Principal direction for k2 (3D unit vector)

        Note:
            Satisfies: K = k1 × k2, H = (k1 + k2) / 2
        """
        g, h, _ = self.compute_fundamental_forms(u, v)
        derivs = self._compute_derivatives(u, v)
        r_u = derivs['r_u']
        r_v = derivs['r_v']

        det_g = np.linalg.det(g)
        if abs(det_g) < 1e-14:
            return 0.0, 0.0, np.array([1., 0., 0.]), np.array([0., 1., 0.])

        # Shape operator S = g⁻¹h
        g_inv = np.linalg.inv(g)
        S = g_inv @ h

        # Eigenvalue decomposition
        eigenvalues, eigenvectors = np.linalg.eig(S)
        k1, k2 = eigenvalues.real

        # Ensure k1 >= k2 (by absolute value)
        if abs(k1) < abs(k2):
            k1, k2 = k2, k1
            eigenvectors = eigenvectors[:, [1, 0]]

        # Convert tangent plane coordinates to 3D directions
        dir1_2d = eigenvectors[:, 0]
        dir2_2d = eigenvectors[:, 1]

        dir1_3d = dir1_2d[0] * r_u + dir1_2d[1] * r_v
        dir2_3d = dir2_2d[0] * r_u + dir2_2d[1] * r_v

        # Normalize
        dir1_3d = dir1_3d / (np.linalg.norm(dir1_3d) + 1e-14)
        dir2_3d = dir2_3d / (np.linalg.norm(dir2_3d) + 1e-14)

        return k1, k2, dir1_3d, dir2_3d

    def compute_all_curvatures(self, u: float, v: float) -> Dict[str, Union[float, np.ndarray]]:
        """
        Compute all curvature quantities at once

        Args:
            u, v: Parameter coordinates

        Returns:
            Dictionary containing:
            - 'K': Gaussian curvature
            - 'H': Mean curvature
            - 'k1': Maximum principal curvature
            - 'k2': Minimum principal curvature
            - 'dir1': Principal direction for k1 (3D)
            - 'dir2': Principal direction for k2 (3D)
            - 'g': First fundamental form (2×2)
            - 'h': Second fundamental form (2×2)
            - 'n': Normal vector (3D)

        Example:
            >>> calc = CurvatureCalculator(sphere)
            >>> curvatures = calc.compute_all_curvatures(math.pi/4, math.pi/6)
            >>> print(f"K = {curvatures['K']:.6f}")
            >>> print(f"H = {curvatures['H']:.6f}")
            >>> print(f"k1 = {curvatures['k1']:.6f}")
            >>> print(f"k2 = {curvatures['k2']:.6f}")
        """
        g, h, n = self.compute_fundamental_forms(u, v)
        K = self.compute_gaussian_curvature(u, v)
        H = self.compute_mean_curvature(u, v)
        k1, k2, dir1, dir2 = self.compute_principal_curvatures(u, v)

        return {
            'K': K,
            'H': H,
            'k1': k1,
            'k2': k2,
            'dir1': dir1,
            'dir2': dir2,
            'g': g,
            'h': h,
            'n': n
        }

    def convergence_analysis(
        self,
        u: float,
        v: float,
        step_sizes: Optional[List[float]] = None
    ) -> List[Dict[str, float]]:
        """
        Perform convergence analysis with multiple step sizes

        Args:
            u, v: Parameter coordinates
            step_sizes: List of step sizes to test (default: [1e-3, 5e-4, 1e-4, 5e-5, 1e-5])

        Returns:
            List of dictionaries, each containing:
            - 'h': Step size
            - 'K': Gaussian curvature
            - 'H': Mean curvature
            - 'k1': Principal curvature 1
            - 'k2': Principal curvature 2

        Example:
            >>> calc = CurvatureCalculator(sphere)
            >>> results = calc.convergence_analysis(math.pi/4, math.pi/6)
            >>> for r in results:
            >>>     print(f"h={r['h']:.1e}: K={r['K']:.8f}")
        """
        if step_sizes is None:
            step_sizes = [1e-3, 5e-4, 1e-4, 5e-5, 1e-5]

        results = []
        original_h = self.h

        for h in step_sizes:
            self.h = h
            K = self.compute_gaussian_curvature(u, v)
            H = self.compute_mean_curvature(u, v)
            k1, k2, _, _ = self.compute_principal_curvatures(u, v)

            results.append({
                'h': h,
                'K': K,
                'H': H,
                'k1': k1,
                'k2': k2
            })

        self.h = original_h
        return results


# ========== Simplified Interface Functions ==========

def gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute Gaussian curvature at a point (simplified interface)

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size: Finite difference step size (default: 1e-3)

    Returns:
        Gaussian curvature K

    Example:
        >>> from coordinate_system import Sphere
        >>> from coordinate_system.curvature import gaussian_curvature
        >>> import math
        >>>
        >>> sphere = Sphere(radius=2.0)
        >>> K = gaussian_curvature(sphere, math.pi/4, math.pi/6)
        >>> print(f"K = {K:.6f}")  # Should output K ≈ 0.250000
    """
    calc = CurvatureCalculator(surface, step_size)
    return calc.compute_gaussian_curvature(u, v)


def mean_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute mean curvature at a point (simplified interface)

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size: Finite difference step size (default: 1e-3)

    Returns:
        Mean curvature H
    """
    calc = CurvatureCalculator(surface, step_size)
    return calc.compute_mean_curvature(u, v)


def principal_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Tuple[float, float]:
    """
    Compute principal curvatures (simplified interface)

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size: Finite difference step size (default: 1e-3)

    Returns:
        Tuple of (k1, k2) principal curvatures

    Example:
        >>> from coordinate_system import Sphere
        >>> from coordinate_system.curvature import principal_curvatures
        >>> import math
        >>>
        >>> sphere = Sphere(radius=2.0)
        >>> k1, k2 = principal_curvatures(sphere, math.pi/4, math.pi/6)
        >>> print(f"k1 = {k1:.6f}, k2 = {k2:.6f}")  # Should be ≈ 0.5, 0.5
    """
    calc = CurvatureCalculator(surface, step_size)
    k1, k2, _, _ = calc.compute_principal_curvatures(u, v)
    return k1, k2


def all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, Union[float, np.ndarray]]:
    """
    Compute all curvature quantities (simplified interface)

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size: Finite difference step size (default: 1e-3)

    Returns:
        Dictionary with keys: 'K', 'H', 'k1', 'k2', 'dir1', 'dir2', 'g', 'h', 'n'
    """
    calc = CurvatureCalculator(surface, step_size)
    return calc.compute_all_curvatures(u, v)


# ========== Lie Group Method ==========

class LieGroupCurvatureCalculator:
    """
    Curvature calculator using Lie group frame field method

    This method uses coord3 Lie group operations to compute curvature
    through connection operators (frame derivatives) and Cartan structure equations.

    Theory:
    1. Construct intrinsic frame c(u,v) ∈ SO(3) (orthonormalized)
    2. Construct embedding frame C(u,v) (preserving metric with scale vector)
    3. Compute connection operator: G' = (c₂·c₁⁻¹)/C₂ - I/C₁
    4. Apply corrections: G = scale × G' / √det(g)
    5. Compute curvature tensor: Θ = [G_u, G_v] - G_{[u,v]}
    6. Extract Gaussian curvature: K = Θ₁₂ / det(g)

    Advantages:
    - Eliminates parametrization dependence through intrinsic frames
    - Natural handling of scale through coord3 Lie group structure
    - Compatible with C++ optimized implementations

    Comparison with Classical Method:
    - Classical: Uses first/second fundamental forms directly
    - Lie Group: Uses frame field derivatives (connection operators)
    - Both methods converge to same result with proper corrections
    """

    def __init__(
        self,
        surface: Surface,
        step_size: float = 1e-3,
        scale_factor: float = 2.0,
        use_metric_correction: bool = True,
        use_lie_derivative: bool = True
    ):
        """
        Initialize Lie group curvature calculator

        Args:
            surface: Surface object
            step_size: Finite difference step size (default: 1e-3, optimal for O(h²) convergence)
            scale_factor: Scaling factor for connection correction (default: 2.0, precomputed correction for self-referencing terms)
            use_metric_correction: Whether to apply metric correction (default: True)
            use_lie_derivative: Whether to include Lie derivative term (default: True)
                              Highly recommended for accuracy!
        """
        self.surface = surface
        self.h = step_size
        self.scale_factor = scale_factor
        self.use_metric_correction = use_metric_correction
        self.use_lie_derivative = use_lie_derivative

    def compute_gaussian_curvature(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature using Lie group method

        Args:
            u, v: Parameter coordinates

        Returns:
            Gaussian curvature K

        Example:
            >>> from coordinate_system import Sphere
            >>> from coordinate_system.curvature import LieGroupCurvatureCalculator
            >>> import math
            >>>
            >>> sphere = Sphere(radius=2.0)
            >>> calc = LieGroupCurvatureCalculator(sphere)
            >>> K = calc.compute_gaussian_curvature(math.pi/4, math.pi/6)
            >>> print(f"K = {K:.6f}, Expected = 0.250000")
        """
        # Temporarily set surface.h to match calculator's step size
        original_h = self.surface.h
        self.surface.h = self.h

        try:
            # Compute curvature tensor using connection operators
            R_uv = compute_curvature_tensor_lie(
                self.surface, u, v,
                scale_factor=self.scale_factor,
                use_metric_correction=self.use_metric_correction,
                use_lie_derivative=self.use_lie_derivative
            )

            # Compute metric tensor
            g = MetricTensor.from_surface(self.surface, u, v)

            # Extract Gaussian curvature using antisymmetric part
            # K = R_{12}^{antisym} / det(g) = (R_01 - R_10)/2 / det(g)
            #
            # R_uv is a coord3 representing the curvature tensor as a 3×3 matrix:
            # R_uv.ux = [R_00, R_01, R_02]  (first row)
            # R_uv.uy = [R_10, R_11, R_12]  (second row)
            # R_uv.uz = [R_20, R_21, R_22]  (third row)
            #
            # We need:
            # R_01 = R_uv.ux.y (first row, second column)
            # R_10 = R_uv.uy.x (second row, first column)
            R_01 = R_uv.ux.y
            R_10 = R_uv.uy.x

            # Antisymmetric part extracts pure curvature (eliminates metric influence)
            R_12_antisym = (R_01 - R_10) / 2.0

            if abs(g.det) > 1e-14:
                K = R_12_antisym / g.det
            else:
                K = 0.0

            return K
        finally:
            # Restore original step size
            self.surface.h = original_h

    def compute_all_curvatures(self, u: float, v: float) -> Dict[str, Union[float, np.ndarray, coord3]]:
        """
        Compute curvature and related quantities using Lie group method

        Args:
            u, v: Parameter coordinates

        Returns:
            Dictionary containing:
            - 'K': Gaussian curvature
            - 'R_uv': Curvature tensor (coord3 object)
            - 'G_u': Connection operator in u direction (coord3)
            - 'G_v': Connection operator in v direction (coord3)
            - 'g': Metric tensor (MetricTensor object)
            - 'det_g': Metric determinant

        Example:
            >>> calc = LieGroupCurvatureCalculator(sphere)
            >>> result = calc.compute_all_curvatures(math.pi/4, math.pi/6)
            >>> print(f"K = {result['K']:.6f}")
            >>> print(f"det(g) = {result['det_g']:.6f}")
        """
        # Temporarily set surface.h to match calculator's step size
        original_h = self.surface.h
        self.surface.h = self.h

        try:
            # Compute intrinsic gradient operators
            intrinsic_op = IntrinsicGradientOperator(
                self.surface,
                self.h
            )
            G_u, G_v = intrinsic_op.compute_both(u, v)

            # Compute curvature tensor
            R_uv = compute_curvature_tensor_lie(
                self.surface, u, v,
                scale_factor=self.scale_factor,
                use_metric_correction=self.use_metric_correction,
                use_lie_derivative=self.use_lie_derivative
            )

            # Compute metric
            g = MetricTensor.from_surface(self.surface, u, v)

            # Extract Gaussian curvature using antisymmetric part
            # K = (R_01 - R_10)/2 / det(g)
            R_01 = R_uv.ux.y
            R_10 = R_uv.uy.x
            R_12_antisym = (R_01 - R_10) / 2.0
            K = R_12_antisym / g.det if abs(g.det) > 1e-14 else 0.0

            return {
                'K': K,
                'R_uv': R_uv,
                'G_u': G_u,
                'G_v': G_v,
                'g': g,
                'det_g': g.det,
                'R_12_antisym': R_12_antisym
            }
        finally:
            # Restore original step size
            self.surface.h = original_h


def compare_methods(
    surface: Surface,
    u: float,
    v: float,
    step_size_classical: float = 1e-3,
    step_size_lie: float = 1e-5
) -> Dict[str, float]:
    """
    Compare classical and Lie group curvature methods

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size_classical: Step size for classical method
        step_size_lie: Step size for Lie group method

    Returns:
        Dictionary with comparison results:
        - 'K_classical': Gaussian curvature from classical method
        - 'K_lie': Gaussian curvature from Lie group method
        - 'difference': Absolute difference
        - 'relative_error': Relative error (if K_classical != 0)

    Example:
        >>> from coordinate_system import Sphere
        >>> from coordinate_system.curvature import compare_methods
        >>> import math
        >>>
        >>> sphere = Sphere(radius=2.0)
        >>> result = compare_methods(sphere, math.pi/4, math.pi/6)
        >>> print(f"Classical: K = {result['K_classical']:.8f}")
        >>> print(f"Lie Group: K = {result['K_lie']:.8f}")
        >>> print(f"Difference: {result['difference']:.2e}")
    """
    # Classical method
    calc_classical = CurvatureCalculator(surface, step_size_classical)
    K_classical = calc_classical.compute_gaussian_curvature(u, v)

    # Lie group method
    calc_lie = LieGroupCurvatureCalculator(surface, step_size_lie)
    K_lie = calc_lie.compute_gaussian_curvature(u, v)

    # Comparison
    difference = abs(K_classical - K_lie)
    relative_error = difference / abs(K_classical) if abs(K_classical) > 1e-14 else 0.0

    return {
        'K_classical': K_classical,
        'K_lie': K_lie,
        'difference': difference,
        'relative_error': relative_error
    }


def gaussian_curvature_lie(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-5,
    scale_factor: float = 2.0,
    use_metric_correction: bool = True,
    use_lie_derivative: bool = True
) -> float:
    """
    Compute Gaussian curvature using Lie group method (simplified interface)

    Args:
        surface: Surface object
        u, v: Parameter coordinates
        step_size: Finite difference step size (default: 1e-5)
        scale_factor: Scaling factor for correction (default: 2.0)
        use_metric_correction: Whether to apply metric correction
        use_lie_derivative: Whether to include Lie derivative term

    Returns:
        Gaussian curvature K

    Example:
        >>> from coordinate_system import Sphere
        >>> from coordinate_system.curvature import gaussian_curvature_lie
        >>> import math
        >>>
        >>> sphere = Sphere(radius=2.0)
        >>> K = gaussian_curvature_lie(sphere, math.pi/4, math.pi/6)
        >>> print(f"K = {K:.6f}")
    """
    calc = LieGroupCurvatureCalculator(
        surface, step_size, scale_factor,
        use_metric_correction, use_lie_derivative
    )
    return calc.compute_gaussian_curvature(u, v)


# ========== Intrinsic Gradient Operator Method ==========
# Now imported from differential_geometry module
from .differential_geometry import (
    IntrinsicGradientOperator,
    IntrinsicGradientCurvatureCalculator,
)

# Define convenience functions for backward compatibility
def intrinsic_gradient_gaussian_curvature(surface, u, v, step_size=1e-3):
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_gaussian_curvature(u, v)

def intrinsic_gradient_mean_curvature(surface, u, v, step_size=1e-3):
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_mean_curvature(u, v)

def intrinsic_gradient_principal_curvatures(surface, u, v, step_size=1e-3):
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    result = calc.compute_all_curvatures(u, v)
    return result['principal_curvatures']

def intrinsic_gradient_all_curvatures(surface, u, v, step_size=1e-3):
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_all_curvatures(u, v)

# ========== Export ==========

__all__ = [
    # Classical method
    'CurvatureCalculator',
    'gaussian_curvature',
    'mean_curvature',
    'principal_curvatures',
    'all_curvatures',

    # Lie group method
    'LieGroupCurvatureCalculator',
    'gaussian_curvature_lie',
    'compare_methods',

    # Intrinsic Gradient Operator method
    'IntrinsicGradientOperator',
    'IntrinsicGradientCurvatureCalculator',
    'intrinsic_gradient_gaussian_curvature',
    'intrinsic_gradient_mean_curvature',
    'intrinsic_gradient_principal_curvatures',
    'intrinsic_gradient_all_curvatures',

    # Utility functions
    'derivative_5pt',
    'derivative_2nd_5pt',
    'richardson_extrapolation',
]
