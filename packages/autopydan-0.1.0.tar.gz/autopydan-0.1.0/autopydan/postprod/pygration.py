POTENTIAL_IMPORTS = [
    "from pydantic import BaseModel",
    ", EmailStr",
    ", HttpUrl",
    "\nfrom uuid import UUID",
    "\nfrom typing import Any",
    "\nfrom enum import StrEnum",
    "\nfrom datetime import datetime"
]
IMPORTS_CHECKERS = {
    "BaseModel": [0],
    "EmailStr": [0,1],
    "HttpUrl": [0,2],
    "UUID": [3],
    "Any": [4],
    "StrEnum": [5],
    "datetime": [6]
}


def get_needed_imports(code_str: str) -> set[int]:
    needed_imports: set[int] = set()
    for checker, import_indices in IMPORTS_CHECKERS.items():
        if checker in code_str:
            needed_imports.update(import_indices)
    return needed_imports

def import_code(needed_imports: set[int]) -> str:
    import_code: list[str] = []
    for i in sorted(needed_imports):
        import_code.append(POTENTIAL_IMPORTS[i])
    return "".join(import_code)