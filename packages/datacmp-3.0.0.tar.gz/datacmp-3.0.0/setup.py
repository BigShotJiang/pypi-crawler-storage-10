from setuptools import setup

# pyproject.toml is the primary configuration
# This file is kept for backward compatibility
setup()