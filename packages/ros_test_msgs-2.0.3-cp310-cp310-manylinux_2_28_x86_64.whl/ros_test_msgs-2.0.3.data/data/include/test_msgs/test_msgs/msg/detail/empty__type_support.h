// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from test_msgs:msg/Empty.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "test_msgs/msg/empty.h"


#ifndef TEST_MSGS__MSG__DETAIL__EMPTY__TYPE_SUPPORT_H_
#define TEST_MSGS__MSG__DETAIL__EMPTY__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "test_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_test_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  test_msgs,
  msg,
  Empty
)(void);

#ifdef __cplusplus
}
#endif

#endif  // TEST_MSGS__MSG__DETAIL__EMPTY__TYPE_SUPPORT_H_
