from setuptools import setup, find_packages

setup(
    name="kmath",
    version="0.1",
    packages=find_packages(),
    install_requires=[],  # dépendances éventuelles
    description="Bibliothèque de math",
    author="Christ Kekeli KELI",
    author_email="christdev9@gmail.com",
)
