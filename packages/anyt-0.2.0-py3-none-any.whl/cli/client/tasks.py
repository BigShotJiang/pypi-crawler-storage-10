"""API client for task operations."""

# pyright: reportUnknownVariableType=false, reportUnknownMemberType=false

from datetime import datetime
from typing import Any, cast

from cli.config import GlobalConfig
from cli.generated.api_config import APIConfig
from cli.generated.models.AddDependencyRequest import AddDependencyRequest
from cli.generated.models.CreateTaskRequest import CreateTaskRequest
from cli.generated.models.DependencyResponse import DependencyResponse
from cli.generated.models.DependencyTaskInfo import (
    DependencyTaskInfo as GeneratedDependencyTaskInfo,
)
from cli.generated.models.Task import Task as GeneratedTask
from cli.generated.models.TaskListResponse_Output import TaskListResponse_Output
from cli.generated.models.AssigneeType import AssigneeType as GeneratedAssigneeType
from cli.generated.models.TaskStatus import TaskStatus as GeneratedTaskStatus
from cli.generated.models.TaskUpdate import TaskUpdate as GeneratedTaskUpdate
from cli.models.common import AssigneeType, Status
from cli.models.dependency import TaskDependency
from cli.models.task import (
    TaskCreate,
    TaskFilters,
    TaskUpdate,
)
from cli.models.wrappers.task import Task, TaskDependencyInfo

# Import generated service functions for use and testing
# These are conditionally imported with pyright ignore for missing imports
from cli.generated.services.async_Public_Tasks_service import (  # pyright: ignore[reportMissingImports]  # noqa: F401
    get_public_task_v1_t__uid__get,
    get_task_from_home_workspace_v1_home__identifier__get,
)
from cli.generated.services.async_Task_Dependencies_service import (  # pyright: ignore[reportMissingImports]  # noqa: F401
    add_dependency_v1_workspaces__workspace_id__tasks__identifier__dependencies__post,
    get_dependencies_v1_workspaces__workspace_id__tasks__identifier__dependencies__get,
    get_dependents_v1_workspaces__workspace_id__tasks__identifier__dependents_get,
    remove_dependency_v1_workspaces__workspace_id__tasks__identifier__dependencies__depends_on_identifier__delete,
)
from cli.generated.services.async_Tasks_service import (  # pyright: ignore[reportMissingImports]  # noqa: F401
    create_task_v1_projects__project_id__tasks__post,
    delete_task_v1_workspaces__workspace_id__tasks__identifier__delete,
    get_task_v1_workspaces__workspace_id__tasks__identifier__get,
    list_tasks_v1_workspaces__workspace_id__tasks__get,
    update_task_v1_workspaces__workspace_id__tasks__identifier__patch,
)


class TasksAPIClient:
    """API client for task operations using generated OpenAPI client.

    This client uses generated service functions directly instead of the adapter
    pattern to reduce indirection and improve type safety.
    """

    def __init__(
        self,
        base_url: str | None = None,
        auth_token: str | None = None,
        agent_key: str | None = None,
        workspace_id: int | None = None,
    ):
        """Initialize with API configuration.

        Args:
            base_url: Base URL for the API
            auth_token: Optional JWT auth token
            agent_key: Optional agent API key
            workspace_id: Optional workspace ID for workspace-scoped operations
        """
        self.base_url = base_url
        self.auth_token = auth_token
        self.agent_key = agent_key
        self.workspace_id = workspace_id

    @classmethod
    def from_config(cls, config: GlobalConfig | None = None) -> "TasksAPIClient":
        """Create client from global configuration.

        Args:
            config: Optional global config (uses default if not provided)

        Returns:
            TasksAPIClient instance
        """
        if config is None:
            config = GlobalConfig.load()

        effective_config = config.get_effective_config()

        # Try to load workspace_id from workspace config
        workspace_id: int | None = None
        try:
            from cli.config import WorkspaceConfig

            ws_config = WorkspaceConfig.load()
            workspace_id = ws_config.workspace_id if ws_config else None
        except Exception:
            # No workspace config available
            pass

        return cls(
            base_url=effective_config.get("api_url"),
            auth_token=effective_config.get("auth_token"),
            agent_key=effective_config.get("agent_key"),
            workspace_id=workspace_id,
        )

    def _get_api_config(self) -> APIConfig:
        """Get APIConfig for generated client calls."""
        if not self.base_url:
            raise ValueError("API base URL not configured")
        return APIConfig(base_path=self.base_url, access_token=self.auth_token)

    def _convert_status_to_generated(self, status: Status | str) -> GeneratedTaskStatus:
        """Convert domain Status enum or string to generated TaskStatus."""
        # Handle both Status enum instances and string values
        # (Pydantic's use_enum_values=True converts enums to strings)
        if isinstance(status, Status):
            return GeneratedTaskStatus(status.value)
        return GeneratedTaskStatus(status)

    def _convert_assignee_type_to_generated(
        self, assignee_type: AssigneeType | str
    ) -> GeneratedAssigneeType:
        """Convert domain AssigneeType enum or string to generated AssigneeType."""
        # Handle both AssigneeType enum instances and string values
        # (Pydantic's use_enum_values=True converts enums to strings)
        if isinstance(assignee_type, AssigneeType):
            return GeneratedAssigneeType(assignee_type.value)
        return GeneratedAssigneeType(assignee_type)

    @staticmethod
    def _parse_datetime(dt_str: str | datetime) -> datetime:
        """Parse ISO 8601 datetime string or return datetime as-is."""
        # Handle datetime objects directly
        if isinstance(dt_str, datetime):
            return dt_str
        # Handle both with and without 'Z' suffix for strings
        if dt_str.endswith("Z"):
            dt_str = dt_str[:-1] + "+00:00"
        return datetime.fromisoformat(dt_str)

    async def list_tasks(self, filters: TaskFilters) -> list[Task]:
        """List tasks with filters.

        Args:
            filters: Task filter criteria

        Returns:
            List of Task objects

        Raises:
            APIError: On HTTP errors
        """
        # Convert domain filters to API parameters
        params = filters.model_dump(exclude_none=True)

        # Validate required path parameters
        workspace_id = params.get("workspace_id")
        if workspace_id is None:
            raise ValueError(
                "workspace_id is required for listing tasks. "
                "Please provide workspace_id in TaskFilters or ensure workspace context is set."
            )

        # Convert status and priority lists to comma-separated strings
        if "status" in params and isinstance(params["status"], list):
            params["status"] = ",".join(params["status"])
        if "priority" in params and isinstance(params["priority"], list):
            params["priority"] = ",".join(str(p) for p in params["priority"])

        # Call generated service function (note: domain uses project_id, API expects project)
        response = await list_tasks_v1_workspaces__workspace_id__tasks__get(
            api_config_override=self._get_api_config(),
            workspace_id=workspace_id,
            project=params.get("project_id"),  # Map project_id -> project
            status=params.get("status"),
            priority=params.get("priority"),
            priority_gte=params.get("priority_gte"),
            priority_lte=params.get("priority_lte"),
            owner=params.get("owner"),
            creator=params.get("creator"),
            labels=params.get("labels"),
            parent=params.get("parent"),
            has_subtasks=params.get("has_subtasks"),
            created_after=params.get("created_after"),
            updated_after=params.get("updated_after"),
            completed_after=params.get("completed_after"),
            completed_before=params.get("completed_before"),
            limit=params.get("limit"),
            offset=params.get("offset"),
            sort_by=params.get("sort_by"),
            order=params.get("order"),
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        # Extract items from response
        response_data: TaskListResponse_Output = cast(Any, response).data
        items = response_data.items if response_data and response_data.items else []

        # Wrap generated models in domain wrappers
        return [Task(item) for item in items]

    async def get_task(self, identifier: str) -> Task:
        """Get task by identifier.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID

        Returns:
            Task object

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Use the home workspace endpoint (v1/home/{identifier})
        # This is the equivalent endpoint in the generated API
        response = await get_task_from_home_workspace_v1_home__identifier__get(
            api_config_override=self._get_api_config(),
            identifier=identifier,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        task_data: GeneratedTask = cast(Any, response).data
        return Task(task_data)

    async def get_task_by_workspace(self, workspace_id: int, identifier: str) -> Task:
        """Get task by workspace and identifier.

        Args:
            workspace_id: Workspace ID
            identifier: Task identifier within workspace

        Returns:
            Task object

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        response = await get_task_v1_workspaces__workspace_id__tasks__identifier__get(
            api_config_override=self._get_api_config(),
            workspace_id=workspace_id,
            identifier=identifier,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        task_data: GeneratedTask = cast(Any, response).data
        return Task(task_data)

    async def get_task_by_uid(self, uid: str) -> Task:
        """Get task by UID.

        Args:
            uid: Task UID in string format (e.g., t_1Z)

        Returns:
            Task object

        Raises:
            NotFoundError: If task not found
            ForbiddenError: If user doesn't have access to the task
            APIError: On other HTTP errors
        """
        response = await get_public_task_v1_t__uid__get(
            api_config_override=self._get_api_config(),
            uid=uid,
            workspace_id=self.workspace_id,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        task_data: GeneratedTask = cast(Any, response).data
        return Task(task_data)

    async def create_task(self, project_id: int, task: TaskCreate) -> Task:
        """Create a new task.

        Args:
            project_id: Project ID to create task in
            task: Task creation data

        Returns:
            Created Task object

        Raises:
            ValidationError: If task data is invalid
            APIError: On other HTTP errors
        """
        # Convert domain model to generated API request model
        request = CreateTaskRequest(
            title=task.title,
            description=task.description,
            status=self._convert_status_to_generated(task.status)
            if task.status
            else None,
            priority=task.priority.value
            if task.priority and hasattr(task.priority, "value")
            else (task.priority if isinstance(task.priority, int) else None),
            owner_id=task.owner_id,
            assignee_type=self._convert_assignee_type_to_generated(task.assignee_type)
            if task.assignee_type
            else None,
            parent_id=task.parent_id,
            goal_id=task.goal_id,
            depends_on=task.depends_on,
            labels=task.labels,
            estimate=task.estimate,
            phase=task.phase,
        )

        # Call generated service function
        response = await create_task_v1_projects__project_id__tasks__post(
            api_config_override=self._get_api_config(),
            project_id=project_id,
            data=request,
            workspace_id=self.workspace_id,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        task_data: GeneratedTask = cast(Any, response).data
        return Task(task_data)

    async def update_task(self, identifier: str, updates: TaskUpdate) -> Task:
        """Update an existing task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID
            updates: Task update data

        Returns:
            Updated Task object

        Raises:
            NotFoundError: If task not found
            ValidationError: If update data is invalid
            APIError: On other HTTP errors
        """
        # Convert domain model to generated API model
        request = GeneratedTaskUpdate(
            title=updates.title,
            description=updates.description,
            status=self._convert_status_to_generated(updates.status)
            if updates.status
            else None,
            priority=updates.priority.value
            if updates.priority and hasattr(updates.priority, "value")
            else (updates.priority if isinstance(updates.priority, int) else None),
            owner_id=updates.owner_id,
            assignee_type=self._convert_assignee_type_to_generated(
                updates.assignee_type
            )
            if updates.assignee_type
            else None,
            parent_id=updates.parent_id,
            goal_id=updates.goal_id,
            labels=updates.labels,
            estimate=updates.estimate,
            phase=updates.phase,
            project_id=updates.project_id,
        )

        # Call generated service function
        response = (
            await update_task_v1_workspaces__workspace_id__tasks__identifier__patch(
                api_config_override=self._get_api_config(),
                workspace_id=self.workspace_id,
                identifier=identifier,
                data=request,
                If_Match=None,
                X_API_Key=self.agent_key,
                X_Test_User_Id=None,
            )
        )

        task_data: GeneratedTask = cast(Any, response).data
        return Task(task_data)

    async def delete_task(self, identifier: str) -> None:
        """Delete a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        await delete_task_v1_workspaces__workspace_id__tasks__identifier__delete(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

    async def add_task_dependency(
        self, identifier: str, depends_on: str
    ) -> TaskDependency:
        """Add a dependency to a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID
            depends_on: Identifier of task this depends on

        Returns:
            Created TaskDependency object

        Raises:
            NotFoundError: If either task not found
            ConflictError: If dependency would create a cycle
            APIError: On other HTTP errors
        """
        request = AddDependencyRequest(depends_on=depends_on)

        response = await add_dependency_v1_workspaces__workspace_id__tasks__identifier__dependencies__post(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            data=request,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        # Convert response to TaskDependency
        # Note: The generated API returns task identifiers as strings, but domain expects IDs as ints
        # We'll need to parse the identifiers or use placeholder values
        dep_response: DependencyResponse = cast(Any, response).data

        # Try to extract numeric IDs from identifiers (e.g., "DEV-42" -> 42)
        # If not possible, use 0 as placeholder (this is a known limitation)
        task_id_int = 0
        depends_on_id_int = 0

        try:
            # Try to parse as integer directly
            task_id_int = int(dep_response.task_id)
        except (ValueError, AttributeError):
            # If it's an identifier format, we can't convert - use 0
            task_id_int = 0

        try:
            depends_on_id_int = int(dep_response.depends_on)
        except (ValueError, AttributeError):
            depends_on_id_int = 0

        return TaskDependency(
            task_id=task_id_int,
            depends_on_id=depends_on_id_int,
            created_at=self._parse_datetime(dep_response.created_at),
        )

    async def remove_task_dependency(self, identifier: str, depends_on: str) -> None:
        """Remove a dependency from a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID
            depends_on: Identifier of task dependency to remove

        Raises:
            NotFoundError: If task or dependency not found
            APIError: On other HTTP errors
        """
        await remove_dependency_v1_workspaces__workspace_id__tasks__identifier__dependencies__depends_on_identifier__delete(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            depends_on_identifier=depends_on,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

    async def get_task_dependencies(self, identifier: str) -> list[TaskDependencyInfo]:
        """Get tasks that this task depends on.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID

        Returns:
            List of TaskDependencyInfo objects this task depends on

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        response = await get_dependencies_v1_workspaces__workspace_id__tasks__identifier__dependencies__get(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        deps_data: list[GeneratedDependencyTaskInfo] = cast(Any, response).data
        return [TaskDependencyInfo(dep) for dep in deps_data]

    async def get_task_dependents(self, identifier: str) -> list[TaskDependencyInfo]:
        """Get tasks that depend on this task (blocked by this task).

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID

        Returns:
            List of TaskDependencyInfo objects that depend on this task

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        response = await get_dependents_v1_workspaces__workspace_id__tasks__identifier__dependents_get(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            X_API_Key=self.agent_key,
            X_Test_User_Id=None,
        )

        deps_data: list[GeneratedDependencyTaskInfo] = cast(Any, response).data
        return [TaskDependencyInfo(dep) for dep in deps_data]

    async def get_task_events(
        self,
        identifier: str,
        event_type: str | None = None,
        since: str | None = None,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Get chronological timeline of events for a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID
            event_type: Optional filter by event type (created, updated, etc.)
            since: Optional filter events since date (ISO format: YYYY-MM-DD)
            limit: Max number of events to return (default 50)

        Returns:
            List of task events with timestamps and descriptions

        Raises:
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Note: The generated client doesn't have a dedicated events endpoint yet
        # This is a placeholder that should be updated when the endpoint is available
        # For now, return empty list to maintain backward compatibility
        return []
