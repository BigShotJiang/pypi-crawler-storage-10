"""API client for task comment operations."""

# pyright: reportUnknownVariableType=false, reportUnknownMemberType=false

from datetime import datetime
from typing import Any, cast

from cli.config import GlobalConfig
from cli.generated.api_config import APIConfig
from cli.generated.models.CommentResponse import CommentResponse
from cli.generated.models.CreateCommentRequest import CreateCommentRequest
from cli.generated.services.async_Task_Comments_service import (  # pyright: ignore[reportMissingImports]
    create_task_comment_v1_workspaces__workspace_id__tasks__identifier__comments__post,
    list_task_comments_v1_workspaces__workspace_id__tasks__identifier__comments__get,
)
from cli.models.comment import Comment, CommentCreate


class CommentsAPIClient:
    """API client for task comment operations using generated OpenAPI client."""

    def __init__(
        self,
        base_url: str | None = None,
        auth_token: str | None = None,
        agent_key: str | None = None,
        workspace_id: int | None = None,
    ):
        """Initialize with API configuration.

        Args:
            base_url: Base URL for the API
            auth_token: Optional JWT auth token
            agent_key: Optional agent API key
            workspace_id: Optional workspace ID for workspace-scoped operations
        """
        self.base_url = base_url
        self.auth_token = auth_token
        self.agent_key = agent_key
        self.workspace_id = workspace_id

    @classmethod
    def from_config(cls, config: GlobalConfig | None = None) -> "CommentsAPIClient":
        """Create client from global configuration.

        Args:
            config: Optional global config (uses default if not provided)

        Returns:
            CommentsAPIClient instance
        """
        if config is None:
            config = GlobalConfig.load()

        effective_config = config.get_effective_config()

        # Try to load workspace_id from workspace config
        workspace_id: int | None = None
        try:
            from cli.config import WorkspaceConfig

            ws_config = WorkspaceConfig.load()
            workspace_id = ws_config.workspace_id if ws_config else None
        except Exception:
            # No workspace config available
            pass

        return cls(
            base_url=effective_config.get("api_url"),
            auth_token=effective_config.get("auth_token"),
            agent_key=effective_config.get("agent_key"),
            workspace_id=workspace_id,
        )

    def _get_api_config(self) -> APIConfig:
        """Get APIConfig for generated client calls."""
        if not self.base_url:
            raise ValueError("API base URL not configured")
        return APIConfig(base_path=self.base_url, access_token=self.auth_token)

    def _convert_comment_response(self, response: CommentResponse) -> Comment:
        """Convert generated CommentResponse to domain Comment model."""
        return Comment(
            id=response.id,
            content=response.content,
            created_at=datetime.fromisoformat(
                response.created_at.replace("Z", "+00:00")
            ),
            user_id=None,  # Not in CommentResponse
            task_id=response.task_id,
            mentioned_users=response.mentioned_users,
        )

    async def create_comment(self, identifier: str, comment: CommentCreate) -> Comment:
        """Create a comment on a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID
            comment: Comment creation data

        Returns:
            Created Comment object

        Raises:
            ValueError: If author_id is not provided in comment
            NotFoundError: If task not found
            ValidationError: If comment data is invalid
            APIError: On other HTTP errors
        """
        # Validate author_id is provided (required for X-API-Key header)
        if not comment.author_id:
            raise ValueError(
                "Comment author_id is required (agent key or user ID). "
                "Ensure agent key is configured or user is authenticated."
            )

        # Convert domain model to generated API request model
        request = CreateCommentRequest(
            content=comment.content,
            mentioned_users=comment.mentioned_users,
            parent_id=comment.parent_id,
        )

        # Call generated service function with all required parameters
        response = await create_task_comment_v1_workspaces__workspace_id__tasks__identifier__comments__post(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            data=request,
            X_API_Key=comment.author_id,  # Agent key or user ID (validated above)
            X_Test_User_Id="Agent",
        )

        # Convert generated response to domain model
        return self._convert_comment_response(cast(Any, response).data)

    async def list_comments(self, identifier: str) -> list[Comment]:
        """List all comments on a task.

        Args:
            identifier: Task identifier (e.g., DEV-42) or ID

        Returns:
            List of Comment objects, ordered by creation time

        Raises:
            ValueError: If agent_key is not configured
            NotFoundError: If task not found
            APIError: On other HTTP errors
        """
        # Validate agent_key is configured (required for X-API-Key header)
        if not self.agent_key:
            raise ValueError(
                "Agent key not configured. "
                "Run 'anyt auth agent-key set <key>' to configure agent authentication."
            )

        # Call generated service function
        response = await list_task_comments_v1_workspaces__workspace_id__tasks__identifier__comments__get(
            api_config_override=self._get_api_config(),
            workspace_id=self.workspace_id,
            identifier=identifier,
            limit=None,
            offset=None,
            X_API_Key=self.agent_key,  # Validated above
            X_Test_User_Id=None,
        )

        # Convert generated responses to domain models
        response_data = cast(Any, response).data
        comments = response_data.comments if response_data else []
        return [self._convert_comment_response(c) for c in comments]
