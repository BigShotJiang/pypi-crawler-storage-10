from typing import *
from pydantic import BaseModel, Field
from .AgentKeyResponse import AgentKeyResponse

class CreateAgentKeyResponse(BaseModel):
    """
    CreateAgentKeyResponse model
        Response when creating a new agent key (includes full key once).
            """
    model_config = {
        "populate_by_name": True,
        "validate_assignment": True
    }
    
    key : str = Field(validation_alias="key" )
    
    agent_key : AgentKeyResponse = Field(validation_alias="agent_key" )
    