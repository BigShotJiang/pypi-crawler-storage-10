"""Built-in workflows bundled with the CLI package."""

__all__ = ["BUILT_IN_WORKFLOWS"]

BUILT_IN_WORKFLOWS = ["local_dev", "feature_development", "general_task", "dry_run"]
