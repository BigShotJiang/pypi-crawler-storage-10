"""
Workflow executor for running AnyTask workflows.
"""

import asyncio
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, cast

from rich.console import Console

from .actions.registry import ActionRegistry
from .cache import CacheManager
from .conditions import ExpressionEvaluator
from .context import ExecutionContext
from .models import StepResult, StepStatus, Workflow, WorkflowExecution, WorkflowStep
from .secrets import SecretsManager

console = Console()


class WorkflowExecutor:
    """Executes workflows with step-by-step processing."""

    def __init__(
        self,
        cache_manager: Optional[CacheManager] = None,
        secrets_manager: Optional[SecretsManager] = None,
        agent_key: Optional[str] = None,
        workspace_id: Optional[int] = None,
    ):
        self.cache_manager = cache_manager or CacheManager()
        self.action_registry = ActionRegistry()
        self.secrets_manager = secrets_manager or SecretsManager()
        self.agent_key = agent_key
        self.workspace_id = workspace_id

    def _get_api_config(self) -> Any:
        """
        Get APIConfig for generated API client calls.

        Returns:
            APIConfig instance with base_path set from config
        """
        try:
            from cli.config import GlobalConfig
            from cli.generated.api_config import APIConfig

            config = GlobalConfig.load()
            effective_config = config.get_effective_config()
            api_url = effective_config.get("api_url")

            if not api_url:
                raise RuntimeError("API URL not configured")

            return APIConfig(base_path=api_url, access_token=None)
        except Exception as e:
            console.print(f"[yellow]Warning: Failed to load API config: {e}[/yellow]")
            # Return default config as fallback
            from cli.generated.api_config import APIConfig

            return APIConfig()

    async def execute_workflow(
        self,
        workflow: Workflow,
        task: Dict[str, Any],
        workspace_dir: Path,
        attempt_id: Optional[int] = None,
    ) -> WorkflowExecution:
        """Execute a complete workflow for a task."""
        execution = WorkflowExecution(
            workflow_name=workflow.name,
            task_id=str(task.get("id")),
            task_identifier=task.get("identifier", ""),
            started_at=datetime.now(),
            status="running",
            context={"task": task, "workspace": str(workspace_dir)},
            attempt_id=attempt_id,
        )

        console.print(f"\n[bold blue]Starting workflow:[/bold blue] {workflow.name}")
        console.print(
            f"[dim]Task: {task.get('identifier')} - {task.get('title')}[/dim]\n"
        )

        try:
            # Execute all jobs (currently supporting single job)
            for job_name, job in workflow.jobs.items():
                console.print(f"[bold]Job:[/bold] {job.name}")

                # Create execution context
                ctx = ExecutionContext(
                    task=task,
                    workspace_dir=workspace_dir,
                    outputs={},
                    env={},
                )

                # Execute each step
                for step in job.steps:
                    step_result = await self._execute_step(step, ctx)
                    execution.step_results.append(step_result)

                    # Update context with step outputs
                    if step.id and step_result.output:
                        ctx.outputs[step.id] = step_result.output

                    # Handle step failure
                    if step_result.status == StepStatus.FAILURE:
                        if not step.continue_on_error:
                            execution.status = "failure"
                            console.print(
                                f"\n[bold red]Workflow failed at step: {step.name}[/bold red]"
                            )

                            # Execute failure handlers if defined
                            if workflow.on_failure:
                                await self._execute_failure_handlers(
                                    workflow.on_failure.steps, ctx, step_result
                                )

                            break

            # Mark as success if all steps completed
            if execution.status == "running":
                execution.status = "success"
                console.print(
                    "\n[bold green]✓ Workflow completed successfully[/bold green]"
                )

        except Exception as e:
            execution.status = "failure"
            console.print(f"\n[bold red]✗ Workflow failed with error:[/bold red] {e}")

        finally:
            execution.completed_at = datetime.now()

            # Update attempt with token costs and artifacts (if attempt_id provided)
            if attempt_id:
                try:
                    # Update attempt with token costs
                    await self._update_attempt_with_costs(attempt_id, execution)

                    # Create workflow artifacts
                    await self._create_workflow_artifacts(execution, attempt_id)
                except Exception as e:
                    console.print(
                        f"[yellow]Warning: Failed to update attempt: {e}[/yellow]"
                    )

        return execution

    async def _execute_step(
        self, step: WorkflowStep, ctx: ExecutionContext
    ) -> StepResult:
        """Execute a single workflow step."""
        step_id = step.id or step.name.lower().replace(" ", "_")
        console.print(f"\n[cyan]▶[/cyan] {step.name}")

        result = StepResult(
            step_id=step_id,
            step_name=step.name,
            status=StepStatus.RUNNING,
            started_at=datetime.now(),
        )

        # Check conditional execution
        if step.if_:
            try:
                # Build context for expression evaluation
                eval_context = self._build_evaluation_context(ctx)
                evaluator = ExpressionEvaluator(eval_context)
                should_run = evaluator.evaluate(step.if_)

                if not should_run:
                    console.print(
                        "  [dim yellow]⊘ Skipped (condition not met)[/dim yellow]"
                    )
                    result.status = StepStatus.SKIPPED
                    result.completed_at = datetime.now()
                    return result
            except Exception as e:
                console.print(f"  [red]✗ Condition evaluation failed:[/red] {e}")
                result.status = StepStatus.FAILURE
                result.error = f"Condition evaluation failed: {e}"
                result.completed_at = datetime.now()
                return result

        # Handle parallel execution
        if step.parallel is not None:
            return await self._execute_parallel_steps(step, step.parallel, ctx)

        try:
            # Check cache if applicable
            cache_key = self._get_cache_key(step, ctx)
            if cache_key:
                cached_result = await self.cache_manager.get(cache_key)
                if cached_result:
                    console.print("  [dim]✓ Using cached result[/dim]")
                    result.status = StepStatus.SUCCESS
                    result.output = cached_result
                    result.completed_at = datetime.now()
                    return result

            # Execute based on step type
            if step.uses:
                # Action-based step
                output = await self._execute_action(step, ctx)
            elif step.run:
                # Command-based step
                output = await self._execute_command(step, ctx)
            elif step.parallel:
                # Parallel steps - should never reach here as handled above
                raise ValueError(
                    f"Internal error: parallel step should have been handled: {step.name}"
                )
            else:
                raise ValueError(
                    f"Step must have either 'uses', 'run', or 'parallel': {step.name}"
                )

            result.status = StepStatus.SUCCESS
            result.output = output

            # Cache result if applicable
            if cache_key:
                await self.cache_manager.set(cache_key, output)

            console.print("  [dim green]✓ Completed[/dim green]")

        except Exception as e:
            result.status = StepStatus.FAILURE
            result.error = str(e)

            # Enhanced error logging with context
            error_details: list[str] = []
            error_details.append(f"[red]✗ Failed:[/red] {e}")

            # Add action/command context
            if step.uses:
                error_details.append(f"  [dim]Action: {step.uses}[/dim]")
            elif step.run:
                error_details.append(
                    f"  [dim]Command: {step.run[:100]}{'...' if len(step.run) > 100 else ''}[/dim]"
                )

            # Add step parameters if available (helps debug configuration issues)
            if step.with_:
                # Don't log sensitive data like full auth tokens, just indicate what params were used
                param_keys = list(step.with_.keys())
                error_details.append(
                    f"  [dim]Parameters: {', '.join(param_keys)}[/dim]"
                )

            # Print all error details
            console.print("\n".join(error_details))

        finally:
            result.completed_at = datetime.now()
            if result.started_at and result.completed_at:
                result.duration_seconds = (
                    result.completed_at - result.started_at
                ).total_seconds()

        return result

    async def _execute_parallel_steps(
        self,
        parent_step: WorkflowStep,
        parallel_steps: "list[WorkflowStep]",
        ctx: ExecutionContext,
    ) -> StepResult:
        """
        Execute multiple steps in parallel.

        Args:
            parent_step: The parent step containing parallel configuration
            parallel_steps: List of steps to execute in parallel
            ctx: Execution context

        Returns:
            StepResult with aggregated outputs and status
        """
        step_id = parent_step.id or parent_step.name.lower().replace(" ", "_")
        parent_result = StepResult(
            step_id=step_id,
            step_name=parent_step.name,
            status=StepStatus.RUNNING,
            started_at=datetime.now(),
        )

        console.print(
            f"  [dim]Running {len(parallel_steps)} steps in parallel...[/dim]"
        )

        try:
            # Create tasks for parallel execution
            tasks: list[Any] = []
            for i, sub_step in enumerate(parallel_steps):
                # Ensure sub-step has an ID for tracking
                if not sub_step.id:
                    sub_step.id = f"{step_id}_parallel_{i}"
                tasks.append(self._execute_step(sub_step, ctx))

            # Execute all steps in parallel and gather results
            # Use return_exceptions=True to handle partial failures
            results: list[Any] = await asyncio.gather(*tasks, return_exceptions=True)

            # Process results
            aggregated_outputs: dict[str, Any] = {}
            failed_steps: list[dict[str, Any]] = []
            successful_steps: list[str] = []
            skipped_steps: list[str] = []

            for i, result_or_exception in enumerate(results):
                sub_step = parallel_steps[i]
                sub_step_id = sub_step.id or f"{step_id}_parallel_{i}"

                if isinstance(result_or_exception, Exception):
                    # Handle exception
                    failed_steps.append(
                        {
                            "name": sub_step.name,
                            "error": str(result_or_exception),
                        }
                    )
                    console.print(
                        f"  [red]✗ {sub_step.name} failed:[/red] {result_or_exception}"
                    )
                elif isinstance(result_or_exception, StepResult):
                    step_result = result_or_exception
                    # Add to context outputs
                    if step_result.output:
                        ctx.outputs[sub_step_id] = step_result.output
                        aggregated_outputs[sub_step_id] = step_result.output

                    # Track status
                    if step_result.status == StepStatus.SUCCESS:
                        successful_steps.append(sub_step.name)
                    elif step_result.status == StepStatus.FAILURE:
                        failed_steps.append(
                            {
                                "name": sub_step.name,
                                "error": step_result.error or "Unknown error",
                            }
                        )
                    elif step_result.status == StepStatus.SKIPPED:
                        skipped_steps.append(sub_step.name)

            # Determine overall status
            if failed_steps and not parent_step.continue_on_error:
                parent_result.status = StepStatus.FAILURE
                parent_result.error = (
                    f"{len(failed_steps)} step(s) failed: "
                    + ", ".join(f["name"] for f in failed_steps)
                )
                console.print(
                    f"  [red]✗ {len(failed_steps)} parallel step(s) failed[/red]"
                )
            else:
                parent_result.status = StepStatus.SUCCESS
                console.print(
                    f"  [dim green]✓ {len(successful_steps)} step(s) succeeded"
                    + (
                        f", {len(failed_steps)} failed (ignored)"
                        if failed_steps
                        else ""
                    )
                    + (f", {len(skipped_steps)} skipped" if skipped_steps else "")
                    + "[/dim green]"
                )

            # Set aggregated output
            parent_result.output = {
                "parallel_results": aggregated_outputs,
                "summary": {
                    "total": len(parallel_steps),
                    "successful": len(successful_steps),
                    "failed": len(failed_steps),
                    "skipped": len(skipped_steps),
                },
                "failed_steps": failed_steps if failed_steps else None,
            }

        except Exception as e:
            parent_result.status = StepStatus.FAILURE
            parent_result.error = f"Parallel execution failed: {e}"
            console.print(f"  [red]✗ Parallel execution failed:[/red] {e}")

        finally:
            parent_result.completed_at = datetime.now()
            if parent_result.started_at and parent_result.completed_at:
                parent_result.duration_seconds = (
                    parent_result.completed_at - parent_result.started_at
                ).total_seconds()

        return parent_result

    async def _execute_action(
        self, step: WorkflowStep, ctx: ExecutionContext
    ) -> Dict[str, Any]:
        """Execute an action-based step."""
        if not step.uses:
            raise ValueError("Step must have 'uses' field for action execution")
        action = self.action_registry.get_action(step.uses)
        if not action:
            raise ValueError(f"Unknown action: {step.uses}")

        # Interpolate variables in step parameters
        params = self._interpolate_vars(step.with_ or {}, ctx)

        return await action.execute(params, ctx)

    async def _execute_command(
        self, step: WorkflowStep, ctx: ExecutionContext
    ) -> Dict[str, Any]:
        """Execute a command-based step."""
        command = self._interpolate_vars(step.run, ctx)

        # Prepare environment with secrets interpolation
        env = {**ctx.env, **(step.env or {})}
        # Interpolate secrets in environment variables
        env = self.secrets_manager.interpolate_dict(env)

        # Execute command
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=ctx.workspace_dir,
            env=env,
        )

        # Wait with timeout
        try:
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=step.timeout_minutes * 60
            )
        except asyncio.TimeoutError:
            process.kill()
            raise TimeoutError(f"Step timed out after {step.timeout_minutes} minutes")

        # Check exit code
        if process.returncode != 0:
            raise RuntimeError(
                f"Command failed with exit code {process.returncode}\n{stderr.decode()}"
            )

        return {
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
            "exit_code": process.returncode,
        }

    async def _execute_failure_handlers(
        self,
        failure_steps: "list[WorkflowStep]",
        ctx: ExecutionContext,
        failed_step: StepResult,
    ) -> None:
        """Execute failure handler steps."""
        console.print("\n[yellow]Running failure handlers...[/yellow]")

        # Add failure info to context
        ctx.outputs["failure"] = {
            "step": failed_step.step_name,
            "message": failed_step.error,
        }

        for step in failure_steps:
            try:
                await self._execute_step(step, ctx)
            except Exception as e:
                console.print(f"[red]Failure handler error:[/red] {e}")

    def _get_cache_key(
        self, step: WorkflowStep, ctx: ExecutionContext
    ) -> Optional[str]:
        """Generate cache key for a step if caching is enabled."""
        if not step.uses or "cache" not in (step.with_ or {}):
            return None

        # For now, simple key based on step and task
        task_id = ctx.task.get("id")
        task_updated = ctx.task.get("updated_at", "")
        return f"step:{step.uses}:task:{task_id}:updated:{task_updated}"

    def _build_evaluation_context(self, ctx: ExecutionContext) -> Dict[str, Any]:
        """
        Build context dictionary for expression evaluation.

        Returns:
            Dictionary containing steps, env, task, and other variables
        """
        # Convert step outputs to nested structure
        steps = {}
        for step_id, output in ctx.outputs.items():
            steps[step_id] = {
                "outputs": output if isinstance(output, dict) else {"value": output}
            }

        return {
            "steps": steps,
            "env": ctx.env,
            "task": ctx.task,
        }

    def _interpolate_vars(self, value: Any, ctx: ExecutionContext) -> Any:
        """Interpolate variables in strings like ${{ task.title }} and ${{ secrets.NAME }}."""
        import json as json_module

        if isinstance(value, str):
            # Simple variable replacement (TODO: implement proper expression evaluator)
            result = value

            # Replace task variables
            for key, val in ctx.task.items():
                result = result.replace(f"${{{{ task.{key} }}}}", str(val))

            # Replace step outputs
            for step_id, output in ctx.outputs.items():
                if isinstance(output, dict):
                    output_dict: dict[str, Any] = cast(dict[str, Any], output)
                    for out_key, out_val in output_dict.items():
                        # Use json.dumps for complex types (dict, list) to ensure valid JSON
                        if isinstance(out_val, (dict, list)):
                            replacement = json_module.dumps(out_val)
                        else:
                            replacement = str(out_val)
                        result = result.replace(
                            f"${{{{ steps.{step_id}.outputs.{out_key} }}}}",
                            replacement,
                        )

            # Replace secrets
            try:
                result = self.secrets_manager.interpolate_secrets(result)
            except ValueError as e:
                # Re-raise with better context
                raise ValueError(f"Secret interpolation failed: {e}") from e

            return result

        elif isinstance(value, dict):
            value_dict: dict[str, Any] = cast(dict[str, Any], value)
            return {k: self._interpolate_vars(v, ctx) for k, v in value_dict.items()}

        elif isinstance(value, list):
            value_list: list[Any] = cast(list[Any], value)  # type: ignore[redundant-cast]
            return [self._interpolate_vars(item, ctx) for item in value_list]

        return value

    async def _create_workflow_artifacts(
        self, execution: WorkflowExecution, attempt_id: int
    ) -> None:
        """
        Create artifacts for workflow execution.

        Creates execution summary and error log artifacts attached to the attempt.

        Args:
            execution: Completed workflow execution
            attempt_id: ID of the attempt to attach artifacts to

        Raises:
            Exception: If artifact creation fails (caller should handle gracefully)
        """
        from cli.generated.models.CreateArtifactRequest import CreateArtifactRequest
        from cli.generated.services.async_Artifacts_service import (
            create_artifact_v1_workspaces__workspace_id__attempts__attempt_id__artifacts__post,
        )

        # Get API config with correct base URL
        api_config = self._get_api_config()

        # Get workspace_id from execution context, fallback to self.workspace_id
        task = execution.context.get("task", {})
        workspace_id = task.get("workspace_id") or self.workspace_id

        # Artifact 1: Execution summary (always created)
        summary_json = self._generate_execution_summary(execution)
        artifact_data = CreateArtifactRequest(
            type="log",
            name="workflow_execution_summary.json",
            content=summary_json,
            mime_type="application/json",
        )

        # Debug logging
        console.print(
            f"[dim]Creating artifact with data: {artifact_data.model_dump()}[/dim]"
        )
        console.print(
            f"[dim]Workspace ID: {workspace_id}, Attempt ID: {attempt_id}[/dim]"
        )

        try:
            # Build kwargs for API call
            api_kwargs: Dict[str, Any] = {
                "api_config_override": api_config,
                "attempt_id": attempt_id,
                "data": artifact_data,
                "workspace_id": workspace_id,
            }
            # Only pass X_API_Key if agent_key is available (not None)
            if self.agent_key is not None:
                api_kwargs["X_API_Key"] = self.agent_key

            await create_artifact_v1_workspaces__workspace_id__attempts__attempt_id__artifacts__post(
                **api_kwargs
            )
        except Exception as e:
            console.print(f"[red]Artifact creation failed: {e}[/red]")
            console.print(f"[dim]Artifact data was: {artifact_data.model_dump()}[/dim]")
            console.print(
                f"[dim]Workspace ID: {workspace_id}, Attempt ID: {attempt_id}[/dim]"
            )
            raise

        # Artifact 2: Error log (only on failure)
        if execution.status == "failure":
            error_log = self._generate_error_log(execution)
            # Build kwargs for API call
            error_api_kwargs: Dict[str, Any] = {
                "api_config_override": api_config,
                "attempt_id": attempt_id,
                "data": CreateArtifactRequest(
                    type="log",
                    name="workflow_errors.txt",
                    content=error_log,
                    mime_type="text/plain",
                ),
                "workspace_id": workspace_id,
            }
            # Only pass X_API_Key if agent_key is available (not None)
            if self.agent_key is not None:
                error_api_kwargs["X_API_Key"] = self.agent_key

            await create_artifact_v1_workspaces__workspace_id__attempts__attempt_id__artifacts__post(
                **error_api_kwargs
            )

        console.print("[dim]✓ Created workflow artifacts[/dim]")

    def _generate_execution_summary(self, execution: WorkflowExecution) -> str:
        """
        Generate JSON execution summary.

        Args:
            execution: Completed workflow execution

        Returns:
            JSON string containing execution summary
        """
        import json

        # Calculate duration
        duration_seconds = 0.0
        if execution.started_at and execution.completed_at:
            duration_seconds = (
                execution.completed_at - execution.started_at
            ).total_seconds()

        # Build step summaries
        steps: list[dict[str, Any]] = []
        for step_result in execution.step_results:
            step_duration = step_result.duration_seconds or 0.0
            # Preview output (truncate if too long)
            output_preview = None
            if step_result.output:
                output_str = str(step_result.output)
                output_preview = (
                    output_str[:200] + "..." if len(output_str) > 200 else output_str
                )

            steps.append(
                {
                    "step_id": step_result.step_id,
                    "step_name": step_result.step_name,
                    "status": step_result.status.value,
                    "duration_seconds": round(step_duration, 2),
                    "output_preview": output_preview,
                    "error": step_result.error,
                }
            )

        # Calculate summary counts
        total_steps = len(execution.step_results)
        steps_succeeded = sum(
            1 for s in execution.step_results if s.status == StepStatus.SUCCESS
        )
        steps_failed = sum(
            1 for s in execution.step_results if s.status == StepStatus.FAILURE
        )
        steps_skipped = sum(
            1 for s in execution.step_results if s.status == StepStatus.SKIPPED
        )

        summary: dict[str, Any] = {
            "workflow_name": execution.workflow_name,
            "task_id": execution.task_id,
            "task_identifier": execution.task_identifier,
            "started_at": (
                execution.started_at.isoformat() if execution.started_at else None
            ),
            "completed_at": (
                execution.completed_at.isoformat() if execution.completed_at else None
            ),
            "duration_seconds": round(duration_seconds, 2),
            "status": execution.status,
            "steps": steps,
            "summary": {
                "total_steps": total_steps,
                "steps_succeeded": steps_succeeded,
                "steps_failed": steps_failed,
                "steps_skipped": steps_skipped,
            },
        }

        return json.dumps(summary, indent=2)

    def _generate_error_log(self, execution: WorkflowExecution) -> str:
        """
        Generate human-readable error log for failed workflow.

        Args:
            execution: Failed workflow execution

        Returns:
            Formatted error log text
        """
        lines: list[str] = []

        # Header
        lines.append("WORKFLOW EXECUTION FAILED")
        lines.append("=" * 50)
        lines.append("")
        lines.append(f"Workflow: {execution.workflow_name}")
        lines.append(
            f"Task: {execution.task_identifier} - {execution.context.get('task', {}).get('title', 'N/A')}"
        )

        if execution.started_at:
            lines.append(f"Started: {execution.started_at.isoformat()}")
        if execution.completed_at:
            lines.append(f"Failed: {execution.completed_at.isoformat()}")

        # Duration
        if execution.started_at and execution.completed_at:
            duration = (execution.completed_at - execution.started_at).total_seconds()
            lines.append(f"Duration: {duration:.1f} seconds")

        lines.append("")

        # Failed steps
        failed_steps = [
            s for s in execution.step_results if s.status == StepStatus.FAILURE
        ]

        if failed_steps:
            lines.append("FAILED STEPS")
            lines.append("=" * 50)
            lines.append("")

            for step in failed_steps:
                lines.append(f"Step: {step.step_name}")
                lines.append(f"Status: {step.status.value.upper()}")
                if step.duration_seconds:
                    lines.append(f"Duration: {step.duration_seconds:.1f} seconds")
                if step.error:
                    lines.append(f"Error: {step.error}")
                lines.append("")

                # Include step output if available
                if step.output:
                    lines.append("Step output:")
                    lines.append("-" * 50)
                    output_str = str(step.output)
                    # Limit output to avoid huge artifacts
                    if len(output_str) > 5000:
                        lines.append(output_str[:5000])
                        lines.append("... (output truncated)")
                    else:
                        lines.append(output_str)
                    lines.append("")

        # Overall workflow error (if any caught at workflow level)
        lines.append("WORKFLOW STATUS")
        lines.append("=" * 50)
        lines.append(f"Final status: {execution.status}")
        lines.append(
            f"Steps completed: {len([s for s in execution.step_results if s.status != StepStatus.PENDING])}/{len(execution.step_results)}"
        )

        return "\n".join(lines)

    async def _update_attempt_with_costs(
        self, attempt_id: int, execution: WorkflowExecution
    ) -> None:
        """
        Update attempt with token costs from workflow execution.

        Since cost_tokens is set via FinishAttemptInput only, we store it
        in the execution summary artifact's metadata for now.

        Args:
            attempt_id: ID of the attempt to update
            execution: Completed workflow execution with token tracking
        """
        # Token costs are tracked in the execution summary artifact
        # The finish_attempt API call should set cost_tokens when finishing
        if execution.total_tokens > 0:
            console.print(f"[dim]✓ Tracked token costs: {execution.total_tokens}[/dim]")
