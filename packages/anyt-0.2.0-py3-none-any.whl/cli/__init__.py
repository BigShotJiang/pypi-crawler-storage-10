"""AnyTask CLI - Command-line interface for AnyTask task management."""

__version__ = "0.2.0"
