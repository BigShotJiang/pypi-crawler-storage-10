"""Domain model wrappers - delegate to generated models with CLI-friendly API."""

from cli.models.wrappers.task import Task, TaskDependencyInfo

__all__ = ["Task", "TaskDependencyInfo"]
