"""Initialize AnyTask workspace in current directory."""

import asyncio
import os
from datetime import datetime
from pathlib import Path

import typer
from typing_extensions import Annotated
from rich.console import Console
from rich.prompt import Prompt

from cli.config import GlobalConfig, WorkspaceConfig
from cli.services.workspace_service import WorkspaceService
from cli.services.project_service import ProjectService

console = Console()


def init(
    workspace_id: Annotated[
        int | None,
        typer.Option("--workspace-id", "-w", help="Workspace ID to link to"),
    ] = None,
    workspace_name: Annotated[
        str | None,
        typer.Option("--workspace-name", "-n", help="Workspace name (optional)"),
    ] = None,
    identifier: Annotated[
        str | None,
        typer.Option(
            "--identifier", "-i", help="Workspace identifier (e.g., DEV, PROJ)"
        ),
    ] = None,
    directory: Annotated[
        Path | None,
        typer.Option("--dir", "-d", help="Directory to initialize (default: current)"),
    ] = None,
) -> None:
    """Initialize AnyTask in the current directory.

    Automatically fetches your current workspace and project if ANYT_AGENT_KEY is set.
    Creates .anyt/ directory structure and anyt.json configuration.

    Examples:
        anyt init                                    # Auto-setup with ANYT_AGENT_KEY
        anyt init --workspace-id 123 --identifier DEV  # Link to specific workspace
    """
    try:
        # Determine target directory
        target_dir = directory or Path.cwd()
        target_dir = target_dir.resolve()

        # Create .anyt directory if it doesn't exist
        anyt_dir = target_dir / ".anyt"
        if not anyt_dir.exists():
            anyt_dir.mkdir(parents=True)
            console.print("[green]✓[/green] Created .anyt/ directory")
        else:
            console.print("[dim].anyt/ directory already exists[/dim]")

        # Create subdirectories
        subdirs = ["workflows", "tasks"]
        for subdir in subdirs:
            subdir_path = anyt_dir / subdir
            if not subdir_path.exists():
                subdir_path.mkdir(parents=True)
                console.print(f"[green]✓[/green] Created .anyt/{subdir}/ directory")

        # Check if workspace config already exists
        existing_config = WorkspaceConfig.load(target_dir)
        if existing_config:
            console.print(
                f"[yellow]Warning:[/yellow] Workspace config already exists: {existing_config.name}"
            )
            console.print(f"Workspace ID: {existing_config.workspace_id}")
            if existing_config.workspace_identifier:
                console.print(f"Identifier: {existing_config.workspace_identifier}")

            reset = Prompt.ask(
                "Do you want to reset it?", choices=["y", "N"], default="N"
            )

            if reset.lower() != "y":
                # Even if not resetting, update agent_key from environment if available
                config = GlobalConfig.load()
                effective_config = config.get_effective_config()
                new_agent_key = effective_config.get("agent_key")

                # Check if agent_key changed
                if new_agent_key and new_agent_key != existing_config.agent_key:
                    existing_config.agent_key = new_agent_key
                    existing_config.save(target_dir)
                    console.print(
                        "[green]✓[/green] Updated agent key from environment variable"
                    )
                    console.print(f"[dim]New key: {new_agent_key[:20]}...[/dim]")

                console.print("[green]✓[/green] Using existing workspace configuration")
                raise typer.Exit(0)

        # Check for ANYT_AGENT_KEY environment variable
        agent_key = os.getenv("ANYT_AGENT_KEY")

        # If workspace_id is provided, create workspace config manually
        if workspace_id:
            config = GlobalConfig.load()
            effective_config = config.get_effective_config()

            ws_config = WorkspaceConfig(
                workspace_id=workspace_id,
                name=workspace_name or f"Workspace {workspace_id}",
                api_url=effective_config.get("api_url", "http://localhost:8000"),
                workspace_identifier=identifier,
                current_project_id=None,
                agent_key=effective_config.get("agent_key"),
                last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )
            ws_config.save(target_dir)

            console.print(f"[green]✓[/green] Linked to workspace ID {workspace_id}")
            console.print(
                f"[green]✓[/green] Saved config to {target_dir}/.anyt/anyt.json"
            )
        elif agent_key:
            # Agent key is set - automatically fetch and setup workspace
            console.print(
                "[cyan]ANYT_AGENT_KEY detected - setting up workspace...[/cyan]"
            )

            async def setup_workspace() -> None:
                try:
                    # Load config and initialize services
                    config = GlobalConfig.load()
                    effective_config = config.get_effective_config()

                    workspace_service: WorkspaceService = WorkspaceService.from_config(
                        config
                    )
                    project_service: ProjectService = ProjectService.from_config(config)

                    # Fetch available workspaces (agent keys can list but not create)
                    console.print("Fetching accessible workspaces...")
                    workspaces = await workspace_service.list_workspaces()

                    if not workspaces:
                        console.print(
                            "[red]Error:[/red] No accessible workspaces found for this agent key"
                        )
                        console.print(
                            "\nAgent keys require at least one workspace to be created first."
                        )
                        console.print(
                            "Please create a workspace using the web interface at [cyan]https://anyt.dev[/cyan]"
                        )
                        raise typer.Exit(1)

                    # Use the first available workspace
                    workspace = workspaces[0]
                    console.print(
                        f"[green]✓[/green] Using workspace: {workspace.name} ({workspace.identifier})"
                    )

                    # If multiple workspaces, show info
                    if len(workspaces) > 1:
                        console.print(
                            f"[dim]Found {len(workspaces)} workspaces. Using the first one.[/dim]"
                        )
                        console.print(
                            "[dim]Use 'anyt workspace list' to see all, or 'anyt workspace switch' to change.[/dim]"
                        )

                    # Fetch or create default project
                    console.print("Fetching current project...")
                    try:
                        current_project = (
                            await project_service.get_or_create_default_project(
                                workspace.id, workspace.identifier
                            )
                        )
                        current_project_id = current_project.id
                        console.print(
                            f"[green]✓[/green] Using project: {current_project.name} ({current_project.identifier})"
                        )
                    except Exception as e:
                        console.print(
                            f"[yellow]Warning:[/yellow] Could not fetch current project: {e}"
                        )
                        current_project_id = None

                    # Create and save workspace config
                    ws_config = WorkspaceConfig(
                        workspace_id=workspace.id,
                        name=workspace.name,
                        api_url=effective_config["api_url"],
                        workspace_identifier=workspace.identifier,
                        current_project_id=current_project_id,
                        agent_key=agent_key,
                        last_sync=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    )
                    ws_config.save(target_dir)

                    console.print(
                        f"[green]✓[/green] Saved config to {target_dir}/.anyt/anyt.json"
                    )

                except Exception as e:
                    if not isinstance(e, typer.Exit):
                        console.print(
                            f"[red]Error:[/red] Failed to setup workspace: {e}"
                        )
                        raise typer.Exit(1)
                    raise

            asyncio.run(setup_workspace())
        else:
            # No agent key and no workspace_id - show warning
            console.print("\n[yellow]⚠ ANYT_AGENT_KEY not found[/yellow]")
            console.print("\nTo complete setup, you need an agent API key:")
            console.print(
                "  1. Get your agent key from: [cyan]https://anyt.dev/home/settings/agent-keys[/cyan]"
            )
            console.print("  2. Set the environment variable:")
            console.print("     [dim]export ANYT_AGENT_KEY=anyt_agent_...[/dim]")
            console.print("  3. Run [cyan]anyt init[/cyan] again")
            console.print(
                "\n[dim]Directory structure created. Run anyt init again with ANYT_AGENT_KEY set.[/dim]"
            )
            raise typer.Exit(0)

        console.print("\n[green]✓[/green] Initialization complete!")

    except Exception as e:
        if not isinstance(e, typer.Exit):
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(1)
