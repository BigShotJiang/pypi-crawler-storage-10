# SPDX-FileCopyrightText: 2024-present Ramiro Gómez <code@ramiro.org>
#
# SPDX-License-Identifier: MIT
