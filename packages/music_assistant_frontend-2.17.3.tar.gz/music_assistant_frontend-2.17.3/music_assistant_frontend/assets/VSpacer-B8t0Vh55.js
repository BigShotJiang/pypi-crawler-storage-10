/* empty css              */import{cM as r}from"./index-CD7iYaFT.js";const e=r("v-spacer","div","VSpacer");export{e as V};
