"""
Service modules for Ruby Manager Web3 package
"""

from .events import EventService

__all__ = [
    "EventService",
]