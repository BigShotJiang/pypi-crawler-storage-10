# Orderman

A simple library to execute functions in a specific order. define the order of functions and classes with @task(). Inside of @task() you can put any intreger which will determine the order of the execution of that function. Eg- @task(1) would execute before @task(3)