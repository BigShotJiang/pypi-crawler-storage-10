# Melodi Connector

> ⚠️ **Status**: This library is under construction. Not yet ready for production use.

Python translation of the `melodi-connector` typescript package. 
