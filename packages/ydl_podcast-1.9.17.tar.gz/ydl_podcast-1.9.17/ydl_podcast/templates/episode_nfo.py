EPISODE_NFO_TMPL = """<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<episodedetails>
  <plot />
  <lockdata>true</lockdata>
  <dateadded>{{ ep_date }}</dateadded>
  <title>{{ title }}</title>
  <runtime>{{ duration }}</runtime>
  <art />
  <showtitle>{{ show_title }}</showtitle>
  <aired>{{ ep_date }}</aired>
</episodedetails>
"""
