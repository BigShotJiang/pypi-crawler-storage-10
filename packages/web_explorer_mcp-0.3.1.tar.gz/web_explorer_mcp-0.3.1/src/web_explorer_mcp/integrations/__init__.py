"""Integrations package exports."""

from web_explorer_mcp.integrations import (
    web,
)

__all__ = ["web"]
