import argparse
import os
import subprocess
import sys
from pathlib import Path

import toml
from colorama import just_fix_windows_console
from termcolor import colored

just_fix_windows_console()

python_cmd = "py" if os.name == "nt" else "python3"
pyproject_path = Path("pyproject.toml")
purples = {
    "1": (95, 2, 130),
    "2": (136, 3, 186),
    "3": (161, 11, 190),
}


def log_step(text: str, color=True):
    print("-" * len(text))
    print(colored(text, purples["1"]) if color else text)
    print("-" * len(text))


def _run(args: list[str], error_msg: str = None):
    exit_code = subprocess.run(args).returncode
    if exit_code != 0:
        raise Exception(
            f"{colored(f'Erro ({exit_code}):', 'red', attrs=['bold'])} {error_msg if error_msg else f'Falha ao executar: {args}'}"
        )


def get_toml_file():
    if not pyproject_path.is_file():
        print(f"{colored('pyproject.toml', purples['1'])} não encontrado.")
        sys.exit(1)

    return toml.load(pyproject_path)


def confirm_new_version(pyproject, version):
    old_version = pyproject["project"]["version"]
    print(
        f"Versão anterior: {colored(old_version, purples['1'], attrs=['bold'])}"
    )  # Purple color
    confirmation = input(
        f"Confirma a alteração de versão de {colored(old_version, purples['1'], attrs=['bold'])} para {colored(version, purples['2'], attrs=['bold'])}? (S/n): "
    )

    return confirmation.lower() == "s" or not confirmation


# Function to update the version in pyproject.toml
def update_version_in_toml(pyproject, version: str):
    pyproject["project"]["version"] = version
    toml.dump(pyproject, open(pyproject_path, "w", encoding="utf-8"))


# Function to check for uncommitted changes
def check_git_status():
    status = subprocess.run(
        ["git", "status", "--porcelain"], capture_output=True, text=True
    )
    return status.stdout.strip()


# Function to create a new git tag
def create_git_tag(version):
    _run(["git", "add", "."])
    _run(["git", "commit", "-m", f"chore: v{version}"])
    _run(["git", "tag", version])


# function to push the tag to origin
def push_git_tag(version):
    _run(["git", "push", "origin", version])


# function to reset git changes
def reset_git(version):
    subprocess.run(["git", "tag", "-d", version])
    subprocess.run(["git", "checkout", "."])


# Function to build the package
def build_package():
    _run([python_cmd, "-m", "build"], "Erro ao realizar build")


# Function to upload the package
def upload_package(version: str):
    _run(
        [python_cmd, "-m", "twine", "upload", f"dist/*{version}*"],
        "Erro ao realizar upload",
    )


# Main functionality
def main():
    parser = argparse.ArgumentParser(
        description="Faz build e upload do módulo para o Pypi"
    )
    parser.add_argument("version", help="Nova versão do módulo.")
    parser.add_argument(
        "-b", "--build", action="store_true", help="Habilitar build. Padrão True."
    )
    parser.add_argument(
        "-u", "--upload", action="store_true", help="Habilitar upload. Padrão True."
    )
    args = parser.parse_args()

    if check_git_status():
        print(
            f"{colored('Erro:', 'red', attrs=['bold'])} {colored('Você tem alterações no git. Verifique e faça commit antes de fazer upload.', purples['2'])}"
        )
        sys.exit(1)

    try:
        log_step("Atualizando versão no pyproject.toml")
        pyproject = get_toml_file()
        if not confirm_new_version(pyproject, args.version):
            print("Operação abortada")
            sys.exit()
        update_version_in_toml(pyproject, args.version)

        if args.build:
            log_step("Realizando build")
            build_package()
        else:
            log_step("Pulando build")

        if args.upload:
            log_step("Realizando upload")
            upload_package(args.version)
        else:
            log_step("Pulando upload")

        log_step("Fazendo commit das alterações e criando tag no git")
        create_git_tag(args.version)
        if args.upload:
            log_step("Subindo tag no git")
            push_git_tag(args.version)
        else:
            log_step("Pulando push no git")

        print()
        print(
            colored(
                "*** Sucesso! ***", color="white", on_color=purples["3"], attrs=["bold"]
            ),
            color=False,
        )
    except KeyboardInterrupt:
        print(colored("Encerrando por escolha do usuárie. Tchau!", purples["3"]))
        reset_git(args.version)
        sys.exit()
    except Exception as e:
        print(e)
        reset_git(args.version)


if __name__ == "__main__":
    main()
