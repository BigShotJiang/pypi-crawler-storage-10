from mcp_server_gaode_thy import main

main()