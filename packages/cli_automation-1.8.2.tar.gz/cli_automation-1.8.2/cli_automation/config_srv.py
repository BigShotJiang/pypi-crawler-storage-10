
CONFIG_PARAMS = {
    "log_file": "cla.log",
    "telnet_prompts": [">", "#", "(config)#", "(config-if)#", "$", "%", "> (doble)","# (doble)", "?", ")", "!", "*", "~", ":]", "]", ">", "##"],
    "tunnel_port_test": 22,
    "tunnel_timeout": 10,
    "proxy_host": "localhost",
    "tunnel_local_port": 1080
}