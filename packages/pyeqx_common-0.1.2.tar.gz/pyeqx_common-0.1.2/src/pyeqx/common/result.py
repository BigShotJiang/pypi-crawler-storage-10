from typing import Generic, TypeVar

TResultData = TypeVar("TResultData")


class FunctionExecuteResultBase(Generic[TResultData]):
    def __init__(
        self,
        data: TResultData = None,
        is_success: bool = False,
        error: Exception | None = None,
    ):
        self.data: TResultData = data
        self.is_success = is_success
        self.error = error


class FunctionExecuteResult(FunctionExecuteResultBase[TResultData | None]):
    def __init__(self, data: TResultData = None, error: Exception | None = None):
        if error is None:
            super().__init__(data=data, is_success=True, error=None)
        else:
            super().__init__(data=None, is_success=False, error=error)


class ReturnResultBase(Generic[TResultData]):
    def __init__(
        self,
        data: TResultData = None,
        is_error: bool = False,
        error: Exception | None = None,
    ) -> None:
        self.data = data
        self.is_error = is_error
        self.error = error


class ReturnResult(ReturnResultBase[TResultData | None]):
    def __init__(self, data: TResultData, error: Exception | None = None):
        if error is None:
            super().__init__(data=data, is_error=False, error=None)
        else:
            super().__init__(data=None, is_error=True, error=error)
