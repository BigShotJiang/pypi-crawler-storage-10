from .result import FunctionExecuteResult, ReturnResult


__all__ = [
    "FunctionExecuteResult",
    "ReturnResult",
]
