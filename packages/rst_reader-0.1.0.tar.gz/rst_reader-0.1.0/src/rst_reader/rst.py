import os
from abc import abstractmethod
from functools import cached_property
from pathlib import Path

import chardet
import spacy
import xmltodict
from pydantic import BaseModel, Field, PrivateAttr


class Relation(BaseModel):
    name: str
    type: str


class Node(BaseModel):
    id: int
    _rst: "RST" = PrivateAttr(init=False)
    relname: str | None
    parent_id: int | None

    @abstractmethod
    def get_order(self) -> int: ...

    @cached_property
    def relation(self) -> Relation | None:
        for relation in self._rst.relations:
            if relation.name == self.relname:
                return relation
        return None

    @cached_property
    def parent(self) -> "Node | None":
        if self.parent_id is not None:
            return self._rst[self.parent_id]
        return None

    @cached_property
    def children(self) -> list["Node"]:
        return [node for node in self._rst.nodes.values() if node.parent_id == self.id]

    @cached_property
    def is_root(self) -> bool:
        return self.parent_id is None

    @cached_property
    def signals(self) -> list["Signal"]:
        return [signal for signal in self._rst.signals if signal.source_id == self.id]


class Segment(Node):
    text: str
    order: int = Field(exclude=True)

    def get_order(self) -> int:
        return self.order


class Group(Node):
    type: str

    def get_order(self) -> int:
        return min(child.get_order() for child in self.children)


class Signal(BaseModel):
    _rst: "RST" = PrivateAttr(init=False)
    type: str
    subtype: str
    tokens_ids: list[int]
    source_id: int

    @cached_property
    def tokens(self) -> list[str]:
        return [self._rst.tokens[token_id - 1] for token_id in self.tokens_ids]

    @cached_property
    def source(self) -> Node:
        return self._rst[self.source_id]


class RST(BaseModel):
    nodes: dict[int, Node]
    relations: list[Relation]
    signals: list[Signal]

    @cached_property
    def segments(self) -> dict[int, Segment]:
        return {
            node_id: node
            for node_id, node in self.nodes.items()
            if isinstance(node, Segment)
        }

    @cached_property
    def groups(self) -> dict[int, Group]:
        return {
            node_id: node
            for node_id, node in self.nodes.items()
            if isinstance(node, Group)
        }

    @cached_property
    def tokens(self) -> list[str]:
        pln = spacy.blank("pt-BR")
        sorted_segments = sorted(self.segments.values(), key=lambda s: s.order)
        raw_text = " ".join([segment.text for segment in sorted_segments])
        doc = pln(raw_text)
        return [token.text for token in doc]

    @cached_property
    def text(self) -> str:
        pln = spacy.blank("pt-BR")
        sorted_segments = sorted(self.segments.values(), key=lambda s: s.order)
        raw_text = " ".join([segment.text for segment in sorted_segments])
        doc = pln(raw_text)
        return doc.text

    def __getitem__(self, node_id: int) -> Node:
        return self.nodes[node_id]


class RSTDocument(BaseModel):
    encoding: str
    file_name: str
    rst: RST


def listar_arquivos(pasta: Path) -> list[Path]:
    """Lista todos os arquivos em uma pasta específica."""
    return [arquivo for arquivo in pasta.rglob("*") if arquivo.is_file()]


def rs3_to_dict(arquivo: Path, encoding: str) -> dict:
    conteudo = arquivo.read_text(encoding=encoding)
    return xmltodict.parse(conteudo, encoding=encoding)["rst"]


def dict_to_rst(rst_dict: dict) -> RST:
    nodes: dict[int, Node] = {}
    relations: list[Relation] = []

    # if has_keys(rst_dict, ["header", "relations", "rel"]):
    for relation_dict in rst_dict["header"]["relations"]["rel"]:
        relations.append(
            Relation(
                name=relation_dict["@name"],
                type=relation_dict["@type"],
            )
        )

    order = 0

    for segment_dict in rst_dict["body"]["segment"]:
        rst_dependent = Segment(
            id=int(segment_dict["@id"]),
            text=segment_dict["#text"],
            relname=segment_dict.get("@relname"),
            parent_id=int(segment_dict["@parent"])
            if "@parent" in segment_dict
            else None,
            order=order,
        )
        assert rst_dependent.id not in nodes, f"ID duplicado: {rst_dependent.id}"
        nodes[rst_dependent.id] = rst_dependent
        order += 1

    for group_dict in rst_dict["body"]["group"]:
        rst_dependent = Group(
            id=int(group_dict["@id"]),
            type=group_dict["@type"],
            relname=group_dict.get("@relname"),
            parent_id=int(group_dict["@parent"]) if "@parent" in group_dict else None,
        )
        assert rst_dependent.id not in nodes, f"ID duplicado: {rst_dependent.id}"
        nodes[rst_dependent.id] = rst_dependent

    signals: list[Signal] = []

    if "signals" in rst_dict["body"]:
        for signal_dict in rst_dict["body"]["signals"]["signal"]:
            signals.append(
                Signal(
                    type=signal_dict["@type"],
                    subtype=signal_dict["@subtype"],
                    tokens_ids=[
                        int(token_id) for token_id in signal_dict["@tokens"].split(",")
                    ]
                    if signal_dict["@tokens"]
                    else [],
                    source_id=int(signal_dict["@source"]),
                )
            )

    rst = RST(nodes=nodes, relations=relations, signals=signals)

    for rst_dependent in list(rst.nodes.values()) + rst.signals:
        rst_dependent._rst = rst

    return rst


def rs3_to_document(arquivo: Path) -> RSTDocument:
    encoding = chardet.detect(arquivo.read_bytes())["encoding"]
    assert encoding is not None, "Não foi possível detectar a codificação do arquivo."
    file_name = os.path.basename(arquivo)
    rst_dict = rs3_to_dict(arquivo, encoding)
    rst = dict_to_rst(rst_dict)
    return RSTDocument(
        encoding=encoding,
        file_name=file_name,
        rst=rst,
    )
