"""
webbrowser-mcp: A Model Context Protocol (MCP) server for web browser automation.

This package provides an MCP server that exposes Julia Browser tools for web automation,
including opening websites, interacting with elements, form submission, and page navigation.
"""

__version__ = "1.0.0"
__author__ = "Harish Santhanalakshmi Ganesan"
__description__ = "MCP server for web browser automation using Julia Browser"

from webbrowser_mcp.server import create_server

__all__ = ["create_server"]
