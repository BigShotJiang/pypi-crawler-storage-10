"""
Setup configuration for webbrowser-mcp package
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="julia-browser-mcp",
    version="1.0.0",
    author="Harish Santhanalakshmi Ganesan",
    author_email="harish@example.com",
    description="MCP server for web browser automation using Julia Browser",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/harish/webbrowser-mcp",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "fastmcp>=2.0.0",
        "julia-browser>=1.0.0",
    ],
    entry_points={
        "console_scripts": [
            "webbrowser-mcp=webbrowser_mcp.server:main",
        ],
    },
)
