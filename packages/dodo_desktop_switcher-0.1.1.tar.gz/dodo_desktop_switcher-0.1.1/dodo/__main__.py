#!/usr/bin/env python
"""Allow running dodo as a module: python -m dodo"""

from dodo.dodo import main

if __name__ == '__main__':
    main()
