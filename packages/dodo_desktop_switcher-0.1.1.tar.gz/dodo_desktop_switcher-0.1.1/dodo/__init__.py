__version__ = '0.1.1'

from dodo.dodo import main as cli

__all__ = ['cli', '__version__']
