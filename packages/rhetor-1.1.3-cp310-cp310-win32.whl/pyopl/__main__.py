from .pyopl_ide_bootstrap import OPLIDE

if __name__ == "__main__":
    ide = OPLIDE()
    ide.mainloop()
