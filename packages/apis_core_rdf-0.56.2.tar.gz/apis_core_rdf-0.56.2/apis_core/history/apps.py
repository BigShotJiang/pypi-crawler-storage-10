from django.apps import AppConfig


class HistoryConfig(AppConfig):
    name = "apis_core.history"
