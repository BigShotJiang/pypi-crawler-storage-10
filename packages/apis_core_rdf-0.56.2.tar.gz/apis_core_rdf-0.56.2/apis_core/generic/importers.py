import json
import logging
import urllib
from functools import cache

from AcdhArcheAssets.uri_norm_rules import get_normalized_uri
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ImproperlyConfigured
from django.db.utils import IntegrityError

from apis_core.uris.models import Uri
from apis_core.utils.rdf import get_something_from_uri

logger = logging.getLogger(__name__)


class GenericModelImporter:
    """
    A generic importer class which provides methods for
    importing data from a URI and creating a model instance from it.

    By default, it fetches a resource and first tries to parse it using
    our RDF parser. If that fails, it tries to parse it using JSON and
    then extracts the fields whose keys match the model field names.
    Projects can inherit from this class and override the default
    methods or simply write their own from scratch.
    """

    model = None
    import_uri = None

    def __init__(self, uri, model):
        self.model = model
        self.import_uri = self.clean_uri(uri)

    @property
    def get_uri(self):
        return self.import_uri

    def clean_uri(self, uri):
        return get_normalized_uri(uri)

    @cache
    def request(self, uri):
        data = None
        # We first try to use the RDF parser
        if not data:
            try:
                data = get_something_from_uri(
                    uri,
                    [self.model],
                )
            except Exception as e:
                logger.debug(e)
        # If there is no data yet, try parsing JSON
        if not data:
            try:
                data = json.loads(urllib.request.urlopen(uri).read())
            except Exception as e:
                logger.debug(e)
        # Return the fetched data or an empty dict if there is none
        return data or {}

    def mangle_data(self, data):
        return data

    def get_data(self, drop_unknown_fields=True):
        """
        Fetch the data using the `request` method and
        mangle it using the `mangle_data` method.

        If the `drop_unknown_fields` argument is True,
        remove all fields from the data dict that do not
        have an equivalent field in the model.
        """
        data = self.request(self.import_uri)
        data = self.mangle_data(data)
        if drop_unknown_fields:
            # we are dropping all fields that are not part of the model
            modelfields = [field.name for field in self.model._meta.fields]
            data = {key: data[key] for key in data if key in modelfields}
        if not data:
            raise ImproperlyConfigured(
                f"Could not import {self.import_uri}. Data fetched was: {data}"
            )
        return data

    def import_into_instance(self, instance, fields="__all__"):
        data = self.get_data()
        if fields == "__all__":
            fields = data.keys()
        for field in fields:
            if hasattr(instance, field) and field in data.keys():
                setattr(instance, field, data[field][0])
        instance.save()

    def create_instance(self):
        logger.debug("Create instance from URI %s", self.import_uri)
        data = self.get_data(drop_unknown_fields=False)
        instance = None
        same_as = data.get("same_as", [])
        same_as = [get_normalized_uri(uri) for uri in same_as]
        if sa := Uri.objects.filter(uri__in=same_as):
            root_set = set([s.content_object for s in sa])
            if len(root_set) > 1:
                raise IntegrityError(
                    f"Multiple objects found for sameAs URIs {data['same_as']}. "
                    f"This indicates a data integrity problem as these URIs should be unique."
                )
            instance = sa.first().content_object
            logger.debug("Found existing instance %s", instance)
        if not instance:
            attributes = {}
            for field in self.model._meta.fields:
                if data.get(field.name, False):
                    attributes[field.name] = data[field.name][0]
            instance = self.model.objects.create(**attributes)
            logger.debug("Created instance %s from attributes %s", instance, attributes)
        content_type = ContentType.objects.get_for_model(instance)
        for uri in same_as:
            Uri.objects.get_or_create(
                uri=uri, content_type=content_type, object_id=instance.id
            )
        if "relations" in data:
            instance.create_relations_to_uris = data["relations"]
            instance.save()
        return instance
