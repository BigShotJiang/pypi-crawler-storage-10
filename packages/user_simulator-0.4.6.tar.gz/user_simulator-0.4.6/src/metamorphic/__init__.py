filtered_tests = []


def get_filtered_tests():
    return filtered_tests


def empty_filtered_tests():
    filtered_tests = []