"""Authorization Error for The Thinks Network client."""


# define Python user-defined exceptions
class TTNAuthError(Exception):
    "Raised when we get 4xx."
