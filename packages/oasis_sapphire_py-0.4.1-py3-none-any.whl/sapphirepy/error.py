
class SapphireError(Exception):
    pass
