from runtime.helpers.extensions import on_captcha_event
from runtime.helpers.extensions import wait_for_captcha_solve

__all__ = [
    "on_captcha_event",
    "wait_for_captcha_solve",
]
