"""
Test suite for claudelint
"""
