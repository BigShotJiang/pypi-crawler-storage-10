#!/usr/bin/env bash

# Shell file taken from Bash v5 source folder (tests/getopts1.sub)

aflag=
bflag=

while getopts ab: name
do
    case $name in
        a)	aflag=1 ;;
        b)	bflag=1
            bval=$OPTARG ;;
        ?)	echo Usage: $0 [-a] [-b value] args
            exit 2 ;;
    esac

done

if [ ! -z "$aflag" ] ; then echo -a specified ; fi
if [ ! -z "$bflag" ] ; then echo -b $bval specified ; fi

if [ "$OPTIND" -gt 1 ]
then
    shift $(( $OPTIND - 1 ))
fi

echo remaining args: "$*"

exit 0
