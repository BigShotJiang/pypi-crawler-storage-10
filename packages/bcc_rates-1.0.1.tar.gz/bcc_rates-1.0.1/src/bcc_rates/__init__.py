def main() -> None:
    print("Hello from bcc-rates!")
