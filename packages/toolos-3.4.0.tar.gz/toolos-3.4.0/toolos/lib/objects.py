decodeobject = """
construct(key)
    var self.__key__ = key
    var self.Name = "decodeobject"
    var self.FLAGS = []
    var self.PAIR = {}
    var self.FREEZE = False
    var self._locks = False
    var self.Constructor = {}
    var self.Global = False

method type_object()
    ret "token123-decodekeyobject@main<DecodeObjectConstructor>"

method Reload()
    var self.Constructor = self.GetConstructdata()
    ret True

method blockKey()
    var self._locks = True
    ret True

method unblockKey()
    var self._locks = False
    ret True

method Key()
    if self.Global
        ret self.__key__
    else
        if not self._locks
            ret self.__key__
        else
            ret None

method FreezeLock(toggle)
    if toggle eq None
        var self.FREEZE = not self.FREEZE
    else
        var self.FREEZE = toggle
    ret self.FREEZE

method setName(name)
    var self.Name = name
    ret True

method forceGlobalKey()
    var self.Global = True
    ret True

method addFlag(flag)
    var flag_dict = {"flag": flag}
    ret True

method Pair(restrictions)
    ret self.Constructor

method GetConstructdata()
    var data = {"flags": self.FLAGS, "pair": self.PAIR, "freeze": self.FREEZE}
    ret data

method _destroyObject()
    var self.__key__ = None
    ret True
"""