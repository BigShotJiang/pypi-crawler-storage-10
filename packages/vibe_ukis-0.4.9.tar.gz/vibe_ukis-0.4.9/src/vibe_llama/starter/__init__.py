from typing import Optional
from rich.console import Console

from .terminal import run_terminal_interface
from .utils import write_file, get_instructions
from .data import agent_rules, services
from .mcp import mcp_server
from .subagents import create_subagents_from_services
from .skills import create_claude_skills


async def starter(
    agent: Optional[str] = None,
    service: Optional[str] = None,
    overwrite_files: Optional[bool] = None,
    verbose: Optional[bool] = None,
) -> bool:
    cs = Console(stderr=True)
    if agent is None and service is None:
        term_res = await run_terminal_interface()
        if not term_res:
            cs.log(
                "[bold red]ERROR[/]\tYou need to choose at least one agent and one service before continuining. Exiting..."
            )
            return False
        agent_files, service_urls, overwrite_files = term_res
        if agent_files is None or service_urls is None:
            cs.log(
                "[bold red]ERROR[/]\tYou need to choose at least one agent and one service before continuining. Exiting..."
            )
            return False
    elif agent is not None and service is not None:
        agent_files = [agent_rules[agent]]
        service_urls = [services[service]]
    else:
        cs.log(
            "[bold red]ERROR[/]\tEither you pass the options from command line or you choose them from terminal interface, you can't mix the two."
        )
        return False
    instructions = ""
    services_content = {}  # Store service name -> content mapping
    
    for serv_url in service_urls:
        if verbose:
            cs.log(f"[bold cyan]FETCHING[/]\t{serv_url}")
        instr = await get_instructions(instructions_url=serv_url)
        if instr is None:
            cs.log(
                f"[bold yellow]WARNING[/]\tIt was not possible to retrieve instructions for {serv_url}, please try again later"
            )
            continue
        instructions += instr + "\n\n---\n\n"
        
        # Store content by service name for subagent generation
        for service_name, service_path in services.items():
            if service_path == serv_url:
                services_content[service_name] = instr
                break
        
        if verbose:
            cs.log("[bold green]FETCHED✅[/]")
    
    if not instructions:
        cs.log(
            "[bold red]ERROR[/]\tIt was not possible to retrieve instructions at this time, please try again later"
        )
        return False
    
    for fl in agent_files:
        # Check if this is the subagents directory
        if fl == ".claude/agents/":
            if verbose:
                cs.log(f"[bold cyan]CREATING SUBAGENTS[/]\t{fl}")
            created = create_subagents_from_services(
                agents_dir=fl,
                services_content=services_content,
                overwrite=overwrite_files or False,
                verbose=verbose,
            )
            if created:
                cs.log(f"[bold green]CREATED {len(created)} SUBAGENT(S)✅[/]")
            else:
                cs.log("[bold yellow]No new subagents created (files may already exist)[/]")
        # Check if this is the skills directory
        elif fl == ".claude/skills/":
            if verbose:
                cs.log(f"[bold cyan]CREATING CLAUDE SKILLS[/]\t{fl}")
            created = create_claude_skills(
                base_dir=".claude",
                services_content=services_content,
                overwrite=overwrite_files or False,
                verbose=verbose,
            )
            total_created = sum(len(files) for files in created.values())
            if total_created > 0:
                cs.log(f"[bold green]CREATED CLAUDE SKILLS STRUCTURE WITH {total_created} FILE(S)✅[/]")
            else:
                cs.log("[bold yellow]No new skills created (files may already exist)[/]")
        else:
            # Regular file writing for non-subagent agents
            if verbose:
                cs.log(f"[bold cyan]WRITING[/]\t{fl}")
            write_file(fl, instructions, overwrite_files or False, ", ".join(service_urls))
            if verbose:
                cs.log("[bold green]WRITTEN✅[/]")
    cs.log(
        "[bold green]SUCCESS✅[/]\tAll the instructions files have been written, happy vibe-coding!"
    )
    return ".vibe-llama/rules/AGENTS.md" in agent_files


__all__ = ["starter", "agent_rules", "services", "mcp_server", "create_claude_skills"]
