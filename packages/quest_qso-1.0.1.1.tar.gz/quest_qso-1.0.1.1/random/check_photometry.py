# load in the generated photometry
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from corner import corner
from fg_utils.utils import euclid_selection_utils as esu

# =========================================================================== #
# =========================================================================== #
# =========================================================================== #

READ_IN_SPECTRA = False

# =========================================================================== #
# =========================================================================== #
# =========================================================================== #

phot_cat_fname = (
    Path.home()
    / "data"
    / "ml_qso_model"
    / "generated_photometry"
    / "20251002"
    / "GeneratedPhot-w_pert-DES-z_Euclid-HJYvis_HSC-z-6to9_M1450-m28tom21_20251002_114246.hdf5"
)

phot_cat = pd.read_hdf(phot_cat_fname)

# Read in the photometry

# Optionally read in the spectra, this is a hefty file
if READ_IN_SPECTRA:
    spec_cat_fname = list(phot_cat_fname.parts)

    # Maybe a bit too involved but at least gets the job done and automatically
    spec_fname = (
        Path(*spec_cat_fname[: phot_cat_fname.parts.index("generated_photometry")])
        / "generated_spectra"
        / f"VAE_Spectra_with_IGM_{phot_cat_fname.stem.split('_')[-2]}_{phot_cat_fname.stem.split('_')[-1]}.npy"
    )

    spec_cat = np.load(spec_cat_fname)


# Objects with bonkers photometry are more easily findable by checking the flux ratios

# check the northern catalogue first
esu.rename_features_north(phot_cat)
esu.make_features(phot_cat)


# make a corner plot of the flux ratios
features = ["IoZ", "IoY", "IoJ", "IoH", "YoZ", "YoJ", "YoH", "JoZ", "JoH", "HoZ"]

corner(
    phot_cat[features],
    labels=features,
    show_titles=True,
    title_fmt=".2f",
    title_kwargs={"fontsize": 12},
)

# there are inf, see if you can find them
for feat in features:
    print(f"{feat} min: {phot_cat[feat].min()} max: {phot_cat[feat].max()}")

plt.hist(phot_cat["IoZ"], bins=100)