# `ModelDiff` class

Here's the reference information for the `ModelDiff` class, with all its
parameters, attributes and methods.

You can import the `ModelDiff` class directly from `pyrmute`:

```python
from pyrmute import ModelDiff
```

::: pyrmute.ModelDiff
