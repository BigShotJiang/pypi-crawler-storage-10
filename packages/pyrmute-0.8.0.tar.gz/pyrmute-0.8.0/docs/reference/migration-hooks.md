# Migration Hooks

Here's the reference information for the included migration hooks classes,
with all their parameters, attributes and methods.

You can import these classes directly from `pyrmute`:

```python
from pyrmute import MigrationHook, MetricsHook
```

::: pyrmute.MigrationHook

::: pyrmute.MetricsHook
