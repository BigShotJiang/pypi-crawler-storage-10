# `SchemaConfig` class

Here's the reference information for the `SchemaConfig` class, with all its
parameters, attributes and methods.

You can import the `SchemaConfig` class directly from `pyrmute`:

```python
from pyrmute import SchemaConfig
```

::: pyrmute.SchemaConfig
