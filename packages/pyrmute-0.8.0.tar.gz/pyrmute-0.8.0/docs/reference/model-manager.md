# `ModelManager` class

Here's the reference information for the `ModelManager` class, with all its
parameters, attributes and methods.

This is the main class you interact with in pyrmute.

You can import the `ModelManager` class directly from `pyrmute`:

```python
from pyrmute import ModelManager
```

::: pyrmute.ModelManager

