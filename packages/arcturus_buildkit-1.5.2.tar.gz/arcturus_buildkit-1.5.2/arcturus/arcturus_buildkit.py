import re
import math
import random
from collections import defaultdict
from . import data_arcturus

class arcturusNLP:
    def __init__(self):
        self.LEMMATIZER = data_arcturus.LEMMATIZER

    def tokenize(self, text):
        text = text.lower()
        pattern = r'\w+|[^\w\s]'
        tokens = re.findall(pattern, text)
        return [t for t in tokens]

    def lemmatizer(self, token):
        for lemma, forms in self.LEMMATIZER.items():
            if token in forms:
                return {token: (token, lemma)}
        return {token: (token, token)}

    def sentence_to_vector(self, sentence, idf=None):
        tokens = self.tokenize(sentence)
        lemmas = [self.lemmatizer(t).get(t, (t, t))[1] for t in tokens]
        vec = {}
        for t in lemmas:
            vec[t] = vec.get(t, 0) + 1

        if idf:
            for t in vec:
                vec[t] *= idf.get(t, 1.0)
        return vec

    def cosine_similarity(self, vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        dot = sum(vec1[t] * vec2[t] for t in intersection)
        mag1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
        mag2 = math.sqrt(sum(v ** 2 for v in vec2.values()))
        if mag1 == 0 or mag2 == 0:
            return 0
        return dot / (mag1 * mag2)

class arcturusSUPERVISED_INTENT:
    def __init__(self, nlp_pipeline, intent_responses):
        self.nlp = nlp_pipeline
        self.intent_responses = intent_responses
        self.inputs = []
        self.intents = []
        self.vectors = []
        self.idf = {}

    def compute_idf(self, dataset):
        doc_count = {}
        total_docs = len(dataset)
        for sent, _ in dataset:
            tokens = set(self.nlp.tokenize(sent))
            for t in tokens:
                doc_count[t] = doc_count.get(t, 0) + 1
        for t, c in doc_count.items():
            self.idf[t] = math.log((1 + total_docs) / (1 + c)) + 1

    def train(self, data):
        self.inputs = [inp for inp, intent in data]
        self.intents = [intent for inp, intent in data]
        self.compute_idf(data)
        self.vectors = [self.nlp.sentence_to_vector(inp, self.idf) for inp in self.inputs]

    def predict_intent(self, sentence, show_scores=False):
        vec = self.nlp.sentence_to_vector(sentence, self.idf)
        scores = []
        for i, v in enumerate(self.vectors):
            sim = self.nlp.cosine_similarity(vec, v)
            scores.append((self.intents[i], sim))
        scores.sort(key=lambda x: x[1], reverse=True)
        if show_scores:
            print("Intent similarity scores:", scores)
        return scores[0][0] if scores else "unknown"

    def get_response(self, sentence):
        intent = self.predict_intent(sentence)
        responses = self.intent_responses.get(intent, ["I don't understand."])
        return random.choice(responses)

class arcturusSEARCH_ENGINE:
    def __init__(self, nlp_pipeline, search_data):
        self.nlp = nlp_pipeline
        self.search_data = search_data or []
        self.idf = self.compute_idf(self.search_data)

        # Precompute TF-IDF vectors for all documents
        self.vectors = [
            self.nlp.sentence_to_vector(doc, self.idf)
            for doc in self.search_data  
        ]

    def compute_idf(self, documents):
        doc_count = {}
        total_docs = len(documents)
        for doc in documents:
            tokens = set(self.nlp.tokenize(doc))
            for t in tokens:
                doc_count[t] = doc_count.get(t, 0) + 1
        idf = {t: math.log((1 + total_docs) / (1 + c)) + 1 for t, c in doc_count.items()}
        return idf

    def search_response(self, sentence, show_scores=False):
        query_vec = self.nlp.sentence_to_vector(sentence, self.idf)

        best_doc = None
        best_score = 0
        scores = []

        for doc, vec in zip(self.search_data, self.vectors):
            score = self.nlp.cosine_similarity(query_vec, vec)
            scores.append((doc, score))
            if score > best_score:
                best_score = score
                best_doc = doc

        if show_scores:
            print("🔍 Similarity Scores:")
            for doc, s in sorted(scores, key=lambda x: x[1], reverse=True):
                print(f"  {doc} -> {s:.3f}")

        return best_doc


class NGramModel:
    def __init__(self, n=2):
        self.n = n
        self.ngrams = defaultdict(list)

    def train(self, corpus_tokens):
        if len(corpus_tokens) < self.n:
            return  # Not enough tokens to form n-grams

        for i in range(len(corpus_tokens) - self.n):
            key = tuple(corpus_tokens[i:i+self.n-1])
            next_word = corpus_tokens[i+self.n-1]
            self.ngrams[key].append(next_word)

    def predict_next(self, current_tokens):
        key = tuple(current_tokens[-(self.n-1):])
        if key in self.ngrams:
            return random.choice(self.ngrams[key])
        return None

    def generate_text(self, start_tokens, length=10):
        output = list(start_tokens)
        for _ in range(length):
            next_word = self.predict_next(output)
            if next_word is None:
                break
            output.append(next_word)
        return output

import random

class arcturusContextAI:
    def __init__(self, nlp, context_data):
        self.nlp = nlp
        self.context_data = context_data

        # Precompute vectors for each context tuple
        self.context_vectors = {
            ctx: [self.nlp.sentence_to_vector(inp) for inp in ctx]
            for ctx in context_data
        }

    def getInput(self, current_context_tuple):
        best_score = 0
        best_context = None

        # Compare input tuple to stored contexts
        for ctx, vec_list in self.context_vectors.items():
            # Compute average cosine similarity over tuple elements
            score = 0
            for user_vec, stored_vec in zip(current_context_tuple, vec_list):
                # Make sure user_vec is vectorized
                user_vec_vec = self.nlp.sentence_to_vector(user_vec)
                score += self.nlp.cosine_similarity(user_vec_vec, stored_vec)
            score /= len(vec_list)

            if score > best_score:
                best_score = score
                best_context = ctx

        if best_context and best_score > 0:  # threshold can be tuned
            return random.choice(self.context_data[best_context])
        else:
            return "I don't understand."


