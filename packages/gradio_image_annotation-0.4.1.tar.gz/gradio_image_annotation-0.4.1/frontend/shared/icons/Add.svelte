<svg
	width="100%"
	height="100%"
	viewBox="0 0 24 24"
	version="1.1"
	xmlns="http://www.w3.org/2000/svg"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	xml:space="preserve"
	stroke="currentColor"
	style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"
>
	<line x1="4" y1="12" x2="20" y2="12" style="fill:none;stroke-width:2px;"/>
	<line x1="12" y1="4" x2="12" y2="20" style="fill:none;stroke-width:2px;"/>
</svg>
