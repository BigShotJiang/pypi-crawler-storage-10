
from .image_annotator import image_annotator

__all__ = ['image_annotator']
