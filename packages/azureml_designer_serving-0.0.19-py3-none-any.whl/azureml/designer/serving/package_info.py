VERSION = '0.0.19'
PACKAGE_NAME = 'azureml-designer-serving'
DESCRIPTION = 'Provide functionalities to invoke Azure Machine Learning designer ' \
              'built-in modules in deployment service.'
