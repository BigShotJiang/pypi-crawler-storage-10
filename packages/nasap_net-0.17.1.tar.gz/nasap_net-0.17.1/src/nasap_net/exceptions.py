class IDNotSetError(Exception):
    pass
