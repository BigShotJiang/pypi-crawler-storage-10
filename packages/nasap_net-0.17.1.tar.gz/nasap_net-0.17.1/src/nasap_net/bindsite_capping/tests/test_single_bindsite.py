import pytest

from nasap_net import cap_single_bindsite


def test_cap_single_bindsite():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
