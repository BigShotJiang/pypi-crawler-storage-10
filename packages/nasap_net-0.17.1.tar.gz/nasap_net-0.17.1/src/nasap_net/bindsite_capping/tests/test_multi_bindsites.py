import pytest

from nasap_net import cap_bindsites


def test_cap_bindsites():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
