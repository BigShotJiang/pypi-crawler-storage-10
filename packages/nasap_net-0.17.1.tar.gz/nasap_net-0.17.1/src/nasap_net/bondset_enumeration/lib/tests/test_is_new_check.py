import pytest

from nasap_net.bondset_enumeration import is_new_under_symmetry


def test_is_new_under_symmetry():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
