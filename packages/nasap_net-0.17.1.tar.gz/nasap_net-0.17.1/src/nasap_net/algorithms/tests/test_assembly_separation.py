import pytest

from nasap_net import separate_product_if_possible


def test_separate_product_if_possible():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
