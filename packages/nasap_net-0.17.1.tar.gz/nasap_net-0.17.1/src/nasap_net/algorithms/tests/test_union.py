import pytest

from nasap_net import union_assemblies


def test_union_assemblies():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
