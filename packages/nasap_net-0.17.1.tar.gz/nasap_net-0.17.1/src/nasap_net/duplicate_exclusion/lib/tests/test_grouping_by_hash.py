import pytest

from nasap_net.duplicate_exclusion import group_assemblies_by_hash


def test_group_assemblies_by_hash():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
