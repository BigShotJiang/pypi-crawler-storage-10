import pytest

from nasap_net.duplicate_exclusion import is_new


def test_is_new():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
