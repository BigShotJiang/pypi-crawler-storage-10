import pytest

from nasap_net.duplicate_exclusion import group_assemblies_by_isomorphism


def test_group_duplicates_by_isomorphism():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
