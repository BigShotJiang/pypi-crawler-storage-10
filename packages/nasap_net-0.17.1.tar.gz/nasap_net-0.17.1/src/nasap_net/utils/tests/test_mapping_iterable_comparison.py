import pytest

from nasap_net.utils import compare_mapping_iterables


def test_compare_mapping_iterables():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
