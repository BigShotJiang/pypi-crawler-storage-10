import pytest

from nasap_net.utils import update_nested_dict


def test_update_nested_dict():
    pass


if __name__ == '__main__':
    pytest.main(['-vv', __file__])
