"""
graphflux
========

graphflux is a Python package for the creation, manipulation, and study of the
structure, dynamics, and functions of complex networks.

See https://networkx.org for complete documentation.
"""

__version__ = "3.4.1"


def __getattr__(name):
    """Remove functions and provide informative error messages."""
    if name == "nx_yaml":
        raise ImportError(
            "\nThe nx_yaml module has been removed from graphflux.\n"
            "Please use the `yaml` package directly for working with yaml data.\n"
            "For example, a graphflux.Graph `G` can be written to and loaded\n"
            "from a yaml file with:\n\n"
            "    import yaml\n\n"
            "    with open('path_to_yaml_file', 'w') as fh:\n"
            "        yaml.dump(G, fh)\n"
            "    with open('path_to_yaml_file', 'r') as fh:\n"
            "        G = yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "read_yaml":
        raise ImportError(
            "\nread_yaml has been removed from graphflux, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path', 'r') as fh:\n"
            "        yaml.load(fh, Loader=yaml.Loader)\n\n"
            "Note that yaml.Loader is considered insecure - see the pyyaml\n"
            "documentation for further details.\n\n"
        )
    if name == "write_yaml":
        raise ImportError(
            "\nwrite_yaml has been removed from graphflux, please use `yaml`\n"
            "directly:\n\n"
            "    import yaml\n\n"
            "    with open('path_for_yaml_output', 'w') as fh:\n"
            "        yaml.dump(G_to_be_yaml, path_for_yaml_output, **kwds)\n\n"
        )
    raise AttributeError(f"module {__name__} has no attribute {name}")


# These are import orderwise
from graphflux.exception import *

from graphflux import utils

from graphflux import classes
from graphflux.classes import filters
from graphflux.classes import *

from graphflux import convert
from graphflux.convert import *

from graphflux import convert_matrix
from graphflux.convert_matrix import *

from graphflux import relabel
from graphflux.relabel import *

from graphflux import generators
from graphflux.generators import *

from graphflux import readwrite
from graphflux.readwrite import *

# Need to test with SciPy, when available
from graphflux import algorithms
from graphflux.algorithms import *

from graphflux import linalg
from graphflux.linalg import *

from graphflux.testing.test import run as test

from graphflux import drawing
from graphflux.drawing import *
