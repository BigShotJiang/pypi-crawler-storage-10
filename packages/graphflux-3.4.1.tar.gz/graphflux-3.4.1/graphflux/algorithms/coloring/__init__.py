from graphflux.algorithms.coloring.greedy_coloring import *
from graphflux.algorithms.coloring.equitable_coloring import equitable_color

__all__ = ["greedy_color", "equitable_color"]
