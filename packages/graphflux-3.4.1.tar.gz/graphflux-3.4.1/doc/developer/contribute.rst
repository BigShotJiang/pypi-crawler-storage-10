.. include:: ../../CONTRIBUTING.rst
