"""
cyborgdb-lite has been deprecated and merged into cyborgdb-core.
This package now simply re-exports cyborgdb-core for backward compatibility.

Please update your imports to use 'cyborgdb_core' directly.
"""

import warnings

warnings.warn(
    "cyborgdb-lite is deprecated and has been merged into cyborgdb-core. "
    "Please update your code to 'import cyborgdb_core'. "
    "See https://pypi.org/project/cyborgdb-core/ for more information.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from cyborgdb_core
try:
    from cyborgdb_core import *
    from cyborgdb_core import __version__
except ImportError as e:
    raise ImportError(
        "cyborgdb-core is not installed. "
        "Please install it with: pip install cyborgdb-core"
    ) from e
