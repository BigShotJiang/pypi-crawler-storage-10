# ⚠️ DEPRECATED: CyborgDB Lite

**This package has been deprecated and merged into [`cyborgdb-core`](https://pypi.org/project/cyborgdb-core/).**

## Migration Guide

Please update your dependencies:

```bash
# Old installation
pip uninstall cyborgdb-lite
pip install cyborgdb-core
```

And update your imports:

```python
# Old import
import cyborgdb_lite as cyborgdb

# New import
import cyborgdb_core as cyborgdb
```

All functionality from `cyborgdb-lite` is available in `cyborgdb-core` with the same API.

## Why the Change?

We've consolidated our Python packages to simplify distribution and maintenance. The `cyborgdb-core` package now includes all functionality previously in `cyborgdb-lite`, along with additional features and improvements.

## Automatic Migration

For backward compatibility, installing `cyborgdb-lite` version 0.13.0+ will automatically install `cyborgdb-core` as a dependency. However, we strongly recommend updating your code to import from `cyborgdb-core` directly.

## Support

For questions or issues:

- [Documentation](https://docs.cyborg.co)
- [Contact Us](https://www.cyborg.co/contact)