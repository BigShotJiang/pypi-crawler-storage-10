"""
Classes which represent distinct entities within MarkLogic.
"""
