from django.contrib import admin

from .models import WhatsAppBusinessAccount, WabaAccountUpdate, WabaGenericEvent


@admin.register(WhatsAppBusinessAccount)
class WhatsAppBusinessAccountAdmin(admin.ModelAdmin):
    list_display = ("waba_id", "owner_business_id", "name", "created_at")
    search_fields = ("waba_id", "owner_business_id", "name")


@admin.register(WabaAccountUpdate)
class WabaAccountUpdateAdmin(admin.ModelAdmin):
    list_display = (
        "get_subtype",
        "get_waba_id",
        "phone_number",
        "event_name",
        "get_event_timestamp",
    )
    list_filter = ("event_name",)
    search_fields = ("phone_number", "event__entry_id")

    def get_subtype(self, obj):
        return obj.event.subtype

    def get_waba_id(self, obj):
        return obj.event.entry_id

    def get_event_timestamp(self, obj):
        return obj.event.event_timestamp

    get_subtype.short_description = "Subtype"
    get_waba_id.short_description = "WABA ID"
    get_event_timestamp.short_description = "Timestamp"


@admin.register(WabaGenericEvent)
class WabaGenericEventAdmin(admin.ModelAdmin):
    list_display = ("get_subtype", "get_waba_id", "get_event_timestamp")
    search_fields = ("event__entry_id",)

    def get_subtype(self, obj):
        return obj.event.subtype

    def get_waba_id(self, obj):
        return obj.event.entry_id

    def get_event_timestamp(self, obj):
        return obj.event.event_timestamp

    get_subtype.short_description = "Subtype"
    get_waba_id.short_description = "WABA ID"
    get_event_timestamp.short_description = "Timestamp"


