import datetime
from typing import Any, Dict

from django.utils.timezone import timezone

from .models import WebhookEvent, WhatsAppBusinessAccount, WabaAccountUpdate, WabaGenericEvent


def _to_dt_from_seconds(seconds: int | None):
    if seconds is None:
        return None
    return datetime.datetime.fromtimestamp(int(seconds), tz=datetime.timezone.utc)


def handle_waba_entry(entry: Dict[str, Any], object_kind: str) -> None:
    waba_id = entry.get("id")
    entry_time = entry.get("time")
    ts = _to_dt_from_seconds(entry_time)

    if not waba_id:
        return

    waba, _ = WhatsAppBusinessAccount.objects.get_or_create(
        waba_id=waba_id
    )

    for change in entry.get("changes", []) or []:
        field = change.get("field")
        value = change.get("value") or {}

        event, _ = WebhookEvent.objects.update_or_create(
            event_kind=WebhookEvent.KIND_WABA,
            subtype=field,
            entry_id=waba_id,
            waba=waba,
            defaults={
                "object": object_kind,
                "field": field,
                "event_timestamp": ts,
                "raw_payload": value,
            },
        )

        if field == "account_update":
            WabaAccountUpdate.objects.update_or_create(
                event=event,
                defaults={
                    "phone_number": value.get("phone_number"),
                    "event_name": value.get("event"),
                    "business_verification_status": value.get("business_verification_status"),
                    "ban_info": value.get("ban_info"),
                    "violation_info": value.get("violation_info"),
                    "lock_info": value.get("lock_info"),
                    "restriction_info": value.get("restriction_info"),
                    "partner_client_certification_info": value.get("partner_client_certification_info"),
                    "waba_info": value.get("waba_info"),
                    "auth_international_rate_eligibility": value.get("auth_international_rate_eligibility"),
                    "volume_tier_info": value.get("volume_tier_info"),
                },
            )
        else:
            WabaGenericEvent.objects.update_or_create(
                event=event, defaults={"value": value}
            )


