from django.db import models

from .core import WebhookEvent


class WhatsAppBusinessAccount(models.Model):
    waba_id = models.CharField(max_length=64, unique=True, db_index=True)
    owner_business_id = models.CharField(max_length=64, null=True, blank=True)
    name = models.CharField(max_length=255, null=True, blank=True)
    meta = models.JSONField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = "django_whatsapp_api_wrapper"
        verbose_name = "WABA"
        verbose_name_plural = "WABAs"

    def __str__(self) -> str:
        return self.waba_id


class WabaAccountUpdate(models.Model):
    event = models.OneToOneField(
        WebhookEvent, on_delete=models.CASCADE, related_name="waba_account_update"
    )
    phone_number = models.CharField(max_length=32, null=True, blank=True, db_index=True)
    event_name = models.CharField(max_length=64, null=True, blank=True, db_index=True)
    business_verification_status = models.CharField(max_length=64, null=True, blank=True)

    ban_info = models.JSONField(null=True, blank=True)
    violation_info = models.JSONField(null=True, blank=True)
    lock_info = models.JSONField(null=True, blank=True)
    restriction_info = models.JSONField(null=True, blank=True)
    partner_client_certification_info = models.JSONField(null=True, blank=True)
    waba_info = models.JSONField(null=True, blank=True)
    auth_international_rate_eligibility = models.JSONField(null=True, blank=True)
    volume_tier_info = models.JSONField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = "django_whatsapp_api_wrapper"
        verbose_name = "WABA Account Update"
        verbose_name_plural = "WABA Account Updates"


class WabaGenericEvent(models.Model):
    event = models.OneToOneField(
        WebhookEvent, on_delete=models.CASCADE, related_name="waba_generic"
    )
    value = models.JSONField()

    class Meta:
        app_label = "django_whatsapp_api_wrapper"
        verbose_name = "WABA Generic Event"
        verbose_name_plural = "WABA Generic Events"


