from .. import license

license.check("cache")
