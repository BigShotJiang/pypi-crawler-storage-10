# Stable

Version of solara-enterprise is locked to solara, and released in CI.

# Test a release

e.g. to manually make a release with a new solara-enterprise


```
$ cd packages/solara-enterprise
$ bump2version --verbose major
$ hatch build
```
