import numpy as np
from skrf import Network

from .core import Tab


def moving_average(data: Network, window_size=5):
    f = data.f[int(window_size/2):-int(window_size/2)]
    S = np.zeros((f.shape[0], 2, 2), dtype=complex)
    S[:, 0, 0] = np.convolve(data.s[:, 0, 0], np.ones(window_size)/window_size, mode='valid')
    S[:, 0, 1] = np.convolve(data.s[:, 0, 1], np.ones(window_size)/window_size, mode='valid')
    S[:, 1, 0] = np.convolve(data.s[:, 1, 0], np.ones(window_size)/window_size, mode='valid')
    S[:, 1, 1] = np.convolve(data.s[:, 1, 1], np.ones(window_size)/window_size, mode='valid')
    return Network(s=S, frequency=f)


class Tab3(Tab):
    def __init__(self, gui_elements: tuple = (), **kargs):
        super().__init__(gui_elements, **kargs)
        self.ntw = None

    def _init(self):
        pass

