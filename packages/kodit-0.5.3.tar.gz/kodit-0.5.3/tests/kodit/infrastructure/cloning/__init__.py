"""Tests for cloning infrastructure."""
