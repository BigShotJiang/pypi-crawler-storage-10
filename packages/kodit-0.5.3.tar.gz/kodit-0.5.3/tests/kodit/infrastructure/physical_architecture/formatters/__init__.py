"""Test package for narrative formatters."""
