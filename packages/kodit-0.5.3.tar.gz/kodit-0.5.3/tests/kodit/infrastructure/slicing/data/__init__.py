"""Test data for slicer functionality."""
