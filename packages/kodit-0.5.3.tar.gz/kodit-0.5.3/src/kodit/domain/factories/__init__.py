"""Domain factories package."""
