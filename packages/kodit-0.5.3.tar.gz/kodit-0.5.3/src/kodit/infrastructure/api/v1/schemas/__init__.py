"""JSON:API schemas for the REST API."""
