"""Formatters for converting architecture observations to LLM-optimized text."""
