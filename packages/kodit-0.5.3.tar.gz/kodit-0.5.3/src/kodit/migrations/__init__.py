"""Database configuration for kodit."""
