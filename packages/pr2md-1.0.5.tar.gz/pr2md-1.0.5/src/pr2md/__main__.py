"""Entry point for running pr2md as a module."""

from pr2md.cli import main

if __name__ == "__main__":
    main()
