import pyperformance.cli

pyperformance.cli.main()
