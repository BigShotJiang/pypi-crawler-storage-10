Copy of django/core/*.py files of Django 1.1.4.
