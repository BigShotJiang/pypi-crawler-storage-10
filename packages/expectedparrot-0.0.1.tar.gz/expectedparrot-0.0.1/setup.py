from setuptools import setup, find_packages

setup(
    name="expectedparrot",
    version="0.0.1",
    description="Reserved placeholder package for expectedparrot.",
    author="Your Name",
    packages=find_packages(),
    python_requires=">=3.7",
)
