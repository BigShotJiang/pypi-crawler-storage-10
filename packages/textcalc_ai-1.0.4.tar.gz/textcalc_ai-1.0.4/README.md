# 🧮 Text2Math

Convert natural language math statements into actual calculations!  

This Python library interprets statements like:

- "add 68 and 256"  
- "what is 20 divided by 4"  
- "multiply 12 with 5"  

and returns the correct mathematical result.

---

## 🚀 Installation

You can install the library via PyPI:

```bash
pip install text2math
