import re

def calculate(statement):
    statement = statement.lower().strip()
    statement = re.sub(r'[^\w\s]', '', statement)
    
    operators = {
        "add": "+", "plus": "+", "sum": "+",
        "subtract": "-", "minus": "-", "difference": "-",
        "multiply": "*", "times": "*", "product": "*",
        "divide": "/", "divided": "/", "quotient": "/"
    }
    
    for word, symbol in operators.items():
        statement = statement.replace(word, symbol)
    
    numbers = re.findall(r'\d+', statement)
    operator = re.findall(r'[\+\-\*/]', statement)
    
    if len(numbers) >= 2 and operator:
        num1, num2 = int(numbers[0]), int(numbers[1])
        op = operator[0]
        try:
            result = eval(f"{num1}{op}{num2}")
            return result
        except Exception:
            raise ValueError("Invalid mathematical operation.")
    else:
        raise ValueError("Could not understand the mathematical operation.")
