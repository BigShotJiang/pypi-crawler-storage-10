from setuptools import setup, find_packages

setup(
    name="textcalc-ai",                   
    version="1.0.4",                    
    author="Pravanjan Roy",
    author_email="deadpoolroy2006@gmail.com",
    description="A simple text-to-math converter that interprets natural language math statements.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/kingmon6996/",
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
