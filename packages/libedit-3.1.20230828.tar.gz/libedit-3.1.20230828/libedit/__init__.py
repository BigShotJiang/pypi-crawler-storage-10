"""
libedit - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from libedit!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "libedit",
        "version": "3.1.20230828",
        "description": "A useful Python package"
    }

# Package version
__version__ = "3.1.20230828"
