# Mark2TG

> Robust Markdown → Telegram MarkdownV2 converter.  
> Safe escaping, optional 4096-split, readable table rendering.

[![PyPI](https://img.shields.io/pypi/v/mark2tg.svg)](https://pypi.org/project/mark2tg/)
[![Python](https://img.shields.io/pypi/pyversions/mark2tg.svg)](https://pypi.org/project/mark2tg/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![CI](https://github.com/livlev/Mark2TG/actions/workflows/ci.yml/badge.svg)](https://github.com/livlev/Mark2TG/actions/workflows/ci.yml)

---

## 🔍 Overview

`Mark2TG` converts standard **Markdown** into **Telegram MarkdownV2**, preserving formatting and escaping symbols that Telegram treats as control characters.  

It aims to be minimal, predictable, and compatible with official Telegram API limits.

---

## ✨ Features

- Correct escaping for all Telegram MarkdownV2 special characters  
- Optional message splitting at 4096 characters  
- Safe handling of links, code, and inline entities  
- Table rendering using monospaced text  
- CLI tool (`mark2tg`) for terminal use  
- Works with any bot or API wrapper (e.g. `aiogram`, `python-telegram-bot`)

---

## ⚙️ Installation

```bash
pip install mark2tg