# setup.py
from pathlib import Path
from setuptools import setup, find_packages

README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")

setup(
    name="mark2tg",
    version="1.0.2",  # синхронизируй с релизом
    description="Robust Markdown → Telegram MarkdownV2 converter",
    long_description=README,
    long_description_content_type="text/markdown",
    author="Leonid Ivlev",
    author_email="leonid.a.ivelv@gmail.com",
    url="https://github.com/livlev/Mark2TG",
    project_urls={
        "Homepage": "https://github.com/livlev/Mark2TG",
        "Repository": "https://github.com/livlev/Mark2TG",
        "Issues": "https://github.com/livlev/Mark2TG/issues",
        "Changelog": "https://github.com/livlev/Mark2TG/releases",
    },
    license="MIT",
    packages=find_packages(exclude=("tests", "examples")),
    include_package_data=True,
    python_requires=">=3.9",
    install_requires=[
    ],
    extras_require={
        "test": ["pytest>=7.0", "hypothesis>=6.0"],
    },
    entry_points={
        "console_scripts": [
            "mark2tg=mark2tg.cli:main",
        ],
    },
    keywords=["telegram", "markdown", "markdownv2", "bot", "converter"],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3",
        "Topic :: Text Processing :: Markup",
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
    ],
)
