import sys
import threading
import inspect
import time
from threading import Thread
import os

import builtins
import threading



# Global lock for thread-safe printing
_print_lock = threading.Lock()

def safe_print(s, end='\r', max_len=0):
    """Thread-safe printing for inline updates"""
    with _print_lock:
        print(s.ljust(max_len), end=end, flush=True)
        
class LiveStack:
    def __init__(self, interval=1, max_depth=5, min_display_time=1):
        """
        interval: how often to update the display (seconds)
        max_depth: max number of functions to show
        min_display_time: minimum time a stack must stay before updating (reduces flicker)
        """
        self.interval = interval
        self.max_depth = max_depth
        self.min_display_time = min_display_time
        self._running = False
        self._last_stack_str = ""
        self._max_len = 0
        self.project_root = os.getcwd()  # optional: filter by project files

    def _get_main_stack(self):
        main_thread = threading.main_thread()
        frame = sys._current_frames().get(main_thread.ident)
        stack = []
        while frame and len(stack) < self.max_depth:
            name = frame.f_code.co_name
            filename = frame.f_code.co_filename
            # Skip stdlib and site-packages
            if filename.startswith(sys.prefix) or "threading.py" in filename:
                frame = frame.f_back
                continue
            stack.append(name)
            frame = frame.f_back
        stack = list(reversed(stack))
        # Replace <module> with main
        stack = ["main" if s == "<module>" else s for s in stack]
        return stack

    def _print_stack(self, stack_list):
        stack_str = " > ".join(stack_list)
        # Only update if changed and held longer than min_display_time
        if stack_str != self._last_stack_str:
            safe_print(stack_str, end='\r', max_len=self._max_len)
            self._max_len = max(self._max_len, len(stack_str))
            self._last_stack_str = stack_str

    def _run(self):
        while self._running:
            stack = self._get_main_stack()
            self._print_stack(stack)
            time.sleep(self.interval)

    def start(self):
        if not self._running:
            self._running = True
            thread = Thread(target=self._run, daemon=True)
            thread.start()

    def stop(self):
        self._running = False

# Convenience function
def start_monitor_bg(interval=1, max_depth=5):
    monitor = LiveStack(interval=interval, max_depth=max_depth)
    monitor.start()
    return monitor
