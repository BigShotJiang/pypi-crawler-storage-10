import pandas as pd
import numpy as np
import xmlrpc.client
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

@dataclass
class Credentials:
    url: str
    db: str
    username: str
    password: str


class OdooConnector:
    """
    Clase para conectar y operar con Odoo de manera genérica.
    Permite crear registros en cualquier modelo con mapeo de campos flexible.
    Soporta multi-compañía.
    """
    
    def __init__(self,creds:Credentials, connect_imediately:bool = True):
        self.creds = creds
        self.uid: Optional[Any] = None
        self.models: Any = None
        if connect_imediately:
            self.connect()
    
    def connect(self):
        try:
            common = xmlrpc.client.ServerProxy(f'{self.creds.url}/xmlrpc/2/common', allow_none=True)
            self.uid = common.authenticate(self.creds.db,self.creds.username,self.creds.password,{})
            if not self.uid:
                raise RuntimeError("Failed authentication")
            self.models = xmlrpc.client.ServerProxy(f'{self.creds.url}/xmlrpc/2/object', allow_none=True)
            print(f"Connected to Odoo instance at {self.creds.url} as user {self.creds.username}")
        except Exception as e:
            raise RuntimeError(f"Connection failed: {e}")
        
    def _ensure_connection(self):
        if self.uid is None or self.models is None:
            self.connect()

    def execute_kw(self, db: str, uid: Any, password: str, model: str, method: str, 
                   args: Optional[List] = None, kwargs: Optional[Dict] = None):
        """
        Método directo para ejecutar cualquier método de Odoo.
        Expone la funcionalidad completa de execute_kw.
        """
        self._ensure_connection()
        if args is None:
            args = []
        if kwargs is None:
            kwargs = {}
        
        try:
            return self.models.execute_kw(db, uid, password, model, method, args, kwargs)
        except Exception as e:
            raise RuntimeError(f"Execute_kw failed on {model}.{method}: {e}")

    def _build_context(self, company_id: Optional[int] = None, extra_context: Optional[Dict] = None) -> Dict:
        """Construye el contexto con información de compañía."""
        context = extra_context.copy() if extra_context else {}
        if company_id:
            context.update({
                'company_id': company_id,
                'allowed_company_ids': [company_id],
            })
        return context

    def get_fields(self, model: str, company_id: Optional[int] = None) -> Dict[str, Any]:
        self._ensure_connection()
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'fields_get', [], 
                {'attributes': ['string', 'type', 'required', 'help'], 'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Failed to get fields for model {model}: {e}")

    def search(self, model: str, domain: Optional[List]=None, limit: Optional[int]=None, company_id: Optional[int] = None) -> List[int]:
        self._ensure_connection()
        if domain is None:
            domain = []
        
        # Agregar filtro de compañía al domain si se especifica
        if company_id:
            domain = domain + [('company_id', '=', company_id)]
        
        try:
            context = self._build_context(company_id)
            kwargs = {'context': context}
            if limit:
                kwargs['limit'] = limit # type: ignore
                
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'search', [domain], kwargs
            )
        except Exception as e:
            raise RuntimeError(f"Search failed on model {model}: {e}")
        
    def read(self, model: str, fields: Optional[list[str]]=None, domain: Optional[List]=None, 
             limit: Optional[int]=None, company_id: Optional[int] = None) -> List[Dict]:
        self._ensure_connection()
        if domain is None:
            domain = []
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return []
        try:
            context = self._build_context(company_id)
            kwargs = {'context': context}
            if fields:
                kwargs['fields'] = fields # type: ignore
                
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'read', [ids], kwargs
            )
        except Exception as e:
            raise RuntimeError(f"Read failed on model {model}: {e}")

    def create(self, model: str, values: Union[Dict,List[Dict]], company_id: Optional[int] = None) -> Union[int, List[int]]:
        """
        Create one or multiple records in the specified model.
        values can be a single dictionary or a list of dictionaries.
        Returns the ID or list of IDs of the created records.
        """
        self._ensure_connection()
        
        # Agregar company_id a los valores si se especifica
        if company_id:
            if isinstance(values, dict):
                values['company_id'] = company_id
            elif isinstance(values, list):
                for val_dict in values:
                    val_dict['company_id'] = company_id
        
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                model, 'create', [values], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Create failed on model {model}: {e}")
        
    def update(self, model: str, ids: Sequence[int], values: Dict, company_id: Optional[int] = None) -> bool:
        """
        Update records in the specified model.
        ids: list of record IDs to update
        """
        self._ensure_connection()
        if not ids:
            return False
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password, 
                model, 'write', [list(ids), values], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Update failed on model {model}: {e}")

    def update_by_domain(self, model: str, domain: List, values: Dict, 
                        limit: Optional[int]=None, company_id: Optional[int] = None) -> Tuple[List[int], bool]:
        """
        Update records in the specified model matching the domain.
        domain: search domain to find records
        values: dictionary of values to update
        """
        self._ensure_connection()
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return [], False
        ok = self.update(model, ids, values, company_id)
        return ids, ok
    
    def delete(self, model: str, ids: Sequence[int], company_id: Optional[int] = None) -> bool:
        """
        Delete records in the specified model.
        ids: list of record IDs to delete
        """
        self._ensure_connection()
        if not ids:
            return False
        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password, 
                model, 'unlink', [list(ids)], {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Delete failed on model {model}: {e}")
        
    def delete_by_domain(self, model: str, domain: List, limit: Optional[int]=None, 
                        company_id: Optional[int] = None) -> Tuple[List[int], bool]:
        """
        Delete records in the specified model matching the domain.
        domain: search domain to find records
        """
        self._ensure_connection()
        ids = self.search(model, domain, limit, company_id)
        if not ids:
            return [], False
        ok = self.delete(model, ids, company_id)
        return ids, ok
    
    # Data helpers
    def _normalize_value(self, val):
        if pd.isna(val):
            return None
        if isinstance(val, np.integer):
            return int(val)
        if isinstance(val, np.floating):
            return float(val)
        return val
    
    def create_from_df(self, model: str, df: pd.DataFrame, field_map: Dict[str, str], 
                       static_values: Optional[Dict[str, Any]]=None, batch_size: int=50, 
                       validate: bool=True, company_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Create records in the specified model from a DataFrame.
        field_map: mapping from DataFrame columns to Odoo fields
        company_id: opcional, para crear registros en una compañía específica
        Returns list of created record IDs.
        """
        if static_values is None:
            static_values = {}
        
        # validate columns
        missing = [col for col in field_map.keys() if col not in df.columns]
        if missing:
            raise ValueError(f"DataFrame is missing required columns: {missing}")
        
        result = {'created_ids': [], 'errors': [], 'total_processed': 0, 'total_created': 0}
        total = len(df)
        for start in range(0, total, batch_size):
            batch = df.iloc[start:start + batch_size]
            payload = []
            for idx, row in batch.iterrows():
                values = dict(static_values)
                for df_column, odoo_field in field_map.items():
                    v = row[df_column]
                    nv = self._normalize_value(v)
                    if nv is None:
                        continue
                    values[odoo_field] = nv
                try:
                    if validate and not values:
                        raise ValueError("Registro vacío tras normalización")
                    print(f"Preparando para crear: {values}")
                    payload.append(values)
                except Exception as e:
                    result['errors'].append({'row_index': idx, 'error': str(e), 'row_data': row.to_dict()})
            print(f"Creando lote de {len(payload)} registros en {model}...")
            print(f"Payload: {payload}")
            if payload:
                try:
                    created = self.create(model, payload, company_id)
                    # created puede ser int o lista
                    if isinstance(created, list):
                        result['created_ids'].extend(created)
                        result['total_created'] += len(created)
                    else:
                        result['created_ids'].append(created)
                        result['total_created'] += 1
                except Exception as e:
                    # fallback: intentar individualmente
                    print(f"Error bulk create, intentando individual: {e}")
                    for rec in payload:
                        try:
                            cid = self.create(model, rec, company_id)
                            if isinstance(cid, list):
                                result['created_ids'].append(cid[0] if cid else None)
                            else:
                                result['created_ids'].append(cid)
                            result['total_created'] += 1
                        except Exception as ie:
                            result['errors'].append({'record': rec, 'error': str(ie)})
            result['total_processed'] += len(batch)
        print(f"Creación completada: procesados {result['total_processed']}, creados {result['total_created']}, errores {len(result['errors'])}")
        return result

    def upsert_by_external_id(self, model: str, external_id_field: str, external_id_value: str, 
                             values: Dict, company_id: Optional[int] = None) -> Tuple[int, bool]:
        """
        Crear o actualizar registro basado en ID externo.
        Retorna (record_id, was_created)
        """
        domain = [(external_id_field, '=', external_id_value)]
        existing_ids = self.search(model, domain, limit=1, company_id=company_id)
        
        if existing_ids:
            # Actualizar
            self.update(model, existing_ids, values, company_id)
            return existing_ids[0], False
        else:
            # Crear
            values[external_id_field] = external_id_value
            new_id = self.create(model, values, company_id)
            # self.create can return int or List[int]; normalize to int
            if isinstance(new_id, list):
                if not new_id:
                    raise RuntimeError("Create returned an empty list when creating record with external id")
                new_id = new_id[0]
            if not isinstance(new_id, int):
                raise RuntimeError(f"Unexpected id type returned from create: {type(new_id)}")
            return new_id, True
    def confirm_sale_order(self, order_ids: List[int], company_id: Optional[int] = None) -> bool:
        """
        Confirma órdenes de venta usando el método action_confirm (equivalente al botón Confirmar en la UI).
        """
        self._ensure_connection()
        if not order_ids:
            raise ValueError("Se requiere al menos un ID de orden para confirmar.")

        try:
            context = self._build_context(company_id)
            return self.models.execute_kw(
                self.creds.db, self.uid, self.creds.password,
                'sale.order', 'action_confirm',
                [order_ids],
                {'context': context}
            )
        except Exception as e:
            raise RuntimeError(f"Falló la confirmación de órdenes de venta: {e}")


__all__ = ["Credentials", "OdooConnector"]

