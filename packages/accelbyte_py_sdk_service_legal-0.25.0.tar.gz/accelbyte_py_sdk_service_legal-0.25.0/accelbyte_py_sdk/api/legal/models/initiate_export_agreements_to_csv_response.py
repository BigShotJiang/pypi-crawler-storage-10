# Copyright (c) 2021 AccelByte Inc. All Rights Reserved.
# This is licensed software from AccelByte Inc, for limitations
# and restrictions contact your company contract manager.
#
# Code generated. DO NOT EDIT!

# template file: model.j2

# AccelByte Gaming Services Legal Service

# pylint: disable=duplicate-code
# pylint: disable=line-too-long
# pylint: disable=missing-function-docstring
# pylint: disable=missing-module-docstring
# pylint: disable=too-many-arguments
# pylint: disable=too-many-branches
# pylint: disable=too-many-instance-attributes
# pylint: disable=too-many-lines
# pylint: disable=too-many-locals
# pylint: disable=too-many-public-methods
# pylint: disable=too-many-return-statements
# pylint: disable=too-many-statements
# pylint: disable=unused-import

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple, Union

from accelbyte_py_sdk.core import Model


class InitiateExportAgreementsToCSVResponse(Model):
    """Initiate export agreements to CSV response (InitiateExportAgreementsToCSVResponse)

    Properties:
        export_id: (exportId) REQUIRED str

        processing: (processing) REQUIRED bool
    """

    # region fields

    export_id: str  # REQUIRED
    processing: bool  # REQUIRED

    # endregion fields

    # region with_x methods

    def with_export_id(self, value: str) -> InitiateExportAgreementsToCSVResponse:
        self.export_id = value
        return self

    def with_processing(self, value: bool) -> InitiateExportAgreementsToCSVResponse:
        self.processing = value
        return self

    # endregion with_x methods

    # region to methods

    def to_dict(self, include_empty: bool = False) -> dict:
        result: dict = {}
        if hasattr(self, "export_id"):
            result["exportId"] = str(self.export_id)
        elif include_empty:
            result["exportId"] = ""
        if hasattr(self, "processing"):
            result["processing"] = bool(self.processing)
        elif include_empty:
            result["processing"] = False
        return result

    # endregion to methods

    # region static methods

    @classmethod
    def create(
        cls, export_id: str, processing: bool, **kwargs
    ) -> InitiateExportAgreementsToCSVResponse:
        instance = cls()
        instance.export_id = export_id
        instance.processing = processing
        return instance

    @classmethod
    def create_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> InitiateExportAgreementsToCSVResponse:
        instance = cls()
        if not dict_:
            return instance
        if "exportId" in dict_ and dict_["exportId"] is not None:
            instance.export_id = str(dict_["exportId"])
        elif include_empty:
            instance.export_id = ""
        if "processing" in dict_ and dict_["processing"] is not None:
            instance.processing = bool(dict_["processing"])
        elif include_empty:
            instance.processing = False
        return instance

    @classmethod
    def create_many_from_dict(
        cls, dict_: dict, include_empty: bool = False
    ) -> Dict[str, InitiateExportAgreementsToCSVResponse]:
        return (
            {k: cls.create_from_dict(v, include_empty=include_empty) for k, v in dict_}
            if dict_
            else {}
        )

    @classmethod
    def create_many_from_list(
        cls, list_: list, include_empty: bool = False
    ) -> List[InitiateExportAgreementsToCSVResponse]:
        return (
            [cls.create_from_dict(i, include_empty=include_empty) for i in list_]
            if list_
            else []
        )

    @classmethod
    def create_from_any(
        cls, any_: any, include_empty: bool = False, many: bool = False
    ) -> Union[
        InitiateExportAgreementsToCSVResponse,
        List[InitiateExportAgreementsToCSVResponse],
        Dict[Any, InitiateExportAgreementsToCSVResponse],
    ]:
        if many:
            if isinstance(any_, dict):
                return cls.create_many_from_dict(any_, include_empty=include_empty)
            elif isinstance(any_, list):
                return cls.create_many_from_list(any_, include_empty=include_empty)
            else:
                raise ValueError()
        else:
            return cls.create_from_dict(any_, include_empty=include_empty)

    @staticmethod
    def get_field_info() -> Dict[str, str]:
        return {
            "exportId": "export_id",
            "processing": "processing",
        }

    @staticmethod
    def get_required_map() -> Dict[str, bool]:
        return {
            "exportId": True,
            "processing": True,
        }

    # endregion static methods
