import inspect
import warnings
import logging
import json
import os
import sys
import traceback
from dotenv import load_dotenv
from openai import OpenAI
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.traceback import install
from rich.logging import RichHandler
from pydantic import BaseModel, Field

# ===========================
# Setup
# ===========================

load_dotenv()
install(show_locals=True)
console = Console()

logging.basicConfig(
    level="NOTSET",
    format="%(message)s",
    datefmt="[%X]",
    handlers=[
        RichHandler(
            rich_tracebacks=True,
            markup=True,
            show_time=True,
            show_level=True,
            show_path=True
        )
    ],
)

log = logging.getLogger("rich")

# Disable noisy logs
for noisy in ["httpx", "openai", "urllib3", "httpcore", "stainless_sdk"]:
    logging.getLogger(noisy).setLevel(logging.CRITICAL)
    logging.getLogger(noisy).propagate = False

warnings.filterwarnings("ignore")

# ===========================
# Data Model
# ===========================

class ErrorSuggestion(BaseModel):
    cause: str = Field(..., description="Reason for the error.")
    fix: str = Field(..., description="How to fix the error.")

# ===========================
# AI Assistant Class
# ===========================

class AIDebugger:
    def __init__(self):
        self.api_key = os.getenv("API_KEY")
        self.base_url = os.getenv("BASE_URL")
        self.instruction = os.getenv("INSTRUCTION", "Explain this Python error simply and clearly.")
        self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def analyze(self, error: str, code: str, args=None, kwargs=None, result=None):
        args_repr = json.dumps(args, default=str)
        kwargs_repr = json.dumps(kwargs, default=str)

        base_prompt = (
            "You are a professional Python assistant. "
            "Explain the cause of the exception and how to fix it in simple terms. "
            "Show short, helpful, and concise explanations.\n\n"
            "Response format:\n"
            "- Cause: (Why the error occurred)\n"
            "- Fix: (How to fix it)"
        )

        prompt = f"""
        {base_prompt}

        Error:
        {error}

        Args: {args_repr}
        Kwargs: {kwargs_repr}

        Code:
        ```python
        {code}
        ```
        """

        try:
            response = self.client.beta.chat.completions.parse(
                model="gemini-2.5-flash",
                messages=[
                    {"role": "system", "content": "You are a Python debugging assistant."},
                    {"role": "user", "content": prompt},
                ],
                response_format=ErrorSuggestion,
            )
            return response.choices[0].message.parsed
        except Exception as e:
            return ErrorSuggestion(
                cause="Could not get AI suggestion.",
                fix=str(e)
            )

# ===========================
# Error Catcher (Decorator Class)
# ===========================

class ErrorCatcher:
    def __init__(self):
        self.ai_debugger = AIDebugger()

    def __call__(self, func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)

            except Exception as e:
                tb = traceback.format_exc()
                src = inspect.getsource(func)
                err_type = type(e).__name__

                console.print(
                    Panel(Text(f"{err_type}: {e}", style="bold red"),
                          title="[bold red]Error Detected", border_style="red")
                )

                console.print(
                    Panel(Text(src.strip(), style="yellow"),
                          title="[bold yellow]Code Causing Error", border_style="yellow")
                )

                suggestion = self.ai_debugger.analyze(str(e), src, args, kwargs)

                console.print(
                    Panel(Text(suggestion.cause.strip(), style="bold red"),
                          title="[bold red]Error Cause", border_style="red")
                )

                console.print(
                    Panel(Text(suggestion.fix.strip(), style="bold green"),
                          title="[bold green]Fix Suggestion", border_style="green")
                )

                log.error(f"\n{tb}")

        return wrapper