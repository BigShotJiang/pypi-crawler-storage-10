"""
Shared module that holds runtime mappings and small utilities used by the
JPype/Timefold interop layers.

This module centralizes mutable global structures so other modules can import
these lightweight containers without causing heavy import-time dependencies
or circular import cycles.

Keep this module free of imports that themselves import the larger interop
layers (e.g. avoid importing _solverforge_java_interop or _jpype_type_conversions
here). Only simple stdlib imports are used so it remains safe at import time.
"""

from __future__ import annotations

from threading import Lock
from typing import Any, Dict, List, Optional

# Protects mutation of the shared structures below
_lock = Lock()

# Score type mapping dictionaries.
# Keys are short names like "SimpleScore", "HardSoftScore", etc.
# Values are the Python classes (in python mapping) or Java proxy classes (in java mapping).
_python_score_mapping_dict: Dict[str, object] = {}
_java_score_mapping_dict: Dict[str, object] = {}

# Map from a composed class identifier -> last registered Java Class
# (the value type is intentionally Any because the actual objects are JVM proxies).
class_identifier_to_java_class_map: Dict[str, Any] = {}

# Queue of classes or suppliers to be compiled into Java proxies.
_compilation_queue: List[object] = []

# Feature flags / state
_enterprise_installed: bool = False
_mappings_registered: bool = False

# Unique id generator for created Java class names (keeps names unique across process).
unique_class_id: int = 0

# Default package prefix used when generating Java class names for Python types.
_user_package_prefix: str = "org.jpyinterpreter.user."

# --- Utility accessors / mutators -------------------------------------------------


def get_python_score_mappings() -> Dict[str, object]:
    """
    Return a shallow copy of the Python->helper mapping dict.
    Use this when you need a snapshot without holding the internal lock.
    """
    with _lock:
        return dict(_python_score_mapping_dict)


def get_java_score_mappings() -> Dict[str, object]:
    """Return a shallow copy of the Java score mapping dict."""
    with _lock:
        return dict(_java_score_mapping_dict)


def register_python_score_mapping(name: str, py_obj: object) -> None:
    """Register a Python-side score mapping under `name`."""
    with _lock:
        _python_score_mapping_dict[name] = py_obj


def register_java_score_mapping(name: str, java_obj: object) -> None:
    """Register a Java-side score mapping under `name`."""
    with _lock:
        _java_score_mapping_dict[name] = java_obj


def get_java_class_for_identifier(identifier: str) -> Optional[Any]:
    """Lookup the Java class currently registered for `identifier`."""
    with _lock:
        return class_identifier_to_java_class_map.get(identifier)


def set_java_class_for_identifier(identifier: str, java_class: Any) -> None:
    """Associate `java_class` with `identifier` (overwrites any previous value)."""
    with _lock:
        class_identifier_to_java_class_map[identifier] = java_class


def enqueue_for_compilation(item: object) -> None:
    """Add a Python class or supplier to the compilation queue."""
    with _lock:
        _compilation_queue.append(item)


def dequeue_next_for_compilation() -> Optional[object]:
    """Pop and return the next item to compile, or None if the queue is empty."""
    with _lock:
        if not _compilation_queue:
            return None
        return _compilation_queue.pop(0)


def is_compilation_queue_empty() -> bool:
    """Return True if no pending compilation items exist."""
    with _lock:
        return len(_compilation_queue) == 0


def set_enterprise_installed(value: bool) -> None:
    """Set enterprise installed flag."""
    global _enterprise_installed
    with _lock:
        _enterprise_installed = bool(value)


def is_enterprise_installed() -> bool:
    """Return whether enterprise jars were detected / installed."""
    with _lock:
        return bool(_enterprise_installed)


def set_mappings_registered(value: bool) -> None:
    """Set whether mappings have been registered already."""
    global _mappings_registered
    with _lock:
        _mappings_registered = bool(value)


def are_mappings_registered() -> bool:
    """Return whether mappings were registered."""
    with _lock:
        return bool(_mappings_registered)


def next_unique_class_id() -> int:
    """
    Atomically increment and return a unique integer to help generate
    globally-unique Java class names.
    """
    global unique_class_id
    with _lock:
        unique_class_id += 1
        return unique_class_id


# Expose the raw dicts for callers that prefer direct access (use with care).
# These are the names some other modules in the project expect to import.
_python_score_mapping_dict = _python_score_mapping_dict
_java_score_mapping_dict = _java_score_mapping_dict
# also expose the class map and queue under the conventional names:
class_identifier_to_java_class_map = class_identifier_to_java_class_map
_compilation_queue = _compilation_queue

# --- Optional runtime callback -----------------------------------------------
# A small, lightweight mechanism that allows registering a callable which can be
# used by interop layers to obtain a Java class/object for a Python object.
# This keeps the registration local to this small module and avoids importing
# heavyweight runtime interop modules at import time (helpful to prevent cycles
# during static analysis).
_get_class_callback: Optional[Any] = None


def register_get_class_callback(cb: Any) -> None:
    """
    Register a callback used to compute/resolve a Java class for a given Python
    object. The callback should accept a single argument (the Python object)
    and return the corresponding Java class/proxy or None.
    """
    global _get_class_callback
    with _lock:
        _get_class_callback = cb


def call_get_class_callback(obj: Any) -> Optional[Any]:
    """
    Call the registered get-class callback (if any) with `obj` and return the
    result. If no callback is registered, returns None.
    """
    with _lock:
        cb = _get_class_callback
    if cb is None:
        return None
    try:
        return cb(obj)
    except Exception:
        # Swallow exceptions here to keep callers robust; callers can perform
        # additional logging if desired.
        return None


__all__ = [
    "_python_score_mapping_dict",
    "_java_score_mapping_dict",
    "class_identifier_to_java_class_map",
    "_compilation_queue",
    "get_python_score_mappings",
    "get_java_score_mappings",
    "register_python_score_mapping",
    "register_java_score_mapping",
    "get_java_class_for_identifier",
    "set_java_class_for_identifier",
    "enqueue_for_compilation",
    "dequeue_next_for_compilation",
    "is_compilation_queue_empty",
    "set_enterprise_installed",
    "is_enterprise_installed",
    "set_mappings_registered",
    "are_mappings_registered",
    "next_unique_class_id",
    "_user_package_prefix",
    # New callback registration API
    "register_get_class_callback",
    "call_get_class_callback",
    "_get_class_callback",
]
