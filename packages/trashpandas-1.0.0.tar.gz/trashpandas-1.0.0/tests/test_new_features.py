"""Tests for new features and edge cases."""

import tempfile
from pathlib import Path
from typing import Generator

import pytest
import pandas as pd
from sqlalchemy import create_engine

from trashpandas.sql import SqlStorage
from trashpandas.csv import CsvStorage
from trashpandas.pickle import PickleStorage
from trashpandas.exceptions import (
    TrashPandasError,
    StorageError,
    TableNotFoundError,
    TableAlreadyExistsError,
    MetadataError,
    MetadataNotFoundError,
    MetadataCorruptedError,
    StorageConnectionError,
    ValidationError,
    ConversionError,
    CompressionError,
)
from trashpandas.metadata import TableMetadata


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for test data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def sqlite_engine(temp_dir: Path):
    """Create a SQLite engine for testing."""
    db_path = temp_dir / "test.db"
    engine = create_engine(f'sqlite:///{db_path}')
    yield engine
    engine.dispose()


@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Create a sample DataFrame for testing."""
    return pd.DataFrame({
        'name': ['Alice', 'Bob', 'Charlie'],
        'age': [25, 30, 35],
        'city': ['New York', 'London', 'Tokyo']
    })


class TestExceptionHierarchy:
    """Test the custom exception hierarchy."""

    def test_base_exception(self):
        """Test base TrashPandasError."""
        error = TrashPandasError("Test error", details="Some details")
        assert str(error) == "Test error"
        assert error.details == "Some details"

    def test_storage_error(self):
        """Test StorageError."""
        error = StorageError("Storage error")
        assert isinstance(error, TrashPandasError)
        assert str(error) == "Storage error"

    def test_table_not_found_error(self):
        """Test TableNotFoundError."""
        error = TableNotFoundError("users", "sql")
        assert error.table_name == "users"
        assert error.storage_type == "sql"
        assert "users" in str(error)
        assert "sql" in str(error)

    def test_table_already_exists_error(self):
        """Test TableAlreadyExistsError."""
        error = TableAlreadyExistsError("users", "sql")
        assert error.table_name == "users"
        assert error.storage_type == "sql"

    def test_metadata_error(self):
        """Test MetadataError."""
        error = MetadataError("Metadata error")
        assert isinstance(error, TrashPandasError)

    def test_metadata_not_found_error(self):
        """Test MetadataNotFoundError."""
        error = MetadataNotFoundError("users")
        assert error.table_name == "users"

    def test_metadata_corrupted_error(self):
        """Test MetadataCorruptedError."""
        error = MetadataCorruptedError("users", "Invalid format")
        assert error.table_name == "users"
        assert "Invalid format" in str(error)

    def test_connection_error(self):
        """Test StorageConnectionError."""
        error = StorageConnectionError("sql", "Connection failed")
        assert error.storage_type == "sql"
        assert "Connection failed" in str(error)

    def test_validation_error(self):
        """Test ValidationError."""
        error = ValidationError("table_name", "invalid_name!", "Invalid characters")
        assert error.field == "table_name"
        assert error.value == "invalid_name!"
        assert error.reason == "Invalid characters"

    def test_conversion_error(self):
        """Test ConversionError."""
        error = ConversionError("csv", "sql", "Schema mismatch")
        assert error.source_format == "csv"
        assert error.target_format == "sql"
        assert "Schema mismatch" in str(error)

    def test_compression_error(self):
        """Test CompressionError."""
        error = CompressionError("compress", "File corrupted")
        assert error.operation == "compress"
        assert "File corrupted" in str(error)


class TestTableMetadata:
    """Test the TableMetadata dataclass."""

    def test_from_dataframe(self, sample_df: pd.DataFrame):
        """Test creating metadata from DataFrame."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        
        assert metadata.table_name == "test_table"
        assert metadata.storage_format == "csv"
        assert metadata.columns == list(sample_df.columns)
        assert len(metadata.column_types) == len(sample_df.columns)

    def test_to_dataframe(self, sample_df: pd.DataFrame):
        """Test converting metadata to DataFrame."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        metadata_df = metadata.to_dataframe()
        
        assert 'column' in metadata_df.columns
        assert 'index' in metadata_df.columns
        assert 'datatype' in metadata_df.columns

    def test_validation(self, sample_df: pd.DataFrame):
        """Test metadata validation."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        metadata.validate()  # Should not raise

    def test_validation_duplicate_columns(self):
        """Test validation with duplicate columns."""
        metadata = TableMetadata(
            table_name="test",
            columns=["col1", "col1"],  # Duplicate
            column_types={"col1": "int64"},
            index_columns=[],
            index_types={}
        )
        
        with pytest.raises(MetadataCorruptedError):
            metadata.validate()

    def test_validation_missing_types(self):
        """Test validation with missing types."""
        metadata = TableMetadata(
            table_name="test",
            columns=["col1", "col2"],
            column_types={"col1": "int64"},  # Missing col2
            index_columns=[],
            index_types={}
        )
        
        with pytest.raises(MetadataCorruptedError):
            metadata.validate()

    def test_get_column_types(self, sample_df: pd.DataFrame):
        """Test getting column types as pandas dtypes."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        types = metadata.get_column_types()
        
        assert isinstance(types, dict)
        assert len(types) == len(sample_df.columns)

    def test_get_index_types(self, sample_df: pd.DataFrame):
        """Test getting index types as pandas dtypes."""
        sample_df.index.name = "id"
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        types = metadata.get_index_types()
        
        assert isinstance(types, dict)

    def test_str_representation(self, sample_df: pd.DataFrame):
        """Test string representation."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        str_repr = str(metadata)
        
        assert "test_table" in str_repr
        assert "3" in str_repr  # Number of columns

    def test_repr_representation(self, sample_df: pd.DataFrame):
        """Test detailed string representation."""
        metadata = TableMetadata.from_dataframe(sample_df, "test_table", "csv")
        repr_str = repr(metadata)
        
        assert "TableMetadata" in repr_str
        assert "test_table" in repr_str


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_empty_dataframe(self, temp_dir: Path):
        """Test storing and loading empty DataFrame."""
        empty_df = pd.DataFrame()
        storage = CsvStorage(temp_dir)
        
        storage.store(empty_df, 'empty')
        loaded_df = storage.load('empty')
        
        # Empty DataFrames may have different inferred types, so check shape and columns
        assert empty_df.shape == loaded_df.shape
        assert list(empty_df.columns) == list(loaded_df.columns)

    def test_single_row_dataframe(self, temp_dir: Path):
        """Test storing and loading single row DataFrame."""
        single_row_df = pd.DataFrame({'value': [42]})
        storage = CsvStorage(temp_dir)
        
        storage.store(single_row_df, 'single')
        loaded_df = storage.load('single')
        
        pd.testing.assert_frame_equal(single_row_df, loaded_df)

    def test_large_dataframe(self, temp_dir: Path):
        """Test storing and loading large DataFrame."""
        large_df = pd.DataFrame({
            'id': range(1000),
            'value': [f'value_{i}' for i in range(1000)]
        })
        storage = CsvStorage(temp_dir)
        
        storage.store(large_df, 'large')
        loaded_df = storage.load('large')
        
        pd.testing.assert_frame_equal(large_df, loaded_df)

    def test_special_characters_in_data(self, temp_dir: Path):
        """Test storing data with special characters."""
        special_df = pd.DataFrame({
            'text': ['Hello, World!', 'Line\nBreak', 'Tab\tCharacter', 'Quote"Test'],
            'unicode': ['café', 'naïve', 'résumé', '🚀']
        })
        storage = CsvStorage(temp_dir)
        
        storage.store(special_df, 'special')
        loaded_df = storage.load('special')
        
        pd.testing.assert_frame_equal(special_df, loaded_df)

    def test_nan_values(self, temp_dir: Path):
        """Test storing data with NaN values."""
        nan_df = pd.DataFrame({
            'numbers': [1, 2, None, 4, 5],
            'text': ['a', 'b', None, 'd', 'e']
        })
        storage = CsvStorage(temp_dir)
        
        storage.store(nan_df, 'nan_data')
        loaded_df = storage.load('nan_data')
        
        pd.testing.assert_frame_equal(nan_df, loaded_df)

    def test_very_long_column_names(self, temp_dir: Path):
        """Test storing data with very long column names."""
        long_name_df = pd.DataFrame({
            'a' * 100: [1, 2, 3],
            'b' * 100: [4, 5, 6]
        })
        storage = CsvStorage(temp_dir)
        
        storage.store(long_name_df, 'long_names')
        loaded_df = storage.load('long_names')
        
        pd.testing.assert_frame_equal(long_name_df, loaded_df)

    def test_very_long_table_name(self, temp_dir: Path):
        """Test storing data with very long table name."""
        df = pd.DataFrame({'value': [1, 2, 3]})
        storage = CsvStorage(temp_dir)
        
        long_name = 'a' * 100
        storage.store(df, long_name)
        loaded_df = storage.load(long_name)
        
        pd.testing.assert_frame_equal(df, loaded_df)


class TestCompressionEdgeCases:
    """Test compression edge cases."""

    def test_compression_with_empty_data(self, temp_dir: Path):
        """Test compression with empty DataFrame."""
        empty_df = pd.DataFrame()
        storage = CsvStorage(temp_dir, compression='gzip')
        
        storage.store(empty_df, 'empty')
        loaded_df = storage.load('empty')
        
        # Empty DataFrames may have different inferred types, so check shape and columns
        assert empty_df.shape == loaded_df.shape
        assert list(empty_df.columns) == list(loaded_df.columns)

    def test_compression_with_single_character_data(self, temp_dir: Path):
        """Test compression with single character data."""
        single_char_df = pd.DataFrame({'a': ['x']})
        storage = CsvStorage(temp_dir, compression='gzip')
        
        storage.store(single_char_df, 'single_char')
        loaded_df = storage.load('single_char')
        
        pd.testing.assert_frame_equal(single_char_df, loaded_df)

    def test_different_compression_algorithms(self, temp_dir: Path):
        """Test different compression algorithms."""
        df = pd.DataFrame({'data': [f'row_{i}' for i in range(100)]})
        
        for compression in ['gzip', 'bz2', 'xz']:
            storage = CsvStorage(temp_dir / compression, compression=compression)
            storage.store(df, 'data')
            loaded_df = storage.load('data')
            pd.testing.assert_frame_equal(df, loaded_df)


class TestBulkOperationsEdgeCases:
    """Test bulk operations edge cases."""

    def test_empty_bulk_operations(self, temp_dir: Path):
        """Test bulk operations with empty data."""
        storage = CsvStorage(temp_dir)
        
        # Empty store_many
        storage.store_many({})
        
        # Empty load_many
        results = storage.load_many([])
        assert results == {}
        
        # Empty delete_many
        storage.delete_many([])

    def test_bulk_operations_with_single_item(self, temp_dir: Path, sample_df: pd.DataFrame):
        """Test bulk operations with single item."""
        storage = CsvStorage(temp_dir)
        
        # Single item store_many
        storage.store_many({'single': sample_df})
        
        # Single item load_many
        results = storage.load_many(['single'])
        assert len(results) == 1
        pd.testing.assert_frame_equal(sample_df, results['single'])
        
        # Single item delete_many
        storage.delete_many(['single'])
        assert len(storage) == 0

    def test_bulk_operations_with_duplicate_names(self, temp_dir: Path, sample_df: pd.DataFrame):
        """Test bulk operations with duplicate names."""
        storage = CsvStorage(temp_dir)
        
        # This should work - last one wins
        dataframes = {
            'duplicate': sample_df.copy(),
            'duplicate': sample_df.copy()  # Same key twice
        }
        storage.store_many(dataframes)
        
        # Should have only one table
        assert len(storage) == 1
        assert 'duplicate' in storage
