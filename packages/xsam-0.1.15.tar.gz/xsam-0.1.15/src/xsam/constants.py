TIMESTAMP_FORMAT = "%Y-%m-%d_%H-%M-%S"
TIMESTAMP_FORMAT_LOG = "%Y-%m-%d %H:%M:%S %z"
DATE_FORMAT = "%Y-%m-%d"
LOG_DELIMITER = " | "
