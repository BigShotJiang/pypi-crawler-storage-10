def main():
    print("Welcome to the XSAM package!")


if __name__ == "__main__":
    main()
