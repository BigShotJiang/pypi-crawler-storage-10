# NuStatTools

Statistical tools (not just) for neutrino physics

```{toctree}
:maxdepth: 2
:hidden:
api/nustattools
changelog
```

```{include} ../README.md
:start-after: <!-- SPHINX-START -->
```

## Indices and tables

- {ref}`genindex`
- {ref}`modindex`
- {ref}`search`
