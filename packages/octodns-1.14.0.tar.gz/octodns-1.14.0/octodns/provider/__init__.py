#
#
#


class ProviderException(Exception):
    pass


class SupportsException(ProviderException):
    pass
