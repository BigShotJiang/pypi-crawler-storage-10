
import click
import subprocess
import os
import AgentService


@click.group()
def group():
    pass


@group.command('add_image', help="Command that creates docker image")
def add_image():
    image_dir = os.path.join(AgentService.__path__[0], "templates", "agent-image")

    subprocess.run(
        "docker build -t agentservice-base .",
        shell=True,
        text=True,
        cwd=image_dir
    )
