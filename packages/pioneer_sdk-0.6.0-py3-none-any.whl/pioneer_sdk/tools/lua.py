"""
API to Lua-related functionality
"""

import os, pathlib


def compile(lua_source) -> str:
    here = pathlib.Path(__file__).resolve().parent
    """ Compiles a binary from Lua source file """

    out = "hw.luac"

    if os.name == "nt":  # "Windows"
        tool = here / "luac.exe"
    elif os.name == "posix":  # "Linux"
        tool = here / "luac"

    tool = str(tool)
    os.system(f"{tool} -s -o {out} {lua_source}")

    return pathlib.Path(out)
