# Language model extensions

Some useful integrations for llama-index.
