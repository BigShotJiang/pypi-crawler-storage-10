#!/usr/bin/env python3

"""
Project: BRS-XSS (XSS Detection Suite)
Company: EasyProTech LLC (www.easypro.tech)
Dev: Brabus
Date: Sun 26 Oct 2025 21:38:09 MSK
Status: Modified
Telegram: https://t.me/EasyProTech
"""