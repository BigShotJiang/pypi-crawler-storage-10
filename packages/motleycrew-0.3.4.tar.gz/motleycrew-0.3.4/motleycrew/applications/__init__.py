"""Miscellaneous motleycrew applications."""
