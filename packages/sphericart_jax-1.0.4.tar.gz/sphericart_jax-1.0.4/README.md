# JAX bindings to sphericart

This package contains the JAX version of sphericart. See the
[sphericart documentation](https://sphericart.readthedocs.io/en/latest/) for
more information.
