"""Metadata for troml-dev-status."""

__all__ = [
    "__title__",
    "__version__",
    "__keywords__",
    "__description__",
    "__readme__",
    "__credits__",
    "__requires_python__",
    "__status__",
]

__title__ = "troml-dev-status"
__version__ = "0.5.0"
__keywords__ = ["development status", "trove classifiers", "python packaging"]
__description__ = "Objectively infer PyPI Development Status classifiers from code and release artifacts."
__readme__ = "README.md"
__credits__ = [
    {"name": "Matthew Dean Martin", "email": "matthewdeanmartin@gmail.com"},
    {"name": "Gemini"},
    {"name": "ChatGPT"},
]
__requires_python__ = ">=3.9"
__status__ = "5 - Production/Stable"
