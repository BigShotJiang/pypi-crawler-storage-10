from .ilamb import *
from .ilamb import tree_generator
from .hackathon import check_hackathon
from . import _version
__version__ = _version.get_versions()['version']
