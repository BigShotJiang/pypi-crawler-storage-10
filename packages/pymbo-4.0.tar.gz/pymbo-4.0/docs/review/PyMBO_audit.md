# PyMBO Architecture & Verification Audit

## Table of Contents
- [Architecture Map & Functionality Inventory](#architecture-map--functionality-inventory)
- [Pipeline & Workflow Map](#pipeline--workflow-map)
- [Verification Findings](#verification-findings)
  - [Scientific Correctness](#scientific-correctness)
  - [Reproducibility](#reproducibility)
  - [Performance & Scalability](#performance--scalability)
  - [API & Usability](#api--usability)
  - [Documentation](#documentation)
  - [Testing](#testing)
  - [Code Quality](#code-quality)
- [Prioritized Recommendations](#prioritized-recommendations)
- [Local Check Recipes](#local-check-recipes)

## Architecture Map & Functionality Inventory

### Entry Points & Packaging
- `launch_pymbo.py`
  - Purpose: thin launcher script for end users to call `pymbo.launcher.main()` from the project root.
  - Inputs/Outputs: CLI (no args) � calls `main()`; returns integer exit code.
  - Dependencies: `pymbo.launcher`.
  - Pipeline role: desktop entry point (GUI/headless orchestration).
  - Status: stable; Docs: minimal docstring; Tests: covered indirectly by `tests/test_launcher_headless.py`.
- `pymbo/__init__.py`
  - Key symbols: re-exports `EnhancedMultiObjectiveOptimizer`, `SimpleController` as public API (`__all__`).
  - Pipeline role: canonical import surface for consumers embedding PyMBO.
  - Status: experimental (API exported without versioned contract); Docs: short module docstring; Tests: missing.
- `pymbo/__main__.py`
  - Purpose: enable `python -m pymbo` to call CLI.
  - Status: stable; Docs: minimal docstring; Tests: missing.
- `pymbo/cli.py`
  - Provides `main()` CLI shim that imports `pymbo.launcher.main()`; handles exception printing.
  - Status: experimental (no argument parsing, best-effort error handling); Docs: succinct; Tests: missing.
- Packaging & requirements: `setup.py`, `requirements*.txt` define package metadata with loose `>=` pins; no lockfiles or optional extras for GPU/unified kernel.

### Core Optimisation Stack (`pymbo/core`)
- `optimizer.py`
  - Key symbols: `SimpleParameterTransformer`, `EnhancedMultiObjectiveOptimizer`, kernel builders, hypervolume utilities, random/LHS samplers, acquisition setup & optimization, caching helpers.
  - Purpose: primary Bayesian optimisation engine (multi-objective, constraint support, caching, progress summaries).
  - Inputs/Outputs: parameter/response configs, experimental `DataFrame` inputs � suggestion dicts, internal Pandas/tensor stores.
  - Dependencies: NumPy, Pandas, PyTorch, BoTorch (EHVI, qNEHVI fallback), GPytorch, SciPy LHS, utilities (`performance_timer`, `warnings_config`).
  - Pipeline role: parameter normalisation, surrogate training, acquisition selection, candidate optimisation, hypervolume progress, iteration history.
  - Status: experimental (large monolith, heavy side effects, unchecked fallbacks); Docs: extensive docstrings but uneven inline comments; Tests: missing.
- `enhanced_optimizer.py`
  - `EfficientMultiObjectiveOptimizer` wrapper integrating `OptimizationDataManager` for batched updates, incremental retraining.
  - Pipeline role: optional faster engine sharing interface with `EnhancedMultiObjectiveOptimizer`.
  - Status: experimental; Docs: module/class docstrings; Tests: missing.
- `efficient_data_manager.py`
  - Structures: `OptimizationDataManager`, `DataBuffer`, `SmartTensorManager`, `create_efficient_data_manager` factory, configs.
  - Purpose: manage data ingestion, batching, tensor caching, retraining triggers.
  - Pipeline role: feeding optimizers with batched, debounced updates.
  - Status: experimental; Docs: detailed docstrings; Tests: missing.
- `controller.py`
  - `SimpleController` orchestrates GUI interactions, optimizer creation, threading, file I/O, plotting updates.
  - Inputs: Tk view interface + configs; Outputs: triggers optimizer/orchestrator, updates GUI state.
  - Dependencies: `OptimizationOrchestrator`, `EnhancedMultiObjectiveOptimizer`, utils.
  - Pipeline role: user-facing orchestration layer.
  - Status: experimental; Docs: thorough class docstring; Tests: missing.
- `orchestrator.py`
  - Types: `OptimizationOrchestrator`, `OptimizationContext` enum, `OptimizationRequest`, caches, parallel engines.
  - Purpose: hybrid sequential/parallel execution, caching, background evaluation.
  - Pipeline role: wraps base optimizer for scheduling suggestions, batch execution, what-if analysis.
  - Status: experimental; Docs: rich docstring; Tests: missing (no coverage of concurrency).
- `modern_acquisition_core.py`
  - Functions: `create_modern_acquisition_function`, GP builders, qNEHVI/qLogEI setup, fallback LogEI.
  - Purpose: optional modern acquisition drop-in using BoTorch qNEHVI/qLogEI, Unified Exponential Kernel if available.
  - Pipeline role: alternative acquisition path called inside `optimizer.py`.
  - Status: experimental; Docs: yes; Tests: missing.
- `advanced_sglbo_optimizer.py`
  - Classes: `AdvancedSGLBOOptimizer`, gradient/line-search enums, configs/results.
  - Purpose: gradient-guided stochastic line Bayesian optimisation for screening.
  - Pipeline role: pre-screening stage feeding full BO.
  - Status: experimental; Docs: extensive; Tests: missing.
- `sglbo_controller.py`
  - Manages SGLBO workflows (`SGLBOController`, asynchronous orchestration) bridging GUI, advanced optimizer, performance manager.
  - Status: experimental; Docs: yes; Tests: missing.
- `sglbo_acquisition.py`
  - Provides SGLBO-specific acquisition calculations, gradient aggregation, GPU paths.
  - Status: experimental; Docs: partial; Tests: missing.
- `batch_prediction_optimizer.py`
  - Batch inference utilities (model caching, tensor transforms, GPU support) for what-if scenarios.
  - Status: experimental; Docs: yes; Tests: missing.
- `device_manager.py`
  - Singleton `DeviceManager`, capability dataclasses, device utilities.
  - Inputs: hardware probe; Outputs: `torch.device`, capability metadata.
  - Pipeline role: central device selection for models/tests.
  - Status: experimental; Docs: thorough; Tests: missing.
- `gradient_estimator.py`
  - Implements gradient estimation strategies, bootstrapping, finite differences for SGLBO.
  - Status: experimental; Docs: partial; Tests: missing.
- `line_search_optimizer.py`
  - Line search routines (Armijo, Wolfe) with adaptive step control for gradient-driven stages.
  - Status: experimental; Docs: partial; Tests: missing.
- `hypervolume_calculator.py`
  - `HypervolumeCalculator`, Pareto utilities, GPU/CPU fallback calculations.
  - Pipeline role: analytics/metrics for BO progress.
  - Status: experimental; Docs: yes; Tests: missing.
- `validation_engine.py`
  - `ValidationEngine`, `HypervolumeCalculator`, `EnhancedValidationEngine` for benchmark runs.
  `- Pipeline role: offline validation harness hooking benchmark algorithms & test functions.
  - Status: experimental; Docs: partial; Tests: missing.
- `algorithm_verifier.py`
  - `AlgorithmVerifier`, configs/results dataclasses, parallel execution & statistical checks.
  - Pipeline: wraps validation engine for GUI/CLI verification workflows.
  - Status: experimental; Docs: yes; Tests: missing.
- `benchmark_algorithms.py`, `enhanced_benchmark_algorithms.py`, `fast_benchmark_algorithms.py`, `gpu_benchmark_algorithms.py`, `parallel_benchmark_algorithms.py`
  - Portfolio of baseline algorithms (random search, NSGA-II via pymoo, MOBO variants, GPU/parallel accelerators).
  - Pipeline role: comparative benchmarking invoked via validation widgets/orchestrator.
  - Status: experimental; Docs: docstrings; Tests: missing.
- `whatif_simulation.py`, `parallel_whatif_simulation.py`
  - Scenario simulation engines for exploring alternative strategies with caching/parallel execution.
  - Pipeline role: analytics sidecar for GUI.
  - Status: experimental; Docs: yes; Tests: missing.
- `plot_data_fixer.py`
  - Cleans plotting datasets, repairs NaNs/outliers before visualization.
  - Status: experimental; Docs: partial; Tests: missing.
- `blas_optimizer.py`
  - Applies BLAS configuration tweaks for PyTorch/NumPy to accelerate linear algebra.
  - Status: experimental; Docs: yes; Tests: missing.
- `robust_mobo.py`
  - Provides robust optimization extensions (noise handling, scenario weighting).
  - Status: experimental; Docs: partial; Tests: missing.
- `test_functions.py`
  - GPU-accelerated benchmark functions (`TestFunction` base, `ZDT1`, `ZDT2`, `DTLZ2`), config helpers.
  - Pipeline role: validation/benchmark dataset definitions.
  - Status: experimental; Docs: thorough; Tests: missing.
- `test_function_manager.py`
  - Registry/factory for benchmark functions, metadata helpers.
  - Status: experimental; Docs: partial; Tests: missing.

### GUI Layer (`pymbo/gui`)
- `gui.py`
  - Main Tkinter application: window construction, menus, dashboards, Matplotlib integration, screening dialogs, GPU widgets.
  - Interfaces: accepts controller, manages view state, handles user events, file I/O.
  - Status: experimental (400kB monolith); Docs: minimal; Tests: missing.
- Auxiliary control modules (`advanced_sglbo_controls.py`, `algorithm_verification_widget.py`, `compact_controls.py`, `enhanced_gui_theme.py`, `goal_impact_dashboard.py`, `gpu_acceleration_widget.py`, `gp_slice_controls.py`, `gradient_visualization.py`, `import_wizard.py`, `interactive_screening_window.py`, `model_diagnostics_controls.py`, `movable_controls.py`, `parallel_coordinates_controls.py`, `parallel_optimization_controls.py`, `pareto_controls.py`, `plot_controls.py`, `progress_controls.py`, `response_importance_dialog.py`, `screening_execution_window.py`, `sensitivity_analysis_controls.py`, `surface_3d_controls.py`, `tkinter_theme_integration.py`, `uncertainty_analysis_controls.py`, `window_controls.py`)
  - Purpose: modular Tkinter frames/dialogs for parameter goals, acquisition heatmaps, diagnostics, GPU configuration, screening workflows, sensitivity analysis, progress tracking.
  - Dependencies: Tkinter, Matplotlib, Pandas, NumPy, controller hooks, utils caches.
  - Pipeline role: user interaction surfaces mapping to controller/orchestrator actions and visualization of optimization state.
  - Status: experimental; Docs: docstrings present but inconsistent; Tests: missing across board.

### Screening Subpackage (`pymbo/screening`)
- `__init__.py`: exposes screening APIs (`ScreeningOptimizer`, handlers, results containers).
- `design_space_generator.py`: creates CCD/DoE spaces around optima.
- `parameter_handler.py`: validates/normalizes screening parameters & constraints.
- `screening_optimizer.py`: streamlined SGLBO screening loop with gradient steps and candidate suggestion.
- `screening_results.py`: persistence/analytics for screening runs, summary generation.
- `README.md`: narrative description of SGLBO module (no executable code).
- Status: experimental; Docs: generous top-level docstrings; Tests: missing.

### Utilities (`pymbo/utils`)
- `performance_optimizer.py`: timers, cache classes (`PlotCache`, `DataHasher`, `PerformanceMonitor`), decorators.
- `pkl_converter.py`: CLI utilities for migrating legacy `.pkl` sessions to new schema.
- `plotting.py`: Matplotlib/Seaborn plotting helpers, acquisition heatmaps, Pareto plots (large file ~200k lines; minimal structure; high complexity).
- `scientific_utilities.py`: statistical helpers, validation stubs, scientific constants.
- `sglbo_performance.py`: GPU acceleration, memory managers, caches specific to SGLBO workloads.
- `warnings_config.py`: central warning filters + environment flagging.
- Status: experimental; Docs: partial (some modules top-level docstring only); Tests: missing except implicit use in GUI.

### Tests & Tooling
- `tests/test_launcher_headless.py`: two pytest cases covering launcher headless behavior and missing dependency handling (mocked). Only automated test in repo.
- No fixtures for optimization correctness, kernels, acquisitions, GUI smoke tests.

### Absent / Placeholder Areas
- No `docs/`, `examples/`, `notebooks/`, or `configs/` directories despite references in README; user guidance limited to README.
- `logs/` contains runtime artifact `optimization_enhanced.log`; should be gitignored (currently committed sample).

## Pipeline & Workflow Map
1. **Problem definition**: GUI/import collects parameter & response configs (`gui.py` � `SimpleController.start_new_optimization`). Parameters normalized via `SimpleParameterTransformer` (`pymbo/core/optimizer.py`).
2. **Search space encoding**: transformer encodes continuous/discrete/categorical spaces; constraints parsed via string validator (`validate_constraint_expression`).
3. **Initial design**: random or Latin Hypercube sampling (`_generate_random_samples`, `_generate_doe_samples`). Screening path can use SGLBO (`pymbo/core/sglbo_controller.py`, `pymbo/screening`).
4. **Surrogate modelling**: Gaussian Processes per objective (`_build_models` using `SingleTaskGP`/`ModelListGP`, kernels from `create_kernel_for_parameters`, optional unified kernel, data subsampling via `OptimizationDataManager`).
5. **Acquisition computation**: modern path `create_modern_acquisition_function` � qLogEI/qLogNEHVI, fall back to EHVI/LogEI/chebyshev scalarized EI; constraint aware via `parameter_constraints` (range/target heuristics).
6. **Acquisition optimisation**: `optimize_acqf` with adaptive restarts/raw samples (`_optimize_acquisition_function`), caching for fast-validation mode, BLAS tweaks.
7. **Constraints & post-processing**: `tensor_to_params` reconverts suggestions, constraint enforcement heuristics clamp range goals; discrete/categorical recovered per transformer.
8. **Experiment loop orchestration**: `OptimizationOrchestrator` schedules sequential/parallel requests, caches models (`ModelCache`), integrates parallel pools for benchmarking/what-if.
9. **Evaluation ingestion**: results fed via `add_experimental_data` (handles baseline vs optimisation iterations, sliding window subsampling, hypervolume calculation, iteration history).
10. **Analytics & reporting**: hypervolume metrics, Pareto front extraction (`hypervolume_calculator`), dashboards (`goal_impact_dashboard`, `progress_controls`), exports via controller.
11. **Logging & persistence**: logging configured in `pymbo/launcher.py` (file + stdout). Session states saved via controller (pickle) and `pkl_converter` for migration.

## Verification Findings

### Scientific Correctness
- `pymbo/core/optimizer.py:233` � `SimpleParameterTransformer.params_to_tensor` silently defaults missing parameter entries to 0 and normalises discrete values via linear interpolation of numeric bounds. This breaks non-uniform discrete sets and masks user input errors, leading to invalid candidate evaluation and biased surrogate training.
- `pymbo/core/optimizer.py:356` � constraint enforcement for "Range" goals clamps suggestions but never validates that enforced values satisfy original discrete/categorical domains, risking infeasible lab suggestions.
- `pymbo/core/optimizer.py:1200` � `_calculate_adaptive_reference_point` replaces NaN entries with constant `2.0`, which violates the requirement that reference points be dominated (should be below transformed objective values). This can flip hypervolume sign and destabilise EHVI/qNEHVI when objectives are negated for minimisation.
- `pymbo/core/optimizer.py:1898` � modern acquisition path rebuilds a fresh GP via `create_modern_acquisition_function` using already transformed `train_Y` but discards the existing fitted model state (hyperparameters, warm starts). This doubles fit cost per iteration and risks divergent kernel hyperparameters compared to suggestions ultimately returned by `_build_models`.
- `pymbo/core/optimizer.py:2024` � fallback to scalarised qEI assumes objective directions already applied to weights but does not re-standardise objectives; mixing negated minimisation targets with positive weights can invert the scalarisation objective.
- `pymbo/core/modern_acquisition_core.py:64` � imports `UnifiedExponentialKernel` from `unified_kernel`, a dependency absent from repository/requirements. The code silently falls back to Matern without exposing that mixed-variable kernels are unavailable, negating advertised mixed-variable support.
- SGLBO stack (`pymbo/core/advanced_sglbo_optimizer.py`, `sglbo_acquisition.py`, `gradient_estimator.py`) implements custom gradient and line search logic without unit tests or analytical checks; numerical stability (step clipping, convergence criteria) is unverified.

### Reproducibility
- Random seed handling only sets `torch.manual_seed` and `np.random.seed` (`pymbo/core/optimizer.py:640`); Python `random` and subprocess seeds remain uncontrolled, and orchestrator parallel pools spawn processes with default RNG states.
- No deterministic flags for PyTorch/BoTorch (e.g., `torch.use_deterministic_algorithms`), and CUDA determinism controls are absent in `device_manager.py`.
- Session metadata (library versions, seeds, system info) not persisted with exported optimisation sessions; `pkl_converter.py` lacks schema version stamping.
- Requirements use wide `>=` pins; no lockfile/conda environment export or optional extras for GPU/cupy/unified kernel, making scientific reproducibility fragile.

### Performance & Scalability
- `pymbo/core/optimizer.py:1695` caches acquisition candidates but never invalidates cache when new data alters the posterior outside fast-validation mode; stale suggestions may leak into production runs.
- `pymbo/core/orchestrator.py` spins up both process and thread pools eagerly; no lifecycle management when GUI closes, risking leaked workers and memory pressure.
- `pymbo/utils/plotting.py` (~200k lines) mixes heavy Matplotlib rendering logic with caching in pure Python without profiling; lacks vectorisation and continues to recompute expensive plots for large designs.
- GPU acceleration paths rely on optional `cupy`/CUDA availability but do not check tensor device consistency when falling back (e.g., `test_functions.py` switching between CPU/GPU arrays without `.to()` conversions for baseline arrays).

### API & Usability
- Public API exports only `EnhancedMultiObjectiveOptimizer` and `SimpleController`; newer `EfficientMultiObjectiveOptimizer`/SGLBO orchestrators require deep imports, contrary to README messaging.
- Configuration relies on nested dictionaries with implicit keys (`goal`, `range_bounds`, `optimization_weight`) and no validation schema; errors appear late via KeyError or silent defaults.
- CLI (`pymbo/cli.py`) lacks options to run benchmarking/test suites headlessly; `pymbo/launcher.py` includes GUI-first behaviour (Tkinter message boxes), degrading usability for scientific pipelines.
- Logging uses decorative Unicode glyphs (e.g., `?`, `???`) across modules, causing encoding issues in terminals/log aggregators.

### Documentation
- README introduces heavy marketing copy with garbled characters (UTF-8 issues) and lacks practical setup/examples. No API reference, no theory sections, and SGLBO README is orphaned from main docs.
- Module docstrings exist but do not follow numpydoc style; parameter/returns not documented consistently, hindering auto-generation of API docs.
- No CONTRIBUTING, CODE_OF_CONDUCT, SECURITY, CITATION, or governance docs.

### Testing
- Only `tests/test_launcher_headless.py` exists; no coverage for optimiser correctness, acquisition gradients, SGLBO flows, GUI smoke tests, or performance regression checks.
- Absence of property-based tests for kernels/acquisitions leaves numerical stability unchecked; no benchmark harness verifying regret/hypervolume metrics.

### Code Quality
- Massive modules (`pymbo/gui/gui.py`, `pymbo/utils/plotting.py`, `pymbo/core/optimizer.py`) exceed 5k lines, hindering review & maintenance.
- No static analysis tooling (ruff/flake8), formatting (black), or typing enforcement (mypy); type hints sporadic.
- Exception handling often swallows errors (e.g., broad `except Exception` in acquisition setup) without surfacing actionable diagnostics.
- Mixed responsibilities (logging setup, device detection, acquisition logic) located in monolithic files instead of cohesive packages.

## Prioritized Recommendations

| Priority | Recommendation | Rationale & Impact | Effort | Acceptance Criteria |
| --- | --- | --- | --- | --- |
| P0 | Fix parameter transformation & constraint enforcement (`pymbo/core/optimizer.py` around lines 225-380) | Ensures discrete/categorical domains and constraints yield valid candidate suggestions, prevents corrupt surrogate training. | High | Unit tests covering discrete grids/categorical sets; transformer raises on missing keys; range enforcement respects discrete sets. |
| P0 | Repair hypervolume/adaptive reference logic (`pymbo/core/optimizer.py:1200`) | Guarantees EHVI/qNEHVI stability and accurate convergence metrics for minimisation problems. | Medium | Deterministic hypervolume tests on synthetic fronts; reference point always dominated; no NaN fallback to positive values. |
| P0 | Establish deterministic execution controls | Seed `random`, torch, numpy; propagate seeds to orchestrator workers; expose seed in public API; document deterministic mode. | Medium | End-to-end test verifying identical suggestions with fixed seed; configuration option to toggle determinism. |
| P1 | Introduce regression tests & property-based checks for optimiser/acquisition stack | Prevents scientific regressions; validates gradients, posterior shapes, acquisition optimisation success. | High | pytest suite covering single/multi-objective runs against benchmark functions (Branin, Hartmann), Hypothesis tests for kernel symmetry/positive definiteness. |
| P1 | Refactor and document public API surface (`pymbo/__init__.py`, controllers) | Clarifies supported entry points, surfaces Efficient MOBO/SGLBO, and defines stability guarantees for consumers. | Medium | Documented API reference; deprecation or exposure plan; README updated with import examples. |
| P1 | Modularise oversized modules (`pymbo/gui/gui.py`, `pymbo/utils/plotting.py`, `pymbo/core/optimizer.py`) | Improves maintainability and enables targeted testing (plots, acquisition, GUI). | High | Modules split into focused packages (<1k lines each), tests updated, no behavioural regression in smoke tests. |
| P1 | Create benchmark harness hooking `validation_engine` with standard problems | Validates scientific claims and provides reproducible performance baselines. | Medium | CLI/pytest benchmark fixture running Branin/Hartmann/Ackley, reporting regret/hypervolume, results stored under `benchmarks/`. |
| P2 | Implement documentation & governance framework | Builds trust for academic/industrial use; enables community contributions. | Medium | CONTRIBUTING, CODE_OF_CONDUCT, SECURITY, CITATION, numpydoc docstrings, API reference build, tutorial notebooks. |
| P2 | Add engineering automation (black, ruff, mypy, pytest-cov, pre-commit, CI) | Enforces code quality and continuous verification. | Medium | Config files present; CI pipeline runs lint/type/test/docs; coverage threshold enforced. |
| P2 | Provide reproducible environments (lockfile, optional Docker) | Simplifies setup and ensures dependency consistency across machines. | Medium | `requirements-lock.txt` or Poetry/pip-tools lock; optional Dockerfile; README instructions. |

## Local Check Recipes
- `python -m pytest` � core unit tests and regression suites (post-rework) with `PYMBO_HEADLESS=1` for GUI-free execution.
- `python -m pytest benchmarks/ --runslow` � benchmark harness producing regret/hypervolume summaries.
- `ruff check pymbo tests` � linting for style and static issues.
- `black --check pymbo tests` � formatting guard.
- `mypy pymbo` � static typing assurance once annotations added.
- `python -m build && twine check dist/*` � packaging sanity before release.
- `sphinx-build -b html docs docs/_build/html` � documentation build (once docs added).
- `python -m pymbo.launcher --headless` � smoke test for CLI entry.
