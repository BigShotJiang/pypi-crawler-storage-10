# PyMBO Public API

This reference documents the supported programmatic entry points that PyMBO
exposes. The goal is to surface a small, stable surface for users embedding
PyMBO in headless pipelines while keeping implementation details private.

## Optimizers

### `pymbo.EnhancedMultiObjectiveOptimizer`
High-level Bayesian optimisation engine. Accepts `params_config` and
`responses_config` dictionaries describing the search space and objectives.
Supports mixed variable types, constraint handling, hypervolume analytics,
and deterministic execution via `deterministic=True`.

### `pymbo.EfficientMultiObjectiveOptimizer`
Drop-in replacement optimised for batched updates and reduced retraining
overhead, built on top of the data management layer.

### `pymbo.AdvancedSGLBOOptimizer`
Gradient-guided screening optimiser for rapid space exploration prior to
full Bayesian optimisation.

### `pymbo.create_kernel_for_parameters(params_config, ard_num_dims)`
Factory that returns the appropriate GPyTorch kernel for mixed-variable
problems, automatically using the Unified Exponential Kernel when available.

## Orchestration

### `pymbo.SimpleController`
MVC controller coordinating the GUI/view layer with an optimizer instance.

### `pymbo.OptimizationOrchestrator`
Hybrid sequential/parallel orchestrator that wraps an optimizer and decides
when to execute requests in parallel. Automatically falls back to sequential
mode when deterministic execution is requested.

## Screening

### `pymbo.ScreeningOptimizer`
Entry point for SGLBO screening workflows, useful for coarse exploration
before switching to the main optimiser.

## Usage Notes

* Use `pymbo.EnhancedMultiObjectiveOptimizer` for most programmatic use cases.
* Set `deterministic=True` and `random_seed=value` to make runs reproducible.
* Access the Unified Exponential Kernel automatically via
  `pymbo.create_kernel_for_parameters`; no direct imports from
  `pymbo.core.unified_kernel` are required.
* GUI-specific modules (e.g. `pymbo.gui`) remain internal and are not part of
  the supported API surface.

## Import Example

```python
from pymbo import (
    EnhancedMultiObjectiveOptimizer,
    OptimizationOrchestrator,
    ScreeningOptimizer,
)

optimizer = EnhancedMultiObjectiveOptimizer(params_config, responses_config)
orchestrator = OptimizationOrchestrator(optimizer)
```

## Benchmark Harness

The `pymbo.benchmarks` module provides small deterministic harnesses for
standard optimisation problems built on the `pymbo.core.test_functions`
module.

* `run_single_objective(problem, iterations=10, seed=None)` – runs a short
  single-objective optimisation loop and returns a `BenchmarkResult` with the
  evaluation history and best objective value.
* `run_multi_objective(problem, iterations=10, seed=None)` – similar interface
  for multi-objective benchmarks; the result includes the raw hypervolume of
  the observed Pareto set.
* `available_single_objective()` and `available_multi_objective()` expose the
  registered problem names (e.g., `Sphere`, `Rosenbrock`, `ZDT1`).

Results are deterministic when a seed is provided, making them suitable for
smoke tests or regression checks in downstream projects.

### Benchmark Metrics

The harness now reports standard metrics:

- `best_curve` and `simple_regret`, `cumulative_regret` for single-objective
  problems when a known optimum is available (Sphere, Rosenbrock, Branin,
  Ackley, Hartmann3/6).
- `hypervolume` and `hv_history` for multi-objective problems (e.g., ZDT1, ZDT2,
  DTLZ2), along with `wall_clock_s`, iteration count, and reproducible seeding.
