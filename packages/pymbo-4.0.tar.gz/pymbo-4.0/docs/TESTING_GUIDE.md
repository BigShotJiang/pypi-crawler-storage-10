# PyMBO Testing Guide

Comprehensive testing framework for PyMBO optimization software, implementing academic standards and industry best practices for mathematical software validation.

## Table of Contents

1. [Overview](#overview)
2. [Test Categories](#test-categories)
3. [Running Tests](#running-tests)
4. [Mathematical Validation](#mathematical-validation)
5. [Performance Benchmarks](#performance-benchmarks)
6. [Integration Testing](#integration-testing)
7. [Adding New Tests](#adding-new-tests)
8. [Continuous Integration](#continuous-integration)
9. [Academic Standards](#academic-standards)
10. [Troubleshooting](#troubleshooting)

## Overview

PyMBO employs a multi-layered testing approach to ensure mathematical correctness, computational reliability, and software quality. Our testing framework is based on established academic standards and industry best practices for optimization software validation.

### Testing Philosophy

- **Mathematical Rigor**: All kernel functions and optimization algorithms are validated against known mathematical properties
- **Reproducibility**: Tests use fixed random seeds and deterministic procedures
- **Scalability**: Performance tests validate computational complexity and memory usage
- **Academic Standards**: Compliance with IEEE 829-2008 and ISO/IEC 25010 standards
- **Benchmark Validation**: Standard test functions from academic literature (CEC, BBOB)

### Test Framework Architecture

```
tests/
├── test_mathematical_kernels.py     # Core mathematical validation
├── test_integration_suite.py        # Component interaction tests
├── test_benchmark_suite.py          # Performance benchmarks
├── test_regression_suite.py         # Regression prevention
├── conftest.py                      # Test configuration
└── reports/                         # Generated test reports
```

## Test Categories

### 1. Mathematical Tests (`@pytest.mark.mathematical`)

Validate fundamental mathematical properties of optimization components:

- **Kernel Properties**: Positive definiteness, symmetry, continuity
- **Numerical Stability**: Precision consistency, extreme value handling
- **Boundary Conditions**: Edge cases and parameter limits
- **Cross-validation**: Comparison with reference implementations

### 2. Unit Tests (`@pytest.mark.unit`)

Test individual functions and methods in isolation:

- **Function-level Testing**: Input/output validation
- **Error Handling**: Exception conditions and edge cases
- **Parameter Validation**: Type checking and bounds verification
- **Code Coverage**: Minimum 70% coverage requirement

### 3. Integration Tests (`@pytest.mark.integration`)

Validate component interactions and data flow:

- **Optimizer Integration**: GUI ↔ Core ↔ Kernels
- **Parameter Transformation**: Mixed variable handling
- **Model Training**: GP model construction and prediction
- **Plotting Integration**: Visualization with optimization data

### 4. Benchmark Tests (`@pytest.mark.benchmark`)

Performance evaluation on standard test problems:

- **Standard Functions**: Rosenbrock, Rastrigin, Ackley, Sphere
- **Multi-objective**: ZDT and DTLZ test suites
- **Mixed Variables**: Custom benchmark problems
- **Scalability**: Performance vs. problem size

### 5. Regression Tests (`@pytest.mark.regression`)

Prevent reintroduction of known bugs:

- **Bug Prevention**: Tests for previously fixed issues
- **API Stability**: Interface consistency checks
- **Performance Regression**: Computational efficiency monitoring
- **Output Validation**: Result consistency across versions

### 6. Property Tests (`@pytest.mark.property`)

Property-based testing with hypothesis library:

- **Generative Testing**: Random input validation
- **Invariant Checking**: Mathematical properties
- **Fuzzing**: Robustness against unexpected inputs
- **Statistical Validation**: Distribution properties

## Running Tests

### Quick Start

```bash
# Install test dependencies
pip install pytest pytest-cov pytest-html pytest-timeout hypothesis

# Run all tests
python run_tests.py --level full

# Run quick development tests
python run_tests.py --level quick

# Run mathematical tests only
python run_tests.py --mathematical
```

### Test Runner Options

```bash
# Run specific categories
python run_tests.py --category mathematical
python run_tests.py --category benchmark
python run_tests.py --category integration

# Run individual test types
python run_tests.py --unit
python run_tests.py --benchmark
python run_tests.py --gpu

# Output options
python run_tests.py --verbose      # Detailed output
python run_tests.py --quiet        # Minimal output
python run_tests.py --skip-slow    # Skip time-consuming tests
```

### Using pytest Directly

```bash
# Run with coverage report
pytest --cov=pymbo --cov-report=html

# Run specific test file
pytest tests/test_mathematical_kernels.py -v

# Run tests with specific markers
pytest -m "mathematical and not slow" -v

# Run with timeout protection
pytest --timeout=300

# Generate HTML report
pytest --html=test_reports/report.html --self-contained-html
```

## Mathematical Validation

### Kernel Function Validation

Mathematical kernels must satisfy fundamental properties:

1. **Positive Semi-Definiteness**
   ```python
   # All eigenvalues ≥ 0
   eigenvals = np.linalg.eigvals(K)
   assert np.all(eigenvals >= -1e-10)
   ```

2. **Symmetry**
   ```python
   # K(x_i, x_j) = K(x_j, x_i)
   assert np.allclose(K, K.T, atol=1e-10)
   ```

3. **Diagonal Values**
   ```python
   # K(x, x) = 1 for normalized kernels
   assert np.allclose(np.diag(K), 1.0, atol=1e-8)
   ```

4. **Lipschitz Continuity**
   ```python
   # Bounded rate of change
   lipschitz_constant = |K(x+δ, y) - K(x, y)| / |δ|
   assert lipschitz_constant < threshold
   ```

### Numerical Stability Tests

1. **Precision Consistency**
   - Test float32 vs float64 consistency
   - Verify no NaN or infinite values
   - Check condition number bounds

2. **Extreme Value Handling**
   - Large parameter values (1e6)
   - Small parameter values (1e-10)
   - Boundary conditions

3. **Iterative Stability**
   - Repeated operations maintain precision
   - Accumulation of numerical errors
   - Matrix inversion stability

### Reference Implementation Comparison

Cross-validate against established libraries:

```python
# Compare with scikit-learn RBF kernel
from sklearn.gaussian_process.kernels import RBF
sklearn_kernel = RBF(length_scale=1.0)
pymbo_kernel = UnifiedExponentialKernel(...)

# Verify similar behavior
assert property_similarity_check(pymbo_kernel, sklearn_kernel)
```

## Performance Benchmarks

### Standard Test Functions

| Function | Domain | Optimum | Characteristics |
|----------|--------|---------|-----------------|
| Sphere | [-5.12, 5.12]ⁿ | f(0,...,0) = 0 | Convex, separable |
| Rosenbrock | [-2.048, 2.048]ⁿ | f(1,...,1) = 0 | Non-convex, narrow valley |
| Rastrigin | [-5.12, 5.12]ⁿ | f(0,...,0) = 0 | Multimodal, many local minima |
| Ackley | [-32.768, 32.768]ⁿ | f(0,...,0) = 0 | Multimodal, nearly flat outer region |
| Griewank | [-600, 600]ⁿ | f(0,...,0) = 0 | Multimodal, product term |

### Multi-objective Test Suites

#### ZDT Test Functions
- **ZDT1**: Convex Pareto front
- **ZDT2**: Non-convex Pareto front
- **ZDT3**: Disconnected Pareto front
- **ZDT4**: Multimodal
- **ZDT6**: Non-uniform density

#### DTLZ Test Functions
- **DTLZ1**: Linear Pareto front
- **DTLZ2**: Concave Pareto front
- **DTLZ3**: Concave with multimodal
- **DTLZ4**: Concave with bias

### Performance Metrics

1. **Convergence Rate**
   ```python
   # Iterations to reach target tolerance
   target_tolerance = 1e-2
   iterations_to_converge = len(convergence_history)
   ```

2. **Solution Quality**
   ```python
   # Distance from known optimum
   error = |best_found - true_optimum|
   relative_error = error / |true_optimum|
   ```

3. **Computational Efficiency**
   ```python
   # Function evaluations per improvement
   efficiency = total_evaluations / improvements
   ```

4. **Scalability Analysis**
   ```python
   # Time complexity with problem size
   time_ratio = time_large / time_small
   size_ratio = size_large / size_small
   complexity_order = log(time_ratio) / log(size_ratio)
   ```

### Performance Acceptance Criteria

- **Sphere Function**: Convergence < 1.0 within 50 iterations
- **Rosenbrock Function**: Convergence < 10.0 within 100 iterations
- **Rastrigin Function**: Convergence < 50.0 within 150 iterations
- **Computation Time**: < O(n³) scaling with problem size
- **Memory Usage**: < 1GB for 500 training points

## Integration Testing

### End-to-End Workflows

1. **Optimization Pipeline**
   ```
   Parameter Definition → Data Input → Model Training →
   Suggestion Generation → Result Visualization
   ```

2. **Multi-objective Workflow**
   ```
   Multi-response Setup → Pareto Front Modeling →
   Compromise Solution Finding → Trade-off Analysis
   ```

3. **Mixed Variable Handling**
   ```
   Mixed Parameter Types → Unified Transformation →
   Kernel Integration → Consistent Predictions
   ```

### Component Integration Points

- **Optimizer ↔ Kernels**: Model building and prediction
- **GUI ↔ Core**: Parameter passing and result display
- **Plotting ↔ Data**: Visualization consistency
- **Import/Export**: Data persistence and configuration

## Adding New Tests

### Test Structure Template

```python
import pytest
import numpy as np
import torch

@pytest.mark.mathematical  # Appropriate marker
class TestNewFeature:
    """Test description and purpose."""

    @pytest.fixture
    def test_config(self):
        """Test configuration setup."""
        return {...}

    def test_specific_property(self, test_config):
        """Test specific mathematical property."""
        # Arrange
        setup_test_environment()

        # Act
        result = execute_test_operation()

        # Assert
        assert mathematical_property_holds(result)
        assert performance_acceptable(result)

        # Log results
        logger.info(f"✓ Test passed: {result}")
```

### Test Categories Guidelines

1. **Mathematical Tests**
   - Focus on mathematical correctness
   - Use analytical validation where possible
   - Include boundary condition testing
   - Verify numerical stability

2. **Performance Tests**
   - Measure computation time and memory
   - Test scalability with problem size
   - Compare against benchmarks
   - Set acceptance criteria

3. **Integration Tests**
   - Test component interactions
   - Validate data flow
   - Check error propagation
   - Verify end-to-end workflows

### Test Data Management

```python
@pytest.fixture(scope="session")
def benchmark_data():
    """Generate reproducible benchmark data."""
    np.random.seed(42)  # Fixed seed for reproducibility
    return generate_test_data()

@pytest.fixture
def temporary_files():
    """Manage temporary test files."""
    with tempfile.TemporaryDirectory() as temp_dir:
        yield Path(temp_dir)
    # Automatic cleanup
```

## Continuous Integration

### GitHub Actions Workflow

```yaml
name: PyMBO Test Suite

on: [push, pull_request]

jobs:
  test:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: [3.8, 3.9, 3.10, 3.11]

    steps:
    - uses: actions/checkout@v3

## Local Quality Checks

Run code quality and typing checks locally before committing:

```bash
# Install tooling
pip install -r requirements-test.txt

# One-time pre-commit setup
pre-commit install

# Format, lint, and type-check all files
ruff check .
black --check .
mypy .

# Or run everything via pre-commit
pre-commit run --all-files
```
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}

    - name: Install dependencies
      run: |
        pip install -e .
        pip install pytest pytest-cov pytest-html

    - name: Run mathematical tests
      run: python run_tests.py --mathematical

    - name: Run integration tests
      run: python run_tests.py --integration

    - name: Upload coverage
      uses: codecov/codecov-action@v3
```

### Test Scheduling

- **Pre-commit**: Quick unit tests (<30s)
- **Pull Request**: Mathematical + Integration tests (<10min)
- **Nightly**: Full test suite including benchmarks (<1hr)
- **Release**: Complete validation including performance regression

## Academic Standards

### IEEE 829-2008 Compliance

- **Test Plan**: Comprehensive test strategy documentation
- **Test Design**: Detailed test case specifications
- **Test Procedures**: Step-by-step execution instructions
- **Test Reports**: Results analysis and interpretation

### ISO/IEC 25010 Quality Model

- **Functional Suitability**: Correctness and appropriateness
- **Performance Efficiency**: Time behavior and resource utilization
- **Compatibility**: Co-existence and interoperability
- **Usability**: User interface and accessibility
- **Reliability**: Maturity and fault tolerance
- **Security**: Confidentiality and integrity
- **Maintainability**: Modularity and testability
- **Portability**: Adaptability and installability

### Documentation Standards

Each test must include:

1. **Purpose**: What is being tested and why
2. **Prerequisites**: Required setup and dependencies
3. **Input Data**: Test parameters and expected ranges
4. **Expected Results**: Acceptance criteria and tolerances
5. **Validation Method**: How correctness is verified
6. **References**: Academic sources and standards

## Troubleshooting

### Common Issues

1. **CUDA Device Errors**
   ```bash
   # Run CPU-only tests
   pytest -m "not gpu"

   # Check CUDA availability
   python -c "import torch; print(torch.cuda.is_available())"
   ```

2. **Memory Issues**
   ```bash
   # Skip memory-intensive tests
   pytest -m "not slow"

   # Run with reduced data size
   pytest --tb=short --maxfail=1
   ```

3. **Numerical Precision**
   ```bash
   # Adjust tolerance for different platforms
   pytest --tolerance=1e-6

   # Use specific random seeds
   pytest --seed=42
   ```

4. **Missing Dependencies**
   ```bash
   # Install all test requirements
   pip install -r requirements-test.txt

   # Check dependency versions
   pip list | grep -E "(pytest|torch|numpy)"
   ```

### Performance Issues

1. **Slow Test Execution**
   - Use `pytest-xdist` for parallel execution
   - Profile individual tests with `pytest-benchmark`
   - Skip expensive tests during development

2. **Memory Consumption**
   - Monitor with `pytest-monitor`
   - Use `gc.collect()` between tests
   - Implement memory cleanup in fixtures

3. **Flaky Tests**
   - Set fixed random seeds
   - Increase tolerance for numerical comparisons
   - Add retry mechanisms for network-dependent tests

### Debugging Tips

```bash
# Run single test with debugging
pytest tests/test_mathematical_kernels.py::TestMathematicalProperties::test_positive_definiteness -v -s

# Debug with pdb
pytest --pdb --pdb-trace

# Capture stdout/stderr
pytest -s --capture=no

# Generate detailed reports
pytest --html=debug_report.html --self-contained-html --tb=long
```

### Getting Help

1. **Test Documentation**: Check test docstrings and comments
2. **Academic References**: Consult cited papers and standards
3. **Issue Tracker**: Report bugs with minimal reproduction cases
4. **Community**: Discuss testing approaches with optimization experts

---

## References

1. Hansen, N., et al. (2009). "Real-Parameter Black-Box Optimization Benchmarking: BBOB-2009." *GECCO Workshop*.
2. Deb, K., et al. (2002). "Scalable Multi-Objective Optimization Test Problems." *Congress on Evolutionary Computation*.
3. IEEE 829-2008: "Standard for Software and System Test Documentation."
4. ISO/IEC 25010:2011: "Systems and Software Quality Requirements and Evaluation."
5. Rasmussen, C.E. & Williams, C.K.I. (2006). *Gaussian Processes for Machine Learning*. MIT Press.
6. Williams, C.K.I. & Rasmussen, C.E. (1996). "Gaussian processes for regression." *NIPS*.

For additional information, see the [PyMBO documentation](../README.md) and [API reference](api/index.md).
