# Advanced State Management - Complete Save/Load System

## Overview

PyMBO now includes a comprehensive state management system that saves **everything** needed to resume your optimization exactly where you left off, including:

- ✅ All experimental data
- ✅ Trained GP models (model parameters)
- ✅ Parameter and response configurations
- ✅ Iteration history and hypervolume metrics
- ✅ Pareto front and optimization state
- ✅ Training tensors and internal state
- ✅ Complete optimization history

## File Formats

### 📦 .pymbo (Recommended - New Advanced Format)

**ZIP archive containing:**
- `metadata.json` - Save timestamp, PyMBO version, device info
- `config.json` - Parameters, responses, constraints configuration
- `opt_state.json` - Iteration history, hypervolume data, Pareto front
- `exp_data.json` - All experimental data points
- `models.pkl` - Trained GP model state dicts (lightweight)
- `tensors.json` - Training tensors (X, Y data)
- `transformer.json` - Parameter transformer state

**Advantages:**
- Complete state preservation
- Trained models included
- Human-readable components (JSON)
- Smaller file size (compressed ZIP)
- Version information for compatibility

### 📄 .pkl (Legacy Format)

**Simple pickle file containing:**
- Configuration and experimental data
- Iteration history
- Hypervolume cache

**Limitations:**
- No trained models
- Models must be retrained on load
- Larger file size

## Usage

### Saving Your Optimization

#### Via GUI

1. Click **"Save Optimization"** button
2. Choose file location
3. Select format:
   - **Save as `.pymbo`** (recommended) - Complete state with models
   - **Save as `.pkl`** - Legacy format without models

#### Via Python API

```python
# Recommended: Save with complete state
optimizer.save_state('my_optimization_2024-01-15.pymbo')

# Or using controller
controller.save_optimization_to_file('my_optimization.pymbo')

# Legacy format (backward compatible)
controller.save_optimization_to_file('my_optimization.pkl')
```

### Loading Your Optimization

#### Via GUI

1. Click **"📂 Load Study"** button
2. Select your saved file (.pymbo or .pkl)
3. All state and models are restored automatically

#### Via Python API

```python
# Load from saved state (class method)
from pymbo import EnhancedMultiObjectiveOptimizer

optimizer = EnhancedMultiObjectiveOptimizer.load_state('my_optimization.pymbo')

# Continue optimization immediately
next_experiments = optimizer.suggest_next_experiment(n_suggestions=3)

# Or using controller
controller.load_optimization_from_file('my_optimization.pymbo')
```

## What Gets Saved

### Experimental Data
- All parameter values
- All response values
- Data quality metadata
- Iteration timestamps

### Models
- **GP Model State Dicts** - Trained Gaussian Process model parameters for each response
- **Kernel Parameters** - Optimized hyperparameters
- **Training Data** - X and Y tensors used for training

### Optimization State
- **Current Iteration** - Where you are in the optimization
- **Baseline Hypervolume** - Initial performance reference
- **Iteration History** - Complete timeline with hypervolume at each step
- **Pareto Front** - Current set of non-dominated solutions

### Configuration
- Parameter definitions (bounds, types, constraints)
- Response definitions (goals, importance)
- General constraints
- Device settings (CPU/GPU)

## Benefits

### 🚀 Resume Instantly
No need to retrain models - they're already optimized and ready to use.

### 💾 Complete Reproducibility
Every aspect of your optimization is preserved bit-for-bit.

### 🔄 Share with Colleagues
Send a single `.pymbo` file with complete optimization state.

### 📊 Audit Trail
Metadata includes save timestamps, version info, and data quality reports.

### ⚡ Performance
- Compressed ZIP format
- Efficient storage
- Fast loading (models don't need retraining)

## Examples

### Complete Workflow

```python
from pymbo import EnhancedMultiObjectiveOptimizer

# 1. Create and run optimization
optimizer = EnhancedMultiObjectiveOptimizer(
    params_config=my_params,
    responses_config=my_responses,
    deterministic=True,
    random_seed=42
)

# Add experimental data
optimizer.add_experimental_data(data_df)

# Run optimization
suggestions = optimizer.suggest_next_experiment(n_suggestions=5)

# 2. Save complete state
optimizer.save_state('experiment_day1.pymbo')
```

**Later, on a different machine or session:**

```python
from pymbo import EnhancedMultiObjectiveOptimizer

# 3. Load and continue from exact point
optimizer = EnhancedMultiObjectiveOptimizer.load_state('experiment_day1.pymbo')

# Models are already trained - ready to go!
print(f"Resuming from iteration {optimizer.optimization_iterations}")
print(f"With {len(optimizer.experimental_data)} experiments")

# Continue immediately
more_suggestions = optimizer.suggest_next_experiment(n_suggestions=5)
```

### Saving at Checkpoints

```python
# Save after each batch of experiments
for batch_num in range(10):
    # Run experiments
    suggestions = optimizer.suggest_next_experiment(n_suggestions=5)
    # ... collect results ...
    optimizer.add_experimental_data(results_df)

    # Save checkpoint
    optimizer.save_state(f'checkpoint_batch_{batch_num}.pymbo')
```

### Comparing Different Runs

```python
# Load multiple optimization runs
run1 = EnhancedMultiObjectiveOptimizer.load_state('run1.pymbo')
run2 = EnhancedMultiObjectiveOptimizer.load_state('run2.pymbo')

# Compare performance
print(f"Run 1 HV: {run1.baseline_hypervolume}")
print(f"Run 2 HV: {run2.baseline_hypervolume}")
```

## Technical Details

### File Structure (.pymbo)

```
my_optimization.pymbo (ZIP archive)
├── metadata.json          # Version, timestamp, device
├── config.json            # Parameters, responses, constraints
├── opt_state.json         # Iteration history, HV, Pareto
├── exp_data.json          # All experimental data
├── models.pkl             # Trained GP model state dicts
├── tensors.json           # Training tensors (X, Y)
└── transformer.json       # Parameter transformer state
```

### Model Restoration Process

1. **Load Configuration** - Read params/responses from `config.json`
2. **Create Optimizer** - Initialize new optimizer with saved config
3. **Restore Data** - Load experimental data from `exp_data.json`
4. **Rebuild Tensors** - Reconstruct training tensors
5. **Restore Models** - Load GP model state dicts and parameters
6. **Verify State** - Validate all components match

### Backward Compatibility

The system automatically detects file format:

```python
# Both formats work transparently
optimizer1 = EnhancedMultiObjectiveOptimizer.load_state('old_format.pkl')
optimizer2 = EnhancedMultiObjectiveOptimizer.load_state('new_format.pymbo')

# Recommended: Always save as .pymbo going forward
optimizer1.save_state('converted.pymbo')
```

## Troubleshooting

### "Failed to load models"
- Models are retrained automatically if loading fails
- Check logs for detailed diagnostics

### "Version mismatch"
- .pymbo files include version metadata
- PyMBO attempts to load anyway with warnings

### "CUDA not available"
- Models saved on GPU can be loaded on CPU
- Specify device: `load_state('file.pymbo', device='cpu')`

## Best Practices

1. **Use .pymbo format** for all new saves
2. **Save frequently** during long optimizations
3. **Include dates** in filenames: `experiment_2024-01-15.pymbo`
4. **Keep checkpoints** before major changes
5. **Backup important** optimization states
6. **Check logs** after loading for any warnings

## Performance Comparison

| Aspect | .pymbo (New) | .pkl (Legacy) |
|--------|--------------|---------------|
| File Size | ~2-5 MB | ~3-8 MB |
| Save Time | ~1-2 sec | ~0.5-1 sec |
| Load Time | ~1-2 sec | ~2-5 sec* |
| Model Included | ✅ Yes | ❌ No |
| Reproducibility | ✅ Complete | ⚠️ Partial |

*Legacy format requires model retraining on load

## Migration Guide

### Converting Old Saves to New Format

```python
# Load old pickle file
optimizer = EnhancedMultiObjectiveOptimizer.load_state('old_study.pkl')

# Save in new format with all models
optimizer.save_state('new_study.pymbo')
```

---

**For more information, see:**
- Main documentation: `README.md`
- API reference: `pymbo/__init__.py`
- Examples: `docs/examples/`
