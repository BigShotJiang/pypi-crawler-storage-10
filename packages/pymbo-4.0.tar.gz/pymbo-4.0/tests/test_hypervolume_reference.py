import torch
import pytest

from pymbo.core.optimizer import EnhancedMultiObjectiveOptimizer


def _make_optimizer():
    params_config = {
        "x": {"type": "continuous", "bounds": [0.0, 1.0]},
    }
    responses_config = {
        "f1": {"goal": "Maximize"},
        "f2": {"goal": "Minimize"},
    }
    return EnhancedMultiObjectiveOptimizer(
        params_config, responses_config, fast_validation_mode=True
    )


def test_reference_point_is_strictly_dominated():
    opt = _make_optimizer()
    # Train Y is expected in maximize orientation; negate minimized objective
    Y = torch.tensor([[0.2, -0.8], [0.5, -0.6]], dtype=torch.double)
    ref = opt._calculate_adaptive_reference_point(Y)
    mins = Y.min(dim=0).values
    # Ensure strictly dominated in all dimensions
    assert torch.all(ref < mins), (ref, mins)


def test_hypervolume_monotonicity_and_bounds():
    opt = _make_optimizer()
    # Baseline set
    Y1 = torch.tensor([[0.2, -0.8], [0.5, -0.6]], dtype=torch.double)
    opt.train_Y = Y1
    # objective_names length >= 2 already satisfied in optimizer setup
    hv1 = opt._calculate_hypervolume()
    assert 0.0 <= hv1["normalized_hypervolume"] <= 1.0

    # Add a strictly better point (componentwise >= for maximize orientation)
    Y2 = torch.cat([Y1, torch.tensor([[0.7, -0.4]], dtype=torch.double)], dim=0)
    opt.train_Y = Y2
    hv2 = opt._calculate_hypervolume()

    assert hv2["raw_hypervolume"] >= hv1["raw_hypervolume"]
    assert 0.0 <= hv2["normalized_hypervolume"] <= 1.0
