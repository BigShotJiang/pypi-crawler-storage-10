from importlib import reload

import pymbo


def test_public_api_all_exports():
    expected = {
        "EnhancedMultiObjectiveOptimizer",
        "EfficientMultiObjectiveOptimizer",
        "OptimizationOrchestrator",
        "SimpleController",
        "AdvancedSGLBOOptimizer",
        "ScreeningOptimizer",
        "create_kernel_for_parameters",
        "BenchmarkResult",
        "available_single_objective",
        "available_multi_objective",
        "run_single_objective",
        "run_multi_objective",
    }

    assert set(pymbo.__all__) == expected


def test_core_namespace_matches_top_level():
    import pymbo.core as core

    for name in pymbo.__all__:
        attr_top = getattr(pymbo, name)
        attr_core = getattr(core, name, None)
        if attr_core is not None:
            assert attr_core is attr_top


def test_reload_preserves_exports():
    reload(pymbo)
    assert "EnhancedMultiObjectiveOptimizer" in pymbo.__all__
