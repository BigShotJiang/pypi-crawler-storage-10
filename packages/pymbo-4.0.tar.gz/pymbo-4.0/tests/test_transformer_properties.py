from math import isclose

import pytest

hypothesis = pytest.importorskip("hypothesis")
from hypothesis import given, strategies as st

from pymbo.core.optimizer import SimpleParameterTransformer


PARAMS_CONFIG = {
    "x": {"type": "continuous", "bounds": [0.0, 1.0]},
    "layers": {"type": "discrete", "bounds": [0, 5]},
    "material": {"type": "categorical", "values": ["steel", "aluminum", "ceramic"]},
}


transformer = SimpleParameterTransformer(PARAMS_CONFIG)


@st.composite
def valid_param_draw(draw):
    x = draw(st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False))
    layers = draw(st.integers(min_value=0, max_value=5))
    material = draw(st.sampled_from(PARAMS_CONFIG["material"]["values"]))
    return {"x": x, "layers": layers, "material": material}


@given(valid_param_draw())
def test_params_tensor_roundtrip(values):
    tensor = transformer.params_to_tensor(values)
    restored = transformer.tensor_to_params(tensor)

    assert isclose(restored["x"], values["x"], rel_tol=1e-9, abs_tol=1e-9)
    assert restored["layers"] == values["layers"]
    assert restored["material"] == values["material"]


@given(st.sampled_from(PARAMS_CONFIG["material"]["values"]))
def test_invalid_discrete_inputs_raise(material):
    with pytest.raises(ValueError):
        transformer.params_to_tensor({"x": 0.5, "layers": 2.5, "material": material})


@given(valid_param_draw())
def test_constraint_enforcement_projects_into_domain(values):
    candidate = {
        "x": max(values["x"] + 0.5, 1.5),
        "layers": values["layers"] + 10,
        "material": "titanium",  # not in list
    }

    constrained = transformer.enforce_parameter_constraints(candidate)

    assert 0.0 <= constrained["x"] <= 1.0
    assert constrained["layers"] in range(0, 6)
    assert constrained["material"] in PARAMS_CONFIG["material"]["values"]
