import warnings

import pytest


def test_unified_kernel_available_and_used_for_mixed_variables():
    # Mixed variable configuration: continuous + discrete + categorical
    params = {
        "x": {"type": "continuous", "bounds": [0.0, 1.0]},
        "n": {"type": "discrete", "bounds": [0, 3]},
        "mat": {"type": "categorical", "values": ["a", "b"]},
    }

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        from pymbo.core.optimizer import (
            create_kernel_for_parameters,
            UNIFIED_KERNEL_AVAILABLE,
        )

        kernel = create_kernel_for_parameters(params, ard_num_dims=3)

        # Should not log the fallback warning when unified kernel is available
        fallback_msgs = [
            m for m in w if "Unified Exponential Kernel not available" in str(m.message)
        ]

        if UNIFIED_KERNEL_AVAILABLE:
            assert not fallback_msgs, "Unexpected unified-kernel fallback warning"
            # Type check without importing the class directly
            assert "UnifiedExponentialKernel" in type(kernel).__name__
        else:
            # When truly unavailable, ensure a valid fallback is returned
            assert kernel is not None
