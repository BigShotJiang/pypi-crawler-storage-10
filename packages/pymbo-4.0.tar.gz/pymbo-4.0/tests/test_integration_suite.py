"""
Integration Test Suite for PyMBO

Tests component interactions, data flow, and end-to-end optimization workflows.
Validates that all PyMBO components work together correctly.

Test Categories:
1. Optimizer Integration (GUI ↔ Core ↔ Kernels)
2. Parameter Transformation Pipeline
3. Model Training and Prediction Workflows
4. Plotting and Visualization Integration
5. Data Import/Export Integration
6. Multi-objective Optimization Workflows

References:
- IEEE 829-2008: Standard for Software Test Documentation
- ISO/IEC 25010: Software Quality Model
"""

import pytest
import torch
import numpy as np
import pandas as pd
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Any, Tuple
import warnings
import logging

# Import PyMBO components
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

try:
    from pymbo.core.optimizer import Optimizer
    from pymbo.core.parameter_transformer import ParameterTransformer
    from pymbo.utils.plotting.manager import SimplePlotManager
    from pymbo.core.unified_kernel.utils.parameter_detection import ParameterTypeDetector
    from pymbo.core.unified_kernel.kernels.unified_exponential import UnifiedExponentialKernel
except ImportError as e:
    pytest.skip(f"PyMBO components not available: {e}", allow_module_level=True)

logger = logging.getLogger(__name__)


@pytest.mark.integration
class TestOptimizerIntegration:
    """Test integration between optimizer components."""

    @pytest.fixture
    def sample_configs(self):
        """Standard optimization configurations for testing."""
        return {
            "continuous_optimization": {
                "params": {
                    "temperature": {"type": "continuous", "bounds": [20, 100]},
                    "pressure": {"type": "continuous", "bounds": [1, 10]},
                },
                "responses": {
                    "efficiency": {"type": "continuous", "goal": "Maximize"},
                    "cost": {"type": "continuous", "goal": "Minimize"},
                },
            },
            "mixed_variable_optimization": {
                "params": {
                    "temperature": {"type": "continuous", "bounds": [20, 100]},
                    "material": {"type": "categorical", "bounds": ["steel", "aluminum"]},
                    "cycles": {"type": "discrete", "bounds": [100, 1000]},
                },
                "responses": {
                    "strength": {"type": "continuous", "goal": "Maximize"},
                    "weight": {"type": "continuous", "goal": "Minimize"},
                },
            },
        }

    @pytest.fixture
    def sample_data(self):
        """Generate sample experimental data for testing."""
        np.random.seed(42)  # Reproducible results

        # Continuous optimization data
        continuous_data = []
        for _ in range(20):
            temp = np.random.uniform(20, 100)
            pressure = np.random.uniform(1, 10)

            # Synthetic responses with some correlation
            efficiency = 50 + 0.3 * temp + 2 * pressure + np.random.normal(0, 2)
            cost = 100 - 0.2 * temp - 1.5 * pressure + np.random.normal(0, 3)

            continuous_data.append(
                {"temperature": temp, "pressure": pressure, "efficiency": efficiency, "cost": cost}
            )

        # Mixed variable data
        mixed_data = []
        materials = ["steel", "aluminum"]
        for _ in range(25):
            temp = np.random.uniform(20, 100)
            material = np.random.choice(materials)
            cycles = np.random.randint(100, 1001)

            # Material effect
            material_effect = 10 if material == "steel" else 5

            strength = 200 + 0.5 * temp + material_effect + 0.01 * cycles + np.random.normal(0, 5)
            weight = 50 + 0.1 * temp + (2 if material == "steel" else 1) + np.random.normal(0, 1)

            mixed_data.append(
                {
                    "temperature": temp,
                    "material": material,
                    "cycles": cycles,
                    "strength": strength,
                    "weight": weight,
                }
            )

        return {"continuous": pd.DataFrame(continuous_data), "mixed": pd.DataFrame(mixed_data)}

    def test_end_to_end_continuous_optimization(self, sample_configs, sample_data):
        """Test complete continuous optimization workflow."""
        config = sample_configs["continuous_optimization"]
        data = sample_data["continuous"]

        # Initialize optimizer
        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add experimental data
        for _, row in data.iterrows():
            optimizer.add_experimental_data(row.to_dict())

        # Verify data integration
        assert len(optimizer.experimental_data) == len(data)
        assert all(
            col in optimizer.experimental_data.columns
            for col in ["temperature", "pressure", "efficiency", "cost"]
        )

        # Test model building
        optimizer._build_models()
        models = optimizer.get_response_models()

        assert "efficiency" in models
        assert "cost" in models
        assert models["efficiency"] is not None
        assert models["cost"] is not None

        # Test prediction
        test_point = {"temperature": 50, "pressure": 5}
        predictions = optimizer.predict(test_point)

        assert "efficiency" in predictions
        assert "cost" in predictions
        assert isinstance(predictions["efficiency"], (int, float))
        assert isinstance(predictions["cost"], (int, float))

        # Test suggestion
        suggestion = optimizer.suggest_next_experiment()
        assert "temperature" in suggestion
        assert "pressure" in suggestion
        assert 20 <= suggestion["temperature"] <= 100
        assert 1 <= suggestion["pressure"] <= 10

        logger.info("✓ End-to-end continuous optimization workflow completed")

    def test_mixed_variable_optimization_integration(self, sample_configs, sample_data):
        """Test optimization with mixed variable types."""
        config = sample_configs["mixed_variable_optimization"]
        data = sample_data["mixed"]

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add experimental data
        for _, row in data.iterrows():
            optimizer.add_experimental_data(row.to_dict())

        # Verify categorical handling
        assert len(optimizer.experimental_data) == len(data)
        materials_in_data = set(optimizer.experimental_data["material"].unique())
        expected_materials = set(config["params"]["material"]["bounds"])
        assert materials_in_data.issubset(expected_materials)

        # Test model building with mixed variables
        optimizer._build_models()
        models = optimizer.get_response_models()

        assert len(models) == 2
        assert all(model is not None for model in models.values())

        # Test prediction with mixed variables
        test_point = {"temperature": 60, "material": "steel", "cycles": 500}
        predictions = optimizer.predict(test_point)

        assert len(predictions) == 2
        assert all(isinstance(pred, (int, float)) for pred in predictions.values())

        # Test suggestion with mixed variables
        suggestion = optimizer.suggest_next_experiment()

        assert "temperature" in suggestion
        assert "material" in suggestion
        assert "cycles" in suggestion
        assert suggestion["material"] in config["params"]["material"]["bounds"]
        assert isinstance(suggestion["cycles"], int)

        logger.info("✓ Mixed variable optimization integration completed")

    def test_parameter_transformation_pipeline(self, sample_configs):
        """Test parameter transformation integration."""
        config = sample_configs["mixed_variable_optimization"]

        # Test transformer creation
        transformer = ParameterTransformer(config["params"])
        detector = ParameterTypeDetector(config["params"])

        # Test parameter to tensor conversion
        test_params = {"temperature": 60, "material": "steel", "cycles": 500}
        tensor = transformer.params_to_tensor(test_params)

        assert torch.is_tensor(tensor)
        assert tensor.dim() == 1
        assert tensor.shape[0] == len(config["params"])

        # Test tensor to parameter conversion
        recovered_params = transformer.tensor_to_params(tensor)

        assert "temperature" in recovered_params
        assert "material" in recovered_params
        assert "cycles" in recovered_params

        # Check approximate equality for continuous/discrete
        assert abs(recovered_params["temperature"] - test_params["temperature"]) < 1e-6
        assert abs(recovered_params["cycles"] - test_params["cycles"]) < 1
        assert recovered_params["material"] == test_params["material"]

        logger.info("✓ Parameter transformation pipeline integration completed")

    def test_kernel_optimizer_integration(self, sample_configs):
        """Test kernel integration with optimizer."""
        config = sample_configs["continuous_optimization"]

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add minimal data for model building
        test_data = [
            {"temperature": 30, "pressure": 2, "efficiency": 45, "cost": 95},
            {"temperature": 70, "pressure": 8, "efficiency": 65, "cost": 75},
            {"temperature": 50, "pressure": 5, "efficiency": 55, "cost": 85},
        ]

        for data_point in test_data:
            optimizer.add_experimental_data(data_point)

        # Build models and verify kernel integration
        optimizer._build_models()
        models = optimizer.get_response_models()

        # Test that models use unified kernel
        for response_name, model in models.items():
            assert hasattr(model, "covar_module")
            # Verify model can make predictions
            test_point = {"temperature": 60, "pressure": 6}
            tensor = optimizer.parameter_transformer.params_to_tensor(test_point)

            with torch.no_grad():
                prediction = model(tensor.unsqueeze(0))
                assert torch.is_tensor(prediction.mean)
                assert not torch.isnan(prediction.mean).any()

        logger.info("✓ Kernel-optimizer integration completed")


@pytest.mark.integration
class TestPlottingIntegration:
    """Test integration of plotting components with optimization data."""

    @pytest.fixture
    def optimizer_with_data(self):
        """Create optimizer with sample data for plotting tests."""
        config = {
            "params": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [0, 1]},
            },
            "responses": {"y1": {"type": "continuous", "goal": "Maximize"}},
        }

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add grid of test data
        np.random.seed(42)
        for i in range(25):
            x1 = np.random.uniform(0, 1)
            x2 = np.random.uniform(0, 1)
            y1 = np.sin(2 * np.pi * x1) * np.cos(2 * np.pi * x2) + np.random.normal(0, 0.1)

            optimizer.add_experimental_data({"x1": x1, "x2": x2, "y1": y1})

        optimizer._build_models()
        return optimizer

    def test_plot_manager_integration(self, optimizer_with_data):
        """Test plotting manager integration with optimizer."""
        import matplotlib

        matplotlib.use("Agg")  # Non-interactive backend
        import matplotlib.pyplot as plt

        optimizer = optimizer_with_data
        plot_manager = SimplePlotManager(optimizer)

        # Test GP slice plot creation
        fig, ax = plt.subplots(figsize=(8, 6))

        try:
            plot_manager.create_gp_slice_plot(
                fig=fig,
                canvas=None,
                response_name="y1",
                param1_name="x1",
                param2_name="x2",
                fixed_value=0.5,
            )

            # Verify plot was created
            assert len(fig.get_axes()) > 0
            ax = fig.get_axes()[0]
            assert ax.get_xlabel() != ""
            assert ax.get_ylabel() != ""

        except Exception as e:
            # Log error but don't fail test (plotting can be environment-dependent)
            logger.warning(f"GP slice plot creation failed: {e}")

        plt.close(fig)

        # Test 3D surface plot
        fig = plt.figure(figsize=(10, 8))

        try:
            plot_manager.create_3d_surface_plot(
                fig=fig,
                canvas=None,
                param1_name="x1",
                param2_name="x2",
                surface_mode="individual",
                response_name="y1",
            )

            # Verify 3D plot was created
            assert len(fig.get_axes()) > 0

        except Exception as e:
            logger.warning(f"3D surface plot creation failed: {e}")

        plt.close(fig)

        logger.info("✓ Plot manager integration completed")

    def test_data_visualization_workflow(self, optimizer_with_data):
        """Test complete data visualization workflow."""
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        optimizer = optimizer_with_data

        # Test data availability for plotting
        exp_data = optimizer.experimental_data
        assert len(exp_data) > 0
        assert "x1" in exp_data.columns
        assert "x2" in exp_data.columns
        assert "y1" in exp_data.columns

        # Test model availability for plotting
        models = optimizer.get_response_models()
        assert "y1" in models
        assert models["y1"] is not None

        # Test plotting parameter extraction
        params_config = optimizer.params_config
        continuous_params = [
            name for name, config in params_config.items() if config["type"] == "continuous"
        ]
        assert len(continuous_params) >= 2  # Needed for 2D plots

        logger.info("✓ Data visualization workflow integration completed")


@pytest.mark.integration
class TestDataImportExportIntegration:
    """Test data import/export integration workflows."""

    def test_csv_import_export_workflow(self):
        """Test complete CSV import/export workflow."""
        # Create temporary directory for test files
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create sample CSV data
            sample_data = pd.DataFrame(
                {
                    "temperature": [20, 30, 40, 50, 60],
                    "pressure": [1, 2, 3, 4, 5],
                    "efficiency": [45, 50, 55, 60, 65],
                    "cost": [100, 95, 90, 85, 80],
                }
            )

            csv_file = temp_path / "test_data.csv"
            sample_data.to_csv(csv_file, index=False)

            # Test configuration for the data
            config = {
                "params": {
                    "temperature": {"type": "continuous", "bounds": [20, 60]},
                    "pressure": {"type": "continuous", "bounds": [1, 5]},
                },
                "responses": {
                    "efficiency": {"type": "continuous", "goal": "Maximize"},
                    "cost": {"type": "continuous", "goal": "Minimize"},
                },
            }

            # Initialize optimizer and load data
            optimizer = Optimizer(
                params_config=config["params"], responses_config=config["responses"]
            )

            # Simulate data loading (would normally be done by GUI)
            loaded_data = pd.read_csv(csv_file)
            for _, row in loaded_data.iterrows():
                optimizer.add_experimental_data(row.to_dict())

            # Verify data integration
            assert len(optimizer.experimental_data) == len(sample_data)

            # Test data export
            export_file = temp_path / "exported_data.csv"
            optimizer.experimental_data.to_csv(export_file, index=False)

            # Verify export
            assert export_file.exists()
            exported_data = pd.read_csv(export_file)
            assert len(exported_data) == len(sample_data)
            assert list(exported_data.columns) == list(sample_data.columns)

        logger.info("✓ CSV import/export workflow completed")

    def test_parameter_configuration_persistence(self):
        """Test parameter configuration save/load workflows."""
        import json

        config = {
            "params": {
                "temperature": {"type": "continuous", "bounds": [20, 100], "units": "C"},
                "material": {"type": "categorical", "bounds": ["steel", "aluminum"]},
                "cycles": {"type": "discrete", "bounds": [100, 1000]},
            },
            "responses": {
                "strength": {"type": "continuous", "goal": "Maximize", "units": "MPa"},
                "cost": {"type": "continuous", "goal": "Minimize", "units": "USD"},
            },
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            config_file = Path(temp_dir) / "config.json"

            # Save configuration
            with open(config_file, "w") as f:
                json.dump(config, f, indent=2)

            # Load and verify configuration
            with open(config_file, "r") as f:
                loaded_config = json.load(f)

            assert loaded_config == config

            # Test optimizer initialization with loaded config
            optimizer = Optimizer(
                params_config=loaded_config["params"], responses_config=loaded_config["responses"]
            )

            assert optimizer.params_config == config["params"]
            assert optimizer.responses_config == config["responses"]

        logger.info("✓ Parameter configuration persistence completed")


@pytest.mark.integration
@pytest.mark.slow
class TestMultiObjectiveIntegration:
    """Test multi-objective optimization integration."""

    def test_multi_objective_workflow(self):
        """Test complete multi-objective optimization workflow."""
        config = {
            "params": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [0, 1]},
            },
            "responses": {
                "objective1": {"type": "continuous", "goal": "Maximize"},
                "objective2": {"type": "continuous", "goal": "Minimize"},
            },
        }

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add multi-objective test data (Pareto front)
        np.random.seed(42)
        for _ in range(30):
            x1 = np.random.uniform(0, 1)
            x2 = np.random.uniform(0, 1)

            # Create conflicting objectives
            obj1 = x1 + 0.5 * x2 + np.random.normal(0, 0.1)  # Maximize
            obj2 = (1 - x1) + 0.5 * (1 - x2) + np.random.normal(0, 0.1)  # Minimize

            optimizer.add_experimental_data(
                {"x1": x1, "x2": x2, "objective1": obj1, "objective2": obj2}
            )

        # Test multi-objective model building
        optimizer._build_models()
        models = optimizer.get_response_models()

        assert len(models) == 2
        assert "objective1" in models
        assert "objective2" in models

        # Test multi-objective prediction
        test_point = {"x1": 0.5, "x2": 0.5}
        predictions = optimizer.predict(test_point)

        assert len(predictions) == 2
        assert "objective1" in predictions
        assert "objective2" in predictions

        # Test multi-objective suggestion
        suggestion = optimizer.suggest_next_experiment()

        assert "x1" in suggestion
        assert "x2" in suggestion
        assert 0 <= suggestion["x1"] <= 1
        assert 0 <= suggestion["x2"] <= 1

        logger.info("✓ Multi-objective optimization workflow completed")


if __name__ == "__main__":
    # Run integration tests
    pytest.main([__file__, "-v", "-m", "integration"])
