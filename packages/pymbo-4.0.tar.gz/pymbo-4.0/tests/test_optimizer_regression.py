import pandas as pd
import numpy as np
import torch

from pymbo.core.optimizer import EnhancedMultiObjectiveOptimizer


def _quadratic_peak(x: float) -> float:
    # Maximum at x=0.5 with value 1.0
    return 1.0 - (x - 0.5) ** 2


def _build_single_objective_optimizer(seed: int = 123) -> EnhancedMultiObjectiveOptimizer:
    params_config = {
        "x": {"type": "continuous", "bounds": [0.0, 1.0], "goal": "None"},
    }
    responses_config = {
        "f": {"goal": "Maximize"},
    }
    optimizer = EnhancedMultiObjectiveOptimizer(
        params_config=params_config,
        responses_config=responses_config,
        general_constraints=[],
        random_seed=seed,
        deterministic=True,
        fast_validation_mode=True,
    )
    baseline = pd.DataFrame(
        [
            {"x": 0.0, "f": _quadratic_peak(0.0)},
            {"x": 1.0, "f": _quadratic_peak(1.0)},
        ]
    )
    optimizer.add_experimental_data(baseline)
    return optimizer


def test_single_objective_regression_improves_best_value():
    optimizer = _build_single_objective_optimizer()
    baseline_best = optimizer.experimental_data["f"].max()

    suggestion = optimizer.suggest_next_experiment(n_suggestions=1)[0]
    suggestion_value = suggestion["x"]
    new_eval = _quadratic_peak(suggestion_value)

    optimizer.add_experimental_data(
        pd.DataFrame([{**suggestion, "f": new_eval}]),
        is_optimization_result=True,
    )

    best_value = optimizer.experimental_data["f"].max()
    assert best_value > baseline_best


def test_multi_objective_suggestions_respect_bounds():
    params_config = {
        "x": {"type": "continuous", "bounds": [0.0, 1.0], "goal": "None"},
        "y": {"type": "continuous", "bounds": [-1.0, 1.0], "goal": "None"},
    }
    responses_config = {
        "f1": {"goal": "Maximize"},
        "f2": {"goal": "Minimize"},
    }
    optimizer = EnhancedMultiObjectiveOptimizer(
        params_config=params_config,
        responses_config=responses_config,
        general_constraints=[],
        random_seed=42,
        deterministic=True,
        fast_validation_mode=True,
    )

    data = pd.DataFrame(
        [
            {"x": 0.0, "y": -1.0, "f1": 0.1, "f2": 1.0},
            {"x": 1.0, "y": 1.0, "f1": 0.2, "f2": 0.5},
            {"x": 0.5, "y": 0.0, "f1": 0.5, "f2": 0.2},
        ]
    )
    optimizer.add_experimental_data(data)

    suggestions = optimizer.suggest_next_experiment(n_suggestions=2)
    assert len(suggestions) == 2

    for suggestion in suggestions:
        assert 0.0 <= suggestion["x"] <= 1.0
        assert -1.0 <= suggestion["y"] <= 1.0
