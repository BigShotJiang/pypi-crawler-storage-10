"""
Mathematical Kernel Test Suite for PyMBO

Comprehensive test suite for validating mathematical correctness of kernel implementations.
Based on academic standards and established benchmark practices.

Test Categories:
1. Mathematical Properties (Positive Definiteness, Symmetry)
2. Numerical Stability and Precision
3. Boundary Conditions and Edge Cases
4. Cross-validation with Reference Implementations
5. Performance and Scalability Testing

References:
- Rasmussen & Williams (2006): Gaussian Processes for Machine Learning
- Williams & Rasmussen (1996): Gaussian processes for regression
- Duvenaud (2014): Automatic Model Construction with Gaussian Processes
"""

import pytest
import torch
import numpy as np
import scipy.stats as stats
from scipy.spatial.distance import pdist, squareform
from sklearn.gaussian_process.kernels import RBF, Matern
import warnings
from typing import Dict, List, Tuple, Any
import logging

# Import PyMBO kernel modules
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "pymbo", "core", "unified_kernel"))

from kernels.unified_exponential import UnifiedExponentialKernel
from kernels.distance_functions import DistanceFunctions, UnifiedDistanceComputer
from utils.parameter_detection import ParameterTypeDetector
from utils.transforms import ParameterTransformer

# Configure logging for test output
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

pytestmark = pytest.mark.mathematical  # categorize entire module for mathematical harness

# Test tolerances based on floating point precision
RTOL_SINGLE = 1e-6  # Relative tolerance for float32
RTOL_DOUBLE = 1e-12  # Relative tolerance for float64
ATOL_SINGLE = 1e-7  # Absolute tolerance for float32
ATOL_DOUBLE = 1e-14  # Absolute tolerance for float64


def _get_kernel_device(kernel: torch.nn.Module) -> torch.device:
    """Return the device hosting the kernel parameters."""
    try:
        return next(kernel.parameters()).device
    except StopIteration:
        return torch.device("cpu")


class TestMathematicalProperties:
    """Test fundamental mathematical properties of kernels."""

    @pytest.fixture
    def sample_configs(self):
        """Standard test configurations for different parameter types."""
        return {
            "continuous_only": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [-1, 1]},
                "x3": {"type": "continuous", "bounds": [0, 10]},
            },
            "discrete_only": {
                "n1": {"type": "discrete", "bounds": [1, 10]},
                "n2": {"type": "discrete", "bounds": [5, 50]},
            },
            "categorical_only": {
                "material": {"type": "categorical", "bounds": ["steel", "aluminum", "plastic"]},
                "coating": {"type": "categorical", "bounds": ["none", "polymer", "ceramic"]},
            },
            "mixed": {
                "temperature": {"type": "continuous", "bounds": [20, 100]},
                "material": {"type": "categorical", "bounds": ["steel", "aluminum"]},
                "cycles": {"type": "discrete", "bounds": [100, 1000]},
            },
        }

    @pytest.fixture
    def kernel_instances(self, sample_configs):
        """Create kernel instances for each configuration type."""
        kernels = {}
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        for config_name, config in sample_configs.items():
            try:
                detector = ParameterTypeDetector(config)
                transformer = ParameterTransformer(config)
                kernel = UnifiedExponentialKernel(config).to(device)
                kernels[config_name] = {
                    "kernel": kernel,
                    "detector": detector,
                    "transformer": transformer,
                    "config": config,
                }
            except Exception as e:
                logger.warning(f"Failed to create kernel for {config_name}: {e}")

        return kernels

    def test_positive_definiteness(self, kernel_instances):
        """Test that kernel matrices are positive semi-definite.

        Mathematical Property: K ⪰ 0 (positive semi-definite)
        All eigenvalues must be non-negative.
        """
        for config_name, instance in kernel_instances.items():
            kernel = instance["kernel"]
            transformer = instance["transformer"]

            # Generate test points
            n_points = 20
            test_points = self._generate_test_points(instance, n_points)

            # Convert to tensors
            X = torch.stack([transformer.params_to_tensor(point) for point in test_points])
            X = X.to(_get_kernel_device(kernel))

            # Compute kernel matrix
            K = kernel(X, X).to_dense()
            K_np = K.detach().cpu().numpy()

            # Check positive semi-definiteness
            eigenvals = np.linalg.eigvals(K_np)
            min_eigenval = np.min(eigenvals)

            assert min_eigenval >= -1e-10, (
                f"Kernel {config_name} not positive semi-definite. "
                f"Minimum eigenvalue: {min_eigenval}"
            )

            logger.info(
                f"✓ {config_name}: Positive semi-definite (min eigenval: {min_eigenval:.2e})"
            )

    def test_symmetry(self, kernel_instances):
        """Test that kernel matrices are symmetric.

        Mathematical Property: K(x_i, x_j) = K(x_j, x_i)
        """
        for config_name, instance in kernel_instances.items():
            kernel = instance["kernel"]
            transformer = instance["transformer"]

            # Generate test points
            test_points = self._generate_test_points(instance, 15)
            X = torch.stack([transformer.params_to_tensor(point) for point in test_points])
            X = X.to(_get_kernel_device(kernel))

            # Compute kernel matrix
            K = kernel(X, X).to_dense()
            K_np = K.detach().cpu().numpy()

            # Check symmetry
            symmetry_error = np.max(np.abs(K_np - K_np.T))

            assert symmetry_error < 1e-10, (
                f"Kernel {config_name} not symmetric. " f"Max asymmetry: {symmetry_error}"
            )

            logger.info(f"✓ {config_name}: Symmetric (max error: {symmetry_error:.2e})")

    def test_diagonal_values(self, kernel_instances):
        """Test that diagonal values equal 1 (for normalized kernels).

        Mathematical Property: K(x, x) = 1 for normalized kernels
        """
        for config_name, instance in kernel_instances.items():
            kernel = instance["kernel"]
            transformer = instance["transformer"]

            # Generate test points
            test_points = self._generate_test_points(instance, 10)
            X = torch.stack([transformer.params_to_tensor(point) for point in test_points])
            X = X.to(_get_kernel_device(kernel))

            # Compute kernel matrix
            K = kernel(X, X).to_dense()
            diagonal_values = torch.diag(K).detach().cpu().numpy()

            # Check diagonal values
            expected_diag = np.ones_like(diagonal_values)
            diagonal_error = np.max(np.abs(diagonal_values - expected_diag))

            assert diagonal_error < 1e-8, (
                f"Kernel {config_name} diagonal not normalized. " f"Max error: {diagonal_error}"
            )

            logger.info(f"✓ {config_name}: Diagonal normalized (max error: {diagonal_error:.2e})")

    def test_smoothness_and_continuity(self, kernel_instances):
        """Test kernel smoothness by checking Lipschitz continuity.

        For small perturbations δ, |K(x, y) - K(x+δ, y)| should be bounded.
        """
        for config_name, instance in kernel_instances.items():
            if config_name == "categorical_only":
                continue  # Skip for categorical-only (discrete)

            kernel = instance["kernel"]
            transformer = instance["transformer"]

            # Generate base point
            test_points = self._generate_test_points(instance, 2)
            x1, x2 = test_points[0], test_points[1]

            X1 = transformer.params_to_tensor(x1).to(_get_kernel_device(kernel))
            X2 = transformer.params_to_tensor(x2).to(_get_kernel_device(kernel))

            # Original kernel value
            k_orig = kernel(X1.unsqueeze(0), X2.unsqueeze(0)).to_dense().item()

            # Add small perturbations
            perturbation_scales = [1e-4, 1e-3, 1e-2]
            lipschitz_constants = []

            for scale in perturbation_scales:
                # Perturb x1 slightly
                x1_pert = self._add_small_perturbation(x1, instance["config"], scale)
                X1_pert = transformer.params_to_tensor(x1_pert).to(_get_kernel_device(kernel))

                k_pert = kernel(X1_pert.unsqueeze(0), X2.unsqueeze(0)).to_dense().item()

                # Estimate Lipschitz constant
                kernel_diff = abs(k_orig - k_pert)
                param_diff = scale  # Approximate parameter difference

                if param_diff > 0:
                    lipschitz_constants.append(kernel_diff / param_diff)

            # Check that Lipschitz constants are reasonable (not infinite)
            max_lipschitz = max(lipschitz_constants) if lipschitz_constants else 0

            assert max_lipschitz < 1e6, (
                f"Kernel {config_name} may not be Lipschitz continuous. "
                f"Max Lipschitz constant: {max_lipschitz}"
            )

            logger.info(f"✓ {config_name}: Lipschitz continuous (max L: {max_lipschitz:.2e})")

    def _generate_test_points(self, instance, n_points: int) -> List[Dict]:
        """Generate valid test points for the given configuration."""
        config = instance["config"]
        points = []

        for _ in range(n_points):
            point = {}
            for param_name, param_config in config.items():
                param_type = param_config["type"]
                bounds = param_config["bounds"]

                if param_type == "continuous":
                    point[param_name] = np.random.uniform(bounds[0], bounds[1])
                elif param_type == "discrete":
                    point[param_name] = np.random.randint(bounds[0], bounds[1] + 1)
                elif param_type == "categorical":
                    point[param_name] = np.random.choice(bounds)

            points.append(point)

        return points

    def _add_small_perturbation(self, point: Dict, config: Dict, scale: float) -> Dict:
        """Add small perturbation to continuous/discrete parameters."""
        perturbed = point.copy()

        for param_name, param_config in config.items():
            param_type = param_config["type"]

            if param_type == "continuous":
                bounds = param_config["bounds"]
                range_size = bounds[1] - bounds[0]
                perturbation = np.random.normal(0, scale * range_size)
                new_val = point[param_name] + perturbation
                # Clamp to bounds
                perturbed[param_name] = np.clip(new_val, bounds[0], bounds[1])
            elif param_type == "discrete":
                # Small chance to change discrete value
                if np.random.random() < scale:
                    bounds = param_config["bounds"]
                    perturbed[param_name] = np.random.randint(bounds[0], bounds[1] + 1)
            # Categorical parameters unchanged (discrete nature)

        return perturbed


class TestNumericalStability:
    """Test numerical stability and precision of kernel computations."""

    def test_precision_consistency(self):
        """Test consistency across different floating point precisions."""
        config = {
            "x1": {"type": "continuous", "bounds": [0, 1]},
            "x2": {"type": "continuous", "bounds": [0, 1]},
        }

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)

        # Test points
        test_points = [{"x1": 0.3, "x2": 0.7}, {"x1": 0.8, "x2": 0.2}]

        X = torch.stack([transformer.params_to_tensor(point) for point in test_points])

        # Test with different precisions
        for dtype in [torch.float32, torch.float64]:
            kernel = UnifiedExponentialKernel(config)

            X_typed = X.to(dtype)
            K = kernel(X_typed, X_typed).to_dense()

            # Check for NaN or infinite values
            assert not torch.isnan(K).any(), f"NaN values detected with {dtype}"
            assert not torch.isinf(K).any(), f"Infinite values detected with {dtype}"
            assert torch.all(K >= 0), f"Negative values detected with {dtype}"

            logger.info(f"✓ Precision {dtype}: Numerically stable")

    def test_extreme_values(self):
        """Test kernel behavior with extreme parameter values."""
        config = {
            "x1": {"type": "continuous", "bounds": [-1e6, 1e6]},
            "x2": {"type": "continuous", "bounds": [1e-10, 1e10]},
        }

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        kernel = UnifiedExponentialKernel(config)

        # Extreme test points
        extreme_points = [{"x1": -1e6, "x2": 1e-10}, {"x1": 1e6, "x2": 1e10}, {"x1": 0, "x2": 1}]

        X = torch.stack([transformer.params_to_tensor(point) for point in extreme_points])
        K = kernel(X, X).to_dense()

        # Verify numerical stability
        assert not torch.isnan(K).any(), "NaN values with extreme inputs"
        assert not torch.isinf(K).any(), "Infinite values with extreme inputs"
        assert torch.all(K >= -1e-10), "Unexpected negative values"

        logger.info("✓ Extreme values: Numerically stable")

    def test_condition_number(self):
        """Test condition number of kernel matrices for numerical stability."""
        config = {
            "x1": {"type": "continuous", "bounds": [0, 1]},
            "x2": {"type": "continuous", "bounds": [0, 1]},
        }

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        kernel = UnifiedExponentialKernel(config)

        # Generate points with varying densities
        n_points_list = [5, 10, 20, 50]

        for n_points in n_points_list:
            # Random test points
            test_points = []
            for _ in range(n_points):
                point = {"x1": np.random.uniform(0, 1), "x2": np.random.uniform(0, 1)}
                test_points.append(point)

            X = torch.stack([transformer.params_to_tensor(point) for point in test_points])
            K = kernel(X, X).to_dense()

            # Add small jitter for numerical stability (common practice)
            K_jitter = K + 1e-6 * torch.eye(K.shape[0])

            # Compute condition number
            eigenvals = torch.linalg.eigvals(K_jitter).real
            cond_num = torch.max(eigenvals) / torch.min(eigenvals)

            # Condition number should be reasonable (< 1e12 for double precision)
            assert cond_num < 1e12, f"Poor conditioning with {n_points} points: {cond_num}"

            logger.info(f"✓ Condition number ({n_points} points): {cond_num:.2e}")


class TestCrossValidation:
    """Cross-validate against reference implementations and known results."""

    def test_rbf_kernel_equivalence(self):
        """Compare continuous-only kernels with scikit-learn RBF for equivalence."""
        config = {
            "x1": {"type": "continuous", "bounds": [0, 1]},
            "x2": {"type": "continuous", "bounds": [0, 1]},
        }

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        pymbo_kernel = UnifiedExponentialKernel(config)

        # Generate test points
        test_points = []
        for _ in range(10):
            point = {"x1": np.random.uniform(0, 1), "x2": np.random.uniform(0, 1)}
            test_points.append(point)

        X = torch.stack([transformer.params_to_tensor(point) for point in test_points])
        X_np = X.detach().cpu().numpy()

        # PyMBO kernel matrix
        K_pymbo = pymbo_kernel(X, X).to_dense().detach().cpu().numpy()

        # Scikit-learn RBF kernel (approximate comparison)
        # Note: May need to adjust length_scale for exact equivalence
        sklearn_rbf = RBF(length_scale=1.0)
        K_sklearn = sklearn_rbf(X_np)

        # Compare shapes and basic properties
        assert K_pymbo.shape == K_sklearn.shape, "Shape mismatch"

        # Both should be positive semi-definite
        pymbo_min_eig = np.min(np.linalg.eigvals(K_pymbo))
        sklearn_min_eig = np.min(np.linalg.eigvals(K_sklearn))

        assert pymbo_min_eig >= -1e-10, "PyMBO kernel not PSD"
        assert sklearn_min_eig >= -1e-10, "Sklearn kernel not PSD"

        logger.info("✓ RBF kernel comparison: Basic properties match")

    def test_known_analytical_results(self):
        """Test against known analytical results for simple cases."""
        # Test case: Identical points should give kernel value of 1
        config = {"x": {"type": "continuous", "bounds": [0, 1]}}

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        kernel = UnifiedExponentialKernel(config)

        # Identical points
        point = {"x": 0.5}
        X = transformer.params_to_tensor(point).unsqueeze(0)

        K = kernel(X, X).to_dense()

        # Should be exactly 1 for identical points
        assert torch.abs(K - 1.0) < 1e-10, f"Identical points should give K=1, got {K.item()}"

        # Test case: Very different points should give small kernel values
        point1 = {"x": 0.0}
        point2 = {"x": 1.0}

        X1 = transformer.params_to_tensor(point1).unsqueeze(0)
        X2 = transformer.params_to_tensor(point2).unsqueeze(0)

        K12 = kernel(X1, X2).to_dense()

        # Should be smaller than identical case
        assert K12 < 1.0, f"Different points should give K<1, got {K12.item()}"
        assert K12 > 0.0, f"Kernel should be positive, got {K12.item()}"

        logger.info("✓ Analytical results: Known cases verified")


class TestPerformanceScaling:
    """Test performance characteristics and scalability."""

    def test_computation_time_scaling(self):
        """Test that kernel computation scales reasonably with input size."""
        import time

        config = {
            "x1": {"type": "continuous", "bounds": [0, 1]},
            "x2": {"type": "continuous", "bounds": [0, 1]},
        }

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        kernel = UnifiedExponentialKernel(config)

        sizes = [10, 50, 100, 200]
        times = []

        for n in sizes:
            # Generate test points
            test_points = []
            for _ in range(n):
                point = {"x1": np.random.uniform(0, 1), "x2": np.random.uniform(0, 1)}
                test_points.append(point)

            X = torch.stack([transformer.params_to_tensor(point) for point in test_points])

            # Time the computation
            start_time = time.time()
            K = kernel(X, X).to_dense()
            end_time = time.time()

            computation_time = end_time - start_time
            times.append(computation_time)

            logger.info(f"Size {n}: {computation_time:.4f}s")

        # Check that scaling is reasonable (should be roughly O(n²))
        # Time ratio should be approximately (n₂/n₁)²
        if len(times) >= 2:
            time_ratio = times[-1] / times[0]
            size_ratio = (sizes[-1] / sizes[0]) ** 2

            # Allow for some overhead, but shouldn't be worse than O(n³)
            assert time_ratio < size_ratio * 10, (
                f"Poor scaling: time ratio {time_ratio:.2f}, " f"expected ~{size_ratio:.2f}"
            )

        logger.info("✓ Performance scaling: Reasonable complexity")

    def test_memory_usage(self):
        """Test memory usage for large kernel matrices."""
        import psutil
        import gc

        config = {"x": {"type": "continuous", "bounds": [0, 1]}}

        detector = ParameterTypeDetector(config)
        transformer = ParameterTransformer(config)
        kernel = UnifiedExponentialKernel(config)

        # Measure baseline memory
        gc.collect()
        process = psutil.Process()
        baseline_memory = process.memory_info().rss / 1024 / 1024  # MB

        # Create moderately large kernel matrix
        n_points = 500
        test_points = [{"x": np.random.uniform(0, 1)} for _ in range(n_points)]
        X = torch.stack([transformer.params_to_tensor(point) for point in test_points])

        K = kernel(X, X).to_dense()

        # Measure memory after computation
        peak_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_used = peak_memory - baseline_memory

        # Expected memory: roughly n² * 8 bytes for float64 matrix
        expected_memory = (n_points**2 * 8) / 1024 / 1024  # MB

        # Allow for reasonable overhead (12x to accommodate allocator fragmentation)
        allowed_overhead = 12
        assert memory_used <= expected_memory * allowed_overhead, (
            f"Excessive memory usage: {memory_used:.1f}MB, " f"expected ~{expected_memory:.1f}MB"
        )

        logger.info(f"✓ Memory usage: {memory_used:.1f}MB for {n_points}² matrix")


if __name__ == "__main__":
    # Run all tests
    pytest.main([__file__, "-v", "--tb=short"])
