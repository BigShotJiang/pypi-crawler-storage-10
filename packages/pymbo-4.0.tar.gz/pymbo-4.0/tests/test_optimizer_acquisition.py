import math
import numpy as np
import pandas as pd
import torch

import pytest

from pymbo.core.optimizer import EnhancedMultiObjectiveOptimizer, MODERN_ACQUISITION_AVAILABLE


def sphere_2d(p):
    return float(p["x1"]) ** 2 + float(p["x2"]) ** 2


def zdt1_2d(p):
    # Simplified ZDT1 with 2 variables in [0,1]
    x0 = float(p["x1"])
    x1 = float(p["x2"])
    g = 1.0 + 9.0 * x1  # with n=2, sum over x1 only
    f1 = x0
    f2 = g * (1.0 - math.sqrt(x0 / g))
    return f1, f2


def _make_optimizer_2d_sphere(seed=0):
    params = {
        "x1": {"type": "continuous", "bounds": [-2.0, 2.0], "goal": "None"},
        "x2": {"type": "continuous", "bounds": [-2.0, 2.0], "goal": "None"},
    }
    responses = {"f": {"goal": "Minimize"}}
    opt = EnhancedMultiObjectiveOptimizer(
        params_config=params,
        responses_config=responses,
        random_seed=seed,
        deterministic=True,
        num_restarts=3,
        raw_samples=32,
        fast_validation_mode=True,
        max_gp_points=50,
    )
    return opt


def _make_optimizer_2d_zdt1(seed=0):
    params = {
        "x1": {"type": "continuous", "bounds": [0.0, 1.0], "goal": "None"},
        "x2": {"type": "continuous", "bounds": [0.0, 1.0], "goal": "None"},
    }
    responses = {"f1": {"goal": "Minimize"}, "f2": {"goal": "Minimize"}}
    opt = EnhancedMultiObjectiveOptimizer(
        params_config=params,
        responses_config=responses,
        random_seed=seed,
        deterministic=True,
        num_restarts=3,
        raw_samples=32,
        fast_validation_mode=True,
        max_gp_points=50,
    )
    return opt


def test_single_objective_optimizer_improves_on_sphere():
    opt = _make_optimizer_2d_sphere(seed=123)

    # Initial random/LHS suggestions may be used internally; run a few BO iterations
    best = float("inf")
    history = []
    for _ in range(4):
        suggestion = opt.suggest_next_experiment(n_suggestions=1)[0]
        f = sphere_2d(suggestion)
        best = min(best, f)
        history.append(best)

        df = pd.DataFrame({"x1": [suggestion["x1"]], "x2": [suggestion["x2"]], "f": [f]})
        opt.add_experimental_data(df)

    assert history[-1] <= history[0]


def test_acquisition_is_used_in_suggestion_after_seeding():
    opt = _make_optimizer_2d_sphere(seed=7)

    # Seed with minimal data for model/ACQ building
    seed_points = [
        {"x1": -1.0, "x2": -1.0},
        {"x1": 0.0, "x2": 0.0},
        {"x1": 1.0, "x2": 1.0},
        {"x1": -1.0, "x2": 1.0},
        {"x1": 1.0, "x2": -1.0},
    ]
    df = pd.DataFrame(
        {
            "x1": [p["x1"] for p in seed_points],
            "x2": [p["x2"] for p in seed_points],
            "f": [sphere_2d(p) for p in seed_points],
        }
    )
    opt.add_experimental_data(df)

    # Now the internal acquisition path should be engaged when suggesting
    suggestion = opt.suggest_next_experiment(n_suggestions=1)[0]
    assert all(k in suggestion for k in ("x1", "x2"))
    assert all(np.isfinite([suggestion["x1"], suggestion["x2"]]))


def test_multiobjective_hypervolume_increases_on_zdt1():
    opt = _make_optimizer_2d_zdt1(seed=42)

    best_hv = 0.0
    for _ in range(4):
        suggestion = opt.suggest_next_experiment(n_suggestions=1)[0]
        f1, f2 = zdt1_2d(suggestion)
        df = pd.DataFrame(
            {"x1": [suggestion["x1"]], "x2": [suggestion["x2"]], "f1": [f1], "f2": [f2]}
        )
        opt.add_experimental_data(df)
        hv = opt._calculate_hypervolume()["raw_hypervolume"]
        best_hv = max(best_hv, hv)

    assert best_hv > 0.0
