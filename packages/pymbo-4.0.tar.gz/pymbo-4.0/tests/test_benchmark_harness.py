from pymbo import (
    available_multi_objective,
    available_single_objective,
    run_multi_objective,
    run_single_objective,
)


def test_single_objective_benchmark_smoke():
    result = run_single_objective("Sphere", iterations=3, seed=7)
    assert len(result.history) == 3
    assert "f1" in result.history.columns
    assert "Sphere" in available_single_objective()


def test_multi_objective_benchmark_smoke():
    result = run_multi_objective("ZDT1", iterations=3, seed=7)
    assert len(result.history) == 3
    assert result.hypervolume is not None
    assert "ZDT1" in available_multi_objective()


def test_benchmark_availability_classics():
    singles = set(available_single_objective())
    # Newly added classics
    for name in ("Branin", "Ackley", "Hartmann3", "Hartmann6"):
        assert name in singles


def test_single_objective_metrics_present():
    result = run_single_objective("Rosenbrock", iterations=3, seed=11)
    # Basic metadata
    assert result.wall_clock_s is not None and result.wall_clock_s >= 0.0
    assert result.best_curve is not None and len(result.best_curve) == 3
    # Regret should be non-negative when optimum known
    assert result.simple_regret is None or result.simple_regret >= 0.0
    assert result.cumulative_regret is None or result.cumulative_regret >= 0.0


def test_multi_objective_hv_history_monotone():
    result = run_multi_objective("ZDT1", iterations=4, seed=3)
    if result.hv_history is None:
        return  # early iterations may not yield HV
    hv = result.hv_history
    # Non-decreasing HV over iterations (best-seen curve)
    assert all(hv[i] <= hv[i + 1] for i in range(len(hv) - 1))
