import math

import pandas as pd

from pymbo.core.optimizer import EnhancedMultiObjectiveOptimizer


def _build_optimizer(seed):
    params = {
        "x": {"type": "continuous", "bounds": [0.0, 1.0], "goal": "None"},
    }
    responses = {"f": {"goal": "Maximize"}}
    return EnhancedMultiObjectiveOptimizer(
        params_config=params,
        responses_config=responses,
        general_constraints=[],
        random_seed=seed,
        deterministic=True,
        fast_validation_mode=True,
    )


def test_reset_random_state_reproduces_suggestions():
    optimizer = _build_optimizer(seed=123)
    first = optimizer.suggest_next_experiment(n_suggestions=1)[0]

    optimizer.reset_random_state()
    second = optimizer.suggest_next_experiment(n_suggestions=1)[0]

    assert first == second


def test_different_seeds_yield_different_samples():
    opt1 = _build_optimizer(seed=7)
    opt2 = _build_optimizer(seed=21)

    suggestion1 = opt1.suggest_next_experiment(n_suggestions=1)[0]
    suggestion2 = opt2.suggest_next_experiment(n_suggestions=1)[0]

    assert suggestion1 != suggestion2


def test_deterministic_mode_disables_parallel(monkeypatch):
    optimizer = _build_optimizer(seed=123)

    # Ensure orchestrator forces sequential mode when deterministic
    from pymbo.core.orchestrator import OptimizationOrchestrator

    orchestrator = OptimizationOrchestrator(base_optimizer=optimizer, enable_parallel=True)
    assert not orchestrator.parallel_enabled
