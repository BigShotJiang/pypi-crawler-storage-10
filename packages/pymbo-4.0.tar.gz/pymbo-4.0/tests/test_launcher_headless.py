import logging
from unittest import mock

import pytest


@pytest.fixture(autouse=True)
def minimize_logging_levels():
    logging.getLogger("pymbo").setLevel(logging.CRITICAL)
    yield


def test_headless_main_success(monkeypatch):
    import pymbo.launcher as launcher

    monkeypatch.setattr(launcher, "check_dependencies", lambda: ([], ["numpy"], []))
    monkeypatch.setattr(launcher, "test_enhanced_components", lambda: True)
    monkeypatch.setattr(launcher, "setup_logging", lambda **kwargs: logging.getLogger("pymbo.test"))

    exit_code = launcher.main(["--headless"])
    assert exit_code == 0


def test_headless_main_dependency_failure(monkeypatch):
    import pymbo.launcher as launcher

    monkeypatch.setattr(launcher, "check_dependencies", lambda: (["numpy"], [], []))
    monkeypatch.setattr(launcher, "show_dependency_error", lambda missing_deps, **kwargs: None)
    monkeypatch.setattr(launcher, "setup_logging", lambda **kwargs: logging.getLogger("pymbo.test"))

    exit_code = launcher.main(["--headless"])
    assert exit_code == 1
