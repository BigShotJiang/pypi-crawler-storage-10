"""
Benchmark Test Suite for PyMBO

Performance benchmarks and scalability tests for optimization algorithms.
Based on established benchmark functions and academic standards.

Test Categories:
1. Standard Benchmark Functions (Rosenbrock, Rastrigin, Ackley, etc.)
2. Multi-objective Test Problems (ZDT, DTLZ test suites)
3. Mixed-variable Benchmark Problems
4. Scalability and Performance Tests
5. Algorithm Convergence Analysis
6. Memory Usage and Computational Efficiency

References:
- Hansen et al. (2009): "Real-Parameter Black-Box Optimization Benchmarking"
- Deb et al. (2002): "Scalable Multi-Objective Optimization Test Problems"
- CEC Competition benchmark suites
- BBOB (Black-Box Optimization Benchmarking)
"""

import pytest
import torch
import numpy as np
import time
import psutil
import gc
from typing import Dict, List, Tuple, Callable, Any
import warnings
import logging
from dataclasses import dataclass

# Import PyMBO components
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

try:
    from pymbo.core.optimizer import Optimizer
    from pymbo.core.parameter_transformer import ParameterTransformer
    from pymbo.core.unified_kernel.utils.parameter_detection import ParameterTypeDetector
    from pymbo.core.unified_kernel.kernels.unified_exponential import UnifiedExponentialKernel
except ImportError as e:
    pytest.skip(f"PyMBO components not available: {e}", allow_module_level=True)

logger = logging.getLogger(__name__)


@dataclass
class BenchmarkResult:
    """Container for benchmark test results."""

    function_name: str
    dimensions: int
    iterations: int
    best_value: float
    convergence_history: List[float]
    computation_time: float
    memory_usage: float
    success: bool


class BenchmarkFunctions:
    """Standard benchmark functions for optimization testing."""

    @staticmethod
    def rosenbrock(x: np.ndarray) -> float:
        """Rosenbrock function - classic optimization benchmark.

        Global minimum: f(1, 1, ..., 1) = 0
        Search domain: [-5, 10]^n (typically [-2.048, 2.048]^n)
        """
        return np.sum(100.0 * (x[1:] - x[:-1] ** 2) ** 2 + (1 - x[:-1]) ** 2)

    @staticmethod
    def rastrigin(x: np.ndarray) -> float:
        """Rastrigin function - multimodal benchmark.

        Global minimum: f(0, 0, ..., 0) = 0
        Search domain: [-5.12, 5.12]^n
        """
        A = 10
        n = len(x)
        return A * n + np.sum(x**2 - A * np.cos(2 * np.pi * x))

    @staticmethod
    def ackley(x: np.ndarray) -> float:
        """Ackley function - multimodal benchmark.

        Global minimum: f(0, 0, ..., 0) = 0
        Search domain: [-32.768, 32.768]^n
        """
        a, b, c = 20, 0.2, 2 * np.pi
        n = len(x)
        sum1 = np.sum(x**2)
        sum2 = np.sum(np.cos(c * x))
        return -a * np.exp(-b * np.sqrt(sum1 / n)) - np.exp(sum2 / n) + a + np.exp(1)

    @staticmethod
    def sphere(x: np.ndarray) -> float:
        """Sphere function - simple convex benchmark.

        Global minimum: f(0, 0, ..., 0) = 0
        Search domain: [-5.12, 5.12]^n
        """
        return np.sum(x**2)

    @staticmethod
    def griewank(x: np.ndarray) -> float:
        """Griewank function - multimodal benchmark.

        Global minimum: f(0, 0, ..., 0) = 0
        Search domain: [-600, 600]^n
        """
        sum_sq = np.sum(x**2)
        prod_cos = np.prod(np.cos(x / np.sqrt(np.arange(1, len(x) + 1))))
        return 1 + sum_sq / 4000 - prod_cos

    @staticmethod
    def schwefel(x: np.ndarray) -> float:
        """Schwefel function - deceptive multimodal benchmark.

        Global minimum: f(420.9687, ..., 420.9687) ≈ 0
        Search domain: [-500, 500]^n
        """
        n = len(x)
        return 418.9829 * n - np.sum(x * np.sin(np.sqrt(np.abs(x))))


class MultiObjectiveBenchmarks:
    """Multi-objective benchmark problems."""

    @staticmethod
    def zdt1(x: np.ndarray) -> Tuple[float, float]:
        """ZDT1 test function - convex Pareto front.

        Search domain: [0, 1]^n
        Pareto front: f2 = 1 - sqrt(f1), f1 ∈ [0, 1]
        """
        f1 = x[0]
        g = 1 + 9 * np.sum(x[1:]) / (len(x) - 1)
        h = 1 - np.sqrt(f1 / g)
        f2 = g * h
        return f1, f2

    @staticmethod
    def zdt2(x: np.ndarray) -> Tuple[float, float]:
        """ZDT2 test function - non-convex Pareto front.

        Search domain: [0, 1]^n
        Pareto front: f2 = 1 - (f1)^2, f1 ∈ [0, 1]
        """
        f1 = x[0]
        g = 1 + 9 * np.sum(x[1:]) / (len(x) - 1)
        h = 1 - (f1 / g) ** 2
        f2 = g * h
        return f1, f2

    @staticmethod
    def zdt3(x: np.ndarray) -> Tuple[float, float]:
        """ZDT3 test function - disconnected Pareto front.

        Search domain: [0, 1]^n
        """
        f1 = x[0]
        g = 1 + 9 * np.sum(x[1:]) / (len(x) - 1)
        h = 1 - np.sqrt(f1 / g) - (f1 / g) * np.sin(10 * np.pi * f1)
        f2 = g * h
        return f1, f2

    @staticmethod
    def dtlz1(x: np.ndarray, m: int = 3) -> List[float]:
        """DTLZ1 test function - scalable multi-objective.

        Args:
            x: Decision variables
            m: Number of objectives

        Search domain: [0, 1]^n
        """
        n = len(x)
        k = n - m + 1

        g = 100 * (k + np.sum((x[m - 1 :] - 0.5) ** 2 - np.cos(20 * np.pi * (x[m - 1 :] - 0.5))))

        objectives = []
        for i in range(m):
            f = 0.5 * (1 + g)
            for j in range(m - 1 - i):
                f *= x[j]
            if i > 0:
                f *= 1 - x[m - 1 - i]
            objectives.append(f)

        return objectives


@pytest.mark.benchmark
@pytest.mark.slow
class TestStandardBenchmarks:
    """Test PyMBO performance on standard benchmark functions."""

    @pytest.fixture
    def benchmark_configs(self):
        """Configurations for different benchmark problems."""
        return {
            "sphere_2d": {
                "function": BenchmarkFunctions.sphere,
                "params": {
                    "x1": {"type": "continuous", "bounds": [-5.12, 5.12]},
                    "x2": {"type": "continuous", "bounds": [-5.12, 5.12]},
                },
                "optimal_value": 0.0,
                "optimal_point": {"x1": 0.0, "x2": 0.0},
            },
            "rosenbrock_2d": {
                "function": BenchmarkFunctions.rosenbrock,
                "params": {
                    "x1": {"type": "continuous", "bounds": [-2.048, 2.048]},
                    "x2": {"type": "continuous", "bounds": [-2.048, 2.048]},
                },
                "optimal_value": 0.0,
                "optimal_point": {"x1": 1.0, "x2": 1.0},
            },
            "rastrigin_2d": {
                "function": BenchmarkFunctions.rastrigin,
                "params": {
                    "x1": {"type": "continuous", "bounds": [-5.12, 5.12]},
                    "x2": {"type": "continuous", "bounds": [-5.12, 5.12]},
                },
                "optimal_value": 0.0,
                "optimal_point": {"x1": 0.0, "x2": 0.0},
            },
            "ackley_2d": {
                "function": BenchmarkFunctions.ackley,
                "params": {
                    "x1": {"type": "continuous", "bounds": [-32.768, 32.768]},
                    "x2": {"type": "continuous", "bounds": [-32.768, 32.768]},
                },
                "optimal_value": 0.0,
                "optimal_point": {"x1": 0.0, "x2": 0.0},
            },
        }

    def test_sphere_function_optimization(self, benchmark_configs):
        """Test optimization on simple sphere function."""
        config = benchmark_configs["sphere_2d"]
        result = self._run_optimization_benchmark(
            config, "sphere", max_iterations=50, target_tolerance=1e-2
        )

        # Sphere function should be easy to optimize
        assert result.success, f"Sphere optimization failed: best_value={result.best_value}"
        assert result.best_value < 1.0, f"Poor convergence on sphere function: {result.best_value}"

        logger.info(f"✓ Sphere function: {result.best_value:.6f} in {result.computation_time:.2f}s")

    def test_rosenbrock_function_optimization(self, benchmark_configs):
        """Test optimization on Rosenbrock function."""
        config = benchmark_configs["rosenbrock_2d"]
        result = self._run_optimization_benchmark(
            config, "rosenbrock", max_iterations=100, target_tolerance=1e-1
        )

        # Rosenbrock is more challenging but should converge
        assert result.best_value < 10.0, f"Poor convergence on Rosenbrock: {result.best_value}"

        logger.info(
            f"✓ Rosenbrock function: {result.best_value:.6f} in {result.computation_time:.2f}s"
        )

    def test_rastrigin_function_optimization(self, benchmark_configs):
        """Test optimization on multimodal Rastrigin function."""
        config = benchmark_configs["rastrigin_2d"]
        result = self._run_optimization_benchmark(
            config, "rastrigin", max_iterations=150, target_tolerance=1.0
        )

        # Rastrigin is multimodal, more challenging
        assert result.best_value < 50.0, f"Poor convergence on Rastrigin: {result.best_value}"

        logger.info(
            f"✓ Rastrigin function: {result.best_value:.6f} in {result.computation_time:.2f}s"
        )

    def test_ackley_function_optimization(self, benchmark_configs):
        """Test optimization on Ackley function."""
        config = benchmark_configs["ackley_2d"]
        result = self._run_optimization_benchmark(
            config, "ackley", max_iterations=100, target_tolerance=1e-1
        )

        # Ackley should converge to near-zero
        assert result.best_value < 5.0, f"Poor convergence on Ackley: {result.best_value}"

        logger.info(f"✓ Ackley function: {result.best_value:.6f} in {result.computation_time:.2f}s")

    def _run_optimization_benchmark(
        self,
        config: Dict,
        function_name: str,
        max_iterations: int = 100,
        target_tolerance: float = 1e-2,
    ) -> BenchmarkResult:
        """Run optimization benchmark and return results."""

        # Setup optimizer
        responses_config = {"objective": {"type": "continuous", "goal": "Minimize"}}

        optimizer = Optimizer(params_config=config["params"], responses_config=responses_config)

        # Track performance
        start_time = time.time()
        start_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB

        convergence_history = []
        best_value = float("inf")

        # Initial sampling with Latin Hypercube or random
        np.random.seed(42)  # Reproducible results

        for iteration in range(max_iterations):
            # Get suggestion
            if iteration == 0:
                # Initial points
                suggestions = self._generate_initial_points(config["params"], n_points=5)
            else:
                suggestions = [optimizer.suggest_next_experiment()]

            # Evaluate suggestions
            for suggestion in suggestions:
                # Convert to numpy array for benchmark function
                x_array = np.array([suggestion[key] for key in sorted(config["params"].keys())])

                # Evaluate benchmark function
                objective_value = config["function"](x_array)

                # Add to optimizer
                data_point = suggestion.copy()
                data_point["objective"] = objective_value
                optimizer.add_experimental_data(data_point)

                # Track best value
                if objective_value < best_value:
                    best_value = objective_value

                convergence_history.append(best_value)

            # Check convergence
            if best_value < target_tolerance:
                break

            # Periodic model rebuilding
            if iteration % 10 == 0 and iteration > 0:
                try:
                    optimizer._build_models()
                except Exception as e:
                    logger.warning(f"Model building failed at iteration {iteration}: {e}")

        # Calculate performance metrics
        end_time = time.time()
        end_memory = psutil.Process().memory_info().rss / 1024 / 1024  # MB

        computation_time = end_time - start_time
        memory_usage = end_memory - start_memory
        success = best_value < target_tolerance

        return BenchmarkResult(
            function_name=function_name,
            dimensions=len(config["params"]),
            iterations=len(convergence_history),
            best_value=best_value,
            convergence_history=convergence_history,
            computation_time=computation_time,
            memory_usage=memory_usage,
            success=success,
        )

    def _generate_initial_points(self, params_config: Dict, n_points: int) -> List[Dict]:
        """Generate initial sampling points."""
        points = []

        for _ in range(n_points):
            point = {}
            for param_name, param_config in params_config.items():
                bounds = param_config["bounds"]
                point[param_name] = np.random.uniform(bounds[0], bounds[1])
            points.append(point)

        return points


@pytest.mark.benchmark
@pytest.mark.slow
class TestMultiObjectiveBenchmarks:
    """Test multi-objective optimization performance."""

    def test_zdt1_optimization(self):
        """Test ZDT1 multi-objective benchmark."""
        config = {
            "params": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [0, 1]},
                "x3": {"type": "continuous", "bounds": [0, 1]},
            },
            "responses": {
                "f1": {"type": "continuous", "goal": "Minimize"},
                "f2": {"type": "continuous", "goal": "Minimize"},
            },
        }

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Sample ZDT1 function
        np.random.seed(42)
        pareto_solutions = []

        for _ in range(50):
            # Generate test point
            x = np.array([np.random.uniform(0, 1) for _ in range(3)])
            f1, f2 = MultiObjectiveBenchmarks.zdt1(x)

            data_point = {"x1": x[0], "x2": x[1], "x3": x[2], "f1": f1, "f2": f2}
            optimizer.add_experimental_data(data_point)
            pareto_solutions.append((f1, f2))

        # Build models
        optimizer._build_models()
        models = optimizer.get_response_models()

        assert "f1" in models
        assert "f2" in models
        assert models["f1"] is not None
        assert models["f2"] is not None

        # Test multi-objective suggestion
        suggestion = optimizer.suggest_next_experiment()
        assert all(0 <= suggestion[f"x{i}"] <= 1 for i in range(1, 4))

        # Analyze Pareto front quality
        pareto_front = np.array(pareto_solutions)
        f1_range = np.ptp(pareto_front[:, 0])  # Peak-to-peak range
        f2_range = np.ptp(pareto_front[:, 1])

        assert f1_range > 0.1, "Insufficient diversity in f1"
        assert f2_range > 0.1, "Insufficient diversity in f2"

        logger.info(f"✓ ZDT1 optimization: {len(pareto_solutions)} Pareto points sampled")

    def test_dtlz1_optimization(self):
        """Test DTLZ1 scalable multi-objective benchmark."""
        config = {
            "params": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [0, 1]},
                "x3": {"type": "continuous", "bounds": [0, 1]},
                "x4": {"type": "continuous", "bounds": [0, 1]},
                "x5": {"type": "continuous", "bounds": [0, 1]},
            },
            "responses": {
                "f1": {"type": "continuous", "goal": "Minimize"},
                "f2": {"type": "continuous", "goal": "Minimize"},
                "f3": {"type": "continuous", "goal": "Minimize"},
            },
        }

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Sample DTLZ1 function
        np.random.seed(42)

        for _ in range(30):
            x = np.array([np.random.uniform(0, 1) for _ in range(5)])
            objectives = MultiObjectiveBenchmarks.dtlz1(x, m=3)

            data_point = {f"x{i+1}": x[i] for i in range(5)}
            for i, obj in enumerate(objectives):
                data_point[f"f{i+1}"] = obj

            optimizer.add_experimental_data(data_point)

        # Build models for 3 objectives
        optimizer._build_models()
        models = optimizer.get_response_models()

        assert len(models) == 3
        assert all(model is not None for model in models.values())

        logger.info("✓ DTLZ1 optimization: 3-objective problem handled")


@pytest.mark.benchmark
class TestScalabilityPerformance:
    """Test computational scalability and performance characteristics."""

    def test_parameter_scaling(self):
        """Test performance scaling with number of parameters."""
        dimensions = [2, 5, 10, 20]
        times = []

        for n_dim in dimensions:
            # Create configuration
            params_config = {
                f"x{i}": {"type": "continuous", "bounds": [0, 1]} for i in range(n_dim)
            }
            responses_config = {"y": {"type": "continuous", "goal": "Minimize"}}

            optimizer = Optimizer(params_config=params_config, responses_config=responses_config)

            # Add sample data
            start_time = time.time()

            for _ in range(20):  # Fixed number of samples
                point = {f"x{i}": np.random.uniform(0, 1) for i in range(n_dim)}
                point["y"] = np.sum([point[f"x{i}"] ** 2 for i in range(n_dim)])  # Sphere function
                optimizer.add_experimental_data(point)

            # Build model and get suggestion
            optimizer._build_models()
            suggestion = optimizer.suggest_next_experiment()

            end_time = time.time()
            elapsed = end_time - start_time
            times.append(elapsed)

            logger.info(f"Dimensions {n_dim:2d}: {elapsed:.3f}s")

        # Check that scaling is reasonable (not exponential)
        if len(times) >= 2:
            max_scaling_factor = times[-1] / times[0]
            dimension_ratio = dimensions[-1] / dimensions[0]

            # Should scale better than O(n³)
            assert max_scaling_factor < dimension_ratio**3, (
                f"Poor parameter scaling: {max_scaling_factor:.2f}x for "
                f"{dimension_ratio:.1f}x parameters"
            )

        logger.info("✓ Parameter scaling test completed")

    def test_data_scaling(self):
        """Test performance scaling with amount of training data."""
        data_sizes = [10, 50, 100, 200]
        times = []

        config = {
            "params": {
                "x1": {"type": "continuous", "bounds": [0, 1]},
                "x2": {"type": "continuous", "bounds": [0, 1]},
            },
            "responses": {"y": {"type": "continuous", "goal": "Minimize"}},
        }

        for n_data in data_sizes:
            optimizer = Optimizer(
                params_config=config["params"], responses_config=config["responses"]
            )

            # Add varying amounts of data
            start_time = time.time()

            for _ in range(n_data):
                x1, x2 = np.random.uniform(0, 1, 2)
                y = (x1 - 0.5) ** 2 + (x2 - 0.5) ** 2  # Simple quadratic
                optimizer.add_experimental_data({"x1": x1, "x2": x2, "y": y})

            # Build model and get suggestion
            optimizer._build_models()
            suggestion = optimizer.suggest_next_experiment()

            end_time = time.time()
            elapsed = end_time - start_time
            times.append(elapsed)

            logger.info(f"Data size {n_data:3d}: {elapsed:.3f}s")

        # Check scaling with data size
        if len(times) >= 2:
            scaling_factor = times[-1] / times[0]
            data_ratio = data_sizes[-1] / data_sizes[0]

            # Should scale better than O(n³)
            assert scaling_factor < data_ratio**3, (
                f"Poor data scaling: {scaling_factor:.2f}x for " f"{data_ratio:.1f}x data points"
            )

        logger.info("✓ Data scaling test completed")

    def test_memory_usage_scaling(self):
        """Test memory usage scaling."""
        gc.collect()  # Clean memory before test

        config = {
            "params": {f"x{i}": {"type": "continuous", "bounds": [0, 1]} for i in range(5)},
            "responses": {"y": {"type": "continuous", "goal": "Minimize"}},
        }

        # Baseline memory
        process = psutil.Process()
        baseline_memory = process.memory_info().rss / 1024 / 1024  # MB

        optimizer = Optimizer(params_config=config["params"], responses_config=config["responses"])

        # Add substantial data
        for _ in range(500):
            point = {f"x{i}": np.random.uniform(0, 1) for i in range(5)}
            point["y"] = np.sum([point[f"x{i}"] ** 2 for i in range(5)])
            optimizer.add_experimental_data(point)

        # Build models
        optimizer._build_models()

        # Check memory usage
        peak_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_used = peak_memory - baseline_memory

        # Should not use excessive memory (allow up to 1GB for 500 points)
        assert memory_used < 1000, f"Excessive memory usage: {memory_used:.1f}MB"

        logger.info(f"✓ Memory usage: {memory_used:.1f}MB for 500 data points")


if __name__ == "__main__":
    # Run benchmark tests
    pytest.main([__file__, "-v", "-m", "benchmark"])
