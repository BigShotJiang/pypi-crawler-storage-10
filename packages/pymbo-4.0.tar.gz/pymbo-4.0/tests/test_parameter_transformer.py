import pytest

from pymbo.core.optimizer import SimpleParameterTransformer


@pytest.fixture
def params_config():
    return {
        "x_cont": {
            "type": "continuous",
            "bounds": [0.0, 1.0],
            "goal": "Range",
            "range_bounds": [0.0, 1.0],
        },
        "x_disc_enum": {
            "type": "discrete",
            "values": [1, 3, 5],
            "goal": "Range",
            "range_bounds": [1, 5],
        },
        "x_disc_bounds": {
            "type": "discrete",
            "bounds": [0, 4],
        },
        "cat": {
            "type": "categorical",
            "values": ["low", "mid", "high"],
        },
    }


@pytest.fixture
def transformer(params_config):
    return SimpleParameterTransformer(params_config)


@pytest.fixture
def valid_params():
    return {
        "x_cont": 0.25,
        "x_disc_enum": 3,
        "x_disc_bounds": 2,
        "cat": "mid",
    }


def _tensor_value(transformer, tensor, name):
    index = transformer.param_names.index(name)
    return tensor[index].item()


def test_params_to_tensor_requires_all_parameters(transformer, valid_params):
    missing = valid_params.copy()
    missing.pop("x_cont")
    with pytest.raises(ValueError, match="x_cont"):
        transformer.params_to_tensor(missing)


def test_params_to_tensor_validates_discrete_choices(transformer, valid_params):
    invalid = valid_params.copy()
    invalid["x_disc_enum"] = 2
    with pytest.raises(ValueError, match="x_disc_enum"):
        transformer.params_to_tensor(invalid)


def test_params_to_tensor_discrete_enum_normalization(transformer, valid_params):
    tensor = transformer.params_to_tensor(valid_params)
    expected = transformer.discrete_index_lookup["x_disc_enum"][valid_params["x_disc_enum"]]
    expected = (
        0.0
        if len(transformer.discrete_choices["x_disc_enum"]) == 1
        else expected / (len(transformer.discrete_choices["x_disc_enum"]) - 1)
    )
    assert _tensor_value(transformer, tensor, "x_disc_enum") == pytest.approx(expected)


def test_params_to_tensor_rejects_non_integer_discrete(transformer, valid_params):
    invalid = valid_params.copy()
    invalid["x_disc_bounds"] = 1.2
    with pytest.raises(ValueError, match="x_disc_bounds"):
        transformer.params_to_tensor(invalid)


def test_validate_parameter_constraints_reports_domain_issue(transformer, valid_params):
    invalid = valid_params.copy()
    invalid["cat"] = "invalid"
    is_valid, violations = transformer.validate_parameter_constraints(invalid)
    assert not is_valid
    assert any("cat" in message for message in violations)


def test_enforce_parameter_constraints_projects_to_domain(transformer, valid_params):
    candidate = {
        "x_cont": -0.1,
        "x_disc_enum": 4,  # Not in allowed set
        "x_disc_bounds": 10,  # Outside bounds
        "cat": "invalid",
    }

    constrained = transformer.enforce_parameter_constraints(candidate)

    # Continuous parameter clamped to lower bound
    assert constrained["x_cont"] == pytest.approx(0.0)

    # Discrete enum snapped to nearest allowed value (3 from [1,3,5])
    assert constrained["x_disc_enum"] in transformer.discrete_choices["x_disc_enum"]
    assert constrained["x_disc_enum"] == 3

    # Discrete bounds clamped to upper bound and converted to int
    assert constrained["x_disc_bounds"] == 4

    # Categorical parameter falls back to first allowed choice
    assert constrained["cat"] == transformer.categorical_choices["cat"][0]
