"""
Desirability plot control panel for the PyMBO GUI.
"""

from __future__ import annotations

import logging
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Any, Callable, Dict, Optional

from .control_panel_style import create_panel_container, create_panel_window

# Import theme constants for consistent styling
from .theme_constants import (
    COLOR_PRIMARY,
    COLOR_SECONDARY,
    COLOR_BACKGROUND,
    COLOR_SURFACE,
    COLOR_ERROR,
    SPACING_SM,
    SPACING_MD,
    FONT_SIZE_BODY,
    FONT_FAMILY_DEFAULT,
)

logger = logging.getLogger(__name__)


class DesirabilityPlotControlPanel:
    """Popup window with controls for Desirability plot configuration."""

    def __init__(
        self,
        parent: tk.Misc,
        plot_type: str,
        params_config: Optional[Dict[str, Dict[str, Any]]] = None,
        responses_config: Optional[Dict[str, Dict[str, Any]]] = None,
        update_callback: Optional[Callable[[], None]] = None,
        export_callback: Optional[Callable[[str, int], None]] = None,
    ) -> None:
        self.parent = parent
        self.plot_type = plot_type
        self.params_config = params_config or {}
        self.responses_config = responses_config or {}
        self.update_callback = update_callback
        self.export_callback = export_callback

        self.window = create_panel_window(
            parent=parent,
            title="Desirability Plot Controls",
            on_close=self.hide,
            geometry="540x640",
            min_size=(520, 520),
        )

        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        container = create_panel_container(self.window)

        self._build_parameter_section(container)
        self._build_response_weights_section(container)
        self._build_settings_section(container)
        self._build_display_section(container)
        self._build_axes_section(container)
        self._build_actions(container)

    def _build_parameter_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Parameter Axes", padding=10)
        frame.pack(fill=tk.X, expand=False, pady=(0, 10))

        param_names = [
            name
            for name, cfg in self.params_config.items()
            if cfg.get("type") in {"continuous", "discrete"}
        ]
        param_names.sort()

        default_x = param_names[0] if param_names else ""
        default_y = param_names[1] if len(param_names) > 1 else default_x

        self.param1_var = tk.StringVar(value=default_x)
        self.param2_var = tk.StringVar(value=default_y)

        ttk.Label(frame, text="X Axis:").grid(row=0, column=0, sticky="w", pady=2)
        self.param1_combo = ttk.Combobox(
            frame,
            values=param_names,
            textvariable=self.param1_var,
            state="readonly",
            width=24,
        )
        self.param1_combo.grid(row=0, column=1, sticky="ew", padx=(8, 0), pady=2)

        ttk.Label(frame, text="Y Axis:").grid(row=1, column=0, sticky="w", pady=2)
        self.param2_combo = ttk.Combobox(
            frame,
            values=param_names,
            textvariable=self.param2_var,
            state="readonly",
            width=24,
        )
        self.param2_combo.grid(row=1, column=1, sticky="ew", padx=(8, 0), pady=2)

        frame.columnconfigure(1, weight=1)

        self.param1_combo.bind("<<ComboboxSelected>>", self._ensure_distinct_params)
        self.param2_combo.bind("<<ComboboxSelected>>", self._ensure_distinct_params)

        if len(param_names) < 2:
            hint = ttk.Label(
                frame,
                text="At least two continuous or discrete parameters are required.",
                foreground=COLOR_ERROR,
            )
            hint.grid(row=2, column=0, columnspan=2, sticky="w", pady=(SPACING_SM, 0))

    def _build_response_weights_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Response Weights", padding=10)
        frame.pack(fill=tk.X, expand=False, pady=(0, 10))

        self.response_weight_vars: Dict[str, tk.DoubleVar] = {}
        if not self.responses_config:
            ttk.Label(
                frame,
                text="Define responses in the main configuration to adjust weights.",
            ).pack(anchor="w")
            return

        for idx, (name, cfg) in enumerate(sorted(self.responses_config.items())):
            weight_default = cfg.get("optimization_weight")
            if weight_default is None:
                weight_default = cfg.get("importance", 1.0)
            try:
                weight_default = float(weight_default)
            except Exception:
                weight_default = 1.0

            weight_var = tk.DoubleVar(value=max(0.0, weight_default))
            self.response_weight_vars[name] = weight_var

            ttk.Label(frame, text=name).grid(row=idx, column=0, sticky="w", pady=2)
            spin = ttk.Spinbox(
                frame,
                from_=0.0,
                to=10.0,
                increment=0.1,
                textvariable=weight_var,
                width=8,
                state="readonly",
            )
            spin.grid(row=idx, column=1, sticky="w", padx=(8, 0), pady=2)

        frame.columnconfigure(1, weight=1)

    def _build_settings_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Computation Settings", padding=10)
        frame.pack(fill=tk.X, expand=False, pady=(0, 10))

        self.resolution_var = tk.IntVar(value=70)
        self.threshold_var = tk.DoubleVar(value=0.7)
        self.aggregation_var = tk.StringVar(value="geometric")
        self.gradient_levels_var = tk.IntVar(value=50)  # Color gradient smoothness
        self.dpi_var = tk.IntVar(value=150)

        ttk.Label(frame, text="Resolution:").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Spinbox(
            frame,
            from_=20,
            to=200,
            increment=5,
            textvariable=self.resolution_var,
            width=6,
        ).grid(row=0, column=1, sticky="w", padx=(8, 16), pady=2)

        ttk.Label(frame, text="Min Desirability:").grid(row=0, column=2, sticky="w", pady=2)
        ttk.Spinbox(
            frame,
            from_=0.0,
            to=1.0,
            increment=0.05,
            textvariable=self.threshold_var,
            width=6,
        ).grid(row=0, column=3, sticky="w", padx=(8, 0), pady=2)

        ttk.Label(frame, text="Gradient Levels:").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Spinbox(
            frame,
            from_=20,
            to=200,
            increment=10,
            textvariable=self.gradient_levels_var,
            width=6,
        ).grid(row=1, column=1, sticky="w", padx=(8, 16), pady=2)

        ttk.Label(frame, text="Aggregation:").grid(row=1, column=2, sticky="w", pady=2)
        agg_combo = ttk.Combobox(
            frame,
            values=["geometric", "arithmetic"],
            textvariable=self.aggregation_var,
            state="readonly",
            width=12,
        )
        agg_combo.grid(row=1, column=3, sticky="w", padx=(8, 0), pady=2)

        ttk.Label(frame, text="Export DPI:").grid(row=2, column=0, sticky="w", pady=2)
        ttk.Spinbox(
            frame,
            from_=72,
            to=600,
            increment=24,
            textvariable=self.dpi_var,
            width=6,
        ).grid(row=1, column=3, sticky="w", padx=(8, 0), pady=2)

        frame.columnconfigure(1, weight=1)

    def _build_display_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Display Options", padding=10)
        frame.pack(fill=tk.X, expand=False, pady=(0, 10))

        self.show_constraints_var = tk.BooleanVar(value=True)
        self.show_data_points_var = tk.BooleanVar(value=True)
        self.show_best_point_var = tk.BooleanVar(value=True)
        self.show_colorbar_var = tk.BooleanVar(value=True)
        self.show_contours_var = tk.BooleanVar(value=True)
        self.colormap_var = tk.StringVar(value="viridis")

        ttk.Checkbutton(
            frame,
            text="Highlight feasible region",
            variable=self.show_constraints_var,
        ).grid(row=0, column=0, sticky="w", pady=2)
        ttk.Checkbutton(
            frame,
            text="Show experimental data",
            variable=self.show_data_points_var,
        ).grid(row=1, column=0, sticky="w", pady=2)
        ttk.Checkbutton(
            frame,
            text="Mark best candidate",
            variable=self.show_best_point_var,
        ).grid(row=2, column=0, sticky="w", pady=2)

        ttk.Checkbutton(
            frame,
            text="Show colorbar",
            variable=self.show_colorbar_var,
        ).grid(row=0, column=1, sticky="w", padx=(20, 0), pady=2)
        ttk.Checkbutton(
            frame,
            text="Show contour lines",
            variable=self.show_contours_var,
        ).grid(row=1, column=1, sticky="w", padx=(20, 0), pady=2)

        ttk.Label(frame, text="Colormap:").grid(row=2, column=1, sticky="w", padx=(20, 0), pady=2)
        ttk.Combobox(
            frame,
            values=["viridis", "plasma", "magma", "cividis", "inferno", "turbo"],
            textvariable=self.colormap_var,
            state="readonly",
            width=12,
        ).grid(row=2, column=1, sticky="e", padx=(0, 8), pady=2)

        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

    def _build_axes_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Axis Ranges", padding=10)
        frame.pack(fill=tk.X, expand=False, pady=(0, 10))

        self.x_min_var = tk.StringVar(value="auto")
        self.x_max_var = tk.StringVar(value="auto")
        self.y_min_var = tk.StringVar(value="auto")
        self.y_max_var = tk.StringVar(value="auto")

        ttk.Label(frame, text="X min:").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Entry(frame, textvariable=self.x_min_var, width=10).grid(row=0, column=1, sticky="w", padx=(6, 16), pady=2)
        ttk.Label(frame, text="X max:").grid(row=0, column=2, sticky="w", pady=2)
        ttk.Entry(frame, textvariable=self.x_max_var, width=10).grid(row=0, column=3, sticky="w", padx=(6, 0), pady=2)

        ttk.Label(frame, text="Y min:").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(frame, textvariable=self.y_min_var, width=10).grid(row=1, column=1, sticky="w", padx=(6, 16), pady=2)
        ttk.Label(frame, text="Y max:").grid(row=1, column=2, sticky="w", pady=2)
        ttk.Entry(frame, textvariable=self.y_max_var, width=10).grid(row=1, column=3, sticky="w", padx=(6, 0), pady=2)

    def _build_actions(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, expand=False, pady=(10, 0))

        refresh_btn = ttk.Button(
            frame,
            text="Refresh Plot",
            command=self._on_refresh,
            state=tk.NORMAL if self.update_callback else tk.DISABLED,
        )
        refresh_btn.pack(side=tk.LEFT)

        export_btn = ttk.Button(
            frame,
            text="Export Plot",
            command=self._on_export,
            state=tk.NORMAL if self.export_callback else tk.DISABLED,
        )
        export_btn.pack(side=tk.LEFT, padx=(10, 0))

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------
    def _ensure_distinct_params(self, _event: Optional[tk.Event] = None) -> None:
        if self.param1_var.get() == self.param2_var.get():
            options = self.param1_combo.cget("values")
            if isinstance(options, (list, tuple)) and len(options) > 1:
                for option in options:
                    if option != self.param1_var.get():
                        self.param2_var.set(option)
                        break

    def _on_refresh(self) -> None:
        if not self.update_callback:
            return
        try:
            self.update_callback()
        except Exception as exc:
            logger.error(f"Failed to trigger desirability refresh: {exc}")
            messagebox.showerror("Desirability", f"Could not refresh plot:\n{exc}")

    def _on_export(self) -> None:
        if not self.export_callback:
            return
        filename = filedialog.asksaveasfilename(
            parent=self.window,
            title="Export Desirability Plot",
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("PDF", "*.pdf"), ("SVG", "*.svg")],
        )
        if not filename:
            return
        dpi = max(72, int(self.dpi_var.get()))
        try:
            self.export_callback(filename, dpi)
        except Exception as exc:
            logger.error(f"Failed to export desirability plot: {exc}")
            messagebox.showerror("Desirability", f"Could not export plot:\n{exc}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def show(self) -> None:
        self.window.deiconify()
        self.window.lift()
        self.window.focus_set()

    def hide(self) -> None:
        self.window.withdraw()

    def is_visible(self) -> bool:
        return self.window.state() != "withdrawn"

    # ------------------------------------------------------------------
    # Data accessors
    # ------------------------------------------------------------------
    def get_display_options(self) -> Dict[str, Any]:
        weights = {
            name: max(0.0, weight_var.get())
            for name, weight_var in self.response_weight_vars.items()
        }

        options: Dict[str, Any] = {
            "param1_name": self.param1_var.get(),
            "param2_name": self.param2_var.get(),
            "resolution": max(20, int(self.resolution_var.get())),
            "min_desirability": min(1.0, max(0.0, float(self.threshold_var.get()))),
            "aggregation": self.aggregation_var.get(),
            "response_weights": weights,
            "show_constraints": bool(self.show_constraints_var.get()),
            "show_data_points": bool(self.show_data_points_var.get()),
            "show_best_point": bool(self.show_best_point_var.get()),
            "show_colorbar": bool(self.show_colorbar_var.get()),
            "show_contours": bool(self.show_contours_var.get()),
            "colormap": self.colormap_var.get(),
            "gradient_levels": max(20, int(self.gradient_levels_var.get())),
        }
        return options

    def get_axis_ranges(self) -> Dict[str, Any]:
        return {
            "x_range": self._parse_range(self.x_min_var, self.x_max_var),
            "y_range": self._parse_range(self.y_min_var, self.y_max_var),
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _parse_range(self, min_var: tk.StringVar, max_var: tk.StringVar) -> Any:
        min_str = (min_var.get() or "").strip()
        max_str = (max_var.get() or "").strip()

        def _parse(value: str) -> Optional[float]:
            if not value or value.lower() == "auto":
                return None
            try:
                return float(value)
            except ValueError:
                return None

        min_val = _parse(min_str)
        max_val = _parse(max_str)
        is_auto = (min_val is None) or (max_val is None)
        return (min_val, max_val, is_auto)


def create_desirability_control_panel(
    parent: tk.Misc,
    plot_type: str,
    params_config: Optional[Dict[str, Dict[str, Any]]] = None,
    responses_config: Optional[Dict[str, Dict[str, Any]]] = None,
    update_callback: Optional[Callable[[], None]] = None,
    export_callback: Optional[Callable[[str, int], None]] = None,
) -> DesirabilityPlotControlPanel:
    """Factory for Desirability plot control panels."""
    panel = DesirabilityPlotControlPanel(
        parent=parent,
        plot_type=plot_type,
        params_config=params_config,
        responses_config=responses_config,
        update_callback=update_callback,
        export_callback=export_callback,
    )
    logger.debug("Desirability control panel instantiated")
    return panel

