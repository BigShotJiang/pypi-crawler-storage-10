"""
PyMBO GUI Theme Constants - Single Source of Truth
===================================================

This module defines all styling constants for the PyMBO Tkinter GUI.
It serves as the central theme system to ensure visual consistency across
all GUI components.

Design Philosophy
-----------------
- Material Design inspired color palette for professional appearance
- WCAG 2.1 AA compliant for accessibility (minimum 9pt fonts, 4.5:1 contrast)
- Consistent spacing scale for predictable layouts
- Semantic color naming for clear intent
- Single source of truth - all GUI files should import from here

Author: Multi-Objective Optimization Laboratory
Version: 2.0.0 - Unified Theme System
Last Updated: 2025-10-12
"""

# ==============================================================================
# PRIMARY COLOR SYSTEM
# ==============================================================================

COLOR_PRIMARY = "#1976D2"  # Material Blue 700 - Main brand color
"""Primary brand color used for key UI elements, active states, and emphasis.
Use for: Primary buttons, selected states, key highlights, active tabs."""

COLOR_PRIMARY_DARK = "#1565C0"  # Material Blue 800 - Hover/pressed states
"""Darker variant of primary color for interactive states.
Use for: Button hover effects, pressed states, darker accents."""

COLOR_PRIMARY_LIGHT = "#E3F2FD"  # Material Blue 50 - Subtle backgrounds
"""Light variant of primary color for subtle emphasis.
Use for: Selected item backgrounds, subtle highlights, info boxes."""


# ==============================================================================
# SECONDARY COLOR SYSTEM
# ==============================================================================

COLOR_SECONDARY = "#424242"  # Material Gray 800 - Secondary text and UI
"""Secondary color for supporting UI elements and muted text.
Use for: Secondary buttons, labels, less important UI elements, borders.

IMPORTANT: This is the AUTHORITATIVE definition. Previously conflicted with
orange (#FF6F00) in ModernTheme class. Gray semantics are clearer for
secondary UI elements."""

COLOR_SECONDARY_DARK = "#212121"  # Material Gray 900
"""Darker secondary for strong contrast.
Use for: Primary text, headers, strong emphasis."""

COLOR_SECONDARY_LIGHT = "#757575"  # Material Gray 600
"""Lighter secondary for subtle text.
Use for: Placeholder text, disabled states, subtle labels."""


# ==============================================================================
# ACCENT COLORS (Semantic)
# ==============================================================================

COLOR_SUCCESS = "#4CAF50"  # Material Green 500
"""Success state color.
Use for: Success messages, completion indicators, positive feedback."""

COLOR_WARNING = "#FF9800"  # Material Orange 500
"""Warning state color.
Use for: Warning messages, caution indicators, alerts."""

COLOR_ERROR = "#F44336"  # Material Red 500
"""Error state color.
Use for: Error messages, validation failures, critical alerts."""

COLOR_INFO = "#2196F3"  # Material Blue 500
"""Informational color.
Use for: Info messages, tooltips, help text."""

# Light variants for backgrounds
COLOR_SUCCESS_LIGHT = "#E8F5E9"  # Material Green 50
COLOR_WARNING_LIGHT = "#FFF8E1"  # Material Amber 50
COLOR_ERROR_LIGHT = "#FFEBEE"  # Material Red 50
COLOR_INFO_LIGHT = "#E3F2FD"  # Material Blue 50


# ==============================================================================
# NEUTRAL COLORS (Surfaces and Backgrounds)
# ==============================================================================

COLOR_BACKGROUND = "#FAFAFA"  # Material Gray 50 - Main app background
"""Main application background color.
Use for: Root window, main container backgrounds."""

COLOR_SURFACE = "#FFFFFF"  # Pure white - Widget surfaces
"""Surface color for widgets and input fields.
Use for: Entry fields, text boxes, card surfaces, panels."""

COLOR_CARD = "#F5F7FA"  # Light blue-gray - Elevated surfaces
"""Card background for grouped content.
Use for: Panel cards, grouped sections, elevated surfaces."""

COLOR_BORDER = "#E0E0E0"  # Material Gray 300 - Standard borders
"""Standard border color.
Use for: Widget borders, dividers, separators."""

COLOR_DIVIDER = "#EEEEEE"  # Material Gray 200 - Subtle dividers
"""Subtle divider color for visual separation.
Use for: Section dividers, subtle separators."""


# ==============================================================================
# TEXT COLORS
# ==============================================================================

COLOR_TEXT_PRIMARY = "#212121"  # Material Gray 900 - Primary text
"""Primary text color for body text and labels.
Use for: Main content text, labels, headings."""

COLOR_TEXT_SECONDARY = "#757575"  # Material Gray 600 - Secondary text
"""Secondary text color for less important text.
Use for: Help text, secondary labels, metadata."""

COLOR_TEXT_DISABLED = "#BDBDBD"  # Material Gray 400 - Disabled text
"""Disabled text color.
Use for: Disabled widgets, inactive states."""

COLOR_TEXT_HINT = "#9E9E9E"  # Material Gray 500 - Hint text
"""Hint/placeholder text color.
Use for: Placeholder text, hints, subtle guidance."""

COLOR_TEXT_INVERSE = "#FFFFFF"  # White text for dark backgrounds
"""Inverse text color for dark backgrounds.
Use for: Text on primary color, text on dark surfaces."""


# ==============================================================================
# SPACING SCALE (Pixels)
# ==============================================================================

SPACING_XS = 4   # Extra small - Tight spacing
"""Extra small spacing (4px). Use for: Minimal padding, tight layouts."""

SPACING_SM = 8   # Small - Compact spacing
"""Small spacing (8px). Use for: Compact padding, button internal spacing."""

SPACING_MD = 16  # Medium - Standard spacing
"""Medium spacing (16px). Use for: Standard padding, default margins."""

SPACING_LG = 24  # Large - Generous spacing
"""Large spacing (24px). Use for: Section spacing, generous padding."""

SPACING_XL = 32  # Extra large - Major spacing
"""Extra large spacing (32px). Use for: Major section breaks, dialog padding."""

SPACING_XXL = 48  # Extra extra large - Hero spacing
"""Extra extra large spacing (48px). Use for: Hero sections, major separations."""


# ==============================================================================
# FONT SIZE SCALE (Points)
# ==============================================================================

FONT_SIZE_SMALL = 9   # Small text - WCAG minimum
"""Small font size (9pt). Minimum for accessibility compliance (WCAG 2.1 AA).
Use for: Captions, help text, metadata, fine print."""

FONT_SIZE_BODY = 10   # Body text - Default
"""Body font size (10pt). Default for most text.
Use for: Body text, labels, input fields, general UI text."""

FONT_SIZE_SUBHEAD = 12  # Subheadings
"""Subheading font size (12pt).
Use for: Subheadings, section titles, emphasized labels."""

FONT_SIZE_HEADING = 14  # Headings
"""Heading font size (14pt).
Use for: Panel headings, dialog titles, major section headers."""

FONT_SIZE_DISPLAY = 16  # Display text
"""Display font size (16pt).
Use for: Large titles, hero text, primary headings."""


# ==============================================================================
# FONT FAMILIES
# ==============================================================================

FONT_FAMILY_DEFAULT = "Segoe UI"
"""Default font family. Falls back to Arial → Helvetica → sans-serif."""

FONT_FAMILY_MONOSPACE = "Consolas"
"""Monospace font family. Falls back to Courier New → Courier → monospace.
Use for: Code snippets, numerical data, fixed-width requirements."""

FONT_FAMILY_FALLBACK = ["Arial", "Helvetica", "sans-serif"]
"""Fallback font families for cross-platform compatibility."""

FONT_FAMILY_MONOSPACE_FALLBACK = ["Courier New", "Courier", "monospace"]
"""Fallback monospace fonts."""

# Font weight constants
FONT_WEIGHT_NORMAL = "normal"
FONT_WEIGHT_BOLD = "bold"


# ==============================================================================
# DIALOG SIZE PRESETS (WxH in pixels)
# ==============================================================================

DIALOG_SIZE_SMALL = "400x300"
"""Small dialog size (400x300). Use for: Simple confirmations, basic inputs."""

DIALOG_SIZE_MEDIUM = "600x400"
"""Medium dialog size (600x400). Use for: Standard forms, configuration dialogs."""

DIALOG_SIZE_LARGE = "800x600"
"""Large dialog size (800x600). Use for: Complex forms, data tables, detailed views."""

DIALOG_SIZE_XLARGE = "1000x700"
"""Extra large dialog size (1000x700). Use for: Advanced settings, full-featured panels."""

# Minimum sizes for dialogs
DIALOG_MIN_WIDTH = 400
DIALOG_MIN_HEIGHT = 300


# ==============================================================================
# RELIEF STYLES (Tkinter)
# ==============================================================================

RELIEF_FLAT = "flat"
"""Flat relief - modern, no border effect. Use for: Modern buttons, clean panels."""

RELIEF_RAISED = "raised"
"""Raised relief - traditional button look. Use for: Classic buttons."""

RELIEF_SUNKEN = "sunken"
"""Sunken relief - inset appearance. Use for: Input fields, text boxes."""

RELIEF_SOLID = "solid"
"""Solid relief - simple border. Use for: Frames, containers."""

RELIEF_RIDGE = "ridge"
"""Ridge relief - 3D ridge effect. Use for: Decorative separators."""

RELIEF_GROOVE = "groove"
"""Groove relief - 3D groove effect. Use for: Decorative separators."""


# ==============================================================================
# BORDER WIDTHS
# ==============================================================================

BORDER_NONE = 0
"""No border."""

BORDER_THIN = 1
"""Thin border (1px). Use for: Standard widget borders."""

BORDER_MEDIUM = 2
"""Medium border (2px). Use for: Emphasized containers."""

BORDER_THICK = 3
"""Thick border (3px). Use for: Strong emphasis, selection indicators."""


# ==============================================================================
# STANDARD WIDGET CONFIGURATIONS
# ==============================================================================

# Button padding (Tkinter padx/pady)
BUTTON_PAD_X = 12
BUTTON_PAD_Y = 6

# Entry padding
ENTRY_PAD_X = 8
ENTRY_PAD_Y = 6

# Frame padding
FRAME_PAD = 10

# Label padding
LABEL_PAD_X = 4
LABEL_PAD_Y = 2


# ==============================================================================
# USAGE GUIDELINES
# ==============================================================================

"""
USAGE EXAMPLES
--------------

1. Importing in GUI modules:
    ```python
    from .theme_constants import (
        COLOR_PRIMARY,
        COLOR_SURFACE,
        SPACING_MD,
        FONT_SIZE_BODY,
        FONT_FAMILY_DEFAULT,
    )
    ```

2. Configuring a button:
    ```python
    button = tk.Button(
        parent,
        text="Primary Action",
        bg=COLOR_PRIMARY,
        fg=COLOR_TEXT_INVERSE,
        font=(FONT_FAMILY_DEFAULT, FONT_SIZE_BODY, FONT_WEIGHT_BOLD),
        padx=BUTTON_PAD_X,
        pady=BUTTON_PAD_Y,
        relief=RELIEF_FLAT,
        bd=BORDER_NONE,
    )
    ```

3. Configuring a frame:
    ```python
    frame = tk.Frame(
        parent,
        bg=COLOR_SURFACE,
        relief=RELIEF_SOLID,
        bd=BORDER_THIN,
        padx=SPACING_MD,
        pady=SPACING_MD,
    )
    ```

4. Configuring text labels:
    ```python
    # Heading
    heading = tk.Label(
        parent,
        text="Section Title",
        bg=COLOR_BACKGROUND,
        fg=COLOR_TEXT_PRIMARY,
        font=(FONT_FAMILY_DEFAULT, FONT_SIZE_HEADING, FONT_WEIGHT_BOLD),
    )

    # Body text
    label = tk.Label(
        parent,
        text="Description text",
        bg=COLOR_BACKGROUND,
        fg=COLOR_TEXT_SECONDARY,
        font=(FONT_FAMILY_DEFAULT, FONT_SIZE_BODY, FONT_WEIGHT_NORMAL),
    )
    ```

5. Semantic colors for state:
    ```python
    # Success message
    success_label = tk.Label(
        parent,
        text="✓ Operation completed",
        bg=COLOR_SUCCESS_LIGHT,
        fg=COLOR_SUCCESS,
    )

    # Error message
    error_label = tk.Label(
        parent,
        text="✗ Operation failed",
        bg=COLOR_ERROR_LIGHT,
        fg=COLOR_ERROR,
    )
    ```

MIGRATION NOTES
---------------
When migrating existing GUI code:

1. Replace hardcoded colors:
   - "#1976D2" → COLOR_PRIMARY
   - "#FFFFFF" → COLOR_SURFACE
   - "#424242" → COLOR_SECONDARY

2. Replace hardcoded sizes:
   - 10 (font) → FONT_SIZE_BODY
   - 16 (padding) → SPACING_MD

3. Use semantic colors:
   - Success indicators → COLOR_SUCCESS
   - Error messages → COLOR_ERROR
   - Warnings → COLOR_WARNING

4. Standardize spacing:
   - padx=10, pady=10 → padx=SPACING_MD, pady=SPACING_MD
   - Small gaps → SPACING_SM
   - Section breaks → SPACING_LG

ACCESSIBILITY NOTES
-------------------
- All font sizes meet WCAG 2.1 AA minimum (≥9pt)
- Color contrast ratios:
  * COLOR_TEXT_PRIMARY on COLOR_BACKGROUND: 16.1:1 (AAA)
  * COLOR_PRIMARY on COLOR_SURFACE: 4.5:1 (AA)
  * COLOR_TEXT_SECONDARY on COLOR_BACKGROUND: 4.6:1 (AA)
- Semantic colors provide additional visual cues beyond color alone

MAINTENANCE
-----------
- DO NOT add colors outside this file
- DO NOT hardcode colors in GUI modules
- Update version and date when making changes
- Document any breaking changes in CHANGELOG.md
"""

# ==============================================================================
# VERSION HISTORY
# ==============================================================================

__version__ = "2.0.0"
__author__ = "Multi-Objective Optimization Laboratory"
__last_updated__ = "2025-10-12"

"""
Version History:
- 2.0.0 (2025-10-12): Initial unified theme system
  * Consolidated colors from main_window.py, tkinter_theme_integration.py
  * Resolved SECONDARY color conflict (#FF6F00 vs #424242, chose gray)
  * Added comprehensive spacing and font scales
  * Defined dialog size presets
  * Added detailed usage guidelines
  * WCAG 2.1 AA accessibility compliance
"""
