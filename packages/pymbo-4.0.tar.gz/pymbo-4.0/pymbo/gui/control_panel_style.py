﻿"""Common styling utilities for Tkinter-based control panels."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional, Tuple

# Import from centralized theme system
try:
    from .theme_constants import (
        COLOR_BACKGROUND,
        COLOR_SURFACE,
        COLOR_SECONDARY,
    )
except ImportError:  # Fallback palette when theme constants are unavailable
    COLOR_BACKGROUND = "#FAFAFA"
    COLOR_SURFACE = "#FFFFFF"
    COLOR_SECONDARY = "#424242"

_DEFAULT_GEOMETRY = "540x640"
_DEFAULT_MIN_SIZE = (520, 520)

_panel_styles_registered = False


def _ensure_panel_styles() -> None:
    """Register ttk styles used by control panels."""
    global _panel_styles_registered
    if _panel_styles_registered:
        return

    style = ttk.Style()
    try:
        style.theme_use("clam")
    except tk.TclError:
        # Fall back silently if clam is unavailable (e.g., on some Tk builds)
        pass

    base_background = COLOR_SURFACE

    style.configure("Panel.TFrame", background=base_background)
    style.configure("Panel.TLabelframe", background=base_background)
    style.configure("Panel.TLabelframe.Label", background=base_background, foreground=COLOR_SECONDARY)
    style.configure("Panel.TLabel", background=base_background, foreground=COLOR_SECONDARY)
    style.configure("TLabel", background=base_background, foreground=COLOR_SECONDARY)
    style.configure("Panel.TButton", padding=(10, 6))

    # Ensure default widgets inherit neutral background when possible
    for element in ("TFrame", "TLabelframe", "TLabelframe.Label", "TLabel", "TCheckbutton", "TRadiobutton"):
        try:
            style.configure(element, background=base_background, foreground=COLOR_SECONDARY)

        except tk.TclError:
            # Some ttk themes do not expose all style elements; ignore failures
            continue

    _panel_styles_registered = True


def create_panel_window(
    parent: tk.Misc,
    *,
    title: str,
    on_close: Callable[[], None],
    geometry: Optional[str] = None,
    min_size: Optional[Tuple[int, int]] = None,
    resizable: Tuple[bool, bool] = (True, True),
    withdraw: bool = True,
    transient: bool = True,
) -> tk.Toplevel:
    """Instantiate a toplevel window with shared panel styling."""
    _ensure_panel_styles()

    window = tk.Toplevel(parent)
    window.title(title)
    window.configure(bg=COLOR_BACKGROUND)

    if geometry is None:
        geometry = _DEFAULT_GEOMETRY
    window.geometry(geometry)

    if min_size is None:
        min_size = _DEFAULT_MIN_SIZE
    window.minsize(*min_size)

    if resizable:
        window.resizable(*resizable)
    else:
        window.resizable(False, False)

    if transient and parent is not None:
        try:
            window.transient(parent)
        except Exception:
            # Some parent widgets (e.g., withdrawn roots) may reject transient calls.
            pass

    window.protocol("WM_DELETE_WINDOW", on_close)
    window.bind("<Escape>", lambda _event: on_close())

    if withdraw:
        window.withdraw()

    return window


def create_panel_container(
    parent: tk.Widget,
    *,
    padding: int = 12,
    padx: int = 0,
    pady: int = 0,
) -> ttk.Frame:
    """Create the standard content container for a control panel."""
    _ensure_panel_styles()
    frame = ttk.Frame(parent, padding=padding, style="Panel.TFrame")
    frame.pack(fill=tk.BOTH, expand=True, padx=padx, pady=pady)
    return frame


def create_section(
    parent: tk.Widget,
    title: str,
    *,
    padding: int = 10,
) -> ttk.LabelFrame:
    """Helper to create a consistently styled panel section."""
    _ensure_panel_styles()
    section = ttk.LabelFrame(parent, text=title, padding=padding, style="Panel.TLabelframe")
    section.pack(fill=tk.X, expand=False, pady=(0, 10))
    return section


