"""
Synthetic Test Functions for Mixed Variable Optimization

Collection of test functions with continuous, discrete, and categorical variables
for validating the Unified Exponential Kernel implementation.
"""

import numpy as np
import torch
from typing import Dict, List, Any, Callable, Tuple
import logging

logger = logging.getLogger(__name__)


class MixedVariableTestFunctions:
    """
    Collection of synthetic test functions for mixed variable optimization.

    Each function includes continuous, discrete, and/or categorical variables
    to test different aspects of the Unified Exponential Kernel.
    """

    @staticmethod
    def mixed_branin(params: Dict[str, Any]) -> float:
        """
        Modified Branin function with mixed variables.

        Parameters:
        - x1: continuous [0, 15]
        - x2: continuous [0, 15]
        - material: categorical ["steel", "aluminum", "plastic"]
        - num_layers: discrete [1, 10]

        Args:
            params: Dictionary with parameter values

        Returns:
            Function value (to be minimized)
        """
        x1 = params["x1"]
        x2 = params["x2"]
        material = params["material"]
        num_layers = params["num_layers"]

        # Base Branin function
        a = 1
        b = 5.1 / (4 * np.pi**2)
        c = 5 / np.pi
        r = 6
        s = 10
        t = 1 / (8 * np.pi)

        branin_val = a * (x2 - b * x1**2 + c * x1 - r) ** 2 + s * (1 - t) * np.cos(x1) + s

        # Material effect (categorical)
        material_multiplier = {"steel": 1.0, "aluminum": 0.8, "plastic": 1.2}

        # Layer effect (discrete) - optimal around 5 layers
        layer_penalty = 0.1 * (num_layers - 5) ** 2

        result = branin_val * material_multiplier[material] + layer_penalty

        return float(result)

    @staticmethod
    def get_mixed_branin_config() -> Dict[str, Dict[str, Any]]:
        """Get parameter configuration for mixed Branin function."""
        return {
            "x1": {"type": "continuous", "bounds": [0, 15]},
            "x2": {"type": "continuous", "bounds": [0, 15]},
            "material": {"type": "categorical", "bounds": ["steel", "aluminum", "plastic"]},
            "num_layers": {"type": "discrete", "bounds": [1, 10]},
        }

    @staticmethod
    def discrete_rosenbrock(params: Dict[str, Any]) -> float:
        """
        Modified Rosenbrock function with discrete variables.

        Parameters:
        - x1: continuous [-2, 2]
        - x2: continuous [-2, 2]
        - resolution: discrete [1, 20] (affects precision)

        Args:
            params: Dictionary with parameter values

        Returns:
            Function value (to be minimized)
        """
        x1 = params["x1"]
        x2 = params["x2"]
        resolution = params["resolution"]

        # Apply resolution discretization
        scale = resolution / 20.0  # Scale resolution to [0.05, 1.0]
        x1_disc = np.round(x1 / scale) * scale
        x2_disc = np.round(x2 / scale) * scale

        # Rosenbrock function
        result = 100 * (x2_disc - x1_disc**2) ** 2 + (1 - x1_disc) ** 2

        # Add penalty for low resolution (encourage higher resolution)
        resolution_penalty = 0.1 / (resolution + 1)

        return float(result + resolution_penalty)

    @staticmethod
    def get_discrete_rosenbrock_config() -> Dict[str, Dict[str, Any]]:
        """Get parameter configuration for discrete Rosenbrock function."""
        return {
            "x1": {"type": "continuous", "bounds": [-2, 2]},
            "x2": {"type": "continuous", "bounds": [-2, 2]},
            "resolution": {"type": "discrete", "bounds": [1, 20]},
        }

    @staticmethod
    def categorical_ackley(params: Dict[str, Any]) -> float:
        """
        Modified Ackley function with all three variable types.

        Parameters:
        - x1: continuous [-5, 5]
        - x2: continuous [-5, 5]
        - algorithm: categorical ["standard", "modified", "adaptive"]
        - iterations: discrete [10, 100]

        Args:
            params: Dictionary with parameter values

        Returns:
            Function value (to be minimized)
        """
        x1 = params["x1"]
        x2 = params["x2"]
        algorithm = params["algorithm"]
        iterations = params["iterations"]

        # Base Ackley function
        a = 20
        b = 0.2
        c = 2 * np.pi

        term1 = -a * np.exp(-b * np.sqrt(0.5 * (x1**2 + x2**2)))
        term2 = -np.exp(0.5 * (np.cos(c * x1) + np.cos(c * x2)))
        ackley_val = term1 + term2 + a + np.e

        # Algorithm modification (categorical)
        algorithm_factor = {
            "standard": 1.0,
            "modified": 0.9,  # Slightly better
            "adaptive": 1.1,  # Slightly worse
        }

        # Iterations effect (discrete) - more iterations generally better
        iteration_factor = 1.0 - 0.005 * (iterations - 10)  # Better with more iterations

        result = ackley_val * algorithm_factor[algorithm] * iteration_factor

        return float(result)

    @staticmethod
    def get_categorical_ackley_config() -> Dict[str, Dict[str, Any]]:
        """Get parameter configuration for categorical Ackley function."""
        return {
            "x1": {"type": "continuous", "bounds": [-5, 5]},
            "x2": {"type": "continuous", "bounds": [-5, 5]},
            "algorithm": {"type": "categorical", "bounds": ["standard", "modified", "adaptive"]},
            "iterations": {"type": "discrete", "bounds": [10, 100]},
        }

    @staticmethod
    def simple_categorical(params: Dict[str, Any]) -> float:
        """
        Simple function with only categorical variables for basic testing.

        Parameters:
        - color: categorical ["red", "green", "blue", "yellow"]
        - size: categorical ["small", "medium", "large"]

        Args:
            params: Dictionary with parameter values

        Returns:
            Function value (to be minimized)
        """
        color = params["color"]
        size = params["size"]

        # Color preferences (green is best)
        color_values = {"red": 3.0, "green": 1.0, "blue": 2.0, "yellow": 4.0}  # Optimal

        # Size preferences (medium is best)
        size_values = {"small": 2.0, "medium": 1.0, "large": 3.0}  # Optimal

        # Interaction effect
        interaction_bonus = 0.0
        if color == "green" and size == "medium":
            interaction_bonus = -0.5  # Extra bonus for optimal combination

        result = color_values[color] + size_values[size] + interaction_bonus

        return float(result)

    @staticmethod
    def get_simple_categorical_config() -> Dict[str, Dict[str, Any]]:
        """Get parameter configuration for simple categorical function."""
        return {
            "color": {"type": "categorical", "bounds": ["red", "green", "blue", "yellow"]},
            "size": {"type": "categorical", "bounds": ["small", "medium", "large"]},
        }

    @staticmethod
    def continuous_only_sphere(params: Dict[str, Any]) -> float:
        """
        Simple sphere function with only continuous variables for baseline testing.

        Parameters:
        - x1: continuous [-5, 5]
        - x2: continuous [-5, 5]
        - x3: continuous [-5, 5]

        Args:
            params: Dictionary with parameter values

        Returns:
            Function value (to be minimized)
        """
        x1 = params["x1"]
        x2 = params["x2"]
        x3 = params["x3"]

        result = x1**2 + x2**2 + x3**2

        return float(result)

    @staticmethod
    def get_continuous_only_sphere_config() -> Dict[str, Dict[str, Any]]:
        """Get parameter configuration for continuous sphere function."""
        return {
            "x1": {"type": "continuous", "bounds": [-5, 5]},
            "x2": {"type": "continuous", "bounds": [-5, 5]},
            "x3": {"type": "continuous", "bounds": [-5, 5]},
        }


class TestFunctionEvaluator:
    """
    Evaluator for test functions with batch processing and noise options.
    """

    def __init__(
        self, function: Callable, config: Dict[str, Dict[str, Any]], noise_std: float = 0.0
    ):
        """
        Initialize evaluator.

        Args:
            function: Test function to evaluate
            config: Parameter configuration
            noise_std: Standard deviation of Gaussian noise to add
        """
        self.function = function
        self.config = config
        self.noise_std = noise_std

        # Store optimal values for known functions
        self.known_optima = {
            "mixed_branin": {"value": 0.397887, "location": None},
            "discrete_rosenbrock": {
                "value": 0.0,
                "location": {"x1": 1.0, "x2": 1.0, "resolution": 20},
            },
            "categorical_ackley": {
                "value": 0.0,
                "location": {"x1": 0.0, "x2": 0.0, "algorithm": "modified", "iterations": 100},
            },
            "simple_categorical": {"value": 1.5, "location": {"color": "green", "size": "medium"}},
            "continuous_only_sphere": {"value": 0.0, "location": {"x1": 0.0, "x2": 0.0, "x3": 0.0}},
        }

    def evaluate(self, params: Dict[str, Any]) -> float:
        """
        Evaluate function with optional noise.

        Args:
            params: Parameter values

        Returns:
            Function value (possibly with noise)
        """
        try:
            value = self.function(params)

            if self.noise_std > 0:
                noise = np.random.normal(0, self.noise_std)
                value += noise

            return float(value)

        except Exception as e:
            logger.error(f"Error evaluating function: {e}")
            return float("inf")

    def batch_evaluate(self, params_list: List[Dict[str, Any]]) -> List[float]:
        """
        Evaluate function on batch of parameter sets.

        Args:
            params_list: List of parameter dictionaries

        Returns:
            List of function values
        """
        return [self.evaluate(params) for params in params_list]

    def get_random_sample(self) -> Dict[str, Any]:
        """
        Generate random parameter sample within bounds.

        Returns:
            Random parameter dictionary
        """
        sample = {}

        for param_name, param_config in self.config.items():
            param_type = param_config["type"]

            if param_type == "continuous":
                bounds = param_config["bounds"]
                sample[param_name] = np.random.uniform(bounds[0], bounds[1])

            elif param_type == "discrete":
                bounds = param_config["bounds"]
                sample[param_name] = np.random.randint(bounds[0], bounds[1] + 1)

            elif param_type == "categorical":
                values_key = "bounds" if "bounds" in param_config else "values"
                values = param_config[values_key]
                sample[param_name] = np.random.choice(values)

        return sample

    def generate_random_dataset(self, n_samples: int) -> Tuple[List[Dict[str, Any]], List[float]]:
        """
        Generate random dataset for testing.

        Args:
            n_samples: Number of samples to generate

        Returns:
            Tuple of (parameter_list, values_list)
        """
        params_list = [self.get_random_sample() for _ in range(n_samples)]
        values_list = self.batch_evaluate(params_list)

        return params_list, values_list

    def get_optimal_value(self, function_name: str) -> Dict[str, Any]:
        """
        Get known optimal value for function.

        Args:
            function_name: Name of the function

        Returns:
            Dictionary with optimal value and location (if known)
        """
        return self.known_optima.get(function_name, {"value": None, "location": None})


# Factory functions for easy test function creation


def get_test_function(name: str, noise_std: float = 0.0) -> TestFunctionEvaluator:
    """
    Factory function to create test function evaluators.

    Args:
        name: Name of test function
        noise_std: Noise standard deviation

    Returns:
        TestFunctionEvaluator instance
    """
    functions = {
        "mixed_branin": (
            MixedVariableTestFunctions.mixed_branin,
            MixedVariableTestFunctions.get_mixed_branin_config(),
        ),
        "discrete_rosenbrock": (
            MixedVariableTestFunctions.discrete_rosenbrock,
            MixedVariableTestFunctions.get_discrete_rosenbrock_config(),
        ),
        "categorical_ackley": (
            MixedVariableTestFunctions.categorical_ackley,
            MixedVariableTestFunctions.get_categorical_ackley_config(),
        ),
        "simple_categorical": (
            MixedVariableTestFunctions.simple_categorical,
            MixedVariableTestFunctions.get_simple_categorical_config(),
        ),
        "continuous_only_sphere": (
            MixedVariableTestFunctions.continuous_only_sphere,
            MixedVariableTestFunctions.get_continuous_only_sphere_config(),
        ),
    }

    if name not in functions:
        raise ValueError(f"Unknown test function: {name}. Available: {list(functions.keys())}")

    function, config = functions[name]
    return TestFunctionEvaluator(function, config, noise_std=noise_std)


def list_test_functions() -> List[str]:
    """Get list of available test function names."""
    return [
        "mixed_branin",
        "discrete_rosenbrock",
        "categorical_ackley",
        "simple_categorical",
        "continuous_only_sphere",
    ]
