"""
Test suite for Unified Exponential Kernel
"""

# Avoid circular imports - let modules be imported directly
pass
