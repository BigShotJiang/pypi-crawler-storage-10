"""
Unit Tests for Unified Exponential Kernel

Comprehensive test suite for validating the Unified Exponential Kernel
implementation, including correctness, compatibility, and performance tests.
"""

import unittest
import torch
import numpy as np
import gpytorch
from typing import Dict, Any
import logging

# Import our modules
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Direct imports to handle module structure
from kernels.unified_exponential import UnifiedExponentialKernel
from utils.parameter_detection import ParameterTypeDetector
from utils.transforms import ParameterTransformer
from kernels.distance_functions import DistanceFunctions, UnifiedDistanceComputer
from tests.test_functions import get_test_function, list_test_functions

logger = logging.getLogger(__name__)


# Helper: materialize gpytorch lazy tensors to dense when needed
def _to_dense(x):
    to_dense = getattr(x, "to_dense", None)
    return to_dense() if callable(to_dense) else x


class TestParameterTypeDetector(unittest.TestCase):
    """Test parameter type detection functionality."""

    def setUp(self):
        self.mixed_config = {
            "x1": {"type": "continuous", "bounds": [0, 10]},
            "x2": {"type": "continuous", "bounds": [-5, 5]},
            "material": {"type": "categorical", "bounds": ["steel", "aluminum", "plastic"]},
            "layers": {"type": "discrete", "bounds": [1, 20]},
        }

        self.continuous_only_config = {
            "param1": {"type": "continuous", "bounds": [0, 1]},
            "param2": {"type": "continuous", "bounds": [-1, 1]},
        }

        self.categorical_only_config = {
            "color": {"type": "categorical", "bounds": ["red", "green", "blue"]},
            "size": {"type": "categorical", "bounds": ["small", "large"]},
        }

    def test_mixed_variable_detection(self):
        """Test detection of mixed variable problems."""
        detector = ParameterTypeDetector(self.mixed_config)

        self.assertEqual(detector.n_params, 4)
        self.assertEqual(detector.variable_info["n_continuous"], 2)
        self.assertEqual(detector.variable_info["n_discrete"], 1)
        self.assertEqual(detector.variable_info["n_categorical"], 1)
        self.assertTrue(detector.variable_info["is_mixed"])

    def test_continuous_only_detection(self):
        """Test detection of continuous-only problems."""
        detector = ParameterTypeDetector(self.continuous_only_config)

        self.assertEqual(detector.n_params, 2)
        self.assertEqual(detector.variable_info["n_continuous"], 2)
        self.assertEqual(detector.variable_info["n_discrete"], 0)
        self.assertEqual(detector.variable_info["n_categorical"], 0)
        self.assertFalse(detector.variable_info["is_mixed"])

    def test_categorical_only_detection(self):
        """Test detection of categorical-only problems."""
        detector = ParameterTypeDetector(self.categorical_only_config)

        self.assertEqual(detector.n_params, 2)
        self.assertEqual(detector.variable_info["n_continuous"], 0)
        self.assertEqual(detector.variable_info["n_discrete"], 0)
        self.assertEqual(detector.variable_info["n_categorical"], 2)
        self.assertFalse(detector.variable_info["is_mixed"])

    def test_bounds_extraction(self):
        """Test bounds extraction by variable type."""
        detector = ParameterTypeDetector(self.mixed_config)
        bounds = detector.get_bounds_by_type()

        self.assertEqual(len(bounds["continuous"]), 2)
        self.assertEqual(len(bounds["discrete"]), 1)
        self.assertEqual(len(bounds["categorical"]), 1)

        # Check continuous bounds
        self.assertEqual(bounds["continuous"][0], (0.0, 10.0))
        self.assertEqual(bounds["continuous"][1], (-5.0, 5.0))

        # Check discrete bounds
        self.assertEqual(bounds["discrete"][0], (1.0, 20.0))

        # Check categorical bounds (should be index range)
        self.assertEqual(bounds["categorical"][0], (0.0, 2.0))

    def test_validation(self):
        """Test parameter validation."""
        detector = ParameterTypeDetector(self.mixed_config)

        # Valid parameters
        valid_params = {"x1": 5.0, "x2": 0.0, "material": "steel", "layers": 10}
        self.assertTrue(detector.validate_parameter_values(valid_params))

        # Invalid continuous parameter
        invalid_params = {
            "x1": 15.0,  # Outside bounds
            "x2": 0.0,
            "material": "steel",
            "layers": 10,
        }
        self.assertFalse(detector.validate_parameter_values(invalid_params))

        # Invalid categorical parameter
        invalid_params2 = {
            "x1": 5.0,
            "x2": 0.0,
            "material": "wood",  # Not in allowed values
            "layers": 10,
        }
        self.assertFalse(detector.validate_parameter_values(invalid_params2))


class TestDistanceFunctions(unittest.TestCase):
    """Test distance function implementations."""

    def setUp(self):
        self.device = torch.device("cpu")
        torch.manual_seed(42)

    def test_continuous_distance(self):
        """Test continuous distance computation."""
        x1 = torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=torch.float64)
        x2 = torch.tensor([[1.5, 2.5], [2.0, 3.0]], dtype=torch.float64)
        lengthscales = torch.tensor([1.0, 2.0], dtype=torch.float64)

        distance = DistanceFunctions.continuous_distance(x1, x2, lengthscales)

        self.assertEqual(distance.shape, (2, 2))

        # Check diagonal elements (distance from point to itself should be 0)
        self.assertAlmostEqual(
            distance[0, 0].item(), 0.25 + 0.0625, places=5
        )  # (0.5/1)^2 + (0.5/2)^2

    def test_discrete_distance(self):
        """Test discrete distance computation."""
        x1 = torch.tensor([[1.0, 5.0], [3.0, 2.0]], dtype=torch.float64)
        x2 = torch.tensor([[2.0, 7.0], [3.0, 2.0]], dtype=torch.float64)
        lengthscales = torch.tensor([1.0, 2.0], dtype=torch.float64)

        distance = DistanceFunctions.discrete_distance(x1, x2, lengthscales)

        self.assertEqual(distance.shape, (2, 2))

        # Check known values
        self.assertAlmostEqual(distance[0, 0].item(), 1.0 + 1.0, places=5)  # |1-2|/1 + |5-7|/2
        self.assertAlmostEqual(distance[1, 1].item(), 0.0, places=5)  # Same point

    def test_categorical_distance(self):
        """Test categorical distance computation."""
        x1 = torch.tensor([[0.0, 1.0], [1.0, 0.0]], dtype=torch.float64)
        x2 = torch.tensor([[0.0, 2.0], [1.0, 0.0]], dtype=torch.float64)
        theta = torch.tensor([1.5, 2.0], dtype=torch.float64)

        distance = DistanceFunctions.categorical_distance(x1, x2, theta)

        self.assertEqual(distance.shape, (2, 2))

        # Check known values
        self.assertAlmostEqual(
            distance[0, 0].item(), 2.0, places=5
        )  # 0 + theta[1] (different second category)
        self.assertAlmostEqual(distance[1, 1].item(), 0.0, places=5)  # Same point

    def test_hamming_distance(self):
        """Test Hamming distance computation."""
        x1 = torch.tensor([[0.0, 1.0, 2.0], [1.0, 1.0, 2.0]], dtype=torch.float64)
        x2 = torch.tensor([[0.0, 2.0, 2.0], [1.0, 1.0, 2.0]], dtype=torch.float64)

        distance = DistanceFunctions.hamming_distance(x1, x2)

        self.assertEqual(distance.shape, (2, 2))

        # Check known values
        self.assertAlmostEqual(distance[0, 0].item(), 1.0 / 3.0, places=5)  # 1 different out of 3
        self.assertAlmostEqual(distance[1, 1].item(), 0.0, places=5)  # Same point


class TestUnifiedExponentialKernel(unittest.TestCase):
    """Test Unified Exponential Kernel implementation."""

    def setUp(self):
        self.mixed_config = {
            "x1": {"type": "continuous", "bounds": [0, 10]},
            "x2": {"type": "continuous", "bounds": [-5, 5]},
            "material": {"type": "categorical", "bounds": ["steel", "aluminum", "plastic"]},
            "layers": {"type": "discrete", "bounds": [1, 20]},
        }

        self.continuous_config = {
            "param1": {"type": "continuous", "bounds": [0, 1]},
            "param2": {"type": "continuous", "bounds": [-1, 1]},
        }

        torch.manual_seed(42)

    def test_kernel_initialization(self):
        """Test kernel initialization and parameter setup."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        self.assertEqual(kernel.ard_num_dims, 4)
        self.assertTrue(hasattr(kernel, "raw_weights"))
        self.assertTrue(hasattr(kernel, "raw_continuous_lengthscales"))
        self.assertTrue(hasattr(kernel, "raw_discrete_lengthscales"))
        self.assertTrue(hasattr(kernel, "raw_categorical_theta"))

        # Check hyperparameter shapes
        self.assertEqual(kernel.weights.shape, torch.Size([4]))
        self.assertEqual(kernel.continuous_lengthscales.shape, torch.Size([2]))
        self.assertEqual(kernel.discrete_lengthscales.shape, torch.Size([1]))
        self.assertEqual(kernel.categorical_theta.shape, torch.Size([1]))

    def test_kernel_forward_mixed(self):
        """Test kernel forward pass with mixed variables."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        # Create test data
        x1 = torch.tensor([[0.5, 0.0, 1.0, 10.0], [0.3, 0.2, 0.0, 5.0]], dtype=torch.float64)
        x2 = torch.tensor([[0.5, 0.0, 1.0, 10.0], [0.7, -0.1, 2.0, 15.0]], dtype=torch.float64)

        # Compute covariance
        cov = _to_dense(kernel(x1, x2))

        self.assertEqual(cov.shape, (2, 2))

        # Check properties
        self.assertTrue(torch.all(cov >= 0))  # Non-negative
        self.assertTrue(torch.all(cov <= 1))  # Bounded by 1 (before scaling)
        self.assertAlmostEqual(cov[0, 0].item(), 1.0, places=5)  # Same point should have cov=1

    def test_kernel_forward_continuous_only(self):
        """Test kernel with continuous variables only."""
        kernel = UnifiedExponentialKernel(self.continuous_config)

        x1 = torch.tensor([[0.5, 0.0], [0.3, 0.2]], dtype=torch.float64)
        x2 = torch.tensor([[0.5, 0.0], [0.7, -0.1]], dtype=torch.float64)

        cov = _to_dense(kernel(x1, x2))

        self.assertEqual(cov.shape, (2, 2))
        self.assertAlmostEqual(cov[0, 0].item(), 1.0, places=5)

    def test_kernel_diagonal(self):
        """Test diagonal computation."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        x = torch.tensor([[0.5, 0.0, 1.0, 10.0], [0.3, 0.2, 0.0, 5.0]], dtype=torch.float64)

        cov_diag = _to_dense(kernel(x, x, diag=True))

        self.assertEqual(cov_diag.shape, (2,))
        self.assertTrue(torch.allclose(cov_diag, torch.ones(2), atol=1e-5))

    def test_positive_definite(self):
        """Test that kernel produces positive definite matrices."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        # Generate random test points
        n_points = 5
        x = torch.rand(n_points, 4, dtype=torch.float64)
        x[:, 2] = torch.randint(0, 3, (n_points,), dtype=torch.float64)  # Categorical
        x[:, 3] = torch.randint(1, 21, (n_points,), dtype=torch.float64)  # Discrete

        # Compute covariance matrix
        cov_matrix = _to_dense(kernel(x, x))

        # Check positive definiteness
        eigenvals = torch.linalg.eigvals(cov_matrix)
        self.assertTrue(torch.all(eigenvals.real >= -1e-6))  # Allow small numerical errors

    def test_lengthscale_compatibility(self):
        """Test lengthscale property for PyMBO compatibility."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        lengthscales = kernel.lengthscale

        self.assertEqual(lengthscales.shape, torch.Size([4]))
        self.assertTrue(torch.all(lengthscales > 0))

    def test_hyperparameter_summary(self):
        """Test hyperparameter summary generation."""
        kernel = UnifiedExponentialKernel(self.mixed_config)

        summary = kernel.get_hyperparameter_summary()

        self.assertIn("weights", summary)
        self.assertIn("continuous_lengthscales", summary)
        self.assertIn("discrete_lengthscales", summary)
        self.assertIn("categorical_theta", summary)
        self.assertIn("variable_info", summary)

        self.assertEqual(len(summary["weights"]), 4)
        self.assertEqual(len(summary["continuous_lengthscales"]), 2)
        self.assertEqual(len(summary["discrete_lengthscales"]), 1)
        self.assertEqual(len(summary["categorical_theta"]), 1)


class TestParameterTransformer(unittest.TestCase):
    """Test parameter transformation functionality."""

    def setUp(self):
        self.config = {
            "x1": {"type": "continuous", "bounds": [0, 10]},
            "material": {"type": "categorical", "bounds": ["steel", "aluminum", "plastic"]},
            "layers": {"type": "discrete", "bounds": [1, 20]},
        }

        self.transformer = ParameterTransformer(self.config)

    def test_params_to_tensor(self):
        """Test parameter dictionary to tensor conversion."""
        params = {"x1": 5.0, "material": "aluminum", "layers": 10}

        tensor = self.transformer.params_to_tensor(params, normalize=True)

        self.assertEqual(tensor.shape, torch.Size([3]))
        self.assertAlmostEqual(tensor[0].item(), 0.5, places=5)  # 5.0 normalized to [0,10]
        self.assertAlmostEqual(
            tensor[1].item(), 0.5, places=5
        )  # aluminum is index 1 of 3, normalized
        self.assertAlmostEqual(tensor[2].item(), (10 - 1) / (20 - 1), places=5)  # layers normalized

    def test_tensor_to_params(self):
        """Test tensor to parameter dictionary conversion."""
        tensor = torch.tensor([0.5, 0.5, 0.5], dtype=torch.float64)

        params = self.transformer.tensor_to_params(tensor, denormalize=True)

        self.assertAlmostEqual(params["x1"], 5.0, places=5)
        self.assertEqual(params["material"], "aluminum")  # Index 1
        self.assertEqual(params["layers"], 11)  # Rounded discrete value

    def test_roundtrip_conversion(self):
        """Test that conversion is invertible."""
        original_params = {"x1": 7.5, "material": "steel", "layers": 15}

        # Convert to tensor and back
        tensor = self.transformer.params_to_tensor(original_params, normalize=True)
        recovered_params = self.transformer.tensor_to_params(tensor, denormalize=True)

        self.assertAlmostEqual(recovered_params["x1"], original_params["x1"], places=5)
        self.assertEqual(recovered_params["material"], original_params["material"])
        self.assertEqual(recovered_params["layers"], original_params["layers"])

    def test_batch_conversion(self):
        """Test batch parameter conversion."""
        params_list = [
            {"x1": 1.0, "material": "steel", "layers": 5},
            {"x1": 9.0, "material": "plastic", "layers": 15},
        ]

        batch_tensor = self.transformer.batch_params_to_tensor(params_list, normalize=True)

        self.assertEqual(batch_tensor.shape, (2, 3))

        # Convert back
        recovered_list = self.transformer.batch_tensor_to_params(batch_tensor, denormalize=True)

        self.assertEqual(len(recovered_list), 2)
        self.assertAlmostEqual(recovered_list[0]["x1"], 1.0, places=5)
        self.assertEqual(recovered_list[1]["material"], "plastic")


class TestGPyTorchCompatibility(unittest.TestCase):
    """Test GPyTorch integration and compatibility."""

    def setUp(self):
        self.config = {
            "x1": {"type": "continuous", "bounds": [0, 1]},
            "x2": {"type": "continuous", "bounds": [0, 1]},
            "material": {"type": "categorical", "bounds": ["A", "B"]},
        }

        torch.manual_seed(42)

    def test_scale_kernel_compatibility(self):
        """Test compatibility with GPyTorch ScaleKernel."""
        base_kernel = UnifiedExponentialKernel(self.config)
        scale_kernel = gpytorch.kernels.ScaleKernel(base_kernel)

        x = torch.rand(3, 3, dtype=torch.float64)
        x[:, 2] = torch.randint(0, 2, (3,), dtype=torch.float64)  # Categorical

        cov = _to_dense(scale_kernel(x, x))

        self.assertEqual(cov.shape, (3, 3))
        self.assertTrue(hasattr(scale_kernel, "base_kernel"))
        self.assertTrue(hasattr(scale_kernel.base_kernel, "lengthscale"))

    def test_gp_model_integration(self):
        """Test integration with GPyTorch GP models."""
        # Create synthetic training data
        n_train = 10
        x_train = torch.rand(n_train, 3, dtype=torch.float64)
        x_train[:, 2] = torch.randint(0, 2, (n_train,), dtype=torch.float64)  # Categorical
        y_train = torch.randn(n_train, 1, dtype=torch.float64)

        # Create kernel and model
        base_kernel = UnifiedExponentialKernel(self.config)
        covar_module = gpytorch.kernels.ScaleKernel(base_kernel)

        # This would be the integration point in PyMBO
        # model = SingleTaskGP(train_X=x_train, train_Y=y_train, covar_module=covar_module)

        # For now, just test that the kernel works with the expected interface
        cov_matrix = _to_dense(covar_module(x_train, x_train))
        self.assertEqual(cov_matrix.shape, (n_train, n_train))


class TestIntegrationWithTestFunctions(unittest.TestCase):
    """Test integration with synthetic test functions."""

    def test_mixed_branin_function(self):
        """Test with mixed Branin function."""
        evaluator = get_test_function("mixed_branin")
        kernel = UnifiedExponentialKernel(evaluator.config)
        transformer = ParameterTransformer(evaluator.config)

        # Generate some test data
        params_list, values = evaluator.generate_random_dataset(10)

        # Convert to tensors
        x_tensor = transformer.batch_params_to_tensor(params_list, normalize=True)

        # Test kernel evaluation
        cov_matrix = _to_dense(kernel(x_tensor, x_tensor))

        self.assertEqual(cov_matrix.shape, (10, 10))
        self.assertTrue(torch.all(cov_matrix >= 0))

    def test_all_test_functions(self):
        """Test kernel with all available test functions."""
        for func_name in list_test_functions():
            with self.subTest(function=func_name):
                evaluator = get_test_function(func_name)
                kernel = UnifiedExponentialKernel(evaluator.config)

                # Generate small dataset
                params_list, _ = evaluator.generate_random_dataset(5)
                transformer = ParameterTransformer(evaluator.config)
                x_tensor = transformer.batch_params_to_tensor(params_list, normalize=True)

                # Test kernel evaluation
                cov_matrix = _to_dense(kernel(x_tensor, x_tensor))

                self.assertEqual(cov_matrix.shape, (5, 5))
                self.assertTrue(torch.all(cov_matrix >= 0))
                self.assertTrue(torch.all(cov_matrix <= 1.1))  # Allow small numerical errors


if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)

    # Run tests
    unittest.main(verbosity=2)
