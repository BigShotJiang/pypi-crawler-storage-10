"""Hypervolume utilities extracted from optimizer.

These functions provide pure computations for adaptive reference points and
hypervolume metrics to keep the core optimizer lightweight and modular.
"""

from typing import Dict, List
import logging
import torch
from botorch.utils.multi_objective.box_decompositions.non_dominated import (
    FastNondominatedPartitioning,
)

logger = logging.getLogger(__name__)


def calculate_adaptive_reference_point(clean_Y: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """Compute a strictly dominated reference point for hypervolume.

    Assumes ``clean_Y`` is already in maximization orientation (i.e., any
    minimization objectives have been negated upstream).
    """
    min_observed = torch.min(clean_Y, dim=0).values
    max_observed = torch.max(clean_Y, dim=0).values

    span = torch.clamp(max_observed - min_observed, min=clean_Y.new_tensor(eps))
    base_offset = span * 0.2

    scale = torch.clamp(min_observed.abs(), min=clean_Y.new_tensor(1.0))
    scale_offset = scale * 0.05

    adaptive_offset = torch.maximum(base_offset, scale_offset)
    adaptive_offset = adaptive_offset.clamp_min(clean_Y.new_tensor(1e-3))

    ref_point = min_observed - adaptive_offset

    # Guard against non-finite results by falling back one unit below the minimum
    fallback = min_observed - clean_Y.new_tensor(1.0)
    ref_point = torch.where(torch.isfinite(ref_point), ref_point, fallback)

    return ref_point


def calculate_hypervolume(train_Y: torch.Tensor, objective_names: List[str]) -> Dict[str, float]:
    """Calculate raw and normalized hypervolume for a set of observations.

    Expects ``train_Y`` to be in maximization orientation and finite where used.
    """
    default_result = {
        "raw_hypervolume": 0.0,
        "normalized_hypervolume": 0.0,
        "reference_point_adaptive": True,
        "data_points_used": 0,
    }

    try:
        if len(objective_names) < 2:
            return default_result
        if train_Y is None or train_Y.shape[0] == 0:
            return default_result

        Y_cpu = train_Y.cpu() if train_Y.is_cuda else train_Y
        finite_mask = torch.isfinite(Y_cpu).all(dim=1)
        if not finite_mask.any():
            return default_result

        clean_Y = Y_cpu[finite_mask]
        if clean_Y.shape[0] < 2:
            return default_result

        ref_point = calculate_adaptive_reference_point(clean_Y)

        partitioning = FastNondominatedPartitioning(ref_point=ref_point, Y=clean_Y)
        raw_hypervolume = partitioning.compute_hypervolume().item()

        max_observed_Y = clean_Y.max(dim=0)[0]
        theoretical_max_volume = torch.prod(max_observed_Y - ref_point)

        if theoretical_max_volume.item() > 1e-12:
            normalized_hypervolume = raw_hypervolume / theoretical_max_volume.item()
        else:
            normalized_hypervolume = 0.0

        normalized_hypervolume = max(0.0, min(1.0, normalized_hypervolume))

        return {
            "raw_hypervolume": raw_hypervolume,
            "normalized_hypervolume": normalized_hypervolume,
            "reference_point_adaptive": True,
            "data_points_used": clean_Y.shape[0],
        }

    except Exception as e:
        logger.warning(f"Hypervolume calculation failed: {e}")
        return default_result
