"""
State Management Module for PyMBO Optimizer

This module provides comprehensive save/load functionality for the optimizer,
enabling complete state persistence and restoration.
"""

import logging
import time
import pickle
import json
import zipfile
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any
import numpy as np
import pandas as pd
import torch
from .. import __version__ as PYMBO_VERSION

logger = logging.getLogger(__name__)


def convert_to_serializable(obj):
    """
    Convert non-JSON-serializable objects to serializable formats.

    Handles:
    - pandas Timestamps → ISO format strings
    - numpy arrays → lists
    - numpy scalars → Python scalars
    - DataFrames → dict records
    """
    if isinstance(obj, pd.Timestamp):
        return obj.isoformat()
    elif isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    elif isinstance(obj, pd.DataFrame):
        return obj.to_dict('records')
    elif isinstance(obj, dict):
        return {k: convert_to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [convert_to_serializable(item) for item in obj]
    else:
        return obj


def save_optimizer_state(optimizer, filepath: str) -> None:
    """
    Save the complete optimizer state to a file for later resumption.

    This function creates a comprehensive save file containing all necessary
    information to resume optimization exactly where it left off, including:
    - All experimental data
    - Trained GP models (state dicts)
    - Configuration (parameters, responses, constraints)
    - Iteration history and hypervolume tracking
    - Pareto front and optimization metrics
    - Training tensors and internal state

    Args:
        optimizer: EnhancedMultiObjectiveOptimizer instance
        filepath (str): Path where the state file should be saved.
                       Recommended extension: .pymbo or .zip

    Raises:
        Exception: If saving fails for any reason

    Example:
        >>> save_optimizer_state(optimizer, 'my_optimization_2024-01-15.pymbo')
    """
    try:
        logger.info(f"Saving optimizer state to: {filepath}")
        start_time = time.time()

        # Create a temporary directory to hold all components
        save_path = Path(filepath)
        save_path.parent.mkdir(parents=True, exist_ok=True)

        # Prepare metadata
        metadata = {
            'pymbo_version': PYMBO_VERSION,
            'save_timestamp': datetime.now().isoformat(),
            'optimizer_class': optimizer.__class__.__name__,
            'device': str(optimizer.device),
            'dtype': str(optimizer.dtype),
            'deterministic': optimizer.deterministic,
            'random_seed': optimizer.random_seed,
        }

        # Prepare configuration (ensure all values are serializable)
        config = {
            'params_config': convert_to_serializable(optimizer.params_config),
            'responses_config': convert_to_serializable(optimizer.responses_config),
            'general_constraints': optimizer.general_constraints if optimizer.general_constraints else [],
            'objective_names': optimizer.objective_names,
            'objective_directions': [int(d) for d in optimizer.objective_directions],
            'max_gp_points': optimizer.max_gp_points,
        }

        # Prepare optimization state (convert non-serializable objects)
        opt_state = {
            'optimization_iterations': optimizer.optimization_iterations,
            'has_baseline_data': optimizer.has_baseline_data,
            'baseline_hypervolume': float(optimizer.baseline_hypervolume) if optimizer.baseline_hypervolume else 0.0,
            'iteration_history': convert_to_serializable(optimizer.iteration_history),
            'pareto_front': optimizer.pareto_front.to_dict() if hasattr(optimizer, 'pareto_front') and not optimizer.pareto_front.empty else {},
        }

        # Save experimental data (convert to serializable format)
        exp_data_dict = {
            'experimental_data': convert_to_serializable(optimizer.experimental_data.to_dict('records')) if not optimizer.experimental_data.empty else [],
            'n_experiments': len(optimizer.experimental_data),
        }

        # Save trained models (state dicts only - lightweight)
        models_data = {}
        try:
            response_models = optimizer.get_response_models()
            for response_name, model in response_models.items():
                models_data[response_name] = {
                    'state_dict': model.state_dict(),
                    'train_inputs_shape': list(model.train_inputs[0].shape) if model.train_inputs else None,
                    'train_targets_shape': list(model.train_targets.shape) if hasattr(model, 'train_targets') else None,
                }
            logger.info(f"Saved {len(models_data)} trained GP models")
        except Exception as e:
            logger.warning(f"Could not save models: {e}")
            models_data = {}

        # Save training tensors (if available)
        tensors_data = {}
        try:
            if hasattr(optimizer, 'train_X') and optimizer.train_X is not None:
                tensors_data['train_X'] = optimizer.train_X.cpu().numpy().tolist()
            if hasattr(optimizer, 'train_Y') and optimizer.train_Y is not None:
                tensors_data['train_Y'] = optimizer.train_Y.cpu().numpy().tolist()
            if hasattr(optimizer, 'train_Y_raw') and optimizer.train_Y_raw is not None:
                tensors_data['train_Y_raw'] = optimizer.train_Y_raw.cpu().numpy().tolist()
        except Exception as e:
            logger.debug(f"Could not save training tensors: {e}")

        # Create ZIP archive with all components
        with zipfile.ZipFile(filepath, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Save JSON-serializable data
            zf.writestr('metadata.json', json.dumps(metadata, indent=2))
            zf.writestr('config.json', json.dumps(config, indent=2))
            zf.writestr('opt_state.json', json.dumps(opt_state, indent=2))
            zf.writestr('exp_data.json', json.dumps(exp_data_dict, indent=2))

            # Save model state dicts using pickle
            if models_data:
                zf.writestr('models.pkl', pickle.dumps(models_data))

            # Save training tensors
            if tensors_data:
                zf.writestr('tensors.json', json.dumps(tensors_data))

            # Save parameter transformer state
            if hasattr(optimizer, 'parameter_transformer'):
                transformer_state = {
                    'param_names': optimizer.parameter_transformer.param_names,
                    'param_types': optimizer.parameter_transformer.param_types,
                    'bounds': convert_to_serializable(optimizer.parameter_transformer.bounds),
                    'param_numeric_bounds': convert_to_serializable(optimizer.parameter_transformer.param_numeric_bounds),
                    'discrete_choices': convert_to_serializable(optimizer.parameter_transformer.discrete_choices),
                    'categorical_choices': convert_to_serializable(optimizer.parameter_transformer.categorical_choices),
                }
                zf.writestr('transformer.json', json.dumps(transformer_state, indent=2))

        elapsed = time.time() - start_time
        file_size = Path(filepath).stat().st_size / (1024 * 1024)  # MB
        logger.info(f"✓ State saved successfully in {elapsed:.2f}s (size: {file_size:.2f} MB)")
        logger.info(f"  - {len(optimizer.experimental_data)} experimental data points")
        logger.info(f"  - {len(models_data)} trained GP models")
        logger.info(f"  - {len(optimizer.iteration_history)} iterations")

    except Exception as e:
        logger.error(f"Failed to save optimizer state: {e}", exc_info=True)
        raise


def load_optimizer_state(optimizer_class, filepath: str, device: Optional[str] = None):
    """
    Load a previously saved optimizer state and restore it completely.

    This function reconstructs the optimizer from a save file, restoring:
    - All experimental data
    - Parameter and response configurations
    - Trained GP models
    - Iteration history and metrics
    - Complete optimization state

    Args:
        optimizer_class: EnhancedMultiObjectiveOptimizer class
        filepath (str): Path to the saved state file (.pymbo or .zip)
        device (Optional[str]): Device to load models onto ('cpu', 'cuda', etc.)
                               If None, uses the device from the saved state

    Returns:
        EnhancedMultiObjectiveOptimizer: Fully restored optimizer instance

    Raises:
        FileNotFoundError: If the save file doesn't exist
        Exception: If loading or reconstruction fails

    Example:
        >>> from pymbo import EnhancedMultiObjectiveOptimizer
        >>> optimizer = load_optimizer_state(EnhancedMultiObjectiveOptimizer, 'my_optimization.pymbo')
        >>> # Continue optimization
        >>> next_experiments = optimizer.suggest_next_experiment(n_suggestions=3)
    """
    try:
        logger.info(f"Loading optimizer state from: {filepath}")
        start_time = time.time()

        if not Path(filepath).exists():
            raise FileNotFoundError(f"Save file not found: {filepath}")

        # Extract all data from ZIP archive
        with zipfile.ZipFile(filepath, 'r') as zf:
            # Load metadata
            metadata = json.loads(zf.read('metadata.json'))
            logger.info(f"Loading state from PyMBO v{metadata['pymbo_version']} (saved: {metadata['save_timestamp']})")

            # Load configuration
            config = json.loads(zf.read('config.json'))

            # Load optimization state
            opt_state = json.loads(zf.read('opt_state.json'))

            # Load experimental data
            exp_data_dict = json.loads(zf.read('exp_data.json'))

            # Load models (if present)
            models_data = {}
            try:
                models_data = pickle.loads(zf.read('models.pkl'))
            except KeyError:
                logger.warning("No models found in save file")

            # Load training tensors (if present)
            tensors_data = {}
            try:
                tensors_data = json.loads(zf.read('tensors.json'))
            except KeyError:
                logger.debug("No training tensors in save file")

            # Load transformer state (if present)
            transformer_state = None
            try:
                transformer_state = json.loads(zf.read('transformer.json'))
            except KeyError:
                logger.debug("No transformer state in save file")

        # Determine device
        if device is None:
            device = metadata.get('device', 'cpu')
        if 'cuda' in device and not torch.cuda.is_available():
            logger.warning(f"CUDA not available, falling back to CPU")
            device = 'cpu'

        # Create new optimizer instance with restored configuration
        optimizer = optimizer_class(
            params_config=config['params_config'],
            responses_config=config['responses_config'],
            general_constraints=config['general_constraints'],
            device=device,
            deterministic=metadata.get('deterministic', False),
            random_seed=metadata.get('random_seed', None),
            max_gp_points=config.get('max_gp_points'),
        )

        # Restore experimental data
        if exp_data_dict['experimental_data']:
            experimental_data = pd.DataFrame.from_records(exp_data_dict['experimental_data'])
            optimizer.experimental_data = experimental_data
            logger.info(f"Restored {len(experimental_data)} experimental data points")

            # Rebuild training tensors from experimental data
            optimizer._update_training_data()

        # Restore optimization state
        optimizer.optimization_iterations = opt_state['optimization_iterations']
        optimizer.has_baseline_data = opt_state['has_baseline_data']
        optimizer.baseline_hypervolume = opt_state['baseline_hypervolume']
        optimizer.iteration_history = opt_state['iteration_history']

        # Restore Pareto front
        if opt_state['pareto_front']:
            optimizer.pareto_front = pd.DataFrame.from_dict(opt_state['pareto_front'])

        # Restore trained models
        if models_data and hasattr(optimizer, 'train_X') and optimizer.train_X is not None:
            logger.info(f"Restoring {len(models_data)} trained GP models...")
            restored_models = {}
            for response_name, model_data in models_data.items():
                try:
                    # Rebuild the model using current training data
                    response_models = optimizer.get_response_models()
                    if response_name in response_models:
                        model = response_models[response_name]
                        # Load the saved state dict
                        model.load_state_dict(model_data['state_dict'])
                        restored_models[response_name] = model
                        logger.debug(f"  Restored model for response: {response_name}")
                except Exception as e:
                    logger.warning(f"Could not restore model for {response_name}: {e}")

            logger.info(f"Successfully restored {len(restored_models)}/{len(models_data)} models")

        elapsed = time.time() - start_time
        logger.info(f"✓ State loaded successfully in {elapsed:.2f}s")
        logger.info(f"  - Optimizer at iteration {optimizer.optimization_iterations}")
        logger.info(f"  - {len(optimizer.experimental_data)} data points")
        logger.info(f"  - Baseline HV: {optimizer.baseline_hypervolume:.6f}")

        return optimizer

    except Exception as e:
        logger.error(f"Failed to load optimizer state: {e}", exc_info=True)
        raise
