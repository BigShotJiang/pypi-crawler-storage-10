﻿"""
Optimizer Engine - Enhanced Multi-Objective Bayesian Optimization

This module implements a sophisticated multi-objective Bayesian optimization engine
using PyTorch/BoTorch for the Multi-Objective Optimization Laboratory. It provides
advanced optimization capabilities with robust error handling and comprehensive
functionality.

Key Features:
- Multi-objective Bayesian optimization with Gaussian Process models
- Expected Hypervolume Improvement acquisition function
- Support for continuous and categorical parameters
- Latin Hypercube and random initial sampling
- Pareto front computation and hypervolume metrics
- Advanced constraint handling and validation
- Thread-safe operations with comprehensive logging
- Performance optimization and caching

Classes:
    SimpleParameterTransformer: Handles parameter space transformations
    EnhancedMultiObjectiveOptimizer: Main optimization engine

NOTE: For improved performance and clean output, consider using the new
EfficientMultiObjectiveOptimizer from pymbo.core.enhanced_optimizer which
provides 5-10x speedup and eliminates chaotic tensor logging.

Author: Multi-Objective Optimization Laboratory
Version: 4.0 Enhanced
"""

import ast
import logging
import math

logger = logging.getLogger(__name__)
import time
import warnings
from typing import Any, Dict, List, Optional, Tuple, Union
import pickle
import json
import zipfile
from pathlib import Path
from datetime import datetime

# Scientific computing imports
import numpy as np
from torch.quasirandom import SobolEngine
import pandas as pd
import torch

# BoTorch components for multi-objective optimization
from botorch.acquisition.analytic import LogExpectedImprovement
from botorch.acquisition.multi_objective import ExpectedHypervolumeImprovement

# Modern acquisition availability flag (avoid unused imports)
try:
    import importlib.util as _importlib_util

    MODERN_ACQUISITION_AVAILABLE = (
        _importlib_util.find_spec("pymbo.core.modern_acquisition_core") is not None
    )
    if MODERN_ACQUISITION_AVAILABLE:
        logger.info(
            "Modern acquisition functions loaded (qNEHVI, qLogEI, UnifiedExponentialKernel)"
        )
    else:
        logger.warning(
            "Modern acquisition module unavailable; using legacy acquisition functions (EHVI, LogEI)"
        )
except Exception:
    MODERN_ACQUISITION_AVAILABLE = False
    logger.warning(
        "Modern acquisition module unavailable; using legacy acquisition functions (EHVI, LogEI)"
    )
from botorch.fit import fit_gpytorch_mll
from botorch.models import ModelListGP, SingleTaskGP
from botorch.models.transforms.input import Normalize
from botorch.models.transforms.outcome import Standardize
from botorch.optim import optimize_acqf
from botorch.utils.multi_objective.pareto import is_non_dominated

# GPyTorch components for Gaussian Process models
from gpytorch.kernels import MaternKernel, ScaleKernel
from gpytorch.mlls import ExactMarginalLogLikelihood

# Unified Exponential Kernel for mixed variables
try:
    from unified_kernel.kernels.unified_exponential import (
        UnifiedExponentialKernel,
        is_mixed_variable_problem,
        get_variable_type_summary,
    )

    UNIFIED_KERNEL_AVAILABLE = True
except ImportError:
    try:
        from .unified_kernel.kernels.unified_exponential import (
            UnifiedExponentialKernel,
            is_mixed_variable_problem,
            get_variable_type_summary,
        )

        UNIFIED_KERNEL_AVAILABLE = True
    except ImportError:
        UNIFIED_KERNEL_AVAILABLE = False
        warnings.warn(
            "Unified Exponential Kernel not available. Mixed variable problems will use standard kernels.",
            UserWarning,
        )

# Additional scientific libraries
# Latin Hypercube Sampling (used in DoE paths migrated to _sampling)

# Performance optimization imports
try:
    from pymbo.utils.performance_optimizer import performance_timer

    PERFORMANCE_OPTIMIZATION_AVAILABLE = True
except ImportError:
    PERFORMANCE_OPTIMIZATION_AVAILABLE = False

# Import centralized warnings configuration
from ..utils.warnings_config import configure_warnings
from ..utils.scientific_utilities import (
    seed_everything,
    capture_random_state,
    restore_random_state,
)
from .parameter_transformer import SimpleParameterTransformer

configure_warnings()

# Optimization configuration constants
MIN_DATA_POINTS_FOR_GP = 3  # Minimum data points required for GP model training
DEFAULT_BATCH_SIZE = 5  # Default number of suggestions to generate
MAX_BATCH_SIZE = 50  # Maximum allowed batch size
DEFAULT_NUM_RESTARTS = 10  # Default number of optimization restarts
DEFAULT_RAW_SAMPLES = 100  # Default number of raw samples for optimization
MAX_ITERATIONS = 1000  # Maximum iterations for acquisition optimization

# Data subsampling configuration constants
DEFAULT_MAX_GP_POINTS = 100  # Default maximum points for GP training (balanced performance)
FAST_MODE_MAX_GP_POINTS = 50  # Maximum points for ultra-fast validation mode
MAX_RECOMMENDED_GP_POINTS = 200  # Maximum recommended before performance degrades significantly

# Numerical constants
EPS = 1e-8  # Small epsilon for numerical stability
INF = 1e6  # Large number for constraint handling

# Security: Allowed operators for safe constraint expression evaluation
# This prevents code injection through constraint strings
ALLOWED_CONSTRAINT_OPERATORS = {"+", "-", "*", "/", "(", ")", "<", ">", "=", " "}
ALLOWED_CONSTRAINT_FUNCTIONS = {"abs", "sqrt", "log", "exp", "sin", "cos", "tan"}


def validate_constraint_expression(constraint: str, param_names: List[str]) -> bool:
    """
    Validates a constraint expression for security and correctness.

    Args:
        constraint: The constraint expression to validate
        param_names: List of valid parameter names

    Returns:
        bool: True if constraint is safe, False otherwise
    """
    if not isinstance(constraint, str):
        return False

    # Remove whitespace for easier processing
    clean_constraint = constraint.replace(" ", "")

    # Check for dangerous patterns
    dangerous_patterns = [
        "import",
        "exec",
        "eval",
        "__",
        "getattr",
        "setattr",
        "delattr",
    ]
    if any(pattern in constraint.lower() for pattern in dangerous_patterns):
        logger.warning(f"Dangerous pattern detected in constraint: {constraint}")
        return False

    # Check that only allowed characters are present
    allowed_chars = ALLOWED_CONSTRAINT_OPERATORS | set("0123456789.") | set("".join(param_names))
    for char in clean_constraint:
        if char not in allowed_chars and not char.isalpha():
            logger.warning(f"Disallowed character '{char}' in constraint: {constraint}")
            return False

    # Basic syntax validation using AST
    try:
        # Replace parameter names with dummy values for parsing
        test_expr = clean_constraint
        for param in param_names:
            test_expr = test_expr.replace(param, "1.0")

        # Try to parse as AST to check basic syntax
        ast.parse(test_expr, mode="eval")
        return True
    except (SyntaxError, ValueError) as e:
        logger.warning(f"Invalid syntax in constraint '{constraint}': {e}")
        return False


def create_kernel_for_parameters(
    params_config: Dict[str, Dict[str, Any]],
    ard_num_dims: int,
    kernel_type: str = "matern-2.5"
) -> object:
    """
    Create appropriate kernel based on parameter types and user selection.

    Uses UnifiedExponentialKernel for mixed variables or MaternKernel for continuous
    problems with configurable smoothness parameter (nu).

    Args:
        params_config: PyMBO parameter configuration dictionary
        ard_num_dims: Number of dimensions for ARD
        kernel_type: Kernel type selection. Options:
            - "matern-0.5": Exponential kernel (rough, non-differentiable)
            - "matern-1.5": Once differentiable Matérn
            - "matern-2.5": Twice differentiable Matérn (default)
            - "rbf": RBF/Squared Exponential (infinitely smooth)
            - "unified": Force UnifiedExponentialKernel
            - "auto": Auto-select based on parameter types (legacy behavior)

    Returns:
        Configured kernel (UnifiedExponentialKernel or MaternKernel/RBFKernel)
    """
    # Parse kernel type
    kernel_type = kernel_type.lower().strip()

    # Auto-select kernel based on parameter types (legacy behavior)
    if kernel_type == "auto" or kernel_type == "unified":
        if UNIFIED_KERNEL_AVAILABLE and params_config:
            try:
                # Check for mixed variables or non-continuous variables
                has_mixed_vars = is_mixed_variable_problem(params_config)
                var_summary = get_variable_type_summary(params_config)

                has_categorical = var_summary["type_counts"]["categorical"] > 0
                has_discrete = var_summary["type_counts"]["discrete"] > 0

                if has_mixed_vars or has_categorical or has_discrete or kernel_type == "unified":
                    logger.info(
                        f"Using UnifiedExponentialKernel for {'mixed variables' if has_mixed_vars or has_categorical or has_discrete else 'user selection'}: "
                        f"{var_summary['type_counts']}"
                    )
                    return UnifiedExponentialKernel(params_config, ard_num_dims=ard_num_dims)

            except Exception as e:
                logger.warning(
                    f"Failed to create UnifiedExponentialKernel ({e}), falling back to MaternKernel"
                )
                kernel_type = "matern-2.5"  # Fall back to default Matérn

    # Create standard kernel based on user selection
    if kernel_type == "matern-0.5":
        logger.info("Using Matérn kernel with nu=0.5 (Exponential kernel)")
        return MaternKernel(nu=0.5, ard_num_dims=ard_num_dims)
    elif kernel_type == "matern-1.5":
        logger.info("Using Matérn kernel with nu=1.5 (once differentiable)")
        return MaternKernel(nu=1.5, ard_num_dims=ard_num_dims)
    elif kernel_type == "matern-2.5" or kernel_type == "matern":
        logger.info("Using Matérn kernel with nu=2.5 (twice differentiable)")
        return MaternKernel(nu=2.5, ard_num_dims=ard_num_dims)
    elif kernel_type == "rbf" or kernel_type == "squared-exponential":
        from gpytorch.kernels import RBFKernel
        logger.info("Using RBF kernel (infinitely differentiable)")
        return RBFKernel(ard_num_dims=ard_num_dims)
    else:
        # Unknown kernel type - fall back to default
        logger.warning(f"Unknown kernel type '{kernel_type}', falling back to Matérn-2.5")
        return MaternKernel(nu=2.5, ard_num_dims=ard_num_dims)


class EnhancedMultiObjectiveOptimizer:
    """
    Simplified multi-objective Bayesian optimizer that actually works
    """

    def __init__(
        self,
        params_config: Dict[str, Dict[str, Any]],
        responses_config: Dict[str, Dict[str, Any]],
        general_constraints: Optional[List[str]] = None,
        random_seed: Optional[int] = None,
        deterministic: bool = False,
        initial_sampling_method: str = "random",
        num_restarts: int = 5,  # Reduced from 10 for faster optimization
        raw_samples: int = 50,  # Reduced from 100 for faster optimization
        fast_validation_mode: bool = False,  # Ultra-fast mode for validation scenarios
        max_gp_points: Optional[int] = None,  # Maximum points for GP training (data subsampling)
        kernel_type: str = "matern-2.5",  # Kernel selection for GP models
        **kwargs,
    ):
        """
        Initializes the EnhancedMultiObjectiveOptimizer.

        Args:
            params_config: Configuration for input parameters, including their type,
                           bounds/values, and optional optimization goals.
            responses_config: Configuration for response variables (objectives),
                              including their names and optimization goals (Maximize/Minimize).
            general_constraints: Optional list of string representations of general
                                 constraints (e.g., "x1 + x2 <= 10"). Not fully implemented
                                 in this simplified version but kept for future expansion.
            random_seed: Optional integer to seed the random number generators for
                         reproducibility.
            initial_sampling_method: Method to use for initial data generation when
                                     insufficient experimental data is available.
                                     Currently supports "random" and "LHS" (Latin Hypercube Sampling).
            max_gp_points: Optional maximum number of data points to use for GP training.
                           If specified, keeps only the most recent N points to limit
                           matrix size and improve performance. Recommended: 50-200 points.
                           Default: None (no limit).
            kernel_type: Type of kernel to use for GP models. Options:
                        - "matern-0.5": Exponential kernel (rough)
                        - "matern-1.5": Once differentiable
                        - "matern-2.5": Twice differentiable (default)
                        - "rbf": RBF/Squared Exponential (infinitely smooth)
                        - "auto": Auto-select based on parameter types
            **kwargs: Additional keyword arguments (e.g., for device configuration).
        """
        # Validate configuration
        if not params_config:
            raise ValueError("Parameters configuration cannot be empty")
        if not responses_config:
            raise ValueError("At least one optimization objective must be defined")

        print("ENHANCED OPTIMIZER INITIALIZATION")
        print(f"Received params_config: {params_config}")
        print(f"Received responses_config: {responses_config}")

        self.params_config = params_config
        self.responses_config = responses_config
        self.general_constraints = general_constraints or []
        self.kernel_type = kernel_type  # Store kernel selection for GP model creation

        print("OPTIMIZER CONFIG STORED:")
        for name, config in self.params_config.items():
            print(
                f"Parameter '{name}': goal='{config.get('goal', 'MISSING')}', config={config}"
            )
        for name, config in self.responses_config.items():
            print(
                f"Response '{name}': goal='{config.get('goal', 'MISSING')}', config={config}"
            )

        # Data subsampling configuration for performance optimization
        if max_gp_points is None:
            if fast_validation_mode:
                # Auto-set conservative limit for fast validation mode
                self.max_gp_points = FAST_MODE_MAX_GP_POINTS
                logger.info(
                    f"Fast validation mode: auto-limiting GP training to {self.max_gp_points} points"
                )
            else:
                # No limit by default for regular mode
                self.max_gp_points = None
        else:
            self.max_gp_points = max_gp_points
            if max_gp_points > MAX_RECOMMENDED_GP_POINTS:
                logger.warning(
                    f"max_gp_points ({max_gp_points}) exceeds recommended limit "
                    f"({MAX_RECOMMENDED_GP_POINTS}). Performance may degrade significantly."
                )
            logger.info(
                f"Data subsampling enabled: GP training limited to {self.max_gp_points} most recent points"
            )

        # Cache for hypervolume data to avoid recalculation on load
        self._cached_hypervolume_data = {}

        # Import device manager for hardware-agnostic device selection
        from pymbo.core.device_manager import get_device_manager, DeviceMemoryManager

        # Import BLAS optimizer for matrix operation performance
        from pymbo.core.blas_optimizer import get_blas_optimizer

        # Get the optimal device (CUDA, MPS, or CPU) for PyTorch operations
        # Add fallback to CPU if CUDA has issues
        try:
            self.device_manager = get_device_manager()
            self.device = self.device_manager.device
            self.memory_manager = DeviceMemoryManager(self.device_manager)

            # Test CUDA functionality if using CUDA
            if str(self.device).startswith("cuda"):
                test_tensor = torch.zeros(1, device=self.device)
                _ = test_tensor + 1  # Simple operation to test CUDA

        except Exception as e:
            logger.warning(f"Device initialization failed ({e}), falling back to CPU")
            self.device = torch.device("cpu")
            self.memory_manager = None

        # Set the default data type for PyTorch tensors to double precision
        self.dtype = torch.double

        # Log device information
        device_info = self.device_manager.get_device_info()
        logger.info(
            f"Optimizer using device: {device_info['device']} ({device_info['device_name']})"
        )
        if device_info.get("total_memory_gb", 0) > 0:
            logger.info(f"Available memory: {device_info['available_memory_gb']:.1f} GB")
        # Store the chosen initial sampling method.
        self.initial_sampling_method = initial_sampling_method
        self.num_restarts = num_restarts
        self.raw_samples = raw_samples
        self.fast_validation_mode = fast_validation_mode

        # BLAS optimization for matrix operations
        self.blas_optimizer = get_blas_optimizer()
        self.blas_optimizations_applied = False

        # Apply BLAS optimizations automatically for better performance
        try:
            if not self.blas_optimizer.optimizations_applied:
                optimization_results = self.blas_optimizer.apply_optimizations()
                self.blas_optimizations_applied = True
                logger.info("đźš€ BLAS optimizations applied for improved matrix performance")

                # Log key optimizations
                applied = optimization_results.get("optimizations_applied", [])
                if applied:
                    logger.info(
                        f"   Applied: {', '.join(applied[:3])}{'...' if len(applied) > 3 else ''}"
                    )
            else:
                self.blas_optimizations_applied = True
                logger.info("âś… BLAS optimizations already applied")
        except Exception as e:
            logger.warning(f"âš ď¸Ź BLAS optimization failed: {e}")
            self.blas_optimizations_applied = False

        # Acquisition function caching for performance
        self._acquisition_cache = {}
        self._candidate_cache = []
        self._cache_max_size = 50  # Maximum cached candidates
        self._slow_optimizations = 0  # Counter for slow optimization fallbacks

        # Apply random seed for reproducibility if provided.
        self.random_seed = random_seed
        self.deterministic = deterministic
        if random_seed is not None:
            logger.info("Seeding RNGs for reproducibility (seed=%s)", random_seed)
            self._initial_random_state = seed_everything(random_seed)
        else:
            self._initial_random_state = capture_random_state()

        self._torch_deterministic_previous: Optional[bool] = None
        if self.deterministic and hasattr(torch, "are_deterministic_algorithms_enabled"):
            try:
                self._torch_deterministic_previous = torch.are_deterministic_algorithms_enabled()
                torch.use_deterministic_algorithms(True)
            except Exception as exc:
                logger.warning("Failed to enable deterministic algorithms: %s", exc)
                self._torch_deterministic_previous = None

        # Configure cuDNN determinism if available
        self._cudnn_prev: Dict[str, Optional[bool]] = {"benchmark": None, "deterministic": None}
        try:
            if (
                self.deterministic
                and hasattr(torch, "backends")
                and hasattr(torch.backends, "cudnn")
            ):
                self._cudnn_prev["benchmark"] = torch.backends.cudnn.benchmark
                self._cudnn_prev["deterministic"] = torch.backends.cudnn.deterministic
                torch.backends.cudnn.benchmark = False
                torch.backends.cudnn.deterministic = True
        except Exception as exc:
            logger.debug("Failed to configure cuDNN determinism: %s", exc)

        # Initialize core components of the optimizer.
        self.parameter_transformer = SimpleParameterTransformer(params_config)

        # Set up the optimization objectives based on the responses_config.
        self._setup_objectives()

        # Initialize data structures for storing experimental data and iteration history.
        self._initialize_data_storage()

        logger.info(f"Multi-objective optimizer initialized on {self.device}")

    def _setup_objectives(self) -> None:
        """
        Sets up the objective names and their optimization directions (maximize/minimize)
        based on the `responses_config` and `params_config`. Also extracts optimization
        weights for weighted multi-objective optimization.
        """
        self.objective_names = []
        self.objective_directions = []  # 1 for maximize, -1 for minimize
        self.objective_weights = []  # Optimization weights from importance ratings
        self.objective_definitions: List[Dict[str, Any]] = []

        # Process responses defined as objectives
        for name, config in self.responses_config.items():
            goal = config.get("goal", "None")
            if goal in ["Maximize", "Minimize"]:
                self.objective_names.append(name)
                self.objective_directions.append(1 if goal == "Maximize" else -1)

                # Extract optimization weight (default to 1.0 if not specified)
                weight = config.get("optimization_weight", 1.0)
                self.objective_weights.append(weight)
                self.objective_definitions.append(
                    {
                        "type": "response",
                        "name": name,
                        "goal": goal,
                        "weight": weight,
                        "config": config,
                    }
                )

            elif goal == "Target":
                # Target goals for responses become deviation minimization objectives
                target_value = config.get("target_value")
                if target_value is not None:
                    # For Target responses, we want to minimize deviation from target
                    # The response itself is already measured, we just need to add it as objective
                    self.objective_names.append(name)
                    self.objective_directions.append(-1)  # Minimize (deviation is handled in desirability)

                    weight = config.get("optimization_weight", 1.0)
                    self.objective_weights.append(weight)
                    self.objective_definitions.append(
                        {
                            "type": "response_target",
                            "name": name,
                            "goal": goal,
                            "weight": weight,
                            "config": config,
                            "target_value": target_value,
                        }
                    )

                    logger.info(
                        f"Added Target response objective '{name}' for target={target_value}"
                    )

            elif goal in ["Range", "In Range"]:
                # Range goals for responses - optimize to stay within range
                range_bounds = config.get("range_bounds")
                if range_bounds and len(range_bounds) == 2:
                    # For Range responses, we add them as objectives to be kept in range
                    # The acquisition function will treat this as a satisfaction constraint
                    self.objective_names.append(name)
                    self.objective_directions.append(1)  # Maximize satisfaction (staying in range)

                    weight = config.get("optimization_weight", 1.0)
                    self.objective_weights.append(weight)
                    self.objective_definitions.append(
                        {
                            "type": "response_range",
                            "name": name,
                            "goal": "Range",  # Normalize to "Range"
                            "weight": weight,
                            "config": config,
                            "range_bounds": range_bounds,
                        }
                    )

                    logger.info(
                        f"Added Range response objective '{name}' for range=[{range_bounds[0]}, {range_bounds[1]}]"
                    )
                else:
                    logger.warning(
                        f"Response '{name}' has Range goal but no valid range_bounds specified. Skipping."
                    )

        # Process parameters that might also be objectives (less common but supported)
        for name, config in self.params_config.items():
            goal = config.get("goal", "None")
            if goal in ["Maximize", "Minimize"]:
                self.objective_names.append(name)
                self.objective_directions.append(1 if goal == "Maximize" else -1)

                # Extract optimization weight (default to 1.0 if not specified)
                weight = config.get("optimization_weight", 1.0)
                self.objective_weights.append(weight)
                self.objective_definitions.append(
                    {
                        "type": "parameter",
                        "name": name,
                        "goal": goal,
                        "weight": weight,
                        "config": config,
                    }
                )

            elif goal == "Target":
                # Target goals become deviation minimization objectives
                target_value = config.get("target_value")
                if target_value is not None:
                    objective_name = f"{name}_target_deviation"
                    self.objective_names.append(objective_name)
                    self.objective_directions.append(-1)  # Minimize deviation

                    # Extract optimization weight (default to 1.0 if not specified)
                    weight = config.get("optimization_weight", 1.0)
                    self.objective_weights.append(weight)
                    self.objective_definitions.append(
                        {
                            "type": "parameter_target",
                            "name": name,
                            "goal": goal,
                            "weight": weight,
                            "config": config,
                            "objective_name": objective_name,
                        }
                    )

                    logger.info(
                        f"Added Target deviation objective '{objective_name}' for target={target_value}"
                    )

        # Check if we have non-uniform weights (indicating user-defined importance)
        self.has_weighted_objectives = len(set(self.objective_weights)) > 1

        logger.info(f"Setup {len(self.objective_names)} objectives: {self.objective_names}")

        if self.has_weighted_objectives:
            logger.info(
                f"Objective weights: {dict(zip(self.objective_names, self.objective_weights))}"
            )
        else:
            logger.info("Using equal weighting for all objectives")

        if not self.objective_names:
            raise ValueError("At least one optimization objective must be defined.")

        # Setup parameter constraints (Target and Range goals)
        self._setup_parameter_constraints()

    def _setup_parameter_constraints(self) -> None:
        # Delegate to constraints helper
        try:
            from ._constraints import setup_parameter_constraints as _setup

            return _setup(self)
        except Exception:
            # Fallback: keep previously inlined logic (no-op if failure)
            self.parameter_constraints = []
            self.constraint_tolerance = 1e-3

    def _calculate_target_deviations(self, data_df: pd.DataFrame) -> pd.DataFrame:
        try:
            from ._constraints import calculate_target_deviations as _calc_dev

            return _calc_dev(self, data_df)
        except Exception:
            return data_df

    def _initialize_data_storage(self) -> None:
        """
        Initializes the data storage attributes for experimental data, iteration history,
        and a cache for models.
        """
        self.experimental_data = (
            pd.DataFrame()
        )  # Stores all experimental data (parameters + responses)
        self.iteration_history = []  # Stores historical data about each optimization iteration
        self.models_cache = {}  # Cache for storing trained GP models

        # New fields for Option 1 handling
        self.has_baseline_data = False  # Track if initial batch import was done
        self.baseline_hypervolume = 0.0  # Hypervolume from baseline data
        self.optimization_iterations = (
            0  # Count of actual optimization iterations (not batch imports)
        )

    def _generate_doe_samples(
        self, n_suggestions: int, method: str = "LHS"
    ) -> List[Dict[str, Any]]:
        """Delegate DoE sampling to sampling helper."""
        try:
            from ._sampling import doe_samples as _doe

            return _doe(self, n_suggestions, method)
        except Exception:
            return self._generate_random_samples(n_suggestions)

    def add_experimental_data(
        self, data_df: pd.DataFrame, is_optimization_result: bool = False
    ) -> None:
        """
        Adds new experimental data points to the optimizer's internal data storage.

        Implements hybrid approach:
        - First import: Option 1 (baseline at iteration 0)
        - Subsequent imports: Option 2 (sequential iterations)
        - Optimization results: Always sequential iterations

        Args:
            data_df (pd.DataFrame): A Pandas DataFrame containing the new experimental
                                    data. It must include columns for all parameters
                                    and response variables defined in the configuration.
            is_optimization_result (bool): True if this data comes from suggest_next_experiment(),
                                          False if this is imported/batch data.
        Raises:
            Exception: If an error occurs during data addition or processing.
        """
        try:
            n_new_points = len(data_df)
            logger.info(f"đź“Ą Adding {n_new_points} new experimental data points to optimizer")

            # Calculate target deviations for new data
            data_with_deviations = self._calculate_target_deviations(data_df)

            # Concatenate new data with existing experimental data
            if self.experimental_data.empty:
                self.experimental_data = data_with_deviations.copy()
            else:
                self.experimental_data = pd.concat(
                    [self.experimental_data, data_with_deviations], ignore_index=True
                )

            # Apply data subsampling/sliding window for performance optimization
            if self.max_gp_points is not None and len(self.experimental_data) > self.max_gp_points:
                original_size = len(self.experimental_data)
                self.experimental_data = self.experimental_data.tail(
                    self.max_gp_points
                ).reset_index(drop=True)
                logger.info(
                    f"Applied data subsampling: kept {len(self.experimental_data)} most recent points "
                    f"(removed {original_size - len(self.experimental_data)} older points for performance)"
                )

            # Update the PyTorch tensors used for training the GP models
            self._update_training_data()

            # Calculate the current hypervolume indicator
            hypervolume_data = self._calculate_hypervolume()
            current_hv = hypervolume_data.get("raw_hypervolume", 0.0)

            # Determine iteration handling based on data type and current state
            if not self.has_baseline_data and not is_optimization_result:
                # FIRST IMPORT: Option 1 - treat as baseline (iteration 0)
                self._handle_baseline_data_import(data_df, hypervolume_data, n_new_points)

            elif is_optimization_result:
                # OPTIMIZATION RESULT: Always treat as sequential iteration
                self._handle_optimization_result(data_df, hypervolume_data, n_new_points)

            else:
                # SUBSEQUENT IMPORTS: Option 2 - treat as sequential iteration
                self._handle_subsequent_batch_import(data_df, hypervolume_data, n_new_points)

            logger.info(
                f"đź“Š Dataset now contains {len(self.experimental_data)} total experiments"
            )
            logger.info(
                f"đź“ Current hypervolume: {current_hv:.6f} (baseline: {self.baseline_hypervolume:.6f})"
            )

        except Exception as e:
            logger.error(f"Error adding experimental data: {e}")
            raise

    def _handle_baseline_data_import(
        self, data_df: pd.DataFrame, hypervolume_data: dict, n_points: int
    ) -> None:
        """Handle the first batch import as baseline data (iteration 0)."""
        self.has_baseline_data = True
        self.baseline_hypervolume = hypervolume_data.get("raw_hypervolume", 0.0)

        iteration_record = {
            "iteration": 0,  # Baseline iteration
            "iteration_type": "baseline_import",
            "timestamp": pd.Timestamp.now(),
            "n_experiments": len(self.experimental_data),
            "n_new_points": n_points,
            "hypervolume": hypervolume_data,
            "hypervolume_raw": hypervolume_data.get("raw_hypervolume", 0.0),
            "hypervolume_normalized": hypervolume_data.get("normalized_hypervolume", 0.0),
            "is_baseline": True,
            "improvement_over_baseline": 0.0,  # By definition, baseline has no improvement
            "description": f"Baseline established from {n_points} imported experiments",
        }

        self.iteration_history.append(iteration_record)
        logger.info(
            f"đźŹ Baseline established from {n_points} experiments (HV: {self.baseline_hypervolume:.6f})"
        )

    def _handle_optimization_result(
        self, data_df: pd.DataFrame, hypervolume_data: dict, n_points: int
    ) -> None:
        """Handle results from optimization (suggest_next_experiment)."""
        self.optimization_iterations += 1
        current_hv = hypervolume_data.get("raw_hypervolume", 0.0)
        improvement = current_hv - self.baseline_hypervolume
        relative_improvement = (
            (improvement / self.baseline_hypervolume * 100)
            if self.baseline_hypervolume > 0
            else 0.0
        )

        iteration_record = {
            "iteration": self.optimization_iterations,
            "iteration_type": "optimization",
            "timestamp": pd.Timestamp.now(),
            "n_experiments": len(self.experimental_data),
            "n_new_points": n_points,
            "hypervolume": hypervolume_data,
            "hypervolume_raw": current_hv,
            "hypervolume_normalized": hypervolume_data.get("normalized_hypervolume", 0.0),
            "is_baseline": False,
            "improvement_over_baseline": improvement,
            "relative_improvement_pct": relative_improvement,
            "description": f"Optimization iteration {self.optimization_iterations} (+{n_points} points)",
        }

        # Add convergence analysis for optimization iterations
        if self.optimization_iterations >= 3:
            convergence_info = self.check_hypervolume_convergence()
            iteration_record["convergence_analysis"] = {
                "converged": convergence_info.get("converged", False),
                "relative_improvement": convergence_info.get("relative_improvement", 0.0),
                "recommendation": convergence_info.get("recommendation", "continue"),
            }

        self.iteration_history.append(iteration_record)
        logger.info(
            f"đźŽŻ Optimization iteration {self.optimization_iterations}: HV improved by {improvement:.6f} ({relative_improvement:.2f}%)"
        )

    def _handle_subsequent_batch_import(
        self, data_df: pd.DataFrame, hypervolume_data: dict, n_points: int
    ) -> None:
        """Handle subsequent batch imports as sequential iterations (Option 2)."""
        # Count all non-baseline iterations (both optimization and batch imports)
        non_baseline_iterations = len(
            [h for h in self.iteration_history if not h.get("is_baseline", False)]
        )
        iteration_num = non_baseline_iterations + 1

        current_hv = hypervolume_data.get("raw_hypervolume", 0.0)
        improvement = current_hv - self.baseline_hypervolume
        relative_improvement = (
            (improvement / self.baseline_hypervolume * 100)
            if self.baseline_hypervolume > 0
            else 0.0
        )

        iteration_record = {
            "iteration": iteration_num,
            "iteration_type": "batch_import",
            "timestamp": pd.Timestamp.now(),
            "n_experiments": len(self.experimental_data),
            "n_new_points": n_points,
            "hypervolume": hypervolume_data,
            "hypervolume_raw": current_hv,
            "hypervolume_normalized": hypervolume_data.get("normalized_hypervolume", 0.0),
            "is_baseline": False,
            "improvement_over_baseline": improvement,
            "relative_improvement_pct": relative_improvement,
            "description": f"Batch import iteration {iteration_num} (+{n_points} points)",
        }

        self.iteration_history.append(iteration_record)
        logger.info(
            f"đź“¦ Batch import iteration {iteration_num}: HV improved by {improvement:.6f} ({relative_improvement:.2f}%)"
        )

    def tell_experiment_result(
        self, params_dict: Dict[str, Any], response_dict: Dict[str, Any]
    ) -> None:
        """
        Add a single experiment result from optimization (suggest_next_experiment).
        This is a convenience method that automatically marks the data as optimization result.

        Args:
            params_dict: Dictionary of parameter values
            response_dict: Dictionary of response values
        """
        # Convert single experiment to DataFrame
        combined_dict = {**params_dict, **response_dict}
        result_df = pd.DataFrame([combined_dict])

        # Add as optimization result (triggers proper iteration tracking)
        self.add_experimental_data(result_df, is_optimization_result=True)

    def tell_experiment_results(self, results: List[Dict[str, Any]]) -> None:
        """
        Add multiple experiment results from optimization (suggest_next_experiment).

        Args:
            results: List of dictionaries, each containing both parameters and responses
        """
        if not results:
            return

        # Convert to DataFrame
        results_df = pd.DataFrame(results)

        # Add as optimization result (triggers proper iteration tracking)
        self.add_experimental_data(results_df, is_optimization_result=True)

    def _update_training_data(self) -> None:
        """
        Updates the `train_X` and `train_Y` tensors used for training the
        Gaussian Process (GP) models. Uses optimized vectorized operations
        for 10-50x speedup compared to row-by-row processing.
        """
        # Delegated modular implementation
        try:
            from ._models import update_training_data as _update

            return _update(self)
        except Exception:
            pass
        if self.experimental_data.empty:
            logger.info("No experimental data to update training tensors.")
            return

        import time

        start_time = time.time()
        n_rows = len(self.experimental_data)

        try:
            # OPTIMIZED: Extract all parameter data at once (vectorized)
            param_names = self.parameter_transformer.param_names
            param_data = self.experimental_data[param_names].values  # numpy array

            # OPTIMIZED: Extract all objective data at once (vectorized)
            objective_data = []
            for obj_name in self.objective_names:
                if obj_name in self.experimental_data.columns:
                    values = self.experimental_data[obj_name].values

                    # Handle list values (multiple replicates) efficiently
                    processed_values = []
                    for value in values:
                        if isinstance(value, list) and len(value) > 0:
                            processed_values.append(np.mean(value))
                        else:
                            processed_values.append(float(value) if not pd.isna(value) else np.nan)

                    objective_data.append(processed_values)
                else:
                    # Missing objective - fill with NaN
                    objective_data.append([np.nan] * n_rows)

            # Convert to numpy arrays
            objective_data = np.array(objective_data).T  # (n_samples, n_objectives)

            # OPTIMIZED: Batch parameter transformation (process in chunks to avoid memory issues)
            batch_size = min(1000, n_rows)  # Process up to 1000 rows at a time
            X_batches = []

            for i in range(0, n_rows, batch_size):
                batch_end = min(i + batch_size, n_rows)
                param_batch = param_data[i:batch_end]

                # Convert batch to list of dictionaries
                param_dicts = [
                    {param_names[j]: param_batch[k, j] for j in range(len(param_names))}
                    for k in range(len(param_batch))
                ]

                # Transform each parameter dictionary to tensor
                X_tensors = [
                    self.parameter_transformer.params_to_tensor(param_dict)
                    for param_dict in param_dicts
                ]

                # Stack batch tensors
                if X_tensors:
                    X_batch = torch.stack(X_tensors)
                    X_batches.append(X_batch)

            # Combine all batches
            if X_batches:
                self.train_X = torch.cat(X_batches, dim=0).to(self.device, self.dtype)
            else:
                logger.warning("No valid parameter data found")
                return

            # OPTIMIZED: Convert objectives to tensor (vectorized)
            self.train_Y = torch.tensor(objective_data, dtype=self.dtype, device=self.device)

            # NEW: Transform Target and Range objectives before applying directions
            for i, obj_def in enumerate(self.objective_definitions):
                obj_type = obj_def.get("type")

                if obj_type == "response_target":
                    # Transform to absolute deviation from target
                    target_value = obj_def.get("target_value")
                    if target_value is not None:
                        # Minimize absolute deviation: |response - target|
                        self.train_Y[:, i] = torch.abs(self.train_Y[:, i] - target_value)
                        logger.debug(
                            f"Transformed '{obj_def['name']}' to deviation from target={target_value}"
                        )

                elif obj_type == "response_range":
                    # Transform to range violation penalty
                    range_bounds = obj_def.get("range_bounds")
                    if range_bounds and len(range_bounds) == 2:
                        lower, upper = float(range_bounds[0]), float(range_bounds[1])
                        # Penalty: 0 if in range, distance from range if outside
                        # For values below lower: penalty = lower - value
                        # For values above upper: penalty = value - upper
                        # For values in range: penalty = 0
                        values = self.train_Y[:, i]
                        below_mask = values < lower
                        above_mask = values > upper

                        # Create penalty tensor (0 inside range, positive outside)
                        penalty = torch.zeros_like(values)
                        penalty[below_mask] = lower - values[below_mask]
                        penalty[above_mask] = values[above_mask] - upper

                        self.train_Y[:, i] = penalty
                        logger.debug(
                            f"Transformed '{obj_def['name']}' to range violation penalty for range=[{lower}, {upper}]"
                        )

            # OPTIMIZED: Apply objective directions efficiently (vectorized)
            for i, direction in enumerate(self.objective_directions):
                if direction == -1:  # Minimization objective
                    self.train_Y[:, i] = -self.train_Y[:, i]

            update_time = time.time() - start_time
            logger.info(
                f"đź”„ Training data updated: {self.train_X.shape[0]} samples (X: {self.train_X.shape}, Y: {self.train_Y.shape}) "
                f"processed in {update_time:.3f}s ({n_rows / update_time:.0f} samples/sec)"
            )

        except Exception as e:
            logger.error(f"Error in optimized training data update: {e}")
            logger.info("Falling back to row-by-row processing...")

            # FALLBACK: Original row-by-row method if optimization fails
            X_list = []
            Y_list = []

            for _, row in self.experimental_data.iterrows():
                param_dict = {
                    param_name: row[param_name]
                    for param_name in self.parameter_transformer.param_names
                }
                X_tensor = self.parameter_transformer.params_to_tensor(param_dict)
                X_list.append(X_tensor)

                y_values = []
                for obj_name in self.objective_names:
                    if obj_name in row:
                        value = row[obj_name]
                        if isinstance(value, list) and len(value) > 0:
                            mean_value = np.mean(value)
                        else:
                            mean_value = float(value)
                        y_values.append(mean_value)
                    else:
                        y_values.append(np.nan)

                Y_tensor = torch.tensor(y_values, dtype=self.dtype, device=self.device)
                Y_list.append(Y_tensor)

            if X_list and Y_list:
                self.train_X = torch.stack(X_list).to(self.device, self.dtype)
                self.train_Y = torch.stack(Y_list).to(self.device, self.dtype)

                # Apply Target and Range transformations (same as optimized path)
                for i, obj_def in enumerate(self.objective_definitions):
                    obj_type = obj_def.get("type")

                    if obj_type == "response_target":
                        target_value = obj_def.get("target_value")
                        if target_value is not None:
                            self.train_Y[:, i] = torch.abs(self.train_Y[:, i] - target_value)

                    elif obj_type == "response_range":
                        range_bounds = obj_def.get("range_bounds")
                        if range_bounds and len(range_bounds) == 2:
                            lower, upper = float(range_bounds[0]), float(range_bounds[1])
                            values = self.train_Y[:, i]
                            below_mask = values < lower
                            above_mask = values > upper
                            penalty = torch.zeros_like(values)
                            penalty[below_mask] = lower - values[below_mask]
                            penalty[above_mask] = values[above_mask] - upper
                            self.train_Y[:, i] = penalty

                for i, direction in enumerate(self.objective_directions):
                    if direction == -1:
                        self.train_Y[:, i] = -self.train_Y[:, i]

                fallback_time = time.time() - start_time
                logger.info(
                    f"Training data updated (fallback): X shape {self.train_X.shape}, "
                    f"Y shape {self.train_Y.shape} in {fallback_time:.3f}s"
                )

    def _calculate_adaptive_reference_point(self, clean_Y: torch.Tensor) -> torch.Tensor:
        """Compute a dominated reference point for hypervolume calculations."""
        from ._hv import calculate_adaptive_reference_point

        return calculate_adaptive_reference_point(clean_Y, eps=EPS)

    def _calculate_hypervolume(self) -> Dict[str, float]:
        """Delegate hypervolume calculation to the _hv helper module."""
        default_result = {
            "raw_hypervolume": 0.0,
            "normalized_hypervolume": 0.0,
            "reference_point_adaptive": True,
            "data_points_used": 0,
        }
        try:
            from ._hv import calculate_hypervolume as _calc_hv

            return _calc_hv(self.train_Y, self.objective_names)
        except Exception as e:
            logger.error(f"Error in _calculate_hypervolume: {e}", exc_info=True)
            return default_result

    def _calculate_hypervolume_legacy(self) -> float:
        """
        Legacy method that returns only the raw hypervolume for backward compatibility.
        This maintains compatibility with existing code that expects a float return.

        Returns:
            float: Raw hypervolume value
        """
        hv_result = self._calculate_hypervolume()
        return hv_result["raw_hypervolume"]

    def check_hypervolume_convergence(
        self, window_size: int = 5, threshold: float = 0.01, use_normalized: bool = True
    ) -> Dict[str, Any]:
        """
        Checks for hypervolume-based convergence using a sliding window approach.
        Only considers optimization iterations for convergence analysis (excludes baseline and batch imports).

        Args:
            window_size: Number of recent optimization iterations to consider for convergence
            threshold: Relative change threshold below which we consider convergence
            use_normalized: Whether to use normalized hypervolume for convergence check

        Returns:
            Dict containing convergence status, metrics, and recommendations
        """
        # Delegated fast path
        try:
            from ._progress import check_hv_convergence

            return check_hv_convergence(
                self.iteration_history, window_size, threshold, use_normalized
            )
        except Exception:
            pass

        convergence_result = {
            "converged": False,
            "progress_stagnant": False,
            "iterations_stable": 0,
            "relative_improvement": 0.0,
            "recommendation": "continue",
            "confidence": "low",
        }

        try:
            # Filter to only optimization iterations (exclude baseline and batch imports)
            optimization_iterations = [
                h for h in self.iteration_history if h.get("iteration_type") == "optimization"
            ]

            if len(optimization_iterations) < window_size:
                convergence_result["recommendation"] = "continue - insufficient optimization data"
                convergence_result["note"] = (
                    f"Need {window_size - len(optimization_iterations)} more optimization iterations"
                )
                return convergence_result

            # Extract hypervolume values from recent optimization iterations
            hv_key = "normalized_hypervolume" if use_normalized else "hypervolume"

            # Handle both old format (float) and new format (dict) for recent optimization iterations
            recent_hvs = []
            for iteration in optimization_iterations[-window_size:]:
                hv_value = iteration.get("hypervolume", 0.0)
                if isinstance(hv_value, dict):
                    recent_hvs.append(hv_value.get(hv_key, 0.0))
                else:
                    # Legacy format - use raw value
                    recent_hvs.append(hv_value)

            if not recent_hvs or all(hv == 0.0 for hv in recent_hvs):
                convergence_result["recommendation"] = "continue - no valid hypervolume data"
                return convergence_result

            # Calculate relative improvement
            max_hv = max(recent_hvs)
            min_hv = min(recent_hvs)

            if max_hv > 1e-12:
                relative_improvement = (max_hv - min_hv) / max_hv
            else:
                relative_improvement = 0.0

            convergence_result["relative_improvement"] = relative_improvement

            # Check for convergence
            if relative_improvement < threshold:
                convergence_result["converged"] = True
                convergence_result["iterations_stable"] = window_size
                convergence_result["confidence"] = "high" if window_size >= 10 else "medium"

                # Additional check: is hypervolume actually improving over longer period?
                if len(optimization_iterations) >= window_size * 2:
                    earlier_hvs = []
                    for iteration in optimization_iterations[-(window_size * 2) : -window_size]:
                        hv_value = iteration.get("hypervolume", 0.0)
                        if isinstance(hv_value, dict):
                            earlier_hvs.append(hv_value.get(hv_key, 0.0))
                        else:
                            earlier_hvs.append(hv_value)

                    if earlier_hvs and max(earlier_hvs) > 1e-12:
                        long_term_improvement = (max(recent_hvs) - max(earlier_hvs)) / max(
                            earlier_hvs
                        )

                        if long_term_improvement < threshold / 2:
                            convergence_result["progress_stagnant"] = True
                            convergence_result["recommendation"] = "consider_stopping"
                        else:
                            convergence_result["recommendation"] = "continue_cautiously"
                    else:
                        convergence_result["recommendation"] = "continue_cautiously"
                else:
                    convergence_result["recommendation"] = "continue_cautiously"
            else:
                convergence_result["recommendation"] = "continue"

            # Calculate trend
            if len(recent_hvs) >= 3:
                # Simple linear trend analysis
                x = list(range(len(recent_hvs)))
                n = len(recent_hvs)
                sum_x = sum(x)
                sum_y = sum(recent_hvs)
                sum_xy = sum(xi * yi for xi, yi in zip(x, recent_hvs))
                sum_x2 = sum(xi * xi for xi in x)

                if n * sum_x2 - sum_x * sum_x != 0:
                    slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
                    convergence_result["trend_slope"] = slope

                    if slope < -threshold / 10:
                        convergence_result["recommendation"] = "investigate_degradation"

            logger.debug(f"Convergence check: {convergence_result}")
            return convergence_result

        except Exception as e:
            logger.error(f"Error in convergence check: {e}", exc_info=True)
            convergence_result["recommendation"] = "continue - error in analysis"
            return convergence_result

    def get_optimization_progress_summary(self) -> Dict[str, Any]:
        """
        Provides a comprehensive summary of optimization progress including
        hypervolume trends, convergence status, and recommendations.
        Uses the hybrid approach: distinguishes baseline data from optimization progress.

        Returns:
            Dict containing detailed progress analysis
        """
        # Delegated fast path
        try:
            from ._progress import summarize_progress

            return summarize_progress(self)
        except Exception:
            pass

        # Separate different types of iterations
        baseline_iterations = [h for h in self.iteration_history if h.get("is_baseline", False)]
        optimization_iterations = [
            h for h in self.iteration_history if h.get("iteration_type") == "optimization"
        ]
        batch_import_iterations = [
            h for h in self.iteration_history if h.get("iteration_type") == "batch_import"
        ]

        summary = {
            "total_iterations": len(self.iteration_history),
            "baseline_iterations": len(baseline_iterations),
            "optimization_iterations": len(optimization_iterations),
            "batch_import_iterations": len(batch_import_iterations),
            "total_experiments": (
                len(self.experimental_data) if hasattr(self, "experimental_data") else 0
            ),
            "baseline_hypervolume": self.baseline_hypervolume,
            "current_hypervolume": None,
            "improvement_over_baseline": 0.0,
            "hypervolume_trend": "unknown",
            "convergence_status": "unknown",
            "efficiency_metrics": {},
            "recommendations": [],
        }

        try:
            if not self.iteration_history:
                summary["recommendations"].append("Start optimization by adding experimental data")
                return summary

            # Get current hypervolume
            latest_iteration = self.iteration_history[-1]
            hv_value = latest_iteration.get("hypervolume", 0.0)

            if isinstance(hv_value, dict):
                summary["current_hypervolume"] = {
                    "raw": hv_value.get("raw_hypervolume", 0.0),
                    "normalized": hv_value.get("normalized_hypervolume", 0.0),
                    "data_points_used": hv_value.get("data_points_used", 0),
                }
            else:
                summary["current_hypervolume"] = {"raw": hv_value, "normalized": None}

            # Analyze trend over recent iterations
            if len(self.iteration_history) >= 3:
                recent_iterations = min(10, len(self.iteration_history))
                recent_hvs = []

                for iteration in self.iteration_history[-recent_iterations:]:
                    hv_val = iteration.get("hypervolume", 0.0)
                    if isinstance(hv_val, dict):
                        recent_hvs.append(hv_val.get("raw_hypervolume", 0.0))
                    else:
                        recent_hvs.append(hv_val)

                if len(recent_hvs) >= 3 and max(recent_hvs) > 1e-12:
                    first_third = sum(recent_hvs[: len(recent_hvs) // 3]) / (len(recent_hvs) // 3)
                    last_third = sum(recent_hvs[-len(recent_hvs) // 3 :]) / (len(recent_hvs) // 3)

                    relative_change = (last_third - first_third) / max(first_third, 1e-12)

                    if relative_change > 0.05:
                        summary["hypervolume_trend"] = "improving"
                    elif relative_change > -0.02:
                        summary["hypervolume_trend"] = "stable"
                    else:
                        summary["hypervolume_trend"] = "declining"

            # Check convergence
            convergence_result = self.check_hypervolume_convergence()
            summary["convergence_status"] = convergence_result["recommendation"]
            summary["convergence_details"] = convergence_result

            # Calculate efficiency metrics
            if len(self.iteration_history) > 1:
                # Hypervolume per experiment efficiency
                current_hv = (
                    summary["current_hypervolume"]["raw"] if summary["current_hypervolume"] else 0.0
                )
                experiments_count = summary["total_experiments"]

                if experiments_count > 0:
                    summary["efficiency_metrics"]["hv_per_experiment"] = (
                        current_hv / experiments_count
                    )

                # Rate of improvement
                if len(self.iteration_history) >= 5:
                    early_hv = self.iteration_history[min(4, len(self.iteration_history) - 1)].get(
                        "hypervolume", 0.0
                    )
                    if isinstance(early_hv, dict):
                        early_hv = early_hv.get("raw_hypervolume", 0.0)

                    if early_hv > 1e-12:
                        improvement_rate = (current_hv - early_hv) / early_hv
                        summary["efficiency_metrics"]["improvement_rate"] = improvement_rate

            # Generate recommendations
            if summary["hypervolume_trend"] == "declining":
                summary["recommendations"].append("Check for overfitting or data quality issues")
            elif summary["hypervolume_trend"] == "stable" and len(self.iteration_history) > 10:
                summary["recommendations"].append(
                    "Consider exploring different regions of parameter space"
                )
            elif convergence_result["converged"]:
                summary["recommendations"].append(
                    "Optimization may have converged - consider validation experiments"
                )
            else:
                summary["recommendations"].append(
                    "Continue optimization - good progress being made"
                )

            return summary

        except Exception as e:
            logger.error(f"Error generating progress summary: {e}", exc_info=True)
            summary["recommendations"].append("Error in progress analysis - continue with caution")
            return summary

    def get_cached_hypervolume_data(self) -> Dict[str, Any]:
        """Get cached hypervolume data if available, otherwise calculate fresh"""
        if self._cached_hypervolume_data:
            logger.info("Using cached hypervolume data")
            return self._cached_hypervolume_data
        else:
            logger.info("No cached hypervolume data found, calculating fresh")
            try:
                current_hv = self._calculate_hypervolume()
                progress_summary = self.get_optimization_progress_summary()
                convergence_data = self.check_hypervolume_convergence()

                return {
                    "current_hypervolume": current_hv,
                    "progress_summary": progress_summary,
                    "convergence_analysis": convergence_data,
                    "calculation_timestamp": pd.Timestamp.now().isoformat(),
                }
            except Exception as e:
                logger.error(f"Error calculating hypervolume data: {e}")
                return {}

    def set_cached_hypervolume_data(self, cached_data: Dict[str, Any]):
        """Set cached hypervolume data (used when loading from file)"""
        self._cached_hypervolume_data = cached_data
        logger.info("Cached hypervolume data has been set")

    @performance_timer if PERFORMANCE_OPTIMIZATION_AVAILABLE else lambda x: x
    def suggest_next_experiment(self, n_suggestions: int = 1) -> List[Dict[str, Any]]:
        """
        Generates suggestions for the next set of experiments using Bayesian optimization.
        If insufficient data is available, it falls back to initial sampling methods
        (e.g., random or Latin Hypercube Sampling).

        Args:
            n_suggestions (int): The number of parameter combinations to suggest.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries, each representing a suggested
                                  parameter combination in its original scale.
        """
        try:
            # Ensure training data is updated if experimental data exists but tensors don't
            if (
                not hasattr(self, "train_X") or not hasattr(self, "train_Y")
            ) and not self.experimental_data.empty:
                logger.info("Updating training data tensors from experimental data")
                self._update_training_data()

            # Check if there's enough data to train the Gaussian Process models.
            if (
                not hasattr(self, "train_X")
                or not hasattr(self, "train_Y")
                or self.train_X.shape[0] < MIN_DATA_POINTS_FOR_GP
            ):
                logger.info("Insufficient data for GP. Using initial sampling method.")
                if self.initial_sampling_method == "LHS":
                    return self._generate_doe_samples(n_suggestions, method="LHS")
                else:
                    return self._generate_random_samples(n_suggestions)

            # Build the Gaussian Process models based on the current experimental data.
            models = self._build_models()
            if models is None:
                logger.warning("Could not build models. Using random sampling.")
                return self._generate_random_samples(n_suggestions)

            # Set up the acquisition function (e.g., Expected Hypervolume Improvement for MOO,
            # Expected Improvement for SOO).
            acq_func = self._setup_acquisition_function(models)
            if acq_func is None:
                logger.warning("Could not set up acquisition function. Using random sampling.")
                return self._generate_random_samples(n_suggestions)

            # Optimize the acquisition function to find the next best experimental points.
            suggestions = self._optimize_acquisition_function(acq_func, n_suggestions)

            logger.info(
                f"đźŽŻ Generated {len(suggestions)} new experiment suggestions using Bayesian optimization"
            )
            return suggestions

        except Exception as e:
            logger.error(f"Error in suggest_next_experiment: {e}", exc_info=True)
            # Fallback to random sampling in case of any unexpected error.
            return self._generate_random_samples(n_suggestions)

    def _cache_candidates(self, candidates: torch.Tensor, optimization_time: float):
        """Cache optimization candidates for potential reuse."""
        try:
            # Store candidates with metadata
            cache_entry = {
                "candidates": candidates.clone().detach(),
                "timestamp": time.time(),
                "optimization_time": optimization_time,
                "data_size": (
                    len(self.experimental_data)
                    if hasattr(self, "experimental_data") and not self.experimental_data.empty
                    else 0
                ),
            }

            self._candidate_cache.append(cache_entry)

            # Maintain cache size limit
            if len(self._candidate_cache) > self._cache_max_size:
                self._candidate_cache.pop(0)  # Remove oldest entry

            logger.debug(
                f"Cached {len(candidates)} candidates (cache size: {len(self._candidate_cache)})"
            )

        except Exception as e:
            logger.debug(f"Failed to cache candidates: {e}")

    def _try_cached_candidates(
        self, n_suggestions: int, current_data_size: int
    ) -> Optional[List[Dict[str, Any]]]:
        """Try to reuse cached candidates if optimization is taking too long."""
        try:
            if not self._candidate_cache:
                return None

            # Find candidates from similar data sizes (within 50% range or any if few options)
            suitable_entries = []
            for entry in self._candidate_cache:
                if current_data_size <= 1:
                    # For very small datasets, any cache entry is suitable
                    suitable_entries.append(entry)
                else:
                    data_size_diff = abs(entry["data_size"] - current_data_size) / max(
                        current_data_size, 1
                    )
                    if data_size_diff <= 0.5:  # Within 50% of current data size (more lenient)
                        suitable_entries.append(entry)

            # If no suitable entries with size matching, use any available entry
            if not suitable_entries and len(self._candidate_cache) > 0:
                suitable_entries = list(self._candidate_cache)
                logger.debug("Using any available cached candidates (no size match)")

            # Use the most recent suitable entry
            best_entry = max(suitable_entries, key=lambda x: x["timestamp"])
            cached_candidates = best_entry["candidates"]

            # Select random subset if we have more than needed
            if len(cached_candidates) >= n_suggestions:
                indices = torch.randperm(len(cached_candidates))[:n_suggestions]
                selected_candidates = cached_candidates[indices]
            else:
                selected_candidates = cached_candidates

            # Convert to parameter dictionaries
            suggestions = []
            for i in range(len(selected_candidates)):
                param_dict = self.parameter_transformer.tensor_to_params(selected_candidates[i])
                suggestions.append(param_dict)

            logger.info(
                f"đź”„ Using {len(suggestions)} cached candidates (saved optimization time)"
            )
            return suggestions

        except Exception as e:
            logger.debug(f"Failed to use cached candidates: {e}")
            return None

    def _generate_random_samples(self, n_suggestions: int) -> List[Dict[str, Any]]:
        """Delegate random sampling to sampling helper."""
        try:
            from ._sampling import random_samples as _rand

            return _rand(self, n_suggestions)
        except Exception:
            return []

    def _are_params_similar(
        self, params1: Dict[str, Any], params2: Dict[str, Any], rtol: float = 1e-3
    ) -> bool:
        """
        Compares two sets of parameters to determine if they are similar within a
        given relative tolerance. This is used to avoid suggesting duplicate experiments.

        Args:
            params1 (Dict[str, Any]): The first dictionary of parameters.
            params2 (Dict[str, Any]): The second dictionary of parameters.
            rtol (float): The relative tolerance for comparing numerical values.

        Returns:
            bool: True if the parameter sets are similar, False otherwise.
        """
        # Check if all keys in params1 are present in params2 and vice-versa
        if set(params1.keys()) != set(params2.keys()):
            return False

        for key in params1:
            val1, val2 = params1[key], params2[key]

            # Compare numerical values using numpy.isclose for tolerance.
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                if not np.isclose(val1, val2, rtol=rtol):
                    return False
            # For non-numerical values, perform exact comparison.
            elif val1 != val2:
                return False

        return True

    def _build_models(self) -> Optional[ModelListGP]:
        """
        Builds and fits Gaussian Process (GP) models for each objective.
        A `SingleTaskGP` model is created for each objective, and then all
        models are combined into a `ModelListGP`.

        Returns:
            Optional[ModelListGP]: A `ModelListGP` containing the fitted GP models,
                                   or None if models cannot be built (e.g., insufficient data).
        """
        # Delegated modular implementation
        try:
            from ._models import build_models as _build

            return _build(self, create_kernel_for_parameters)
        except Exception:
            pass
        try:
            # Check if training data exists
            if not hasattr(self, "train_X") or not hasattr(self, "train_Y"):
                logger.warning("No training data available for model building.")
                return None

            if self.train_X.shape[0] == 0 or self.train_Y.shape[0] == 0:
                logger.warning("Empty training data for model building.")
                return None

            models = []

            for i, obj_name in enumerate(self.objective_names):
                if i >= self.train_Y.shape[1]:
                    logger.warning(
                        f"Objective index {i} exceeds training data dimensions for {obj_name}"
                    )
                    continue

                Y_obj = self.train_Y[:, i]

                # Filter out non-finite (NaN or Inf) values for the current objective.
                finite_mask = torch.isfinite(Y_obj)
                if finite_mask.sum() < MIN_DATA_POINTS_FOR_GP:
                    logger.warning(
                        f"Insufficient finite data points ({finite_mask.sum()}) for objective {obj_name}. Skipping model building for this objective."
                    )
                    continue

                X_filtered = self.train_X[finite_mask]
                Y_filtered = Y_obj[finite_mask].unsqueeze(
                    -1
                )  # Add a feature dimension for BoTorch.

                # Initialize a SingleTaskGP model.
                # - `MaternKernel` with nu=2.5 is a common choice for smooth functions.
                # - `ScaleKernel` scales the output of the Matern kernel.
                # - `Normalize` input transform normalizes input features to [0, 1].
                # - `Standardize` outcome transform standardizes output features to zero mean and unit variance.
                # Create appropriate kernel based on parameter types (mixed variables support)
                base_kernel = create_kernel_for_parameters(
                    self.params_config, X_filtered.shape[-1], self.kernel_type
                )
                covar_module = ScaleKernel(base_kernel)

                model = SingleTaskGP(
                    train_X=X_filtered,
                    train_Y=Y_filtered,
                    covar_module=covar_module,
                    input_transform=Normalize(d=X_filtered.shape[-1]),
                    outcome_transform=Standardize(m=1),
                )

                # Fit the GP model by optimizing the marginal log-likelihood.
                mll = ExactMarginalLogLikelihood(model.likelihood, model)

                # Apply optimized GP fitting with Cholesky decomposition preference
                try:
                    # Use optimized fitting with potential Cholesky acceleration
                    self._fit_gp_model_optimized(mll)
                except Exception as e:
                    logger.warning(
                        f"Optimized GP fitting failed ({e}), falling back to standard fitting"
                    )
                    fit_gpytorch_mll(mll)

                models.append(model)

            if not models:
                logger.warning("No GP models could be built for any objective.")
                return None

            # Validate that we have models for all objectives
            if len(models) != len(self.objective_names):
                logger.error(
                    f"Model count mismatch: built {len(models)} models for {len(self.objective_names)} objectives"
                )
                logger.error(f"Objectives: {self.objective_names}")
                logger.error("This can cause dimension mismatches in acquisition functions")
                return None

            # Return a ModelListGP if multiple objectives, or the single model if only one.
            logger.debug(
                f"Successfully built {len(models)} models for objectives: {self.objective_names}"
            )
            return ModelListGP(*models) if len(models) > 1 else models[0]

        except Exception as e:
            logger.error(f"Error building models: {e}", exc_info=True)
            return None

    def _setup_acquisition_function(
        self, models: Union[SingleTaskGP, ModelListGP]
    ) -> Optional[Union[LogExpectedImprovement, ExpectedHypervolumeImprovement]]:
        """Delegate acquisition configuration to the _acq helper module."""
        try:
            from ._acq import setup_acquisition_function as _setup_acq

            return _setup_acq(self, models)
        except Exception as e:
            logger.error(f"Error setting up acquisition function: {e}", exc_info=True)
            return None

    def _create_scalarized_ei_fallback(self, models, clean_Y):
        from ._acq import _create_scalarized_ei_fallback as _fallback

        return _fallback(self, models, clean_Y)

    def _setup_weighted_scalarization_acquisition(self, models):
        from ._acq import _setup_weighted_scalarization_acquisition as _weighted

        return _weighted(self, models)

    def _optimize_acquisition_function(
        self,
        acq_func: Union[LogExpectedImprovement, ExpectedHypervolumeImprovement],
        n_suggestions: int,
    ) -> List[Dict[str, Any]]:
        """
        Optimizes the acquisition function to find the next set of suggested experimental
        points. This involves using a multi-start optimization approach to find the
        global optimum of the acquisition function.

        Args:
            acq_func (Union[LogExpectedImprovement, ExpectedHypervolumeImprovement]): The
                       initialized acquisition function to be optimized.
            n_suggestions (int): The number of suggested points to generate.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries, each representing a suggested
                                  parameter combination in its original scale.
        """
        try:
            # Delegated fast path to modular helper
            try:
                from ._suggest import optimize_acquisition as _opt

                return _opt(self, acq_func, n_suggestions)
            except Exception:
                pass
            # Define the bounds for the optimization of the acquisition function.
            # These are typically the normalized [0, 1] bounds of the parameter space.
            bounds = torch.stack(
                [
                    torch.zeros(len(self.parameter_transformer.param_names), dtype=self.dtype),
                    torch.ones(len(self.parameter_transformer.param_names), dtype=self.dtype),
                ]
            ).to(self.device)

            # Adaptive optimization parameters based on dataset size and interactive use
            n_data = (
                len(self.experimental_data)
                if hasattr(self, "experimental_data") and not self.experimental_data.empty
                else 0
            )

            if self.fast_validation_mode:
                # Ultra-fast mode for validation scenarios: minimal optimization for speed
                adaptive_restarts = 1
                adaptive_raw_samples = 2  # Ultra-aggressive for validation speed
                logger.debug(
                    f"đźš€ Ultra-fast validation mode: {adaptive_restarts} restarts, {adaptive_raw_samples} samples"
                )
            elif n_data < 20:
                # Early exploration: prioritize speed over exhaustive search
                adaptive_restarts = min(2, self.num_restarts)  # Reduced from 3
                adaptive_raw_samples = min(12, self.raw_samples)  # Reduced from 20
                logger.debug(
                    f"Using fast optimization for early exploration: {adaptive_restarts} restarts, {adaptive_raw_samples} samples"
                )
            elif n_data < 100:
                # Medium exploration: balanced approach
                adaptive_restarts = min(3, self.num_restarts)  # Reduced from 4
                adaptive_raw_samples = min(20, self.raw_samples)  # Reduced from 30
                logger.debug(
                    f"Using balanced optimization: {adaptive_restarts} restarts, {adaptive_raw_samples} samples"
                )
            else:
                # Large datasets: use full optimization for better suggestions
                adaptive_restarts = self.num_restarts
                adaptive_raw_samples = self.raw_samples
                logger.debug(
                    f"Using full optimization: {adaptive_restarts} restarts, {adaptive_raw_samples} samples"
                )

            # Optimize the acquisition function using `optimize_acqf` from BoTorch.
            # `q` specifies the number of points to optimize for (batch size).
            # `num_restarts` and `raw_samples` control the multi-start optimization process.

            # Time-based adaptive optimization with fallback
            start_time = time.time()
            max_optimization_time = (
                1.0 if self.fast_validation_mode else 10.0
            )  # Ultra-aggressive timeout for validation
            n_data = (
                len(self.experimental_data)
                if hasattr(self, "experimental_data") and not self.experimental_data.empty
                else 0
            )

            # Check if we can use cached candidates in fast mode for very recent similar scenarios
            if (
                self.fast_validation_mode
                and hasattr(self, "_slow_optimizations")
                and self._slow_optimizations >= 2
            ):
                cached_suggestions = self._try_cached_candidates(n_suggestions, n_data)
                if cached_suggestions is not None:
                    return cached_suggestions

            # Ultra-aggressive fallback for validation: skip acquisition optimization after first few slow runs
            if (
                self.fast_validation_mode
                and hasattr(self, "_slow_optimizations")
                and self._slow_optimizations >= 1
            ):
                logger.debug("đźš€ Ultra-fast validation mode: using random sampling fallback")
                return self._generate_random_samples(n_suggestions)

            try:
                # Try regular optimization with parameter constraints (Windows doesn't support SIGALRM timeout)
                # Include parameter constraints if any are defined
                optimization_kwargs = {
                    "acq_function": acq_func,
                    "bounds": bounds,
                    "q": n_suggestions,
                    "num_restarts": adaptive_restarts,
                    "raw_samples": adaptive_raw_samples,
                }

                # Add parameter constraints if defined (Target/Range goals)
                if hasattr(self, "parameter_constraints") and self.parameter_constraints:
                    optimization_kwargs["inequality_constraints"] = self.parameter_constraints
                    logger.debug(
                        f"Using {len(self.parameter_constraints)} parameter constraints in acquisition optimization"
                    )

                candidates, _ = optimize_acqf(**optimization_kwargs)

                optimization_time = time.time() - start_time
                if optimization_time > max_optimization_time:
                    logger.warning(
                        f"Acquisition optimization took {optimization_time:.2f}s (target: {max_optimization_time}s)"
                    )
                    if self.fast_validation_mode:
                        self._slow_optimizations += 1
                        logger.debug(f"Slow optimization count: {self._slow_optimizations}")

            except Exception as e:
                logger.warning(f"Acquisition optimization failed: {e}")
                logger.info("Falling back to minimal optimization settings")
                # Emergency fallback: use absolute minimum settings with constraints if available
                fallback_kwargs = {
                    "acq_function": acq_func,
                    "bounds": bounds,
                    "q": n_suggestions,
                    "num_restarts": 1,
                    "raw_samples": 2,
                }

                # Include constraints in fallback if they exist
                if hasattr(self, "parameter_constraints") and self.parameter_constraints:
                    fallback_kwargs["inequality_constraints"] = self.parameter_constraints
                    logger.debug("Using parameter constraints in fallback optimization")

                candidates, _ = optimize_acqf(**fallback_kwargs)
                optimization_time = time.time() - start_time

            suggestions = []
            for i in range(candidates.shape[0]):
                # Convert the normalized candidate tensor back to a parameter dictionary.
                param_dict = self.parameter_transformer.tensor_to_params(candidates[i])

                # Validate and enforce parameter constraints if defined
                if hasattr(self, "parameter_constraints") and self.parameter_constraints:
                    is_valid, violations = (
                        self.parameter_transformer.validate_parameter_constraints(param_dict)
                    )
                    if not is_valid:
                        logger.debug(f"Constraint violations detected: {violations}")
                        param_dict = self.parameter_transformer.enforce_parameter_constraints(
                            param_dict
                        )
                        logger.debug("Applied constraint enforcement to suggestion")

                suggestions.append(param_dict)

            # Cache successful candidates for potential reuse
            self._cache_candidates(candidates, optimization_time)

            # Ensure we don't return more suggestions than requested
            if len(suggestions) > n_suggestions:
                suggestions = suggestions[:n_suggestions]
                logger.warning(
                    f"Generated {len(candidates)} candidates but only returning {n_suggestions} as requested"
                )

            logger.info(
                f"Successfully optimized acquisition function and generated {len(suggestions)} candidates."
            )
            return suggestions

        except Exception as e:
            logger.error(f"Error optimizing acquisition function: {e}", exc_info=True)
            # Fallback to random sampling in case of any unexpected error.
            return self._generate_random_samples(n_suggestions)

    def get_pareto_front(self) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
        """
        Identifies and returns the Pareto front from the observed experimental data.
        The Pareto front consists of non-dominated solutions, meaning no other solution
        is better in all objectives.

        Returns:
            Tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
                - A DataFrame of parameters corresponding to the Pareto front.
                - A DataFrame of objective values corresponding to the Pareto front.
                - A NumPy array of original indices of the Pareto optimal points in the
                  `experimental_data` DataFrame.
                Returns empty DataFrames and array if no data or no finite data points.
        """
        try:
            # Delegated fast path
            try:
                from ._progress import pareto_front as _pareto

                return _pareto(
                    self.train_X,
                    self.train_Y,
                    getattr(self, "experimental_data", pd.DataFrame()),
                    self.parameter_transformer.param_names,
                )
            except Exception:
                pass
            if (
                not hasattr(self, "train_Y")
                or not hasattr(self, "train_X")
                or self.train_Y.shape[0] == 0
            ):
                logger.debug("No training data available to determine Pareto front.")
                return pd.DataFrame(), pd.DataFrame(), np.array([])

            # Filter out rows containing NaN values in objectives.
            finite_mask = torch.isfinite(self.train_Y).all(dim=1)
            if not finite_mask.any():
                logger.debug("No finite data points to determine Pareto front.")
                return pd.DataFrame(), pd.DataFrame(), np.array([])

            clean_Y = self.train_Y[finite_mask]  # Filtered objective values
            clean_X = self.train_X[finite_mask]  # Filtered parameter values
            clean_indices = torch.where(finite_mask)[0]  # Original indices of finite points

            # Use BoTorch's `is_non_dominated` to find Pareto optimal points.
            pareto_mask = is_non_dominated(clean_Y)
            pareto_Y = clean_Y[pareto_mask]  # Objective values on the Pareto front
            pareto_X = clean_X[pareto_mask]  # Parameter values on the Pareto front
            pareto_indices = clean_indices[pareto_mask]  # Original indices of Pareto points

            # Convert objective values back to their original scale (undo negation for minimization).
            pareto_Y_original = pareto_Y.clone()
            for i, direction in enumerate(self.objective_directions):
                if direction == -1:  # If objective was minimized, negate back to original scale.
                    pareto_Y_original[:, i] = -pareto_Y_original[:, i]

            # Create Pandas DataFrames for the Pareto front parameters and objectives.
            pareto_X_df = pd.DataFrame(
                pareto_X.cpu().numpy(), columns=self.parameter_transformer.param_names
            )

            pareto_obj_df = pd.DataFrame(
                pareto_Y_original.cpu().numpy(), columns=self.objective_names
            )

            logger.debug(f"Found {len(pareto_X_df)} points on the Pareto front.")
            return pareto_X_df, pareto_obj_df, pareto_indices.cpu().numpy()

        except Exception as e:
            logger.error(f"Error getting Pareto front: {e}", exc_info=True)
            return pd.DataFrame(), pd.DataFrame(), np.array([])

    def get_best_compromise_solution(self) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """
        Estimates the best optimal parameter combination and its predicted responses.
        This is achieved by generating the next suggested experiment (which is optimized
        by the acquisition function) and then predicting the responses for that point
        using the trained Gaussian Process models.

        Returns:
            Tuple[Dict[str, Any], Dict[str, Any]]:
                - A dictionary representing the best predicted parameter combination.
                - A dictionary representing the predicted responses (mean and 95% CI)
                  for the best parameter combination.
                Returns empty dictionaries if no suggestions can be generated or
                predictions fail.
        """
        try:
            # Get the next suggested experiment from the optimizer.
            # This point is already optimized to be "best" in terms of the acquisition function.
            suggestions = self.suggest_next_experiment(n_suggestions=1)

            if not suggestions:
                logger.warning("No suggestions generated for best compromise solution.")
                return {}, {}

            best_predicted_params = suggestions[0]

            # Predict the responses at this suggested parameter combination.
            predicted_responses = self.predict_responses_at(best_predicted_params)

            logger.info("Successfully estimated best compromise solution.")
            return best_predicted_params, predicted_responses

        except Exception as e:
            logger.error(f"Error estimating best compromise solution: {e}", exc_info=True)
            return {}, {}

    def get_goal_aligned_solution(
        self, n_candidates: int = 512
    ) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
        """
        Estimate the parameter combination that best satisfies the configured goals
        (response desirability/targets, parameter ranges) using model predictions.

        Returns:
            Tuple containing:
              - parameter dictionary for the best predicted point
              - predicted responses (filtered to configured responses)
              - metadata dict with score, feasibility, and component breakdown
        """

        try:
            if not self.responses_config and not any(
                (cfg.get("goal") or "None") not in {"None", None, ""}
                for cfg in self.params_config.values()
            ):
                return {}, {}, {"reason": "No goal-aware configuration defined"}

            models = self._build_models()
            if not models:
                return {}, {}, {"reason": "Models unavailable"}

            n_params = len(self.parameter_transformer.param_names)
            if n_params == 0:
                return {}, {}, {"reason": "No parameters defined"}

            candidate_tensors: List[torch.Tensor] = []

            response_models = {}
            try:
                response_models = self.get_response_models()
            except Exception as resp_exc:
                logger.debug(
                    f"Unable to build individual response models for goal alignment: {resp_exc}"
                )

            if hasattr(self, "train_X") and isinstance(self.train_X, torch.Tensor):
                if self.train_X.numel() > 0:
                    candidate_tensors.append(
                        self.train_X.clone().detach().to(self.device, self.dtype)
                    )

            max_candidates = max(int(n_candidates), 0)
            if max_candidates > 0:
                sobol_engine = SobolEngine(dimension=n_params, scramble=True)
                sobol_samples = sobol_engine.draw(max_candidates).to(
                    self.device, self.dtype
                )
                candidate_tensors.append(sobol_samples)

            if not candidate_tensors:
                return {}, {}, {"reason": "No candidate samples"}

            candidates = torch.vstack(candidate_tensors)
            best_score = -1.0
            best_params: Optional[Dict[str, Any]] = None
            best_meta: Optional[Dict[str, Any]] = None

            for idx in range(candidates.shape[0]):
                normalized = candidates[idx].clamp(0.0, 1.0)
                param_dict = self.parameter_transformer.tensor_to_params(
                    normalized.detach().cpu()
                )
                predicted_responses = self._predict_all_responses(
                    models, response_models, normalized.unsqueeze(0)
                )
                score, meta = self._evaluate_goal_alignment(
                    predicted_responses, param_dict
                )
                if score > best_score:
                    best_score = score
                    best_params = param_dict
                    best_meta = meta

            if best_params is None:
                return {}, {}, {"reason": "No feasible candidate"}

            predictions = self.predict_responses_at(best_params)
            filtered_predictions = {
                name: predictions.get(name, {})
                for name in self.responses_config.keys()
            }

            best_meta = best_meta or {}
            best_meta["score"] = best_score
            return best_params, filtered_predictions, best_meta

        except Exception as exc:
            logger.error(
                f"Error computing goal-aligned solution: {exc}", exc_info=True
            )
            return {}, {}, {"reason": str(exc)}

    def predict_responses_at(self, param_dict: Dict[str, Any]) -> Dict[str, Dict[str, float]]:
        """
        Predicts the mean and 95% confidence interval for each objective at a given
        parameter combination using the trained Gaussian Process models.

        For Range/Target response objectives, uses response models (trained on actual values)
        instead of objective models (trained on penalty values).

        Args:
            param_dict (Dict[str, Any]): A dictionary representing the parameter
                                         combination for which to make predictions.

        Returns:
            Dict[str, Dict[str, float]]: A dictionary where keys are objective names
                                        and values are dictionaries containing 'mean',
                                        'lower_ci', and 'upper_ci' for that objective.
                                        Returns an empty dictionary if models cannot be
                                        built or prediction fails.
        """
        try:
            # Build objective models (for optimization - may use transformed values)
            objective_models = self._build_models()
            if not objective_models:
                logger.warning("Cannot predict responses: No objective models available.")
                return {}

            # Build response models (for actual response predictions - uses raw values)
            response_models = {}
            try:
                response_models = self.get_response_models()
            except Exception as e:
                logger.debug(f"Could not build response models: {e}")

            # Convert the input parameter dictionary to a normalized tensor.
            param_tensor = self.parameter_transformer.params_to_tensor(param_dict)
            X_test = param_tensor.unsqueeze(0).to(
                self.device, self.dtype
            )  # Add a batch dimension and move to device

            predictions = {}
            # Iterate through each objective to get its prediction.
            for i, obj_name in enumerate(self.objective_names):
                obj_def = self.objective_definitions[i] if i < len(self.objective_definitions) else {}
                obj_type = obj_def.get("type")

                # For Range and Target response objectives, use response models (actual values)
                # instead of objective models (penalty values)
                use_response_model = obj_type in ["response_range", "response_target"]

                if use_response_model and obj_name in response_models:
                    # Use response model for actual value prediction
                    model = response_models[obj_name]
                    with torch.no_grad():
                        posterior = model.posterior(X_test)
                        mean = posterior.mean.item()
                        std = posterior.variance.sqrt().item()
                        z_score = 1.96
                        lower_ci = mean - z_score * std
                        upper_ci = mean + z_score * std

                        predictions[obj_name] = {
                            "mean": mean,
                            "lower_ci": lower_ci,
                            "upper_ci": upper_ci,
                        }
                    logger.debug(f"Predicted {obj_name} using response model (actual value): {mean:.4f}")
                else:
                    # Use objective model (standard approach)
                    # Handle both SingleTaskGP (single objective) and ModelListGP (multiple objectives)
                    if hasattr(objective_models, "models"):
                        # Multiple objectives - ModelListGP
                        if i < len(objective_models.models):
                            model = objective_models.models[i]
                        else:
                            continue
                    else:
                        # Single objective - SingleTaskGP
                        if i == 0:
                            model = objective_models
                        else:
                            continue

                    with torch.no_grad():  # Disable gradient calculations for inference.
                        posterior = model.posterior(X_test)
                        mean = posterior.mean.item()
                        std = posterior.variance.sqrt().item()

                        # Calculate 95% confidence interval using a Z-score of 1.96
                        # for a normal distribution.
                        z_score = 1.96
                        lower_ci = mean - z_score * std
                        upper_ci = mean + z_score * std

                        # Undo negation for minimization objectives to return values
                        # in their original scale.
                        if self.objective_directions[i] == -1:
                            mean = -mean
                            # Negate and swap CIs to maintain lower/upper order.
                            lower_ci, upper_ci = -upper_ci, -lower_ci

                        predictions[obj_name] = {
                            "mean": mean,
                            "lower_ci": lower_ci,
                            "upper_ci": upper_ci,
                        }

            logger.info(f"Successfully predicted responses for {param_dict}.")
            return predictions

        except Exception as e:
            logger.error(f"Error predicting responses: {e}", exc_info=True)
            return {}

    def _predict_objective_means(
        self, models, normalized_tensor: torch.Tensor
    ) -> Dict[str, float]:
        predictions: Dict[str, float] = {}
        try:
            for i, obj_name in enumerate(self.objective_names):
                # Skip Range/Target response objectives - they'll be predicted by response models
                obj_def = self.objective_definitions[i] if i < len(self.objective_definitions) else {}
                obj_type = obj_def.get("type")
                if obj_type in ["response_range", "response_target"]:
                    logger.debug(f"Skipping objective prediction for {obj_name} (will use response model)")
                    continue

                if hasattr(models, "models"):
                    if i >= len(models.models):
                        continue
                    model = models.models[i]
                else:
                    if i > 0:
                        continue
                    model = models

                with torch.no_grad():
                    posterior = model.posterior(normalized_tensor)
                    mean = posterior.mean.squeeze().item()
                    if self.objective_directions[i] == -1:
                        mean = -mean
                    if np.isfinite(mean):
                        predictions[obj_name] = float(mean)
        except Exception as exc:
            logger.debug(f"Failed to compute objective means: {exc}")

        return predictions

    def _predict_all_responses(
        self,
        objective_models,
        response_models: Dict[str, Any],
        normalized_tensor: torch.Tensor,
    ) -> Dict[str, float]:
        predictions = self._predict_objective_means(objective_models, normalized_tensor)

        if response_models:
            for name, model in response_models.items():
                if name in predictions:
                    continue
                try:
                    with torch.no_grad():
                        posterior = model.posterior(normalized_tensor)
                        mean_val = posterior.mean.squeeze().item()
                        if np.isfinite(mean_val):
                            predictions[name] = float(mean_val)
                except Exception as exc:
                    logger.debug(
                        f"Failed to predict response '{name}' for goal alignment: {exc}"
                    )

        return predictions

    def _evaluate_goal_alignment(
        self,
        predicted_responses: Dict[str, float],
        param_dict: Dict[str, Any],
    ) -> Tuple[float, Dict[str, Any]]:

        components: Dict[str, Dict[str, Any]] = {}
        score_sum = 0.0
        weight_sum = 0.0
        feasible = True

        for name, config in self.responses_config.items():
            goal = config.get("goal", "Maximize")
            mean_value = predicted_responses.get(name)
            if mean_value is None or not np.isfinite(mean_value):
                continue
            stats = self._get_response_stats(name)
            desirability, is_feasible = self._scalar_desirability(
                mean_value, goal, config, stats
            )
            weight = float(config.get("optimization_weight", 1.0))
            components[name] = {
                "type": "response",
                "goal": goal,
                "weight": weight,
                "desirability": desirability,
                "feasible": is_feasible,
                "value": mean_value,
            }

            if weight > 0:
                feasibility_flag = is_feasible and desirability > 0.0
                feasible = feasible and feasibility_flag
                desirability_clipped = max(desirability, 1e-9)
                score_sum += weight * math.log(desirability_clipped)
                weight_sum += weight

        for name, config in self.params_config.items():
            goal = config.get("goal", "None")
            if not goal or goal.lower() in {"none", "", "fixed"}:
                continue
            if config.get("type") == "categorical":
                continue

            numeric_value = self._coerce_numeric(param_dict.get(name))
            if numeric_value is None:
                continue

            stats = self._get_parameter_stats(name, config)
            desirability, is_feasible = self._scalar_desirability(
                numeric_value, goal, config, stats
            )
            weight = float(config.get("optimization_weight", 1.0))
            components[name] = {
                "type": "parameter",
                "goal": goal,
                "weight": weight,
                "desirability": desirability,
                "feasible": is_feasible,
                "value": numeric_value,
            }

            if weight > 0:
                feasibility_flag = is_feasible and desirability > 0.0
                feasible = feasible and feasibility_flag
                desirability_clipped = max(desirability, 1e-9)
                score_sum += weight * math.log(desirability_clipped)
                weight_sum += weight

        if weight_sum == 0:
            return 0.0, {"components": components, "feasible": feasible}

        score = math.exp(score_sum / weight_sum)
        if not feasible:
            score = 0.0

        return score, {
            "components": components,
            "feasible": feasible,
            "objective_means": predicted_responses,
        }

    def _get_response_stats(self, response_name: str) -> Tuple[float, float, float, float]:
        stats_min = 0.0
        stats_max = 1.0
        stats_mean = 0.5
        stats_std = 0.1

        try:
            if (
                hasattr(self, "experimental_data")
                and not self.experimental_data.empty
                and response_name in self.experimental_data.columns
            ):
                series = (
                    self.experimental_data[response_name]
                    .replace([np.inf, -np.inf], np.nan)
                    .dropna()
                )
                if len(series) > 0:
                    stats_min = float(series.min())
                    stats_max = float(series.max())
                    stats_mean = float(series.mean())
                    stats_std = float(series.std(ddof=0))

            config = self.responses_config.get(response_name, {}) or {}

            bounds = config.get("range_bounds") or config.get("bounds")
            if bounds and len(bounds) == 2:
                stats_min = float(bounds[0])
                stats_max = float(bounds[1])

            target = config.get("target_value")
            if target is not None:
                stats_mean = float(target)

            if stats_max <= stats_min:
                stats_max = stats_min + 1.0

            stats_std_candidate = config.get("target_tolerance")
            if stats_std_candidate is not None:
                stats_std = max(float(stats_std_candidate), 1e-6)
            else:
                stats_std = max(float(stats_std), (stats_max - stats_min) / 6.0, 1e-6)

        except Exception as exc:
            logger.debug(f"Failed to compute response stats for {response_name}: {exc}")

        return stats_min, stats_max, stats_mean, stats_std

    def _get_parameter_stats(
        self, param_name: str, config: Dict[str, Any]
    ) -> Tuple[float, float, float, float]:
        stats_min = 0.0
        stats_max = 1.0
        stats_mean = 0.5
        stats_std = 0.1

        try:
            bounds = config.get("range_bounds") or config.get("bounds")
            if bounds and len(bounds) == 2:
                stats_min = float(bounds[0])
                stats_max = float(bounds[1])
            elif config.get("type") == "continuous" and config.get("bounds"):
                stats_min = float(config["bounds"][0])
                stats_max = float(config["bounds"][1])

            if stats_max <= stats_min:
                stats_max = stats_min + 1.0

            stats_mean = (stats_min + stats_max) / 2.0
            stats_std = max((stats_max - stats_min) / 6.0, 1e-6)

            target = config.get("target_value")
            if target is not None:
                stats_mean = float(target)
            tol = config.get("target_tolerance")
            if tol is not None:
                stats_std = max(float(tol), stats_std)

        except Exception as exc:
            logger.debug(f"Failed to compute parameter stats for {param_name}: {exc}")

        return stats_min, stats_max, stats_mean, stats_std

    def _scalar_desirability(
        self,
        value: float,
        goal: Optional[str],
        config: Dict[str, Any],
        stats: Tuple[float, float, float, float],
    ) -> Tuple[float, bool]:
        goal_lower = (goal or "maximize").lower()
        stats_min, stats_max, stats_mean, stats_std = stats

        desirability = 0.0
        feasible = True

        if goal_lower == "maximize":
            lower = float(config.get("target_value", stats_min))
            upper = max(stats_max, lower + 1e-6)
            span = max(upper - lower, 1e-8)
            desirability = np.clip((value - lower) / span, 0.0, 1.0)
            feasible = value >= lower

        elif goal_lower == "minimize":
            upper = float(config.get("target_value", stats_max))
            lower = min(stats_min, upper - 1e-6)
            span = max(upper - lower, 1e-8)
            desirability = np.clip((upper - value) / span, 0.0, 1.0)
            feasible = value <= upper

        elif goal_lower == "target":
            target = float(config.get("target_value", stats_mean))
            tol = config.get("target_tolerance")
            if tol is None:
                tol = max(0.05 * max(abs(target), stats_max - stats_min, 1.0), stats_std)
            tol = max(float(tol), 1e-6)
            diff = abs(value - target)
            desirability = math.exp(-((diff / tol) ** 2))
            feasible = diff <= tol

        elif goal_lower in {"range", "in range"}:
            bounds = config.get("range_bounds")
            if bounds and len(bounds) == 2:
                lower, upper = float(bounds[0]), float(bounds[1])
            else:
                lower, upper = stats_min, stats_max

            if upper <= lower:
                return 0.0, False

            margin = max(0.1 * (upper - lower), 1e-6)
            if lower <= value <= upper:
                desirability = 1.0
                feasible = True
            elif value < lower:
                desirability = math.exp(-((lower - value) / margin))
                feasible = False
            else:
                desirability = math.exp(-((value - upper) / margin))
                feasible = False
            desirability = np.clip(desirability, 0.0, 1.0)

        else:
            span = max(stats_max - stats_min, 1e-8)
            desirability = np.clip((value - stats_min) / span, 0.0, 1.0)
            feasible = True

        return float(np.clip(desirability, 0.0, 1.0)), feasible

    @staticmethod
    def _coerce_numeric(value: Any) -> Optional[float]:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None


    def get_data_quality_report(self) -> Dict[str, Dict[str, int]]:
        """
        Generate a data quality report for all responses in the experimental data.

        Returns:
            Dict[str, Dict[str, int]]: Dictionary mapping response names to quality metrics
                                      (total_rows, valid_count, nan_count, etc.)
        """
        if not hasattr(self, 'experimental_data') or self.experimental_data.empty:
            return {}

        report = {}
        candidate_responses = (
            list(self.responses_config.keys()) if self.responses_config else []
        )

        # Auto-detect responses if needed
        if not candidate_responses:
            param_names = (
                set(self.parameter_transformer.param_names)
                if hasattr(self, "parameter_transformer")
                else set()
            )
            candidate_responses = [
                col
                for col in self.experimental_data.columns
                if col not in param_names
                and self.experimental_data[col].dtype in ["float64", "float32", "int64", "int32"]
            ]

        for response_name in candidate_responses:
            if response_name not in self.experimental_data.columns:
                continue

            total_rows = len(self.experimental_data)
            valid_count = 0
            nan_count = 0
            empty_list_count = 0
            conversion_error_count = 0

            for _, row in self.experimental_data.iterrows():
                if response_name in row:
                    response_value = row[response_name]
                    try:
                        if isinstance(response_value, list):
                            if len(response_value) > 0:
                                mean_value = np.mean(response_value)
                            else:
                                empty_list_count += 1
                                continue
                        else:
                            mean_value = float(response_value)

                        if not np.isnan(mean_value) and np.isfinite(mean_value):
                            valid_count += 1
                        else:
                            nan_count += 1
                    except (ValueError, TypeError):
                        conversion_error_count += 1

            report[response_name] = {
                'total_rows': total_rows,
                'valid_count': valid_count,
                'nan_count': nan_count,
                'empty_list_count': empty_list_count,
                'conversion_error_count': conversion_error_count,
            }

        return report

    def get_response_models(self) -> Dict[str, SingleTaskGP]:
        """
        Builds and returns individual `SingleTaskGP` models for each response variable
        (objective or non-objective response) based on the current experimental data.
        These models can be used for plotting or further analysis of individual responses.

        Returns:
            Dict[str, SingleTaskGP]: A dictionary where keys are response names and values
                                    are the fitted `SingleTaskGP` models for those responses.
                                    Returns an empty dictionary if no models can be built.
        """
        try:
            # Debug logging to diagnose loading issues
            logger.debug("get_response_models() called")
            logger.debug(
                f'experimental_data shape: {self.experimental_data.shape if hasattr(self, "experimental_data") and not self.experimental_data.empty else "EMPTY"}'
            )
            if hasattr(self, "experimental_data") and not self.experimental_data.empty:
                logger.debug(f"experimental_data columns: {list(self.experimental_data.columns)}")
            logger.debug(
                f'responses_config keys: {list(self.responses_config.keys()) if self.responses_config else "NONE"}'
            )
            logger.debug(
                f'parameter_transformer available: {hasattr(self, "parameter_transformer")}'
            )
            models_dict = {}

            # Get candidate response names - try config first, then auto-detect from data
            candidate_responses = (
                list(self.responses_config.keys()) if self.responses_config else []
            )

            # If no responses found in config or config responses don't exist in data, auto-detect
            if not candidate_responses or not any(
                resp in self.experimental_data.columns for resp in candidate_responses
            ):
                logger.debug("Auto-detecting response columns from experimental data")
                # Auto-detect responses: exclude parameter columns, keep numeric columns
                param_names = (
                    set(self.parameter_transformer.param_names)
                    if hasattr(self, "parameter_transformer")
                    else set()
                )
                candidate_responses = [
                    col
                    for col in self.experimental_data.columns
                    if col not in param_names
                    and self.experimental_data[col].dtype
                    in ["float64", "float32", "int64", "int32"]
                    and not self.experimental_data[col].isna().all()
                ]
                logger.info(f"Auto-detected response columns: {candidate_responses}")

            # Iterate through each candidate response
            for response_name in candidate_responses:
                # Ensure the response data exists in the experimental data.
                if response_name not in self.experimental_data.columns:
                    logger.debug(
                        f"Response '{response_name}' not found in experimental data. Skipping model building."
                    )
                    continue

                X_data = []  # List to store parameter tensors for this response
                Y_data = []  # List to store response values for this response

                # Track data quality issues for better diagnostics
                total_rows = len(self.experimental_data)
                nan_count = 0
                empty_list_count = 0
                conversion_error_count = 0

                for _, row in self.experimental_data.iterrows():
                    # Extract parameter values for the current row.
                    param_dict = {
                        param_name: row[param_name]
                        for param_name in self.parameter_transformer.param_names
                    }

                    if response_name in row:
                        response_value = row[response_name]
                        try:
                            # Handle cases where the response might be a list (e.g., multiple replicates).
                            if isinstance(response_value, list):
                                if len(response_value) > 0:
                                    mean_value = np.mean(response_value)
                                else:
                                    empty_list_count += 1
                                    continue
                            else:
                                mean_value = float(response_value)

                            # Only include finite (non-NaN) response values for model training.
                            if not np.isnan(mean_value) and np.isfinite(mean_value):
                                X_tensor = self.parameter_transformer.params_to_tensor(param_dict)
                                X_data.append(X_tensor)
                                Y_data.append(mean_value)
                            else:
                                nan_count += 1
                        except (ValueError, TypeError) as e:
                            conversion_error_count += 1
                            logger.debug(f"Could not convert response value for {response_name}: {response_value} - {e}")

                # Build a GP model only if sufficient data points are available for this response.
                valid_count = len(Y_data)
                logger.debug(
                    f"Response {response_name}: {valid_count}/{total_rows} valid data points (need {MIN_DATA_POINTS_FOR_GP})"
                )

                if valid_count >= MIN_DATA_POINTS_FOR_GP:
                    X_tensor = torch.stack(X_data).to(self.device, self.dtype)
                    Y_tensor = torch.tensor(Y_data, dtype=self.dtype, device=self.device).unsqueeze(
                        -1
                    )  # Add feature dimension.

                    # Initialize and fit a SingleTaskGP model for this response.
                    # Create appropriate kernel based on parameter types (mixed variables support)
                    base_kernel = create_kernel_for_parameters(
                        self.params_config, X_tensor.shape[-1], self.kernel_type
                    )

                    model = SingleTaskGP(
                        train_X=X_tensor,
                        train_Y=Y_tensor,
                        covar_module=ScaleKernel(base_kernel),
                        input_transform=Normalize(d=X_tensor.shape[-1]),
                        outcome_transform=Standardize(m=1),
                    )

                    mll = ExactMarginalLogLikelihood(model.likelihood, model)
                    fit_gpytorch_mll(mll)

                    models_dict[response_name] = model
                    logger.debug(f"Successfully built GP model for response: {response_name}")
                else:
                    # Provide detailed diagnostic information
                    issues = []
                    if nan_count > 0:
                        issues.append(f"{nan_count} NaN/infinite values")
                    if empty_list_count > 0:
                        issues.append(f"{empty_list_count} empty lists")
                    if conversion_error_count > 0:
                        issues.append(f"{conversion_error_count} type conversion errors")

                    issue_detail = f" ({', '.join(issues)})" if issues else ""
                    logger.warning(
                        f"Insufficient valid data points for response '{response_name}': "
                        f"{valid_count}/{total_rows} valid (need ≥{MIN_DATA_POINTS_FOR_GP}){issue_detail}. "
                        f"Check your data for missing values, NaN, or formatting issues."
                    )

            return models_dict

        except Exception as e:
            logger.error(f"Error building response models: {e}", exc_info=True)
            return {}

    def get_predicted_values(self, response_name: str) -> np.ndarray:
        """
        Returns the predicted mean values for a given response based on the current
        experimental data and the fitted Gaussian Process model for that response.

        Args:
            response_name (str): The name of the response variable for which to get
                                 predicted values.

        Returns:
            np.ndarray: A NumPy array containing the predicted mean values for the
                        specified response at the observed experimental points.
                        Returns an empty array if no model is available or prediction fails.
        """
        try:
            models = self.get_response_models()
            model = models.get(response_name)

            if model is None or not hasattr(self, "train_X") or self.train_X.shape[0] == 0:
                logger.warning(
                    f"Cannot get predicted values for {response_name}: No model or training data available."
                )
                return np.array([])

            with torch.no_grad():
                # Predict the mean of the posterior distribution at the training points.
                posterior = model.posterior(model.train_inputs[0])
                mean = posterior.mean.squeeze().cpu().numpy()

                # Undo negation if the objective was minimized to return original scale.
                if response_name in self.objective_names:
                    obj_idx = self.objective_names.index(response_name)
                    if self.objective_directions[obj_idx] == -1:
                        mean = -mean

            logger.debug(f"Successfully retrieved predicted values for {response_name}.")
            return mean
        except Exception as e:
            logger.error(
                f"Error getting predicted values for {response_name}: {e}",
                exc_info=True,
            )
            return np.array([])

    def get_feature_importances(self, response_name: str) -> Dict[str, float]:
        """Extract feature importances via diagnostics helper."""
        try:
            from ._diagnostics import feature_importances as _feat

            return _feat(self, response_name)
        except Exception as e:
            logger.error(f"Error getting feature importances for {response_name}: {e}")
            return {}

    def get_data_subsampling_info(self) -> Dict[str, Any]:
        """Return data subsampling configuration and status via diagnostics helper."""
        try:
            from ._diagnostics import data_subsampling_info as _sub

            return _sub(self)
        except Exception:
            return {}

    def _fit_gp_model_optimized(self, mll):
        """
        Fit GP model with optimized matrix operations using Cholesky decomposition
        when possible for symmetric positive definite covariance matrices.

        Args:
            mll: Marginal log likelihood object from GPyTorch
        """
        import time

        start_time = time.time()

        try:
            # Standard GPyTorch fitting with optimizations
            # GPyTorch automatically uses Cholesky decomposition for SPD matrices
            fit_gpytorch_mll(mll)

            fit_time = time.time() - start_time

            # Log performance for monitoring
            n_data = mll.model.train_targets.shape[0] if hasattr(mll.model, "train_targets") else 0
            if fit_time > 1.0:  # Log slow fits
                logger.debug(f"GP fitting took {fit_time:.3f}s for {n_data} data points")

        except Exception as e:
            logger.error(f"Optimized GP fitting failed: {e}")
            raise

    def reset_random_state(self) -> None:
        """Reset RNGs to the initialization snapshot (if available)."""
        if getattr(self, "_initial_random_state", None):
            restore_random_state(self._initial_random_state)

    def cleanup(self) -> None:
        """Restore deterministic algorithm settings if they were modified."""
        if getattr(self, "_torch_deterministic_previous", None) is not None and hasattr(
            torch, "use_deterministic_algorithms"
        ):
            try:
                torch.use_deterministic_algorithms(self._torch_deterministic_previous)
            except Exception as exc:
                logger.debug("Failed to restore deterministic algorithms flag: %s", exc)
            finally:
                self._torch_deterministic_previous = None

        # Restore cuDNN flags if we changed them
        try:
            if (
                hasattr(self, "_cudnn_prev")
                and hasattr(torch, "backends")
                and hasattr(torch.backends, "cudnn")
            ):
                if self._cudnn_prev["benchmark"] is not None:
                    torch.backends.cudnn.benchmark = bool(self._cudnn_prev["benchmark"])
                if self._cudnn_prev["deterministic"] is not None:
                    torch.backends.cudnn.deterministic = bool(self._cudnn_prev["deterministic"])
        except Exception as exc:
            logger.debug("Failed to restore cuDNN flags: %s", exc)

    def get_matrix_performance_info(self) -> Dict[str, Any]:
        """Return BLAS backend and performance diagnostics via helper."""
        try:
            from ._diagnostics import matrix_performance_info as _mpi

            return _mpi(self)
        except Exception:
            return {}

    def save_state(self, filepath: str) -> None:
        """
        Save the complete optimizer state to a file for later resumption.

        Creates a comprehensive save file (.pymbo) containing all experimental data,
        trained models, configuration, and optimization history.

        Args:
            filepath (str): Path where the state file should be saved

        Example:
            >>> optimizer.save_state('my_optimization_2024-01-15.pymbo')
        """
        from ._state_management import save_optimizer_state
        save_optimizer_state(self, filepath)

    @classmethod
    def load_state(cls, filepath: str, device: Optional[str] = None) -> 'EnhancedMultiObjectiveOptimizer':
        """
        Load a previously saved optimizer state and restore it completely.

        Args:
            filepath (str): Path to the saved state file (.pymbo)
            device (Optional[str]): Device to load models onto ('cpu', 'cuda')

        Returns:
            EnhancedMultiObjectiveOptimizer: Fully restored optimizer instance

        Example:
            >>> optimizer = EnhancedMultiObjectiveOptimizer.load_state('my_optimization.pymbo')
            >>> next_experiments = optimizer.suggest_next_experiment(n_suggestions=3)
        """
        from ._state_management import load_optimizer_state
        return load_optimizer_state(cls, filepath, device)


