"""Constraint and goal utilities extracted from the optimizer.

Provides helpers to set up parameter constraints for acquisition optimization
and compute target-deviation objectives for Target goals.
"""

import logging
import pandas as pd
import torch

logger = logging.getLogger(__name__)


def setup_parameter_constraints(opt) -> None:
    """Populate opt.parameter_constraints from Range goals in params_config.

    Creates inequality constraint tuples compatible with BoTorch's optimize_acqf.
    Each constraint is represented as (indices, coefficients, rhs) in normalized
    parameter space. Target goals are handled as deviation objectives elsewhere.
    """
    opt.parameter_constraints = []
    opt.constraint_tolerance = 1e-3

    for name, config in opt.params_config.items():
        goal = config.get("goal", "None")
        param_idx = opt.parameter_transformer.param_names.index(name)

        if goal == "Target":
            logger.info(
                f"Skipping Target constraint for parameter '{name}' - handled as deviation objective"
            )
            continue

        if goal == "Range":
            range_bounds = config.get("range_bounds")
            if range_bounds is not None and len(range_bounds) == 2:
                range_min, range_max = range_bounds
                param_bounds = opt.parameter_transformer.bounds[param_idx]
                denom = param_bounds[1] - param_bounds[0]
                if denom <= 0:
                    logger.warning(
                        f"Cannot create range constraint for parameter '{name}' with zero span"
                    )
                    continue
                normalized_min = (range_min - param_bounds[0]) / denom
                normalized_max = (range_max - param_bounds[0]) / denom
                normalized_min = max(0.0, min(1.0, normalized_min))
                normalized_max = max(0.0, min(1.0, normalized_max))

                idx_tensor_lower = torch.tensor([param_idx], dtype=torch.long)
                idx_tensor_upper = torch.tensor([param_idx], dtype=torch.long)
                dtype = opt.dtype if hasattr(opt, "dtype") else torch.double
                device = opt.device if hasattr(opt, "device") else torch.device('cpu')
                lower_coeff = torch.tensor([-1.0], dtype=dtype, device=device)
                upper_coeff = torch.tensor([1.0], dtype=dtype, device=device)
                lower_rhs = torch.tensor([-float(normalized_min)], dtype=dtype, device=device)
                upper_rhs = torch.tensor([float(normalized_max)], dtype=dtype, device=device)

                opt.parameter_constraints.extend(
                    [
                        (idx_tensor_lower, lower_coeff, lower_rhs),
                        (idx_tensor_upper, upper_coeff, upper_rhs),
                    ]
                )
                logger.info(
                    f"Added Range constraint for '{name}': range=[{range_min}, {range_max}] "
                    f"(norm=[{normalized_min:.4f}, {normalized_max:.4f}])"
                )

    logger.info(
        f"Setup {len(opt.parameter_constraints)} parameter constraints"
    )


def calculate_target_deviations(opt, data_df: pd.DataFrame) -> pd.DataFrame:
    """Append target deviation columns for Target goals and return a new DataFrame."""
    updated_df = data_df.copy()
    for name, config in opt.params_config.items():
        if config.get("goal", "None") == "Target":
            target_value = config.get("target_value")
            if target_value is not None and name in updated_df.columns:
                deviation_column = f"{name}_target_deviation"
                updated_df[deviation_column] = (updated_df[name] - target_value).abs()
                logger.debug(
                    f"Calculated target deviations for '{name}' with target={target_value}"
                )
    return updated_df
