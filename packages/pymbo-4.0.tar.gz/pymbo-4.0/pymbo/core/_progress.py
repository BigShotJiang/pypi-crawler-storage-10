"""Progress and Pareto utilities extracted from the optimizer.

Provides reusable helpers for convergence analysis, progress summaries,
and Pareto front extraction without coupling to the optimizer class.
"""

from typing import Dict, Any, Tuple
import logging
import numpy as np
import pandas as pd
import torch
from botorch.utils.multi_objective.pareto import is_non_dominated

logger = logging.getLogger(__name__)


def check_hv_convergence(
    iteration_history, window_size: int = 5, threshold: float = 0.01, use_normalized: bool = True
) -> Dict[str, Any]:
    result = {
        "converged": False,
        "progress_stagnant": False,
        "iterations_stable": 0,
        "relative_improvement": 0.0,
        "recommendation": "continue",
        "confidence": "low",
    }
    try:
        optimization_iterations = [
            h for h in iteration_history if h.get("iteration_type") == "optimization"
        ]
        if len(optimization_iterations) < window_size:
            result["recommendation"] = "continue - insufficient optimization data"
            result["note"] = (
                f"Need {window_size - len(optimization_iterations)} more optimization iterations"
            )
            return result

        hv_key = "normalized_hypervolume" if use_normalized else "hypervolume"
        recent_hvs = []
        for it in optimization_iterations[-window_size:]:
            hv_val = it.get("hypervolume", 0.0)
            if isinstance(hv_val, dict):
                recent_hvs.append(hv_val.get(hv_key, 0.0))
            else:
                recent_hvs.append(hv_val)
        if not recent_hvs or all(hv == 0.0 for hv in recent_hvs):
            result["recommendation"] = "continue - no valid hypervolume data"
            return result

        max_hv, min_hv = max(recent_hvs), min(recent_hvs)
        relative_improvement = (max_hv - min_hv) / max(max_hv, 1e-12)
        result["relative_improvement"] = relative_improvement

        if relative_improvement < threshold:
            result["converged"] = True
            result["iterations_stable"] = window_size
            result["confidence"] = "high" if window_size >= 10 else "medium"

            if len(optimization_iterations) >= window_size * 2:
                earlier_hvs = []
                for it in optimization_iterations[-(window_size * 2) : -window_size]:
                    hv_val = it.get("hypervolume", 0.0)
                    earlier_hvs.append(
                        hv_val.get(hv_key, 0.0) if isinstance(hv_val, dict) else hv_val
                    )
                if earlier_hvs and max(earlier_hvs) > 1e-12:
                    long_term = (max(recent_hvs) - max(earlier_hvs)) / max(earlier_hvs)
                    if long_term < threshold / 2:
                        result["progress_stagnant"] = True
                        result["recommendation"] = "consider_stopping"
                    else:
                        result["recommendation"] = "continue_cautiously"
        else:
            result["recommendation"] = "continue"

        if len(recent_hvs) >= 3:
            x = list(range(len(recent_hvs)))
            n = len(recent_hvs)
            sum_x = sum(x)
            sum_y = sum(recent_hvs)
            sum_xy = sum(xi * yi for xi, yi in zip(x, recent_hvs))
            sum_x2 = sum(xi * xi for xi in x)
            denom = n * sum_x2 - sum_x * sum_x
            if denom != 0:
                slope = (n * sum_xy - sum_x * sum_y) / denom
                result["trend_slope"] = slope
                if slope < -threshold / 10:
                    result["recommendation"] = "investigate_degradation"
        return result
    except Exception as e:
        logger.error(f"Error in convergence check: {e}")
        result["recommendation"] = "continue - error in analysis"
        return result


def summarize_progress(opt) -> Dict[str, Any]:
    summary = {
        "total_iterations": len(getattr(opt, "iteration_history", [])),
        "baseline_iterations": 0,
        "optimization_iterations": 0,
        "batch_import_iterations": 0,
        "total_experiments": (
            len(getattr(opt, "experimental_data", [])) if hasattr(opt, "experimental_data") else 0
        ),
        "baseline_hypervolume": getattr(opt, "baseline_hypervolume", 0.0),
        "current_hypervolume": None,
        "improvement_over_baseline": 0.0,
        "hypervolume_trend": "unknown",
        "convergence_status": "unknown",
        "efficiency_metrics": {},
        "recommendations": [],
    }
    try:
        hist = getattr(opt, "iteration_history", [])
        baseline_iterations = [h for h in hist if h.get("is_baseline", False)]
        optimization_iterations = [h for h in hist if h.get("iteration_type") == "optimization"]
        batch_import_iterations = [h for h in hist if h.get("iteration_type") == "batch_import"]
        summary["baseline_iterations"] = len(baseline_iterations)
        summary["optimization_iterations"] = len(optimization_iterations)
        summary["batch_import_iterations"] = len(batch_import_iterations)

        if not hist:
            summary["recommendations"].append("Start optimization by adding experimental data")
            return summary

        latest = hist[-1]
        hv_val = latest.get("hypervolume", 0.0)
        if isinstance(hv_val, dict):
            summary["current_hypervolume"] = {
                "raw": hv_val.get("raw_hypervolume", 0.0),
                "normalized": hv_val.get("normalized_hypervolume", 0.0),
                "data_points_used": hv_val.get("data_points_used", 0),
            }
        else:
            summary["current_hypervolume"] = {"raw": hv_val, "normalized": None}

        if len(hist) >= 3:
            recent_n = min(10, len(hist))
            recent_hvs = []
            for it in hist[-recent_n:]:
                val = it.get("hypervolume", 0.0)
                recent_hvs.append(val.get("raw_hypervolume", 0.0) if isinstance(val, dict) else val)
            if len(recent_hvs) >= 3 and max(recent_hvs) > 1e-12:
                first = sum(recent_hvs[: len(recent_hvs) // 3]) / max(1, (len(recent_hvs) // 3))
                last = sum(recent_hvs[-len(recent_hvs) // 3 :]) / max(1, (len(recent_hvs) // 3))
                rel = (last - first) / max(first, 1e-12)
                if rel > 0.05:
                    summary["hypervolume_trend"] = "improving"
                elif rel > -0.02:
                    summary["hypervolume_trend"] = "stable"
                else:
                    summary["hypervolume_trend"] = "declining"

        conv = check_hv_convergence(hist)
        summary["convergence_status"] = conv["recommendation"]
        summary["convergence_details"] = conv

        if len(hist) > 1:
            current_hv = (
                summary["current_hypervolume"]["raw"] if summary["current_hypervolume"] else 0.0
            )
            experiments_count = summary["total_experiments"]
            if experiments_count > 0:
                summary["efficiency_metrics"]["hv_per_experiment"] = current_hv / experiments_count
            if len(hist) >= 5:
                early = hist[min(4, len(hist) - 1)].get("hypervolume", 0.0)
                early = early.get("raw_hypervolume", 0.0) if isinstance(early, dict) else early
                if early > 1e-12:
                    summary["efficiency_metrics"]["improvement_rate"] = (current_hv - early) / early

        if summary["hypervolume_trend"] == "declining":
            summary["recommendations"].append("Check for overfitting or data quality issues")
        elif summary["hypervolume_trend"] == "stable" and len(hist) > 10:
            summary["recommendations"].append(
                "Consider stopping early or changing acquisition settings"
            )
        elif summary["hypervolume_trend"] == "improving" and len(hist) > 20:
            summary["recommendations"].append("Keep exploring or increase batch size for speed")
        return summary
    except Exception as e:
        logger.error(f"Error summarizing progress: {e}")
        return summary


def pareto_front(
    train_X: torch.Tensor, train_Y: torch.Tensor, experimental_data: pd.DataFrame, param_names
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray]:
    if train_X is None or train_Y is None or train_Y.shape[0] == 0:
        return pd.DataFrame(), pd.DataFrame(), np.array([])
    finite_mask = torch.isfinite(train_Y).all(dim=1)
    if not finite_mask.any():
        return pd.DataFrame(), pd.DataFrame(), np.array([])
    clean_Y = train_Y[finite_mask]
    clean_X = train_X[finite_mask]
    clean_indices = torch.where(finite_mask)[0]
    pareto_mask = is_non_dominated(clean_Y)
    pareto_indices = clean_indices[pareto_mask].cpu().numpy()
    pareto_params = pd.DataFrame(clean_X[pareto_mask].cpu().numpy(), columns=list(param_names))
    pareto_objectives = pd.DataFrame(clean_Y[pareto_mask].cpu().numpy())
    try:
        param_df = experimental_data[list(param_names)].iloc[pareto_indices].reset_index(drop=True)
        obj_cols = [col for col in experimental_data.columns if col not in param_names]
        obj_df = experimental_data[obj_cols].iloc[pareto_indices].reset_index(drop=True)
        return param_df, obj_df, pareto_indices
    except Exception:
        return pareto_params, pareto_objectives, pareto_indices
