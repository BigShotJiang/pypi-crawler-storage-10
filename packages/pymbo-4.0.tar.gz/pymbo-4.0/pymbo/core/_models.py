"""Model and data-tensor utilities extracted from the optimizer.

Provide helpers to update training tensors and build GP models without keeping
large method bodies inside the optimizer class. These functions expect the
optimizer instance to be passed in, and they use its attributes (device, dtype,
parameter_transformer, etc.).
"""

from __future__ import annotations

from typing import Optional
import logging
import numpy as np
import pandas as pd
import torch
from botorch.models import SingleTaskGP, ModelListGP
from botorch.models.transforms.input import Normalize
from botorch.models.transforms.outcome import Standardize
from gpytorch.kernels import ScaleKernel
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.fit import fit_gpytorch_mll

logger = logging.getLogger(__name__)

# Mirror optimizer constant to avoid circular import
MIN_DATA_POINTS_FOR_GP = 3


def update_training_data(opt) -> None:
    """Update opt.train_X and opt.train_Y from opt.experimental_data.

    Performs a vectorized path with batching and falls back to a row-by-row
    construction if anything fails. Applies objective direction negation.
    """
    if getattr(opt, "experimental_data", pd.DataFrame()).empty:
        logger.info("No experimental data to update training tensors.")
        return

    import time

    start_time = time.time()
    n_rows = len(opt.experimental_data)

    try:
        param_names = opt.parameter_transformer.param_names
        param_data = opt.experimental_data[param_names].values

        objective_data = []
        for obj_name in opt.objective_names:
            if obj_name in opt.experimental_data.columns:
                values = opt.experimental_data[obj_name].values
                processed_values = []
                for value in values:
                    if isinstance(value, list) and len(value) > 0:
                        processed_values.append(float(np.mean(value)))
                    else:
                        processed_values.append(float(value) if not pd.isna(value) else np.nan)
                objective_data.append(processed_values)
            else:
                objective_data.append([np.nan] * n_rows)

        objective_data = np.array(objective_data).T

        batch_size = min(1000, n_rows)
        X_batches = []
        for i in range(0, n_rows, batch_size):
            batch_end = min(i + batch_size, n_rows)
            param_batch = param_data[i:batch_end]
            param_dicts = [
                {param_names[j]: param_batch[k, j] for j in range(len(param_names))}
                for k in range(len(param_batch))
            ]
            X_tensors = [opt.parameter_transformer.params_to_tensor(d) for d in param_dicts]
            if X_tensors:
                X_batch = torch.stack(X_tensors)
                X_batches.append(X_batch)

        if X_batches:
            opt.train_X = torch.cat(X_batches, dim=0).to(opt.device, opt.dtype)
        else:
            logger.warning("No valid parameter data found")
            return

        opt.train_Y = torch.tensor(objective_data, dtype=opt.dtype, device=opt.device)

        # Apply Target and Range transformations before direction negation
        for i, obj_def in enumerate(opt.objective_definitions):
            obj_type = obj_def.get("type")

            if obj_type == "response_target":
                target_value = obj_def.get("target_value")
                if target_value is not None:
                    opt.train_Y[:, i] = torch.abs(opt.train_Y[:, i] - target_value)
                    logger.debug(
                        f"Transformed '{obj_def['name']}' to deviation from target={target_value}"
                    )

            elif obj_type == "response_range":
                range_bounds = obj_def.get("range_bounds")
                if range_bounds and len(range_bounds) == 2:
                    lower, upper = float(range_bounds[0]), float(range_bounds[1])
                    values = opt.train_Y[:, i]
                    below_mask = values < lower
                    above_mask = values > upper
                    penalty = torch.zeros_like(values)
                    penalty[below_mask] = lower - values[below_mask]
                    penalty[above_mask] = values[above_mask] - upper
                    opt.train_Y[:, i] = penalty
                    logger.debug(
                        f"Transformed '{obj_def['name']}' to range violation penalty for range=[{lower}, {upper}]"
                    )

        for i, direction in enumerate(opt.objective_directions):
            if direction == -1:
                opt.train_Y[:, i] = -opt.train_Y[:, i]

        update_time = time.time() - start_time
        logger.info(
            f"Training data updated: {opt.train_X.shape[0]} samples (X: {opt.train_X.shape}, Y: {opt.train_Y.shape}) "
            f"processed in {update_time:.3f}s"
        )

    except Exception as e:
        logger.error(f"Error in optimized training data update: {e}")
        logger.info("Falling back to row-by-row processing...")
        X_list = []
        Y_list = []
        for _, row in opt.experimental_data.iterrows():
            param_dict = {name: row[name] for name in opt.parameter_transformer.param_names}
            X_tensor = opt.parameter_transformer.params_to_tensor(param_dict)
            X_list.append(X_tensor)

            y_values = []
            for obj_name in opt.objective_names:
                if obj_name in row:
                    value = row[obj_name]
                    if isinstance(value, list) and len(value) > 0:
                        mean_value = float(np.mean(value))
                    else:
                        mean_value = float(value)
                    y_values.append(mean_value)
                else:
                    y_values.append(np.nan)

            Y_tensor = torch.tensor(y_values, dtype=opt.dtype, device=opt.device)
            Y_list.append(Y_tensor)

        if X_list and Y_list:
            opt.train_X = torch.stack(X_list).to(opt.device, opt.dtype)
            opt.train_Y = torch.stack(Y_list).to(opt.device, opt.dtype)

            # Apply Target and Range transformations (same as optimized path)
            for i, obj_def in enumerate(opt.objective_definitions):
                obj_type = obj_def.get("type")

                if obj_type == "response_target":
                    target_value = obj_def.get("target_value")
                    if target_value is not None:
                        opt.train_Y[:, i] = torch.abs(opt.train_Y[:, i] - target_value)

                elif obj_type == "response_range":
                    range_bounds = obj_def.get("range_bounds")
                    if range_bounds and len(range_bounds) == 2:
                        lower, upper = float(range_bounds[0]), float(range_bounds[1])
                        values = opt.train_Y[:, i]
                        below_mask = values < lower
                        above_mask = values > upper
                        penalty = torch.zeros_like(values)
                        penalty[below_mask] = lower - values[below_mask]
                        penalty[above_mask] = values[above_mask] - upper
                        opt.train_Y[:, i] = penalty

            for i, direction in enumerate(opt.objective_directions):
                if direction == -1:
                    opt.train_Y[:, i] = -opt.train_Y[:, i]


def build_models(opt, kernel_factory) -> Optional[ModelListGP]:
    """Build one SingleTaskGP per objective and return a ModelListGP or single model.

    Args:
        opt: optimizer instance with train_X/train_Y prepared
        kernel_factory: callable(params_config, ard_num_dims) -> kernel
    """
    if not hasattr(opt, "train_X") or not hasattr(opt, "train_Y"):
        logger.warning("No training data available for model building.")
        return None
    if opt.train_X.shape[0] == 0 or opt.train_Y.shape[0] == 0:
        logger.warning("Empty training data for model building.")
        return None

    models = []
    for i, obj_name in enumerate(opt.objective_names):
        if i >= opt.train_Y.shape[1]:
            logger.warning(f"Objective index {i} exceeds training data dimensions for {obj_name}")
            continue
        Y_obj = opt.train_Y[:, i]
        finite_mask = torch.isfinite(Y_obj)
        if finite_mask.sum() < MIN_DATA_POINTS_FOR_GP:
            logger.warning(
                f"Insufficient finite data points ({finite_mask.sum()}) for objective {obj_name}. Skipping model building."
            )
            continue

        X_filtered = opt.train_X[finite_mask]
        Y_filtered = Y_obj[finite_mask].unsqueeze(-1)

        base_kernel = kernel_factory(opt.params_config, X_filtered.shape[-1])
        covar_module = ScaleKernel(base_kernel)
        model = SingleTaskGP(
            train_X=X_filtered,
            train_Y=Y_filtered,
            covar_module=covar_module,
            input_transform=Normalize(d=X_filtered.shape[-1]),
            outcome_transform=Standardize(m=1),
        )

        mll = ExactMarginalLogLikelihood(model.likelihood, model)
        try:
            if hasattr(opt, "_fit_gp_model_optimized"):
                opt._fit_gp_model_optimized(mll)
            else:
                fit_gpytorch_mll(mll)
        except Exception as e:
            logger.warning(f"Optimized GP fitting failed ({e}), falling back to standard fitting")
            fit_gpytorch_mll(mll)

        models.append(model)

    if not models:
        logger.warning("No GP models could be built for any objective.")
        return None
    if len(models) != len(opt.objective_names):
        logger.error(
            f"Model count mismatch: built {len(models)} models for {len(opt.objective_names)} objectives"
        )
        logger.error(f"Objectives: {opt.objective_names}")
        logger.error("This can cause dimension mismatches in acquisition functions")
        return None
    return ModelListGP(*models) if len(models) > 1 else models[0]
