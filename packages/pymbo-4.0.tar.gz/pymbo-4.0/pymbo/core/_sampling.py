"""Sampling helpers for initial design and fallback generation.

Provides Latin Hypercube Sampling (LHS) and uniform random sampling in the
normalized parameter space, returning parameter dictionaries in original scale.
"""

from typing import List, Dict, Any
import logging
import torch
from scipy.stats import qmc

logger = logging.getLogger(__name__)


def random_samples(opt, n_suggestions: int) -> List[Dict[str, Any]]:
    suggestions: List[Dict[str, Any]] = []
    max_attempts = n_suggestions * 10
    attempts = 0
    while len(suggestions) < n_suggestions and attempts < max_attempts:
        sample = torch.rand(len(opt.parameter_transformer.param_names), dtype=opt.dtype)
        param_dict = opt.parameter_transformer.tensor_to_params(sample)
        is_unique = True
        for existing in suggestions:
            if opt._are_params_similar(param_dict, existing):
                is_unique = False
                break
        if is_unique:
            suggestions.append(param_dict)
        attempts += 1
    logger.debug(f"Generated {len(suggestions)} random suggestions.")
    return suggestions


def doe_samples(opt, n_suggestions: int, method: str = "LHS") -> List[Dict[str, Any]]:
    suggestions: List[Dict[str, Any]] = []
    bounds = opt.parameter_transformer.bounds_tensor.T.cpu().numpy()
    if method == "LHS":
        sampler = qmc.LatinHypercube(d=opt.parameter_transformer.n_params)
        lhs = sampler.random(n=n_suggestions)
        for i in range(n_suggestions):
            sample_2d = lhs[i].reshape(1, -1)
            scaled = qmc.scale(sample_2d, bounds[0], bounds[1]).flatten()
            tensor = torch.tensor(scaled, dtype=opt.dtype)
            param_dict = opt.parameter_transformer.tensor_to_params(tensor)
            suggestions.append(param_dict)
        logger.info(
            f"Generated {len(suggestions)} initial suggestions using Latin Hypercube Sampling."
        )
        return suggestions
    else:
        logger.warning(f"Unknown DoE method: {method}. Falling back to random sampling.")
        return random_samples(opt, n_suggestions)
