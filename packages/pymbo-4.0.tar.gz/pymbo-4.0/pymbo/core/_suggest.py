"""Suggestion optimization helpers extracted from the optimizer.

This module centralizes acquisition optimization and related adaptive logic.
It expects to be called with the optimizer instance (for context and helpers).
"""

from typing import List
import logging
import time
import torch
from botorch.optim import optimize_acqf

logger = logging.getLogger(__name__)


def optimize_acquisition(opt, acq_func, n_suggestions: int) -> List[dict]:
    """Optimize the acquisition function using the optimizer context.

    Uses adaptive restarts/raw samples and supports fast-validation shortcuts.
    Returns a list of parameter dictionaries in original scale.
    """
    try:
        bounds = torch.stack(
            [
                torch.zeros(len(opt.parameter_transformer.param_names), dtype=opt.dtype),
                torch.ones(len(opt.parameter_transformer.param_names), dtype=opt.dtype),
            ]
        ).to(opt.device)

        n_data = (
            len(opt.experimental_data)
            if hasattr(opt, "experimental_data") and not opt.experimental_data.empty
            else 0
        )

        if getattr(opt, "fast_validation_mode", False):
            adaptive_restarts = 1
            adaptive_raw_samples = 2
        elif n_data < 20:
            adaptive_restarts = min(2, opt.num_restarts)
            adaptive_raw_samples = min(12, opt.raw_samples)
        elif n_data < 100:
            adaptive_restarts = min(3, opt.num_restarts)
            adaptive_raw_samples = min(20, opt.raw_samples)
        else:
            adaptive_restarts = opt.num_restarts
            adaptive_raw_samples = opt.raw_samples

        start_time = time.time()
        max_optimization_time = 1.0 if getattr(opt, "fast_validation_mode", False) else 10.0

        if (
            getattr(opt, "fast_validation_mode", False)
            and getattr(opt, "_slow_optimizations", 0) >= 2
        ):
            cached = opt._try_cached_candidates(n_suggestions, n_data)
            if cached is not None:
                return cached

        if (
            getattr(opt, "fast_validation_mode", False)
            and getattr(opt, "_slow_optimizations", 0) >= 1
        ):
            logger.debug("Ultra-fast validation mode: using random sampling fallback")
            return opt._generate_random_samples(n_suggestions)

        try:
            optimization_kwargs = {
                "acq_function": acq_func,
                "bounds": bounds,
                "q": n_suggestions,
                "num_restarts": adaptive_restarts,
                "raw_samples": adaptive_raw_samples,
            }
            if hasattr(opt, "parameter_constraints") and opt.parameter_constraints:
                optimization_kwargs["inequality_constraints"] = opt.parameter_constraints

            candidates, _ = optimize_acqf(**optimization_kwargs)
            optimization_time = time.time() - start_time
            if optimization_time > max_optimization_time and getattr(
                opt, "fast_validation_mode", False
            ):
                opt._slow_optimizations = getattr(opt, "_slow_optimizations", 0) + 1
        except Exception as e:
            logger.warning(f"Acquisition optimization failed: {e}")
            logger.info("Falling back to minimal optimization settings")
            fallback_kwargs = {
                "acq_function": acq_func,
                "bounds": bounds,
                "q": n_suggestions,
                "num_restarts": 1,
                "raw_samples": 2,
            }
            if hasattr(opt, "parameter_constraints") and opt.parameter_constraints:
                fallback_kwargs["inequality_constraints"] = opt.parameter_constraints
            candidates, _ = optimize_acqf(**fallback_kwargs)
            optimization_time = time.time() - start_time

        suggestions = []
        for i in range(candidates.shape[0]):
            param_dict = opt.parameter_transformer.tensor_to_params(candidates[i])
            if hasattr(opt, "parameter_constraints") and opt.parameter_constraints:
                is_valid, violations = opt.parameter_transformer.validate_parameter_constraints(
                    param_dict
                )
                if not is_valid:
                    param_dict = opt.parameter_transformer.enforce_parameter_constraints(param_dict)
            suggestions.append(param_dict)

        opt._cache_candidates(candidates, optimization_time)
        if len(suggestions) > n_suggestions:
            suggestions = suggestions[:n_suggestions]
        return suggestions

    except Exception as e:
        logger.error(f"Error optimizing acquisition function: {e}", exc_info=True)
        return opt._generate_random_samples(n_suggestions)
