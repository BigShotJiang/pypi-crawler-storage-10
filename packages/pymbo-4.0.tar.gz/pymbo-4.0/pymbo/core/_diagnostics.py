"""Diagnostics utilities: feature importances, subsampling and BLAS info.

These helpers use the optimizer context to report insights without keeping
large method bodies in the optimizer class.
"""

from typing import Dict, Any
import logging
import numpy as np

logger = logging.getLogger(__name__)


def feature_importances(opt, response_name: str) -> Dict[str, float]:
    """Extract feature importances (inverse lengthscales) for a response model.

    Returns a dict mapping parameter name -> normalized importance in [0,1].
    """
    try:
        models = opt.get_response_models()
        model = models.get(response_name)
        if (
            model is None
            or not hasattr(model.covar_module, "base_kernel")
            or not hasattr(model.covar_module.base_kernel, "lengthscale")
        ):
            logger.warning(
                f"Model for {response_name} does not have lengthscales for sensitivity analysis."
            )
            return {}

        lengthscales = model.covar_module.base_kernel.lengthscale.squeeze().detach().cpu().numpy()
        importances = 1.0 / lengthscales
        total = np.sum(importances)
        if total > 0:
            importances = importances / total
        feat: Dict[str, float] = {}
        for i, param_name in enumerate(opt.parameter_transformer.param_names):
            feat[param_name] = float(importances[i])
        return feat
    except Exception as e:
        logger.error(f"Error getting feature importances for {response_name}: {e}")
        return {}


def data_subsampling_info(opt) -> Dict[str, Any]:
    info = {
        "subsampling_enabled": getattr(opt, "max_gp_points", None) is not None,
        "max_gp_points": getattr(opt, "max_gp_points", None),
        "current_data_points": (
            len(getattr(opt, "experimental_data", [])) if hasattr(opt, "experimental_data") else 0
        ),
        "recommended_limits": {
            "fast_mode": (
                getattr(opt, "FAST_MODE_MAX_GP_POINTS", 50)
                if hasattr(opt, "FAST_MODE_MAX_GP_POINTS")
                else 50
            ),
            "default": (
                getattr(opt, "DEFAULT_MAX_GP_POINTS", 100)
                if hasattr(opt, "DEFAULT_MAX_GP_POINTS")
                else 100
            ),
            "maximum_recommended": (
                getattr(opt, "MAX_RECOMMENDED_GP_POINTS", 200)
                if hasattr(opt, "MAX_RECOMMENDED_GP_POINTS")
                else 200
            ),
        },
    }
    if info["subsampling_enabled"] and hasattr(opt, "experimental_data"):
        current_points = len(opt.experimental_data)
        info.update(
            {
                "is_at_limit": current_points >= (opt.max_gp_points or 0),
                "utilization_percentage": (current_points / (opt.max_gp_points or 1)) * 100,
                "points_until_limit": max(0, (opt.max_gp_points or 0) - current_points),
            }
        )
    return info


def matrix_performance_info(opt) -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "blas_optimizations_applied": getattr(opt, "blas_optimizations_applied", False),
        "backend_info": {},
        "performance_recommendations": [],
    }
    try:
        if hasattr(opt, "blas_optimizer"):
            info["backend_info"] = opt.blas_optimizer._get_backend_info()
            info["performance_recommendations"] = (
                opt.blas_optimizer.get_optimization_recommendations()
            )
        if hasattr(opt, "max_gp_points"):
            info["data_subsampling"] = data_subsampling_info(opt)
        return info
    except Exception as e:
        logger.warning(f"Could not get matrix performance info: {e}")
        info["error"] = str(e)
        return info
