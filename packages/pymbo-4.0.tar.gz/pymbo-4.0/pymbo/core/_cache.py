"""Candidate caching helpers extracted from the optimizer.

Encapsulates caching and reuse of optimized acquisition candidates.
"""

from typing import List, Optional, Dict, Any
import logging
import time
import torch

logger = logging.getLogger(__name__)


def cache_candidates(opt, candidates: torch.Tensor, optimization_time: float) -> None:
    """Store candidate tensor and metadata in the optimizer cache."""
    try:
        entry = {
            "candidates": candidates.clone().detach(),
            "timestamp": time.time(),
            "optimization_time": optimization_time,
            "data_size": (
                len(opt.experimental_data)
                if hasattr(opt, "experimental_data") and not opt.experimental_data.empty
                else 0
            ),
        }
        opt._candidate_cache.append(entry)
        if len(opt._candidate_cache) > opt._cache_max_size:
            opt._candidate_cache.pop(0)
        logger.debug(
            f"Cached {len(candidates)} candidates (cache size: {len(opt._candidate_cache)})"
        )
    except Exception as e:
        logger.debug(f"Failed to cache candidates: {e}")


def try_cached_candidates(
    opt, n_suggestions: int, current_data_size: int
) -> Optional[List[Dict[str, Any]]]:
    """Return a subset of cached candidates as parameter dicts if suitable, else None."""
    try:
        if not getattr(opt, "_candidate_cache", []):
            return None

        suitable = []
        for entry in opt._candidate_cache:
            if current_data_size <= 1:
                suitable.append(entry)
            else:
                diff = abs(entry["data_size"] - current_data_size) / max(current_data_size, 1)
                if diff <= 0.5:
                    suitable.append(entry)
        if not suitable and len(opt._candidate_cache) > 0:
            suitable = list(opt._candidate_cache)
            logger.debug("Using any available cached candidates (no size match)")

        best_entry = max(suitable, key=lambda x: x["timestamp"])
        cached = best_entry["candidates"]
        if len(cached) >= n_suggestions:
            idx = torch.randperm(len(cached))[:n_suggestions]
            selected = cached[idx]
        else:
            selected = cached
        suggestions: List[Dict[str, Any]] = []
        for i in range(len(selected)):
            param_dict = opt.parameter_transformer.tensor_to_params(selected[i])
            suggestions.append(param_dict)
        logger.info(f"Using {len(suggestions)} cached candidates (saved optimization time)")
        return suggestions
    except Exception as e:
        logger.debug(f"Failed to use cached candidates: {e}")
        return None
