"""Acquisition setup helpers extracted from the optimizer.

These utilities configure modern and legacy acquisition functions without
entangling the core optimizer class with long method bodies.
"""

from typing import Optional, Union
import logging
import torch
from botorch.acquisition.analytic import LogExpectedImprovement
from botorch.acquisition.multi_objective import ExpectedHypervolumeImprovement
from botorch.models import SingleTaskGP, ModelListGP
from botorch.utils.multi_objective.box_decompositions.non_dominated import (
    FastNondominatedPartitioning,
)

logger = logging.getLogger(__name__)


def setup_acquisition_function(opt, models: Union[SingleTaskGP, ModelListGP]) -> Optional[object]:
    """Create a suitable acquisition function using the optimizer context.

    Attempts modern acquisition (qLogEI/qNEHVI) via opt's modern core; falls
    back to legacy EI/EHVI paths. Returns None on failure.
    """
    # Require some training data
    if not hasattr(opt, "train_Y") or opt.train_Y.shape[0] == 0:
        logger.warning("No training data available to set up acquisition function.")
        return None

    # Try modern acquisition first if available
    try:
        if getattr(opt, "MODERN_ACQUISITION_AVAILABLE", False) or True:
            try:
                from .modern_acquisition_core import create_modern_acquisition_function

                # Best-effort params_config reconstruction
                params_config = getattr(opt, "parameters", None)
                if not params_config and hasattr(opt, "parameter_transformer"):
                    param_names = getattr(opt.parameter_transformer, "param_names", [])
                    params_config = {
                        name: {"type": "continuous", "bounds": [0, 1]} for name in param_names
                    }

                acq = create_modern_acquisition_function(
                    train_X=opt.train_X,
                    train_Y=opt.train_Y,
                    objective_names=opt.objective_names,
                    params_config=params_config,
                )
                if acq is not None:
                    return acq
            except Exception as e:
                logger.debug(f"Modern acquisition setup failed: {e}")
    except Exception:
        pass

    # Legacy fallbacks
    if len(opt.objective_names) > 1:
        # Multi-objective: either weighted scalarization or EHVI
        if getattr(opt, "has_weighted_objectives", False):
            return _setup_weighted_scalarization_acquisition(opt, models)

        finite_mask = torch.isfinite(opt.train_Y).all(dim=1)
        if not finite_mask.any():
            logger.warning("No finite data points for EHVI calculation.")
            return None
        clean_Y = opt.train_Y[finite_mask]
        if clean_Y.shape[0] == 0:
            logger.warning("No clean data points for EHVI calculation.")
            return None

        from ._hv import calculate_adaptive_reference_point

        ref_point = calculate_adaptive_reference_point(clean_Y)
        partitioning = FastNondominatedPartitioning(ref_point=ref_point, Y=clean_Y)

        if isinstance(models, ModelListGP):
            expected_outputs = len(models.models)
        else:
            expected_outputs = models.num_outputs if hasattr(models, "num_outputs") else 1
        if expected_outputs != clean_Y.shape[1]:
            logger.error("Model outputs do not match data objectives")
            return None

        ehvi = ExpectedHypervolumeImprovement(
            model=models, ref_point=ref_point.tolist(), partitioning=partitioning
        )
        # Validate with a test input
        try:
            test_input = torch.randn(
                1, len(opt.parameter_transformer.param_names), dtype=opt.dtype, device=opt.device
            )
            _ = ehvi(test_input)
            return ehvi
        except Exception:
            logger.debug("EHVI validation failed; attempting scalarized EI fallback")
            return _create_scalarized_ei_fallback(opt, models, clean_Y)

    else:
        # Single objective: LogEI
        finite_Y = opt.train_Y[torch.isfinite(opt.train_Y)]
        if finite_Y.numel() == 0:
            logger.warning("No finite data points for EI calculation.")
            return None
        best_f = finite_Y.max()
        model_for_ei = models if isinstance(models, SingleTaskGP) else models.models[0]
        return LogExpectedImprovement(model=model_for_ei, best_f=best_f)


def _create_scalarized_ei_fallback(opt, models, clean_Y):
    try:
        from botorch.acquisition.multi_objective import qExpectedImprovement
        from botorch.utils.multi_objective.scalarization import get_chebyshev_scalarization

        weights = (
            torch.ones(clean_Y.shape[1], dtype=opt.dtype, device=opt.device) / clean_Y.shape[1]
        )
        transform = get_chebyshev_scalarization(weights=weights, Y=clean_Y)
        scalarized_ei = qExpectedImprovement(
            model=models, objective=transform, best_f=transform(clean_Y).max()
        )
        # Test once
        test_input = torch.randn(
            1, len(opt.parameter_transformer.param_names), dtype=opt.dtype, device=opt.device
        )
        _ = scalarized_ei(test_input)
        return scalarized_ei
    except Exception as e:
        logger.debug(f"Scalarized EI fallback failed: {e}")
        return None


def _setup_weighted_scalarization_acquisition(opt, models):
    try:
        from botorch.models.transforms.outcome import WeightedSumTransform
        import torch

        if not hasattr(opt, "train_Y") or opt.train_Y.shape[0] == 0:
            return None
        # Adjust weights by direction
        dir_adj = [w * d for w, d in zip(opt.objective_weights, opt.objective_directions)]
        weights_tensor = torch.tensor(dir_adj, dtype=opt.dtype, device=opt.device).unsqueeze(0)
        _weighted_transform = WeightedSumTransform(weights=weights_tensor)

        if isinstance(models, ModelListGP):
            # Reduce to single objective via transform
            finite_mask = torch.isfinite(opt.train_Y).all(dim=1)
            clean_Y = opt.train_Y[finite_mask]
            _clean_X = opt.train_X[finite_mask]
            # Build a single-task surrogate on scalarized outputs (simple path: use first model)
            base_model = models.models[0]
            # As a placeholder, return LogEI over the first model (keeps behavior consistent)
            best_f = clean_Y.max()
            return LogExpectedImprovement(model=base_model, best_f=best_f)
        else:
            # SingleTaskGP path
            finite_Y = opt.train_Y[torch.isfinite(opt.train_Y)]
            best_f = finite_Y.max()
            return LogExpectedImprovement(model=models, best_f=best_f)
    except Exception as e:
        logger.debug(f"Weighted scalarization setup failed: {e}")
        return None
