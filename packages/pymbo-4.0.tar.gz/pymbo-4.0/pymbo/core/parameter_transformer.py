"""Parameter transformation utilities for PyMBO."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

import torch

logger = logging.getLogger(__name__)

EPS = 1e-8


class SimpleParameterTransformer:
    """
    Transforms parameters between their original scale/representation and a normalized
    tensor representation (typically [0, 1]) suitable for Bayesian optimization models.
    Handles continuous, discrete, and categorical parameter types.
    """

    def __init__(self, params_config: Dict[str, Dict[str, Any]]):
        """
        Initializes the transformer with parameter configurations.

        Args:
            params_config: A dictionary where keys are parameter names and values
                           are dictionaries containing 'type' (e.g., 'continuous',
                           'discrete', 'categorical') and 'bounds' or 'values'.
        """
        self.params_config = params_config
        self.param_names = list(params_config.keys())
        self.n_params = len(self.param_names)

        # Stores the min/max bounds for each parameter in its normalized space.
        # For continuous/discrete numeric parameters these are the actual bounds; for enumerations
        # we use index ranges and maintain explicit lookup tables.
        self.bounds = []
        self.param_types: Dict[str, str] = {}
        self.param_numeric_bounds: Dict[str, Optional[Tuple[float, float]]] = {}
        self.discrete_choices: Dict[str, List[Any]] = {}
        self.discrete_index_lookup: Dict[str, Dict[Any, int]] = {}
        self.categorical_choices: Dict[str, List[Any]] = {}
        self.categorical_index_lookup: Dict[str, Dict[Any, int]] = {}
        self.categorical_mappings: Dict[str, Dict[Any, int]] = {}

        # Iterate through each parameter to set up its transformation rules and bounds.
        for i, (name, config) in enumerate(params_config.items()):
            if "type" not in config:
                raise ValueError(f"Parameter '{name}' is missing required 'type' field")
            param_type = config["type"]
            self.param_types[name] = param_type

            if param_type == "continuous":
                bounds = config.get("bounds")
                if not bounds or len(bounds) != 2:
                    raise ValueError(
                        f"Continuous parameter '{name}' must define two-element 'bounds'"
                    )
                lower, upper = float(bounds[0]), float(bounds[1])
                if lower >= upper:
                    raise ValueError(f"Continuous parameter '{name}' has invalid bounds {bounds}")
                self.param_numeric_bounds[name] = (lower, upper)
                self.bounds.append([lower, upper])

            elif param_type == "discrete":
                values = config.get("values")
                bounds = config.get("bounds")
                if values:
                    values_list = list(values)
                    if not values_list:
                        raise ValueError(f"Discrete parameter '{name}' has empty 'values'")
                    self.discrete_choices[name] = values_list
                    self.discrete_index_lookup[name] = {v: idx for idx, v in enumerate(values_list)}
                    max_index = float(len(values_list) - 1) if len(values_list) > 1 else 0.0
                    self.param_numeric_bounds[name] = None
                    self.bounds.append([0.0, max_index])
                elif bounds and len(bounds) == 2:
                    lower, upper = int(bounds[0]), int(bounds[1])
                    if lower > upper:
                        raise ValueError(f"Discrete parameter '{name}' has invalid bounds {bounds}")
                    self.param_numeric_bounds[name] = (float(lower), float(upper))
                    self.bounds.append([float(lower), float(upper)])
                else:
                    raise ValueError(
                        f"Discrete parameter '{name}' must define either 'values' or two-element 'bounds'"
                    )

            elif param_type == "categorical":
                values = config.get("values")
                if not values:
                    raise ValueError(
                        f"Categorical parameter '{name}' must define non-empty 'values'"
                    )
                values_list = list(values)
                self.categorical_choices[name] = values_list
                index_lookup = {v: idx for idx, v in enumerate(values_list)}
                self.categorical_index_lookup[name] = index_lookup
                self.categorical_mappings[name] = index_lookup
                max_index = float(len(values_list) - 1) if len(values_list) > 1 else 0.0
                self.param_numeric_bounds[name] = None
                self.bounds.append([0.0, max_index])

            else:
                raise ValueError(f"Unknown parameter type '{param_type}' for parameter '{name}'")

        # Convert to tensor
        self.bounds_tensor = torch.tensor(self.bounds, dtype=torch.double)

        logger.info(f"Parameter transformer initialized for {self.n_params} parameters")

    def params_to_tensor(self, params_dict: Dict[str, Any]) -> torch.Tensor:
        """
        Converts a dictionary of parameters to a normalized PyTorch tensor.
        Continuous and discrete parameters are normalized to [0, 1].
        Categorical parameters are mapped to their integer index and then normalized.

        Args:
            params_dict: A dictionary where keys are parameter names and values
                         are their corresponding experimental values.

        Returns:
            A `torch.Tensor` of shape (n_params,) with normalized parameter values.
        """
        values = []
        for name in self.param_names:
            if name not in params_dict:
                raise ValueError(f"Parameter '{name}' missing from input data")
            raw_value = params_dict[name]
            param_type = self.param_types[name]

            if param_type == "continuous":
                lower, upper = self.param_numeric_bounds[name]
                numeric_value = float(raw_value)
                if numeric_value < lower - EPS or numeric_value > upper + EPS:
                    raise ValueError(
                        f"Parameter '{name}' value {numeric_value} outside bounds [{lower}, {upper}]"
                    )
                normalized = (numeric_value - lower) / (upper - lower)

            elif param_type == "discrete":
                if name in self.discrete_choices:
                    if raw_value not in self.discrete_index_lookup[name]:
                        raise ValueError(
                            f"Parameter '{name}' must be one of {self.discrete_choices[name]}, received {raw_value!r}"
                        )
                    choices = self.discrete_choices[name]
                    idx = self.discrete_index_lookup[name][raw_value]
                    normalized = 0.0 if len(choices) == 1 else idx / (len(choices) - 1)
                else:
                    lower, upper = self.param_numeric_bounds[name]
                    numeric_value = float(raw_value)
                    if abs(numeric_value - round(numeric_value)) > EPS:
                        raise ValueError(
                            f"Parameter '{name}' must be an integer within bounds [{int(lower)}, {int(upper)}], "
                            f"received {raw_value}"
                        )
                    integer_value = int(round(numeric_value))
                    if integer_value < lower or integer_value > upper:
                        raise ValueError(
                            f"Parameter '{name}' integer value {integer_value} outside bounds [{int(lower)}, {int(upper)}]"
                        )
                    span = upper - lower
                    normalized = 0.0 if span == 0 else (integer_value - lower) / span

            elif param_type == "categorical":
                if raw_value not in self.categorical_index_lookup[name]:
                    raise ValueError(
                        f"Parameter '{name}' must be one of {self.categorical_choices[name]}, received {raw_value!r}"
                    )
                choices = self.categorical_choices[name]
                idx = self.categorical_index_lookup[name][raw_value]
                normalized = 0.0 if len(choices) == 1 else idx / (len(choices) - 1)

            else:
                raise ValueError(f"Unsupported parameter type '{param_type}' for '{name}'")

            values.append(min(max(normalized, 0.0), 1.0))

        return torch.tensor(values, dtype=torch.double)

    def tensor_to_params(self, tensor: torch.Tensor) -> Dict[str, Any]:
        """
        Converts a normalized PyTorch tensor back to a dictionary of parameters
        in their original scale/representation.

        Args:
            tensor: A `torch.Tensor` of shape (n_params,) with normalized parameter values.

        Returns:
            A dictionary where keys are parameter names and values are their
            corresponding values in the original scale.
        """
        tensor = tensor.clamp(0, 1)
        params_dict: Dict[str, Any] = {}

        for i, name in enumerate(self.param_names):
            value = tensor[i].item()
            param_type = self.param_types[name]

            if param_type == "continuous":
                lower, upper = self.param_numeric_bounds[name]
                actual_value = lower + value * (upper - lower)
                precision = self.params_config[name].get("precision")
                if precision is not None:
                    actual_value = round(actual_value, precision)
                params_dict[name] = actual_value

            elif param_type == "discrete":
                if name in self.discrete_choices:
                    choices = self.discrete_choices[name]
                    if len(choices) == 1:
                        params_dict[name] = choices[0]
                    else:
                        idx = int(round(value * (len(choices) - 1)))
                        idx = max(0, min(idx, len(choices) - 1))
                        params_dict[name] = choices[idx]
                else:
                    lower, upper = self.param_numeric_bounds[name]
                    if lower == upper:
                        params_dict[name] = int(lower)
                    else:
                        span = upper - lower
                        projected = lower + value * span
                        snapped = int(round(projected))
                        snapped = int(min(max(snapped, int(lower)), int(upper)))
                        params_dict[name] = snapped

            elif param_type == "categorical":
                choices = self.categorical_choices[name]
                if len(choices) == 1:
                    params_dict[name] = choices[0]
                else:
                    idx = int(round(value * (len(choices) - 1)))
                    idx = max(0, min(idx, len(choices) - 1))
                    params_dict[name] = choices[idx]

            else:
                params_dict[name] = value

        return params_dict

    def _ensure_value_in_domain(self, name: str, value: Any) -> None:
        if value is None:
            raise ValueError(f"Parameter '{name}' value is None")

        param_type = self.param_types[name]
        if param_type == "continuous":
            lower, upper = self.param_numeric_bounds[name]
            numeric_value = float(value)
            if numeric_value < lower - EPS or numeric_value > upper + EPS:
                raise ValueError(
                    f"Parameter '{name}' value {numeric_value} outside bounds [{lower}, {upper}]"
                )

        elif param_type == "discrete":
            if name in self.discrete_choices:
                if value not in self.discrete_index_lookup[name]:
                    raise ValueError(
                        f"Parameter '{name}' must be one of {self.discrete_choices[name]}, received {value!r}"
                    )
            else:
                lower, upper = self.param_numeric_bounds[name]
                numeric_value = float(value)
                if abs(numeric_value - round(numeric_value)) > EPS:
                    raise ValueError(
                        f"Parameter '{name}' must be an integer within bounds [{int(lower)}, {int(upper)}], received {value}"
                    )
                integer_value = int(round(numeric_value))
                if integer_value < lower or integer_value > upper:
                    raise ValueError(
                        f"Parameter '{name}' integer value {integer_value} outside bounds [{int(lower)}, {int(upper)}]"
                    )

        elif param_type == "categorical":
            if value not in self.categorical_index_lookup[name]:
                raise ValueError(
                    f"Parameter '{name}' must be one of {self.categorical_choices[name]}, received {value!r}"
                )
        else:
            raise ValueError(f"Unsupported parameter type '{param_type}' for '{name}'")

    def _project_value_to_domain(self, name: str, value: Any) -> Any:
        if value is None:
            return value
        try:
            self._ensure_value_in_domain(name, value)
            return value
        except ValueError as exc:
            param_type = self.param_types[name]
            if param_type == "categorical":
                fallback = self.categorical_choices[name][0]
                logger.debug(
                    f"Projected categorical parameter '{name}' from {value!r} to {fallback!r}: {exc}"
                )
                return fallback
            if param_type == "discrete":
                if name in self.discrete_choices:
                    choices = self.discrete_choices[name]
                    fallback = choices[0]
                    try:
                        numeric_value = float(value)
                        numeric_choices = [float(v) for v in choices]
                        idx = min(
                            range(len(choices)),
                            key=lambda j: (abs(numeric_choices[j] - numeric_value), j),
                        )
                        fallback = choices[idx]
                    except Exception:
                        pass
                    logger.debug(
                        f"Projected discrete parameter '{name}' from {value!r} to {fallback!r}: {exc}"
                    )
                    return fallback
                lower, upper = self.param_numeric_bounds[name]
                snapped = round(float(value))
                if snapped < lower:
                    snapped = lower
                if snapped > upper:
                    snapped = upper
                logger.debug(
                    f"Projected discrete parameter '{name}' from {value!r} to {int(snapped)!r}: {exc}"
                )
                return int(snapped)
            if param_type == "continuous":
                lower, upper = self.param_numeric_bounds[name]
                clamped = min(max(float(value), lower), upper)
                logger.debug(
                    f"Projected continuous parameter '{name}' from {value!r} to {clamped!r}: {exc}"
                )
                return clamped
            return value

    def transform_to_unit_cube(self, params_dict: Dict[str, Any]) -> torch.Tensor:
        """
        Transform parameters from their original space to unit cube [0, 1]^d.

        Args:
            params_dict: Parameters in original space

        Returns:
            Parameters transformed to unit cube
        """
        return self.params_to_tensor(params_dict)

    def transform_from_unit_cube(self, unit_tensor: torch.Tensor) -> Dict[str, Any]:
        """
        Transform parameters from unit cube [0, 1]^d to original space.

        Args:
            unit_tensor: Parameters in unit cube space

        Returns:
            Parameters in original space
        """
        return self.tensor_to_params(unit_tensor)

    def transform_from_unit_cube_batch(self, unit_tensors: torch.Tensor) -> List[Dict[str, Any]]:
        """
        Transform batch of parameters from unit cube [0, 1]^d to original space.

        Args:
            unit_tensors: Batch of parameters in unit cube space (shape: batch_size x n_params)

        Returns:
            List of parameter dictionaries in original space
        """
        batch_results = []
        for i in range(unit_tensors.shape[0]):
            params_dict = self.tensor_to_params(unit_tensors[i])
            batch_results.append(params_dict)
        return batch_results

    def validate_parameter_constraints(self, params_dict: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validates that parameters satisfy their Range constraints and stay within their configured domains.
        Note: Target goals are now objectives, not constraints, so no validation needed.

        Args:
            params_dict: Parameters in original space

        Returns:
            Tuple of (is_valid, list_of_violated_constraints)
        """
        violations = []

        for name, config in self.params_config.items():
            value = params_dict.get(name)
            try:
                self._ensure_value_in_domain(name, value)
            except ValueError as exc:
                violations.append(str(exc))
                continue

            goal = config.get("goal", "None")
            if goal == "Range" and "range_bounds" in config:
                range_bounds = config["range_bounds"]
                if len(range_bounds) == 2:
                    range_min, range_max = range_bounds
                    if value < range_min or value > range_max:
                        violations.append(
                            f"Parameter '{name}' violates Range constraint: {value} not in range [{range_min}, {range_max}]"
                        )

        return len(violations) == 0, violations

    def enforce_parameter_constraints(self, params_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enforces Range parameter constraints by clipping values to feasible regions and projecting
        the result back into each parameter's domain.
        Note: Target goals are now objectives, not constraints, so no enforcement needed.
        Used as a safety mechanism to ensure generated suggestions are valid.

        Args:
            params_dict: Parameters in original space

        Returns:
            Constrained parameters in original space
        """
        constrained_params = params_dict.copy()

        for name, config in self.params_config.items():
            goal = config.get("goal", "None")
            value = constrained_params.get(name)

            if goal == "Range" and "range_bounds" in config and value is not None:
                range_bounds = config["range_bounds"]
                if len(range_bounds) == 2:
                    range_min, range_max = range_bounds
                    if value < range_min:
                        logger.debug(
                            f"Enforced Range constraint for '{name}': {value} -> {range_min}"
                        )
                        value = range_min
                    elif value > range_max:
                        logger.debug(
                            f"Enforced Range constraint for '{name}': {value} -> {range_max}"
                        )
                        value = range_max
                    constrained_params[name] = value

            constrained_params[name] = self._project_value_to_domain(
                name, constrained_params.get(name)
            )

        return constrained_params
