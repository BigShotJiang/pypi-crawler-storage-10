"""PyMBO public API
====================

High-level, supported entry points for embedding PyMBO in scripts and
pipelines. The goal is a small, stable surface: optimizers, orchestrator,
screening, kernel factory, and a deterministic benchmark harness.

Notes
-----
- GUI modules under ``pymbo.gui`` are internal and not part of the public API.
- Mixed-variable problems automatically use the Unified Exponential Kernel when
  available via :func:`create_kernel_for_parameters`.
- Reproducibility: pass ``random_seed`` and ``deterministic=True`` to
  :class:`EnhancedMultiObjectiveOptimizer`.

Examples
--------
>>> from pymbo import EnhancedMultiObjectiveOptimizer, OptimizationOrchestrator
>>> params = {"x": {"type": "continuous", "bounds": [0.0, 1.0]}}
>>> responses = {"f": {"goal": "Minimize"}}
>>> opt = EnhancedMultiObjectiveOptimizer(params, responses, random_seed=7, deterministic=True)
>>> orch = OptimizationOrchestrator(opt)
"""

__version__ = "4.0"
__author__ = "Jakub Jagielski"

# Public API surface
from .core.optimizer import EnhancedMultiObjectiveOptimizer, create_kernel_for_parameters
from .core.enhanced_optimizer import EfficientMultiObjectiveOptimizer
from .core.controller import SimpleController
from .core.orchestrator import OptimizationOrchestrator
from .core.advanced_sglbo_optimizer import AdvancedSGLBOOptimizer
from .screening import ScreeningOptimizer
from .benchmarks import (
    BenchmarkResult,
    available_single_objective,
    available_multi_objective,
    run_single_objective,
    run_multi_objective,
)

__all__ = [
    "EnhancedMultiObjectiveOptimizer",
    "EfficientMultiObjectiveOptimizer",
    "OptimizationOrchestrator",
    "SimpleController",
    "AdvancedSGLBOOptimizer",
    "ScreeningOptimizer",
    "create_kernel_for_parameters",
    "BenchmarkResult",
    "available_single_objective",
    "available_multi_objective",
    "run_single_objective",
    "run_multi_objective",
]
