"""
PyMBO - Python Multi-objective Bayesian Optimization Main Application

This is the main entry point for PyMBO v4.0.
It provides advanced Bayesian optimization with acquisition function visualization,
enhanced plotting capabilities, and flexible control panel interfaces.

Features:
- Multi-objective Bayesian optimization with PyTorch/BoTorch backend
- Real-time acquisition function heatmap visualization
- Interactive plot controls with fixed aspect ratios
- Comprehensive logging and error handling
- Dependency validation with version checking

Usage:
    python main.py

Requirements:
    - Python 3.8+
    - All dependencies listed in check_dependencies()
"""

import argparse
import logging
import os
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import tkinter as tk
    from tkinter import messagebox

    TK_AVAILABLE = True
except Exception:
    tk = None
    messagebox = None
    TK_AVAILABLE = False

import matplotlib
from . import __version__ as PYMBO_VERSION

# Configuration constants
APP_NAME = "PyMBO - Python Multi-objective Bayesian Optimization"
APP_VERSION = PYMBO_VERSION
LOG_DIR = Path("logs")
LOG_FILE = "optimization_enhanced.log"

BOOL_TRUE_VALUES = {"1", "true", "yes", "on"}
HEADLESS_ENV_VAR = "PYMBO_HEADLESS"
FORCE_LOGGING_ENV_VAR = "PYMBO_FORCE_LOGGING_CONFIG"

logger = logging.getLogger(__name__)


def _env_flag(name: str, default: bool = False) -> bool:
    """Return True if the environment variable is set to a truthy value."""
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in BOOL_TRUE_VALUES


def _parse_cli_args(argv: Optional[List[str]] = None) -> Tuple[argparse.Namespace, List[str]]:
    """Parse launcher command-line arguments."""
    parser = argparse.ArgumentParser(prog="pymbo", add_help=True)
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run without launching the GUI (or set PYMBO_HEADLESS=1).",
    )
    parser.add_argument(
        "--force-log-config",
        action="store_true",
        help="Force PyMBO to reconfigure root logging handlers.",
    )
    return parser.parse_known_args(argv)


def configure_matplotlib_backend(headless: bool) -> None:
    """Select an appropriate Matplotlib backend based on execution mode."""
    desired_backend = "Agg" if headless else "TkAgg"
    try:
        current_backend = matplotlib.get_backend()
    except Exception:
        current_backend = None

    if current_backend and current_backend.lower() == desired_backend.lower():
        return

    try:
        matplotlib.use(desired_backend)
    except Exception as exc:
        logger.warning("Failed to set Matplotlib backend to %s: %s", desired_backend, exc)


# Set stdout encoding to UTF-8 for broader character support
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def _log_banner() -> None:
    """Log a startup banner for interactive sessions."""
    banner_lines = [
        "=" * 70,
        f"  {APP_NAME} v{APP_VERSION}",
        "  Now with Acquisition Function Heatmap Visualization",
        "=" * 70,
    ]
    for line in banner_lines:
        logger.info(line)


def setup_logging(*, force_override: Optional[bool] = None) -> logging.Logger:
    """Setup logging handlers while respecting existing configurations."""
    try:
        if force_override is None:
            force_override = _env_flag(FORCE_LOGGING_ENV_VAR)

        root_logger = logging.getLogger()
        need_config = force_override or not root_logger.handlers

        log_format = "%(asctime)s | %(name)-20s | %(levelname)-8s | %(message)s"
        date_format = "%Y-%m-%d %H:%M:%S"

        if need_config:
            LOG_DIR.mkdir(exist_ok=True)
            logging.basicConfig(
                level=logging.INFO,
                format=log_format,
                datefmt=date_format,
                handlers=[
                    logging.FileHandler(LOG_DIR / LOG_FILE, encoding="utf-8", mode="a"),
                    logging.StreamHandler(sys.stdout),
                ],
                force=force_override,
            )

        external_loggers = [
            "matplotlib",
            "PIL",
            "torch",
            "botorch",
            "gpytorch",
            "sklearn",
            "urllib3",
            "requests",
        ]
        for logger_name in external_loggers:
            logging.getLogger(logger_name).setLevel(logging.WARNING)

        logger = logging.getLogger(__name__)
        if need_config:
            logger.info("Logging initialized - Log file: %s", LOG_DIR / LOG_FILE)
        else:
            logger.debug("Skipping logging configuration; root handlers already present.")
        return logger

    except Exception as exc:
        sys.stderr.write(f"Warning: Failed to setup enhanced logging: {exc}\n")
        logging.basicConfig(level=logging.INFO)
        return logging.getLogger(__name__)


def check_dependencies() -> Tuple[List[str], List[str], List[str]]:
    """Check for required dependencies with comprehensive version validation.

    Returns:
        Tuple containing:
        - missing_deps: List of missing required packages
        - available_deps: List of successfully imported packages
        - version_warnings: List of version compatibility warnings
    """
    # Core dependencies with minimum versions
    required_deps = {
        "numpy": "1.20.0",
        "pandas": "1.3.0",
        "matplotlib": "3.4.0",
        "scipy": "1.7.0",
        "sklearn": "1.0.0",
        "torch": "1.10.0",
        "botorch": "0.6.0",
        "gpytorch": "1.6.0",
        "seaborn": "0.11.0",
    }

    # Optional dependencies that enhance functionality
    optional_deps = {"packaging": "20.0", "plotly": "5.0.0", "ipython": "7.0.0"}

    missing_deps = []
    available_deps = []
    version_warnings = []

    # Check required dependencies
    for dep, min_version in required_deps.items():
        try:
            module = __import__(dep)
            available_deps.append(dep)

            # Version checking with better error handling
            if hasattr(module, "__version__"):
                current_version = module.__version__
                try:
                    from packaging import version

                    if version.parse(current_version) < version.parse(min_version):
                        version_warnings.append(
                            f"{dep} v{current_version} < recommended v{min_version}"
                        )
                except (ImportError, Exception):
                    # If packaging unavailable or version parsing fails
                    version_warnings.append(f"{dep} version check failed - ensure v{min_version}+")

        except ImportError:
            missing_deps.append(dep)
        except Exception as e:
            version_warnings.append(f"{dep} import warning: {str(e)}")

    # Check optional dependencies (don't add to missing_deps)
    for dep, min_version in optional_deps.items():
        try:
            module = __import__(dep)
            available_deps.append(dep)
        except ImportError:
            pass  # Optional dependencies don't cause failures

    return missing_deps, available_deps, version_warnings


def show_dependency_error(missing_deps: List[str], *, use_gui: bool = True) -> None:
    """Display dependency errors either via GUI dialog or console output."""
    logger = logging.getLogger(__name__)
    dependency_lines = "\n".join(f"  - {dep}" for dep in missing_deps)
    message = (
        "Missing Required Dependencies\n\n"
        f"{APP_NAME} v{APP_VERSION} requires the following packages:\n\n"
        f"{dependency_lines}\n\n"
        "Install with:\n"
        f"  pip install {' '.join(missing_deps)}\n"
    )

    if use_gui and TK_AVAILABLE:
        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.title("Dependency Error")
            messagebox.showerror("Missing Dependencies - Cannot Start", message)
            return
        except Exception as exc:
            logger.warning("Failed to display dependency dialog: %s", exc)
        finally:
            if root is not None:
                root.destroy()

    logger.error("Missing dependencies prevent startup: %s", ", ".join(missing_deps))
    sys.stderr.write("\n" + message + "\n")


def test_enhanced_components() -> bool:
    """Run a lightweight self-test of enhanced optimization components."""
    logger = logging.getLogger(__name__)
    logger.info("Running enhanced component self-test")

    try:
        from .core.optimizer import EnhancedMultiObjectiveOptimizer
        import pandas as pd

        test_params = {
            "Temperature": {"type": "continuous", "bounds": [25, 200], "goal": "None"},
            "Pressure": {"type": "continuous", "bounds": [1, 10], "goal": "None"},
        }
        test_responses = {"Yield": {"goal": "Maximize"}}

        optimizer = EnhancedMultiObjectiveOptimizer(
            params_config=test_params,
            responses_config=test_responses,
            general_constraints=[],
        )

        suggestions = optimizer.suggest_next_experiment(n_suggestions=1)
        if not suggestions:
            logger.warning("Component self-test did not produce suggestions")
            return False

        dummy_data = pd.DataFrame(
            {
                "Temperature": [50.0, 100.0, 150.0],
                "Pressure": [2.0, 5.0, 8.0],
                "Yield": [0.5, 0.8, 0.6],
            }
        )
        optimizer.add_experimental_data(dummy_data)

        try:
            models = optimizer._build_models()
            if models:
                optimizer._setup_acquisition_function(models)
                logger.info("Acquisition function components initialised")
            else:
                logger.warning("Insufficient data to build acquisition models during self-test")
        except Exception as exc:
            logger.warning("Acquisition function test warning: %s", exc)

        logger.info("Enhanced component self-test succeeded: %s", suggestions[0])
        return True

    except ImportError as exc:
        logger.error("Import error during enhanced component self-test: %s", exc)
        return False
    except Exception as exc:
        logger.exception("Enhanced component self-test failed: %s", exc)
        return False


def main(argv: Optional[List[str]] = None) -> int:
    """Enhanced main application entry point.

    Returns:
        int: Exit code (0 for success, 1 for error)
    """
    parsed_args, unknown_args = _parse_cli_args(argv or sys.argv[1:])
    headless = parsed_args.headless or _env_flag(HEADLESS_ENV_VAR)

    logger = setup_logging(force_override=parsed_args.force_log_config)
    if unknown_args:
        logger.debug("Ignoring unrecognised CLI arguments: %s", unknown_args)

    configure_matplotlib_backend(headless)

    if headless:
        logger.info("Headless mode enabled; GUI components will not be started.")
    else:
        _log_banner()
        if not TK_AVAILABLE:
            logger.error(
                "Tkinter is not available but GUI mode was requested. "
                "Install tkinter or run with --headless."
            )
            return 1

    try:
        # Check dependencies
        missing_deps, available_deps, version_warnings = check_dependencies()
        if missing_deps:
            logger.error("Missing dependencies: %s", missing_deps)
            show_dependency_error(missing_deps, use_gui=(not headless and TK_AVAILABLE))
            return 1

        logger.info("All dependencies available for enhanced features")
        logger.info("Available dependencies: %s", available_deps)

        if version_warnings:
            for warning in version_warnings:
                logger.warning("Version warning: %s", warning)

        if headless:
            logger.info("Headless mode completed dependency checks successfully.")
            return 0

        # Import enhanced application components
        logger.info("Importing enhanced application components...")

        app_modules = {}
        try:
            # Import core modules
            from .gui.gui import SimpleOptimizerApp
            from .core.controller import SimpleController

            app_modules["gui"] = SimpleOptimizerApp
            app_modules["controller"] = SimpleController

            # Try to import enhanced plotting
            try:
                from .utils.plotting import SimplePlotManager

                app_modules["plotting"] = SimplePlotManager
                logger.info("✓ Enhanced modules with plotting imported successfully")
                logger.info("✓ Acquisition function visualization available")
            except ImportError as plot_e:
                logger.warning(f"Enhanced plotting unavailable: {plot_e}")
                logger.info("✓ Core modules imported - basic functionality available")

        except ImportError as e:
            logger.error("Failed to import core modules: %s", e)
            error_msg = f"""Critical Import Error

Failed to import required application modules: {str(e)}

Possible solutions:
1. Ensure all Python files are in the same directory
2. Check that no files are corrupted or missing
3. Verify Python path and working directory
4. Try reinstalling dependencies

Technical details:
{traceback.format_exc()}"""

            if not headless and TK_AVAILABLE:
                try:
                    messagebox.showerror("Import Error", error_msg)
                except Exception as dialog_error:
                    logger.warning("Failed to display import error dialog: %s", dialog_error)
                    sys.stderr.write("\n" + error_msg + "\n")
            else:
                sys.stderr.write("\n" + error_msg + "\n")
            return 1

        # Create and start application
        logger.info("Creating application...")

        try:
            # Initialize application components
            app = app_modules["gui"]()
            controller = app_modules["controller"](view=app)
            app.set_controller(controller)

            logger.info("Application components initialized successfully")

            # Configure application window
            app.title(f"{APP_NAME} v{APP_VERSION}")
            app.set_status("Application ready")

            # Center the window with better error handling
            try:
                app.update_idletasks()
                width = max(app.winfo_width(), 800)  # Minimum width
                height = max(app.winfo_height(), 600)  # Minimum height
                screen_width = app.winfo_screenwidth()
                screen_height = app.winfo_screenheight()

                # Calculate center position
                x = max(0, (screen_width - width) // 2)
                y = max(0, (screen_height - height) // 2)

                app.geometry(f"{width}x{height}+{x}+{y}")
                logger.info(f"Window positioned at {x},{y} with size {width}x{height}")

            except Exception as pos_e:
                logger.warning(f"Window positioning failed: {pos_e}")
                # Continue without positioning

        except Exception as app_e:
            logger.error(f"Application creation failed: {app_e}")
            error_msg = f"Failed to create application: {str(app_e)}\n\nCheck the logs for details."
            try:
                messagebox.showerror("Application Error", error_msg)
            except:
                sys.stderr.write("\n" + error_msg + "\n")
            return 1

        logger.info("Starting main application loop...")

        # Show startup message about new features (optional)
        try:
            if "plotting" in app_modules:  # Only show if enhanced features available
                startup_msg = f"""🎆 Enhanced Features Available!

{APP_NAME} v{APP_VERSION} includes:

• Acquisition Function Heatmap - visualize optimization sampling strategy
• Enhanced plotting with improved parameter space visualization  
• Interactive control panels with fixed aspect ratios
• Real-time Bayesian optimization with PyTorch/BoTorch
• Multi-objective optimization support

📊 The Acquisition Function tab shows where the optimizer
will most likely suggest new experiments.

🔧 Control panels maintain aspect ratios for better visualization."""

                messagebox.showinfo("Enhanced Laboratory Ready", startup_msg)
        except Exception as msg_e:
            logger.debug(f"Startup message failed: {msg_e}")
            # Don't fail application if message box doesn't work

        # Start main application loop
        try:
            app.mainloop()
            logger.info("Application closed normally by user")
            return 0

        except Exception as loop_e:
            logger.error(f"Main loop error: {loop_e}")
            try:
                messagebox.showerror("Runtime Error", f"Application runtime error: {str(loop_e)}")
            except:
                sys.stderr.write(f"\nRuntime error: {loop_e}\n")
            return 1

    # This except block was moved above

    except KeyboardInterrupt:
        logger.info("Application interrupted by user (Ctrl+C)")
        sys.stderr.write("\nApplication interrupted by user\n")
        return 0

    except Exception as e:
        logger.error(f"Critical application error: {e}", exc_info=True)

        # Show comprehensive error dialog
        try:
            root = tk.Tk()
            root.withdraw()
            root.title("Critical Error")

            error_msg = f"""📢 Critical Application Error

An unexpected error occurred in {APP_NAME} v{APP_VERSION}:

{str(e)}

🔍 Technical Details:
{traceback.format_exc()}

📄 Log Information:
Check the log file at: {LOG_DIR / LOG_FILE}

🔧 Troubleshooting:
1. Restart the application
2. Check system resources (memory, disk space)
3. Verify all dependencies are properly installed
4. Check for file permission issues
5. Report this error if it persists

⚠️ This is an unexpected error. The application will now close."""

            messagebox.showerror("Critical Error - Application Will Close", error_msg)
            root.destroy()

        except Exception as dialog_e:
            # Fallback to console output if GUI fails
            sys.stderr.write(f"\nCRITICAL ERROR: {e}\n")
            sys.stderr.write(f"\nLog file: {LOG_DIR / LOG_FILE}\n")
            sys.stderr.write(f"\nDialog error: {dialog_e}\n")
            traceback.print_exc()

        return 1


if __name__ == "__main__":
    # Application startup banner
    sys.stdout.write(f"{APP_NAME} v{APP_VERSION}\n")
    sys.stdout.write("=" * 60 + "\n")
    sys.stdout.write("Enhanced Bayesian Optimization with Acquisition Function Visualization\n")
    sys.stdout.write(f"Log directory: {LOG_DIR}\n")
    sys.stdout.write("\n")

    try:
        # Test enhanced components before starting main application
        sys.stdout.write("Running enhanced component checks...\n")

        component_test_passed = test_enhanced_components()

        if component_test_passed:
            sys.stdout.write("Enhanced component checks passed.\n")
            logger.info("Enhanced component self-test passed; launching application")
            exit_code = main()
            if exit_code == 0:
                logger.info("%s closed successfully", APP_NAME)
            else:
                logger.error("%s exited with error code %s", APP_NAME, exit_code)
            sys.exit(exit_code)

        logger.error("Enhanced component self-test failed; aborting startup")
        sys.stderr.write("Enhanced component checks failed. See log for details.\n")
        logger.info("Troubleshooting steps:")
        logger.info("  1. Ensure required dependencies are installed")
        logger.info("  2. Verify Python files are located correctly")
        logger.info("  3. Review the log file for detailed error information")
        logger.info("  4. Reinstall dependencies as needed (e.g., pip install --upgrade <package>)")
        logger.info("Log file location: %s", LOG_DIR / LOG_FILE)
        sys.exit(1)
    except KeyboardInterrupt:
        sys.stderr.write("\n\nStartup interrupted by user\n")
        sys.exit(0)

    except Exception as startup_e:
        sys.stderr.write(f"\nCRITICAL STARTUP ERROR: {startup_e}\n")
        sys.stderr.write(f"\nDetails:\n{traceback.format_exc()}")
        try:
            sys.stderr.write(f"\nCheck log file: {LOG_DIR / LOG_FILE}\n")
        except:
            pass
        sys.exit(1)
