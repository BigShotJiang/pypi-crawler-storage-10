"""
Warnings Configuration Module

Provides centralized warning configuration for PyMBO with optional
suppression controls.
"""

from __future__ import annotations

import os
import warnings
from typing import Iterable, Tuple, Type


# Known noisy modules whose user-level warnings can overwhelm the UI.
_TARGETED_SUPPRESSIONS: Tuple[Tuple[Type[Warning], str], ...] = (
    (UserWarning, "botorch"),
    (RuntimeWarning, "botorch"),
    (UserWarning, "gpytorch"),
    (FutureWarning, "sklearn"),
    (UserWarning, "pymoo"),
)

# Optional broad categories that can be silenced via opt-in settings.
_GENERAL_SUPPRESSIONS: Tuple[Type[Warning], ...] = (
    FutureWarning,
    DeprecationWarning,
)


def _apply_filters(pairs: Iterable[Tuple[Type[Warning], str | None]]) -> None:
    """Apply warning filters for the provided (category, module) pairs."""
    for category, module in pairs:
        kwargs = {"action": "ignore", "category": category}
        if module:
            kwargs["module"] = module
        warnings.filterwarnings(**kwargs)


def configure_warnings(*, suppress_general: bool | None = None) -> None:
    """Configure warning filters for PyMBO.

    Args:
        suppress_general: Explicit flag that controls broad warning suppression.
            If `None` (default), the value of the `PYMBO_SUPPRESS_GENERAL_WARNINGS`
            environment variable is used (`"1"`/`"true"` enables it).
    """
    _apply_filters((category, module) for category, module in _TARGETED_SUPPRESSIONS)

    if suppress_general is None:
        env_value = os.getenv("PYMBO_SUPPRESS_GENERAL_WARNINGS", "0").lower()
        suppress_general = env_value in {"1", "true", "yes"}

    if suppress_general:
        _apply_filters((category, None) for category in _GENERAL_SUPPRESSIONS)


# Configure warnings on import using default behaviour.
configure_warnings()
