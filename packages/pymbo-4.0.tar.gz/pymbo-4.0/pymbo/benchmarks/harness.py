"""Lightweight benchmarking harness for PyMBO optimizers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import torch

from pymbo.core.optimizer import EnhancedMultiObjectiveOptimizer
from pymbo.core.test_functions import get_test_function, TEST_FUNCTIONS


@dataclass
class BenchmarkResult:
    history: pd.DataFrame
    best_objectives: Dict[str, float]
    hypervolume: Optional[float] = None
    # Enriched metrics (optional depending on problem type)
    best_curve: Optional[List[float]] = None
    hv_history: Optional[List[float]] = None
    simple_regret: Optional[float] = None
    cumulative_regret: Optional[float] = None
    wall_clock_s: Optional[float] = None
    problem: Optional[str] = None
    dims: Optional[int] = None
    seed: Optional[int] = None


_SINGLE_OBJECTIVE_PROBLEMS: Sequence[str] = [
    name for name, cls in TEST_FUNCTIONS.items() if cls().n_objectives == 1
]
_MULTI_OBJECTIVE_PROBLEMS: Sequence[str] = [
    name for name, cls in TEST_FUNCTIONS.items() if cls().n_objectives > 1
]


def available_single_objective() -> List[str]:
    return list(_SINGLE_OBJECTIVE_PROBLEMS)


def available_multi_objective() -> List[str]:
    return list(_MULTI_OBJECTIVE_PROBLEMS)


def _evaluate_function(func, params: Dict[str, float]) -> np.ndarray:
    param_order = list(func.get_params_config().keys())
    x_tensor = torch.tensor([[params[name] for name in param_order]], dtype=torch.double)
    values = func.evaluate(x_tensor)
    if isinstance(values, torch.Tensor):
        values = values.detach().cpu().numpy()
    return values.reshape(-1)


def _aggregate_best(
    history: pd.DataFrame, responses_config: Dict[str, Dict[str, str]]
) -> Dict[str, float]:
    best = {}
    for response in responses_config:
        goal = responses_config[response].get("goal", "Maximize")
        column = history[response]
        if goal == "Minimize":
            best[response] = float(column.min())
        else:
            best[response] = float(column.max())
    return best


_TRUE_MINIMA: Dict[str, float] = {
    # Single-objective problems (minimise)
    "Sphere": 0.0,
    "Rosenbrock": 0.0,
    "Branin": 0.397887,  # ~ (pi^2)/5 - can vary by convention
    "Ackley": 0.0,
    "Hartmann3": -3.86278,
    "Hartmann6": -3.32237,
}


def run_single_objective(
    problem: str, *, iterations: int = 10, seed: Optional[int] = None
) -> BenchmarkResult:
    if problem not in _SINGLE_OBJECTIVE_PROBLEMS:
        raise ValueError(
            f"Unknown single-objective benchmark '{problem}'. Available: {available_single_objective()}"
        )

    function = get_test_function(problem)
    optimizer = EnhancedMultiObjectiveOptimizer(
        params_config=function.get_params_config(),
        responses_config=function.get_responses_config(),
        general_constraints=[],
        random_seed=seed,
        deterministic=True,
        fast_validation_mode=True,
    )

    import time

    start = time.perf_counter()

    history_rows: List[Dict[str, float]] = []
    best_curve: List[float] = []
    best_val = float("inf")
    for _ in range(iterations):
        suggestion = optimizer.suggest_next_experiment(n_suggestions=1)[0]
        values = _evaluate_function(function, suggestion)
        fval = float(values[0])
        best_val = min(best_val, fval)
        best_curve.append(best_val)
        record = {**suggestion, "f1": fval}
        optimizer.add_experimental_data(pd.DataFrame([record]), is_optimization_result=True)
        history_rows.append(record)

    history = pd.DataFrame(history_rows)
    best = _aggregate_best(history, function.get_responses_config())
    true_min = _TRUE_MINIMA.get(problem)
    simple_regret = (
        (best_curve[-1] - true_min) if (true_min is not None and len(best_curve) > 0) else None
    )
    cumulative_regret = (
        sum(v - true_min for v in best_curve)
        if (true_min is not None and len(best_curve) > 0)
        else None
    )
    wall = time.perf_counter() - start

    return BenchmarkResult(
        history=history,
        best_objectives=best,
        best_curve=best_curve,
        simple_regret=simple_regret,
        cumulative_regret=cumulative_regret,
        wall_clock_s=wall,
        problem=problem,
        dims=len(function.get_params_config()),
        seed=seed,
    )


def run_multi_objective(
    problem: str, *, iterations: int = 10, seed: Optional[int] = None
) -> BenchmarkResult:
    if problem not in _MULTI_OBJECTIVE_PROBLEMS:
        raise ValueError(
            f"Unknown multi-objective benchmark '{problem}'. Available: {available_multi_objective()}"
        )

    function = get_test_function(problem)
    responses_config = function.get_responses_config()

    optimizer = EnhancedMultiObjectiveOptimizer(
        params_config=function.get_params_config(),
        responses_config=responses_config,
        general_constraints=[],
        random_seed=seed,
        deterministic=True,
        fast_validation_mode=True,
    )

    import time

    start = time.perf_counter()

    history_rows: List[Dict[str, float]] = []
    hv_history: List[float] = []
    for _ in range(iterations):
        suggestion = optimizer.suggest_next_experiment(n_suggestions=1)[0]
        values = _evaluate_function(function, suggestion)
        record = {**suggestion}
        for idx, response in enumerate(responses_config.keys()):
            record[response] = float(values[idx])
        optimizer.add_experimental_data(pd.DataFrame([record]), is_optimization_result=True)
        history_rows.append(record)
        try:
            hv = optimizer._calculate_hypervolume().get("raw_hypervolume")
            if hv is not None:
                hv_history.append(float(hv))
        except Exception:
            # Keep robustness: HV may be undefined early on
            pass

    history = pd.DataFrame(history_rows)
    best = _aggregate_best(history, responses_config)
    hypervolume = (
        optimizer._calculate_hypervolume().get("raw_hypervolume")
        if len(responses_config) > 1
        else None
    )
    wall = time.perf_counter() - start
    return BenchmarkResult(
        history=history,
        best_objectives=best,
        hypervolume=hypervolume,
        hv_history=hv_history if hv_history else None,
        wall_clock_s=wall,
        problem=problem,
        dims=len(function.get_params_config()),
        seed=seed,
    )
