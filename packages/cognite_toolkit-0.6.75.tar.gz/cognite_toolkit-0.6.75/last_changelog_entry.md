## cdf 

### Added

- [alpha] New command `cdf data download hierarchy` that enable you to
download an entire asset-hierarchy.

### Fixed

- [alpha] The command `cdf data purge dataset` no longer fails if the
alpha flag `infield` is activated and the APM is missing.

## templates

No changes.