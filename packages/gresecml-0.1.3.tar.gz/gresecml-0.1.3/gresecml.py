import os
import click
from gresecml.commands.tensorflow_group import tf as tf_group

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' # Suppress TensorFlow logging from console

@click.group()
def cli():
    pass
cli.add_command(tf_group)
