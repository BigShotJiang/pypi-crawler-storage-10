"""
Ukraine: A Data Science Toolkit
"""
__version__ = "0.1.1"