Changes
=======

0.4 (2025-10-25)
----------------

- Pin upper versions of dependencies.
  [rnix]


0.3 (2022-10-06)
----------------

- Modernize JavaScript.
  [rnix]


0.2 (2020-07-09)
----------------

- Add ``show_contextmenu`` to ``CalendarTile``. Defaults to ``False``.
  [rnix]

- Also check for action length when handling actions dropdown in JS.
  [rnix]


0.1 (2020-05-30)
----------------

- Initial.
  [rnix, thet]
