# -*- coding: utf-8 -*-

"""
CDK Stack Deployment Utilities

This module provides utilities for deploying and managing AWS CDK stacks programmatically.
It handles CDK CLI operations, CloudFormation stack management, and lifecycle operations.
"""

import json
import pathlib
import shutil
import subprocess  # nosec B404 - subprocess used for secure CDK CLI operations
import tempfile
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import boto3
from aws_cdk import App
from botocore.exceptions import ClientError
from core_mixins.logger import get_logger


@dataclass
class DeploymentResult:
    """
    Result of a CDK stack deployment operation.

    :param stack_name: Name of the deployed stack.
    :param success: Whether deployment was successful.
    :param outputs: Stack outputs from CloudFormation.
    :param error: Error message if deployment failed.
    :param duration_seconds: Time taken for deployment.
    """

    stack_name: str
    success: bool
    outputs: Dict[str, str] = field(default_factory=dict)
    error: Optional[str] = None
    duration_seconds: float = 0.0


@dataclass
class StackStatus:
    """
    Current status of a CloudFormation stack.

    :param stack_name: Name of the stack.
    :param status: CloudFormation status (e.g., CREATE_COMPLETE, UPDATE_IN_PROGRESS).
    :param exists: Whether the stack exists.
    :param resources_count: Number of resources in the stack.
    :param outputs: The stack's outputs.
    """

    stack_name: str
    status: str
    exists: bool
    resources_count: int = 0
    outputs: Dict[str, str] = field(default_factory=dict)


class Deployer:
    """
    Deploys and manages CDK stacks programmatically. This class provides
    a convenient interface for CDK operations without requiring a full CDK project
    structure. It manages temporary directories, tracks deployed stacks, and
    provides cleanup capabilities.

    :param folder_name: Prefix for temporary directory creation
    :param auto_approve: Automatically approve deployments without confirmation
    :param region: AWS region for deployment (defaults to session region)

    Example::

        from aws_cdk import App
        from core_aws_cdk.utils.deployment import Deployer
        from core_aws_cdk.stacks.ecs.cluster.base import ECSClusterStack

        deployer = Deployer(folder_name="test_deployment")
        deployer.bootstrap()

        app = App(outdir=str(deployer.cdk_out_dir))

        stack = ECSClusterStack(
            app,
            "TestCluster",
            cluster_name="my-cluster",
            enable_fargate=True)

        deployer.synthesize(app)
        result = deployer.deploy_stack("TestCluster")

        if result.success:
            print(f"Deployment successful: {result.outputs}")

        deployer.cleanup_all()
    """

    def __init__(
        self,
        folder_name: str = "cdk_deployment",
        auto_approve: bool = True,
        region: str = "us-east-1",
    ) -> None:
        """
        Initialize the Deployer.

        :param folder_name: Prefix for temporary directory
        :param auto_approve: Auto-approve deployments
        :param region: AWS region
        """

        self.temp_dir = pathlib.Path(tempfile.mkdtemp(prefix=f"{folder_name}_"))
        self.cdk_out_dir = self.temp_dir / "cdk.out"
        self.auto_approve = auto_approve
        self.deployed_stacks: List[str] = []

        self.region = region or boto3.Session().region_name or "us-east-1"
        self.cloudformation_client = boto3.client("cloudformation", region_name=self.region)

        self.logger = get_logger(__name__)

        self.logger.info(
            "Deployer initialized: temp_dir=%s, region=%s",
            self.temp_dir, self.region
        )

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - automatic cleanup."""
        self.cleanup_all()

    def bootstrap(
        self,
        account: Optional[str] = None,
        region: Optional[str] = None,
        force: bool = False,
    ) -> bool:
        """
        Bootstrap the AWS environment for CDK deployments. This creates the
        necessary S3 bucket, ECR repositories, and IAM roles or other resources
        required for CDK deployments with assets.

        Bootstrap is required when your stacks use:
        - Assets (Lambda code, Docker images, large CloudFormation templates > 50KB).
        - File assets (need S3 bucket for storage).
        - Docker image assets (need ECR repository).
        - Cross-account/cross-region deployments.
        - Lookup operations (VPC/subnet/AMI lookups).

        You can skip bootstrap if:
        - Your stacks don't use any assets.
        - All templates are small (< 50KB).
        - No Lambda functions with local code.
        - No Docker containers.
        - Simple infrastructure only.

        :param account: AWS account ID (uses current account if None)
        :param region: AWS region (uses deployer region if None)
        :param force: Force re-bootstrap even if already bootstrapped
        :return: True if bootstrap was successful
        """

        account = account or boto3.client("sts").get_caller_identity()["Account"]
        region = region or self.region

        self.logger.info("Bootstrapping CDK environment: %s/%s", account, region)
        bootstrap_cmd = ["cdk", "bootstrap", f"aws://{account}/{region}"]

        if force:
            bootstrap_cmd.append("--force")

        try:
            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                bootstrap_cmd,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(self.temp_dir),
                check=False,
            )

            if result.returncode != 0:
                self.logger.error("Bootstrap failed: %s", result.stderr)
                return False

            self.logger.info("Bootstrap completed successfully")
            return True

        except (subprocess.TimeoutExpired, OSError) as e:
            self.logger.error("Bootstrap error: %s", e)
            return False

    def clear_context(
        self,
        force: bool = False,
    ) -> bool:
        """
        Clear CDK context cache to force fresh lookups on
        next synthesis.

        This is useful when:
        - VPC/subnet lookups are returning stale data
        - Availability zones have changed
        - You want to force re-lookup of AWS resources
        - Context has become corrupted or incorrect

        :param force: Skip confirmation and force clear
        :return: True if context was cleared successfully

        Example::

            deployer = Deployer("test")
            deployer.clear_context()  # Clear all cached context
            deployer.synthesize(app)  # Will perform fresh lookups
        """

        self.logger.info("Clearing CDK context cache...")

        # Try using cdk context --clear command
        try:
            clear_cmd = ["cdk", "context", "--clear"]

            if force:
                clear_cmd.append("--force")

            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                clear_cmd,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(self.temp_dir),
                check=False,
            )

            if result.returncode != 0:
                self.logger.warning("CDK context clear returned non-zero: %s", result.stderr)
                # Fall back to manual deletion
                self._clear_context_files()
                return True

            self.logger.info("Context cleared successfully via CDK CLI")
            return True

        except (subprocess.TimeoutExpired, OSError) as e:
            self.logger.warning("CDK context clear failed: %s, falling back to manual deletion", e)
            # Fall back to manual file deletion
            return self._clear_context_files()

    def _clear_context_files(self) -> bool:
        """
        Manually delete context files as fallback.

        :return: True if files were deleted successfully
        :rtype: bool
        """

        try:
            context_file = self.temp_dir / "cdk.context.json"

            if context_file.exists():
                context_file.unlink()
                self.logger.info("Deleted context file: %s", context_file)

            # Also check in cdk.out directory
            cdk_out_context = self.cdk_out_dir / "cdk.context.json"
            if cdk_out_context.exists():
                cdk_out_context.unlink()
                self.logger.info("Deleted context file: %s", cdk_out_context)

            return True

        except OSError as e:
            self.logger.error("Failed to delete context files: %s", e)
            return False

    def synthesize(self, app: App) -> None:
        """
        Synthesize CDK app to CloudFormation templates.

        :param app: CDK App instance to synthesize
        :raises RuntimeError: If synthesis fails
        """

        self.logger.info("Synthesizing CDK app...")

        try:
            app.synth()
            self.logger.info("CDK synthesis complete: %s", self.cdk_out_dir)

        except Exception as e:
            self.logger.error("CDK synthesis failed: %s", e)
            raise RuntimeError(f"Failed to synthesize CDK app: {e}") from e

    def deploy_stack(
        self,
        stack_name: str,
        timeout_seconds: int = 900,
        context: Optional[Dict[str, str]] = None,
    ) -> DeploymentResult:
        """
        Deploy a CDK stack to AWS.

        :param stack_name: Name of the stack to deploy.
        :param timeout_seconds: Maximum time to wait for deployment.
        :param context: CDK context values.

        :return: Deployment result with outputs and status.
        :raises RuntimeError: If deployment fails.
        """

        self.logger.info("Deploying stack: %s", stack_name)
        start_time = time.time()

        # Build deploy command
        deploy_cmd = [
            "cdk",
            "deploy",
            stack_name,
            "--app",
            str(self.cdk_out_dir),
            "--outputs-file",
            str(self.temp_dir / "outputs.json"),
        ]

        if self.auto_approve:
            deploy_cmd.extend(["--require-approval", "never"])

        # Add context values if provided
        if context:
            for key, value in context.items():
                deploy_cmd.extend(["--context", f"{key}={value}"])

        self.logger.debug("Deploy command: %s", ' '.join(deploy_cmd))

        try:
            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                deploy_cmd,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                cwd=str(self.temp_dir),
                check=False,
            )

            duration = time.time() - start_time
            if result.returncode != 0:
                self.logger.error("Deploy failed: %s", result.stderr)

                return DeploymentResult(
                    stack_name=stack_name,
                    success=False,
                    error=result.stderr,
                    duration_seconds=duration,
                )

            self.logger.info("Stack %s deployed successfully in %.2fs", stack_name, duration)
            if stack_name not in self.deployed_stacks:
                self.deployed_stacks.append(stack_name)

            outputs = self._read_outputs(stack_name)

            return DeploymentResult(
                stack_name=stack_name,
                success=True,
                outputs=outputs,
                duration_seconds=duration,
            )

        except subprocess.TimeoutExpired:
            duration = time.time() - start_time
            error_msg = f"Deployment timed out after {timeout_seconds}s"
            self.logger.error(error_msg)

            return DeploymentResult(
                stack_name=stack_name,
                success=False,
                error=error_msg,
                duration_seconds=duration,
            )

        except (OSError, ValueError) as e:
            duration = time.time() - start_time
            self.logger.error("Deployment error: %s", e)

            return DeploymentResult(
                stack_name=stack_name,
                success=False,
                error=str(e),
                duration_seconds=duration,
            )

    def destroy_stack(
        self,
        stack_name: str,
        timeout_seconds: int = 900,
        force: bool = True,
    ) -> bool:
        """
        Destroy a CDK stack from AWS.

        :param stack_name: Name of the stack to destroy.
        :param timeout_seconds: Maximum time to wait for destruction.
        :param force: Skip confirmation prompts.
        :return: True if destruction was successful.
        """

        self.logger.info("Destroying stack: %s", stack_name)

        destroy_cmd = [
            "cdk",
            "destroy",
            stack_name,
            "--app",
            str(self.cdk_out_dir),
        ]

        if force:
            destroy_cmd.append("--force")

        self.logger.debug("Destroy command: %s", ' '.join(destroy_cmd))

        try:
            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                destroy_cmd,
                capture_output=True,
                text=True,
                timeout=timeout_seconds,
                cwd=str(self.temp_dir),
                check=False,
            )

            if result.returncode != 0:
                self.logger.warning("Destroy returned non-zero: %s", result.stderr)
                return False

            self.logger.info("Stack %s destroyed successfully", stack_name)
            if stack_name in self.deployed_stacks:
                self.deployed_stacks.remove(stack_name)

            return True

        except subprocess.TimeoutExpired:
            self.logger.error("Destroy timed out after %ss", timeout_seconds)
            return False

        except (OSError, ValueError) as e:
            self.logger.error("Destroy error: %s", e)
            return False

    def diff_stack(self, stack_name: str) -> Optional[str]:
        """
        Show differences between deployed and synthesized stack.

        :param stack_name: Name of the stack to diff.
        :return: Difference output as string, or None if diff fails.
        """

        self.logger.info("Running diff for stack: %s", stack_name)

        diff_cmd = [
            "cdk",
            "diff",
            stack_name,
            "--app",
            str(self.cdk_out_dir),
        ]

        try:
            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                diff_cmd,
                capture_output=True,
                text=True,
                timeout=60,
                cwd=str(self.temp_dir),
                check=False,
            )

            return result.stdout

        except (OSError, ValueError) as e:
            self.logger.error("Diff error: %s", e)
            return None

    def list_stacks(self) -> List[str]:
        """
        List all stacks available in the synthesized CDK app.
        :return: List of stack names.
        """

        self.logger.info("Listing available stacks")

        list_cmd = [
            "cdk",
            "list",
            "--app",
            str(self.cdk_out_dir),
        ]

        try:
            result = subprocess.run(  # nosec B603 - controlled CDK CLI command
                list_cmd,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(self.temp_dir),
                check=False,
            )

            if result.returncode == 0:
                stacks = [line.strip() for line in result.stdout.split("\n") if line.strip()]
                self.logger.info("Found %s stacks: %s", len(stacks), stacks)
                return stacks

            self.logger.warning("List command failed: %s", result.stderr)
            return []

        except (OSError, ValueError) as e:
            self.logger.error("List error: %s", e)
            return []

    def get_stack_status(self, stack_name: str) -> StackStatus:
        """
        Get the current status of a CloudFormation stack.

        :param stack_name: Name of the stack.
        :return: Stack status information.
        """

        try:
            self.logger.debug("Querying stack status: %s", stack_name)
            response = self.cloudformation_client.describe_stacks(StackName=stack_name)

            if not response.get("Stacks"):
                return StackStatus(
                    stack_name=stack_name,
                    status="NOT_FOUND",
                    exists=False,
                )

            stack = response["Stacks"][0]
            outputs = {
                output["OutputKey"]: output["OutputValue"]
                for output in stack.get("Outputs", [])
            }

            try:
                resources_count = len(
                    self.cloudformation_client.list_stack_resources(
                        StackName=stack_name
                    ).get("StackResourceSummaries", [])
                )

            except (ClientError, KeyError):
                resources_count = 0

            return StackStatus(
                stack_name=stack_name,
                status=stack["StackStatus"],
                exists=True,
                resources_count=resources_count,
                outputs=outputs,
            )

        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            if error_code == "ValidationError":
                return StackStatus(
                    stack_name=stack_name,
                    status="NOT_FOUND",
                    exists=False,
                )

            self.logger.error("Error querying stack status: %s", e)
            raise

        except Exception as e:
            self.logger.error("Unexpected error querying stack: %s", e)
            raise

    def wait_for_stack(
        self,
        stack_name: str,
        target_status: str,
        max_wait_seconds: int = 600,
        poll_interval: int = 10,
    ) -> bool:
        """
        Wait for a stack to reach a specific status.

        :param stack_name: Name of the stack.
        :param target_status: CloudFormation status to wait for (e.g., CREATE_COMPLETE).
        :param max_wait_seconds: Maximum time to wait.
        :param poll_interval: Seconds between status checks.
        :return: True if target status reached.
        """

        self.logger.info("Waiting for %s to reach %s", stack_name, target_status)
        start_time = time.time()

        while time.time() - start_time < max_wait_seconds:
            status = self.get_stack_status(stack_name)

            if not status.exists:
                self.logger.warning("Stack %s does not exist", stack_name)
                return False

            self.logger.debug("Current status: %s", status.status)

            if status.status == target_status:
                self.logger.info("Stack reached %s", target_status)
                return True

            # Check for failure states
            if "FAILED" in status.status or "ROLLBACK" in status.status:
                self.logger.error("Stack entered failure state: %s", status.status)
                return False

            time.sleep(poll_interval)

        self.logger.error("Timeout waiting for %s", target_status)
        return False

    def cleanup_all(self) -> None:
        """
        Destroy all tracked stacks and clean up temporary directory.
        Stacks are destroyed in reverse order of deployment.
        """

        self.logger.info("Cleaning up %s deployed stacks", len(self.deployed_stacks))

        for stack_name in reversed(self.deployed_stacks):
            try:
                self.destroy_stack(stack_name)

            except (OSError, ValueError, RuntimeError) as e:
                self.logger.warning("Failed to destroy stack %s: %s", stack_name, e)

        try:
            self.logger.info("Removing temporary directory: %s", self.temp_dir)
            shutil.rmtree(self.temp_dir, ignore_errors=True)

        except OSError as e:
            self.logger.warning("Failed to remove temp directory: %s", e)

    def _read_outputs(self, stack_name: str) -> Dict[str, str]:
        """
        Read stack outputs from CDK outputs file.

        :param stack_name: Name of the stack.
        :return: Dictionary of output key-value pairs.
        """

        outputs_file = self.temp_dir / "outputs.json"
        if not outputs_file.exists():
            self.logger.debug("No outputs file found")
            return {}

        try:
            with open(outputs_file, "r", encoding="utf-8") as f:
                all_outputs = json.load(f)

            stack_outputs = all_outputs.get(stack_name, {})
            self.logger.debug("Stack outputs: %s", stack_outputs)
            return stack_outputs

        except (OSError, json.JSONDecodeError, KeyError) as e:
            self.logger.warning("Failed to read outputs: %s", e)
            return {}
