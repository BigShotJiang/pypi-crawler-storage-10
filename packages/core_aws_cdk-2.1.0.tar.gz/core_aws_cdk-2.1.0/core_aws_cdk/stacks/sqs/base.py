# -*- coding: utf-8 -*-

"""
SQS Stack for AWS CDK.

This module provides a base stack for creating and managing
Amazon SQS queues with support for dead-letter queues (DLQ),
visibility timeouts, and long polling.
"""

from typing import Any
from typing import Optional

from aws_cdk import Duration
from aws_cdk import RemovalPolicy
from aws_cdk import aws_sqs as sqs

from core_aws_cdk.stacks.base import BaseStack


class BaseSqsStack(BaseStack):
    """
    Base SQS stack providing queue creation and management.

    Extends BaseStack to provide:
    - Standard SQS queue creation with configurable settings
    - Optional dead-letter queue (DLQ) support
    - Long polling configuration
    - Visibility timeout management
    - Automatic tagging and lifecycle policies
    """

    # pylint: disable=too-many-arguments,too-many-positional-arguments
    def create_sqs_queue(
        self,
        queue_id: str,
        queue_name: Optional[str],
        receive_message_wait_time: Optional[Duration] = Duration.seconds(20),
        removal_policy: Optional[RemovalPolicy] = RemovalPolicy.DESTROY,
        visibility_timeout: Optional[Duration] = Duration.minutes(5),
        with_dlq: bool = False,
        dlq_id: Optional[str] = None,
        dlq_name: Optional[str] = None,
        max_receive_count: int = 3,
        **kwargs: Any
    ) -> sqs.Queue:
        """
        Create a new Amazon SQS queue with optional dead-letter queue.

        :param queue_id: Construct ID for the queue resource
        :param queue_name: Name of the SQS queue (must be unique within region)

        :param receive_message_wait_time:
            Long polling wait time (default: 20 seconds).
            Set to 0 to disable long polling.

        :param removal_policy:
            Policy for resource removal on stack deletion
            (default: DESTROY)

        :param visibility_timeout:
            Time a message is invisible after being received
            (default: 5 minutes). Should be longer than
            your processing time.

        :param with_dlq: If True, creates a dead-letter queue (default: False)
        :param dlq_id: Construct ID for the DLQ (required if with_dlq=True)
        :param dlq_name: Name of the dead-letter queue

        :param max_receive_count:
            Number of times a message can be received before
            moving to DLQ (default: 3)

        :param kwargs: Additional queue properties

        :return: The created SQS queue
        :raises ValueError: If with_dlq=True but dlq_id is not provided

        For additional configuration options, see:
        https://docs.aws.amazon.com/cdk/api/v2/python/aws_cdk.aws_sqs/Queue.html
        """

        dead_letter_queue = None
        if with_dlq:
            if dlq_id is None:
                raise ValueError(
                    "The attribute `dlq_id` is required when `with_dlq` is True!"
                )

            dead_letter_queue = sqs.DeadLetterQueue(
                max_receive_count=max_receive_count,
                queue=sqs.Queue(  # type: ignore
                    self,
                    id=dlq_id,
                    queue_name=dlq_name,
                    removal_policy=removal_policy,
                ))

        return sqs.Queue(
            self, queue_id,
            queue_name=queue_name,
            receive_message_wait_time=receive_message_wait_time,
            visibility_timeout=visibility_timeout,
            dead_letter_queue=dead_letter_queue,
            removal_policy=removal_policy,
            **kwargs
        )
