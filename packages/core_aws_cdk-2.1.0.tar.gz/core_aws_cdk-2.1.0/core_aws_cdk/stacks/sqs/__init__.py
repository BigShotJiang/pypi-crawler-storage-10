# -*- coding: utf-8 -*-

"""SQS (Simple Queue Service) stack module."""

from .base import BaseSqsStack


__all__ = [
    "BaseSqsStack",
]
