# -*- coding: utf-8 -*-

"""Base stack with tagging support for AWS CDK infrastructure."""

from typing import Any
from typing import Dict
from typing import Optional

from aws_cdk import Stack, Tags, RemovalPolicy
from aws_cdk import aws_iam as iam
from aws_cdk import aws_logs as logs
from constructs import Construct


class BaseStack(Stack):
    """
    Base stack providing common functionality for AWS CDK infrastructure resources.

    Provides centralized management of:
    - Global tagging across all resources
    - Default log retention policies
    - Default removal policies for resource lifecycle management
    - IAM policy lookup utilities
    """

    # pylint: disable=too-many-arguments
    # pylint: disable=too-many-positional-arguments
    # pylint: disable=redefined-builtin
    def __init__(
        self,
        scope: Construct,
        id: str,
        default_log_retention: logs.RetentionDays = logs.RetentionDays.ONE_YEAR,
        default_removal_policy: RemovalPolicy = RemovalPolicy.RETAIN,
        global_tags: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> None:
        """
        Initialize the BaseStack with optional configuration.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID.

        :param default_log_retention:
            Default retention period for CloudWatch
            logs (default: ONE_YEAR).

        :param default_removal_policy:
            Default policy for resource removal on stack deletion
            (default: RETAIN).

        :param global_tags:
            Optional dictionary of tags to apply to all resources
            in the stack hierarchy.

        :param kwargs: Additional Stack properties.
        """

        super().__init__(scope, id, **kwargs)

        self.default_log_retention = default_log_retention
        self.default_removal_policy = default_removal_policy
        self.global_tags = global_tags or {}

        # Apply tags to the stack level (will propagate to all resources)
        for key, value in self.global_tags.items():
            Tags.of(self).add(key, value)

    @staticmethod
    def get_iam_policy(name: str) -> iam.IManagedPolicy:
        """
        Returns a managed policy by name.
        :param name: Policy's name.
        :return: The policy.
        """
        return iam.ManagedPolicy.from_aws_managed_policy_name(name)

    def apply_tags(
        self,
        resource: Construct,
        additional_tags: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Apply global tags and optional additional tags to a specific resource.

        :param resource: The CDK resource to tag.
        :param additional_tags: Optional additional tags to apply beyond global tags.
        """

        all_tags = {**self.global_tags, **(additional_tags or {})}
        for key, value in all_tags.items():
            Tags.of(resource).add(key, value)
